import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CanonicalVehicleService } from '../../core/services/canonical-vehicle.service';
import { VehicleParameters } from '../../core/models/vehicle.types';

@Component({
  selector: 'app-design-studio',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full overflow-y-auto p-4 space-y-6 text-slate-200">
      <!-- Section Header -->
      <div class="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <h2 class="text-base font-semibold text-white tracking-wide flex items-center gap-2">
            <mat-icon class="text-cyan-400 !w-5 !h-5 !text-lg">tune</mat-icon>
            Parametric Vehicle Design & Dimensions
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">Continuous geometric constraints linked to mass & aerodynamic solvers.</p>
        </div>
        
        <div class="flex items-center gap-2">
          <button 
            (click)="vehicleService.resetToDefaults()" 
            class="px-2.5 py-1 text-xs font-mono text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 transition flex items-center gap-1">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm">restart_alt</mat-icon>
            Reset
          </button>
        </div>
      </div>

      <!-- Variant Selector Presets -->
      <div class="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-2">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold">VEHICLE VARIANT PRESET</div>
        <div class="grid grid-cols-2 gap-2">
          <button 
            (click)="vehicleService.applyVariant('PREMIUM_EV')"
            [class.border-cyan-500]="vehicleService.activeVariant() === 'PREMIUM_EV'"
            [class.bg-cyan-950/40]="vehicleService.activeVariant() === 'PREMIUM_EV'"
            class="p-2.5 rounded-lg border border-slate-800 text-left hover:border-slate-700 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-white">Premium Modern EV</span>
              <span class="w-2.5 h-2.5 rounded-full bg-cyan-500"></span>
            </div>
            <div class="text-[10px] text-slate-400 mt-0.5">150 kW / 60 kWh / 18" Aero</div>
          </button>

          <button 
            (click)="vehicleService.applyVariant('SPORT')"
            [class.border-red-500]="vehicleService.activeVariant() === 'SPORT'"
            [class.bg-red-950/40]="vehicleService.activeVariant() === 'SPORT'"
            class="p-2.5 rounded-lg border border-slate-800 text-left hover:border-slate-700 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-white">GTI Sport Edition</span>
              <span class="w-2.5 h-2.5 rounded-full bg-red-500"></span>
            </div>
            <div class="text-[10px] text-slate-400 mt-0.5">-30mm Roof / Stiffer Chassis</div>
          </button>

          <button 
            (click)="vehicleService.applyVariant('COMFORT')"
            [class.border-amber-500]="vehicleService.activeVariant() === 'COMFORT'"
            [class.bg-amber-950/40]="vehicleService.activeVariant() === 'COMFORT'"
            class="p-2.5 rounded-lg border border-slate-800 text-left hover:border-slate-700 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-white">Heritage Comfort</span>
              <span class="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            </div>
            <div class="text-[10px] text-slate-400 mt-0.5">+20mm Roof / Recycled PET</div>
          </button>

          <button 
            (click)="vehicleService.applyVariant('BASE')"
            [class.border-slate-500]="vehicleService.activeVariant() === 'BASE'"
            [class.bg-slate-800/40]="vehicleService.activeVariant() === 'BASE'"
            class="p-2.5 rounded-lg border border-slate-800 text-left hover:border-slate-700 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-white">Base Fleet</span>
              <span class="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
            </div>
            <div class="text-[10px] text-slate-400 mt-0.5">Essential Efficiency / 16"</div>
          </button>
        </div>
      </div>

      <!-- Exterior Paint & Finish Selector -->
      <div class="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold">EXTERIOR PAINT FINISH</div>
        <div class="flex items-center gap-3">
          @for (c of paintColors; track c.hex) {
            <button 
              (click)="vehicleService.exteriorColorHex.set(c.hex)"
              [title]="c.name"
              [class.ring-2]="vehicleService.exteriorColorHex() === c.hex"
              [class.ring-white]="vehicleService.exteriorColorHex() === c.hex"
              class="w-7 h-7 rounded-full transition shadow-md hover:scale-110"
              [style.backgroundColor]="c.hex">
            </button>
          }
        </div>
      </div>

      <!-- Key Geometric Sliders -->
      <div class="space-y-4">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>PARAMETRIC DIMENSIONS (MM / DEG)</span>
          <span class="text-cyan-400 text-[10px]">LIVE SOLVER SYNC</span>
        </div>

        <!-- Roof Height -->
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800/80 space-y-2">
          <div class="flex justify-between items-center text-xs">
            <span class="text-slate-300 font-medium">Roof Height (Dachhöhe)</span>
            <span class="font-mono text-cyan-300 font-bold">{{ vehicleService.parameters().roof_height }} mm</span>
          </div>
          <input 
            type="range" 
            min="1420" 
            max="1580" 
            step="5"
            [value]="vehicleService.parameters().roof_height"
            (input)="onParamChange('roof_height', $event)"
            class="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg">
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>1420 mm (Low/Sport)</span>
            <span>Default: 1500 mm</span>
            <span>1580 mm (High Cabin)</span>
          </div>
        </div>

        <!-- Wheelbase -->
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800/80 space-y-2">
          <div class="flex justify-between items-center text-xs">
            <span class="text-slate-300 font-medium">Wheelbase (Radstand)</span>
            <span class="font-mono text-cyan-300 font-bold">{{ vehicleService.parameters().wheelbase }} mm</span>
          </div>
          <input 
            type="range" 
            min="2400" 
            max="2680" 
            step="10"
            [value]="vehicleService.parameters().wheelbase"
            (input)="onParamChange('wheelbase', $event)"
            class="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg">
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>2400 mm</span>
            <span>Default: 2540 mm</span>
            <span>2680 mm</span>
          </div>
        </div>

        <!-- Windshield Angle -->
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800/80 space-y-2">
          <div class="flex justify-between items-center text-xs">
            <span class="text-slate-300 font-medium">Windshield Rake Angle (Frontscheibenwinkel)</span>
            <span class="font-mono text-cyan-300 font-bold">{{ vehicleService.parameters().windshield_angle }}°</span>
          </div>
          <input 
            type="range" 
            min="48" 
            max="62" 
            step="1"
            [value]="vehicleService.parameters().windshield_angle"
            (input)="onParamChange('windshield_angle', $event)"
            class="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg">
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>48° (Upright)</span>
            <span>Default: 54°</span>
            <span>62° (Sleek Aero)</span>
          </div>
        </div>

        <!-- Ground Clearance -->
        <div class="bg-slate-900/60 p-3 rounded-xl border border-slate-800/80 space-y-2">
          <div class="flex justify-between items-center text-xs">
            <span class="text-slate-300 font-medium">Ground Clearance (Bodenfreiheit)</span>
            <span class="font-mono text-cyan-300 font-bold">{{ vehicleService.parameters().ground_clearance }} mm</span>
          </div>
          <input 
            type="range" 
            min="120" 
            max="180" 
            step="2"
            [value]="vehicleService.parameters().ground_clearance"
            (input)="onParamChange('ground_clearance', $event)"
            class="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg">
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>120 mm</span>
            <span>Default: 145 mm</span>
            <span>180 mm</span>
          </div>
        </div>

        <!-- Sheet Metal Thicknesses -->
        <div class="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-3">
          <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold">GAUGE THICKNESSES (STAMPING)</div>
          
          <div class="grid grid-cols-2 gap-3">
            <div>
              <div class="text-[11px] text-slate-400 mb-1">Roof Skin: {{ vehicleService.parameters().roof_thickness }} mm</div>
              <input 
                type="range" 
                min="0.6" 
                max="1.4" 
                step="0.05"
                [value]="vehicleService.parameters().roof_thickness"
                (input)="onParamChange('roof_thickness', $event)"
                class="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg">
            </div>

            <div>
              <div class="text-[11px] text-slate-400 mb-1">Hood Skin: {{ vehicleService.parameters().hood_thickness }} mm</div>
              <input 
                type="range" 
                min="0.6" 
                max="1.2" 
                step="0.05"
                [value]="vehicleService.parameters().hood_thickness"
                (input)="onParamChange('hood_thickness', $event)"
                class="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg">
            </div>
          </div>
        </div>
      </div>

      <!-- Selected Component Material Customizer -->
      @if (vehicleService.selectedComponent(); as sel) {
        <div class="bg-slate-900/90 rounded-xl p-4 border border-cyan-500/30 space-y-3 shadow-xl">
          <div class="flex items-center justify-between">
            <span class="text-xs font-mono font-bold text-cyan-300">COMPONENT INSPECTOR</span>
            <span class="text-[10px] font-mono bg-cyan-950 px-2 py-0.5 rounded text-cyan-400 border border-cyan-800">{{ sel.component_id }}</span>
          </div>
          
          <div class="text-sm font-semibold text-white">{{ sel.name }}</div>

          <div class="space-y-1.5">
            <label for="component-material-select" class="text-[11px] font-mono text-slate-400">ASSIGNED ENGINEERING MATERIAL</label>
            <select 
              id="component-material-select"
              [value]="sel.material_id"
              (change)="onMaterialChange(sel.component_id, $event)"
              class="w-full bg-slate-800 border border-slate-700 text-xs font-mono text-slate-200 rounded-lg p-2 focus:outline-none focus:border-cyan-500">
              @for (m of vehicleService.materials(); track m.material_id) {
                <option [value]="m.material_id">
                  {{ m.name }} ({{ m.density }} kg/m³, €{{ m.cost_per_kg }}/kg)
                </option>
              }
            </select>
          </div>

          <div class="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-slate-800">
            <div>
              <span class="text-slate-500">Mass:</span>
              <strong class="text-white ml-1">{{ sel.mass_kg }} kg</strong>
            </div>
            <div>
              <span class="text-slate-500">Supplier:</span>
              <span class="text-slate-300 ml-1 truncate">{{ sel.supplier }}</span>
            </div>
            <div>
              <span class="text-slate-500">Mfg:</span>
              <span class="text-slate-300 ml-1 truncate">{{ sel.manufacturing_method }}</span>
            </div>
            <div>
              <span class="text-slate-500">Unit Cost:</span>
              <strong class="text-emerald-400 ml-1">€{{ sel.unit_cost_eur.total }}</strong>
            </div>
          </div>
        </div>
      }
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DesignStudio {
  readonly vehicleService = inject(CanonicalVehicleService);

  readonly paintColors = [
    { name: 'Electric Ocean Blue', hex: '#0284c7' },
    { name: 'Tornado Red Metallic', hex: '#dc2626' },
    { name: 'Habanero Orange', hex: '#d97706' },
    { name: 'Reflex Silver Metallic', hex: '#94a3b8' },
    { name: 'Pure White Gloss', hex: '#f8fafc' },
    { name: 'Deep Black Pearl', hex: '#0f172a' }
  ];

  onParamChange(key: keyof VehicleParameters, e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.vehicleService.updateParameter(key, val);
  }

  onMaterialChange(componentId: string, e: Event) {
    const val = (e.target as HTMLSelectElement).value;
    this.vehicleService.updateComponentMaterial(componentId, val);
  }
}
