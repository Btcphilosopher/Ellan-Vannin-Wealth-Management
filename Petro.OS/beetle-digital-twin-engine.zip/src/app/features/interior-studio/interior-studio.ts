import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CanonicalVehicleService } from '../../core/services/canonical-vehicle.service';

@Component({
  selector: 'app-interior-studio',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full overflow-y-auto p-4 space-y-6 text-slate-200">
      <!-- Section Header -->
      <div class="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <h2 class="text-base font-semibold text-white tracking-wide flex items-center gap-2">
            <mat-icon class="text-emerald-400 !w-5 !h-5 !text-lg">airline_seat_recline_normal</mat-icon>
            Human Package & Ergonomics Studio (RAMSIS Twin)
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">H-Point kinematics, 95th percentile clearance envelopes & sight lines.</p>
        </div>

        <button 
          (click)="vehicleService.cameraPreset.set('INTERIOR')"
          class="px-2.5 py-1 text-xs font-mono text-cyan-300 bg-cyan-950/80 hover:bg-cyan-900 rounded border border-cyan-800 transition flex items-center gap-1">
          <mat-icon class="!w-3.5 !h-3.5 !text-sm">visibility</mat-icon>
          Focus Cabin
        </button>
      </div>

      <!-- Driver Percentile Selector -->
      <div class="bg-slate-900/80 rounded-xl p-3 border border-slate-800 space-y-2">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold">HUMAN PACKAGE MANNEQUIN PERCENTILE</div>
        <div class="grid grid-cols-3 gap-2">
          <button 
            (click)="vehicleService.driverPercentile.set('95th-Male')"
            [class.border-emerald-500]="vehicleService.driverPercentile() === '95th-Male'"
            [class.bg-emerald-950/40]="vehicleService.driverPercentile() === '95th-Male'"
            class="p-2 rounded-lg border border-slate-800 text-left hover:border-slate-700 transition">
            <div class="text-xs font-bold text-white">95th % Male</div>
            <div class="text-[10px] text-slate-400">188 cm / 98 kg</div>
          </button>

          <button 
            (click)="vehicleService.driverPercentile.set('50th-Male')"
            [class.border-emerald-500]="vehicleService.driverPercentile() === '50th-Male'"
            [class.bg-emerald-950/40]="vehicleService.driverPercentile() === '50th-Male'"
            class="p-2 rounded-lg border border-slate-800 text-left hover:border-slate-700 transition">
            <div class="text-xs font-bold text-white">50th % Male</div>
            <div class="text-[10px] text-slate-400">178 cm / 78 kg</div>
          </button>

          <button 
            (click)="vehicleService.driverPercentile.set('50th-Female')"
            [class.border-emerald-500]="vehicleService.driverPercentile() === '50th-Female'"
            [class.bg-emerald-950/40]="vehicleService.driverPercentile() === '50th-Female'"
            class="p-2 rounded-lg border border-slate-800 text-left hover:border-slate-700 transition">
            <div class="text-xs font-bold text-white">50th % Female</div>
            <div class="text-[10px] text-slate-400">163 cm / 62 kg</div>
          </button>
        </div>
      </div>

      <!-- Ergonomics Clearance Envelopes (Headroom, Legroom, Knee, Shoulder) -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">FRONT HEADROOM</div>
          <div class="text-xl font-bold font-mono text-emerald-300">
            {{ vehicleService.ergonomicsMetrics().headroom_front_mm }} <span class="text-xs text-slate-400">mm</span>
          </div>
          <div class="text-[10px] text-slate-500 font-mono">SAE J1100 Min: 980 mm</div>
        </div>

        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">REAR HEADROOM</div>
          <div class="text-xl font-bold font-mono text-cyan-300">
            {{ vehicleService.ergonomicsMetrics().headroom_rear_mm }} <span class="text-xs text-slate-400">mm</span>
          </div>
          <div class="text-[10px] text-slate-500 font-mono">Curved Roof Slope Check</div>
        </div>

        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">FRONT LEGROOM</div>
          <div class="text-xl font-bold font-mono text-white">
            {{ vehicleService.ergonomicsMetrics().legroom_front_mm }} <span class="text-xs text-slate-400">mm</span>
          </div>
          <div class="text-[10px] text-slate-500 font-mono">Pedal reach: {{ vehicleService.ergonomicsMetrics().pedal_reach_mm }} mm</div>
        </div>

        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400">KNEE CLEARANCE</div>
          <div class="text-xl font-bold font-mono text-amber-300">
            {{ vehicleService.ergonomicsMetrics().knee_clearance_mm }} <span class="text-xs text-slate-400">mm</span>
          </div>
          <div class="text-[10px] text-slate-500 font-mono">Rear passenger space</div>
        </div>
      </div>

      <!-- H-Point Kinematics & Driver Adjustments -->
      <div class="bg-slate-900/80 rounded-xl p-4 border border-slate-800 space-y-4">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>DYNAMIC H-POINT POSITIONING & SEAT ADJUSTMENT</span>
          <span class="text-emerald-400 text-xs font-mono">H = [{{ vehicleService.ergonomicsMetrics().h_point.join(', ') }}] mm</span>
        </div>

        <!-- Fore / Aft Slider -->
        <div class="space-y-1.5">
          <div class="flex justify-between text-xs font-mono">
            <span class="text-slate-300">Seat Fore / Aft Travel (X-Offset)</span>
            <span class="text-cyan-300 font-bold">{{ vehicleService.seatPositionX() }} mm</span>
          </div>
          <input 
            type="range" 
            min="-50" 
            max="50" 
            step="5"
            [value]="vehicleService.seatPositionX()"
            (input)="onSeatXChange($event)"
            class="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg">
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>-50 mm (Forward)</span>
            <span>0 mm</span>
            <span>+50 mm (Aft)</span>
          </div>
        </div>

        <!-- Height Slider -->
        <div class="space-y-1.5">
          <div class="flex justify-between text-xs font-mono">
            <span class="text-slate-300">Seat Height Travel (Z-Offset)</span>
            <span class="text-cyan-300 font-bold">{{ vehicleService.seatHeightOffset() }} mm</span>
          </div>
          <input 
            type="range" 
            min="-30" 
            max="30" 
            step="5"
            [value]="vehicleService.seatHeightOffset()"
            (input)="onSeatZChange($event)"
            class="w-full accent-cyan-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg">
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>-30 mm (Low)</span>
            <span>0 mm</span>
            <span>+30 mm (High)</span>
          </div>
        </div>

        <!-- Backrest Angle Slider -->
        <div class="space-y-1.5">
          <div class="flex justify-between text-xs font-mono">
            <span class="text-slate-300">Backrest Recline Angle</span>
            <span class="text-emerald-300 font-bold">{{ vehicleService.seatBackrestAngle() }}°</span>
          </div>
          <input 
            type="range" 
            min="18" 
            max="32" 
            step="1"
            [value]="vehicleService.seatBackrestAngle()"
            (input)="onSeatAngleChange($event)"
            class="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg">
          <div class="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>18° (Upright)</span>
            <span>Default: 24°</span>
            <span>32° (Relaxed)</span>
          </div>
        </div>
      </div>

      <!-- Driver Field of View / Sight Angle Audit -->
      <div class="bg-slate-900/80 rounded-xl p-4 border border-slate-800 space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold">OPTICAL SIGHT CONE & BLIND SPOT ANALYSIS</div>
        <div class="grid grid-cols-2 gap-3 font-mono text-xs">
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span class="text-slate-400">Upward Sight Angle (Traffic Lights):</span>
            <div class="text-base font-bold text-emerald-400 mt-1">{{ vehicleService.ergonomicsMetrics().sight_angle_up_deg }}°</div>
            <div class="text-[10px] text-slate-500 mt-0.5">ECE-R43 Compliant (Min 15°)</div>
          </div>
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800">
            <span class="text-slate-400">Downward Sight Angle (Obstacle):</span>
            <div class="text-base font-bold text-cyan-400 mt-1">{{ vehicleService.ergonomicsMetrics().sight_angle_down_deg }}°</div>
            <div class="text-[10px] text-slate-500 mt-0.5">Over-the-Hood Ground Horizon</div>
          </div>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InteriorStudio {
  readonly vehicleService = inject(CanonicalVehicleService);

  onSeatXChange(e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.vehicleService.seatPositionX.set(val);
  }

  onSeatZChange(e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.vehicleService.seatHeightOffset.set(val);
  }

  onSeatAngleChange(e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.vehicleService.seatBackrestAngle.set(val);
  }
}
