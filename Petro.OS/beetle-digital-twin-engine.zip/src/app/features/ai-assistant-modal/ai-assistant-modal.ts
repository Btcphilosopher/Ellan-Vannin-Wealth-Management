import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { AIAssistantService } from '../../core/services/ai-assistant.service';

@Component({
  selector: 'app-ai-assistant-modal',
  imports: [CommonModule, MatIconModule, ReactiveFormsModule],
  template: `
    @if (aiService.isOpen()) {
      <div class="fixed inset-y-0 right-0 z-50 w-full max-w-lg bg-slate-900/95 backdrop-blur-xl border-l border-cyan-500/30 shadow-2xl flex flex-col transition-all">
        <!-- Header -->
        <div class="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20">
              <mat-icon class="!w-5 !h-5 !text-lg">smart_toy</mat-icon>
            </div>
            <div>
              <h3 class="text-sm font-bold text-white tracking-wide">Beetle Engineering AI</h3>
              <div class="flex items-center gap-1.5 text-[10px] font-mono text-cyan-400">
                <span class="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                <span>ONLINE · CANONICAL TWIN MODEL v3.2</span>
              </div>
            </div>
          </div>

          <button 
            (click)="aiService.toggleOpen()"
            class="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition">
            <mat-icon class="!w-5 !h-5 !text-xl">close</mat-icon>
          </button>
        </div>

        <!-- Messages Body -->
        <div class="flex-1 overflow-y-auto p-4 space-y-4 text-xs font-mono">
          @for (msg of aiService.messages(); track msg.id) {
            <div 
              [class.items-end]="msg.sender === 'user'"
              [class.items-start]="msg.sender !== 'user'"
              class="flex flex-col gap-1">
              <div class="flex items-center gap-2 text-[10px] text-slate-500">
                <span>{{ msg.sender === 'user' ? 'Lead Engineer' : 'Beetle Engineering AI' }}</span>
                <span>{{ msg.timestamp }}</span>
              </div>

              <div 
                [class.bg-cyan-600]="msg.sender === 'user'"
                [class.text-white]="msg.sender === 'user'"
                [class.bg-slate-800]="msg.sender === 'assistant'"
                [class.text-slate-200]="msg.sender === 'assistant'"
                [class.bg-slate-950]="msg.sender === 'system'"
                [class.text-cyan-400]="msg.sender === 'system'"
                [class.border]="msg.sender !== 'user'"
                [class.border-slate-700]="msg.sender === 'assistant'"
                [class.border-cyan-900]="msg.sender === 'system'"
                class="p-3 rounded-xl max-w-[90%] whitespace-pre-line leading-relaxed shadow-md">
                {{ msg.text }}
              </div>

              <!-- Suggested Action Chips -->
              @if (msg.suggestedActions && msg.suggestedActions.length > 0) {
                <div class="flex flex-wrap gap-1.5 mt-2">
                  @for (act of msg.suggestedActions; track act.label) {
                    <button 
                      (click)="onSuggestedPrompt(act.label)"
                      class="px-2.5 py-1 bg-slate-800/80 hover:bg-cyan-950 hover:border-cyan-500 border border-slate-700 rounded-lg text-[10px] text-cyan-300 font-mono transition">
                      {{ act.label }}
                    </button>
                  }
                </div>
              }
            </div>
          }

          @if (aiService.isLoading()) {
            <div class="flex items-center gap-2 text-cyan-400 text-xs font-mono p-3 bg-slate-800/50 rounded-xl border border-slate-700 animate-pulse">
              <mat-icon class="!w-4 !h-4 !text-base animate-spin">autorenew</mat-icon>
              <span>Analyzing Digital Twin telemetry & solving physics models...</span>
            </div>
          }
        </div>

        <!-- Input Area -->
        <form [formGroup]="chatForm" (ngSubmit)="sendMessage()" class="p-3 border-t border-slate-800 bg-slate-950/80 flex items-center gap-2">
          <input 
            type="text" 
            formControlName="query"
            placeholder="Ask engineering question (e.g. Mass drivers, Robot 17 impact)..." 
            class="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500">

          <button 
            type="submit" 
            [disabled]="aiService.isLoading() || !chatForm.valid"
            class="p-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-white rounded-xl transition shadow-md shadow-cyan-600/30">
            <mat-icon class="!w-4 !h-4 !text-base">send</mat-icon>
          </button>
        </form>
      </div>
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AIAssistantModal {
  readonly aiService = inject(AIAssistantService);

  readonly chatForm = new FormGroup({
    query: new FormControl('', { nonNullable: true })
  });

  sendMessage() {
    const q = this.chatForm.controls.query.value;
    if (!q.trim()) return;
    this.chatForm.reset();
    this.aiService.askQuestion(q);
  }

  onSuggestedPrompt(prompt: string) {
    this.aiService.askQuestion(prompt);
  }
}
