import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CanonicalVehicleService } from '../../core/services/canonical-vehicle.service';

@Component({
  selector: 'app-engineering-studio',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full overflow-y-auto p-4 space-y-6 text-slate-200">
      <!-- Section Header -->
      <div class="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <h2 class="text-base font-semibold text-white tracking-wide flex items-center gap-2">
            <mat-icon class="text-cyan-400 !w-5 !h-5 !text-lg">architecture</mat-icon>
            Automotive Computational Engineering & BOM
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">Rigorous mass rollups, inertia tensors, aerodynamic solvers & cost tracking.</p>
        </div>

        <!-- Engineering Freeze Button -->
        <button 
          (click)="vehicleService.toggleEngineeringFreeze()"
          [class.bg-red-600]="vehicleService.engineeringFrozen()"
          [class.hover:bg-red-500]="vehicleService.engineeringFrozen()"
          [class.bg-slate-800]="!vehicleService.engineeringFrozen()"
          [class.hover:bg-slate-700]="!vehicleService.engineeringFrozen()"
          class="px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition border border-slate-700 flex items-center gap-1.5 shadow-lg">
          <mat-icon class="!w-4 !h-4 !text-base">{{ vehicleService.engineeringFrozen() ? 'lock' : 'lock_open' }}</mat-icon>
          <span>{{ vehicleService.engineeringFrozen() ? 'ENGINEERING FROZEN' : 'FREEZE REVISION' }}</span>
        </button>
      </div>

      <!-- Real-Time Engineering Metrics HUD (Mass, CG, Aero, Cost) -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
        <!-- Mass Rollup -->
        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>TOTAL MASS</span>
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-cyan-400">scale</mat-icon>
          </div>
          <div class="text-xl font-bold font-mono text-cyan-300">
            {{ vehicleService.massInertiaMetrics().total_mass_kg }} <span class="text-xs text-slate-400">kg</span>
          </div>
          <div class="text-[11px] font-mono text-slate-400 flex justify-between">
            <span>Curb: {{ vehicleService.massInertiaMetrics().curb_weight_kg }} kg</span>
            <span class="text-emerald-400">{{ vehicleService.massInertiaMetrics().mass_distribution_front_percent }}/{{ vehicleService.massInertiaMetrics().mass_distribution_rear_percent }} F/R</span>
          </div>
        </div>

        <!-- Center of Gravity -->
        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>CENTER OF GRAVITY</span>
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-amber-400">center_focus_strong</mat-icon>
          </div>
          <div class="text-lg font-bold font-mono text-amber-300">
            [{{ vehicleService.massInertiaMetrics().cg_x_mm }}, {{ vehicleService.massInertiaMetrics().cg_y_mm }}, {{ vehicleService.massInertiaMetrics().cg_z_mm }}]
          </div>
          <div class="text-[11px] font-mono text-slate-400">
            Z-Height: <strong class="text-slate-200">{{ vehicleService.massInertiaMetrics().cg_z_mm }} mm</strong>
          </div>
        </div>

        <!-- Aerodynamic Drag -->
        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>AERODYNAMICS</span>
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-sky-400">air</mat-icon>
          </div>
          <div class="text-xl font-bold font-mono text-sky-300">
            cw {{ vehicleService.aerodynamicsMetrics().drag_coefficient_cd }}
          </div>
          <div class="text-[11px] font-mono text-slate-400 flex justify-between">
            <span>Area: {{ vehicleService.aerodynamicsMetrics().frontal_area_m2 }} m²</span>
            <span class="text-cyan-400">{{ vehicleService.aerodynamicsMetrics().electric_range_km }} km</span>
          </div>
        </div>

        <!-- Direct Unit Cost -->
        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>DIRECT MFG COST</span>
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-emerald-400">payments</mat-icon>
          </div>
          <div class="text-xl font-bold font-mono text-emerald-300">
            €{{ vehicleService.vehicleCostModel().total_direct_manufacturing_cost_eur.toLocaleString() }}
          </div>
          <div class="text-[11px] font-mono text-slate-400">
            Est. MSRP: <strong class="text-slate-200">€{{ vehicleService.vehicleCostModel().estimated_msrp_eur.toLocaleString() }}</strong>
          </div>
        </div>
      </div>

      <!-- Inertia Tensor Breakdown -->
      <div class="bg-slate-900/80 rounded-xl p-4 border border-slate-800 space-y-2">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>DYNAMIC MOMENTS OF INERTIA (RIGID BODY TENSOR)</span>
          <span class="text-cyan-400 text-[10px] font-mono">I_xx, I_yy, I_zz [kg·m²]</span>
        </div>
        <div class="grid grid-cols-3 gap-3 text-center font-mono">
          <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
            <div class="text-[10px] text-slate-500">I_xx (Roll)</div>
            <div class="text-sm font-bold text-cyan-300">{{ vehicleService.massInertiaMetrics().inertia_ixx_kg_m2 }} kg·m²</div>
          </div>
          <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
            <div class="text-[10px] text-slate-500">I_yy (Pitch)</div>
            <div class="text-sm font-bold text-cyan-300">{{ vehicleService.massInertiaMetrics().inertia_iyy_kg_m2 }} kg·m²</div>
          </div>
          <div class="bg-slate-950 p-2 rounded-lg border border-slate-800">
            <div class="text-[10px] text-slate-500">I_zz (Yaw)</div>
            <div class="text-sm font-bold text-cyan-300">{{ vehicleService.massInertiaMetrics().inertia_izz_kg_m2 }} kg·m²</div>
          </div>
        </div>
      </div>

      <!-- Aerodynamic Highway Energy Demand Breakdown -->
      <div class="bg-slate-900/80 rounded-xl p-4 border border-slate-800 space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold">HIGHWAY CRUISE RESISTANCE SOLVER (@ 130 KM/H)</div>
        <div class="grid grid-cols-3 gap-3 font-mono text-xs">
          <div>
            <span class="text-slate-400">Aero Drag Force:</span>
            <div class="text-sm font-bold text-white mt-0.5">{{ vehicleService.aerodynamicsMetrics().drag_force_n }} N</div>
          </div>
          <div>
            <span class="text-slate-400">Total Power Demand:</span>
            <div class="text-sm font-bold text-amber-300 mt-0.5">{{ vehicleService.aerodynamicsMetrics().power_demand_kw }} kW</div>
          </div>
          <div>
            <span class="text-slate-400">Specific Consumption:</span>
            <div class="text-sm font-bold text-emerald-300 mt-0.5">{{ vehicleService.aerodynamicsMetrics().energy_consumption_kwh_100km }} kWh/100km</div>
          </div>
        </div>
      </div>

      <!-- Engineering Bill of Materials (BOM) Table -->
      <div class="bg-slate-900/80 rounded-xl border border-slate-800 overflow-hidden space-y-2">
        <div class="p-3 border-b border-slate-800 flex items-center justify-between">
          <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-2">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">list_alt</mat-icon>
            CANONICAL BILL OF MATERIALS (BOM) — {{ vehicleService.components().length }} COMPONENTS
          </div>
          <span class="text-[10px] font-mono bg-emerald-950 px-2 py-0.5 rounded text-emerald-400 border border-emerald-800">SYNCHRONIZED</span>
        </div>

        <div class="overflow-x-auto max-h-80 overflow-y-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800 sticky top-0">
              <tr>
                <th class="p-2.5">ID / Name</th>
                <th class="p-2.5">Assembly</th>
                <th class="p-2.5">Material</th>
                <th class="p-2.5">Thick</th>
                <th class="p-2.5">Mass</th>
                <th class="p-2.5">Supplier</th>
                <th class="p-2.5">Cost</th>
                <th class="p-2.5">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (c of vehicleService.components(); track c.component_id) {
                <tr 
                  [class.bg-cyan-950/30]="vehicleService.selectedComponentId() === c.component_id"
                  class="hover:bg-slate-800/40 transition">
                  <td class="p-2.5">
                    <div class="font-bold text-white">{{ c.name }}</div>
                    <div class="text-[10px] text-slate-500">{{ c.component_id }} ({{ c.version }})</div>
                  </td>
                  <td class="p-2.5 text-slate-300">{{ c.assembly }}</td>
                  <td class="p-2.5 text-cyan-300 truncate max-w-[120px]">{{ c.material_id }}</td>
                  <td class="p-2.5 text-slate-300">{{ c.thickness_mm }} mm</td>
                  <td class="p-2.5 font-bold text-white">{{ c.mass_kg }} kg</td>
                  <td class="p-2.5 text-slate-400 truncate max-w-[120px]">{{ c.supplier }}</td>
                  <td class="p-2.5 text-emerald-400">€{{ c.unit_cost_eur.total }}</td>
                  <td class="p-2.5">
                    <button 
                      (click)="vehicleService.selectedComponentId.set(c.component_id)"
                      class="px-2 py-1 bg-slate-800 hover:bg-cyan-600 text-white rounded text-[10px] transition">
                      Inspect
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EngineeringStudio {
  readonly vehicleService = inject(CanonicalVehicleService);
}
