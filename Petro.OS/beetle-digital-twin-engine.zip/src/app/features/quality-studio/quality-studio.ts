import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { QualityTwinService } from '../../core/services/quality-twin.service';

@Component({
  selector: 'app-quality-studio',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full overflow-y-auto p-4 space-y-6 text-slate-200">
      <!-- Section Header -->
      <div class="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <h2 class="text-base font-semibold text-white tracking-wide flex items-center gap-2">
            <mat-icon class="text-rose-400 !w-5 !h-5 !text-lg">verified</mat-icon>
            Quality Digital Twin & End-of-Line Traceability
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">Spaltmaß gap & flush metrics, torque-angle curves, paint microns & VIN audit.</p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="qualityService.injectGapDefect()"
            class="px-2.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition border border-red-700 bg-red-950/80 hover:bg-red-900 text-red-300 flex items-center gap-1 shadow-lg">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm">bug_report</mat-icon>
            Inject Gap Defect
          </button>

          <button 
            (click)="qualityService.resolveAllDefects()"
            class="px-2.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition border border-emerald-700 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 flex items-center gap-1 shadow-lg">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm">check_circle</mat-icon>
            Resolve / Rework
          </button>
        </div>
      </div>

      <!-- Active VIN Audit Passport Header -->
      <div class="bg-slate-900/80 rounded-xl p-4 border border-slate-800 space-y-2">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-cyan-300">ACTIVE VEHICLE PASSPORT:</span>
            <span class="font-mono text-xs px-2 py-0.5 bg-cyan-950 text-cyan-300 rounded border border-cyan-800">{{ qualityService.activeVin() }}</span>
          </div>
          <div class="text-xs font-mono text-emerald-400 flex items-center gap-1">
            <mat-icon class="!w-4 !h-4 !text-base text-emerald-400">task_alt</mat-icon>
            EOL AUDIT SCORE: <strong class="text-white">{{ qualityService.endOfLineAudit().overall_readiness_score }}%</strong>
          </div>
        </div>
      </div>

      <!-- Gap and Flush Measurements (Spaltmaß) -->
      <div class="bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>SPALTMASS & FLUSH (GAP AUDIT)</span>
          <span class="text-[10px] font-mono text-slate-500">OPTICAL LASER SCAN (TOLERANCE ±0.5 MM)</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          @for (g of qualityService.gapFlushData(); track g.id) {
            <div 
              [class.border-red-500]="g.status === 'RED'"
              [class.bg-red-950/30]="g.status === 'RED'"
              [class.border-amber-500]="g.status === 'YELLOW'"
              [class.bg-amber-950/20]="g.status === 'YELLOW'"
              [class.border-slate-800]="g.status === 'GREEN'"
              [class.bg-slate-950]="g.status === 'GREEN'"
              class="p-3 rounded-xl border space-y-2 transition">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-white">{{ g.location_name }}</span>
                <span 
                  [class.bg-emerald-950]="g.status === 'GREEN'"
                  [class.text-emerald-400]="g.status === 'GREEN'"
                  [class.bg-amber-950]="g.status === 'YELLOW'"
                  [class.text-amber-400]="g.status === 'YELLOW'"
                  [class.bg-red-950]="g.status === 'RED'"
                  [class.text-red-400]="g.status === 'RED'"
                  class="text-[9px] font-mono font-bold px-2 py-0.5 rounded border border-current">
                  {{ g.status }}
                </span>
              </div>

              <div class="grid grid-cols-2 gap-2 text-xs font-mono">
                <div>
                  <span class="text-slate-400">Gap Actual:</span>
                  <div class="font-bold text-white mt-0.5">{{ g.gap_actual_mm }} mm (Target: {{ g.gap_target_mm }} mm)</div>
                </div>
                <div>
                  <span class="text-slate-400">Flush Actual:</span>
                  <div class="font-bold text-white mt-0.5">{{ g.flush_actual_mm }} mm (Target: {{ g.flush_target_mm }} mm)</div>
                </div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Bolt Torque-Angle Quality Curves -->
      <div class="bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>CRITICAL BOLT TORQUE & ANGLE CURVES (SAFETY FASTENERS)</span>
          <span class="text-emerald-400 text-xs font-mono">100% OK LOGGED</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
          @for (t of qualityService.torqueMeasurements(); track t.bolt_id) {
            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-white truncate max-w-[160px]">{{ t.joint_name }}</span>
                <span class="text-[10px] font-mono bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded font-bold">PASS</span>
              </div>

              <div class="text-xs font-mono space-y-1">
                <div class="flex justify-between">
                  <span class="text-slate-400">Torque:</span>
                  <strong class="text-emerald-300">{{ t.actual_torque_nm }} Nm</strong>
                </div>
                <div class="flex justify-between text-[11px] text-slate-500">
                  <span>Target: {{ t.target_torque_nm }} ± {{ t.tolerance_nm }} Nm</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-slate-400">Angle:</span>
                  <strong class="text-cyan-300">{{ t.actual_angle_deg }}° (Target: {{ t.target_angle_deg }}°)</strong>
                </div>
              </div>

              <!-- Mini Curve Visualizer -->
              <div class="h-12 bg-slate-900 rounded p-1 flex items-end justify-between gap-1">
                @for (pt of t.curve_points; track pt.angle) {
                  <div 
                    class="w-full bg-cyan-500 rounded-t transition-all"
                    [style.height.%]="(pt.torque / t.target_torque_nm) * 90">
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Paint Layer Thickness Inspection (Microns) -->
      <div class="bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>PAINT LAYER THICKNESS & CURING AUDIT (MICRONS / µM)</span>
          <span class="text-xs font-mono text-cyan-300">TOTAL: 120.9 µm</span>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
          @for (p of qualityService.paintInspections(); track p.layer_type) {
            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
              <div class="text-[10px] text-slate-400 font-semibold">{{ p.layer_type }}</div>
              <div class="text-base font-bold text-white">
                {{ p.actual_thickness_um }} <span class="text-xs text-slate-500">µm</span>
              </div>
              <div class="text-[10px] text-slate-500 flex justify-between">
                <span>Target: {{ p.target_thickness_um }} µm</span>
                <span class="text-emerald-400">OK</span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Defect History Log -->
      <div class="bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>ACTIVE QUALITY DEFECTS & REMEDY LOG</span>
          <span class="text-[10px] font-mono text-slate-500">{{ qualityService.defectLog().length }} LOGS</span>
        </div>

        <div class="space-y-2">
          @for (d of qualityService.defectLog(); track d.defect_id) {
            <div 
              [class.border-red-500]="!d.resolved && d.severity === 'CRITICAL'"
              [class.bg-red-950/20]="!d.resolved && d.severity === 'CRITICAL'"
              [class.border-slate-800]="d.resolved"
              [class.bg-slate-950]="d.resolved"
              class="p-3 rounded-xl border text-xs space-y-1.5">
              <div class="flex items-center justify-between font-mono">
                <div class="flex items-center gap-2">
                  <span class="font-bold text-white">{{ d.defect_id }}</span>
                  <span class="text-slate-500">· {{ d.timestamp }} · {{ d.station_id }}</span>
                </div>
                <span 
                  [class.bg-red-950]="!d.resolved"
                  [class.text-red-400]="!d.resolved"
                  [class.bg-emerald-950]="d.resolved"
                  [class.text-emerald-400]="d.resolved"
                  class="text-[9px] font-bold px-2 py-0.5 rounded border border-current">
                  {{ d.resolved ? 'RESOLVED / PASSED' : 'OPEN / REWORK REQUIRED' }}
                </span>
              </div>
              <div class="text-slate-300 font-medium">{{ d.description }}</div>
              <div class="text-[11px] text-slate-400 font-mono">
                <span class="text-slate-500">Root Cause:</span> {{ d.root_cause }}
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class QualityStudio {
  readonly qualityService = inject(QualityTwinService);
}
