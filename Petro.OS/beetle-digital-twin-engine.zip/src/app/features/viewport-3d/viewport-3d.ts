import { 
  Component, 
  ElementRef, 
  OnInit, 
  OnDestroy, 
  ViewChild, 
  inject, 
  effect, 
  NgZone, 
  ChangeDetectionStrategy,
  PLATFORM_ID
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { CanonicalVehicleService } from '../../core/services/canonical-vehicle.service';
import { FactorySimulationService } from '../../core/services/factory-simulation.service';
import { CameraViewPreset, VehicleParameters, SectionMode } from '../../core/models/vehicle.types';

@Component({
  selector: 'app-viewport-3d',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="relative w-full h-full select-none overflow-hidden bg-gradient-to-b from-[#080d1a] via-[#0b1329] to-[#040711] flex flex-col">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="relative w-full h-full cursor-grab active:cursor-grabbing outline-none"></div>

      <!-- Top CAD Viewport HUD Overlay -->
      <div class="absolute top-4 left-4 z-10 flex flex-col gap-2 pointer-events-none">
        <div class="flex items-center gap-2 bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-cyan-500/30 text-xs shadow-lg shadow-cyan-950/30">
          <div class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></div>
          <span class="font-mono text-cyan-300 font-semibold uppercase tracking-wider">CANONICAL 3D TWIN</span>
          <span class="text-slate-500">|</span>
          <span class="font-mono text-slate-300">LOD-0 HIGH RES</span>
          <span class="text-slate-500">|</span>
          <span class="font-mono text-emerald-400">{{ fps }} FPS</span>
        </div>

        @if (vehicleService.selectedComponent(); as sel) {
          <div class="bg-slate-900/90 backdrop-blur-md px-3 py-2 rounded-lg border border-slate-700/60 text-xs shadow-lg max-w-xs">
            <div class="text-[10px] uppercase font-mono tracking-widest text-slate-400">ACTIVE COMPONENT</div>
            <div class="text-sm font-semibold text-white truncate">{{ sel.name }}</div>
            <div class="flex items-center gap-3 mt-1 font-mono text-[11px] text-slate-300">
              <span>M: <strong class="text-cyan-300">{{ sel.mass_kg }} kg</strong></span>
              <span>T: <strong class="text-amber-300">{{ sel.thickness_mm }} mm</strong></span>
              <span>Cost: <strong class="text-emerald-300">€{{ sel.unit_cost_eur.total }}</strong></span>
            </div>
          </div>
        }
      </div>

      <!-- Floating Viewport Control Toolbar -->
      <div class="absolute top-4 right-4 z-10 flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-700/60 shadow-xl pointer-events-auto">
        <button 
          (click)="setPreset('ORBIT')"
          [class.bg-cyan-600]="vehicleService.cameraPreset() === 'ORBIT'"
          [class.text-white]="vehicleService.cameraPreset() === 'ORBIT'"
          [class.text-slate-400]="vehicleService.cameraPreset() !== 'ORBIT'"
          title="Orbit Isometric 3D"
          class="p-2 rounded-lg hover:bg-slate-800 transition flex items-center gap-1 text-xs font-mono font-medium">
          <mat-icon class="!w-4 !h-4 !text-base">3d_rotation</mat-icon>
          <span class="hidden md:inline">ISO</span>
        </button>

        <button 
          (click)="setPreset('SIDE')"
          [class.bg-cyan-600]="vehicleService.cameraPreset() === 'SIDE'"
          [class.text-white]="vehicleService.cameraPreset() === 'SIDE'"
          [class.text-slate-400]="vehicleService.cameraPreset() !== 'SIDE'"
          title="Side Profile"
          class="p-2 rounded-lg hover:bg-slate-800 transition flex items-center gap-1 text-xs font-mono font-medium">
          <mat-icon class="!w-4 !h-4 !text-base">view_carousel</mat-icon>
          <span class="hidden md:inline">SIDE</span>
        </button>

        <button 
          (click)="setPreset('FRONT')"
          [class.bg-cyan-600]="vehicleService.cameraPreset() === 'FRONT'"
          [class.text-white]="vehicleService.cameraPreset() === 'FRONT'"
          [class.text-slate-400]="vehicleService.cameraPreset() !== 'FRONT'"
          title="Front View"
          class="p-2 rounded-lg hover:bg-slate-800 transition flex items-center gap-1 text-xs font-mono font-medium">
          <mat-icon class="!w-4 !h-4 !text-base">directions_car</mat-icon>
          <span class="hidden md:inline">FRONT</span>
        </button>

        <button 
          (click)="setPreset('TOP')"
          [class.bg-cyan-600]="vehicleService.cameraPreset() === 'TOP'"
          [class.text-white]="vehicleService.cameraPreset() === 'TOP'"
          [class.text-slate-400]="vehicleService.cameraPreset() !== 'TOP'"
          title="Top Aerodynamic Plan"
          class="p-2 rounded-lg hover:bg-slate-800 transition flex items-center gap-1 text-xs font-mono font-medium">
          <mat-icon class="!w-4 !h-4 !text-base">flight</mat-icon>
          <span class="hidden md:inline">TOP</span>
        </button>

        <button 
          (click)="setPreset('INTERIOR')"
          [class.bg-cyan-600]="vehicleService.cameraPreset() === 'INTERIOR'"
          [class.text-white]="vehicleService.cameraPreset() === 'INTERIOR'"
          [class.text-slate-400]="vehicleService.cameraPreset() !== 'INTERIOR'"
          title="Cabin Ergonomics View"
          class="p-2 rounded-lg hover:bg-slate-800 transition flex items-center gap-1 text-xs font-mono font-medium">
          <mat-icon class="!w-4 !h-4 !text-base">airline_seat_recline_normal</mat-icon>
          <span class="hidden md:inline">CABIN</span>
        </button>

        <div class="w-px h-6 bg-slate-700 mx-1"></div>

        <!-- Wireframe Mode Toggle -->
        <button 
          (click)="toggleWireframe()"
          [class.text-cyan-400]="vehicleService.wireframeMode()"
          [class.text-slate-400]="!vehicleService.wireframeMode()"
          title="Toggle Wireframe Mesh"
          class="p-2 rounded-lg hover:bg-slate-800 transition">
          <mat-icon class="!w-4 !h-4 !text-base">grid_4x4</mat-icon>
        </button>

        <!-- Center of Gravity Toggle -->
        <button 
          (click)="toggleCG()"
          [class.text-amber-400]="vehicleService.showCenterOfGravity()"
          [class.text-slate-400]="!vehicleService.showCenterOfGravity()"
          title="Toggle Center of Gravity Marker"
          class="p-2 rounded-lg hover:bg-slate-800 transition">
          <mat-icon class="!w-4 !h-4 !text-base">center_focus_strong</mat-icon>
        </button>

        <!-- RAMSIS Mannequin Toggle -->
        <button 
          (click)="toggleErgoMannequin()"
          [class.text-emerald-400]="vehicleService.showErgoMannequin()"
          [class.text-slate-400]="!vehicleService.showErgoMannequin()"
          title="Toggle 95th-Percentile Ergonomic Mannequin"
          class="p-2 rounded-lg hover:bg-slate-800 transition">
          <mat-icon class="!w-4 !h-4 !text-base">accessibility_new</mat-icon>
        </button>
      </div>

      <!-- Bottom Interactive Controls Bar (Exploded View & Cross-Section) -->
      <div class="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 flex items-center gap-4 bg-slate-900/95 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-slate-700/80 shadow-2xl pointer-events-auto">
        <!-- Exploded View Slider -->
        <div class="flex items-center gap-2">
          <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">burst_mode</mat-icon>
          <span class="text-xs font-mono text-slate-300">EXPLODE</span>
          <input 
            type="range" 
            min="0" 
            max="1" 
            step="0.01" 
            [value]="vehicleService.explodedFactor()"
            (input)="onExplodeChange($event)"
            class="w-24 md:w-32 accent-cyan-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg">
          <span class="text-xs font-mono text-cyan-300 w-8">{{ (vehicleService.explodedFactor() * 100).toFixed(0) }}%</span>
        </div>

        <div class="w-px h-5 bg-slate-700"></div>

        <!-- Cross-Section Selector -->
        <div class="flex items-center gap-2">
          <mat-icon class="!w-4 !h-4 !text-base text-amber-400">content_cut</mat-icon>
          <span class="text-xs font-mono text-slate-300">SECTION</span>
          <select 
            [value]="vehicleService.sectionMode()"
            (change)="onSectionChange($event)"
            class="bg-slate-800 border border-slate-700 text-xs font-mono text-slate-200 rounded px-2 py-1 focus:outline-none focus:border-cyan-500">
            <option value="NONE">Off</option>
            <option value="LONGITUDINAL">Longitudinal (X-Z)</option>
            <option value="TRANSVERSAL">Transversal (Y-Z)</option>
            <option value="HORIZONTAL">Horizontal (X-Y)</option>
          </select>
        </div>

        <div class="w-px h-5 bg-slate-700"></div>

        <!-- Reset Camera -->
        <button 
          (click)="resetCamera()"
          class="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
          title="Reset Camera Target">
          <mat-icon class="!w-4 !h-4 !text-base">restart_alt</mat-icon>
        </button>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Viewport3D implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) containerRef!: ElementRef<HTMLDivElement>;

  readonly vehicleService = inject(CanonicalVehicleService);
  readonly factoryService = inject(FactorySimulationService);
  private ngZone = inject(NgZone);
  private platformId = inject(PLATFORM_ID);

  fps = 60;
  private frameCount = 0;
  private lastFpsTime = performance.now();

  // Three.js Core
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private resizeObserver: ResizeObserver | null = null;

  // Interaction & Camera Controls
  private isPointerDown = false;
  private previousPointerPosition = { x: 0, y: 0 };
  private cameraTarget = new THREE.Vector3(0, 0.4, 0);
  private spherical = { radius: 6.8, phi: Math.PI / 3, theta: Math.PI / 4 };

  // Raycaster for 3D component clicking
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();

  // Mesh Groups
  private vehicleRootGroup = new THREE.Group();
  private factoryFloorGroup = new THREE.Group();
  private cgMarkerMesh!: THREE.Mesh;
  private ergoMannequinGroup = new THREE.Group();
  private componentMeshMap = new Map<string, THREE.Object3D>();

  // Clipping Planes for Section Views
  private clipPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

  constructor() {
    // Effect to dynamically rebuild/update vehicle 3D nodes when parameters or materials change
    effect(() => {
      // Track dependencies
      const params = this.vehicleService.parameters();
      const color = this.vehicleService.exteriorColorHex();
      const exploded = this.vehicleService.explodedFactor();
      const wireframe = this.vehicleService.wireframeMode();
      const showCG = this.vehicleService.showCenterOfGravity();
      const showMannequin = this.vehicleService.showErgoMannequin();
      const section = this.vehicleService.sectionMode();
      const activeStudio = this.vehicleService.activeStudio();
      const selectedId = this.vehicleService.selectedComponentId();

      if (this.scene) {
        this.updateVehicleGeometry(params, color, wireframe, selectedId);
        this.updateExplodedOffsets(exploded);
        this.updateCGMarker(showCG);
        this.updateErgoMannequin(showMannequin);
        this.updateSectionClipping(section);
        this.updateFactoryFloorVisibility(activeStudio === 'FACTORY');
      }
    });
  }

  ngOnInit() {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }
    this.ngZone.runOutsideAngular(() => {
      this.initThreeScene();
      this.buildVehicleMeshHierarchy();
      this.buildFactoryFloor();
      this.buildCenterOfGravityMarker();
      this.buildErgoMannequin();
      this.setupInteraction();
      this.startRenderLoop();
    });
  }

  ngOnDestroy() {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  private initThreeScene() {
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x060b17);
    this.scene.fog = new THREE.FogExp2(0x060b17, 0.035);

    this.camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    this.updateCameraPosition();

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.localClippingEnabled = true;
    container.appendChild(this.renderer.domElement);

    // Studio Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    this.scene.add(ambientLight);

    const dirLightKey = new THREE.DirectionalLight(0xe0f2fe, 3.2);
    dirLightKey.position.set(6, 10, 8);
    dirLightKey.castShadow = true;
    dirLightKey.shadow.mapSize.width = 2048;
    dirLightKey.shadow.mapSize.height = 2048;
    dirLightKey.shadow.bias = -0.0001;
    this.scene.add(dirLightKey);

    const dirLightRim = new THREE.DirectionalLight(0x38bdf8, 2.0);
    dirLightRim.position.set(-8, 6, -6);
    this.scene.add(dirLightRim);

    const floorGrid = new THREE.GridHelper(24, 48, 0x0284c7, 0x1e293b);
    floorGrid.position.y = -0.01;
    this.scene.add(floorGrid);

    this.scene.add(this.vehicleRootGroup);
    this.scene.add(this.factoryFloorGroup);

    // Resize handling
    this.resizeObserver = new ResizeObserver(() => {
      this.onWindowResize();
    });
    this.resizeObserver.observe(container);
  }

  private buildVehicleMeshHierarchy() {
    this.vehicleRootGroup.clear();
    this.componentMeshMap.clear();

    const carColor = new THREE.Color(this.vehicleService.exteriorColorHex());

    // 1. Monocoque Floorpan & Battery Chassis Base
    const floorGeo = new THREE.BoxGeometry(3.6, 0.12, 1.5);
    const floorMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6, metalness: 0.7 });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.position.set(0, 0.3, 0);
    floorMesh.castShadow = true;
    floorMesh.receiveShadow = true;
    floorMesh.userData['componentId'] = 'COMP-STRUC-FLOOR';
    this.vehicleRootGroup.add(floorMesh);
    this.componentMeshMap.set('COMP-STRUC-FLOOR', floorMesh);

    // 2. High Voltage 60 kWh Battery Pack
    const batGeo = new THREE.BoxGeometry(2.1, 0.15, 1.3);
    const batMat = new THREE.MeshStandardMaterial({ color: 0x10b981, roughness: 0.4, metalness: 0.8 });
    const batMesh = new THREE.Mesh(batGeo, batMat);
    batMesh.position.set(0, 0.22, 0);
    batMesh.userData['componentId'] = 'COMP-BAT-PACK-60';
    this.vehicleRootGroup.add(batMesh);
    this.componentMeshMap.set('COMP-BAT-PACK-60', batMesh);

    // 3. Iconic Curved Beetle Roof Dome (Parametric Extrusion/Lathe Dome)
    const roofCurveGeo = new THREE.SphereGeometry(1.3, 32, 24, 0, Math.PI * 2, 0, Math.PI * 0.48);
    roofCurveGeo.scale(1.35, 0.7, 1.05);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: carColor,
      roughness: 0.15,
      metalness: 0.75
    });
    const roofMesh = new THREE.Mesh(roofCurveGeo, bodyMat);
    roofMesh.position.set(-0.1, 0.95, 0);
    roofMesh.castShadow = true;
    roofMesh.userData['componentId'] = 'COMP-ROOF-01';
    this.vehicleRootGroup.add(roofMesh);
    this.componentMeshMap.set('COMP-ROOF-01', roofMesh);

    // 4. Front Sloping Hood
    const hoodGeo = new THREE.CylinderGeometry(0.68, 0.75, 1.1, 24, 1, false, 0, Math.PI);
    hoodGeo.rotateZ(Math.PI / 2);
    hoodGeo.rotateY(Math.PI / 2);
    hoodGeo.scale(1.0, 0.45, 1.25);
    const hoodMesh = new THREE.Mesh(hoodGeo, bodyMat);
    hoodMesh.position.set(1.25, 0.55, 0);
    hoodMesh.rotation.z = -0.12;
    hoodMesh.castShadow = true;
    hoodMesh.userData['componentId'] = 'COMP-HOOD-01';
    this.vehicleRootGroup.add(hoodMesh);
    this.componentMeshMap.set('COMP-HOOD-01', hoodMesh);

    // 5. Four Distinct Flared Beetle Wheel Arches (Fenders)
    const createFender = (id: string, posX: number, posZ: number, isRight: boolean) => {
      const fenderGeo = new THREE.TorusGeometry(0.48, 0.14, 16, 24, Math.PI);
      fenderGeo.scale(1.0, 1.0, 1.3);
      const fenderMesh = new THREE.Mesh(fenderGeo, bodyMat);
      fenderMesh.position.set(posX, 0.46, posZ);
      fenderMesh.rotation.y = isRight ? -Math.PI / 2 : Math.PI / 2;
      fenderMesh.castShadow = true;
      fenderMesh.userData['componentId'] = id;
      this.vehicleRootGroup.add(fenderMesh);
      this.componentMeshMap.set(id, fenderMesh);
    };

    createFender('COMP-FENDER-FL', 1.27, 0.76, false);
    createFender('COMP-FENDER-FR', 1.27, -0.76, true);
    createFender('COMP-FENDER-RL', -1.27, 0.76, false);
    createFender('COMP-FENDER-RR', -1.27, -0.76, true);

    // 6. Left and Right Doors
    const doorGeo = new THREE.BoxGeometry(1.25, 0.65, 0.08);
    const doorL = new THREE.Mesh(doorGeo, bodyMat);
    doorL.position.set(0.05, 0.65, 0.76);
    doorL.userData['componentId'] = 'COMP-DOOR-L';
    this.vehicleRootGroup.add(doorL);
    this.componentMeshMap.set('COMP-DOOR-L', doorL);

    const doorR = new THREE.Mesh(doorGeo, bodyMat);
    doorR.position.set(0.05, 0.65, -0.76);
    doorR.userData['componentId'] = 'COMP-DOOR-R';
    this.vehicleRootGroup.add(doorR);
    this.componentMeshMap.set('COMP-DOOR-R', doorR);

    // 7. Glass Glazing (Windshield & Rear Oval Glass)
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0x0ea5e9,
      transmission: 0.9,
      opacity: 1,
      transparent: true,
      roughness: 0.05,
      ior: 1.52,
      thickness: 0.2
    });

    const windshieldGeo = new THREE.CylinderGeometry(0.72, 0.72, 0.85, 24, 1, false, 0, Math.PI);
    windshieldGeo.rotateZ(Math.PI / 2);
    windshieldGeo.scale(1.2, 0.45, 0.95);
    const windshieldMesh = new THREE.Mesh(windshieldGeo, glassMat);
    windshieldMesh.position.set(0.85, 1.05, 0);
    windshieldMesh.rotation.z = -0.55;
    windshieldMesh.userData['componentId'] = 'COMP-GLASS-WINDSHIELD';
    this.vehicleRootGroup.add(windshieldMesh);
    this.componentMeshMap.set('COMP-GLASS-WINDSHIELD', windshieldMesh);

    const rearGlassGeo = new THREE.SphereGeometry(0.65, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.35);
    rearGlassGeo.scale(0.9, 0.5, 0.9);
    const rearGlassMesh = new THREE.Mesh(rearGlassGeo, glassMat);
    rearGlassMesh.position.set(-1.0, 1.08, 0);
    rearGlassMesh.rotation.z = 0.65;
    rearGlassMesh.userData['componentId'] = 'COMP-GLASS-REAR';
    this.vehicleRootGroup.add(rearGlassMesh);
    this.componentMeshMap.set('COMP-GLASS-REAR', rearGlassMesh);

    // 8. Four Wheels & Tires
    const createWheel = (id: string, posX: number, posZ: number) => {
      const wheelGroup = new THREE.Group();
      wheelGroup.position.set(posX, 0.34, posZ);

      // Tire (Rubber)
      const tireGeo = new THREE.TorusGeometry(0.34, 0.12, 16, 32);
      const tireMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.85 });
      const tireMesh = new THREE.Mesh(tireGeo, tireMat);
      tireMesh.rotation.y = Math.PI / 2;
      tireMesh.castShadow = true;
      wheelGroup.add(tireMesh);

      // Alloy Rim
      const rimGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.22, 24);
      rimGeo.rotateZ(Math.PI / 2);
      const rimMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.9, roughness: 0.2 });
      const rimMesh = new THREE.Mesh(rimGeo, rimMat);
      wheelGroup.add(rimMesh);

      // Brake Caliper
      const brakeGeo = new THREE.BoxGeometry(0.12, 0.14, 0.08);
      const brakeMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.3 });
      const brakeMesh = new THREE.Mesh(brakeGeo, brakeMat);
      brakeMesh.position.set(0, 0.12, 0);
      wheelGroup.add(brakeMesh);

      wheelGroup.userData['componentId'] = id;
      this.vehicleRootGroup.add(wheelGroup);
      this.componentMeshMap.set(id, wheelGroup);
    };

    createWheel('COMP-WHEEL-FL', 1.27, 0.75);
    createWheel('COMP-WHEEL-FR', 1.27, -0.75);
    createWheel('COMP-WHEEL-RL', -1.27, 0.75);
    createWheel('COMP-WHEEL-RR', -1.27, -0.75);

    // 9. Interior: Dashboard & Steering Wheel & Seats
    const dashGeo = new THREE.BoxGeometry(0.55, 0.35, 1.35);
    const dashMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.7 });
    const dashMesh = new THREE.Mesh(dashGeo, dashMat);
    dashMesh.position.set(0.65, 0.75, 0);
    dashMesh.userData['componentId'] = 'COMP-INT-DASHBOARD';
    this.vehicleRootGroup.add(dashMesh);
    this.componentMeshMap.set('COMP-INT-DASHBOARD', dashMesh);

    // Steering Wheel
    const steerGeo = new THREE.TorusGeometry(0.18, 0.02, 12, 24);
    const steerMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.6, roughness: 0.3 });
    const steerMesh = new THREE.Mesh(steerGeo, steerMat);
    steerMesh.position.set(0.48, 0.82, 0.38);
    steerMesh.rotation.y = Math.PI / 2;
    steerMesh.rotation.z = -0.3;
    steerMesh.userData['componentId'] = 'COMP-INT-STEERING';
    this.vehicleRootGroup.add(steerMesh);
    this.componentMeshMap.set('COMP-INT-STEERING', steerMesh);

    // Front Seats
    const createSeat = (id: string, posX: number, posZ: number) => {
      const seatGroup = new THREE.Group();
      seatGroup.position.set(posX, 0.58, posZ);

      // Base Cushion
      const cushionGeo = new THREE.BoxGeometry(0.5, 0.12, 0.5);
      const seatMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 });
      const cushionMesh = new THREE.Mesh(cushionGeo, seatMat);
      seatGroup.add(cushionMesh);

      // Backrest
      const backGeo = new THREE.BoxGeometry(0.12, 0.65, 0.46);
      const backMesh = new THREE.Mesh(backGeo, seatMat);
      backMesh.position.set(-0.2, 0.35, 0);
      backMesh.rotation.z = -0.15; // 24 deg recline
      seatGroup.add(backMesh);

      seatGroup.userData['componentId'] = id;
      this.vehicleRootGroup.add(seatGroup);
      this.componentMeshMap.set(id, seatGroup);
    };

    createSeat('COMP-SEAT-DRIVER', 0.1, 0.38);
    createSeat('COMP-SEAT-PASSENGER', 0.1, -0.38);

    // 10. Iconic Circular LED Headlights
    const createHeadlight = (id: string, posX: number, posZ: number) => {
      const headGeo = new THREE.CylinderGeometry(0.13, 0.13, 0.1, 24);
      headGeo.rotateZ(Math.PI / 2);
      const headMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        emissive: 0x38bdf8,
        emissiveIntensity: 0.9,
        roughness: 0.1
      });
      const headMesh = new THREE.Mesh(headGeo, headMat);
      headMesh.position.set(posX, 0.68, posZ);
      headMesh.userData['componentId'] = id;
      this.vehicleRootGroup.add(headMesh);
      this.componentMeshMap.set(id, headMesh);
    };

    createHeadlight('COMP-LIGHT-HEADLIGHT-L', 1.84, 0.58);
    createHeadlight('COMP-LIGHT-HEADLIGHT-R', 1.84, -0.58);
  }

  private buildCenterOfGravityMarker() {
    const cgGroup = new THREE.Group();
    
    // Core Sphere
    const sphereGeo = new THREE.SphereGeometry(0.09, 16, 16);
    const sphereMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, wireframe: true });
    this.cgMarkerMesh = new THREE.Mesh(sphereGeo, sphereMat);
    cgGroup.add(this.cgMarkerMesh);

    // Axes crosshairs
    const axes = new THREE.AxesHelper(0.35);
    cgGroup.add(axes);

    this.scene.add(cgGroup);
    this.cgMarkerMesh.parent = cgGroup;
  }

  private buildErgoMannequin() {
    this.ergoMannequinGroup.clear();

    // Wireframe 95th Percentile RAMSIS Ergonomic Mannequin
    const manMat = new THREE.MeshStandardMaterial({ 
      color: 0x10b981, 
      roughness: 0.5, 
      wireframe: true,
      transparent: true,
      opacity: 0.85
    });

    // Head
    const headGeo = new THREE.SphereGeometry(0.12, 12, 12);
    const headMesh = new THREE.Mesh(headGeo, manMat);
    headMesh.position.set(0.08, 1.28, 0.38);
    this.ergoMannequinGroup.add(headMesh);

    // Sight line vector (green laser beam projecting to windshield)
    const sightLineGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0.12, 1.28, 0.38),
      new THREE.Vector3(1.8, 1.45, 0.38)
    ]);
    const sightLineMat = new THREE.LineBasicMaterial({ color: 0x34d399, linewidth: 2 });
    const sightLine = new THREE.Line(sightLineGeo, sightLineMat);
    this.ergoMannequinGroup.add(sightLine);

    // Torso
    const torsoGeo = new THREE.CylinderGeometry(0.14, 0.12, 0.5, 12);
    const torsoMesh = new THREE.Mesh(torsoGeo, manMat);
    torsoMesh.position.set(0.02, 0.95, 0.38);
    torsoMesh.rotation.z = -0.2;
    this.ergoMannequinGroup.add(torsoMesh);

    // Thighs
    const thighGeo = new THREE.CylinderGeometry(0.08, 0.07, 0.45, 8);
    thighGeo.rotateZ(Math.PI / 2);
    const thighL = new THREE.Mesh(thighGeo, manMat);
    thighL.position.set(0.25, 0.65, 0.46);
    this.ergoMannequinGroup.add(thighL);

    const thighR = new THREE.Mesh(thighGeo, manMat);
    thighR.position.set(0.25, 0.65, 0.30);
    this.ergoMannequinGroup.add(thighR);

    // Lower legs
    const shinGeo = new THREE.CylinderGeometry(0.06, 0.05, 0.45, 8);
    const shinL = new THREE.Mesh(shinGeo, manMat);
    shinL.position.set(0.55, 0.45, 0.46);
    shinL.rotation.z = 0.35;
    this.ergoMannequinGroup.add(shinL);

    const shinR = new THREE.Mesh(shinGeo, manMat);
    shinR.position.set(0.55, 0.45, 0.30);
    shinR.rotation.z = 0.35;
    this.ergoMannequinGroup.add(shinR);

    this.scene.add(this.ergoMannequinGroup);
  }

  private buildFactoryFloor() {
    this.factoryFloorGroup.clear();

    // Conveyor Line Rails
    const railGeo = new THREE.BoxGeometry(48, 0.15, 0.2);
    const railMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.4 });
    
    const railL = new THREE.Mesh(railGeo, railMat);
    railL.position.set(0, 0.08, 1.4);
    this.factoryFloorGroup.add(railL);

    const railR = new THREE.Mesh(railGeo, railMat);
    railR.position.set(0, 0.08, -1.4);
    this.factoryFloorGroup.add(railR);

    // Yellow Safety Danger Demarcation Lines
    const stripGeo = new THREE.PlaneGeometry(48, 0.1);
    stripGeo.rotateX(-Math.PI / 2);
    const stripMat = new THREE.MeshBasicMaterial({ color: 0xeab308 });
    
    const stripL = new THREE.Mesh(stripGeo, stripMat);
    stripL.position.set(0, 0.01, 2.2);
    this.factoryFloorGroup.add(stripL);

    const stripR = new THREE.PlaneGeometry(48, 0.1);
    stripR.rotateX(-Math.PI / 2);
    const stripRMesh = new THREE.Mesh(stripR, stripMat);
    stripRMesh.position.set(0, 0.01, -2.2);
    this.factoryFloorGroup.add(stripRMesh);

    // 7 Industrial Robotic Arms positioned along conveyor
    const robotPositions = [
      { id: 'ROB-01', x: -18, z: 3.2, name: 'Body Framing Arm' },
      { id: 'ROB-02', x: -12, z: -3.2, name: 'Laser Brazer #17' },
      { id: 'ROB-03', x: -6, z: 3.2, name: 'Paint Atomizer' },
      { id: 'ROB-04', x: 0, z: -3.2, name: 'Marriage Lift' },
      { id: 'ROB-06', x: 6, z: 3.2, name: 'Cockpit Inserter' },
      { id: 'ROB-07', x: 12, z: -3.2, name: 'Glass Placement' },
      { id: 'ROB-09', x: 18, z: 3.2, name: 'Wheel Torquer' }
    ];

    for (const r of robotPositions) {
      const robotArm = this.createRobotMesh(r.name === 'Laser Brazer #17' && this.factoryService.robot17FaultActive());
      robotArm.position.set(r.x, 0, r.z);
      if (r.z < 0) robotArm.rotation.y = Math.PI;
      this.factoryFloorGroup.add(robotArm);
    }
  }

  private createRobotMesh(isFaulted: boolean): THREE.Group {
    const group = new THREE.Group();

    // Base Pedestal
    const baseGeo = new THREE.CylinderGeometry(0.5, 0.6, 0.4, 16);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7, roughness: 0.4 });
    const baseMesh = new THREE.Mesh(baseGeo, baseMat);
    baseMesh.position.y = 0.2;
    group.add(baseMesh);

    // Turntable Joint 1
    const j1Geo = new THREE.CylinderGeometry(0.35, 0.35, 0.4, 16);
    const armMat = new THREE.MeshStandardMaterial({ 
      color: isFaulted ? 0xdc2626 : 0xf97316, // Orange KUKA/ABB standard, Red if fault
      roughness: 0.3, 
      metalness: 0.6 
    });
    const j1Mesh = new THREE.Mesh(j1Geo, armMat);
    j1Mesh.position.y = 0.5;
    group.add(j1Mesh);

    // Lower Arm Boom Joint 2
    const boom1Geo = new THREE.BoxGeometry(0.28, 1.4, 0.28);
    const boom1Mesh = new THREE.Mesh(boom1Geo, armMat);
    boom1Mesh.position.set(0.2, 1.2, 0);
    boom1Mesh.rotation.z = -0.35;
    group.add(boom1Mesh);

    // Upper Arm Boom Joint 3
    const boom2Geo = new THREE.BoxGeometry(0.22, 1.3, 0.22);
    const boom2Mesh = new THREE.Mesh(boom2Geo, armMat);
    boom2Mesh.position.set(0.5, 1.9, 0);
    boom2Mesh.rotation.z = 0.65;
    group.add(boom2Mesh);

    // Tool End-Effector (Laser / Gripper)
    const toolGeo = new THREE.ConeGeometry(0.12, 0.35, 12);
    toolGeo.rotateZ(-Math.PI / 2);
    const toolMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9 });
    const toolMesh = new THREE.Mesh(toolGeo, toolMat);
    toolMesh.position.set(0.95, 2.1, 0);
    group.add(toolMesh);

    return group;
  }

  private updateVehicleGeometry(params: VehicleParameters, colorHex: string, wireframe: boolean, selectedId: string | null) {
    const col = new THREE.Color(colorHex);

    this.componentMeshMap.forEach((mesh, compId) => {
      // Wireframe update
      mesh.traverse(child => {
        if (child instanceof THREE.Mesh && child.material) {
          const mat = child.material as THREE.MeshStandardMaterial;
          mat.wireframe = wireframe;

          // Highlight selected component in glowing cyan/amber
          if (compId === selectedId) {
            mat.emissive = new THREE.Color(0x06b6d4);
            mat.emissiveIntensity = 0.45;
          } else if (mat.emissive && (compId.startsWith('COMP-ROOF') || compId.startsWith('COMP-HOOD') || compId.startsWith('COMP-FENDER') || compId.startsWith('COMP-DOOR'))) {
            mat.color = col;
            mat.emissive = new THREE.Color(0x000000);
            mat.emissiveIntensity = 0;
          }
        }
      });

      // Parametric scaling
      if (compId === 'COMP-ROOF-01') {
        const heightScale = params.roof_height / 1500;
        mesh.scale.set(1.0, heightScale, 1.0);
      }
    });
  }

  private updateExplodedOffsets(factor: number) {
    // Vector expansion based on component assemblies
    const offsets: Record<string, [number, number, number]> = {
      'COMP-ROOF-01': [0, 1.6, 0],
      'COMP-HOOD-01': [1.2, 0.8, 0],
      'COMP-FENDER-FL': [0.6, 0.3, 1.2],
      'COMP-FENDER-FR': [0.6, 0.3, -1.2],
      'COMP-FENDER-RL': [-0.6, 0.3, 1.2],
      'COMP-FENDER-RR': [-0.6, 0.3, -1.2],
      'COMP-DOOR-L': [0, 0, 1.4],
      'COMP-DOOR-R': [0, 0, -1.4],
      'COMP-GLASS-WINDSHIELD': [0.8, 1.1, 0],
      'COMP-GLASS-REAR': [-0.8, 1.1, 0],
      'COMP-BAT-PACK-60': [0, -0.9, 0],
      'COMP-WHEEL-FL': [0, 0, 1.1],
      'COMP-WHEEL-FR': [0, 0, -1.1],
      'COMP-WHEEL-RL': [0, 0, 1.1],
      'COMP-WHEEL-RR': [0, 0, -1.1],
      'COMP-LIGHT-HEADLIGHT-L': [1.1, 0.4, 0.4],
      'COMP-LIGHT-HEADLIGHT-R': [1.1, 0.4, -0.4],
      'COMP-INT-DASHBOARD': [0, 0.9, 0],
      'COMP-INT-STEERING': [0.3, 0.7, 0.3],
      'COMP-SEAT-DRIVER': [0, 0.8, 0.6],
      'COMP-SEAT-PASSENGER': [0, 0.8, -0.6]
    };

    this.componentMeshMap.forEach((mesh, compId) => {
      const vec = offsets[compId] || [0, 0, 0];
      mesh.position.x = (mesh.userData['baseX'] ??= mesh.position.x) + vec[0] * factor;
      mesh.position.y = (mesh.userData['baseY'] ??= mesh.position.y) + vec[1] * factor;
      mesh.position.z = (mesh.userData['baseZ'] ??= mesh.position.z) + vec[2] * factor;
    });
  }

  private updateCGMarker(show: boolean) {
    if (this.cgMarkerMesh && this.cgMarkerMesh.parent) {
      this.cgMarkerMesh.parent.visible = show;
      const cg = this.vehicleService.massInertiaMetrics();
      this.cgMarkerMesh.parent.position.set(cg.cg_x_mm / 1000, cg.cg_z_mm / 1000, cg.cg_y_mm / 1000);
    }
  }

  private updateErgoMannequin(show: boolean) {
    this.ergoMannequinGroup.visible = show;
    // Align with seat positions
    const seatX = this.vehicleService.seatPositionX() / 1000;
    const seatZ = this.vehicleService.seatHeightOffset() / 1000;
    this.ergoMannequinGroup.position.set(seatX, seatZ, 0);
  }

  private updateSectionClipping(mode: string) {
    if (mode === 'NONE') {
      this.renderer.clippingPlanes = [];
    } else if (mode === 'LONGITUDINAL') {
      this.clipPlane.set(new THREE.Vector3(0, 0, 1), 0.05);
      this.renderer.clippingPlanes = [this.clipPlane];
    } else if (mode === 'TRANSVERSAL') {
      this.clipPlane.set(new THREE.Vector3(1, 0, 0), 0.0);
      this.renderer.clippingPlanes = [this.clipPlane];
    } else if (mode === 'HORIZONTAL') {
      this.clipPlane.set(new THREE.Vector3(0, 1, 0), -0.7);
      this.renderer.clippingPlanes = [this.clipPlane];
    }
  }

  private updateFactoryFloorVisibility(isFactoryStudio: boolean) {
    this.factoryFloorGroup.visible = isFactoryStudio;
  }

  private setupInteraction() {
    const el = this.containerRef.nativeElement;

    el.addEventListener('pointerdown', (e) => {
      this.isPointerDown = true;
      this.previousPointerPosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('pointermove', (e) => {
      if (!this.isPointerDown) return;
      const deltaX = e.clientX - this.previousPointerPosition.x;
      const deltaY = e.clientY - this.previousPointerPosition.y;

      this.spherical.theta -= deltaX * 0.006;
      this.spherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.02, this.spherical.phi - deltaY * 0.006));

      this.previousPointerPosition = { x: e.clientX, y: e.clientY };
      this.updateCameraPosition();
    });

    window.addEventListener('pointerup', () => {
      this.isPointerDown = false;
    });

    el.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.spherical.radius = Math.max(2.0, Math.min(18.0, this.spherical.radius + e.deltaY * 0.005));
      this.updateCameraPosition();
    }, { passive: false });

    // Raycast on click
    el.addEventListener('click', (e) => {
      const rect = el.getBoundingClientRect();
      this.pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this.pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      this.raycaster.setFromCamera(this.pointer, this.camera);
      const intersects = this.raycaster.intersectObjects(this.vehicleRootGroup.children, true);

      if (intersects.length > 0) {
        let hitObj: THREE.Object3D | null = intersects[0].object;
        while (hitObj && !hitObj.userData['componentId'] && hitObj !== this.vehicleRootGroup) {
          hitObj = hitObj.parent;
        }
        if (hitObj && hitObj.userData['componentId']) {
          this.ngZone.run(() => {
            this.vehicleService.selectedComponentId.set(hitObj?.userData['componentId']);
          });
        }
      }
    });
  }

  private updateCameraPosition() {
    const x = this.spherical.radius * Math.sin(this.spherical.phi) * Math.sin(this.spherical.theta);
    const y = this.spherical.radius * Math.cos(this.spherical.phi);
    const z = this.spherical.radius * Math.sin(this.spherical.phi) * Math.cos(this.spherical.theta);

    this.camera.position.set(x + this.cameraTarget.x, y + this.cameraTarget.y, z + this.cameraTarget.z);
    this.camera.lookAt(this.cameraTarget);
  }

  private onWindowResize() {
    const container = this.containerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  private startRenderLoop() {
    let lastTime = performance.now();

    const animate = (currentTime: number) => {
      const deltaMs = currentTime - lastTime;
      lastTime = currentTime;

      // Conveyor simulation tick
      this.factoryService.tickConveyor(deltaMs);

      // FPS tracking
      this.frameCount++;
      if (currentTime - this.lastFpsTime >= 1000) {
        this.fps = this.frameCount;
        this.frameCount = 0;
        this.lastFpsTime = currentTime;
      }

      this.renderer.render(this.scene, this.camera);
      this.animationFrameId = requestAnimationFrame(animate);
    };

    this.animationFrameId = requestAnimationFrame(animate);
  }

  setPreset(preset: CameraViewPreset) {
    this.vehicleService.cameraPreset.set(preset);
    if (preset === 'ORBIT') {
      this.spherical = { radius: 6.8, phi: Math.PI / 3, theta: Math.PI / 4 };
      this.cameraTarget.set(0, 0.4, 0);
    } else if (preset === 'SIDE') {
      this.spherical = { radius: 6.2, phi: Math.PI / 2.1, theta: Math.PI / 2 };
      this.cameraTarget.set(0, 0.4, 0);
    } else if (preset === 'FRONT') {
      this.spherical = { radius: 5.8, phi: Math.PI / 2.1, theta: 0 };
      this.cameraTarget.set(0, 0.4, 0);
    } else if (preset === 'TOP') {
      this.spherical = { radius: 7.0, phi: 0.05, theta: 0 };
      this.cameraTarget.set(0, 0.2, 0);
    } else if (preset === 'INTERIOR') {
      this.spherical = { radius: 2.2, phi: Math.PI / 2.5, theta: Math.PI / 3.2 };
      this.cameraTarget.set(0.1, 0.7, 0.2);
    }
    this.updateCameraPosition();
  }

  toggleWireframe() {
    this.vehicleService.wireframeMode.update(w => !w);
  }

  toggleCG() {
    this.vehicleService.showCenterOfGravity.update(cg => !cg);
  }

  toggleErgoMannequin() {
    this.vehicleService.showErgoMannequin.update(m => !m);
  }

  onExplodeChange(e: Event) {
    const val = parseFloat((e.target as HTMLInputElement).value);
    this.vehicleService.explodedFactor.set(val);
  }

  onSectionChange(e: Event) {
    const val = (e.target as HTMLSelectElement).value as SectionMode;
    this.vehicleService.sectionMode.set(val);
  }

  resetCamera() {
    this.setPreset('ORBIT');
  }
}
