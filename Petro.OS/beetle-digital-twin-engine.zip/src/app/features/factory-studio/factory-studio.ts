import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FactorySimulationService } from '../../core/services/factory-simulation.service';
import { CanonicalVehicleService } from '../../core/services/canonical-vehicle.service';

@Component({
  selector: 'app-factory-studio',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full overflow-y-auto p-4 space-y-6 text-slate-200">
      <!-- Section Header -->
      <div class="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <h2 class="text-base font-semibold text-white tracking-wide flex items-center gap-2">
            <mat-icon class="text-amber-400 !w-5 !h-5 !text-lg">factory</mat-icon>
            Virtual Factory & MES Production Simulation
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">11-station discrete-event production line with robotic kinematics & bottleneck analysis.</p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="factoryService.togglePlayPause()"
            class="px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition border border-slate-700 bg-slate-800 hover:bg-slate-700 flex items-center gap-1">
            <mat-icon class="!w-4 !h-4 !text-base">{{ factoryService.isPlaying() ? 'pause' : 'play_arrow' }}</mat-icon>
            <span>{{ factoryService.isPlaying() ? 'PAUSE' : 'RESUME' }}</span>
          </button>
        </div>
      </div>

      <!-- Live Factory Line KPIs (JPH, Taktzeit, Bottleneck, OEE) -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
        <!-- Taktzeit -->
        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>LINE TAKTZEIT</span>
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-amber-400">timer</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-amber-300">
            {{ factoryService.plantMetrics().taktzeit_s }} <span class="text-xs text-slate-400">s</span>
          </div>
          <div class="text-[10px] text-slate-400 font-mono">Target: 58s | Max Cycle</div>
        </div>

        <!-- Jobs Per Hour -->
        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>LINE SPEED (JPH)</span>
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-cyan-400">speed</mat-icon>
          </div>
          <div class="text-2xl font-bold font-mono text-cyan-300">
            {{ factoryService.plantMetrics().line_speed_jph }} <span class="text-xs text-slate-400">JPH</span>
          </div>
          <div class="text-[10px] text-slate-400 font-mono">418 / 500 Daily Units</div>
        </div>

        <!-- Overall Line OEE -->
        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>OVERALL OEE</span>
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-emerald-400">trending_up</mat-icon>
          </div>
          <div 
            [class.text-emerald-300]="factoryService.plantMetrics().overall_line_oee >= 85"
            [class.text-red-400]="factoryService.plantMetrics().overall_line_oee < 85"
            class="text-2xl font-bold font-mono">
            {{ factoryService.plantMetrics().overall_line_oee }}%
          </div>
          <div class="text-[10px] text-slate-400 font-mono">Availability · Perf · Quality</div>
        </div>

        <!-- Active Bottleneck Station -->
        <div class="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1">
          <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>BOTTLENECK STATION</span>
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-red-400">warning</mat-icon>
          </div>
          <div class="text-sm font-bold font-mono text-red-400 truncate">
            {{ factoryService.plantMetrics().active_bottleneck_station }}
          </div>
          <div class="text-[10px] text-slate-400 font-mono truncate">Controls Total Output</div>
        </div>
      </div>

      <!-- MASTER DEMO CONTROLS: Interactive Factory Stress Testing -->
      <div class="bg-slate-900/90 rounded-xl p-4 border border-amber-500/30 space-y-3 shadow-xl">
        <div class="flex items-center justify-between">
          <span class="text-xs font-mono font-bold text-amber-300 flex items-center gap-1.5">
            <mat-icon class="!w-4 !h-4 !text-base text-amber-400">bolt</mat-icon>
            MASTER DEMO — DISRUPTION & BOTTLENECK INJECTION
          </span>
          <span class="text-[10px] font-mono text-slate-400">REAL-TIME PROPAGATION</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <!-- Robot #17 Fault -->
          <button 
            (click)="factoryService.triggerRobot17Fault()"
            [class.bg-red-950/70]="factoryService.robot17FaultActive()"
            [class.border-red-500]="factoryService.robot17FaultActive()"
            [class.bg-slate-950]="!factoryService.robot17FaultActive()"
            [class.border-slate-800]="!factoryService.robot17FaultActive()"
            class="p-3 rounded-xl border text-left hover:border-red-500/60 transition space-y-1">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold font-mono text-white flex items-center gap-1.5">
                <mat-icon class="!w-4 !h-4 !text-base text-red-400">precision_manufacturing</mat-icon>
                Simulate Robot #17 Failure
              </span>
              <span 
                [class.bg-red-500]="factoryService.robot17FaultActive()"
                [class.bg-slate-700]="!factoryService.robot17FaultActive()"
                class="text-[10px] font-mono px-2 py-0.5 rounded text-white font-bold">
                {{ factoryService.robot17FaultActive() ? 'TRIPPED' : 'STANDBY' }}
              </span>
            </div>
            <p class="text-[11px] text-slate-400">
              ABB Laser Brazer at Station 2 trips. Station cycle jumps to 138s, stalling line flow & reducing OEE.
            </p>
          </button>

          <!-- Paint Slowdown -->
          <button 
            (click)="factoryService.triggerPaintSlowdown()"
            [class.bg-amber-950/70]="factoryService.paintSlowdownActive()"
            [class.border-amber-500]="factoryService.paintSlowdownActive()"
            [class.bg-slate-950]="!factoryService.paintSlowdownActive()"
            [class.border-slate-800]="!factoryService.paintSlowdownActive()"
            class="p-3 rounded-xl border text-left hover:border-amber-500/60 transition space-y-1">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold font-mono text-white flex items-center gap-1.5">
                <mat-icon class="!w-4 !h-4 !text-base text-amber-400">format_paint</mat-icon>
                Paint Oven Curing Slowdown (+15%)
              </span>
              <span 
                [class.bg-amber-500]="factoryService.paintSlowdownActive()"
                [class.bg-slate-700]="!factoryService.paintSlowdownActive()"
                class="text-[10px] font-mono px-2 py-0.5 rounded text-white font-bold">
                {{ factoryService.paintSlowdownActive() ? 'ACTIVE' : 'STANDBY' }}
              </span>
            </div>
            <p class="text-[11px] text-slate-400">
              Station 3 cycle time increases to 75s due to humidity compensation, creating upstream buffer starvation.
            </p>
          </button>
        </div>
      </div>

      <!-- TIME MACHINE TIMELINE REPLAY -->
      <div class="bg-slate-900/80 rounded-xl p-4 border border-slate-800 space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>TIME MACHINE REPLAY SCRUBBER</span>
          <span class="text-cyan-400 text-xs font-mono">{{ factoryService.activeReplayTime() }} AM SHIFT</span>
        </div>

        <div class="grid grid-cols-5 gap-2 font-mono text-xs">
          @for (t of ['09:00', '09:05', '09:10', '09:15', '09:20']; track t) {
            <button 
              (click)="factoryService.setTimeMachineReplay(t)"
              [class.bg-cyan-600]="factoryService.activeReplayTime() === t"
              [class.text-white]="factoryService.activeReplayTime() === t"
              [class.bg-slate-950]="factoryService.activeReplayTime() !== t"
              [class.text-slate-400]="factoryService.activeReplayTime() !== t"
              class="p-2 rounded-lg border border-slate-800 hover:border-slate-700 transition text-center">
              <div class="font-bold">{{ t }}</div>
              <div class="text-[9px] mt-0.5">
                {{ t === '09:10' || t === '09:15' ? 'Incident' : 'Normal' }}
              </div>
            </button>
          }
        </div>
      </div>

      <!-- 11 Canonical Factory Stations Grid -->
      <div class="space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>11 CANONICAL PRODUCTION STATIONS</span>
          <span class="text-xs font-mono text-slate-500">CONVEYOR SEQUENCE 01 → 11</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          @for (s of factoryService.stations(); track s.station_id) {
            <div 
              [class.border-red-500]="s.is_bottleneck || s.status === 'BLOCKED'"
              [class.bg-red-950/20]="s.is_bottleneck || s.status === 'BLOCKED'"
              [class.border-slate-800]="!s.is_bottleneck && s.status !== 'BLOCKED'"
              [class.bg-slate-900/70]="!s.is_bottleneck && s.status !== 'BLOCKED'"
              class="p-3.5 rounded-xl border space-y-2 transition">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="w-6 h-6 rounded-full bg-slate-800 text-cyan-400 font-mono text-xs font-bold flex items-center justify-center">
                    {{ s.station_number }}
                  </span>
                  <div>
                    <div class="text-xs font-bold text-white">{{ s.german_name }}</div>
                    <div class="text-[10px] text-slate-400 font-mono">{{ s.name }}</div>
                  </div>
                </div>

                <div class="text-right font-mono">
                  <div class="text-xs font-bold" [class.text-red-400]="s.is_bottleneck" [class.text-emerald-400]="!s.is_bottleneck">
                    {{ s.cycle_time_actual_s }}s <span class="text-[10px] text-slate-500">/ {{ s.cycle_time_target_s }}s</span>
                  </div>
                  <span class="text-[9px] uppercase px-1.5 py-0.5 rounded font-bold"
                    [class.bg-emerald-950]="s.status === 'NORMAL'"
                    [class.text-emerald-400]="s.status === 'NORMAL'"
                    [class.bg-red-950]="s.status === 'BLOCKED'"
                    [class.text-red-400]="s.status === 'BLOCKED'"
                    [class.bg-amber-950]="s.status === 'SLOWDOWN'"
                    [class.text-amber-400]="s.status === 'SLOWDOWN'">
                    {{ s.status }}
                  </span>
                </div>
              </div>

              <p class="text-[11px] text-slate-400 leading-relaxed">{{ s.description }}</p>

              <div class="grid grid-cols-3 gap-2 text-[10px] font-mono text-slate-400 pt-2 border-t border-slate-800/80">
                <div>Buffer: <strong class="text-slate-200">{{ s.buffer_current }} / {{ s.buffer_capacity }}</strong></div>
                <div>Operators: <strong class="text-slate-200">{{ s.operators_count }}</strong></div>
                <div>OEE: <strong class="text-emerald-400">{{ s.oee_percent }}%</strong></div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Manufacturing BOM (MBOM) Table -->
      <div class="bg-slate-900/80 rounded-xl border border-slate-800 overflow-hidden space-y-2">
        <div class="p-3 border-b border-slate-800 flex items-center justify-between">
          <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center gap-2">
            <mat-icon class="!w-4 !h-4 !text-base text-amber-400">precision_manufacturing</mat-icon>
            MANUFACTURING BILL OF MATERIALS (MBOM) & TOOLING
          </div>
          <span class="text-[10px] font-mono bg-amber-950 px-2 py-0.5 rounded text-amber-400 border border-amber-800">MES LINKED</span>
        </div>

        <div class="overflow-x-auto max-h-60 overflow-y-auto">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800 sticky top-0">
              <tr>
                <th class="p-2.5">BOM ID / Part</th>
                <th class="p-2.5">Station</th>
                <th class="p-2.5">Assigned Operation</th>
                <th class="p-2.5">Machine / Tool</th>
                <th class="p-2.5">QA Requirement</th>
                <th class="p-2.5">Dur.</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (b of factoryService.manufacturingBOM(); track b.bom_id) {
                <tr class="hover:bg-slate-800/40 transition">
                  <td class="p-2.5">
                    <div class="font-bold text-white">{{ b.name }}</div>
                    <div class="text-[10px] text-slate-500">{{ b.part_number }}</div>
                  </td>
                  <td class="p-2.5 text-cyan-300">{{ b.station_id }}</td>
                  <td class="p-2.5 text-slate-300">{{ b.operation_name }}</td>
                  <td class="p-2.5 text-amber-300">{{ b.machine_id }}</td>
                  <td class="p-2.5 text-slate-400">{{ b.quality_check_type }}</td>
                  <td class="p-2.5 font-bold text-white">{{ b.duration_seconds }}s</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FactoryStudio {
  readonly factoryService = inject(FactorySimulationService);
  readonly vehicleService = inject(CanonicalVehicleService);
}
