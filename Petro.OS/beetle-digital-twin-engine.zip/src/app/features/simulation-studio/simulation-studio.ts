import { Component, inject, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CanonicalVehicleService } from '../../core/services/canonical-vehicle.service';
import { FactorySimulationService } from '../../core/services/factory-simulation.service';
import { WhatIfScenario, ParetoOptPoint } from '../../core/models/simulation.types';

@Component({
  selector: 'app-simulation-studio',
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="h-full overflow-y-auto p-4 space-y-6 text-slate-200">
      <!-- Section Header -->
      <div class="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <h2 class="text-base font-semibold text-white tracking-wide flex items-center gap-2">
            <mat-icon class="text-indigo-400 !w-5 !h-5 !text-lg">model_training</mat-icon>
            What-If Scenarios & Pareto Multi-Objective Optimization
          </h2>
          <p class="text-xs text-slate-400 mt-0.5">Explore trade-off frontiers between Mass, Drag, Ergonomics, Production Takt & Cost.</p>
        </div>
      </div>

      <!-- Presets for What-If Scenarios -->
      <div class="space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold">PRE-CONFIGURED WHAT-IF ENGINEERING EXPERIMENTS</div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          @for (s of scenarios(); track s.id) {
            <div class="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-3 hover:border-indigo-500/50 transition">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-white">{{ s.name }}</span>
                <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-400 border border-indigo-800">{{ s.category }}</span>
              </div>

              <p class="text-[11px] text-slate-400 leading-relaxed">{{ s.description }}</p>

              <!-- Predicted Impact -->
              <div class="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-2.5 rounded-lg border border-slate-800/80">
                <div>
                  <span class="text-slate-500">Mass:</span>
                  <strong [class.text-emerald-400]="s.predicted_impact.mass_delta_kg < 0" [class.text-amber-400]="s.predicted_impact.mass_delta_kg > 0" class="ml-1">
                    {{ s.predicted_impact.mass_delta_kg > 0 ? '+' : '' }}{{ s.predicted_impact.mass_delta_kg }} kg
                  </strong>
                </div>
                <div>
                  <span class="text-slate-500">Cost:</span>
                  <strong [class.text-emerald-400]="s.predicted_impact.cost_delta_eur < 0" [class.text-amber-400]="s.predicted_impact.cost_delta_eur > 0" class="ml-1">
                    {{ s.predicted_impact.cost_delta_eur > 0 ? '+' : '' }}€{{ s.predicted_impact.cost_delta_eur }}
                  </strong>
                </div>
                <div>
                  <span class="text-slate-500">cw Drag:</span>
                  <strong [class.text-emerald-400]="s.predicted_impact.cd_delta < 0" [class.text-red-400]="s.predicted_impact.cd_delta > 0" class="ml-1">
                    {{ s.predicted_impact.cd_delta > 0 ? '+' : '' }}{{ s.predicted_impact.cd_delta }}
                  </strong>
                </div>
                <div>
                  <span class="text-slate-500">Headroom:</span>
                  <strong [class.text-emerald-400]="s.predicted_impact.headroom_delta_mm > 0" [class.text-amber-400]="s.predicted_impact.headroom_delta_mm < 0" class="ml-1">
                    {{ s.predicted_impact.headroom_delta_mm > 0 ? '+' : '' }}{{ s.predicted_impact.headroom_delta_mm }} mm
                  </strong>
                </div>
              </div>

              <button 
                (click)="applyScenario(s)"
                class="w-full py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-mono font-semibold transition flex items-center justify-center gap-1.5 shadow-lg">
                <mat-icon class="!w-4 !h-4 !text-base">play_circle</mat-icon>
                Apply Scenario to Canonical Twin
              </button>
            </div>
          }
        </div>
      </div>

      <!-- Pareto Front Multi-Objective Optimization Explorer -->
      <div class="bg-slate-900/80 rounded-xl border border-slate-800 p-4 space-y-3">
        <div class="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold flex items-center justify-between">
          <span>PARETO OPTIMALITY FRONTIER (MASS VS. AERO VS. COST)</span>
          <span class="text-xs font-mono text-emerald-400">7 GENERATIONS COMPUTED</span>
        </div>

        <div class="space-y-2">
          @for (pt of paretoPoints(); track pt.iteration) {
            <div 
              [class.border-emerald-500]="pt.is_pareto_optimal"
              [class.bg-emerald-950/20]="pt.is_pareto_optimal"
              [class.border-slate-800]="!pt.is_pareto_optimal"
              [class.bg-slate-950]="!pt.is_pareto_optimal"
              class="p-3 rounded-xl border flex items-center justify-between text-xs font-mono">
              <div>
                <div class="flex items-center gap-2">
                  <span class="font-bold text-white">Design Gen #{{ pt.iteration }}</span>
                  @if (pt.is_pareto_optimal) {
                    <span class="text-[9px] px-2 py-0.5 bg-emerald-900 text-emerald-300 font-bold rounded">PARETO OPTIMAL</span>
                  }
                </div>
                <div class="text-[11px] text-slate-400 mt-1">
                  Roof: {{ pt.roof_height_mm }} mm · Cabin: {{ pt.cabin_volume_l }} L
                </div>
              </div>

              <div class="text-right space-y-0.5">
                <div>Mass: <strong class="text-cyan-300">{{ pt.mass_kg }} kg</strong></div>
                <div>Drag: <strong class="text-sky-300">cw {{ pt.cd_drag }}</strong></div>
                <div>Cost: <strong class="text-emerald-300">€{{ pt.cost_eur }}</strong></div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SimulationStudio {
  readonly vehicleService = inject(CanonicalVehicleService);
  readonly factoryService = inject(FactorySimulationService);

  readonly scenarios = signal<WhatIfScenario[]>([
    {
      id: 'SCEN-01',
      name: '+30 mm Roof Height & Upright Windshield',
      category: 'Geometric',
      description: 'Increases cabin headroom for 95th percentile occupants at the cost of frontal area aerodynamic drag.',
      parameter_delta: {
        roof_height: 1530,
        windshield_angle: 52
      },
      predicted_impact: {
        mass_delta_kg: 2.1,
        cost_delta_eur: 18.0,
        taktzeit_impact_s: 0,
        cd_delta: 0.009,
        headroom_delta_mm: 28
      }
    },
    {
      id: 'SCEN-02',
      name: 'CF-SMC Composite Hood & Roof Substitution',
      category: 'Material',
      description: 'Replaces steel and aluminum stamping panels with carbon-fiber sheet molding compound.',
      parameter_delta: {
        hood_thickness: 1.2,
        roof_thickness: 1.2
      },
      predicted_impact: {
        mass_delta_kg: -14.8,
        cost_delta_eur: 185.0,
        taktzeit_impact_s: 0,
        cd_delta: 0.0,
        headroom_delta_mm: 0
      }
    },
    {
      id: 'SCEN-03',
      name: 'Sport Aero Package (-30 mm Lowering & 58° Rake)',
      category: 'Geometric',
      description: 'Aggressive low silhouette with optimized flow separation line and reduced frontal area.',
      parameter_delta: {
        roof_height: 1470,
        ground_clearance: 130,
        windshield_angle: 58
      },
      predicted_impact: {
        mass_delta_kg: -1.8,
        cost_delta_eur: 0,
        taktzeit_impact_s: 0,
        cd_delta: -0.015,
        headroom_delta_mm: -25
      }
    }
  ]);

  readonly paretoPoints = signal<ParetoOptPoint[]>([
    { iteration: 1, roof_height_mm: 1500, mass_kg: 745.2, cost_eur: 12480, cd_drag: 0.278, cabin_volume_l: 2150, production_time_s: 58, is_pareto_optimal: true },
    { iteration: 2, roof_height_mm: 1470, mass_kg: 742.8, cost_eur: 12480, cd_drag: 0.264, cabin_volume_l: 2080, production_time_s: 58, is_pareto_optimal: true },
    { iteration: 3, roof_height_mm: 1530, mass_kg: 747.5, cost_eur: 12498, cd_drag: 0.287, cabin_volume_l: 2220, production_time_s: 58, is_pareto_optimal: true },
    { iteration: 4, roof_height_mm: 1550, mass_kg: 751.0, cost_eur: 12540, cd_drag: 0.298, cabin_volume_l: 2260, production_time_s: 60, is_pareto_optimal: false },
    { iteration: 5, roof_height_mm: 1450, mass_kg: 741.0, cost_eur: 12480, cd_drag: 0.261, cabin_volume_l: 2020, production_time_s: 58, is_pareto_optimal: false }
  ]);

  applyScenario(s: WhatIfScenario) {
    if (s.parameter_delta.roof_height) {
      this.vehicleService.updateParameter('roof_height', s.parameter_delta.roof_height);
    }
    if (s.parameter_delta.windshield_angle) {
      this.vehicleService.updateParameter('windshield_angle', s.parameter_delta.windshield_angle);
    }
    if (s.parameter_delta.ground_clearance) {
      this.vehicleService.updateParameter('ground_clearance', s.parameter_delta.ground_clearance);
    }
  }
}
