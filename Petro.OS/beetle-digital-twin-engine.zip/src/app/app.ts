import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CanonicalVehicleService } from './core/services/canonical-vehicle.service';
import { FactorySimulationService } from './core/services/factory-simulation.service';
import { QualityTwinService } from './core/services/quality-twin.service';
import { AIAssistantService } from './core/services/ai-assistant.service';
import { Viewport3D } from './features/viewport-3d/viewport-3d';
import { DesignStudio } from './features/design-studio/design-studio';
import { EngineeringStudio } from './features/engineering-studio/engineering-studio';
import { InteriorStudio } from './features/interior-studio/interior-studio';
import { FactoryStudio } from './features/factory-studio/factory-studio';
import { QualityStudio } from './features/quality-studio/quality-studio';
import { SimulationStudio } from './features/simulation-studio/simulation-studio';
import { AIAssistantModal } from './features/ai-assistant-modal/ai-assistant-modal';
import { ActiveStudio } from './core/models/vehicle.types';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    Viewport3D,
    DesignStudio,
    EngineeringStudio,
    InteriorStudio,
    FactoryStudio,
    QualityStudio,
    SimulationStudio,
    AIAssistantModal
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly vehicleService = inject(CanonicalVehicleService);
  readonly factoryService = inject(FactorySimulationService);
  readonly qualityService = inject(QualityTwinService);
  readonly aiService = inject(AIAssistantService);

  readonly studios: { id: ActiveStudio; label: string; icon: string; badge?: string }[] = [
    { id: 'DESIGN', label: 'Design & Geometry', icon: 'tune' },
    { id: 'ENGINEERING', label: 'Engineering & BOM', icon: 'architecture' },
    { id: 'INTERIOR', label: 'Ergonomics & RAMSIS', icon: 'airline_seat_recline_normal' },
    { id: 'FACTORY', label: 'Virtual Factory & MES', icon: 'factory', badge: '11 STATIONS' },
    { id: 'QUALITY', label: 'Quality & Traceability', icon: 'verified' },
    { id: 'SIMULATION', label: 'What-If & Pareto', icon: 'model_training' }
  ];

  selectStudio(studio: ActiveStudio) {
    this.vehicleService.activeStudio.set(studio);
    if (studio === 'INTERIOR') {
      this.vehicleService.cameraPreset.set('INTERIOR');
    } else if (studio === 'FACTORY') {
      this.vehicleService.cameraPreset.set('ORBIT');
    }
  }
}
