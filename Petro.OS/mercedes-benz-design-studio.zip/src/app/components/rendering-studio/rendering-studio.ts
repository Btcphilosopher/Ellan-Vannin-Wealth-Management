import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-rendering-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">camera_alt</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">RENDERINGPIPELINE & STUDIOPRÄSENTATION</h2>
            <div class="text-[11px] text-neutral-400 font-light">HDRI-Umgebungen, Virtuelle Kameras, Schärfentiefe & 4K Export</div>
          </div>
        </div>

        <button (click)="state.exportPdfDesignReport()"
          class="px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-lg shadow-rose-950/40 transition cursor-pointer">
          <mat-icon class="!w-3.5 !h-3.5 !text-sm">picture_as_pdf</mat-icon>
          <span>PDF Designbericht generieren</span>
        </button>
      </div>

      <!-- Studio Environments -->
      <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3 font-mono text-xs">
        <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
          <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">wb_sunny</mat-icon>
          <span>STUDIO-LICHTRIG & HDRI-ATMOSPHÄRE</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          @for (env of studioRigs; track env.id) {
            <div class="p-3.5 rounded-xl border border-white/10 bg-black/40 hover:border-cyan-500/40 transition flex flex-col justify-between space-y-2">
              <div>
                <div class="font-bold text-neutral-200">{{ env.name }}</div>
                <div class="text-[10px] text-neutral-400 font-sans mt-0.5 leading-relaxed">{{ env.desc }}</div>
              </div>
              <div class="flex items-center justify-between pt-2 border-t border-white/5 text-[10px]">
                <span class="text-neutral-500">{{ env.temp }}</span>
                <span class="text-cyan-400 font-bold">{{ env.key }}</span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Virtual Camera Rig & Sensor Format -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">camera</mat-icon>
            <span>KAMERAOBJEKTIV & BRENNWEITE</span>
          </div>

          <div class="grid grid-cols-2 gap-2">
            @for (lens of cameraLenses; track lens.mm) {
              <div class="p-3 rounded-lg bg-black/40 border border-white/10 space-y-1">
                <div class="font-bold text-cyan-300 text-sm">{{ lens.mm }}mm {{ lens.name }}</div>
                <div class="text-[10px] text-neutral-400 font-sans">{{ lens.use }}</div>
              </div>
            }
          </div>

          <div class="p-2.5 rounded bg-black/40 border border-white/5 text-[11px] text-neutral-400 font-sans">
            Sensor: Vollformat 36 × 24 mm mit ACES Filmic Tone Mapping und physikalisch basierten Shutter-Winkeln.
          </div>
        </div>

        <!-- Render Output Quality -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
            <mat-icon class="!w-4 !h-4 !text-base text-emerald-400">high_quality</mat-icon>
            <span>BILDQUALITÄT & POST-PROCESSING</span>
          </div>

          <div class="space-y-2.5">
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">Anti-Aliasing</div>
                <div class="text-[10px] text-neutral-500 font-sans">MSAA 4x Hardware + TAA Filter</div>
              </div>
              <span class="text-emerald-400 font-bold">Aktiv</span>
            </div>

            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">Shadow Map Auflösung</div>
                <div class="text-[10px] text-neutral-500 font-sans">PCF Soft Shadows</div>
              </div>
              <span class="text-cyan-400 font-bold">2048 × 2048 px</span>
            </div>

            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">Farbmanagement</div>
                <div class="text-[10px] text-neutral-500 font-sans">Academy Color Encoding System</div>
              </div>
              <span class="text-neutral-200 font-bold">ACEScg / sRGB</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class RenderingStudio {
  readonly state = inject(DesignStudioState);

  readonly studioRigs = [
    { id: 'studio', name: 'Sindelfingen Design Studio Rig', desc: 'Neutrale Drei-Punkt-Studiobeleuchtung für präzise Formbeurteilung.', temp: '5500 K', key: 'Softbox Key' },
    { id: 'daylight', name: 'Sonnenlicht & Freigelände', desc: 'Reales Außenlicht für Reflexionsverläufe auf Metallic- und Mattlacken.', temp: '6200 K', key: '100.000 Lux' },
    { id: 'night', name: 'Nacht & Urbane Lichtinszenierung', desc: 'Fokus auf Digitale Lichtsignaturen, OLED-Lichtband & Ambientelicht.', temp: '3200 K', key: 'Dunkelstudio' },
  ];

  readonly cameraLenses = [
    { mm: 24, name: 'Weitwinkel', use: 'Dramatische Hero-Shots & Innenraumübersicht' },
    { mm: 35, name: 'Standard Wide', use: 'Klassische Automobil-Studiofotografie' },
    { mm: 50, name: 'Normalbrennweite', use: 'Verzerrungsfreie Proportionen' },
    { mm: 85, name: 'Tele / Detail', use: 'Class-A Sicken, Felgen & Radhauskompression' },
  ];
}
