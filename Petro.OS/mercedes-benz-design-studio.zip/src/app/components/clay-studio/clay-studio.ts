import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-clay-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-amber-400">brush</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">DIGITALES CLAY-MODELLIERSTUDIO</h2>
            <div class="text-[11px] text-neutral-400 font-light">Industrielles Ton-Skulpting & Flächenverformung in Echtzeit</div>
          </div>
        </div>

        <button (click)="resetClay()"
          class="px-3 py-1.5 rounded-lg bg-rose-950/50 hover:bg-rose-900 border border-rose-500/30 text-rose-300 text-xs font-mono transition flex items-center space-x-1 cursor-pointer">
          <mat-icon class="!w-3.5 !h-3.5 !text-sm">restart_alt</mat-icon>
          <span>Clay zurücksetzen</span>
        </button>
      </div>

      <!-- Sculpting Mode Notification -->
      <div class="p-3 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs flex items-start space-x-2">
        <mat-icon class="text-amber-400 shrink-0">touch_app</mat-icon>
        <div>
          <div class="font-bold">Interaktives Clay-Werkzeug aktiv:</div>
          <div class="text-[11px] text-amber-200/80 leading-relaxed">
            Klicken Sie im 3D-Viewport direkt auf die Karosseriefläche, um Material aufzubauen, abzutragen oder Kanten zu schärfen. Halten Sie <span class="font-mono bg-black/40 px-1 py-0.5 rounded border border-white/10">Shift + Linksklick</span> gedrückt, um kontinuierlich zu modellieren.
          </div>
        </div>
      </div>

      <!-- Clay Sculpting Tools Palette -->
      <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3 font-mono text-xs">
        <div class="font-bold text-neutral-200 flex items-center justify-between">
          <span>MODELLIERWERKZEUGE</span>
          <span class="text-cyan-400 text-[11px]">{{ state.currentProject().clay.deformations.length }} Verformungen aktiv</span>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
          @for (tool of clayTools; track tool.id) {
            <button (click)="setTool(tool.id)"
              [class.bg-amber-500/20]="state.currentProject().clay.activeTool === tool.id"
              [class.text-amber-300]="state.currentProject().clay.activeTool === tool.id"
              [class.border-amber-500/50]="state.currentProject().clay.activeTool === tool.id"
              [class.bg-black/40]="state.currentProject().clay.activeTool !== tool.id"
              [class.text-neutral-300]="state.currentProject().clay.activeTool !== tool.id"
              class="p-3 rounded-lg border border-white/10 hover:border-amber-500/30 transition text-left flex flex-col justify-between space-y-2 cursor-pointer">
              <div class="flex items-center justify-between">
                <mat-icon class="!w-4 !h-4 !text-base text-amber-400">{{ tool.icon }}</mat-icon>
                @if (state.currentProject().clay.activeTool === tool.id) {
                  <span class="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                }
              </div>
              <div>
                <div class="font-bold">{{ tool.name }}</div>
                <div class="text-[10px] text-neutral-500 font-sans mt-0.5">{{ tool.desc }}</div>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Parameters (Radius, Intensity, Falloff, Symmetry) -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        <!-- Radius & Intensity -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">PINSELEIGENSCHAFTEN</div>

          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Pinselradius (Tool Radius)</span>
              <span class="text-amber-400 font-bold">{{ state.currentProject().clay.toolRadius }} mm</span>
            </div>
            <input type="range" min="30" max="300" step="5"
              [value]="state.currentProject().clay.toolRadius"
              (input)="updateClayParam('toolRadius', +$any($event.target).value)" class="w-full cursor-pointer" />
            <div class="flex justify-between text-[10px] text-neutral-500">
              <span>30 mm (Detail)</span>
              <span>150 mm (Fläche)</span>
              <span>300 mm (Groß)</span>
            </div>
          </div>

          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Intensität (Intensity)</span>
              <span class="text-amber-400 font-bold">{{ (state.currentProject().clay.toolIntensity * 100).toFixed(0) }}%</span>
            </div>
            <input type="range" min="0.05" max="1.0" step="0.05"
              [value]="state.currentProject().clay.toolIntensity"
              (input)="updateClayParam('toolIntensity', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>
        </div>

        <!-- Falloff & Symmetry -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">SYMMETRIE & PROFILE</div>

          <div class="flex items-center justify-between p-3 rounded-lg bg-black/40 border border-white/10">
            <div>
              <div class="font-bold text-neutral-200">Bilateral-Symmetrie (X-Achse)</div>
              <div class="text-[11px] text-neutral-500 font-sans">Spiegelt Änderungen simultan auf Fahrer-/Beifahrerseite</div>
            </div>
            <input type="checkbox"
              [checked]="state.currentProject().clay.symmetryX"
              (change)="updateClayParam('symmetryX', $any($event.target).checked)"
              class="w-4 h-4 rounded text-cyan-600 bg-neutral-900 border-white/20 cursor-pointer" />
          </div>

          <div class="space-y-1">
            <label class="block text-neutral-400">ÜBERGANGSKURVE (FALLOFF)</label>
            <div class="grid grid-cols-3 gap-2">
              @for (f of ['gaussian', 'linear', 'smoothstep']; track f) {
                <button (click)="updateClayParam('toolFalloff', f)"
                  [class.bg-amber-500/20]="state.currentProject().clay.toolFalloff === f"
                  [class.text-amber-300]="state.currentProject().clay.toolFalloff === f"
                  [class.border-amber-500/40]="state.currentProject().clay.toolFalloff === f"
                  class="py-2 rounded border border-white/10 text-center hover:bg-white/10 transition cursor-pointer capitalize">
                  {{ f }}
                </button>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ClayStudio {
  readonly state = inject(DesignStudioState);

  readonly clayTools: Array<{ id: any; name: string; icon: string; desc: string }> = [
    { id: 'build-up', name: 'Aufbauen', icon: 'add_circle', desc: 'Material & Volumen auftragen' },
    { id: 'carve', name: 'Abtragen', icon: 'remove_circle', desc: 'Material abschaben / Sicken' },
    { id: 'smooth', name: 'Glätten', icon: 'auto_fix_high', desc: 'Flächenübergänge verfeinern' },
    { id: 'pinch', name: 'Pinchen', icon: 'flare', desc: 'Scharfe Lichtkante erzeugen' },
    { id: 'pull', name: 'Ziehen', icon: 'north', desc: 'Kontrollpunkte nach außen heben' },
    { id: 'push', name: 'Drücken', icon: 'south', desc: 'Fläche nach innen senken' },
    { id: 'inflate', name: 'Inflate', icon: 'lens', desc: 'Konvexe Wölbung verstärken' },
    { id: 'relax', name: 'Relax', icon: 'waves', desc: 'Spannungsfreie Krümmung' },
  ];

  setTool(tool: any) {
    this.state.updateProject((p) => {
      p.clay.activeTool = tool;
    });
  }

  updateClayParam(key: string, val: any) {
    this.state.updateProject((p) => {
      (p.clay as any)[key] = val;
    });
  }

  resetClay() {
    this.state.updateProject((p) => {
      p.clay.deformations = [];
    });
  }
}
