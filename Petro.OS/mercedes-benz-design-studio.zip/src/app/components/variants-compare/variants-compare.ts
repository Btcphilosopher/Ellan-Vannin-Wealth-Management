import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';
import { VehicleVariant } from '../../core/models/vehicle.model';

@Component({
  selector: 'app-variants-compare',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <!-- Title & Actions -->
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">compare</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">VARIANTENMANAGEMENT & DESIGNVERGLEICH</h2>
            <div class="text-[11px] text-neutral-400 font-light">Proportions-, Aerodynamik- und Styling-Vergleich verschiedener Fahrzeugderivate</div>
          </div>
        </div>

        <button (click)="saveNewVariantPrompt()"
          class="px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-lg shadow-cyan-950/30 transition cursor-pointer">
          <mat-icon class="!w-3.5 !h-3.5 !text-sm">add</mat-icon>
          <span>Aktuellen Stand als Variante sichern</span>
        </button>
      </div>

      <!-- Variants Catalog Strip -->
      <div class="space-y-2">
        <div class="text-xs font-mono font-bold text-neutral-300">GESPEICHERTE DESIGNVARIANTEN</div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
          @for (v of state.currentProject().variants; track v.id) {
            <div class="p-3.5 rounded-xl border border-white/10 bg-[#12151d] space-y-3 flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between">
                  <span class="text-xs font-bold text-neutral-100 font-mono">{{ v.name }}</span>
                  <span class="text-[10px] px-1.5 py-0.5 rounded bg-white/10 font-mono text-cyan-400">{{ v.code }}</span>
                </div>
                <p class="text-[11px] text-neutral-400 mt-1 leading-relaxed">{{ v.description }}</p>
              </div>

              <div class="flex items-center space-x-2 pt-2 border-t border-white/5">
                <button (click)="state.applyVariant(v)"
                  class="flex-1 py-1.5 rounded-lg bg-neutral-800 hover:bg-cyan-600 text-neutral-200 hover:text-white text-xs font-semibold transition cursor-pointer">
                  Aktivieren
                </button>
                <button (click)="state.comparisonVariant.set(v)"
                  [class.bg-amber-600]="state.comparisonVariant()?.id === v.id"
                  [class.text-white]="state.comparisonVariant()?.id === v.id"
                  class="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs transition cursor-pointer"
                  title="Als Vergleichsmodell setzen">
                  Vergleichen
                </button>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Side-by-Side Comparison Table -->
      @if (state.comparisonVariant(); as comp) {
        <div class="rounded-xl border border-white/10 bg-[#11141c] p-4 space-y-3 font-mono text-xs">
          <div class="font-bold text-neutral-200 flex items-center justify-between">
            <span class="text-cyan-400">SPLIT-VERGLEICH: HAUPTMODELL VS. {{ comp.name }}</span>
            <button (click)="state.comparisonVariant.set(null)" class="text-neutral-500 hover:text-neutral-300 text-[11px]">
              Vergleich schließen
            </button>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
              <thead>
                <tr class="border-b border-white/10 text-neutral-400 text-[11px]">
                  <th class="py-2 px-3">PARAMETER</th>
                  <th class="py-2 px-3 text-cyan-300 font-bold">AKTUELLER STAND ({{ state.currentProject().name }})</th>
                  <th class="py-2 px-3 text-amber-300 font-bold">VERGLEICHS-DERIVAT ({{ comp.name }})</th>
                  <th class="py-2 px-3 text-neutral-400">DIFFERENZ (DELTA)</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-white/5 text-[11px]">
                <tr>
                  <td class="py-2 px-3 text-neutral-400">Gesamtlänge</td>
                  <td class="py-2 px-3 font-bold">{{ state.currentProject().dimensions.length }} mm</td>
                  <td class="py-2 px-3 font-bold">{{ comp.dimensions.length }} mm</td>
                  <td class="py-2 px-3" [class.text-emerald-400]="comp.dimensions.length > state.currentProject().dimensions.length">
                    {{ comp.dimensions.length - state.currentProject().dimensions.length }} mm
                  </td>
                </tr>
                <tr>
                  <td class="py-2 px-3 text-neutral-400">Radstand</td>
                  <td class="py-2 px-3 font-bold">{{ state.currentProject().dimensions.wheelbase }} mm</td>
                  <td class="py-2 px-3 font-bold">{{ comp.dimensions.wheelbase }} mm</td>
                  <td class="py-2 px-3">
                    {{ comp.dimensions.wheelbase - state.currentProject().dimensions.wheelbase }} mm
                  </td>
                </tr>
                <tr>
                  <td class="py-2 px-3 text-neutral-400">Gesamthöhe</td>
                  <td class="py-2 px-3 font-bold">{{ state.currentProject().dimensions.height }} mm</td>
                  <td class="py-2 px-3 font-bold">{{ comp.dimensions.height }} mm</td>
                  <td class="py-2 px-3">
                    {{ comp.dimensions.height - state.currentProject().dimensions.height }} mm
                  </td>
                </tr>
                <tr>
                  <td class="py-2 px-3 text-neutral-400">cW-Wert (Luftwiderstand)</td>
                  <td class="py-2 px-3 font-bold text-emerald-400">{{ state.effectiveCw() }}</td>
                  <td class="py-2 px-3 font-bold text-amber-400">{{ comp.aerodynamics.cw }}</td>
                  <td class="py-2 px-3">
                    {{ (comp.aerodynamics.cw - state.effectiveCw()).toFixed(3) }}
                  </td>
                </tr>
                <tr>
                  <td class="py-2 px-3 text-neutral-400">Rädergröße</td>
                  <td class="py-2 px-3 font-bold">{{ state.currentProject().wheels.diameterInches }}" {{ state.currentProject().wheels.rimStyle }}</td>
                  <td class="py-2 px-3 font-bold">{{ comp.wheels.diameterInches }}" {{ comp.wheels.rimStyle }}</td>
                  <td class="py-2 px-3 text-neutral-500">—</td>
                </tr>
                <tr>
                  <td class="py-2 px-3 text-neutral-400">Lackierung</td>
                  <td class="py-2 px-3 font-bold">{{ state.currentProject().materials.paintName }}</td>
                  <td class="py-2 px-3 font-bold">{{ comp.materials.paintName }}</td>
                  <td class="py-2 px-3 text-neutral-500">—</td>
                </tr>
                <tr>
                  <td class="py-2 px-3 text-neutral-400">Kühlergrill</td>
                  <td class="py-2 px-3 font-bold">{{ state.currentProject().exterior.grilleStyle }}</td>
                  <td class="py-2 px-3 font-bold">{{ comp.exterior.grilleStyle }}</td>
                  <td class="py-2 px-3 text-neutral-500">—</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `,
})
export class VariantsCompare {
  readonly state = inject(DesignStudioState);

  saveNewVariantPrompt() {
    const name = prompt('Name der neuen Designvariante eingeben:', `Variante ${this.state.currentProject().variants.length + 1}`);
    if (name) {
      this.state.saveCurrentAsVariant(name, 'Benutzerdefinierte Designvariante');
    }
  }
}
