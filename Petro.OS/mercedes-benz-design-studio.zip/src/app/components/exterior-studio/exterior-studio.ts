import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-exterior-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">directions_car</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">EXTERIEURDESIGN & ANBAUTEILE</h2>
            <div class="text-[11px] text-neutral-400 font-light">Frontmaske, Aerodynamik-Elemente, Spiegel, Verglasung & Heckabschluss</div>
          </div>
        </div>
      </div>

      <!-- Grille & Front Mask Architecture -->
      <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3 font-mono text-xs">
        <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
          <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">grid_view</mat-icon>
          <span>KÜHLERMASKE & FRONTARCHITEKTUR</span>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-5 gap-2">
          @for (g of grilleStyles; track g.id) {
            <button (click)="updateExt('grilleStyle', g.id)"
              [class.bg-cyan-500/20]="state.currentProject().exterior.grilleStyle === g.id"
              [class.text-cyan-300]="state.currentProject().exterior.grilleStyle === g.id"
              [class.border-cyan-500/50]="state.currentProject().exterior.grilleStyle === g.id"
              [class.bg-black/40]="state.currentProject().exterior.grilleStyle !== g.id"
              [class.text-neutral-400]="state.currentProject().exterior.grilleStyle !== g.id"
              class="p-3 rounded-lg border border-white/10 hover:border-cyan-500/30 transition text-left flex flex-col justify-between space-y-2 cursor-pointer">
              <div class="font-bold text-neutral-200">{{ g.name }}</div>
              <div class="text-[10px] text-neutral-500 font-sans">{{ g.desc }}</div>
            </button>
          }
        </div>
      </div>

      <!-- Exterior Components Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        
        <!-- Mirrors & Handles -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">SPIEGEL & TÜRFLÄCHEN</div>

          <!-- Mirror Style -->
          <div class="space-y-1">
            <label class="block text-neutral-400">AUSSENSPIEGEL-KONZEPT</label>
            <div class="grid grid-cols-2 gap-2">
              <button (click)="updateExt('mirrorStyle', 'digital-camera-aerowings')"
                [class.bg-cyan-500/20]="state.currentProject().exterior.mirrorStyle === 'digital-camera-aerowings'"
                [class.text-cyan-300]="state.currentProject().exterior.mirrorStyle === 'digital-camera-aerowings'"
                class="p-2.5 rounded border border-white/10 hover:bg-white/10 transition text-left">
                <div class="font-bold">Digitale Kameraflügel</div>
                <div class="text-[10px] text-neutral-500 font-sans mt-0.5">-0.006 cW Reduktion</div>
              </button>

              <button (click)="updateExt('mirrorStyle', 'sculptural-mirrors')"
                [class.bg-cyan-500/20]="state.currentProject().exterior.mirrorStyle === 'sculptural-mirrors'"
                [class.text-cyan-300]="state.currentProject().exterior.mirrorStyle === 'sculptural-mirrors'"
                class="p-2.5 rounded border border-white/10 hover:bg-white/10 transition text-left">
                <div class="font-bold">Skulpturale Spiegel</div>
                <div class="text-[10px] text-neutral-500 font-sans mt-0.5">Klassischer Strak</div>
              </button>
            </div>
          </div>

          <!-- Door Handles -->
          <div class="space-y-1">
            <label class="block text-neutral-400">TÜRGRIFF-INTEGRATION</label>
            <div class="grid grid-cols-3 gap-2">
              @for (h of handleStyles; track h.id) {
                <button (click)="updateExt('doorHandles', h.id)"
                  [class.bg-cyan-500/20]="state.currentProject().exterior.doorHandles === h.id"
                  [class.text-cyan-300]="state.currentProject().exterior.doorHandles === h.id"
                  class="p-2 rounded border border-white/10 hover:bg-white/10 transition text-center">
                  {{ h.name }}
                </button>
              }
            </div>
          </div>

          <!-- Powerdomes -->
          <div class="flex items-center justify-between p-3 rounded-lg bg-black/40 border border-white/10">
            <div>
              <div class="font-bold text-neutral-200">Powerdomes auf Motorhaube</div>
              <div class="text-[11px] text-neutral-500 font-sans">Längswölbungen für muskulöse Fronterscheinung</div>
            </div>
            <input type="checkbox"
              [checked]="state.currentProject().exterior.hoodPowerdomes"
              (change)="updateExt('hoodPowerdomes', $any($event.target).checked)"
              class="w-4 h-4 rounded text-cyan-600 bg-neutral-900 border-white/20 cursor-pointer" />
          </div>
        </div>

        <!-- Aero, Spoilers & Diffuser -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">HECKABSCHLUSS & DIFFUSOR</div>

          <!-- Rear Spoiler -->
          <div class="space-y-1">
            <label class="block text-neutral-400">HECKSPOILER-ARCHITEKTUR</label>
            <div class="grid grid-cols-3 gap-2">
              @for (sp of spoilerStyles; track sp.id) {
                <button (click)="updateExt('rearSpoiler', sp.id)"
                  [class.bg-cyan-500/20]="state.currentProject().exterior.rearSpoiler === sp.id"
                  [class.text-cyan-300]="state.currentProject().exterior.rearSpoiler === sp.id"
                  class="p-2 rounded border border-white/10 hover:bg-white/10 transition text-center text-[11px]">
                  {{ sp.name }}
                </button>
              }
            </div>
          </div>

          <!-- Glass Roof -->
          <div class="space-y-1">
            <label class="block text-neutral-400">DACHKONZEPT</label>
            <div class="grid grid-cols-3 gap-2">
              @for (r of roofTypes; track r.id) {
                <button (click)="updateExt('glassRoofType', r.id)"
                  [class.bg-cyan-500/20]="state.currentProject().exterior.glassRoofType === r.id"
                  [class.text-cyan-300]="state.currentProject().exterior.glassRoofType === r.id"
                  class="p-2 rounded border border-white/10 hover:bg-white/10 transition text-center text-[11px]">
                  {{ r.name }}
                </button>
              }
            </div>
          </div>

          <!-- Carbon Splitter & Diffuser Fins -->
          <div class="space-y-3 pt-2">
            <div class="flex items-center justify-between p-3 rounded-lg bg-black/40 border border-white/10">
              <div>
                <div class="font-bold text-neutral-200">Carbon Frontsplitter</div>
                <div class="text-[11px] text-neutral-500 font-sans">Erhöht Vorderachs-Abtrieb um +15 kg</div>
              </div>
              <input type="checkbox"
                [checked]="state.currentProject().exterior.frontSplitterCarbon"
                (change)="updateExt('frontSplitterCarbon', $any($event.target).checked)"
                class="w-4 h-4 rounded text-cyan-600 bg-neutral-900 border-white/20 cursor-pointer" />
            </div>

            <div class="flex items-center justify-between p-3 rounded-lg bg-black/40 border border-white/10">
              <div>
                <div class="font-bold text-neutral-200">Heckdiffusor Finnenanzahl</div>
                <div class="text-[11px] text-neutral-500 font-sans">Unterbodenströmung-Entwirbelung</div>
              </div>
              <div class="flex space-x-1">
                @for (fins of [2, 4, 6]; track fins) {
                  <button (click)="updateExt('rearDiffuserFins', fins)"
                    [class.bg-cyan-500/20]="state.currentProject().exterior.rearDiffuserFins === fins"
                    [class.text-cyan-300]="state.currentProject().exterior.rearDiffuserFins === fins"
                    class="px-2.5 py-1 rounded border border-white/10 font-bold">
                    {{ fins }}
                  </button>
                }
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  `,
})
export class ExteriorStudio {
  readonly state = inject(DesignStudioState);

  readonly grilleStyles = [
    { id: 'eq-blackpanel-star', name: 'EQ Black Panel', desc: 'Nahtloses Glas mit Sternenmuster' },
    { id: 'panamericana', name: 'AMG Panamericana', desc: 'Vertikale Chromstreben' },
    { id: 'maybach-pinstripe', name: 'Maybach Pinstripe', desc: 'Feine vertikale Nadelstreifen' },
    { id: 'avantgarde-slat', name: 'Avantgarde Lamelle', desc: 'Klassische Doppellamellen' },
    { id: 'aero-flush', name: 'Aero Flush Minimal', desc: 'Vollständig geschlossene Haube' },
  ];

  readonly handleStyles = [
    { id: 'flush-retractable', name: 'Versenkbar' },
    { id: 'aerodynamic-recess', name: 'Griffmulde' },
    { id: 'sensor-touch', name: 'Sensor-Touch' },
  ];

  readonly spoilerStyles = [
    { id: 'active-integrated-wing', name: 'Aktiv Ausfahrbar' },
    { id: 'ducktail-lip', name: 'Ducktail Abriss' },
    { id: 'aero-diffuser-flush', name: 'Bündig Diffusor' },
  ];

  readonly roofTypes = [
    { id: 'panoramic-electrochromic', name: 'Elektrochrom Glas' },
    { id: 'split-glass', name: 'Geteiltes Glas' },
    { id: 'solid-lightweight-carbon', name: 'Carbon Dach' },
  ];

  updateExt(key: string, val: any) {
    this.state.updateProject((p) => {
      (p.exterior as any)[key] = val;
    });
  }
}
