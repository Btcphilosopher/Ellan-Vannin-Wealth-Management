import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnInit,
  PLATFORM_ID,
  ViewChild,
  inject,
  signal,
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

export type SketchTool = 'pencil' | 'marker' | 'airbrush' | 'tech-line' | 'eraser';

@Component({
  selector: 'app-sketch-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0a0c10] text-neutral-100 overflow-hidden font-sans p-3 space-y-3 select-none">
      <!-- Top Toolbar -->
      <div class="flex items-center justify-between bg-[#12151d] border border-white/10 p-2 rounded-xl text-xs font-mono">
        <!-- Tools Palette -->
        <div class="flex items-center space-x-1">
          <button (click)="setTool('pencil')" [class.bg-cyan-500/20]="activeTool() === 'pencil'" [class.text-cyan-300]="activeTool() === 'pencil'"
            class="px-2.5 py-1.5 rounded hover:bg-white/10 text-neutral-300 flex items-center space-x-1.5 transition">
            <mat-icon class="!w-4 !h-4 !text-base">edit</mat-icon>
            <span>Bleistift</span>
          </button>

          <button (click)="setTool('marker')" [class.bg-cyan-500/20]="activeTool() === 'marker'" [class.text-cyan-300]="activeTool() === 'marker'"
            class="px-2.5 py-1.5 rounded hover:bg-white/10 text-neutral-300 flex items-center space-x-1.5 transition">
            <mat-icon class="!w-4 !h-4 !text-base">brush</mat-icon>
            <span>Design-Marker</span>
          </button>

          <button (click)="setTool('airbrush')" [class.bg-cyan-500/20]="activeTool() === 'airbrush'" [class.text-cyan-300]="activeTool() === 'airbrush'"
            class="px-2.5 py-1.5 rounded hover:bg-white/10 text-neutral-300 flex items-center space-x-1.5 transition">
            <mat-icon class="!w-4 !h-4 !text-base">air</mat-icon>
            <span>Airbrush</span>
          </button>

          <button (click)="setTool('tech-line')" [class.bg-cyan-500/20]="activeTool() === 'tech-line'" [class.text-cyan-300]="activeTool() === 'tech-line'"
            class="px-2.5 py-1.5 rounded hover:bg-white/10 text-neutral-300 flex items-center space-x-1.5 transition">
            <mat-icon class="!w-4 !h-4 !text-base">timeline</mat-icon>
            <span>Techn. Linie</span>
          </button>

          <button (click)="setTool('eraser')" [class.bg-cyan-500/20]="activeTool() === 'eraser'" [class.text-cyan-300]="activeTool() === 'eraser'"
            class="px-2.5 py-1.5 rounded hover:bg-white/10 text-neutral-300 flex items-center space-x-1.5 transition">
            <mat-icon class="!w-4 !h-4 !text-base">auto_fix_normal</mat-icon>
            <span>Radierer</span>
          </button>
        </div>

        <!-- Tool Modifiers (Size, Opacity) -->
        <div class="flex items-center space-x-4">
          <div class="flex items-center space-x-2">
            <span class="text-neutral-400">Größe:</span>
            <input type="range" min="1" max="40" [value]="brushSize()" (input)="brushSize.set(+$any($event.target).value)" class="w-20 cursor-pointer" />
            <span class="text-cyan-400 w-6">{{ brushSize() }}px</span>
          </div>

          <div class="flex items-center space-x-2">
            <span class="text-neutral-400">Deckkraft:</span>
            <input type="range" min="0.1" max="1.0" step="0.05" [value]="brushOpacity()" (input)="brushOpacity.set(+$any($event.target).value)" class="w-20 cursor-pointer" />
            <span class="text-cyan-400 w-8">{{ (brushOpacity() * 100).toFixed(0) }}%</span>
          </div>

          <!-- Symmetry Mirror Toggle -->
          <button (click)="symmetry.set(!symmetry())" [class.bg-cyan-500/20]="symmetry()" [class.text-cyan-300]="symmetry()"
            class="px-2.5 py-1.5 rounded hover:bg-white/10 border border-white/10 text-neutral-300 flex items-center space-x-1">
            <mat-icon class="!w-4 !h-4 !text-base">flip</mat-icon>
            <span>Spiegelachse</span>
          </button>

          <!-- Clear Canvas -->
          <button (click)="clearCanvas()" class="px-2.5 py-1.5 rounded hover:bg-rose-950/40 text-rose-400 border border-rose-500/30 transition">
            Leeren
          </button>
        </div>
      </div>

      <!-- Canvas Area + Colors Sidebar -->
      <div class="flex-1 flex gap-3 min-h-0">
        <!-- Main Canvas -->
        <div class="flex-1 relative rounded-xl border border-white/10 bg-[#07080b] cad-grid overflow-hidden flex items-center justify-center">
          <canvas #sketchCanvas
            class="w-full h-full cursor-crosshair touch-none"
            (pointerdown)="startDrawing($event)"
            (pointermove)="draw($event)"
            (pointerup)="stopDrawing()"
            (pointerleave)="stopDrawing()">
          </canvas>

          <!-- Center Symmetry Guide Line -->
          @if (symmetry()) {
            <div class="absolute inset-y-0 left-1/2 w-px bg-cyan-400/40 border-r border-dashed border-cyan-400 pointer-events-none"></div>
          }
        </div>

        <!-- Automotive Color Palette Sidebar -->
        <div class="w-48 bg-[#11141c] border border-white/10 rounded-xl p-3 flex flex-col justify-between text-xs font-mono space-y-4 shrink-0">
          <div class="space-y-3">
            <div class="font-bold text-neutral-300">FARBPALETTE</div>
            <div class="grid grid-cols-4 gap-2">
              @for (c of palette; track c) {
                <button (click)="brushColor.set(c)"
                  [style.background-color]="c"
                  [class.ring-2]="brushColor() === c"
                  [class.ring-cyan-400]="brushColor() === c"
                  class="w-8 h-8 rounded-lg border border-white/20 hover:scale-105 transition cursor-pointer shadow-sm">
                </button>
              }
            </div>

            <!-- Custom Color Picker -->
            <div class="pt-2 border-t border-white/10">
              <label class="block text-[11px] text-neutral-400 mb-1">EIGENER FARBTON</label>
              <input type="color" [value]="brushColor()" (input)="brushColor.set($any($event.target).value)"
                class="w-full h-8 rounded bg-transparent border border-white/10 cursor-pointer" />
            </div>
          </div>

          <!-- Project onto 3D Blueprint Plane Button -->
          <div class="space-y-2 pt-2 border-t border-white/10">
            <div class="text-[10px] text-neutral-500">PROJEKTION</div>
            <button (click)="saveSketchTo3DBlueprint()"
              class="w-full py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs flex items-center justify-center space-x-1 shadow-lg shadow-cyan-950/40 transition cursor-pointer">
              <mat-icon class="!w-4 !h-4 !text-base">view_in_ar</mat-icon>
              <span>Auf 3D-Ebene</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class SketchStudio implements OnInit {
  @ViewChild('sketchCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;

  readonly state = inject(DesignStudioState);
  private readonly platformId = inject(PLATFORM_ID);
  readonly isBrowser = isPlatformBrowser(this.platformId);

  readonly activeTool = signal<SketchTool>('pencil');
  readonly brushSize = signal<number>(4);
  readonly brushOpacity = signal<number>(0.9);
  readonly brushColor = signal<string>('#00d2ff');
  readonly symmetry = signal<boolean>(false);

  readonly palette = [
    '#00d2ff', '#ffffff', '#0a0a0c', '#333b47',
    '#e60028', '#f5a623', '#27ae60', '#9e6a4b',
    '#8e44ad', '#3498db', '#f1c40f', '#bdc3c7'
  ];

  private ctx?: CanvasRenderingContext2D;
  private isDrawing = false;
  private lastX = 0;
  private lastY = 0;

  ngOnInit() {
    if (this.isBrowser) {
      this.initCanvas();
    }
  }

  private initCanvas() {
    const canvas = this.canvasRef.nativeElement;
    canvas.width = canvas.parentElement?.clientWidth || 1000;
    canvas.height = canvas.parentElement?.clientHeight || 650;
    this.ctx = canvas.getContext('2d')!;
    this.ctx.lineCap = 'round';
    this.ctx.lineJoin = 'round';
  }

  setTool(tool: SketchTool) {
    this.activeTool.set(tool);
    if (tool === 'marker') {
      this.brushSize.set(16);
      this.brushOpacity.set(0.35);
    } else if (tool === 'pencil') {
      this.brushSize.set(3);
      this.brushOpacity.set(0.85);
    } else if (tool === 'airbrush') {
      this.brushSize.set(28);
      this.brushOpacity.set(0.15);
    }
  }

  startDrawing(e: PointerEvent) {
    this.isDrawing = true;
    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    this.lastX = e.clientX - rect.left;
    this.lastY = e.clientY - rect.top;
  }

  draw(e: PointerEvent) {
    if (!this.isDrawing || !this.ctx) return;

    const rect = this.canvasRef.nativeElement.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    this.ctx.save();
    if (this.activeTool() === 'eraser') {
      this.ctx.globalCompositeOperation = 'destination-out';
      this.ctx.lineWidth = this.brushSize() * 2;
    } else {
      this.ctx.globalCompositeOperation = 'source-over';
      this.ctx.strokeStyle = this.brushColor();
      this.ctx.fillStyle = this.brushColor();
      this.ctx.globalAlpha = this.brushOpacity();
      this.ctx.lineWidth = this.brushSize();
    }

    // Primary stroke
    this.ctx.beginPath();
    this.ctx.moveTo(this.lastX, this.lastY);
    this.ctx.lineTo(x, y);
    this.ctx.stroke();

    // Symmetry mirror stroke across canvas horizontal center
    if (this.symmetry()) {
      const centerX = this.canvasRef.nativeElement.width / 2;
      const mirrorLastX = centerX - (this.lastX - centerX);
      const mirrorX = centerX - (x - centerX);

      this.ctx.beginPath();
      this.ctx.moveTo(mirrorLastX, this.lastY);
      this.ctx.lineTo(mirrorX, y);
      this.ctx.stroke();
    }

    this.ctx.restore();

    this.lastX = x;
    this.lastY = y;
  }

  stopDrawing() {
    this.isDrawing = false;
  }

  clearCanvas() {
    if (!this.ctx) return;
    this.ctx.clearRect(0, 0, this.canvasRef.nativeElement.width, this.canvasRef.nativeElement.height);
  }

  saveSketchTo3DBlueprint() {
    const dataUrl = this.canvasRef.nativeElement.toDataURL('image/png');
    this.state.updateProject((p) => {
      p.sketchLayers['side'] = dataUrl;
    });
    this.state.setWorkspace('karosserie3d');
  }
}
