import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-surface-analysis',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-blue-400">view_stream</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">CLASS-A FLÄCHENDESIGN & STRAKANALYSE</h2>
            <div class="text-[11px] text-neutral-400 font-light">Krümmungsanalyse, G0/G1/G2 Kontinuität und Zebra-Reflektionsstreifen</div>
          </div>
        </div>

        <!-- Class-A Certification Stamp -->
        <div class="px-3 py-1 rounded bg-blue-950/80 border border-blue-500/40 text-blue-300 text-xs font-mono flex items-center space-x-1.5">
          <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">verified</mat-icon>
          <span>CLASS-A AUTOMOTIVE STRAK-GÜTE: 98.6%</span>
        </div>
      </div>

      <!-- Mode Selector -->
      <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3 font-mono text-xs">
        <div class="font-bold text-neutral-200">ANALYSE-MODUS IM 3D VIEWPORT</div>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
          @for (m of analysisModes; track m.id) {
            <button (click)="setMode(m.id)"
              [class.bg-blue-500/20]="state.currentProject().surfaceAnalysis.mode === m.id"
              [class.text-blue-300]="state.currentProject().surfaceAnalysis.mode === m.id"
              [class.border-blue-500/50]="state.currentProject().surfaceAnalysis.mode === m.id"
              [class.bg-black/40]="state.currentProject().surfaceAnalysis.mode !== m.id"
              [class.text-neutral-400]="state.currentProject().surfaceAnalysis.mode !== m.id"
              class="p-3 rounded-lg border border-white/10 hover:border-blue-500/30 transition text-left flex flex-col justify-between space-y-1.5 cursor-pointer">
              <div class="flex items-center justify-between">
                <mat-icon class="!w-4 !h-4 !text-base text-blue-400">{{ m.icon }}</mat-icon>
                @if (state.currentProject().surfaceAnalysis.mode === m.id) {
                  <span class="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
                }
              </div>
              <div class="font-bold text-neutral-200">{{ m.name }}</div>
              <div class="text-[10px] text-neutral-500 font-sans">{{ m.desc }}</div>
            </button>
          }
        </div>
      </div>

      <!-- Zebra Shader Parameters -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">tune</mat-icon>
            <span>ZEBRA-STREIFEN PARAMETER</span>
          </div>

          <!-- Zebra Frequency -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Streifen-Frequenz (Frequency)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().surfaceAnalysis.zebraFrequency }}</span>
            </div>
            <input type="range" min="4" max="36" step="1"
              [value]="state.currentProject().surfaceAnalysis.zebraFrequency"
              (input)="updateParam('zebraFrequency', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>

          <!-- Zebra Angle -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Projektionswinkel (Angle)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().surfaceAnalysis.zebraAngle }}°</span>
            </div>
            <input type="range" min="0" max="180" step="5"
              [value]="state.currentProject().surfaceAnalysis.zebraAngle"
              (input)="updateParam('zebraAngle', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>

          <!-- Zebra Sharpness -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Kantenkontrast (Sharpness)</span>
              <span class="text-cyan-400 font-bold">{{ (state.currentProject().surfaceAnalysis.zebraSharpness * 100).toFixed(0) }}%</span>
            </div>
            <input type="range" min="0.1" max="0.95" step="0.05"
              [value]="state.currentProject().surfaceAnalysis.zebraSharpness"
              (input)="updateParam('zebraSharpness', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>
        </div>

        <!-- Continuity Inspector Metrics -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
            <mat-icon class="!w-4 !h-4 !text-base text-emerald-400">check_circle_outline</mat-icon>
            <span>KONTINUITÄTSPROTOKOLL (G0 / G1 / G2 / G3)</span>
          </div>

          <div class="space-y-2.5">
            <!-- G0 -->
            <div class="p-2.5 rounded-lg bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">G0 — Punktstetigkeit (Position)</div>
                <div class="text-[10px] text-neutral-500 font-sans">Nahtloser Fugenabstand &lt; 0.01 mm</div>
              </div>
              <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30 text-[11px] font-bold">100% PASS</span>
            </div>

            <!-- G1 -->
            <div class="p-2.5 rounded-lg bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">G1 — Tangentialität (Tangency)</div>
                <div class="text-[10px] text-neutral-500 font-sans">Keine Kantenknicke, Winkelabweichung &lt; 0.05°</div>
              </div>
              <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30 text-[11px] font-bold">99.8% PASS</span>
            </div>

            <!-- G2 -->
            <div class="p-2.5 rounded-lg bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">G2 — Krümmungsstetigkeit (Curvature)</div>
                <div class="text-[10px] text-neutral-500 font-sans">Fließender Reflexionsstrak über Schulterlinie</div>
              </div>
              <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-500/30 text-[11px] font-bold">98.6% PASS</span>
            </div>

            <!-- G3 -->
            <div class="p-2.5 rounded-lg bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">G3 — Torsionsstetigkeit (Acceleration)</div>
                <div class="text-[10px] text-neutral-500 font-sans">Harmonische Krümmungsänderung dK/ds</div>
              </div>
              <span class="px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-500/30 text-[11px] font-bold">96.2% PASS</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class SurfaceAnalysis {
  readonly state = inject(DesignStudioState);

  readonly analysisModes = [
    { id: 'standard-pbr', name: 'Standard PBR Lack', icon: 'palette', desc: 'Fotorealistisches Rendering' },
    { id: 'zebra-stripes', name: 'Zebra-Streifen', icon: 'view_stream', desc: 'Reflektionsstrak-Linien' },
    { id: 'curvature-gauss', name: 'Gauss-Krümmung', icon: 'gradient', desc: 'Flächenwölbungs-Heatmap' },
    { id: 'highlight-lines', name: 'Highlight-Linien', icon: 'flare', desc: 'Lichtkanten-Verlauf' },
  ];

  setMode(mode: any) {
    this.state.updateProject((p) => {
      p.surfaceAnalysis.mode = mode;
    });
  }

  updateParam(key: string, val: any) {
    this.state.updateProject((p) => {
      (p.surfaceAnalysis as any)[key] = val;
    });
  }
}
