import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  ViewChild,
  effect,
  inject,
  signal,
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { DesignStudioState } from '../../core/services/design-studio-state';
import {
  VehicleSceneBuild,
  buildVehicleScene,
  applyClayDeformationsToGeometry,
} from '../../core/geometry/vehicle-geometry-generator';

export type LightingEnv = 'Studio' | 'Tageslicht' | 'Nacht' | 'Showroom' | 'Tunnel';
export type CameraPreset = 'hero-front' | 'hero-side' | 'rear-34' | 'top' | 'front' | 'interior' | 'aero';

@Component({
  selector: 'app-viewport-3d',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-[#08090c] overflow-hidden select-none flex flex-col">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="relative w-full flex-1 h-full cursor-grab active:cursor-grabbing"
        (pointerdown)="onPointerDown($event)"
        (pointermove)="onPointerMove($event)"
        (pointerup)="onPointerUp($event)"
        (wheel)="onWheel($event)">
        <canvas #webglCanvas class="w-full h-full block"></canvas>
      </div>

      <!-- Viewport Floating Overlays & Controls -->
      <!-- Top Left: Studio Status HUD & Active Mode -->
      <div class="absolute top-3 left-3 flex items-center space-x-2 pointer-events-none">
        <div class="px-2.5 py-1 rounded bg-neutral-900/90 border border-white/10 backdrop-blur-md flex items-center space-x-2 text-xs">
          <div class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
          <span class="font-mono text-neutral-200 tracking-wider">3D ENGINE // WEBGL2</span>
          <span class="text-neutral-500">|</span>
          <span class="text-cyan-400 font-mono">{{ state.currentProject().codeName }}</span>
        </div>
        
        @if (state.activeWorkspace() === 'clay') {
          <div class="px-2.5 py-1 rounded bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono flex items-center space-x-1.5 pointer-events-auto">
            <mat-icon class="!w-4 !h-4 !text-base">brush</mat-icon>
            <span>DIGITAL CLAY MODUS (Klicken & Ziehen zum Modellieren)</span>
          </div>
        }

        @if (state.currentProject().surfaceAnalysis.mode === 'zebra-stripes') {
          <div class="px-2.5 py-1 rounded bg-blue-500/20 border border-blue-500/40 text-blue-300 text-xs font-mono flex items-center space-x-1.5 pointer-events-auto">
            <mat-icon class="!w-4 !h-4 !text-base">view_stream</mat-icon>
            <span>CLASS-A ZEBRA REFLEKTIONSSTRAK</span>
          </div>
        }
      </div>

      <!-- Top Right: Camera Presets & Environment Rig -->
      <div class="absolute top-3 right-3 flex items-center space-x-1.5 bg-neutral-900/90 border border-white/10 backdrop-blur-md p-1 rounded-lg text-xs">
        <button (click)="setCameraPreset('hero-front')" title="Hero Front 3/4"
          class="px-2 py-1 rounded hover:bg-white/10 text-neutral-300 hover:text-white transition flex items-center space-x-1">
          <mat-icon class="!w-3.5 !h-3.5 !text-sm">photo_camera</mat-icon>
          <span>Hero 3/4</span>
        </button>
        <button (click)="setCameraPreset('hero-side')" title="Seitenansicht"
          class="px-2 py-1 rounded hover:bg-white/10 text-neutral-300 hover:text-white transition">
          Seite
        </button>
        <button (click)="setCameraPreset('front')" title="Frontansicht"
          class="px-2 py-1 rounded hover:bg-white/10 text-neutral-300 hover:text-white transition">
          Front
        </button>
        <button (click)="setCameraPreset('rear-34')" title="Heck 3/4"
          class="px-2 py-1 rounded hover:bg-white/10 text-neutral-300 hover:text-white transition">
          Heck
        </button>
        <button (click)="setCameraPreset('top')" title="Draufsicht"
          class="px-2 py-1 rounded hover:bg-white/10 text-neutral-300 hover:text-white transition">
          Draufsicht
        </button>
        <button (click)="setCameraPreset('interior')" title="Innenraum"
          class="px-2 py-1 rounded hover:bg-white/10 text-neutral-300 hover:text-white transition">
          Interieur
        </button>

        <div class="h-4 w-px bg-white/10 my-auto"></div>

        <!-- Turntable 360 -->
        <button (click)="toggleTurntable()" [class.text-cyan-400]="isTurntableActive()" [class.bg-cyan-500/20]="isTurntableActive()"
          class="p-1 rounded hover:bg-white/10 text-neutral-300 transition" title="Drehbühne 360°">
          <mat-icon class="!w-4 !h-4 !text-base">360</mat-icon>
        </button>
      </div>

      <!-- Bottom Bar: Lighting Environment & Focal Length -->
      <div class="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <!-- Left: Lighting Environment Selector -->
        <div class="bg-neutral-900/90 border border-white/10 backdrop-blur-md p-1 rounded-lg flex items-center space-x-1 pointer-events-auto text-xs">
          <span class="text-neutral-400 px-2 font-mono">Licht:</span>
          @for (env of environments; track env) {
            <button (click)="setEnvironment(env)"
              [class.bg-white/15]="activeEnv() === env"
              [class.text-white]="activeEnv() === env"
              [class.text-neutral-400]="activeEnv() !== env"
              class="px-2 py-1 rounded hover:bg-white/10 hover:text-neutral-200 transition">
              {{ env }}
            </button>
          }
        </div>

        <!-- Center: Quick Metric Pill -->
        <div class="bg-neutral-900/90 border border-white/10 backdrop-blur-md px-3 py-1 rounded-lg flex items-center space-x-3 pointer-events-auto text-xs font-mono">
          <div>
            <span class="text-neutral-400">cW: </span>
            <span class="text-emerald-400 font-bold">{{ state.effectiveCw() }}</span>
          </div>
          <span class="text-neutral-600">|</span>
          <div>
            <span class="text-neutral-400">A: </span>
            <span class="text-neutral-200">{{ state.effectiveFrontalArea() }} m²</span>
          </div>
          <span class="text-neutral-600">|</span>
          <div>
            <span class="text-neutral-400">cW×A: </span>
            <span class="text-cyan-400">{{ state.effectiveCwA() }} m²</span>
          </div>
        </div>

        <!-- Right: Camera Focal Length & Snapshot -->
        <div class="bg-neutral-900/90 border border-white/10 backdrop-blur-md p-1 rounded-lg flex items-center space-x-1 pointer-events-auto text-xs">
          <span class="text-neutral-400 px-2 font-mono">Brennweite:</span>
          @for (fl of [24, 35, 50, 85]; track fl) {
            <button (click)="setFocalLength(fl)"
              [class.bg-cyan-500/20]="focalLength() === fl"
              [class.text-cyan-400]="focalLength() === fl"
              [class.text-neutral-400]="focalLength() !== fl"
              class="px-2 py-1 rounded hover:bg-white/10 transition">
              {{ fl }}mm
            </button>
          }

          <div class="h-4 w-px bg-white/10 my-auto"></div>

          <button (click)="captureScreenshot()" title="4K Snapshot rendern"
            class="px-2 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-medium transition flex items-center space-x-1">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm">camera</mat-icon>
            <span>Render</span>
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      width: 100%;
      height: 100%;
    }
  `],
})
export class Viewport3d implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;
  @ViewChild('webglCanvas', { static: true }) webglCanvas!: ElementRef<HTMLCanvasElement>;

  readonly state = inject(DesignStudioState);
  private readonly platformId = inject(PLATFORM_ID);
  readonly isBrowser = isPlatformBrowser(this.platformId);

  readonly environments: LightingEnv[] = ['Studio', 'Tageslicht', 'Nacht', 'Showroom', 'Tunnel'];
  readonly activeEnv = signal<LightingEnv>('Studio');
  readonly isTurntableActive = signal<boolean>(false);
  readonly focalLength = signal<number>(35);

  // Three.js internal objects
  private renderer?: THREE.WebGLRenderer;
  private scene?: THREE.Scene;
  private camera?: THREE.PerspectiveCamera;
  private sceneBuild: VehicleSceneBuild | null = null;
  private animationFrameId: number | null = null;

  // Camera Orbit / Pan state
  private isPointerDown = false;
  private pointerButton = 0;
  private prevPointerX = 0;
  private prevPointerY = 0;
  private spherical = new THREE.Spherical(7.8, Math.PI / 2.6, Math.PI / 4.2);
  private cameraTarget = new THREE.Vector3(0, 0.7, 0);

  // Raycaster for Clay Sculpting
  private raycaster = new THREE.Raycaster();
  private mouseVec = new THREE.Vector2();

  constructor() {
    // Re-build 3D geometry when project dimensions, materials, wheels, or lights change
    effect(() => {
      const project = this.state.currentProject();
      if (this.isBrowser && this.scene) {
        this.rebuildVehicleScene();
      }
    });
  }

  ngOnInit() {
    if (this.isBrowser) {
      this.initThreeScene();
      window.addEventListener('resize', this.onResize);
    }
  }

  ngOnDestroy() {
    if (this.isBrowser) {
      window.removeEventListener('resize', this.onResize);
      if (this.animationFrameId !== null) {
        cancelAnimationFrame(this.animationFrameId);
      }
      if (this.renderer) {
        this.renderer.dispose();
      }
    }
  }

  private initThreeScene() {
    if (!this.isBrowser) return;

    const container = this.canvasContainer.nativeElement;
    const canvas = this.webglCanvas.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 600;

    try {
      this.renderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        powerPreference: 'high-performance',
        preserveDrawingBuffer: true,
      });
      this.renderer.setSize(width, height);
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.25;

      this.scene = new THREE.Scene();
      this.scene.background = new THREE.Color(0x0a0c10);

      this.camera = new THREE.PerspectiveCamera(this.getFovFromFocalLength(this.focalLength()), width / height, 0.1, 100);
      this.updateCameraPosition();

      this.createStudioFloor();
      this.setupLightingRig(this.activeEnv());
      this.rebuildVehicleScene();
      this.animate();
    } catch (err) {
      console.error('WebGL Initialization error:', err);
    }
  }

  private createStudioFloor() {
    if (!this.scene) return;

    const floorGeo = new THREE.PlaneGeometry(80, 80);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x0e1117,
      roughness: 0.8,
      metalness: 0.2,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = 0;
    floor.receiveShadow = true;
    this.scene.add(floor);

    const discGeo = new THREE.CircleGeometry(4.2, 64);
    const discMat = new THREE.MeshStandardMaterial({
      color: 0x141822,
      roughness: 0.4,
      metalness: 0.7,
    });
    const disc = new THREE.Mesh(discGeo, discMat);
    disc.rotation.x = -Math.PI / 2;
    disc.position.y = 0.002;
    disc.receiveShadow = true;
    this.scene.add(disc);

    const ringGeo = new THREE.RingGeometry(4.16, 4.22, 64);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x00d2ff, side: THREE.DoubleSide });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.003;
    this.scene.add(ring);
  }

  private setupLightingRig(env: LightingEnv) {
    if (!this.scene) return;

    const existingLights = this.scene.children.filter((c) => c.name.startsWith('StudioLight_'));
    existingLights.forEach((l) => this.scene!.remove(l));

    const ambientLight = new THREE.AmbientLight(0xffffff, env === 'Nacht' ? 0.35 : 0.9);
    ambientLight.name = 'StudioLight_Ambient';
    this.scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfff5ea, env === 'Nacht' ? 0.8 : 2.2);
    keyLight.position.set(5, 8, 5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 2048;
    keyLight.shadow.mapSize.height = 2048;
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 25;
    keyLight.shadow.bias = -0.0005;
    keyLight.name = 'StudioLight_Key';
    this.scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x00d2ff, env === 'Nacht' ? 1.8 : 1.2);
    rimLight.position.set(-6, 4, -7);
    rimLight.name = 'StudioLight_Rim';
    this.scene.add(rimLight);

    const fillLight = new THREE.DirectionalLight(0xaaccff, 0.85);
    fillLight.position.set(-5, 5, 5);
    fillLight.name = 'StudioLight_Fill';
    this.scene.add(fillLight);
  }

  rebuildVehicleScene() {
    if (!this.scene) return;

    if (this.sceneBuild) {
      this.scene.remove(this.sceneBuild.rootGroup);
    }

    const project = this.state.currentProject();
    this.sceneBuild = buildVehicleScene(project);
    this.scene.add(this.sceneBuild.rootGroup);
  }

  setEnvironment(env: LightingEnv) {
    this.activeEnv.set(env);
    this.setupLightingRig(env);
  }

  setFocalLength(mm: number) {
    this.focalLength.set(mm);
    if (this.camera) {
      this.camera.fov = this.getFovFromFocalLength(mm);
      this.camera.updateProjectionMatrix();
    }
  }

  private getFovFromFocalLength(fl: number): number {
    return 2 * Math.atan(12 / fl) * (180 / Math.PI);
  }

  setCameraPreset(preset: CameraPreset) {
    switch (preset) {
      case 'hero-front':
        this.spherical.set(7.5, Math.PI / 2.5, Math.PI / 4.5);
        this.cameraTarget.set(0, 0.7, 0);
        break;
      case 'hero-side':
        this.spherical.set(7.8, Math.PI / 2.1, Math.PI / 2);
        this.cameraTarget.set(0, 0.7, 0);
        break;
      case 'front':
        this.spherical.set(7.2, Math.PI / 2.2, 0);
        this.cameraTarget.set(0, 0.7, 0);
        break;
      case 'rear-34':
        this.spherical.set(7.5, Math.PI / 2.5, Math.PI * 0.8);
        this.cameraTarget.set(0, 0.7, 0);
        break;
      case 'top':
        this.spherical.set(9.0, 0.05, 0);
        this.cameraTarget.set(0, 0, 0);
        break;
      case 'interior':
        this.spherical.set(1.8, Math.PI / 2.3, Math.PI * 0.45);
        this.cameraTarget.set(0, 0.85, -0.2);
        break;
      case 'aero':
        this.spherical.set(8.5, Math.PI / 2.4, Math.PI / 3.0);
        this.cameraTarget.set(0, 0.6, 0);
        break;
    }
    this.updateCameraPosition();
  }

  toggleTurntable() {
    this.isTurntableActive.update((v) => !v);
  }

  captureScreenshot() {
    if (!this.renderer || !this.scene || !this.camera) return;
    this.renderer.render(this.scene, this.camera);
    const dataUrl = this.renderer.domElement.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `${this.state.currentProject().codeName}_Render_${Date.now()}.png`;
    a.click();
    a.remove();
  }

  onPointerDown(e: PointerEvent) {
    this.isPointerDown = true;
    this.pointerButton = e.button;
    this.prevPointerX = e.clientX;
    this.prevPointerY = e.clientY;

    if (this.state.activeWorkspace() === 'clay' && e.button === 0) {
      this.performClaySculpt(e);
    }
  }

  onPointerMove(e: PointerEvent) {
    if (!this.isPointerDown) return;

    const dx = e.clientX - this.prevPointerX;
    const dy = e.clientY - this.prevPointerY;
    this.prevPointerX = e.clientX;
    this.prevPointerY = e.clientY;

    if (this.state.activeWorkspace() === 'clay' && this.pointerButton === 0 && e.shiftKey) {
      this.performClaySculpt(e);
      return;
    }

    if (this.pointerButton === 0) {
      this.spherical.theta -= dx * 0.005;
      this.spherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.02, this.spherical.phi - dy * 0.005));
      this.updateCameraPosition();
    } else if (this.pointerButton === 2 || (this.pointerButton === 0 && e.shiftKey)) {
      const panSpeed = 0.004;
      if (this.camera) {
        const right = new THREE.Vector3().crossVectors(this.camera.up, new THREE.Vector3().subVectors(this.camera.position, this.cameraTarget)).normalize();
        this.cameraTarget.addScaledVector(right, -dx * panSpeed);
        this.cameraTarget.y += dy * panSpeed;
        this.updateCameraPosition();
      }
    }
  }

  onPointerUp(e: PointerEvent) {
    this.isPointerDown = false;
  }

  onWheel(e: WheelEvent) {
    e.preventDefault();
    this.spherical.radius = Math.max(1.2, Math.min(30.0, this.spherical.radius + e.deltaY * 0.004));
    this.updateCameraPosition();
  }

  private performClaySculpt(e: PointerEvent) {
    if (!this.sceneBuild || !this.renderer || !this.camera) return;

    const rect = this.webglCanvas.nativeElement.getBoundingClientRect();
    this.mouseVec.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouseVec.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouseVec, this.camera);
    const intersects = this.raycaster.intersectObject(this.sceneBuild.bodyMesh);

    if (intersects.length > 0) {
      const hit = intersects[0];
      const clay = this.state.currentProject().clay;
      const radiusM = clay.toolRadius / 1000;
      const intensityM = (clay.toolIntensity * 0.04);

      let dir = hit.face ? hit.face.normal.clone() : new THREE.Vector3(0, 1, 0);
      if (clay.activeTool === 'carve' || clay.activeTool === 'push') {
        dir.negate();
      }

      const point = {
        id: `def-${Date.now()}`,
        x: hit.point.x,
        y: hit.point.y,
        z: hit.point.z,
        dx: dir.x * intensityM,
        dy: dir.y * intensityM,
        dz: dir.z * intensityM,
        radius: radiusM,
        operation: clay.activeTool,
      };

      this.state.updateProject((proj) => {
        proj.clay.deformations.push(point);
      });

      applyClayDeformationsToGeometry(
        this.sceneBuild.bodyGeometry,
        this.sceneBuild.basePositions,
        this.state.currentProject().clay.deformations
      );
    }
  }

  private updateCameraPosition() {
    if (!this.camera) return;
    const pos = new THREE.Vector3().setFromSpherical(this.spherical).add(this.cameraTarget);
    this.camera.position.copy(pos);
    this.camera.lookAt(this.cameraTarget);
  }

  private animate = () => {
    if (!this.isBrowser) return;

    this.animationFrameId = requestAnimationFrame(this.animate);

    if (this.isTurntableActive()) {
      this.spherical.theta += 0.003;
      this.updateCameraPosition();
    }

    if (this.renderer && this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
    }
  };

  private onResize = () => {
    if (!this.isBrowser || !this.canvasContainer || !this.renderer || !this.camera) return;
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };
}
