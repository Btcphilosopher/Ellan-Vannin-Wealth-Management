import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-proportion-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0d12] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <!-- Title & Live Constraints Status -->
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">aspect_ratio</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">PROPORTIONSSTUDIO & FAHRZEUGARCHITEKTUR</h2>
            <div class="text-[11px] text-neutral-400 font-light">Parametrische Geometrie & CAD-Ebenen</div>
          </div>
        </div>

        <div class="flex items-center space-x-2">
          @if (state.designConstraintWarnings().length === 0) {
            <span class="px-2.5 py-1 rounded bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 text-xs font-mono flex items-center space-x-1">
              <mat-icon class="!w-3.5 !h-3.5 !text-sm">check_circle</mat-icon>
              <span>DAIMLER CONSTRAINTS VERIFIZIERT</span>
            </span>
          } @else {
            <span class="px-2.5 py-1 rounded bg-amber-950/80 border border-amber-500/30 text-amber-400 text-xs font-mono flex items-center space-x-1">
              <mat-icon class="!w-3.5 !h-3.5 !text-sm">warning</mat-icon>
              <span>{{ state.designConstraintWarnings().length }} WARNUNGEN</span>
            </span>
          }
        </div>
      </div>

      <!-- Constraint Warning Banner if any -->
      @if (state.designConstraintWarnings().length > 0) {
        <div class="p-3 rounded-lg bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs space-y-1">
          <div class="font-bold flex items-center space-x-1 text-amber-300">
            <mat-icon class="!w-4 !h-4 !text-base">info</mat-icon>
            <span>Designregel-Hinweise:</span>
          </div>
          <ul class="list-disc list-inside space-y-0.5 text-[11px] text-amber-200/90 pl-1">
            @for (w of state.designConstraintWarnings(); track w) {
              <li>{{ w }}</li>
            }
          </ul>
        </div>
      }

      <!-- Interactive Blueprint Canvas Preview -->
      <div class="relative w-full h-44 rounded-xl border border-white/10 bg-[#07080b] p-3 flex flex-col justify-between cad-grid overflow-hidden">
        <div class="flex items-center justify-between text-[11px] font-mono text-neutral-400">
          <span class="text-cyan-400">BLUEPRINT SEITENPROFIL (ORTHOGRAPHISCH)</span>
          <span>MASSTAB 1:50 · L: {{ state.currentProject().dimensions.length }} mm</span>
        </div>

        <!-- SVG Wireframe of Car Silhouette based on live dimensions -->
        <svg class="w-full h-28 my-auto" viewBox="0 0 600 180">
          <defs>
            <linearGradient id="blueprintGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stop-color="#00d2ff" stop-opacity="0.25"/>
              <stop offset="100%" stop-color="#00d2ff" stop-opacity="0.02"/>
            </linearGradient>
          </defs>

          <!-- Ground Line -->
          <line x1="20" y1="145" x2="580" y2="145" stroke="rgba(255,255,255,0.2)" stroke-width="1" stroke-dasharray="4 4" />

          <!-- Dynamic Car Body Path computed from state -->
          <path [attr.d]="computeCarSvgPath()" fill="url(#blueprintGrad)" stroke="#00d2ff" stroke-width="2" />

          <!-- Front Wheel -->
          <circle [attr.cx]="frontWheelX()" cy="130" r="22" fill="#141822" stroke="#00d2ff" stroke-width="1.5" />
          <circle [attr.cx]="frontWheelX()" cy="130" r="14" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="1" />

          <!-- Rear Wheel -->
          <circle [attr.cx]="rearWheelX()" cy="130" r="22" fill="#141822" stroke="#00d2ff" stroke-width="1.5" />
          <circle [attr.cx]="rearWheelX()" cy="130" r="14" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="1" />

          <!-- Wheelbase Dimension Line -->
          <line [attr.x1]="frontWheelX()" y1="165" [attr.x2]="rearWheelX()" y2="165" stroke="#00d2ff" stroke-width="1" />
          <text [attr.x]="(frontWheelX() + rearWheelX()) / 2" y="162" fill="#00d2ff" font-size="10" font-family="monospace" text-anchor="middle">
            Radstand {{ state.currentProject().dimensions.wheelbase }} mm
          </text>
        </svg>

        <div class="flex items-center justify-between text-[10px] font-mono text-neutral-500">
          <span>Überhang Vorn: {{ state.currentProject().dimensions.frontOverhang }} mm</span>
          <span>A-Säule: {{ state.currentProject().dimensions.aPillarAngle }}°</span>
          <span>Überhang Heck: {{ state.currentProject().dimensions.rearOverhang }} mm</span>
        </div>
      </div>

      <!-- Parameter Sliders Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        
        <!-- Column 1: Längsabmessungen -->
        <div class="p-4 rounded-xl bg-[#11141c] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">straighten</mat-icon>
            <span>LÄNGS- & HAUPTABMESSUNGEN</span>
          </div>

          <!-- Wheelbase -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Radstand (Wheelbase)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().dimensions.wheelbase }} mm</span>
            </div>
            <input type="range" min="2600" max="3600" step="10"
              [value]="state.currentProject().dimensions.wheelbase"
              (input)="updateDim('wheelbase', +$any($event.target).value)" class="w-full cursor-pointer" />
            <div class="flex justify-between text-[10px] text-neutral-500">
              <span>2600 mm</span>
              <span>EVA/MMA Plattform</span>
              <span>3600 mm</span>
            </div>
          </div>

          <!-- Length -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Gesamtlänge (Length)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().dimensions.length }} mm</span>
            </div>
            <input type="range" min="4400" max="5600" step="10"
              [value]="state.currentProject().dimensions.length"
              (input)="updateDim('length', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>

          <!-- Width -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Gesamtbreite (Width)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().dimensions.width }} mm</span>
            </div>
            <input type="range" min="1800" max="2150" step="5"
              [value]="state.currentProject().dimensions.width"
              (input)="updateDim('width', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>

          <!-- Height -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Gesamthöhe (Height)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().dimensions.height }} mm</span>
            </div>
            <input type="range" min="1250" max="1950" step="5"
              [value]="state.currentProject().dimensions.height"
              (input)="updateDim('height', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>
        </div>

        <!-- Column 2: Überhänge & Winkel -->
        <div class="p-4 rounded-xl bg-[#11141c] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">architecture</mat-icon>
            <span>ÜBERHÄNGE & SÄULENWINKEL</span>
          </div>

          <!-- Front Overhang -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Überhang Vorn (Front Overhang)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().dimensions.frontOverhang }} mm</span>
            </div>
            <input type="range" min="700" max="1100" step="5"
              [value]="state.currentProject().dimensions.frontOverhang"
              (input)="updateDim('frontOverhang', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>

          <!-- Rear Overhang -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Überhang Heck (Rear Overhang)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().dimensions.rearOverhang }} mm</span>
            </div>
            <input type="range" min="800" max="1350" step="5"
              [value]="state.currentProject().dimensions.rearOverhang"
              (input)="updateDim('rearOverhang', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>

          <!-- Ground Clearance -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Bodenfreiheit (Ground Clearance)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().dimensions.groundClearance }} mm</span>
            </div>
            <input type="range" min="95" max="240" step="5"
              [value]="state.currentProject().dimensions.groundClearance"
              (input)="updateDim('groundClearance', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>

          <!-- A-Pillar Angle -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>A-Säulen-Winkel (A-Pillar)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().dimensions.aPillarAngle }}°</span>
            </div>
            <input type="range" min="20.0" max="35.0" step="0.5"
              [value]="state.currentProject().dimensions.aPillarAngle"
              (input)="updateDim('aPillarAngle', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>
        </div>

      </div>
    </div>
  `,
})
export class ProportionStudio {
  readonly state = inject(DesignStudioState);

  updateDim(key: string, val: number) {
    this.state.updateProject((p) => {
      (p.dimensions as any)[key] = val;
    });
  }

  frontWheelX(): number {
    const d = this.state.currentProject().dimensions;
    return 150 + (d.frontOverhang / 1000) * 40;
  }

  rearWheelX(): number {
    const d = this.state.currentProject().dimensions;
    return this.frontWheelX() + (d.wheelbase / 1000) * 90;
  }

  computeCarSvgPath(): string {
    const d = this.state.currentProject().dimensions;
    const fwX = this.frontWheelX();
    const rwX = this.rearWheelX();
    const noseX = fwX - (d.frontOverhang / 1000) * 70;
    const tailX = rwX + (d.rearOverhang / 1000) * 70;
    const roofApexX = fwX + (rwX - fwX) * d.roofApexRatio;
    const roofY = 40 + (1950 - d.height) * 0.05;

    return `M ${noseX} 135 
      C ${noseX + 20} 125, ${fwX - 35} 120, ${fwX - 25} 130 
      A 25 25 0 0 1 ${fwX + 25} 130 
      C ${fwX + 40} 120, ${fwX + 60} 95, ${fwX + 90} 70
      C ${fwX + 110} 55, ${roofApexX - 30} ${roofY}, ${roofApexX} ${roofY}
      C ${roofApexX + 60} ${roofY}, ${rwX - 20} 70, ${rwX - 25} 130
      A 25 25 0 0 1 ${rwX + 25} 130
      C ${rwX + 35} 120, ${tailX - 20} 115, ${tailX} 125
      L ${tailX} 140 
      L ${noseX} 140 Z`;
  }
}
