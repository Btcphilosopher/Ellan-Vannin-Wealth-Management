import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';
import { SAMPLE_PROJECTS_CATALOG } from '../../core/models/templates';
import { VehicleClass, DriveConcept, VehicleProject } from '../../core/models/vehicle.model';

@Component({
  selector: 'app-start-screen',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full overflow-y-auto bg-gradient-to-b from-[#0e1117] to-[#07090d] p-8 text-neutral-100 font-sans">
      <div class="max-w-7xl mx-auto space-y-8">
        
        <!-- Welcome Hero Banner -->
        <div class="relative rounded-2xl overflow-hidden border border-white/10 p-8 aluminum-panel shadow-2xl">
          <div class="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div class="space-y-3">
              <div class="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-mono">
                <span class="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                <span>DIGITAL AUTOMOTIVE DESIGN SUITE 2026–2030</span>
              </div>
              <h1 class="text-3xl lg:text-4xl font-extrabold tracking-tight font-mono text-neutral-100">
                MERCEDES-BENZ DESIGN STUDIO
              </h1>
              <p class="text-neutral-400 text-sm max-w-2xl leading-relaxed">
                Willkommen in der digitalen Fahrzeugentwicklungsumgebung für Designer, Clay-Modeller, Surface-Spezialisten, Aerodynamiker und Karosserieingenieure. Entwickeln Sie Ihr Fahrzeug von der ersten Proportionsskizze bis zum Class-A Strak und Design Freeze.
              </p>
            </div>

            <div class="flex items-center space-x-3 shrink-0">
              <button (click)="state.isNewProjectWizardOpen.set(true)"
                class="px-5 py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-sm shadow-lg shadow-cyan-900/40 flex items-center space-x-2 transition cursor-pointer">
                <mat-icon>add_circle</mat-icon>
                <span>Neues Fahrzeug</span>
              </button>

              <button (click)="triggerFileInput()"
                class="px-5 py-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-white/10 text-neutral-200 font-medium text-sm flex items-center space-x-2 transition cursor-pointer">
                <mat-icon>folder_open</mat-icon>
                <span>.mbdesign öffnen</span>
              </button>
              <input #fileInput type="file" accept=".mbdesign,.json" class="hidden" (change)="onFileSelected($event)" />
            </div>
          </div>
        </div>

        <!-- Quick Start / Featured Projects -->
        <div class="space-y-4">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-bold font-mono tracking-wider flex items-center space-x-2">
              <mat-icon class="text-cyan-400">directions_car</mat-icon>
              <span>FAHRZEUGPROJEKTE & VORLAGEN</span>
            </h2>
            <span class="text-xs text-neutral-500 font-mono">5 Konzeptfahrzeuge geladen</span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            @for (proj of projectsCatalog; track proj.id) {
              <div class="group rounded-xl border border-white/10 bg-[#12151d] hover:border-cyan-500/50 p-5 transition flex flex-col justify-between hover:shadow-xl hover:shadow-cyan-950/20">
                <div class="space-y-3">
                  <div class="flex items-center justify-between">
                    <span class="px-2 py-0.5 rounded text-[11px] font-mono font-semibold"
                      [class.bg-cyan-950]="proj.status === 'IN ENTWICKLUNG'"
                      [class.text-cyan-300]="proj.status === 'IN ENTWICKLUNG'"
                      [class.border]="true"
                      [class.border-cyan-500/30]="proj.status === 'IN ENTWICKLUNG'"
                      [class.bg-amber-950]="proj.status === 'DESIGN REVIEW'"
                      [class.text-amber-300]="proj.status === 'DESIGN REVIEW'"
                      [class.border-amber-500/30]="proj.status === 'DESIGN REVIEW'"
                      [class.bg-neutral-800]="proj.status === 'ENTWURF'"
                      [class.text-neutral-400]="proj.status === 'ENTWURF'">
                      {{ proj.status }}
                    </span>
                    <span class="text-xs text-neutral-500 font-mono">{{ proj.codeName }}</span>
                  </div>

                  <div>
                    <h3 class="text-base font-bold text-neutral-100 group-hover:text-cyan-300 transition">
                      {{ proj.name }}
                    </h3>
                    <p class="text-xs text-neutral-400 mt-1">
                      {{ proj.vehicleClass }} · {{ proj.driveConcept }}
                    </p>
                  </div>

                  <!-- Spec Pills -->
                  <div class="grid grid-cols-3 gap-2 pt-2 border-t border-white/5 text-[11px] font-mono">
                    <div class="bg-black/30 p-2 rounded">
                      <div class="text-neutral-500">Radstand</div>
                      <div class="text-neutral-200 font-bold">{{ proj.dimensions.wheelbase }} mm</div>
                    </div>
                    <div class="bg-black/30 p-2 rounded">
                      <div class="text-neutral-500">cW-Wert</div>
                      <div class="text-emerald-400 font-bold">{{ proj.aerodynamics.cw }}</div>
                    </div>
                    <div class="bg-black/30 p-2 rounded">
                      <div class="text-neutral-500">Räder</div>
                      <div class="text-neutral-200 font-bold">{{ proj.wheels.diameterInches }}"</div>
                    </div>
                  </div>
                </div>

                <div class="pt-4 flex items-center justify-between">
                  <span class="text-[11px] text-neutral-500">{{ proj.currentVersion }}</span>
                  <button (click)="openProject(proj)"
                    class="px-3.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-cyan-600 text-neutral-200 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer">
                    <span>Projekt laden</span>
                    <mat-icon class="!w-3.5 !h-3.5 !text-sm">arrow_forward</mat-icon>
                  </button>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Design Workflow Overview -->
        <div class="rounded-xl border border-white/10 bg-[#10131a] p-6 space-y-4">
          <h3 class="text-sm font-bold font-mono tracking-wider text-neutral-300 flex items-center space-x-2">
            <mat-icon class="text-cyan-400">account_tree</mat-icon>
            <span>INTEGRIERTER AUTOMOBILDESIGN-WORKFLOW</span>
          </h3>

          <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3 text-center">
            @for (step of workflowSteps; track step.title) {
              <div class="p-3 rounded-lg bg-black/40 border border-white/5 space-y-1.5">
                <div class="w-7 h-7 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-400 text-xs font-mono font-bold mx-auto flex items-center justify-center">
                  {{ step.num }}
                </div>
                <div class="text-xs font-bold text-neutral-200">{{ step.title }}</div>
                <div class="text-[10px] text-neutral-500 leading-tight">{{ step.desc }}</div>
              </div>
            }
          </div>
        </div>

      </div>

      <!-- New Project Modal Wizard -->
      @if (state.isNewProjectWizardOpen()) {
        <div class="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div class="w-full max-w-xl rounded-2xl bg-[#141822] border border-white/10 p-6 space-y-6 shadow-2xl">
            <div class="flex items-center justify-between border-b border-white/10 pb-4">
              <div class="flex items-center space-x-2">
                <mat-icon class="text-cyan-400">add_circle</mat-icon>
                <h3 class="text-lg font-bold font-mono text-neutral-100">NEUES FAHRZEUGKONZEPT ERSTELLEN</h3>
              </div>
              <button (click)="state.isNewProjectWizardOpen.set(false)" class="text-neutral-400 hover:text-white">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div class="space-y-4 text-xs font-mono">
              <div>
                <label class="block text-neutral-400 mb-1">PROJEKTNAME</label>
                <input #nameInput type="text" value="VISION E-PERFORMANCE 2030"
                  class="w-full px-3 py-2 rounded bg-black/50 border border-white/10 text-neutral-100 focus:border-cyan-400 focus:outline-none" />
              </div>

              <div>
                <label class="block text-neutral-400 mb-1">BAUREIHEN-CODE (z.B. BR-297-EV)</label>
                <input #codeInput type="text" value="BR-301-CONCEPT"
                  class="w-full px-3 py-2 rounded bg-black/50 border border-white/10 text-neutral-100 focus:border-cyan-400 focus:outline-none" />
              </div>

              <div>
                <label class="block text-neutral-400 mb-1">FAHRZEUGKLASSE</label>
                <select #classSelect class="w-full px-3 py-2 rounded bg-black/50 border border-white/10 text-neutral-100 focus:border-cyan-400 focus:outline-none">
                  @for (cls of vehicleClasses; track cls) {
                    <option [value]="cls">{{ cls }}</option>
                  }
                </select>
              </div>

              <div>
                <label class="block text-neutral-400 mb-1">ANTRIEBSKONZEPT & PLATTFORM</label>
                <select #driveSelect class="w-full px-3 py-2 rounded bg-black/50 border border-white/10 text-neutral-100 focus:border-cyan-400 focus:outline-none">
                  @for (drv of driveConcepts; track drv) {
                    <option [value]="drv">{{ drv }}</option>
                  }
                </select>
              </div>
            </div>

            <div class="flex items-center justify-end space-x-3 pt-4 border-t border-white/10">
              <button (click)="state.isNewProjectWizardOpen.set(false)"
                class="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-medium transition">
                Abbrechen
              </button>
              <button (click)="createProject(nameInput.value, codeInput.value, classSelect.value, driveSelect.value)"
                class="px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-lg shadow-cyan-900/30 flex items-center space-x-1.5 transition">
                <span>Projekt initialisieren</span>
                <mat-icon class="!w-3.5 !h-3.5 !text-sm">arrow_forward</mat-icon>
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class StartScreen {
  readonly state = inject(DesignStudioState);
  readonly projectsCatalog = SAMPLE_PROJECTS_CATALOG;

  readonly vehicleClasses: VehicleClass[] = [
    'Luxuslimousine',
    'Limousine',
    'Coupé',
    'Cabriolet',
    'Kombi',
    'SUV',
    'Crossover',
    'Sportwagen',
    'Gran Turismo',
    'Van',
    'Konzeptfahrzeug',
  ];

  readonly driveConcepts: DriveConcept[] = [
    'EQ-Dual-eATS-Allrad (800V)',
    'EQ-Single-Heckantrieb',
    'AMG-High-Performance-Hybrid',
    'Solid-State-Electric-Platform',
    'V8-Biturbo-E-Performance',
  ];

  readonly workflowSteps = [
    { num: '01', title: 'Architektur', desc: 'Radstand & Package' },
    { num: '02', title: 'Proportion', desc: 'Säulen & Dachlinie' },
    { num: '03', title: '2D-Skizze', desc: 'Formfindung & Strich' },
    { num: '04', title: 'Digital Clay', desc: 'Volumen & Skulptur' },
    { num: '05', title: 'Class-A Strak', desc: 'Zebra G2 Stetigkeit' },
    { num: '06', title: 'Aero & cW', desc: 'Strömungsanalyse' },
    { num: '07', title: 'Material & Licht', desc: 'Farben & Signatur' },
    { num: '08', title: 'Freigabe', desc: 'Freeze & PDF Report' },
  ];

  openProject(proj: VehicleProject) {
    this.state.loadProject(proj);
    this.state.setWorkspace('karosserie3d');
  }

  createProject(name: string, code: string, vClass: string, drive: string) {
    this.state.createNewProject({
      name,
      codeName: code,
      vehicleClass: vClass as VehicleClass,
      driveConcept: drive as DriveConcept,
    });
  }

  triggerFileInput() {
    const el = document.querySelector('input[type=file]') as HTMLInputElement;
    if (el) el.click();
  }

  onFileSelected(e: Event) {
    const input = e.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) {
          this.state.importMbDesignFile(text);
          this.state.setWorkspace('karosserie3d');
        }
      };
      reader.readAsText(input.files[0]);
    }
  }
}
