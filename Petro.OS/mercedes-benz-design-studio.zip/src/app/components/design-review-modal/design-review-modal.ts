import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';
import { Viewport3d } from '../viewport-3d/viewport-3d';

@Component({
  selector: 'app-design-review-modal',
  imports: [CommonModule, MatIconModule, Viewport3d],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (state.isReviewModeOpen()) {
      <div class="fixed inset-0 z-50 bg-[#07080b] flex flex-col overflow-hidden text-neutral-100 font-sans select-none">
        
        <!-- Clean Minimal Top Floating HUD -->
        <div class="absolute top-4 inset-x-4 z-20 flex items-center justify-between pointer-events-none">
          <div class="flex items-center space-x-3 pointer-events-auto bg-black/70 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10 shadow-2xl">
            <div class="w-6 h-6 rounded-full border border-white/40 flex items-center justify-center p-0.5">
              <svg class="w-full h-full text-white fill-current" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 1.8c4.52 0 8.2 3.68 8.2 8.2 0 4.52-3.68 8.2-8.2 8.2-4.52 0-8.2-3.68-8.2-8.2 0-4.52 3.68-8.2 8.2-8.2zm0 1.9l-2.7 7.5L3.6 15.6l7.7-1.7 0.7 7.1 0.7-7.1 7.7 1.7-5.7-4.4L12 5.7z"/>
              </svg>
            </div>
            <div>
              <div class="text-xs font-mono font-bold tracking-widest text-neutral-100">
                MERCEDES-BENZ EXECUTIVE DESIGN REVIEW
              </div>
              <div class="text-[11px] text-cyan-400 font-mono">
                {{ state.currentProject().name }} · {{ state.currentProject().currentVersion }}
              </div>
            </div>
          </div>

          <!-- Actions -->
          <div class="flex items-center space-x-2 pointer-events-auto">
            <!-- Overlay Toggle -->
            <button (click)="showSpecsOverlay.set(!showSpecsOverlay())"
              [class.bg-white/20]="showSpecsOverlay()"
              class="px-3 py-1.5 rounded-xl bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-neutral-300 hover:text-white transition flex items-center space-x-1.5">
              <mat-icon class="!w-4 !h-4 !text-base">info</mat-icon>
              <span>Kennwerte {{ showSpecsOverlay() ? 'ausblenden' : 'einblenden' }}</span>
            </button>

            <!-- Design Freeze Button -->
            @if (state.currentProject().status !== 'DESIGN FREEZE') {
              <button (click)="confirmDesignFreeze()"
                class="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-mono font-bold flex items-center space-x-1.5 shadow-lg shadow-amber-950/40 transition cursor-pointer">
                <mat-icon class="!w-4 !h-4 !text-base">lock</mat-icon>
                <span>OFFIZIELLER DESIGN FREEZE</span>
              </button>
            } @else {
              <span class="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold flex items-center space-x-1">
                <mat-icon class="!w-4 !h-4 !text-base">verified</mat-icon>
                <span>STATUS: DESIGN FREEZE</span>
              </span>
            }

            <!-- Close Presentation Mode -->
            <button (click)="state.isReviewModeOpen.set(false)"
              class="p-2 rounded-xl bg-black/70 backdrop-blur-md border border-white/10 text-neutral-300 hover:text-white transition cursor-pointer">
              <mat-icon>fullscreen_exit</mat-icon>
            </button>
          </div>
        </div>

        <!-- 3D Vehicle Fullscreen Viewport -->
        <div class="flex-1 w-full h-full">
          <app-viewport-3d></app-viewport-3d>
        </div>

        <!-- Technical Specs Overlay Bottom Left -->
        @if (showSpecsOverlay()) {
          <div class="absolute bottom-6 left-6 z-20 p-5 rounded-2xl bg-black/80 backdrop-blur-xl border border-white/10 max-w-md shadow-2xl space-y-3 font-mono text-xs pointer-events-auto animate-in fade-in">
            <div class="font-bold text-cyan-300 text-sm border-b border-white/10 pb-2 flex items-center justify-between">
              <span>FAHRZEUGDATEN & FREIGABESTATUS</span>
              <span class="text-neutral-400 text-xs font-normal">{{ state.currentProject().vehicleClass }}</span>
            </div>

            <div class="grid grid-cols-2 gap-x-4 gap-y-2 text-[11px]">
              <div>
                <span class="text-neutral-500">Länge × Breite × Höhe:</span>
                <div class="text-neutral-200 font-bold">
                  {{ state.currentProject().dimensions.length }} × {{ state.currentProject().dimensions.width }} × {{ state.currentProject().dimensions.height }} mm
                </div>
              </div>

              <div>
                <span class="text-neutral-500">Radstand:</span>
                <div class="text-cyan-400 font-bold">{{ state.currentProject().dimensions.wheelbase }} mm</div>
              </div>

              <div>
                <span class="text-neutral-500">cW-Wert / Stirnfläche:</span>
                <div class="text-emerald-400 font-bold">{{ state.effectiveCw() }} / {{ state.effectiveFrontalArea() }} m²</div>
              </div>

              <div>
                <span class="text-neutral-500">cW × A Index:</span>
                <div class="text-cyan-400 font-bold">{{ state.effectiveCwA() }} m²</div>
              </div>

              <div>
                <span class="text-neutral-500">Räder & Reifen:</span>
                <div class="text-neutral-200 font-bold">{{ state.currentProject().wheels.diameterInches }}" {{ state.currentProject().wheels.rimStyle }}</div>
              </div>

              <div>
                <span class="text-neutral-500">Antriebsstrang:</span>
                <div class="text-neutral-200 font-bold">{{ state.currentProject().driveConcept }}</div>
              </div>
            </div>

            <div class="pt-2 border-t border-white/10 text-[10px] text-neutral-400">
              MANUFAKTUR Lackierung: {{ state.currentProject().materials.paintName }}
            </div>
          </div>
        }

      </div>
    }
  `,
})
export class DesignReviewModal {
  readonly state = inject(DesignStudioState);
  readonly showSpecsOverlay = signal<boolean>(true);

  confirmDesignFreeze() {
    const ok = confirm('Möchten Sie den aktuellen Stand offiziell als DESIGN FREEZE festlegen?\n\nDamit wird die Karosseriegeometrie für den Prototypenbau freigegeben und das Modell im Versionsprotokoll schreibgeschützt gesichert.');
    if (ok) {
      this.state.setProjectStatus('DESIGN FREEZE');
    }
  }
}
