import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-ai-assistant-modal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (state.isAiAssistantOpen()) {
      <div class="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="w-full max-w-2xl h-[640px] rounded-2xl bg-[#121620] border border-white/10 shadow-2xl flex flex-col overflow-hidden font-sans text-neutral-100">
          
          <!-- Header -->
          <div class="h-14 px-5 bg-[#0e1118] border-b border-white/10 flex items-center justify-between shrink-0">
            <div class="flex items-center space-x-2.5">
              <div class="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                <mat-icon class="!w-5 !h-5 !text-xl">auto_awesome</mat-icon>
              </div>
              <div>
                <h3 class="text-sm font-bold font-mono tracking-wider text-neutral-100">KI-DESIGN- & AERODYNAMIKASSISTENT</h3>
                <div class="text-[11px] text-neutral-400 font-light">Mercedes-Benz Sindelfingen Design Intelligence</div>
              </div>
            </div>

            <button (click)="state.isAiAssistantOpen.set(false)" class="text-neutral-400 hover:text-white p-1 rounded transition">
              <mat-icon>close</mat-icon>
            </button>
          </div>

          <!-- Quick Prompts Chips -->
          <div class="px-5 py-2.5 bg-[#0a0c10] border-b border-white/5 flex items-center space-x-2 overflow-x-auto scrollbar-none shrink-0 text-xs">
            <span class="text-neutral-500 font-mono shrink-0">Vorschläge:</span>
            <button (click)="sendQuickPrompt('Wie verändert sich die Seitenproportion, wenn der Radstand um 120 mm verlängert wird?')"
              class="px-2.5 py-1 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[11px] whitespace-nowrap transition">
              Radstand +120mm Analyse
            </button>
            <button (click)="sendQuickPrompt('Wie steht es um die Class-A G2 Krümmungskontinuität der Schulterlinie?')"
              class="px-2.5 py-1 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[11px] whitespace-nowrap transition">
              Class-A Strak-Check
            </button>
            <button (click)="sendQuickPrompt('Berechne den aktuellen cW × A Index und den aerodynamischen Nachlaufwirbel.')"
              class="px-2.5 py-1 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[11px] whitespace-nowrap transition">
              cW × A Index
            </button>
          </div>

          <!-- Messages Stream -->
          <div #messageContainer class="flex-1 p-5 overflow-y-auto space-y-4 text-xs font-mono">
            @for (msg of state.aiMessages(); track msg.id) {
              <div [class.justify-end]="msg.sender === 'user'" class="flex">
                <div [class.bg-cyan-950]="msg.sender === 'user'"
                     [class.border-cyan-500/40]="msg.sender === 'user'"
                     [class.text-cyan-100]="msg.sender === 'user'"
                     [class.bg-[#191e2b]]="msg.sender === 'assistant'"
                     [class.border-white/10]="msg.sender === 'assistant'"
                     class="max-w-[85%] rounded-xl p-3.5 border shadow-md space-y-1.5">
                  <div class="flex items-center justify-between text-[10px] text-neutral-400 font-sans border-b border-white/5 pb-1">
                    <span class="font-bold font-mono">
                      {{ msg.sender === 'user' ? 'DESIGNER' : 'MBDS EXPERT INTELLIGENCE' }}
                    </span>
                    <span>{{ msg.timestamp }}</span>
                  </div>
                  <div class="whitespace-pre-wrap leading-relaxed font-sans text-xs">
                    {{ msg.text }}
                  </div>
                </div>
              </div>
            }

            @if (state.isAiThinking()) {
              <div class="flex items-center space-x-2 text-neutral-400 text-xs font-mono p-2">
                <mat-icon class="animate-spin text-cyan-400 !w-4 !h-4 !text-base">refresh</mat-icon>
                <span>Analysiere Fahrzeugparameter & Strak-Geometrie...</span>
              </div>
            }
          </div>

          <!-- Input Footer -->
          <div class="p-4 bg-[#0e1118] border-t border-white/10 shrink-0">
            <div class="flex items-center space-x-2">
              <input #chatInput type="text" placeholder="Frage an den Design- & Aero-Ingenieur formulieren..."
                (keydown.enter)="sendMessage(chatInput)"
                class="flex-1 px-4 py-2.5 rounded-xl bg-black/50 border border-white/10 text-neutral-100 placeholder-neutral-500 text-xs focus:outline-none focus:border-cyan-400" />
              <button (click)="sendMessage(chatInput)"
                [disabled]="state.isAiThinking()"
                class="px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center space-x-1 shadow-lg shadow-cyan-950/40 transition cursor-pointer">
                <mat-icon class="!w-4 !h-4 !text-base">send</mat-icon>
                <span>Senden</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    }
  `,
})
export class AiAssistantModal {
  readonly state = inject(DesignStudioState);
  @ViewChild('messageContainer') messageContainer!: ElementRef<HTMLDivElement>;

  sendMessage(input: HTMLInputElement) {
    const val = input.value.trim();
    if (!val) return;
    input.value = '';
    this.state.askAiAssistant(val);
  }

  sendQuickPrompt(prompt: string) {
    this.state.askAiAssistant(prompt);
  }
}
