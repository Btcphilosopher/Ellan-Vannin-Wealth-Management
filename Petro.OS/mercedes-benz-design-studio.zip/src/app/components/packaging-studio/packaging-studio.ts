import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-packaging-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">battery_charging_full</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">PACKAGING & ELEKTRO-ARCHITEKTUR (EVA/MMA)</h2>
            <div class="text-[11px] text-neutral-400 font-light">Unterbodenbatterie, eATS-Antriebseinheiten, Crashstrukturen & Raumökonomie</div>
          </div>
        </div>

        <div class="px-3 py-1 rounded bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-bold">
          PLATTFORM: 800V SKATEBOARD ARCHITEKTUR
        </div>
      </div>

      <!-- X-Ray Layer Toggles -->
      <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3 font-mono text-xs">
        <div class="font-bold text-neutral-200">3D RÖNTGEN-PACKAGING KOMPONENTEN EINBLENDEN</div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          <!-- Battery -->
          <div (click)="togglePackaging('showBatteryPack')"
            [class.border-cyan-500]="state.currentProject().packaging.showBatteryPack"
            [class.bg-cyan-500/10]="state.currentProject().packaging.showBatteryPack"
            class="p-3.5 rounded-xl border border-white/10 bg-black/40 hover:border-white/20 transition cursor-pointer flex items-center justify-between">
            <div class="space-y-1">
              <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
                <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">battery_full</mat-icon>
                <span>118 kWh Batterie</span>
              </div>
              <div class="text-[10px] text-neutral-500 font-sans">Unterboden Skateboard Pack</div>
            </div>
            <span [class.text-cyan-400]="state.currentProject().packaging.showBatteryPack" class="font-bold text-xs">
              {{ state.currentProject().packaging.showBatteryPack ? 'AN' : 'AUS' }}
            </span>
          </div>

          <!-- Motors -->
          <div (click)="togglePackaging('showMotors')"
            [class.border-cyan-500]="state.currentProject().packaging.showMotors"
            [class.bg-cyan-500/10]="state.currentProject().packaging.showMotors"
            class="p-3.5 rounded-xl border border-white/10 bg-black/40 hover:border-white/20 transition cursor-pointer flex items-center justify-between">
            <div class="space-y-1">
              <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
                <mat-icon class="!w-4 !h-4 !text-base text-amber-400">electric_meter</mat-icon>
                <span>Dual eATS Motoren</span>
              </div>
              <div class="text-[10px] text-neutral-500 font-sans">Permanenterregte Synchronmotoren</div>
            </div>
            <span [class.text-cyan-400]="state.currentProject().packaging.showMotors" class="font-bold text-xs">
              {{ state.currentProject().packaging.showMotors ? 'AN' : 'AUS' }}
            </span>
          </div>

          <!-- Crash Structures -->
          <div (click)="togglePackaging('showCrashStructures')"
            [class.border-cyan-500]="state.currentProject().packaging.showCrashStructures"
            [class.bg-cyan-500/10]="state.currentProject().packaging.showCrashStructures"
            class="p-3.5 rounded-xl border border-white/10 bg-black/40 hover:border-white/20 transition cursor-pointer flex items-center justify-between">
            <div class="space-y-1">
              <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
                <mat-icon class="!w-4 !h-4 !text-base text-rose-400">security</mat-icon>
                <span>Crash-Strukturen</span>
              </div>
              <div class="text-[10px] text-neutral-500 font-sans">Alu-Druckguss Längsträger</div>
            </div>
            <span [class.text-cyan-400]="state.currentProject().packaging.showCrashStructures" class="font-bold text-xs">
              {{ state.currentProject().packaging.showCrashStructures ? 'AN' : 'AUS' }}
            </span>
          </div>

          <!-- Luggage Volume -->
          <div (click)="togglePackaging('showLuggageSpace')"
            [class.border-cyan-500]="state.currentProject().packaging.showLuggageSpace"
            [class.bg-cyan-500/10]="state.currentProject().packaging.showLuggageSpace"
            class="p-3.5 rounded-xl border border-white/10 bg-black/40 hover:border-white/20 transition cursor-pointer flex items-center justify-between">
            <div class="space-y-1">
              <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
                <mat-icon class="!w-4 !h-4 !text-base text-emerald-400">luggage</mat-icon>
                <span>Kofferraum 520 L</span>
              </div>
              <div class="text-[10px] text-neutral-500 font-sans">VDA-Quadervolumen</div>
            </div>
            <span [class.text-cyan-400]="state.currentProject().packaging.showLuggageSpace" class="font-bold text-xs">
              {{ state.currentProject().packaging.showLuggageSpace ? 'AN' : 'AUS' }}
            </span>
          </div>
        </div>
      </div>

      <!-- Technical Package Specifications -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        <!-- High Voltage & Powertrain -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3">
          <div class="font-bold text-neutral-200">HOCHVOLTSYSTEM & THERMOMANAGEMENT</div>

          <div class="space-y-2">
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex justify-between">
              <span class="text-neutral-400">Systemspannung</span>
              <span class="text-cyan-400 font-bold">800 Volt Siliziumkarbid (SiC)</span>
            </div>
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex justify-between">
              <span class="text-neutral-400">Batterie-Nettokapazität</span>
              <span class="text-neutral-200 font-bold">118 kWh (NMC90-Zellen)</span>
            </div>
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex justify-between">
              <span class="text-neutral-400">Max. DC-Ladeleistung</span>
              <span class="text-emerald-400 font-bold">320 kW (10-80% in 18 Min.)</span>
            </div>
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex justify-between">
              <span class="text-neutral-400">Antriebsstrang</span>
              <span class="text-neutral-200 font-bold">Dual-Motor Allrad 4MATIC (540 kW)</span>
            </div>
          </div>
        </div>

        <!-- Space & Dimensions -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3">
          <div class="font-bold text-neutral-200">RAUMÖKONOMIE & KOFFERRAUM (VDA)</div>

          <div class="space-y-2">
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex justify-between">
              <span class="text-neutral-400">Hauptkofferraum Heck (VDA)</span>
              <span class="text-neutral-200 font-bold">520 Liter</span>
            </div>
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex justify-between">
              <span class="text-neutral-400">Frunk (Front-Kofferraum)</span>
              <span class="text-neutral-200 font-bold">75 Liter (Kabel & Taschen)</span>
            </div>
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex justify-between">
              <span class="text-neutral-400">Batterie-Bauhöhe im Unterboden</span>
              <span class="text-cyan-400 font-bold">110 mm Ultra-Flat Pack</span>
            </div>
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex justify-between">
              <span class="text-neutral-400">Wendekreis (mit 10° Hinterachslenkung)</span>
              <span class="text-emerald-400 font-bold">10.8 Meter</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PackagingStudio {
  readonly state = inject(DesignStudioState);

  togglePackaging(key: keyof typeof this.state.currentProject.prototype.packaging) {
    this.state.updateProject((p) => {
      (p.packaging as any)[key] = !(p.packaging as any)[key];
    });
  }
}
