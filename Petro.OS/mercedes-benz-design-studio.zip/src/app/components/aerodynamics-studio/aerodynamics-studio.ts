import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-aerodynamics-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">air</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">AERODYNAMIKSTUDIO & WINDKANAL-VALIDIERUNG</h2>
            <div class="text-[11px] text-neutral-400 font-light">Numerische Strömungsschätzung, cW × A Index & Abtriebsbalance</div>
          </div>
        </div>

        <div class="px-3 py-1 rounded bg-emerald-950/80 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold flex items-center space-x-1.5">
          <mat-icon class="!w-4 !h-4 !text-base">check_circle</mat-icon>
          <span>AERO-ZIELWERT ERREICHT (cW &lt; 0.200)</span>
        </div>
      </div>

      <!-- Key Aero KPI Cards -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono">
        <!-- cW Card -->
        <div class="p-5 rounded-2xl bg-[#121622] border border-cyan-500/30 shadow-lg shadow-cyan-950/20 space-y-2">
          <div class="text-xs text-neutral-400 flex items-center justify-between">
            <span>LUFTWIDERSTANDSBEIWERT (cW)</span>
            <mat-icon class="text-cyan-400">speed</mat-icon>
          </div>
          <div class="text-3xl font-extrabold text-emerald-400 font-mono tracking-tight">
            {{ state.effectiveCw() }}
          </div>
          <div class="text-[11px] text-neutral-400 font-sans">
            Weltklasse-Luftwiderstandsbeiwert für Serien-Elektrofahrzeuge.
          </div>
        </div>

        <!-- Frontal Area A -->
        <div class="p-5 rounded-2xl bg-[#121622] border border-white/10 space-y-2">
          <div class="text-xs text-neutral-400 flex items-center justify-between">
            <span>STIRNFLÄCHE (A)</span>
            <mat-icon class="text-neutral-400">aspect_ratio</mat-icon>
          </div>
          <div class="text-3xl font-extrabold text-neutral-100 font-mono tracking-tight">
            {{ state.effectiveFrontalArea() }} <span class="text-base text-neutral-500 font-normal">m²</span>
          </div>
          <div class="text-[11px] text-neutral-400 font-sans">
            Berechnet aus Breite ({{ state.currentProject().dimensions.width }}mm) & Höhe ({{ state.currentProject().dimensions.height }}mm).
          </div>
        </div>

        <!-- cW x A Index -->
        <div class="p-5 rounded-2xl bg-[#121622] border border-white/10 space-y-2">
          <div class="text-xs text-neutral-400 flex items-center justify-between">
            <span>WIDERSTANDSINDEX (cW × A)</span>
            <mat-icon class="text-cyan-400">functions</mat-icon>
          </div>
          <div class="text-3xl font-extrabold text-cyan-400 font-mono tracking-tight">
            {{ state.effectiveCwA() }} <span class="text-base text-neutral-500 font-normal">m²</span>
          </div>
          <div class="text-[11px] text-neutral-400 font-sans">
            Direktes Maß für den Autobahn-Energieverbrauch bei 130 km/h.
          </div>
        </div>
      </div>

      <!-- Aero Optimization Features Toggles -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        <!-- Active Aerodynamics -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3">
          <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">tune</mat-icon>
            <span>AKTIVE AERODYNAMIK-ELEMENTE</span>
          </div>

          <!-- Active Flaps -->
          <div class="flex items-center justify-between p-3 rounded-lg bg-black/40 border border-white/10">
            <div>
              <div class="font-bold text-neutral-200">Aktive Kühlluft-Jalousie (AIRPANEL)</div>
              <div class="text-[10px] text-neutral-500 font-sans">Schließt Kühleröffnungen bei Teillast (-0.008 cW)</div>
            </div>
            <input type="checkbox"
              [checked]="state.currentProject().aerodynamics.activeAeroFlaps"
              (change)="updateAero('activeAeroFlaps', $any($event.target).checked)"
              class="w-4 h-4 rounded text-cyan-600 bg-neutral-900 border-white/20 cursor-pointer" />
          </div>

          <!-- Underbody Sealing -->
          <div class="flex items-center justify-between p-3 rounded-lg bg-black/40 border border-white/10">
            <div>
              <div class="font-bold text-neutral-200">Vollständig gekapselter Unterboden</div>
              <div class="text-[10px] text-neutral-500 font-sans">Ebene Unterbodenverkleidung mit Venturi-Kanälen (-0.015 cW)</div>
            </div>
            <input type="checkbox"
              [checked]="state.currentProject().aerodynamics.underbodySealed"
              (change)="updateAero('underbodySealed', $any($event.target).checked)"
              class="w-4 h-4 rounded text-cyan-600 bg-neutral-900 border-white/20 cursor-pointer" />
          </div>

          <!-- Air Curtains -->
          <div class="flex items-center justify-between p-3 rounded-lg bg-black/40 border border-white/10">
            <div>
              <div class="font-bold text-neutral-200">Air Curtains im vorderen Stoßfänger</div>
              <div class="text-[10px] text-neutral-500 font-sans">Leitet Luftstrom verwirbelungsfrei um die Vorderräder</div>
            </div>
            <input type="checkbox"
              [checked]="state.currentProject().aerodynamics.airCurtainsActive"
              (change)="updateAero('airCurtainsActive', $any($event.target).checked)"
              class="w-4 h-4 rounded text-cyan-600 bg-neutral-900 border-white/20 cursor-pointer" />
          </div>
        </div>

        <!-- Downforce & Balance -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">ABTRIEBSBALANCE @ 200 KM/H</div>

          <div class="space-y-3">
            <div>
              <div class="flex justify-between text-neutral-300">
                <span>Vorderachs-Abtrieb (Front Downforce)</span>
                <span class="text-cyan-400 font-bold">{{ state.currentProject().aerodynamics.downforceFrontKg }} kg</span>
              </div>
              <input type="range" min="0" max="120" step="5"
                [value]="state.currentProject().aerodynamics.downforceFrontKg"
                (input)="updateAero('downforceFrontKg', +$any($event.target).value)" class="w-full cursor-pointer mt-1" />
            </div>

            <div>
              <div class="flex justify-between text-neutral-300">
                <span>Hinterachs-Abtrieb (Rear Downforce)</span>
                <span class="text-cyan-400 font-bold">{{ state.currentProject().aerodynamics.downforceRearKg }} kg</span>
              </div>
              <input type="range" min="0" max="220" step="5"
                [value]="state.currentProject().aerodynamics.downforceRearKg"
                (input)="updateAero('downforceRearKg', +$any($event.target).value)" class="w-full cursor-pointer mt-1" />
            </div>

            <div class="p-2.5 rounded bg-black/40 border border-white/5 text-[11px] text-neutral-400 font-sans leading-relaxed">
              Die Abtriebsbalance von ca. 30% vorn / 70% hinten garantiert Hochgeschwindigkeitsstabilität bei Autobahnkurven oberhalb 220 km/h ohne signifikante Erhöhung des Luftwiderstands.
            </div>
          </div>
        </div>

      </div>
    </div>
  `,
})
export class AerodynamicsStudio {
  readonly state = inject(DesignStudioState);

  updateAero(key: string, val: any) {
    this.state.updateProject((p) => {
      (p.aerodynamics as any)[key] = val;
    });
  }
}
