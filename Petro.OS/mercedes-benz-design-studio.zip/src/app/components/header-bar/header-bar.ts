import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';
import { ActiveWorkspace, ProjectStatus } from '../../core/models/vehicle.model';

interface WorkspaceTab {
  id: ActiveWorkspace;
  label: string;
  icon: string;
}

@Component({
  selector: 'app-header-bar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-[#0b0e14] border-b border-white/10 text-neutral-100 flex flex-col select-none shrink-0 z-20">
      <!-- Top Title Bar -->
      <div class="h-12 px-4 flex items-center justify-between border-b border-white/5">
        <!-- Logo & Branding -->
        <div class="flex items-center space-x-3 cursor-pointer" (click)="state.setWorkspace('start')">
          <!-- Mercedes 3-pointed Star Symbol (SVG) -->
          <div class="w-7 h-7 rounded-full border border-neutral-300/80 flex items-center justify-center p-0.5 bg-gradient-to-b from-neutral-800 to-neutral-950 shadow-inner">
            <svg class="w-full h-full text-neutral-200 fill-current" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 1.8c4.52 0 8.2 3.68 8.2 8.2 0 4.52-3.68 8.2-8.2 8.2-4.52 0-8.2-3.68-8.2-8.2 0-4.52 3.68-8.2 8.2-8.2zm0 1.9l-2.7 7.5L3.6 15.6l7.7-1.7 0.7 7.1 0.7-7.1 7.7 1.7-5.7-4.4L12 5.7z"/>
            </svg>
          </div>
          <div>
            <div class="flex items-center space-x-2">
              <span class="font-bold text-sm tracking-widest text-neutral-100 font-mono">MERCEDES-BENZ</span>
              <span class="text-xs px-1.5 py-0.2 rounded bg-white/10 font-mono text-cyan-400 font-semibold tracking-wider">DESIGN STUDIO</span>
            </div>
            <div class="text-[10px] text-neutral-400 font-light tracking-wide">
              Fahrzeugentwicklung · Exterieur · Interieur · Flächendesign (2026–2030)
            </div>
          </div>
        </div>

        <!-- Center: Current Project & Version Selector -->
        <div class="flex items-center space-x-3 bg-neutral-900/80 border border-white/10 px-3 py-1 rounded-md">
          <div class="flex items-center space-x-2 text-xs">
            <span class="text-neutral-400">Projekt:</span>
            <span class="font-semibold text-neutral-100">{{ state.currentProject().name }}</span>
            <span class="text-neutral-500 font-mono text-[11px]">[{{ state.currentProject().codeName }}]</span>
          </div>

          <div class="h-3.5 w-px bg-white/10"></div>

          <!-- Version Pill -->
          <div class="flex items-center space-x-1.5 text-xs">
            <span class="text-neutral-400">Version:</span>
            <span class="px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 font-mono text-[11px]">
              {{ state.currentProject().currentVersion }}
            </span>
          </div>

          <div class="h-3.5 w-px bg-white/10"></div>

          <!-- Status Dropdown/Selector -->
          <div class="flex items-center space-x-1">
            <span class="text-neutral-400 text-xs">Status:</span>
            <select [value]="state.currentProject().status" (change)="onStatusChange($event)"
              class="bg-neutral-800 text-neutral-200 border border-white/10 rounded px-2 py-0.5 text-xs font-mono focus:outline-none focus:border-cyan-400">
              <option value="ENTWURF">ENTWURF</option>
              <option value="IN ENTWICKLUNG">IN ENTWICKLUNG</option>
              <option value="DESIGN REVIEW">DESIGN REVIEW</option>
              <option value="FREIGEGEBEN">FREIGEGEBEN</option>
              <option value="DESIGN FREEZE">DESIGN FREEZE</option>
            </select>
          </div>
        </div>

        <!-- Right: Utility Actions & Assistant -->
        <div class="flex items-center space-x-2">
          <!-- Undo / Redo -->
          <div class="flex items-center space-x-0.5 bg-neutral-900 border border-white/10 rounded p-0.5">
            <button (click)="state.undo()" title="Rückgängig (Strg+Z)" class="p-1 hover:bg-white/10 rounded text-neutral-300 transition">
              <mat-icon class="!w-4 !h-4 !text-base">undo</mat-icon>
            </button>
            <button (click)="state.redo()" title="Wiederholen (Strg+Y)" class="p-1 hover:bg-white/10 rounded text-neutral-300 transition">
              <mat-icon class="!w-4 !h-4 !text-base">redo</mat-icon>
            </button>
          </div>

          <!-- Save Snapshot Button -->
          <button (click)="state.saveVersionSnapshot('Zwischenspeicherung aus Arbeitsleiste')"
            title="Design-Version snapshotten"
            class="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 border border-white/10 text-xs font-medium flex items-center space-x-1 transition">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-cyan-400">save</mat-icon>
            <span>Snapshot</span>
          </button>

          <!-- Export .mbdesign -->
          <button (click)="state.exportMbDesignFile()"
            title=".mbdesign Projektdatei exportieren"
            class="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 border border-white/10 text-xs font-medium flex items-center space-x-1 transition">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-emerald-400">download</mat-icon>
            <span>.mbdesign</span>
          </button>

          <!-- PDF Report Export -->
          <button (click)="state.exportPdfDesignReport()"
            title="Technischen PDF Designbericht erzeugen"
            class="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 border border-white/10 text-xs font-medium flex items-center space-x-1 transition">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-rose-400">picture_as_pdf</mat-icon>
            <span>PDF Bericht</span>
          </button>

          <!-- Presentation Review Mode -->
          <button (click)="state.isReviewModeOpen.set(true)"
            title="Vollbild Design Review Präsentation"
            class="px-2.5 py-1 rounded bg-gradient-to-r from-neutral-800 to-neutral-700 hover:from-neutral-700 hover:to-neutral-600 border border-cyan-500/30 text-neutral-100 text-xs font-medium flex items-center space-x-1 transition">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm text-amber-400">fullscreen</mat-icon>
            <span>Design Review</span>
          </button>

          <!-- AI Assistant Trigger -->
          <button (click)="state.isAiAssistantOpen.set(true)"
            title="KI-Designassistent & Ingenieurexpertise öffnen"
            class="px-3 py-1 rounded bg-cyan-600/90 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-lg shadow-cyan-900/30 transition">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm animate-pulse">auto_awesome</mat-icon>
            <span>KI-Assistent</span>
          </button>
        </div>
      </div>

      <!-- Navigation Module Tabs (All Central Design Modules) -->
      <nav class="h-9 px-2 flex items-center space-x-1 overflow-x-auto bg-[#090b0f] scrollbar-none border-t border-white/5">
        @for (tab of workspaceTabs; track tab.id) {
          <button (click)="state.setWorkspace(tab.id)"
            [class.bg-white/15]="state.activeWorkspace() === tab.id"
            [class.text-cyan-300]="state.activeWorkspace() === tab.id"
            [class.font-semibold]="state.activeWorkspace() === tab.id"
            [class.border-cyan-500/40]="state.activeWorkspace() === tab.id"
            [class.text-neutral-400]="state.activeWorkspace() !== tab.id"
            class="px-2.5 py-1 rounded border border-transparent hover:border-white/10 hover:text-neutral-200 text-xs whitespace-nowrap transition flex items-center space-x-1.5">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm">{{ tab.icon }}</mat-icon>
            <span>{{ tab.label }}</span>
          </button>
        }
      </nav>
    </header>
  `,
})
export class HeaderBar {
  readonly state = inject(DesignStudioState);

  readonly workspaceTabs: WorkspaceTab[] = [
    { id: 'start', label: 'Start / Projekte', icon: 'dashboard' },
    { id: 'proportion', label: 'Proportion', icon: 'aspect_ratio' },
    { id: 'skizze', label: '2D-Skizze', icon: 'draw' },
    { id: 'karosserie3d', label: '3D-Karosserie', icon: 'view_in_ar' },
    { id: 'surface', label: 'Class-A Strak', icon: 'view_stream' },
    { id: 'clay', label: 'Digital Clay', icon: 'brush' },
    { id: 'exterieur', label: 'Exterieur', icon: 'directions_car' },
    { id: 'interieur', label: 'Interieur & Cockpit', icon: 'airline_seat_recline_extra' },
    { id: 'licht', label: 'Lichtdesign', icon: 'wb_incandescent' },
    { id: 'raeder', label: 'Räder & Felgen', icon: 'trip_origin' },
    { id: 'materialien', label: 'Farben & Material', icon: 'palette' },
    { id: 'aerodynamik', label: 'Aerodynamik cW', icon: 'air' },
    { id: 'packaging', label: 'Packaging & E-Antrieb', icon: 'battery_charging_full' },
    { id: 'rendering', label: 'Rendering & Studio', icon: 'camera_alt' },
    { id: 'varianten', label: 'Varianten', icon: 'layers' },
    { id: 'vergleich', label: 'Designvergleich', icon: 'compare' },
    { id: 'historie', label: 'Designhistorie', icon: 'history' },
  ];

  onStatusChange(e: Event) {
    const target = e.target as HTMLSelectElement;
    this.state.setProjectStatus(target.value as ProjectStatus);
  }
}
