import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-interior-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">airline_seat_recline_extra</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">INTERIEURSTUDIO, COCKPIT & ERGONOMIE</h2>
            <div class="text-[11px] text-neutral-400 font-light">Hyperscreen-Architektur, Sitzkonturierung, 64-Farben Ambientelicht & Ergonomie</div>
          </div>
        </div>
      </div>

      <!-- Cockpit & Screen Architecture -->
      <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3 font-mono text-xs">
        <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
          <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">desktop_windows</mat-icon>
          <span>INSTRUMENTENTAFEL & HYPERSCREEN</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div class="p-3 rounded-lg bg-black/40 border border-white/10 space-y-2">
            <div class="font-bold text-cyan-300">MBUX Curved Hyperscreen</div>
            <div class="text-[11px] text-neutral-400 font-sans">
              Durchgängiges 141 cm breites OLED-Glasband von A-Säule zu A-Säule mit Zero-Layer Bedienphilosophie.
            </div>
            <div class="text-[10px] text-emerald-400">Blickfeldoptimiert: 18° Neigung</div>
          </div>

          <div class="p-3 rounded-lg bg-black/40 border border-white/10 space-y-2">
            <div class="font-bold text-neutral-200">Augmented-Reality HUD</div>
            <div class="text-[11px] text-neutral-400 font-sans">
              Großflächige 77-Zoll Projektionsfläche mit 3D-Tiefenebene in 10 Metern virtueller Entfernung.
            </div>
            <div class="text-[10px] text-cyan-400">Augenellipse SAE J941 konform</div>
          </div>

          <div class="p-3 rounded-lg bg-black/40 border border-white/10 space-y-2">
            <div class="font-bold text-neutral-200">Freischwebende Mittelkonsole</div>
            <div class="text-[11px] text-neutral-400 font-sans">
              Architektonischer Raumgewinn durch Wegfall des Kardantunnels auf der reinen Elektroplattform.
            </div>
            <div class="text-[10px] text-cyan-400">14 Liter Ablagevolumen</div>
          </div>
        </div>
      </div>

      <!-- Ambient Lighting 64 Colors & Seating -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        
        <!-- Ambient Light Studio -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200 flex items-center justify-between">
            <span>64-FARBEN AKTIVE AMBIENTEBELEUCHTUNG</span>
            <div class="w-3.5 h-3.5 rounded-full shadow-lg" [style.background-color]="state.currentProject().lighting.ambientColor"></div>
          </div>

          <!-- Color Swatches -->
          <div class="grid grid-cols-6 gap-2">
            @for (ac of ambientColors; track ac.color) {
              <button (click)="updateAmbientColor(ac.color)"
                [style.background-color]="ac.color"
                [class.ring-2]="state.currentProject().lighting.ambientColor === ac.color"
                [class.ring-white]="state.currentProject().lighting.ambientColor === ac.color"
                class="h-8 rounded-lg border border-white/20 hover:scale-105 transition cursor-pointer shadow-md"
                [title]="ac.name">
              </button>
            }
          </div>

          <!-- Ambient Intensity -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Lichtintensität</span>
              <span class="text-cyan-400 font-bold">{{ (state.currentProject().lighting.ambientIntensity * 100).toFixed(0) }}%</span>
            </div>
            <input type="range" min="0.1" max="1.0" step="0.05"
              [value]="state.currentProject().lighting.ambientIntensity"
              (input)="updateAmbientIntensity(+$any($event.target).value)" class="w-full cursor-pointer" />
          </div>
        </div>

        <!-- Seat & Ergonomics -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">SITZKONZEPT & ERGONOMISCHE VALIDIERUNG</div>

          <div class="space-y-2.5">
            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">Fahrersitz-Konturierung</div>
                <div class="text-[10px] text-neutral-500 font-sans">Multikontursitz mit 10-Kammer-Massage & ENERGIZING Comfort</div>
              </div>
              <span class="text-cyan-400 font-bold">Aktiv</span>
            </div>

            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">Reichweiten-Ergonomie (Reach)</div>
                <div class="text-[10px] text-neutral-500 font-sans">Alle Primärbedienelemente innerhalb 450 mm Armkreis</div>
              </div>
              <span class="text-emerald-400 font-bold">100% 95th Percentile</span>
            </div>

            <div class="p-2.5 rounded bg-black/40 border border-white/5 flex items-center justify-between">
              <div>
                <div class="font-bold text-neutral-200">Fond-Beinfreiheit</div>
                <div class="text-[10px] text-neutral-500 font-sans">Knieraum bei aktuellem Radstand ({{ state.currentProject().dimensions.wheelbase }} mm)</div>
              </div>
              <span class="text-cyan-400 font-bold">+185 mm vs. Standard</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  `,
})
export class InteriorStudio {
  readonly state = inject(DesignStudioState);

  readonly ambientColors = [
    { name: 'EQ Electric Cyan', color: '#00d2ff' },
    { name: 'AMG Performance Red', color: '#ff2d55' },
    { name: 'Maybach Kalahari Gold', color: '#e5a93c' },
    { name: 'Solaris Warm Amber', color: '#ff9500' },
    { name: 'Smaragd Green', color: '#30d158' },
    { name: 'Deep Space Violet', color: '#bf5af2' },
  ];

  updateAmbientColor(color: string) {
    this.state.updateProject((p) => {
      p.lighting.ambientColor = color;
    });
  }

  updateAmbientIntensity(val: number) {
    this.state.updateProject((p) => {
      p.lighting.ambientIntensity = val;
    });
  }
}
