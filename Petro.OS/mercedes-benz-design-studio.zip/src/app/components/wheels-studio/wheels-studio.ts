import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-wheels-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">trip_origin</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">RAD- & REIFENDESIGN</h2>
            <div class="text-[11px] text-neutral-400 font-light">Felgendimensionen, Speichendesign, Aero-Blades & Hochleistungs-Bremsanlagen</div>
          </div>
        </div>
      </div>

      <!-- Rim Diameter Selector -->
      <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3 font-mono text-xs">
        <div class="font-bold text-neutral-200 flex items-center justify-between">
          <span>FELGENDURCHMESSER (ZOLLGRÖSSEN)</span>
          <span class="text-cyan-400 font-bold text-sm">{{ state.currentProject().wheels.diameterInches }} ZOLL</span>
        </div>

        <div class="grid grid-cols-6 gap-2">
          @for (d of [18, 19, 20, 21, 22, 23]; track d) {
            <button (click)="updateWheel('diameterInches', d)"
              [class.bg-cyan-500/20]="state.currentProject().wheels.diameterInches === d"
              [class.text-cyan-300]="state.currentProject().wheels.diameterInches === d"
              [class.border-cyan-500/50]="state.currentProject().wheels.diameterInches === d"
              [class.bg-black/40]="state.currentProject().wheels.diameterInches !== d"
              class="py-3 rounded-lg border border-white/10 hover:border-cyan-500/30 text-center font-bold text-sm transition cursor-pointer">
              {{ d }}"
            </button>
          }
        </div>
      </div>

      <!-- Rim Style & Finish Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        
        <!-- Rim Designs -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">SPEICHENDESIGN & FELGENKONZEPT</div>

          <div class="space-y-2">
            @for (style of rimStyles; track style.id) {
              <button (click)="updateWheel('rimStyle', style.id)"
                [class.bg-cyan-500/10]="state.currentProject().wheels.rimStyle === style.id"
                [class.border-cyan-500/40]="state.currentProject().wheels.rimStyle === style.id"
                class="w-full p-3 rounded-lg bg-black/40 border border-white/10 hover:border-white/20 transition text-left flex items-center justify-between cursor-pointer">
                <div>
                  <div class="font-bold text-neutral-200">{{ style.name }}</div>
                  <div class="text-[10px] text-neutral-500 font-sans mt-0.5">{{ style.desc }}</div>
                </div>
                <span class="text-cyan-400 font-bold text-[11px]">{{ style.tag }}</span>
              </button>
            }
          </div>
        </div>

        <!-- Finish & Calipers -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">OBERFLÄCHENFINISH & BREMSEN</div>

          <!-- Finish -->
          <div class="space-y-1">
            <label class="block text-neutral-400">FELGENOBERFLÄCHE</label>
            <div class="grid grid-cols-2 gap-2">
              @for (fin of rimFinishes; track fin.id) {
                <button (click)="updateWheel('rimFinish', fin.id)"
                  [class.bg-cyan-500/20]="state.currentProject().wheels.rimFinish === fin.id"
                  [class.text-cyan-300]="state.currentProject().wheels.rimFinish === fin.id"
                  class="p-2.5 rounded border border-white/10 hover:bg-white/10 transition text-left">
                  <div class="font-bold">{{ fin.name }}</div>
                </button>
              }
            </div>
          </div>

          <!-- Caliper Color -->
          <div class="space-y-1.5 pt-2">
            <label class="block text-neutral-400">AMG HOCHLEISTUNGS-BREMSSÄTTEL</label>
            <div class="grid grid-cols-5 gap-2">
              @for (cal of caliperColors; track cal.id) {
                <button (click)="updateWheel('caliperColor', cal.id)"
                  [class.ring-2]="state.currentProject().wheels.caliperColor === cal.id"
                  [class.ring-white]="state.currentProject().wheels.caliperColor === cal.id"
                  class="p-2 rounded-lg border border-white/10 text-center transition cursor-pointer flex flex-col items-center space-y-1"
                  [style.background-color]="cal.hex + '22'">
                  <div class="w-3.5 h-3.5 rounded-full shadow" [style.background-color]="cal.hex"></div>
                  <span class="text-[10px] text-neutral-300 font-bold">{{ cal.name }}</span>
                </button>
              }
            </div>
          </div>

          <!-- Tire Width & Profile -->
          <div class="grid grid-cols-2 gap-3 pt-2">
            <div>
              <div class="flex justify-between text-neutral-300 text-[11px]">
                <span>Reifenbreite:</span>
                <span class="text-cyan-400 font-bold">{{ state.currentProject().wheels.tireWidthMm }} mm</span>
              </div>
              <input type="range" min="245" max="325" step="10"
                [value]="state.currentProject().wheels.tireWidthMm"
                (input)="updateWheel('tireWidthMm', +$any($event.target).value)" class="w-full cursor-pointer mt-1" />
            </div>

            <div>
              <div class="flex justify-between text-neutral-300 text-[11px]">
                <span>Querschnitt:</span>
                <span class="text-cyan-400 font-bold">/{{ state.currentProject().wheels.tireProfileRatio }} R{{ state.currentProject().wheels.diameterInches }}</span>
              </div>
              <input type="range" min="25" max="45" step="5"
                [value]="state.currentProject().wheels.tireProfileRatio"
                (input)="updateWheel('tireProfileRatio', +$any($event.target).value)" class="w-full cursor-pointer mt-1" />
            </div>
          </div>
        </div>

      </div>
    </div>
  `,
})
export class WheelsStudio {
  readonly state = inject(DesignStudioState);

  readonly rimStyles = [
    { id: 'amg-multispoke-forged', name: 'AMG Vielspeichen-Schmiederad', desc: 'Gewichtsoptimiertes Leichtmetallrad im Rennsport-Design', tag: 'AMG' },
    { id: 'eq-aero-blade', name: 'EQ Aero Blade Turbine', desc: 'Aerodynamisch geschlossene Turbinenflügel für cW-Reduktion', tag: '-0.005 cW' },
    { id: 'maybach-monoblock-disc', name: 'Maybach Monoblock Scheibenrad', desc: 'Hochglanzpolierte geschmiedete Luxusscheibe', tag: 'MAYBACH' },
    { id: 'gt-centerlock-y-spoke', name: 'AMG GT Zentralverschluss Y-Speiche', desc: 'Motorsport-Zentralverschluss mit Y-Doppelspeichen', tag: 'CENTERLOCK' },
  ];

  readonly rimFinishes = [
    { id: 'bi-color-machined-black', name: 'Bicolor Glanzgedreht Schwarz' },
    { id: 'titanium-satin', name: 'Titangrau Seidenmatt' },
    { id: 'high-gloss-silver', name: 'High-Gloss Alusilber' },
    { id: 'manufaktur-rosegold', name: 'MANUFAKTUR Roségold' },
  ];

  readonly caliperColors = [
    { id: 'amg-gold-ceramic', name: 'Gold Keramik', hex: '#daa520' },
    { id: 'amg-red', name: 'AMG Rot', hex: '#d91424' },
    { id: 'eq-electric-blue', name: 'Electric Cyan', hex: '#00d2ff' },
    { id: 'stealth-black', name: 'Stealth Schwarz', hex: '#1a1a1a' },
    { id: 'manufaktur-yellow', name: 'Gelb', hex: '#ffcc00' },
  ];

  updateWheel(key: string, val: any) {
    this.state.updateProject((p) => {
      (p.wheels as any)[key] = val;
    });
  }
}
