import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-material-color-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">palette</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">FARBEN- & MATERIALSTUDIO (MANUFAKTUR)</h2>
            <div class="text-[11px] text-neutral-400 font-light">Exterieurlacke, Alubeam Liquid Metal, Magno-Mattlacke & Interieurwerkstoffe</div>
          </div>
        </div>

        <div class="flex items-center space-x-2">
          <span class="text-xs font-mono text-neutral-400">Aktiver Lack:</span>
          <span class="px-2.5 py-1 rounded bg-neutral-900 border border-white/10 text-cyan-300 font-mono text-xs font-bold">
            {{ state.currentProject().materials.paintName }}
          </span>
        </div>
      </div>

      <!-- Exterior Paint Colors Catalog -->
      <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3 font-mono text-xs">
        <div class="font-bold text-neutral-200">MERCEDES-BENZ & MANUFAKTUR FARBPALETTE</div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          @for (paint of paintCatalog; track paint.name) {
            <button (click)="applyPaint(paint)"
              [class.border-cyan-400]="state.currentProject().materials.paintColor === paint.color"
              [class.ring-2]="state.currentProject().materials.paintColor === paint.color"
              [class.ring-cyan-500/30]="state.currentProject().materials.paintColor === paint.color"
              class="p-3 rounded-xl border border-white/10 hover:border-white/30 bg-black/40 transition text-left flex flex-col justify-between space-y-3 cursor-pointer">
              
              <!-- Color Sphere / Swatch -->
              <div class="h-14 rounded-lg w-full shadow-inner border border-white/10 flex items-center justify-center relative overflow-hidden"
                [style.background-color]="paint.color">
                <div class="absolute inset-0 bg-gradient-to-tr from-black/40 via-transparent to-white/30"></div>
                @if (paint.finish === 'alubeam-liquid-metal') {
                  <span class="relative z-10 px-2 py-0.5 rounded bg-black/60 text-[10px] text-cyan-300 font-bold border border-cyan-400/30">ALUBEAM</span>
                } @else if (paint.finish === 'magno-matt') {
                  <span class="relative z-10 px-2 py-0.5 rounded bg-black/60 text-[10px] text-neutral-300 font-bold border border-white/20">MAGNO MATT</span>
                }
              </div>

              <div>
                <div class="font-bold text-neutral-100 text-[11px] leading-tight">{{ paint.name }}</div>
                <div class="text-[10px] text-neutral-500 font-sans mt-0.5 capitalize">{{ paint.finish }}</div>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Physical Shader Material Parameters -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        
        <!-- PBR Shading Knobs -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
            <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">tune</mat-icon>
            <span>PHYSIKALISCHE LACK-PARAMETER (PBR)</span>
          </div>

          <!-- Roughness -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Rauheit (Roughness)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().materials.roughness }}</span>
            </div>
            <input type="range" min="0.02" max="0.6" step="0.02"
              [value]="state.currentProject().materials.roughness"
              (input)="updateMat('roughness', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>

          <!-- Metalness -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Metallizität (Metalness)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().materials.metalness }}</span>
            </div>
            <input type="range" min="0.1" max="1.0" step="0.05"
              [value]="state.currentProject().materials.metalness"
              (input)="updateMat('metalness', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>

          <!-- Clearcoat -->
          <div class="space-y-1">
            <div class="flex justify-between text-neutral-300">
              <span>Klarlackschicht (Clearcoat)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().materials.clearcoat }}</span>
            </div>
            <input type="range" min="0.0" max="1.0" step="0.05"
              [value]="state.currentProject().materials.clearcoat"
              (input)="updateMat('clearcoat', +$any($event.target).value)" class="w-full cursor-pointer" />
          </div>
        </div>

        <!-- Trims & Interior Materials -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">ZIERELEMENTE & INTERIEURSTOFFE</div>

          <!-- Trim Material -->
          <div class="space-y-1">
            <label class="block text-neutral-400">EXTERIEUR ZIERLEISTEN</label>
            <div class="grid grid-cols-3 gap-2">
              @for (tm of trimMaterials; track tm.id) {
                <button (click)="updateMat('trimMaterial', tm.id)"
                  [class.bg-cyan-500/20]="state.currentProject().materials.trimMaterial === tm.id"
                  [class.text-cyan-300]="state.currentProject().materials.trimMaterial === tm.id"
                  class="p-2 rounded border border-white/10 hover:bg-white/10 transition text-center text-[10px]">
                  {{ tm.name }}
                </button>
              }
            </div>
          </div>

          <!-- Interior Leather -->
          <div class="space-y-1 pt-2">
            <label class="block text-neutral-400">NAPPALEDER EXKLUSIV</label>
            <div class="grid grid-cols-2 gap-2">
              @for (l of leatherStyles; track l.id) {
                <button (click)="updateMat('interiorLeather', l.id)"
                  [class.bg-cyan-500/20]="state.currentProject().materials.interiorLeather === l.id"
                  [class.text-cyan-300]="state.currentProject().materials.interiorLeather === l.id"
                  class="p-2 rounded border border-white/10 hover:bg-white/10 transition text-left text-[11px]">
                  {{ l.name }}
                </button>
              }
            </div>
          </div>
        </div>

      </div>
    </div>
  `,
})
export class MaterialColorStudio {
  readonly state = inject(DesignStudioState);

  readonly paintCatalog = [
    { name: 'MANUFAKTUR Obsidianschwarz Metallic', color: '#10141a', finish: 'alubeam-liquid-metal', roughness: 0.1, metalness: 0.95 },
    { name: 'MANUFAKTUR Hyazinthrot Magno', color: '#5c0f16', finish: 'magno-matt', roughness: 0.38, metalness: 0.88 },
    { name: 'Alubeam Liquid Silver Chrome', color: '#d2d8e0', finish: 'alubeam-liquid-metal', roughness: 0.05, metalness: 1.0 },
    { name: 'Selenitgrau Magno Matt', color: '#686e76', finish: 'magno-matt', roughness: 0.42, metalness: 0.85 },
    { name: 'MANUFAKTUR Nautikblau Deep', color: '#09152a', finish: 'metallic', roughness: 0.12, metalness: 0.92 },
    { name: 'AMG Solarbeam Liquid Gold', color: '#d6a800', finish: 'alubeam-liquid-metal', roughness: 0.1, metalness: 0.95 },
    { name: 'MANUFAKTUR Smaragdgrün Metallic', color: '#142920', finish: 'metallic', roughness: 0.14, metalness: 0.9 },
    { name: 'MANUFAKTUR Diamantweiß Bright', color: '#eef3f7', finish: 'perleffekt', roughness: 0.15, metalness: 0.75 },
  ];

  readonly trimMaterials = [
    { id: 'brushed-aluminum', name: 'Aluminium Gebürstet' },
    { id: 'dark-chrome', name: 'Dark Chrome' },
    { id: 'gloss-black-nightpack', name: 'Night-Paket Schwarz' },
    { id: 'carbon-weave', name: 'Carbon Gewebe' },
    { id: 'rosegold', name: 'Roségold Maybach' },
  ];

  readonly leatherStyles = [
    { id: 'nappa-manufaktur-deep-white', name: 'Nappa Tiefweiß MANUFAKTUR' },
    { id: 'nappa-saddle-brown', name: 'Nappa Sattelbraun Exklusiv' },
    { id: 'nappa-black-anthracite', name: 'Nappa Titanschwarz / Anthrazit' },
    { id: 'nappa-macchiato-beige', name: 'Nappa Macchiatobeige' },
  ];

  applyPaint(p: any) {
    this.state.updateProject((proj) => {
      proj.materials.paintColor = p.color;
      proj.materials.paintName = p.name;
      proj.materials.paintFinish = p.finish;
      proj.materials.roughness = p.roughness;
      proj.materials.metalness = p.metalness;
    });
  }

  updateMat(key: string, val: any) {
    this.state.updateProject((proj) => {
      (proj.materials as any)[key] = val;
    });
  }
}
