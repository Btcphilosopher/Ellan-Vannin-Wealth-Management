import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-design-history',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">history</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">DESIGNHISTORIE & VERSIONSPROTOKOLL</h2>
            <div class="text-[11px] text-neutral-400 font-light">Lückenlose Nachverfolgung aller Geometrie-, Strak- und Aerodynamikänderungen</div>
          </div>
        </div>

        <button (click)="createSnapshotPrompt()"
          class="px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-lg shadow-cyan-950/30 transition cursor-pointer">
          <mat-icon class="!w-3.5 !h-3.5 !text-sm">add_circle</mat-icon>
          <span>Neuen Versionsstand einfrieren</span>
        </button>
      </div>

      <!-- Timeline Entries -->
      <div class="space-y-3 font-mono text-xs">
        @for (h of state.currentProject().history; track h.id) {
          <div class="p-4 rounded-xl border border-white/10 bg-[#12151d] space-y-3 relative overflow-hidden">
            <div class="flex items-center justify-between border-b border-white/5 pb-2">
              <div class="flex items-center space-x-2">
                <span class="px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300 font-bold">
                  {{ h.versionCode }}
                </span>
                <span class="font-bold text-neutral-200">{{ h.snapshotName }}</span>
              </div>
              <div class="text-[11px] text-neutral-500">
                {{ h.timestamp | date:'dd.MM.yyyy HH:mm' }} · {{ h.author }}
              </div>
            </div>

            <p class="text-[11px] text-neutral-300 font-sans leading-relaxed">{{ h.comment }}</p>

            <!-- Metrics Bar -->
            <div class="grid grid-cols-4 gap-2 pt-2 border-t border-white/5 text-[10px] text-neutral-400">
              <div class="bg-black/30 p-2 rounded">
                <span class="text-neutral-500">cW-Wert: </span>
                <span class="text-emerald-400 font-bold">{{ h.metrics.cw }}</span>
              </div>
              <div class="bg-black/30 p-2 rounded">
                <span class="text-neutral-500">Länge: </span>
                <span class="text-neutral-200 font-bold">{{ h.metrics.length }} mm</span>
              </div>
              <div class="bg-black/30 p-2 rounded">
                <span class="text-neutral-500">Radstand: </span>
                <span class="text-neutral-200 font-bold">{{ h.metrics.wheelbase }} mm</span>
              </div>
              <div class="bg-black/30 p-2 rounded">
                <span class="text-neutral-500">Gewichtsschätzung: </span>
                <span class="text-neutral-200 font-bold">{{ h.metrics.weightEstKg }} kg</span>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class DesignHistory {
  readonly state = inject(DesignStudioState);

  createSnapshotPrompt() {
    const comment = prompt('Kommentar zur neuen Design-Version:', 'Strak- und Aerodynamikoptimierung');
    if (comment !== null) {
      this.state.saveVersionSnapshot(comment);
    }
  }
}
