import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from '../../core/services/design-studio-state';

@Component({
  selector: 'app-lighting-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0b0e14] text-neutral-100 overflow-y-auto font-sans p-4 space-y-4">
      <div class="flex items-center justify-between border-b border-white/10 pb-3">
        <div class="flex items-center space-x-2">
          <mat-icon class="text-cyan-400">wb_incandescent</mat-icon>
          <div>
            <h2 class="text-sm font-bold font-mono tracking-wider">DIGITALES LICHTDESIGN & SIGNATUREN</h2>
            <div class="text-[11px] text-neutral-400 font-light">Digital Light Scheinwerfer, DRL-Signaturen & 3D Helix Heckleuchtenband</div>
          </div>
        </div>

        <div class="flex items-center space-x-2">
          <button (click)="toggleLights('headlightsOn')"
            [class.bg-cyan-500/20]="state.currentProject().lighting.headlightsOn"
            [class.text-cyan-300]="state.currentProject().lighting.headlightsOn"
            class="px-3 py-1.5 rounded-lg border border-white/10 text-xs font-mono flex items-center space-x-1.5 cursor-pointer">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm">light_mode</mat-icon>
            <span>Hauptscheinwerfer: {{ state.currentProject().lighting.headlightsOn ? 'AN' : 'AUS' }}</span>
          </button>

          <button (click)="toggleLights('drlOn')"
            [class.bg-cyan-500/20]="state.currentProject().lighting.drlOn"
            [class.text-cyan-300]="state.currentProject().lighting.drlOn"
            class="px-3 py-1.5 rounded-lg border border-white/10 text-xs font-mono flex items-center space-x-1.5 cursor-pointer">
            <mat-icon class="!w-3.5 !h-3.5 !text-sm">flare</mat-icon>
            <span>Tagfahrlicht: {{ state.currentProject().lighting.drlOn ? 'AN' : 'AUS' }}</span>
          </button>
        </div>
      </div>

      <!-- DRL Signatures Selection Grid -->
      <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-3 font-mono text-xs">
        <div class="font-bold text-neutral-200 flex items-center space-x-1.5">
          <mat-icon class="!w-4 !h-4 !text-base text-cyan-400">auto_fix_high</mat-icon>
          <span>TAGFAHRLICHT-SIGNATUR (PARAMETRISCHE VARIANTEN)</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          @for (sig of drlSignatures; track sig.id) {
            <button (click)="updateLighting('dRLSignature', sig.id)"
              [class.bg-cyan-500/20]="state.currentProject().lighting.dRLSignature === sig.id"
              [class.text-cyan-300]="state.currentProject().lighting.dRLSignature === sig.id"
              [class.border-cyan-500/50]="state.currentProject().lighting.dRLSignature === sig.id"
              [class.bg-black/40]="state.currentProject().lighting.dRLSignature !== sig.id"
              [class.text-neutral-400]="state.currentProject().lighting.dRLSignature !== sig.id"
              class="p-3.5 rounded-xl border border-white/10 hover:border-cyan-500/30 transition text-left flex flex-col justify-between space-y-3 cursor-pointer">
              <div class="flex items-center justify-between">
                <span class="font-bold text-neutral-200">{{ sig.name }}</span>
                @if (state.currentProject().lighting.dRLSignature === sig.id) {
                  <span class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
                }
              </div>

              <!-- Mini visual representation -->
              <div class="h-10 rounded bg-black/60 border border-white/5 flex items-center justify-center p-1">
                <div [class]="sig.cssPattern" class="h-1 w-4/5 rounded-full bg-cyan-400 shadow-[0_0_8px_#00d2ff]"></div>
              </div>

              <div class="text-[10px] text-neutral-500 font-sans leading-tight">{{ sig.desc }}</div>
            </button>
          }
        </div>
      </div>

      <!-- Headlamp Tech & Light Temp -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
        <!-- Headlamp Technology -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">SCHEINWERFER-TECHNOLOGIE</div>

          <div class="space-y-2">
            @for (tech of headlampTechs; track tech.id) {
              <div (click)="updateLighting('headlampTech', tech.id)"
                [class.bg-cyan-500/10]="state.currentProject().lighting.headlampTech === tech.id"
                [class.border-cyan-500/40]="state.currentProject().lighting.headlampTech === tech.id"
                class="p-3 rounded-lg bg-black/40 border border-white/10 hover:border-white/20 transition cursor-pointer flex items-center justify-between">
                <div>
                  <div class="font-bold text-neutral-200">{{ tech.name }}</div>
                  <div class="text-[10px] text-neutral-500 font-sans mt-0.5">{{ tech.spec }}</div>
                </div>
                <span class="text-cyan-400 font-bold text-[11px]">{{ tech.res }}</span>
              </div>
            }
          </div>
        </div>

        <!-- Rear Light & Color Temp -->
        <div class="p-4 rounded-xl bg-[#11141d] border border-white/5 space-y-4">
          <div class="font-bold text-neutral-200">HECKLEUCHTE & LICHTFARBE</div>

          <div class="space-y-1">
            <label class="block text-neutral-400">HECKLEUCHTEN-ARCHITEKTUR</label>
            <div class="grid grid-cols-3 gap-2">
              @for (rl of rearSignatures; track rl.id) {
                <button (click)="updateLighting('rearLightSignature', rl.id)"
                  [class.bg-rose-500/20]="state.currentProject().lighting.rearLightSignature === rl.id"
                  [class.text-rose-300]="state.currentProject().lighting.rearLightSignature === rl.id"
                  class="p-2 rounded border border-white/10 hover:bg-white/10 transition text-center text-[11px]">
                  {{ rl.name }}
                </button>
              }
            </div>
          </div>

          <!-- Color Temperature Slider -->
          <div class="space-y-1 pt-2">
            <div class="flex justify-between text-neutral-300">
              <span>Farbtemperatur (Color Temp)</span>
              <span class="text-cyan-400 font-bold">{{ state.currentProject().lighting.lightTemperatureK }} Kelvin</span>
            </div>
            <input type="range" min="4500" max="7500" step="100"
              [value]="state.currentProject().lighting.lightTemperatureK"
              (input)="updateLighting('lightTemperatureK', +$any($event.target).value)" class="w-full cursor-pointer" />
            <div class="flex justify-between text-[10px] text-neutral-500">
              <span>4500 K (Warmweiß)</span>
              <span>6200 K (Tageslichtweiß)</span>
              <span>7500 K (Laser Kaltblau)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class LightingStudio {
  readonly state = inject(DesignStudioState);

  readonly drlSignatures = [
    {
      id: 'sig-a-star-arch',
      name: 'Signatur A — Star Arch',
      desc: 'Geschwungener Sternen-Bogen mit zentralem Tagfahrlichtsteg.',
      cssPattern: 'border-t-2 border-cyan-400',
    },
    {
      id: 'sig-b-twin-eyebrow',
      name: 'Signatur B — Twin Eyebrow',
      desc: 'Doppelschwung-Fackelsignatur mit progressiver Lichtführung.',
      cssPattern: 'border-y-2 border-cyan-400',
    },
    {
      id: 'sig-c-continuous-lightband',
      name: 'Signatur C — EQ One-Bow Lightbar',
      desc: 'Durchgängiges horizontales LED-Band über die gesamte Fahrzeugbreite.',
      cssPattern: 'h-1.5 w-full bg-cyan-400',
    },
    {
      id: 'sig-d-amg-horizontal-slits',
      name: 'Signatur D — AMG Twin Blades',
      desc: 'Aggressive doppelte Horizontalschlitze für High-Performance Modelle.',
      cssPattern: 'space-y-1',
    },
  ];

  readonly headlampTechs = [
    { id: 'digital-light-micro-mirror', name: 'Digital Light (DMD Micro-Mirror)', spec: '1,3 Millionen Mikrospiegel pro Scheinwerfer mit Symbolprojektion', res: '2.6 Mio px' },
    { id: 'laser-projection', name: 'Ultra-Range Laser High-Beam', spec: 'Laser-Fernlicht mit 650 m Reichweite und selektivem Matrix-Dimming', res: '650m Reichweite' },
    { id: 'multibeam-led', name: 'High-Performance Multibeam LED', spec: '84 einzeln ansteuerbare Präzisions-LEDs je Scheinwerfereinheit', res: '84 LEDs' },
  ];

  readonly rearSignatures = [
    { id: '3d-helix-lightband', name: '3D Helix Band' },
    { id: 'star-cluster-continuous', name: 'Sternen-Cluster' },
    { id: 'matrix-ribbon', name: 'Matrix Ribbon' },
  ];

  updateLighting(key: string, val: any) {
    this.state.updateProject((p) => {
      (p.lighting as any)[key] = val;
    });
  }

  toggleLights(key: 'headlightsOn' | 'drlOn') {
    this.state.updateProject((p) => {
      p.lighting[key] = !p.lighting[key];
    });
  }
}
