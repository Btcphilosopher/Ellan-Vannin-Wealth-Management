import {
  ChangeDetectionStrategy,
  Component,
  HostListener,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DesignStudioState } from './core/services/design-studio-state';
import { HeaderBar } from './components/header-bar/header-bar';
import { Viewport3d } from './components/viewport-3d/viewport-3d';
import { StartScreen } from './components/start-screen/start-screen';
import { ProportionStudio } from './components/proportion-studio/proportion-studio';
import { SketchStudio } from './components/sketch-studio/sketch-studio';
import { ClayStudio } from './components/clay-studio/clay-studio';
import { SurfaceAnalysis } from './components/surface-analysis/surface-analysis';
import { ExteriorStudio } from './components/exterior-studio/exterior-studio';
import { InteriorStudio } from './components/interior-studio/interior-studio';
import { LightingStudio } from './components/lighting-studio/lighting-studio';
import { WheelsStudio } from './components/wheels-studio/wheels-studio';
import { MaterialColorStudio } from './components/material-color-studio/material-color-studio';
import { AerodynamicsStudio } from './components/aerodynamics-studio/aerodynamics-studio';
import { PackagingStudio } from './components/packaging-studio/packaging-studio';
import { RenderingStudio } from './components/rendering-studio/rendering-studio';
import { VariantsCompare } from './components/variants-compare/variants-compare';
import { DesignHistory } from './components/design-history/design-history';
import { AiAssistantModal } from './components/ai-assistant-modal/ai-assistant-modal';
import { DesignReviewModal } from './components/design-review-modal/design-review-modal';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderBar,
    Viewport3d,
    StartScreen,
    ProportionStudio,
    SketchStudio,
    ClayStudio,
    SurfaceAnalysis,
    ExteriorStudio,
    InteriorStudio,
    LightingStudio,
    WheelsStudio,
    MaterialColorStudio,
    AerodynamicsStudio,
    PackagingStudio,
    RenderingStudio,
    VariantsCompare,
    DesignHistory,
    AiAssistantModal,
    DesignReviewModal,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly state = inject(DesignStudioState);
  readonly isSidePanelExpanded = signal<boolean>(true);

  @HostListener('window:keydown', ['$event'])
  handleKeyboardShortcuts(e: KeyboardEvent) {
    // Ignore when typing inside input or textarea
    const target = e.target as HTMLElement;
    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT') {
      return;
    }

    if (e.ctrlKey || e.metaKey) {
      if (e.key === 'z' || e.key === 'Z') {
        e.preventDefault();
        if (e.shiftKey) {
          this.state.redo();
        } else {
          this.state.undo();
        }
      } else if (e.key === 'y' || e.key === 'Y') {
        e.preventDefault();
        this.state.redo();
      } else if (e.key === 's' || e.key === 'S') {
        e.preventDefault();
        this.state.saveVersionSnapshot('Tastatur-Snapshot');
      }
      return;
    }

    // Direct key shortcuts
    switch (e.key.toLowerCase()) {
      case 'p':
        this.state.setWorkspace('proportion');
        break;
      case 's':
        this.state.setWorkspace('skizze');
        break;
      case 'c':
        this.state.setWorkspace('clay');
        break;
      case 'm':
        this.state.setWorkspace('materialien');
        break;
      case 'l':
        this.state.setWorkspace('licht');
        break;
      case 'a':
        this.state.setWorkspace('aerodynamik');
        break;
      case 'v':
        this.state.setWorkspace('varianten');
        break;
      case 'h':
        this.state.setWorkspace('historie');
        break;
    }
  }

  toggleSidePanel() {
    this.isSidePanelExpanded.update((v) => !v);
  }
}
