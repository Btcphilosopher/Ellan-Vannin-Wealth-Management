export type ProjectStatus = 'ENTWURF' | 'IN ENTWICKLUNG' | 'DESIGN REVIEW' | 'FREIGEGEBEN' | 'DESIGN FREEZE';

export type VehicleClass = 
  | 'Luxuslimousine'
  | 'Limousine'
  | 'Coupé'
  | 'Cabriolet'
  | 'Kombi'
  | 'SUV'
  | 'Crossover'
  | 'Sportwagen'
  | 'Gran Turismo'
  | 'Van'
  | 'Kleinwagen'
  | 'Konzeptfahrzeug'
  | 'Nutzfahrzeug';

export type DriveConcept = 
  | 'EQ-Dual-eATS-Allrad (800V)'
  | 'EQ-Single-Heckantrieb'
  | 'AMG-High-Performance-Hybrid'
  | 'Solid-State-Electric-Platform'
  | 'V8-Biturbo-E-Performance';

export type ActiveWorkspace = 
  | 'start'
  | 'proportion'
  | 'skizze'
  | 'karosserie3d'
  | 'surface'
  | 'clay'
  | 'exterieur'
  | 'interieur'
  | 'licht'
  | 'raeder'
  | 'materialien'
  | 'aerodynamik'
  | 'packaging'
  | 'rendering'
  | 'varianten'
  | 'vergleich'
  | 'historie'
  | 'review';

export interface VehicleDimensions {
  wheelbase: number; // mm (e.g. 3210)
  length: number; // mm (e.g. 5230)
  width: number; // mm (e.g. 1960)
  height: number; // mm (e.g. 1450)
  frontOverhang: number; // mm (e.g. 860)
  rearOverhang: number; // mm (e.g. 1160)
  trackWidthFront: number; // mm (e.g. 1680)
  trackWidthRear: number; // mm (e.g. 1690)
  groundClearance: number; // mm (e.g. 135)
  aPillarAngle: number; // deg (e.g. 27.5)
  cPillarAngle: number; // deg (e.g. 24.0)
  roofApexRatio: number; // 0.0 - 1.0 (e.g. 0.46)
  waistlineHeight: number; // mm (e.g. 980)
  shoulderTumblehome: number; // mm (e.g. 35)
  tumblehomeAngle: number; // deg (e.g. 18.0)
  hoodDipRatio: number; // 0.0 - 1.0
}

export interface ExteriorStyling {
  grilleStyle: 'panamericana' | 'eq-blackpanel-star' | 'avantgarde-slat' | 'maybach-pinstripe' | 'aero-flush';
  hoodPowerdomes: boolean;
  doorHandles: 'flush-retractable' | 'aerodynamic-recess' | 'sensor-touch';
  mirrorStyle: 'digital-camera-aerowings' | 'sculptural-mirrors';
  rearSpoiler: 'active-integrated-wing' | 'ducktail-lip' | 'aero-diffuser-flush';
  glassRoofType: 'panoramic-electrochromic' | 'split-glass' | 'solid-lightweight-carbon';
  frontSplitterCarbon: boolean;
  rearDiffuserFins: number; // 2, 4, 6
  sideSkirtsFlared: boolean;
}

export interface LightingConfig {
  headlampTech: 'digital-light-micro-mirror' | 'multibeam-led' | 'laser-projection';
  dRLSignature: 'sig-a-star-arch' | 'sig-b-twin-eyebrow' | 'sig-c-continuous-lightband' | 'sig-d-amg-horizontal-slits';
  rearLightSignature: '3d-helix-lightband' | 'star-cluster-continuous' | 'matrix-ribbon';
  lightTemperatureK: number; // e.g. 6000
  ambientColor: string; // hex
  ambientIntensity: number; // 0.0 - 1.0
  headlightsOn: boolean;
  drlOn: boolean;
  hazardLightsOn: boolean;
}

export interface WheelConfig {
  diameterInches: 18 | 19 | 20 | 21 | 22 | 23;
  rimStyle: 'amg-multispoke-forged' | 'eq-aero-blade' | 'maybach-monoblock-disc' | 'gt-centerlock-y-spoke';
  rimFinish: 'bi-color-machined-black' | 'titanium-satin' | 'high-gloss-silver' | 'manufaktur-rosegold';
  tireWidthMm: number; // 245 - 315
  tireProfileRatio: number; // 30 - 45
  caliperColor: 'amg-gold-ceramic' | 'amg-red' | 'eq-electric-blue' | 'stealth-black' | 'manufaktur-yellow';
}

export interface MaterialConfig {
  paintColor: string;
  paintName: string;
  paintFinish: 'metallic' | 'magno-matt' | 'perleffekt' | 'alubeam-liquid-metal' | 'two-tone-maybach';
  paintClearcoat: 'high-gloss' | 'satin-matt';
  secondaryColor?: string;
  roughness: number; // 0.0 - 1.0
  metalness: number; // 0.0 - 1.0
  clearcoat: number; // 0.0 - 1.0
  trimMaterial: 'brushed-aluminum' | 'dark-chrome' | 'gloss-black-nightpack' | 'carbon-weave' | 'rosegold';
  glassTint: 'subtle-emerald' | 'pure-smoke' | 'privacy-black' | 'solar-silver-reflective';
  interiorLeather: 'nappa-saddle-brown' | 'nappa-manufaktur-deep-white' | 'nappa-black-anthracite' | 'nappa-macchiato-beige';
  interiorTrim: 'open-pore-anthracite-oak' | 'flowing-lines-walnut' | 'forged-carbon' | 'piano-black-glass';
}

export interface AerodynamicData {
  cw: number; // e.g. 0.198
  frontalArea: number; // m² (e.g. 2.24)
  downforceFrontKg: number;
  downforceRearKg: number;
  activeAeroFlaps: boolean;
  underbodySealed: boolean;
  airCurtainsActive: boolean;
}

export interface PackagingConfig {
  showBatteryPack: boolean;
  showMotors: boolean;
  showInverterHV: boolean;
  showSuspensionAir: boolean;
  showCrashStructures: boolean;
  showOccupantsDummies: boolean;
  showLuggageSpace: boolean;
  batteryCapacityKwh: number; // e.g. 118
  motorCount: number; // 1, 2, 3, 4
  trunkVolumeLiters: number; // e.g. 520
  frunkVolumeLiters: number; // e.g. 65
}

export interface ClayDeformationPoint {
  id: string;
  x: number;
  y: number;
  z: number;
  dx: number;
  dy: number;
  dz: number;
  radius: number;
  operation: string;
}

export interface ClayConfig {
  activeTool: 'build-up' | 'carve' | 'smooth' | 'pull' | 'push' | 'inflate' | 'pinch' | 'relax';
  toolRadius: number; // 20 - 250 mm
  toolIntensity: number; // 0.1 - 1.0
  toolFalloff: 'gaussian' | 'linear' | 'smoothstep';
  symmetryX: boolean;
  subdivisionLevel: number;
  deformations: ClayDeformationPoint[];
}

export interface ClassAAnalysisConfig {
  mode: 'standard-pbr' | 'zebra-stripes' | 'curvature-gauss' | 'mean-curvature' | 'highlight-lines' | 'reflection-studio';
  zebraFrequency: number;
  zebraAngle: number;
  zebraSharpness: number;
  highlightLineWidth: number;
  showContinuityLabels: boolean;
}

export interface DesignHistoryEntry {
  id: string;
  versionCode: string; // e.g. DESIGN_001
  timestamp: string;
  author: string;
  comment: string;
  snapshotName: string;
  metrics: {
    cw: number;
    length: number;
    wheelbase: number;
    weightEstKg: number;
  };
}

export interface VehicleVariant {
  id: string;
  name: string;
  code: string;
  description: string;
  bodyStyle: VehicleClass;
  dimensions: VehicleDimensions;
  materials: MaterialConfig;
  wheels: WheelConfig;
  lights: LightingConfig;
  exterior: ExteriorStyling;
  aerodynamics: AerodynamicData;
  updatedAt: string;
}

export interface DesignAnnotation {
  id: string;
  author: string;
  position: [number, number, number];
  text: string;
  category: 'Styling' | 'Aerodynamik' | 'Class-A' | 'Packaging' | 'Ergonomie';
  resolved: boolean;
  timestamp: string;
}

export interface VehicleProject {
  id: string;
  name: string;
  codeName: string;
  status: ProjectStatus;
  vehicleClass: VehicleClass;
  driveConcept: DriveConcept;
  designer: string;
  team: string;
  currentVersion: string;
  createdAt: string;
  updatedAt: string;
  dimensions: VehicleDimensions;
  exterior: ExteriorStyling;
  lighting: LightingConfig;
  wheels: WheelConfig;
  materials: MaterialConfig;
  aerodynamics: AerodynamicData;
  packaging: PackagingConfig;
  clay: ClayConfig;
  surfaceAnalysis: ClassAAnalysisConfig;
  variants: VehicleVariant[];
  history: DesignHistoryEntry[];
  annotations: DesignAnnotation[];
  sketchLayers: { [plane: string]: string }; // Base64 dataUrls
}
