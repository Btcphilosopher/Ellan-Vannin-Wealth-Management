import * as THREE from 'three';
import { VehicleProject } from '../models/vehicle.model';

export interface VehicleSceneBuild {
  rootGroup: THREE.Group;
  bodyMesh: THREE.Mesh;
  glazingMesh: THREE.Mesh;
  wheelsGroup: THREE.Group;
  lightsGroup: THREE.Group;
  interiorGroup: THREE.Group;
  packagingGroup: THREE.Group;
  aerodynamicsGroup: THREE.Group;
  frontGrilleMesh: THREE.Object3D;
  bodyMaterial: THREE.Material;
  zebraMaterial: THREE.ShaderMaterial;
  clayMaterial: THREE.MeshStandardMaterial;
  bodyGeometry: THREE.BufferGeometry;
  basePositions: Float32Array; // Original unmodified positions for clay deformation
}

/**
 * Custom Class-A Zebra Reflection Striping Shader
 */
export function createZebraShaderMaterial(frequency: number = 14.0, angle: number = 45.0, sharpness: number = 0.8): THREE.ShaderMaterial {
  const rad = (angle * Math.PI) / 180.0;
  return new THREE.ShaderMaterial({
    uniforms: {
      uFrequency: { value: frequency },
      uAngleDir: { value: new THREE.Vector2(Math.cos(rad), Math.sin(rad)) },
      uSharpness: { value: sharpness },
      uColor1: { value: new THREE.Color(0x0a0a0c) },
      uColor2: { value: new THREE.Color(0xf0f4f8) },
    },
    vertexShader: `
      varying vec3 vNormal;
      varying vec3 vViewPosition;
      void main() {
        vNormal = normalize(normalMatrix * normal);
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        vViewPosition = -mvPosition.xyz;
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: `
      uniform float uFrequency;
      uniform vec2 uAngleDir;
      uniform float uSharpness;
      uniform vec3 uColor1;
      uniform vec3 uColor2;
      varying vec3 vNormal;
      varying vec3 vViewPosition;

      void main() {
        vec3 normal = normalize(vNormal);
        vec3 viewDir = normalize(vViewPosition);
        vec3 refl = reflect(-viewDir, normal);
        
        // Project reflection vector onto screen-plane zebra stripes
        float stripe = dot(refl.xy, uAngleDir) * uFrequency;
        float val = sin(stripe * 3.14159265);
        float edge = smoothstep(-1.0 + uSharpness, 1.0 - uSharpness, val);
        
        // Rim highlight
        float rim = 1.0 - max(dot(viewDir, normal), 0.0);
        vec3 col = mix(uColor1, uColor2, edge);
        col += pow(rim, 3.0) * 0.15;
        
        gl_FragColor = vec4(col, 1.0);
      }
    `,
    side: THREE.DoubleSide,
  });
}

/**
 * Builds the complete parametric Mercedes-Benz 3D Vehicle representation
 */
export function buildVehicleScene(project: VehicleProject): VehicleSceneBuild {
  const rootGroup = new THREE.Group();
  rootGroup.name = 'MercedesBenzVehicleRoot';

  // Real world coordinates conversion: mm to meters (1000mm = 1.0m)
  const d = project.dimensions;
  const L = d.length / 1000;
  const W = d.width / 1000;
  const H = d.height / 1000;
  const WB = d.wheelbase / 1000;
  const FO = d.frontOverhang / 1000;
  const RO = d.rearOverhang / 1000;
  const GC = d.groundClearance / 1000;
  const halfW = W / 2;

  // 1. CAR BODY GEOMETRY (Parametric NURBS-like Hull with Subdivision)
  const { geometry: bodyGeometry, basePositions } = generateParametricBodyGeometry(project);
  
  // Create Paint Material
  const bodyMaterial = createAutomotivePaintMaterial(project);
  const zebraMaterial = createZebraShaderMaterial(
    project.surfaceAnalysis.zebraFrequency,
    project.surfaceAnalysis.zebraAngle,
    project.surfaceAnalysis.zebraSharpness
  );

  const clayMaterial = new THREE.MeshStandardMaterial({
    color: 0x9e6a4b, // Italian Industrial Styling Clay Terra-Cotta
    roughness: 0.65,
    metalness: 0.05,
    bumpScale: 0.02,
    flatShading: false,
    side: THREE.DoubleSide
  });

  const activeMaterial = project.clay.activeTool && project.clay.deformations.length > 0 
    ? (project.surfaceAnalysis.mode === 'zebra-stripes' ? zebraMaterial : bodyMaterial)
    : (project.surfaceAnalysis.mode === 'zebra-stripes' ? zebraMaterial : bodyMaterial);

  const bodyMesh = new THREE.Mesh(bodyGeometry, activeMaterial);
  bodyMesh.name = 'CarrosserieHullMesh';
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  rootGroup.add(bodyMesh);

  // Apply any stored clay deformations
  applyClayDeformationsToGeometry(bodyGeometry, basePositions, project.clay.deformations);

  // 2. GLAZING (Windshield, Glass Roof, Side Windows, Rear Screen)
  const glazingMesh = generateGlazingMesh(project);
  rootGroup.add(glazingMesh);

  // 3. WHEELS & BRAKES
  const wheelsGroup = generateWheelsAndBrakes(project);
  rootGroup.add(wheelsGroup);

  // 4. FRONT FASCIA & GRILLE
  const frontGrilleMesh = generateFrontGrille(project);
  rootGroup.add(frontGrilleMesh);

  // 5. LIGHTING FIXTURES & DRL SIGNATURES
  const lightsGroup = generateLightingFixtures(project);
  rootGroup.add(lightsGroup);

  // 6. INTERIOR COCKPIT (Hyperscreen, Seats, Console)
  const interiorGroup = generateInteriorCockpit(project);
  rootGroup.add(interiorGroup);

  // 7. PACKAGING X-RAY COMPONENTS (Battery, eATS Motors, HV cabling, Dummies, Trunk)
  const packagingGroup = generatePackagingComponents(project);
  rootGroup.add(packagingGroup);

  // 8. AERODYNAMICS WIND-TUNNEL STREAMLINES
  const aerodynamicsGroup = generateAerodynamicStreamlines(project);
  rootGroup.add(aerodynamicsGroup);

  return {
    rootGroup,
    bodyMesh,
    glazingMesh,
    wheelsGroup,
    lightsGroup,
    interiorGroup,
    packagingGroup,
    aerodynamicsGroup,
    frontGrilleMesh,
    bodyMaterial,
    zebraMaterial,
    clayMaterial,
    bodyGeometry,
    basePositions,
  };
}

/**
 * Creates physical automotive paint material with clearcoat
 */
export function createAutomotivePaintMaterial(project: VehicleProject): THREE.MeshPhysicalMaterial {
  const m = project.materials;
  const col = new THREE.Color(m.paintColor);
  
  const isMatt = m.paintFinish === 'magno-matt';
  const isAlubeam = m.paintFinish === 'alubeam-liquid-metal';

  return new THREE.MeshPhysicalMaterial({
    color: col,
    roughness: isMatt ? 0.38 : (isAlubeam ? 0.08 : m.roughness),
    metalness: isAlubeam ? 0.98 : m.metalness,
    clearcoat: isMatt ? 0.2 : m.clearcoat,
    clearcoatRoughness: isMatt ? 0.5 : 0.06,
    reflectivity: 0.95,
    envMapIntensity: 1.4,
    side: THREE.DoubleSide,
  });
}

/**
 * Parametric car body hull mesh generation
 */
function generateParametricBodyGeometry(project: VehicleProject): { geometry: THREE.BufferGeometry; basePositions: Float32Array } {
  const d = project.dimensions;
  const L = d.length / 1000;
  const W = d.width / 1000;
  const H = d.height / 1000;
  const WB = d.wheelbase / 1000;
  const FO = d.frontOverhang / 1000;
  const RO = d.rearOverhang / 1000;
  const GC = d.groundClearance / 1000;
  const apex = d.roofApexRatio;
  const tumble = (d.shoulderTumblehome / 1000);

  // Grid resolution along length (Z) and perimeter (X/Y)
  const segmentsZ = 64;
  const segmentsU = 48; // Circumference profile

  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const zStart = L / 2; // Front bumper
  const zEnd = -L / 2;  // Rear bumper

  // Wheel center positions
  const zFrontAxle = zStart - FO;
  const zRearAxle = zFrontAxle - WB;
  const wheelRadius = ((project.wheels.diameterInches * 0.0254) / 2) + 0.12;

  // Generate vertices slice by slice
  for (let i = 0; i <= segmentsZ; i++) {
    const tZ = i / segmentsZ;
    const z = zStart - tZ * L;

    // Evaluate longitudinal cross-section parameters at Z
    let heightFactor = 1.0;
    let widthFactor = 1.0;
    let groundOffset = GC;

    // Roof arc & hood curve
    if (z > zFrontAxle) {
      // Hood area
      const tHood = (z - zFrontAxle) / FO;
      heightFactor = GC + (H - GC) * 0.52 * (1.0 - Math.pow(tHood, 1.4) * 0.35);
      widthFactor = (W / 2) * (1.0 - Math.pow(tHood, 2.0) * 0.18);
    } else if (z >= zRearAxle) {
      // Passenger cabin area
      const tCabin = (zFrontAxle - z) / WB;
      const arc = Math.sin(tCabin * Math.PI);
      const roofPeak = H * (1.0 - (1.0 - apex) * 0.1);
      heightFactor = GC + (H - GC) * (0.55 + 0.45 * Math.sin(Math.pow(tCabin, 0.85) * Math.PI));
      widthFactor = (W / 2) * (0.95 + 0.05 * arc);
    } else {
      // Rear trunk & diffuser area
      const tTrunk = (zRearAxle - z) / RO;
      const isShootingBrake = project.vehicleClass === 'Kombi' || project.vehicleClass === 'SUV';
      const rearHeightDrop = isShootingBrake ? 0.25 : 0.48;
      heightFactor = GC + (H - GC) * (0.75 - Math.pow(tTrunk, 1.2) * rearHeightDrop);
      widthFactor = (W / 2) * (0.98 - Math.pow(tTrunk, 1.8) * 0.22);
    }

    // Powerdomes on hood
    const hasPowerdomes = project.exterior.hoodPowerdomes && z > zFrontAxle;

    // Circumference profile from rocker panel (bottom left) -> side flank -> shoulder -> roof -> right side
    for (let j = 0; j <= segmentsU; j++) {
      const u = j / segmentsU; // 0 to 1
      const angle = (u - 0.5) * Math.PI; // -PI/2 (bottom) to +PI/2 (bottom other side) via roof at 0
      
      const symmetrySign = Math.sign(Math.sin(angle));
      const absSin = Math.abs(Math.sin(angle));
      const cosAngle = Math.cos(angle);

      // Local cross section coordinates
      let localX = Math.sin(angle) * widthFactor;
      let localY = groundOffset + cosAngle * (heightFactor - groundOffset);

      // Flank contour: widen shoulder line and tuck tumblehome inward near roof
      if (cosAngle > 0.6) {
        // Tumblehome near roof
        localX *= (1.0 - (cosAngle - 0.6) * tumble * 2.2);
      } else if (cosAngle > 0.2 && cosAngle <= 0.6) {
        // Muscular shoulder line
        localX *= 1.025;
      }

      // Wheel arch cutouts
      const distFrontWheel = Math.abs(z - zFrontAxle);
      const distRearWheel = Math.abs(z - zRearAxle);
      if ((distFrontWheel < wheelRadius * 1.15 || distRearWheel < wheelRadius * 1.15) && cosAngle < 0.45) {
        // Arch flare
        localX += symmetrySign * 0.035;
      }

      // Powerdome bump on hood center
      if (hasPowerdomes && cosAngle > 0.85 && Math.abs(localX) > 0.15 && Math.abs(localX) < 0.5) {
        localY += 0.025 * Math.sin((Math.abs(localX) - 0.15) / 0.35 * Math.PI);
      }

      // Side skirts flare
      if (project.exterior.sideSkirtsFlared && cosAngle < 0.15 && z > zRearAxle && z < zFrontAxle) {
        localX += symmetrySign * 0.03;
      }

      positions.push(localX, localY, z);
      uvs.push(u, tZ);
    }
  }

  // Generate triangle faces
  for (let i = 0; i < segmentsZ; i++) {
    for (let j = 0; j < segmentsU; j++) {
      const a = i * (segmentsU + 1) + j;
      const b = (i + 1) * (segmentsU + 1) + j;
      const c = (i + 1) * (segmentsU + 1) + (j + 1);
      const d = i * (segmentsU + 1) + (j + 1);

      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();

  const basePositions = new Float32Array(positions);

  return { geometry, basePositions };
}

/**
 * Applies Digital Clay deformations to vertices with Gaussian/Linear Falloff and Bilateral Symmetry
 */
export function applyClayDeformationsToGeometry(
  geometry: THREE.BufferGeometry,
  basePositions: Float32Array,
  deformations: { x: number; y: number; z: number; dx: number; dy: number; dz: number; radius: number }[]
) {
  const posAttr = geometry.getAttribute('position') as THREE.BufferAttribute;
  const count = posAttr.count;

  // Reset to pristine base mesh
  for (let i = 0; i < count * 3; i++) {
    posAttr.array[i] = basePositions[i];
  }

  if (!deformations || deformations.length === 0) {
    posAttr.needsUpdate = true;
    geometry.computeVertexNormals();
    return;
  }

  for (let i = 0; i < count; i++) {
    const vx = posAttr.getX(i);
    const vy = posAttr.getY(i);
    const vz = posAttr.getZ(i);

    let accumDx = 0;
    let accumDy = 0;
    let accumDz = 0;

    for (const d of deformations) {
      const dist = Math.hypot(vx - d.x, vy - d.y, vz - d.z);
      if (dist < d.radius) {
        const factor = Math.exp(-Math.pow(dist / (d.radius * 0.6), 2.0));
        accumDx += d.dx * factor;
        accumDy += d.dy * factor;
        accumDz += d.dz * factor;
      }

      // Bilateral Symmetry (Mirrored across X=0 plane)
      const mirrorDist = Math.hypot(vx - (-d.x), vy - d.y, vz - d.z);
      if (mirrorDist < d.radius) {
        const factor = Math.exp(-Math.pow(mirrorDist / (d.radius * 0.6), 2.0));
        accumDx += -d.dx * factor;
        accumDy += d.dy * factor;
        accumDz += d.dz * factor;
      }
    }

    posAttr.setXYZ(i, vx + accumDx, vy + accumDy, vz + accumDz);
  }

  posAttr.needsUpdate = true;
  geometry.computeVertexNormals();
}

/**
 * Glazing generation (Tinted Windshield, Panoramic Roof, Side Glass)
 */
function generateGlazingMesh(project: VehicleProject): THREE.Mesh {
  const d = project.dimensions;
  const L = d.length / 1000;
  const W = d.width / 1000;
  const H = d.height / 1000;
  const WB = d.wheelbase / 1000;
  const FO = d.frontOverhang / 1000;
  const zFrontAxle = L / 2 - FO;
  const zRearAxle = zFrontAxle - WB;

  // Curved glass cockpit canopy
  const glassGeo = new THREE.CylinderGeometry(
    (W * 0.42),
    (W * 0.46),
    WB * 0.85,
    32,
    16,
    true,
    -Math.PI * 0.48,
    Math.PI * 0.96
  );
  glassGeo.rotateX(Math.PI / 2);
  glassGeo.rotateZ(Math.PI / 2);

  const glassMaterial = new THREE.MeshPhysicalMaterial({
    color: project.materials.glassTint === 'subtle-emerald' ? 0x051a14 : 0x08090b,
    transparent: true,
    opacity: 0.72,
    roughness: 0.04,
    metalness: 0.1,
    transmission: 0.78,
    ior: 1.52,
    reflectivity: 0.9,
    clearcoat: 1.0,
    side: THREE.DoubleSide
  });

  const glassMesh = new THREE.Mesh(glassGeo, glassMaterial);
  glassMesh.position.set(0, H * 0.68, zFrontAxle - WB * 0.52);
  glassMesh.name = 'CanopyGlazingMesh';
  return glassMesh;
}

/**
 * Wheels, Rims, Tires, and AMG Calipers
 */
function generateWheelsAndBrakes(project: VehicleProject): THREE.Group {
  const group = new THREE.Group();
  group.name = 'WheelsAndChassisGroup';

  const d = project.dimensions;
  const L = d.length / 1000;
  const W = d.width / 1000;
  const WB = d.wheelbase / 1000;
  const FO = d.frontOverhang / 1000;
  const trackF = (d.trackWidthFront / 1000) / 2;
  const trackR = (d.trackWidthRear / 1000) / 2;

  const rimDiameterM = (project.wheels.diameterInches * 0.0254);
  const tireRadius = rimDiameterM / 2 + 0.11;
  const tireWidth = project.wheels.tireWidthMm / 1000;

  const zF = L / 2 - FO;
  const zR = zF - WB;
  const yHub = tireRadius;

  const wheelPositions = [
    { x: -trackF, y: yHub, z: zF, isFront: true, isLeft: true },
    { x: trackF, y: yHub, z: zF, isFront: true, isLeft: false },
    { x: -trackR, y: yHub, z: zR, isFront: false, isLeft: true },
    { x: trackR, y: yHub, z: zR, isFront: false, isLeft: false },
  ];

  const tireMaterial = new THREE.MeshStandardMaterial({
    color: 0x141518,
    roughness: 0.85,
    metalness: 0.08,
  });

  const rimMaterial = new THREE.MeshStandardMaterial({
    color: project.wheels.rimFinish === 'manufaktur-rosegold' ? 0xd4a574 : (project.wheels.rimFinish === 'titanium-satin' ? 0x6e7278 : 0xcccccc),
    metalness: 0.92,
    roughness: project.wheels.rimFinish.includes('satin') ? 0.35 : 0.12,
  });

  const discMaterial = new THREE.MeshStandardMaterial({
    color: 0x888888,
    metalness: 0.95,
    roughness: 0.25,
  });

  const caliperColors = {
    'amg-gold-ceramic': 0xdaa520,
    'amg-red': 0xd91424,
    'eq-electric-blue': 0x00d2ff,
    'stealth-black': 0x1a1a1a,
    'manufaktur-yellow': 0xffcc00,
  };
  const caliperMaterial = new THREE.MeshStandardMaterial({
    color: caliperColors[project.wheels.caliperColor] || 0xdaa520,
    metalness: 0.85,
    roughness: 0.2,
  });

  wheelPositions.forEach((wp, idx) => {
    const wheelAssembly = new THREE.Group();
    wheelAssembly.position.set(wp.x, wp.y, wp.z);

    // Tire
    const tireGeo = new THREE.TorusGeometry(tireRadius - 0.05, 0.058, 24, 48);
    const tireMesh = new THREE.Mesh(tireGeo, tireMaterial);
    tireMesh.rotation.y = Math.PI / 2;
    tireMesh.castShadow = true;
    wheelAssembly.add(tireMesh);

    // Rim Outer Barrel
    const rimBarrelGeo = new THREE.CylinderGeometry(rimDiameterM / 2, rimDiameterM / 2, tireWidth * 0.9, 32);
    rimBarrelGeo.rotateZ(Math.PI / 2);
    const rimBarrel = new THREE.Mesh(rimBarrelGeo, rimMaterial);
    wheelAssembly.add(rimBarrel);

    // Spokes Pattern
    const spokesCount = project.wheels.rimStyle === 'amg-multispoke-forged' ? 14 : (project.wheels.rimStyle === 'gt-centerlock-y-spoke' ? 10 : 5);
    for (let s = 0; s < spokesCount; s++) {
      const spokeAngle = (s / spokesCount) * Math.PI * 2;
      const spokeGeo = new THREE.BoxGeometry(0.018, rimDiameterM * 0.46, 0.02);
      const spoke = new THREE.Mesh(spokeGeo, rimMaterial);
      spoke.position.set(wp.isLeft ? -0.04 : 0.04, Math.sin(spokeAngle) * (rimDiameterM * 0.22), Math.cos(spokeAngle) * (rimDiameterM * 0.22));
      spoke.rotation.x = spokeAngle;
      wheelAssembly.add(spoke);
    }

    // Brake Disc
    const discGeo = new THREE.CylinderGeometry(rimDiameterM * 0.38, rimDiameterM * 0.38, 0.015, 32);
    discGeo.rotateZ(Math.PI / 2);
    const disc = new THREE.Mesh(discGeo, discMaterial);
    wheelAssembly.add(disc);

    // AMG Brake Caliper
    const caliperGeo = new THREE.BoxGeometry(0.045, 0.12, 0.06);
    const caliper = new THREE.Mesh(caliperGeo, caliperMaterial);
    caliper.position.set(wp.isLeft ? 0.02 : -0.02, rimDiameterM * 0.26, 0.04);
    wheelAssembly.add(caliper);

    group.add(wheelAssembly);
  });

  return group;
}

/**
 * Front Grille & Mercedes-Benz Star Matrix
 */
function generateFrontGrille(project: VehicleProject): THREE.Group {
  const group = new THREE.Group();
  group.name = 'FrontFasciaAndGrille';

  const d = project.dimensions;
  const L = d.length / 1000;
  const W = d.width / 1000;
  const H = d.height / 1000;
  const zNose = L / 2 + 0.01;
  const yGrille = d.groundClearance / 1000 + 0.35;

  const style = project.exterior.grilleStyle;

  if (style === 'panamericana') {
    // AMG Panamericana Vertical Louvers
    const grilleFrameGeo = new THREE.BoxGeometry(W * 0.58, 0.36, 0.08);
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.9, roughness: 0.1 });
    const frame = new THREE.Mesh(grilleFrameGeo, frameMat);
    frame.position.set(0, yGrille, zNose);
    group.add(frame);

    const louverMat = new THREE.MeshStandardMaterial({ color: 0xd0d0d0, metalness: 0.95, roughness: 0.15 });
    for (let i = -6; i <= 6; i++) {
      const louver = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.32, 0.04), louverMat);
      louver.position.set(i * (W * 0.042), yGrille, zNose + 0.03);
      group.add(louver);
    }
  } else {
    // EQ Black Panel with Star Pattern or Maybach
    const panelGeo = new THREE.BoxGeometry(W * 0.62, 0.34, 0.06);
    const panelMat = new THREE.MeshPhysicalMaterial({
      color: 0x07080a,
      roughness: 0.05,
      metalness: 0.2,
      clearcoat: 1.0,
      reflectivity: 0.98,
    });
    const panel = new THREE.Mesh(panelGeo, panelMat);
    panel.position.set(0, yGrille, zNose);
    group.add(panel);
  }

  // Central Illuminated Mercedes Star Badge
  const starRingGeo = new THREE.TorusGeometry(0.09, 0.012, 16, 32);
  const starMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: 0x00d2ff,
    emissiveIntensity: project.lighting.drlOn ? 0.9 : 0.1,
    metalness: 0.95,
    roughness: 0.1
  });
  const star = new THREE.Mesh(starRingGeo, starMat);
  star.position.set(0, yGrille, zNose + 0.045);
  group.add(star);

  // 3 Star points
  for (let p = 0; p < 3; p++) {
    const pointAngle = (p / 3) * Math.PI * 2 + Math.PI / 2;
    const pointGeo = new THREE.BoxGeometry(0.012, 0.08, 0.008);
    const starPoint = new THREE.Mesh(pointGeo, starMat);
    starPoint.position.set(Math.cos(pointAngle) * 0.04, yGrille + Math.sin(pointAngle) * 0.04, zNose + 0.045);
    starPoint.rotation.z = pointAngle - Math.PI / 2;
    group.add(starPoint);
  }

  return group;
}

/**
 * Lighting Fixtures: Digital Light Matrix, Star Arch DRL, 3D Helix Rear Light Ribbon
 */
function generateLightingFixtures(project: VehicleProject): THREE.Group {
  const group = new THREE.Group();
  group.name = 'DigitalLightGroup';

  const d = project.dimensions;
  const L = d.length / 1000;
  const W = d.width / 1000;
  const zNose = L / 2;
  const zRear = -L / 2;
  const yHeadlight = d.groundClearance / 1000 + 0.44;

  const l = project.lighting;
  const drlColor = new THREE.Color(0xdffff);
  const rearColor = new THREE.Color(0xff1225);

  const headlampMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: l.headlightsOn ? 0xd0f0ff : 0x111111,
    emissiveIntensity: l.headlightsOn ? 2.5 : 0.0,
    metalness: 0.9,
    roughness: 0.1
  });

  const drlMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: l.drlOn ? 0x00d2ff : 0x222222,
    emissiveIntensity: l.drlOn ? 2.0 : 0.0,
    metalness: 0.5,
    roughness: 0.2
  });

  const rearMat = new THREE.MeshStandardMaterial({
    color: 0xff0022,
    emissive: 0xff0820,
    emissiveIntensity: 2.2,
    metalness: 0.3,
    roughness: 0.2
  });

  // Left & Right Front Headlights (Digital Light)
  [-1, 1].forEach((side) => {
    const headlampGeo = new THREE.BoxGeometry(W * 0.16, 0.06, 0.12);
    const headlamp = new THREE.Mesh(headlampGeo, headlampMat);
    headlamp.position.set(side * (W * 0.36), yHeadlight, zNose - 0.04);
    group.add(headlamp);

    // DRL Signature Eyebrow/Star Arch
    const drlGeo = new THREE.CylinderGeometry(0.012, 0.012, W * 0.18, 16);
    drlGeo.rotateZ(Math.PI / 2);
    const drl = new THREE.Mesh(drlGeo, drlMat);
    drl.position.set(side * (W * 0.36), yHeadlight + 0.04, zNose + 0.01);
    group.add(drl);
  });

  // Continuous Full-Width Front Lightband
  if (l.dRLSignature === 'sig-c-continuous-lightband' || l.dRLSignature === 'sig-a-star-arch') {
    const lightbandGeo = new THREE.BoxGeometry(W * 0.72, 0.014, 0.02);
    const lightband = new THREE.Mesh(lightbandGeo, drlMat);
    lightband.position.set(0, yHeadlight + 0.04, zNose + 0.02);
    group.add(lightband);
  }

  // Rear 3D Helix Continuous Lightband
  const rearRibbonGeo = new THREE.BoxGeometry(W * 0.84, 0.038, 0.04);
  const rearRibbon = new THREE.Mesh(rearRibbonGeo, rearMat);
  rearRibbon.position.set(0, yHeadlight + 0.12, zRear + 0.02);
  group.add(rearRibbon);

  return group;
}

/**
 * Interior Cockpit & Hyperscreen visible through glass
 */
function generateInteriorCockpit(project: VehicleProject): THREE.Group {
  const group = new THREE.Group();
  group.name = 'InteriorCockpitGroup';

  const d = project.dimensions;
  const L = d.length / 1000;
  const W = d.width / 1000;
  const H = d.height / 1000;
  const WB = d.wheelbase / 1000;
  const FO = d.frontOverhang / 1000;
  const zF = L / 2 - FO;
  const yFloor = d.groundClearance / 1000 + 0.18;

  // Curved MBUX Hyperscreen (OLED glass curved display spanning A-pillar to A-pillar)
  const screenGeo = new THREE.BoxGeometry(W * 0.75, 0.22, 0.04);
  const screenMat = new THREE.MeshPhysicalMaterial({
    color: 0x050810,
    emissive: 0x0088cc,
    emissiveIntensity: 0.65,
    roughness: 0.05,
    metalness: 0.8,
    clearcoat: 1.0,
  });
  const screen = new THREE.Mesh(screenGeo, screenMat);
  screen.position.set(0, yFloor + 0.48, zF - WB * 0.28);
  screen.rotation.x = -Math.PI * 0.12;
  group.add(screen);

  // Ergonomic Front Sport Contour Seats
  const leatherMat = new THREE.MeshStandardMaterial({
    color: project.materials.interiorLeather === 'nappa-manufaktur-deep-white' ? 0xe8edf2 : (project.materials.interiorLeather === 'nappa-saddle-brown' ? 0x6e3b1c : 0x1f2429),
    roughness: 0.72,
    metalness: 0.1,
  });

  [-1, 1].forEach((side) => {
    const seatBaseGeo = new THREE.BoxGeometry(0.48, 0.14, 0.52);
    const seatBase = new THREE.Mesh(seatBaseGeo, leatherMat);
    seatBase.position.set(side * 0.38, yFloor + 0.16, zF - WB * 0.44);
    group.add(seatBase);

    const seatBackGeo = new THREE.BoxGeometry(0.46, 0.58, 0.12);
    const seatBack = new THREE.Mesh(seatBackGeo, leatherMat);
    seatBack.position.set(side * 0.38, yFloor + 0.48, zF - WB * 0.62);
    seatBack.rotation.x = Math.PI * 0.08;
    group.add(seatBack);
  });

  return group;
}

/**
 * Packaging X-Ray layer (EVA 800V Underbody Battery, Dual eATS Motors, HV Inverter, Dummies, Luggage)
 */
function generatePackagingComponents(project: VehicleProject): THREE.Group {
  const group = new THREE.Group();
  group.name = 'PackagingXRayGroup';

  const d = project.dimensions;
  const L = d.length / 1000;
  const W = d.width / 1000;
  const WB = d.wheelbase / 1000;
  const FO = d.frontOverhang / 1000;
  const zF = L / 2 - FO;
  const zR = zF - WB;
  const yFloor = d.groundClearance / 1000 + 0.04;

  const pkg = project.packaging;

  // 1. Skateboard Battery Pack (118 kWh with cooling channels)
  if (pkg.showBatteryPack) {
    const batGeo = new THREE.BoxGeometry(W * 0.78, 0.14, WB * 0.72);
    const batMat = new THREE.MeshStandardMaterial({
      color: 0x1c3b57,
      emissive: 0x0055aa,
      emissiveIntensity: 0.4,
      roughness: 0.3,
      metalness: 0.85,
      wireframe: false
    });
    const battery = new THREE.Mesh(batGeo, batMat);
    battery.position.set(0, yFloor + 0.07, zF - WB * 0.5);
    group.add(battery);
  }

  // 2. Electric Drive Units (eATS Motors with copper windings)
  if (pkg.showMotors) {
    const motorMat = new THREE.MeshStandardMaterial({
      color: 0xcd7f32, // Copper & Aluminum
      metalness: 0.9,
      roughness: 0.2
    });

    // Front Motor
    const fMotor = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.44, 24), motorMat);
    fMotor.rotation.z = Math.PI / 2;
    fMotor.position.set(0, yFloor + 0.18, zF);
    group.add(fMotor);

    // Rear Motor
    const rMotor = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.52, 24), motorMat);
    rMotor.rotation.z = Math.PI / 2;
    rMotor.position.set(0, yFloor + 0.2, zR);
    group.add(rMotor);
  }

  // 3. Crash Absorber Crumple Zones (Aluminum extrusion structures)
  if (pkg.showCrashStructures) {
    const crashMat = new THREE.MeshStandardMaterial({ color: 0xffaa00, metalness: 0.6, roughness: 0.3 });
    [-1, 1].forEach((side) => {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.12, FO * 0.75), crashMat);
      rail.position.set(side * 0.42, yFloor + 0.22, zF + FO * 0.4);
      group.add(rail);
    });
  }

  // 4. Luggage Enclosure (Trunk Volume)
  if (pkg.showLuggageSpace) {
    const trunkGeo = new THREE.BoxGeometry(W * 0.68, 0.42, (d.rearOverhang / 1000) * 0.65);
    const trunkMat = new THREE.MeshBasicMaterial({ color: 0x00ff88, wireframe: true });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.set(0, yFloor + 0.45, zR - 0.45);
    group.add(trunk);
  }

  return group;
}

/**
 * Aerodynamic Wind-Tunnel Streamlines & Vortex Visualization
 */
function generateAerodynamicStreamlines(project: VehicleProject): THREE.Group {
  const group = new THREE.Group();
  group.name = 'AerodynamicStreamlinesGroup';

  const d = project.dimensions;
  const L = d.length / 1000;
  const W = d.width / 1000;
  const H = d.height / 1000;

  const streamlinesCount = 28;
  const pointsPerLine = 32;

  for (let s = 0; s < streamlinesCount; s++) {
    const startX = ((s / (streamlinesCount - 1)) - 0.5) * (W * 0.95);
    const startY = (d.groundClearance / 1000) + 0.1 + (s % 5) * 0.26;
    const startZ = L / 2 + 1.2;

    const curvePoints: THREE.Vector3[] = [];
    for (let p = 0; p <= pointsPerLine; p++) {
      const t = p / pointsPerLine;
      const z = startZ - t * (L + 2.4);

      // Curve upward over hood and roof
      let y = startY;
      if (z > 0 && z < L / 2) {
        y += Math.sin((1 - z / (L / 2)) * Math.PI) * (H * 0.38);
      } else if (z <= 0 && z > -L / 2) {
        y += H * 0.48 * (1.0 - Math.pow(Math.abs(z) / (L / 2), 1.6) * 0.4);
      }

      // Smooth outward displacement around fenders
      let x = startX;
      if (Math.abs(z) < L / 2.2) {
        x += Math.sign(startX) * 0.04 * Math.sin(t * Math.PI);
      }

      curvePoints.push(new THREE.Vector3(x, y, z));
    }

    const curve = new THREE.CatmullRomCurve3(curvePoints);
    const tubeGeo = new THREE.TubeGeometry(curve, 32, 0.006, 6, false);
    
    // Velocity pressure color: Cyan/Blue (low pressure) to Orange/Red (high stagnation)
    const streamMat = new THREE.MeshBasicMaterial({
      color: s < streamlinesCount / 2 ? 0x00d2ff : 0x38ef7d,
      transparent: true,
      opacity: 0.45,
    });

    const streamMesh = new THREE.Mesh(tubeGeo, streamMat);
    group.add(streamMesh);
  }

  return group;
}
