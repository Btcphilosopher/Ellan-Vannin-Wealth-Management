import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { VehicleProject, ActiveWorkspace, VehicleVariant, DesignHistoryEntry, ProjectStatus, VehicleClass, DriveConcept } from '../models/vehicle.model';
import { DEMO_PROJECT_VISION_LUX, SAMPLE_PROJECTS_CATALOG } from '../models/templates';
import { jsPDF } from 'jspdf';

export interface AssistantMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  source?: string;
}

@Injectable({
  providedIn: 'root',
})
export class DesignStudioState {
  private http = inject(HttpClient);

  // Active loaded project
  readonly currentProject = signal<VehicleProject>(JSON.parse(JSON.stringify(DEMO_PROJECT_VISION_LUX)));

  // Current active workspace navigation
  readonly activeWorkspace = signal<ActiveWorkspace>('karosserie3d');

  // Secondary comparison variant for Split-Screen
  readonly comparisonVariant = signal<VehicleVariant | null>(
    DEMO_PROJECT_VISION_LUX.variants[1] || null
  );

  // Modal states
  readonly isReviewModeOpen = signal<boolean>(false);
  readonly isAiAssistantOpen = signal<boolean>(false);
  readonly isNewProjectWizardOpen = signal<boolean>(false);

  // AI Assistant conversation
  readonly aiMessages = signal<AssistantMessage[]>([
    {
      id: 'm-0',
      sender: 'assistant',
      text: 'Willkommen im Mercedes-Benz Design Studio. Ich bin Ihr KI-Design- und Aerodynamikingenieur. Wie kann ich die Proportionen, Class-A Flächen, Packaging-Freigaben oder den cW-Wert von "' + DEMO_PROJECT_VISION_LUX.name + '" analysieren?',
      timestamp: new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }),
    }
  ]);
  readonly isAiThinking = signal<boolean>(false);

  // Undo / Redo stacks
  private undoStack: string[] = [];
  private redoStack: string[] = [];

  // Computed properties
  readonly effectiveCw = computed(() => {
    const p = this.currentProject();
    let baseCw = p.aerodynamics.cw;
    // Dynamic aerodynamics modifier based on active features
    if (p.wheels.rimStyle === 'eq-aero-blade') baseCw -= 0.005;
    if (p.exterior.mirrorStyle === 'digital-camera-aerowings') baseCw -= 0.006;
    if (p.exterior.doorHandles === 'flush-retractable') baseCw -= 0.003;
    if (!p.aerodynamics.underbodySealed) baseCw += 0.015;
    return Math.max(0.185, Number(baseCw.toFixed(3)));
  });

  readonly effectiveFrontalArea = computed(() => {
    const p = this.currentProject();
    const d = p.dimensions;
    // Frontal Area estimation formula: A = (Width * Height * 0.82)
    const area = ((d.width / 1000) * (d.height / 1000) * 0.812);
    return Number(area.toFixed(2));
  });

  readonly effectiveCwA = computed(() => {
    return Number((this.effectiveCw() * this.effectiveFrontalArea()).toFixed(3));
  });

  readonly designConstraintWarnings = computed(() => {
    const p = this.currentProject();
    const warnings: string[] = [];
    const d = p.dimensions;

    if (d.groundClearance < 115) {
      warnings.push('Bodenfreiheit kritisch niedrig (< 115 mm) — Rampenwinkel & Batterieunterfahrschutz gefährdet.');
    }
    if (d.wheelbase / d.length > 0.65) {
      warnings.push('Extremes Radstand-zu-Länge-Verhältnis (> 0.65) — Wendekreis erfordert zwingend Hinterachslenkung.');
    }
    if (p.wheels.diameterInches === 23 && d.groundClearance < 125) {
      warnings.push('Radhaus-Freigängigkeit bei 23"-Rädern und Tieferlegung bei vollem Lenkeinschlag überprüfen.');
    }
    if (d.aPillarAngle > 31.0) {
      warnings.push('Flache A-Säule (> 31°) verringert den Kopfraum beim Ein- und Ausstieg.');
    }

    return warnings;
  });

  // Actions
  setWorkspace(ws: ActiveWorkspace) {
    this.activeWorkspace.set(ws);
  }

  loadProject(project: VehicleProject) {
    this.saveSnapshotToHistory('Projekt gewechselt');
    this.currentProject.set(JSON.parse(JSON.stringify(project)));
  }

  updateProject(mutator: (p: VehicleProject) => void) {
    this.pushUndoState();
    this.currentProject.update((curr) => {
      const copy: VehicleProject = JSON.parse(JSON.stringify(curr));
      mutator(copy);
      copy.updatedAt = new Date().toISOString();
      return copy;
    });
  }

  createNewProject(params: {
    name: string;
    codeName: string;
    vehicleClass: VehicleClass;
    driveConcept: DriveConcept;
  }) {
    this.pushUndoState();
    const base = JSON.parse(JSON.stringify(DEMO_PROJECT_VISION_LUX));
    const newProj: VehicleProject = {
      ...base,
      id: `MBDS-${Date.now().toString().slice(-6)}`,
      name: params.name || 'NEUES FAHRZEUGKONZEPT',
      codeName: params.codeName || 'BR-CONCEPT-2030',
      vehicleClass: params.vehicleClass,
      driveConcept: params.driveConcept,
      status: 'ENTWURF',
      currentVersion: 'DESIGN_001',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      variants: [],
      history: [
        {
          id: `h-${Date.now()}`,
          versionCode: 'DESIGN_001',
          timestamp: new Date().toISOString(),
          author: 'Designer',
          snapshotName: 'Projekt initialisiert',
          comment: `Neuentwicklung ${params.vehicleClass} mit ${params.driveConcept}`,
          metrics: {
            cw: 0.200,
            length: base.dimensions.length,
            wheelbase: base.dimensions.wheelbase,
            weightEstKg: 2450
          }
        }
      ],
      clay: {
        ...base.clay,
        deformations: []
      }
    };
    this.currentProject.set(newProj);
    this.activeWorkspace.set('proportion');
    this.isNewProjectWizardOpen.set(false);
  }

  saveVersionSnapshot(comment: string = 'Manuelle Zwischenspeicherung') {
    const p = this.currentProject();
    const nextVerNum = p.history.length + 1;
    const versionCode = `DESIGN_${String(nextVerNum).padStart(3, '0')}`;
    
    const entry: DesignHistoryEntry = {
      id: `hist-${Date.now()}`,
      versionCode,
      timestamp: new Date().toISOString(),
      author: p.designer || 'Chefdesigner',
      snapshotName: `Stand: ${p.name} (${versionCode})`,
      comment,
      metrics: {
        cw: this.effectiveCw(),
        length: p.dimensions.length,
        wheelbase: p.dimensions.wheelbase,
        weightEstKg: 2450 + (p.dimensions.length > 5200 ? 50 : 0)
      }
    };

    this.updateProject((proj) => {
      proj.currentVersion = versionCode;
      proj.history.push(entry);
    });
  }

  setProjectStatus(status: ProjectStatus) {
    this.updateProject((proj) => {
      proj.status = status;
      if (status === 'DESIGN FREEZE') {
        proj.history.push({
          id: `freeze-${Date.now()}`,
          versionCode: `${proj.currentVersion}_FREEZE`,
          timestamp: new Date().toISOString(),
          author: proj.designer,
          snapshotName: 'DESIGN FREEZE OFFIZIELL BESTÄTIGT',
          comment: 'Finaler digitaler Strak und Package-Freigabe für Prototypenbau.',
          metrics: {
            cw: this.effectiveCw(),
            length: proj.dimensions.length,
            wheelbase: proj.dimensions.wheelbase,
            weightEstKg: 2460
          }
        });
      }
    });
  }

  saveCurrentAsVariant(name: string, description: string) {
    const p = this.currentProject();
    const variant: VehicleVariant = {
      id: `var-${Date.now()}`,
      name: name || `Variante ${p.variants.length + 1}`,
      code: `VAR-${p.variants.length + 1}`,
      description: description || 'Konzeptuelle Ausprägung',
      bodyStyle: p.vehicleClass,
      dimensions: JSON.parse(JSON.stringify(p.dimensions)),
      materials: JSON.parse(JSON.stringify(p.materials)),
      wheels: JSON.parse(JSON.stringify(p.wheels)),
      lights: JSON.parse(JSON.stringify(p.lighting)),
      exterior: JSON.parse(JSON.stringify(p.exterior)),
      aerodynamics: JSON.parse(JSON.stringify(p.aerodynamics)),
      updatedAt: new Date().toISOString(),
    };

    this.updateProject((proj) => {
      proj.variants.push(variant);
    });
  }

  applyVariant(variant: VehicleVariant) {
    this.updateProject((proj) => {
      proj.dimensions = JSON.parse(JSON.stringify(variant.dimensions));
      proj.materials = JSON.parse(JSON.stringify(variant.materials));
      proj.wheels = JSON.parse(JSON.stringify(variant.wheels));
      proj.lighting = JSON.parse(JSON.stringify(variant.lights));
      proj.exterior = JSON.parse(JSON.stringify(variant.exterior));
      proj.aerodynamics = JSON.parse(JSON.stringify(variant.aerodynamics));
      proj.vehicleClass = variant.bodyStyle;
    });
  }

  // AI Assistant Integration
  async askAiAssistant(question: string) {
    if (!question.trim()) return;

    const userMsg: AssistantMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: question,
      timestamp: new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }),
    };

    this.aiMessages.update((msgs) => [...msgs, userMsg]);
    this.isAiThinking.set(true);

    try {
      const p = this.currentProject();
      const payload = {
        prompt: question,
        projectContext: {
          name: p.name,
          codeName: p.codeName,
          status: p.status,
          vehicleClass: p.vehicleClass,
          driveConcept: p.driveConcept,
          wheelbase: p.dimensions.wheelbase,
          length: p.dimensions.length,
          width: p.dimensions.width,
          height: p.dimensions.height,
          frontOverhang: p.dimensions.frontOverhang,
          rearOverhang: p.dimensions.rearOverhang,
          groundClearance: p.dimensions.groundClearance,
          aerodynamics: {
            cw: this.effectiveCw(),
            frontalArea: this.effectiveFrontalArea(),
            cwA: this.effectiveCwA(),
          },
          wheels: p.wheels,
          paint: p.materials.paintName,
          paintFinish: p.materials.paintFinish,
          variantsCount: p.variants.length,
        }
      };

      this.http.post<{ text: string; source: string }>('/api/design-assistant', payload).subscribe({
        next: (res) => {
          const aiMsg: AssistantMessage = {
            id: `a-${Date.now()}`,
            sender: 'assistant',
            text: res.text,
            timestamp: new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }),
            source: res.source,
          };
          this.aiMessages.update((msgs) => [...msgs, aiMsg]);
          this.isAiThinking.set(false);
        },
        error: (err) => {
          const fallbackMsg: AssistantMessage = {
            id: `a-${Date.now()}`,
            sender: 'assistant',
            text: `Analyse für ${p.name}: Radstand beträgt ${p.dimensions.wheelbase} mm, Gesamtlänge ${p.dimensions.length} mm. Effektiver cW-Wert liegt bei ${this.effectiveCw()} (cW × A = ${this.effectiveCwA()} m²). Class-A Flächenkontinuität G2 an Schulter- und Dachlinie verifiziert.`,
            timestamp: new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' }),
          };
          this.aiMessages.update((msgs) => [...msgs, fallbackMsg]);
          this.isAiThinking.set(false);
        }
      });
    } catch {
      this.isAiThinking.set(false);
    }
  }

  // Export Native .mbdesign project file
  exportMbDesignFile() {
    const p = this.currentProject();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(p, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${p.codeName || 'MBDS'}_${p.currentVersion}.mbdesign`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  }

  // Import Native .mbdesign project file
  importMbDesignFile(jsonContent: string) {
    try {
      const parsed: VehicleProject = JSON.parse(jsonContent);
      if (parsed && parsed.dimensions && parsed.materials) {
        this.loadProject(parsed);
      }
    } catch (e) {
      console.error('Ungültige .mbdesign Projektdatei', e);
    }
  }

  // Export Technical PDF Design Report using jsPDF
  exportPdfDesignReport() {
    const p = this.currentProject();
    const d = p.dimensions;
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4',
    });

    // Dark luxury styling header
    doc.setFillColor(15, 18, 24);
    doc.rect(0, 0, 297, 210, 'F');

    // Metallic Header Ribbon
    doc.setFillColor(28, 34, 46);
    doc.rect(10, 10, 277, 28, 'F');
    doc.setDrawColor(0, 210, 255);
    doc.setLineWidth(0.5);
    doc.line(10, 38, 287, 38);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(240, 245, 250);
    doc.text('MERCEDES-BENZ DESIGN STUDIO', 16, 22);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(0, 210, 255);
    doc.text('FAHRZEUGENTWICKLUNG & DESIGN-FREIGABEBERICHT', 16, 30);

    doc.setTextColor(180, 190, 200);
    doc.text(`Projekt: ${p.name} | Code: ${p.codeName} | Status: ${p.status} | Version: ${p.currentVersion}`, 160, 22);
    doc.text(`Erstellt am: ${new Date().toLocaleDateString('de-DE')} | Designer: ${p.designer}`, 160, 30);

    // Section 1: Fahrzeugabmessungen & Proportion
    doc.setFillColor(22, 26, 35);
    doc.roundedRect(10, 44, 134, 76, 2, 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(0, 210, 255);
    doc.text('1. PROPORTION & FAHRZEUGARCHITEKTUR', 16, 52);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(230, 235, 240);
    const dimLines = [
      `Gesamtlänge: ${d.length} mm`,
      `Gesamtbreite: ${d.width} mm`,
      `Gesamthöhe: ${d.height} mm`,
      `Radstand: ${d.wheelbase} mm`,
      `Überhang vorn / hinten: ${d.frontOverhang} mm / ${d.rearOverhang} mm`,
      `Spurweite vorn / hinten: ${d.trackWidthFront} mm / ${d.trackWidthRear} mm`,
      `Bodenfreiheit: ${d.groundClearance} mm`,
      `A-Säulen-Winkel: ${d.aPillarAngle}° | C-Säulen-Winkel: ${d.cPillarAngle}°`,
      `Antriebskonzept: ${p.driveConcept}`,
      `Fahrzeugklasse: ${p.vehicleClass}`,
    ];
    dimLines.forEach((l, idx) => {
      doc.text(l, 16, 60 + idx * 5.6);
    });

    // Section 2: Aerodynamik & Effizienz
    doc.setFillColor(22, 26, 35);
    doc.roundedRect(150, 44, 137, 76, 2, 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(0, 210, 255);
    doc.text('2. AERODYNAMIK & STRÖMUNGSVALIDIERUNG', 156, 52);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(230, 235, 240);
    const aeroLines = [
      `Strömungswiderstandsbeiwert (cW): ${this.effectiveCw()}`,
      `Stirnfläche (A): ${this.effectiveFrontalArea()} m²`,
      `Effektive Widerstandsfläche (cW × A): ${this.effectiveCwA()} m²`,
      `Abtrieb Vorderachse: ${p.aerodynamics.downforceFrontKg} kg @ 200 km/h`,
      `Abtrieb Hinterachse: ${p.aerodynamics.downforceRearKg} kg @ 200 km/h`,
      `Unterboden: Vollständig gekapselt (Venturi-Tunnel)`,
      `Räder: ${p.wheels.diameterInches}" ${p.wheels.rimStyle} (${p.wheels.tireWidthMm}/${p.wheels.tireProfileRatio} R${p.wheels.diameterInches})`,
      `Kühlluftklappen: Aktiv geregelt & flächenbündig`,
      `Spiegel: ${p.exterior.mirrorStyle === 'digital-camera-aerowings' ? 'Digitale Aero-Kameras' : 'Skulpturale Spiegel'}`,
      `Türgriffe: Flächenbündig versenkbar`,
    ];
    aeroLines.forEach((l, idx) => {
      doc.text(l, 156, 60 + idx * 5.6);
    });

    // Section 3: Material & Class-A Freigabe
    doc.setFillColor(22, 26, 35);
    doc.roundedRect(10, 126, 277, 68, 2, 2, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(0, 210, 255);
    doc.text('3. MATERIALIEN, LICHTDESIGN & DESIGN-FREIGABE (CLASS-A)', 16, 134);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(230, 235, 240);
    doc.text(`Exterieur-Lackierung: ${p.materials.paintName} (${p.materials.paintFinish})`, 16, 142);
    doc.text(`Interieur: ${p.materials.interiorLeather} mit Zierelementen in ${p.materials.interiorTrim}`, 16, 148);
    doc.text(`Lichttechnologie: ${p.lighting.headlampTech} mit DRL-Signatur "${p.lighting.dRLSignature}"`, 16, 154);
    doc.text(`Class-A Strak-Qualität: G0/G1/G2 Krümmungsstetigkeit über die gesamte Seitenwand und Schulter verifiziert.`, 16, 160);
    doc.text(`Design-Status: ${p.status} — Freigegeben für Strak-Validierung und Prototypenbau.`, 16, 166);

    doc.setDrawColor(255, 255, 255);
    doc.line(16, 182, 100, 182);
    doc.text('Unterschrift Chefdesigner Sindelfingen', 16, 187);

    doc.line(180, 182, 264, 182);
    doc.text('Unterschrift Leiter Karosserieentwicklung', 180, 187);

    doc.save(`${p.codeName}_Design_Report.pdf`);
  }

  // Undo / Redo helpers
  private pushUndoState() {
    this.undoStack.push(JSON.stringify(this.currentProject()));
    if (this.undoStack.length > 30) this.undoStack.shift();
    this.redoStack = [];
  }

  undo() {
    if (this.undoStack.length === 0) return;
    const prev = this.undoStack.pop();
    if (prev) {
      this.redoStack.push(JSON.stringify(this.currentProject()));
      this.currentProject.set(JSON.parse(prev));
    }
  }

  redo() {
    if (this.redoStack.length === 0) return;
    const next = this.redoStack.pop();
    if (next) {
      this.undoStack.push(JSON.stringify(this.currentProject()));
      this.currentProject.set(JSON.parse(next));
    }
  }

  private saveSnapshotToHistory(reason: string) {
    // Snapshot helper
  }
}
