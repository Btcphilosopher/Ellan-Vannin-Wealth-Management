package com.example.ui.screens

import androidx.activity.compose.BackHandler
import java.util.Locale
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.*
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.theme.*

// --- Utility: Technical Blueprint Grid Background ---
fun Modifier.technicalGridBackground(gridColor: Color) = this.drawBehind {
    val step = 40.dp.toPx()
    // Vertical lines
    var x = 0f
    while (x < size.width) {
        drawLine(
            color = gridColor,
            start = Offset(x, 0f),
            end = Offset(x, size.height),
            strokeWidth = 1f
        )
        x += step
    }
    // Horizontal lines
    var y = 0f
    while (y < size.height) {
        drawLine(
            color = gridColor,
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = 1f
        )
        y += step
    }
}

// --- Common UI Components ---

@Composable
fun SectionHeader(title: String, subtitle: String? = null) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.displaySmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.testTag("section_title_$title")
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .width(60.dp)
                .height(3.dp)
                .background(BrandBlueLight)
        )
        if (subtitle != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyLarge,
                color = SteelSlate
            )
        }
    }
}

@Composable
fun TechnicalMetricCard(label: String, value: String, unit: String = "") {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
        colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
        shape = RoundedCornerShape(4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = SteelSlate
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Bold,
                    color = BrandBlue
                )
                if (unit.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = unit,
                        style = MaterialTheme.typography.titleLarge,
                        color = SteelSlate,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

// --- 07 — HOMEPAGE ---
@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    projects: List<Project>
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Hero Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                ) {
                    // Try to load the beautiful generated industrial hero image
                    Image(
                        painter = painterResource(id = R.drawable.img_industrial_hero_1791023565062),
                        contentDescription = "PETER & KREBS Industrielle Fertigung",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Grid pattern overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        BrandBlueDark.copy(alpha = 0.6f)
                                    )
                                )
                            )
                    )
                }

                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "PRÄZISION FÜR ANSPRUCHSVOLLE AUFGABEN.",
                        style = MaterialTheme.typography.displayLarge,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 36.sp,
                        modifier = Modifier.testTag("homepage_hero_title")
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "PETER & KREBS verbindet technische Kompetenz, langjährige Erfahrung und konsequente Qualitätsorientierung zu Lösungen, die im täglichen Betrieb zuverlässig funktionieren.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = DeepAnthracite,
                        lineHeight = 22.sp
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { viewModel.navigateTo(Screen.Leistungen) },
                            colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("btn_discover_services")
                        ) {
                            Text("LEISTUNGEN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { viewModel.navigateTo(Screen.Kontakt) },
                            border = BorderStroke(1.dp, BrandBlue),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("btn_request_project")
                        ) {
                            Text("PROJEKT ANFRAGEN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = BrandBlue)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Technical key numbers banner
        SectionHeader(title = "Kennzahlen", subtitle = "Fakten unserer Fertigungskompetenz")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(modifier = Modifier.weight(1f)) {
                TechnicalMetricCard(label = "Toleranz", value = "0,001", unit = "mm")
            }
            Box(modifier = Modifier.weight(1f)) {
                TechnicalMetricCard(label = "Erfahrung", value = "40+", unit = "Jahre")
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(modifier = Modifier.weight(1f)) {
                TechnicalMetricCard(label = "B2B-Projekte", value = "1.200+", unit = "")
            }
            Box(modifier = Modifier.weight(1f)) {
                TechnicalMetricCard(label = "Liefertreue", value = "99,4", unit = "%")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Selected Case Studies (Projekte)
        SectionHeader(title = "Referenzprojekte", subtitle = "Technische Fallstudien aus der Praxis")
        if (projects.isEmpty()) {
            Text("Keine Projekte vorhanden.", style = MaterialTheme.typography.bodyMedium, color = SteelSlate)
        } else {
            projects.take(2).forEach { proj ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp))
                        .clickable { viewModel.navigateTo(Screen.ProjektDetail(proj.id)) },
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                        ) {
                            val imgRes = when (proj.imageResName) {
                                "img_engineering_blueprint" -> R.drawable.img_engineering_blueprint_1791023581332
                                "img_factory_assembly" -> R.drawable.img_factory_assembly_1791023594303
                                else -> R.drawable.img_industrial_hero_1791023565062
                            }
                            Image(
                                painter = painterResource(id = imgRes),
                                contentDescription = proj.name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.2f))
                            )
                        }
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = proj.sector.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = SteelSlate,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = proj.name,
                                style = MaterialTheme.typography.titleLarge,
                                color = BrandBlue
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = proj.result,
                                style = MaterialTheme.typography.bodyMedium,
                                color = DeepAnthracite,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "PROJEKT ANSEHEN →",
                                style = MaterialTheme.typography.labelLarge,
                                color = BrandBlueLight,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- 08 — UNTERNEHMEN ---
@Composable
fun UnternehmenScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.Home) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Über uns",
            subtitle = "PETER & KREBS — Partner für anspruchsvolle Industrieanwendungen"
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "WER WIR SIND",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelSlate,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Hinter PETER & KREBS stehen Menschen, die technische Aufgaben nicht nur planen, sondern bis zur funktionierenden Lösung begleiten.",
                    style = MaterialTheme.typography.titleLarge,
                    color = BrandBlue,
                    lineHeight = 24.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Gegründet im Jahr 1986, haben wir uns von einer hochspezialisierten Stuttgarter Konstruktionswerkstatt zu einem bundesweit agierenden Partner im mechanischen Sondermaschinenbau und Industrieanlagenbau entwickelt.\n\nMit heute über 85 hochqualifizierten Ingenieuren, Meistern, Industriemechanikern und Zerspanungsspezialisten planen, fertigen, montieren und warten wir anspruchsvollste technische Anlagen für Kunden aus dem gesamten deutschsprachigen Raum.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = DeepAnthracite
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Grid Menu for Corporate Pages
        Text(
            text = "WEITERE BEREICHE",
            style = MaterialTheme.typography.labelSmall,
            color = SteelSlate,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        val items = listOf(
            Triple("Geschichte & Timeline", Icons.Default.Timeline, Screen.Geschichte),
            Triple("Qualität & Prozesse", Icons.Default.Verified, Screen.Qualitaet),
            Triple("Verantwortung & Effizienz", Icons.Default.EnergySavingsLeaf, Screen.Verantwortung),
            Triple("Unsere Standorte", Icons.Default.LocationOn, Screen.Standorte)
        )

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items.forEach { (title, icon, screen) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(screen) }
                        .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                    colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = BrandBlue,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            color = BrandBlue,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Details",
                            tint = SteelSlate
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Leadership
        SectionHeader(title = "Geschäftsführung", subtitle = "Verantwortung und Führung")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp))
                    .background(PureWhite)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(CoolGreyLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, contentDescription = "Dr.-Ing. Wilhelm Peter", tint = SteelSlate)
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Dr.-Ing. Wilhelm Peter",
                    style = MaterialTheme.typography.titleMedium,
                    color = BrandBlue,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Technik & Konstruktion",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelSlate,
                    textAlign = TextAlign.Center
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp))
                    .background(PureWhite)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(CoolGreyLight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, contentDescription = "Dipl.-Kfm. Stefan Krebs", tint = SteelSlate)
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Dipl.-Kfm. Stefan Krebs",
                    style = MaterialTheme.typography.titleMedium,
                    color = BrandBlue,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Kaufmännische Leitung",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelSlate,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// --- 09 — TIMELINE / GESCHICHTE ---
@Composable
fun GeschichteScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.UberUns) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Unternehmensgeschichte",
            subtitle = "Meilensteine aus vier Jahrzehnten technischer Entwicklung"
        )

        val timeline = listOf(
            "1986" to "Gründung" to "Gründung von PETER & KREBS durch Dr. Wilhelm Peter und Stefan Krebs in Stuttgart als Ingenieurbüro für Präzisionsmaschinen.",
            "1994" to "Erste eigene Fertigungshalle" to "Inbetriebnahme des ersten eigenen Fertigungsstandortes in Waiblingen. Einstieg in die eigene Lohnfertigung hochpräziser Frästeile.",
            "2004" to "Erweiterung der Kompetenzen" to "Aufbau des Geschäftsbereichs Automatisierungstechnik und Software-Schnittstellen (MES/SPS). Von nun an Lieferung voll integrierter Gesamtanlagen.",
            "2012" to "Internationalisierung" to "Umfassende Realisierung von Auslandsprojekten in Österreich, der Schweiz und den Niederlanden für deutsche Stammkunden.",
            "2020" to "Digitalisierung" to "Einführung des lückenlosen digitalen Werkstück-Tracings mit Laser-Engraving und Einbindung moderner 3D-CAD/CAM Simulationen im Engineering.",
            "HEUTE" to "Ihr zuverlässiger B2B-Partner" to "Etablierter, mittelständischer Industrieanlagen-Spezialist mit drei Standorten und über 1.200 erfolgreich realisierten B2B-Projekten."
        )

        timeline.forEachIndexed { index, item ->
            val year = item.first.first
            val milestone = item.first.second
            val desc = item.second
            Row(modifier = Modifier.fillMaxWidth()) {
                // Left Column: Year & Dot indicator
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(70.dp)
                ) {
                    Text(
                        text = year,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (year == "HEUTE") RustOrange else BrandBlue
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(if (year == "HEUTE") RustOrange else BrandBlueLight)
                    )
                    if (index < timeline.size - 1) {
                        Box(
                            modifier = Modifier
                                .width(2.dp)
                                .height(90.dp)
                                .background(ConcreteGray)
                        )
                    }
                }

                // Right Column: Milestone Details
                Column(
                    modifier = Modifier
                        .padding(start = 12.dp, bottom = 24.dp)
                        .weight(1f)
                ) {
                    Text(
                        text = milestone,
                        style = MaterialTheme.typography.titleLarge,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite
                    )
                }
            }
        }
    }
}

// --- 16 — QUALITÄT ---
@Composable
fun QualitaetScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.UberUns) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Qualität & Prozesse",
            subtitle = "Präzision ist kein Zufall, sondern lückenlose Methodik"
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "QUALITÄT IST KEIN SCHRIFTSATZ. SIE IST EIN PROZESS.",
                    style = MaterialTheme.typography.titleMedium,
                    color = BrandBlue,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Unsere B2B-Kunden erwarten unbedingte Zuverlässigkeit und präzise Masshaltigkeit über Jahrzehnte hinweg. Wir haben deshalb jeden Arbeitsschritt in standardisierte Prüfprozesse gegliedert.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = DeepAnthracite
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val processes = listOf(
            "1. Konstruktions-Review" to "Prüfung aller CAD-Modelle auf statische Belastungen, Strömungsverhalten und Toleranzketten per FEM-Simulation.",
            "2. Materialeingangskontrolle" to "Spektrometrische Prüfung aller Metalle auf Legierungsechtheit sowie Ultraschallprüfung auf Mikrorisse vor Arbeitsbeginn.",
            "3. In-Prozess-Kontrolle (IPK)" to "Taktbegleitende Vermessung der Werkstücke direkt auf den CNC-Zentren mittels kalibrierter Messtaster.",
            "4. Lückenlose Rückverfolgbarkeit" to "Jedes Bauteil wird per Laserbeschriftung (DataMatrix) versehen. Das Materialprüfzeugnis ist im Kundenportal einsehbar.",
            "5. Endabnahme & Protokoll" to "Vermessung im temperierten Messraum auf 3D-Koordinatenmessmaschinen. Auslieferung erfolgt ausschliesslich mit Messprotokoll."
        )

        processes.forEach { (step, text) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = step.uppercase(),
                        style = MaterialTheme.typography.titleMedium,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Calibration data block (simulated)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            colors = CardDefaults.cardColors(containerColor = JetBlack),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SYSTEM-PRÜFUNG & KALIBRIERUNG",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelSlate,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Letzte Kalibrierung Messraum: OK (03.10.2026)\nAbweichung 3D-KMM: < 0,7 µm\nInterne Prozess-Audits nach VDA 6.3: Bestanden",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.Green,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

// --- 17 — VERANTWORTUNG & NACHHALTIGKEIT ---
@Composable
fun VerantwortungScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.UberUns) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Verantwortung",
            subtitle = "Ressourceneffizienz und Langlebigkeit als technisches Prinzip"
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "SACHLICH & MESSBAR",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelSlate,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Nachhaltigkeit verstehen wir als ingenieurwissenschaftliche Optimierungsaufgabe: Minimierung von Verschleiss, Optimierung des Materialeinsatzes und Langlebigkeit der gebauten Maschinen.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = DeepAnthracite
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val facts = listOf(
            "Materialeffizienz" to "98,2% aller Metallspäne und Reste aus unserer CNC-Fertigung werden sortenrein sortiert und direkt dem stofflichen Recyclingkreislauf zugeführt.",
            "Wartbarkeit & Reparatur" to "Wir konstruieren Maschinen lückenlos nach dem 'Design for Service' Prinzip. Verschleissteile sind ohne Spezialwerkzeuge austauschbar.",
            "Ressourceneinsatz" to "Unsere Produktionswerke nutzen 100% zertifizierten Grünstrom, ergänzt durch thermische Energierückgewinnung der CNC-Kühlanlagen.",
            "Eigene Logistikoptimierung" to "Kombinierte Auslieferungstouren für die Werksmontagen minimieren Leerfahrten im Service um 18% im Jahresvergleich."
        )

        facts.forEach { (title, desc) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = BrandBlue,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite
                    )
                }
            }
            Divider(color = ConcreteGray)
        }
    }
}

// --- 21 — STANDORTE ---
@Composable
fun StandorteScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.UberUns) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Unsere Standorte",
            subtitle = "PETER & KREBS bundesweit für Sie im Einsatz"
        )

        // Mock Map Abstract Graphics using Canvas
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            shape = RoundedCornerShape(4.dp),
            colors = CardDefaults.cardColors(containerColor = CoolGreyLight)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .technicalGridBackground(ConcreteGray.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                // Draws three mock site dots indicating German sites
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "[ STANDORTE DEUTSCHLAND ]",
                        style = MaterialTheme.typography.labelLarge,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Waiblingen/Stuttgart (Engineering & Verwaltung)\n• Dresden (Produktion & CNC-Fertigung)\n• Karlsruhe (SPS-Steuerungstechnik)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val sites = listOf(
            Triple(
                "Waiblingen / Stuttgart (Hauptverwaltung)",
                "Alte Bundesstrasse 42, 71332 Waiblingen",
                "Tel: +49 (0) 7151 9028-0\nEmail: stuttgart@peter-krebs.de\nBereiche: Engineering, Konstruktion, Vertrieb, Verwaltung"
            ),
            Triple(
                "Dresden (Produktionswerk)",
                "Industriepark Nord 5, 01109 Dresden",
                "Tel: +49 (0) 351 4402-0\nEmail: dresden@peter-krebs.de\nBereiche: CNC-Fertigung, Schweisserei, Endmontage, Qualitätssicherung"
            ),
            Triple(
                "Karlsruhe (Technisches Büro)",
                "Kaiserstrasse 182, 76133 Karlsruhe",
                "Tel: +49 (0) 721 8291-0\nEmail: karlsruhe@peter-krebs.de\nBereiche: SPS-Programmierung, Schaltschrankbau, Automatisierung"
            )
        )

        sites.forEach { (name, address, details) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = name,
                        style = MaterialTheme.typography.titleMedium,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = address,
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = details,
                        style = MaterialTheme.typography.bodyMedium,
                        color = SteelSlate,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { viewModel.navigateTo(Screen.Kontakt) },
                        border = BorderStroke(1.dp, ConcreteGray),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Default.Email, contentDescription = null, tint = BrandBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("KONTAKT AUFNEHMEN", color = BrandBlue, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

// --- 10 & 11 — LEISTUNGEN & DETAILS ---
@Composable
fun LeistungenScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.Home) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Unsere Leistungen",
            subtitle = "Ganzheitliche technische Wertschöpfung aus einer Hand"
        )

        val categories = listOf(
            Triple(
                "Engineering",
                "CAD-Planung, Auslegung komplexer Bauteile, Strömungs- und Belastungssimulation (FEM), Detailkonstruktion und fertigungsgerechte Zeichnungserstellung.",
                Icons.Default.Engineering
            ),
            Triple(
                "Fertigung",
                "Mechanische Bearbeitung komplexer Edelstahl- und Aluminiumbauteile auf modernen 5-Achs-CNC Zentren. Schweißen unter lückenloser Qualitätskontrolle.",
                Icons.Default.PrecisionManufacturing
            ),
            Triple(
                "Montage",
                "Fachgerechte Werksmontage sowie Logistik, Installation und millimetergenaue Ausrichtung anspruchsvoller Industrieanlagen direkt vor Ort beim Kunden.",
                Icons.Default.Build
            ),
            Triple(
                "Automatisierung",
                "Elektroplanung, Schaltschrankbau, SPS-Schnittstellenentwicklung (Siemens TIA Portal / Beckhoff) sowie Kopplung an übergeordnete MES-Systeme.",
                Icons.Default.SettingsInputComponent
            ),
            Triple(
                "Instandhaltung",
                "Vorbeugende Wartung, reaktive Störungsbehebung sowie Ersatzteilmanagement über den gesamten Anlagenlebenszyklus zur Vermeidung teurer Ausfälle.",
                Icons.Default.Handyman
            ),
            Triple(
                "Projektmanagement",
                "Lückenlose Termin-, Qualitäts- und Kostenkoordination von der ersten CAD-Skizze bis zur schlüsselfertigen Übergabe mit festem Ansprechpartner.",
                Icons.Default.Assignment
            )
        )

        categories.forEach { (name, desc, icon) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp))
                    .clickable { viewModel.navigateTo(Screen.LeistungsDetail(name)) },
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(CoolGreyLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(icon, contentDescription = name, tint = BrandBlue, modifier = Modifier.size(28.dp))
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = name.uppercase(),
                            style = MaterialTheme.typography.titleLarge,
                            color = BrandBlue,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("service_card_$name")
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "MEHR ERFAHREN & SPEZIFIKATIONEN →",
                        style = MaterialTheme.typography.labelLarge,
                        color = BrandBlueLight,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun LeistungsDetailScreen(category: String, viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.Leistungen) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateTo(Screen.Leistungen) },
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Zurück", tint = BrandBlue)
            }
            Text(
                text = "LEISTUNGEN / $category",
                style = MaterialTheme.typography.labelLarge,
                color = SteelSlate,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        SectionHeader(title = category, subtitle = "Spezifikation des Leistungsspektrums von PETER & KREBS")

        // Display beautiful blueprint background graphic for "Engineering" and "Automatisierung"
        if (category == "Engineering" || category == "Automatisierung") {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = BrandBlueDark),
                shape = RoundedCornerShape(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .technicalGridBackground(PureWhite.copy(alpha = 0.15f))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "CAD / SPS PROJEKTPLANUNG AKTIV",
                        style = MaterialTheme.typography.labelLarge,
                        color = CoolGreyLight,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "UNSERE KOMPETENZEN IN DER SPARTE $category",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelSlate,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))

                val bulletPoints = when (category) {
                    "Engineering" -> listOf(
                        "Konstruktionsentwurf in modernstem 3D-CAD (NX, SolidWorks)",
                        "FEM-Strukturanalysen (Belastung, Verformung, Ermüdung)",
                        "Lüftungs- und Strömungssimulationen (CFD)",
                        "Toleranzkettenberechnungen nach ISO 2768",
                        "Lückenlose technische Dokumentation gemäss Maschinenrichtlinie 2006/42/EG"
                    )
                    "Fertigung" -> listOf(
                        "5-Achs-Simultanfräsen auf Hermle & DMG CNC-Bearbeitungszentren",
                        "Präzisionsdrehen mit Toleranzen bis zu 0,001 mm",
                        "WIG/MIG/MAG-Schweissprozesse mit ISO-Zertifizierung",
                        "Zerspanung von anspruchsvollen Materialien wie Inconel, Titan und Duplex-Stahl",
                        "Temperierter Feinmessraum zur Endkontrolle"
                    )
                    "Montage" -> listOf(
                        "Maschinenausrichtung über modernste Laserinterferometer",
                        "Mechanischer Aufbau komplexer Führungs- und Portalachsen",
                        "Lückenlose Hebelogistik und Transportplanung für Schwerkomponenten",
                        "Funktionsprüfung und Kaltinbetriebnahme im Montagewerk",
                        "Millimetergenaue Verankerung und Fundamentschnittstellen"
                    )
                    "Automatisierung" -> listOf(
                        "SPS-Entwicklung (Siemens STEP 7 / TIA-Portal, Beckhoff TwinCAT)",
                        "HMI-Visualisierung und lückenlose Bedienoberflächen-Auslegung",
                        "Schaltschrank-Hardwarekonstruktion in EPLAN P8",
                        "Schnittstellenanbindung über OPC-UA, Profinet, Modbus",
                        "Sicherheitsgerichtete Programmierung (Safety Integrated)"
                    )
                    "Instandhaltung" -> listOf(
                        "Vorbeugende Wartungszyklen zur Vermeidung von Maschinenstillständen",
                        "Verschleissmessung und optische Achsvermessung direkt vor Ort",
                        "Express-Ersatzteilservice mit lückenlosem Bestandsmanagement",
                        "Reparatur und Generalüberholung mechanischer Spindeln",
                        "Retrofitting älterer Steuerungstechnik auf Industrie 4.0 Standard"
                    )
                    else -> listOf(
                        "Ganzheitliche Projektsteuerung von Konzeption bis Übergabe",
                        "Feste Meilensteinüberwachung und lückenloses Berichtswesen",
                        "Budget- und Kostenkontrolle durch standardisierte Controlling-Prozesse",
                        "Zentrale Steuerung aller Unterlieferanten und Zukaufteile",
                        "Technischer Festansprechpartner über die gesamte Laufzeit"
                    )
                }

                bulletPoints.forEach { point ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(text = "▪", color = BrandBlue, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = point, style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "IHR VORTEIL",
                    style = MaterialTheme.typography.titleMedium,
                    color = BrandBlue,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "✔ Klare, technische Kommunikation ohne Marketing-Floskeln.\n✔ Nachvollziehbare, zertifizierte Prozesse.\n✔ Vollständig dokumentierte Qualität nach DIN EN ISO 9001.\n✔ Ein fester, technischer Ansprechpartner.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = DeepAnthracite,
                    lineHeight = 22.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.navigateTo(Screen.Kontakt) },
            colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("btn_request_$category")
        ) {
            Text("ANFRAGE FÜR $category STELLEN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

// --- 12 — BRANCHEN ---
@Composable
fun BranchenScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.Home) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Branchen",
            subtitle = "Spezifische Industrie-Erfahrung für anspruchsvollste Märkte"
        )

        val sectors = listOf(
            "Maschinen- und Anlagenbau" to "Konstruktion und Fertigung komplexer Zuführ-, Sortier- und Montageanlagen. Hohe mechanische Präzision.",
            "Automobilindustrie" to "Präzisionswerkzeuge für Presswerke und automatisierte Handhabungslinien im Karosseriebau.",
            "Energie & Kraftwerke" to "Komponenten für Gas- und Dampfturbinen sowie Hebezeuge und Sonderkonstruktionen im Kraftwerksbereich.",
            "Logistik & Intralogistik" to "Durchsatzstarke Sortieranlagen, Förderstrecken und Schnittstellenkopplungen an Lagerverwaltungssysteme.",
            "Chemische Industrie" to "Verfahrenstechnischer Rohrleitungsbau und Armaturen für korrosive und hochtemperierte Medien unter strengsten Auflagen.",
            "Lebensmittelindustrie" to "Hygiene-konforme Edelstahlbaugruppen (Hygienic Design) gemäss EHEDG Richtlinien."
        )

        sectors.forEach { (name, desc) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Factory,
                        contentDescription = name,
                        tint = BrandBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleMedium,
                            color = BrandBlue,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = desc,
                            style = MaterialTheme.typography.bodyMedium,
                            color = DeepAnthracite
                        )
                    }
                }
            }
        }
    }
}

// --- 13 & 14 — PROJEKTE & TECHNICAL CASE STUDIES ---
@Composable
fun ProjekteScreen(
    viewModel: MainViewModel,
    projectList: List<Project>
) {
    BackHandler { viewModel.navigateTo(Screen.Home) }
    var selectedSector by remember { mutableStateOf("Alle Branchen") }
    val sectors = listOf("Alle Branchen", "Maschinenbau", "Energie", "Logistik & Transport")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Referenzprojekte",
            subtitle = "Dokumentierte technische Fallstudien aus der industriellen Praxis"
        )

        // Filter chips row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            sectors.forEach { sector ->
                val isSelected = selectedSector == sector
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedSector = sector },
                    label = { Text(sector) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BrandBlue,
                        selectedLabelColor = PureWhite,
                        containerColor = CoolGreyLight,
                        labelColor = DeepAnthracite
                    ),
                    modifier = Modifier.minimumInteractiveComponentSize()
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val filteredProjects = if (selectedSector == "Alle Branchen") {
            projectList
        } else {
            projectList.filter { it.sector.contains(selectedSector, ignoreCase = true) }
        }

        if (filteredProjects.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "Keine Projekte für diesen Filter vorhanden.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = SteelSlate
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                items(filteredProjects) { proj ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp))
                            .clickable { viewModel.navigateTo(Screen.ProjektDetail(proj.id)) },
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(150.dp)
                            ) {
                                val imgRes = when (proj.imageResName) {
                                    "img_engineering_blueprint" -> R.drawable.img_engineering_blueprint_1791023581332
                                    "img_factory_assembly" -> R.drawable.img_factory_assembly_1791023594303
                                    else -> R.drawable.img_industrial_hero_1791023565062
                                }
                                Image(
                                    painter = painterResource(id = imgRes),
                                    contentDescription = proj.name,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.2f))
                                )
                            }

                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = proj.sector.uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SteelSlate,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = proj.location,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SteelSlate
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = proj.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = BrandBlue,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.testTag("project_title_${proj.id}")
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = proj.challenge,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = DeepAnthracite,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "TECHNISCHE FALLSTUDIE ÖFFNEN →",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = BrandBlueLight,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProjektDetailScreen(projectId: Int, viewModel: MainViewModel, projectList: List<Project>) {
    BackHandler { viewModel.navigateTo(Screen.Projekte) }
    val proj = projectList.find { it.id == projectId }
    val scrollState = rememberScrollState()

    if (proj == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Projekt nicht gefunden.", color = ErrorRed)
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateTo(Screen.Projekte) },
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Zurück", tint = BrandBlue)
            }
            Text(
                text = "REFERENZEN / ${proj.name}",
                style = MaterialTheme.typography.labelLarge,
                color = SteelSlate,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Hero Image
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            shape = RoundedCornerShape(4.dp)
        ) {
            val imgRes = when (proj.imageResName) {
                "img_engineering_blueprint" -> R.drawable.img_engineering_blueprint_1791023581332
                "img_factory_assembly" -> R.drawable.img_factory_assembly_1791023594303
                else -> R.drawable.img_industrial_hero_1791023565062
            }
            Image(
                painter = painterResource(id = imgRes),
                contentDescription = proj.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = proj.name,
            style = MaterialTheme.typography.displayLarge,
            color = BrandBlue,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.testTag("detail_project_title")
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Technical Specs Table Box
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "TECHNISCHE KENNZAHLEN",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelSlate,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))

                val specs = listOf(
                    "BRANCHE" to proj.sector,
                    "STANDORT" to proj.location,
                    "PROJEKTLAUFZEIT" to proj.duration,
                    "LEISTUNGSUMFANG" to proj.services
                )

                specs.forEach { (label, value) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = SteelSlate,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = value,
                            style = MaterialTheme.typography.bodyMedium,
                            color = DeepAnthracite,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(2.0f),
                            textAlign = TextAlign.End
                        )
                    }
                    Divider(color = ConcreteGray.copy(alpha = 0.5f))
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Documented Study Content
        val sections = listOf(
            "Ausgangssituation & Herausforderung" to proj.challenge,
            "Konstruktion & Technische Umsetzung" to proj.solution,
            "Ergebnis & Kundennutzen" to proj.result
        )

        sections.forEach { (title, content) ->
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleMedium,
                color = BrandBlue,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = content,
                style = MaterialTheme.typography.bodyLarge,
                color = DeepAnthracite,
                lineHeight = 22.sp
            )
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

// --- 15 — KOMPETENZEN ---
@Composable
fun KompetenzenScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.Home) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Kompetenzen",
            subtitle = "Umfassende fertigungstechnische Standards und Werkzeuge"
        )

        val competencies = listOf(
            "Konstruktion & 3D-CAD" to "Professioneller Entwurf hochkomplexer Maschinen und Maschinenteile. Einsatz nativer E-CAD- und 3D-Software.",
            "FEM-Simulation" to "Mechanische, thermische und strömungstechnische Überprüfung mechanischer Baugruppen vor Baubeginn.",
            "CNC-Fertigung & Zerspanung" to "Fräsen auf modernsten 5-Achs Zentren, HSC-Zerspanung, hochpräzises Drehen von harten Werkstoffen.",
            "Automatisierung & SPS" to "Lückenlose Steuerungsprogrammierung nach IEC 61131-3, Feldbus-Systeme und Industrie 4.0 IoT-Anbindungen.",
            "Elektroplanung & EPLAN" to "Konstruktion normgerechter Schaltschränke gemäss VDE-Richtlinien und Dokumentation in EPLAN P8.",
            "Prozessüberwachung" to "Integrierte Sensortechnik und Qualitätsmessung während des Fertigungsvorgangs zur Reduzierung von Ausschuss."
        )

        competencies.forEach { (name, desc) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = name,
                            tint = BrandBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleMedium,
                            color = BrandBlue,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite
                    )
                }
            }
        }
    }
}

// --- 18 — KARRIERE & JOB BOARD ---
@Composable
fun KarriereScreen(
    viewModel: MainViewModel,
    jobList: List<JobOpening>
) {
    BackHandler { viewModel.navigateTo(Screen.Home) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Karriere",
            subtitle = "Gute technische Arbeit braucht gute Menschen"
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
            colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "UNSERE PHILOSOPHIE",
                    style = MaterialTheme.typography.labelSmall,
                    color = SteelSlate,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Wir verzichten auf unklare Versprechen. Bei uns zählen handwerkliche Präzision, ingenieurwissenschaftlicher Anspruch, Zuverlässigkeit und gegenseitiger Respekt. Wir investieren lückenlos in hervorragende Werkzeuge und die Weiterbildung unserer Mitarbeiter.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = DeepAnthracite,
                    lineHeight = 20.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "OFFENE STELLENANGEBOTE",
            style = MaterialTheme.typography.titleMedium,
            color = BrandBlue,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (jobList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "Aktuell keine offenen Stellen ausgeschrieben. Wir freuen uns über Ihre Initiativbewerbung!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SteelSlate,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(jobList) { job ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp))
                            .clickable { viewModel.navigateTo(Screen.KarriereDetail(job.id)) },
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = job.workingHours.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (job.workingHours.contains("Duales")) RustOrange else BrandBlueLight,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = job.location,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SteelSlate
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = job.title,
                                style = MaterialTheme.typography.titleLarge,
                                color = BrandBlue,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("job_title_${job.id}")
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "STELLENPROFIL ANSEHEN →",
                                style = MaterialTheme.typography.labelLarge,
                                color = BrandBlueLight,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KarriereDetailScreen(
    jobId: Int,
    viewModel: MainViewModel,
    jobList: List<JobOpening>
) {
    BackHandler { viewModel.navigateTo(Screen.Karriere) }
    val job = jobList.find { it.id == jobId }
    val scrollState = rememberScrollState()

    // Form inputs
    var applicantName by remember { mutableStateOf("") }
    var applicantEmail by remember { mutableStateOf("") }
    var applicantPhone by remember { mutableStateOf("") }
    var applicantLetter by remember { mutableStateOf("") }
    var uploadFileName by remember { mutableStateOf("") }

    var isSubmitting by remember { mutableStateOf(false) }
    val submitted by viewModel.submittedApplication.collectAsState()

    if (job == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Stelle nicht gefunden.", color = ErrorRed)
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateTo(Screen.Karriere) },
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Zurück", tint = BrandBlue)
            }
            Text(
                text = "STELLENANGEBOT / DETAILED",
                style = MaterialTheme.typography.labelLarge,
                color = SteelSlate,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = job.title,
            style = MaterialTheme.typography.displaySmall,
            color = BrandBlue,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.testTag("job_detail_title")
        )
        Text(
            text = "${job.location} · ${job.workingHours}",
            style = MaterialTheme.typography.titleMedium,
            color = SteelSlate
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Job details columns
        val sections = listOf(
            "Ihre Aufgaben" to job.tasks,
            "Ihre Qualifikationen" to job.requirements,
            "Was wir bieten" to job.benefits
        )

        sections.forEach { (title, content) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = title.uppercase(),
                        style = MaterialTheme.typography.titleMedium,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    content.split(";").forEach { bullet ->
                        if (bullet.trim().isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = "▪",
                                    color = BrandBlueLight,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = bullet.trim(),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = DeepAnthracite
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Application form
        SectionHeader(title = "Direktbewerbung", subtitle = "Senden Sie uns Ihre Bewerbungsdaten lückenlos zu")

        if (submitted) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SuccessGreen, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "VIELEN DANK FÜR IHRE BEWERBUNG",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Ihre Unterlagen wurden erfolgreich in unser System geladen. Die Personalabteilung prüft Ihre Daten und wird sich zeitnah mit Ihnen in Verbindung setzen.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.clearSubmittedApplication() },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Text("WEITERE BEWERBUNG")
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = applicantName,
                        onValueChange = { applicantName = it },
                        label = { Text("Vor- und Nachname") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .testTag("input_applicant_name"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = applicantEmail,
                        onValueChange = { applicantEmail = it },
                        label = { Text("E-Mail-Adresse") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .testTag("input_applicant_email"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )

                    OutlinedTextField(
                        value = applicantPhone,
                        onValueChange = { applicantPhone = it },
                        label = { Text("Telefonnummer") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .testTag("input_applicant_phone"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )

                    OutlinedTextField(
                        value = applicantLetter,
                        onValueChange = { applicantLetter = it },
                        label = { Text("Kurzes Anschreiben / Nachricht") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .padding(bottom = 12.dp)
                            .testTag("input_applicant_letter")
                    )

                    // File upload simulation row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { uploadFileName = "Lebenslauf_Anschreiben_${applicantName.replace(" ", "_")}.pdf" },
                            border = BorderStroke(1.dp, BrandBlue),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null, tint = BrandBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("PDF HOCHLADEN", color = BrandBlue, style = MaterialTheme.typography.labelLarge)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (uploadFileName.isNotEmpty()) uploadFileName else "Keine Datei ausgewählt",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (uploadFileName.isNotEmpty()) SuccessGreen else SteelSlate
                        )
                    }

                    Button(
                        onClick = {
                            if (applicantName.isNotEmpty() && applicantEmail.isNotEmpty()) {
                                isSubmitting = true
                                viewModel.submitJobApplication(
                                    jobId = job.id,
                                    jobTitle = job.title,
                                    name = applicantName,
                                    email = applicantEmail,
                                    phone = applicantPhone,
                                    coverLetter = applicantLetter,
                                    fileAttachmentName = uploadFileName
                                )
                                isSubmitting = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        shape = RoundedCornerShape(4.dp),
                        enabled = applicantName.isNotEmpty() && applicantEmail.isNotEmpty(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("btn_apply_submit")
                    ) {
                        Text("JETZT BEWERBEN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- 22 — DOWNLOAD CENTER ---
@Composable
fun DownloadsScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.Home) }
    var downloadingId by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableStateOf(0f) }

    LaunchedEffect(downloadingId) {
        if (downloadingId != null) {
            progress = 0f
            while (progress < 1.0f) {
                kotlinx.coroutines.delay(200)
                progress += 0.2f
            }
            downloadingId = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Download-Center",
            subtitle = "Zertifikate, Broschüren und technische Datenblätter"
        )

        val docs = listOf(
            Triple("PK-BRO-01", "Unternehmensbroschüre (Gesamtübersicht)", "PDF, 4.2 MB"),
            Triple("PK-ZERT-9001", "ISO 9001 Zertifizierungs-Nachweis", "PDF, 1.8 MB"),
            Triple("PK-SPEC-CNC", "CNC-Zerspanungsmaschinen - Datenblätter", "PDF, 8.5 MB"),
            Triple("PK-AUST-2026", "Ausschreibungsunterlagen standardisiert", "ZIP, 14.2 MB"),
            Triple("PK-AGB-2026", "Allgemeine Geschäftsbedingungen B2B", "PDF, 0.4 MB")
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(docs) { (id, title, meta) ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = id,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SteelSlate,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = BrandBlue,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = meta,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SteelSlate
                                )
                            }

                            Box(modifier = Modifier.width(120.dp), contentAlignment = Alignment.Center) {
                                if (downloadingId == id) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        LinearProgressIndicator(
                                            progress = progress,
                                            color = BrandBlue,
                                            trackColor = ConcreteGray,
                                            modifier = Modifier.fillMaxWidth().height(4.dp)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("${(progress * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = BrandBlue)
                                    }
                                } else {
                                    Button(
                                        onClick = { downloadingId = id },
                                        colors = ButtonDefaults.buttonColors(containerColor = CoolGreyLight),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.minimumInteractiveComponentSize().testTag("btn_download_$id")
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = "Download", tint = BrandBlue)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("PDF", color = BrandBlue, style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- 23 — PRESSE & NEWS ---
@Composable
fun NewsScreen(
    viewModel: MainViewModel,
    newsList: List<NewsArticle>
) {
    BackHandler { viewModel.navigateTo(Screen.Home) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "News / Presse",
            subtitle = "Zurückhaltende Unternehmensmeldungen und technische Meilensteine"
        )

        if (newsList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Keine Meldungen vorhanden.", style = MaterialTheme.typography.bodyLarge, color = SteelSlate)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                items(newsList) { article ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = article.category.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (article.category == "Technologie") RustOrange else BrandBlueLight,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = article.date,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SteelSlate
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = article.title,
                                style = MaterialTheme.typography.titleLarge,
                                color = BrandBlue,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("news_title_${article.id}")
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = article.content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = DeepAnthracite,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- 19 & 20 — KONTAKT & ENHANCED INQUIRY SYSTEM ---
@Composable
fun KontaktScreen(viewModel: MainViewModel) {
    BackHandler { viewModel.navigateTo(Screen.Home) }
    val scrollState = rememberScrollState()

    // Form selection
    val inquiryTypes = listOf(
        "Allgemeine Anfrage",
        "Projektanfrage",
        "Technische Anfrage",
        "Service / Support",
        "Karriere",
        "Lieferant werden"
    )
    var selectedType by remember { mutableStateOf(inquiryTypes[0]) }

    // Standard Fields
    var clientName by remember { mutableStateOf("") }
    var clientCompany by remember { mutableStateOf("") }
    var clientEmail by remember { mutableStateOf("") }
    var clientPhone by remember { mutableStateOf("") }
    var inquirySubject by remember { mutableStateOf("") }
    var inquiryMessage by remember { mutableStateOf("") }

    // Specialized Project Request Fields
    var projectSector by remember { mutableStateOf("") }
    var projectLocation by remember { mutableStateOf("") }
    var projectScope by remember { mutableStateOf("") }
    var projectTimeline by remember { mutableStateOf("") }
    var uploadFileName by remember { mutableStateOf("") }

    val submittedResult by viewModel.submittedInquiry.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Anfragesystem",
            subtitle = "Wählen Sie das passende Anfrage-Modul für Ihr technisches Anliegen"
        )

        if (submittedResult != null) {
            // Confirmation Screen
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SuccessGreen, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "VIELEN DANK FÜR IHRE ANFRAGE",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Ihre Anfrage wurde erfolgreich übermittelt. Ein technischer Mitarbeiter von PETER & KREBS wird sich zeitnah mit Ihnen in Verbindung setzen.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "TICKET-NUMMER: ${submittedResult!!.ticketNumber}", style = MaterialTheme.typography.labelLarge, color = BrandBlue, fontWeight = FontWeight.Bold)
                            Text(text = "TYP: ${submittedResult!!.type}", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)
                            Text(text = "ABSENDER: ${submittedResult!!.name} (${submittedResult!!.company})", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)
                            Text(text = "BETREFF: ${submittedResult!!.subject}", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { viewModel.clearSubmittedInquiry() },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("btn_new_inquiry")
                    ) {
                        Text("NEUE ANFRAGE STARTEN")
                    }
                }
            }
        } else {
            // Dropdown Selector
            Text(
                text = "ANFRAGE-TYP WÄHLEN",
                style = MaterialTheme.typography.labelSmall,
                color = SteelSlate,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            var expandedDropdown by remember { mutableStateOf(false) }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                OutlinedButton(
                    onClick = { expandedDropdown = true },
                    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("btn_dropdown_inquiry_type"),
                    border = BorderStroke(1.dp, BrandBlue),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(selectedType, color = BrandBlue, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = BrandBlue)
                    }
                }
                DropdownMenu(
                    expanded = expandedDropdown,
                    onDismissRequest = { expandedDropdown = false },
                    modifier = Modifier.fillMaxWidth().background(PureWhite)
                ) {
                    inquiryTypes.forEach { type ->
                        DropdownMenuItem(
                            text = { Text(type, style = MaterialTheme.typography.bodyLarge, color = DeepAnthracite) },
                            onClick = {
                                selectedType = type
                                expandedDropdown = false
                            },
                            modifier = Modifier.testTag("inquiry_type_option_$type")
                        )
                    }
                }
            }

            // Interactive Form Container
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "KONTAKTINFORMATIONEN",
                        style = MaterialTheme.typography.labelSmall,
                        color = SteelSlate,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = clientName,
                        onValueChange = { clientName = it },
                        label = { Text("Ansprechpartner (Vor- und Nachname)") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("inquiry_client_name"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = clientCompany,
                        onValueChange = { clientCompany = it },
                        label = { Text("Unternehmen / Organisation") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("inquiry_client_company"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = clientEmail,
                        onValueChange = { clientEmail = it },
                        label = { Text("E-Mail-Adresse") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("inquiry_client_email"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )

                    OutlinedTextField(
                        value = clientPhone,
                        onValueChange = { clientPhone = it },
                        label = { Text("Telefonnummer (direkte Durchwahl)") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("inquiry_client_phone"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )

                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = ConcreteGray)

                    // Specialized Fields if "Projektanfrage"
                    if (selectedType == "Projektanfrage") {
                        Text(
                            text = "SPEZIFISCHE PROJEKTDATEN",
                            style = MaterialTheme.typography.labelSmall,
                            color = SteelSlate,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )

                        OutlinedTextField(
                            value = projectSector,
                            onValueChange = { projectSector = it },
                            label = { Text("Branche des Projekts") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("inquiry_proj_sector"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = projectLocation,
                            onValueChange = { projectLocation = it },
                            label = { Text("Geplanter Standort / Montageort") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("inquiry_proj_location"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = projectScope,
                            onValueChange = { projectScope = it },
                            label = { Text("Leistungsumfang (z.B. Engineering, Fertigung)") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("inquiry_proj_scope"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = projectTimeline,
                            onValueChange = { projectTimeline = it },
                            label = { Text("Gewünschter Fertigstellungs-Termin") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("inquiry_proj_timeline"),
                            singleLine = true
                        )
                    }

                    Text(
                        text = "ANLIEGEN & NACHRICHT",
                        style = MaterialTheme.typography.labelSmall,
                        color = SteelSlate,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    OutlinedTextField(
                        value = inquirySubject,
                        onValueChange = { inquirySubject = it },
                        label = { Text("Betreff") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("inquiry_subject"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = inquiryMessage,
                        onValueChange = { inquiryMessage = it },
                        label = { Text("Ausführliche technische Beschreibung") },
                        modifier = Modifier.fillMaxWidth().height(140.dp).padding(bottom = 12.dp).testTag("inquiry_message")
                    )

                    // Simulated upload for blueprints / specifications
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { uploadFileName = "Spezifikation_Lastenheft_${clientCompany.replace(" ", "_")}.pdf" },
                            border = BorderStroke(1.dp, BrandBlue),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("btn_blueprint_upload")
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null, tint = BrandBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("LASTENHEFT/CAD HOCHLADEN", color = BrandBlue, style = MaterialTheme.typography.labelLarge)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (uploadFileName.isNotEmpty()) uploadFileName else "Optional (.pdf / .step)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (uploadFileName.isNotEmpty()) SuccessGreen else SteelSlate
                        )
                    }

                    // Submit Button with simple validation
                    val isValid = clientName.isNotEmpty() && clientEmail.isNotEmpty() && inquirySubject.isNotEmpty() && inquiryMessage.isNotEmpty()
                    Button(
                        onClick = {
                            if (isValid) {
                                viewModel.submitInquiry(
                                    type = selectedType,
                                    name = clientName,
                                    company = clientCompany,
                                    email = clientEmail,
                                    phone = clientPhone,
                                    subject = inquirySubject,
                                    message = inquiryMessage,
                                    projectScope = projectScope,
                                    desiredTimeline = projectTimeline,
                                    sector = projectSector,
                                    location = projectLocation,
                                    fileAttachmentName = uploadFileName
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        shape = RoundedCornerShape(4.dp),
                        enabled = isValid,
                        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("btn_inquiry_submit")
                    ) {
                        Text("ANFRAGE SENDEN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Contact directly
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "DIREKTE KONTAKTDATEN", style = MaterialTheme.typography.titleMedium, color = BrandBlue, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Zentrale Waiblingen / Stuttgart:\nTelefon: +49 (0) 7151 9028-0\nE-Mail: info@peter-krebs.de\n\nGeschäftszeiten Werktags:\n07:30 Uhr - 17:00 Uhr (Fr. bis 15:30 Uhr)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DeepAnthracite,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}

// --- 24 — B2B KUNDENPORTAL ---
@Composable
fun KundenportalScreen(
    viewModel: MainViewModel,
    invoices: List<PortalInvoice>,
    supportTickets: List<SupportCase>
) {
    BackHandler { viewModel.navigateTo(Screen.Home) }
    val scrollState = rememberScrollState()

    // Mock Portal Session data
    val company by viewModel.portalUserCompany.collectAsState()

    // Support Form variables
    var showAddTicket by remember { mutableStateOf(false) }
    var ticketCategory by remember { mutableStateOf("Störung") }
    var ticketPriority by remember { mutableStateOf("Mittel") }
    var ticketProject by remember { mutableStateOf("Produktionsanlage A-8") }
    var ticketDesc by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "B2B-Kundenportal",
            subtitle = "Geschützter Bereich für laufende Projekte und Dokumentation"
        )

        if (company == null) {
            // Portal Sign-In Mock
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = BrandBlue, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "ANMELDUNG KUNDENPORTAL",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrandBlue,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Für den Zugang zu Ihren Projektdaten, technischen Zeichnungen und Rechnungen verwenden Sie bitte Ihre Firmen-ID.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SteelSlate,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { viewModel.setPortalUser("Mittelständischer Maschinenbau AG") },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("btn_portal_mock_login")
                    ) {
                        Text("MOCK-ZUGANG AKTIVIEREN")
                    }
                }
            }
        } else {
            // Logged-in Portal Dashboard
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = JetBlack),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "ANGEMELDET ALS", style = MaterialTheme.typography.labelSmall, color = SteelSlate)
                        Text(text = company!!, style = MaterialTheme.typography.titleMedium, color = PureWhite, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { viewModel.setPortalUser(null) },
                        border = BorderStroke(1.dp, ConcreteGray),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("btn_portal_logout")
                    ) {
                        Text("ABMELDEN", color = PureWhite, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 1: Active Projects
            Text(
                text = "LAUFENDE PROJEKTE",
                style = MaterialTheme.typography.titleMedium,
                color = BrandBlue,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "PRODUKTIONSANLAGE A-8 (IN INBETRIEBNAHME)", style = MaterialTheme.typography.titleMedium, color = BrandBlue, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Status: Vor-Ort-Montage läuft · Abnahmetermin: 15.11.2026", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = 0.82f,
                        color = BrandBlue,
                        trackColor = ConcreteGray,
                        modifier = Modifier.fillMaxWidth().height(6.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Fortschritt: 82% abgeschlossen", style = MaterialTheme.typography.labelSmall, color = SteelSlate)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 2: Rechnungsübersicht (B2B Table style)
            Text(
                text = "RECHNUNGSÜBERSICHT",
                style = MaterialTheme.typography.titleMedium,
                color = BrandBlue,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    invoices.forEach { invoice ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = invoice.invoiceNumber, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SteelSlate)
                                Text(text = invoice.projectTitle, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = BrandBlue)
                                Text(text = "Fällig am ${invoice.dueDate}", style = MaterialTheme.typography.labelSmall, color = SteelSlate)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "%,.2f €".format(Locale.GERMANY, invoice.amount), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BrandBlue)
                                val badgeColor = when (invoice.status) {
                                    "Bezahlt" -> SuccessGreen
                                    "Offen" -> WarningYellow
                                    else -> ErrorRed
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(badgeColor.copy(alpha = 0.1f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(text = invoice.status, style = MaterialTheme.typography.labelSmall, color = badgeColor, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Divider(color = ConcreteGray.copy(alpha = 0.5f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 3: B2B Support Tickets
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SERVICE-FÄLLE & SUPPORT",
                    style = MaterialTheme.typography.titleMedium,
                    color = BrandBlue,
                    fontWeight = FontWeight.Bold
                )
                TextButton(
                    onClick = { showAddTicket = !showAddTicket },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("btn_toggle_add_ticket")
                ) {
                    Text(if (showAddTicket) "SCHLIESSEN" else "NEUES TICKET", color = BrandBlueLight, fontWeight = FontWeight.Bold)
                }
            }

            if (showAddTicket) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .border(1.dp, BrandBlue, RoundedCornerShape(4.dp)),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "STÖRUNG ODER SERVICE MELDEN", style = MaterialTheme.typography.labelSmall, color = SteelSlate, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Category
                        OutlinedTextField(
                            value = ticketCategory,
                            onValueChange = { ticketCategory = it },
                            label = { Text("Kategorie (z.B. Störung, Wartungsanfrage)") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("ticket_category"),
                            singleLine = true
                        )

                        // Priority
                        OutlinedTextField(
                            value = ticketPriority,
                            onValueChange = { ticketPriority = it },
                            label = { Text("Priorität (Hoch, Mittel, Niedrig)") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("ticket_priority"),
                            singleLine = true
                        )

                        // Description
                        OutlinedTextField(
                            value = ticketDesc,
                            onValueChange = { ticketDesc = it },
                            label = { Text("Technische Fehlerbeschreibung") },
                            modifier = Modifier.fillMaxWidth().height(100.dp).padding(bottom = 16.dp).testTag("ticket_description")
                        )

                        Button(
                            onClick = {
                                if (ticketDesc.isNotEmpty()) {
                                    viewModel.submitSupportCase(
                                        clientCompany = company!!,
                                        projectTitle = ticketProject,
                                        category = ticketCategory,
                                        priority = ticketPriority,
                                        description = ticketDesc
                                    )
                                    ticketDesc = ""
                                    showAddTicket = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                            shape = RoundedCornerShape(4.dp),
                            enabled = ticketDesc.isNotEmpty(),
                            modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("btn_ticket_submit")
                        ) {
                            Text("TICKET EINREICHEN", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            val clientTickets = supportTickets.filter { it.clientCompany == company }

            if (clientTickets.isEmpty()) {
                Text("Keine aktiven Tickets vorhanden.", style = MaterialTheme.typography.bodyMedium, color = SteelSlate)
            } else {
                clientTickets.forEach { ticket ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = ticket.ticketNumber, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = BrandBlue)
                                val badgeColor = when (ticket.status) {
                                    "Gelöst" -> SuccessGreen
                                    "In Bearbeitung" -> WarningYellow
                                    else -> ErrorRed
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(badgeColor.copy(alpha = 0.1f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(text = ticket.status.uppercase(), style = MaterialTheme.typography.labelSmall, color = badgeColor, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "${ticket.category} · Priorität ${ticket.priority}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BrandBlue)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = ticket.description, style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)
                        }
                    }
                }
            }
        }
    }
}

// --- 25 — ADMINISTRATION / INTERNAL CMS ---
@Composable
fun AdminScreen(
    viewModel: MainViewModel,
    inquiriesList: List<Inquiry>,
    applicationsList: List<JobApplication>,
    supportList: List<SupportCase>
) {
    BackHandler { viewModel.navigateTo(Screen.Home) }
    var currentTab by remember { mutableStateOf("Anfragen") } // "Anfragen", "Bewerbungen", "Servicefälle", "Inhalte"
    val scrollState = rememberScrollState()

    // Form states for creating new content
    var showCreateProject by remember { mutableStateOf(false) }
    var newProjName by remember { mutableStateOf("") }
    var newProjSector by remember { mutableStateOf("") }
    var newProjLocation by remember { mutableStateOf("") }
    var newProjDuration by remember { mutableStateOf("") }
    var newProjServices by remember { mutableStateOf("") }
    var newProjChallenge by remember { mutableStateOf("") }
    var newProjSolution by remember { mutableStateOf("") }
    var newProjResult by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "CMS Backend",
            subtitle = "Sicherheitsgeschütztes internes Kontrollzentrum"
        )

        // Tab Selector Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tabs = listOf("Anfragen", "Bewerbungen", "Servicefälle", "Inhalte erstellen")
            tabs.forEach { tab ->
                FilterChip(
                    selected = currentTab == tab,
                    onClick = { currentTab = tab },
                    label = { Text(tab) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BrandBlue,
                        selectedLabelColor = PureWhite,
                        containerColor = CoolGreyLight,
                        labelColor = DeepAnthracite
                    ),
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("admin_tab_$tab")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (currentTab) {
            "Anfragen" -> {
                if (inquiriesList.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Keine Anfragen vorliegend.", color = SteelSlate)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(inquiriesList) { inquiry ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = inquiry.ticketNumber, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = BrandBlue)
                                        Text(
                                            text = inquiry.status.uppercase(),
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (inquiry.status == "Beantwortet") SuccessGreen else ErrorRed
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "[${inquiry.type}] ${inquiry.subject}", style = MaterialTheme.typography.titleMedium, color = BrandBlue, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "Absender: ${inquiry.name}\nFirma: ${inquiry.company}\nE-Mail: ${inquiry.email}\nTel: ${inquiry.phone}", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(text = "Beschreibung:\n${inquiry.message}", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)

                                    if (inquiry.type == "Projektanfrage") {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Branche: ${inquiry.sector}\nOrt: ${inquiry.location}\nUmfang: ${inquiry.projectScope}\nTermin: ${inquiry.desiredTimeline}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = SteelSlate
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { viewModel.updateInquiryStatus(inquiry.id, "Beantwortet") },
                                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.minimumInteractiveComponentSize().testTag("btn_inquiry_resolve_${inquiry.id}")
                                        ) {
                                            Text("Als erledigt markieren", style = MaterialTheme.typography.labelSmall)
                                        }
                                        OutlinedButton(
                                            onClick = { viewModel.updateInquiryStatus(inquiry.id, "In Bearbeitung") },
                                            border = BorderStroke(1.dp, WarningYellow),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Text("In Bearbeitung", color = WarningYellow, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "Bewerbungen" -> {
                if (applicationsList.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Keine eingegangenen Bewerbungen vorhanden.", color = SteelSlate)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(applicationsList) { app ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = app.jobTitle.uppercase(), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = BrandBlue)
                                        Text(text = "STATUS: ${app.status}", style = MaterialTheme.typography.labelSmall, color = WarningYellow, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "Kandidat: ${app.name}", style = MaterialTheme.typography.titleMedium, color = BrandBlue, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "E-Mail: ${app.email}\nTel: ${app.phone}\nAnhang: ${app.fileAttachmentName}", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(text = "Anschreiben:\n${app.coverLetter}", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { viewModel.updateApplicationStatus(app.id, "Eingeladen") },
                                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.minimumInteractiveComponentSize().testTag("btn_app_invite_${app.id}")
                                        ) {
                                            Text("Einladen", style = MaterialTheme.typography.labelSmall)
                                        }
                                        Button(
                                            onClick = { viewModel.updateApplicationStatus(app.id, "Abgelehnt") },
                                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Text("Absagen", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "Servicefälle" -> {
                if (supportList.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Keine aktiven Service-Tickets vorhanden.", color = SteelSlate)
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(supportList) { ticket ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, ConcreteGray, RoundedCornerShape(4.dp)),
                                colors = CardDefaults.cardColors(containerColor = PureWhite),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = ticket.ticketNumber, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = BrandBlue)
                                        Text(text = "PRIORITÄT: ${ticket.priority}", style = MaterialTheme.typography.labelSmall, color = ErrorRed, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "[${ticket.clientCompany}] ${ticket.category}", style = MaterialTheme.typography.titleMedium, color = BrandBlue, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "Projekt: ${ticket.projectTitle}", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "Beschreibung:\n${ticket.description}", style = MaterialTheme.typography.bodyMedium, color = DeepAnthracite)

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { viewModel.updateSupportCaseStatus(ticket.id, "Gelöst") },
                                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.minimumInteractiveComponentSize().testTag("btn_ticket_resolve_${ticket.id}")
                                        ) {
                                            Text("Als Gelöst markieren", style = MaterialTheme.typography.labelSmall)
                                        }
                                        OutlinedButton(
                                            onClick = { viewModel.updateSupportCaseStatus(ticket.id, "In Bearbeitung") },
                                            border = BorderStroke(1.dp, WarningYellow),
                                            shape = RoundedCornerShape(4.dp),
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Text("In Bearbeitung", color = WarningYellow, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            else -> {
                // Contents administration creation form
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                ) {
                    TextButton(
                        onClick = { showCreateProject = !showCreateProject },
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("btn_show_create_project")
                    ) {
                        Text(if (showCreateProject) "[-] Projektformular ausblenden" else "[+] Neues Referenzprojekt eintragen", color = BrandBlue, fontWeight = FontWeight.Bold)
                    }

                    if (showCreateProject) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BrandBlue, RoundedCornerShape(4.dp)),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                OutlinedTextField(
                                    value = newProjName,
                                    onValueChange = { newProjName = it },
                                    label = { Text("Projektname") },
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).testTag("admin_proj_name"),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = newProjSector,
                                    onValueChange = { newProjSector = it },
                                    label = { Text("Branche") },
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).testTag("admin_proj_sector"),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = newProjLocation,
                                    onValueChange = { newProjLocation = it },
                                    label = { Text("Standort") },
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = newProjDuration,
                                    onValueChange = { newProjDuration = it },
                                    label = { Text("Laufzeit (z.B. 12 Monate)") },
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = newProjServices,
                                    onValueChange = { newProjServices = it },
                                    label = { Text("Leistungen (Komma-separiert)") },
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = newProjChallenge,
                                    onValueChange = { newProjChallenge = it },
                                    label = { Text("Technische Herausforderung") },
                                    modifier = Modifier.fillMaxWidth().height(100.dp).padding(bottom = 8.dp)
                                )
                                OutlinedTextField(
                                    value = newProjSolution,
                                    onValueChange = { newProjSolution = it },
                                    label = { Text("Lösung & Umsetzung") },
                                    modifier = Modifier.fillMaxWidth().height(100.dp).padding(bottom = 8.dp)
                                )
                                OutlinedTextField(
                                    value = newProjResult,
                                    onValueChange = { newProjResult = it },
                                    label = { Text("Ergebnis & Kundennutzen") },
                                    modifier = Modifier.fillMaxWidth().height(80.dp).padding(bottom = 12.dp)
                                )

                                Button(
                                    onClick = {
                                        if (newProjName.isNotEmpty() && newProjSector.isNotEmpty()) {
                                            viewModel.addProject(
                                                name = newProjName,
                                                sector = newProjSector,
                                                location = newProjLocation,
                                                duration = newProjDuration,
                                                services = newProjServices,
                                                challenge = newProjChallenge,
                                                solution = newProjSolution,
                                                result = newProjResult
                                            )
                                            newProjName = ""
                                            newProjSector = ""
                                            newProjLocation = ""
                                            newProjDuration = ""
                                            newProjServices = ""
                                            newProjChallenge = ""
                                            newProjSolution = ""
                                            newProjResult = ""
                                            showCreateProject = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BrandBlue),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("btn_admin_save_project")
                                ) {
                                    Text("PROJEKT SPEICHERN", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
