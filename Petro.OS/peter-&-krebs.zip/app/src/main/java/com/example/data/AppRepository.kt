package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val appDao: AppDao) {

    // --- Inquiries ---
    val allInquiries: Flow<List<Inquiry>> = appDao.getAllInquiries()
    suspend fun insertInquiry(inquiry: Inquiry) = appDao.insertInquiry(inquiry)
    suspend fun updateInquiry(inquiry: Inquiry) = appDao.updateInquiry(inquiry)
    suspend fun deleteInquiry(id: Int) = appDao.deleteInquiry(id)

    // --- Projects ---
    val allProjects: Flow<List<Project>> = appDao.getAllProjects()
    suspend fun insertProject(project: Project) = appDao.insertProject(project)
    suspend fun updateProject(project: Project) = appDao.updateProject(project)
    suspend fun deleteProject(id: Int) = appDao.deleteProject(id)

    // --- Job Openings ---
    val allJobOpenings: Flow<List<JobOpening>> = appDao.getAllJobOpenings()
    suspend fun insertJobOpening(jobOpening: JobOpening) = appDao.insertJobOpening(jobOpening)
    suspend fun updateJobOpening(jobOpening: JobOpening) = appDao.updateJobOpening(jobOpening)
    suspend fun deleteJobOpening(id: Int) = appDao.deleteJobOpening(id)

    // --- Job Applications ---
    val allJobApplications: Flow<List<JobApplication>> = appDao.getAllJobApplications()
    suspend fun insertJobApplication(jobApplication: JobApplication) = appDao.insertJobApplication(jobApplication)
    suspend fun updateJobApplication(jobApplication: JobApplication) = appDao.updateJobApplication(jobApplication)
    suspend fun deleteJobApplication(id: Int) = appDao.deleteJobApplication(id)

    // --- News Articles ---
    val allNewsArticles: Flow<List<NewsArticle>> = appDao.getAllNewsArticles()
    suspend fun insertNewsArticle(article: NewsArticle) = appDao.insertNewsArticle(article)
    suspend fun updateNewsArticle(article: NewsArticle) = appDao.updateNewsArticle(article)
    suspend fun deleteNewsArticle(id: Int) = appDao.deleteNewsArticle(id)

    // --- Support Cases ---
    val allSupportCases: Flow<List<SupportCase>> = appDao.getAllSupportCases()
    suspend fun insertSupportCase(supportCase: SupportCase) = appDao.insertSupportCase(supportCase)
    suspend fun updateSupportCase(supportCase: SupportCase) = appDao.updateSupportCase(supportCase)
    suspend fun deleteSupportCase(id: Int) = appDao.deleteSupportCase(id)

    // --- Invoices ---
    val allPortalInvoices: Flow<List<PortalInvoice>> = appDao.getAllPortalInvoices()
    suspend fun insertPortalInvoice(invoice: PortalInvoice) = appDao.insertPortalInvoice(invoice)
    suspend fun deletePortalInvoice(id: Int) = appDao.deletePortalInvoice(id)
}
