package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = CoolGreyLight,
    onPrimary = BrandBlueDark,
    primaryContainer = BrandBlueLight,
    onPrimaryContainer = PureWhite,
    secondary = SteelSlate,
    onSecondary = PureWhite,
    background = JetBlack,
    onBackground = WarmPearl,
    surface = DeepAnthracite,
    onSurface = WarmPearl,
    surfaceVariant = BrandBlueDark,
    onSurfaceVariant = ConcreteGray,
    outline = SteelSlate
)

private val LightColorScheme = lightColorScheme(
    primary = BrandBlue,
    onPrimary = PureWhite,
    primaryContainer = BrandBlueLight,
    onPrimaryContainer = PureWhite,
    secondary = SteelSlate,
    onSecondary = PureWhite,
    background = WarmPearl,
    onBackground = DeepAnthracite,
    surface = PureWhite,
    onSurface = DeepAnthracite,
    surfaceVariant = CoolGreyLight,
    onSurfaceVariant = DeepAnthracite,
    outline = ConcreteGray,
    error = ErrorRed,
    onError = PureWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // We enforce our premium corporate brand colors by default to preserve
    // the precise "PETER & KREBS" corporate industrial aesthetic.
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
