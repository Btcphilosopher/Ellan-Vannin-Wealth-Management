package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "inquiries")
data class Inquiry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "Allgemein", "Projektanfrage", "Technische Anfrage", "Service", "Karriere", "Lieferant"
    val name: String,
    val company: String,
    val email: String,
    val phone: String,
    val subject: String,
    val message: String,
    val projectScope: String = "",
    val desiredTimeline: String = "",
    val sector: String = "",
    val location: String = "",
    val fileAttachmentName: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "Neu", // "Neu", "In Bearbeitung", "Beantwortet"
    val ticketNumber: String = ""
)

@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val sector: String,
    val location: String,
    val duration: String,
    val services: String, // Comma separated, e.g. "Engineering, Montage"
    val challenge: String,
    val solution: String,
    val result: String,
    val isDemo: Boolean = true,
    val imageResName: String = "" // "img_industrial_hero", "img_engineering_blueprint", "img_factory_assembly"
)

@Entity(tableName = "job_openings")
data class JobOpening(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val location: String,
    val workingHours: String, // "Vollzeit", "Teilzeit", "Duales Studium", "Ausbildung"
    val tasks: String, // Comma or newline separated
    val requirements: String, // Comma or newline separated
    val benefits: String // Comma or newline separated
)

@Entity(tableName = "job_applications")
data class JobApplication(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val jobId: Int,
    val jobTitle: String,
    val name: String,
    val email: String,
    val phone: String,
    val coverLetter: String,
    val fileAttachmentName: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "Eingegangen" // "Eingegangen", "In Prüfung", "Eingeladen", "Abgelehnt"
)

@Entity(tableName = "news_articles")
data class NewsArticle(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String, // "Unternehmen", "Technologie", "Projekte", "Mitarbeiter", "Messen", "Presse"
    val content: String,
    val date: String,
    val isDemo: Boolean = true
)

@Entity(tableName = "support_cases")
data class SupportCase(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val clientCompany: String,
    val projectTitle: String,
    val category: String, // "Störung", "Wartungsanfrage", "Technische Klärung"
    val priority: String, // "Hoch", "Mittel", "Niedrig"
    val description: String,
    val status: String = "Offen", // "Offen", "In Bearbeitung", "Gelöst"
    val timestamp: Long = System.currentTimeMillis(),
    val ticketNumber: String = ""
)

@Entity(tableName = "portal_invoices")
data class PortalInvoice(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val invoiceNumber: String,
    val projectTitle: String,
    val amount: Double,
    val date: String,
    val dueDate: String,
    val status: String // "Bezahlt", "Offen", "Überfällig"
)
