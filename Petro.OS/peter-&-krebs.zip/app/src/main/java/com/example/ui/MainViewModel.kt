package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class Screen {
    object Home : Screen()
    object UberUns : Screen()
    object Geschichte : Screen()
    object Qualitaet : Screen()
    object Verantwortung : Screen()
    object Standorte : Screen()
    object Leistungen : Screen()
    data class LeistungsDetail(val category: String) : Screen()
    object Branchen : Screen()
    object Projekte : Screen()
    data class ProjektDetail(val projectId: Int) : Screen()
    object Kompetenzen : Screen()
    object Karriere : Screen()
    data class KarriereDetail(val jobId: Int) : Screen()
    object News : Screen()
    object Downloads : Screen()
    object Kontakt : Screen()
    object Kundenportal : Screen()
    object Admin : Screen()
}

class MainViewModel(private val repository: AppRepository) : ViewModel() {

    // --- Navigation Backstack ---
    private val backstack = mutableListOf<Screen>()
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            backstack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (backstack.isNotEmpty()) {
            _currentScreen.value = backstack.removeAt(backstack.size - 1)
            return true
        }
        return false
    }

    // --- Reactive Database Streams ---
    val inquiries: StateFlow<List<Inquiry>> = repository.allInquiries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val projects: StateFlow<List<Project>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobOpenings: StateFlow<List<JobOpening>> = repository.allJobOpenings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val jobApplications: StateFlow<List<JobApplication>> = repository.allJobApplications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val newsArticles: StateFlow<List<NewsArticle>> = repository.allNewsArticles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val supportCases: StateFlow<List<SupportCase>> = repository.allSupportCases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val portalInvoices: StateFlow<List<PortalInvoice>> = repository.allPortalInvoices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())


    // --- Inquiry Submission state ---
    private val _submittedInquiry = MutableStateFlow<Inquiry?>(null)
    val submittedInquiry = _submittedInquiry.asStateFlow()

    fun clearSubmittedInquiry() {
        _submittedInquiry.value = null
    }

    fun submitInquiry(
        type: String,
        name: String,
        company: String,
        email: String,
        phone: String,
        subject: String,
        message: String,
        projectScope: String = "",
        desiredTimeline: String = "",
        sector: String = "",
        location: String = "",
        fileAttachmentName: String = ""
    ) {
        viewModelScope.launch {
            val count = (inquiries.value.size + 1).toString().padStart(4, '0')
            val ticketNumber = "PK-ANF-26-$count"
            val newInquiry = Inquiry(
                type = type,
                name = name,
                company = company,
                email = email,
                phone = phone,
                subject = subject,
                message = message,
                projectScope = projectScope,
                desiredTimeline = desiredTimeline,
                sector = sector,
                location = location,
                fileAttachmentName = fileAttachmentName,
                status = "Neu",
                ticketNumber = ticketNumber
            )
            repository.insertInquiry(newInquiry)
            _submittedInquiry.value = newInquiry
        }
    }

    // --- Job Application Submission ---
    private val _submittedApplication = MutableStateFlow<Boolean>(false)
    val submittedApplication = _submittedApplication.asStateFlow()

    fun clearSubmittedApplication() {
        _submittedApplication.value = false
    }

    fun submitJobApplication(
        jobId: Int,
        jobTitle: String,
        name: String,
        email: String,
        phone: String,
        coverLetter: String,
        fileAttachmentName: String = ""
    ) {
        viewModelScope.launch {
            val app = JobApplication(
                jobId = jobId,
                jobTitle = jobTitle,
                name = name,
                email = email,
                phone = phone,
                coverLetter = coverLetter,
                fileAttachmentName = fileAttachmentName,
                status = "Eingegangen"
            )
            repository.insertJobApplication(app)
            _submittedApplication.value = true
        }
    }

    // --- Support Case Submission (B2B Portal) ---
    fun submitSupportCase(
        clientCompany: String,
        projectTitle: String,
        category: String,
        priority: String,
        description: String
    ) {
        viewModelScope.launch {
            val count = (supportCases.value.size + 1).toString().padStart(4, '0')
            val ticketNumber = "PK-SRV-26-$count"
            val supportCase = SupportCase(
                clientCompany = clientCompany,
                projectTitle = projectTitle,
                category = category,
                priority = priority,
                description = description,
                status = "Offen",
                ticketNumber = ticketNumber
            )
            repository.insertSupportCase(supportCase)
        }
    }


    // --- CMS / Admin Methods ---
    fun addProject(
        name: String,
        sector: String,
        location: String,
        duration: String,
        services: String,
        challenge: String,
        solution: String,
        result: String,
        imageResName: String = "img_industrial_hero"
    ) {
        viewModelScope.launch {
            val newProj = Project(
                name = name,
                sector = sector,
                location = location,
                duration = duration,
                services = services,
                challenge = challenge,
                solution = solution,
                result = result,
                isDemo = false,
                imageResName = imageResName
            )
            repository.insertProject(newProj)
        }
    }

    fun addJobOpening(
        title: String,
        location: String,
        workingHours: String,
        tasks: String,
        requirements: String,
        benefits: String
    ) {
        viewModelScope.launch {
            val job = JobOpening(
                title = title,
                location = location,
                workingHours = workingHours,
                tasks = tasks,
                requirements = requirements,
                benefits = benefits
            )
            repository.insertJobOpening(job)
        }
    }

    fun addNewsArticle(
        title: String,
        category: String,
        content: String
    ) {
        viewModelScope.launch {
            val sdf = SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY)
            val currentDate = sdf.format(Date())
            val article = NewsArticle(
                title = title,
                category = category,
                content = content,
                date = currentDate,
                isDemo = false
            )
            repository.insertNewsArticle(article)
        }
    }

    fun deleteProject(id: Int) {
        viewModelScope.launch {
            repository.deleteProject(id)
        }
    }

    fun deleteJobOpening(id: Int) {
        viewModelScope.launch {
            repository.deleteJobOpening(id)
        }
    }

    fun deleteNewsArticle(id: Int) {
        viewModelScope.launch {
            repository.deleteNewsArticle(id)
        }
    }

    fun updateInquiryStatus(id: Int, newStatus: String) {
        viewModelScope.launch {
            val currentList = inquiries.value
            val match = currentList.find { it.id == id }
            if (match != null) {
                repository.updateInquiry(match.copy(status = newStatus))
            }
        }
    }

    fun updateApplicationStatus(id: Int, newStatus: String) {
        viewModelScope.launch {
            val currentList = jobApplications.value
            val match = currentList.find { it.id == id }
            if (match != null) {
                repository.updateJobApplication(match.copy(status = newStatus))
            }
        }
    }

    fun updateSupportCaseStatus(id: Int, newStatus: String) {
        viewModelScope.launch {
            val currentList = supportCases.value
            val match = currentList.find { it.id == id }
            if (match != null) {
                repository.updateSupportCase(match.copy(status = newStatus))
            }
        }
    }

    // --- B2B Customer Portal Session Mock ---
    private val _portalUserCompany = MutableStateFlow<String?>("Mittelständischer Maschinenbau AG")
    val portalUserCompany = _portalUserCompany.asStateFlow()

    fun setPortalUser(company: String?) {
        _portalUserCompany.value = company
    }
}

class ViewModelFactory(private val repository: AppRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
