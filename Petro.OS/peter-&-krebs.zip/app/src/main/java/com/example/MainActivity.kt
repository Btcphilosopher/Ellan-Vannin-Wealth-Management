package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.data.AppDatabase
import com.example.data.AppRepository
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.ViewModelFactory
import com.example.ui.screens.*
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueLight
import com.example.ui.theme.ConcreteGray
import com.example.ui.theme.CoolGreyLight
import com.example.ui.theme.DeepAnthracite
import com.example.ui.theme.JetBlack
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RustOrange
import com.example.ui.theme.SteelSlate
import com.example.ui.theme.WarmPearl
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Room Database & Repository
        val database = AppDatabase.getDatabase(applicationContext, lifecycleScope)
        val repository = AppRepository(database.appDao())
        
        // Initialize MainViewModel with our factory
        val viewModel = ViewModelProvider(
            this, 
            ViewModelFactory(repository)
        )[MainViewModel::class.java]

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    AppContent(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun AppContent(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val projectsList by viewModel.projects.collectAsState()
    val jobList by viewModel.jobOpenings.collectAsState()
    val newsList by viewModel.newsArticles.collectAsState()
    val inquiriesList by viewModel.inquiries.collectAsState()
    val applicationsList by viewModel.jobApplications.collectAsState()
    val supportList by viewModel.supportCases.collectAsState()
    val invoicesList by viewModel.portalInvoices.collectAsState()

    var showMenuOverlay by remember { mutableStateOf(false) }

    // Intercept physical back press to safely navigate back
    BackHandler(enabled = currentScreen != Screen.Home) {
        viewModel.navigateBack()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(WarmPearl)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // --- 06 — CORPORATE HEADER ---
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ConcreteGray, RoundedCornerShape(0.dp)),
                colors = CardDefaults.cardColors(containerColor = JetBlack),
                shape = RoundedCornerShape(0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { showMenuOverlay = !showMenuOverlay },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("btn_menu_toggle")
                        ) {
                            Icon(
                                imageVector = if (showMenuOverlay) Icons.Default.Close else Icons.Default.Menu,
                                contentDescription = "Menü öffnen",
                                tint = PureWhite
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PETER & KREBS",
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            modifier = Modifier
                                .clickable {
                                    showMenuOverlay = false
                                    viewModel.navigateTo(Screen.Home)
                                }
                                .testTag("header_logo")
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Quick-CTA Inquiry Button
                        Button(
                            onClick = {
                                showMenuOverlay = false
                                viewModel.navigateTo(Screen.Kontakt)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RustOrange),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .height(38.dp)
                                .minimumInteractiveComponentSize()
                                .testTag("header_cta_anfrage")
                        ) {
                            Text(
                                text = "ANFRAGE",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = PureWhite
                            )
                        }
                    }
                }
            }

            // Simple Breadcrumbs Bar
            BreadcrumbBar(currentScreen) { screen ->
                viewModel.navigateTo(screen)
            }

            // Screen Content Area with animated transitions
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    },
                    label = "screen_navigation"
                ) { screen ->
                    when (screen) {
                        is Screen.Home -> HomeScreen(viewModel, projectsList)
                        is Screen.UberUns -> UnternehmenScreen(viewModel)
                        is Screen.Geschichte -> GeschichteScreen(viewModel)
                        is Screen.Qualitaet -> QualitaetScreen(viewModel)
                        is Screen.Verantwortung -> VerantwortungScreen(viewModel)
                        is Screen.Standorte -> StandorteScreen(viewModel)
                        is Screen.Leistungen -> LeistungenScreen(viewModel)
                        is Screen.LeistungsDetail -> LeistungsDetailScreen(screen.category, viewModel)
                        is Screen.Branchen -> BranchenScreen(viewModel)
                        is Screen.Projekte -> ProjekteScreen(viewModel, projectsList)
                        is Screen.ProjektDetail -> ProjektDetailScreen(screen.projectId, viewModel, projectsList)
                        is Screen.Kompetenzen -> KompetenzenScreen(viewModel)
                        is Screen.Karriere -> KarriereScreen(viewModel, jobList)
                        is Screen.KarriereDetail -> KarriereDetailScreen(screen.jobId, viewModel, jobList)
                        is Screen.News -> NewsScreen(viewModel, newsList)
                        is Screen.Downloads -> DownloadsScreen(viewModel)
                        is Screen.Kontakt -> KontaktScreen(viewModel)
                        is Screen.Kundenportal -> KundenportalScreen(viewModel, invoicesList, supportList)
                        is Screen.Admin -> AdminScreen(viewModel, inquiriesList, applicationsList, supportList)
                    }
                }
            }

            // --- 37 — CORPORATE FOOTER ---
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ConcreteGray, RoundedCornerShape(0.dp)),
                colors = CardDefaults.cardColors(containerColor = JetBlack),
                shape = RoundedCornerShape(0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "PETER & KREBS  ·  PRÄZISION. ERFAHRUNG. LEISTUNG.",
                        style = MaterialTheme.typography.labelSmall,
                        color = SteelSlate,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "© 2026 PETER & KREBS GmbH. Alle Rechte vorbehalten.",
                        style = MaterialTheme.typography.labelSmall,
                        color = SteelSlate,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // --- NAVIGATION DRAWER MENU OVERLAY ---
        if (showMenuOverlay) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable { showMenuOverlay = false }
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(280.dp)
                        .border(1.dp, ConcreteGray, RoundedCornerShape(0.dp))
                        .clickable(enabled = false) {},
                    colors = CardDefaults.cardColors(containerColor = JetBlack),
                    shape = RoundedCornerShape(0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "PETER & KREBS",
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(bottom = 24.dp, top = 8.dp)
                        )

                        Divider(color = SteelSlate.copy(alpha = 0.4f), modifier = Modifier.padding(bottom = 16.dp))

                        val menuItems = listOf(
                            Triple("Startseite", Screen.Home, Icons.Default.Home),
                            Triple("Unternehmen (Über Uns)", Screen.UberUns, Icons.Default.Business),
                            Triple("Leistungen", Screen.Leistungen, Icons.Default.Build),
                            Triple("Branchen", Screen.Branchen, Icons.Default.Factory),
                            Triple("Referenzprojekte", Screen.Projekte, Icons.Default.PhotoLibrary),
                            Triple("Kompetenzen", Screen.Kompetenzen, Icons.Default.Settings),
                            Triple("Karriere / Jobs", Screen.Karriere, Icons.Default.People),
                            Triple("News & Presse", Screen.News, Icons.Default.Newspaper),
                            Triple("Download-Center", Screen.Downloads, Icons.Default.CloudDownload),
                            Triple("Anfrage & Kontakt", Screen.Kontakt, Icons.Default.Mail),
                            Triple("B2B-Kundenportal", Screen.Kundenportal, Icons.Default.AccountBox),
                            Triple("CMS-Administration", Screen.Admin, Icons.Default.Lock)
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(menuItems) { menuItem ->
                                val title = menuItem.first
                                val screen = menuItem.second
                                val icon = menuItem.third
                                val isSelected = currentScreen::class == screen::class
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSelected) BrandBlueLight else Color.Transparent)
                                        .clickable {
                                            showMenuOverlay = false
                                            viewModel.navigateTo(screen)
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = title,
                                        tint = if (isSelected) PureWhite else CoolGreyLight,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = if (isSelected) PureWhite else CoolGreyLight,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.testTag("menu_item_$title")
                                    )
                                }
                            }
                        }

                        Divider(color = SteelSlate.copy(alpha = 0.4f), modifier = Modifier.padding(vertical = 16.dp))

                        // Footer within sidebar
                        Text(
                            text = "PETER & KREBS GmbH\nWaiblingen / Stuttgart\nDeutschland",
                            style = MaterialTheme.typography.labelSmall,
                            color = SteelSlate,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BreadcrumbBar(
    currentScreen: Screen,
    onNavigateHome: (Screen) -> Unit
) {
    val breadcrumbText = when (currentScreen) {
        is Screen.Home -> "Startseite"
        is Screen.UberUns -> "Startseite  >  Unternehmen"
        is Screen.Geschichte -> "Startseite  >  Unternehmen  >  Geschichte"
        is Screen.Qualitaet -> "Startseite  >  Unternehmen  >  Qualität"
        is Screen.Verantwortung -> "Startseite  >  Unternehmen  >  Verantwortung"
        is Screen.Standorte -> "Startseite  >  Unternehmen  >  Standorte"
        is Screen.Leistungen -> "Startseite  >  Leistungen"
        is Screen.LeistungsDetail -> "Startseite  >  Leistungen  >  ${currentScreen.category}"
        is Screen.Branchen -> "Startseite  >  Branchen"
        is Screen.Projekte -> "Startseite  >  Referenzen"
        is Screen.ProjektDetail -> "Startseite  >  Referenzen  >  Details"
        is Screen.Kompetenzen -> "Startseite  >  Kompetenzen"
        is Screen.Karriere -> "Startseite  >  Karriere"
        is Screen.KarriereDetail -> "Startseite  >  Karriere  >  Stellenausschreibung"
        is Screen.News -> "Startseite  >  News & Presse"
        is Screen.Downloads -> "Startseite  >  Downloads"
        is Screen.Kontakt -> "Startseite  >  Anfrage"
        is Screen.Kundenportal -> "Startseite  >  B2B-Portal"
        is Screen.Admin -> "Startseite  >  CMS-Backend"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ConcreteGray.copy(alpha = 0.5f), RoundedCornerShape(0.dp)),
        colors = CardDefaults.cardColors(containerColor = CoolGreyLight),
        shape = RoundedCornerShape(0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.LocationSearching, contentDescription = null, tint = SteelSlate, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = breadcrumbText.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = SteelSlate,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}
