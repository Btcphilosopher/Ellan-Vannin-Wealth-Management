package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        Inquiry::class,
        Project::class,
        JobOpening::class,
        JobApplication::class,
        NewsArticle::class,
        SupportCase::class,
        PortalInvoice::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "peter_krebs_db"
                )
                .addCallback(AppDatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.appDao())
                }
            }
        }

        suspend fun populateDatabase(dao: AppDao) {
            // Pre-populate Projects (with real-looking German technical descriptions)
            val p1 = Project(
                name = "Produktionsanlage A-8",
                sector = "Maschinenbau",
                location = "Stuttgart, Deutschland",
                duration = "14 Monate",
                services = "Engineering, Automatisierung, Montage",
                challenge = "Konstruktion einer vollautomatisierten Produktionslinie unter extremen Raum- und Taktzeitvorgaben. Gewährleistung einer lückenlosen Prozessüberwachung.",
                solution = "Entwicklung über detaillierte 3D-CAD-Simulationen vorab. Einsatz modularer Steuerungseinheiten und dezentraler Profinet-Peripherie.",
                result = "Inbetriebnahme 3 Wochen vor Plan abgeschlossen. Steigerung des Anlagendurchsatzes um 35% bei einer Ausschussrate von unter 0,02%.",
                imageResName = "img_industrial_hero"
            )
            val p2 = Project(
                name = "Energiepark Nord - Grosskompressor",
                sector = "Energie",
                location = "Hamburg, Deutschland",
                duration = "8 Monate",
                services = "Projektmanagement, Montage, Instandhaltung",
                challenge = "Präzisionsmontage und Ausrichtung von Grossverdichterwellen auf Mikrometer-Genauigkeit unter widrigen Witterungsverhältnissen auf dem Werksgelände.",
                solution = "Einsatz laserbasierter 3D-Messverfahren sowie Einhausung der sensiblen Komponenten während der Hebe- und Montageprozesse.",
                result = "Spielfreie mechanische Kopplung nachgewiesen und vibrationsarmer Dauerlauf erfolgreich protokolliert. Vollständige TÜV-Abnahme ohne Beanstandung.",
                imageResName = "img_engineering_blueprint"
            )
            val p3 = Project(
                name = "Automatisierte Logistiklinie",
                sector = "Logistik & Transport",
                location = "München, Deutschland",
                duration = "12 Monate",
                services = "Engineering, Fertigung, Automatisierung",
                challenge = "Anbindung von Hochgeschwindigkeits-Förderbändern und Roboter-Sortierzellen an das übergeordnete MES/ERP-System bei laufendem Lagerbetrieb.",
                solution = "Etablierung standardisierter OPC-UA Schnittstellen für Echtzeit-Telemetriedaten und schrittweiser, nächtlicher Aufbau der Steuerungselektronik.",
                result = "Gesamtdurchlaufgeschwindigkeit im Distributionszentrum verdoppelt. Keine ungeplanten Stillstandzeiten während der gesamten Projektierungs- und Montagephase.",
                imageResName = "img_factory_assembly"
            )
            dao.insertProject(p1)
            dao.insertProject(p2)
            dao.insertProject(p3)

            // Pre-populate Job Openings (German careers)
            val j1 = JobOpening(
                title = "Projektingenieur (m/w/d) - Sondermaschinenbau",
                location = "Stuttgart, Hauptverwaltung",
                workingHours = "Vollzeit",
                tasks = "Technische Auslegung und Planung komplexer Maschinenbaugruppen; Koordination mit Fertigungsabteilungen; Fachliche Beratung und Betreuung unserer B2B-Kunden von Konzept bis Abnahme; Erstellung technischer Dokumentation und CAD-Konstruktionen.",
                requirements = "Erfolgreich abgeschlossenes Studium Maschinenbau oder vergleichbarer Schwerpunkt; Mindestens 3 Jahre einschlägige Berufserfahrung im CAD-Konstruktionsbereich (z.B. SolidWorks, Inventor oder NX); Fliessende Deutsch- und gute Englischkenntnisse; Strukturierte, analytische Arbeitsweise.",
                benefits = "Attraktives Gehaltspaket nach Haustarif; Flexible Arbeitszeiten und Möglichkeit zur mobilen Arbeit; 30 Tage Jahresurlaub; Betriebliche Altersvorsorge und Gruppenunfallversicherung; Individuelle Weiterbildungsangebote."
            )
            val j2 = JobOpening(
                title = "Industriemechaniker / Schlosser (m/w/d)",
                location = "Dresden, Produktionswerk",
                workingHours = "Vollzeit",
                tasks = "Fachgerechte Montage mechanischer, pneumatischer und hydraulischer Baugruppen; Qualitätsprüfung und Funktionskontrolle fertiggestellter Anlagen im Werk; Gelegentliche Aufbauten und Inbetriebnahmen bei unseren Kunden vor Ort; Durchführung von Wartungs- und Reparaturarbeiten.",
                requirements = "Abgeschlossene Ausbildung als Industriemechaniker, Schlosser, Feinwerkmechaniker oder vergleichbar; Idealerweise Erfahrung im Lesen komplexer Montagezeichnungen; Selbstständigkeit und Teamfähigkeit; Führerschein Klasse B und Reisebereitschaft.",
                benefits = "Modernste Werkstattausrüstung und Arbeitskleidung; Unbefristeter Arbeitsvertrag mit leistungsgerechter Vergütung; Weihnachts- und Urlaubsgeld; Gut ausgestattete Montagefahrzeuge zur betrieblichen Nutzung; Angenehmes Betriebsklima im inhabergeführten Mittelstand."
            )
            val j3 = JobOpening(
                title = "Duales Studium: Bachelor of Engineering - Elektrotechnik (m/w/d)",
                location = "Karlsruhe, Technisches Büro",
                workingHours = "Duales Studium",
                tasks = "Durchlauf aller technischen Abteilungen (Projektierung, Elektrokonstruktion, Softwareentwicklung); Mitwirkung bei der Hardwareplanung von Schaltschränken; Begleitung von Inbetriebnahmen und SPS-Programmierung; Erstellung der Bachelorarbeit zu Industrie 4.0 Themen.",
                requirements = "Allgemeine Hochschulreife oder gute Fachhochschulreife; Ausgeprägtes mathematisches und physikalisches Verständnis; Spass an Elektronik und Programmierung; Eigeninitiative, Zuverlässigkeit und Freude an Teamarbeit.",
                benefits = "Vollständige Übernahme der Studiengebühren und Bereitstellung von Fachliteratur; Attraktive monatliche Ausbildungsvergütung ab dem ersten Semester; Übernahmegarantie bei erfolgreichem Studienabschluss; Betreuung durch feste, erfahrene Mentoren."
            )
            dao.insertJobOpening(j1)
            dao.insertJobOpening(j2)
            dao.insertJobOpening(j3)

            // Pre-populate News (German corporate articles)
            val n1 = NewsArticle(
                title = "PETER & KREBS feiert 40-jähriges Firmenjubiläum",
                category = "Unternehmen",
                content = "Seit vier Jahrzehnten steht unser Name im deutschen Mittelstand für höchste Präzision, technische Exzellenz und partnerschaftliche Zusammenarbeit im Industrieanlagenbau. Was 1986 als kleine, spezialisierte Ingenieurwerkstatt in Stuttgart gegründet wurde, hat sich bis heute zu einem bundesweit geschätzten Partner für anspruchsvolle B2B-Projekte entwickelt. Wir danken unseren langjährigen Kunden, Partnern und vor allem unseren hervorragenden Mitarbeitern, die dieses Wachstum durch ihr tägliches Engagement ermöglicht haben. Auch in Zukunft setzen wir konsequent auf kompromisslose Qualität und zuverlässige ingenieurwissenschaftliche Prozesse.",
                date = "15.09.2026"
            )
            val n2 = NewsArticle(
                title = "Investition in modernste CNC-Technik im Werk Dresden",
                category = "Technologie",
                content = "Um den stetig steigenden Genauigkeits- und Terminanforderungen unserer Partner gerecht zu werden, haben wir unsere mechanische Fertigung im Produktionswerk Dresden erweitert. Durch die Inbetriebnahme von zwei hocheffizienten 5-Achs-CNC-Bearbeitungszentren der neuesten Generation heben wir unsere Fertigungstiefe auf ein neues Level. Diese modernste computergestützte Fertigungstechnologie ermöglicht die Bearbeitung hochkomplexer Werkstücke aus Edelstahl, Titan und Aluminium in einer einzigen Aufspannung, was Rüstzeiten minimiert und die Masshaltigkeit auf Bruchteile eines Mikrometers sicherstellt.",
                date = "02.08.2026"
            )
            val n3 = NewsArticle(
                title = "Erfolgreicher Projektabschluss bei Chemiepark Bitterfeld",
                category = "Projekte",
                content = "Nach nur 11 Monaten Gesamtprojektlaufzeit konnte das komplexe verfahrenstechnische Rohrleitungssystem inklusive Steuerungstechnik planmässig an die Betreibergesellschaft übergeben werden. Die besondere technische Herausforderung lag in den extremen Sicherheitsauflagen für korrosive Medien und der engen Taktung im Baufeld. Ein grosses Lob gebührt unserem Montageteam, das unter Einhaltung allerhöchster Sicherheitsstandards die Schweiss- und Prüfarbeiten mangelfrei und fristgerecht beendet hat.",
                date = "10.07.2026"
            )
            dao.insertNewsArticle(n1)
            dao.insertNewsArticle(n2)
            dao.insertNewsArticle(n3)

            // Pre-populate B2B Invoices
            val inv1 = PortalInvoice(
                invoiceNumber = "PK-RE-2026-0481",
                projectTitle = "Produktionsanlage A-8",
                amount = 124500.00,
                date = "15.09.2026",
                dueDate = "15.10.2026",
                status = "Bezahlt"
            )
            val inv2 = PortalInvoice(
                invoiceNumber = "PK-RE-2026-0512",
                projectTitle = "Automatisierte Logistiklinie",
                amount = 43200.00,
                date = "28.09.2026",
                dueDate = "28.10.2026",
                status = "Offen"
            )
            val inv3 = PortalInvoice(
                invoiceNumber = "PK-RE-2026-0390",
                projectTitle = "Instandhaltung Gasturbine T3",
                amount = 18900.00,
                date = "10.08.2026",
                dueDate = "24.08.2026",
                status = "Überfällig"
            )
            dao.insertPortalInvoice(inv1)
            dao.insertPortalInvoice(inv2)
            dao.insertPortalInvoice(inv3)

            // Pre-populate Support Cases
            val sc1 = SupportCase(
                clientCompany = "Mittelständischer Maschinenbau AG",
                projectTitle = "Produktionsanlage A-8",
                category = "Wartungsanfrage",
                priority = "Mittel",
                description = "Geplante jährliche Maschinenwartung für Schmiersystem und optische Führungsschienen. Durchführung am Wochenende bevorzugt.",
                status = "In Bearbeitung",
                ticketNumber = "PK-SRV-26-0012"
            )
            val sc2 = SupportCase(
                clientCompany = "Nordic Energy GmbH",
                projectTitle = "Energiepark Nord - Grosskompressor",
                category = "Störung",
                priority = "Hoch",
                description = "Sensorausfall an Hauptlager 2. Lagertemperatur zeigt unrealistische Schwankungen. Dringende telefonische Klärung und Vor-Ort-Einsatz angefordert.",
                status = "Offen",
                ticketNumber = "PK-SRV-26-0015"
            )
            dao.insertSupportCase(sc1)
            dao.insertSupportCase(sc2)
        }
    }
}
