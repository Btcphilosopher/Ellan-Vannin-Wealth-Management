package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- Inquiries (Anfragen) ---
    @Query("SELECT * FROM inquiries ORDER BY timestamp DESC")
    fun getAllInquiries(): Flow<List<Inquiry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInquiry(inquiry: Inquiry)

    @Update
    suspend fun updateInquiry(inquiry: Inquiry)

    @Query("DELETE FROM inquiries WHERE id = :id")
    suspend fun deleteInquiry(id: Int)


    // --- Projects (Projekte) ---
    @Query("SELECT * FROM projects ORDER BY id DESC")
    fun getAllProjects(): Flow<List<Project>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project)

    @Update
    suspend fun updateProject(project: Project)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProject(id: Int)


    // --- Job Openings (Stellenangebote) ---
    @Query("SELECT * FROM job_openings ORDER BY id DESC")
    fun getAllJobOpenings(): Flow<List<JobOpening>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJobOpening(jobOpening: JobOpening)

    @Update
    suspend fun updateJobOpening(jobOpening: JobOpening)

    @Query("DELETE FROM job_openings WHERE id = :id")
    suspend fun deleteJobOpening(id: Int)


    // --- Job Applications (Bewerbungen) ---
    @Query("SELECT * FROM job_applications ORDER BY timestamp DESC")
    fun getAllJobApplications(): Flow<List<JobApplication>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJobApplication(jobApplication: JobApplication)

    @Update
    suspend fun updateJobApplication(jobApplication: JobApplication)

    @Query("DELETE FROM job_applications WHERE id = :id")
    suspend fun deleteJobApplication(id: Int)


    // --- News Articles (News & Presse) ---
    @Query("SELECT * FROM news_articles ORDER BY id DESC")
    fun getAllNewsArticles(): Flow<List<NewsArticle>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNewsArticle(article: NewsArticle)

    @Update
    suspend fun updateNewsArticle(article: NewsArticle)

    @Query("DELETE FROM news_articles WHERE id = :id")
    suspend fun deleteNewsArticle(id: Int)


    // --- Support Cases (B2B Servicefälle) ---
    @Query("SELECT * FROM support_cases ORDER BY timestamp DESC")
    fun getAllSupportCases(): Flow<List<SupportCase>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupportCase(supportCase: SupportCase)

    @Update
    suspend fun updateSupportCase(supportCase: SupportCase)

    @Query("DELETE FROM support_cases WHERE id = :id")
    suspend fun deleteSupportCase(id: Int)


    // --- Portal Invoices (B2B Rechnungen) ---
    @Query("SELECT * FROM portal_invoices ORDER BY id DESC")
    fun getAllPortalInvoices(): Flow<List<PortalInvoice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPortalInvoice(invoice: PortalInvoice)

    @Query("DELETE FROM portal_invoices WHERE id = :id")
    suspend fun deletePortalInvoice(id: Int)
}
