package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- PETER & KREBS Premium Industrial Palette ---

// Primary Brand Color: Deep Engineering Blue / Navy
val BrandBlue = Color(0xFF0D2540)
val BrandBlueDark = Color(0xFF071424)
val BrandBlueLight = Color(0xFF1B3D66)

// Neutrals: Warm Greys, Concrete, Aluminum, Stainless Steel
val WarmPearl = Color(0xFFFAF9F6)     // Main Light Background
val PureWhite = Color(0xFFFFFFFF)     // Card Backgrounds
val CoolGreyLight = Color(0xFFF3F4F6) // Secondary background / Surface light
val ConcreteGray = Color(0xFFE5E7EB)  // Borders & Dividers
val SteelSlate = Color(0xFF6E8096)     // Muted text / Tech captions
val DeepAnthracite = Color(0xFF1E1E1E) // Dark Text / Main Body text
val JetBlack = Color(0xFF121212)       // Headers, Dark panels, Bottom sheet

// Accent Color: Industrial Rust Orange (Used extremely sparsely for highlighted states/actions)
val RustOrange = Color(0xFFC2410C)
val LightRust = Color(0xFFFDF2E9)

// Feedback
val SuccessGreen = Color(0xFF15803D)
val ErrorRed = Color(0xFFB91C1C)
val WarningYellow = Color(0xFFA16207)
