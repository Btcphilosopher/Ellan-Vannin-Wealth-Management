"""Deterministic demonstration data.

    AUTOS_MIGRATION_DATABASE_URL=... python -m seed.generate [--seed 2026]

Everything here is FICTIONAL: organisations, people, addresses, phone
numbers (+1-555 range), e-mail domains (*.example), VINs (prefix "SYN",
flagged is_synthetic) and payments (simulated provider). Prices and fees
are illustrative only.

Reference data is inserted directly; commercial fixtures (quotes,
reservations, payments, refunds, sale orders) go through the same service
layer the API uses, so they obey every trigger and constraint.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import os
import random
import uuid

from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from app import db as appdb
from app.db import DbContext, apply_context
from app.models import (AppointmentResource, AppUser, ChargeRule, Customer, CustomerAddress, CustomerRelationship, Location,
                        MaintenanceBlock, Organisation, OrganisationMembership, RentalAsset, RentalCategory, RentalInventoryBucket,
                        TermsVersion, Vehicle, VehicleIdentifier, VehicleMake, VehicleModel, VehicleSpecificationVersion, VehicleTrim)
from app.security import load_principal
from app.services import listings as L
from app.services import payments as P
from app.services import quotes as Q
from app.services import sales as S
from app.services import scheduling as T
from app.services.vehicles import vin_check_digit

UTC = dt.timezone.utc
VIN_CHARS = "ABCDEFGHJKLMNPRSTUVWXYZ0123456789"


def synthetic_vin(rng: random.Random, year: int) -> str:
    year_code = "ABCDEFGHJKLMNPRSTVWXY123456789"[(year - 2010) % 30]
    body = "SYN" + "".join(rng.choice(VIN_CHARS) for _ in range(5)) + "0" + year_code + rng.choice("ABC") + "".join(rng.choice("0123456789") for _ in range(6))
    return body[:8] + vin_check_digit(body) + body[9:]


ORGS = [
    dict(key="platform", kind="platform", legal_name="Autos Data Platform Operations (fictional)", display_name="Platform Operations",
         slug="platform-ops", default_currency="USD", default_timezone="America/Los_Angeles"),
    dict(key="harbourview", kind="dealer", legal_name="Harbourview Motors LLC (fictional)", display_name="Harbourview Motors",
         slug="harbourview-motors", default_currency="USD", default_timezone="America/Los_Angeles",
         listing_freshness_warn_after=dt.timedelta(days=3), listing_freshness_action="warn", deposit_hold_extension=dt.timedelta(hours=72)),
    dict(key="ridgeline", kind="dealer", legal_name="Ridgeline Auto Group Inc. (fictional)", display_name="Ridgeline Auto Group",
         slug="ridgeline-auto", default_currency="USD", default_timezone="America/Denver",
         listing_freshness_warn_after=dt.timedelta(days=2), listing_freshness_suspend_after=dt.timedelta(days=5),
         listing_freshness_action="suspend", sale_hold_duration=dt.timedelta(minutes=45)),
    dict(key="cityline", kind="rental_supplier", legal_name="Cityline Vehicle Rentals Co. (fictional)", display_name="Cityline Rentals",
         slug="cityline-rentals", default_currency="USD", default_timezone="America/Los_Angeles"),
]

LOCATIONS = [
    ("harbourview", "HV-PDX", "Harbourview Motors — Pearl District", "dealership", "1200 NW Example Ave", "Portland", "US-OR", "97209", 45.5290, -122.6830, "America/Los_Angeles"),
    ("harbourview", "HV-BVT", "Harbourview Motors — Beaverton", "dealership", "4400 SW Sample Rd", "Beaverton", "US-OR", "97005", 45.4871, -122.8037, "America/Los_Angeles"),
    ("ridgeline", "RL-DEN", "Ridgeline Auto — Denver Central", "dealership", "800 Fictional Blvd", "Denver", "US-CO", "80204", 39.7392, -104.9903, "America/Denver"),
    ("ridgeline", "RL-BLD", "Ridgeline Auto — Boulder", "dealership", "2500 Placeholder St", "Boulder", "US-CO", "80301", 40.0150, -105.2705, "America/Denver"),
    ("cityline", "CL-SEA", "Cityline Rentals — Downtown Seattle", "rental_branch", "500 Demo Way", "Seattle", "US-WA", "98101", 47.6062, -122.3321, "America/Los_Angeles"),
    ("cityline", "CL-SEATAC", "Cityline Rentals — Airport", "rental_branch", "17800 Illustrative Pkwy", "SeaTac", "US-WA", "98188", 47.4502, -122.3088, "America/Los_Angeles"),
]

USERS = [
    ("ops@autos-data.example", "Avery Platform (Ops)", "platform", "platform_admin"),
    ("admin@harbourview.example", "Harper Quinn (Harbourview admin)", "harbourview", "dealer_admin"),
    ("sales@harbourview.example", "Sam Okafor (Harbourview sales)", "harbourview", "dealer_staff"),
    ("finance@harbourview.example", "Farah Lind (Harbourview finance)", "harbourview", "finance"),
    ("admin@ridgeline.example", "Riley Moreno (Ridgeline admin)", "ridgeline", "dealer_admin"),
    ("sales@ridgeline.example", "Dana Kim (Ridgeline sales)", "ridgeline", "dealer_staff"),
    ("finance@ridgeline.example", "Morgan Patel (Ridgeline finance)", "ridgeline", "finance"),
    ("admin@cityline.example", "Casey Brandt (Cityline admin)", "cityline", "rental_admin"),
    ("agent@cityline.example", "Jordan Ellis (Cityline agent)", "cityline", "rental_agent"),
    ("auditor@autos-data.example", "Alex Auditor", "harbourview", "auditor"),
]

# make, model, slug, year, trim, body, drivetrain, fuel, msrp, seats, kw, range_km
CATALOGUE = [
    ("Hyundai", "Tucson", "tucson", 2026, "SEL", "suv", "fwd", "petrol", 3290000, 5, 140, None),
    ("Hyundai", "Tucson", "tucson", 2026, "Limited", "suv", "awd", "hybrid", 4020000, 5, 172, None),
    ("Hyundai", "IONIQ 5", "ioniq-5", 2026, "SE", "crossover", "rwd", "electric", 4350000, 5, 168, 394),
    ("Hyundai", "IONIQ 5", "ioniq-5", 2026, "Limited", "crossover", "awd", "electric", 5320000, 5, 239, 418),
    ("Hyundai", "Sonata", "sonata", 2026, "SEL", "sedan", "fwd", "petrol", 2990000, 5, 143, None),
    ("Hyundai", "Santa Fe", "santa-fe", 2026, "SE", "suv", "fwd", "petrol", 3590000, 7, 207, None),
    ("Hyundai", "Elantra", "elantra", 2026, "SE", "sedan", "fwd", "petrol", 2250000, 5, 110, None),
    ("Hyundai", "Kona", "kona", 2025, "SEL", "crossover", "fwd", "petrol", 2650000, 5, 110, None),
    ("Hyundai", "Palisade", "palisade", 2025, "SEL", "suv", "awd", "petrol", 4520000, 8, 217, None),
    ("Kia", "Sportage", "sportage", 2025, "EX", "suv", "awd", "hybrid", 3450000, 5, 168, None),
    ("Kia", "EV6", "ev6", 2025, "Wind", "crossover", "rwd", "electric", 4890000, 5, 168, 499),
]

HEADLINE = [  # (model, trim, price, dealer, location, deposit)
    ("Tucson", "SEL", 3290000, "harbourview", "HV-PDX", 50000),
    ("IONIQ 5", "SE", 4350000, "harbourview", "HV-PDX", 100000),
    ("Sonata", "SEL", 2990000, "ridgeline", "RL-DEN", 50000),
    ("Santa Fe", "SE", 3590000, "ridgeline", "RL-DEN", 75000),
]

COLOURS = ["Ultimate Red", "Amazon Gray", "Serenity White", "Abyss Black", "Hampton Gray", "Ecotronic Gray", "Lucid Blue", "Calypso Red"]
FIRST = ["Jamie", "Taylor", "Morgan", "Quinn", "Rowan", "Skyler", "Emerson", "Parker", "Reese", "Hayden", "Logan", "Kendall", "Blake", "Drew"]
LAST = ["Alvarez", "Nakamura", "Okonkwo", "Lindqvist", "Brennan", "Castellano", "Haddad", "Iverson", "Mbeki", "Novak", "Petrov", "Sandoval", "Tanaka", "Whitfield"]


def run(owner_url: str, seed: int = 2026) -> dict:
    rng = random.Random(seed)
    engine = create_engine(owner_url)
    appdb.reset_engine(engine)
    s: Session = appdb.new_session()
    apply_context(s, DbContext.system(actor_kind="system"))
    if s.execute(text("SELECT count(*) FROM organisations")).scalar():
        raise SystemExit("database already seeded")
    now = dt.datetime.now(UTC).replace(microsecond=0)

    orgs = {}
    for o in ORGS:
        k = o.pop("key")
        org = Organisation(**o)
        s.add(org)
        s.flush()
        orgs[k] = org
        o["key"] = k
    locs = {}
    for org_key, code, name, kind, line1, city, region, pc, lat, lon, tz in LOCATIONS:
        loc = Location(organisation_id=orgs[org_key].id, code=code, name=name, kind=kind, address_line1=line1, city=city,
                       region=region, postal_code=pc, country_code="US", geog=f"SRID=4326;POINT({lon} {lat})", timezone=tz)
        s.add(loc)
        s.flush()
        locs[code] = loc
    users = {}
    for email, name, org_key, role in USERS:
        u = AppUser(email=email, display_name=name, kind="staff")
        s.add(u)
        s.flush()
        s.add(OrganisationMembership(organisation_id=orgs[org_key].id, user_id=u.id, role=role))
        users[email] = u
    s.flush()

    # ---- catalogue
    makes, models, trims = {}, {}, {}
    for make, model, slug, year, trim, body, drive, fuel, msrp, seats, kw, rng_km in CATALOGUE:
        if make not in makes:
            makes[make] = VehicleMake(name=make, slug=make.lower())
            s.add(makes[make])
            s.flush()
        if (make, model) not in models:
            models[(make, model)] = VehicleModel(make_id=makes[make].id, name=model, slug=slug)
            s.add(models[(make, model)])
            s.flush()
        t = VehicleTrim(model_id=models[(make, model)].id, model_year=year, name=trim, body_style=body, drivetrain=drive, fuel_type=fuel)
        s.add(t)
        s.flush()
        trims[(model, trim)] = t
        s.add(VehicleSpecificationVersion(trim_id=t.id, source="catalogue:illustrative", source_reference="synthetic demo spec sheet",
                                          effective_from=dt.date(year - 1, 9, 1), msrp_minor=msrp, msrp_currency="USD", seats=seats,
                                          power_kw=kw, electric_range_km=rng_km, doors=4, verification_status="unverified",
                                          attributes={"note": "Illustrative values for demonstration; not manufacturer data."}))
    s.flush()
    terms = TermsVersion(code="vehicle-sale-quote", version=1, title="Vehicle sale quote terms (demo)",
                         body_sha256=hashlib.sha256(b"Demo terms v1: quotes are valid until expires_at; deposits apply to the price.").hexdigest(),
                         effective_from=now - dt.timedelta(days=365))
    s.add(terms)

    # ---- charge rules (illustrative amounts)
    hv, rl, cl = orgs["harbourview"], orgs["ridgeline"], orgs["cityline"]
    past = now - dt.timedelta(days=180)
    rules = [
        (hv, "mandatory_fee", "doc_fee", "Dealer documentation fee", "fixed", 40000, None, None),
        (hv, "optional_product", "paint_protection", "Paint protection film", "fixed", 59500, None, None),
        (hv, "optional_product", "ext_warranty_5y", "Extended warranty (5 yr)", "fixed", 189500, None, None),
        (hv, "tax", "or_privilege_tax", "Vehicle privilege tax (illustrative)", "rate_bps", None, 50, "US-OR"),
        (hv, "registration", "or_title_reg", "Title & registration (illustrative)", "fixed", 31200, None, "US-OR"),
        (hv, "delivery", "local_delivery", "Local delivery", "fixed", 25000, None, None),
        (hv, "discount", "WINTER500".lower(), "Winter promotion", "fixed", -50000, None, None),
        (rl, "mandatory_fee", "doc_fee", "Dealer handling fee", "fixed", 69900, None, None),
        (rl, "tax", "co_state_tax", "State sales tax (illustrative)", "rate_bps", None, 290, "US-CO"),
        (rl, "optional_product", "all_weather_mats", "All-weather mats", "fixed", 22900, None, None),
    ]
    for org, ctype, code, label, calc, amount, bps, region in rules:
        s.add(ChargeRule(organisation_id=org.id, charge_type=ctype, code=code, label=label, calculation=calc, amount_minor=amount,
                         rate_bps=bps, currency="USD" if amount is not None else None, region=region, effective_from=past))
    s.flush()

    # ---- customers
    customers = []
    for i in range(14):
        fn, ln = FIRST[i], LAST[i]
        c = Customer(display_name=f"{fn} {ln}", given_name=fn, family_name=ln,
                     email=f"{fn.lower()}.{ln.lower()}@customers.example", phone=f"+1555010{i:04d}"[:12],
                     marketing_consent=[True, False, None][i % 3],
                     created_by_organisation_id=[hv.id, rl.id, cl.id][i % 3])
        s.add(c)
        s.flush()
        s.add(CustomerAddress(customer_id=c.id, kind="home", line1=f"{100 + i} Fictional Lane", city=["Portland", "Denver", "Seattle"][i % 3],
                              region=["US-OR", "US-CO", "US-WA"][i % 3], postal_code="00000", country_code="US"))
        s.add(CustomerRelationship(customer_id=c.id, organisation_id=[hv.id, rl.id, cl.id][i % 3], basis="manual"))
        customers.append(c)
    s.flush()
    for c in customers[:4]:
        s.add(AppUser(email=c.email, display_name=c.display_name, kind="customer", customer_id=c.id))
    s.commit()

    # ---- vehicles + listings via the service layer
    def principal(email):
        ps = appdb.new_session()
        try:
            return load_principal(ps, users[email].id, acting_org_id=None, request_id="seed")
        finally:
            ps.close()

    p_hv, p_rl, p_ops = principal("admin@harbourview.example"), principal("admin@ridgeline.example"), principal("ops@autos-data.example")
    p_cl = principal("admin@cityline.example")
    s.info["db_ctx"] = p_ops.db_context()
    apply_context(s, p_ops.db_context())

    vehicles: dict[str, Vehicle] = {}
    listings = {}

    def add_vehicle(org, loc_code, model, trim, *, used=False, odo=None, colour=None, key=None):
        t = trims[(model, trim)]
        vin = synthetic_vin(rng, t.model_year)
        v = Vehicle(custodian_organisation_id=org.id, trim_id=t.id, current_location_id=locs[loc_code].id, model_year=t.model_year,
                    exterior_colour=colour or rng.choice(COLOURS), interior_colour=rng.choice(["Black", "Gray", "Beige"]),
                    condition="used" if used else "new",
                    odometer_value=odo if odo is not None else (rng.randint(8000, 60000) if used else rng.randint(3, 40)),
                    odometer_unit="mi", odometer_recorded_at=now - dt.timedelta(days=rng.randint(1, 20)),
                    has_open_recall=False if rng.random() < 0.8 else None, keys_count=2)
        s.add(v)
        s.flush()
        s.add(VehicleIdentifier(vehicle_id=v.id, namespace="vin", value=vin, is_synthetic=True, source="seed"))
        s.add(VehicleIdentifier(vehicle_id=v.id, namespace="stock", value=f"{org.slug[:2].upper()}{rng.randint(10000, 99999)}",
                                issuing_organisation_id=org.id, is_synthetic=True, source="seed"))
        s.flush()
        vehicles[key or str(v.id)] = v
        return v

    def add_listing(p, org, v, loc_code, title, price, deposit=0, channel="marketplace", publish=True, key=None):
        lst = L.create_listing(s, p, {"organisation_id": org.id, "vehicle_id": v.id, "location_id": locs[loc_code].id, "channel": channel,
                                      "title": title, "price": price, "deposit_required_minor": deposit, "sale_eligibility": "eligible"})
        if publish:
            L.transition(s, p, lst.id, lst.version, "publish", "seed")
        listings[key or str(lst.id)] = lst
        return lst

    for model, trim, price, dk, loc, dep in HEADLINE:
        org, p = (hv, p_hv) if dk == "harbourview" else (rl, p_rl)
        v = add_vehicle(org, loc, model, trim, key=f"{model} {trim}")
        add_listing(p, org, v, loc, f"2026 {('Hyundai ' + model)} {trim}", price, dep, key=f"{model} {trim}")
    # The Tucson is also offered on the dealer's own site: same physical vehicle, second listing.
    tucson = vehicles["Tucson SEL"]
    add_listing(p_hv, hv, tucson, "HV-PDX", "2026 Hyundai Tucson SEL — dealer site", 3290000, 50000, channel="dealer_site", key="Tucson SEL (dealer site)")

    extra = [("Tucson", "Limited"), ("IONIQ 5", "Limited"), ("Elantra", "SE"), ("Kona", "SEL"), ("Palisade", "SEL"),
             ("Sportage", "EX"), ("EV6", "Wind"), ("Sonata", "SEL"), ("Santa Fe", "SE"), ("Elantra", "SE"), ("Tucson", "SEL")]
    n_extra = 0
    for i in range(24):
        model, trim = extra[i % len(extra)]
        dealer = i % 2
        org, p = (hv, p_hv) if dealer == 0 else (rl, p_rl)
        loc = ["HV-PDX", "HV-BVT"][i % 2] if dealer == 0 else ["RL-DEN", "RL-BLD"][i % 2]
        used = i % 3 == 0
        t = trims[(model, trim)]
        v = add_vehicle(org, loc, model, trim, used=used)
        msrp = {"Tucson": 3290000, "IONIQ 5": 4350000, "Elantra": 2250000, "Kona": 2650000, "Palisade": 4520000, "Sportage": 3450000,
                "EV6": 4890000, "Sonata": 2990000, "Santa Fe": 3590000}[model] + (700000 if trim == "Limited" else 0)
        price = int(round((msrp * (0.78 if used else 1.0) + rng.randint(-60, 60) * 5000) / 10000) * 10000)
        publish = i not in (4, 17)  # one draft per dealer remains for the publication demo
        lst = add_listing(p, org, v, loc, f"{'Used ' if used else ''}{t.model_year} {model} {trim}", price, 50000 if not used else 25000,
                          publish=publish)
        if i % 4 == 1:  # price history
            L.change_price(s, p, lst.id, None, price - 100000, "price_change")
        n_extra += 1
    # One dealer feed listing gone stale (freshness warning demo)
    stale = list(listings.values())[-3]
    s.execute(text("UPDATE listings SET source_namespace = 'feed:harbourview-dms', source_record_id = 'HV-LEGACY-1', "
                   "source_last_seen_at = now() - interval '4 days' WHERE id = :id"), {"id": stale.id})
    s.commit()
    apply_context(s, p_ops.db_context())

    # ---- test drives
    res = {}
    for code, loc in locs.items():
        if loc.kind != "dealership":
            continue
        org_id = loc.organisation_id
        staff = AppointmentResource(organisation_id=org_id, location_id=loc.id, kind="staff", name=f"{code} sales consultant", capacity=1)
        bay = AppointmentResource(organisation_id=org_id, location_id=loc.id, kind="bay", name=f"{code} test-drive bay", capacity=2)
        s.add_all([staff, bay])
        s.flush()
        res[code] = (staff, bay)
    s.commit()
    apply_context(s, p_ops.db_context())
    tomorrow = (now + dt.timedelta(days=1)).astimezone(dt.timezone(dt.timedelta(hours=-8))).replace(hour=10, minute=0, second=0)
    drive_specs = [("IONIQ 5 SE", "HV-PDX", 0, 1, True), ("Tucson SEL", "HV-PDX", 0, 3, True), ("Sonata SEL", "RL-DEN", 1, 0, True),
                   ("Santa Fe SE", "RL-DEN", 1, 2, False), ("IONIQ 5 SE", "HV-PDX", 2, 1, False), ("Sonata SEL", "RL-DEN", 0, 1, True),
                   ("Tucson SEL", "HV-PDX", 3, 2, True), ("Santa Fe SE", "RL-DEN", 4, 3, True)]
    drives = []
    for i, (vk, loc, day, hour, confirm) in enumerate(drive_specs):
        v = vehicles[vk]
        p = p_hv if loc.startswith("HV") else p_rl
        start = tomorrow + dt.timedelta(days=day, hours=hour)
        a = T.request_test_drive(s, p, {"vehicle_id": v.id, "listing_id": listings[vk].id, "customer_id": customers[i % 12].id,
                                        "resource_id": res[loc][1].id, "starts_at": start, "ends_at": start + dt.timedelta(minutes=45),
                                        "confirm": confirm}, None)
        drives.append(a)
    T.drive_action(s, p_rl, drives[5].id, drives[5].version, "cancel", "customer rescheduled")
    s.commit()
    apply_context(s, p_ops.db_context())

    # ---- rentals
    cats = {}
    for code, name, model, trim, rate, buf in [("CCAR", "Compact sedan", "Elantra", "SE", 5900, 60), ("SFAR", "Standard SUV", "Tucson", "SEL", 8900, 60),
                                               ("XEAR", "Electric crossover", "IONIQ 5", "SE", 10900, 90)]:
        c = RentalCategory(organisation_id=cl.id, code=code, name=name, seats=5, transmission="automatic",
                           turnaround_buffer=dt.timedelta(minutes=buf), daily_rate_minor=rate, currency="USD")
        s.add(c)
        s.flush()
        cats[code] = (c, model, trim)
        for lc in ("CL-SEA", "CL-SEATAC"):
            s.add(RentalInventoryBucket(location_id=locs[lc].id, category_id=c.id, organisation_id=cl.id))
    s.flush()
    assets = []
    n = 0
    for code, count in (("CCAR", 4), ("SFAR", 4), ("XEAR", 3)):
        c, model, trim = cats[code]
        for j in range(count):
            lc = "CL-SEA" if j % 2 == 0 else "CL-SEATAC"
            v = add_vehicle(cl, lc, model, trim, used=True, odo=rng.randint(5000, 30000))
            n += 1
            a = RentalAsset(organisation_id=cl.id, vehicle_id=v.id, category_id=c.id, home_location_id=locs[lc].id,
                            fleet_number=f"CL-{code}-{j + 1:03d}", in_fleet_from=now - dt.timedelta(days=200))
            s.add(a)
            s.flush()
            assets.append(a)
    s.commit()
    apply_context(s, p_ops.db_context())
    for k, a in enumerate(assets[:3]):
        start = now + dt.timedelta(days=10 + k * 3)
        s.add(MaintenanceBlock(organisation_id=cl.id, rental_asset_id=a.id, kind=["scheduled_service", "inspection", "repair"][k],
                               starts_at=start, ends_at=start + dt.timedelta(days=1), reason="seeded maintenance"))
    s.flush()
    sea = locs["CL-SEA"]
    bookings = []
    for k in range(10):
        code = ["CCAR", "SFAR", "XEAR"][k % 3]
        c = cats[code][0]
        pickup = (now + dt.timedelta(days=2 + k)).replace(minute=0, second=0)
        b = T.create_booking(s, p_cl, {"category_id": c.id, "location_id": sea.id, "pickup_at": pickup,
                                       "return_at": pickup + dt.timedelta(days=2), "customer_id": customers[(k + 2) % 14].id}, None)
        if k < 6:
            try:
                T.assign_asset(s, p_cl, b.id)
            except Exception:  # noqa: BLE001 - leave unassigned if no free asset
                s.rollback()
                apply_context(s, p_ops.db_context())
        bookings.append(b)
    s.commit()
    apply_context(s, p_ops.db_context())

    # ---- transaction fixtures (through services + simulated provider)
    def deliver(ev):
        from app import simulator
        raw, h = simulator.signed_delivery(ev)
        return P.handle_provider_event(s, "simpay", raw, h["SimPay-Signature"])

    from app import simulator
    # (a) Santa Fe: complete quote (US-CO) -> reservation -> deposit paid -> accepted -> sale order -> handover -> completed?
    #     Keep it at 'agreement_signed' so the vehicle shows as committed.
    sf = listings["Santa Fe SE"]
    q = Q.issue_quote(s, p_rl, {"listing_id": sf.id, "customer_id": customers[1].id, "customer_region": "US-CO",
                                "product_codes": ["all_weather_mats"]})
    s.commit(); apply_context(s, p_rl.db_context())
    r = S.create_reservation(s, p_rl, {"listing_id": sf.id, "customer_id": customers[1].id, "quote_id": q.id}, "seed-res-santafe")
    s.commit(); apply_context(s, p_rl.db_context())
    intent, _ = P.create_payment(s, p_rl, {"purpose": "sale_deposit", "sale_reservation_id": r.id}, "seed-pay-santafe-deposit")
    apply_context(s, DbContext.system()); ev = simulator.settle_payment(s, intent.provider_intent_ref, "succeeded"); s.commit()
    deliver(ev)
    apply_context(s, p_rl.db_context())
    r = s.get(S.SaleReservation, r.id); s.refresh(r)
    S.accept(s, p_rl, r.id, r.version)
    s.commit(); apply_context(s, p_rl.db_context())
    r = s.get(S.SaleReservation, r.id); s.refresh(r)
    # Quote is incomplete (no registration rule for US-CO): the agreed total is set explicitly.
    o = S.convert_to_order(s, p_rl, r.id, r.version, q.total_known_minor + 45000)
    s.commit(); apply_context(s, p_rl.db_context())
    s.refresh(o)
    S.order_action(s, p_rl, o.id, o.version, "sign_agreement", {})
    s.commit(); apply_context(s, p_ops.db_context())

    # (b) A used Harbourview vehicle sold end to end (completed sale -> vehicle sold, listing sold).
    sold_key = next(k for k, l in listings.items() if l.organisation_id == hv.id and l.status == "published" and k not in ("Tucson SEL", "IONIQ 5 SE", "Tucson SEL (dealer site)"))
    sl = listings[sold_key]
    r2 = S.create_reservation(s, p_hv, {"listing_id": sl.id, "customer_id": customers[3].id}, "seed-res-sold")
    s.commit(); apply_context(s, p_hv.db_context())
    if r2.deposit_required_minor:
        i2, _ = P.create_payment(s, p_hv, {"purpose": "sale_deposit", "sale_reservation_id": r2.id}, "seed-pay-sold-deposit")
        apply_context(s, DbContext.system()); deliver_ev = simulator.settle_payment(s, i2.provider_intent_ref); s.commit()
        deliver(deliver_ev)
        apply_context(s, p_hv.db_context())
    r2 = s.get(S.SaleReservation, r2.id); s.refresh(r2)
    S.accept(s, p_hv, r2.id, r2.version); s.commit(); apply_context(s, p_hv.db_context())
    r2 = s.get(S.SaleReservation, r2.id); s.refresh(r2)
    o2 = S.convert_to_order(s, p_hv, r2.id, r2.version, 2950000); s.commit(); apply_context(s, p_hv.db_context()); s.refresh(o2)
    S.order_action(s, p_hv, o2.id, o2.version, "sign_agreement", {}); s.commit(); apply_context(s, p_hv.db_context()); s.refresh(o2)
    S.order_action(s, p_hv, o2.id, o2.version, "handover", {"location_id": sl.location_id, "odometer_value": 41250, "odometer_unit": "mi"})
    s.commit(); apply_context(s, p_hv.db_context()); s.refresh(o2)
    S.order_action(s, p_hv, o2.id, o2.version, "complete", {"accept_outstanding_balance": True,
                                                              "reason": "balance financed by third-party lender (simulated)"})
    s.commit(); apply_context(s, p_ops.db_context())

    # (c) A failed deposit payment and a cancelled reservation with a partial goodwill refund on a rental prepayment.
    b0 = bookings[0]
    i3, _ = P.create_payment(s, p_cl, {"purpose": "rental_prepayment", "rental_booking_id": b0.id}, "seed-pay-rental-0")
    apply_context(s, DbContext.system()); ev3 = simulator.settle_payment(s, i3.provider_intent_ref); s.commit(); deliver(ev3)
    apply_context(s, p_cl.db_context())
    rf, _ = P.request_refund(s, p_cl, {"payment_intent_id": i3.id, "amount_minor": 2000, "reason": "goodwill"}, "seed-refund-rental-0")
    apply_context(s, DbContext.system()); evr = simulator.settle_refund(s, rf.provider_refund_ref); s.commit(); deliver(evr)
    b1 = bookings[1]
    apply_context(s, p_cl.db_context())
    i4, _ = P.create_payment(s, p_cl, {"purpose": "rental_prepayment", "rental_booking_id": b1.id}, "seed-pay-rental-1")
    apply_context(s, DbContext.system()); ev4 = simulator.settle_payment(s, i4.provider_intent_ref, "failed"); s.commit(); deliver(ev4)
    s.commit()

    counts = dict(s.execute(text("""SELECT 'listings', count(*) FROM listings UNION ALL SELECT 'published', count(*) FROM listings WHERE status='published'
        UNION ALL SELECT 'vehicles', count(*) FROM vehicles UNION ALL SELECT 'price_versions', count(*) FROM listing_price_versions
        UNION ALL SELECT 'customers', count(*) FROM customers UNION ALL SELECT 'test_drives', count(*) FROM test_drive_appointments
        UNION ALL SELECT 'rental_assets', count(*) FROM rental_assets UNION ALL SELECT 'maintenance_blocks', count(*) FROM maintenance_blocks
        UNION ALL SELECT 'rental_bookings', count(*) FROM rental_bookings UNION ALL SELECT 'payment_intents', count(*) FROM payment_intents
        UNION ALL SELECT 'payment_transactions', count(*) FROM payment_transactions UNION ALL SELECT 'refunds', count(*) FROM refunds
        UNION ALL SELECT 'sale_orders', count(*) FROM sale_orders""")).all())
    s.close()
    return counts


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=2026)
    args = ap.parse_args()
    url = os.environ.get("AUTOS_MIGRATION_DATABASE_URL")
    if not url:
        raise SystemExit("set AUTOS_MIGRATION_DATABASE_URL (owner role)")
    for k, v in run(url, args.seed).items():
        print(f"{k:22s} {v}")
