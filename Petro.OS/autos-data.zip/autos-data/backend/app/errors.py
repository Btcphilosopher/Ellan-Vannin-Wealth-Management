"""Domain errors and their RFC 9457 problem+json representation.

Integrity triggers raise custom SQLSTATEs (class Z9) whose message starts
with a stable machine code ("vehicle_already_reserved: ..."); these are
translated here so the API reports the database's decision verbatim.
"""
from __future__ import annotations

from typing import Any

from sqlalchemy.exc import DBAPIError


class DomainError(Exception):
    status: int = 400
    code: str = "bad_request"
    title: str = "Bad request"

    def __init__(self, detail: str = "", *, code: str | None = None, status: int | None = None,
                 errors: list[dict[str, Any]] | None = None, extra: dict[str, Any] | None = None):
        super().__init__(detail or self.title)
        self.detail = detail or self.title
        if code:
            self.code = code
        if status:
            self.status = status
        self.errors = errors or []
        self.extra = extra or {}

    def to_problem(self, request_id: str | None) -> dict[str, Any]:
        body = {
            "type": f"https://autos-data.example/problems/{self.code}",
            "title": self.title,
            "status": self.status,
            "code": self.code,
            "detail": self.detail,
            "request_id": request_id,
        }
        if self.errors:
            body["errors"] = self.errors
        body.update(self.extra)
        return body


class NotFound(DomainError):
    status, code, title = 404, "not_found", "Not found"


class Forbidden(DomainError):
    status, code, title = 403, "forbidden", "Forbidden"


class Unauthenticated(DomainError):
    status, code, title = 401, "unauthenticated", "Authentication required"


class Conflict(DomainError):
    status, code, title = 409, "conflict", "Conflict"


class VersionConflict(Conflict):
    code, title = "version_conflict", "The record was changed by someone else"


class PreconditionRequired(DomainError):
    status, code, title = 428, "precondition_required", "If-Match header with the current version is required"


class ValidationFailed(DomainError):
    status, code, title = 422, "validation_failed", "Validation failed"


class IdempotencyMismatch(DomainError):
    status, code, title = 422, "idempotency_key_reused", "Idempotency-Key was already used with a different request"


# SQLSTATE -> (http status, default code, title)
_SQLSTATE = {
    "Z9001": (409, "vehicle_already_reserved", "Vehicle not reservable"),
    "Z9002": (409, "invalid_status_transition", "Invalid state transition"),
    "Z9003": (409, "immutable_record", "Record is immutable"),
    "Z9004": (409, "rental_capacity_exceeded", "No capacity"),
    "Z9005": (409, "rental_asset_conflict", "Asset conflict"),
    "Z9006": (409, "resource_capacity_exceeded", "Resource fully booked"),
    "Z9007": (422, "refund_limit_exceeded", "Refund limit exceeded"),
    "Z9008": (409, "hold_expired", "Hold expired"),
    "Z9009": (422, "quote_not_acceptable", "Quote cannot be accepted"),
    "Z9010": (409, "append_only", "History cannot be changed"),
    "Z9011": (500, "quote_totals_mismatch", "Quote integrity failure"),
    "23P01": (409, "overlap_conflict", "Overlapping period"),
    "23505": (409, "duplicate", "Duplicate"),
    "23503": (422, "unknown_reference", "Referenced record does not exist"),
    "23514": (422, "constraint_violation", "Value violates a database rule"),
    "23502": (422, "missing_value", "Required value missing"),
    "22P02": (422, "invalid_value", "Invalid value"),
    "22007": (422, "invalid_value", "Invalid value"),
    "42501": (403, "forbidden_by_policy", "Not permitted"),
    "40001": (409, "serialization_failure", "Concurrent update, retry"),
    "40P01": (409, "deadlock_detected", "Concurrent update, retry"),
    "55P03": (409, "lock_timeout", "Record is busy, retry"),
    "57014": (503, "statement_timeout", "Query timed out"),
}

# Exclusion / unique constraint names -> friendlier codes
_CONSTRAINT_CODES = {
    "rental_asset_assignments_rental_asset_id_occupied_excl": "rental_asset_conflict",
    "maintenance_blocks_rental_asset_id_block_range_excl": "maintenance_overlap",
    "test_drive_appointments_vehicle_id_slot_excl": "vehicle_slot_conflict",
    "listing_price_versions_listing_id_tstzrange_excl": "price_period_overlap",
    "sale_reservations_one_active_per_vehicle_uq": "vehicle_already_reserved",
    "vehicle_current_reservations_pkey": "vehicle_already_reserved",
    "vehicle_identifiers_active_uq": "duplicate_identifier",
    "listings_one_open_per_vehicle_channel_uq": "duplicate_open_listing",
    "customers_email_uq": "duplicate_email",
    "sale_orders_one_open_per_vehicle_uq": "vehicle_already_sold_or_ordered",
    "reconciliation_cases_open_uq": "duplicate_open_case",
}


_CONSTRAINT_DETAIL = {
    "rental_asset_conflict": "the asset is already assigned for an overlapping period (including turnaround buffer)",
    "maintenance_overlap": "the asset already has a maintenance block in this period",
    "vehicle_slot_conflict": "the vehicle already has a confirmed test drive overlapping this slot",
    "price_period_overlap": "price versions for a listing cannot overlap",
    "vehicle_already_reserved": "this vehicle is committed to another reservation",
    "duplicate_identifier": "an active identifier with this namespace and value already exists",
    "duplicate_open_listing": "this vehicle already has an open listing on this channel for this seller",
    "duplicate_email": "a customer with this email already exists",
    "vehicle_already_sold_or_ordered": "this vehicle already has an open sale order",
    "duplicate_open_case": "an open case of this type already exists for this payment",
}


def from_db_error(exc: DBAPIError) -> DomainError:
    orig = getattr(exc, "orig", None)
    sqlstate = getattr(orig, "sqlstate", None) or ""
    diag = getattr(orig, "diag", None)
    message = (getattr(diag, "message_primary", None) or str(orig or exc)).strip()
    constraint = getattr(diag, "constraint_name", None)
    status, code, title = _SQLSTATE.get(sqlstate, (500, "database_error", "Database error"))
    detail = message
    if sqlstate.startswith("Z9") and ":" in message:
        prefix, rest = message.split(":", 1)
        if prefix.isidentifier():
            code, detail = prefix, rest.strip()
        if code == "invalid_reference":
            status = 422
    if constraint and constraint in _CONSTRAINT_CODES:
        code = _CONSTRAINT_CODES[constraint]
        detail = _CONSTRAINT_DETAIL.get(code, detail)
    if sqlstate == "42501" and "row-level security" in message:
        code = "forbidden_by_policy"
    err = DomainError(detail, code=code, status=status, extra={"sqlstate": sqlstate} | ({"constraint": constraint} if constraint else {}))
    err.title = title
    return err
