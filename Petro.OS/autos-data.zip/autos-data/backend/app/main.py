"""FastAPI application (modular monolith)."""
from __future__ import annotations

import logging
import re
import uuid

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.exc import DBAPIError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.api import routes_commerce, routes_inventory, routes_ops
from app.config import get_settings
from app.errors import DomainError, from_db_error

log = logging.getLogger("autos.api")

DESCRIPTION = """
Authoritative data platform for a vehicle marketplace: catalogue, physical vehicles, dealer listings, immutable quotes,
concurrency-safe sale reservations, test drives, rentals, payments, imports, audit and reconciliation.

**Conventions**

* **Auth** — `Authorization: Bearer <token>`. `POST /v1/auth/token` is a *development* issuer. Optional
  `X-Organisation-Id` narrows the caller to one organisation.
* **Errors** — RFC 9457 `application/problem+json` with a stable `code` (e.g. `vehicle_already_reserved`,
  `version_conflict`, `rental_capacity_exceeded`, `refund_limit_exceeded`, `publication_blocked`) and `request_id`.
* **Pagination** — keyset: `?limit=50&cursor=<next_cursor>`; responses are `{items, next_cursor}`.
* **Optimistic concurrency** — mutable resources return `ETag: "<version>"`; edits and domain actions require
  `If-Match: "<version>"` (428 if missing, 409 `version_conflict` if stale).
* **Idempotency** — consequential POSTs accept `Idempotency-Key` (8-200 chars). Same key + same body replays the
  stored response (`Idempotent-Replayed: true`); same key + different body is 422 `idempotency_key_reused`.
  Payments and refunds *require* it.
* **Money** — integer minor units (`*_minor`) plus an explicit ISO 4217 `currency`.
* **Time** — instants are ISO 8601 with offset (naive timestamps are rejected); local scheduling uses IANA zones.
* **Domain actions** — status changes happen only through action endpoints (`/publish`, `/acceptance`,
  `/cancellation`, ...); generic PATCH cannot change status or financial history.
* **Tenancy** — backend authorisation per request plus PostgreSQL row-level security. Records you may not see return 404.

All dealers, customers, VINs and payments in the bundled data are fictional/synthetic; the payment provider is simulated.
"""

TAGS = [{"name": n} for n in ["Auth", "Catalogue", "Vehicles", "Listings", "Dealers", "Customers", "Quotes", "Reservations",
                              "Test Drives", "Rentals", "Payments", "Imports", "Audit", "Reports", "Operations", "Simulator"]]


def create_app() -> FastAPI:
    s = get_settings()
    app = FastAPI(title=f"{s.brand_name} API", version="1.0.0", description=DESCRIPTION, openapi_tags=TAGS,
                  docs_url="/docs", redoc_url="/redoc", openapi_url="/openapi.json")
    app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://localhost:8080"], allow_credentials=False,
                       allow_methods=["*"], allow_headers=["*"],
                       expose_headers=["ETag", "X-Request-Id", "Idempotent-Replayed"])

    rid_ok = re.compile(r"^[A-Za-z0-9._-]{8,64}$")

    @app.middleware("http")
    async def request_id_mw(request: Request, call_next):
        incoming = request.headers.get(s.request_id_header)
        request.state.request_id = incoming if incoming and rid_ok.match(incoming) else uuid.uuid4().hex
        response = await call_next(request)
        response.headers[s.request_id_header] = request.state.request_id
        response.headers.setdefault("Cache-Control", "no-store")
        return response

    def problem(request: Request, err: DomainError) -> JSONResponse:
        rid = getattr(request.state, "request_id", None)
        return JSONResponse(err.to_problem(rid), status_code=err.status, media_type="application/problem+json",
                            headers={s.request_id_header: rid or ""})

    @app.exception_handler(DomainError)
    async def domain_error(request: Request, exc: DomainError):
        return problem(request, exc)

    @app.exception_handler(DBAPIError)
    async def db_error(request: Request, exc: DBAPIError):
        err = from_db_error(exc)
        if err.status >= 500:
            log.exception("database error", exc_info=exc)
        return problem(request, err)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError):
        errors = [{"field": ".".join(str(x) for x in e["loc"][1:]) or str(e["loc"][0]), "code": e["type"], "message": e["msg"]}
                  for e in exc.errors()]
        return problem(request, DomainError("request did not match the contract", code="validation_failed", status=422, errors=errors))

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request: Request, exc: StarletteHTTPException):
        return problem(request, DomainError(str(exc.detail), code="not_found" if exc.status_code == 404 else "http_error",
                                            status=exc.status_code))

    app.include_router(routes_ops.router)
    app.include_router(routes_inventory.router)
    app.include_router(routes_commerce.router)
    return app


app = create_app()
