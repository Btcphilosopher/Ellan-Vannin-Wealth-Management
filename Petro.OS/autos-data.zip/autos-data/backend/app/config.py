"""Runtime configuration (environment variables prefixed AUTOS_)."""
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="AUTOS_", env_file=".env", extra="ignore")

    # Database: the API and workers connect as a NON-owner login role that is
    # a member of autos_app, so row-level security applies.
    database_url: str = "postgresql+psycopg://autos_api:autos_api@localhost:5432/autos_dev"
    migration_database_url: str = "postgresql+psycopg://autos_owner:autos@localhost:5432/autos_dev"
    db_pool_size: int = 10
    db_max_overflow: int = 10
    db_statement_timeout_ms: int = 15000
    db_lock_timeout_ms: int = 5000

    # Branding is configuration, not code. The default makes no claim of
    # affiliation with any marketplace operator.
    brand_name: str = "Autos Data"
    brand_product: str = "Vehicle Marketplace Database & Operations"
    brand_disclaimer: str = (
        "Independent concept software using fictional dealers, synthetic vehicle identifiers and simulated "
        "transactions. Not affiliated with, endorsed by, or connected to Amazon or any marketplace operator."
    )

    # Authentication. The bundled token issuer is a DEVELOPMENT stand-in for
    # a real identity provider (OIDC). Disable it outside local/demo use.
    jwt_secret: str = Field(default="dev-only-change-me-0123456789abcdef", min_length=32)
    jwt_issuer: str = "autos-data-dev"
    jwt_ttl_seconds: int = 8 * 3600
    enable_dev_auth: bool = True

    # Simulated payment provider.
    enable_simulator: bool = True
    simpay_webhook_secret: str = Field(default="whsec_dev_simpay_0123456789abcdef", min_length=16)
    simpay_signature_tolerance_seconds: int = 300

    # Object storage (S3-compatible: MinIO in Docker Compose).
    storage_backend: str = "local"  # "s3" | "local"
    s3_endpoint_url: str | None = None
    s3_region: str = "us-east-1"
    s3_access_key: str | None = None
    s3_secret_key: str | None = None
    s3_bucket: str = "autos-data"
    local_storage_dir: str = "./var/objects"

    # Domain defaults
    quote_validity_hours: int = 48
    import_max_bytes: int = 10 * 1024 * 1024
    import_max_rows: int = 20000
    outbox_max_attempts: int = 8
    webhook_sink_url: str | None = None  # outbox publisher target; None = log sink

    request_id_header: str = "X-Request-Id"


@lru_cache
def get_settings() -> Settings:
    return Settings()
