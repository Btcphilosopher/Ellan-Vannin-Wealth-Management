"""SIMULATED payment provider ("simpay").

Stands in for an external processor: it stores its own state in the
`simpay` schema, issues provider references, and produces HMAC-signed
webhook events exactly as a real provider would. Nothing here touches the
authoritative tables directly — events flow through the public webhook
handler (`payments.handle_provider_event`).
"""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import json
import time
import uuid

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.config import get_settings

PROVIDER = "simpay"


class ProviderTimeout(Exception):
    """Simulated network timeout: the provider MAY have processed the request."""


def sign(body: bytes, timestamp: int | None = None, secret: str | None = None) -> str:
    ts = timestamp or int(time.time())
    secret = secret or get_settings().simpay_webhook_secret
    mac = hmac.new(secret.encode(), f"{ts}.".encode() + body, hashlib.sha256).hexdigest()
    return f"t={ts},v1={mac}"


def verify(body: bytes, header: str | None, *, now: int | None = None) -> bool:
    if not header:
        return False
    try:
        parts = dict(p.split("=", 1) for p in header.split(","))
        ts = int(parts["t"])
    except (ValueError, KeyError):
        return False
    s = get_settings()
    if abs((now or int(time.time())) - ts) > s.simpay_signature_tolerance_seconds:
        return False
    expected = hmac.new(s.simpay_webhook_secret.encode(), f"{ts}.".encode() + body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, parts.get("v1", ""))


def create_payment(session: Session, *, merchant_ref: str, amount_minor: int, currency: str, idempotency_key: str,
                   simulate_timeout: bool = False) -> dict:
    row = session.execute(text("""
        INSERT INTO simpay.payments (ref, merchant_ref, amount_minor, currency, status, idempotency_key)
        VALUES (:ref, :m, :a, :c, 'processing', :k)
        ON CONFLICT (idempotency_key) DO UPDATE SET updated_at = simpay.payments.updated_at
        RETURNING ref, status, amount_minor, currency"""),
        {"ref": "sp_pi_" + uuid.uuid4().hex[:20], "m": merchant_ref, "a": amount_minor, "c": currency, "k": idempotency_key}).mappings().one()
    if simulate_timeout:
        raise ProviderTimeout("simulated timeout after the provider accepted the request")
    return dict(row)


def find_payment_by_key(session: Session, idempotency_key: str) -> dict | None:
    r = session.execute(text("SELECT * FROM simpay.payments WHERE idempotency_key = :k"), {"k": idempotency_key}).mappings().first()
    return dict(r) if r else None


def _event(session: Session, event_type: str, data: dict, created_at: dt.datetime | None = None) -> dict:
    created = created_at or dt.datetime.now(dt.timezone.utc)
    ev = {"id": "evt_" + uuid.uuid4().hex[:24], "type": event_type, "created": created.isoformat(), "data": data}
    session.execute(text("INSERT INTO simpay.events (event_id, event_type, created_at, body) VALUES (:i, :t, :c, CAST(:b AS jsonb))"),
                    {"i": ev["id"], "t": event_type, "c": created, "b": json.dumps(ev)})
    return ev


def settle_payment(session: Session, ref: str, outcome: str = "succeeded", *, amount_minor: int | None = None,
                   created_at: dt.datetime | None = None) -> dict:
    p = session.execute(text("SELECT * FROM simpay.payments WHERE ref = :r FOR UPDATE"), {"r": ref}).mappings().one()
    amt = amount_minor if amount_minor is not None else p["amount_minor"]
    session.execute(text("UPDATE simpay.payments SET status = :s, captured_minor = :c, updated_at = now() WHERE ref = :r"),
                    {"s": outcome, "c": amt if outcome == "succeeded" else 0, "r": ref})
    data = {"payment_ref": ref, "merchant_ref": p["merchant_ref"], "amount_minor": amt, "currency": p["currency"]}
    if outcome == "succeeded":
        data["transaction_ref"] = "sp_tx_" + uuid.uuid4().hex[:20]
    return _event(session, f"payment.{outcome}", data, created_at)


def processing_event(session: Session, ref: str, created_at: dt.datetime | None = None) -> dict:
    p = session.execute(text("SELECT * FROM simpay.payments WHERE ref = :r"), {"r": ref}).mappings().one()
    return _event(session, "payment.processing", {"payment_ref": ref, "merchant_ref": p["merchant_ref"],
                                                  "amount_minor": p["amount_minor"], "currency": p["currency"]}, created_at)


def create_refund(session: Session, *, payment_ref: str, amount_minor: int, idempotency_key: str) -> dict:
    row = session.execute(text("""
        INSERT INTO simpay.refunds (ref, payment_ref, amount_minor, status, idempotency_key)
        VALUES (:ref, :p, :a, 'pending', :k)
        ON CONFLICT (idempotency_key) DO UPDATE SET status = simpay.refunds.status
        RETURNING ref, status"""), {"ref": "sp_re_" + uuid.uuid4().hex[:20], "p": payment_ref, "a": amount_minor,
                                     "k": idempotency_key}).mappings().one()
    return dict(row)


def settle_refund(session: Session, ref: str, outcome: str = "succeeded") -> dict:
    r = session.execute(text("SELECT * FROM simpay.refunds WHERE ref = :r FOR UPDATE"), {"r": ref}).mappings().one()
    session.execute(text("UPDATE simpay.refunds SET status = :s WHERE ref = :r"), {"s": outcome, "r": ref})
    data = {"refund_ref": ref, "payment_ref": r["payment_ref"], "amount_minor": r["amount_minor"]}
    if outcome == "succeeded":
        data["transaction_ref"] = "sp_rtx_" + uuid.uuid4().hex[:20]
    return _event(session, f"refund.{outcome}", data)


def signed_delivery(event: dict, timestamp: int | None = None) -> tuple[bytes, dict]:
    body = json.dumps(event, separators=(",", ":")).encode()
    return body, {"SimPay-Signature": sign(body, timestamp), "Content-Type": "application/json"}


def get_event(session: Session, event_id: str) -> dict | None:
    r = session.execute(text("SELECT body FROM simpay.events WHERE event_id = :i"), {"i": event_id}).first()
    return r[0] if r else None
