"""Catalogue, vehicles, listings, organisations, customers."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, File, Form, Query, UploadFile
from fastapi.responses import JSONResponse, Response
from sqlalchemy import select, text

from app.api.deps import Ctx, etag, get_ctx, idempotency_key, if_match
from app.errors import Forbidden
from app.models import (Customer, Listing, Location, Organisation, SavedSearch, SavedVehicle, Vehicle, VehicleMake,
                        VehicleMergeProposal, VehicleModel, VehicleTrim)
from app.money import Money
from app.schemas import (AssertionIn, BulkPublish, CustomerCreate, CustomerPatch, ListingCreate, ListingPatch, MergeDecision,
                         Page, PriceChange, ReasonIn, SavedSearchCreate, VehicleCreate, VehiclePatch)
from app.services import listings as L
from app.services import operations as ops
from app.services import vehicles as V
from app.services.common import get_or_404, jsonable, location_point, row_dict

router = APIRouter(prefix="/v1")


def ok(ctx: Ctx, body, status: int = 200, version: int | None = None, commit: bool = True) -> JSONResponse:
    body = jsonable(body)
    ctx.idempotency_finish(status, body)
    if commit:
        ctx.commit()
    return JSONResponse(body, status_code=status, headers=etag(version) if version is not None else None)


# ------------------------------------------------------------------ catalogue
@router.get("/catalogue/trims", tags=["Catalogue"], summary="List catalogue trims (make/model/year/trim)")
def list_trims(make: str | None = None, model_year: int | None = None, ctx: Ctx = Depends(get_ctx)):
    stmt = (select(VehicleTrim, VehicleModel.name, VehicleMake.name).join(VehicleModel, VehicleModel.id == VehicleTrim.model_id)
            .join(VehicleMake, VehicleMake.id == VehicleModel.make_id).order_by(VehicleMake.name, VehicleModel.name, VehicleTrim.model_year))
    if make:
        stmt = stmt.where(VehicleMake.name == make)
    if model_year:
        stmt = stmt.where(VehicleTrim.model_year == model_year)
    items = [row_dict(t) | {"model": m, "make": k} for t, m, k in ctx.session.execute(stmt)]
    return {"items": jsonable(items)}


@router.get("/catalogue/trims/{trim_id}/specifications", tags=["Catalogue"], summary="Versioned manufacturer specifications for a trim")
def trim_specs(trim_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    rows = ctx.session.execute(text("SELECT * FROM vehicle_specification_versions WHERE trim_id = :t ORDER BY source, effective_from DESC"),
                               {"t": trim_id}).mappings()
    return {"items": jsonable([dict(r) for r in rows])}


# ------------------------------------------------------------------ organisations & locations
@router.get("/organisations", tags=["Dealers"], summary="List organisations (dealers, rental suppliers)")
def list_orgs(kind: str | None = None, ctx: Ctx = Depends(get_ctx)):
    stmt = select(Organisation).order_by(Organisation.display_name)
    if kind:
        stmt = stmt.where(Organisation.kind == kind)
    out = []
    for o in ctx.session.execute(stmt).scalars():
        d = row_dict(o)
        if not (ctx.p.is_platform or o.id in ctx.p.org_ids):
            d = {k: d[k] for k in ("id", "kind", "display_name", "slug", "status", "default_currency", "default_timezone")}
        out.append(d)
    return {"items": out}


@router.get("/organisations/{org_id}", tags=["Dealers"], summary="Organisation detail with locations and policies")
def get_org(org_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    o = get_or_404(ctx.session, Organisation, org_id, label="organisation")
    d = row_dict(o)
    d["locations"] = [row_dict(x) | {"point": location_point(ctx.session, x.id)} for x in
                      ctx.session.execute(select(Location).where(Location.organisation_id == o.id).order_by(Location.code)).scalars()]
    if ctx.p.is_platform or o.id in ctx.p.org_ids:
        d["members"] = jsonable([dict(r) for r in ctx.session.execute(text("""
            SELECT u.id, u.display_name, u.email, m.role, m.status FROM organisation_memberships m JOIN app_users u ON u.id = m.user_id
             WHERE m.organisation_id = :o ORDER BY m.role, u.display_name"""), {"o": o.id}).mappings()])
    return JSONResponse(jsonable(d), headers=etag(o.version))


# ------------------------------------------------------------------ vehicles
@router.get("/vehicles", tags=["Vehicles"], response_model=Page, summary="Search physical vehicles",
            description="Keyset-paginated. `q` matches VIN/identifier prefixes or make/model/trim names.")
def list_vehicles(q: str | None = None, availability: str | None = None, organisation_id: uuid.UUID | None = None,
                  limit: int = Query(50, ge=1, le=200), cursor: str | None = None, ctx: Ctx = Depends(get_ctx)):
    items, nxt = V.list_vehicles(ctx.session, q=q, availability=availability, organisation_id=organisation_id, limit=limit, cursor=cursor)
    return {"items": items, "next_cursor": nxt}


@router.post("/vehicles", tags=["Vehicles"], status_code=201, summary="Register a physical vehicle")
def create_vehicle(body: VehicleCreate, ctx: Ctx = Depends(get_ctx), key: str | None = Depends(idempotency_key)):
    if (replay := ctx.idempotency_begin(key, body.model_dump(mode="json"))):
        return replay
    v = V.create_vehicle(ctx.session, ctx.p, body.model_dump(exclude_unset=True, mode="python") |
                         {"identifiers": [i.model_dump() for i in body.identifiers]})
    return ok(ctx, V.describe(ctx.session, v), 201, v.version)


@router.get("/vehicles/{vehicle_id}", tags=["Vehicles"], summary="Vehicle detail (identifiers, current commitment)")
def get_vehicle(vehicle_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    v = get_or_404(ctx.session, Vehicle, vehicle_id, label="vehicle")
    d = V.describe(ctx.session, v)
    d["listings"] = [row_dict(x) for x in ctx.session.execute(select(Listing).where(Listing.vehicle_id == v.id)).scalars()]
    return JSONResponse(jsonable(d), headers=etag(v.version))


@router.patch("/vehicles/{vehicle_id}", tags=["Vehicles"], summary="Edit descriptive vehicle fields (If-Match required)",
              description="Only descriptive fields. Status-like changes (sold, reservations) happen through domain actions.")
def patch_vehicle(vehicle_id: uuid.UUID, body: VehiclePatch, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    v = V.update_vehicle(ctx.session, ctx.p, vehicle_id, version, body.model_dump(exclude_unset=True))
    return ok(ctx, V.describe(ctx.session, v), 200, v.version)


@router.get("/vehicles/{vehicle_id}/assertions", tags=["Vehicles"], summary="Provenance: manufacturer data, seller claims, inspection findings")
def vehicle_assertions(vehicle_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    get_or_404(ctx.session, Vehicle, vehicle_id, label="vehicle")
    return jsonable(V.assertions(ctx.session, vehicle_id))


@router.post("/vehicles/{vehicle_id}/assertions", tags=["Vehicles"], status_code=201, summary="Record a sourced claim/finding")
def add_assertion(vehicle_id: uuid.UUID, body: AssertionIn, ctx: Ctx = Depends(get_ctx)):
    a = V.add_assertion(ctx.session, ctx.p, vehicle_id, body.model_dump())
    return ok(ctx, row_dict(a), 201)


@router.post("/vehicles/{vehicle_id}/media", tags=["Vehicles"], status_code=201, summary="Upload an image/document to object storage")
async def upload_media(vehicle_id: uuid.UUID, file: UploadFile = File(...), kind: str = Form("photo"),
                       caption: str | None = Form(None), ctx: Ctx = Depends(get_ctx)):
    data = await file.read()
    m = V.add_media(ctx.session, ctx.p, vehicle_id, filename=file.filename or "upload", content_type=file.content_type or "application/octet-stream",
                    data=data, kind=kind, caption=caption)
    return ok(ctx, row_dict(m), 201)


@router.get("/vehicle-merge-proposals", tags=["Vehicles"], summary="Uncertain duplicate matches awaiting review")
def list_merge_proposals(status: str = "pending", ctx: Ctx = Depends(get_ctx)):
    rows = ctx.session.execute(select(VehicleMergeProposal).where(VehicleMergeProposal.status == status)
                               .order_by(VehicleMergeProposal.created_at.desc()).limit(200)).scalars()
    return {"items": [row_dict(r) for r in rows]}


@router.post("/vehicle-merge-proposals/{proposal_id}/decision", tags=["Vehicles"], summary="Accept or reject a merge proposal")
def decide_merge(proposal_id: uuid.UUID, body: MergeDecision, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    prop = V.decide_merge(ctx.session, ctx.p, proposal_id, body.decision, body.note, version)
    return ok(ctx, row_dict(prop), 200, prop.version)


# ------------------------------------------------------------------ listings
@router.get("/listings", tags=["Listings"], response_model=Page, summary="Search listings (filters, radius search)",
            description="Radius search: `lat`, `lon`, `radius_km` use PostGIS ST_DWithin on geography (metres). "
                        "Prices filter on integer minor units.")
def search_listings(status: str | None = None, organisation_id: uuid.UUID | None = None, make: str | None = None,
                    model: str | None = None, min_price_minor: int | None = None, max_price_minor: int | None = None,
                    q: str | None = None, lat: float | None = Query(None, ge=-90, le=90), lon: float | None = Query(None, ge=-180, le=180),
                    radius_km: float | None = Query(None, gt=0, le=2000), freshness: str | None = None,
                    limit: int = Query(50, ge=1, le=200), cursor: str | None = None, ctx: Ctx = Depends(get_ctx)):
    items, nxt = L.search(ctx.session, status=status, organisation_id=organisation_id, make=make, model=model,
                          min_price=min_price_minor, max_price=max_price_minor, q=q, lat=lat, lon=lon, radius_km=radius_km,
                          freshness=freshness, limit=limit, cursor=cursor)
    return {"items": jsonable(items), "next_cursor": nxt}


@router.get("/listings/export.csv", tags=["Listings"], summary="CSV export (spreadsheet-formula safe)",
            response_class=Response, responses={200: {"content": {"text/csv": {}}}})
def export_listings(organisation_id: uuid.UUID | None = None, status: str | None = None, ctx: Ctx = Depends(get_ctx)):
    if not ctx.p.orgs_with("listings.read") and not ctx.p.is_platform:
        raise Forbidden("missing permission listings.read")
    data = L.export_csv(ctx.session, organisation_id, status)
    return Response(data, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="listings.csv"', "X-Content-Type-Options": "nosniff"})


@router.post("/listings", tags=["Listings"], status_code=201, summary="Create a draft listing (optionally with initial price)")
def create_listing(body: ListingCreate, ctx: Ctx = Depends(get_ctx), key: str | None = Depends(idempotency_key)):
    if (replay := ctx.idempotency_begin(key, body.model_dump(mode="json"))):
        return replay
    lst = L.create_listing(ctx.session, ctx.p, body.model_dump(exclude_unset=True))
    return ok(ctx, L.describe(ctx.session, lst, include_history=True), 201, lst.version)


@router.get("/listings/{listing_id}", tags=["Listings"], summary="Listing detail with price/status history and validation findings")
def get_listing(listing_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    lst = get_or_404(ctx.session, Listing, listing_id, label="listing")
    return JSONResponse(jsonable(L.describe(ctx.session, lst, include_history=True)), headers=etag(lst.version))


@router.patch("/listings/{listing_id}", tags=["Listings"], summary="Edit listing content (not status/price)")
def patch_listing(listing_id: uuid.UUID, body: ListingPatch, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    lst = L.update_listing(ctx.session, ctx.p, listing_id, version, body.model_dump(exclude_unset=True))
    return ok(ctx, L.describe(ctx.session, lst, include_history=True), 200, lst.version)


@router.post("/listings/{listing_id}/prices", tags=["Listings"], summary="Change asking price (closes the current price version)")
def change_price(listing_id: uuid.UUID, body: PriceChange, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    lst = get_or_404(ctx.session, Listing, listing_id, label="listing")
    from app.services.common import check_version
    check_version(lst, version)
    lst = L.change_price(ctx.session, ctx.p, listing_id, None, Money.parse(body.price, lst.currency).amount_minor, body.reason)
    return ok(ctx, L.describe(ctx.session, lst, include_history=True), 200, lst.version)


@router.get("/listings/{listing_id}/validation", tags=["Listings"], summary="Publication validation findings")
def listing_validation(listing_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    lst = get_or_404(ctx.session, Listing, listing_id, label="listing")
    f = L.validate_for_publication(ctx.session, lst)
    return {"listing_id": str(lst.id), "publishable": not any(x["severity"] == "error" for x in f), "findings": f}


def _transition(action):
    def handler(listing_id: uuid.UUID, body: ReasonIn | None = None, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
        lst = L.transition(ctx.session, ctx.p, listing_id, version, action, body.reason if body else None)
        return ok(ctx, L.describe(ctx.session, lst, include_history=True), 200, lst.version)
    return handler


router.add_api_route("/listings/{listing_id}/publish", _transition("publish"), methods=["POST"], tags=["Listings"],
                     summary="Publish (validates; draft|suspended -> published)")
router.add_api_route("/listings/{listing_id}/suspend", _transition("suspend"), methods=["POST"], tags=["Listings"],
                     summary="Suspend a published listing")
router.add_api_route("/listings/{listing_id}/withdraw", _transition("withdraw"), methods=["POST"], tags=["Listings"],
                     summary="Withdraw a listing (terminal)")


@router.post("/listings/publication-batch", tags=["Listings"], summary="Publish many listings; per-listing results")
def bulk_publish(body: BulkPublish, ctx: Ctx = Depends(get_ctx)):
    res = L.bulk_publish(ctx.session, ctx.p, body.listing_ids)
    return ok(ctx, {"results": res, "published": sum(r["result"] == "published" for r in res),
                    "rejected": sum(r["result"] == "rejected" for r in res)})


# ------------------------------------------------------------------ customers
@router.get("/customers", tags=["Customers"], response_model=Page, summary="Customers visible to you (relationship-scoped)")
def list_customers(q: str | None = None, limit: int = Query(50, ge=1, le=200), cursor: str | None = None, ctx: Ctx = Depends(get_ctx)):
    if not ctx.p.is_customer and not ctx.p.orgs_with("customers.read") and not ctx.p.is_platform:
        raise Forbidden("missing permission customers.read")
    items, nxt = ops.list_customers(ctx.session, q, limit, cursor)
    return {"items": items, "next_cursor": nxt}


@router.post("/customers", tags=["Customers"], status_code=201, summary="Register a customer for your organisation")
def create_customer(body: CustomerCreate, ctx: Ctx = Depends(get_ctx), key: str | None = Depends(idempotency_key)):
    if (replay := ctx.idempotency_begin(key, body.model_dump(mode="json"))):
        return replay
    c = ops.create_customer(ctx.session, ctx.p, body.model_dump(exclude_unset=True))
    return ok(ctx, ops.describe_customer(ctx.session, c), 201, c.version)


@router.get("/customers/{customer_id}", tags=["Customers"], summary="Customer detail")
def get_customer(customer_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    c = get_or_404(ctx.session, Customer, customer_id, label="customer")
    return JSONResponse(jsonable(ops.describe_customer(ctx.session, c)), headers=etag(c.version))


@router.patch("/customers/{customer_id}", tags=["Customers"], summary="Edit customer contact fields (If-Match required)")
def patch_customer(customer_id: uuid.UUID, body: CustomerPatch, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    c = ops.update_customer(ctx.session, ctx.p, customer_id, version, body.model_dump(exclude_unset=True))
    return ok(ctx, ops.describe_customer(ctx.session, c), 200, c.version)


@router.post("/customers/{customer_id}/erasure", tags=["Customers"], summary="Anonymise customer PII (platform only); history kept")
def erase_customer(customer_id: uuid.UUID, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    c = ops.erase_customer(ctx.session, ctx.p, customer_id, version)
    return ok(ctx, row_dict(c), 200, c.version)


@router.get("/me/saved-vehicles", tags=["Customers"], summary="Customer shortlist")
def saved_vehicles(ctx: Ctx = Depends(get_ctx)):
    rows = ctx.session.execute(select(SavedVehicle).where(SavedVehicle.customer_id == ctx.p.customer_id)).scalars()
    return {"items": [row_dict(r) for r in rows]}


@router.put("/me/saved-vehicles/{listing_id}", tags=["Customers"], status_code=204, summary="Save a listing")
def save_vehicle(listing_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    if not ctx.p.is_customer:
        raise Forbidden("customer accounts only")
    ctx.session.execute(text("INSERT INTO saved_vehicles (customer_id, listing_id) VALUES (:c, :l) ON CONFLICT DO NOTHING"),
                        {"c": ctx.p.customer_id, "l": listing_id})
    ctx.commit()
    return Response(status_code=204)


@router.post("/me/saved-searches", tags=["Customers"], status_code=201, summary="Save a search (criteria validated)")
def save_search(body: SavedSearchCreate, ctx: Ctx = Depends(get_ctx)):
    if not ctx.p.is_customer:
        raise Forbidden("customer accounts only")
    s = SavedSearch(customer_id=ctx.p.customer_id, name=body.name, criteria=body.criteria.model_dump(exclude_none=True), notify=body.notify)
    ctx.session.add(s)
    ctx.session.flush()
    return ok(ctx, row_dict(s), 201)
