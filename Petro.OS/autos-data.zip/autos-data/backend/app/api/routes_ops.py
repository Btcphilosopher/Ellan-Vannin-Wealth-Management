"""Auth, health, branding, payments/providers/refunds/reconciliation, imports, audit, outbox, reports, saved filters, simulator."""
from __future__ import annotations

import json
import uuid

from fastapi import APIRouter, Depends, File, Form, Header, Query, Request, UploadFile
from fastapi.responses import JSONResponse, Response
from sqlalchemy import select, text

from app import simulator
from app.api.deps import Ctx, etag, get_ctx, idempotency_key, if_match
from app.api.routes_inventory import ok
from app.config import get_settings
from app.db import DbContext, apply_context, new_session
from app.errors import Forbidden, NotFound, Unauthenticated, ValidationFailed
from app.models import AdminSavedFilter, AuditEvent, ImportJob, OutboxEvent, PaymentIntent, ReconciliationCase, Refund
from app.schemas import (CaseResolution, ImportOptions, Page, PaymentCreate, RefundCreate, SavedFilterCreate, SimSettle,
                         TokenRequest)
from app.security import issue_token
from app.services import imports as I
from app.services import operations as ops
from app.services import payments as P
from app.services.common import get_or_404, jsonable, keyset_page, parse_dt, row_dict

router = APIRouter(prefix="/v1")


# ------------------------------------------------------------------ public
@router.get("/health/live", tags=["Operations"], summary="Liveness")
def live():
    return {"status": "ok"}


@router.get("/health/ready", tags=["Operations"], summary="Readiness: database, migrations, workers")
def ready():
    s = new_session()
    try:
        apply_context(s, DbContext.system(actor_kind="system"))
        rev = s.execute(text("SELECT version_num FROM alembic_version")).scalar()
        workers = jsonable([dict(r) for r in s.execute(text(
            "SELECT worker_name, last_beat_at, now() - last_beat_at < interval '2 minutes' AS healthy FROM worker_heartbeats")).mappings()])
        return {"status": "ok", "database": "ok", "migration_head": rev, "workers": workers}
    except Exception as e:  # noqa: BLE001
        return JSONResponse({"status": "unavailable", "detail": type(e).__name__}, status_code=503)
    finally:
        s.close()


@router.get("/branding", tags=["Operations"], summary="Configurable branding for the admin UI")
def branding():
    s = get_settings()
    return {"name": s.brand_name, "product": s.brand_product, "disclaimer": s.brand_disclaimer,
            "simulator_enabled": s.enable_simulator, "dev_auth_enabled": s.enable_dev_auth}


@router.post("/auth/token", tags=["Auth"], summary="DEVELOPMENT token issuer (stand-in for an OIDC provider)",
             description="Disabled unless AUTOS_ENABLE_DEV_AUTH=true. Issues an HS256 bearer token for a seeded user by email.")
def dev_token(body: TokenRequest):
    if not get_settings().enable_dev_auth:
        raise NotFound("dev auth disabled")
    s = new_session()
    try:
        apply_context(s, DbContext.system(actor_kind="system"))
        uid = s.execute(text("SELECT id FROM app_users WHERE email = :e AND status = 'active'"), {"e": body.email}).scalar()
    finally:
        s.close()
    if not uid:
        raise Unauthenticated("unknown user", code="invalid_credentials")
    return {"access_token": issue_token(uid), "token_type": "bearer", "expires_in": get_settings().jwt_ttl_seconds}


@router.get("/me", tags=["Auth"], summary="Current principal, memberships and effective permissions")
def me(ctx: Ctx = Depends(get_ctx)):
    return ctx.p.summary()


# ------------------------------------------------------------------ payments
@router.post("/payments", tags=["Payments"], status_code=201, summary="Create a payment intent (Idempotency-Key required)",
             description="Idempotent per (organisation, Idempotency-Key): a retry with the same body returns the same intent "
                         "(200, Idempotent-Replayed: true); a different body returns 422. The intent is committed before the "
                         "provider is called; a provider timeout yields status 'unknown' for the reconciliation worker. "
                         "Settlement never confirms a reservation by itself.")
def create_payment(body: PaymentCreate, ctx: Ctx = Depends(get_ctx), key: str | None = Depends(idempotency_key)):
    intent, replayed = P.create_payment(ctx.session, ctx.p, body.model_dump(), key)
    d = jsonable(P.describe_intent(ctx.session, intent))
    ctx.commit()
    return JSONResponse(d, status_code=200 if replayed else 201, headers={"Idempotent-Replayed": "true"} if replayed else None)


@router.get("/payments", tags=["Payments"], response_model=Page, summary="List payment intents")
def list_payments(status: str | None = None, limit: int = Query(50, ge=1, le=200), cursor: str | None = None, ctx: Ctx = Depends(get_ctx)):
    stmt = select(PaymentIntent)
    if status:
        stmt = stmt.where(PaymentIntent.status == status)
    rows, nxt = keyset_page(ctx.session, stmt, PaymentIntent.created_at, PaymentIntent.id, limit=limit, cursor=cursor, parse=parse_dt)
    return {"items": [row_dict(r[0]) for r in rows], "next_cursor": nxt}


@router.get("/payments/{intent_id}", tags=["Payments"], summary="Payment intent with transactions, events, refunds, cases")
def get_payment(intent_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    i = get_or_404(ctx.session, PaymentIntent, intent_id, label="payment intent")
    return JSONResponse(jsonable(P.describe_intent(ctx.session, i)), headers=etag(i.version))


@router.get("/refunds/{refund_id}", tags=["Payments"], summary="Refund")
def get_refund(refund_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    r = get_or_404(ctx.session, Refund, refund_id, label="refund")
    return JSONResponse(jsonable(row_dict(r)), headers=etag(r.version))


@router.post("/providers/{provider}/events", tags=["Payments"], summary="Provider webhook (HMAC-verified, deduplicated)",
             description="Header SimPay-Signature: t=<unix>,v1=<hex hmac-sha256(secret, t + '.' + body)>. Duplicate event ids "
                         "return 200 {result: duplicate} and are never re-applied; out-of-order events are recorded and ignored.")
async def provider_event(provider: str, request: Request, simpay_signature: str | None = Header(default=None, alias="SimPay-Signature")):
    body = await request.body()
    s = new_session()
    try:
        return P.handle_provider_event(s, provider, body, simpay_signature, request_id=request.state.request_id)
    finally:
        s.rollback()
        s.close()


@router.post("/refunds", tags=["Payments"], status_code=201, summary="Request a full or partial refund (Idempotency-Key required)",
             description="The database rejects refunds whose total would exceed the captured amount (refund_limit_exceeded), "
                         "including under concurrency (row lock on the capture).")
def create_refund(body: RefundCreate, ctx: Ctx = Depends(get_ctx), key: str | None = Depends(idempotency_key)):
    ref, replayed = P.request_refund(ctx.session, ctx.p, body.model_dump(), key)
    d = jsonable(row_dict(ref))
    ctx.commit()
    return JSONResponse(d, status_code=200 if replayed else 201)


@router.get("/refunds", tags=["Payments"], summary="List refunds")
def list_refunds(ctx: Ctx = Depends(get_ctx)):
    return {"items": [row_dict(r) for r in ctx.session.execute(select(Refund).order_by(Refund.requested_at.desc()).limit(200)).scalars()]}


@router.get("/reconciliation-cases", tags=["Payments"], summary="Reconciliation queue")
def list_cases(status: str | None = None, ctx: Ctx = Depends(get_ctx)):
    stmt = select(ReconciliationCase).order_by(ReconciliationCase.opened_at.desc()).limit(200)
    if status == "open":
        stmt = stmt.where(ReconciliationCase.status.notin_(["resolved", "written_off"]))
    elif status:
        stmt = stmt.where(ReconciliationCase.status == status)
    return {"items": [row_dict(c) for c in ctx.session.execute(stmt).scalars()]}


@router.get("/reconciliation-cases/{case_id}", tags=["Payments"], summary="Reconciliation case")
def get_case(case_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    c = get_or_404(ctx.session, ReconciliationCase, case_id, label="reconciliation case")
    return JSONResponse(jsonable(row_dict(c)), headers=etag(c.version))


@router.post("/reconciliation-cases/{case_id}/resolution", tags=["Payments"], summary="Resolve or write off a case (If-Match)")
def resolve_case(case_id: uuid.UUID, body: CaseResolution, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    c = P.resolve_case(ctx.session, ctx.p, case_id, version, body.resolution, body.note, body.status)
    ctx.session.flush()
    ctx.session.refresh(c)
    return ok(ctx, row_dict(c), 200, c.version)


# ------------------------------------------------------------------ simulator (dev only)
def _require_sim():
    if not get_settings().enable_simulator:
        raise NotFound("simulator disabled")


@router.post("/dev/simpay/payments/{payment_ref}/settle", tags=["Simulator"], summary="SIMULATOR: settle a provider payment and deliver webhooks")
def sim_settle(payment_ref: str, body: SimSettle, ctx: Ctx = Depends(get_ctx)):
    _require_sim()
    if not ctx.p.is_platform and not ctx.p.orgs_with("payments.read"):
        raise Forbidden("simulator requires staff access")
    s = new_session()
    try:
        apply_context(s, DbContext.system(actor_kind="system"))
        older = s.execute(text("SELECT created_at FROM simpay.payments WHERE ref = :r"), {"r": payment_ref}).scalar()
        if older is None:
            raise NotFound("unknown provider payment")
        ev = simulator.settle_payment(s, payment_ref, body.outcome, amount_minor=body.amount_minor)
        stale = simulator.processing_event(s, payment_ref, created_at=older) if body.also_send_stale_processing else None
        s.commit()
        results = []
        if body.deliver:
            for _ in range(body.deliver_times):
                raw, headers = simulator.signed_delivery(ev)
                results.append(P.handle_provider_event(s, "simpay", raw, headers["SimPay-Signature"]))
            if stale:
                raw, headers = simulator.signed_delivery(stale)
                results.append(P.handle_provider_event(s, "simpay", raw, headers["SimPay-Signature"]))
        return {"event": ev, "deliveries": results}
    finally:
        s.close()


@router.post("/dev/simpay/refunds/{refund_ref}/settle", tags=["Simulator"], summary="SIMULATOR: settle a provider refund")
def sim_refund(refund_ref: str, outcome: str = "succeeded", ctx: Ctx = Depends(get_ctx)):
    _require_sim()
    if not ctx.p.is_platform and not ctx.p.orgs_with("payments.read"):
        raise Forbidden("simulator requires staff access")
    s = new_session()
    try:
        apply_context(s, DbContext.system(actor_kind="system"))
        ev = simulator.settle_refund(s, refund_ref, outcome)
        s.commit()
        raw, headers = simulator.signed_delivery(ev)
        return {"event": ev, "delivery": P.handle_provider_event(s, "simpay", raw, headers["SimPay-Signature"])}
    finally:
        s.close()


# ------------------------------------------------------------------ imports
@router.post("/import-jobs", tags=["Imports"], status_code=201, summary="Upload a CSV/JSON inventory file (staged + validated)",
             description="Idempotent: identical bytes for the same source return the existing job (200). mode=all_or_nothing "
                         "blocks approval while any row is invalid; partial_accept skips invalid rows.")
async def upload_import(file: UploadFile = File(...), source_namespace: str = Form(...), mode: str = Form("partial_accept"),
                        format: str | None = Form(None), organisation_id: uuid.UUID | None = Form(None),
                        options: str = Form("{}", description="JSON ImportOptions"), ctx: Ctx = Depends(get_ctx)):
    if mode not in ("all_or_nothing", "partial_accept"):
        raise ValidationFailed("mode must be all_or_nothing or partial_accept")
    opts = ImportOptions.model_validate(json.loads(options or "{}"))
    data = await file.read()
    job, dup = I.upload(ctx.session, ctx.p, organisation_id=organisation_id, source_namespace=source_namespace,
                        filename=file.filename or "upload", data=data, fmt=format, mode=mode, options=opts.model_dump())
    body = I.describe(ctx.session, job) | {"duplicate_upload": dup}
    return ok(ctx, body, 200 if dup else 201, job.version)


@router.get("/import-jobs", tags=["Imports"], summary="List import jobs")
def list_imports(ctx: Ctx = Depends(get_ctx)):
    return {"items": [row_dict(j) for j in ctx.session.execute(select(ImportJob).order_by(ImportJob.uploaded_at.desc()).limit(200)).scalars()]}


@router.get("/import-jobs/{job_id}", tags=["Imports"], summary="Import job summary (counts, findings by code)")
def get_import(job_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    j = get_or_404(ctx.session, ImportJob, job_id, label="import job")
    return JSONResponse(jsonable(I.describe(ctx.session, j)), headers=etag(j.version))


@router.get("/import-jobs/{job_id}/rows", tags=["Imports"], summary="Import preview: rows with raw, normalised values and findings")
def import_rows(job_id: uuid.UUID, status: str | None = None, code: str | None = None, limit: int = Query(100, le=500),
                offset: int = Query(0, ge=0), ctx: Ctx = Depends(get_ctx)):
    get_or_404(ctx.session, ImportJob, job_id, label="import job")
    return {"items": jsonable(I.list_rows(ctx.session, job_id, status, code, limit, offset))}


@router.post("/import-jobs/{job_id}/approval", tags=["Imports"], summary="Approve and apply (If-Match)")
def approve_import(job_id: uuid.UUID, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    j = I.approve(ctx.session, ctx.p, job_id, version)
    ctx.session.flush()
    ctx.session.refresh(j)
    return ok(ctx, I.describe(ctx.session, j), 200, j.version)


@router.post("/import-jobs/{job_id}/rejection", tags=["Imports"], summary="Reject a staged import (If-Match)")
def reject_import(job_id: uuid.UUID, reason: str = Form(...), version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    j = I.reject(ctx.session, ctx.p, job_id, version, reason)
    return ok(ctx, row_dict(j), 200, j.version)


# ------------------------------------------------------------------ audit / outbox / reports / saved filters
@router.get("/audit-events", tags=["Audit"], response_model=Page, summary="Append-only audit trail (tenant-scoped)")
def audit_events(target_type: str | None = None, target_id: str | None = None, action: str | None = None,
                 request_id: str | None = None, limit: int = Query(100, ge=1, le=500), before_id: int | None = None,
                 ctx: Ctx = Depends(get_ctx)):
    if not ctx.p.is_platform and not ctx.p.orgs_with("audit.read"):
        raise Forbidden("missing permission audit.read")
    stmt = select(AuditEvent).order_by(AuditEvent.id.desc()).limit(limit)
    for col, val in ((AuditEvent.target_type, target_type), (AuditEvent.target_id, target_id), (AuditEvent.action, action),
                     (AuditEvent.request_id, request_id)):
        if val:
            stmt = stmt.where(col == val)
    if before_id:
        stmt = stmt.where(AuditEvent.id < before_id)
    rows = [row_dict(r) for r in ctx.session.execute(stmt).scalars()]
    return {"items": rows, "next_cursor": str(rows[-1]["id"]) if len(rows) == limit else None}


@router.get("/outbox-events", tags=["Audit"], summary="Outbox / dead-letter queue")
def outbox(status: str | None = None, ctx: Ctx = Depends(get_ctx)):
    if not ctx.p.is_platform and not ctx.p.orgs_with("outbox.read"):
        raise Forbidden("missing permission outbox.read")
    stmt = select(OutboxEvent).order_by(OutboxEvent.created_at.desc()).limit(200)
    if status:
        stmt = stmt.where(OutboxEvent.status == status)
    return {"items": [row_dict(e) for e in ctx.session.execute(stmt).scalars()]}


@router.post("/outbox-events/{event_id}/requeue", tags=["Audit"], summary="Requeue a dead-lettered event (platform)")
def requeue(event_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    ev = ops.requeue_dead(ctx.session, ctx.p, event_id)
    return ok(ctx, row_dict(ev))


@router.get("/reports/{name}", tags=["Reports"], summary="Operational reports",
            description="name: overview | inventory | reservations | payments | rentals | imports | data-quality. Tenant-scoped by RLS.")
def report(name: str, organisation_id: uuid.UUID | None = None, ctx: Ctx = Depends(get_ctx)):
    if not ctx.p.is_platform and not ctx.p.orgs_with("reports.read"):
        raise Forbidden("missing permission reports.read")
    if organisation_id is None and not ctx.p.is_platform and len(ctx.p.org_ids) == 1:
        organisation_id = ctx.p.org_ids[0]  # dealers report on their own data, not on everything public
    return ops.reports(ctx.session, name, organisation_id)


@router.get("/saved-filters", tags=["Operations"], summary="Your saved admin filters")
def saved_filters(page: str | None = None, ctx: Ctx = Depends(get_ctx)):
    stmt = select(AdminSavedFilter).where(AdminSavedFilter.user_id == ctx.p.user_id).order_by(AdminSavedFilter.name)
    if page:
        stmt = stmt.where(AdminSavedFilter.page == page)
    return {"items": [row_dict(f) for f in ctx.session.execute(stmt).scalars()]}


@router.post("/saved-filters", tags=["Operations"], status_code=201, summary="Save an admin filter")
def save_filter(body: SavedFilterCreate, ctx: Ctx = Depends(get_ctx)):
    f = AdminSavedFilter(user_id=ctx.p.user_id, page=body.page, name=body.name, params=body.params)
    ctx.session.add(f)
    ctx.session.flush()
    return ok(ctx, row_dict(f), 201)


@router.delete("/saved-filters/{filter_id}", tags=["Operations"], status_code=204, summary="Delete a saved filter")
def delete_filter(filter_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    ctx.session.execute(text("DELETE FROM admin_saved_filters WHERE id = :i AND user_id = :u"), {"i": filter_id, "u": ctx.p.user_id})
    ctx.commit()
    return Response(status_code=204)
