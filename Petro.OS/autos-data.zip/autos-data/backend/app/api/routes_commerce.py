"""Quotes, sale reservations, sale orders, test drives, rentals."""
from __future__ import annotations

import datetime as dt
import uuid

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse
from sqlalchemy import select

from app.api.deps import Ctx, etag, get_ctx, idempotency_key, if_match
from app.api.routes_inventory import ok
from app.models import (AppointmentResource, Quote, RentalAsset, RentalBooking, RentalCategory, SaleOrder, SaleReservation,
                        TestDriveAppointment)
from app.schemas import (AssignmentIn, CancellationIn, CompletionIn, HandoverIn, MaintenanceCreate, Page, QuoteAcceptanceIn, QuoteCreate,
                         ReasonIn, RentalBookingCreate, RentalQuoteCreate, ReservationCreate, SaleOrderCreate, TestDriveCreate)
from app.services import quotes as Q
from app.services import sales as S
from app.services import scheduling as T
from app.services.common import get_or_404, jsonable, keyset_page, parse_dt, row_dict

router = APIRouter(prefix="/v1")


# ------------------------------------------------------------------ quotes
@router.post("/quotes", tags=["Quotes"], status_code=201, summary="Issue an immutable quote",
             description="Snapshots the listing, vehicle, seller and price version; itemises charges. Unknown taxes/registration "
                         "make the quote incomplete (total = null, missing_charges lists them). The deposit is part of the total.")
def create_quote(body: QuoteCreate, ctx: Ctx = Depends(get_ctx), key: str | None = Depends(idempotency_key)):
    if (replay := ctx.idempotency_begin(key, body.model_dump(mode="json"))):
        return replay
    q = Q.issue_quote(ctx.session, ctx.p, body.model_dump())
    ctx.session.flush()
    return ok(ctx, Q.describe(ctx.session, q), 201)


@router.get("/quotes", tags=["Quotes"], response_model=Page, summary="List quotes")
def list_quotes(organisation_id: uuid.UUID | None = None, customer_id: uuid.UUID | None = None,
                limit: int = Query(50, ge=1, le=200), cursor: str | None = None, ctx: Ctx = Depends(get_ctx)):
    items, nxt = Q.list_quotes(ctx.session, organisation_id=organisation_id, customer_id=customer_id, limit=limit, cursor=cursor)
    return {"items": jsonable(items), "next_cursor": nxt}


@router.get("/quotes/{quote_id}", tags=["Quotes"], summary="Quote with lines, snapshot and acceptance")
def get_quote(quote_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    q = get_or_404(ctx.session, Quote, quote_id, label="quote")
    return JSONResponse(jsonable(Q.describe(ctx.session, q)), headers={"ETag": f'"{q.status}"', "Cache-Control": "no-store"})


@router.post("/quotes/{quote_id}/acceptance", tags=["Quotes"], status_code=201, summary="Accept a complete, unexpired quote")
def accept_quote(quote_id: uuid.UUID, body: QuoteAcceptanceIn, ctx: Ctx = Depends(get_ctx)):
    acc = Q.accept_quote(ctx.session, ctx.p, quote_id, body.channel)
    return ok(ctx, row_dict(acc), 201)


# ------------------------------------------------------------------ sale reservations
@router.post("/sale-reservations", tags=["Reservations"], status_code=201, summary="Place a temporary hold on a physical vehicle",
             description="Atomic: the database locks the vehicle row, expires a lapsed hold inline, and enforces one active "
                         "commitment per vehicle across all listings. Competing requests get 409 vehicle_already_reserved. "
                         "Send Idempotency-Key to make retries safe.")
def create_reservation(body: ReservationCreate, ctx: Ctx = Depends(get_ctx), key: str | None = Depends(idempotency_key)):
    if (replay := ctx.idempotency_begin(key, body.model_dump(mode="json"))):
        return replay
    r = S.create_reservation(ctx.session, ctx.p, body.model_dump(), key)
    return ok(ctx, S.describe(ctx.session, r), 201, r.version)


@router.get("/sale-reservations", tags=["Reservations"], response_model=Page, summary="List reservations",
            description="status=expired_effective lists holds past hold_expires_at that the sweeper has not yet transitioned.")
def list_reservations(organisation_id: uuid.UUID | None = None, status: str | None = None, customer_id: uuid.UUID | None = None,
                      limit: int = Query(50, ge=1, le=200), cursor: str | None = None, ctx: Ctx = Depends(get_ctx)):
    items, nxt = S.list_reservations(ctx.session, organisation_id=organisation_id, status=status, customer_id=customer_id,
                                     limit=limit, cursor=cursor)
    return {"items": jsonable(items), "next_cursor": nxt}


@router.get("/sale-reservations/{reservation_id}", tags=["Reservations"], summary="Reservation with effective status and history")
def get_reservation(reservation_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    r = get_or_404(ctx.session, SaleReservation, reservation_id, label="sale reservation")
    return JSONResponse(jsonable(S.describe(ctx.session, r)), headers=etag(r.version))


@router.post("/sale-reservations/{reservation_id}/acceptance", tags=["Reservations"], summary="Dealer acceptance (If-Match)",
             description="Requires an active (unexpired) hold and, where a deposit is required, a settled deposit.")
def accept_reservation(reservation_id: uuid.UUID, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    r = S.accept(ctx.session, ctx.p, reservation_id, version)
    return ok(ctx, S.describe(ctx.session, r), 200, r.version)


@router.post("/sale-reservations/{reservation_id}/cancellation", tags=["Reservations"], summary="Cancel / decline / release a reservation")
def cancel_reservation(reservation_id: uuid.UUID, body: CancellationIn, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    r = S.end(ctx.session, ctx.p, reservation_id, version, body.outcome, body.reason)
    return ok(ctx, S.describe(ctx.session, r), 200, r.version)


@router.post("/sale-reservations/{reservation_id}/sale-order", tags=["Reservations"], status_code=201,
             summary="Convert a dealer-accepted reservation into a sale order (agreement pending)")
def create_order(reservation_id: uuid.UUID, body: SaleOrderCreate, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    o = S.convert_to_order(ctx.session, ctx.p, reservation_id, version, body.agreed_total_minor)
    return ok(ctx, S.describe_order(ctx.session, o), 201, o.version)


@router.get("/sale-orders/{order_id}", tags=["Reservations"], summary="Sale order with handovers and balance")
def get_order(order_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    o = get_or_404(ctx.session, SaleOrder, order_id, label="sale order")
    return JSONResponse(jsonable(S.describe_order(ctx.session, o)), headers=etag(o.version))


@router.post("/sale-orders/{order_id}/agreement", tags=["Reservations"], summary="Record the signed sale agreement")
def sign_agreement(order_id: uuid.UUID, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    o = S.order_action(ctx.session, ctx.p, order_id, version, "sign_agreement", {})
    return ok(ctx, S.describe_order(ctx.session, o), 200, o.version)


@router.post("/sale-orders/{order_id}/handover", tags=["Reservations"], summary="Record the physical handover")
def handover(order_id: uuid.UUID, body: HandoverIn, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    o = S.order_action(ctx.session, ctx.p, order_id, version, "handover", body.model_dump(exclude_unset=True))
    return ok(ctx, S.describe_order(ctx.session, o), 200, o.version)


@router.post("/sale-orders/{order_id}/completion", tags=["Reservations"], summary="Complete the sale (vehicle -> sold, listings -> sold)",
             description="Refused with 409 balance_outstanding while money is owed, unless accept_outstanding_balance=true with a reason (audited).")
def complete(order_id: uuid.UUID, body: CompletionIn | None = None, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    o = S.order_action(ctx.session, ctx.p, order_id, version, "complete", body.model_dump() if body else {})
    return ok(ctx, S.describe_order(ctx.session, o), 200, o.version)


@router.post("/sale-orders/{order_id}/cancellation", tags=["Reservations"], summary="Cancel a sale order (frees the vehicle)")
def cancel_order(order_id: uuid.UUID, body: ReasonIn, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
    o = S.order_action(ctx.session, ctx.p, order_id, version, "cancel", {"reason": body.reason})
    return ok(ctx, S.describe_order(ctx.session, o), 200, o.version)


# ------------------------------------------------------------------ test drives
@router.get("/appointment-resources", tags=["Test Drives"], summary="Bookable staff, bays and plates")
def resources(ctx: Ctx = Depends(get_ctx)):
    return {"items": [row_dict(r) for r in ctx.session.execute(select(AppointmentResource).order_by(AppointmentResource.name)).scalars()]}


@router.post("/test-drive-appointments", tags=["Test Drives"], status_code=201, summary="Request (and optionally confirm) a test drive",
             description="Timestamps must carry a UTC offset. Confirmation enforces vehicle exclusivity (GiST exclusion) and "
                         "resource capacity (row lock + half-open peak check).")
def create_drive(body: TestDriveCreate, ctx: Ctx = Depends(get_ctx), key: str | None = Depends(idempotency_key)):
    if (replay := ctx.idempotency_begin(key, body.model_dump(mode="json"))):
        return replay
    a = T.request_test_drive(ctx.session, ctx.p, body.model_dump(), key)
    return ok(ctx, T.describe_drive(a), 201, a.version)


@router.get("/test-drive-appointments", tags=["Test Drives"], response_model=Page, summary="List appointments")
def list_drives(organisation_id: uuid.UUID | None = None, vehicle_id: uuid.UUID | None = None, status: str | None = None,
                limit: int = Query(50, ge=1, le=200), cursor: str | None = None, ctx: Ctx = Depends(get_ctx)):
    stmt = select(TestDriveAppointment)
    if organisation_id:
        stmt = stmt.where(TestDriveAppointment.organisation_id == organisation_id)
    if vehicle_id:
        stmt = stmt.where(TestDriveAppointment.vehicle_id == vehicle_id)
    if status:
        stmt = stmt.where(TestDriveAppointment.confirmation_status == status)
    rows, nxt = keyset_page(ctx.session, stmt, TestDriveAppointment.starts_at, TestDriveAppointment.id, limit=limit, cursor=cursor, parse=parse_dt)
    return {"items": [T.describe_drive(r[0]) for r in rows], "next_cursor": nxt}


@router.get("/test-drive-appointments/{appointment_id}", tags=["Test Drives"], summary="Test-drive appointment")
def get_drive(appointment_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    a = get_or_404(ctx.session, TestDriveAppointment, appointment_id, label="test drive")
    return JSONResponse(jsonable(T.describe_drive(a)), headers=etag(a.version))


@router.get("/rental-assets/{asset_id}", tags=["Rentals"], summary="Rental asset with maintenance blocks and active assignments")
def get_asset(asset_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    from app.models import MaintenanceBlock, RentalAssetAssignment
    a = get_or_404(ctx.session, RentalAsset, asset_id, label="rental asset")
    d = row_dict(a)
    d["maintenance_blocks"] = [row_dict(m) for m in ctx.session.execute(select(MaintenanceBlock).where(
        MaintenanceBlock.rental_asset_id == a.id).order_by(MaintenanceBlock.starts_at)).scalars()]
    d["active_assignments"] = [row_dict(x) for x in ctx.session.execute(select(RentalAssetAssignment).where(
        RentalAssetAssignment.rental_asset_id == a.id, RentalAssetAssignment.status == "active")).scalars()]
    return JSONResponse(jsonable(d), headers=etag(a.version))


def _drive_action(action):
    def handler(appointment_id: uuid.UUID, body: ReasonIn | None = None, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
        a = T.drive_action(ctx.session, ctx.p, appointment_id, version, action, body.reason if body else None)
        return ok(ctx, T.describe_drive(a), 200, a.version)
    return handler


for _a, _p in (("confirm", "confirmation"), ("decline", "decline"), ("cancel", "cancellation"), ("complete", "completion"), ("no_show", "no-show")):
    router.add_api_route(f"/test-drive-appointments/{{appointment_id}}/{_p}", _drive_action(_a), methods=["POST"],
                         tags=["Test Drives"], summary=f"Test drive: {_a.replace('_', ' ')}")


# ------------------------------------------------------------------ rentals
@router.get("/rental-categories", tags=["Rentals"], summary="Rental categories")
def rental_categories(ctx: Ctx = Depends(get_ctx)):
    return {"items": [row_dict(c) for c in ctx.session.execute(select(RentalCategory).order_by(RentalCategory.code)).scalars()]}


@router.get("/rental-assets", tags=["Rentals"], summary="Rental fleet (exact vehicles)")
def rental_assets(ctx: Ctx = Depends(get_ctx)):
    return {"items": [row_dict(a) for a in ctx.session.execute(select(RentalAsset).order_by(RentalAsset.fleet_number)).scalars()]}


@router.get("/rental-availability", tags=["Rentals"], summary="Peak demand vs available vehicles for a window")
def rental_availability(location_id: uuid.UUID, category_id: uuid.UUID, pickup_at: dt.datetime, return_at: dt.datetime,
                        ctx: Ctx = Depends(get_ctx)):
    T._require_aware(pickup_at, return_at)
    return T.availability(ctx.session, location_id, category_id, pickup_at, return_at)


@router.post("/rental-quotes", tags=["Rentals"], status_code=201, summary="Immutable rental price quote")
def rental_quote(body: RentalQuoteCreate, ctx: Ctx = Depends(get_ctx)):
    q = T.quote_rental(ctx.session, ctx.p, body.model_dump())
    return ok(ctx, row_dict(q), 201)


@router.post("/rental-bookings", tags=["Rentals"], status_code=201, summary="Book a rental category (capacity-controlled)",
             description="Locks the (location, category) inventory bucket and checks peak demand including turnaround buffers. "
                         "Optionally assigns an exact asset (overlaps rejected by exclusion constraint).")
def create_booking(body: RentalBookingCreate, ctx: Ctx = Depends(get_ctx), key: str | None = Depends(idempotency_key)):
    if (replay := ctx.idempotency_begin(key, body.model_dump(mode="json"))):
        return replay
    b = T.create_booking(ctx.session, ctx.p, body.model_dump(exclude_unset=True), key)
    return ok(ctx, T.describe_booking(ctx.session, b), 201, b.version)


@router.get("/rental-bookings", tags=["Rentals"], response_model=Page, summary="List rental bookings")
def list_bookings(status: str | None = None, limit: int = Query(50, ge=1, le=200), cursor: str | None = None, ctx: Ctx = Depends(get_ctx)):
    stmt = select(RentalBooking)
    if status:
        stmt = stmt.where(RentalBooking.status == status)
    rows, nxt = keyset_page(ctx.session, stmt, RentalBooking.pickup_at, RentalBooking.id, limit=limit, cursor=cursor, parse=parse_dt)
    return {"items": [T.describe_booking(ctx.session, r[0]) for r in rows], "next_cursor": nxt}


@router.get("/rental-bookings/{booking_id}", tags=["Rentals"], summary="Booking detail with assignments and local times")
def get_booking(booking_id: uuid.UUID, ctx: Ctx = Depends(get_ctx)):
    b = get_or_404(ctx.session, RentalBooking, booking_id, label="rental booking")
    return JSONResponse(jsonable(T.describe_booking(ctx.session, b)), headers=etag(b.version))


@router.post("/rental-bookings/{booking_id}/assignment", tags=["Rentals"], status_code=201, summary="Assign an exact vehicle")
def assign(booking_id: uuid.UUID, body: AssignmentIn, ctx: Ctx = Depends(get_ctx)):
    x = T.assign_asset(ctx.session, ctx.p, booking_id, body.rental_asset_id, is_upgrade=body.is_upgrade)
    return ok(ctx, row_dict(x), 201)


def _booking_action(action):
    def handler(booking_id: uuid.UUID, body: ReasonIn | None = None, version: int | None = Depends(if_match), ctx: Ctx = Depends(get_ctx)):
        b = T.booking_action(ctx.session, ctx.p, booking_id, version, action, body.reason if body else None)
        return ok(ctx, T.describe_booking(ctx.session, b), 200, b.version)
    return handler


for _a, _p in (("cancel", "cancellation"), ("check_out", "check-out"), ("return", "return"), ("no_show", "no-show")):
    router.add_api_route(f"/rental-bookings/{{booking_id}}/{_p}", _booking_action(_a), methods=["POST"], tags=["Rentals"],
                         summary=f"Rental booking: {_a.replace('_', ' ')}")


@router.post("/maintenance-blocks", tags=["Rentals"], status_code=201, summary="Block an asset for maintenance",
             description="Rejected if it overlaps an active assignment or would leave fewer vehicles than committed bookings.")
def maintenance(body: MaintenanceCreate, ctx: Ctx = Depends(get_ctx)):
    m = T.create_maintenance(ctx.session, ctx.p, body.model_dump())
    return ok(ctx, row_dict(m), 201)
