"""Request-scoped dependencies: request id, principal, unit of work, idempotency, If-Match."""
from __future__ import annotations

import hashlib
import json
import uuid
from typing import Iterator

from fastapi import Depends, Header, Request
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.db import new_session
from app.errors import IdempotencyMismatch, PreconditionRequired, Unauthenticated, ValidationFailed
from app.security import Principal, decode_token, load_principal
from app.services.common import jsonable


def request_id(request: Request) -> str:
    return request.state.request_id


def get_principal(request: Request, authorization: str | None = Header(default=None),
                  x_organisation_id: uuid.UUID | None = Header(default=None, description="Act within one organisation")) -> Principal:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise Unauthenticated("Authorization: Bearer <token> required")
    user_id = decode_token(authorization.split(" ", 1)[1].strip())
    s = new_session()
    try:
        p = load_principal(s, user_id, acting_org_id=x_organisation_id, request_id=request.state.request_id)
    finally:
        s.close()
    request.state.principal = p
    return p


class Ctx:
    """Unit of work for one request. Write endpoints call commit() explicitly
    so that commit-time (deferred) constraint failures become API errors."""

    def __init__(self, session: Session, principal: Principal, request: Request):
        self.session = session
        self.p = principal
        self.request = request
        self._idem_row = None

    def commit(self) -> None:
        self.session.commit()

    # ---- generic Idempotency-Key handling --------------------------------
    def idempotency_begin(self, key: str | None, body: dict | None) -> JSONResponse | None:
        if key is None:
            return None
        if not (8 <= len(key) <= 200):
            raise ValidationFailed("Idempotency-Key must be 8-200 characters", code="invalid_idempotency_key")
        scope = f"user:{self.p.user_id}"
        digest = hashlib.sha256(json.dumps({"m": self.request.method, "p": self.request.url.path, "b": jsonable(body)},
                                           sort_keys=True).encode()).hexdigest()
        # A concurrent duplicate blocks here on the unique index until the first commits.
        row = self.session.execute(text("""
            INSERT INTO idempotency_keys (scope, key, method, path, request_sha256)
            VALUES (:s, :k, :m, :p, :h) ON CONFLICT (scope, key) DO NOTHING RETURNING id"""),
            {"s": scope, "k": key, "m": self.request.method, "p": self.request.url.path, "h": digest}).first()
        if row:
            self._idem_row = row[0]
            return None
        existing = self.session.execute(text("SELECT id, request_sha256, response_status, response_body FROM idempotency_keys "
                                             "WHERE scope = :s AND key = :k"), {"s": scope, "k": key}).mappings().one()
        if existing["request_sha256"] != digest:
            raise IdempotencyMismatch()
        if existing["response_status"] is not None:
            return JSONResponse(existing["response_body"], status_code=existing["response_status"],
                                headers={"Idempotent-Replayed": "true"})
        self._idem_row = existing["id"]
        return None

    def idempotency_finish(self, status: int, body) -> None:
        if self._idem_row is not None:
            self.session.execute(text("UPDATE idempotency_keys SET response_status = :st, response_body = CAST(:b AS jsonb), "
                                      "completed_at = now() WHERE id = :id"),
                                 {"st": status, "b": json.dumps(jsonable(body)), "id": self._idem_row})


def get_ctx(request: Request, principal: Principal = Depends(get_principal)) -> Iterator[Ctx]:
    session = new_session()
    session.info["db_ctx"] = principal.db_context()
    try:
        yield Ctx(session, principal, request)
    finally:
        session.rollback()
        session.close()


def if_match(if_match: str | None = Header(default=None, alias="If-Match",
                                           description="Current record version, e.g. \"3\" (from ETag/version)")) -> int | None:
    if if_match is None:
        return None
    try:
        return int(if_match.strip().removeprefix("W/").strip('"'))
    except ValueError as e:
        raise PreconditionRequired("If-Match must be the integer version, e.g. \"3\"") from e


def idempotency_key(idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")) -> str | None:
    return idempotency_key


def etag(version: int) -> dict:
    return {"ETag": f'"{version}"'}
