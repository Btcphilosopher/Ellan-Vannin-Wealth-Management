"""S3-compatible object storage (MinIO in Docker Compose) with a local
filesystem fallback for tests and single-machine demos."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

from app.config import get_settings


@dataclass
class StoredObject:
    bucket: str
    key: str
    sha256: str
    size: int


class LocalStorage:
    def __init__(self, root: str, bucket: str):
        self.root = Path(root)
        self.bucket = bucket

    def put(self, key: str, data: bytes, content_type: str) -> StoredObject:
        path = self.root / self.bucket / key
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return StoredObject(self.bucket, key, hashlib.sha256(data).hexdigest(), len(data))

    def get(self, key: str) -> bytes:
        return (self.root / self.bucket / key).read_bytes()


class S3Storage:
    def __init__(self):
        import boto3
        s = get_settings()
        self.bucket = s.s3_bucket
        self.client = boto3.client("s3", endpoint_url=s.s3_endpoint_url, region_name=s.s3_region,
                                   aws_access_key_id=s.s3_access_key, aws_secret_access_key=s.s3_secret_key)
        try:
            self.client.head_bucket(Bucket=self.bucket)
        except Exception:  # noqa: BLE001 - create on first use in dev
            self.client.create_bucket(Bucket=self.bucket)

    def put(self, key: str, data: bytes, content_type: str) -> StoredObject:
        digest = hashlib.sha256(data).hexdigest()
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type,
                               Metadata={"sha256": digest})
        return StoredObject(self.bucket, key, digest, len(data))

    def get(self, key: str) -> bytes:
        return self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read()


_storage = None


def get_storage():
    global _storage
    if _storage is None:
        s = get_settings()
        _storage = S3Storage() if s.storage_backend == "s3" else LocalStorage(s.local_storage_dir, s.s3_bucket)
    return _storage
