"""Payments, provider events, refunds and reconciliation.

Rules:
* Payment intents are created idempotently per (organisation, Idempotency-Key)
  and are durable BEFORE the provider is called; a provider timeout leaves
  the intent in status 'unknown' for the reconciliation worker.
* Provider events are verified (HMAC), stored once per provider event id,
  and applied under a row lock with final-state and timestamp precedence,
  so duplicates and out-of-order deliveries cannot regress state.
* A settled payment never advances a reservation or sale by itself. A
  deposit that settles after its hold lapsed opens a reconciliation case;
  the vehicle (possibly reserved by someone else) is never touched.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import uuid

from sqlalchemy import func, select, text
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app import simulator
from app.db import DbContext, apply_context, elevated
from app.errors import Conflict, DomainError, Forbidden, IdempotencyMismatch, NotFound, Unauthenticated, ValidationFailed
from app.models import (Organisation, PaymentEvent, PaymentIntent, PaymentTransaction, ReconciliationCase, Refund,
                        RentalBooking, SaleOrder, SaleReservation)
from app.security import Principal
from app.services.common import audit, check_version, ctx_of, emit, get_or_404, jsonable, row_dict, sha256_json

FINAL = {"succeeded", "failed", "canceled"}
EVENT_STATUS = {"payment.processing": "processing", "payment.requires_action": "requires_action",
                "payment.succeeded": "succeeded", "payment.failed": "failed", "payment.canceled": "canceled"}


# ----------------------------------------------------------------------------- cases
def open_case(session: Session, org_id, case_type: str, summary: str, *, severity: str = "medium", details: dict | None = None,
              **links) -> ReconciliationCase:
    if links.get("payment_intent_id"):
        existing = session.execute(select(ReconciliationCase).where(
            ReconciliationCase.case_type == case_type, ReconciliationCase.payment_intent_id == links["payment_intent_id"],
            ReconciliationCase.status.notin_(["resolved", "written_off"]))).scalar_one_or_none()
        if existing:
            return existing
    c = ReconciliationCase(organisation_id=org_id, case_type=case_type, summary=summary, severity=severity,
                           details=jsonable(details or {}), **links)
    session.add(c)
    session.flush()
    audit(session, "reconciliation.opened", "reconciliation_case", c.id, org_id, changes={"case_type": case_type, "summary": summary})
    emit(session, "reconciliation.opened", "reconciliation_case", c.id, org_id, {"case_id": c.id, "case_type": case_type})
    return c


def resolve_case(session: Session, p: Principal, case_id, expected_version, resolution: str, note: str | None,
                 status: str = "resolved") -> ReconciliationCase:
    c = get_or_404(session, ReconciliationCase, case_id, lock=True, label="reconciliation case")
    p.require("reconciliation.manage", c.organisation_id)
    check_version(c, expected_version)
    if c.status in ("resolved", "written_off"):
        raise Conflict("case already closed", code="case_closed")
    if resolution == "refunded":
        ok = c.refund_id and session.get(Refund, c.refund_id).status == "succeeded"
        if not ok:
            raise ValidationFailed("a 'refunded' resolution requires a linked succeeded refund", code="refund_not_settled")
    c.status, c.resolution, c.resolution_note = status, resolution, note
    c.resolved_at, c.resolved_by = func.now(), p.user_id
    session.flush()
    audit(session, f"reconciliation.{status}", "reconciliation_case", c.id, c.organisation_id,
          changes={"resolution": resolution, "note": note})
    return c


# ----------------------------------------------------------------------------- intents
def _resolve_target(session: Session, purpose: str, data: dict):
    if purpose == "sale_deposit":
        r = get_or_404(session, SaleReservation, data.get("sale_reservation_id"), label="sale reservation")
        return r.organisation_id, r.customer_id, r.deposit_required_minor, r.currency, r
    if purpose == "sale_balance":
        o = get_or_404(session, SaleOrder, data.get("sale_order_id"), label="sale order")
        from app.services.sales import describe_order
        outstanding = describe_order(session, o)["balance_outstanding_minor"]
        if outstanding <= 0:
            raise Conflict("nothing is outstanding on this sale order", code="nothing_outstanding")
        return o.organisation_id, o.customer_id, outstanding, o.currency, o
    if purpose == "rental_prepayment":
        b = get_or_404(session, RentalBooking, data.get("rental_booking_id"), label="rental booking")
        return b.organisation_id, b.customer_id, b.total_minor, b.currency, b
    raise ValidationFailed("unknown purpose", code="invalid_value")


def create_payment(session: Session, p: Principal, data: dict, idempotency_key: str | None) -> tuple[PaymentIntent, bool]:
    """Returns (intent, replayed)."""
    if not idempotency_key:
        raise ValidationFailed("Idempotency-Key header is required for payments", code="idempotency_key_required")
    purpose = data["purpose"]
    org_id, customer_id, expected, currency, target = _resolve_target(session, purpose, data)
    if p.is_customer:
        if customer_id != p.customer_id:
            raise Forbidden("not your reservation/booking")
    else:
        # Finance can take any payment; sales staff can take deposits; rental staff can take prepayments.
        alt = {"sale_deposit": "reservations.create", "sale_balance": "sales.manage", "rental_prepayment": "rentals.book"}[purpose]
        if not (p.can("payments.create", org_id) or p.can(alt, org_id)):
            raise Forbidden(f"missing permission payments.create or {alt}", code="permission_denied")
    amount = data.get("amount_minor") or expected
    if amount is None:
        raise ValidationFailed("amount_minor is required", code="missing_value")
    if data.get("currency") and data["currency"] != currency:
        raise ValidationFailed(f"currency must be {currency}", code="currency_mismatch")
    req_hash = sha256_json({"purpose": purpose, "target": str(target.id), "amount": amount, "currency": currency})
    with elevated(session, ctx_of(session).scoped_to([org_id])):
        existing = session.execute(select(PaymentIntent).where(PaymentIntent.organisation_id == org_id,
                                                               PaymentIntent.idempotency_key == idempotency_key)).scalar_one_or_none()
        if existing:
            if existing.request_sha256 != req_hash:
                raise IdempotencyMismatch()
            return existing, True
        if purpose == "sale_balance" and amount > expected:
            raise ValidationFailed(f"amount exceeds the outstanding balance {expected}", code="amount_exceeds_balance")
        if purpose == "sale_deposit":
            now = session.execute(select(func.now())).scalar_one()
            if target.status != "held" or target.hold_expires_at <= now:
                raise DomainError("the hold is no longer active; a deposit cannot be taken", code="hold_expired", status=409)
            if target.deposit_status != "awaiting":
                raise Conflict(f"deposit is {target.deposit_status}", code="deposit_not_due")
            if amount != expected:
                raise ValidationFailed(f"deposit amount must be exactly {expected}", code="amount_mismatch")
        intent = PaymentIntent(id=uuid.uuid4(), organisation_id=org_id, provider=simulator.PROVIDER, purpose=purpose,
                               sale_reservation_id=data.get("sale_reservation_id") if purpose == "sale_deposit" else None,
                               sale_order_id=data.get("sale_order_id") if purpose == "sale_balance" else None,
                               rental_booking_id=data.get("rental_booking_id") if purpose == "rental_prepayment" else None,
                               customer_id=customer_id, amount_minor=amount, currency=currency,
                               idempotency_key=idempotency_key, request_sha256=req_hash, created_by=p.user_id)
        session.add(intent)
        try:
            session.flush()
        except IntegrityError:
            session.rollback()  # concurrent duplicate won the race: replay it
            apply_context(session, ctx_of(session).scoped_to([org_id]))
            again = session.execute(select(PaymentIntent).where(PaymentIntent.organisation_id == org_id,
                                                                PaymentIntent.idempotency_key == idempotency_key)).scalar_one()
            if again.request_sha256 != req_hash:
                raise IdempotencyMismatch()
            return again, True
        audit(session, "payment.intent_created", "payment_intent", intent.id, org_id,
              changes={"purpose": purpose, "amount_minor": amount, "currency": currency})
        emit(session, "payment.intent_created", "payment_intent", intent.id, org_id, {"payment_intent_id": intent.id})
    session.commit()  # durable before any provider side effect
    _call_provider(session, intent.id, org_id, simulate_timeout=bool(data.get("simulate_provider_timeout")))
    return session.get(PaymentIntent, intent.id), False


def _call_provider(session: Session, intent_id, org_id, *, simulate_timeout: bool = False) -> None:
    ctx = ctx_of(session)
    apply_context(session, ctx.scoped_to([org_id]))
    intent = session.get(PaymentIntent, intent_id)
    try:
        res = simulator.create_payment(session, merchant_ref=str(intent.id), amount_minor=intent.amount_minor,
                                       currency=intent.currency, idempotency_key=str(intent.id), simulate_timeout=simulate_timeout)
        intent.provider_intent_ref, intent.status = res["ref"], "processing"
    except simulator.ProviderTimeout:
        intent.status = "unknown"
        audit(session, "payment.outcome_unknown", "payment_intent", intent.id, org_id, changes={"reason": "provider_timeout"})
    session.flush()
    session.commit()
    apply_context(session, ctx)


# ----------------------------------------------------------------------------- events
def handle_provider_event(session: Session, provider: str, body: bytes, signature: str | None, *,
                          request_id: str | None = None, trusted_source: str | None = None) -> dict:
    if provider != simulator.PROVIDER:
        raise NotFound(f"unknown provider {provider}")
    if trusted_source is None and not simulator.verify(body, signature):
        raise Unauthenticated("signature verification failed", code="invalid_signature")
    try:
        ev = json.loads(body)
        event_id, event_type, created = ev["id"], ev["type"], dt.datetime.fromisoformat(ev["created"])
        data = ev["data"]
    except (ValueError, KeyError, TypeError) as e:
        raise ValidationFailed("malformed provider event", code="malformed_event") from e
    apply_context(session, DbContext.system(request_id, actor_kind="provider"))
    safe_payload = {k: v for k, v in ev.items() if k not in ("card", "payment_method")}
    new_id = session.execute(insert(PaymentEvent).values(
        provider=provider, provider_event_id=event_id, event_type=event_type, provider_created_at=created,
        signature_verified=True, payload=safe_payload, payload_sha256=hashlib.sha256(body).hexdigest())
        .on_conflict_do_nothing(index_elements=["provider", "provider_event_id"]).returning(PaymentEvent.id)).scalar()
    if new_id is None:
        # Not re-applied; recorded so the payment's history shows the redelivery.
        prior = session.execute(select(PaymentEvent).where(PaymentEvent.provider == provider,
                                                           PaymentEvent.provider_event_id == event_id)).scalar_one()
        audit(session, "payment.duplicate_event_ignored", "payment_intent", prior.payment_intent_id or prior.id, prior.organisation_id,
              metadata={"provider_event_id": event_id, "event_type": event_type,
                        "differs_from_stored": hashlib.sha256(body).hexdigest() != prior.payload_sha256})
        session.commit()
        return {"result": "duplicate", "provider_event_id": event_id}
    pe = session.get(PaymentEvent, new_id)
    if event_type.startswith("payment."):
        _apply_payment_event(session, pe, event_type, data, created)
    elif event_type.startswith("refund."):
        _apply_refund_event(session, pe, event_type, data)
    else:
        pe.processing_status, pe.processing_note = "ignored_no_effect", "unhandled event type"
    pe.processed_at = func.now()
    session.flush()
    result = {"result": pe.processing_status, "provider_event_id": event_id, "note": pe.processing_note}
    session.commit()
    return result


def _apply_payment_event(session: Session, pe: PaymentEvent, event_type: str, data: dict, created: dt.datetime) -> None:
    new_status = EVENT_STATUS.get(event_type)
    intent = None
    if data.get("payment_ref"):
        intent = session.execute(select(PaymentIntent).where(PaymentIntent.provider == pe.provider,
                                                             PaymentIntent.provider_intent_ref == data["payment_ref"])
                                 .with_for_update()).scalar_one_or_none()
    if intent is None and data.get("merchant_ref"):
        try:
            intent = session.execute(select(PaymentIntent).where(PaymentIntent.id == uuid.UUID(data["merchant_ref"]))
                                     .with_for_update()).scalar_one_or_none()
        except ValueError:
            intent = None
    if intent is None or new_status is None:
        pe.processing_status, pe.processing_note = "unmatched", "no payment intent for this provider reference"
        return
    pe.payment_intent_id, pe.organisation_id = intent.id, intent.organisation_id
    if intent.provider_intent_ref is None and data.get("payment_ref"):
        intent.provider_intent_ref = data["payment_ref"]

    if intent.status in FINAL:
        if new_status == intent.status:
            pe.processing_status, pe.processing_note = "ignored_no_effect", f"intent already {intent.status}"
        elif new_status == "succeeded":
            pe.processing_status, pe.processing_note = "applied", "capture reported for a non-successful intent"
            _record_capture(session, intent, pe, data)
            open_case(session, intent.organisation_id, "amount_mismatch",
                      f"Provider reported capture on an intent that was {intent.status}.", severity="high",
                      payment_intent_id=intent.id, observed_amount_minor=data.get("amount_minor"), currency=intent.currency,
                      payment_event_id=pe.id)
        else:
            pe.processing_status, pe.processing_note = "ignored_out_of_order", f"{event_type} after final status {intent.status}"
        return
    if new_status not in FINAL and intent.last_provider_event_at and created < intent.last_provider_event_at:
        pe.processing_status, pe.processing_note = "ignored_out_of_order", "older than the last applied event"
        return

    previous = intent.status
    intent.status = new_status
    intent.last_provider_event_at = max(created, intent.last_provider_event_at or created)
    if new_status == "failed":
        intent.failure_code = data.get("failure_code", "provider_declined")
    session.flush()
    pe.processing_status = "applied"
    audit(session, f"payment.{new_status}", "payment_intent", intent.id, intent.organisation_id,
          changes={"status": {"from": previous, "to": new_status}}, metadata={"provider_event_id": pe.provider_event_id})
    emit(session, f"payment.{new_status}", "payment_intent", intent.id, intent.organisation_id,
         {"payment_intent_id": intent.id, "purpose": intent.purpose})
    if new_status == "succeeded":
        tx = _record_capture(session, intent, pe, data)
        observed = data.get("amount_minor")
        if observed != intent.amount_minor:
            open_case(session, intent.organisation_id, "amount_mismatch",
                      f"Captured {observed} but expected {intent.amount_minor}.", payment_intent_id=intent.id,
                      payment_transaction_id=tx.id if tx else None, expected_amount_minor=intent.amount_minor,
                      observed_amount_minor=observed, currency=intent.currency, severity="high")
        if intent.purpose == "sale_deposit":
            _apply_deposit(session, intent, pe, observed)


def _record_capture(session: Session, intent: PaymentIntent, pe: PaymentEvent, data: dict):
    ref = data.get("transaction_ref") or f"{data.get('payment_ref')}:capture"
    tid = session.execute(insert(PaymentTransaction).values(
        organisation_id=intent.organisation_id, payment_intent_id=intent.id, kind="capture",
        amount_minor=data.get("amount_minor") or intent.amount_minor, currency=intent.currency, provider=pe.provider,
        provider_transaction_ref=ref, source_event_id=pe.id, occurred_at=pe.provider_created_at)
        .on_conflict_do_nothing(index_elements=["provider", "provider_transaction_ref"]).returning(PaymentTransaction.id)).scalar()
    return session.get(PaymentTransaction, tid) if tid else None


def _apply_deposit(session: Session, intent: PaymentIntent, pe: PaymentEvent, observed: int | None) -> None:
    r = session.get(SaleReservation, intent.sale_reservation_id)
    session.execute(text("SELECT 1 FROM vehicles WHERE id = :v FOR NO KEY UPDATE"), {"v": r.vehicle_id})  # same lock order
    session.refresh(r, with_for_update=True)
    now = session.execute(select(func.now())).scalar_one()
    from app.services.sales import _expire_inline
    _expire_inline(session, r)
    if r.status == "held" and r.deposit_status == "awaiting" and observed == r.deposit_required_minor:
        org = session.get(Organisation, r.organisation_id)
        r.deposit_status, r.deposit_paid_at = "paid", now
        r.hold_expires_at = max(r.hold_expires_at, now + org.deposit_hold_extension)
        session.flush()
        emit(session, "sale_reservation.deposit_received", "sale_reservation", r.id, r.organisation_id,
             {"reservation_id": r.id, "hold_expires_at": r.hold_expires_at})
        pe.processing_note = "deposit recorded; reservation still awaits dealer acceptance"
        return
    holder = session.execute(text("""SELECT r.reservation_number, r.customer_id = :c AS same_customer
                                       FROM vehicle_current_reservations c JOIN sale_reservations r ON r.id = c.sale_reservation_id
                                      WHERE c.vehicle_id = :v"""), {"v": r.vehicle_id, "c": r.customer_id}).mappings().first()
    case = open_case(session, r.organisation_id,
                     "payment_after_hold_expiry" if r.status in ("expired", "cancelled", "released", "declined") else "amount_mismatch",
                     f"Deposit settled while reservation {r.reservation_number} was {r.status}. "
                     + ("Vehicle is now committed to another reservation; it was not reassigned." if holder and not holder["same_customer"]
                        else "Vehicle was not re-reserved automatically."),
                     severity="high", payment_intent_id=intent.id, sale_reservation_id=r.id,
                     expected_amount_minor=r.deposit_required_minor, observed_amount_minor=observed, currency=r.currency,
                     details={"reservation_status": r.status, "current_holder": holder["reservation_number"] if holder else None,
                              "recommended_action": "refund the deposit or re-reserve if the vehicle is free"})
    pe.processing_note = f"late/mismatched deposit -> {case.case_number}"


def _apply_refund_event(session: Session, pe: PaymentEvent, event_type: str, data: dict) -> None:
    ref = session.execute(select(Refund).where(Refund.provider == pe.provider, Refund.provider_refund_ref == data.get("refund_ref"))
                          .with_for_update()).scalar_one_or_none()
    if ref is None:
        pe.processing_status, pe.processing_note = "unmatched", "no refund for this provider reference"
        return
    pe.refund_id, pe.organisation_id, pe.payment_intent_id = ref.id, ref.organisation_id, ref.payment_intent_id
    if ref.status in ("succeeded", "failed", "canceled"):
        pe.processing_status, pe.processing_note = "ignored_no_effect", f"refund already {ref.status}"
        return
    outcome = event_type.split(".", 1)[1]
    if outcome not in ("succeeded", "failed"):
        pe.processing_status = "ignored_no_effect"
        return
    ref.status = outcome
    session.flush()
    pe.processing_status = "applied"
    intent = session.get(PaymentIntent, ref.payment_intent_id)
    if outcome == "succeeded":
        session.execute(insert(PaymentTransaction).values(
            organisation_id=ref.organisation_id, payment_intent_id=ref.payment_intent_id, kind="refund",
            amount_minor=ref.amount_minor, currency=ref.currency, provider=pe.provider,
            provider_transaction_ref=data.get("transaction_ref") or f"{ref.provider_refund_ref}:refund",
            refund_id=ref.id, source_event_id=pe.id, occurred_at=pe.provider_created_at)
            .on_conflict_do_nothing(index_elements=["provider", "provider_transaction_ref"]))
        captured, refunded = session.execute(text("""
            SELECT COALESCE(sum(amount_minor) FILTER (WHERE kind='capture'),0), COALESCE(sum(amount_minor) FILTER (WHERE kind='refund'),0)
              FROM payment_transactions WHERE payment_intent_id = :i"""), {"i": ref.payment_intent_id}).one()
        if intent.sale_reservation_id and refunded >= captured:
            r = session.get(SaleReservation, intent.sale_reservation_id)
            if r.deposit_status in ("paid", "refund_pending", "awaiting") and r.deposit_required_minor:
                r.deposit_status = "refunded"
        if ref.reconciliation_case_id:
            case = session.get(ReconciliationCase, ref.reconciliation_case_id)
            if case.status not in ("resolved", "written_off") and refunded >= (case.observed_amount_minor or captured):
                case.status, case.resolution = "resolved", "refunded"
                case.resolution_note = f"Auto-resolved: refund {ref.provider_refund_ref} settled ({refunded} of {captured} refunded)."
                case.resolved_at = func.now()
                audit(session, "reconciliation.resolved", "reconciliation_case", case.id, case.organisation_id,
                      changes={"resolution": "refunded", "refund_id": ref.id})
    else:
        ref.failure_code = data.get("failure_code", "provider_failed")
        if ref.reconciliation_case_id:
            case = session.get(ReconciliationCase, ref.reconciliation_case_id)
            case.status = "investigating"
            case.resolution_note = "refund failed at provider; retry or escalate"
    session.flush()
    audit(session, f"refund.{outcome}", "refund", ref.id, ref.organisation_id, changes={"status": outcome})
    emit(session, f"refund.{outcome}", "refund", ref.id, ref.organisation_id, {"refund_id": ref.id})


# ----------------------------------------------------------------------------- refunds
def request_refund(session: Session, p: Principal, data: dict, idempotency_key: str | None) -> tuple[Refund, bool]:
    if not idempotency_key:
        raise ValidationFailed("Idempotency-Key header is required for refunds", code="idempotency_key_required")
    intent = get_or_404(session, PaymentIntent, data["payment_intent_id"], label="payment intent")
    p.require("refunds.request", intent.organisation_id)
    existing = session.execute(select(Refund).where(Refund.organisation_id == intent.organisation_id,
                                                    Refund.idempotency_key == idempotency_key)).scalar_one_or_none()
    if existing:
        if existing.payment_intent_id != intent.id or (data.get("amount_minor") and existing.amount_minor != data["amount_minor"]):
            raise IdempotencyMismatch()
        return existing, True
    capture = session.execute(select(PaymentTransaction).where(PaymentTransaction.payment_intent_id == intent.id,
                                                               PaymentTransaction.kind == "capture")
                              .order_by(PaymentTransaction.occurred_at)).scalars().first()
    if capture is None:
        raise Conflict("nothing has been captured on this payment", code="nothing_to_refund")
    amount = data.get("amount_minor")
    if amount is None:
        committed = session.execute(text("SELECT COALESCE(sum(amount_minor),0) FROM refunds WHERE capture_transaction_id = :c "
                                         "AND status IN ('requested','pending','succeeded')"), {"c": capture.id}).scalar()
        amount = capture.amount_minor - int(committed)
    case_id = data.get("reconciliation_case_id")
    ref = Refund(id=uuid.uuid4(), organisation_id=intent.organisation_id, payment_intent_id=intent.id,
                 capture_transaction_id=capture.id, amount_minor=amount, currency=intent.currency,
                 reason=data.get("reason", "customer_request"), provider=intent.provider, reconciliation_case_id=case_id,
                 idempotency_key=idempotency_key, requested_by=p.user_id)
    session.add(ref)
    session.flush()  # refund-limit trigger runs here under a lock on the capture
    if case_id:
        case = get_or_404(session, ReconciliationCase, case_id, label="reconciliation case")
        case.refund_id, case.status = ref.id, "awaiting_provider"
    audit(session, "refund.requested", "refund", ref.id, ref.organisation_id,
          changes={"amount_minor": amount, "reason": ref.reason, "payment_intent_id": intent.id})
    emit(session, "refund.requested", "refund", ref.id, ref.organisation_id, {"refund_id": ref.id})
    session.commit()
    ctx = ctx_of(session)
    pr = simulator.create_refund(session, payment_ref=intent.provider_intent_ref, amount_minor=amount, idempotency_key=str(ref.id))
    ref = session.get(Refund, ref.id)
    ref.provider_refund_ref, ref.status = pr["ref"], "pending"
    session.flush()
    session.commit()
    apply_context(session, ctx)
    return session.get(Refund, ref.id), False


# ----------------------------------------------------------------------------- worker
def reconcile_unknown(session: Session, *, older_than_seconds: int = 60) -> dict:
    """Resolve intents whose provider outcome is unknown by querying the
    provider, feeding any final status through the normal (deduplicating)
    event path. Intents the provider never received are failed safely."""
    apply_context(session, DbContext.system(actor_kind="system"))
    stats = {"resolved": 0, "failed_not_received": 0, "cases": 0}
    rows = session.execute(select(PaymentIntent).where(
        PaymentIntent.status.in_(["unknown", "created"]),
        PaymentIntent.updated_at < func.now() - dt.timedelta(seconds=older_than_seconds))).scalars().all()
    for intent in rows:
        prov = simulator.find_payment_by_key(session, str(intent.id))
        if prov is None:
            age = session.execute(select(func.now() - PaymentIntent.created_at).where(PaymentIntent.id == intent.id)).scalar_one()
            if age > dt.timedelta(minutes=10):
                intent.status, intent.failure_code = "failed", "not_received_by_provider"
                stats["failed_not_received"] += 1
            else:
                open_case(session, intent.organisation_id, "unknown_payment_outcome",
                          "Provider has no record yet; will retry.", payment_intent_id=intent.id, severity="low")
                stats["cases"] += 1
            continue
        if intent.provider_intent_ref is None:
            intent.provider_intent_ref = prov["ref"]
        if intent.status in ("unknown", "created"):
            intent.status = "processing"
        session.flush()
        if prov["status"] in FINAL:
            ev = {"id": f"poll:{prov['ref']}:{prov['status']}", "type": f"payment.{prov['status']}",
                  "created": prov["updated_at"].isoformat(),
                  "data": {"payment_ref": prov["ref"], "merchant_ref": prov["merchant_ref"], "amount_minor": prov["captured_minor"] or prov["amount_minor"],
                           "currency": prov["currency"], "transaction_ref": f"{prov['ref']}:capture"}}
            session.commit()
            handle_provider_event(session, simulator.PROVIDER, json.dumps(ev).encode(), None, trusted_source="provider_api_poll")
            apply_context(session, DbContext.system(actor_kind="system"))
        stats["resolved"] += 1
        case = session.execute(select(ReconciliationCase).where(
            ReconciliationCase.case_type == "unknown_payment_outcome", ReconciliationCase.payment_intent_id == intent.id,
            ReconciliationCase.status.notin_(["resolved", "written_off"]))).scalar_one_or_none()
        if case:
            case.status, case.resolution, case.resolved_at = "resolved", "provider_confirmed", func.now()
            case.resolution_note = f"provider reports {prov['status']}"
    session.commit()
    return stats


def describe_intent(session: Session, i: PaymentIntent) -> dict:
    d = row_dict(i)
    d["transactions"] = [row_dict(t) for t in session.execute(select(PaymentTransaction).where(PaymentTransaction.payment_intent_id == i.id)
                                                              .order_by(PaymentTransaction.occurred_at)).scalars()]
    d["events"] = [row_dict(e, exclude=["payload"]) for e in session.execute(select(PaymentEvent).where(PaymentEvent.payment_intent_id == i.id)
                                                                             .order_by(PaymentEvent.received_at)).scalars()]
    d["refunds"] = [row_dict(r) for r in session.execute(select(Refund).where(Refund.payment_intent_id == i.id)).scalars()]
    d["cases"] = [row_dict(c) for c in session.execute(select(ReconciliationCase).where(ReconciliationCase.payment_intent_id == i.id)).scalars()]
    return d
