"""Outbox publication, worker heartbeats, customers, reports."""
from __future__ import annotations

import datetime as dt
import json
import logging
import random
import uuid
from typing import Callable

from sqlalchemy import func, or_, select, text
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import DbContext, apply_context
from app.errors import Conflict, Forbidden, ValidationFailed
from app.models import Customer, CustomerAddress, OutboxEvent
from app.security import Principal
from app.services.common import audit, check_version, diff, emit, get_or_404, jsonable, keyset_page, parse_dt, row_dict

log = logging.getLogger("autos.outbox")


# ============================================================================ outbox
class PublishError(Exception):
    pass


def log_sink(event: dict) -> None:
    if event["payload"].get("_simulate_publish_failure"):
        raise PublishError("simulated downstream failure")
    log.info("outbox publish %s %s", event["event_type"], event["id"])


def webhook_sink(url: str) -> Callable[[dict], None]:
    import httpx

    def _send(event: dict) -> None:
        r = httpx.post(url, json=event, headers={"Idempotency-Key": event["id"]}, timeout=5)
        if r.status_code >= 300:
            raise PublishError(f"HTTP {r.status_code}")
    return _send


def backoff_seconds(attempts: int) -> float:
    """Exponential backoff with full jitter, capped at one hour."""
    return random.uniform(0, min(3600, 2 ** attempts))


def dispatch_outbox(session: Session, sink: Callable[[dict], None] | None = None, batch: int = 100) -> dict:
    """Publish pending events. Rows are claimed with FOR UPDATE SKIP LOCKED so
    several workers can run safely; each event is delivered at-least-once
    and carries its id as the consumer's idempotency key."""
    apply_context(session, DbContext.system(actor_kind="system"))
    s = get_settings()
    sink = sink or (webhook_sink(s.webhook_sink_url) if s.webhook_sink_url else log_sink)
    rows = session.execute(select(OutboxEvent).where(OutboxEvent.status == "pending", OutboxEvent.available_at <= func.now())
                           .order_by(OutboxEvent.available_at).limit(batch).with_for_update(skip_locked=True)).scalars().all()
    stats = {"published": 0, "retried": 0, "dead": 0}
    for ev in rows:
        envelope = {"id": str(ev.id), "event_type": ev.event_type, "aggregate_type": ev.aggregate_type,
                    "aggregate_id": str(ev.aggregate_id), "organisation_id": str(ev.organisation_id) if ev.organisation_id else None,
                    "occurred_at": ev.created_at.isoformat(), "payload": ev.payload}
        try:
            sink(envelope)
            ev.status, ev.published_at, ev.last_error = "published", func.now(), None
            ev.attempts += 1
            stats["published"] += 1
        except Exception as e:  # noqa: BLE001
            ev.attempts += 1
            ev.last_error = f"{type(e).__name__}: {e}"[:500]
            if ev.attempts >= ev.max_attempts:
                ev.status = "dead"
                stats["dead"] += 1
            else:
                ev.available_at = func.now() + dt.timedelta(seconds=backoff_seconds(ev.attempts))
                stats["retried"] += 1
    session.commit()
    return stats


def requeue_dead(session: Session, p: Principal, event_id) -> OutboxEvent:
    ev = get_or_404(session, OutboxEvent, event_id, lock=True, label="outbox event")
    p.require("outbox.manage", ev.organisation_id)
    if ev.status != "dead":
        raise Conflict("only dead-lettered events can be requeued", code="invalid_status_transition")
    ev.status, ev.attempts, ev.available_at = "pending", 0, func.now()
    session.flush()
    audit(session, "outbox.requeued", "outbox_event", ev.id, ev.organisation_id, changes={"last_error": ev.last_error})
    return ev


def heartbeat(session: Session, name: str, details: dict) -> None:
    session.execute(text("""INSERT INTO worker_heartbeats (worker_name, last_beat_at, details) VALUES (:n, now(), CAST(:d AS jsonb))
                            ON CONFLICT (worker_name) DO UPDATE SET last_beat_at = now(), details = EXCLUDED.details"""),
                    {"n": name, "d": json.dumps(jsonable(details))})


# ============================================================================ customers
CUSTOMER_FIELDS = {"customer_type", "given_name", "family_name", "business_name", "display_name", "email", "phone", "marketing_consent"}


def describe_customer(session: Session, c: Customer, p: Principal | None = None) -> dict:
    d = row_dict(c)
    d["addresses"] = [row_dict(a) for a in session.execute(select(CustomerAddress).where(
        CustomerAddress.customer_id == c.id, CustomerAddress.valid_to.is_(None))).scalars()]
    d["relationships"] = [dict(r) for r in session.execute(text("""
        SELECT r.organisation_id::text, o.display_name, r.basis, r.first_interaction_at
          FROM customer_relationships r JOIN organisations o ON o.id = r.organisation_id WHERE r.customer_id = :c"""),
        {"c": c.id}).mappings()]
    d["relationships"] = jsonable(d["relationships"])
    return d


def create_customer(session: Session, p: Principal, data: dict) -> Customer:
    org_id = p.single_org_with("customers.write", data.get("organisation_id"))
    unknown = set(data) - CUSTOMER_FIELDS - {"organisation_id", "address"}
    if unknown:
        raise ValidationFailed(f"unknown fields {sorted(unknown)}")
    c = Customer(id=uuid.uuid4(), created_by_organisation_id=org_id, **{k: v for k, v in data.items() if k in CUSTOMER_FIELDS})
    session.add(c)
    session.flush()
    session.execute(text("INSERT INTO customer_relationships (customer_id, organisation_id, basis) VALUES (:c, :o, 'manual') ON CONFLICT DO NOTHING"),
                    {"c": c.id, "o": org_id})
    if data.get("address"):
        a = data["address"]
        session.add(CustomerAddress(customer_id=c.id, kind=a.get("kind", "home"), line1=a["line1"], line2=a.get("line2"),
                                    city=a["city"], region=a.get("region"), postal_code=a.get("postal_code"),
                                    country_code=a["country_code"]))
    session.flush()
    audit(session, "customer.created", "customer", c.id, org_id, changes={"display_name": c.display_name})
    return c


def update_customer(session: Session, p: Principal, customer_id, expected_version, patch: dict) -> Customer:
    c = get_or_404(session, Customer, customer_id, lock=True, label="customer")
    if not (p.is_customer and p.customer_id == c.id):
        if not any(p.can("customers.write", o) for o in p.org_ids) and not p.is_platform:
            raise Forbidden("missing permission customers.write")
    check_version(c, expected_version)
    if c.status == "erased":
        raise Conflict("customer has been erased", code="customer_erased")
    bad = set(patch) - CUSTOMER_FIELDS
    if bad:
        raise ValidationFailed(f"fields not editable: {sorted(bad)}", code="field_not_editable")
    before = row_dict(c)
    for k, v in patch.items():
        setattr(c, k, v)
    session.flush()
    audit(session, "customer.updated", "customer", c.id, c.created_by_organisation_id, changes=diff(before, row_dict(c)))
    return c


def erase_customer(session: Session, p: Principal, customer_id, expected_version) -> Customer:
    """Right-to-erasure: anonymise PII; keep the row so commercial history stays intact."""
    c = get_or_404(session, Customer, customer_id, lock=True, label="customer")
    p.require("customers.erase", None)
    check_version(c, expected_version)
    c.given_name = c.family_name = c.email = c.phone = None
    c.business_name = None
    c.display_name = f"Erased customer {str(c.id)[:8]}"
    c.marketing_consent = None
    c.status, c.erased_at = "erased", func.now()
    session.execute(text("""UPDATE customer_addresses SET line1 = '[erased]', line2 = NULL, postal_code = NULL, geog = NULL,
                            valid_to = COALESCE(valid_to, now()) WHERE customer_id = :c"""), {"c": c.id})
    session.execute(text("DELETE FROM saved_searches WHERE customer_id = :c"), {"c": c.id})
    session.execute(text("DELETE FROM saved_vehicles WHERE customer_id = :c"), {"c": c.id})
    session.flush()
    audit(session, "customer.erased", "customer", c.id, None, changes={"status": "erased"})
    return c


def list_customers(session: Session, q: str | None, limit: int, cursor: str | None):
    stmt = select(Customer)
    if q:
        stmt = stmt.where(or_(Customer.display_name.ilike(f"%{q}%"), Customer.email.ilike(f"%{q}%")))
    rows, nxt = keyset_page(session, stmt, Customer.created_at, Customer.id, limit=limit, cursor=cursor, parse=parse_dt)
    return [row_dict(r[0]) for r in rows], nxt


# ============================================================================ reports
def reports(session: Session, name: str, organisation_id=None) -> dict:
    org_filter = "AND organisation_id = :org" if organisation_id else ""
    params = {"org": organisation_id} if organisation_id else {}
    q = lambda sql: [jsonable(dict(r)) for r in session.execute(text(sql), params).mappings()]  # noqa: E731
    if name == "inventory":
        return {"by_status": q(f"""SELECT o.display_name AS seller, l.status, l.freshness_state, count(*) AS listings,
                                          sum(p.amount_minor) AS total_asking_minor, min(l.currency) AS currency
                                     FROM listings l JOIN organisations o ON o.id = l.organisation_id
                                     LEFT JOIN listing_price_versions p ON p.id = l.current_price_version_id
                                    WHERE true {org_filter.replace('organisation_id', 'l.organisation_id')}
                                    GROUP BY 1, 2, 3 ORDER BY 1, 2, 3"""),
                "vehicle_availability": q(f"""SELECT availability_status, count(*) AS vehicles FROM vehicles
                                               WHERE archived_at IS NULL {org_filter.replace('organisation_id', 'custodian_organisation_id')}
                                               GROUP BY 1 ORDER BY 1""")}
    if name == "reservations":
        return {"funnel": q(f"""SELECT status, deposit_status, count(*) AS reservations,
                                       count(*) FILTER (WHERE status = 'held' AND hold_expires_at <= now()) AS lapsed_not_yet_swept
                                  FROM sale_reservations WHERE true {org_filter} GROUP BY 1, 2 ORDER BY 1, 2"""),
                "orders": q(f"SELECT status, count(*) AS orders, sum(agreed_total_minor) AS agreed_minor FROM sale_orders WHERE true {org_filter} GROUP BY 1")}
    if name == "payments":
        return {"intents": q(f"SELECT purpose, status, count(*) AS n, sum(amount_minor) AS amount_minor FROM payment_intents WHERE true {org_filter} GROUP BY 1, 2 ORDER BY 1, 2"),
                "transactions": q(f"SELECT kind, currency, count(*) AS n, sum(amount_minor) AS amount_minor FROM payment_transactions WHERE true {org_filter} GROUP BY 1, 2"),
                "refunds": q(f"SELECT status, count(*) AS n, sum(amount_minor) AS amount_minor FROM refunds WHERE true {org_filter} GROUP BY 1"),
                "reconciliation": q(f"SELECT case_type, status, count(*) AS n FROM reconciliation_cases WHERE true {org_filter} GROUP BY 1, 2 ORDER BY 1, 2")}
    if name == "rentals":
        return {"bookings": q(f"SELECT status, count(*) AS n, sum(total_minor) AS revenue_minor FROM rental_bookings WHERE true {org_filter} GROUP BY 1"),
                "utilisation_next_30d": q(f"""
                    SELECT c.code AS category, count(DISTINCT a.id) AS assets,
                           round(100.0 * COALESCE(sum(extract(epoch FROM upper(x.occupied * tstzrange(now(), now() + interval '30 days'))
                                                              - lower(x.occupied * tstzrange(now(), now() + interval '30 days')))), 0)
                                 / NULLIF(count(DISTINCT a.id) * 30 * 86400, 0), 1) AS assigned_pct
                      FROM rental_assets a JOIN rental_categories c ON c.id = a.category_id
                      LEFT JOIN rental_asset_assignments x ON x.rental_asset_id = a.id AND x.status = 'active'
                                 AND x.occupied && tstzrange(now(), now() + interval '30 days')
                     WHERE a.status = 'active' {org_filter.replace('organisation_id', 'a.organisation_id')}
                     GROUP BY 1 ORDER BY 1"""),
                "maintenance": q(f"SELECT kind, status, count(*) AS n FROM maintenance_blocks WHERE true {org_filter} GROUP BY 1, 2")}
    if name == "imports":
        return {"jobs": q(f"""SELECT status, mode, count(*) AS jobs, sum(row_count) AS rows, sum(invalid_count) AS invalid_rows,
                                     sum(applied_count) AS applied_rows FROM import_jobs WHERE true {org_filter} GROUP BY 1, 2"""),
                "top_findings": q(f"""SELECT f->>'code' AS code, f->>'severity' AS severity, count(*) AS n
                                        FROM import_rows r, jsonb_array_elements(r.findings) f WHERE true {org_filter.replace('organisation_id', 'r.organisation_id')}
                                       GROUP BY 1, 2 ORDER BY 3 DESC LIMIT 20""")}
    if name == "data-quality":
        return {"checks": q(f"""
            SELECT 'published_without_vin' AS check, count(*) AS n FROM listings l
             WHERE l.status = 'published' {org_filter.replace('organisation_id', 'l.organisation_id')}
               AND NOT EXISTS (SELECT 1 FROM vehicle_identifiers i WHERE i.vehicle_id = l.vehicle_id AND i.namespace = 'vin' AND i.retired_at IS NULL)
            UNION ALL SELECT 'odometer_unknown', count(*) FROM vehicles WHERE odometer_value IS NULL AND archived_at IS NULL {org_filter.replace('organisation_id', 'custodian_organisation_id')}
            UNION ALL SELECT 'trim_unmatched', count(*) FROM vehicles WHERE trim_id IS NULL AND archived_at IS NULL {org_filter.replace('organisation_id', 'custodian_organisation_id')}
            UNION ALL SELECT 'stale_published_listings', count(*) FROM listings WHERE status = 'published' AND freshness_state IN ('stale','expired') {org_filter}
            UNION ALL SELECT 'pending_merge_proposals', count(*) FROM vehicle_merge_proposals WHERE status = 'pending' {org_filter}
            UNION ALL SELECT 'open_reconciliation_cases', count(*) FROM reconciliation_cases WHERE status NOT IN ('resolved','written_off') {org_filter}
            UNION ALL SELECT 'dead_letter_events', count(*) FROM outbox_events WHERE status = 'dead' {org_filter}
            UNION ALL SELECT 'disputed_odometer_claims', count(*) FROM vehicle_attribute_assertions WHERE attribute = 'odometer' AND verification_status = 'disputed' {org_filter}""")}
    if name == "overview":
        return {"counts": q(f"""
            SELECT 'published_listings' AS metric, count(*) AS value FROM listings WHERE status = 'published' {org_filter}
            UNION ALL SELECT 'active_holds', count(*) FROM sale_reservations WHERE status = 'held' AND hold_expires_at > now() {org_filter}
            UNION ALL SELECT 'dealer_accepted', count(*) FROM sale_reservations WHERE status = 'dealer_accepted' {org_filter}
            UNION ALL SELECT 'open_sale_orders', count(*) FROM sale_orders WHERE status NOT IN ('completed','cancelled') {org_filter}
            UNION ALL SELECT 'confirmed_test_drives_next_7d', count(*) FROM test_drive_appointments WHERE confirmation_status = 'confirmed' AND starts_at BETWEEN now() AND now() + interval '7 days' {org_filter}
            UNION ALL SELECT 'active_rental_bookings', count(*) FROM rental_bookings WHERE status IN ('confirmed','checked_out') {org_filter}
            UNION ALL SELECT 'open_reconciliation_cases', count(*) FROM reconciliation_cases WHERE status NOT IN ('resolved','written_off') {org_filter}
            UNION ALL SELECT 'imports_awaiting_approval', count(*) FROM import_jobs WHERE status = 'validated' {org_filter}
            UNION ALL SELECT 'outbox_pending', count(*) FROM outbox_events WHERE status = 'pending' {org_filter}
            UNION ALL SELECT 'outbox_dead', count(*) FROM outbox_events WHERE status = 'dead' {org_filter}"""),
                "workers": q("SELECT worker_name, last_beat_at, now() - last_beat_at < interval '2 minutes' AS healthy, details FROM worker_heartbeats ORDER BY 1")}
    raise ValidationFailed(f"unknown report {name}", code="unknown_report")
