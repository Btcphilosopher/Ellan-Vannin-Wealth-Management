"""Cross-cutting helpers used by every domain service."""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import json
import re
import uuid
from decimal import Decimal
from typing import Any, Iterable

from sqlalchemy import and_, or_, select, text
from sqlalchemy.orm import Session

from app.db import DbContext
from app.errors import NotFound, ValidationFailed, VersionConflict
from app.models import AuditEvent, OutboxEvent

SENSITIVE_KEY = re.compile(r"(password|secret|token|signature|authorization|card|cvc|cvv|pan|iban|email|phone|"
                           r"date_of_birth|given_name|family_name|line1|line2|postal_code)", re.I)


def ctx_of(session: Session) -> DbContext:
    return session.info.get("db_ctx") or DbContext()


def jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        return value
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, (dt.datetime, dt.date)):
        return value.isoformat()
    if isinstance(value, dt.timedelta):
        return int(value.total_seconds())
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, dict):
        return {k: jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [jsonable(v) for v in value]
    if hasattr(value, "lower") and hasattr(value, "upper") and hasattr(value, "bounds"):  # psycopg Range
        return {"lower": jsonable(value.lower), "upper": jsonable(value.upper), "bounds": value.bounds}
    return str(value)


def row_dict(obj: Any, exclude: Iterable[str] = ()) -> dict:
    """Serialise an ORM row (skipping geography blobs, which callers render as lat/lon)."""
    out = {}
    skip = set(exclude) | {"geog"}
    for col in obj.__table__.columns:
        if col.name in skip:
            continue
        attr = "metadata_" if col.name == "metadata" else col.name
        out[col.name] = jsonable(getattr(obj, attr))
    return out


def redact(data: Any) -> Any:
    if isinstance(data, dict):
        return {k: ("[redacted]" if SENSITIVE_KEY.search(k) else redact(v)) for k, v in data.items()}
    if isinstance(data, list):
        return [redact(v) for v in data]
    return data


def diff(before: dict, after: dict) -> dict:
    keys = sorted(set(before) | set(after))
    return {k: {"from": before.get(k), "to": after.get(k)} for k in keys if before.get(k) != after.get(k)}


def audit(session: Session, action: str, target_type: str, target_id: Any, organisation_id: uuid.UUID | None,
          changes: dict | None = None, metadata: dict | None = None) -> None:
    ctx = ctx_of(session)
    kind = ctx.actor_kind if ctx.actor_kind in ("user", "system", "provider", "import") else "unknown"
    session.add(AuditEvent(
        request_id=ctx.request_id, actor_user_id=ctx.user_id, actor_kind=kind,
        actor_organisation_id=ctx.org_ids[0] if len(ctx.org_ids) == 1 else None,
        organisation_id=organisation_id, action=action, target_type=target_type, target_id=str(target_id),
        changes=jsonable(redact(changes or {})), metadata_=jsonable(redact(metadata or {})),
    ))


def emit(session: Session, event_type: str, aggregate_type: str, aggregate_id: uuid.UUID,
         organisation_id: uuid.UUID | None, payload: dict) -> None:
    """Transactional outbox: committed atomically with the domain change."""
    from app.config import get_settings
    session.add(OutboxEvent(
        organisation_id=organisation_id, aggregate_type=aggregate_type, aggregate_id=aggregate_id,
        event_type=event_type, payload=jsonable(redact(payload)), request_id=ctx_of(session).request_id,
        max_attempts=get_settings().outbox_max_attempts,
    ))


def get_or_404(session: Session, model, obj_id, *, lock: bool = False, label: str | None = None):
    stmt = select(model).where(model.id == obj_id)
    if lock:
        stmt = stmt.with_for_update()
    obj = session.execute(stmt).scalar_one_or_none()
    if obj is None:
        raise NotFound(f"{label or model.__tablename__} {obj_id} not found or not visible to you")
    return obj


def check_version(obj, expected: int | None) -> None:
    from app.errors import PreconditionRequired
    if expected is None:
        raise PreconditionRequired()
    if obj.version != expected:
        raise VersionConflict(f"expected version {expected}, current version is {obj.version}",
                              extra={"current_version": obj.version})


def versioned_update(session: Session, model, obj_id, expected_version: int, values: dict) -> Any:
    """UPDATE ... WHERE id = :id AND version = :v — atomic optimistic concurrency."""
    from sqlalchemy import update
    res = session.execute(update(model).where(model.id == obj_id, model.version == expected_version)
                          .values(**values).returning(model.version))
    row = res.first()
    if row is None:
        current = session.execute(select(model.version).where(model.id == obj_id)).scalar_one_or_none()
        if current is None:
            raise NotFound(f"{model.__tablename__} {obj_id} not found")
        raise VersionConflict(f"expected version {expected_version}, current version is {current}",
                              extra={"current_version": current})
    session.expire_all()
    return row[0]


# ---- keyset pagination -------------------------------------------------------
def encode_cursor(values: list) -> str:
    return base64.urlsafe_b64encode(json.dumps(jsonable(values)).encode()).decode().rstrip("=")


def decode_cursor(cursor: str) -> list:
    try:
        pad = "=" * (-len(cursor) % 4)
        return json.loads(base64.urlsafe_b64decode(cursor + pad))
    except Exception as e:  # noqa: BLE001
        raise ValidationFailed("invalid cursor", code="invalid_cursor") from e


def keyset_page(session: Session, stmt, sort_col, id_col, *, limit: int, cursor: str | None, descending: bool = True,
                parse=lambda v: v, order_expr=None):
    """Keyset pagination on (sort_col, id). order_expr lets a caller order by an
    equivalent but non-indexable expression (planner hint, see listings.search)."""
    limit = max(1, min(limit, 200))
    if cursor:
        sort_val, id_val = decode_cursor(cursor)
        sort_val = parse(sort_val)
        if descending:
            stmt = stmt.where(or_(sort_col < sort_val, and_(sort_col == sort_val, id_col < uuid.UUID(id_val))))
        else:
            stmt = stmt.where(or_(sort_col > sort_val, and_(sort_col == sort_val, id_col > uuid.UUID(id_val))))
    ob = order_expr if order_expr is not None else sort_col
    order = (ob.desc(), id_col.desc()) if descending else (ob.asc(), id_col.asc())
    rows = session.execute(stmt.order_by(*order).limit(limit + 1)).all()
    has_more = len(rows) > limit
    rows = rows[:limit]
    next_cursor = None
    if has_more and rows:
        last = rows[-1]
        obj = last[0]
        next_cursor = encode_cursor([getattr(obj, sort_col.key), str(getattr(obj, id_col.key))])
    return rows, next_cursor


def parse_dt(v):
    return dt.datetime.fromisoformat(v) if isinstance(v, str) else v


# ---- spreadsheet-formula injection protection ------------------------------
FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r", "\n", "|", "%")


def csv_safe(value: Any) -> str:
    """Neutralise spreadsheet formulas (OWASP CSV injection guidance): text
    starting with = + - @ tab CR LF | % is prefixed with an apostrophe."""
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, Decimal)):
        return str(value)
    s = str(jsonable(value))
    if s.startswith(FORMULA_PREFIXES):
        return "'" + s
    return s


def sha256_json(obj: Any) -> str:
    return hashlib.sha256(json.dumps(jsonable(obj), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def location_point(session: Session, location_id) -> dict | None:
    r = session.execute(text("SELECT ST_Y(geog::geometry) AS lat, ST_X(geog::geometry) AS lon FROM locations WHERE id = :id"),
                        {"id": location_id}).first()
    return {"lat": r.lat, "lon": r.lon} if r else None
