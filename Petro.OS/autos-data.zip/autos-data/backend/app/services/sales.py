"""Sale reservations, sale orders, handover.

Locking discipline (same everywhere, same as the DB triggers):
    1. lock vehicles row (FOR NO KEY UPDATE: serialises writers, compatible with FK key-share locks)
    2. lock sale_reservations / sale_orders row
Hold expiry is evaluated against the database clock at the moment of use.
"""
from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from app.db import elevated
from app.errors import Conflict, Forbidden, NotFound, ValidationFailed
from app.models import (HandoverRecord, Listing, Organisation, PaymentIntent, PaymentTransaction, Quote, SaleOrder,
                        SaleReservation, SaleStatusEvent, Vehicle)
from app.money import Money
from app.security import Principal
from app.services.common import (audit, check_version, ctx_of, emit, get_or_404, jsonable, keyset_page, parse_dt,
                                 row_dict)
from app.services.quotes import ensure_relationship

TERMINAL = {"expired", "cancelled", "declined", "released"}


def lock_vehicle(session: Session, vehicle_id) -> None:
    session.execute(text("SELECT 1 FROM vehicles WHERE id = :v FOR NO KEY UPDATE"), {"v": vehicle_id})


def describe(session: Session, r: SaleReservation) -> dict:
    d = row_dict(r)
    now = session.execute(select(func.now())).scalar_one()
    d["effective_status"] = "expired" if (r.status == "held" and r.hold_expires_at <= now) else r.status
    d["seconds_remaining"] = max(0, int((r.hold_expires_at - now).total_seconds())) if r.status == "held" else None
    d["deposit"] = Money(r.deposit_required_minor, r.currency).as_dict()
    d["events"] = [row_dict(e) for e in session.execute(select(SaleStatusEvent).where(
        SaleStatusEvent.sale_reservation_id == r.id).order_by(SaleStatusEvent.occurred_at)).scalars()]
    order = session.execute(select(SaleOrder).where(SaleOrder.sale_reservation_id == r.id)).scalar_one_or_none()
    d["sale_order"] = describe_order(session, order) if order else None
    d["payments"] = [row_dict(x) for x in session.execute(select(PaymentIntent).where(PaymentIntent.sale_reservation_id == r.id)).scalars()]
    return d


def describe_order(session: Session, o: SaleOrder) -> dict:
    d = row_dict(o)
    d["handovers"] = [row_dict(h) for h in session.execute(select(HandoverRecord).where(HandoverRecord.sale_order_id == o.id)).scalars()]
    paid = session.execute(text("""
        SELECT COALESCE(sum(CASE WHEN t.kind = 'capture' THEN t.amount_minor ELSE -t.amount_minor END), 0)
          FROM payment_transactions t JOIN payment_intents i ON i.id = t.payment_intent_id
         WHERE i.sale_order_id = :o OR i.sale_reservation_id = :r"""), {"o": o.id, "r": o.sale_reservation_id}).scalar()
    d["net_received_minor"] = int(paid)
    d["balance_outstanding_minor"] = o.agreed_total_minor - int(paid)
    return d


def create_reservation(session: Session, p: Principal, data: dict, idempotency_key: str | None) -> SaleReservation:
    listing = get_or_404(session, Listing, data["listing_id"], label="listing")
    customer_id = data.get("customer_id")
    if p.is_customer:
        if customer_id and customer_id != p.customer_id:
            raise Forbidden("customers can only reserve for themselves")
        customer_id = p.customer_id
    else:
        p.require("reservations.create", listing.organisation_id)
    if not customer_id:
        raise ValidationFailed("customer_id is required", code="missing_value")
    quote_id = data.get("quote_id")
    with elevated(session, ctx_of(session).scoped_to([listing.organisation_id])):
        if quote_id:
            q = get_or_404(session, Quote, quote_id, label="quote")
            if q.listing_id != listing.id or q.customer_id != customer_id:
                raise ValidationFailed("quote does not belong to this listing and customer", code="invalid_reference")
        if idempotency_key:
            existing = session.execute(select(SaleReservation).where(
                SaleReservation.organisation_id == listing.organisation_id,
                SaleReservation.idempotency_key == idempotency_key)).scalar_one_or_none()
            if existing:
                if existing.listing_id != listing.id or existing.customer_id != customer_id:
                    from app.errors import IdempotencyMismatch
                    raise IdempotencyMismatch()
                return existing
        org = session.get(Organisation, listing.organisation_id)
        now = session.execute(select(func.now())).scalar_one()
        deposit = listing.deposit_required_minor
        r = SaleReservation(id=uuid.uuid4(), organisation_id=listing.organisation_id, listing_id=listing.id,
                            vehicle_id=listing.vehicle_id, customer_id=customer_id, quote_id=quote_id,
                            deposit_required_minor=deposit, deposit_status="awaiting" if deposit else "not_required",
                            currency=listing.currency, hold_expires_at=now + org.sale_hold_duration,
                            idempotency_key=idempotency_key, created_by=p.user_id)
        session.add(r)
        session.flush()  # triggers: lock vehicle, expire lapsed hold, enforce single commitment
        ensure_relationship(session, customer_id, listing.organisation_id, "sale_reservation")
        audit(session, "sale_reservation.held", "sale_reservation", r.id, r.organisation_id,
              changes={"vehicle_id": r.vehicle_id, "listing_id": r.listing_id, "hold_expires_at": r.hold_expires_at})
        emit(session, "sale_reservation.held", "sale_reservation", r.id, r.organisation_id,
             {"reservation_id": r.id, "vehicle_id": r.vehicle_id, "hold_expires_at": r.hold_expires_at})
    return r


def _load_locked(session: Session, reservation_id) -> SaleReservation:
    r = get_or_404(session, SaleReservation, reservation_id, label="sale reservation")
    lock_vehicle(session, r.vehicle_id)
    session.refresh(r, with_for_update=True)
    return r


def _expire_inline(session: Session, r: SaleReservation) -> bool:
    now = session.execute(select(func.now())).scalar_one()
    if r.status == "held" and r.hold_expires_at <= now:
        r.status, r.end_reason = "expired", "hold_expired"
        session.flush()
        _after_expiry(session, r)
        return True
    return False


def _after_expiry(session: Session, r: SaleReservation) -> None:
    audit(session, "sale_reservation.expired", "sale_reservation", r.id, r.organisation_id, changes={"status": "expired"})
    emit(session, "sale_reservation.expired", "sale_reservation", r.id, r.organisation_id,
         {"reservation_id": r.id, "vehicle_id": r.vehicle_id})
    if r.deposit_status == "paid":
        from app.services.payments import open_case
        intent = session.execute(select(PaymentIntent).where(PaymentIntent.sale_reservation_id == r.id,
                                                             PaymentIntent.status == "succeeded")).scalars().first()
        open_case(session, r.organisation_id, "deposit_on_lapsed_hold", "Deposit was paid but the hold lapsed without dealer acceptance; refund or re-reserve.",
                  payment_intent_id=intent.id if intent else None, sale_reservation_id=r.id,
                  expected_amount_minor=r.deposit_required_minor, currency=r.currency, severity="high")


def accept(session: Session, p: Principal, reservation_id, expected_version: int | None) -> SaleReservation:
    r = _load_locked(session, reservation_id)
    p.require("reservations.manage", r.organisation_id)
    if _expire_inline(session, r):
        session.commit()  # persist the expiry we just discovered, then report it
        from app.errors import DomainError
        raise DomainError("the hold lapsed before dealer acceptance", code="hold_expired", status=409)
    check_version(r, expected_version)
    if r.status != "held":
        raise Conflict(f"reservation is {r.status}", code="invalid_status_transition")
    if r.deposit_status == "awaiting":
        raise Conflict("deposit has not been received; acceptance requires a settled deposit", code="deposit_outstanding")
    r.status, r.accepted_by = "dealer_accepted", p.user_id
    session.flush()
    audit(session, "sale_reservation.dealer_accepted", "sale_reservation", r.id, r.organisation_id, changes={"status": "dealer_accepted"})
    emit(session, "sale_reservation.dealer_accepted", "sale_reservation", r.id, r.organisation_id, {"reservation_id": r.id})
    return r


def end(session: Session, p: Principal, reservation_id, expected_version, status: str, reason: str) -> SaleReservation:
    r0 = get_or_404(session, SaleReservation, reservation_id, label="sale reservation")
    if p.is_customer:
        if r0.customer_id != p.customer_id or status != "cancelled":
            raise Forbidden("customers may only cancel their own reservation")
    else:
        p.require("reservations.manage", r0.organisation_id)
    # Customer-initiated actions run in the seller's tenant scope once authorised,
    # so the vehicle row lock is real (RLS would otherwise hide it from FOR UPDATE).
    with elevated(session, ctx_of(session).scoped_to([r0.organisation_id])):
        r = _load_locked(session, reservation_id)
        if not p.is_customer:
            check_version(r, expected_version)
        if _expire_inline(session, r):
            return r
        if r.status not in ("held", "dealer_accepted"):
            raise Conflict(f"reservation is {r.status}", code="invalid_status_transition")
        r.status, r.end_reason = status, reason
        session.flush()
        if r.deposit_status == "paid":
            r.deposit_status = "refund_pending"
            session.flush()
        audit(session, f"sale_reservation.{status}", "sale_reservation", r.id, r.organisation_id, changes={"status": status, "reason": reason})
        emit(session, f"sale_reservation.{status}", "sale_reservation", r.id, r.organisation_id,
             {"reservation_id": r.id, "deposit_refund_due": r.deposit_status == "refund_pending"})
    return r


def expire_due(session: Session, limit: int = 200) -> int:
    """Background sweep. Uses SKIP LOCKED so it never blocks request traffic;
    correctness does not depend on it (requests expire lapsed holds inline)."""
    rows = session.execute(text("""SELECT id, vehicle_id FROM sale_reservations
                                    WHERE status = 'held' AND hold_expires_at <= now()
                                    ORDER BY hold_expires_at LIMIT :n"""), {"n": limit}).all()
    n = 0
    for rid, vid in rows:
        got = session.execute(text("SELECT 1 FROM vehicles WHERE id = :v FOR NO KEY UPDATE SKIP LOCKED"), {"v": vid}).first()
        if not got:
            continue
        r = session.execute(select(SaleReservation).where(SaleReservation.id == rid).with_for_update()).scalar_one()
        session.refresh(r)
        if _expire_inline(session, r):
            n += 1
    return n


def convert_to_order(session: Session, p: Principal, reservation_id, expected_version, agreed_total_minor: int | None) -> SaleOrder:
    r = _load_locked(session, reservation_id)
    p.require("sales.manage" if not p.can("reservations.manage", r.organisation_id) else "reservations.manage", r.organisation_id)
    check_version(r, expected_version)
    if r.status != "dealer_accepted":
        raise Conflict("only dealer-accepted reservations can become sale orders", code="invalid_status_transition")
    total = agreed_total_minor
    if total is None and r.quote_id:
        q = session.get(Quote, r.quote_id)
        if q.total_minor is None:
            raise ValidationFailed("the linked quote is incomplete; provide agreed_total_minor", code="quote_incomplete")
        total = q.total_minor
    if total is None:
        raise ValidationFailed("agreed_total_minor is required when no complete quote is linked", code="missing_value")
    o = SaleOrder(id=uuid.uuid4(), organisation_id=r.organisation_id, sale_reservation_id=r.id, vehicle_id=r.vehicle_id,
                  customer_id=r.customer_id, quote_id=r.quote_id, currency=r.currency, agreed_total_minor=total, created_by=p.user_id)
    session.add(o)
    session.flush()
    audit(session, "sale_order.created", "sale_order", o.id, o.organisation_id, changes={"agreed_total_minor": total})
    emit(session, "sale_order.created", "sale_order", o.id, o.organisation_id, {"sale_order_id": o.id, "reservation_id": r.id})
    return o


def order_action(session: Session, p: Principal, order_id, expected_version, action: str, data: dict) -> SaleOrder:
    o = get_or_404(session, SaleOrder, order_id, label="sale order")
    p.require("sales.manage" if action != "cancel" else "reservations.manage", o.organisation_id)
    lock_vehicle(session, o.vehicle_id)
    session.refresh(o, with_for_update=True)
    check_version(o, expected_version)
    if action == "sign_agreement":
        o.status = "agreement_signed"
        o.agreement_media_id = data.get("agreement_media_id")
    elif action == "handover":
        if o.status != "agreement_signed":
            raise Conflict("agreement must be signed before handover", code="invalid_status_transition")
        session.add(HandoverRecord(sale_order_id=o.id, organisation_id=o.organisation_id, location_id=data["location_id"],
                                   scheduled_for=data.get("scheduled_for"),
                                   handed_over_at=data.get("handed_over_at") or dt.datetime.now(dt.timezone.utc),
                                   odometer_value=data.get("odometer_value"), odometer_unit=data.get("odometer_unit"),
                                   staff_user_id=p.user_id, notes=data.get("notes")))
        session.flush()
        o.status = "handed_over"
    elif action == "complete":
        outstanding = describe_order(session, o)["balance_outstanding_minor"]
        if outstanding > 0:
            if not data.get("accept_outstanding_balance"):
                raise Conflict(f"{outstanding} {o.currency} minor units are still outstanding; take the balance payment or "
                               "complete with accept_outstanding_balance and a reason", code="balance_outstanding",
                               extra={"balance_outstanding_minor": outstanding})
            if not (data.get("reason") or "").strip():
                raise ValidationFailed("a reason is required to complete with an outstanding balance", code="reason_required")
            data = {**data, "outstanding_at_completion_minor": outstanding}
        o.status = "completed"
    elif action == "cancel":
        o.status, o.cancel_reason = "cancelled", data.get("reason") or "cancelled"
    else:
        raise ValidationFailed("unknown action")
    session.flush()
    session.refresh(o)
    audit(session, f"sale_order.{o.status}", "sale_order", o.id, o.organisation_id, changes={"status": o.status, **jsonable(data)})
    emit(session, f"sale_order.{o.status}", "sale_order", o.id, o.organisation_id, {"sale_order_id": o.id, "vehicle_id": o.vehicle_id})
    return o


def list_reservations(session: Session, *, organisation_id, status, customer_id, limit, cursor):
    stmt = select(SaleReservation)
    if organisation_id:
        stmt = stmt.where(SaleReservation.organisation_id == organisation_id)
    if status:
        if status == "expired_effective":
            stmt = stmt.where(SaleReservation.status == "held", SaleReservation.hold_expires_at <= func.now())
        else:
            stmt = stmt.where(SaleReservation.status == status)
    if customer_id:
        stmt = stmt.where(SaleReservation.customer_id == customer_id)
    rows, nxt = keyset_page(session, stmt, SaleReservation.created_at, SaleReservation.id, limit=limit, cursor=cursor, parse=parse_dt)
    return [describe(session, r[0]) for r in rows], nxt
