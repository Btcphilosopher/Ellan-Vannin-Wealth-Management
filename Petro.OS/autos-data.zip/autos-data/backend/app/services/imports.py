"""Inventory imports: upload -> staging -> validation -> preview -> approval -> application -> results.

Behaviour contract (also in docs/IMPORTS.md):
* Idempotent upload: identical bytes for the same (organisation, source) return the existing job.
* Idempotent application: a row whose normalised payload hash equals the mapping's last hash is
  `no_change`; re-applying a file never duplicates vehicles, listings or prices.
* Stale updates: a row whose source_updated_at is older than the last applied update for that
  source record is rejected (`stale_source_update`).
* Blank fields never erase existing data unless the field is listed in options.clear_blank_fields.
* all_or_nothing: approval is refused while any row is invalid; application runs in ONE transaction
  and any failure rolls back every row.  partial_accept: invalid rows are skipped; each valid row is
  applied in its own savepoint and failures are reported per row.
* Matching: source mapping > VIN > dealer stock number. Weak similarity (make/model/year/colour) never
  merges records; it creates a vehicle_merge_proposals row for human review.
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import io
import json
import uuid

from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from app.config import get_settings
from app.errors import Conflict, ValidationFailed
from app.models import (ImportJob, ImportRow, Listing, Location, Organisation, SourceRecordMapping, Vehicle,
                        VehicleAttributeAssertion, VehicleFeature, VehicleIdentifier, VehicleMergeProposal)
from app.money import Money, MoneyError
from app.security import Principal
from app.services.common import audit, check_version, emit, get_or_404, jsonable, row_dict, sha256_json
from app.services.vehicles import normalize_vin, resolve_trim, vin_findings
from app.storage import get_storage

REQUIRED = ["source_record_id", "vin", "price", "currency", "location_code", "source_updated_at"]
OPTIONAL = ["make", "model", "model_year", "trim", "exterior_colour", "interior_colour", "condition", "odometer_value",
            "odometer_unit", "deposit", "availability", "stock_number", "title", "description", "features", "sale_eligibility"]
CLEARABLE = {"exterior_colour", "interior_colour", "odometer_value", "description", "features"}
MAX_PRICE_MINOR = 10_000_000_00


def _finding(sev, field, code, msg):
    return {"severity": sev, "field": field, "code": code, "message": msg}


def parse_file(fmt: str, data: bytes) -> list[dict]:
    if fmt == "csv":
        text_data = data.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text_data))
        if not reader.fieldnames:
            raise ValidationFailed("CSV has no header row", code="invalid_file")
        return [{(k or "").strip(): (v if v is not None else "") for k, v in row.items()} for row in reader]
    if fmt == "json":
        try:
            doc = json.loads(data)
        except json.JSONDecodeError as e:
            raise ValidationFailed(f"invalid JSON: {e}", code="invalid_file") from e
        records = doc.get("records") if isinstance(doc, dict) else doc
        if not isinstance(records, list) or not all(isinstance(r, dict) for r in records):
            raise ValidationFailed("JSON must be an array of objects or {\"records\": [...]}", code="invalid_file")
        return [{k: ("" if v is None else v) for k, v in r.items()} for r in records]
    raise ValidationFailed("format must be csv or json", code="invalid_format")


def upload(session: Session, p: Principal, *, organisation_id, source_namespace: str, filename: str, data: bytes,
           fmt: str | None, mode: str, options: dict) -> tuple[ImportJob, bool]:
    org_id = p.single_org_with("imports.manage", organisation_id)
    s = get_settings()
    if not data:
        raise ValidationFailed("empty file", code="invalid_file")
    if len(data) > s.import_max_bytes:
        raise ValidationFailed(f"file exceeds {s.import_max_bytes} bytes", code="file_too_large")
    fmt = fmt or ("json" if filename.lower().endswith(".json") else "csv")
    bad = set(options.get("clear_blank_fields", [])) - CLEARABLE
    if bad:
        raise ValidationFailed(f"clear_blank_fields may only contain {sorted(CLEARABLE)}", code="invalid_option")
    digest = hashlib.sha256(data).hexdigest()
    existing = session.execute(select(ImportJob).where(ImportJob.organisation_id == org_id,
                                                       ImportJob.source_namespace == source_namespace,
                                                       ImportJob.file_sha256 == digest)).scalar_one_or_none()
    if existing:
        return existing, True
    rows = parse_file(fmt, data)
    if len(rows) > s.import_max_rows:
        raise ValidationFailed(f"file exceeds {s.import_max_rows} rows", code="file_too_large")
    key = f"imports/{org_id}/{digest}-{''.join(c for c in filename if c.isalnum() or c in '._-')[:80]}"
    stored = get_storage().put(key, data, "application/json" if fmt == "json" else "text/csv")
    job = ImportJob(id=uuid.uuid4(), organisation_id=org_id, source_namespace=source_namespace, format=fmt, mode=mode,
                    original_filename=filename, storage_bucket=stored.bucket, object_key=stored.key, file_sha256=digest,
                    byte_size=len(data), options=options, row_count=len(rows), uploaded_by=p.user_id)
    session.add(job)
    session.flush()
    for i, raw in enumerate(rows, start=1):
        session.add(ImportRow(import_job_id=job.id, organisation_id=org_id, row_number=i,
                              source_record_id=str(raw.get("source_record_id") or "").strip() or None, raw=jsonable(raw)))
    session.flush()
    audit(session, "import.uploaded", "import_job", job.id, org_id,
          changes={"filename": filename, "rows": len(rows), "sha256": digest, "mode": mode})
    validate(session, job)
    return job, False


def _normalise(raw: dict, job: ImportJob, org: Organisation, loc_codes: dict) -> tuple[dict, list[dict]]:
    f: list[dict] = []
    get = lambda k: str(raw.get(k, "")).strip()  # noqa: E731
    n: dict = {}
    for k in REQUIRED:
        if not get(k):
            f.append(_finding("error", k, "required", f"{k} is required"))
    unknown_cols = set(raw) - set(REQUIRED) - set(OPTIONAL)
    if unknown_cols:
        f.append(_finding("warning", ",".join(sorted(unknown_cols)), "unknown_column", "column ignored (no mapping rule)"))
    n["source_record_id"] = get("source_record_id") or None
    if get("vin"):
        f += vin_findings(get("vin"))
        n["vin"] = normalize_vin(get("vin"))
    cur = get("currency").upper() or None
    n["currency"] = cur
    if cur:
        try:
            Money.zero(cur)
        except MoneyError:
            f.append(_finding("error", "currency", "unsupported_currency", f"{cur} is not a supported currency"))
            cur = None
    if get("price") and cur:
        try:
            m = Money.parse(get("price"), cur)
            if m.amount_minor <= 0 or m.amount_minor > MAX_PRICE_MINOR:
                f.append(_finding("error", "price", "invalid_price", "price must be > 0 and below 10,000,000"))
            n["price_minor"] = m.amount_minor
        except MoneyError as e:
            f.append(_finding("error", "price", "invalid_price", str(e)))
    if get("deposit") and cur:
        try:
            dep = Money.parse(get("deposit"), cur).amount_minor
            if dep < 0 or (n.get("price_minor") and dep > n["price_minor"]):
                f.append(_finding("error", "deposit", "invalid_deposit", "deposit must be between 0 and the price"))
            n["deposit_minor"] = dep
        except MoneyError as e:
            f.append(_finding("error", "deposit", "invalid_deposit", str(e)))
    if get("location_code"):
        loc = loc_codes.get(get("location_code").upper())
        if loc is None:
            f.append(_finding("error", "location_code", "unknown_reference", f"no location {get('location_code')} for this dealer"))
        n["location_id"] = loc
    if get("source_updated_at"):
        try:
            t = dt.datetime.fromisoformat(get("source_updated_at").replace("Z", "+00:00"))
            if t.tzinfo is None:
                f.append(_finding("error", "source_updated_at", "naive_timestamp", "must include a UTC offset"))
            elif t > dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=5):
                f.append(_finding("error", "source_updated_at", "future_timestamp", "source update is in the future"))
            n["source_updated_at"] = t.isoformat()
        except ValueError:
            f.append(_finding("error", "source_updated_at", "invalid_type", "not an ISO 8601 timestamp"))
    if get("model_year"):
        try:
            y = int(get("model_year"))
            if not 1950 <= y <= 2100:
                raise ValueError
            n["model_year"] = y
        except ValueError:
            f.append(_finding("error", "model_year", "invalid_type", "model_year must be an integer 1950-2100"))
    if get("odometer_value"):
        try:
            ov = int(get("odometer_value").replace(",", ""))
            if ov < 0:
                raise ValueError
            n["odometer_value"] = ov
            unit = get("odometer_unit").lower()
            if unit not in ("km", "mi"):
                f.append(_finding("error", "odometer_unit", "unit_required", "odometer_unit must be km or mi when odometer_value is given"))
            n["odometer_unit"] = unit or None
        except ValueError:
            f.append(_finding("error", "odometer_value", "invalid_type", "odometer_value must be a non-negative integer"))
    elif get("odometer_unit"):
        f.append(_finding("warning", "odometer_unit", "unit_without_value", "odometer_unit ignored: no value (odometer stays unknown)"))
    for k in ("make", "model", "trim", "exterior_colour", "interior_colour", "stock_number", "title", "description"):
        if get(k):
            n[k] = get(k)
    if get("condition"):
        c = get("condition").lower().replace(" ", "_")
        if c not in ("new", "used", "certified_pre_owned"):
            f.append(_finding("error", "condition", "invalid_value", "condition must be new, used or certified_pre_owned"))
        n["condition"] = c
    if get("availability"):
        a = get("availability").lower()
        if a not in ("available", "unavailable", "sold", "in_transit"):
            f.append(_finding("error", "availability", "invalid_value", "availability must be available, unavailable, in_transit or sold"))
        n["availability"] = a
    if get("sale_eligibility"):
        se = get("sale_eligibility").lower()
        if se not in ("eligible", "not_eligible", "pending_review"):
            f.append(_finding("error", "sale_eligibility", "invalid_value", "invalid sale_eligibility"))
        n["sale_eligibility"] = se
    if get("features"):
        n["features"] = sorted({x.strip().lower().replace(" ", "_") for x in get("features").split(";") if x.strip()})
    n["_blank"] = sorted(k for k in OPTIONAL if k in raw and get(k) == "")
    return n, f


def validate(session: Session, job: ImportJob) -> ImportJob:
    org = session.get(Organisation, job.organisation_id)
    loc_codes = {c: i for c, i in session.execute(select(Location.code, Location.id).where(Location.organisation_id == org.id))}
    rows = session.execute(select(ImportRow).where(ImportRow.import_job_id == job.id).order_by(ImportRow.row_number)).scalars().all()
    seen_ids: dict[str, int] = {}
    seen_vins: dict[str, str] = {}
    counts = {"valid": 0, "warning": 0, "invalid": 0}
    for row in rows:
        n, f = _normalise(row.raw, job, org, loc_codes)
        sid, vin = n.get("source_record_id"), n.get("vin")
        if sid:
            if sid in seen_ids:
                f.append(_finding("error", "source_record_id", "duplicate_source_identifier", f"duplicate of row {seen_ids[sid]}"))
            else:
                seen_ids[sid] = row.row_number
        if vin:
            if vin in seen_vins and seen_vins[vin] != sid:
                f.append(_finding("error", "vin", "duplicate_vin_in_file", f"VIN also used by source record {seen_vins[vin]}"))
            seen_vins.setdefault(vin, sid)
        action, method, vehicle_id, listing_id = _plan(session, job, n, f)
        n_clean = {k: v for k, v in n.items() if not k.startswith("_")}
        row.normalized = jsonable(n)
        row.payload_sha256 = sha256_json(n_clean)
        row.findings = f
        row.match_method, row.matched_vehicle_id, row.matched_listing_id = method, vehicle_id, listing_id
        if any(x["severity"] == "error" for x in f):
            row.status, row.planned_action = "invalid", "reject"
            counts["invalid"] += 1
        else:
            row.planned_action = action
            row.status = "warning" if f else "valid"
            counts["warning" if f else "valid"] += 1
    job.valid_count, job.warning_count, job.invalid_count = counts["valid"], counts["warning"], counts["invalid"]
    job.status, job.validated_at = "validated", func.now()
    session.flush()
    audit(session, "import.validated", "import_job", job.id, job.organisation_id, changes=counts)
    return job


def _plan(session: Session, job: ImportJob, n: dict, f: list) -> tuple[str, str, uuid.UUID | None, uuid.UUID | None]:
    sid, vin = n.get("source_record_id"), n.get("vin")
    mapping = None
    if sid:
        mapping = session.execute(select(SourceRecordMapping).where(
            SourceRecordMapping.organisation_id == job.organisation_id, SourceRecordMapping.source_namespace == job.source_namespace,
            SourceRecordMapping.source_record_id == sid)).scalar_one_or_none()
    vehicle_id, method = None, "none"
    if mapping:
        vehicle_id, method = mapping.vehicle_id, "source_mapping"
        if vin:
            mvin = session.execute(select(VehicleIdentifier.value_normalized).where(
                VehicleIdentifier.vehicle_id == mapping.vehicle_id, VehicleIdentifier.namespace == "vin",
                VehicleIdentifier.retired_at.is_(None))).scalar_one_or_none()
            if mvin and mvin != vin:
                f.append(_finding("error", "vin", "vin_changed_for_source_record",
                                  f"source record previously mapped to VIN {mvin}; VIN changes need manual review"))
        if n.get("source_updated_at") and mapping.last_source_updated_at:
            incoming = dt.datetime.fromisoformat(n["source_updated_at"])
            payload_hash = sha256_json({k: v for k, v in n.items() if not k.startswith("_")})
            if payload_hash == mapping.last_payload_sha256:
                return "no_change", method, vehicle_id, mapping.listing_id
            if incoming <= mapping.last_source_updated_at:
                f.append(_finding("error", "source_updated_at", "stale_source_update",
                                  f"source update {incoming.isoformat()} is not newer than last applied {mapping.last_source_updated_at.isoformat()}"))
    elif vin:
        vehicle_id = session.execute(select(VehicleIdentifier.vehicle_id).where(
            VehicleIdentifier.namespace == "vin", VehicleIdentifier.value_normalized == vin,
            VehicleIdentifier.retired_at.is_(None))).scalar_one_or_none()
        if vehicle_id:
            method = "vin"
            cust = session.execute(select(Vehicle.custodian_organisation_id).where(Vehicle.id == vehicle_id)).scalar_one_or_none()
            if cust != job.organisation_id:
                # Never attach to (or reveal) a vehicle held by another custodian.
                f.append(_finding("error", "vin", "vehicle_custodian_conflict", "VIN is registered to a vehicle held by another organisation"))
                return "reject", "none", None, None
        elif vin and not any(x["code"] == "invalid_vin" for x in f):
            # Conflict check across tenants without disclosing details: platform-level existence test.
            exists = session.execute(text("SELECT vin_registered_elsewhere(:v, :o)"), {"v": vin, "o": job.organisation_id}).scalar()
            if exists:
                f.append(_finding("error", "vin", "vehicle_custodian_conflict", "VIN is registered to a vehicle held by another organisation"))
    if not vehicle_id and n.get("stock_number"):
        vehicle_id = session.execute(select(VehicleIdentifier.vehicle_id).where(
            VehicleIdentifier.namespace == "stock", VehicleIdentifier.issuing_organisation_id == job.organisation_id,
            VehicleIdentifier.value_normalized == n["stock_number"].upper().replace(" ", "").replace("-", ""),
            VehicleIdentifier.retired_at.is_(None))).scalar_one_or_none()
        if vehicle_id:
            method = "stock_number"
            f.append(_finding("warning", "stock_number", "matched_by_stock_number", "matched an existing vehicle by dealer stock number (no VIN match)"))
    listing_id = mapping.listing_id if mapping else None
    if vehicle_id:
        v = session.get(Vehicle, vehicle_id)
        committed = session.execute(text("SELECT 1 FROM vehicle_current_reservations WHERE vehicle_id = :v"), {"v": vehicle_id}).first()
        avail = n.get("availability")
        if v and v.availability_status == "sold" and avail in (None, "available"):
            f.append(_finding("warning", "availability", "availability_conflict",
                              "source says available but the vehicle is recorded as sold; availability is not changed"))
        if committed and avail in ("sold", "unavailable"):
            f.append(_finding("error", "availability", "availability_conflict",
                              f"source says {avail} but the vehicle is committed to an active reservation; resolve manually"))
        elif committed and avail in (None, "available"):
            f.append(_finding("warning", "availability", "availability_conflict",
                              "vehicle is under an active reservation; listing is updated but stays reserved"))
        return "update", method, vehicle_id, listing_id
    # Weak-signal duplicate check -> review proposal, never an automatic merge.
    if n.get("make") and n.get("model") and n.get("model_year") and n.get("exterior_colour"):
        cand = session.execute(text("""
            SELECT v.id FROM vehicles v JOIN vehicle_trims t ON t.id = v.trim_id JOIN vehicle_models m ON m.id = t.model_id
              JOIN vehicle_makes k ON k.id = m.make_id
             WHERE v.custodian_organisation_id = :o AND lower(k.name::text) = lower(:make) AND lower(m.name) = lower(:model)
               AND v.model_year = :y AND lower(v.exterior_colour) = lower(:c) AND v.archived_at IS NULL
               AND NOT EXISTS (SELECT 1 FROM vehicle_identifiers i WHERE i.vehicle_id = v.id AND i.namespace = 'vin' AND i.retired_at IS NULL)
             LIMIT 1"""), {"o": job.organisation_id, "make": n["make"], "model": n["model"], "y": n["model_year"],
                           "c": n["exterior_colour"]}).scalar()
        if cand:
            f.append(_finding("warning", "vin", "possible_duplicate",
                              f"similar vehicle {cand} without a VIN exists; a merge proposal will be created for review"))
            return "create", "proposal", None, None
    return "create", method, None, None


def approve(session: Session, p: Principal, job_id, expected_version, *, apply_now: bool = True) -> ImportJob:
    job = get_or_404(session, ImportJob, job_id, lock=True, label="import job")
    p.require("imports.approve", job.organisation_id)
    check_version(job, expected_version)
    if job.status != "validated":
        raise Conflict(f"job is {job.status}", code="invalid_status_transition")
    if job.mode == "all_or_nothing" and job.invalid_count > 0:
        raise ValidationFailed(f"{job.invalid_count} invalid rows: all_or_nothing imports cannot be approved until the file is fixed",
                               code="import_has_invalid_rows")
    job.status, job.approved_by, job.approved_at = "approved", p.user_id, func.now()
    session.flush()
    audit(session, "import.approved", "import_job", job.id, job.organisation_id, changes={"mode": job.mode})
    if apply_now:
        apply(session, job, p.user_id)
    return job


def reject(session: Session, p: Principal, job_id, expected_version, reason: str) -> ImportJob:
    job = get_or_404(session, ImportJob, job_id, lock=True, label="import job")
    p.require("imports.approve", job.organisation_id)
    check_version(job, expected_version)
    if job.status not in ("validated", "uploaded"):
        raise Conflict(f"job is {job.status}", code="invalid_status_transition")
    job.status, job.error_summary = "rejected", reason
    session.flush()
    audit(session, "import.rejected", "import_job", job.id, job.organisation_id, changes={"reason": reason})
    return job


def apply(session: Session, job: ImportJob, user_id) -> ImportJob:
    job.status, job.attempts = "applying", job.attempts + 1
    session.flush()
    rows = session.execute(select(ImportRow).where(ImportRow.import_job_id == job.id).order_by(ImportRow.row_number)).scalars().all()
    stats = {"applied": 0, "no_change": 0, "skipped": 0, "failed": 0}
    org = session.get(Organisation, job.organisation_id)
    outer = session.begin_nested()  # all_or_nothing: one savepoint around everything
    try:
        for row in rows:
            if row.status == "invalid":
                row.status = "skipped"
                stats["skipped"] += 1
                continue
            if row.planned_action == "no_change":
                _touch_seen(session, job, row)
                row.status, row.applied_at = "no_change", func.now()
                stats["no_change"] += 1
                continue
            sp = session.begin_nested()
            try:
                result = _apply_row(session, job, org, row, user_id)
                sp.commit()
                row.status, row.result, row.applied_at = "applied", jsonable(result), func.now()
                stats["applied"] += 1
            except Exception as e:  # noqa: BLE001 - per-row capture
                sp.rollback()
                if job.mode == "all_or_nothing":
                    raise
                row.status = "failed"
                row.result = {"error": getattr(e, "code", type(e).__name__), "detail": getattr(e, "detail", str(e))[:500]}
                stats["failed"] += 1
        outer.commit()
    except Exception as e:  # noqa: BLE001
        outer.rollback()
        job = session.get(ImportJob, job.id)
        job.status = "failed"
        job.error_summary = f"all_or_nothing import rolled back: {getattr(e, 'detail', str(e))[:400]}"
        session.flush()
        audit(session, "import.failed", "import_job", job.id, job.organisation_id, changes={"error": job.error_summary})
        return job
    job.applied_count, job.no_change_count, job.skipped_count = stats["applied"], stats["no_change"], stats["skipped"] + stats["failed"]
    job.status = "applied" if stats["skipped"] + stats["failed"] == 0 else "applied_with_skips"
    job.applied_at = func.now()
    session.flush()
    audit(session, "import.applied", "import_job", job.id, job.organisation_id, changes=stats)
    emit(session, "import.applied", "import_job", job.id, job.organisation_id, {"import_job_id": job.id, **stats})
    return job


def _touch_seen(session: Session, job: ImportJob, row: ImportRow) -> None:
    m = session.execute(select(SourceRecordMapping).where(
        SourceRecordMapping.organisation_id == job.organisation_id, SourceRecordMapping.source_namespace == job.source_namespace,
        SourceRecordMapping.source_record_id == row.source_record_id)).scalar_one_or_none()
    if m:
        m.last_seen_at, m.last_import_job_id = func.now(), job.id
        if m.listing_id:
            lst = session.get(Listing, m.listing_id)
            if lst and lst.status in ("draft", "published", "suspended"):
                lst.source_last_seen_at, lst.freshness_state = func.now(), "fresh"


def _apply_row(session: Session, job: ImportJob, org: Organisation, row: ImportRow, user_id) -> dict:
    from app.services.listings import _apply_price
    n = row.normalized
    clear = set(job.options.get("clear_blank_fields", [])) & set(n.get("_blank", []))
    src = f"import:{job.source_namespace}"
    now = session.execute(select(func.now())).scalar_one()
    eff = dt.datetime.fromisoformat(n["source_updated_at"])
    created = False
    if row.matched_vehicle_id:
        v = session.execute(select(Vehicle).where(Vehicle.id == row.matched_vehicle_id).with_for_update()).scalar_one()
    else:
        v = Vehicle(id=uuid.uuid4(), custodian_organisation_id=job.organisation_id, condition=n.get("condition", "unknown"))
        session.add(v)
        created = True
    trim = resolve_trim(session, n.get("make"), n.get("model"), n.get("model_year"), n.get("trim"))
    updates = {}
    for field, value in (("trim_id", trim), ("model_year", n.get("model_year")), ("exterior_colour", n.get("exterior_colour")),
                         ("interior_colour", n.get("interior_colour")), ("current_location_id", n.get("location_id"))):
        if value is not None:
            updates[field] = value
        elif field in clear:
            updates[field] = None
    if n.get("condition"):
        updates["condition"] = n["condition"]
    if n.get("odometer_value") is not None:
        updates.update(odometer_value=n["odometer_value"], odometer_unit=n["odometer_unit"], odometer_recorded_at=eff)
    elif "odometer_value" in clear:
        updates.update(odometer_value=None, odometer_unit=None, odometer_recorded_at=None)
    if n.get("availability") in ("available", "unavailable", "in_transit") and v.availability_status not in ("sold", "written_off"):
        committed = session.execute(text("SELECT 1 FROM vehicle_current_reservations WHERE vehicle_id = :v"), {"v": v.id}).first()
        if not committed:
            updates["availability_status"] = n["availability"]
    for k, val in updates.items():
        setattr(v, k, val)
    session.flush()
    if created or not session.execute(select(VehicleIdentifier.id).where(VehicleIdentifier.vehicle_id == v.id,
                                                                         VehicleIdentifier.namespace == "vin",
                                                                         VehicleIdentifier.retired_at.is_(None))).first():
        session.add(VehicleIdentifier(vehicle_id=v.id, namespace="vin", value=n["vin"], is_synthetic=True, source=src))
    if n.get("stock_number"):
        sn = n["stock_number"].upper().replace(" ", "").replace("-", "")
        if not session.execute(select(VehicleIdentifier.id).where(VehicleIdentifier.vehicle_id == v.id, VehicleIdentifier.namespace == "stock",
                                                                  VehicleIdentifier.issuing_organisation_id == job.organisation_id,
                                                                  VehicleIdentifier.retired_at.is_(None))).first():
            session.add(VehicleIdentifier(vehicle_id=v.id, namespace="stock", value=sn, issuing_organisation_id=job.organisation_id,
                                          is_synthetic=True, source=src))
    if created:
        session.add(VehicleIdentifier(vehicle_id=v.id, namespace=f"source:{job.source_namespace}"[:64], value=n["source_record_id"],
                                      issuing_organisation_id=job.organisation_id, is_synthetic=True, source=src))
    # Provenance: every imported attribute is an import_source/seller_claim assertion.
    for attr in ("odometer_value", "exterior_colour", "interior_colour", "condition"):
        if n.get(attr) is not None:
            session.add(VehicleAttributeAssertion(vehicle_id=v.id, organisation_id=job.organisation_id,
                                                  attribute="odometer" if attr == "odometer_value" else attr,
                                                  assertion_type="seller_claim" if attr == "odometer_value" else "import_source",
                                                  value=n[attr], unit=n.get("odometer_unit") if attr == "odometer_value" else None,
                                                  source=src, source_reference=f"{job.id}#{row.row_number}", effective_at=eff,
                                                  recorded_by=user_id))
    for feat in n.get("features") or []:
        session.execute(text("""INSERT INTO vehicle_features (vehicle_id, feature_code, label, assertion_type, source)
                                VALUES (:v, :c, :l, 'seller_claim', :s) ON CONFLICT DO NOTHING"""),
                        {"v": v.id, "c": feat[:64], "l": feat.replace("_", " "), "s": src})
    if row.match_method == "proposal":
        cand = next((x["message"].split()[2] for x in row.findings if x["code"] == "possible_duplicate"), None)
        if cand:
            session.add(VehicleMergeProposal(organisation_id=job.organisation_id, primary_vehicle_id=uuid.UUID(cand),
                                             duplicate_vehicle_id=v.id, score=0.6, proposed_by=f"import:{job.id}",
                                             evidence=[{"signal": "make_model_year_colour", "row": row.row_number}]))
    session.flush()

    # Listing: one open marketplace listing per vehicle per dealer.
    mapping = session.execute(select(SourceRecordMapping).where(
        SourceRecordMapping.organisation_id == job.organisation_id, SourceRecordMapping.source_namespace == job.source_namespace,
        SourceRecordMapping.source_record_id == n["source_record_id"])).scalar_one_or_none()
    lst = None
    if mapping and mapping.listing_id:
        lst = session.get(Listing, mapping.listing_id)
        if lst and lst.status in ("withdrawn", "sold"):
            lst = None
    if lst is None:
        lst = session.execute(select(Listing).where(Listing.organisation_id == job.organisation_id, Listing.vehicle_id == v.id,
                                                    Listing.channel == "marketplace",
                                                    Listing.status.in_(["draft", "published", "suspended"]))).scalar_one_or_none()
    listing_created = False
    if lst is None:
        title = n.get("title") or " ".join(str(x) for x in (n.get("model_year"), n.get("make"), n.get("model"), n.get("trim")) if x) or "Vehicle"
        lst = Listing(id=uuid.uuid4(), organisation_id=job.organisation_id, vehicle_id=v.id, location_id=n["location_id"],
                      channel="marketplace", title=title, description=n.get("description"), currency=n["currency"],
                      sale_eligibility=n.get("sale_eligibility", "eligible"), deposit_required_minor=n.get("deposit_minor", 0),
                      source_namespace=job.source_namespace, source_record_id=n["source_record_id"],
                      source_last_seen_at=now, freshness_state="fresh", created_by=user_id)
        session.add(lst)
        session.flush()
        listing_created = True
    else:
        if lst.currency != n["currency"]:
            raise ValidationFailed("currency differs from the existing listing; withdraw and relist", code="currency_mismatch")
        if n.get("title"):
            lst.title = n["title"]
        if n.get("description") is not None:
            lst.description = n["description"]
        elif "description" in clear:
            lst.description = None
        if n.get("deposit_minor") is not None:
            lst.deposit_required_minor = n["deposit_minor"]
        if n.get("sale_eligibility"):
            lst.sale_eligibility = n["sale_eligibility"]
        if lst.location_id != n["location_id"]:
            lst.location_id = n["location_id"]
        lst.source_last_seen_at, lst.freshness_state = now, "fresh"
        session.flush()
    _apply_price(session, lst, n["price_minor"], "import", src, user_id)

    if mapping is None:
        mapping = SourceRecordMapping(organisation_id=job.organisation_id, source_namespace=job.source_namespace,
                                      source_record_id=n["source_record_id"], vehicle_id=v.id)
        session.add(mapping)
    mapping.listing_id, mapping.last_source_updated_at = lst.id, eff
    mapping.last_payload_sha256, mapping.last_import_job_id, mapping.last_seen_at = row.payload_sha256, job.id, now
    session.flush()
    result = {"vehicle_id": v.id, "vehicle_created": created, "listing_id": lst.id, "listing_created": listing_created,
              "listing_status": lst.status}
    if job.options.get("publish_on_apply") and lst.status == "draft":
        from app.services.listings import validate_for_publication
        errs = [x for x in validate_for_publication(session, lst) if x["severity"] == "error"]
        if not errs:
            lst.status, lst.status_reason = "published", f"import:{job.id}"
            session.flush()
            result["listing_status"] = "published"
        else:
            result["publication_findings"] = errs
    return result


def describe(session: Session, job: ImportJob) -> dict:
    d = row_dict(job)
    d["findings_summary"] = [dict(r) for r in session.execute(text("""
        SELECT f->>'code' AS code, f->>'severity' AS severity, count(*) AS rows
          FROM import_rows r, jsonb_array_elements(r.findings) f
         WHERE r.import_job_id = :j GROUP BY 1, 2 ORDER BY 2, 3 DESC"""), {"j": job.id}).mappings()]
    d["planned_actions"] = dict(session.execute(text(
        "SELECT COALESCE(planned_action,'pending'), count(*) FROM import_rows WHERE import_job_id = :j GROUP BY 1"), {"j": job.id}).all())
    return d


def list_rows(session: Session, job_id, status: str | None, code: str | None, limit: int, offset: int) -> list[dict]:
    stmt = select(ImportRow).where(ImportRow.import_job_id == job_id)
    if status:
        stmt = stmt.where(ImportRow.status == status)
    if code:
        stmt = stmt.where(ImportRow.findings.contains([{"code": code}]))
    rows = session.execute(stmt.order_by(ImportRow.row_number).limit(min(limit, 500)).offset(offset)).scalars()
    return [row_dict(r) for r in rows]
