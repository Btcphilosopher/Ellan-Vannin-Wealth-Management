"""Physical vehicles, identifiers, provenance assertions, media, merges."""
from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import func, or_, select, text
from sqlalchemy.orm import Session

from app.errors import Conflict, ValidationFailed
from app.models import (Listing, Vehicle, VehicleAttributeAssertion, VehicleFeature, VehicleIdentifier, VehicleMake,
                        VehicleMedia, VehicleMergeProposal, VehicleModel, VehicleTrim)
from app.security import Principal
from app.services.common import audit, emit, get_or_404, jsonable, keyset_page, parse_dt, row_dict, versioned_update
from app.storage import get_storage

VIN_TRANSLIT = {**{str(d): d for d in range(10)}, "A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8,
                "J": 1, "K": 2, "L": 3, "M": 4, "N": 5, "P": 7, "R": 9, "S": 2, "T": 3, "U": 4, "V": 5, "W": 6,
                "X": 7, "Y": 8, "Z": 9}
VIN_WEIGHTS = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]
VIN_ALLOWED = set("ABCDEFGHJKLMNPRSTUVWXYZ0123456789")

PATCHABLE = {"trim_id", "current_location_id", "model_year", "exterior_colour", "interior_colour", "condition",
             "odometer_value", "odometer_unit", "odometer_recorded_at", "has_open_recall", "keys_count",
             "availability_status"}
# 'sold' is only reachable through sale completion; 'written_off' via platform.
STAFF_AVAILABILITY = {"available", "in_transit", "unavailable"}


def normalize_vin(vin: str) -> str:
    return "".join(vin.split()).replace("-", "").upper()


def vin_check_digit(vin: str) -> str:
    total = sum(VIN_TRANSLIT[c] * w for c, w in zip(vin, VIN_WEIGHTS))
    r = total % 11
    return "X" if r == 10 else str(r)


def vin_findings(vin: str) -> list[dict]:
    """Format is an error; a failed North-American check digit is a warning
    (many non-NA VINs legitimately do not use position 9 as a check digit)."""
    v = normalize_vin(vin)
    if len(v) != 17 or not set(v) <= VIN_ALLOWED:
        return [{"severity": "error", "field": "vin", "code": "invalid_vin",
                 "message": "VIN must be 17 characters from A-Z/0-9 excluding I, O, Q"}]
    if vin_check_digit(v) != v[8]:
        return [{"severity": "warning", "field": "vin", "code": "vin_check_digit",
                 "message": f"position-9 check digit is {v[8]}, expected {vin_check_digit(v)}"}]
    return []


def describe(session: Session, vehicle: Vehicle) -> dict:
    d = row_dict(vehicle)
    if vehicle.trim_id:
        t = session.execute(select(VehicleTrim.name, VehicleTrim.model_year, VehicleModel.name, VehicleMake.name,
                                   VehicleTrim.fuel_type, VehicleTrim.body_style)
                            .join(VehicleModel, VehicleModel.id == VehicleTrim.model_id)
                            .join(VehicleMake, VehicleMake.id == VehicleModel.make_id)
                            .where(VehicleTrim.id == vehicle.trim_id)).first()
        if t:
            d["specification"] = {"make": t[3], "model": t[2], "trim": t[0], "model_year": t[1],
                                  "fuel_type": t[4], "body_style": t[5],
                                  "label": f"{t[1]} {t[3]} {t[2]} {t[0]}"}
    d["identifiers"] = [row_dict(i) for i in session.execute(
        select(VehicleIdentifier).where(VehicleIdentifier.vehicle_id == vehicle.id).order_by(VehicleIdentifier.recorded_at)).scalars()]
    cur = session.execute(text("""SELECT c.sale_reservation_id, c.sale_order_id, c.hold_expires_at, r.reservation_number, r.status
                                    FROM vehicle_current_reservations c JOIN sale_reservations r ON r.id = c.sale_reservation_id
                                   WHERE c.vehicle_id = :v"""), {"v": vehicle.id}).mappings().first()
    d["current_commitment"] = jsonable(dict(cur)) if cur else None
    if cur and cur["status"] == "held" and cur["hold_expires_at"] and cur["hold_expires_at"] <= dt.datetime.now(dt.timezone.utc):
        d["current_commitment"]["effective_status"] = "expired"
    return d


def list_vehicles(session: Session, *, q: str | None, availability: str | None, organisation_id, limit: int, cursor: str | None):
    stmt = select(Vehicle).where(Vehicle.archived_at.is_(None))
    if availability:
        stmt = stmt.where(Vehicle.availability_status == availability)
    if organisation_id:
        stmt = stmt.where(Vehicle.custodian_organisation_id == organisation_id)
    if q:
        qn = normalize_vin(q)
        stmt = stmt.where(or_(
            Vehicle.id.in_(select(VehicleIdentifier.vehicle_id).where(VehicleIdentifier.value_normalized.like(f"{qn}%"))),
            Vehicle.trim_id.in_(select(VehicleTrim.id).join(VehicleModel).join(VehicleMake).where(
                or_(VehicleModel.name.ilike(f"%{q}%"), VehicleMake.name.ilike(f"%{q}%"), VehicleTrim.name.ilike(f"%{q}%")))),
        ))
    rows, nxt = keyset_page(session, stmt, Vehicle.created_at, Vehicle.id, limit=limit, cursor=cursor, parse=parse_dt)
    return [describe(session, r[0]) for r in rows], nxt


def resolve_trim(session: Session, make: str | None, model: str | None, year: int | None, trim: str | None) -> uuid.UUID | None:
    if not (make and model and year and trim):
        return None
    return session.execute(select(VehicleTrim.id).join(VehicleModel).join(VehicleMake).where(
        func.lower(VehicleMake.name) == make.lower(), func.lower(VehicleModel.name) == model.lower(),
        VehicleTrim.model_year == year, func.lower(VehicleTrim.name) == trim.lower())).scalar_one_or_none()


def create_vehicle(session: Session, p: Principal, data: dict) -> Vehicle:
    org_id = p.single_org_with("vehicles.write", data.get("custodian_organisation_id"))
    vin = data.get("vin")
    if vin:
        errs = [f for f in vin_findings(vin) if f["severity"] == "error"]
        if errs:
            raise ValidationFailed("invalid VIN", errors=errs)
    v = Vehicle(id=uuid.uuid4(), custodian_organisation_id=org_id, trim_id=data.get("trim_id"),
                current_location_id=data.get("current_location_id"), model_year=data.get("model_year"),
                exterior_colour=data.get("exterior_colour"), interior_colour=data.get("interior_colour"),
                condition=data.get("condition") or "unknown",
                odometer_value=data.get("odometer_value"), odometer_unit=data.get("odometer_unit"),
                odometer_recorded_at=(data.get("odometer_recorded_at") or (dt.datetime.now(dt.timezone.utc) if data.get("odometer_value") is not None else None)),
                has_open_recall=data.get("has_open_recall"), keys_count=data.get("keys_count"))
    session.add(v)
    session.flush()
    if vin:
        session.add(VehicleIdentifier(vehicle_id=v.id, namespace="vin", value=normalize_vin(vin),
                                      is_synthetic=bool(data.get("is_synthetic", True)), source=data.get("source", "manual")))
    for ident in data.get("identifiers") or []:
        session.add(VehicleIdentifier(vehicle_id=v.id, namespace=ident["namespace"], value=ident["value"],
                                      issuing_organisation_id=ident.get("issuing_organisation_id"),
                                      is_synthetic=bool(ident.get("is_synthetic", True)), source=data.get("source", "manual")))
    if data.get("odometer_value") is not None:
        session.add(VehicleAttributeAssertion(vehicle_id=v.id, organisation_id=org_id, attribute="odometer",
                                              assertion_type="seller_claim", value=data["odometer_value"],
                                              unit=data.get("odometer_unit"), source=data.get("source", "manual"),
                                              effective_at=v.odometer_recorded_at, recorded_by=p.user_id))
    session.flush()
    audit(session, "vehicle.created", "vehicle", v.id, org_id, changes={k: data.get(k) for k in sorted(data) if k != "identifiers"})
    emit(session, "vehicle.created", "vehicle", v.id, org_id, {"vehicle_id": v.id})
    return v


def update_vehicle(session: Session, p: Principal, vehicle_id, expected_version: int | None, patch: dict) -> Vehicle:
    v = get_or_404(session, Vehicle, vehicle_id, label="vehicle")
    p.require("vehicles.write", v.custodian_organisation_id)
    from app.services.common import check_version
    check_version(v, expected_version)
    unknown = set(patch) - PATCHABLE
    if unknown:
        raise ValidationFailed(f"fields not editable here: {sorted(unknown)}", code="field_not_editable")
    if "availability_status" in patch and patch["availability_status"] not in STAFF_AVAILABILITY:
        raise ValidationFailed("availability can only be set to available, in_transit or unavailable; sales mark vehicles sold",
                               code="availability_not_settable")
    before = row_dict(v)
    if "odometer_value" in patch and patch["odometer_value"] is not None and "odometer_recorded_at" not in patch:
        patch["odometer_recorded_at"] = dt.datetime.now(dt.timezone.utc)
    versioned_update(session, Vehicle, v.id, v.version, patch)
    v = get_or_404(session, Vehicle, vehicle_id)
    if "odometer_value" in patch and patch["odometer_value"] is not None:
        if before.get("odometer_value") is not None and patch["odometer_value"] < before["odometer_value"] \
                and patch.get("odometer_unit", before["odometer_unit"]) == before["odometer_unit"]:
            # Never silently accept a rollback: keep both claims, flag as disputed.
            status = "disputed"
        else:
            status = "unverified"
        session.add(VehicleAttributeAssertion(vehicle_id=v.id, organisation_id=v.custodian_organisation_id, attribute="odometer",
                                              assertion_type="seller_claim", value=patch["odometer_value"], unit=v.odometer_unit,
                                              source="manual", effective_at=v.odometer_recorded_at, verification_status=status,
                                              recorded_by=p.user_id))
    after = row_dict(v)
    from app.services.common import diff
    audit(session, "vehicle.updated", "vehicle", v.id, v.custodian_organisation_id, changes=diff(before, after))
    emit(session, "vehicle.updated", "vehicle", v.id, v.custodian_organisation_id, {"vehicle_id": v.id, "fields": sorted(patch)})
    return v


def add_assertion(session: Session, p: Principal, vehicle_id, data: dict) -> VehicleAttributeAssertion:
    v = get_or_404(session, Vehicle, vehicle_id, label="vehicle")
    p.require("vehicles.write", v.custodian_organisation_id)
    a = VehicleAttributeAssertion(vehicle_id=v.id, organisation_id=v.custodian_organisation_id, attribute=data["attribute"],
                                  assertion_type=data["assertion_type"], value=data["value"], unit=data.get("unit"),
                                  source=data["source"], source_reference=data.get("source_reference"),
                                  effective_at=data.get("effective_at") or dt.datetime.now(dt.timezone.utc),
                                  verification_status=data.get("verification_status", "unverified"), recorded_by=p.user_id)
    session.add(a)
    session.flush()
    audit(session, "vehicle.assertion_added", "vehicle", v.id, v.custodian_organisation_id,
          changes={"attribute": a.attribute, "assertion_type": a.assertion_type, "value": a.value})
    return a


def assertions(session: Session, vehicle_id) -> list[dict]:
    rows = session.execute(select(VehicleAttributeAssertion).where(VehicleAttributeAssertion.vehicle_id == vehicle_id)
                           .order_by(VehicleAttributeAssertion.attribute, VehicleAttributeAssertion.effective_at.desc())).scalars()
    feats = session.execute(select(VehicleFeature).where(VehicleFeature.vehicle_id == vehicle_id)).scalars()
    return {"assertions": [row_dict(a) for a in rows], "features": [row_dict(f) for f in feats]}


def add_media(session: Session, p: Principal, vehicle_id, *, filename: str, content_type: str, data: bytes, kind: str,
              caption: str | None) -> VehicleMedia:
    v = get_or_404(session, Vehicle, vehicle_id, label="vehicle")
    p.require("vehicles.write", v.custodian_organisation_id)
    if len(data) == 0 or len(data) > 15 * 1024 * 1024:
        raise ValidationFailed("media must be between 1 byte and 15 MB", code="invalid_media_size")
    key = f"vehicles/{v.id}/{uuid.uuid4()}-{''.join(c for c in filename if c.isalnum() or c in '._-')[:80]}"
    stored = get_storage().put(key, data, content_type)
    m = VehicleMedia(vehicle_id=v.id, organisation_id=v.custodian_organisation_id, kind=kind, storage_bucket=stored.bucket,
                     object_key=stored.key, content_type=content_type, byte_size=stored.size, sha256=stored.sha256,
                     caption=caption, uploaded_by=p.user_id)
    session.add(m)
    session.flush()
    audit(session, "vehicle.media_added", "vehicle", v.id, v.custodian_organisation_id, changes={"object_key": key, "kind": kind})
    return m


def decide_merge(session: Session, p: Principal, proposal_id, decision: str, note: str | None, expected_version: int | None):
    prop = get_or_404(session, VehicleMergeProposal, proposal_id, lock=True, label="merge proposal")
    p.require("vehicles.merge", prop.organisation_id)
    from app.services.common import check_version
    check_version(prop, expected_version)
    if prop.status != "pending":
        raise Conflict("proposal already decided", code="already_decided")
    if decision == "accept":
        # Lock both vehicles in a stable order.
        for vid in sorted([prop.primary_vehicle_id, prop.duplicate_vehicle_id], key=str):
            session.execute(select(Vehicle.id).where(Vehicle.id == vid).with_for_update())
        busy = session.execute(text("SELECT 1 FROM vehicle_current_reservations WHERE vehicle_id = :v"),
                               {"v": prop.duplicate_vehicle_id}).first()
        if busy:
            raise Conflict("the duplicate vehicle is committed to a reservation; resolve it first", code="merge_blocked")
        now = dt.datetime.now(dt.timezone.utc)
        idents = session.execute(select(VehicleIdentifier).where(VehicleIdentifier.vehicle_id == prop.duplicate_vehicle_id,
                                                                  VehicleIdentifier.retired_at.is_(None))).scalars().all()
        for i in idents:
            i.retired_at, i.retired_reason = now, f"merged_into:{prop.primary_vehicle_id}"
        session.flush()
        for i in idents:
            exists = session.execute(select(VehicleIdentifier.id).where(
                VehicleIdentifier.vehicle_id == prop.primary_vehicle_id, VehicleIdentifier.namespace == i.namespace,
                VehicleIdentifier.value_normalized == i.value_normalized, VehicleIdentifier.retired_at.is_(None))).first()
            if not exists:
                session.add(VehicleIdentifier(vehicle_id=prop.primary_vehicle_id, namespace=i.namespace, value=i.value,
                                              issuing_organisation_id=i.issuing_organisation_id, is_synthetic=i.is_synthetic,
                                              source=f"merge:{prop.id}", verification_status=i.verification_status))
        for lst in session.execute(select(Listing).where(Listing.vehicle_id == prop.duplicate_vehicle_id,
                                                          Listing.status.in_(["draft", "published", "suspended"]))).scalars():
            lst.status, lst.status_reason = "withdrawn", f"vehicle_merged_into:{prop.primary_vehicle_id}"
        dup = session.get(Vehicle, prop.duplicate_vehicle_id)
        dup.merged_into_vehicle_id, dup.archived_at = prop.primary_vehicle_id, now
    prop.status = "accepted" if decision == "accept" else "rejected"
    prop.decided_by, prop.decided_at, prop.decision_note = p.user_id, dt.datetime.now(dt.timezone.utc), note
    session.flush()
    audit(session, f"vehicle_merge.{prop.status}", "vehicle_merge_proposal", prop.id, prop.organisation_id,
          changes={"primary": prop.primary_vehicle_id, "duplicate": prop.duplicate_vehicle_id, "note": note})
    return prop
