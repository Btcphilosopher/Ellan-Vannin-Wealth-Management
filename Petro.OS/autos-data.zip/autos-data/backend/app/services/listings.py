"""Listings: drafting, price versions, publication workflow, search, export."""
from __future__ import annotations

import csv
import datetime as dt
import io
import uuid

from sqlalchemy import and_, func, or_, select, text
from sqlalchemy.orm import Session

from app.errors import Conflict, ValidationFailed
from app.models import (Listing, ListingPriceVersion, ListingStatusEvent, Location, Organisation, Vehicle,
                        VehicleIdentifier, VehicleMake, VehicleModel, VehicleTrim)
from app.money import Money
from app.security import Principal
from app.services.common import (audit, check_version, csv_safe, diff, emit, get_or_404, jsonable, keyset_page,
                                 parse_dt, row_dict)

EDITABLE = {"title", "description", "location_id", "sale_eligibility", "deposit_required_minor", "effective_from", "effective_to"}


def current_price(session: Session, listing: Listing) -> ListingPriceVersion | None:
    if listing.current_price_version_id is None:
        return None
    return session.get(ListingPriceVersion, listing.current_price_version_id)


def describe(session: Session, listing: Listing, *, include_history: bool = False) -> dict:
    d = row_dict(listing)
    pv = current_price(session, listing)
    d["price"] = Money(pv.amount_minor, pv.currency).as_dict() | {"price_version_id": str(pv.id)} if pv else None
    d["deposit"] = Money(listing.deposit_required_minor, listing.currency).as_dict()
    veh = session.get(Vehicle, listing.vehicle_id)
    if veh:
        from app.services.vehicles import describe as vdesc
        vd = vdesc(session, veh)
        d["vehicle"] = {k: vd.get(k) for k in ("id", "specification", "exterior_colour", "odometer_value", "odometer_unit",
                                               "availability_status", "condition", "current_commitment")}
        vin = next((i for i in vd["identifiers"] if i["namespace"] == "vin" and not i["retired_at"]), None)
        d["vehicle"]["vin"] = vin["value"] if vin else None
    org = session.get(Organisation, listing.organisation_id)
    d["seller"] = {"id": str(org.id), "display_name": org.display_name} if org else None
    loc = session.get(Location, listing.location_id)
    d["location"] = {"id": str(loc.id), "name": loc.name, "city": loc.city, "timezone": loc.timezone} if loc else None
    if include_history:
        d["price_history"] = [row_dict(x) for x in session.execute(
            select(ListingPriceVersion).where(ListingPriceVersion.listing_id == listing.id)
            .order_by(ListingPriceVersion.effective_from.desc())).scalars()]
        d["status_history"] = [row_dict(x) for x in session.execute(
            select(ListingStatusEvent).where(ListingStatusEvent.listing_id == listing.id)
            .order_by(ListingStatusEvent.occurred_at)).scalars()]
        d["validation"] = validate_for_publication(session, listing)
    return d


_SUMMARY_SQL = text("""
    SELECT l.id, pv.amount_minor, pv.currency AS price_currency, pv.id AS price_version_id,
           v.id AS vehicle_id, v.exterior_colour, v.odometer_value, v.odometer_unit, v.availability_status, v.condition,
           t.name AS trim, t.model_year, t.fuel_type, t.body_style, m.name AS model, k.name::text AS make,
           (SELECT i.value FROM vehicle_identifiers i WHERE i.vehicle_id = v.id AND i.namespace = 'vin' AND i.retired_at IS NULL LIMIT 1) AS vin,
           o.display_name AS seller_name, loc.name AS location_name, loc.city, loc.timezone,
           c.sale_reservation_id, c.sale_order_id, c.hold_expires_at, r.reservation_number, r.status AS reservation_status
      FROM listings l
      LEFT JOIN listing_price_versions pv ON pv.id = l.current_price_version_id
      LEFT JOIN vehicles v ON v.id = l.vehicle_id
      LEFT JOIN vehicle_trims t ON t.id = v.trim_id
      LEFT JOIN vehicle_models m ON m.id = t.model_id
      LEFT JOIN vehicle_makes k ON k.id = m.make_id
      LEFT JOIN organisations o ON o.id = l.organisation_id
      LEFT JOIN locations loc ON loc.id = l.location_id
      LEFT JOIN vehicle_current_reservations c ON c.vehicle_id = l.vehicle_id
      LEFT JOIN sale_reservations r ON r.id = c.sale_reservation_id
     WHERE l.id = ANY(:ids)""")


def summaries(session: Session, listings: list[Listing]) -> list[dict]:
    """Same shape as describe(include_history=False), built with ONE query for a page of listings."""
    if not listings:
        return []
    now = dt.datetime.now(dt.timezone.utc)
    rows = {r.id: r for r in session.execute(_SUMMARY_SQL, {"ids": [x.id for x in listings]})}
    out = []
    for lst in listings:
        r = rows[lst.id]
        d = row_dict(lst)
        d["price"] = (Money(r.amount_minor, r.price_currency).as_dict() | {"price_version_id": str(r.price_version_id)}) if r.amount_minor else None
        d["deposit"] = Money(lst.deposit_required_minor, lst.currency).as_dict()
        commitment = None
        if r.sale_reservation_id:
            commitment = jsonable({"sale_reservation_id": r.sale_reservation_id, "sale_order_id": r.sale_order_id,
                                   "hold_expires_at": r.hold_expires_at, "reservation_number": r.reservation_number,
                                   "status": r.reservation_status})
            if r.reservation_status == "held" and r.hold_expires_at and r.hold_expires_at <= now:
                commitment["effective_status"] = "expired"
        spec = ({"make": r.make, "model": r.model, "trim": r.trim, "model_year": r.model_year, "fuel_type": r.fuel_type,
                 "body_style": r.body_style, "label": f"{r.model_year} {r.make} {r.model} {r.trim}"} if r.trim else None)
        d["vehicle"] = {"id": str(r.vehicle_id), "specification": spec, "exterior_colour": r.exterior_colour,
                        "odometer_value": r.odometer_value, "odometer_unit": r.odometer_unit,
                        "availability_status": r.availability_status, "condition": r.condition,
                        "current_commitment": commitment, "vin": r.vin}
        d["seller"] = {"id": str(lst.organisation_id), "display_name": r.seller_name}
        d["location"] = {"id": str(lst.location_id), "name": r.location_name, "city": r.city, "timezone": r.timezone}
        out.append(d)
    return out


def create_listing(session: Session, p: Principal, data: dict) -> Listing:
    org_id = p.single_org_with("listings.write", data.get("organisation_id"))
    veh = get_or_404(session, Vehicle, data["vehicle_id"], label="vehicle")
    org = session.get(Organisation, org_id)
    currency = data.get("currency") or org.default_currency
    listing = Listing(id=uuid.uuid4(), organisation_id=org_id, vehicle_id=veh.id, location_id=data["location_id"],
                      channel=data.get("channel", "marketplace"), title=data["title"], description=data.get("description"),
                      sale_eligibility=data.get("sale_eligibility", "pending_review"), currency=currency,
                      deposit_required_minor=data.get("deposit_required_minor", 0),
                      source_namespace=data.get("source_namespace"), source_record_id=data.get("source_record_id"),
                      source_last_seen_at=data.get("source_last_seen_at"),
                      freshness_state="fresh" if data.get("source_last_seen_at") else "not_applicable",
                      created_by=p.user_id)
    session.add(listing)
    session.flush()
    if data.get("price") is not None:
        amount = data["price"] if isinstance(data["price"], int) else Money.parse(data["price"], currency).amount_minor
        pv = ListingPriceVersion(id=uuid.uuid4(), listing_id=listing.id, organisation_id=org_id, amount_minor=amount,
                                 currency=currency, reason="initial", source=data.get("price_source", "manual"),
                                 created_by=p.user_id)
        session.add(pv)
        session.flush()
        listing.current_price_version_id = pv.id
        session.flush()
    audit(session, "listing.created", "listing", listing.id, org_id,
          changes={"vehicle_id": veh.id, "title": listing.title, "price_minor": data.get("price")})
    emit(session, "listing.created", "listing", listing.id, org_id, {"listing_id": listing.id, "vehicle_id": veh.id})
    return listing


def update_listing(session: Session, p: Principal, listing_id, expected_version, patch: dict) -> Listing:
    listing = get_or_404(session, Listing, listing_id, lock=True, label="listing")
    p.require("listings.write", listing.organisation_id)
    check_version(listing, expected_version)
    bad = set(patch) - EDITABLE
    if bad:
        raise ValidationFailed(f"use domain actions for {sorted(bad)} (publish/suspend/withdraw/price)", code="field_not_editable")
    if listing.status in ("withdrawn", "sold"):
        raise Conflict(f"listing is {listing.status}", code="listing_closed")
    before = row_dict(listing)
    for k, v in patch.items():
        setattr(listing, k, v)
    session.flush()
    audit(session, "listing.updated", "listing", listing.id, listing.organisation_id, changes=diff(before, row_dict(listing)))
    return listing


def change_price(session: Session, p: Principal, listing_id, expected_version, amount_minor: int, reason: str,
                 source: str = "manual") -> Listing:
    listing = get_or_404(session, Listing, listing_id, lock=True, label="listing")
    p.require("listings.write", listing.organisation_id)
    if expected_version is not None:
        check_version(listing, expected_version)
    return _apply_price(session, listing, amount_minor, reason, source, p.user_id)


def _apply_price(session: Session, listing: Listing, amount_minor: int, reason: str, source: str, user_id) -> Listing:
    if listing.status in ("withdrawn", "sold"):
        raise Conflict(f"listing is {listing.status}", code="listing_closed")
    if amount_minor <= 0:
        raise ValidationFailed("price must be positive", code="invalid_price")
    cur = current_price(session, listing)
    if cur and cur.amount_minor == amount_minor:
        return listing
    # clock_timestamp(), not now(): two price versions created in one transaction
    # must still form non-empty, non-overlapping [from, to) periods.
    now = session.execute(select(func.clock_timestamp())).scalar_one()
    if cur:
        cur.effective_to = now
        session.flush()
    pv = ListingPriceVersion(id=uuid.uuid4(), listing_id=listing.id, organisation_id=listing.organisation_id,
                             amount_minor=amount_minor, currency=listing.currency, effective_from=now,
                             reason=reason if cur else "initial", source=source, created_by=user_id)
    session.add(pv)
    session.flush()
    listing.current_price_version_id = pv.id
    session.flush()
    audit(session, "listing.price_changed", "listing", listing.id, listing.organisation_id,
          changes={"price_minor": {"from": cur.amount_minor if cur else None, "to": amount_minor}, "reason": reason})
    emit(session, "listing.price_changed", "listing", listing.id, listing.organisation_id,
         {"listing_id": listing.id, "amount_minor": amount_minor, "currency": listing.currency})
    return listing


def validate_for_publication(session: Session, listing: Listing) -> list[dict]:
    f: list[dict] = []
    if current_price(session, listing) is None:
        f.append({"severity": "error", "field": "price", "code": "price_missing", "message": "listing has no asking price"})
    veh = session.get(Vehicle, listing.vehicle_id)
    vin = session.execute(select(VehicleIdentifier.id).where(VehicleIdentifier.vehicle_id == listing.vehicle_id,
                                                              VehicleIdentifier.namespace == "vin",
                                                              VehicleIdentifier.retired_at.is_(None))).first()
    if not vin:
        f.append({"severity": "error", "field": "vehicle.vin", "code": "vin_missing", "message": "vehicle has no active VIN identifier"})
    if veh and veh.availability_status != "available":
        f.append({"severity": "error", "field": "vehicle.availability_status", "code": "vehicle_not_available",
                  "message": f"vehicle is {veh.availability_status}"})
    if veh and veh.archived_at:
        f.append({"severity": "error", "field": "vehicle", "code": "vehicle_archived", "message": "vehicle is archived/merged"})
    if listing.sale_eligibility != "eligible":
        f.append({"severity": "error", "field": "sale_eligibility", "code": "not_sale_eligible",
                  "message": f"sale eligibility is {listing.sale_eligibility}"})
    loc = session.get(Location, listing.location_id)
    if loc and loc.status != "active":
        f.append({"severity": "error", "field": "location_id", "code": "location_closed", "message": "location is closed"})
    if listing.freshness_state == "expired":
        f.append({"severity": "error", "field": "source_last_seen_at", "code": "source_expired",
                  "message": "source feed has not confirmed this listing within the suspension window"})
    elif listing.freshness_state == "stale":
        f.append({"severity": "warning", "field": "source_last_seen_at", "code": "source_stale",
                  "message": "source feed confirmation is older than the warning threshold"})
    if veh and veh.trim_id is None:
        f.append({"severity": "warning", "field": "vehicle.trim_id", "code": "trim_unmatched",
                  "message": "vehicle is not matched to a catalogue trim"})
    if veh and veh.odometer_value is None:
        f.append({"severity": "warning", "field": "vehicle.odometer_value", "code": "odometer_unknown",
                  "message": "odometer reading is unknown"})
    if listing.effective_to and listing.effective_to <= dt.datetime.now(dt.timezone.utc):
        f.append({"severity": "error", "field": "effective_to", "code": "listing_period_ended", "message": "listing period has ended"})
    return f


def transition(session: Session, p: Principal, listing_id, expected_version, action: str, reason: str | None) -> Listing:
    listing = get_or_404(session, Listing, listing_id, lock=True, label="listing")
    perm = "listings.publish" if action == "publish" else "listings.write"
    p.require(perm, listing.organisation_id)
    check_version(listing, expected_version)
    target = {"publish": "published", "suspend": "suspended", "withdraw": "withdrawn"}[action]
    if action == "publish":
        findings = validate_for_publication(session, listing)
        errors = [x for x in findings if x["severity"] == "error"]
        if errors:
            raise ValidationFailed("listing cannot be published", code="publication_blocked", errors=findings)
    if listing.status == target:
        return listing
    allowed = {"publish": {"draft", "suspended"}, "suspend": {"published"}, "withdraw": {"draft", "published", "suspended"}}
    if listing.status not in allowed[action]:
        raise Conflict(f"cannot {action} a {listing.status} listing", code="invalid_status_transition")
    before = listing.status
    listing.status, listing.status_reason = target, reason
    session.flush()
    audit(session, f"listing.{target}", "listing", listing.id, listing.organisation_id,
          changes={"status": {"from": before, "to": target}, "reason": reason})
    emit(session, f"listing.{target}", "listing", listing.id, listing.organisation_id, {"listing_id": listing.id, "reason": reason})
    return listing


def bulk_publish(session: Session, p: Principal, listing_ids: list) -> list[dict]:
    out = []
    for lid in listing_ids:
        sp = session.begin_nested()
        try:
            lst = get_or_404(session, Listing, lid, label="listing")
            transition(session, p, lid, lst.version, "publish", "bulk_publish")
            sp.commit()
            out.append({"listing_id": str(lid), "result": "published"})
        except Exception as e:  # noqa: BLE001 - report per item
            sp.rollback()
            out.append({"listing_id": str(lid), "result": "rejected", "code": getattr(e, "code", "error"),
                        "detail": getattr(e, "detail", str(e)), "errors": getattr(e, "errors", [])})
    return out


def search(session: Session, *, status: str | None, organisation_id, make: str | None, model: str | None,
           min_price: int | None, max_price: int | None, q: str | None, lat: float | None, lon: float | None,
           radius_km: float | None, freshness: str | None, limit: int, cursor: str | None):
    pv = ListingPriceVersion
    stmt = select(Listing, pv.amount_minor).join(pv, pv.id == Listing.current_price_version_id, isouter=True)
    if status:
        stmt = stmt.where(Listing.status == status)
    if organisation_id:
        stmt = stmt.where(Listing.organisation_id == organisation_id)
    if freshness:
        stmt = stmt.where(Listing.freshness_state == freshness)
    if min_price is not None:
        stmt = stmt.where(pv.amount_minor >= min_price)
    if max_price is not None:
        stmt = stmt.where(pv.amount_minor <= max_price)
    if q:
        stmt = stmt.where(Listing.title.ilike(f"%{q}%"))
    if make or model:
        sub = select(Vehicle.id).join(VehicleTrim, VehicleTrim.id == Vehicle.trim_id).join(VehicleModel).join(VehicleMake)
        if make:
            sub = sub.where(func.lower(VehicleMake.name) == make.lower())
        if model:
            sub = sub.where(func.lower(VehicleModel.name) == model.lower())
        stmt = stmt.where(Listing.vehicle_id.in_(sub))
    if lat is not None and lon is not None and radius_km:
        # Two steps: an index-backed lookup of nearby (public) locations, then the
        # listing query with a constant id list the planner can estimate correctly.
        near = session.execute(select(func.locations_within(lon, lat, radius_km * 1000.0))).scalar() or []
        if not near:
            return [], None
        stmt = stmt.where(Listing.location_id.in_(near))
    # Radius results are small but the planner assumes uniform listings per location;
    # ordering by an equivalent non-indexable expression makes it filter by location
    # first and top-N sort the candidates instead of walking the whole date index.
    order_expr = (Listing.updated_at + dt.timedelta(0)) if (lat is not None and lon is not None and radius_km) else None
    rows, nxt = keyset_page(session, stmt, Listing.updated_at, Listing.id, limit=limit, cursor=cursor, parse=parse_dt,
                            order_expr=order_expr)
    items = summaries(session, [row[0] for row in rows])
    if lat is not None and lon is not None and items:
        dist = dict(session.execute(text(
            "SELECT id, ST_Distance(geog, ST_SetSRID(ST_MakePoint(:lon,:lat),4326)::geography) FROM locations WHERE id = ANY(:ids)"),
            {"lon": lon, "lat": lat, "ids": list({row[0].location_id for row in rows})}).all())
        for d, row in zip(items, rows):
            m = dist.get(row[0].location_id)
            d["distance_km"] = round(m / 1000.0, 2) if m is not None else None
    return items, nxt


def export_csv(session: Session, organisation_id=None, status: str | None = None) -> str:
    stmt = select(Listing).order_by(Listing.created_at)
    if organisation_id:
        stmt = stmt.where(Listing.organisation_id == organisation_id)
    if status:
        stmt = stmt.where(Listing.status == status)
    buf = io.StringIO()
    w = csv.writer(buf, quoting=csv.QUOTE_ALL)
    cols = ["listing_id", "status", "title", "vin", "price", "currency", "freshness_state", "location", "seller", "updated_at"]
    w.writerow(cols)
    for lst in session.execute(stmt).scalars():
        d = describe(session, lst)
        w.writerow([csv_safe(x) for x in [d["id"], d["status"], d["title"], (d.get("vehicle") or {}).get("vin"),
                                          d["price"]["formatted"] if d["price"] else "", d["currency"], d["freshness_state"],
                                          (d.get("location") or {}).get("name"), (d.get("seller") or {}).get("display_name"),
                                          d["updated_at"]]])
    return buf.getvalue()


def evaluate_freshness(session: Session, limit: int = 1000) -> dict:
    """Worker: mark source-fed listings stale, or suspend them per org policy.
    Never changes physical availability; never publishes."""
    now = session.execute(select(func.now())).scalar_one()
    stats = {"stale": 0, "suspended": 0, "fresh": 0}
    rows = session.execute(
        select(Listing, Organisation).join(Organisation, Organisation.id == Listing.organisation_id)
        .where(Listing.source_last_seen_at.is_not(None), Listing.status.in_(["published", "suspended", "draft"]))
        .order_by(Listing.source_last_seen_at).limit(limit).with_for_update(of=Listing, skip_locked=True)).all()
    for lst, org in rows:
        age = now - lst.source_last_seen_at
        if org.listing_freshness_suspend_after and age > org.listing_freshness_suspend_after:
            state = "expired"
        elif age > org.listing_freshness_warn_after:
            state = "stale"
        else:
            state = "fresh"
        if state != lst.freshness_state:
            lst.freshness_state = state
            stats["stale" if state != "fresh" else "fresh"] += 1
            emit(session, "listing.freshness_changed", "listing", lst.id, lst.organisation_id,
                 {"listing_id": lst.id, "freshness_state": state, "source_last_seen_at": lst.source_last_seen_at})
        if state == "expired" and org.listing_freshness_action == "suspend" and lst.status == "published":
            lst.status, lst.status_reason = "suspended", "source_stale:no_feed_confirmation"
            stats["suspended"] += 1
            audit(session, "listing.suspended", "listing", lst.id, lst.organisation_id,
                  changes={"status": {"from": "published", "to": "suspended"}, "reason": "source_stale"})
    session.flush()
    return stats
