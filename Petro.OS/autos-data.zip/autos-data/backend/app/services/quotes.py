"""Immutable quotes with itemised charges and point-in-time snapshots."""
from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import elevated
from app.errors import Forbidden, ValidationFailed
from app.models import (ChargeRule, Customer, CustomerRelationship, Listing, ListingPriceVersion, Location,
                        Organisation, Quote, QuoteAcceptance, QuoteLine, TermsVersion, Vehicle)
from app.money import Money
from app.security import Principal
from app.services.common import audit, ctx_of, emit, get_or_404, jsonable, keyset_page, parse_dt, row_dict, sha256_json

TERMS_CODE = "vehicle-sale-quote"


def ensure_relationship(session: Session, customer_id, org_id, basis: str) -> None:
    from sqlalchemy.dialects.postgresql import insert
    session.execute(insert(CustomerRelationship).values(customer_id=customer_id, organisation_id=org_id, basis=basis)
                    .on_conflict_do_nothing())


def _active_rules(session: Session, org_id, at, region):
    return session.execute(select(ChargeRule).where(
        ChargeRule.organisation_id == org_id, ChargeRule.effective_from <= at,
        or_(ChargeRule.effective_to.is_(None), ChargeRule.effective_to > at),
        or_(ChargeRule.region.is_(None), ChargeRule.region == region)).order_by(ChargeRule.charge_type, ChargeRule.code)).scalars().all()


def _current_terms(session: Session, at) -> TermsVersion:
    t = session.execute(select(TermsVersion).where(TermsVersion.code == TERMS_CODE, TermsVersion.effective_from <= at,
                                                   or_(TermsVersion.effective_to.is_(None), TermsVersion.effective_to > at))
                        .order_by(TermsVersion.version.desc())).scalars().first()
    if not t:
        raise ValidationFailed("no terms version in force", code="terms_missing")
    return t


def build_lines(*, currency: str, vehicle_price: int, rules: list, region: str | None, product_codes: set[str],
                promo_codes: set[str], delivery_requested: bool) -> tuple[list[dict], dict]:
    """Pure pricing function (unit-tested). Returns quote lines and header totals."""
    lines: list[dict] = [{"line_type": "vehicle_price", "code": "vehicle", "description": "Vehicle price",
                          "amount_status": "known", "amount_minor": vehicle_price}]
    for r in rules:
        if r.charge_type == "mandatory_fee":
            lines.append({"line_type": "mandatory_fee", "code": r.code, "description": r.label, "amount_status": "known",
                          "amount_minor": r.amount_minor if r.calculation == "fixed" else Money(vehicle_price, currency).apply_rate_bps(r.rate_bps).amount_minor,
                          "rate_bps": r.rate_bps, "source_rule_id": r.id})
    for r in rules:
        if r.charge_type == "optional_product" and r.code in product_codes:
            lines.append({"line_type": "optional_product", "code": r.code, "description": r.label, "amount_status": "known",
                          "amount_minor": r.amount_minor, "source_rule_id": r.id})
    for r in rules:
        if r.charge_type == "discount" and r.code in promo_codes:
            amt = r.amount_minor if r.calculation == "fixed" else -Money(vehicle_price, currency).apply_rate_bps(r.rate_bps).amount_minor
            lines.append({"line_type": "discount", "code": r.code, "description": r.label, "amount_status": "known",
                          "amount_minor": amt, "rate_bps": r.rate_bps, "source_rule_id": r.id})
    unknown_products = product_codes - {r.code for r in rules if r.charge_type == "optional_product"}
    unknown_promos = promo_codes - {r.code for r in rules if r.charge_type == "discount"}
    if unknown_products or unknown_promos:
        raise ValidationFailed("unknown product or promotion codes", code="unknown_reference",
                               errors=[{"field": "product_codes", "code": "unknown_code", "message": c} for c in sorted(unknown_products | unknown_promos)])
    fees = sum(x["amount_minor"] for x in lines if x["line_type"] == "mandatory_fee")
    products = sum(x["amount_minor"] for x in lines if x["line_type"] == "optional_product")
    discounts = sum(x["amount_minor"] for x in lines if x["line_type"] == "discount")
    subtotal = vehicle_price + fees + products + discounts
    if subtotal <= 0:
        raise ValidationFailed("discounts exceed the price", code="invalid_discount")

    def regional(kind):
        return [r for r in rules if r.charge_type == kind and region is not None and r.region == region]

    taxes = regional("tax")
    if region is None or not taxes:
        lines.append({"line_type": "tax", "code": "sales_tax", "description": "Sales tax (unknown until customer region and rule are known)",
                      "amount_status": "unknown", "amount_minor": None, "basis_minor": subtotal})
    else:
        for r in taxes:
            amt = Money(subtotal, currency).apply_rate_bps(r.rate_bps).amount_minor if r.calculation == "rate_bps" else r.amount_minor
            lines.append({"line_type": "tax", "code": r.code, "description": r.label, "amount_status": "known",
                          "amount_minor": amt, "rate_bps": r.rate_bps, "basis_minor": subtotal, "source_rule_id": r.id})
    regs = regional("registration")
    if regs:
        for r in regs:
            lines.append({"line_type": "registration", "code": r.code, "description": r.label, "amount_status": "known",
                          "amount_minor": r.amount_minor, "source_rule_id": r.id})
    else:
        lines.append({"line_type": "registration", "code": "registration", "description": "Registration and title (unknown)",
                      "amount_status": "unknown", "amount_minor": None})
    if delivery_requested:
        dels = regional("delivery") or [r for r in rules if r.charge_type == "delivery" and r.region is None]
        if dels:
            r = dels[0]
            lines.append({"line_type": "delivery", "code": r.code, "description": r.label, "amount_status": "known",
                          "amount_minor": r.amount_minor, "source_rule_id": r.id})
        else:
            lines.append({"line_type": "delivery", "code": "delivery", "description": "Delivery (unknown)",
                          "amount_status": "unknown", "amount_minor": None})
    else:
        lines.append({"line_type": "delivery", "code": "collection", "description": "Customer collects (no delivery)",
                      "amount_status": "not_applicable", "amount_minor": None})

    def total_of(kind):
        vals = [x for x in lines if x["line_type"] == kind]
        if any(x["amount_status"] == "unknown" for x in vals) or not vals or all(x["amount_status"] == "not_applicable" for x in vals):
            return None
        return sum(x["amount_minor"] for x in vals if x["amount_minor"] is not None)

    tax_total, reg_total, del_total = total_of("tax"), total_of("registration"), total_of("delivery")
    missing = sorted({x["line_type"] for x in lines if x["amount_status"] == "unknown"})
    total_known = subtotal + (tax_total or 0) + (reg_total or 0) + (del_total or 0)
    header = {"vehicle_price_minor": vehicle_price, "mandatory_fees_minor": fees, "optional_products_minor": products,
              "discounts_minor": discounts, "subtotal_before_tax_registration_minor": subtotal, "taxes_minor": tax_total,
              "registration_minor": reg_total, "delivery_minor": del_total, "total_known_minor": total_known,
              "total_minor": None if missing else total_known, "is_complete": not missing, "missing_charges": missing}
    for i, x in enumerate(lines, start=1):
        x["line_no"] = i
    return lines, header


def issue_quote(session: Session, p: Principal, data: dict) -> Quote:
    listing = get_or_404(session, Listing, data["listing_id"], label="listing")
    customer_id = data.get("customer_id")
    if p.is_customer:
        if customer_id and customer_id != p.customer_id:
            raise Forbidden("customers can only request quotes for themselves")
        customer_id = p.customer_id
        if listing.status != "published":
            raise ValidationFailed("listing is not published", code="listing_not_quotable")
    else:
        p.require("quotes.issue", listing.organisation_id)
    if listing.status not in ("published", "draft", "suspended") or listing.current_price_version_id is None:
        raise ValidationFailed("listing has no current price or is closed", code="listing_not_quotable")
    if not customer_id and not data.get("session_reference"):
        raise ValidationFailed("customer_id or session_reference is required", code="missing_value")

    org_ctx = ctx_of(session).scoped_to([listing.organisation_id])
    with elevated(session, org_ctx):
        now = session.execute(select(func.now())).scalar_one()
        pv = session.get(ListingPriceVersion, listing.current_price_version_id)
        org = session.get(Organisation, listing.organisation_id)
        veh = session.get(Vehicle, listing.vehicle_id)
        loc = session.get(Location, listing.location_id)
        rules = _active_rules(session, listing.organisation_id, now, data.get("customer_region"))
        lines, header = build_lines(currency=listing.currency, vehicle_price=pv.amount_minor, rules=rules,
                                    region=data.get("customer_region"), product_codes=set(data.get("product_codes") or []),
                                    promo_codes=set(data.get("promo_codes") or []),
                                    delivery_requested=bool(data.get("delivery_requested")))
        terms = _current_terms(session, now)
        from app.services.vehicles import describe as vdesc
        vd = vdesc(session, veh)
        snapshot = {
            "captured_at": now,
            "listing": {"id": listing.id, "title": listing.title, "channel": listing.channel, "status": listing.status,
                        "price_version_id": pv.id, "asking_price_minor": pv.amount_minor, "currency": pv.currency,
                        "price_effective_from": pv.effective_from, "deposit_required_minor": listing.deposit_required_minor},
            "vehicle": {"id": veh.id, "specification": vd.get("specification"), "model_year": veh.model_year,
                        "exterior_colour": veh.exterior_colour, "condition": veh.condition,
                        "odometer_value": veh.odometer_value, "odometer_unit": veh.odometer_unit,
                        "vin": next((i["value"] for i in vd["identifiers"] if i["namespace"] == "vin" and not i["retired_at"]), None)},
            "seller": {"id": org.id, "legal_name": org.legal_name, "display_name": org.display_name},
            "location": {"id": loc.id, "name": loc.name, "city": loc.city, "region": loc.region, "timezone": loc.timezone},
            "terms": {"code": terms.code, "version": terms.version, "body_sha256": terms.body_sha256},
        }
        snapshot = jsonable(snapshot)
        deposit = min(listing.deposit_required_minor, header["total_known_minor"])
        q = Quote(id=uuid.uuid4(), organisation_id=listing.organisation_id, listing_id=listing.id, vehicle_id=veh.id,
                  listing_price_version_id=pv.id, customer_id=customer_id, session_reference=data.get("session_reference"),
                  customer_region=data.get("customer_region"), currency=listing.currency, **header,
                  deposit_required_minor=deposit, deposit_treatment="applied_to_price" if deposit else "none",
                  terms_version_id=terms.id, snapshot=snapshot, snapshot_sha256=sha256_json(snapshot),
                  expires_at=now + dt.timedelta(hours=data.get("validity_hours") or get_settings().quote_validity_hours),
                  issued_by=p.user_id, request_id=ctx_of(session).request_id)
        session.add(q)
        session.flush()
        for x in lines:
            session.add(QuoteLine(quote_id=q.id, organisation_id=q.organisation_id, **{k: x.get(k) for k in (
                "line_no", "line_type", "code", "description", "amount_status", "amount_minor", "rate_bps", "basis_minor", "source_rule_id")}))
        if customer_id:
            ensure_relationship(session, customer_id, listing.organisation_id, "quote")
        session.flush()
        audit(session, "quote.issued", "quote", q.id, q.organisation_id,
              changes={"quote_number": q.quote_number, "total_known_minor": q.total_known_minor, "is_complete": q.is_complete,
                       "missing_charges": q.missing_charges})
        emit(session, "quote.issued", "quote", q.id, q.organisation_id, {"quote_id": q.id, "listing_id": listing.id})
    return q


def describe(session: Session, q: Quote) -> dict:
    d = row_dict(q)
    lines = session.execute(select(QuoteLine).where(QuoteLine.quote_id == q.id).order_by(QuoteLine.line_no)).scalars().all()
    d["lines"] = [row_dict(x) | ({"formatted": Money(x.amount_minor, q.currency).format()} if x.amount_minor is not None else {"formatted": None})
                  for x in lines]
    now = dt.datetime.now(dt.timezone.utc)
    d["is_expired"] = q.expires_at <= now
    d["effective_status"] = "expired" if (q.status == "issued" and d["is_expired"]) else q.status
    fmt = lambda v: Money(v, q.currency).format() if v is not None else None  # noqa: E731
    d["summary"] = {
        "vehicle_price": fmt(q.vehicle_price_minor), "mandatory_fees": fmt(q.mandatory_fees_minor),
        "optional_products": fmt(q.optional_products_minor), "discounts": fmt(q.discounts_minor),
        "subtotal_before_tax_registration": fmt(q.subtotal_before_tax_registration_minor),
        "taxes": fmt(q.taxes_minor), "registration": fmt(q.registration_minor), "delivery": fmt(q.delivery_minor),
        "total": fmt(q.total_minor), "total_known_so_far": fmt(q.total_known_minor),
        "deposit_required": fmt(q.deposit_required_minor),
        "deposit_note": "The deposit is part of the total, not an additional charge." if q.deposit_required_minor else None,
        "balance_after_deposit": fmt(q.total_minor - q.deposit_required_minor) if q.total_minor is not None else None,
    }
    acc = session.execute(select(QuoteAcceptance).where(QuoteAcceptance.quote_id == q.id)).scalar_one_or_none()
    d["acceptance"] = row_dict(acc) if acc else None
    d["snapshot_verified"] = sha256_json(q.snapshot) == q.snapshot_sha256
    return d


def accept_quote(session: Session, p: Principal, quote_id, channel: str) -> QuoteAcceptance:
    q = get_or_404(session, Quote, quote_id, label="quote")
    if p.is_customer:
        if q.customer_id != p.customer_id:
            raise Forbidden("not your quote")
    else:
        p.require("quotes.issue", q.organisation_id)
    if q.customer_id is None:
        raise ValidationFailed("anonymous (session) quotes must be re-issued to a customer before acceptance", code="quote_not_acceptable")
    with elevated(session, ctx_of(session).scoped_to([q.organisation_id])):
        acc = QuoteAcceptance(quote_id=q.id, organisation_id=q.organisation_id, customer_id=q.customer_id,
                              terms_version_id=q.terms_version_id, acceptance_channel=channel, request_id=ctx_of(session).request_id)
        session.add(acc)
        session.flush()
        audit(session, "quote.accepted", "quote", q.id, q.organisation_id, changes={"channel": channel})
        emit(session, "quote.accepted", "quote", q.id, q.organisation_id, {"quote_id": q.id})
    return acc


def list_quotes(session: Session, *, organisation_id, customer_id, limit, cursor):
    stmt = select(Quote)
    if organisation_id:
        stmt = stmt.where(Quote.organisation_id == organisation_id)
    if customer_id:
        stmt = stmt.where(Quote.customer_id == customer_id)
    rows, nxt = keyset_page(session, stmt, Quote.issued_at, Quote.id, limit=limit, cursor=cursor, parse=parse_dt)
    return [describe(session, r[0]) for r in rows], nxt
