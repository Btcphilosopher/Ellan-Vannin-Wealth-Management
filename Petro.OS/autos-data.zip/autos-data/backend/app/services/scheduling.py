"""Test-drive appointments and rentals (category bookings, assignments, maintenance)."""
from __future__ import annotations

import datetime as dt
import math
import uuid
from zoneinfo import ZoneInfo

from sqlalchemy import func, select, text
from sqlalchemy.dialects.postgresql import Range
from sqlalchemy.orm import Session

from app.db import elevated
from app.errors import Conflict, Forbidden, ValidationFailed
from app.models import (AppointmentResource, Listing, Location, MaintenanceBlock, RentalAsset, RentalAssetAssignment,
                        RentalBooking, RentalCategory, RentalQuote, TestDriveAppointment, Vehicle)
from app.money import Money
from app.security import Principal
from app.services.common import audit, check_version, ctx_of, emit, get_or_404, keyset_page, parse_dt, row_dict
from app.services.quotes import ensure_relationship


def local_view(instant: dt.datetime | None, tz: str) -> str | None:
    return instant.astimezone(ZoneInfo(tz)).isoformat() if instant else None


def _require_aware(*values: dt.datetime) -> None:
    for v in values:
        if v.tzinfo is None:
            raise ValidationFailed("timestamps must include a UTC offset (ISO 8601, e.g. 2026-12-01T10:00:00-05:00)",
                                   code="naive_timestamp")


# ============================================================================ test drives
def describe_drive(a: TestDriveAppointment) -> dict:
    d = row_dict(a)
    d["local_start"] = local_view(a.starts_at, a.local_timezone)
    d["local_end"] = local_view(a.ends_at, a.local_timezone)
    return d


def request_test_drive(session: Session, p: Principal, data: dict, idempotency_key: str | None) -> TestDriveAppointment:
    veh = get_or_404(session, Vehicle, data["vehicle_id"], label="vehicle")
    res = None
    org_id = data.get("organisation_id")
    if data.get("listing_id"):
        lst = get_or_404(session, Listing, data["listing_id"], label="listing")
        org_id = lst.organisation_id
        if lst.vehicle_id != veh.id:
            raise ValidationFailed("listing does not offer this vehicle", code="invalid_reference")
    org_id = org_id or veh.custodian_organisation_id
    customer_id = data.get("customer_id")
    if p.is_customer:
        if customer_id and customer_id != p.customer_id:
            raise Forbidden("customers can only book for themselves")
        customer_id = p.customer_id
    else:
        p.require("test_drives.manage", org_id)
    _require_aware(data["starts_at"], data["ends_at"])
    if veh.availability_status != "available":
        raise Conflict(f"vehicle is {veh.availability_status}", code="vehicle_not_available")
    with elevated(session, ctx_of(session).scoped_to([org_id])):
        if idempotency_key:
            ex = session.execute(select(TestDriveAppointment).where(TestDriveAppointment.organisation_id == org_id,
                                                                    TestDriveAppointment.idempotency_key == idempotency_key)).scalar_one_or_none()
            if ex:
                return ex
        res = get_or_404(session, AppointmentResource, data["resource_id"], label="appointment resource")
        a = TestDriveAppointment(id=uuid.uuid4(), organisation_id=org_id, location_id=res.location_id, vehicle_id=veh.id,
                                 listing_id=data.get("listing_id"), customer_id=customer_id, resource_id=res.id,
                                 starts_at=data["starts_at"], ends_at=data["ends_at"], local_timezone="UTC",
                                 idempotency_key=idempotency_key)
        session.add(a)
        session.flush()
        ensure_relationship(session, customer_id, org_id, "test_drive")
        audit(session, "test_drive.requested", "test_drive_appointment", a.id, org_id,
              changes={"vehicle_id": veh.id, "starts_at": a.starts_at, "ends_at": a.ends_at})
        emit(session, "test_drive.requested", "test_drive_appointment", a.id, org_id, {"appointment_id": a.id})
    session.refresh(a)
    if data.get("confirm") and not p.is_customer:
        return drive_action(session, p, a.id, a.version, "confirm", None)
    return a


def drive_action(session: Session, p: Principal, appointment_id, expected_version, action: str, reason: str | None) -> TestDriveAppointment:
    a = get_or_404(session, TestDriveAppointment, appointment_id, lock=True, label="test drive")
    if p.is_customer:
        if a.customer_id != p.customer_id or action != "cancel":
            raise Forbidden("customers may only cancel their own appointment")
    else:
        p.require("test_drives.manage", a.organisation_id)
        check_version(a, expected_version)
    before = a.confirmation_status
    with elevated(session, ctx_of(session).scoped_to([a.organisation_id])):
        if action == "confirm":
            veh = session.get(Vehicle, a.vehicle_id)
            if veh.availability_status != "available":
                raise Conflict(f"vehicle is {veh.availability_status}", code="vehicle_not_available")
            a.request_status, a.confirmation_status = "accepted", "confirmed"
        elif action == "decline":
            a.request_status = "declined"
            if a.confirmation_status == "unconfirmed":
                a.confirmation_status = "cancelled"
                a.cancelled_at, a.cancelled_by_kind, a.cancellation_reason = func.now(), "dealer", reason or "declined"
        elif action == "cancel":
            a.confirmation_status = "cancelled"
            a.cancelled_at, a.cancelled_by_kind = func.now(), "customer" if p.is_customer else "dealer"
            a.cancellation_reason = reason or "cancelled"
            if a.request_status == "requested":
                a.request_status = "withdrawn" if p.is_customer else "declined"
        elif action in ("complete", "no_show"):
            a.confirmation_status = "completed" if action == "complete" else "no_show"
        else:
            raise ValidationFailed("unknown action")
        session.flush()
        session.refresh(a)
        audit(session, f"test_drive.{action}", "test_drive_appointment", a.id, a.organisation_id,
              changes={"confirmation_status": {"from": before, "to": a.confirmation_status}, "reason": reason})
        emit(session, f"test_drive.{action}", "test_drive_appointment", a.id, a.organisation_id, {"appointment_id": a.id})
    return a


# ============================================================================ rentals
def rental_days(pickup: dt.datetime, ret: dt.datetime) -> int:
    """Number of started 24-hour periods (absolute time, so DST changes never
    create or lose a billable day)."""
    seconds = (ret - pickup).total_seconds()
    if seconds <= 0:
        raise ValidationFailed("return must be after pickup", code="invalid_period")
    return max(1, math.ceil(seconds / 86400))


def quote_rental(session: Session, p: Principal, data: dict) -> RentalQuote:
    _require_aware(data["pickup_at"], data["return_at"])
    cat = get_or_404(session, RentalCategory, data["category_id"], label="rental category")
    loc = get_or_404(session, Location, data["location_id"], label="location")
    if loc.organisation_id != cat.organisation_id:
        raise ValidationFailed("location and category belong to different suppliers", code="invalid_reference")
    days = rental_days(data["pickup_at"], data["return_at"])
    customer_id = p.customer_id if p.is_customer else data.get("customer_id")
    with elevated(session, ctx_of(session).scoped_to([cat.organisation_id])):
        now = session.execute(select(func.now())).scalar_one()
        q = RentalQuote(id=uuid.uuid4(), organisation_id=cat.organisation_id, location_id=loc.id, category_id=cat.id,
                        customer_id=customer_id, pickup_at=data["pickup_at"], return_at=data["return_at"],
                        local_timezone=loc.timezone, rental_days=days, daily_rate_minor=cat.daily_rate_minor,
                        total_minor=days * cat.daily_rate_minor, currency=cat.currency, expires_at=now + dt.timedelta(hours=2))
        session.add(q)
        session.flush()
    return q


def create_booking(session: Session, p: Principal, data: dict, idempotency_key: str | None) -> RentalBooking:
    if data.get("rental_quote_id"):
        rq = get_or_404(session, RentalQuote, data["rental_quote_id"], label="rental quote")
        data = {**data, "category_id": rq.category_id, "location_id": rq.location_id, "pickup_at": rq.pickup_at,
                "return_at": rq.return_at}
        total, currency, org_id = rq.total_minor, rq.currency, rq.organisation_id
    else:
        rq = None
        cat = get_or_404(session, RentalCategory, data["category_id"], label="rental category")
        _require_aware(data["pickup_at"], data["return_at"])
        total = rental_days(data["pickup_at"], data["return_at"]) * cat.daily_rate_minor
        currency, org_id = cat.currency, cat.organisation_id
    customer_id = data.get("customer_id")
    if p.is_customer:
        customer_id = p.customer_id
    else:
        p.require("rentals.book", org_id)
    if not customer_id:
        raise ValidationFailed("customer_id is required", code="missing_value")
    with elevated(session, ctx_of(session).scoped_to([org_id])):
        if idempotency_key:
            ex = session.execute(select(RentalBooking).where(RentalBooking.organisation_id == org_id,
                                                             RentalBooking.idempotency_key == idempotency_key)).scalar_one_or_none()
            if ex:
                return ex
        b = RentalBooking(id=uuid.uuid4(), organisation_id=org_id, customer_id=customer_id, category_id=data["category_id"],
                          pickup_location_id=data["location_id"], return_location_id=data.get("return_location_id") or data["location_id"],
                          rental_quote_id=rq.id if rq else None, pickup_at=data["pickup_at"], return_at=data["return_at"],
                          pickup_timezone="UTC", return_timezone="UTC", total_minor=total, currency=currency,
                          idempotency_key=idempotency_key, created_by=p.user_id)
        session.add(b)
        session.flush()  # capacity trigger: locks the inventory bucket, checks peak demand
        ensure_relationship(session, customer_id, org_id, "rental")
        audit(session, "rental_booking.confirmed", "rental_booking", b.id, org_id,
              changes={"category_id": b.category_id, "pickup_at": b.pickup_at, "return_at": b.return_at, "total_minor": total})
        emit(session, "rental_booking.confirmed", "rental_booking", b.id, org_id, {"booking_id": b.id})
        if data.get("rental_asset_id"):
            assign_asset(session, p, b.id, data["rental_asset_id"], is_upgrade=bool(data.get("is_upgrade")))
    session.refresh(b)
    return b


def assign_asset(session: Session, p: Principal, booking_id, asset_id=None, *, is_upgrade: bool = False) -> RentalAssetAssignment:
    b = get_or_404(session, RentalBooking, booking_id, label="rental booking")
    if not p.is_customer:
        p.require("rentals.book", b.organisation_id)
    with elevated(session, ctx_of(session).scoped_to([b.organisation_id])):
        if asset_id is None:
            buf = session.execute(select(RentalCategory.turnaround_buffer).where(RentalCategory.id == b.category_id)).scalar_one()
            asset_id = session.execute(text("""
                SELECT a.id FROM rental_assets a
                 WHERE a.home_location_id = :loc AND a.category_id = :cat AND a.status = 'active'
                   AND NOT EXISTS (SELECT 1 FROM rental_asset_assignments x WHERE x.rental_asset_id = a.id AND x.status = 'active'
                                     AND x.occupied && tstzrange(:p, CAST(:r AS timestamptz) + CAST(:buf AS interval), '[)'))
                   AND NOT EXISTS (SELECT 1 FROM maintenance_blocks m WHERE m.rental_asset_id = a.id AND m.status IN ('planned','active')
                                     AND m.block_range && tstzrange(:p, CAST(:r AS timestamptz) + CAST(:buf AS interval), '[)'))
                 ORDER BY a.fleet_number LIMIT 1"""),
                {"loc": b.pickup_location_id, "cat": b.category_id, "p": b.pickup_at, "r": b.return_at, "buf": buf}).scalar()
            if asset_id is None:
                raise Conflict("no free asset in this category for the booking period", code="rental_asset_conflict")
        # occupied is recomputed authoritatively by the BEFORE INSERT trigger as
        # [pickup_at, return_at + turnaround_buffer); the value sent here is a placeholder.
        x = RentalAssetAssignment(organisation_id=b.organisation_id, rental_booking_id=b.id, rental_asset_id=asset_id,
                                  occupied=Range(b.pickup_at, b.return_at, bounds="[)"), is_upgrade=is_upgrade, assigned_by=p.user_id)
        session.add(x)
        session.flush()
        session.refresh(x)
        audit(session, "rental_booking.asset_assigned", "rental_booking", b.id, b.organisation_id,
              changes={"rental_asset_id": asset_id, "occupied": x.occupied})
        emit(session, "rental_booking.asset_assigned", "rental_booking", b.id, b.organisation_id,
             {"booking_id": b.id, "rental_asset_id": asset_id})
    return x


def booking_action(session: Session, p: Principal, booking_id, expected_version, action: str, reason: str | None) -> RentalBooking:
    b = get_or_404(session, RentalBooking, booking_id, lock=True, label="rental booking")
    if p.is_customer:
        if b.customer_id != p.customer_id or action != "cancel":
            raise Forbidden("customers may only cancel their own booking")
    else:
        p.require("rentals.book", b.organisation_id)
        check_version(b, expected_version)
    target = {"cancel": "cancelled", "check_out": "checked_out", "return": "returned", "no_show": "no_show"}[action]
    with elevated(session, ctx_of(session).scoped_to([b.organisation_id])):
        before = b.status
        b.status = target
        if target == "cancelled":
            b.cancellation_reason = reason or "cancelled"
        session.flush()
        session.refresh(b)
        audit(session, f"rental_booking.{target}", "rental_booking", b.id, b.organisation_id,
              changes={"status": {"from": before, "to": target}, "reason": reason})
        emit(session, f"rental_booking.{target}", "rental_booking", b.id, b.organisation_id, {"booking_id": b.id})
    return b


def create_maintenance(session: Session, p: Principal, data: dict) -> MaintenanceBlock:
    asset = get_or_404(session, RentalAsset, data["rental_asset_id"], label="rental asset")
    p.require("rentals.manage", asset.organisation_id)
    _require_aware(data["starts_at"], data["ends_at"])
    m = MaintenanceBlock(organisation_id=asset.organisation_id, rental_asset_id=asset.id, kind=data["kind"],
                         starts_at=data["starts_at"], ends_at=data["ends_at"], reason=data["reason"],
                         status=data.get("status", "planned"), created_by=p.user_id)
    session.add(m)
    session.flush()
    session.refresh(m)
    audit(session, "maintenance.created", "maintenance_block", m.id, m.organisation_id,
          changes={"rental_asset_id": asset.id, "starts_at": m.starts_at, "ends_at": m.ends_at, "kind": m.kind})
    return m


def availability(session: Session, location_id, category_id, pickup: dt.datetime, ret: dt.datetime) -> dict:
    buf = session.execute(select(RentalCategory.turnaround_buffer).where(RentalCategory.id == category_id)).scalar_one()
    r = session.execute(text("SELECT * FROM rental_bucket_capacity(:l, :c, tstzrange(:p, CAST(:r AS timestamptz) + CAST(:b AS interval), '[)'))"),
                        {"l": location_id, "c": category_id, "p": pickup, "r": ret, "b": buf}).mappings().one()
    return {"peak_demand": r["peak"], "available_vehicles": r["available"], "can_book": r["peak"] < r["available"],
            "turnaround_buffer_seconds": int(buf.total_seconds())}


def describe_booking(session: Session, b: RentalBooking) -> dict:
    d = row_dict(b)
    d["local_pickup"] = local_view(b.pickup_at, b.pickup_timezone)
    d["local_return"] = local_view(b.return_at, b.return_timezone)
    d["total"] = Money(b.total_minor, b.currency).as_dict()
    d["assignments"] = [row_dict(x) for x in session.execute(select(RentalAssetAssignment).where(
        RentalAssetAssignment.rental_booking_id == b.id).order_by(RentalAssetAssignment.assigned_at)).scalars()]
    return d
