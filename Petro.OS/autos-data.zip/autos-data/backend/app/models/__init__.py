from app.models.base import Base  # noqa: F401
from app.models.tables import *  # noqa: F401,F403
