"""Engine, sessions and per-transaction tenant context.

Every transaction begins by calling set_config(..., is_local => true) for
the RLS context variables. Because they are transaction-local they are
discarded at COMMIT/ROLLBACK, so a pooled connection handed to the next
request carries no tenant context (tests/test_tenant_isolation.py proves
this with a pool of size 1).
"""
from __future__ import annotations

import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from typing import Iterator

from sqlalchemy import create_engine, event, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from app.config import get_settings


@dataclass(frozen=True)
class DbContext:
    """What PostgreSQL row-level security sees for one transaction."""

    org_ids: tuple[uuid.UUID, ...] = ()
    is_platform: bool = False
    user_id: uuid.UUID | None = None
    customer_id: uuid.UUID | None = None
    actor_kind: str = "user"
    request_id: str | None = None
    extra: dict = field(default_factory=dict)

    def scoped_to(self, org_ids) -> "DbContext":
        """Narrow/elevate tenant scope for a domain operation the API has authorised."""
        return replace(self, org_ids=tuple(org_ids))

    @staticmethod
    def system(request_id: str | None = None, actor_kind: str = "system") -> "DbContext":
        return DbContext(is_platform=True, actor_kind=actor_kind, request_id=request_id)


_SET_CONTEXT = text(
    "SELECT set_config('app.org_ids', :orgs, true), set_config('app.is_platform', :plat, true),"
    " set_config('app.user_id', :uid, true), set_config('app.customer_id', :cid, true),"
    " set_config('app.actor_kind', :ak, true), set_config('app.request_id', :rid, true),"
    " set_config('statement_timeout', :st, true), set_config('lock_timeout', :lt, true)"
)


def _context_params(ctx: DbContext) -> dict:
    s = get_settings()
    return {
        "orgs": "{" + ",".join(str(o) for o in ctx.org_ids) + "}",
        "plat": "on" if ctx.is_platform else "off",
        "uid": str(ctx.user_id) if ctx.user_id else "",
        "cid": str(ctx.customer_id) if ctx.customer_id else "",
        "ak": ctx.actor_kind,
        "rid": ctx.request_id or "",
        "st": str(s.db_statement_timeout_ms),
        "lt": str(s.db_lock_timeout_ms),
    }


def apply_context(session: Session, ctx: DbContext) -> None:
    session.info["db_ctx"] = ctx
    session.execute(_SET_CONTEXT, _context_params(ctx))


_engine: Engine | None = None
_sessionmaker: sessionmaker | None = None


def get_engine() -> Engine:
    global _engine, _sessionmaker
    if _engine is None:
        s = get_settings()
        _engine = create_engine(
            s.database_url,
            pool_size=s.db_pool_size,
            max_overflow=s.db_max_overflow,
            pool_pre_ping=True,
            pool_reset_on_return="rollback",
        )
        _sessionmaker = sessionmaker(_engine, expire_on_commit=False, autoflush=True)
    return _engine


def reset_engine(engine: Engine | None = None) -> None:
    """Swap the engine (tests)."""
    global _engine, _sessionmaker
    if _engine is not None and _engine is not engine:
        _engine.dispose()
    _engine = engine
    _sessionmaker = sessionmaker(engine, expire_on_commit=False, autoflush=True) if engine else None


def new_session() -> Session:
    get_engine()
    assert _sessionmaker is not None
    return _sessionmaker()


@event.listens_for(Session, "after_begin")
def _reapply_context(session: Session, transaction, connection) -> None:
    # Any new transaction on a session that carries a context gets it again.
    ctx = session.info.get("db_ctx")
    if ctx is not None:
        connection.execute(_SET_CONTEXT, _context_params(ctx))


@contextmanager
def session_scope(ctx: DbContext) -> Iterator[Session]:
    """Unit of work: commit on success, rollback on error."""
    session = new_session()
    session.info["db_ctx"] = ctx
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


@contextmanager
def elevated(session: Session, ctx: DbContext) -> Iterator[None]:
    """Temporarily switch the RLS context within the current transaction."""
    previous = session.info.get("db_ctx")
    apply_context(session, ctx)
    try:
        yield
    except Exception:
        # The transaction is aborted; don't touch it (that would mask the real
        # error). Restore the stored context so the next transaction re-applies it.
        if previous is not None:
            session.info["db_ctx"] = previous
        raise
    if previous is not None:
        apply_context(session, previous)
