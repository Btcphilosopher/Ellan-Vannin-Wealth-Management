"""Background workers.

    python -m app.workers            # run all loops
    python -m app.workers --once     # one iteration of every job (cron / tests)

Every job is idempotent and safe to run on several replicas concurrently
(FOR UPDATE SKIP LOCKED / row locks); none is required for correctness of
reservations, which expire inline under the vehicle lock.
"""
from __future__ import annotations

import argparse
import logging
import time
import traceback

from sqlalchemy import select

from app.db import DbContext, apply_context, new_session
from app.models import ImportJob
from app.services import imports, listings, operations, payments, sales

log = logging.getLogger("autos.worker")

JOBS = {
    "reservation_expiry": (15, lambda s: {"expired": sales.expire_due(s)}),
    "outbox_dispatch": (2, lambda s: operations.dispatch_outbox(s)),
    "payment_reconciliation": (30, lambda s: payments.reconcile_unknown(s)),
    "listing_freshness": (300, lambda s: listings.evaluate_freshness(s)),
    "import_processing": (5, lambda s: process_imports(s)),
}


def process_imports(session) -> dict:
    """Apply approved jobs left by an interrupted request (bounded retries)."""
    done = 0
    rows = session.execute(select(ImportJob).where(ImportJob.status.in_(["approved", "applying"]), ImportJob.attempts < 3)
                           .with_for_update(skip_locked=True).limit(5)).scalars().all()
    for job in rows:
        imports.apply(session, job, job.approved_by)
        done += 1
    return {"applied_jobs": done}


def run_job(name: str) -> dict:
    s = new_session()
    try:
        apply_context(s, DbContext.system(actor_kind="system"))
        result = JOBS[name][1](s)
        apply_context(s, DbContext.system(actor_kind="system"))
        operations.heartbeat(s, name, {"last_result": result})
        s.commit()
        return result
    except Exception:  # noqa: BLE001 - worker must survive; failure is visible in heartbeat
        s.rollback()
        try:
            apply_context(s, DbContext.system(actor_kind="system"))
            operations.heartbeat(s, name, {"error": traceback.format_exc(limit=3)[-800:]})
            s.commit()
        except Exception:  # noqa: BLE001
            s.rollback()
        log.exception("job %s failed", name)
        return {"error": True}
    finally:
        s.close()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--only", nargs="*")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    names = args.only or list(JOBS)
    if args.once:
        for n in names:
            print(n, run_job(n))
        return
    next_run = {n: 0.0 for n in names}
    while True:
        now = time.monotonic()
        for n in names:
            if now >= next_run[n]:
                run_job(n)
                next_run[n] = now + JOBS[n][0]
        time.sleep(0.5)


if __name__ == "__main__":
    main()
