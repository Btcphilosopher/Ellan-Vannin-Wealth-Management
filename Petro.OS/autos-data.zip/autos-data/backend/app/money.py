"""Money in integer minor units with explicit currency.

Floats are never used. Decimal is used only at the boundary (parsing
"32900.00" from a CSV, formatting for display).
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import ROUND_HALF_EVEN, ROUND_HALF_UP, Decimal, InvalidOperation

# Mirrors the currencies table (seeded in 0001). Kept in code so parsing
# can validate without a round trip; tests assert the two agree.
MINOR_UNITS: dict[str, int] = {"USD": 2, "CAD": 2, "EUR": 2, "GBP": 2, "AUD": 2, "JPY": 0, "BHD": 3}


class MoneyError(ValueError):
    pass


def exponent(currency: str) -> int:
    try:
        return MINOR_UNITS[currency]
    except KeyError as e:
        raise MoneyError(f"unsupported currency {currency!r}") from e


@dataclass(frozen=True, slots=True)
class Money:
    amount_minor: int
    currency: str

    def __post_init__(self):
        if not isinstance(self.amount_minor, int) or isinstance(self.amount_minor, bool):
            raise MoneyError("amount_minor must be an int")
        exponent(self.currency)

    # --- construction -------------------------------------------------
    @classmethod
    def parse(cls, value: str | int | Decimal, currency: str) -> "Money":
        """Parse a major-unit decimal string ("32,900.00") exactly. Rejects excess precision."""
        if isinstance(value, float):
            raise MoneyError("floats are not accepted for money")
        exp = exponent(currency)
        try:
            d = Decimal(str(value).replace(",", "").strip())
        except InvalidOperation as e:
            raise MoneyError(f"not a number: {value!r}") from e
        if not d.is_finite():
            raise MoneyError("amount must be finite")
        scaled = d.scaleb(exp)
        if scaled != scaled.to_integral_value():
            raise MoneyError(f"{value!r} has more than {exp} decimal places for {currency}")
        return cls(int(scaled), currency)

    @classmethod
    def zero(cls, currency: str) -> "Money":
        return cls(0, currency)

    # --- arithmetic ---------------------------------------------------
    def _same(self, other: "Money") -> None:
        if self.currency != other.currency:
            raise MoneyError(f"currency mismatch {self.currency} vs {other.currency}")

    def __add__(self, other: "Money") -> "Money":
        self._same(other)
        return Money(self.amount_minor + other.amount_minor, self.currency)

    def __sub__(self, other: "Money") -> "Money":
        self._same(other)
        return Money(self.amount_minor - other.amount_minor, self.currency)

    def __neg__(self) -> "Money":
        return Money(-self.amount_minor, self.currency)

    def __lt__(self, other: "Money") -> bool:
        self._same(other)
        return self.amount_minor < other.amount_minor

    def __le__(self, other: "Money") -> bool:
        self._same(other)
        return self.amount_minor <= other.amount_minor

    def apply_rate_bps(self, rate_bps: int, rounding=ROUND_HALF_UP) -> "Money":
        """amount * rate_bps / 10000 rounded to the minor unit (half-up by default, as most tax tables use)."""
        if rate_bps < 0:
            raise MoneyError("rate must be non-negative")
        q = (Decimal(self.amount_minor) * Decimal(rate_bps) / Decimal(10000)).quantize(Decimal(1), rounding=rounding)
        return Money(int(q), self.currency)

    def allocate(self, ratios: list[int]) -> list["Money"]:
        """Split without losing minor units (largest-remainder)."""
        total = sum(ratios)
        if total <= 0:
            raise MoneyError("ratios must sum to a positive number")
        shares = [self.amount_minor * r // total for r in ratios]
        remainder = self.amount_minor - sum(shares)
        order = sorted(range(len(ratios)), key=lambda i: (self.amount_minor * ratios[i]) % total, reverse=True)
        for i in order[:remainder]:
            shares[i] += 1
        return [Money(s, self.currency) for s in shares]

    # --- presentation -------------------------------------------------
    def to_decimal(self) -> Decimal:
        return Decimal(self.amount_minor).scaleb(-exponent(self.currency))

    def format(self) -> str:
        exp = exponent(self.currency)
        d = self.to_decimal().quantize(Decimal(1).scaleb(-exp), rounding=ROUND_HALF_EVEN)
        symbol = {"USD": "$", "CAD": "CA$", "EUR": "€", "GBP": "£", "AUD": "A$", "JPY": "¥"}.get(self.currency)
        body = f"{abs(d):,.{exp}f}"
        sign = "-" if d < 0 else ""
        return f"{sign}{symbol}{body}" if symbol else f"{sign}{body} {self.currency}"

    def as_dict(self) -> dict:
        return {"amount_minor": self.amount_minor, "currency": self.currency, "formatted": self.format()}
