"""Pydantic request contracts (validated at the API boundary; the database re-validates)."""
from __future__ import annotations

import datetime as dt
import uuid
from typing import Any, Literal

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, field_validator


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Problem(BaseModel):
    """RFC 9457 problem details."""
    type: str
    title: str
    status: int
    code: str
    detail: str
    request_id: str | None = None
    errors: list[dict[str, Any]] | None = None


class Page(BaseModel):
    items: list[dict[str, Any]]
    next_cursor: str | None = None


class TokenRequest(Strict):
    email: str = Field(examples=["admin@harbourview.example"])


class IdentifierIn(Strict):
    namespace: str = Field(pattern=r"^[a-z][a-z0-9_.:-]{1,63}$")
    value: str = Field(min_length=1, max_length=64)
    issuing_organisation_id: uuid.UUID | None = None


class VehicleCreate(Strict):
    custodian_organisation_id: uuid.UUID | None = None
    vin: str | None = Field(default=None, min_length=17, max_length=21)
    trim_id: uuid.UUID | None = None
    current_location_id: uuid.UUID | None = None
    model_year: int | None = Field(default=None, ge=1950, le=2100)
    exterior_colour: str | None = None
    interior_colour: str | None = None
    condition: Literal["new", "used", "certified_pre_owned", "unknown"] | None = None
    odometer_value: int | None = Field(default=None, ge=0, description="NULL/omitted = unknown; 0 is a real reading")
    odometer_unit: Literal["km", "mi"] | None = None
    has_open_recall: bool | None = Field(default=None, description="NULL = not checked")
    keys_count: int | None = Field(default=None, ge=0)
    identifiers: list[IdentifierIn] = []

    @field_validator("odometer_unit")
    @classmethod
    def _unit(cls, v, info):
        if info.data.get("odometer_value") is not None and v is None:
            raise ValueError("odometer_unit is required when odometer_value is given")
        return v


class VehiclePatch(Strict):
    trim_id: uuid.UUID | None = None
    current_location_id: uuid.UUID | None = None
    model_year: int | None = Field(default=None, ge=1950, le=2100)
    exterior_colour: str | None = None
    interior_colour: str | None = None
    condition: Literal["new", "used", "certified_pre_owned", "unknown"] | None = None
    odometer_value: int | None = Field(default=None, ge=0)
    odometer_unit: Literal["km", "mi"] | None = None
    has_open_recall: bool | None = None
    keys_count: int | None = Field(default=None, ge=0)
    availability_status: Literal["available", "in_transit", "unavailable"] | None = None


class AssertionIn(Strict):
    attribute: str = Field(pattern=r"^[a-z][a-z0-9_]{1,63}$")
    assertion_type: Literal["manufacturer", "seller_claim", "inspection_finding", "registry"]
    value: Any
    unit: str | None = None
    source: str
    source_reference: str | None = None
    effective_at: AwareDatetime | None = None
    verification_status: Literal["unverified", "verified", "disputed"] = "unverified"


class ListingCreate(Strict):
    organisation_id: uuid.UUID | None = None
    vehicle_id: uuid.UUID
    location_id: uuid.UUID
    channel: Literal["marketplace", "dealer_site", "partner_syndication"] = "marketplace"
    title: str = Field(min_length=1, max_length=200)
    description: str | None = None
    currency: str | None = Field(default=None, pattern=r"^[A-Z]{3}$")
    price: str | None = Field(default=None, description="Major units as a decimal string, e.g. \"32900.00\"", examples=["32900.00"])
    deposit_required_minor: int = Field(default=0, ge=0)
    sale_eligibility: Literal["eligible", "not_eligible", "pending_review"] = "pending_review"


class ListingPatch(Strict):
    title: str | None = Field(default=None, min_length=1, max_length=200)
    description: str | None = None
    location_id: uuid.UUID | None = None
    sale_eligibility: Literal["eligible", "not_eligible", "pending_review"] | None = None
    deposit_required_minor: int | None = Field(default=None, ge=0)
    effective_from: AwareDatetime | None = None
    effective_to: AwareDatetime | None = None


class PriceChange(Strict):
    price: str = Field(examples=["31900.00"])
    reason: Literal["price_change", "correction", "promotion"] = "price_change"


class ReasonIn(Strict):
    reason: str | None = Field(default=None, max_length=500)


class BulkPublish(Strict):
    listing_ids: list[uuid.UUID] = Field(min_length=1, max_length=500)


class QuoteCreate(Strict):
    listing_id: uuid.UUID
    customer_id: uuid.UUID | None = None
    session_reference: str | None = Field(default=None, pattern=r"^[A-Za-z0-9_-]{8,128}$")
    customer_region: str | None = Field(default=None, max_length=32, examples=["US-OR"])
    product_codes: list[str] = []
    promo_codes: list[str] = []
    delivery_requested: bool = False
    validity_hours: int | None = Field(default=None, ge=1, le=720)


class QuoteAcceptanceIn(Strict):
    channel: Literal["web", "in_store", "phone", "api"] = "web"


class ReservationCreate(Strict):
    listing_id: uuid.UUID
    customer_id: uuid.UUID | None = None
    quote_id: uuid.UUID | None = None


class CancellationIn(Strict):
    reason: str = Field(min_length=1, max_length=500)
    outcome: Literal["cancelled", "declined", "released"] = "cancelled"


class SaleOrderCreate(Strict):
    agreed_total_minor: int | None = Field(default=None, gt=0)


class HandoverIn(Strict):
    location_id: uuid.UUID
    handed_over_at: AwareDatetime | None = None
    odometer_value: int | None = Field(default=None, ge=0)
    odometer_unit: Literal["km", "mi"] | None = None
    notes: str | None = None


class CompletionIn(Strict):
    accept_outstanding_balance: bool = Field(default=False, description="Complete although money is still owed (e.g. third-party finance); requires a reason and is audited")
    reason: str | None = Field(default=None, max_length=500)


class TestDriveCreate(Strict):
    vehicle_id: uuid.UUID
    listing_id: uuid.UUID | None = None
    customer_id: uuid.UUID | None = None
    resource_id: uuid.UUID
    starts_at: AwareDatetime
    ends_at: AwareDatetime
    confirm: bool = False


class RentalQuoteCreate(Strict):
    location_id: uuid.UUID
    category_id: uuid.UUID
    pickup_at: AwareDatetime
    return_at: AwareDatetime
    customer_id: uuid.UUID | None = None


class RentalBookingCreate(Strict):
    rental_quote_id: uuid.UUID | None = None
    location_id: uuid.UUID | None = None
    category_id: uuid.UUID | None = None
    pickup_at: AwareDatetime | None = None
    return_at: AwareDatetime | None = None
    customer_id: uuid.UUID | None = None
    rental_asset_id: uuid.UUID | None = None
    is_upgrade: bool = False


class AssignmentIn(Strict):
    rental_asset_id: uuid.UUID | None = Field(default=None, description="Omit to auto-select a free asset")
    is_upgrade: bool = False


class MaintenanceCreate(Strict):
    rental_asset_id: uuid.UUID
    kind: Literal["scheduled_service", "repair", "inspection", "recall", "damage"]
    starts_at: AwareDatetime
    ends_at: AwareDatetime
    reason: str = Field(min_length=1)


class PaymentCreate(Strict):
    purpose: Literal["sale_deposit", "sale_balance", "rental_prepayment"]
    sale_reservation_id: uuid.UUID | None = None
    sale_order_id: uuid.UUID | None = None
    rental_booking_id: uuid.UUID | None = None
    amount_minor: int | None = Field(default=None, gt=0)
    currency: str | None = Field(default=None, pattern=r"^[A-Z]{3}$")
    simulate_provider_timeout: bool = Field(default=False, description="SIMULATOR ONLY: provider accepts but the response is lost")


class RefundCreate(Strict):
    payment_intent_id: uuid.UUID
    amount_minor: int | None = Field(default=None, gt=0, description="Omit to refund the remaining refundable amount")
    reason: Literal["customer_request", "hold_expired_before_payment", "duplicate_payment", "sale_cancelled", "goodwill", "reconciliation"] = "customer_request"
    reconciliation_case_id: uuid.UUID | None = None


class CaseResolution(Strict):
    resolution: Literal["refunded", "applied_to_new_reservation", "provider_confirmed", "manual_adjustment", "no_action"]
    note: str | None = None
    status: Literal["resolved", "written_off"] = "resolved"


class MergeDecision(Strict):
    decision: Literal["accept", "reject"]
    note: str | None = None


class CustomerCreate(Strict):
    organisation_id: uuid.UUID | None = None
    customer_type: Literal["individual", "business"] = "individual"
    given_name: str | None = None
    family_name: str | None = None
    business_name: str | None = None
    display_name: str = Field(min_length=1)
    email: str | None = None
    phone: str | None = Field(default=None, pattern=r"^\+[1-9][0-9]{6,14}$")
    marketing_consent: bool | None = None


class CustomerPatch(Strict):
    given_name: str | None = None
    family_name: str | None = None
    business_name: str | None = None
    display_name: str | None = None
    email: str | None = None
    phone: str | None = Field(default=None, pattern=r"^\+[1-9][0-9]{6,14}$")
    marketing_consent: bool | None = None


class SavedSearchCriteria(Strict):
    make: str | None = None
    model: str | None = None
    max_price_minor: int | None = Field(default=None, gt=0)
    lat: float | None = Field(default=None, ge=-90, le=90)
    lon: float | None = Field(default=None, ge=-180, le=180)
    radius_km: float | None = Field(default=None, gt=0, le=1000)


class SavedSearchCreate(Strict):
    name: str = Field(min_length=1, max_length=80)
    criteria: SavedSearchCriteria
    notify: bool = False


class SavedFilterCreate(Strict):
    page: str = Field(pattern=r"^[a-z_-]+$")
    name: str = Field(min_length=1, max_length=80)
    params: dict[str, Any]


class ImportOptions(Strict):
    clear_blank_fields: list[str] = Field(default_factory=list, description="Fields a blank source value may clear. Default: blanks never erase data.")
    publish_on_apply: bool = False


class SimSettle(Strict):
    outcome: Literal["succeeded", "failed", "canceled"] = "succeeded"
    amount_minor: int | None = Field(default=None, gt=0)
    deliver: bool = True
    deliver_times: int = Field(default=1, ge=1, le=5, description="Deliver the same event N times (duplicate test)")
    also_send_stale_processing: bool = Field(default=False, description="After the final event, deliver an older 'processing' event (out-of-order test)")
