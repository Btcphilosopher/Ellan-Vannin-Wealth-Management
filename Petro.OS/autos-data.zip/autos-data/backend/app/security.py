"""Principals, tokens and the role -> permission matrix.

Authorisation is decided here, in the backend, for every request.
PostgreSQL RLS (0012_security.sql) independently restricts which rows the
connection can touch, so a forgotten filter cannot leak another tenant.
"""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field

import jwt
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import DbContext, apply_context
from app.errors import Forbidden, Unauthenticated

READ = {"vehicles.read", "listings.read", "customers.read", "quotes.read", "reservations.read", "test_drives.read",
        "rentals.read", "payments.read", "imports.read", "reports.read"}

ROLE_PERMISSIONS: dict[str, set[str]] = {
    "platform_admin": {"*"},
    "dealer_admin": READ | {"vehicles.write", "vehicles.merge", "listings.write", "listings.publish", "customers.write",
                            "quotes.issue", "reservations.create", "reservations.manage", "sales.manage",
                            "test_drives.manage", "imports.manage", "imports.approve", "refunds.request",
                            "audit.read", "outbox.read"},
    "dealer_staff": READ | {"vehicles.write", "listings.write", "customers.write", "quotes.issue",
                            "reservations.create", "test_drives.manage", "imports.manage"},
    "rental_admin": READ | {"vehicles.write", "customers.write", "rentals.book", "rentals.manage", "refunds.request", "audit.read"},
    "rental_agent": {"rentals.read", "rentals.book", "customers.read", "customers.write", "vehicles.read"},
    "finance": READ | {"payments.create", "refunds.request", "refunds.approve", "reconciliation.manage", "audit.read", "outbox.read"},
    "auditor": READ | {"audit.read", "outbox.read"},
}
ALL_PERMISSIONS = sorted(set().union(*[p for p in ROLE_PERMISSIONS.values() if "*" not in p]) | {"outbox.manage", "org.manage", "customers.erase"})


@dataclass(frozen=True)
class Membership:
    organisation_id: uuid.UUID
    organisation_kind: str
    organisation_name: str
    role: str


@dataclass(frozen=True)
class Principal:
    user_id: uuid.UUID
    email: str
    display_name: str
    kind: str  # staff | customer | service
    customer_id: uuid.UUID | None = None
    memberships: tuple[Membership, ...] = ()
    acting_org_id: uuid.UUID | None = None
    request_id: str | None = None
    extra: dict = field(default_factory=dict)

    @property
    def is_platform(self) -> bool:
        return any(m.role == "platform_admin" for m in self.memberships)

    @property
    def is_customer(self) -> bool:
        return self.kind == "customer"

    @property
    def org_ids(self) -> tuple[uuid.UUID, ...]:
        orgs = tuple(dict.fromkeys(m.organisation_id for m in self.memberships))
        if self.acting_org_id:
            return tuple(o for o in orgs if o == self.acting_org_id)
        return orgs

    def permissions_for(self, org_id: uuid.UUID | None) -> set[str]:
        perms: set[str] = set()
        for m in self.memberships:
            if m.role == "platform_admin" or (org_id is not None and m.organisation_id == org_id):
                perms |= ROLE_PERMISSIONS.get(m.role, set())
        if "*" in perms:
            return set(ALL_PERMISSIONS) | {"*"}
        return perms

    def can(self, perm: str, org_id: uuid.UUID | None) -> bool:
        if self.acting_org_id and org_id and org_id != self.acting_org_id and not self.is_platform:
            return False
        perms = self.permissions_for(org_id)
        return "*" in perms or perm in perms

    def require(self, perm: str, org_id: uuid.UUID | None) -> None:
        if not self.can(perm, org_id):
            raise Forbidden(f"missing permission {perm} for this organisation", code="permission_denied")

    def orgs_with(self, perm: str) -> list[uuid.UUID]:
        return [o for o in self.org_ids if self.can(perm, o)]

    def single_org_with(self, perm: str, requested: uuid.UUID | None = None) -> uuid.UUID:
        if requested:
            self.require(perm, requested)
            return requested
        orgs = self.orgs_with(perm)
        if len(orgs) == 1:
            return orgs[0]
        if not orgs:
            raise Forbidden(f"missing permission {perm}", code="permission_denied")
        raise Forbidden("specify organisation_id or X-Organisation-Id: you belong to several organisations", code="organisation_ambiguous")

    def db_context(self) -> DbContext:
        return DbContext(
            org_ids=self.org_ids,
            is_platform=self.is_platform,
            user_id=self.user_id,
            customer_id=self.customer_id,
            actor_kind="user",
            request_id=self.request_id,
        )

    def summary(self) -> dict:
        return {
            "user_id": str(self.user_id), "email": self.email, "display_name": self.display_name, "kind": self.kind,
            "customer_id": str(self.customer_id) if self.customer_id else None,
            "is_platform": self.is_platform,
            "memberships": [
                {"organisation_id": str(m.organisation_id), "organisation_kind": m.organisation_kind,
                 "organisation_name": m.organisation_name, "role": m.role,
                 "permissions": sorted(self.permissions_for(m.organisation_id) - {"*"})}
                for m in self.memberships
            ],
        }


def issue_token(user_id: uuid.UUID) -> str:
    s = get_settings()
    now = int(time.time())
    return jwt.encode({"sub": str(user_id), "iss": s.jwt_issuer, "iat": now, "exp": now + s.jwt_ttl_seconds},
                      s.jwt_secret, algorithm="HS256")


def decode_token(token: str) -> uuid.UUID:
    s = get_settings()
    try:
        claims = jwt.decode(token, s.jwt_secret, algorithms=["HS256"], issuer=s.jwt_issuer,
                            options={"require": ["sub", "exp", "iss"]})
        return uuid.UUID(claims["sub"])
    except (jwt.PyJWTError, ValueError) as e:
        raise Unauthenticated("invalid or expired token", code="invalid_token") from e


def load_principal(session: Session, user_id: uuid.UUID, *, acting_org_id: uuid.UUID | None,
                   request_id: str | None) -> Principal:
    """Resolve memberships. Runs in its own short system-context transaction
    (identity lookup must precede tenant scoping); the session is committed
    before any tenant work begins."""
    apply_context(session, DbContext.system(request_id, actor_kind="system"))
    user = session.execute(text("SELECT id, email, display_name, kind, customer_id, status FROM app_users WHERE id = :id"),
                           {"id": user_id}).mappings().first()
    if not user or user["status"] != "active":
        session.rollback()
        raise Unauthenticated("unknown or disabled user", code="invalid_token")
    rows = session.execute(text("""
        SELECT m.organisation_id, o.kind, o.display_name, m.role
          FROM organisation_memberships m JOIN organisations o ON o.id = m.organisation_id
         WHERE m.user_id = :id AND m.status = 'active' AND o.status = 'active'
           AND m.valid_from <= now() AND (m.valid_to IS NULL OR m.valid_to > now())
         ORDER BY o.display_name, m.role"""), {"id": user_id}).all()
    session.commit()
    session.info.pop("db_ctx", None)
    memberships = tuple(Membership(r[0], r[1], r[2], r[3]) for r in rows)
    if acting_org_id and acting_org_id not in {m.organisation_id for m in memberships} \
            and not any(m.role == "platform_admin" for m in memberships):
        raise Forbidden("you are not a member of the requested organisation", code="organisation_not_member")
    return Principal(user_id=user["id"], email=user["email"], display_name=user["display_name"], kind=user["kind"],
                     customer_id=user["customer_id"], memberships=memberships, acting_org_id=acting_org_id,
                     request_id=request_id)
