#!/usr/bin/env bash
# Logical backup (custom format) + manifest with checksum, schema head and row counts.
#   PGURL=postgresql://autos_owner:...@host:5432/autos ./backup.sh [out_dir]
# Runs as the schema owner so RLS does not filter rows out of the dump.
set -euo pipefail
PGURL="${PGURL:?set PGURL to the owner connection string}"
OUT="${1:-./backups}"
mkdir -p "$OUT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
FILE="$OUT/autos-$STAMP.dump"
pg_dump --format=custom --compress=6 --serializable-deferrable --dbname="$PGURL" --file="$FILE"
SHA="$(sha256sum "$FILE" | cut -d' ' -f1)"
HEAD="$(psql "$PGURL" -Atc 'SELECT version_num FROM alembic_version')"
COUNTS_SQL="SELECT t, n FROM (
  SELECT 'vehicles' t, count(*) n FROM vehicles UNION ALL SELECT 'listings', count(*) FROM listings
  UNION ALL SELECT 'listing_price_versions', count(*) FROM listing_price_versions UNION ALL SELECT 'quotes', count(*) FROM quotes
  UNION ALL SELECT 'quote_lines', count(*) FROM quote_lines UNION ALL SELECT 'sale_reservations', count(*) FROM sale_reservations
  UNION ALL SELECT 'payment_transactions', count(*) FROM payment_transactions UNION ALL SELECT 'refunds', count(*) FROM refunds
  UNION ALL SELECT 'audit_events', count(*) FROM audit_events UNION ALL SELECT 'customers', count(*) FROM customers
  UNION ALL SELECT 'rental_bookings', count(*) FROM rental_bookings) s ORDER BY t"
psql "$PGURL" -At -F$'\t' -c "$COUNTS_SQL" > "$FILE.counts.tsv"
(cd "$OUT" && sha256sum "$(basename "$FILE")" > "$(basename "$FILE").sha256")
COUNTS_JSON="$(psql "$PGURL" -Atc "SELECT json_object_agg(t, n) FROM ($COUNTS_SQL) x")"
cat > "$FILE.manifest.json" <<JSON
{"file": "$(basename "$FILE")", "sha256": "$SHA", "created_utc": "$STAMP", "alembic_head": "$HEAD",
 "pg_dump": "$(pg_dump --version | awk '{print $3}')", "row_counts": $COUNTS_JSON}
JSON
echo "$HEAD" > "$FILE.head"
echo "$FILE"
