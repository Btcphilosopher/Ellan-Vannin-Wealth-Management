#!/usr/bin/env bash
# Restore a backup into a NEW, EMPTY database and verify it.
#   ADMIN_URL=postgresql://postgres@host:5432/postgres TARGET_DB=autos_restored ./restore.sh backups/autos-XXXX.dump
# 1. verifies the dump checksum (sha256sum -c)
# 2. creates cluster roles (idempotent) and the target database
# 3. pg_restore --exit-on-error (single transaction)
# 4. compares row counts and schema head with the manifest, runs invariant checks
set -euo pipefail
DUMP="${1:?path to .dump}"
ADMIN_URL="${ADMIN_URL:?superuser connection to the target cluster}"
TARGET_DB="${TARGET_DB:-autos_restored}"
HERE="$(cd "$(dirname "$0")" && pwd)"
# Checksum + row counts use plain files written by backup.sh (no Python needed).
(cd "$(dirname "$DUMP")" && sha256sum -c --quiet "$(basename "$DUMP").sha256") || { echo "checksum mismatch" >&2; exit 2; }
psql "$ADMIN_URL" -v ON_ERROR_STOP=1 -q -f "$HERE/../../ops/db-init/01-roles.sql"
EXISTS="$(psql "$ADMIN_URL" -Atc "SELECT 1 FROM pg_database WHERE datname = '$TARGET_DB'")"
[ -z "$EXISTS" ] || { echo "refusing to restore into existing database $TARGET_DB" >&2; exit 3; }
psql "$ADMIN_URL" -v ON_ERROR_STOP=1 -qc "CREATE DATABASE \"$TARGET_DB\" OWNER autos_owner"
TARGET_URL="${ADMIN_URL%/*}/$TARGET_DB"
pg_restore --exit-on-error --single-transaction --dbname="$TARGET_URL" "$DUMP"
HEAD="$(psql "$TARGET_URL" -Atc 'SELECT version_num FROM alembic_version')"
[ "$HEAD" = "$(cat "$DUMP.head")" ] || { echo "schema head $HEAD != $(cat "$DUMP.head")" >&2; exit 5; }
N=0
while IFS=$'\t' read -r table expected; do
  got="$(psql "$TARGET_URL" -Atc "SELECT count(*) FROM $table")"
  [ "$got" = "$expected" ] || { echo "$table: restored $got rows, backup had $expected" >&2; exit 5; }
  N=$((N + 1))
done < "$DUMP.counts.tsv"
echo "row counts match for $N tables; schema head $HEAD"
VIOL="$(psql "$TARGET_URL" -At -F'|' -f "$HERE/verify_integrity.sql")"
echo "$VIOL" | sed 's/^/  invariant: /'
if echo "$VIOL" | awk -F'|' '$2 != 0 {bad=1} END {exit !bad}'; then echo "INVARIANT VIOLATIONS" >&2; exit 4; fi
echo "restore verified: $TARGET_URL"
