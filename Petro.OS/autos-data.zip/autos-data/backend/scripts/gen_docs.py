"""Generate docs/DATA_DICTIONARY.md and docs/er/*.mmd from the migrated database catalog.

    AUTOS_MIGRATION_DATABASE_URL=... python scripts/gen_docs.py --out ../docs
"""
from __future__ import annotations

import argparse
import os
from collections import defaultdict
from pathlib import Path

from sqlalchemy import create_engine, text

DOMAINS = {
    "Tenancy & identity": ["currencies", "organisations", "app_users", "organisation_memberships", "locations"],
    "Catalogue & vehicles": ["vehicle_makes", "vehicle_models", "vehicle_trims", "vehicle_specification_versions", "vehicles",
                             "vehicle_identifiers", "vehicle_attribute_assertions", "vehicle_features", "vehicle_media",
                             "vehicle_merge_proposals"],
    "Listings": ["listings", "listing_price_versions", "listing_status_events"],
    "Customers": ["customers", "customer_relationships", "customer_addresses", "saved_vehicles", "saved_searches"],
    "Quotes": ["terms_versions", "charge_rules", "quotes", "quote_lines", "quote_acceptances"],
    "Sales": ["sale_reservations", "vehicle_current_reservations", "sale_orders", "sale_status_events", "handover_records"],
    "Test drives": ["appointment_resources", "test_drive_appointments"],
    "Rentals": ["rental_categories", "rental_inventory_buckets", "rental_assets", "rental_quotes", "rental_bookings",
                "rental_asset_assignments", "maintenance_blocks"],
    "Payments": ["payment_intents", "payment_events", "payment_transactions", "refunds", "reconciliation_cases"],
    "Imports": ["import_jobs", "import_rows", "source_record_mappings"],
    "Operations": ["outbox_events", "audit_events", "idempotency_keys", "worker_heartbeats", "admin_saved_filters"],
}

# Archival / deletion / retention policy per entity (see also docs/DATA_LIFECYCLE.md)
LIFECYCLE = {
    "organisations": ("archive (status=archived)", "never deleted", "life of platform"),
    "app_users": ("disable (status=disabled)", "never deleted (audit actor)", "life of platform"),
    "organisation_memberships": ("revoke (status, valid_to)", "never deleted", "life of platform"),
    "locations": ("close (status=closed)", "never deleted", "life of platform"),
    "vehicles": ("archive / merge (archived_at, merged_into)", "trigger-blocked", "10 years after last sale"),
    "vehicle_identifiers": ("retire (retired_at + reason)", "trigger-blocked", "with vehicle"),
    "vehicle_attribute_assertions": ("supersede (verification_status)", "trigger-blocked", "with vehicle"),
    "vehicle_specification_versions": ("close (effective_to) / supersede", "append-only", "permanent reference"),
    "vehicle_media": ("archive (archived_at); object kept", "no DELETE grant", "7 years; documents per contract"),
    "listings": ("withdraw / sold (terminal)", "trigger-blocked", "7 years"),
    "listing_price_versions": ("close (effective_to once)", "append-only", "7 years"),
    "listing_status_events": ("—", "append-only", "7 years"),
    "customers": ("erase PII (status=erased) / archive", "trigger-blocked", "PII erased on request; row kept for history"),
    "customer_addresses": ("close (valid_to); blanked on erasure", "no DELETE grant", "with customer"),
    "saved_vehicles": ("—", "DELETE allowed (no history)", "until removed"),
    "saved_searches": ("—", "DELETE allowed (no history)", "until removed"),
    "quotes": ("withdraw (status)", "append-only", "7 years (commercial record)"),
    "quote_lines": ("—", "append-only", "with quote"),
    "quote_acceptances": ("—", "append-only", "7 years"),
    "charge_rules": ("close (effective_to)", "trigger-blocked", "7 years"),
    "terms_versions": ("close (effective_to)", "trigger-blocked", "permanent"),
    "sale_reservations": ("end (expired/cancelled/declined/released)", "trigger-blocked", "7 years"),
    "vehicle_current_reservations": ("row removed when commitment ends", "SECURITY DEFINER triggers only", "transient"),
    "sale_orders": ("complete / cancel", "trigger-blocked", "10 years (sale contract)"),
    "sale_status_events": ("—", "append-only", "10 years"),
    "handover_records": ("frozen once handed over", "trigger-blocked", "10 years"),
    "test_drive_appointments": ("cancel / complete", "trigger-blocked", "2 years"),
    "rental_bookings": ("cancel / return", "trigger-blocked", "7 years"),
    "rental_asset_assignments": ("release / cancel", "trigger-blocked", "7 years"),
    "maintenance_blocks": ("complete / cancel", "trigger-blocked", "asset life + 2 years"),
    "payment_intents": ("terminal statuses", "trigger-blocked", "10 years (financial)"),
    "payment_events": ("processing fields only", "trigger-blocked", "10 years"),
    "payment_transactions": ("—", "append-only", "10 years"),
    "refunds": ("terminal statuses", "trigger-blocked", "10 years"),
    "reconciliation_cases": ("resolve / write off", "trigger-blocked", "10 years"),
    "import_jobs": ("reject / applied", "trigger-blocked", "2 years (summary kept)"),
    "import_rows": ("—", "no DELETE grant; purge job deferred", "180 days (planned purge)"),
    "source_record_mappings": ("—", "no DELETE grant", "while source active"),
    "outbox_events": ("published / dead", "no DELETE grant; purge job deferred", "30 days after publish (planned)"),
    "audit_events": ("—", "append-only + TRUNCATE trigger", "7 years"),
    "idempotency_keys": ("expires_at", "DELETE allowed after expiry", "7 days"),
    "admin_saved_filters": ("—", "DELETE allowed", "until removed"),
}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="../docs")
    out = Path(ap.parse_args().out)
    (out / "er").mkdir(parents=True, exist_ok=True)
    eng = create_engine(os.environ["AUTOS_MIGRATION_DATABASE_URL"])
    with eng.connect() as c:
        tcomment = dict(c.execute(text("""SELECT c.relname, obj_description(c.oid, 'pg_class') FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = 'public' AND c.relkind = 'r'""")).all())
        cols = c.execute(text("""
            SELECT c.relname AS tbl, a.attname AS col, format_type(a.atttypid, a.atttypmod) AS type, a.attnotnull AS notnull,
                   pg_get_expr(d.adbin, d.adrelid) AS dflt, a.attgenerated AS gen, col_description(c.oid, a.attnum) AS comment, a.attnum
              FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
              LEFT JOIN pg_attrdef d ON d.adrelid = a.attrelid AND d.adnum = a.attnum
             WHERE n.nspname = 'public' AND c.relkind = 'r' AND a.attnum > 0 AND NOT a.attisdropped
             ORDER BY c.relname, a.attnum""")).all()
        cons = c.execute(text("""
            SELECT cl.relname AS tbl, con.conname, con.contype, pg_get_constraintdef(con.oid) AS def, rcl.relname AS ref
              FROM pg_constraint con JOIN pg_class cl ON cl.oid = con.conrelid JOIN pg_namespace n ON n.oid = cl.relnamespace
              LEFT JOIN pg_class rcl ON rcl.oid = con.confrelid
             WHERE n.nspname = 'public' ORDER BY cl.relname, con.contype, con.conname""")).all()
        idx = c.execute(text("""SELECT tablename, indexname, indexdef FROM pg_indexes WHERE schemaname = 'public'
                                 AND indexname NOT IN (SELECT conname FROM pg_constraint) ORDER BY 1, 2""")).all()
        trg = c.execute(text("""SELECT c.relname, t.tgname, p.proname FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid
              JOIN pg_proc p ON p.oid = t.tgfoid JOIN pg_namespace n ON n.oid = c.relnamespace
             WHERE n.nspname = 'public' AND NOT t.tgisinternal ORDER BY 1, 2""")).all()
        pol = c.execute(text("SELECT tablename, policyname, cmd, qual, with_check FROM pg_policies WHERE schemaname = 'public' ORDER BY 1, 2")).all()
        rls = dict(c.execute(text("""SELECT c.relname, c.relrowsecurity FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
                                      WHERE n.nspname = 'public' AND c.relkind = 'r'""")).all())
        head = c.execute(text("SELECT version_num FROM alembic_version")).scalar()

    by_t = defaultdict(list)
    for r in cols:
        by_t[r.tbl].append(r)
    cons_t, idx_t, trg_t, pol_t = defaultdict(list), defaultdict(list), defaultdict(list), defaultdict(list)
    for r in cons:
        cons_t[r.tbl].append(r)
    for r in idx:
        idx_t[r.tablename].append(r)
    for r in trg:
        trg_t[r.relname].append(r)
    for r in pol:
        pol_t[r.tablename].append(r)

    md = [f"# Data dictionary\n\nGenerated from the live catalog at schema head `{head}` by `backend/scripts/gen_docs.py` — do not edit by hand.\n",
          "Conventions: `uuid` keys from `uuid_v7()`; instants are `timestamp with time zone`; money is `bigint` minor units with an explicit "
          "`char(3)` currency; status columns are `text` + CHECK; `version` is the optimistic-concurrency counter bumped by trigger; "
          "NULL means *unknown*, never zero/false.\n", "## Contents\n"]
    for dom, tables in DOMAINS.items():
        md.append(f"- **{dom}**: " + ", ".join(f"[`{t}`](#{t.replace('_', '-')})" for t in tables))
    md.append("")
    for dom, tables in DOMAINS.items():
        md.append(f"\n---\n\n## {dom}\n")
        for t in tables:
            md.append(f"### {t}\n")
            md.append((tcomment.get(t) or "").strip() + "\n")
            lc = LIFECYCLE.get(t)
            md.append(f"*RLS:* {'enabled' if rls.get(t) else 'not enabled (reference / platform table)'}"
                      + (f" · *Archival:* {lc[0]} · *Deletion:* {lc[1]} · *Retention:* {lc[2]}" if lc else "") + "\n")
            md.append("| column | type | null | default / generated | notes |\n|---|---|---|---|---|")
            for r in by_t[t]:
                d = (f"GENERATED: `{r.dflt}`" if r.gen == "s" else f"`{r.dflt}`") if r.dflt else ""
                md.append(f"| `{r.col}` | {r.type} | {'' if r.notnull else 'yes'} | {d.replace('|', '¦')} | {(r.comment or '').replace('|', '¦')} |")
            kinds = {"p": "PK", "f": "FK", "u": "UNIQUE", "c": "CHECK", "x": "EXCLUDE", "t": "TRIGGER"}
            if cons_t[t]:
                md.append("\n<details><summary>Constraints</summary>\n")
                for r in cons_t[t]:
                    md.append(f"- **{kinds.get(r.contype, r.contype)}** `{r.conname}`: `{r.def_ if hasattr(r, 'def_') else r[3]}`".replace("|", "¦"))
                md.append("\n</details>")
            if idx_t[t]:
                md.append("\n<details><summary>Indexes</summary>\n")
                for r in idx_t[t]:
                    md.append(f"- `{r.indexdef.replace('CREATE ', '').replace(' ON public.', ' ON ')}`")
                md.append("\n</details>")
            if trg_t[t] or pol_t[t]:
                md.append("\n<details><summary>Triggers & policies</summary>\n")
                for r in trg_t[t]:
                    md.append(f"- trigger `{r.tgname}` → `{r.proname}()`")
                for r in pol_t[t]:
                    md.append(f"- policy `{r.policyname}` ({r.cmd}): USING `{(r.qual or '—')[:160]}`".replace("|", "¦"))
                md.append("\n</details>")
            md.append("")
    (out / "DATA_DICTIONARY.md").write_text("\n".join(md) + "\n")

    # ---------------- ER diagrams (Mermaid)
    fks = [(r.tbl, r.ref, r.conname) for r in cons if r.contype == "f" and r.ref]
    pk = {r.tbl: r[3] for r in cons if r.contype == "p"}

    def entity(t, full=True):
        lines = [f"  {t} {{"]
        for r in by_t[t]:
            if not full and not (r.col == "id" or r.col.endswith("_id") or r.col in ("status", "version")):
                continue
            typ = r.type.split("(")[0].replace(" ", "_").replace("timestamp_with_time_zone", "timestamptz")
            key = "PK" if f"({r.col})" in pk.get(t, "") else ("FK" if any(f[0] == t and r.col in f[2] for f in fks) or r.col.endswith("_id") else "")
            lines.append(f"    {typ} {r.col} {key}".rstrip())
        lines.append("  }")
        return lines

    def diagram(tables, full, compact=()):
        lines = ["erDiagram"]
        for t in tables:
            lines += entity(t, full and t not in compact)
        seen = set()
        for child, parent, name in fks:
            if child in tables and parent in tables and (child, parent) not in seen:
                seen.add((child, parent))
                lines.append(f"  {parent} ||--o{{ {child} : \"{name.replace(child + '_', '').replace('_fkey', '')[:30]}\"")
        return "\n".join(lines) + "\n"

    all_tables = [t for ts in DOMAINS.values() for t in ts]
    (out / "er" / "overview.mmd").write_text(diagram(all_tables, full=False))
    for dom, ts in DOMAINS.items():
        ext = set(ts)
        for child, parent, _ in fks:  # include direct neighbours for context
            if child in ts and parent in ("organisations", "vehicles", "listings", "customers"):
                ext.add(parent)
        ordered = ts + sorted(ext - set(ts))
        slug = dom.lower().replace(" & ", "-").replace(" ", "-")
        (out / "er" / f"{slug}.mmd").write_text(diagram(ordered, full=True, compact=set(ordered) - set(ts)))
    print("tables documented:", len(all_tables), "missing from DOMAINS:", sorted(set(by_t) - set(all_tables) - {"spatial_ref_sys", "alembic_version"}))


if __name__ == "__main__":
    main()
