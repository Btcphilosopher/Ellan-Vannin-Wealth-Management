"""End-to-end demonstration of the 12 required scenarios against a RUNNING API.

    AUTOS_DEMO_API=http://localhost:8000 AUTOS_MIGRATION_DATABASE_URL=postgresql+psycopg://owner@.../autos \
        python scripts/demo.py --out ../docs/DEMO_TRANSCRIPT.md

Requires a freshly seeded database (python -m seed.generate). Uses only the
public HTTP API, except where a step deliberately demonstrates a database-
level guarantee (marked "direct SQL as owner") or simulates time passing by
shortening a dealer's hold policy.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import httpx
from sqlalchemy import create_engine, text

HERE = Path(__file__).resolve().parent
API = os.environ.get("AUTOS_DEMO_API", "http://localhost:8000")
OWNER = os.environ["AUTOS_MIGRATION_DATABASE_URL"]
out: list[str] = []


def say(md: str = "") -> None:
    print(md)
    out.append(md)


def show(label: str, resp: httpx.Response, keys: list[str] | None = None) -> dict:
    try:
        body = resp.json()
    except ValueError:
        body = {"text": resp.text[:300]}
    view = {k: body.get(k) for k in keys} if keys and isinstance(body, dict) else body
    say(f"`{resp.request.method} {resp.request.url.path}` → **{resp.status_code}**")
    say("```json\n" + json.dumps(view, indent=2, default=str)[:1800] + "\n```")
    return body


class Client:
    def __init__(self, email: str):
        self.h = httpx.Client(base_url=API, timeout=30)
        tok = self.h.post("/v1/auth/token", json={"email": email}).json()["access_token"]
        self.h.headers["Authorization"] = f"Bearer {tok}"
        self.email = email

    def __getattr__(self, name):
        return getattr(self.h, name)


def step(n: int, title: str) -> None:
    say(f"\n## {n}. {title}\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(HERE.parent.parent / "docs" / "DEMO_TRANSCRIPT.md"))
    args = ap.parse_args()
    eng = create_engine(OWNER)
    sql = lambda q, **p: eng.connect().execute(text(q), p)  # noqa: E731
    with eng.connect() as c:
        ids = {r.slug: r.id for r in c.execute(text("SELECT slug, id FROM organisations"))}
        locs = {r.code: str(r.id) for r in c.execute(text("SELECT code, id FROM locations"))}
        cust = [str(r.id) for r in c.execute(text("SELECT id FROM customers ORDER BY created_at"))]
    hv, rl, rlf, hvf, cl, ops = (Client("admin@harbourview.example"), Client("admin@ridgeline.example"), Client("finance@ridgeline.example"),
                                 Client("finance@harbourview.example"), Client("admin@cityline.example"), Client("ops@autos-data.example"))
    say(f"# AUTOS DATA — demonstration transcript\n\nGenerated {dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')} "
        f"against `{API}` (PostgreSQL {sql('SHOW server_version').scalar()}, PostGIS {sql('SELECT postgis_lib_version()').scalar()}). "
        "All organisations, people, VINs and payments are fictional/synthetic; the payment provider is simulated.")

    # 1 ------------------------------------------------------------------
    step(1, "Import dealer inventory")
    sample = (HERE.parent / "seed" / "samples" / "ridgeline_inventory_2026-11-25.csv").read_bytes()
    say("Ridgeline uploads a 10-row CSV in `partial_accept` mode. The file is stored in object storage, staged row by row "
        "(raw payload kept for provenance) and validated immediately.")
    r = rl.post("/v1/import-jobs", files={"file": ("ridgeline_inventory_2026-11-25.csv", sample, "text/csv")},
                data={"source_namespace": "feed:ridgeline-dms", "mode": "partial_accept", "options": "{}"})
    job = show("upload", r, ["id", "status", "mode", "row_count", "valid_count", "warning_count", "invalid_count", "file_sha256"])
    r = rl.post("/v1/import-jobs", files={"file": ("same-file-again.csv", sample, "text/csv")},
                data={"source_namespace": "feed:ridgeline-dms", "mode": "partial_accept", "options": "{}"})
    say("Re-uploading identical bytes is idempotent:")
    show("re-upload", r, ["id", "duplicate_upload"])

    # 2 ------------------------------------------------------------------
    step(2, "Review invalid rows")
    rows = rl.get(f"/v1/import-jobs/{job['id']}/rows", params={"status": "invalid"}).json()["items"]
    say("| row | source_record_id | findings (errors) |\n|---|---|---|")
    for x in rows:
        errs = "; ".join(f"`{f['code']}` {f['message']}" for f in x["findings"] if f["severity"] == "error")
        say(f"| {x['row_number']} | {x['source_record_id']} | {errs} |")
    warn = rl.get(f"/v1/import-jobs/{job['id']}/rows", params={"status": "warning"}).json()["items"]
    for x in warn:
        say(f"\nRow {x['row_number']} ({x['source_record_id']}) is valid with warnings: " +
            ", ".join(f"`{f['code']}`" for f in x["findings"]))

    # 3 ------------------------------------------------------------------
    step(3, "Publish valid listings")
    job = rl.get(f"/v1/import-jobs/{job['id']}").json()
    r = rl.post(f"/v1/import-jobs/{job['id']}/approval", headers={"If-Match": f'"{job["version"]}"'})
    show("approve+apply", r, ["status", "applied_count", "skipped_count", "no_change_count"])
    applied = rl.get(f"/v1/import-jobs/{job['id']}/rows", params={"status": "applied"}).json()["items"]
    r = rl.post("/v1/listings/publication-batch", json={"listing_ids": [a["result"]["listing_id"] for a in applied]})
    show("bulk publish", r, ["published", "rejected"])

    # 4 ------------------------------------------------------------------
    step(4, "Generate an immutable quote")
    with eng.connect() as c:
        tucson = c.execute(text("SELECT id, vehicle_id FROM listings WHERE title = '2026 Hyundai Tucson SEL' AND channel = 'marketplace'")).one()
    say("Without a customer region the tax and registration are unknown, so the quote is **incomplete** (no total is invented):")
    r = hv.post("/v1/quotes", json={"listing_id": str(tucson.id), "customer_id": cust[0]}, headers={"Idempotency-Key": uuid.uuid4().hex})
    q1 = r.json()
    say(f"`POST /v1/quotes` → **{r.status_code}** {q1['quote_number']}\n")
    say("| line | status | amount |\n|---|---|---|")
    for line in q1["lines"]:
        say(f"| {line['description']} | {line['amount_status']} | {line['formatted'] or '—'} |")
    say(f"\nSubtotal before tax/registration **{q1['summary']['subtotal_before_tax_registration']}**; "
        f"is_complete={q1['is_complete']}, missing={q1['missing_charges']}, total={q1['total_minor']}; "
        f"deposit {q1['summary']['deposit_required']} — {q1['summary']['deposit_note']}")
    r = hv.post("/v1/quotes", json={"listing_id": str(tucson.id), "customer_id": cust[0], "customer_region": "US-OR"},
                headers={"Idempotency-Key": uuid.uuid4().hex})
    q2 = r.json()
    say(f"\nWith `customer_region=US-OR` the quote is complete: total **{q2['summary']['total']}**, balance after deposit "
        f"{q2['summary']['balance_after_deposit']}.")
    say("\nImmutability is enforced by the database (direct SQL as owner):")
    try:
        with eng.begin() as c:
            c.execute(text("UPDATE quotes SET vehicle_price_minor = 1 WHERE id = :q"), {"q": q2["id"]})
    except Exception as e:  # noqa: BLE001
        say(f"```\n{str(e.orig).splitlines()[0]}\n```")
    lst = hv.get(f"/v1/listings/{tucson.id}").json()
    hv.post(f"/v1/listings/{tucson.id}/prices", json={"price": "31900.00"}, headers={"If-Match": f'"{lst["version"]}"'})
    again = hv.get(f"/v1/quotes/{q2['id']}").json()
    say(f"After the listing price changes to $31,900.00 the issued quote still shows vehicle price "
        f"**{again['summary']['vehicle_price']}** (snapshot_verified={again['snapshot_verified']}).")

    # 5 + 6 ---------------------------------------------------------------
    step(5, "Submit competing reservations")
    with eng.connect() as c:
        site = c.execute(text("SELECT id FROM listings WHERE vehicle_id = :v AND channel = 'dealer_site'"), {"v": tucson.vehicle_id}).scalar()
    say("The same physical Tucson is offered through two listings (marketplace + dealer site). 20 concurrent HTTP requests "
        "from 10 different customers race for it, split across both listings.")
    barrier = threading.Barrier(20)
    clients = [Client("sales@harbourview.example") for _ in range(20)]

    def attempt(i):
        barrier.wait()
        resp = clients[i].post("/v1/sale-reservations", json={"listing_id": str([tucson.id, site][i % 2]), "customer_id": cust[i % 10]},
                               headers={"Idempotency-Key": uuid.uuid4().hex})
        return resp.status_code, resp.json().get("code") or resp.json().get("reservation_number")

    t0 = time.perf_counter()
    with ThreadPoolExecutor(20) as ex:
        results = list(ex.map(attempt, range(20)))
    elapsed = time.perf_counter() - t0
    step(6, "Confirm only one succeeds")
    wins = [r for r in results if r[0] == 201]
    from collections import Counter
    say(f"Outcomes in {elapsed * 1000:.0f} ms: " + ", ".join(f"{k[0]} {k[1] if k[0] != 201 else 'created'} ×{v}" for k, v in Counter(
        (r[0], r[1] if r[0] != 201 else "") for r in results).items()))
    with eng.connect() as c:
        n = c.execute(text("SELECT count(*) FROM vehicle_current_reservations WHERE vehicle_id = :v"), {"v": tucson.vehicle_id}).scalar()
        m = c.execute(text("SELECT count(*) FROM sale_reservations WHERE vehicle_id = :v AND status IN ('held','dealer_accepted')"),
                      {"v": tucson.vehicle_id}).scalar()
    say(f"\nWinner: **{wins[0][1]}**. Database check: vehicle_current_reservations rows = {n}, active reservations = {m}.")
    winner = hv.get("/v1/sale-reservations", params={"status": "held"}).json()["items"]
    winner = next(x for x in winner if x["reservation_number"] == wins[0][1])

    # 7 ------------------------------------------------------------------
    step(7, "Process a duplicate payment event once")
    key = "demo-deposit-" + uuid.uuid4().hex[:8]
    r = hv.post("/v1/payments", json={"purpose": "sale_deposit", "sale_reservation_id": winner["id"]}, headers={"Idempotency-Key": key})
    intent = show("create payment", r, ["id", "status", "amount_minor", "currency", "provider_intent_ref"])
    r = hv.post("/v1/payments", json={"purpose": "sale_deposit", "sale_reservation_id": winner["id"]}, headers={"Idempotency-Key": key})
    say(f"Retrying with the same Idempotency-Key → **{r.status_code}**, same id: {r.json()['id'] == intent['id']}, "
        f"`Idempotent-Replayed: {r.headers.get('Idempotent-Replayed')}`")
    r = hv.post(f"/v1/dev/simpay/payments/{intent['provider_intent_ref']}/settle",
                json={"outcome": "succeeded", "deliver_times": 3, "also_send_stale_processing": True})
    say("The simulated provider delivers the signed `payment.succeeded` webhook three times, then a stale `payment.processing`:")
    say("```json\n" + json.dumps([{k: d.get(k) for k in ("result", "note")} for d in r.json()["deliveries"]], indent=2) + "\n```")
    p = hv.get(f"/v1/payments/{intent['id']}").json()
    res = hv.get(f"/v1/sale-reservations/{winner['id']}").json()
    say(f"Capture transactions recorded: **{len(p['transactions'])}**. Reservation status `{res['status']}` (still awaiting dealer "
        f"acceptance), deposit `{res['deposit_status']}`, hold extended to {res['hold_expires_at']}.")

    # 8 ------------------------------------------------------------------
    step(8, "Handle settlement after hold expiry")
    with eng.connect() as c:
        ioniq = c.execute(text("SELECT id FROM listings WHERE title = '2026 Hyundai IONIQ 5 SE'")).scalar()
    sql_owner = eng.begin
    with sql_owner() as c:
        c.execute(text("UPDATE organisations SET sale_hold_duration = interval '3 seconds' WHERE slug = 'harbourview-motors'"))
    say("To simulate time passing, Harbourview's hold policy is shortened to 3 seconds (direct SQL as owner).")
    a = hv.post("/v1/sale-reservations", json={"listing_id": str(ioniq), "customer_id": cust[1]}, headers={"Idempotency-Key": uuid.uuid4().hex}).json()
    pa = hv.post("/v1/payments", json={"purpose": "sale_deposit", "sale_reservation_id": a["id"]}, headers={"Idempotency-Key": uuid.uuid4().hex}).json()
    say(f"Customer A holds the IONIQ 5 ({a['reservation_number']}) and starts paying a deposit; the provider is slow. 3.5 s later…")
    time.sleep(3.5)
    b = hv.post("/v1/sale-reservations", json={"listing_id": str(ioniq), "customer_id": cust[2]}, headers={"Idempotency-Key": uuid.uuid4().hex})
    say(f"Customer B reserves the same vehicle → **{b.status_code}** {b.json().get('reservation_number')} (A's lapsed hold is expired inline under the vehicle lock).")
    b = b.json()
    with sql_owner() as c:
        c.execute(text("UPDATE organisations SET sale_hold_duration = interval '30 minutes' WHERE slug = 'harbourview-motors'"))
    r = hv.post(f"/v1/dev/simpay/payments/{pa['provider_intent_ref']}/settle", json={"outcome": "succeeded"})
    say(f"Now A's payment settles: webhook result `{r.json()['deliveries'][0]['result']}` — {r.json()['deliveries'][0]['note']}")
    case = hv.get(f"/v1/payments/{pa['id']}").json()["cases"][0]
    say("```json\n" + json.dumps({k: case[k] for k in ("case_number", "case_type", "status", "summary", "details")}, indent=2) + "\n```")
    say(f"B's reservation is untouched: `{hv.get(f'/v1/sale-reservations/{b['id']}').json()['status']}` for customer B; "
        f"A's is `{hv.get(f'/v1/sale-reservations/{a['id']}').json()['status']}`.")

    # 9 ------------------------------------------------------------------
    step(9, "Reject an overlapping rental booking")
    cats = {c["code"]: c for c in cl.get("/v1/rental-categories").json()["items"]}
    assets = [x for x in cl.get("/v1/rental-assets").json()["items"] if x["category_id"] == cats["SFAR"]["id"] and x["home_location_id"] == locs["CL-SEA"]]
    asset = assets[0]["id"]
    la = dt.timezone(dt.timedelta(hours=-8))
    p0 = dt.datetime(2027, 1, 15, 9, 0, tzinfo=la)

    def bk(pick, ret, c, a=asset):
        return cl.post("/v1/rental-bookings", json={"category_id": cats["SFAR"]["id"], "location_id": locs["CL-SEA"], "pickup_at": pick.isoformat(),
                                                   "return_at": ret.isoformat(), "customer_id": c, "rental_asset_id": a},
                       headers={"Idempotency-Key": uuid.uuid4().hex})
    r1 = bk(p0, p0 + dt.timedelta(days=2), cust[3])
    say(f"Booking 1 on asset {assets[0]['fleet_number']}: {p0.isoformat()} → +2 days → **{r1.status_code}**; occupied "
        f"`{r1.json()['assignments'][0]['occupied']}` (includes the 60-minute turnaround buffer).")
    r2 = bk(p0 + dt.timedelta(days=2, minutes=30), p0 + dt.timedelta(days=3), cust[4])
    say(f"Booking 2 on the same asset starting 30 min after return (inside the buffer) → **{r2.status_code}** `{r2.json().get('code')}`: {r2.json().get('detail')}")
    r3 = bk(p0 + dt.timedelta(days=2, hours=1), p0 + dt.timedelta(days=3), cust[4])
    say(f"Booking 3 starting exactly at return + buffer (half-open interval) → **{r3.status_code}**")

    # 10 -----------------------------------------------------------------
    step(10, "Prevent cross-dealer access")
    with eng.connect() as c:
        draft = c.execute(text("SELECT id FROM listings WHERE organisation_id = :o AND status = 'draft' LIMIT 1"), {"o": ids["harbourview-motors"]}).scalar()
    assert draft, "seed should contain a Harbourview draft listing"
    with eng.connect() as c:
        hv_cust = c.execute(text("SELECT customer_id FROM customer_relationships WHERE organisation_id = :o AND customer_id NOT IN "
                                 "(SELECT customer_id FROM customer_relationships WHERE organisation_id = :r) LIMIT 1"),
                            {"o": ids["harbourview-motors"], "r": ids["ridgeline-auto"]}).scalar()
    for label, resp in (("Ridgeline reads a Harbourview draft listing", rl.get(f"/v1/listings/{draft}")),
                        ("Ridgeline reads a Harbourview customer", rl.get(f"/v1/customers/{hv_cust}")),
                        ("Ridgeline reads Harbourview's payment", rl.get(f"/v1/payments/{intent['id']}")),
                        ("Ridgeline tries to accept Harbourview's reservation",
                         rl.post(f"/v1/sale-reservations/{winner['id']}/acceptance", headers={"If-Match": '"1"'}))):
        say(f"- {label} → **{resp.status_code}** `{resp.json().get('code')}`")
    say(f"- Ridgeline's quote list contains only Ridgeline quotes: "
        f"{all(q['organisation_id'] == str(ids['ridgeline-auto']) for q in rl.get('/v1/quotes').json()['items'])}")
    with create_engine(OWNER.replace("autos_owner:autos", "autos_api:autos_api")).connect() as c:
        c.execute(text("SELECT set_config('app.org_ids', :o, false)"), {"o": "{" + str(ids["ridgeline-auto"]) + "}"})
        n = c.execute(text("SELECT count(*) FROM payment_intents WHERE organisation_id = :h"), {"h": ids["harbourview-motors"]}).scalar()
    say(f"- Defence in depth: as the application DB role with Ridgeline context, `SELECT count(*) FROM payment_intents WHERE organisation_id = <Harbourview>` → **{n}** (row-level security).")

    # 11 -----------------------------------------------------------------
    step(11, "Reconcile a refund")
    say(f"Finance resolves {case['case_number']} by refunding customer A's late deposit, linked to the case:")
    r = hvf.post("/v1/refunds", json={"payment_intent_id": pa["id"], "reason": "hold_expired_before_payment", "reconciliation_case_id": case["id"]},
                 headers={"Idempotency-Key": uuid.uuid4().hex})
    ref = show("refund", r, ["id", "status", "amount_minor", "provider_refund_ref"])
    say(f"Case is now `{hvf.get(f'/v1/reconciliation-cases/{case['id']}').json()['status']}`. Over-refunding is impossible:")
    r = hvf.post("/v1/refunds", json={"payment_intent_id": pa["id"], "amount_minor": 1}, headers={"Idempotency-Key": uuid.uuid4().hex})
    say(f"Extra 1-cent refund → **{r.status_code}** `{r.json()['code']}`: {r.json()['detail']}")
    r = hv.post(f"/v1/dev/simpay/refunds/{ref['provider_refund_ref']}/settle")
    say(f"Provider confirms the refund (`refund.succeeded` webhook → `{r.json()['delivery']['result']}`).")
    c2 = hvf.get(f"/v1/reconciliation-cases/{case['id']}").json()
    say(f"Case **{c2['status']}** / resolution `{c2['resolution']}`: {c2['resolution_note']}")
    tx = hv.get(f"/v1/payments/{pa['id']}").json()["transactions"]
    say("Money movements: " + ", ".join(f"{t['kind']} {t['amount_minor']} {t['currency']}" for t in tx))

    # 12 -----------------------------------------------------------------
    step(12, "Restore a backup into a clean environment")
    url = OWNER.replace("postgresql+psycopg://", "postgresql://")
    t0 = time.perf_counter()
    res = subprocess.run([str(HERE / "restore_drill.sh")], env={**os.environ, "PGURL": url}, capture_output=True, text=True)
    say(f"`scripts/restore_drill.sh` (fresh `initdb` cluster on another port; {time.perf_counter() - t0:.1f} s, exit {res.returncode}):")
    say("```\n" + res.stdout.strip() + "\n```")
    Path(args.out).write_text("\n".join(out) + "\n")
    print(f"\nwrote {args.out}")
    if res.returncode != 0:
        print(res.stderr, file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
