-- Post-restore / periodic invariant checks. Every row reports a violation
-- count; anything non-zero fails the restore drill.
SELECT 'multiple_active_reservations_per_vehicle' AS check, count(*) AS violations
  FROM (SELECT vehicle_id FROM sale_reservations WHERE status IN ('held','dealer_accepted') GROUP BY 1 HAVING count(*) > 1) x
UNION ALL
SELECT 'current_reservation_points_to_ended_reservation', count(*)
  FROM vehicle_current_reservations c JOIN sale_reservations r ON r.id = c.sale_reservation_id
 WHERE r.status NOT IN ('held','dealer_accepted','converted')
UNION ALL
SELECT 'refunds_exceed_capture', count(*)
  FROM (SELECT t.id FROM payment_transactions t JOIN refunds r ON r.capture_transaction_id = t.id
         WHERE r.status IN ('requested','pending','succeeded') GROUP BY t.id, t.amount_minor HAVING sum(r.amount_minor) > t.amount_minor) x
UNION ALL
SELECT 'quote_header_line_mismatch', count(*)
  FROM quotes q WHERE q.vehicle_price_minor <> (SELECT COALESCE(sum(amount_minor),0) FROM quote_lines l WHERE l.quote_id = q.id AND l.line_type = 'vehicle_price')
UNION ALL
SELECT 'overlapping_active_assignments', count(*)
  FROM rental_asset_assignments a JOIN rental_asset_assignments b
    ON a.rental_asset_id = b.rental_asset_id AND a.id < b.id AND a.status = 'active' AND b.status = 'active' AND a.occupied && b.occupied
UNION ALL
SELECT 'published_listing_without_price', count(*) FROM listings WHERE status = 'published' AND current_price_version_id IS NULL
UNION ALL
SELECT 'sold_vehicle_with_open_listing', count(*)
  FROM listings l JOIN vehicles v ON v.id = l.vehicle_id WHERE v.availability_status = 'sold' AND l.status IN ('published','suspended')
UNION ALL
SELECT 'listing_without_status_history', count(*)
  FROM listings l WHERE NOT EXISTS (SELECT 1 FROM listing_status_events e WHERE e.listing_id = l.id)
UNION ALL
SELECT 'rls_disabled_on_tenant_table', count(*)
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE n.nspname = 'public' AND c.relname IN ('listings','customers','sale_reservations','payment_intents','audit_events','import_jobs')
   AND NOT c.relrowsecurity
UNION ALL
SELECT 'invalid_constraints', count(*) FROM pg_constraint WHERE NOT convalidated;
