#!/usr/bin/env bash
# Disaster-recovery drill: back up the live database, then restore it into a
# brand-new PostgreSQL cluster (fresh initdb, separate port, no shared state),
# verify, smoke-test as the RLS-subject application role, and tear down.
#   PGURL=postgresql://autos_owner:...@localhost:5432/autos ./restore_drill.sh
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
PGBIN="${PGBIN:-$(dirname "$(readlink -f "$(command -v pg_ctl 2>/dev/null || echo /usr/lib/postgresql/16/bin/pg_ctl)")")}"
[ -x "$PGBIN/initdb" ] || PGBIN=/usr/lib/postgresql/16/bin
PORT="${DRILL_PORT:-5499}"
WORK="$(mktemp -d /tmp/autos-drill.XXXXXX)"
RUNAS=""; [ "$(id -u)" = "0" ] && RUNAS="runuser -u postgres --" && chown postgres "$WORK"
cleanup() { $RUNAS "$PGBIN/pg_ctl" -D "$WORK/data" -m immediate stop >/dev/null 2>&1 || true; rm -rf "$WORK"; }
trap cleanup EXIT
echo "== 1. backup"
DUMP="$(PGURL="$PGURL" "$HERE/backup.sh" "$WORK/backups" | tail -1)"
[ -n "$RUNAS" ] && chmod -R a+rX "$WORK"
echo "   $DUMP ($(du -h "$DUMP" | cut -f1))"
echo "== 2. fresh cluster on port $PORT"
$RUNAS "$PGBIN/initdb" -D "$WORK/data" -U postgres -A trust >/dev/null
$RUNAS "$PGBIN/pg_ctl" -D "$WORK/data" -o "-p $PORT -k $WORK -c listen_addresses=localhost" -l "$WORK/pg.log" -w start >/dev/null
echo "== 3. restore + verify"
ADMIN_URL="postgresql://postgres@localhost:$PORT/postgres" TARGET_DB=autos_restored "$HERE/restore.sh" "$DUMP"
echo "== 4. smoke test as autos_api (RLS applies)"
APP="postgresql://autos_api:autos_api@localhost:$PORT/autos_restored"
NOCTX="$(psql "$APP" -Atc 'SELECT count(*) FROM customers')"
PLATFORM="$(psql "$APP" -qAtc "BEGIN; SELECT set_config('app.is_platform','on',true); SELECT count(*) FROM customers; COMMIT;" | sed -n 2p)"
echo "   customers visible without tenant context: $NOCTX ; with platform context: $PLATFORM"
[ "$NOCTX" = "0" ] && [ "$PLATFORM" -gt 0 ]
echo "DRILL PASSED"
