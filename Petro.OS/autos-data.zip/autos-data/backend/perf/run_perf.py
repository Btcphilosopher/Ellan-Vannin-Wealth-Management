"""Query-plan inspection and latency measurement on the synthetic dataset.

    AUTOS_PERF_APP_URL=postgresql://autos_api:...@localhost/autos_perf \
    AUTOS_PERF_OWNER_URL=postgresql://autos_owner:...@localhost/autos_perf \
    [AUTOS_PERF_API=http://localhost:8020] python -m perf.run_perf --out ../docs/perf

Every query runs as the RLS-subject application role with a realistic
tenant context, so policy overhead is included in the numbers.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import statistics
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import psycopg

APP = os.environ["AUTOS_PERF_APP_URL"]
OWNER = os.environ["AUTOS_PERF_OWNER_URL"]


def ctx_sql(orgs=(), platform_=False, customer=None):
    return ("SELECT set_config('app.org_ids', %s, false), set_config('app.is_platform', %s, false), "
            "set_config('app.customer_id', %s, false)", ("{" + ",".join(map(str, orgs)) + "}", "on" if platform_ else "off",
                                                          str(customer) if customer else ""))


def pct(values, p):
    s = sorted(values)
    return s[min(len(s) - 1, int(round(p / 100 * (len(s) - 1))))]


def measure(conn, sql, params_fn, n=200):
    times = []
    for i in range(n):
        t0 = time.perf_counter()
        conn.execute(sql, params_fn(i)).fetchall()
        times.append((time.perf_counter() - t0) * 1000)
    return {"n": n, "p50_ms": round(statistics.median(times), 3), "p95_ms": round(pct(times, 95), 3),
            "p99_ms": round(pct(times, 99), 3), "max_ms": round(max(times), 3)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="../docs/perf")
    args = ap.parse_args()
    out = Path(args.out)
    (out / "plans").mkdir(parents=True, exist_ok=True)
    owner = psycopg.connect(OWNER, autocommit=True)
    dealer = owner.execute("SELECT o.id FROM organisations o WHERE slug = 'perf-dealer-7'").fetchone()[0]
    customer = owner.execute("SELECT id FROM customers WHERE display_name = 'Perf Customer 11'").fetchone()[0]
    sample_vins = [r[0] for r in owner.execute("SELECT value_normalized FROM vehicle_identifiers WHERE value LIKE 'PRF%' ORDER BY random() LIMIT 500")]
    sample_listings = [str(r[0]) for r in owner.execute("SELECT id FROM listings WHERE organisation_id = %s ORDER BY random() LIMIT 500", (dealer,))]
    cities = [(-104.99, 39.74), (-87.63, 41.88), (-95.37, 29.76), (-118.24, 34.05), (-122.68, 45.52), (-84.39, 33.75), (-74.0, 40.71)]
    env = {
        "postgres": owner.execute("SHOW server_version").fetchone()[0],
        "postgis": owner.execute("SELECT postgis_lib_version()").fetchone()[0],
        "shared_buffers": owner.execute("SHOW shared_buffers").fetchone()[0],
        "work_mem": owner.execute("SHOW work_mem").fetchone()[0],
        "cpus": os.cpu_count(), "python": platform.python_version(), "machine": platform.machine(),
        "db_size": owner.execute("SELECT pg_size_pretty(pg_database_size(current_database()))").fetchone()[0],
        "rows": {t: owner.execute(f"SELECT count(*) FROM {t}").fetchone()[0] for t in
                 ("vehicles", "listings", "listing_price_versions", "sale_reservations", "audit_events", "locations", "customers")},
    }

    queries = {
        "radius_search_50km_price_band (customer context, public listings)": (
            {"customer": customer},
            """SELECT l.id, l.title, p.amount_minor
                 FROM listings l LEFT JOIN listing_price_versions p ON p.id = l.current_price_version_id
                WHERE l.status = 'published' AND p.amount_minor BETWEEN 2000000 AND 4000000
                  AND l.location_id = ANY(locations_within(%s, %s, 50000))
                ORDER BY l.updated_at DESC, l.id DESC LIMIT 50""",
            lambda i: cities[i % len(cities)]),
        "dealer_inventory_page (dealer context)": (
            {"orgs": [dealer]},
            """SELECT l.id, l.title, l.status, l.updated_at FROM listings l
                WHERE l.organisation_id = %s AND l.status = 'published' ORDER BY l.updated_at DESC, l.id DESC LIMIT 50""",
            lambda i: (dealer,)),
        "vin_lookup (dealer context, RLS via vehicle visibility)": (
            {"orgs": [dealer]},
            """SELECT vehicle_id FROM vehicle_identifiers WHERE namespace = 'vin' AND value_normalized = %s AND retired_at IS NULL""",
            lambda i: (sample_vins[i % len(sample_vins)],)),
        "listing_audit_history (dealer context)": (
            {"orgs": [dealer]},
            """SELECT id, action, occurred_at FROM audit_events WHERE target_type = 'listing' AND target_id = %s
                ORDER BY occurred_at DESC LIMIT 50""",
            lambda i: (sample_listings[i % len(sample_listings)],)),
        "listing_detail_with_price_history (dealer context)": (
            {"orgs": [dealer]},
            """SELECT l.*, p.amount_minor, (SELECT count(*) FROM listing_status_events e WHERE e.listing_id = l.id) AS events
                 FROM listings l LEFT JOIN listing_price_versions p ON p.listing_id = l.id WHERE l.id = %s""",
            lambda i: (sample_listings[i % len(sample_listings)],)),
        "reservation_funnel_report (dealer context)": (
            {"orgs": [dealer]},
            """SELECT status, deposit_status, count(*) FROM sale_reservations WHERE organisation_id = %s GROUP BY 1, 2""",
            lambda i: (dealer,)),
    }

    results = {"environment": env, "queries": {}, "writes": {}}
    for name, (ctx, sql, pfn) in queries.items():
        conn = psycopg.connect(APP, autocommit=True)
        conn.execute(*ctx_sql(ctx.get("orgs", ()), customer=ctx.get("customer")))
        for i in range(20):
            conn.execute(sql, pfn(i)).fetchall()  # warm cache
        plan = "\n".join(r[0] for r in conn.execute("EXPLAIN (ANALYZE, BUFFERS, SETTINGS) " + sql, pfn(0)))
        slug = name.split(" ")[0]
        (out / "plans" / f"{slug}.txt").write_text(f"-- {name}\n{sql}\n\n{plan}\n")
        stats = measure(conn, sql, pfn)
        stats["rows_returned"] = len(conn.execute(sql, pfn(0)).fetchall())
        stats["plan_nodes"] = [ln.strip().split("  (")[0] for ln in plan.splitlines() if "Scan" in ln or "Join" in ln or "Loop" in ln][:8]
        results["queries"][name] = stats
        print(f"{name:72s} p50 {stats['p50_ms']:7.2f} ms  p95 {stats['p95_ms']:7.2f} ms")
        conn.close()

    # ---- reservation writes at the database level ---------------------------------
    free = [r for r in owner.execute("""
        SELECT l.id, l.vehicle_id, l.organisation_id FROM listings l
         WHERE l.status = 'published' AND l.title LIKE 'Perf listing%%'
           AND NOT EXISTS (SELECT 1 FROM vehicle_current_reservations c WHERE c.vehicle_id = l.vehicle_id)
         ORDER BY random() LIMIT 2000""")]
    customers = [r[0] for r in owner.execute("SELECT id FROM customers WHERE display_name LIKE 'Perf Customer%%' LIMIT 200")]
    ins = """INSERT INTO sale_reservations (organisation_id, listing_id, vehicle_id, customer_id, deposit_required_minor,
                                            deposit_status, currency, hold_expires_at)
             VALUES (%s, %s, %s, %s, 0, 'not_required', 'USD', now() + interval '30 minutes')"""

    def one(conn, item, cust):
        with conn.transaction():
            conn.execute("SELECT set_config('app.org_ids', %s, true)", ("{" + str(item[2]) + "}",))
            conn.execute(ins, (item[2], item[0], item[1], cust))

    conn = psycopg.connect(APP, autocommit=True)
    lat = []
    for i, item in enumerate(free[:300]):
        t0 = time.perf_counter()
        one(conn, item, customers[i % len(customers)])
        lat.append((time.perf_counter() - t0) * 1000)
    conn.close()
    results["writes"]["reservation_insert_sequential"] = {"n": len(lat), "p50_ms": round(statistics.median(lat), 3),
                                                          "p95_ms": round(pct(lat, 95), 3), "max_ms": round(max(lat), 3)}
    print("reservation insert sequential", results["writes"]["reservation_insert_sequential"])

    for threads in (4, 16):
        batch = free[300 + (0 if threads == 4 else 600): 300 + (600 if threads == 4 else 1400)]
        per = len(batch) // threads
        errors = []

        def worker(k):
            c = psycopg.connect(APP, autocommit=True)
            for j in range(per):
                try:
                    one(c, batch[k * per + j], customers[(k + j) % len(customers)])
                except Exception as e:  # noqa: BLE001
                    errors.append(type(e).__name__)
            c.close()

        t0 = time.perf_counter()
        with ThreadPoolExecutor(threads) as ex:
            list(ex.map(worker, range(threads)))
        el = time.perf_counter() - t0
        results["writes"][f"reservation_insert_distinct_vehicles_{threads}_threads"] = {
            "transactions": per * threads, "seconds": round(el, 2), "tx_per_s": round(per * threads / el, 1), "errors": len(errors)}
        print(threads, "threads", results["writes"][f"reservation_insert_distinct_vehicles_{threads}_threads"])

    contested = free[1999]  # never used by the batches above
    barrier = threading.Barrier(32)
    outcome = []

    def contend(k):
        c = psycopg.connect(APP, autocommit=True)
        barrier.wait()
        t0 = time.perf_counter()
        try:
            one(c, contested, customers[k])
            outcome.append(("ok", (time.perf_counter() - t0) * 1000))
        except psycopg.Error as e:
            outcome.append((e.sqlstate, (time.perf_counter() - t0) * 1000))
        c.close()

    with ThreadPoolExecutor(32) as ex:
        list(ex.map(contend, range(32)))
    from collections import Counter
    results["writes"]["same_vehicle_32_concurrent"] = {"outcomes": dict(Counter(o for o, _ in outcome)),
                                                       "max_wait_ms": round(max(t for _, t in outcome), 1)}
    print("contention", results["writes"]["same_vehicle_32_concurrent"])

    # ---- HTTP end-to-end (optional) --------------------------------------------
    api = os.environ.get("AUTOS_PERF_API")
    if api:
        import httpx
        tok = httpx.post(f"{api}/v1/auth/token", json={"email": "admin@harbourview.example"}).json()["access_token"]
        hv = owner.execute("SELECT id FROM organisations WHERE slug = 'harbourview-motors'").fetchone()[0]
        import subprocess
        for label, url in (("GET /v1/listings radius 50km (Denver)", f"{api}/v1/listings?status=published&lat=39.74&lon=-104.99&radius_km=50&limit=20"),
                           ("GET /v1/listings radius 100km (Chicago)", f"{api}/v1/listings?status=published&lat=41.88&lon=-87.63&radius_km=100&limit=20"),
                           ("GET /v1/listings published page", f"{api}/v1/listings?status=published&limit=20"),
                           ("GET /v1/listings dealer page (all statuses)", f"{api}/v1/listings?organisation_id={hv}&limit=20"),
                           ("GET /v1/reports/overview", f"{api}/v1/reports/overview"),
                           ("GET /v1/me", f"{api}/v1/me")):
            ts = []
            for i in range(65):
                o = subprocess.run(["curl", "-s", "-o", "/dev/null", "-w", "%{http_code} %{time_total}", "-H", f"Authorization: Bearer {tok}", url],
                                   capture_output=True, text=True).stdout.split()
                assert o[0] == "200", o
                if i >= 5:
                    ts.append(float(o[1]) * 1000)
            results["queries"][f"HTTP {label}"] = {"n": len(ts), "p50_ms": round(statistics.median(ts), 2),
                                                   "p95_ms": round(pct(ts, 95), 2), "max_ms": round(max(ts), 2)}
            print(label, results["queries"][f"HTTP {label}"])
    (out / "results.json").write_text(json.dumps(results, indent=2, default=str))
    print("wrote", out / "results.json")


if __name__ == "__main__":
    main()
