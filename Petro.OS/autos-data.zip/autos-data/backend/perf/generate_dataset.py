"""Synthetic performance dataset (documented in docs/PERFORMANCE.md).

    AUTOS_MIGRATION_DATABASE_URL=... python -m perf.generate_dataset --dealers 60 --vehicles 200000

Bulk-generated with set-based SQL as the schema owner. All integrity
triggers still fire (listing status history, reservation commitment, etc.),
so the data obeys the same invariants as production writes. Deterministic
via setseed().
"""
from __future__ import annotations

import argparse
import os
import time

from sqlalchemy import create_engine, text

STEPS = [
    ("dealers", """
        INSERT INTO organisations (kind, legal_name, display_name, slug, default_currency, default_timezone)
        SELECT 'dealer', 'Perf Dealer ' || g || ' (synthetic)', 'Perf Dealer ' || g, 'perf-dealer-' || g, 'USD', 'America/Chicago'
          FROM generate_series(1, :dealers) g"""),
    ("locations", """
        INSERT INTO locations (organisation_id, code, name, kind, address_line1, city, country_code, geog, timezone)
        SELECT o.id, 'L' || l, o.display_name || ' site ' || l, 'dealership', 'Synthetic Rd', 'Perfville', 'US',
               ST_SetSRID(ST_MakePoint(-124 + random() * 57, 26 + random() * 22), 4326)::geography, 'America/Chicago'
          FROM organisations o CROSS JOIN generate_series(1, :locs_per_dealer) l
         WHERE o.slug LIKE 'perf-dealer-%'"""),
    ("vehicles", """
        WITH locs AS (SELECT array_agg(l.id ORDER BY l.id) AS ids, array_agg(l.organisation_id ORDER BY l.id) AS orgs
                        FROM locations l JOIN organisations o ON o.id = l.organisation_id WHERE o.slug LIKE 'perf-dealer-%'),
             trims AS (SELECT array_agg(id ORDER BY id) AS ids FROM vehicle_trims)
        INSERT INTO vehicles (custodian_organisation_id, current_location_id, trim_id, model_year, exterior_colour, condition,
                              odometer_value, odometer_unit, odometer_recorded_at)
        SELECT locs.orgs[1 + g % cardinality(locs.ids)], locs.ids[1 + g % cardinality(locs.ids)], trims.ids[1 + g % cardinality(trims.ids)],
               2020 + (g % 7), (ARRAY['White','Black','Gray','Blue','Red'])[1 + g % 5],
               CASE WHEN g % 3 = 0 THEN 'used' ELSE 'new' END, (g * 37) % 90000, 'mi', now()
          FROM generate_series(1, :vehicles) g, locs, trims"""),
    ("vin identifiers", """
        INSERT INTO vehicle_identifiers (vehicle_id, namespace, value, is_synthetic, source)
        SELECT v.id, 'vin', 'PRF' || upper(substr(md5(v.id::text), 1, 5)) || '0' || 'T' || 'A' || lpad((row_number() OVER ())::text, 6, '0'), true, 'perf'
          FROM vehicles v JOIN organisations o ON o.id = v.custodian_organisation_id WHERE o.slug LIKE 'perf-dealer-%'"""),
    ("listings (draft)", """
        INSERT INTO listings (organisation_id, vehicle_id, location_id, title, currency, sale_eligibility, deposit_required_minor)
        SELECT v.custodian_organisation_id, v.id, v.current_location_id, 'Perf listing ' || v.model_year, 'USD', 'eligible', 50000
          FROM vehicles v JOIN organisations o ON o.id = v.custodian_organisation_id WHERE o.slug LIKE 'perf-dealer-%'"""),
    ("price versions", """
        INSERT INTO listing_price_versions (listing_id, organisation_id, amount_minor, currency, reason, effective_from)
        SELECT l.id, l.organisation_id, (1500000 + (abs(hashtext(l.id::text)) % 5000000))::bigint, 'USD', 'initial', now() - interval '30 days'
          FROM listings l JOIN organisations o ON o.id = l.organisation_id WHERE o.slug LIKE 'perf-dealer-%'"""),
    ("link current price", """
        UPDATE listings l SET current_price_version_id = p.id FROM listing_price_versions p
         WHERE p.listing_id = l.id AND l.title LIKE 'Perf listing%'"""),
    ("publish 90%", """
        UPDATE listings SET status = 'published' WHERE title LIKE 'Perf listing%' AND abs(hashtext(id::text)) % 10 <> 0"""),
    ("customers", """
        INSERT INTO customers (display_name, email) SELECT 'Perf Customer ' || g, 'perf' || g || '@customers.example'
          FROM generate_series(1, :customers) g"""),
    ("reservation history (held -> cancelled)", """
        WITH picked AS (
          SELECT l.id AS listing_id, l.vehicle_id, l.organisation_id, row_number() OVER () AS n
            FROM listings l WHERE l.status = 'published' AND l.title LIKE 'Perf listing%' ORDER BY l.id LIMIT :reservations),
        cust AS (SELECT id, row_number() OVER () AS n FROM customers WHERE display_name LIKE 'Perf Customer%')
        INSERT INTO sale_reservations (organisation_id, listing_id, vehicle_id, customer_id, deposit_required_minor, deposit_status, currency, hold_expires_at)
        SELECT p.organisation_id, p.listing_id, p.vehicle_id, c.id, 0, 'not_required', 'USD', now() + interval '30 minutes'
          FROM picked p JOIN cust c ON c.n = 1 + (p.n % :customers)"""),
    ("end 80% of reservations", """
        UPDATE sale_reservations SET status = 'cancelled', end_reason = 'perf'
         WHERE status = 'held' AND abs(hashtext(id::text)) % 5 <> 0
           AND listing_id IN (SELECT id FROM listings WHERE title LIKE 'Perf listing%')"""),
    ("audit events", """
        INSERT INTO audit_events (actor_kind, organisation_id, action, target_type, target_id, changes)
        SELECT 'system', l.organisation_id, 'listing.updated', 'listing', l.id::text, '{}'::jsonb
          FROM listings l CROSS JOIN generate_series(1, :audit_per_listing) WHERE l.title LIKE 'Perf listing%'"""),
    ("analyze", "ANALYZE"),
]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dealers", type=int, default=60)
    ap.add_argument("--locs-per-dealer", type=int, default=8)
    ap.add_argument("--vehicles", type=int, default=200_000)
    ap.add_argument("--customers", type=int, default=50_000)
    ap.add_argument("--reservations", type=int, default=50_000)
    ap.add_argument("--audit-per-listing", type=int, default=3)
    a = ap.parse_args()
    params = {"dealers": a.dealers, "locs_per_dealer": a.locs_per_dealer, "vehicles": a.vehicles, "customers": a.customers,
              "reservations": a.reservations, "audit_per_listing": a.audit_per_listing}
    eng = create_engine(os.environ["AUTOS_MIGRATION_DATABASE_URL"], isolation_level="AUTOCOMMIT")
    with eng.connect() as c:
        c.execute(text("SELECT setseed(0.42)"))
        for name, sql in STEPS:
            t0 = time.perf_counter()
            r = c.execute(text(sql), {k: v for k, v in params.items() if f":{k}" in sql})
            print(f"{name:42s} {r.rowcount if r.rowcount >= 0 else '':>9} rows  {time.perf_counter() - t0:7.1f}s", flush=True)
        for t in ("vehicles", "listings", "listing_price_versions", "listing_status_events", "sale_reservations", "audit_events", "customers", "locations"):
            print(f"  {t:28s} {c.execute(text(f'SELECT count(*) FROM {t}')).scalar():>10,}")
        print("  database size", c.execute(text("SELECT pg_size_pretty(pg_database_size(current_database()))")).scalar())


if __name__ == "__main__":
    main()
