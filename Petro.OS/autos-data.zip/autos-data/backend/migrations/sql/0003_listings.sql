-- =====================================================================
-- AUTOS DATA — 0003 Listings, price versions, status history
-- Listing publication is separate from physical availability
-- (vehicles.availability_status).
-- =====================================================================

CREATE TABLE listings (
  id                        uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id           uuid NOT NULL REFERENCES organisations(id),
  vehicle_id                uuid NOT NULL REFERENCES vehicles(id),
  location_id               uuid NOT NULL,
  channel                   text NOT NULL DEFAULT 'marketplace' CHECK (channel IN ('marketplace','dealer_site','partner_syndication')),
  title                     text NOT NULL CHECK (length(btrim(title)) > 0),
  description               text NULL,
  status                    text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','suspended','withdrawn','sold')),
  status_reason             text NULL,
  sale_eligibility          text NOT NULL DEFAULT 'pending_review' CHECK (sale_eligibility IN ('eligible','not_eligible','pending_review')),
  currency                  char(3) NOT NULL REFERENCES currencies(code),
  current_price_version_id  uuid NULL,
  deposit_required_minor    bigint NOT NULL DEFAULT 0 CHECK (deposit_required_minor >= 0),
  source_namespace          text NULL,
  source_record_id          text NULL,
  source_last_seen_at       timestamptz NULL,
  freshness_state           text NOT NULL DEFAULT 'not_applicable' CHECK (freshness_state IN ('fresh','stale','expired','not_applicable')),
  effective_from            timestamptz NULL,
  effective_to              timestamptz NULL,
  published_at              timestamptz NULL,
  withdrawn_at              timestamptz NULL,
  sold_at                   timestamptz NULL,
  created_by                uuid NULL REFERENCES app_users(id),
  created_at                timestamptz NOT NULL DEFAULT now(),
  updated_at                timestamptz NOT NULL DEFAULT now(),
  version                   integer NOT NULL DEFAULT 1,
  FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id),
  UNIQUE (id, organisation_id),
  UNIQUE (id, currency),
  CHECK (effective_to IS NULL OR effective_from IS NULL OR effective_to > effective_from),
  CHECK ((source_namespace IS NULL) = (source_record_id IS NULL)),
  CHECK (status <> 'published' OR current_price_version_id IS NOT NULL),
  CHECK (status <> 'published' OR published_at IS NOT NULL)
);
COMMENT ON TABLE listings IS 'A seller''s offer of a physical vehicle on a channel. Status changes are recorded automatically in listing_status_events.';
COMMENT ON COLUMN listings.freshness_state IS 'For source-fed listings: fresh/stale/expired relative to source_last_seen_at and the organisation freshness policy. Staleness never implies availability.';
COMMENT ON COLUMN listings.deposit_required_minor IS 'Deposit payable to secure a sale hold. A deposit is a payment towards the price, never an additional charge.';
CREATE UNIQUE INDEX listings_one_open_per_vehicle_channel_uq ON listings (organisation_id, channel, vehicle_id)
  WHERE status IN ('draft','published','suspended');
CREATE INDEX listings_status_location_idx ON listings (status, location_id);
CREATE INDEX listings_vehicle_idx ON listings (vehicle_id);
CREATE INDEX listings_org_status_idx ON listings (organisation_id, status, updated_at DESC);
CREATE INDEX listings_source_idx ON listings (organisation_id, source_namespace, source_record_id) WHERE source_record_id IS NOT NULL;
CREATE INDEX listings_freshness_idx ON listings (source_last_seen_at) WHERE status = 'published' AND source_last_seen_at IS NOT NULL;
CREATE INDEX listings_title_trgm ON listings USING gin (title gin_trgm_ops);

CREATE TABLE listing_price_versions (
  id               uuid PRIMARY KEY DEFAULT uuid_v7(),
  listing_id       uuid NOT NULL,
  organisation_id  uuid NOT NULL,
  amount_minor     bigint NOT NULL CHECK (amount_minor > 0 AND amount_minor < 100000000000),
  currency         char(3) NOT NULL REFERENCES currencies(code),
  effective_from   timestamptz NOT NULL DEFAULT now(),
  effective_to     timestamptz NULL,
  reason           text NOT NULL CHECK (reason IN ('initial','price_change','import','correction','promotion')),
  source           text NOT NULL DEFAULT 'manual',
  created_by       uuid NULL REFERENCES app_users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id),
  FOREIGN KEY (listing_id, currency) REFERENCES listings(id, currency),
  UNIQUE (id, listing_id),
  CHECK (effective_to IS NULL OR effective_to > effective_from),
  EXCLUDE USING gist (listing_id WITH =, tstzrange(effective_from, effective_to, '[)') WITH &&)
);
COMMENT ON TABLE listing_price_versions IS 'Append-only asking-price history. Non-overlapping [effective_from, effective_to) per listing (exclusion constraint). Only effective_to may be set, once, to close a version.';
CREATE INDEX listing_price_versions_listing_idx ON listing_price_versions (listing_id, effective_from DESC);
CREATE INDEX listing_price_versions_amount_idx ON listing_price_versions (amount_minor) WHERE effective_to IS NULL;

ALTER TABLE listings
  ADD CONSTRAINT listings_current_price_fk FOREIGN KEY (current_price_version_id, id)
  REFERENCES listing_price_versions(id, listing_id) DEFERRABLE INITIALLY DEFERRED;

CREATE FUNCTION trg_price_versions_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9010', MESSAGE = 'append_only: listing_price_versions cannot be deleted';
  END IF;
  IF OLD.effective_to IS NOT NULL
     OR (NEW.id, NEW.listing_id, NEW.organisation_id, NEW.amount_minor, NEW.currency, NEW.effective_from, NEW.reason, NEW.source, NEW.created_by, NEW.created_at)
        IS DISTINCT FROM
        (OLD.id, OLD.listing_id, OLD.organisation_id, OLD.amount_minor, OLD.currency, OLD.effective_from, OLD.reason, OLD.source, OLD.created_by, OLD.created_at)
  THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: a price version can only be closed (effective_to set once)';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER listing_price_versions_guard BEFORE UPDATE OR DELETE ON listing_price_versions
  FOR EACH ROW EXECUTE FUNCTION trg_price_versions_guard();

CREATE TABLE listing_status_events (
  id               uuid PRIMARY KEY DEFAULT uuid_v7(),
  listing_id       uuid NOT NULL,
  organisation_id  uuid NOT NULL,
  from_status      text NULL,
  to_status        text NOT NULL,
  reason           text NULL,
  actor_user_id    uuid NULL REFERENCES app_users(id),
  actor_kind       text NOT NULL,
  request_id       text NULL,
  occurred_at      timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id)
);
COMMENT ON TABLE listing_status_events IS 'Append-only publication history, written by trigger on every listings.status change.';
CREATE INDEX listing_status_events_listing_idx ON listing_status_events (listing_id, occurred_at);
CREATE TRIGGER listing_status_events_append BEFORE UPDATE OR DELETE ON listing_status_events
  FOR EACH ROW EXECUTE FUNCTION trg_append_only();

-- Allowed listing transitions (defence in depth; the service layer
-- performs the same checks and returns friendlier validation findings).
CREATE FUNCTION trg_listings_status() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE
  ok boolean;
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status NOT IN ('draft') THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: listings start as draft, not %s', NEW.status);
    END IF;
    INSERT INTO listing_status_events (listing_id, organisation_id, from_status, to_status, reason, actor_user_id, actor_kind, request_id)
    VALUES (NEW.id, NEW.organisation_id, NULL, NEW.status, NEW.status_reason, app_user_id(), app_actor_kind(), app_request_id());
    RETURN NEW;
  END IF;

  IF NEW.vehicle_id <> OLD.vehicle_id OR NEW.organisation_id <> OLD.organisation_id OR NEW.currency <> OLD.currency THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: listing vehicle, seller and currency are fixed; create a new listing instead';
  END IF;

  IF NEW.status IS DISTINCT FROM OLD.status THEN
    ok := (OLD.status, NEW.status) IN (
      ('draft','published'), ('draft','withdrawn'),
      ('published','suspended'), ('published','withdrawn'), ('published','sold'),
      ('suspended','published'), ('suspended','withdrawn'), ('suspended','sold'));
    IF NOT ok THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: listing %s -> %s', OLD.status, NEW.status);
    END IF;
    IF NEW.status = 'published' AND NEW.published_at IS NULL THEN NEW.published_at := now(); END IF;
    IF NEW.status = 'withdrawn' THEN NEW.withdrawn_at := now(); END IF;
    IF NEW.status = 'sold' THEN NEW.sold_at := now(); END IF;
    INSERT INTO listing_status_events (listing_id, organisation_id, from_status, to_status, reason, actor_user_id, actor_kind, request_id)
    VALUES (NEW.id, NEW.organisation_id, OLD.status, NEW.status, NEW.status_reason, app_user_id(), app_actor_kind(), app_request_id());
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER listings_status AFTER INSERT ON listings FOR EACH ROW EXECUTE FUNCTION trg_listings_status();
CREATE TRIGGER listings_status_upd BEFORE UPDATE ON listings FOR EACH ROW EXECUTE FUNCTION trg_listings_status();
CREATE TRIGGER listings_touch BEFORE UPDATE ON listings FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER listings_no_delete BEFORE DELETE ON listings FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

-- @@DOWN@@
DROP TABLE IF EXISTS listing_status_events, listing_price_versions, listings CASCADE;
DROP FUNCTION IF EXISTS trg_listings_status(), trg_price_versions_guard();
