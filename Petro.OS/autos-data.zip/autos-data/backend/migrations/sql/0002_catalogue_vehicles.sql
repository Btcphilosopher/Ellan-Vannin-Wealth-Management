-- =====================================================================
-- AUTOS DATA — 0002 Catalogue, physical vehicles, identity & provenance
--
-- Four distinct concepts are kept apart:
--   specification  : vehicle_makes / vehicle_models / vehicle_trims /
--                    vehicle_specification_versions (what a trim IS)
--   physical       : vehicles (+ identifiers, features, assertions, media)
--   listing        : listings (0003) — an offer by a seller
--   external record: source_record_mappings (0010)
-- =====================================================================

CREATE TABLE vehicle_makes (
  id          uuid PRIMARY KEY DEFAULT uuid_v7(),
  name        citext NOT NULL UNIQUE,
  slug        text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9][a-z0-9-]*$'),
  created_at  timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE vehicle_makes IS 'Manufacturer brands (catalogue reference data).';

CREATE TABLE vehicle_models (
  id          uuid PRIMARY KEY DEFAULT uuid_v7(),
  make_id     uuid NOT NULL REFERENCES vehicle_makes(id),
  name        text NOT NULL,
  slug        text NOT NULL CHECK (slug ~ '^[a-z0-9][a-z0-9-]*$'),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (make_id, slug)
);
COMMENT ON TABLE vehicle_models IS 'Model lines of a make (e.g. Tucson).';

CREATE TABLE vehicle_trims (
  id          uuid PRIMARY KEY DEFAULT uuid_v7(),
  model_id    uuid NOT NULL REFERENCES vehicle_models(id),
  model_year  smallint NOT NULL CHECK (model_year BETWEEN 1950 AND 2100),
  name        text NOT NULL,
  body_style  text NULL CHECK (body_style IN ('sedan','suv','crossover','hatchback','wagon','coupe','convertible','pickup','van','other')),
  drivetrain  text NULL CHECK (drivetrain IN ('fwd','rwd','awd','4wd')),
  fuel_type   text NULL CHECK (fuel_type IN ('petrol','diesel','hybrid','plug_in_hybrid','electric','hydrogen','other')),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (model_id, model_year, name)
);
COMMENT ON TABLE vehicle_trims IS 'A model-year trim (e.g. 2026 Tucson SEL). NULL attributes are unknown, not "none".';

CREATE TABLE vehicle_specification_versions (
  id                     uuid PRIMARY KEY DEFAULT uuid_v7(),
  trim_id                uuid NOT NULL REFERENCES vehicle_trims(id),
  source                 text NOT NULL CHECK (source ~ '^[a-z][a-z0-9_.:-]{1,63}$'),
  source_reference       text NULL,
  effective_from         date NOT NULL,
  effective_to           date NULL CHECK (effective_to IS NULL OR effective_to > effective_from),
  verification_status    text NOT NULL DEFAULT 'unverified' CHECK (verification_status IN ('unverified','verified','superseded','disputed')),
  msrp_minor             bigint NULL CHECK (msrp_minor IS NULL OR msrp_minor > 0),
  msrp_currency          char(3) NULL REFERENCES currencies(code),
  doors                  smallint NULL CHECK (doors BETWEEN 1 AND 8),
  seats                  smallint NULL CHECK (seats BETWEEN 1 AND 15),
  engine_displacement_cc integer NULL CHECK (engine_displacement_cc > 0),
  battery_capacity_kwh   numeric(6,2) NULL CHECK (battery_capacity_kwh > 0),
  power_kw               numeric(7,2) NULL CHECK (power_kw > 0),
  electric_range_km      integer NULL CHECK (electric_range_km > 0),
  combined_l_per_100km   numeric(5,2) NULL CHECK (combined_l_per_100km > 0),
  attributes             jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(attributes) = 'object'),
  recorded_at            timestamptz NOT NULL DEFAULT now(),
  recorded_by            uuid NULL REFERENCES app_users(id),
  CHECK ((msrp_minor IS NULL) = (msrp_currency IS NULL)),
  EXCLUDE USING gist (trim_id WITH =, source WITH =, daterange(effective_from, effective_to, '[)') WITH &&)
);
COMMENT ON TABLE vehicle_specification_versions IS 'Manufacturer/catalogue specification for a trim, versioned by effective date per source. New facts create a new version; history is never rewritten.';
COMMENT ON COLUMN vehicle_specification_versions.attributes IS 'JSONB for long-tail spec attributes that vary by source (justified: heterogeneous, read-mostly, never joined on). Core specs are typed columns.';
CREATE TRIGGER vehicle_specification_versions_append BEFORE DELETE ON vehicle_specification_versions FOR EACH ROW EXECUTE FUNCTION trg_append_only();

-- ---------------------------------------------------------------------
-- Physical vehicles
-- ---------------------------------------------------------------------
CREATE TABLE vehicles (
  id                         uuid PRIMARY KEY DEFAULT uuid_v7(),
  trim_id                    uuid NULL REFERENCES vehicle_trims(id),
  custodian_organisation_id  uuid NOT NULL REFERENCES organisations(id),
  current_location_id        uuid NULL,
  model_year                 smallint NULL CHECK (model_year BETWEEN 1950 AND 2100),
  exterior_colour            text NULL,
  interior_colour            text NULL,
  condition                  text NOT NULL DEFAULT 'unknown' CHECK (condition IN ('new','used','certified_pre_owned','unknown')),
  odometer_value             integer NULL CHECK (odometer_value >= 0),
  odometer_unit              text NULL CHECK (odometer_unit IN ('km','mi')),
  odometer_recorded_at       timestamptz NULL,
  has_open_recall            boolean NULL,
  keys_count                 smallint NULL CHECK (keys_count >= 0),
  availability_status        text NOT NULL DEFAULT 'available'
                               CHECK (availability_status IN ('available','in_transit','unavailable','sold','written_off')),
  sold_at                    timestamptz NULL,
  merged_into_vehicle_id     uuid NULL REFERENCES vehicles(id),
  created_at                 timestamptz NOT NULL DEFAULT now(),
  updated_at                 timestamptz NOT NULL DEFAULT now(),
  version                    integer NOT NULL DEFAULT 1,
  archived_at                timestamptz NULL,
  FOREIGN KEY (current_location_id, custodian_organisation_id) REFERENCES locations(id, organisation_id),
  CHECK ((odometer_value IS NULL) = (odometer_unit IS NULL)),
  CHECK (odometer_value IS NULL OR odometer_recorded_at IS NOT NULL),
  CHECK ((availability_status = 'sold') = (sold_at IS NOT NULL)),
  CHECK (merged_into_vehicle_id IS NULL OR (merged_into_vehicle_id <> id AND archived_at IS NOT NULL))
);
COMMENT ON TABLE vehicles IS 'Exact physical vehicles. One vehicle may be offered by several listings; availability here is physical, independent of listing publication.';
COMMENT ON COLUMN vehicles.odometer_value IS 'NULL = unknown. 0 = a genuinely zero reading. Always paired with odometer_unit.';
COMMENT ON COLUMN vehicles.has_open_recall IS 'NULL = not yet checked; false = checked, none open.';
COMMENT ON COLUMN vehicles.custodian_organisation_id IS 'Organisation physically responsible for the vehicle (tenant boundary for unpublished data).';
CREATE INDEX vehicles_custodian_idx ON vehicles (custodian_organisation_id, availability_status);
CREATE INDEX vehicles_trim_idx ON vehicles (trim_id);
CREATE TRIGGER vehicles_touch BEFORE UPDATE ON vehicles FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER vehicles_no_delete BEFORE DELETE ON vehicles FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

-- External/legal identifiers, always namespaced.
CREATE TABLE vehicle_identifiers (
  id                       uuid PRIMARY KEY DEFAULT uuid_v7(),
  vehicle_id               uuid NOT NULL REFERENCES vehicles(id),
  namespace                text NOT NULL CHECK (namespace ~ '^[a-z][a-z0-9_.:-]{1,63}$'),
  value                    text NOT NULL CHECK (length(btrim(value)) > 0),
  value_normalized         text GENERATED ALWAYS AS (upper(regexp_replace(value, '[\s-]', '', 'g'))) STORED,
  issuing_organisation_id  uuid NULL REFERENCES organisations(id),
  is_synthetic             boolean NOT NULL DEFAULT false,
  verification_status      text NOT NULL DEFAULT 'unverified' CHECK (verification_status IN ('unverified','verified','disputed')),
  source                   text NOT NULL,
  recorded_at              timestamptz NOT NULL DEFAULT now(),
  retired_at               timestamptz NULL,
  retired_reason           text NULL,
  CHECK (namespace <> 'vin' OR value_normalized ~ '^[A-HJ-NPR-Z0-9]{17}$'),
  CHECK ((retired_at IS NULL) = (retired_reason IS NULL))
);
COMMENT ON TABLE vehicle_identifiers IS 'Namespaced identifiers (vin, registration:<region>, stock:<dealer>, source:<system>). Uniqueness is per namespace (+issuer), never by descriptive attributes.';
COMMENT ON COLUMN vehicle_identifiers.is_synthetic IS 'True for generated demo identifiers. All demo VINs are synthetic and do not identify real vehicles.';
CREATE UNIQUE INDEX vehicle_identifiers_active_uq ON vehicle_identifiers (namespace, issuing_organisation_id, value_normalized) NULLS NOT DISTINCT
  WHERE retired_at IS NULL;
CREATE INDEX vehicle_identifiers_vehicle_idx ON vehicle_identifiers (vehicle_id);
CREATE TRIGGER vehicle_identifiers_no_delete BEFORE DELETE ON vehicle_identifiers FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

-- Provenance-carrying assertions about a vehicle: manufacturer data,
-- seller claims and inspection findings are separate rows, never merged.
CREATE TABLE vehicle_attribute_assertions (
  id                   uuid PRIMARY KEY DEFAULT uuid_v7(),
  vehicle_id           uuid NOT NULL REFERENCES vehicles(id),
  organisation_id      uuid NOT NULL REFERENCES organisations(id),
  attribute            text NOT NULL CHECK (attribute ~ '^[a-z][a-z0-9_]{1,63}$'),
  assertion_type       text NOT NULL CHECK (assertion_type IN ('manufacturer','seller_claim','inspection_finding','import_source','registry')),
  value                jsonb NOT NULL,
  unit                 text NULL,
  source               text NOT NULL,
  source_reference     text NULL,
  effective_at         timestamptz NOT NULL,
  verification_status  text NOT NULL DEFAULT 'unverified' CHECK (verification_status IN ('unverified','verified','disputed','superseded')),
  supersedes_id        uuid NULL REFERENCES vehicle_attribute_assertions(id),
  recorded_by          uuid NULL REFERENCES app_users(id),
  recorded_at          timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE vehicle_attribute_assertions IS 'Who said what about a vehicle, when, and whether it was verified. value is JSONB because attributes are heterogeneous (number, text, list).';
CREATE INDEX vehicle_attribute_assertions_vehicle_idx ON vehicle_attribute_assertions (vehicle_id, attribute, effective_at DESC);
CREATE TRIGGER vehicle_attribute_assertions_no_delete BEFORE DELETE ON vehicle_attribute_assertions FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

CREATE TABLE vehicle_features (
  id                   uuid PRIMARY KEY DEFAULT uuid_v7(),
  vehicle_id           uuid NOT NULL REFERENCES vehicles(id),
  feature_code         text NOT NULL CHECK (feature_code ~ '^[a-z][a-z0-9_]{1,63}$'),
  label                text NOT NULL,
  assertion_type       text NOT NULL CHECK (assertion_type IN ('manufacturer','seller_claim','inspection_finding','import_source')),
  source               text NOT NULL,
  verification_status  text NOT NULL DEFAULT 'unverified' CHECK (verification_status IN ('unverified','verified','disputed')),
  recorded_at          timestamptz NOT NULL DEFAULT now(),
  UNIQUE (vehicle_id, feature_code, assertion_type, source)
);
COMMENT ON TABLE vehicle_features IS 'Equipment/features per vehicle with provenance.';

CREATE TABLE vehicle_media (
  id               uuid PRIMARY KEY DEFAULT uuid_v7(),
  vehicle_id       uuid NOT NULL REFERENCES vehicles(id),
  organisation_id  uuid NOT NULL REFERENCES organisations(id),
  kind             text NOT NULL CHECK (kind IN ('photo','document','inspection_report','agreement')),
  storage_bucket   text NOT NULL,
  object_key       text NOT NULL,
  content_type     text NOT NULL CHECK (content_type ~ '^[a-z]+/[a-z0-9.+-]+$'),
  byte_size        bigint NOT NULL CHECK (byte_size > 0),
  sha256           char(64) NOT NULL CHECK (sha256 ~ '^[0-9a-f]{64}$'),
  caption          text NULL,
  sort_order       integer NOT NULL DEFAULT 0,
  uploaded_by      uuid NULL REFERENCES app_users(id),
  uploaded_at      timestamptz NOT NULL DEFAULT now(),
  archived_at      timestamptz NULL,
  UNIQUE (storage_bucket, object_key)
);
COMMENT ON TABLE vehicle_media IS 'Pointers to images/documents in S3-compatible object storage (bytes are not stored in PostgreSQL).';
CREATE INDEX vehicle_media_vehicle_idx ON vehicle_media (vehicle_id, sort_order) WHERE archived_at IS NULL;

CREATE TABLE vehicle_merge_proposals (
  id                    uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id       uuid NOT NULL REFERENCES organisations(id),
  primary_vehicle_id    uuid NOT NULL REFERENCES vehicles(id),
  duplicate_vehicle_id  uuid NOT NULL REFERENCES vehicles(id),
  score                 numeric(4,3) NOT NULL CHECK (score BETWEEN 0 AND 1),
  evidence              jsonb NOT NULL CHECK (jsonb_typeof(evidence) = 'array'),
  proposed_by           text NOT NULL,
  status                text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','accepted','rejected')),
  decided_by            uuid NULL REFERENCES app_users(id),
  decided_at            timestamptz NULL,
  decision_note         text NULL,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  version               integer NOT NULL DEFAULT 1,
  CHECK (primary_vehicle_id <> duplicate_vehicle_id),
  CHECK ((status = 'pending') = (decided_at IS NULL))
);
COMMENT ON TABLE vehicle_merge_proposals IS 'Uncertain vehicle matches awaiting human review. Records are never merged automatically on weak evidence (make/model/colour/text similarity).';
CREATE UNIQUE INDEX vehicle_merge_proposals_pending_uq ON vehicle_merge_proposals (LEAST(primary_vehicle_id, duplicate_vehicle_id), GREATEST(primary_vehicle_id, duplicate_vehicle_id))
  WHERE status = 'pending';
CREATE TRIGGER vehicle_merge_proposals_touch BEFORE UPDATE ON vehicle_merge_proposals FOR EACH ROW EXECUTE FUNCTION trg_touch_row();

-- @@DOWN@@
DROP TABLE IF EXISTS vehicle_merge_proposals, vehicle_media, vehicle_features, vehicle_attribute_assertions,
  vehicle_identifiers, vehicles, vehicle_specification_versions, vehicle_trims, vehicle_models, vehicle_makes CASCADE;
