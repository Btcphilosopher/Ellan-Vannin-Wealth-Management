-- =====================================================================
-- AUTOS DATA — 0008 Rental fleet, bookings, assignments, maintenance
--
-- Two levels of inventory, both half-open [start, end):
--   * Category bookings (rental_bookings) consume capacity of a
--     (location, category) inventory bucket. Capacity control method:
--     every write that can change demand or supply for a bucket first
--     takes a row lock on rental_inventory_buckets (SELECT ... FOR
--     NO KEY UPDATE), then — in a fresh READ COMMITTED snapshot — computes the
--     peak concurrent demand over the affected window and compares it
--     with the number of assets available for the whole window. Writes
--     to one bucket are therefore serialised; "count then insert" races
--     are impossible because the count happens after the lock.
--   * Exact-asset assignments (rental_asset_assignments) occupy
--     [pickup_at, return_at + turnaround_buffer). A GiST exclusion
--     constraint forbids overlapping active assignments per asset;
--     assignments and maintenance blocks lock the rental_assets row and
--     check each other, and maintenance has its own exclusion constraint.
-- Lock order (deadlock avoidance): bucket -> asset.
-- One-way rentals (return location <> pickup location) are DEFERRED and
-- rejected by CHECK.
-- =====================================================================

CREATE TABLE rental_categories (
  id                  uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id     uuid NOT NULL REFERENCES organisations(id),
  code                text NOT NULL CHECK (code ~ '^[A-Z0-9_-]{2,16}$'),
  name                text NOT NULL,
  seats               smallint NULL CHECK (seats BETWEEN 1 AND 15),
  transmission        text NULL CHECK (transmission IN ('automatic','manual')),
  turnaround_buffer   interval NOT NULL DEFAULT interval '60 minutes' CHECK (turnaround_buffer >= interval '0' AND turnaround_buffer <= interval '2 days'),
  daily_rate_minor    bigint NOT NULL CHECK (daily_rate_minor > 0),
  currency            char(3) NOT NULL REFERENCES currencies(code),
  status              text NOT NULL DEFAULT 'active' CHECK (status IN ('active','retired')),
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  version             integer NOT NULL DEFAULT 1,
  UNIQUE (organisation_id, code),
  UNIQUE (id, organisation_id)
);
COMMENT ON TABLE rental_categories IS 'Bookable rental classes. turnaround_buffer is added after each return before the asset can be used again.';
CREATE TRIGGER rental_categories_touch BEFORE UPDATE ON rental_categories FOR EACH ROW EXECUTE FUNCTION trg_touch_row();

CREATE TABLE rental_inventory_buckets (
  location_id        uuid NOT NULL,
  category_id        uuid NOT NULL,
  organisation_id    uuid NOT NULL REFERENCES organisations(id),
  capacity_override  integer NULL CHECK (capacity_override >= 0),
  created_at         timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (location_id, category_id),
  FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id),
  FOREIGN KEY (category_id, organisation_id) REFERENCES rental_categories(id, organisation_id)
);
COMMENT ON TABLE rental_inventory_buckets IS 'Lock target for category-capacity control at a location. capacity_override can cap sellable capacity below the physical fleet (never raise it).';

CREATE TABLE rental_assets (
  id                uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id   uuid NOT NULL REFERENCES organisations(id),
  vehicle_id        uuid NOT NULL UNIQUE REFERENCES vehicles(id),
  category_id       uuid NOT NULL,
  home_location_id  uuid NOT NULL,
  fleet_number      text NOT NULL,
  status            text NOT NULL DEFAULT 'active' CHECK (status IN ('active','out_of_service','retired')),
  in_fleet_from     timestamptz NOT NULL DEFAULT now(),
  in_fleet_to       timestamptz NULL CHECK (in_fleet_to IS NULL OR in_fleet_to > in_fleet_from),
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  version           integer NOT NULL DEFAULT 1,
  FOREIGN KEY (home_location_id, category_id) REFERENCES rental_inventory_buckets(location_id, category_id),
  FOREIGN KEY (category_id, organisation_id) REFERENCES rental_categories(id, organisation_id),
  UNIQUE (organisation_id, fleet_number),
  UNIQUE (id, organisation_id)
);
COMMENT ON TABLE rental_assets IS 'Exact physical vehicles in a rental fleet (one rental_assets row per vehicle).';
CREATE INDEX rental_assets_bucket_idx ON rental_assets (home_location_id, category_id) WHERE status = 'active';
CREATE TRIGGER rental_assets_touch BEFORE UPDATE ON rental_assets FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER rental_assets_no_delete BEFORE DELETE ON rental_assets FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

CREATE TABLE rental_quotes (
  id                  uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id     uuid NOT NULL REFERENCES organisations(id),
  location_id         uuid NOT NULL,
  category_id         uuid NOT NULL,
  customer_id         uuid NULL REFERENCES customers(id),
  pickup_at           timestamptz NOT NULL,
  return_at           timestamptz NOT NULL,
  local_timezone      text NOT NULL,
  rental_days         integer NOT NULL CHECK (rental_days BETWEEN 1 AND 90),
  daily_rate_minor    bigint NOT NULL CHECK (daily_rate_minor > 0),
  total_minor         bigint NOT NULL CHECK (total_minor > 0),
  currency            char(3) NOT NULL REFERENCES currencies(code),
  issued_at           timestamptz NOT NULL DEFAULT now(),
  expires_at          timestamptz NOT NULL,
  FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id),
  FOREIGN KEY (category_id, organisation_id) REFERENCES rental_categories(id, organisation_id),
  UNIQUE (id, organisation_id),
  CHECK (return_at > pickup_at),
  CHECK (expires_at > issued_at),
  CHECK (total_minor = rental_days * daily_rate_minor)
);
COMMENT ON TABLE rental_quotes IS 'Immutable rental price quotes. rental_days = number of started 24-hour periods between pickup and return instants.';
CREATE TRIGGER rental_quotes_append BEFORE UPDATE OR DELETE ON rental_quotes FOR EACH ROW EXECUTE FUNCTION trg_append_only();

CREATE SEQUENCE rental_booking_number_seq;

CREATE TABLE rental_bookings (
  id                   uuid PRIMARY KEY DEFAULT uuid_v7(),
  booking_number       text NOT NULL UNIQUE
                         DEFAULT ('B-' || to_char(now() AT TIME ZONE 'UTC', 'YYYY') || '-' || lpad(nextval('rental_booking_number_seq')::text, 7, '0')),
  organisation_id      uuid NOT NULL REFERENCES organisations(id),
  customer_id          uuid NOT NULL REFERENCES customers(id),
  category_id          uuid NOT NULL,
  pickup_location_id   uuid NOT NULL,
  return_location_id   uuid NOT NULL,
  rental_quote_id      uuid NULL,
  pickup_at            timestamptz NOT NULL,
  return_at            timestamptz NOT NULL,
  pickup_timezone      text NOT NULL,
  return_timezone      text NOT NULL,
  booked_range         tstzrange GENERATED ALWAYS AS (tstzrange(pickup_at, return_at, '[)')) STORED,
  status               text NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed','checked_out','returned','cancelled','no_show')),
  total_minor          bigint NOT NULL CHECK (total_minor > 0),
  currency             char(3) NOT NULL REFERENCES currencies(code),
  cancelled_at         timestamptz NULL,
  cancellation_reason  text NULL,
  idempotency_key      text NULL,
  created_by           uuid NULL REFERENCES app_users(id),
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  version              integer NOT NULL DEFAULT 1,
  FOREIGN KEY (pickup_location_id, category_id) REFERENCES rental_inventory_buckets(location_id, category_id),
  FOREIGN KEY (category_id, organisation_id) REFERENCES rental_categories(id, organisation_id),
  FOREIGN KEY (return_location_id, organisation_id) REFERENCES locations(id, organisation_id),
  FOREIGN KEY (rental_quote_id, organisation_id) REFERENCES rental_quotes(id, organisation_id),
  UNIQUE (id, organisation_id),
  CHECK (return_at > pickup_at AND return_at - pickup_at <= interval '90 days'),
  CHECK (return_location_id = pickup_location_id),
  CHECK ((status = 'cancelled') = (cancelled_at IS NOT NULL AND cancellation_reason IS NOT NULL))
);
COMMENT ON TABLE rental_bookings IS 'Category-level rental bookings. Capacity is enforced per (pickup location, category) bucket under a row lock. Exact vehicles are attached via rental_asset_assignments.';
COMMENT ON COLUMN rental_bookings.pickup_timezone IS 'IANA zone of the pickup location at booking time, for local display and local-day rules.';
CREATE INDEX rental_bookings_bucket_range_idx ON rental_bookings USING gist (pickup_location_id, category_id, booked_range) WHERE status IN ('confirmed','checked_out');
CREATE INDEX rental_bookings_org_pickup_idx ON rental_bookings (organisation_id, pickup_at);
CREATE INDEX rental_bookings_customer_idx ON rental_bookings (customer_id);
CREATE UNIQUE INDEX rental_bookings_idem_uq ON rental_bookings (organisation_id, idempotency_key) WHERE idempotency_key IS NOT NULL;

CREATE TABLE rental_asset_assignments (
  id                 uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id    uuid NOT NULL REFERENCES organisations(id),
  rental_booking_id  uuid NOT NULL,
  rental_asset_id    uuid NOT NULL,
  occupied           tstzrange NOT NULL,
  is_upgrade         boolean NOT NULL DEFAULT false,
  status             text NOT NULL DEFAULT 'active' CHECK (status IN ('active','released','cancelled')),
  assigned_by        uuid NULL REFERENCES app_users(id),
  assigned_at        timestamptz NOT NULL DEFAULT now(),
  released_at        timestamptz NULL,
  FOREIGN KEY (rental_booking_id, organisation_id) REFERENCES rental_bookings(id, organisation_id),
  FOREIGN KEY (rental_asset_id, organisation_id) REFERENCES rental_assets(id, organisation_id),
  CHECK (lower_inc(occupied) AND NOT upper_inc(occupied) AND NOT isempty(occupied)),
  CHECK ((status = 'active') = (released_at IS NULL)),
  EXCLUDE USING gist (rental_asset_id WITH =, occupied WITH &&) WHERE (status = 'active')
);
COMMENT ON TABLE rental_asset_assignments IS 'Binds a booking to an exact asset for [pickup_at, return_at + turnaround_buffer). Exclusion constraint prevents overlapping active assignments.';
CREATE UNIQUE INDEX rental_asset_assignments_one_active_uq ON rental_asset_assignments (rental_booking_id) WHERE status = 'active';

CREATE TABLE maintenance_blocks (
  id               uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id  uuid NOT NULL REFERENCES organisations(id),
  rental_asset_id  uuid NOT NULL,
  kind             text NOT NULL CHECK (kind IN ('scheduled_service','repair','inspection','recall','damage')),
  starts_at        timestamptz NOT NULL,
  ends_at          timestamptz NOT NULL,
  block_range      tstzrange GENERATED ALWAYS AS (tstzrange(starts_at, ends_at, '[)')) STORED,
  status           text NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','active','completed','cancelled')),
  reason           text NOT NULL,
  created_by       uuid NULL REFERENCES app_users(id),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  version          integer NOT NULL DEFAULT 1,
  FOREIGN KEY (rental_asset_id, organisation_id) REFERENCES rental_assets(id, organisation_id),
  CHECK (ends_at > starts_at),
  EXCLUDE USING gist (rental_asset_id WITH =, block_range WITH &&) WHERE (status IN ('planned','active'))
);
COMMENT ON TABLE maintenance_blocks IS 'Periods an asset cannot be rented. Cannot overlap active assignments and cannot reduce bucket capacity below committed bookings.';
CREATE INDEX maintenance_blocks_asset_idx ON maintenance_blocks USING gist (rental_asset_id, block_range) WHERE status IN ('planned','active');
CREATE TRIGGER maintenance_blocks_touch BEFORE UPDATE ON maintenance_blocks FOR EACH ROW EXECUTE FUNCTION trg_touch_row();

-- ---------------------------------------------------------------------
-- Capacity evaluation for a bucket over a window.
-- available = active in-fleet assets free of maintenance for the whole
-- window (conservative), capped by capacity_override.
-- peak      = peak concurrent active bookings, each occupying
--             [pickup_at, return_at + buffer).
-- ---------------------------------------------------------------------
CREATE FUNCTION rental_bucket_capacity(p_location uuid, p_category uuid, p_window tstzrange)
RETURNS TABLE (peak integer, available integer)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  WITH cat AS (SELECT turnaround_buffer AS buf FROM rental_categories WHERE id = p_category),
  bucket AS (SELECT capacity_override FROM rental_inventory_buckets WHERE location_id = p_location AND category_id = p_category),
  demand AS (
    SELECT tstzrange(b.pickup_at, b.return_at + cat.buf, '[)') AS r
      FROM rental_bookings b, cat
     WHERE b.pickup_location_id = p_location AND b.category_id = p_category
       AND b.status IN ('confirmed','checked_out')
       AND tstzrange(b.pickup_at, b.return_at + cat.buf, '[)') && p_window
  ),
  supply AS (
    SELECT count(*)::integer AS n
      FROM rental_assets a
     WHERE a.home_location_id = p_location AND a.category_id = p_category AND a.status = 'active'
       AND a.in_fleet_from <= lower(p_window)
       AND (a.in_fleet_to IS NULL OR a.in_fleet_to >= upper(p_window))
       AND NOT EXISTS (SELECT 1 FROM maintenance_blocks m
                        WHERE m.rental_asset_id = a.id AND m.status IN ('planned','active') AND m.block_range && p_window)
  )
  SELECT (SELECT peak_concurrency(COALESCE(array_agg(r), '{}'), p_window) FROM demand),
         (SELECT CASE WHEN bucket.capacity_override IS NULL THEN supply.n ELSE LEAST(supply.n, bucket.capacity_override) END
            FROM supply LEFT JOIN bucket ON true)
$$;
COMMENT ON FUNCTION rental_bucket_capacity(uuid, uuid, tstzrange) IS 'Peak demand vs available supply for a rental inventory bucket over a half-open window.';

CREATE FUNCTION trg_rental_booking_before() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status <> 'confirmed' THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_status_transition: bookings start as confirmed';
    END IF;
    SELECT timezone INTO NEW.pickup_timezone FROM locations WHERE id = NEW.pickup_location_id;
    SELECT timezone INTO NEW.return_timezone FROM locations WHERE id = NEW.return_location_id;
  ELSE
    IF (NEW.organisation_id, NEW.customer_id, NEW.created_at, NEW.pickup_timezone, NEW.return_timezone)
       IS DISTINCT FROM (OLD.organisation_id, OLD.customer_id, OLD.created_at, OLD.pickup_timezone, OLD.return_timezone) THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: booking identity fields cannot change';
    END IF;
    IF OLD.status IN ('returned','cancelled','no_show')
       AND (to_jsonb(NEW) - 'updated_at' - 'version' - 'booked_range') IS DISTINCT FROM (to_jsonb(OLD) - 'updated_at' - 'version' - 'booked_range') THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = format('immutable_record: booking is %s', OLD.status);
    END IF;
    IF NEW.status IS DISTINCT FROM OLD.status AND (OLD.status, NEW.status) NOT IN (
        ('confirmed','checked_out'), ('confirmed','cancelled'), ('confirmed','no_show'), ('checked_out','returned')) THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: booking %s -> %s', OLD.status, NEW.status);
    END IF;
    IF NEW.status = 'cancelled' AND NEW.cancelled_at IS NULL THEN NEW.cancelled_at := now(); END IF;
  END IF;
  IF NEW.status IN ('confirmed','checked_out') THEN
    -- Serialisation point for this bucket. The capacity check runs in the
    -- AFTER trigger so that it sees this row plus every committed row.
    PERFORM 1 FROM rental_inventory_buckets
      WHERE location_id = NEW.pickup_location_id AND category_id = NEW.category_id FOR NO KEY UPDATE;
  END IF;
  RETURN NEW;
END $$;

CREATE FUNCTION trg_rental_booking_after() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  buf interval;
  win tstzrange;
  cap record;
BEGIN
  IF NEW.status IN ('confirmed','checked_out')
     AND (TG_OP = 'INSERT' OR (NEW.pickup_at, NEW.return_at, NEW.category_id, NEW.pickup_location_id) IS DISTINCT FROM
                                (OLD.pickup_at, OLD.return_at, OLD.category_id, OLD.pickup_location_id)) THEN
    SELECT turnaround_buffer INTO buf FROM rental_categories WHERE id = NEW.category_id;
    win := tstzrange(NEW.pickup_at, NEW.return_at + buf, '[)');
    SELECT * INTO cap FROM rental_bucket_capacity(NEW.pickup_location_id, NEW.category_id, win);
    IF cap.peak > cap.available THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9004',
        MESSAGE = format('rental_capacity_exceeded: peak demand %s exceeds %s available vehicles in this category for the requested period', cap.peak, cap.available);
    END IF;
  END IF;
  IF TG_OP = 'UPDATE' AND NEW.status IN ('cancelled','no_show') AND OLD.status <> NEW.status THEN
    UPDATE rental_asset_assignments SET status = 'cancelled', released_at = now()
     WHERE rental_booking_id = NEW.id AND status = 'active';
  ELSIF TG_OP = 'UPDATE' AND NEW.status = 'returned' AND OLD.status <> NEW.status THEN
    UPDATE rental_asset_assignments SET status = 'released', released_at = now()
     WHERE rental_booking_id = NEW.id AND status = 'active';
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER rental_bookings_before BEFORE INSERT OR UPDATE ON rental_bookings FOR EACH ROW EXECUTE FUNCTION trg_rental_booking_before();
CREATE TRIGGER rental_bookings_touch BEFORE UPDATE ON rental_bookings FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER rental_bookings_after AFTER INSERT OR UPDATE ON rental_bookings FOR EACH ROW EXECUTE FUNCTION trg_rental_booking_after();
CREATE TRIGGER rental_bookings_no_delete BEFORE DELETE ON rental_bookings FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

CREATE FUNCTION trg_rental_assignment_before() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  b rental_bookings%ROWTYPE;
  a rental_assets%ROWTYPE;
  buf interval;
BEGIN
  IF TG_OP = 'UPDATE' THEN
    IF (NEW.rental_booking_id, NEW.rental_asset_id, NEW.occupied, NEW.assigned_at) IS DISTINCT FROM
       (OLD.rental_booking_id, OLD.rental_asset_id, OLD.occupied, OLD.assigned_at)
       OR (OLD.status <> 'active') THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: assignments can only be released or cancelled';
    END IF;
    RETURN NEW;
  END IF;
  SELECT * INTO b FROM rental_bookings WHERE id = NEW.rental_booking_id;
  IF b.status NOT IN ('confirmed','checked_out') THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: cannot assign a %s booking', b.status);
  END IF;
  SELECT * INTO a FROM rental_assets WHERE id = NEW.rental_asset_id FOR NO KEY UPDATE;
  IF a.status <> 'active' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9005', MESSAGE = format('rental_asset_conflict: asset is %s', a.status);
  END IF;
  IF a.home_location_id <> b.pickup_location_id THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_reference: asset is based at a different location';
  END IF;
  IF a.category_id <> b.category_id AND NOT NEW.is_upgrade THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_reference: asset category differs from booking (set is_upgrade to allow)';
  END IF;
  SELECT turnaround_buffer INTO buf FROM rental_categories WHERE id = a.category_id;
  NEW.occupied := tstzrange(b.pickup_at, b.return_at + buf, '[)');
  IF EXISTS (SELECT 1 FROM maintenance_blocks m WHERE m.rental_asset_id = a.id
              AND m.status IN ('planned','active') AND m.block_range && NEW.occupied) THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9005', MESSAGE = 'rental_asset_conflict: asset has a maintenance block in this period';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER rental_asset_assignments_before BEFORE INSERT OR UPDATE ON rental_asset_assignments FOR EACH ROW EXECUTE FUNCTION trg_rental_assignment_before();
CREATE TRIGGER rental_asset_assignments_no_delete BEFORE DELETE ON rental_asset_assignments FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

CREATE FUNCTION trg_maintenance_before() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE a rental_assets%ROWTYPE;
BEGIN
  IF NEW.status IN ('planned','active') THEN
    SELECT * INTO a FROM rental_assets WHERE id = NEW.rental_asset_id;
    PERFORM 1 FROM rental_inventory_buckets WHERE location_id = a.home_location_id AND category_id = a.category_id FOR NO KEY UPDATE;
    PERFORM 1 FROM rental_assets WHERE id = a.id FOR NO KEY UPDATE;
    IF EXISTS (SELECT 1 FROM rental_asset_assignments x WHERE x.rental_asset_id = a.id
                AND x.status = 'active' AND x.occupied && tstzrange(NEW.starts_at, NEW.ends_at, '[)')) THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9005', MESSAGE = 'rental_asset_conflict: asset is assigned to a booking in this period; reassign it first';
    END IF;
  END IF;
  RETURN NEW;
END $$;

-- After the block is visible, every booking it overlaps must still fit.
CREATE FUNCTION trg_maintenance_after() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  a rental_assets%ROWTYPE;
  buf interval;
  bk record;
  cap record;
BEGIN
  IF NEW.status NOT IN ('planned','active') THEN RETURN NULL; END IF;
  SELECT * INTO a FROM rental_assets WHERE id = NEW.rental_asset_id;
  SELECT turnaround_buffer INTO buf FROM rental_categories WHERE id = a.category_id;
  FOR bk IN
    SELECT b.id, tstzrange(b.pickup_at, b.return_at + buf, '[)') AS win
      FROM rental_bookings b
     WHERE b.pickup_location_id = a.home_location_id AND b.category_id = a.category_id
       AND b.status IN ('confirmed','checked_out')
       AND tstzrange(b.pickup_at, b.return_at + buf, '[)') && NEW.block_range
  LOOP
    SELECT * INTO cap FROM rental_bucket_capacity(a.home_location_id, a.category_id, bk.win);
    IF cap.peak > cap.available THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9004',
        MESSAGE = format('rental_capacity_exceeded: this maintenance block would leave %s vehicles for %s committed bookings', cap.available, cap.peak);
    END IF;
  END LOOP;
  RETURN NULL;
END $$;
CREATE TRIGGER maintenance_blocks_before BEFORE INSERT OR UPDATE ON maintenance_blocks FOR EACH ROW EXECUTE FUNCTION trg_maintenance_before();
CREATE TRIGGER maintenance_blocks_after AFTER INSERT OR UPDATE ON maintenance_blocks FOR EACH ROW EXECUTE FUNCTION trg_maintenance_after();
CREATE TRIGGER maintenance_blocks_no_delete BEFORE DELETE ON maintenance_blocks FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

-- @@DOWN@@
DROP TABLE IF EXISTS maintenance_blocks, rental_asset_assignments, rental_bookings, rental_quotes, rental_assets, rental_inventory_buckets, rental_categories CASCADE;
DROP SEQUENCE IF EXISTS rental_booking_number_seq;
DROP FUNCTION IF EXISTS trg_maintenance_after(), trg_maintenance_before(), trg_rental_assignment_before(), trg_rental_booking_after(), trg_rental_booking_before(),
  rental_bucket_capacity(uuid, uuid, tstzrange);
