-- =====================================================================
-- AUTOS DATA — 0013 SIMULATED payment provider ("simpay")
--
-- This schema stands in for an EXTERNAL payment processor so that the
-- webhook, idempotency, out-of-order, unknown-outcome and refund flows
-- can be exercised end to end. It is not part of the authoritative data
-- model, holds no card data, and should not be deployed to production
-- (set AUTOS_ENABLE_SIMULATOR=false and skip this schema).
-- =====================================================================

CREATE SCHEMA simpay;

CREATE TABLE simpay.payments (
  ref               text PRIMARY KEY,
  merchant_ref      text NOT NULL,
  amount_minor      bigint NOT NULL CHECK (amount_minor > 0),
  currency          char(3) NOT NULL,
  status            text NOT NULL CHECK (status IN ('processing','succeeded','failed','canceled')),
  captured_minor    bigint NOT NULL DEFAULT 0,
  idempotency_key   text NOT NULL UNIQUE,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE simpay.refunds (
  ref               text PRIMARY KEY,
  payment_ref       text NOT NULL REFERENCES simpay.payments(ref),
  amount_minor      bigint NOT NULL CHECK (amount_minor > 0),
  status            text NOT NULL CHECK (status IN ('pending','succeeded','failed')),
  idempotency_key   text NOT NULL UNIQUE,
  created_at        timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE simpay.events (
  event_id          text PRIMARY KEY,
  event_type        text NOT NULL,
  created_at        timestamptz NOT NULL,
  body              jsonb NOT NULL,
  delivered_at      timestamptz NULL
);
COMMENT ON SCHEMA simpay IS 'SIMULATED external payment provider used for demonstrations and tests only.';

GRANT USAGE ON SCHEMA simpay TO autos_app;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA simpay TO autos_app;

-- @@DOWN@@
DROP SCHEMA IF EXISTS simpay CASCADE;
