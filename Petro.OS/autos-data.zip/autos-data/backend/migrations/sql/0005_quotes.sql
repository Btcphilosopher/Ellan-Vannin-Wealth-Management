-- =====================================================================
-- AUTOS DATA — 0005 Charge rules, terms, immutable quotes
--
-- Price structure (all integer minor units, one currency per quote):
--   subtotal_before_tax_registration = vehicle_price + mandatory_fees
--                                      + optional_products + discounts
--   total_known = subtotal + taxes? + registration? + delivery?
--   total       = total_known when complete, NULL when any charge unknown
--   deposit_required is a payment TOWARDS the total, never added to it.
-- =====================================================================

CREATE TABLE terms_versions (
  id              uuid PRIMARY KEY DEFAULT uuid_v7(),
  code            text NOT NULL CHECK (code ~ '^[a-z][a-z0-9_-]+$'),
  version         integer NOT NULL CHECK (version > 0),
  title           text NOT NULL,
  body_sha256     char(64) NOT NULL CHECK (body_sha256 ~ '^[0-9a-f]{64}$'),
  effective_from  timestamptz NOT NULL,
  effective_to    timestamptz NULL CHECK (effective_to IS NULL OR effective_to > effective_from),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (code, version)
);
COMMENT ON TABLE terms_versions IS 'Versioned terms and conditions; quotes and acceptances reference the exact version shown.';
CREATE TRIGGER terms_versions_no_delete BEFORE DELETE ON terms_versions FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

CREATE TABLE charge_rules (
  id               uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id  uuid NOT NULL REFERENCES organisations(id),
  charge_type      text NOT NULL CHECK (charge_type IN ('mandatory_fee','tax','registration','delivery','optional_product','discount')),
  code             text NOT NULL CHECK (code ~ '^[a-z][a-z0-9_]+$'),
  label            text NOT NULL,
  calculation      text NOT NULL CHECK (calculation IN ('fixed','rate_bps')),
  amount_minor     bigint NULL,
  rate_bps         integer NULL CHECK (rate_bps BETWEEN 0 AND 10000),
  currency         char(3) NULL REFERENCES currencies(code),
  region           text NULL,
  effective_from   timestamptz NOT NULL DEFAULT now(),
  effective_to     timestamptz NULL CHECK (effective_to IS NULL OR effective_to > effective_from),
  created_at       timestamptz NOT NULL DEFAULT now(),
  CHECK ((calculation = 'fixed') = (amount_minor IS NOT NULL AND currency IS NOT NULL)),
  CHECK ((calculation = 'rate_bps') = (rate_bps IS NOT NULL)),
  CHECK (charge_type <> 'discount' OR amount_minor IS NULL OR amount_minor <= 0),
  CHECK (charge_type = 'discount' OR amount_minor IS NULL OR amount_minor >= 0),
  EXCLUDE USING gist (organisation_id WITH =, code WITH =, (COALESCE(region, '*')) WITH =,
                      tstzrange(effective_from, effective_to, '[)') WITH &&)
);
COMMENT ON TABLE charge_rules IS 'Seller fee/tax/registration/delivery/product rules, effective-dated. Rules are closed, never edited, so historical quotes remain explainable. A missing tax or registration rule for the customer region makes a quote incomplete.';
COMMENT ON COLUMN charge_rules.rate_bps IS 'Rate in basis points (1/100 of a percent), applied to the taxable subtotal.';
CREATE TRIGGER charge_rules_no_delete BEFORE DELETE ON charge_rules FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

CREATE SEQUENCE quote_number_seq;

CREATE TABLE quotes (
  id                                      uuid PRIMARY KEY DEFAULT uuid_v7(),
  quote_number                            text NOT NULL UNIQUE
                                            DEFAULT ('Q-' || to_char(now() AT TIME ZONE 'UTC', 'YYYY') || '-' || lpad(nextval('quote_number_seq')::text, 7, '0')),
  organisation_id                         uuid NOT NULL REFERENCES organisations(id),
  listing_id                              uuid NOT NULL,
  vehicle_id                              uuid NOT NULL REFERENCES vehicles(id),
  listing_price_version_id                uuid NOT NULL,
  customer_id                             uuid NULL REFERENCES customers(id),
  session_reference                       text NULL CHECK (session_reference IS NULL OR session_reference ~ '^[A-Za-z0-9_-]{8,128}$'),
  customer_region                         text NULL,
  currency                                char(3) NOT NULL REFERENCES currencies(code),
  vehicle_price_minor                     bigint NOT NULL CHECK (vehicle_price_minor > 0),
  mandatory_fees_minor                    bigint NOT NULL DEFAULT 0 CHECK (mandatory_fees_minor >= 0),
  optional_products_minor                 bigint NOT NULL DEFAULT 0 CHECK (optional_products_minor >= 0),
  discounts_minor                         bigint NOT NULL DEFAULT 0 CHECK (discounts_minor <= 0),
  subtotal_before_tax_registration_minor  bigint NOT NULL,
  taxes_minor                             bigint NULL CHECK (taxes_minor >= 0),
  registration_minor                      bigint NULL CHECK (registration_minor >= 0),
  delivery_minor                          bigint NULL CHECK (delivery_minor >= 0),
  total_known_minor                       bigint NOT NULL,
  total_minor                             bigint NULL,
  deposit_required_minor                  bigint NOT NULL DEFAULT 0 CHECK (deposit_required_minor >= 0),
  deposit_treatment                       text NOT NULL DEFAULT 'applied_to_price' CHECK (deposit_treatment IN ('applied_to_price','none')),
  is_complete                             boolean NOT NULL,
  missing_charges                         text[] NOT NULL DEFAULT '{}',
  terms_version_id                        uuid NOT NULL REFERENCES terms_versions(id),
  snapshot                                jsonb NOT NULL CHECK (jsonb_typeof(snapshot) = 'object'),
  snapshot_sha256                         char(64) NOT NULL CHECK (snapshot_sha256 ~ '^[0-9a-f]{64}$'),
  status                                  text NOT NULL DEFAULT 'issued' CHECK (status IN ('issued','accepted','withdrawn')),
  issued_at                               timestamptz NOT NULL DEFAULT now(),
  expires_at                              timestamptz NOT NULL,
  issued_by                               uuid NULL REFERENCES app_users(id),
  request_id                              text NULL,
  FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id),
  FOREIGN KEY (listing_price_version_id, listing_id) REFERENCES listing_price_versions(id, listing_id),
  UNIQUE (id, organisation_id),
  CHECK (customer_id IS NOT NULL OR session_reference IS NOT NULL),
  CHECK (expires_at > issued_at),
  CHECK (subtotal_before_tax_registration_minor = vehicle_price_minor + mandatory_fees_minor + optional_products_minor + discounts_minor),
  CHECK (subtotal_before_tax_registration_minor > 0),
  CHECK (total_known_minor = subtotal_before_tax_registration_minor + COALESCE(taxes_minor,0) + COALESCE(registration_minor,0) + COALESCE(delivery_minor,0)),
  CHECK (is_complete = (cardinality(missing_charges) = 0)),
  CHECK (is_complete = (total_minor IS NOT NULL)),
  CHECK (total_minor IS NULL OR total_minor = total_known_minor),
  CHECK (deposit_required_minor <= total_known_minor),
  CHECK ((deposit_treatment = 'none') = (deposit_required_minor = 0))
);
COMMENT ON TABLE quotes IS 'Immutable issued quotes. Price/listing/vehicle data is snapshotted; later catalogue or price changes never rewrite a quote. Only status may move issued -> accepted|withdrawn. Expiry is evaluated against expires_at, not stored.';
COMMENT ON COLUMN quotes.snapshot IS 'Point-in-time JSONB copy of the vehicle, trim, listing and seller as shown to the customer (justified: a frozen document, not a relationship). Hash in snapshot_sha256.';
COMMENT ON COLUMN quotes.missing_charges IS 'Charge types that could not be determined (e.g. {tax,registration}). Non-empty => is_complete = false and total_minor IS NULL.';
CREATE INDEX quotes_org_issued_idx ON quotes (organisation_id, issued_at DESC);
CREATE INDEX quotes_customer_idx ON quotes (customer_id, issued_at DESC) WHERE customer_id IS NOT NULL;
CREATE INDEX quotes_listing_idx ON quotes (listing_id);

CREATE TABLE quote_lines (
  id                uuid PRIMARY KEY DEFAULT uuid_v7(),
  quote_id          uuid NOT NULL,
  organisation_id   uuid NOT NULL,
  line_no           smallint NOT NULL CHECK (line_no > 0),
  line_type         text NOT NULL CHECK (line_type IN ('vehicle_price','mandatory_fee','tax','registration','delivery','optional_product','discount')),
  code              text NOT NULL,
  description       text NOT NULL,
  amount_status     text NOT NULL CHECK (amount_status IN ('known','unknown','not_applicable')),
  amount_minor      bigint NULL,
  rate_bps          integer NULL CHECK (rate_bps BETWEEN 0 AND 10000),
  basis_minor       bigint NULL CHECK (basis_minor >= 0),
  source_rule_id    uuid NULL REFERENCES charge_rules(id),
  FOREIGN KEY (quote_id, organisation_id) REFERENCES quotes(id, organisation_id),
  UNIQUE (quote_id, line_no),
  CHECK ((amount_status = 'known') = (amount_minor IS NOT NULL)),
  CHECK (line_type <> 'discount' OR amount_minor IS NULL OR amount_minor <= 0),
  CHECK (line_type = 'discount' OR amount_minor IS NULL OR amount_minor >= 0),
  CHECK (amount_status <> 'not_applicable' OR line_type IN ('tax','registration','delivery'))
);
COMMENT ON TABLE quote_lines IS 'Itemised, append-only quote charges. amount_status distinguishes a known amount (possibly 0) from an unknown one (NULL).';
CREATE TRIGGER quote_lines_append BEFORE UPDATE OR DELETE ON quote_lines FOR EACH ROW EXECUTE FUNCTION trg_append_only();

-- Quote header immutability: only status may change, and only forwards.
CREATE FUNCTION trg_quotes_immutable() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9010', MESSAGE = 'append_only: quotes cannot be deleted';
  END IF;
  IF (to_jsonb(NEW) - 'status') IS DISTINCT FROM (to_jsonb(OLD) - 'status') THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: issued quotes cannot be modified';
  END IF;
  IF NEW.status IS DISTINCT FROM OLD.status
     AND (OLD.status, NEW.status) NOT IN (('issued','accepted'), ('issued','withdrawn')) THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: quote %s -> %s', OLD.status, NEW.status);
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER quotes_immutable BEFORE UPDATE OR DELETE ON quotes FOR EACH ROW EXECUTE FUNCTION trg_quotes_immutable();

-- Deferred consistency check: header totals must equal the sum of lines,
-- and missing_charges must equal the set of unknown line types. Runs at
-- COMMIT so the header and its lines can be inserted in any order.
CREATE FUNCTION trg_quote_totals_check() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE
  q quotes%ROWTYPE;
  qid uuid;
  s record;
BEGIN
  IF TG_TABLE_NAME = 'quotes' THEN qid := NEW.id; ELSE qid := NEW.quote_id; END IF;
  SELECT * INTO q FROM quotes WHERE id = qid;
  IF NOT FOUND THEN RETURN NULL; END IF;
  SELECT
    COALESCE(sum(amount_minor) FILTER (WHERE line_type = 'vehicle_price'), 0)      AS vehicle,
    count(*) FILTER (WHERE line_type = 'vehicle_price')                            AS vehicle_lines,
    COALESCE(sum(amount_minor) FILTER (WHERE line_type = 'mandatory_fee'), 0)      AS fees,
    COALESCE(sum(amount_minor) FILTER (WHERE line_type = 'optional_product'), 0)   AS products,
    COALESCE(sum(amount_minor) FILTER (WHERE line_type = 'discount'), 0)           AS discounts,
    sum(amount_minor) FILTER (WHERE line_type = 'tax')                             AS taxes,
    sum(amount_minor) FILTER (WHERE line_type = 'registration')                    AS registration,
    sum(amount_minor) FILTER (WHERE line_type = 'delivery')                        AS delivery,
    COALESCE(array_agg(DISTINCT line_type ORDER BY line_type) FILTER (WHERE amount_status = 'unknown'), '{}') AS unknown_types
  INTO s
  FROM quote_lines WHERE quote_id = qid;

  IF s.vehicle_lines <> 1
     OR s.vehicle <> q.vehicle_price_minor
     OR s.fees <> q.mandatory_fees_minor
     OR s.products <> q.optional_products_minor
     OR s.discounts <> q.discounts_minor
     OR s.taxes IS DISTINCT FROM q.taxes_minor
     OR s.registration IS DISTINCT FROM q.registration_minor
     OR s.delivery IS DISTINCT FROM q.delivery_minor
     OR s.unknown_types::text[] <> (SELECT COALESCE(array_agg(DISTINCT m ORDER BY m), '{}') FROM unnest(q.missing_charges) m)
  THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9011',
      MESSAGE = format('quote_totals_mismatch: quote %s header does not match its lines', q.quote_number);
  END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER quotes_totals_check AFTER INSERT ON quotes
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION trg_quote_totals_check();
CREATE CONSTRAINT TRIGGER quote_lines_totals_check AFTER INSERT ON quote_lines
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION trg_quote_totals_check();

CREATE TABLE quote_acceptances (
  id                  uuid PRIMARY KEY DEFAULT uuid_v7(),
  quote_id            uuid NOT NULL UNIQUE,
  organisation_id     uuid NOT NULL,
  customer_id         uuid NOT NULL REFERENCES customers(id),
  terms_version_id    uuid NOT NULL REFERENCES terms_versions(id),
  accepted_at         timestamptz NOT NULL DEFAULT now(),
  acceptance_channel  text NOT NULL CHECK (acceptance_channel IN ('web','in_store','phone','api')),
  request_id          text NULL,
  FOREIGN KEY (quote_id, organisation_id) REFERENCES quotes(id, organisation_id)
);
COMMENT ON TABLE quote_acceptances IS 'Customer acceptance of an issued, complete, unexpired quote under its terms version. At most one per quote.';
CREATE TRIGGER quote_acceptances_append BEFORE UPDATE OR DELETE ON quote_acceptances FOR EACH ROW EXECUTE FUNCTION trg_append_only();

CREATE FUNCTION trg_quote_acceptance_check() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE q quotes%ROWTYPE;
BEGIN
  SELECT * INTO q FROM quotes WHERE id = NEW.quote_id FOR NO KEY UPDATE;
  IF q.status <> 'issued' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9009', MESSAGE = format('quote_not_acceptable: quote is %s', q.status);
  END IF;
  IF NOT q.is_complete THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9009', MESSAGE = 'quote_not_acceptable: quote is incomplete (missing ' || array_to_string(q.missing_charges, ', ') || ')';
  END IF;
  IF NEW.accepted_at >= q.expires_at THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9009', MESSAGE = 'quote_not_acceptable: quote has expired';
  END IF;
  IF q.customer_id IS DISTINCT FROM NEW.customer_id THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9009', MESSAGE = 'quote_not_acceptable: quote was issued to a different customer';
  END IF;
  IF q.terms_version_id <> NEW.terms_version_id THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9009', MESSAGE = 'quote_not_acceptable: terms version differs from the quoted terms';
  END IF;
  UPDATE quotes SET status = 'accepted' WHERE id = q.id;
  RETURN NEW;
END $$;
CREATE TRIGGER quote_acceptances_check BEFORE INSERT ON quote_acceptances FOR EACH ROW EXECUTE FUNCTION trg_quote_acceptance_check();

-- @@DOWN@@
DROP TABLE IF EXISTS quote_acceptances, quote_lines, quotes, charge_rules, terms_versions CASCADE;
DROP SEQUENCE IF EXISTS quote_number_seq;
DROP FUNCTION IF EXISTS trg_quote_acceptance_check(), trg_quote_totals_check(), trg_quotes_immutable();
