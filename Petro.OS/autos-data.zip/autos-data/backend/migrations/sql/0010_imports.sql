-- =====================================================================
-- AUTOS DATA — 0010 Imports and source provenance
-- Upload -> staging (import_rows) -> validation (findings) -> preview ->
-- approval -> application -> results. Every row keeps its raw payload,
-- normalised form, findings and outcome.
-- =====================================================================

CREATE TABLE import_jobs (
  id                 uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id    uuid NOT NULL REFERENCES organisations(id),
  source_namespace   text NOT NULL CHECK (source_namespace ~ '^[a-z][a-z0-9_.:-]{1,63}$'),
  format             text NOT NULL CHECK (format IN ('csv','json')),
  mode               text NOT NULL CHECK (mode IN ('all_or_nothing','partial_accept')),
  status             text NOT NULL DEFAULT 'uploaded'
                       CHECK (status IN ('uploaded','validating','validated','approved','applying','applied','applied_with_skips','rejected','failed')),
  original_filename  text NOT NULL,
  storage_bucket     text NOT NULL,
  object_key         text NOT NULL,
  file_sha256        char(64) NOT NULL CHECK (file_sha256 ~ '^[0-9a-f]{64}$'),
  byte_size          bigint NOT NULL CHECK (byte_size > 0),
  options            jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(options) = 'object'),
  row_count          integer NOT NULL DEFAULT 0 CHECK (row_count >= 0),
  valid_count        integer NOT NULL DEFAULT 0,
  warning_count      integer NOT NULL DEFAULT 0,
  invalid_count      integer NOT NULL DEFAULT 0,
  applied_count      integer NOT NULL DEFAULT 0,
  no_change_count    integer NOT NULL DEFAULT 0,
  skipped_count      integer NOT NULL DEFAULT 0,
  error_summary      text NULL,
  attempts           integer NOT NULL DEFAULT 0,
  uploaded_by        uuid NULL REFERENCES app_users(id),
  uploaded_at        timestamptz NOT NULL DEFAULT now(),
  validated_at       timestamptz NULL,
  approved_by        uuid NULL REFERENCES app_users(id),
  approved_at        timestamptz NULL,
  applied_at         timestamptz NULL,
  updated_at         timestamptz NOT NULL DEFAULT now(),
  version            integer NOT NULL DEFAULT 1,
  UNIQUE (organisation_id, source_namespace, file_sha256),
  UNIQUE (id, organisation_id),
  CHECK (status NOT IN ('approved','applying','applied','applied_with_skips') OR approved_at IS NOT NULL)
);
COMMENT ON TABLE import_jobs IS 'One uploaded file. Re-uploading identical bytes for the same source returns the existing job (idempotent). mode: all_or_nothing = any invalid row blocks approval and application is one transaction; partial_accept = valid rows applied, invalid rows skipped and reported.';
COMMENT ON COLUMN import_jobs.options IS 'Validated ImportOptions: {"clear_blank_fields": [...], "publish_on_apply": false}. Blank source fields never erase data unless listed in clear_blank_fields.';
CREATE INDEX import_jobs_org_idx ON import_jobs (organisation_id, uploaded_at DESC);
CREATE INDEX import_jobs_pending_idx ON import_jobs (status, updated_at) WHERE status IN ('uploaded','validating','approved','applying');
CREATE TRIGGER import_jobs_touch BEFORE UPDATE ON import_jobs FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER import_jobs_no_delete BEFORE DELETE ON import_jobs FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

CREATE TABLE import_rows (
  id                  uuid PRIMARY KEY DEFAULT uuid_v7(),
  import_job_id       uuid NOT NULL,
  organisation_id     uuid NOT NULL,
  row_number          integer NOT NULL CHECK (row_number > 0),
  source_record_id    text NULL,
  raw                 jsonb NOT NULL,
  normalized          jsonb NULL,
  payload_sha256      char(64) NULL,
  status              text NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','valid','warning','invalid','applied','no_change','skipped','failed')),
  findings            jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(findings) = 'array'),
  planned_action      text NULL CHECK (planned_action IN ('create','update','no_change','reject')),
  match_method        text NULL CHECK (match_method IN ('source_mapping','vin','stock_number','none','proposal')),
  matched_vehicle_id  uuid NULL REFERENCES vehicles(id),
  matched_listing_id  uuid NULL REFERENCES listings(id),
  result              jsonb NULL,
  applied_at          timestamptz NULL,
  FOREIGN KEY (import_job_id, organisation_id) REFERENCES import_jobs(id, organisation_id),
  UNIQUE (import_job_id, row_number)
);
COMMENT ON TABLE import_rows IS 'Staged rows with raw source payload (provenance), normalised values, findings [{severity, field, code, message}] and outcome.';
COMMENT ON COLUMN import_rows.findings IS 'JSONB array of validation findings; variable length and shape per rule (justified). Filter with findings @> ''[{"code":"..."}]''.';
CREATE INDEX import_rows_job_status_idx ON import_rows (import_job_id, status);
CREATE INDEX import_rows_findings_gin ON import_rows USING gin (findings jsonb_path_ops);

CREATE TABLE source_record_mappings (
  id                      uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id         uuid NOT NULL REFERENCES organisations(id),
  source_namespace        text NOT NULL,
  source_record_id        text NOT NULL,
  vehicle_id              uuid NOT NULL REFERENCES vehicles(id),
  listing_id              uuid NULL REFERENCES listings(id),
  last_source_updated_at  timestamptz NULL,
  last_payload_sha256     char(64) NULL,
  last_import_job_id      uuid NULL REFERENCES import_jobs(id),
  last_seen_at            timestamptz NOT NULL DEFAULT now(),
  created_at              timestamptz NOT NULL DEFAULT now(),
  updated_at              timestamptz NOT NULL DEFAULT now(),
  version                 integer NOT NULL DEFAULT 1,
  UNIQUE (organisation_id, source_namespace, source_record_id)
);
COMMENT ON TABLE source_record_mappings IS 'External source record -> internal vehicle/listing. Drives idempotent re-imports (payload hash) and stale-update rejection (last_source_updated_at).';
CREATE INDEX source_record_mappings_vehicle_idx ON source_record_mappings (vehicle_id);
CREATE TRIGGER source_record_mappings_touch BEFORE UPDATE ON source_record_mappings FOR EACH ROW EXECUTE FUNCTION trg_touch_row();

-- Cross-tenant VIN conflict probe for import validation. Returns only a
-- boolean (existence), never the other organisation or vehicle.
CREATE FUNCTION vin_registered_elsewhere(p_vin text, p_org uuid) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT EXISTS (SELECT 1 FROM vehicle_identifiers i JOIN vehicles v ON v.id = i.vehicle_id
                  WHERE i.namespace = 'vin' AND i.value_normalized = upper(p_vin) AND i.retired_at IS NULL
                    AND v.custodian_organisation_id <> p_org)
$$;

-- @@DOWN@@
DROP FUNCTION IF EXISTS vin_registered_elsewhere(text, uuid);
DROP TABLE IF EXISTS source_record_mappings, import_rows, import_jobs CASCADE;
