-- =====================================================================
-- AUTOS DATA — 0004 Customers
-- Customers are platform-level people/businesses. A dealer sees a
-- customer only through a customer_relationships row (created when the
-- customer quotes, reserves, books a test drive or rents with them).
-- =====================================================================

CREATE TABLE customers (
  id                 uuid PRIMARY KEY DEFAULT uuid_v7(),
  customer_type      text NOT NULL DEFAULT 'individual' CHECK (customer_type IN ('individual','business')),
  given_name         text NULL,
  family_name        text NULL,
  business_name      text NULL,
  display_name       text NOT NULL CHECK (length(btrim(display_name)) > 0),
  email              citext NULL CHECK (email IS NULL OR email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  phone              text NULL CHECK (phone IS NULL OR phone ~ '^\+[1-9][0-9]{6,14}$'),
  marketing_consent  boolean NULL,
  status             text NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived','erased')),
  erased_at          timestamptz NULL,
  is_synthetic       boolean NOT NULL DEFAULT true,
  created_by_organisation_id uuid NULL REFERENCES organisations(id),
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  version            integer NOT NULL DEFAULT 1,
  CHECK ((status = 'erased') = (erased_at IS NOT NULL)),
  CHECK (status <> 'erased' OR (email IS NULL AND phone IS NULL AND given_name IS NULL AND family_name IS NULL)),
  CHECK (customer_type <> 'business' OR business_name IS NOT NULL OR status = 'erased')
);
COMMENT ON TABLE customers IS 'Customer records. Erasure anonymises personal fields but keeps the row so quotes, sales and payments stay referentially intact.';
COMMENT ON COLUMN customers.created_by_organisation_id IS 'Organisation whose staff registered the customer (NULL = self-registered). Grants that organisation visibility.';
COMMENT ON COLUMN customers.marketing_consent IS 'NULL = never asked; false = declined; true = consented.';
CREATE UNIQUE INDEX customers_email_uq ON customers (email) WHERE email IS NOT NULL AND status <> 'erased';
CREATE INDEX customers_name_trgm ON customers USING gin (display_name gin_trgm_ops);
CREATE TRIGGER customers_touch BEFORE UPDATE ON customers FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER customers_no_delete BEFORE DELETE ON customers FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

ALTER TABLE app_users ADD CONSTRAINT app_users_customer_fk FOREIGN KEY (customer_id) REFERENCES customers(id);
CREATE UNIQUE INDEX app_users_customer_uq ON app_users (customer_id) WHERE customer_id IS NOT NULL;

CREATE TABLE customer_relationships (
  customer_id           uuid NOT NULL REFERENCES customers(id),
  organisation_id       uuid NOT NULL REFERENCES organisations(id),
  basis                 text NOT NULL CHECK (basis IN ('quote','sale_reservation','test_drive','rental','import','manual')),
  first_interaction_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (customer_id, organisation_id)
);
COMMENT ON TABLE customer_relationships IS 'Which organisations may see a customer. The tenant boundary for customer PII.';
CREATE INDEX customer_relationships_org_idx ON customer_relationships (organisation_id);

CREATE TABLE customer_addresses (
  id            uuid PRIMARY KEY DEFAULT uuid_v7(),
  customer_id   uuid NOT NULL REFERENCES customers(id),
  kind          text NOT NULL CHECK (kind IN ('home','billing','delivery')),
  line1         text NOT NULL,
  line2         text NULL,
  city          text NOT NULL,
  region        text NULL,
  postal_code   text NULL,
  country_code  char(2) NOT NULL CHECK (country_code ~ '^[A-Z]{2}$'),
  geog          geography(Point, 4326) NULL,
  valid_from    timestamptz NOT NULL DEFAULT now(),
  valid_to      timestamptz NULL CHECK (valid_to IS NULL OR valid_to > valid_from),
  created_at    timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE customer_addresses IS 'Effective-dated addresses; superseded addresses are closed (valid_to), not overwritten.';
CREATE INDEX customer_addresses_customer_idx ON customer_addresses (customer_id) WHERE valid_to IS NULL;

CREATE TABLE saved_vehicles (
  customer_id  uuid NOT NULL REFERENCES customers(id),
  listing_id   uuid NOT NULL REFERENCES listings(id),
  note         text NULL,
  saved_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (customer_id, listing_id)
);
COMMENT ON TABLE saved_vehicles IS 'Customer shortlist. Deletable by the customer (no business history).';

CREATE TABLE saved_searches (
  id                uuid PRIMARY KEY DEFAULT uuid_v7(),
  customer_id       uuid NOT NULL REFERENCES customers(id),
  name              text NOT NULL,
  criteria          jsonb NOT NULL CHECK (jsonb_typeof(criteria) = 'object'),
  notify            boolean NOT NULL DEFAULT false,
  last_notified_at  timestamptz NULL,
  created_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (customer_id, name)
);
COMMENT ON COLUMN saved_searches.criteria IS 'JSONB: user-defined filter set, validated by the API contract (SavedSearchCriteria). Variable by design; never joined on.';

-- @@DOWN@@
DROP TABLE IF EXISTS saved_searches, saved_vehicles, customer_addresses, customer_relationships CASCADE;
ALTER TABLE app_users DROP CONSTRAINT IF EXISTS app_users_customer_fk;
DROP TABLE IF EXISTS customers CASCADE;
