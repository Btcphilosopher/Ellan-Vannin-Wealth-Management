-- =====================================================================
-- AUTOS DATA — 0007 Test-drive scheduling
--
-- * A vehicle can be in at most one CONFIRMED appointment at any instant
--   (GiST exclusion on [starts_at, ends_at)).
-- * An appointment resource (staff member, bay, demo plate) has a
--   capacity; confirmations lock the resource row and check peak
--   concurrent usage with a half-open sweep, so N concurrent
--   confirmations cannot exceed capacity.
-- * Test drives are independent of sale holds. Policy when the vehicle
--   changes state:
--     - another customer's sale hold starts  -> availability_notice =
--       'vehicle_reserved' on future appointments (kept, flagged)
--     - hold released/expired                -> notice cleared
--     - vehicle sold / unavailable / written off -> future requested or
--       confirmed appointments are cancelled by the system with reason
--       'vehicle_unavailable'.
-- =====================================================================

CREATE TABLE appointment_resources (
  id               uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id  uuid NOT NULL REFERENCES organisations(id),
  location_id      uuid NOT NULL,
  kind             text NOT NULL CHECK (kind IN ('staff','bay','demo_plate')),
  name             text NOT NULL,
  user_id          uuid NULL REFERENCES app_users(id),
  capacity         smallint NOT NULL DEFAULT 1 CHECK (capacity BETWEEN 1 AND 50),
  status           text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  version          integer NOT NULL DEFAULT 1,
  FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id),
  UNIQUE (id, organisation_id),
  UNIQUE (organisation_id, location_id, name),
  CHECK (kind <> 'staff' OR capacity = 1)
);
COMMENT ON TABLE appointment_resources IS 'Bookable test-drive resources with a concurrent capacity (staff are always capacity 1).';
CREATE TRIGGER appointment_resources_touch BEFORE UPDATE ON appointment_resources FOR EACH ROW EXECUTE FUNCTION trg_touch_row();

CREATE TABLE test_drive_appointments (
  id                    uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id       uuid NOT NULL REFERENCES organisations(id),
  location_id           uuid NOT NULL,
  vehicle_id            uuid NOT NULL REFERENCES vehicles(id),
  listing_id            uuid NULL,
  customer_id           uuid NOT NULL REFERENCES customers(id),
  resource_id           uuid NOT NULL,
  starts_at             timestamptz NOT NULL,
  ends_at               timestamptz NOT NULL,
  slot                  tstzrange GENERATED ALWAYS AS (tstzrange(starts_at, ends_at, '[)')) STORED,
  local_timezone        text NOT NULL,
  request_status        text NOT NULL DEFAULT 'requested' CHECK (request_status IN ('requested','accepted','declined','withdrawn')),
  confirmation_status   text NOT NULL DEFAULT 'unconfirmed' CHECK (confirmation_status IN ('unconfirmed','confirmed','cancelled','completed','no_show')),
  availability_notice   text NULL CHECK (availability_notice IN ('vehicle_reserved')),
  cancelled_at          timestamptz NULL,
  cancelled_by_kind     text NULL CHECK (cancelled_by_kind IN ('customer','dealer','system')),
  cancellation_reason   text NULL,
  idempotency_key       text NULL,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  version               integer NOT NULL DEFAULT 1,
  FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id),
  FOREIGN KEY (resource_id, organisation_id) REFERENCES appointment_resources(id, organisation_id),
  FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id),
  CHECK (ends_at > starts_at AND ends_at - starts_at <= interval '4 hours'),
  CHECK ((confirmation_status = 'cancelled') = (cancelled_at IS NOT NULL AND cancellation_reason IS NOT NULL AND cancelled_by_kind IS NOT NULL)),
  CHECK (confirmation_status <> 'confirmed' OR request_status = 'accepted'),
  CHECK (request_status <> 'declined' OR confirmation_status IN ('unconfirmed','cancelled')),
  EXCLUDE USING gist (vehicle_id WITH =, slot WITH &&) WHERE (confirmation_status = 'confirmed')
);
COMMENT ON TABLE test_drive_appointments IS 'Test-drive requests and confirmations. Instants are timestamptz; local_timezone (copied from the location) is used for display and local-day rules. Independent of sale holds.';
COMMENT ON COLUMN test_drive_appointments.request_status IS 'Customer request lifecycle: requested -> accepted | declined | withdrawn.';
COMMENT ON COLUMN test_drive_appointments.confirmation_status IS 'Slot lifecycle: unconfirmed -> confirmed -> completed | no_show; any non-final -> cancelled. Conflicts are enforced only between confirmed rows.';
CREATE INDEX test_drive_appointments_resource_idx ON test_drive_appointments USING gist (resource_id, slot) WHERE confirmation_status = 'confirmed';
CREATE INDEX test_drive_appointments_org_start_idx ON test_drive_appointments (organisation_id, starts_at);
CREATE INDEX test_drive_appointments_vehicle_idx ON test_drive_appointments (vehicle_id, starts_at);
CREATE UNIQUE INDEX test_drive_appointments_idem_uq ON test_drive_appointments (organisation_id, idempotency_key) WHERE idempotency_key IS NOT NULL;

-- Peak concurrency of a set of half-open ranges, clipped to a window.
-- Ends sort before starts at the same instant, so [9:00,10:00) and
-- [10:00,11:00) never overlap.
CREATE FUNCTION peak_concurrency(ranges tstzrange[], win tstzrange) RETURNS integer
LANGUAGE sql IMMUTABLE AS $$
  WITH clipped AS (
    SELECT r * win AS r FROM unnest(ranges) AS r WHERE r && win
  ), ev AS (
    SELECT lower(r) AS t, 1 AS d FROM clipped WHERE NOT isempty(r)
    UNION ALL
    SELECT upper(r) AS t, -1 AS d FROM clipped WHERE NOT isempty(r)
  )
  SELECT COALESCE(max(c), 0)::integer FROM (
    SELECT sum(d) OVER (ORDER BY t, d ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS c FROM ev
  ) s
$$;
COMMENT ON FUNCTION peak_concurrency(tstzrange[], tstzrange) IS 'Maximum number of simultaneously open half-open ranges inside win.';

CREATE FUNCTION trg_test_drive_check() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  res   appointment_resources%ROWTYPE;
  loc   locations%ROWTYPE;
  peak  integer;
  win   tstzrange := tstzrange(NEW.starts_at, NEW.ends_at, '[)');  -- generated column NEW.slot is not yet computed in BEFORE triggers
BEGIN
  SELECT * INTO loc FROM locations WHERE id = NEW.location_id;
  IF TG_OP = 'INSERT' THEN
    NEW.local_timezone := loc.timezone;
  ELSIF NEW.local_timezone IS DISTINCT FROM OLD.local_timezone THEN
    NEW.local_timezone := OLD.local_timezone;
  END IF;

  IF TG_OP = 'UPDATE' AND OLD.confirmation_status IN ('cancelled','completed','no_show')
     AND (to_jsonb(NEW) - 'updated_at' - 'version' - 'slot') IS DISTINCT FROM (to_jsonb(OLD) - 'updated_at' - 'version' - 'slot') THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = format('immutable_record: appointment is %s', OLD.confirmation_status);
  END IF;
  IF TG_OP = 'UPDATE' AND NEW.confirmation_status IS DISTINCT FROM OLD.confirmation_status
     AND (OLD.confirmation_status, NEW.confirmation_status) NOT IN (
       ('unconfirmed','confirmed'), ('unconfirmed','cancelled'), ('confirmed','cancelled'),
       ('confirmed','completed'), ('confirmed','no_show')) THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: appointment %s -> %s', OLD.confirmation_status, NEW.confirmation_status);
  END IF;

  IF NEW.confirmation_status = 'confirmed' THEN
    -- Serialise all confirmations for this resource.
    SELECT * INTO res FROM appointment_resources WHERE id = NEW.resource_id FOR NO KEY UPDATE;
    IF res.status <> 'active' THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9006', MESSAGE = 'resource_capacity_exceeded: resource is inactive';
    END IF;
    IF res.location_id <> NEW.location_id THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_reference: resource belongs to a different location';
    END IF;
    SELECT peak_concurrency(array_agg(a.slot) || win, win) INTO peak
      FROM test_drive_appointments a
     WHERE a.resource_id = NEW.resource_id AND a.confirmation_status = 'confirmed'
       AND a.slot && win AND a.id <> NEW.id;
    IF COALESCE(peak, 1) > res.capacity THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9006',
        MESSAGE = format('resource_capacity_exceeded: %s already has %s of %s concurrent slots in use', res.name, peak - 1, res.capacity);
    END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER test_drive_appointments_check BEFORE INSERT OR UPDATE ON test_drive_appointments FOR EACH ROW EXECUTE FUNCTION trg_test_drive_check();
CREATE TRIGGER test_drive_appointments_touch BEFORE UPDATE ON test_drive_appointments FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER test_drive_appointments_no_delete BEFORE DELETE ON test_drive_appointments FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

-- Policy: vehicle becomes unavailable -> cancel future appointments.
CREATE FUNCTION trg_vehicle_availability_appointments() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  IF NEW.availability_status IN ('sold','unavailable','written_off')
     AND OLD.availability_status IS DISTINCT FROM NEW.availability_status THEN
    UPDATE test_drive_appointments
       SET confirmation_status = 'cancelled', cancelled_at = now(), cancelled_by_kind = 'system',
           cancellation_reason = 'vehicle_unavailable:' || NEW.availability_status,
           request_status = CASE WHEN request_status = 'requested' THEN 'declined' ELSE request_status END
     WHERE vehicle_id = NEW.id AND starts_at > now() AND confirmation_status IN ('unconfirmed','confirmed');
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER vehicles_availability_appointments AFTER UPDATE OF availability_status ON vehicles
  FOR EACH ROW EXECUTE FUNCTION trg_vehicle_availability_appointments();

-- Policy: a sale hold by any customer flags other customers' future drives.
CREATE FUNCTION trg_current_reservation_appointments() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE holder uuid;
BEGIN
  IF TG_OP = 'INSERT' THEN
    SELECT customer_id INTO holder FROM sale_reservations WHERE id = NEW.sale_reservation_id;
    UPDATE test_drive_appointments SET availability_notice = 'vehicle_reserved'
     WHERE vehicle_id = NEW.vehicle_id AND starts_at > now() AND customer_id <> holder
       AND confirmation_status IN ('unconfirmed','confirmed') AND availability_notice IS NULL;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE test_drive_appointments SET availability_notice = NULL
     WHERE vehicle_id = OLD.vehicle_id AND availability_notice = 'vehicle_reserved'
       AND confirmation_status IN ('unconfirmed','confirmed');
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER vehicle_current_reservations_appointments AFTER INSERT OR DELETE ON vehicle_current_reservations
  FOR EACH ROW EXECUTE FUNCTION trg_current_reservation_appointments();

-- @@DOWN@@
DROP TRIGGER IF EXISTS vehicle_current_reservations_appointments ON vehicle_current_reservations;
DROP TRIGGER IF EXISTS vehicles_availability_appointments ON vehicles;
DROP TABLE IF EXISTS test_drive_appointments, appointment_resources CASCADE;
DROP FUNCTION IF EXISTS trg_current_reservation_appointments(), trg_vehicle_availability_appointments(), trg_test_drive_check(), peak_concurrency(tstzrange[], tstzrange);
