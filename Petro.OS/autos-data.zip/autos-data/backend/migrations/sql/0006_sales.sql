-- =====================================================================
-- AUTOS DATA — 0006 Sale reservations, orders, handover
--
-- Concurrency design (one physical vehicle => at most one commitment):
--   1. vehicle_current_reservations has PRIMARY KEY (vehicle_id). A row
--      exists while a reservation/sale order commits the vehicle. A
--      second concurrent commitment fails on the PK, regardless of which
--      listing it came through.
--   2. Before inserting a reservation, the trigger locks the vehicles
--      row (SELECT ... FOR NO KEY UPDATE). All reservation creation,
--      expiry and acceptance for a vehicle therefore serialises on that
--      lock. NO KEY UPDATE (not FOR UPDATE) is deliberate: it serialises
--      writers but stays compatible with the FOR KEY SHARE locks that
--      foreign-key checks take, which avoids lock-upgrade deadlocks.
--   3. Expiry is evaluated against hold_expires_at under that same lock
--      at the moment of use (a lapsed hold is expired inline before a
--      competing reservation is accepted). The background sweeper only
--      tidies up; correctness never depends on it running on time.
--   4. A partial unique index on sale_reservations(vehicle_id) for active
--      statuses is a second, independent guard.
--
-- Lifecycle (kept separate on purpose):
--   temporary hold     sale_reservations.status = held, hold_expires_at
--   deposit payment    sale_reservations.deposit_status (+ payments 0009)
--   dealer acceptance  status held -> dealer_accepted (accepted_at/by)
--   sale agreement     sale_orders (agreement_pending -> agreement_signed)
--   handover           handover_records + sale_orders.handed_over
--   completed sale     sale_orders.completed -> vehicle sold
-- Payment settlement alone never advances any of these statuses.
-- =====================================================================

CREATE SEQUENCE sale_reservation_number_seq;
CREATE SEQUENCE sale_order_number_seq;

CREATE TABLE sale_reservations (
  id                      uuid PRIMARY KEY DEFAULT uuid_v7(),
  reservation_number      text NOT NULL UNIQUE
                            DEFAULT ('R-' || to_char(now() AT TIME ZONE 'UTC', 'YYYY') || '-' || lpad(nextval('sale_reservation_number_seq')::text, 7, '0')),
  organisation_id         uuid NOT NULL REFERENCES organisations(id),
  listing_id              uuid NOT NULL,
  vehicle_id              uuid NOT NULL REFERENCES vehicles(id),
  customer_id             uuid NOT NULL REFERENCES customers(id),
  quote_id                uuid NULL,
  status                  text NOT NULL DEFAULT 'held'
                            CHECK (status IN ('held','dealer_accepted','converted','expired','cancelled','declined','released')),
  deposit_status          text NOT NULL DEFAULT 'not_required'
                            CHECK (deposit_status IN ('not_required','awaiting','paid','refund_pending','refunded')),
  deposit_required_minor  bigint NOT NULL DEFAULT 0 CHECK (deposit_required_minor >= 0),
  currency                char(3) NOT NULL REFERENCES currencies(code),
  hold_expires_at         timestamptz NOT NULL,
  deposit_paid_at         timestamptz NULL,
  accepted_at             timestamptz NULL,
  accepted_by             uuid NULL REFERENCES app_users(id),
  ended_at                timestamptz NULL,
  end_reason              text NULL,
  idempotency_key         text NULL,
  created_by              uuid NULL REFERENCES app_users(id),
  created_at              timestamptz NOT NULL DEFAULT now(),
  updated_at              timestamptz NOT NULL DEFAULT now(),
  version                 integer NOT NULL DEFAULT 1,
  FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id),
  FOREIGN KEY (quote_id, organisation_id) REFERENCES quotes(id, organisation_id),
  UNIQUE (id, organisation_id),
  CHECK (hold_expires_at > created_at),
  CHECK ((deposit_required_minor = 0) = (deposit_status = 'not_required')),
  CHECK ((status IN ('held','dealer_accepted','converted')) = (ended_at IS NULL OR status = 'converted')),
  CHECK (status NOT IN ('expired','cancelled','declined','released') OR end_reason IS NOT NULL),
  CHECK (status NOT IN ('dealer_accepted','converted') OR accepted_at IS NOT NULL),
  CHECK (deposit_status <> 'paid' OR deposit_paid_at IS NOT NULL)
);
COMMENT ON TABLE sale_reservations IS 'Reservation history for physical vehicles. Identity columns are immutable; status moves forward only. Effective expiry = status held AND hold_expires_at <= now(), even before the row is transitioned.';
COMMENT ON COLUMN sale_reservations.hold_expires_at IS 'Temporary-hold deadline. Extended (never shortened) when a deposit is confirmed in time.';
CREATE UNIQUE INDEX sale_reservations_one_active_per_vehicle_uq ON sale_reservations (vehicle_id) WHERE status IN ('held','dealer_accepted');
CREATE UNIQUE INDEX sale_reservations_idempotency_uq ON sale_reservations (organisation_id, idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX sale_reservations_org_status_idx ON sale_reservations (organisation_id, status, created_at DESC);
CREATE INDEX sale_reservations_customer_idx ON sale_reservations (customer_id, created_at DESC);
CREATE INDEX sale_reservations_expiry_idx ON sale_reservations (hold_expires_at) WHERE status = 'held';

CREATE TABLE sale_orders (
  id                     uuid PRIMARY KEY DEFAULT uuid_v7(),
  order_number           text NOT NULL UNIQUE
                           DEFAULT ('S-' || to_char(now() AT TIME ZONE 'UTC', 'YYYY') || '-' || lpad(nextval('sale_order_number_seq')::text, 7, '0')),
  organisation_id        uuid NOT NULL REFERENCES organisations(id),
  sale_reservation_id    uuid NOT NULL UNIQUE,
  vehicle_id             uuid NOT NULL REFERENCES vehicles(id),
  customer_id            uuid NOT NULL REFERENCES customers(id),
  quote_id               uuid NULL,
  currency               char(3) NOT NULL REFERENCES currencies(code),
  agreed_total_minor     bigint NOT NULL CHECK (agreed_total_minor > 0),
  status                 text NOT NULL DEFAULT 'agreement_pending'
                           CHECK (status IN ('agreement_pending','agreement_signed','handed_over','completed','cancelled')),
  agreement_signed_at    timestamptz NULL,
  agreement_media_id     uuid NULL REFERENCES vehicle_media(id),
  completed_at           timestamptz NULL,
  cancelled_at           timestamptz NULL,
  cancel_reason          text NULL,
  created_by             uuid NULL REFERENCES app_users(id),
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),
  version                integer NOT NULL DEFAULT 1,
  FOREIGN KEY (sale_reservation_id, organisation_id) REFERENCES sale_reservations(id, organisation_id),
  FOREIGN KEY (quote_id, organisation_id) REFERENCES quotes(id, organisation_id),
  UNIQUE (id, organisation_id),
  CHECK (status NOT IN ('agreement_signed','handed_over','completed') OR agreement_signed_at IS NOT NULL),
  CHECK ((status = 'completed') = (completed_at IS NOT NULL)),
  CHECK ((status = 'cancelled') = (cancelled_at IS NOT NULL AND cancel_reason IS NOT NULL))
);
COMMENT ON TABLE sale_orders IS 'Sale agreement through to completion. Created only from a dealer-accepted reservation.';
CREATE UNIQUE INDEX sale_orders_one_open_per_vehicle_uq ON sale_orders (vehicle_id) WHERE status NOT IN ('completed','cancelled');
CREATE INDEX sale_orders_org_status_idx ON sale_orders (organisation_id, status, created_at DESC);

CREATE TABLE vehicle_current_reservations (
  vehicle_id           uuid PRIMARY KEY REFERENCES vehicles(id),
  sale_reservation_id  uuid NOT NULL UNIQUE REFERENCES sale_reservations(id),
  sale_order_id        uuid NULL UNIQUE REFERENCES sale_orders(id),
  organisation_id      uuid NOT NULL REFERENCES organisations(id),
  hold_expires_at      timestamptz NULL,
  committed_since      timestamptz NOT NULL DEFAULT now()
);
COMMENT ON TABLE vehicle_current_reservations IS 'At most one row per physical vehicle: the reservation (and later sale order) currently committing it. Maintained only by SECURITY DEFINER triggers; the application role has SELECT only.';

CREATE TABLE sale_status_events (
  id                   uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id      uuid NOT NULL REFERENCES organisations(id),
  sale_reservation_id  uuid NULL REFERENCES sale_reservations(id),
  sale_order_id        uuid NULL REFERENCES sale_orders(id),
  event                text NOT NULL,
  from_status          text NULL,
  to_status            text NULL,
  detail               jsonb NOT NULL DEFAULT '{}'::jsonb,
  actor_user_id        uuid NULL REFERENCES app_users(id),
  actor_kind           text NOT NULL,
  request_id           text NULL,
  occurred_at          timestamptz NOT NULL DEFAULT now(),
  CHECK (num_nonnulls(sale_reservation_id, sale_order_id) >= 1)
);
COMMENT ON TABLE sale_status_events IS 'Append-only history of reservation and sale-order transitions (written by triggers).';
CREATE INDEX sale_status_events_reservation_idx ON sale_status_events (sale_reservation_id, occurred_at);
CREATE INDEX sale_status_events_order_idx ON sale_status_events (sale_order_id, occurred_at);
CREATE TRIGGER sale_status_events_append BEFORE UPDATE OR DELETE ON sale_status_events FOR EACH ROW EXECUTE FUNCTION trg_append_only();

CREATE TABLE handover_records (
  id               uuid PRIMARY KEY DEFAULT uuid_v7(),
  sale_order_id    uuid NOT NULL,
  organisation_id  uuid NOT NULL,
  location_id      uuid NOT NULL,
  scheduled_for    timestamptz NULL,
  handed_over_at   timestamptz NULL,
  odometer_value   integer NULL CHECK (odometer_value >= 0),
  odometer_unit    text NULL CHECK (odometer_unit IN ('km','mi')),
  staff_user_id    uuid NULL REFERENCES app_users(id),
  notes            text NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  version          integer NOT NULL DEFAULT 1,
  FOREIGN KEY (sale_order_id, organisation_id) REFERENCES sale_orders(id, organisation_id),
  FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id),
  CHECK ((odometer_value IS NULL) = (odometer_unit IS NULL)),
  CHECK (scheduled_for IS NOT NULL OR handed_over_at IS NOT NULL)
);
COMMENT ON TABLE handover_records IS 'Scheduled and completed physical handovers. Once handed_over_at is recorded the row is frozen.';
CREATE UNIQUE INDEX handover_records_one_completed_uq ON handover_records (sale_order_id) WHERE handed_over_at IS NOT NULL;
CREATE TRIGGER handover_records_touch BEFORE UPDATE ON handover_records FOR EACH ROW EXECUTE FUNCTION trg_touch_row();

CREATE FUNCTION trg_handover_freeze() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' OR OLD.handed_over_at IS NOT NULL THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: completed handover records are frozen';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER handover_records_freeze BEFORE UPDATE OR DELETE ON handover_records FOR EACH ROW EXECUTE FUNCTION trg_handover_freeze();

-- ---------------------------------------------------------------------
-- Reservation integrity triggers
-- ---------------------------------------------------------------------
CREATE FUNCTION sales_log_event(p_org uuid, p_res uuid, p_order uuid, p_event text, p_from text, p_to text, p_detail jsonb)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public, pg_temp AS $$
  INSERT INTO sale_status_events (organisation_id, sale_reservation_id, sale_order_id, event, from_status, to_status, detail, actor_user_id, actor_kind, request_id)
  VALUES (p_org, p_res, p_order, p_event, p_from, p_to, COALESCE(p_detail, '{}'::jsonb), app_user_id(), app_actor_kind(), app_request_id());
$$;

-- BEFORE INSERT: serialise on the vehicle, validate, expire a lapsed hold inline.
CREATE FUNCTION trg_sale_reservation_before_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  v      vehicles%ROWTYPE;
  l      listings%ROWTYPE;
  cur    vehicle_current_reservations%ROWTYPE;
  prior  sale_reservations%ROWTYPE;
BEGIN
  IF NEW.status <> 'held' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_status_transition: reservations start as held';
  END IF;
  IF NEW.hold_expires_at <= now() THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9008', MESSAGE = 'hold_expired: hold_expires_at must be in the future';
  END IF;

  -- The serialisation point for everything that commits this vehicle.
  SELECT * INTO v FROM vehicles WHERE id = NEW.vehicle_id FOR NO KEY UPDATE;
  SELECT * INTO l FROM listings WHERE id = NEW.listing_id;
  IF l.vehicle_id <> NEW.vehicle_id THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_reference: listing does not offer this vehicle';
  END IF;
  IF l.status <> 'published' OR l.sale_eligibility <> 'eligible' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9001', MESSAGE = format('listing_not_reservable: listing is %s / %s', l.status, l.sale_eligibility);
  END IF;
  IF v.availability_status <> 'available' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9001', MESSAGE = format('vehicle_not_available: vehicle is %s', v.availability_status);
  END IF;

  SELECT * INTO cur FROM vehicle_current_reservations WHERE vehicle_id = NEW.vehicle_id FOR NO KEY UPDATE;
  IF FOUND THEN
    SELECT * INTO prior FROM sale_reservations WHERE id = cur.sale_reservation_id FOR NO KEY UPDATE;
    IF prior.status = 'held' AND prior.hold_expires_at <= now() THEN
      UPDATE sale_reservations
         SET status = 'expired', ended_at = now(), end_reason = 'hold_expired'
       WHERE id = prior.id;
    ELSE
      RAISE EXCEPTION USING ERRCODE = 'Z9001',
        MESSAGE = 'vehicle_already_reserved: this vehicle is committed to another reservation',
        DETAIL = format('vehicle_id=%s', NEW.vehicle_id);
    END IF;
  END IF;
  RETURN NEW;
END $$;

CREATE FUNCTION trg_sale_reservation_after_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  BEGIN
    INSERT INTO vehicle_current_reservations (vehicle_id, sale_reservation_id, organisation_id, hold_expires_at)
    VALUES (NEW.vehicle_id, NEW.id, NEW.organisation_id, NEW.hold_expires_at);
  EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9001', MESSAGE = 'vehicle_already_reserved: this vehicle is committed to another reservation';
  END;
  PERFORM sales_log_event(NEW.organisation_id, NEW.id, NULL, 'hold_created', NULL, NEW.status,
          jsonb_build_object('hold_expires_at', NEW.hold_expires_at, 'listing_id', NEW.listing_id, 'deposit_required_minor', NEW.deposit_required_minor));
  RETURN NULL;
END $$;

CREATE FUNCTION trg_sale_reservation_before_update() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF (NEW.id, NEW.reservation_number, NEW.organisation_id, NEW.listing_id, NEW.vehicle_id, NEW.customer_id, NEW.quote_id,
      NEW.deposit_required_minor, NEW.currency, NEW.created_at, NEW.created_by, NEW.idempotency_key)
     IS DISTINCT FROM
     (OLD.id, OLD.reservation_number, OLD.organisation_id, OLD.listing_id, OLD.vehicle_id, OLD.customer_id, OLD.quote_id,
      OLD.deposit_required_minor, OLD.currency, OLD.created_at, OLD.created_by, OLD.idempotency_key) THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: reservation identity fields cannot change';
  END IF;

  IF NEW.hold_expires_at < OLD.hold_expires_at THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: a hold can be extended but never shortened';
  END IF;
  IF NEW.hold_expires_at > OLD.hold_expires_at AND (OLD.status <> 'held' OR OLD.hold_expires_at <= now()) THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9008', MESSAGE = 'hold_expired: an expired or non-held reservation cannot be extended';
  END IF;

  IF NEW.status IS DISTINCT FROM OLD.status THEN
    IF (OLD.status, NEW.status) NOT IN (
        ('held','dealer_accepted'), ('held','expired'), ('held','cancelled'), ('held','declined'), ('held','released'),
        ('dealer_accepted','converted'), ('dealer_accepted','cancelled'), ('dealer_accepted','released')) THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: reservation %s -> %s', OLD.status, NEW.status);
    END IF;
    IF NEW.status = 'expired' AND OLD.hold_expires_at > now() THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_status_transition: hold has not reached hold_expires_at';
    END IF;
    IF NEW.status = 'dealer_accepted' AND OLD.hold_expires_at <= now() THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9008', MESSAGE = 'hold_expired: the hold lapsed before dealer acceptance';
    END IF;
    IF NEW.status IN ('expired','cancelled','declined','released') AND NEW.ended_at IS NULL THEN
      NEW.ended_at := now();
    END IF;
    IF NEW.status = 'dealer_accepted' AND NEW.accepted_at IS NULL THEN
      NEW.accepted_at := now();
    END IF;
  END IF;
  RETURN NEW;
END $$;

CREATE FUNCTION trg_sale_reservation_after_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    PERFORM sales_log_event(NEW.organisation_id, NEW.id, NULL, 'status_changed', OLD.status, NEW.status,
            jsonb_build_object('end_reason', NEW.end_reason));
    IF NEW.status IN ('expired','cancelled','declined','released') THEN
      DELETE FROM vehicle_current_reservations WHERE sale_reservation_id = NEW.id AND sale_order_id IS NULL;
    ELSIF NEW.status = 'dealer_accepted' THEN
      UPDATE vehicle_current_reservations SET hold_expires_at = NULL WHERE sale_reservation_id = NEW.id;
    END IF;
  END IF;
  IF NEW.hold_expires_at IS DISTINCT FROM OLD.hold_expires_at THEN
    UPDATE vehicle_current_reservations SET hold_expires_at = NEW.hold_expires_at WHERE sale_reservation_id = NEW.id;
    PERFORM sales_log_event(NEW.organisation_id, NEW.id, NULL, 'hold_extended', NULL, NULL,
            jsonb_build_object('from', OLD.hold_expires_at, 'to', NEW.hold_expires_at));
  END IF;
  IF NEW.deposit_status IS DISTINCT FROM OLD.deposit_status THEN
    PERFORM sales_log_event(NEW.organisation_id, NEW.id, NULL, 'deposit_status_changed', OLD.deposit_status, NEW.deposit_status, '{}'::jsonb);
  END IF;
  RETURN NULL;
END $$;

CREATE TRIGGER sale_reservations_before_insert BEFORE INSERT ON sale_reservations FOR EACH ROW EXECUTE FUNCTION trg_sale_reservation_before_insert();
CREATE TRIGGER sale_reservations_after_insert AFTER INSERT ON sale_reservations FOR EACH ROW EXECUTE FUNCTION trg_sale_reservation_after_insert();
CREATE TRIGGER sale_reservations_before_update BEFORE UPDATE ON sale_reservations FOR EACH ROW EXECUTE FUNCTION trg_sale_reservation_before_update();
CREATE TRIGGER sale_reservations_touch BEFORE UPDATE ON sale_reservations FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER sale_reservations_after_update AFTER UPDATE ON sale_reservations FOR EACH ROW EXECUTE FUNCTION trg_sale_reservation_after_update();
CREATE TRIGGER sale_reservations_no_delete BEFORE DELETE ON sale_reservations FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

-- ---------------------------------------------------------------------
-- Sale order triggers
-- ---------------------------------------------------------------------
CREATE FUNCTION trg_sale_order_before_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE r sale_reservations%ROWTYPE;
BEGIN
  PERFORM 1 FROM vehicles WHERE id = NEW.vehicle_id FOR NO KEY UPDATE;
  SELECT * INTO r FROM sale_reservations WHERE id = NEW.sale_reservation_id FOR NO KEY UPDATE;
  IF r.status <> 'dealer_accepted' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: sale orders require a dealer-accepted reservation (reservation is %s)', r.status);
  END IF;
  IF r.vehicle_id <> NEW.vehicle_id OR r.customer_id <> NEW.customer_id OR r.currency <> NEW.currency THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_reference: sale order must match its reservation (vehicle, customer, currency)';
  END IF;
  IF NEW.status <> 'agreement_pending' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_status_transition: sale orders start as agreement_pending';
  END IF;
  RETURN NEW;
END $$;

CREATE FUNCTION trg_sale_order_after_insert() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  UPDATE sale_reservations SET status = 'converted' WHERE id = NEW.sale_reservation_id;
  UPDATE vehicle_current_reservations SET sale_order_id = NEW.id WHERE sale_reservation_id = NEW.sale_reservation_id;
  PERFORM sales_log_event(NEW.organisation_id, NEW.sale_reservation_id, NEW.id, 'sale_order_created', NULL, NEW.status,
          jsonb_build_object('agreed_total_minor', NEW.agreed_total_minor, 'currency', NEW.currency));
  RETURN NULL;
END $$;

CREATE FUNCTION trg_sale_order_before_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  IF (NEW.organisation_id, NEW.sale_reservation_id, NEW.vehicle_id, NEW.customer_id, NEW.currency, NEW.quote_id, NEW.created_at)
     IS DISTINCT FROM (OLD.organisation_id, OLD.sale_reservation_id, OLD.vehicle_id, OLD.customer_id, OLD.currency, OLD.quote_id, OLD.created_at) THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: sale order identity fields cannot change';
  END IF;
  IF NEW.agreed_total_minor <> OLD.agreed_total_minor AND OLD.status <> 'agreement_pending' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: agreed total is fixed once the agreement is signed';
  END IF;
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    IF (OLD.status, NEW.status) NOT IN (
        ('agreement_pending','agreement_signed'), ('agreement_signed','handed_over'), ('handed_over','completed'),
        ('agreement_pending','cancelled'), ('agreement_signed','cancelled')) THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: sale order %s -> %s', OLD.status, NEW.status);
    END IF;
    IF NEW.status = 'agreement_signed' AND NEW.agreement_signed_at IS NULL THEN NEW.agreement_signed_at := now(); END IF;
    IF NEW.status = 'handed_over' AND NOT EXISTS (SELECT 1 FROM handover_records WHERE sale_order_id = NEW.id AND handed_over_at IS NOT NULL) THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = 'invalid_status_transition: record the handover before marking handed_over';
    END IF;
    IF NEW.status = 'completed' AND NEW.completed_at IS NULL THEN NEW.completed_at := now(); END IF;
    IF NEW.status = 'cancelled' AND NEW.cancelled_at IS NULL THEN NEW.cancelled_at := now(); END IF;
  END IF;
  RETURN NEW;
END $$;

CREATE FUNCTION trg_sale_order_after_update() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
BEGIN
  IF NEW.status IS DISTINCT FROM OLD.status THEN
    PERFORM sales_log_event(NEW.organisation_id, NEW.sale_reservation_id, NEW.id, 'status_changed', OLD.status, NEW.status,
            jsonb_build_object('cancel_reason', NEW.cancel_reason));
    IF NEW.status = 'completed' THEN
      DELETE FROM vehicle_current_reservations WHERE sale_order_id = NEW.id;
      UPDATE vehicles SET availability_status = 'sold', sold_at = NEW.completed_at WHERE id = NEW.vehicle_id;
      UPDATE listings SET status = 'sold', status_reason = 'sale_completed:' || NEW.order_number
       WHERE vehicle_id = NEW.vehicle_id AND status IN ('published','suspended');
      UPDATE listings SET status = 'withdrawn', status_reason = 'vehicle_sold_elsewhere:' || NEW.order_number
       WHERE vehicle_id = NEW.vehicle_id AND status = 'draft';
    ELSIF NEW.status = 'cancelled' THEN
      DELETE FROM vehicle_current_reservations WHERE sale_order_id = NEW.id;
    END IF;
  END IF;
  RETURN NULL;
END $$;

CREATE TRIGGER sale_orders_before_insert BEFORE INSERT ON sale_orders FOR EACH ROW EXECUTE FUNCTION trg_sale_order_before_insert();
CREATE TRIGGER sale_orders_after_insert AFTER INSERT ON sale_orders FOR EACH ROW EXECUTE FUNCTION trg_sale_order_after_insert();
CREATE TRIGGER sale_orders_before_update BEFORE UPDATE ON sale_orders FOR EACH ROW EXECUTE FUNCTION trg_sale_order_before_update();
CREATE TRIGGER sale_orders_touch BEFORE UPDATE ON sale_orders FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER sale_orders_after_update AFTER UPDATE ON sale_orders FOR EACH ROW EXECUTE FUNCTION trg_sale_order_after_update();
CREATE TRIGGER sale_orders_no_delete BEFORE DELETE ON sale_orders FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

-- Reservation effective-state view: never trust a stale 'held' row.
CREATE VIEW v_sale_reservation_effective WITH (security_invoker = true) AS
SELECT r.*,
       CASE WHEN r.status = 'held' AND r.hold_expires_at <= now() THEN 'expired' ELSE r.status END AS effective_status
FROM sale_reservations r;
COMMENT ON VIEW v_sale_reservation_effective IS 'Reservations with effective_status computed against now(); a held row past hold_expires_at reads as expired even before the sweeper transitions it.';

-- @@DOWN@@
DROP VIEW IF EXISTS v_sale_reservation_effective;
DROP TABLE IF EXISTS vehicle_current_reservations, handover_records, sale_status_events, sale_orders, sale_reservations CASCADE;
DROP SEQUENCE IF EXISTS sale_reservation_number_seq, sale_order_number_seq;
DROP FUNCTION IF EXISTS trg_sale_order_after_update(), trg_sale_order_before_update(), trg_sale_order_after_insert(), trg_sale_order_before_insert(),
  trg_sale_reservation_after_update(), trg_sale_reservation_before_update(), trg_sale_reservation_after_insert(), trg_sale_reservation_before_insert(),
  sales_log_event(uuid, uuid, uuid, text, text, text, jsonb), trg_handover_freeze();
