-- =====================================================================
-- AUTOS DATA — 0012 Roles, privileges, row-level security
--
-- Roles (group roles, NOLOGIN; login users are created by ops and
-- granted membership — see ops/db-init/01-roles.sh):
--   autos_owner     owns all objects, runs migrations, bypasses RLS
--   autos_app       runtime role for API and workers; subject to RLS;
--                   no DDL, no TRUNCATE, no UPDATE/DELETE on history
--   autos_readonly  SELECT only, subject to RLS (reporting)
--
-- RLS is defence in depth behind the API's authorisation checks. Tenant
-- context comes from set_config(..., is_local => true) per transaction.
-- =====================================================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autos_app') THEN
    CREATE ROLE autos_app NOLOGIN NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autos_readonly') THEN
    CREATE ROLE autos_readonly NOLOGIN NOBYPASSRLS;
  END IF;
END $$;

REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO autos_app, autos_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO autos_app, autos_readonly;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO autos_app;

-- Mutable operational tables: INSERT + UPDATE (no DELETE; rows archive).
GRANT INSERT, UPDATE ON
  organisations, app_users, organisation_memberships, locations,
  vehicles, vehicle_merge_proposals,
  listings, customers, customer_addresses,
  sale_reservations, sale_orders, handover_records,
  appointment_resources, test_drive_appointments,
  rental_categories, rental_inventory_buckets, rental_assets, rental_bookings, maintenance_blocks,
  payment_intents, refunds, reconciliation_cases,
  import_jobs, import_rows, source_record_mappings,
  outbox_events, idempotency_keys, worker_heartbeats
TO autos_app;

-- Insert-only / append-only tables.
GRANT INSERT ON
  vehicle_makes, vehicle_models, vehicle_trims, vehicle_specification_versions,
  vehicle_identifiers, vehicle_attribute_assertions, vehicle_features, vehicle_media,
  listing_price_versions, listing_status_events,
  customer_relationships, saved_vehicles, saved_searches,
  terms_versions, charge_rules, quotes, quote_lines, quote_acceptances,
  sale_status_events, rental_quotes, rental_asset_assignments,
  payment_events, payment_transactions, audit_events, admin_saved_filters
TO autos_app;

-- Narrow column-level updates on otherwise frozen tables.
GRANT UPDATE (effective_to) ON listing_price_versions TO autos_app;
GRANT UPDATE (status) ON quotes TO autos_app;
GRANT UPDATE (processing_status, processing_note, processed_at, organisation_id, payment_intent_id, refund_id) ON payment_events TO autos_app;
GRANT UPDATE (status, released_at) ON rental_asset_assignments TO autos_app;
GRANT UPDATE (retired_at, retired_reason, verification_status) ON vehicle_identifiers TO autos_app;
GRANT UPDATE (verification_status) ON vehicle_attribute_assertions TO autos_app;
GRANT UPDATE (verification_status, effective_to) ON vehicle_specification_versions TO autos_app;
GRANT UPDATE (archived_at, caption, sort_order) ON vehicle_media TO autos_app;
GRANT UPDATE (effective_to) ON charge_rules TO autos_app;
GRANT UPDATE (name, criteria, notify, last_notified_at) ON saved_searches TO autos_app;

-- Deletable only where no business history is involved.
GRANT DELETE ON saved_vehicles, saved_searches, admin_saved_filters, idempotency_keys TO autos_app;

-- vehicle_current_reservations: SELECT only. Maintained by SECURITY DEFINER triggers.
REVOKE INSERT, UPDATE, DELETE ON vehicle_current_reservations FROM autos_app;

-- ---------------------------------------------------------------------
-- Row-level security: standard tenant policy for organisation-scoped rows
-- ---------------------------------------------------------------------
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'organisation_memberships','locations','vehicle_attribute_assertions','vehicle_media','vehicle_merge_proposals',
    'listings','listing_price_versions','listing_status_events','charge_rules',
    'quotes','quote_lines','quote_acceptances',
    'sale_reservations','sale_orders','sale_status_events','handover_records','vehicle_current_reservations',
    'appointment_resources','test_drive_appointments',
    'rental_categories','rental_inventory_buckets','rental_assets','rental_quotes','rental_bookings',
    'rental_asset_assignments','maintenance_blocks',
    'payment_intents','payment_transactions','payment_events','refunds','reconciliation_cases',
    'import_jobs','import_rows','source_record_mappings','customer_relationships',
    'audit_events','outbox_events']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY tenant_rw ON %I USING (app_can_access_org(organisation_id)) WITH CHECK (app_can_access_org(organisation_id))', t);
  END LOOP;
END $$;

-- Public catalogue visibility (anyone, including customers and other
-- dealers, may read what is published).
CREATE POLICY listings_public_read ON listings FOR SELECT USING (status = 'published');
CREATE POLICY listing_prices_public_read ON listing_price_versions FOR SELECT
  USING (EXISTS (SELECT 1 FROM listings l WHERE l.id = listing_price_versions.listing_id AND l.status = 'published'));
CREATE POLICY locations_public_read ON locations FOR SELECT USING (status = 'active');
CREATE POLICY rental_categories_public_read ON rental_categories FOR SELECT USING (status = 'active');

-- Vehicles: custodian tenant, or reachable through a listing the caller can see.
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
CREATE POLICY vehicles_custodian_rw ON vehicles
  USING (app_can_access_org(custodian_organisation_id)) WITH CHECK (app_can_access_org(custodian_organisation_id));
CREATE POLICY vehicles_listed_read ON vehicles FOR SELECT
  USING (EXISTS (SELECT 1 FROM listings l WHERE l.vehicle_id = vehicles.id));

-- Vehicle children inherit vehicle visibility; issuer-scoped identifiers
-- (e.g. a dealer's stock number) are visible only to the issuer.
ALTER TABLE vehicle_identifiers ENABLE ROW LEVEL SECURITY;
CREATE POLICY vehicle_identifiers_read ON vehicle_identifiers FOR SELECT
  USING (EXISTS (SELECT 1 FROM vehicles v WHERE v.id = vehicle_identifiers.vehicle_id)
         AND (issuing_organisation_id IS NULL OR app_can_access_org(issuing_organisation_id)));
CREATE POLICY vehicle_identifiers_write ON vehicle_identifiers FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM vehicles v WHERE v.id = vehicle_identifiers.vehicle_id AND app_can_access_org(v.custodian_organisation_id)));
CREATE POLICY vehicle_identifiers_update ON vehicle_identifiers FOR UPDATE
  USING (EXISTS (SELECT 1 FROM vehicles v WHERE v.id = vehicle_identifiers.vehicle_id AND app_can_access_org(v.custodian_organisation_id)));

ALTER TABLE vehicle_features ENABLE ROW LEVEL SECURITY;
CREATE POLICY vehicle_features_read ON vehicle_features FOR SELECT
  USING (EXISTS (SELECT 1 FROM vehicles v WHERE v.id = vehicle_features.vehicle_id));
CREATE POLICY vehicle_features_write ON vehicle_features FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM vehicles v WHERE v.id = vehicle_features.vehicle_id AND app_can_access_org(v.custodian_organisation_id)));

-- Customers: platform, the customer themself, the registering
-- organisation, or an organisation with a recorded relationship.
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
CREATE POLICY customers_read ON customers FOR SELECT
  USING (app_is_platform()
         OR id = app_customer_id()
         OR created_by_organisation_id = ANY (app_org_ids())
         OR EXISTS (SELECT 1 FROM customer_relationships cr
                     WHERE cr.customer_id = customers.id AND cr.organisation_id = ANY (app_org_ids())));
CREATE POLICY customers_insert ON customers FOR INSERT
  WITH CHECK (app_is_platform() OR created_by_organisation_id = ANY (app_org_ids()) OR (created_by_organisation_id IS NULL AND app_customer_id() IS NULL AND app_actor_kind() = 'system'));
CREATE POLICY customers_update ON customers FOR UPDATE
  USING (app_is_platform() OR id = app_customer_id()
         OR created_by_organisation_id = ANY (app_org_ids())
         OR EXISTS (SELECT 1 FROM customer_relationships cr
                     WHERE cr.customer_id = customers.id AND cr.organisation_id = ANY (app_org_ids())));

ALTER TABLE customer_addresses ENABLE ROW LEVEL SECURITY;
CREATE POLICY customer_addresses_rw ON customer_addresses
  USING (EXISTS (SELECT 1 FROM customers c WHERE c.id = customer_addresses.customer_id))
  WITH CHECK (EXISTS (SELECT 1 FROM customers c WHERE c.id = customer_addresses.customer_id));

ALTER TABLE saved_vehicles ENABLE ROW LEVEL SECURITY;
CREATE POLICY saved_vehicles_self ON saved_vehicles
  USING (app_is_platform() OR customer_id = app_customer_id()) WITH CHECK (app_is_platform() OR customer_id = app_customer_id());
ALTER TABLE saved_searches ENABLE ROW LEVEL SECURITY;
CREATE POLICY saved_searches_self ON saved_searches
  USING (app_is_platform() OR customer_id = app_customer_id()) WITH CHECK (app_is_platform() OR customer_id = app_customer_id());

-- Customer self-service read access to their own commercial records.
CREATE POLICY quotes_customer_read ON quotes FOR SELECT USING (customer_id = app_customer_id());
CREATE POLICY quote_lines_customer_read ON quote_lines FOR SELECT
  USING (EXISTS (SELECT 1 FROM quotes q WHERE q.id = quote_lines.quote_id AND q.customer_id = app_customer_id()));
CREATE POLICY sale_reservations_customer_read ON sale_reservations FOR SELECT USING (customer_id = app_customer_id());
CREATE POLICY sale_orders_customer_read ON sale_orders FOR SELECT USING (customer_id = app_customer_id());
CREATE POLICY test_drives_customer_read ON test_drive_appointments FOR SELECT USING (customer_id = app_customer_id());
CREATE POLICY rental_bookings_customer_read ON rental_bookings FOR SELECT USING (customer_id = app_customer_id());
CREATE POLICY rental_quotes_customer_read ON rental_quotes FOR SELECT USING (customer_id = app_customer_id());
CREATE POLICY payment_intents_customer_read ON payment_intents FOR SELECT USING (customer_id = app_customer_id());

-- Principals: self, platform, or members of an organisation the caller can see.
ALTER TABLE app_users ENABLE ROW LEVEL SECURITY;
CREATE POLICY app_users_read ON app_users FOR SELECT
  USING (app_is_platform() OR id = app_user_id()
         OR EXISTS (SELECT 1 FROM organisation_memberships m WHERE m.user_id = app_users.id));
CREATE POLICY app_users_write ON app_users FOR INSERT WITH CHECK (app_is_platform());
CREATE POLICY app_users_update ON app_users FOR UPDATE USING (app_is_platform() OR id = app_user_id());

ALTER TABLE admin_saved_filters ENABLE ROW LEVEL SECURITY;
CREATE POLICY admin_saved_filters_self ON admin_saved_filters
  USING (user_id = app_user_id()) WITH CHECK (user_id = app_user_id());

-- Default privileges so later migrations' tables are not accidentally world-writable.
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO autos_app, autos_readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO autos_app;

-- @@DOWN@@
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT schemaname, tablename, policyname FROM pg_policies WHERE schemaname = 'public' LOOP
    EXECUTE format('DROP POLICY %I ON %I.%I', r.policyname, r.schemaname, r.tablename);
  END LOOP;
  FOR r IN SELECT relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE n.nspname = 'public' AND c.relkind = 'r' AND c.relrowsecurity LOOP
    EXECUTE format('ALTER TABLE public.%I DISABLE ROW LEVEL SECURITY', r.relname);
  END LOOP;
END $$;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM autos_app, autos_readonly;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM autos_app;
REVOKE USAGE ON SCHEMA public FROM autos_app, autos_readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE SELECT ON TABLES FROM autos_app, autos_readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE USAGE, SELECT ON SEQUENCES FROM autos_app;
