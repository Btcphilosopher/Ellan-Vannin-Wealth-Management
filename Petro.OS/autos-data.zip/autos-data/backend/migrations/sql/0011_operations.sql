-- =====================================================================
-- AUTOS DATA — 0011 Outbox, audit, idempotency, worker health, saved filters
-- =====================================================================

CREATE TABLE outbox_events (
  id              uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id uuid NULL REFERENCES organisations(id),
  aggregate_type  text NOT NULL,
  aggregate_id    uuid NOT NULL,
  event_type      text NOT NULL CHECK (event_type ~ '^[a-z_]+\.[a-z_.]+$'),
  payload         jsonb NOT NULL CHECK (jsonb_typeof(payload) = 'object'),
  status          text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','published','dead')),
  attempts        integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  max_attempts    integer NOT NULL DEFAULT 8 CHECK (max_attempts BETWEEN 1 AND 50),
  available_at    timestamptz NOT NULL DEFAULT now(),
  last_error      text NULL,
  request_id      text NULL,
  created_at      timestamptz NOT NULL DEFAULT now(),
  published_at    timestamptz NULL,
  CHECK ((status = 'published') = (published_at IS NOT NULL)),
  CHECK (attempts <= max_attempts)
);
COMMENT ON TABLE outbox_events IS 'Transactional outbox: written in the same transaction as the domain change; a worker publishes with FOR UPDATE SKIP LOCKED, exponential backoff and a dead-letter status after max_attempts. Consumers dedupe on id.';
CREATE INDEX outbox_events_pending_idx ON outbox_events (available_at) WHERE status = 'pending';
CREATE INDEX outbox_events_aggregate_idx ON outbox_events (aggregate_type, aggregate_id, created_at);
CREATE INDEX outbox_events_dead_idx ON outbox_events (created_at) WHERE status = 'dead';

CREATE TABLE audit_events (
  id                     bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  occurred_at            timestamptz NOT NULL DEFAULT clock_timestamp(),
  request_id             text NULL,
  actor_user_id          uuid NULL REFERENCES app_users(id),
  actor_kind             text NOT NULL CHECK (actor_kind IN ('user','system','provider','import','unknown')),
  actor_organisation_id  uuid NULL REFERENCES organisations(id),
  organisation_id        uuid NULL REFERENCES organisations(id),
  action                 text NOT NULL CHECK (action ~ '^[a-z_]+\.[a-z_]+$'),
  target_type            text NOT NULL,
  target_id              text NOT NULL,
  changes                jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(changes) = 'object'),
  metadata               jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(metadata) = 'object')
);
COMMENT ON TABLE audit_events IS 'Application audit trail: actor, organisation, action, target, time, request id and redacted changes. Append-only for the application role (no UPDATE/DELETE grants + trigger). Not tamper-proof against a database superuser; see docs/SECURITY.md for stronger measures.';
COMMENT ON COLUMN audit_events.changes IS 'Redacted before/after field values. Secrets, tokens, signatures and contact details are never written here.';
CREATE INDEX audit_events_org_time_idx ON audit_events (organisation_id, occurred_at DESC);
CREATE INDEX audit_events_target_idx ON audit_events (target_type, target_id, occurred_at DESC);
CREATE INDEX audit_events_request_idx ON audit_events (request_id) WHERE request_id IS NOT NULL;
CREATE TRIGGER audit_events_append BEFORE UPDATE OR DELETE ON audit_events FOR EACH ROW EXECUTE FUNCTION trg_append_only();
CREATE TRIGGER audit_events_no_truncate BEFORE TRUNCATE ON audit_events FOR EACH STATEMENT EXECUTE FUNCTION trg_append_only();

CREATE TABLE idempotency_keys (
  id               uuid PRIMARY KEY DEFAULT uuid_v7(),
  scope            text NOT NULL,
  key              text NOT NULL CHECK (length(key) BETWEEN 8 AND 200),
  method           text NOT NULL,
  path             text NOT NULL,
  request_sha256   char(64) NOT NULL,
  response_status  integer NULL,
  response_body    jsonb NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  completed_at     timestamptz NULL,
  expires_at       timestamptz NOT NULL DEFAULT now() + interval '7 days',
  UNIQUE (scope, key)
);
COMMENT ON TABLE idempotency_keys IS 'Stored responses for Idempotency-Key requests. The row is inserted at the start of the request transaction, so a concurrent duplicate blocks on the unique index and then replays the committed response. Errors roll the key back (retry is safe).';
CREATE INDEX idempotency_keys_expiry_idx ON idempotency_keys (expires_at);

CREATE TABLE worker_heartbeats (
  worker_name   text PRIMARY KEY,
  last_beat_at  timestamptz NOT NULL DEFAULT now(),
  details       jsonb NOT NULL DEFAULT '{}'::jsonb
);
COMMENT ON TABLE worker_heartbeats IS 'Liveness of background workers, surfaced by /v1/health/ready and the admin overview.';

CREATE TABLE admin_saved_filters (
  id          uuid PRIMARY KEY DEFAULT uuid_v7(),
  user_id     uuid NOT NULL REFERENCES app_users(id),
  page        text NOT NULL CHECK (page ~ '^[a-z_-]+$'),
  name        text NOT NULL CHECK (length(name) BETWEEN 1 AND 80),
  params      jsonb NOT NULL CHECK (jsonb_typeof(params) = 'object'),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, page, name)
);
COMMENT ON TABLE admin_saved_filters IS 'Per-staff-user saved table filters in the administration UI. Deletable.';

-- @@DOWN@@
DROP TABLE IF EXISTS admin_saved_filters, worker_heartbeats, idempotency_keys, audit_events, outbox_events CASCADE;
