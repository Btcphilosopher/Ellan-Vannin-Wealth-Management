-- =====================================================================
-- AUTOS DATA — 0014 Indexes driven by measured query plans
-- (docs/PERFORMANCE.md, synthetic 200k-listing dataset)
--
-- * VIN / identifier lookup filtered by issuer in the middle column of the
--   uniqueness index -> scan of every VIN. Dedicated lookup index.
-- * Keyset pagination orders by (updated_at DESC, id DESC); without id in
--   the index the planner adds an incremental sort over the whole tenant.
-- Production note: on a live system create these with CREATE INDEX
-- CONCURRENTLY in a non-transactional migration.
-- =====================================================================
CREATE INDEX vehicle_identifiers_lookup_idx ON vehicle_identifiers (namespace, value_normalized) WHERE retired_at IS NULL;
DROP INDEX listings_org_status_idx;
CREATE INDEX listings_org_status_idx ON listings (organisation_id, status, updated_at DESC, id DESC);
CREATE INDEX listings_status_updated_idx ON listings (status, updated_at DESC, id DESC);
CREATE INDEX listings_updated_idx ON listings (updated_at DESC, id DESC);
CREATE INDEX sale_reservations_org_created_idx ON sale_reservations (organisation_id, created_at DESC, id DESC);

-- Radius search under RLS: PostGIS functions are not LEAKPROOF, so with row-
-- level security active the planner may not use ST_DWithin as a GiST index
-- condition on locations. Active locations are public directory data, so a
-- narrow SECURITY DEFINER lookup returning only ids is safe and index-backed.
CREATE FUNCTION locations_within(p_lon double precision, p_lat double precision, p_meters double precision)
RETURNS uuid[] LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, pg_temp AS $$
  SELECT COALESCE(array_agg(id ORDER BY id), '{}'::uuid[]) FROM locations
   WHERE status = 'active' AND ST_DWithin(geog, ST_SetSRID(ST_MakePoint(p_lon, p_lat), 4326)::geography, p_meters)
$$;
COMMENT ON FUNCTION locations_within(double precision, double precision, double precision) IS 'Ids of active locations within p_meters of a WGS84 point (GiST-indexed; bypasses RLS because active locations are public).';

-- @@DOWN@@
DROP FUNCTION IF EXISTS locations_within(double precision, double precision, double precision);
DROP INDEX IF EXISTS sale_reservations_org_created_idx;
DROP INDEX IF EXISTS listings_status_updated_idx;
DROP INDEX IF EXISTS listings_updated_idx;
DROP INDEX IF EXISTS listings_org_status_idx;
CREATE INDEX listings_org_status_idx ON listings (organisation_id, status, updated_at DESC);
DROP INDEX IF EXISTS vehicle_identifiers_lookup_idx;
