-- =====================================================================
-- AUTOS DATA — 0009 Payments, refunds, reconciliation
--
-- No card data is ever stored: the provider holds instruments; we hold
-- provider references, expected amounts and verified outcomes.
-- payment_transactions is a record of confirmed money movements. It is
-- NOT a general ledger (no double-entry postings are implemented).
-- =====================================================================

CREATE TABLE payment_intents (
  id                     uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id        uuid NOT NULL REFERENCES organisations(id),
  provider               text NOT NULL CHECK (provider ~ '^[a-z][a-z0-9_]{1,31}$'),
  provider_intent_ref    text NULL,
  purpose                text NOT NULL CHECK (purpose IN ('sale_deposit','sale_balance','rental_prepayment')),
  sale_reservation_id    uuid NULL,
  sale_order_id          uuid NULL,
  rental_booking_id      uuid NULL,
  customer_id            uuid NOT NULL REFERENCES customers(id),
  amount_minor           bigint NOT NULL CHECK (amount_minor > 0),
  currency               char(3) NOT NULL REFERENCES currencies(code),
  status                 text NOT NULL DEFAULT 'created'
                           CHECK (status IN ('created','processing','requires_action','succeeded','failed','canceled','unknown')),
  last_provider_event_at timestamptz NULL,
  failure_code           text NULL,
  idempotency_key        text NOT NULL CHECK (length(idempotency_key) BETWEEN 8 AND 200),
  request_sha256         char(64) NOT NULL,
  created_by             uuid NULL REFERENCES app_users(id),
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),
  version                integer NOT NULL DEFAULT 1,
  FOREIGN KEY (sale_reservation_id, organisation_id) REFERENCES sale_reservations(id, organisation_id),
  FOREIGN KEY (sale_order_id, organisation_id) REFERENCES sale_orders(id, organisation_id),
  FOREIGN KEY (rental_booking_id, organisation_id) REFERENCES rental_bookings(id, organisation_id),
  UNIQUE (provider, provider_intent_ref),
  UNIQUE (organisation_id, idempotency_key),
  UNIQUE (id, organisation_id),
  CHECK (num_nonnulls(sale_reservation_id, sale_order_id, rental_booking_id) = 1),
  CHECK (purpose <> 'sale_deposit' OR sale_reservation_id IS NOT NULL),
  CHECK (purpose <> 'sale_balance' OR sale_order_id IS NOT NULL),
  CHECK (purpose <> 'rental_prepayment' OR rental_booking_id IS NOT NULL)
);
COMMENT ON TABLE payment_intents IS 'Expected payments. Created idempotently (organisation_id, idempotency_key). Status follows verified provider events; it never by itself advances a reservation or sale.';
COMMENT ON COLUMN payment_intents.status IS 'unknown = the provider call outcome could not be determined (timeout); resolved by the reconciliation worker.';
CREATE INDEX payment_intents_org_created_idx ON payment_intents (organisation_id, created_at DESC);
CREATE INDEX payment_intents_reservation_idx ON payment_intents (sale_reservation_id) WHERE sale_reservation_id IS NOT NULL;
CREATE INDEX payment_intents_unknown_idx ON payment_intents (updated_at) WHERE status IN ('unknown','processing','created');
CREATE TRIGGER payment_intents_touch BEFORE UPDATE ON payment_intents FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER payment_intents_no_delete BEFORE DELETE ON payment_intents FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();

CREATE FUNCTION trg_payment_intent_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF (NEW.organisation_id, NEW.provider, NEW.purpose, NEW.sale_reservation_id, NEW.sale_order_id, NEW.rental_booking_id,
      NEW.customer_id, NEW.amount_minor, NEW.currency, NEW.idempotency_key, NEW.request_sha256, NEW.created_at)
     IS DISTINCT FROM
     (OLD.organisation_id, OLD.provider, OLD.purpose, OLD.sale_reservation_id, OLD.sale_order_id, OLD.rental_booking_id,
      OLD.customer_id, OLD.amount_minor, OLD.currency, OLD.idempotency_key, OLD.request_sha256, OLD.created_at) THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: payment intent terms cannot change';
  END IF;
  IF OLD.provider_intent_ref IS NOT NULL AND NEW.provider_intent_ref IS DISTINCT FROM OLD.provider_intent_ref THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: provider reference is fixed once assigned';
  END IF;
  -- Terminal states are final; out-of-order or replayed events cannot regress them.
  IF OLD.status IN ('succeeded','failed','canceled') AND NEW.status IS DISTINCT FROM OLD.status THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: payment intent %s is final', OLD.status);
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER payment_intents_guard BEFORE UPDATE ON payment_intents FOR EACH ROW EXECUTE FUNCTION trg_payment_intent_guard();

CREATE TABLE payment_events (
  id                   uuid PRIMARY KEY DEFAULT uuid_v7(),
  provider             text NOT NULL,
  provider_event_id    text NOT NULL,
  event_type           text NOT NULL,
  provider_created_at  timestamptz NOT NULL,
  received_at          timestamptz NOT NULL DEFAULT now(),
  signature_verified   boolean NOT NULL CHECK (signature_verified),
  organisation_id      uuid NULL REFERENCES organisations(id),
  payment_intent_id    uuid NULL REFERENCES payment_intents(id),
  refund_id            uuid NULL,
  payload              jsonb NOT NULL CHECK (jsonb_typeof(payload) = 'object'),
  payload_sha256       char(64) NOT NULL,
  processing_status    text NOT NULL DEFAULT 'received'
                         CHECK (processing_status IN ('received','applied','ignored_out_of_order','ignored_no_effect','unmatched','failed')),
  processing_note      text NULL,
  processed_at         timestamptz NULL,
  UNIQUE (provider, provider_event_id)
);
COMMENT ON TABLE payment_events IS 'Verified provider webhook events, stored once per (provider, provider_event_id): duplicates are detected by the unique key and never re-applied. Payload is the provider JSON minus anything sensitive. Only processing_* columns may change.';
CREATE INDEX payment_events_intent_idx ON payment_events (payment_intent_id, provider_created_at);
CREATE INDEX payment_events_status_idx ON payment_events (processing_status, received_at) WHERE processing_status IN ('received','unmatched','failed');

CREATE FUNCTION trg_payment_events_guard() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9010', MESSAGE = 'append_only: payment_events cannot be deleted';
  END IF;
  IF (NEW.provider, NEW.provider_event_id, NEW.event_type, NEW.provider_created_at, NEW.received_at, NEW.payload, NEW.payload_sha256)
     IS DISTINCT FROM (OLD.provider, OLD.provider_event_id, OLD.event_type, OLD.provider_created_at, OLD.received_at, OLD.payload, OLD.payload_sha256) THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: provider event content cannot change';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER payment_events_guard BEFORE UPDATE OR DELETE ON payment_events FOR EACH ROW EXECUTE FUNCTION trg_payment_events_guard();

CREATE TABLE payment_transactions (
  id                        uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id           uuid NOT NULL REFERENCES organisations(id),
  payment_intent_id         uuid NOT NULL,
  kind                      text NOT NULL CHECK (kind IN ('capture','refund','chargeback')),
  amount_minor              bigint NOT NULL CHECK (amount_minor > 0),
  currency                  char(3) NOT NULL REFERENCES currencies(code),
  provider                  text NOT NULL,
  provider_transaction_ref  text NOT NULL,
  refund_id                 uuid NULL,
  source_event_id           uuid NULL REFERENCES payment_events(id),
  occurred_at               timestamptz NOT NULL,
  recorded_at               timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY (payment_intent_id, organisation_id) REFERENCES payment_intents(id, organisation_id),
  UNIQUE (provider, provider_transaction_ref),
  UNIQUE (id, organisation_id),
  CHECK ((kind = 'refund') = (refund_id IS NOT NULL))
);
COMMENT ON TABLE payment_transactions IS 'Append-only record of confirmed captures, refunds and chargebacks, one row per provider transaction reference. Not a double-entry ledger.';
CREATE INDEX payment_transactions_intent_idx ON payment_transactions (payment_intent_id);
CREATE TRIGGER payment_transactions_append BEFORE UPDATE OR DELETE ON payment_transactions FOR EACH ROW EXECUTE FUNCTION trg_append_only();

CREATE SEQUENCE reconciliation_case_number_seq;

CREATE TABLE refunds (
  id                       uuid PRIMARY KEY DEFAULT uuid_v7(),
  organisation_id          uuid NOT NULL REFERENCES organisations(id),
  payment_intent_id        uuid NOT NULL,
  capture_transaction_id   uuid NOT NULL,
  amount_minor             bigint NOT NULL CHECK (amount_minor > 0),
  currency                 char(3) NOT NULL REFERENCES currencies(code),
  reason                   text NOT NULL CHECK (reason IN ('customer_request','hold_expired_before_payment','duplicate_payment','sale_cancelled','goodwill','reconciliation')),
  status                   text NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','pending','succeeded','failed','canceled')),
  provider                 text NOT NULL,
  provider_refund_ref      text NULL,
  reconciliation_case_id   uuid NULL,
  idempotency_key          text NOT NULL,
  failure_code             text NULL,
  requested_by             uuid NULL REFERENCES app_users(id),
  requested_at             timestamptz NOT NULL DEFAULT now(),
  completed_at             timestamptz NULL,
  updated_at               timestamptz NOT NULL DEFAULT now(),
  version                  integer NOT NULL DEFAULT 1,
  FOREIGN KEY (payment_intent_id, organisation_id) REFERENCES payment_intents(id, organisation_id),
  FOREIGN KEY (capture_transaction_id, organisation_id) REFERENCES payment_transactions(id, organisation_id),
  UNIQUE (provider, provider_refund_ref),
  UNIQUE (organisation_id, idempotency_key),
  UNIQUE (id, organisation_id),
  CHECK ((status IN ('succeeded','failed','canceled')) = (completed_at IS NOT NULL))
);
COMMENT ON TABLE refunds IS 'Full or partial refunds against a capture. The sum of non-failed refunds can never exceed the captured amount (enforced under a row lock on the capture).';
CREATE INDEX refunds_intent_idx ON refunds (payment_intent_id);
CREATE TRIGGER refunds_touch BEFORE UPDATE ON refunds FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER refunds_no_delete BEFORE DELETE ON refunds FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();
ALTER TABLE payment_transactions ADD CONSTRAINT payment_transactions_refund_fk FOREIGN KEY (refund_id) REFERENCES refunds(id);
ALTER TABLE payment_events ADD CONSTRAINT payment_events_refund_fk FOREIGN KEY (refund_id) REFERENCES refunds(id);

CREATE FUNCTION trg_refund_limit() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE
  cap payment_transactions%ROWTYPE;
  committed bigint;
BEGIN
  IF TG_OP = 'UPDATE' THEN
    IF (NEW.amount_minor, NEW.currency, NEW.capture_transaction_id, NEW.payment_intent_id, NEW.organisation_id, NEW.idempotency_key)
       IS DISTINCT FROM (OLD.amount_minor, OLD.currency, OLD.capture_transaction_id, OLD.payment_intent_id, OLD.organisation_id, OLD.idempotency_key) THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9003', MESSAGE = 'immutable_record: refund amount and target cannot change';
    END IF;
    IF OLD.status IN ('succeeded','failed','canceled') AND NEW.status IS DISTINCT FROM OLD.status THEN
      RAISE EXCEPTION USING ERRCODE = 'Z9002', MESSAGE = format('invalid_status_transition: refund %s is final', OLD.status);
    END IF;
    IF NEW.status IN ('succeeded','failed','canceled') AND NEW.completed_at IS NULL THEN NEW.completed_at := now(); END IF;
    RETURN NEW;
  END IF;
  -- Serialise refunds per capture.
  SELECT * INTO cap FROM payment_transactions WHERE id = NEW.capture_transaction_id FOR NO KEY UPDATE;
  IF cap.kind <> 'capture' THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9007', MESSAGE = 'refund_limit_exceeded: refunds must target a capture transaction';
  END IF;
  IF cap.currency <> NEW.currency OR cap.payment_intent_id <> NEW.payment_intent_id THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9007', MESSAGE = 'refund_limit_exceeded: refund currency/intent must match the capture';
  END IF;
  SELECT COALESCE(sum(amount_minor), 0) INTO committed
    FROM refunds WHERE capture_transaction_id = cap.id AND status IN ('requested','pending','succeeded');
  IF committed + NEW.amount_minor > cap.amount_minor THEN
    RAISE EXCEPTION USING ERRCODE = 'Z9007',
      MESSAGE = format('refund_limit_exceeded: requested %s + already refunded/pending %s exceeds captured %s', NEW.amount_minor, committed, cap.amount_minor);
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER refunds_limit BEFORE INSERT OR UPDATE ON refunds FOR EACH ROW EXECUTE FUNCTION trg_refund_limit();

CREATE TABLE reconciliation_cases (
  id                      uuid PRIMARY KEY DEFAULT uuid_v7(),
  case_number             text NOT NULL UNIQUE
                            DEFAULT ('RC-' || to_char(now() AT TIME ZONE 'UTC', 'YYYY') || '-' || lpad(nextval('reconciliation_case_number_seq')::text, 6, '0')),
  organisation_id         uuid NOT NULL REFERENCES organisations(id),
  case_type               text NOT NULL CHECK (case_type IN ('payment_after_hold_expiry','deposit_on_lapsed_hold','amount_mismatch',
                                                             'unknown_payment_outcome','orphan_provider_event','refund_outcome_mismatch','duplicate_capture')),
  status                  text NOT NULL DEFAULT 'open' CHECK (status IN ('open','investigating','awaiting_provider','resolved','written_off')),
  severity                text NOT NULL DEFAULT 'medium' CHECK (severity IN ('low','medium','high')),
  payment_intent_id       uuid NULL REFERENCES payment_intents(id),
  payment_transaction_id  uuid NULL REFERENCES payment_transactions(id),
  payment_event_id        uuid NULL REFERENCES payment_events(id),
  refund_id               uuid NULL REFERENCES refunds(id),
  sale_reservation_id     uuid NULL REFERENCES sale_reservations(id),
  rental_booking_id       uuid NULL REFERENCES rental_bookings(id),
  expected_amount_minor   bigint NULL,
  observed_amount_minor   bigint NULL,
  currency                char(3) NULL REFERENCES currencies(code),
  summary                 text NOT NULL,
  details                 jsonb NOT NULL DEFAULT '{}'::jsonb,
  resolution              text NULL CHECK (resolution IN ('refunded','applied_to_new_reservation','provider_confirmed','manual_adjustment','no_action')),
  resolution_note         text NULL,
  opened_at               timestamptz NOT NULL DEFAULT now(),
  resolved_at             timestamptz NULL,
  resolved_by             uuid NULL REFERENCES app_users(id),
  updated_at              timestamptz NOT NULL DEFAULT now(),
  version                 integer NOT NULL DEFAULT 1,
  CHECK ((status IN ('resolved','written_off')) = (resolved_at IS NOT NULL AND resolution IS NOT NULL)),
  CHECK ((expected_amount_minor IS NULL AND observed_amount_minor IS NULL) OR currency IS NOT NULL)
);
COMMENT ON TABLE reconciliation_cases IS 'Investigation queue for money that does not line up with operational state (late settlement, unknown outcomes, mismatches). Resolved by staff or automatically when a linked refund settles.';
CREATE UNIQUE INDEX reconciliation_cases_open_uq ON reconciliation_cases (case_type, payment_intent_id)
  WHERE status NOT IN ('resolved','written_off') AND payment_intent_id IS NOT NULL;
CREATE INDEX reconciliation_cases_org_status_idx ON reconciliation_cases (organisation_id, status, opened_at DESC);
CREATE TRIGGER reconciliation_cases_touch BEFORE UPDATE ON reconciliation_cases FOR EACH ROW EXECUTE FUNCTION trg_touch_row();
CREATE TRIGGER reconciliation_cases_no_delete BEFORE DELETE ON reconciliation_cases FOR EACH ROW EXECUTE FUNCTION trg_forbid_delete();
ALTER TABLE refunds ADD CONSTRAINT refunds_case_fk FOREIGN KEY (reconciliation_case_id) REFERENCES reconciliation_cases(id);

-- @@DOWN@@
ALTER TABLE IF EXISTS refunds DROP CONSTRAINT IF EXISTS refunds_case_fk;
DROP TABLE IF EXISTS reconciliation_cases, refunds, payment_transactions, payment_events, payment_intents CASCADE;
DROP SEQUENCE IF EXISTS reconciliation_case_number_seq;
DROP FUNCTION IF EXISTS trg_refund_limit(), trg_payment_events_guard(), trg_payment_intent_guard();
