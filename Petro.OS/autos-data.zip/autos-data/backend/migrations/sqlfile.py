"""Execute a migrations/sql/NNNN_*.sql file (upgrade or downgrade half)."""
from pathlib import Path

from alembic import op

SQL_DIR = Path(__file__).resolve().parent / "sql"
MARKER = "-- @@DOWN@@"


def _split(name: str) -> tuple[str, str]:
    text = (SQL_DIR / name).read_text(encoding="utf-8")
    if MARKER not in text:
        raise RuntimeError(f"{name} has no {MARKER} section")
    up, down = text.split(MARKER, 1)
    return up, down


def _execute(sql: str) -> None:
    # Use the raw DBAPI cursor: no SQLAlchemy bind-parameter parsing and no
    # psycopg %-placeholder parsing (no parameters are passed), so the file
    # runs exactly as written, inside Alembic's migration transaction.
    bind = op.get_bind()
    dbapi_conn = bind.connection.dbapi_connection
    with dbapi_conn.cursor() as cur:
        cur.execute(sql)


def upgrade_file(name: str) -> None:
    _execute(_split(name)[0])


def downgrade_file(name: str) -> None:
    _execute(_split(name)[1])
