"""Alembic environment.

Schema changes are authored as plain, reviewable SQL files in
migrations/sql/ and applied by thin Alembic revisions (see
migrations/sqlfile.py). Alembic owns ordering, the version table and
up/down execution; PostgreSQL owns the constraints and triggers.
"""
import os

from alembic import context
from sqlalchemy import create_engine, pool

config = context.config


def _url() -> str:
    url = os.environ.get("AUTOS_MIGRATION_DATABASE_URL") or config.get_main_option("sqlalchemy.url")
    if not url:
        raise RuntimeError("Set AUTOS_MIGRATION_DATABASE_URL (owner role) to run migrations")
    return url


def run_migrations_offline() -> None:
    context.configure(url=_url(), literal_binds=True, transaction_per_migration=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    engine = create_engine(_url(), poolclass=pool.NullPool)
    with engine.connect() as connection:
        context.configure(connection=connection, transaction_per_migration=True)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
