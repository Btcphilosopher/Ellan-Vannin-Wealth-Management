"""0003 listings

Applies migrations/sql/0003_listings.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0003"
down_revision = 'r0002'
branch_labels = None
depends_on = None

SQL_FILE = "0003_listings.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
