"""0011 operations

Applies migrations/sql/0011_operations.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0011"
down_revision = 'r0010'
branch_labels = None
depends_on = None

SQL_FILE = "0011_operations.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
