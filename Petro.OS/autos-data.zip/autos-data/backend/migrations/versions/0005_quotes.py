"""0005 quotes

Applies migrations/sql/0005_quotes.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0005"
down_revision = 'r0004'
branch_labels = None
depends_on = None

SQL_FILE = "0005_quotes.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
