"""0006 sales

Applies migrations/sql/0006_sales.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0006"
down_revision = 'r0005'
branch_labels = None
depends_on = None

SQL_FILE = "0006_sales.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
