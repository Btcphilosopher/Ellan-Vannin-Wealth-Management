"""0010 imports

Applies migrations/sql/0010_imports.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0010"
down_revision = 'r0009'
branch_labels = None
depends_on = None

SQL_FILE = "0010_imports.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
