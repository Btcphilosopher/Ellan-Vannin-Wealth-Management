"""0008 rentals

Applies migrations/sql/0008_rentals.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0008"
down_revision = 'r0007'
branch_labels = None
depends_on = None

SQL_FILE = "0008_rentals.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
