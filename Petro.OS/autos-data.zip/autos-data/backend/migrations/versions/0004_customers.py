"""0004 customers

Applies migrations/sql/0004_customers.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0004"
down_revision = 'r0003'
branch_labels = None
depends_on = None

SQL_FILE = "0004_customers.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
