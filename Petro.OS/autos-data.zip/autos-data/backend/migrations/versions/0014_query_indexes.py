"""0014 query indexes

Applies migrations/sql/0014_query_indexes.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0014"
down_revision = 'r0013'
branch_labels = None
depends_on = None

SQL_FILE = "0014_query_indexes.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
