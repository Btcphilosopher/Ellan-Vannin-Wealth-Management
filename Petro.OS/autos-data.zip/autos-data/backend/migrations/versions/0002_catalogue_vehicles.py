"""0002 catalogue vehicles

Applies migrations/sql/0002_catalogue_vehicles.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0002"
down_revision = 'r0001'
branch_labels = None
depends_on = None

SQL_FILE = "0002_catalogue_vehicles.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
