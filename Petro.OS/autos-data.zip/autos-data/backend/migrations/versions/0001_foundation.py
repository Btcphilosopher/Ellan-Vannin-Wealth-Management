"""0001 foundation

Applies migrations/sql/0001_foundation.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0001"
down_revision = None
branch_labels = None
depends_on = None

SQL_FILE = "0001_foundation.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
