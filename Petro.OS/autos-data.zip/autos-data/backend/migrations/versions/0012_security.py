"""0012 security

Applies migrations/sql/0012_security.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0012"
down_revision = 'r0011'
branch_labels = None
depends_on = None

SQL_FILE = "0012_security.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
