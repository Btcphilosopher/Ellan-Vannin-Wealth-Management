"""0007 test drives

Applies migrations/sql/0007_test_drives.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0007"
down_revision = 'r0006'
branch_labels = None
depends_on = None

SQL_FILE = "0007_test_drives.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
