"""0009 payments

Applies migrations/sql/0009_payments.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0009"
down_revision = 'r0008'
branch_labels = None
depends_on = None

SQL_FILE = "0009_payments.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
