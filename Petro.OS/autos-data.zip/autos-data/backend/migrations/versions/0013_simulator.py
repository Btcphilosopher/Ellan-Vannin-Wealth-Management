"""0013 simulator

Applies migrations/sql/0013_simulator.sql
"""
from migrations.sqlfile import downgrade_file, upgrade_file

revision = "r0013"
down_revision = 'r0012'
branch_labels = None
depends_on = None

SQL_FILE = "0013_simulator.sql"


def upgrade() -> None:
    upgrade_file(SQL_FILE)


def downgrade() -> None:
    downgrade_file(SQL_FILE)
