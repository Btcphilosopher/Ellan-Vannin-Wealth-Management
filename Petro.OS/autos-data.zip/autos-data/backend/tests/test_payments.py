"""Idempotent payments, verified + deduplicated + ordered events, late settlement, refunds, reconciliation."""
import datetime as dt
import json
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from sqlalchemy import text

from app import simulator
from app.db import DbContext, apply_context, new_session
from app.services import payments as P


def pay_deposit(api, reservation_id, key=None, **extra):
    return api.post("/v1/payments", json={"purpose": "sale_deposit", "sale_reservation_id": reservation_id, **extra},
                    key=key or uuid.uuid4().hex)


def settle(ref, outcome="succeeded", amount=None, created_at=None):
    s = new_session()
    apply_context(s, DbContext.system())
    ev = simulator.settle_payment(s, ref, outcome, amount_minor=amount, created_at=created_at)
    s.commit()
    s.close()
    return ev


def deliver(client, ev, signature=None):
    body, h = simulator.signed_delivery(ev)
    if signature is not None:
        h["SimPay-Signature"] = signature
    return client.post("/v1/providers/simpay/events", content=body, headers=h)


def test_payment_creation_is_idempotent(as_user, factory, ids):
    api = as_user("admin@harbourview.example")
    lst = factory.listing()
    r = factory.reserve(lst["id"], ids["customers"][0]).json()
    key = "pay-" + uuid.uuid4().hex
    a = pay_deposit(api, r["id"], key)
    b = pay_deposit(api, r["id"], key)
    assert a.status_code == 201 and b.status_code == 200 and a.json()["id"] == b.json()["id"]
    assert b.headers.get("Idempotent-Replayed") == "true"
    c = api.post("/v1/payments", json={"purpose": "sale_deposit", "sale_reservation_id": r["id"], "amount_minor": 1}, key=key)
    assert c.status_code == 422 and c.json()["code"] == "idempotency_key_reused"
    assert api.post("/v1/payments", json={"purpose": "sale_deposit", "sale_reservation_id": r["id"]}).status_code == 422


def test_concurrent_identical_payment_requests_create_one_intent(as_user, factory, ids, owner_engine):
    api = as_user("admin@harbourview.example")
    r = factory.reserve(factory.listing()["id"], ids["customers"][1]).json()
    key = "pay-" + uuid.uuid4().hex
    barrier = threading.Barrier(6)

    def go(_):
        barrier.wait()
        return pay_deposit(api, r["id"], key).json().get("id")

    with ThreadPoolExecutor(6) as ex:
        idset = set(ex.map(go, range(6)))
    assert len(idset) == 1
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT count(*) FROM payment_intents WHERE idempotency_key = :k"), {"k": key}).scalar() == 1
        assert c.execute(text("SELECT count(*) FROM simpay.payments WHERE merchant_ref = :m"), {"m": next(iter(idset))}).scalar() == 1


def test_unsigned_or_forged_events_are_rejected_and_not_stored(client, as_user, factory, ids, owner_engine):
    api = as_user("admin@harbourview.example")
    r = factory.reserve(factory.listing()["id"], ids["customers"][2]).json()
    intent = pay_deposit(api, r["id"]).json()
    ev = settle(intent["provider_intent_ref"])
    assert deliver(client, ev, signature="t=1,v1=deadbeef").status_code == 401
    old = simulator.sign(json.dumps(ev, separators=(",", ":")).encode(), timestamp=int(time.time()) - 3600)
    assert deliver(client, ev, signature=old).status_code == 401  # replay outside tolerance
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT count(*) FROM payment_events WHERE provider_event_id = :e"), {"e": ev["id"]}).scalar() == 0


def test_duplicate_event_processed_once(client, as_user, factory, ids, owner_engine):
    api = as_user("admin@harbourview.example")
    r = factory.reserve(factory.listing()["id"], ids["customers"][3]).json()
    intent = pay_deposit(api, r["id"]).json()
    ev = settle(intent["provider_intent_ref"])
    results = [deliver(client, ev).json()["result"] for _ in range(3)]
    assert results == ["applied", "duplicate", "duplicate"]
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT count(*) FROM payment_events WHERE provider_event_id = :e"), {"e": ev["id"]}).scalar() == 1
        assert c.execute(text("SELECT count(*) FROM payment_transactions WHERE payment_intent_id = :i"), {"i": intent["id"]}).scalar() == 1
        hold = c.execute(text("SELECT hold_expires_at - created_at FROM sale_reservations WHERE id = :r"), {"r": r["id"]}).scalar()
    assert hold > dt.timedelta(hours=71)  # deposit extended the hold once (72h policy)


def test_concurrent_duplicate_deliveries(client, as_user, factory, ids, owner_engine):
    api = as_user("admin@harbourview.example")
    r = factory.reserve(factory.listing()["id"], ids["customers"][4]).json()
    intent = pay_deposit(api, r["id"]).json()
    ev = settle(intent["provider_intent_ref"])
    barrier = threading.Barrier(8)

    def go(_):
        barrier.wait()
        return deliver(client, ev).json()["result"]

    with ThreadPoolExecutor(8) as ex:
        res = list(ex.map(go, range(8)))
    assert res.count("applied") == 1 and res.count("duplicate") == 7
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT count(*) FROM payment_transactions WHERE payment_intent_id = :i"), {"i": intent["id"]}).scalar() == 1


def test_out_of_order_events(client, as_user, factory, ids):
    api = as_user("admin@harbourview.example")
    r = factory.reserve(factory.listing()["id"], ids["customers"][5]).json()
    intent = pay_deposit(api, r["id"]).json()
    ref = intent["provider_intent_ref"]
    s = new_session(); apply_context(s, DbContext.system())
    older = simulator.processing_event(s, ref, created_at=dt.datetime.now(dt.timezone.utc) - dt.timedelta(minutes=5))
    s.commit(); s.close()
    assert deliver(client, settle(ref)).json()["result"] == "applied"
    assert deliver(client, older).json()["result"] == "ignored_out_of_order"
    got = api.get(f"/v1/payments/{intent['id']}").json()
    assert got["status"] == "succeeded"
    assert {e["processing_status"] for e in got["events"]} == {"applied", "ignored_out_of_order"}


def test_settlement_after_hold_expiry_opens_case_and_never_seizes(client, as_user, factory, ids, owner_engine):
    api = as_user("admin@harbourview.example")
    with owner_engine.begin() as c:
        c.execute(text("UPDATE organisations SET sale_hold_duration = interval '2 seconds' WHERE id = :o"), {"o": ids["hv"]})
    try:
        lst = factory.listing()
        first = factory.reserve(lst["id"], ids["customers"][6]).json()
        intent = pay_deposit(api, first["id"]).json()
        time.sleep(2.3)
        second = factory.reserve(lst["id"], ids["customers"][7]).json()  # another customer takes the vehicle
    finally:
        with owner_engine.begin() as c:
            c.execute(text("UPDATE organisations SET sale_hold_duration = interval '30 minutes' WHERE id = :o"), {"o": ids["hv"]})
    res = deliver(client, settle(intent["provider_intent_ref"])).json()
    assert res["result"] == "applied" and "RC-" in res["note"]
    cases = api.get(f"/v1/payments/{intent['id']}").json()["cases"]
    assert [c["case_type"] for c in cases] == ["payment_after_hold_expiry"]
    assert cases[0]["details"]["current_holder"] == second["reservation_number"]
    got2 = api.get(f"/v1/sale-reservations/{second['id']}").json()
    assert got2["status"] == "held" and got2["customer_id"] == str(ids["customers"][7])
    got1 = api.get(f"/v1/sale-reservations/{first['id']}").json()
    assert got1["status"] == "expired" and got1["deposit_status"] == "awaiting"


def test_partial_refunds_and_limit(client, as_user, factory, ids):
    api = as_user("admin@harbourview.example")
    r = factory.reserve(factory.listing(deposit=100000)["id"], ids["customers"][8]).json()
    intent = pay_deposit(api, r["id"]).json()
    deliver(client, settle(intent["provider_intent_ref"]))
    a = api.post("/v1/refunds", json={"payment_intent_id": intent["id"], "amount_minor": 30000}, key=uuid.uuid4().hex)
    b = api.post("/v1/refunds", json={"payment_intent_id": intent["id"], "amount_minor": 50000}, key=uuid.uuid4().hex)
    c = api.post("/v1/refunds", json={"payment_intent_id": intent["id"], "amount_minor": 20001}, key=uuid.uuid4().hex)
    assert a.status_code == 201 and b.status_code == 201
    assert c.status_code == 422 and c.json()["code"] == "refund_limit_exceeded"
    d = api.post("/v1/refunds", json={"payment_intent_id": intent["id"]}, key=uuid.uuid4().hex)  # remaining 200.00
    assert d.status_code == 201 and d.json()["amount_minor"] == 20000


def test_concurrent_refunds_never_exceed_capture(client, as_user, factory, ids, owner_engine):
    api = as_user("admin@harbourview.example")
    r = factory.reserve(factory.listing(deposit=100000)["id"], ids["customers"][9]).json()
    intent = pay_deposit(api, r["id"]).json()
    deliver(client, settle(intent["provider_intent_ref"]))
    barrier = threading.Barrier(10)

    def go(_):
        barrier.wait()
        return api.post("/v1/refunds", json={"payment_intent_id": intent["id"], "amount_minor": 30000}, key=uuid.uuid4().hex).status_code

    with ThreadPoolExecutor(10) as ex:
        codes = list(ex.map(go, range(10)))
    assert codes.count(201) == 3 and codes.count(422) == 7, codes
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT sum(amount_minor) FROM refunds WHERE payment_intent_id = :i"), {"i": intent["id"]}).scalar() == 90000


def test_refund_reconciles_late_payment_case(client, as_user, factory, ids, owner_engine):
    hv_fin = as_user("finance@harbourview.example")
    api = as_user("admin@harbourview.example")
    with owner_engine.begin() as c:
        c.execute(text("UPDATE organisations SET sale_hold_duration = interval '2 seconds' WHERE id = :o"), {"o": ids["hv"]})
    try:
        r = factory.reserve(factory.listing()["id"], ids["customers"][10]).json()
        intent = pay_deposit(api, r["id"]).json()
        time.sleep(2.3)
    finally:
        with owner_engine.begin() as c:
            c.execute(text("UPDATE organisations SET sale_hold_duration = interval '30 minutes' WHERE id = :o"), {"o": ids["hv"]})
    deliver(client, settle(intent["provider_intent_ref"]))
    case = api.get(f"/v1/payments/{intent['id']}").json()["cases"][0]
    bad = hv_fin.post(f"/v1/reconciliation-cases/{case['id']}/resolution", json={"resolution": "refunded"}, version=case["version"])
    assert bad.status_code == 422 and bad.json()["code"] == "refund_not_settled"
    ref = hv_fin.post("/v1/refunds", json={"payment_intent_id": intent["id"], "reason": "hold_expired_before_payment",
                                           "reconciliation_case_id": case["id"]}, key=uuid.uuid4().hex).json()
    assert ref["status"] == "pending"
    assert hv_fin.get(f"/v1/reconciliation-cases/{case['id']}").json()["status"] == "awaiting_provider"
    s = new_session(); apply_context(s, DbContext.system())
    ev = simulator.settle_refund(s, ref["provider_refund_ref"]); s.commit(); s.close()
    assert deliver(client, ev).json()["result"] == "applied"
    case = hv_fin.get(f"/v1/reconciliation-cases/{case['id']}").json()
    assert case["status"] == "resolved" and case["resolution"] == "refunded"
    detail = api.get(f"/v1/payments/{intent['id']}").json()
    assert sorted(t["kind"] for t in detail["transactions"]) == ["capture", "refund"]
    assert api.get(f"/v1/sale-reservations/{r['id']}").json()["deposit_status"] == "refunded"


def test_unknown_outcome_is_reconciled_by_worker(client, as_user, factory, ids, owner_engine):
    api = as_user("admin@harbourview.example")
    r = factory.reserve(factory.listing()["id"], ids["customers"][11]).json()
    intent = pay_deposit(api, r["id"], simulate_provider_timeout=True).json()
    assert intent["status"] == "unknown" and intent["provider_intent_ref"] is None
    with owner_engine.begin() as c:  # provider actually charged the card
        ref = c.execute(text("SELECT ref FROM simpay.payments WHERE idempotency_key = :k"), {"k": intent["id"]}).scalar()
        c.execute(text("UPDATE simpay.payments SET status = 'succeeded', captured_minor = amount_minor, updated_at = now() WHERE ref = :r"), {"r": ref})
    s = new_session()
    stats = P.reconcile_unknown(s, older_than_seconds=0)
    s.close()
    assert stats["resolved"] >= 1
    got = api.get(f"/v1/payments/{intent['id']}").json()
    assert got["status"] == "succeeded" and got["provider_intent_ref"] == ref and len(got["transactions"]) == 1
    assert api.get(f"/v1/sale-reservations/{r['id']}").json()["deposit_status"] == "paid"


def test_no_card_data_columns_exist(owner_engine):
    with owner_engine.connect() as c:
        cols = c.execute(text("""SELECT table_name || '.' || column_name FROM information_schema.columns
                                 WHERE table_schema IN ('public','simpay') AND column_name ~* '(card|pan|cvv|cvc|expiry_month|track)'""")).scalars().all()
    assert cols == []


def test_duplicate_deliveries_are_visible_in_audit(client, as_user, factory, ids):
    api = as_user("admin@harbourview.example")
    r = factory.reserve(factory.listing()["id"], ids["customers"][12]).json()
    intent = pay_deposit(api, r["id"]).json()
    ev = settle(intent["provider_intent_ref"])
    for _ in range(3):
        deliver(client, ev)
    a = api.get("/v1/audit-events", params={"target_type": "payment_intent", "target_id": intent["id"],
                                            "action": "payment.duplicate_event_ignored"}).json()["items"]
    assert len(a) == 2 and a[0]["metadata"]["provider_event_id"] == ev["id"] and a[0]["metadata"]["differs_from_stored"] is False
