"""Dealer/customer access boundaries: API authorisation + PostgreSQL RLS + pooled-connection hygiene."""
import uuid

from sqlalchemy import create_engine, text

from app.db import DbContext, apply_context
from tests.conftest import APP_URL


def test_cross_dealer_api_access_is_denied(as_user, factory, ids):
    draft = factory.listing(publish=False)  # Harbourview draft
    rl = as_user("admin@ridgeline.example")
    assert rl.get(f"/v1/listings/{draft['id']}").status_code == 404
    assert rl.get(f"/v1/vehicles/{draft['vehicle']['id']}").status_code == 404
    r = rl.patch(f"/v1/vehicles/{draft['vehicle']['id']}", json={"exterior_colour": "Hacked"}, version=1)
    assert r.status_code == 404
    r = rl.post(f"/v1/listings/{draft['id']}/publish", json={}, version=draft["version"])
    assert r.status_code == 404
    # Harbourview's own staff see it
    assert as_user("sales@harbourview.example").get(f"/v1/listings/{draft['id']}").status_code == 200


def test_cross_dealer_customers_quotes_and_imports_are_invisible(as_user, ids):
    hv, rl = as_user("admin@harbourview.example"), as_user("admin@ridgeline.example")
    hv_customers = {c["id"] for c in hv.get("/v1/customers?limit=200").json()["items"]}
    rl_customers = {c["id"] for c in rl.get("/v1/customers?limit=200").json()["items"]}
    only_hv = hv_customers - rl_customers
    assert only_hv
    for cid in list(only_hv)[:3]:
        assert rl.get(f"/v1/customers/{cid}").status_code == 404
    rl_quotes = rl.get("/v1/quotes?limit=200").json()["items"]
    assert all(q["organisation_id"] == str(ids["rl"]) for q in rl_quotes)
    rl_payments = rl.get("/v1/payments?limit=200").json()["items"]
    assert all(p["organisation_id"] == str(ids["rl"]) for p in rl_payments)
    rl_audit = rl.get("/v1/audit-events?limit=500").json()["items"]
    assert all(a["organisation_id"] in (str(ids["rl"]), None) for a in rl_audit) and rl_audit


def test_published_listings_are_public_but_drafts_are_not(as_user, factory):
    pub = factory.listing()
    rl = as_user("admin@ridgeline.example")
    assert rl.get(f"/v1/listings/{pub['id']}").status_code == 200
    # ...but a Ridgeline user cannot act on it: RLS gives them no writable row (404, nothing disclosed)
    assert rl.post(f"/v1/listings/{pub['id']}/suspend", json={}, version=pub["version"]).status_code in (403, 404)
    assert as_user("admin@harbourview.example").get(f"/v1/listings/{pub['id']}").json()["status"] == "published"


def test_permission_matrix_dealer_staff_cannot_approve_or_publish(as_user, factory):
    draft = factory.listing(publish=False)
    staff = as_user("sales@harbourview.example")
    r = staff.post(f"/v1/listings/{draft['id']}/publish", json={}, version=draft["version"])
    assert r.status_code == 403 and r.json()["code"] == "permission_denied"


def test_customer_principal_sees_only_own_records(as_user, factory, ids, owner_engine):
    with owner_engine.connect() as c:
        email, cid = c.execute(text("SELECT email, customer_id FROM app_users WHERE kind = 'customer' ORDER BY email LIMIT 1")).one()
    me = as_user(email)
    lst = factory.listing()
    r = me.post("/v1/quotes", json={"listing_id": lst["id"]})
    assert r.status_code == 201, r.text
    quotes = me.get("/v1/quotes?limit=200").json()["items"]
    assert quotes and all(q["customer_id"] == str(cid) for q in quotes)
    other = next(x for x in ids["customers"] if x != cid)
    assert me.get(f"/v1/customers/{other}").status_code == 404
    assert me.get("/v1/import-jobs").json()["items"] == []


def test_rls_blocks_rows_even_with_unfiltered_sql(ids):
    """A query with no WHERE clause (a bug) still only returns the tenant's rows."""
    eng = create_engine(APP_URL)
    with eng.connect() as c:
        with c.begin():
            c.execute(text("SELECT set_config('app.org_ids', :o, true)"), {"o": "{" + str(ids["hv"]) + "}"})
            orgs = set(c.execute(text("SELECT DISTINCT organisation_id FROM sale_reservations")).scalars())
            jobs = set(c.execute(text("SELECT DISTINCT organisation_id FROM payment_intents")).scalars())
        assert orgs <= {ids["hv"]} and jobs <= {ids["hv"]}
        with c.begin():  # no context at all -> nothing tenant-scoped is visible
            assert c.execute(text("SELECT count(*) FROM sale_reservations")).scalar() == 0
            assert c.execute(text("SELECT count(*) FROM customers")).scalar() == 0
            assert c.execute(text("SELECT count(*) FROM audit_events")).scalar() == 0
    eng.dispose()


def test_rls_with_check_blocks_cross_tenant_writes(ids):
    eng = create_engine(APP_URL)
    with eng.connect() as c:
        c.begin()
        c.execute(text("SELECT set_config('app.org_ids', :o, true)"), {"o": "{" + str(ids["rl"]) + "}"})
        try:
            c.execute(text("INSERT INTO charge_rules (organisation_id, charge_type, code, label, calculation, amount_minor, currency) "
                           "VALUES (:o, 'mandatory_fee', 'sneaky_fee', 'x', 'fixed', 1, 'USD')"), {"o": ids["hv"]})
            raise AssertionError("cross-tenant insert should fail")
        except Exception as e:  # noqa: BLE001
            assert "row-level security" in str(e)
        c.rollback()
    eng.dispose()


def test_pooled_connection_does_not_leak_tenant_context(ids):
    """pool_size=1: the same physical connection serves tenant A, then an unscoped request."""
    eng = create_engine(APP_URL, pool_size=1, max_overflow=0)
    from sqlalchemy.orm import Session
    pid_seen = set()
    for outcome in ("commit", "rollback"):
        s = Session(eng)
        apply_context(s, DbContext(org_ids=(ids["hv"],), user_id=uuid.uuid4()))
        pid_seen.add(s.execute(text("SELECT pg_backend_pid()")).scalar())
        assert s.execute(text("SELECT count(*) FROM customers")).scalar() > 0
        s.commit() if outcome == "commit" else s.rollback()
        s.close()
        s2 = Session(eng)
        pid_seen.add(s2.execute(text("SELECT pg_backend_pid()")).scalar())
        assert s2.execute(text("SELECT current_setting('app.org_ids', true)")).scalar() in ("", None)
        assert s2.execute(text("SELECT count(*) FROM customers")).scalar() == 0
        s2.close()
    assert len(pid_seen) == 1, "test must reuse one physical connection"
    eng.dispose()


def test_acting_organisation_header_narrows_scope(as_user, ids):
    ops = as_user("ops@autos-data.example")
    assert ops.get("/v1/me").json()["is_platform"] is True
    r = as_user("admin@harbourview.example", org=str(ids["rl"])).get("/v1/me")
    assert r.status_code == 403 and r.json()["code"] == "organisation_not_member"
