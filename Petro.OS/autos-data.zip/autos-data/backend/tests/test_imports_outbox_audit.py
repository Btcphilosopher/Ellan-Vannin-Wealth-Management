"""Import pipeline (validation, preview, modes, idempotency, stale/blank rules), CSV safety, outbox, audit."""
import csv
import io
import json
import uuid
from pathlib import Path

from sqlalchemy import text

from app.db import DbContext, session_scope
from app.services import operations as ops
from tests.conftest import ROOT, new_vin

SAMPLES = ROOT / "seed" / "samples"


def upload(api, data: bytes, filename="feed.csv", source="feed:test", mode="partial_accept", options=None):
    return api.c.post("/v1/import-jobs", headers=api.headers, files={"file": (filename, data, "text/csv")},
                      data={"source_namespace": source, "mode": mode, "options": json.dumps(options or {})})


def csv_bytes(rows: list[dict]) -> bytes:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
    return buf.getvalue().encode()


def row(sid, vin=None, price="25000.00", **kw):
    base = {"source_record_id": sid, "vin": vin or new_vin(), "make": "Hyundai", "model": "Elantra", "model_year": "2026", "trim": "SE",
            "exterior_colour": "Serenity White", "odometer_value": "10", "odometer_unit": "mi", "price": price, "currency": "USD",
            "location_code": "RL-DEN", "source_updated_at": "2026-11-20T10:00:00-07:00"}
    base.update(kw)
    return base


def test_sample_file_validation_and_preview(as_user):
    api = as_user("admin@ridgeline.example")
    data = (SAMPLES / "ridgeline_inventory_2026-11-25.csv").read_bytes()
    job = upload(api, data, "ridgeline_inventory_2026-11-25.csv", source="feed:ridgeline-sample", mode="all_or_nothing")
    assert job.status_code == 201, job.text
    j = job.json()
    assert (j["row_count"], j["invalid_count"]) == (10, 6) and j["valid_count"] + j["warning_count"] == 4
    codes = {f["code"] for f in j["findings_summary"] if f["severity"] == "error"}
    assert {"invalid_vin", "invalid_price", "unknown_reference", "unit_required", "duplicate_source_identifier", "unsupported_currency"} <= codes
    rows = api.get(f"/v1/import-jobs/{j['id']}/rows", params={"status": "invalid"}).json()["items"]
    assert len(rows) == 6 and all(r["raw"] and r["findings"] for r in rows)  # raw source payload preserved for review
    bad_price = api.get(f"/v1/import-jobs/{j['id']}/rows", params={"code": "invalid_price"}).json()["items"]
    assert [r["source_record_id"] for r in bad_price] == ["RL-1005"]
    # all_or_nothing: approval refused while invalid rows exist
    r = api.post(f"/v1/import-jobs/{j['id']}/approval", version=j["version"])
    assert r.status_code == 422 and r.json()["code"] == "import_has_invalid_rows"
    # Re-uploading identical bytes is idempotent
    again = upload(api, data, "renamed.csv", source="feed:ridgeline-sample", mode="all_or_nothing")
    assert again.status_code == 200 and again.json()["duplicate_upload"] is True and again.json()["id"] == j["id"]


def test_partial_accept_applies_valid_rows_then_publish(as_user):
    api = as_user("admin@ridgeline.example")
    data = (SAMPLES / "ridgeline_inventory_2026-11-25.csv").read_bytes()
    j = upload(api, data, source="feed:ridgeline-partial").json()
    j = api.post(f"/v1/import-jobs/{j['id']}/approval", version=j["version"]).json()
    assert j["status"] == "applied_with_skips" and j["applied_count"] == 4 and j["skipped_count"] == 6
    applied = api.get(f"/v1/import-jobs/{j['id']}/rows", params={"status": "applied"}).json()["items"]
    lids = [r["result"]["listing_id"] for r in applied]
    res = api.post("/v1/listings/publication-batch", json={"listing_ids": lids}).json()
    assert res["published"] == 4, res
    lst = api.get(f"/v1/listings/{lids[0]}").json()
    assert lst["freshness_state"] == "fresh" and lst["source_namespace"] == "feed:ridgeline-partial"


def test_repeat_import_is_idempotent_and_stale_updates_rejected(as_user, owner_engine):
    api = as_user("admin@ridgeline.example")
    v1, v2 = new_vin(), new_vin()
    first = [row("IDEM-1", v1), row("IDEM-2", v2)]
    j = upload(api, csv_bytes(first), source="feed:idem").json()
    j = api.post(f"/v1/import-jobs/{j['id']}/approval", version=j["version"]).json()
    assert j["applied_count"] == 2
    # Same records, different file bytes (column order changed): no_change, nothing duplicated
    reordered = [{k: r[k] for k in reversed(list(r))} for r in first]
    j2 = upload(api, csv_bytes(reordered), source="feed:idem").json()
    assert j2["planned_actions"] == {"no_change": 2}
    j2 = api.post(f"/v1/import-jobs/{j2['id']}/approval", version=j2["version"]).json()
    assert j2["no_change_count"] == 2 and j2["applied_count"] == 0
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT count(*) FROM vehicle_identifiers WHERE value_normalized IN (:a, :b) AND namespace = 'vin'"),
                         {"a": v1, "b": v2}).scalar() == 2
        assert c.execute(text("SELECT count(*) FROM source_record_mappings WHERE source_namespace = 'feed:idem'")).scalar() == 2
    # Older source timestamp with a different price -> stale, rejected
    stale = upload(api, csv_bytes([row("IDEM-1", v1, price="1.00", source_updated_at="2026-11-01T10:00:00-07:00")]), source="feed:idem").json()
    assert stale["invalid_count"] == 1
    assert any(f["code"] == "stale_source_update" for f in stale["findings_summary"])
    # Newer update changes the price via a new price version
    newer = upload(api, csv_bytes([row("IDEM-1", v1, price="24000.00", source_updated_at="2026-11-25T10:00:00-07:00")]), source="feed:idem").json()
    newer = api.post(f"/v1/import-jobs/{newer['id']}/approval", version=newer["version"]).json()
    assert newer["applied_count"] == 1
    lid = api.get(f"/v1/import-jobs/{newer['id']}/rows").json()["items"][0]["result"]["listing_id"]
    assert [p["amount_minor"] for p in api.get(f"/v1/listings/{lid}").json()["price_history"]] == [2400000, 2500000]


def test_blank_fields_do_not_erase_without_rule(as_user):
    api = as_user("admin@ridgeline.example")
    vin = new_vin()
    j = upload(api, csv_bytes([row("BLANK-1", vin, exterior_colour="Lucid Blue")]), source="feed:blank").json()
    j = api.post(f"/v1/import-jobs/{j['id']}/approval", version=j["version"]).json()
    vid = api.get(f"/v1/import-jobs/{j['id']}/rows").json()["items"][0]["result"]["vehicle_id"]
    j = upload(api, csv_bytes([row("BLANK-1", vin, exterior_colour="", source_updated_at="2026-11-21T10:00:00-07:00")]), source="feed:blank").json()
    api.post(f"/v1/import-jobs/{j['id']}/approval", version=j["version"])
    assert api.get(f"/v1/vehicles/{vid}").json()["exterior_colour"] == "Lucid Blue"
    j = upload(api, csv_bytes([row("BLANK-1", vin, exterior_colour="", source_updated_at="2026-11-22T10:00:00-07:00")]), source="feed:blank",
               options={"clear_blank_fields": ["exterior_colour"]}).json()
    api.post(f"/v1/import-jobs/{j['id']}/approval", version=j["version"])
    assert api.get(f"/v1/vehicles/{vid}").json()["exterior_colour"] is None


def test_all_or_nothing_success_and_json_format(as_user):
    api = as_user("admin@harbourview.example")
    data = (SAMPLES / "harbourview_dms_feed.json").read_bytes()
    r = api.c.post("/v1/import-jobs", headers=api.headers, files={"file": ("feed.json", data, "application/json")},
                   data={"source_namespace": "feed:harbourview-dms", "mode": "all_or_nothing", "options": json.dumps({"publish_on_apply": True})})
    j = r.json()
    assert r.status_code == 201 and j["format"] == "json" and j["invalid_count"] == 0
    j = api.post(f"/v1/import-jobs/{j['id']}/approval", version=j["version"]).json()
    assert j["status"] == "applied" and j["applied_count"] == 3
    rows = api.get(f"/v1/import-jobs/{j['id']}/rows").json()["items"]
    assert all(r["result"]["listing_status"] == "published" for r in rows)


def test_cross_tenant_vin_conflict_detected_without_disclosure(as_user, factory):
    lst = factory.listing()  # Harbourview vehicle
    vin = as_user("admin@harbourview.example").get(f"/v1/vehicles/{lst['vehicle']['id']}").json()["identifiers"][0]["value"]
    api = as_user("admin@ridgeline.example")
    j = upload(api, csv_bytes([row("XT-1", vin)]), source="feed:xt").json()
    assert j["invalid_count"] == 1
    r = api.get(f"/v1/import-jobs/{j['id']}/rows").json()["items"][0]
    f = next(x for x in r["findings"] if x["code"] == "vehicle_custodian_conflict")
    assert "Harbourview" not in f["message"] and r["matched_vehicle_id"] is None


def test_weak_match_creates_merge_proposal_not_merge(as_user, ids, owner_engine):
    api = as_user("admin@ridgeline.example")
    with owner_engine.begin() as c:  # an existing VIN-less vehicle
        vid = c.execute(text("INSERT INTO vehicles (custodian_organisation_id, trim_id, model_year, exterior_colour) "
                             "VALUES (:o, :t, 2026, 'Calypso Red') RETURNING id"), {"o": ids["rl"], "t": ids["trims"][("Elantra", "SE")]}).scalar()
    j = upload(api, csv_bytes([row("WEAK-1", exterior_colour="Calypso Red")]), source="feed:weak").json()
    rows = api.get(f"/v1/import-jobs/{j['id']}/rows").json()["items"]
    assert rows[0]["planned_action"] == "create" and any(f["code"] == "possible_duplicate" for f in rows[0]["findings"])
    api.post(f"/v1/import-jobs/{j['id']}/approval", version=j["version"])
    props = api.get("/v1/vehicle-merge-proposals").json()["items"]
    assert any(p["primary_vehicle_id"] == str(vid) for p in props)
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT archived_at FROM vehicles WHERE id = :v"), {"v": vid}).scalar() is None


def test_csv_export_neutralises_formulas(as_user):
    api = as_user("admin@ridgeline.example")
    j = upload(api, csv_bytes([row("FORMULA-1", title='=HYPERLINK("http://evil.invalid","x")'),
                                row("FORMULA-2", title="+SUM(A1:A2)"), row("FORMULA-3", title="@cmd")]), source="feed:formula").json()
    api.post(f"/v1/import-jobs/{j['id']}/approval", version=j["version"])
    out = api.get("/v1/listings/export.csv").text
    titles = [r["title"] for r in csv.DictReader(io.StringIO(out))]
    assert "'=HYPERLINK(\"http://evil.invalid\",\"x\")" in titles and "'+SUM(A1:A2)" in titles and "'@cmd" in titles
    assert not any(t.startswith(("=", "+", "-", "@")) for t in titles)


# ------------------------------------------------------------------ outbox
def test_outbox_retry_backoff_and_dead_letter(owner_engine, ids, as_user):
    with owner_engine.begin() as c:
        eid = c.execute(text("""INSERT INTO outbox_events (organisation_id, aggregate_type, aggregate_id, event_type, payload, max_attempts)
                                VALUES (:o, 'test', gen_random_uuid(), 'test.fail', '{"_simulate_publish_failure": true}', 3) RETURNING id"""),
                        {"o": ids["hv"]}).scalar()
    delivered = []
    for _ in range(3):
        with owner_engine.begin() as c:
            c.execute(text("UPDATE outbox_events SET available_at = now() WHERE id = :i AND status = 'pending'"), {"i": eid})
        with session_scope(DbContext.system()) as s:
            ops.dispatch_outbox(s, sink=lambda e: delivered.append(e["id"]) if not e["payload"].get("_simulate_publish_failure") else ops.log_sink(e),
                                batch=100000)
    with owner_engine.connect() as c:
        st, attempts, err = c.execute(text("SELECT status, attempts, last_error FROM outbox_events WHERE id = :i"), {"i": eid}).one()
    assert (st, attempts) == ("dead", 3) and "simulated" in err
    ops_api = as_user("ops@autos-data.example")
    r = ops_api.post(f"/v1/outbox-events/{eid}/requeue")
    assert r.status_code == 200 and r.json()["status"] == "pending" and r.json()["attempts"] == 0
    assert as_user("admin@harbourview.example").post(f"/v1/outbox-events/{eid}/requeue").status_code == 403


def test_outbox_publishes_each_event_once(owner_engine, ids):
    with owner_engine.begin() as c:
        for i in range(5):
            c.execute(text("INSERT INTO outbox_events (organisation_id, aggregate_type, aggregate_id, event_type, payload) "
                           "VALUES (:o, 'test', gen_random_uuid(), 'test.ok', '{}')"), {"o": ids["hv"]})
    seen = []
    with session_scope(DbContext.system()) as s:
        ops.dispatch_outbox(s, sink=lambda e: seen.append(e["id"]), batch=10000)
    with session_scope(DbContext.system()) as s:
        ops.dispatch_outbox(s, sink=lambda e: seen.append(e["id"]), batch=10000)
    assert len(seen) == len(set(seen)) and seen
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT count(*) FROM outbox_events WHERE status = 'published' AND published_at IS NULL")).scalar() == 0


# ------------------------------------------------------------------ audit
def test_audit_records_actor_request_and_redacts(as_user, ids, client):
    api = as_user("admin@harbourview.example")
    rid = "req-" + uuid.uuid4().hex[:12]
    r = api.post("/v1/customers", json={"display_name": "Audit Probe", "email": "probe@customers.example", "phone": "+15550199999"},
                 headers={"X-Request-Id": rid})
    assert r.status_code == 201 and r.headers["X-Request-Id"] == rid
    ev = api.get("/v1/audit-events", params={"request_id": rid}).json()["items"]
    assert len(ev) == 1
    e = ev[0]
    assert e["action"] == "customer.created" and e["actor_user_id"] == str(ids["users"]["admin@harbourview.example"])
    assert e["organisation_id"] == str(ids["hv"]) and e["target_id"] == r.json()["id"]
    assert "probe@customers.example" not in json.dumps(e) and "+15550199999" not in json.dumps(e)


def test_app_role_cannot_tamper_with_audit(ids):
    from sqlalchemy import create_engine
    from tests.conftest import APP_URL
    eng = create_engine(APP_URL)
    with eng.connect() as c:
        c.execute(text("SELECT set_config('app.is_platform', 'on', false)"))
        for sql in ("UPDATE audit_events SET action = 'x.y'", "DELETE FROM audit_events"):
            try:
                c.execute(text(sql))
                raise AssertionError("tamper should fail")
            except Exception as e:  # noqa: BLE001
                assert "permission denied" in str(e) or "append_only" in str(e)
            c.rollback()
            c.execute(text("SELECT set_config('app.is_platform', 'on', false)"))
    eng.dispose()
