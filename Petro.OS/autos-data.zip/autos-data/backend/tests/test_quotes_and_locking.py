"""Immutable quotes, price arithmetic, preservation across catalogue changes; optimistic locking."""
import json
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor

import pytest
from sqlalchemy import text


def test_quote_example_incomplete_without_region(as_user, factory, ids):
    lst = factory.listing(price="32900.00", deposit=50000)
    api = as_user("admin@harbourview.example")
    q = api.post("/v1/quotes", json={"listing_id": lst["id"], "customer_id": str(ids["customers"][0])}).json()
    assert q["vehicle_price_minor"] == 3290000
    assert q["mandatory_fees_minor"] == 40000                       # dealer fee $400
    assert q["subtotal_before_tax_registration_minor"] == 3330000   # $33,300
    assert q["is_complete"] is False and q["total_minor"] is None
    assert q["missing_charges"] == ["registration", "tax"]
    assert q["deposit_required_minor"] == 50000 and q["deposit_treatment"] == "applied_to_price"
    assert q["total_known_minor"] == 3330000                        # deposit NOT added
    assert q["summary"]["subtotal_before_tax_registration"] == "$33,300.00"
    unknown = [l for l in q["lines"] if l["amount_status"] == "unknown"]
    assert {l["line_type"] for l in unknown} == {"tax", "registration"} and all(l["amount_minor"] is None for l in unknown)
    acc = api.post(f"/v1/quotes/{q['id']}/acceptance", json={"channel": "in_store"})
    assert acc.status_code == 422 and acc.json()["code"] == "quote_not_acceptable"


def test_quote_complete_with_region_and_options(as_user, factory, ids):
    lst = factory.listing(price="32900.00", deposit=50000)
    api = as_user("admin@harbourview.example")
    q = api.post("/v1/quotes", json={"listing_id": lst["id"], "customer_id": str(ids["customers"][0]), "customer_region": "US-OR",
                                     "product_codes": ["paint_protection"], "promo_codes": ["winter500"], "delivery_requested": True}).json()
    # 32,900 + 400 fee + 595 product - 500 discount = 33,395 ; tax 0.5% = 166.98 (half-up) ; reg 312 ; delivery 250
    assert q["subtotal_before_tax_registration_minor"] == 3339500
    assert q["taxes_minor"] == 16698 and q["registration_minor"] == 31200 and q["delivery_minor"] == 25000
    assert q["is_complete"] is True and q["total_minor"] == 3339500 + 16698 + 31200 + 25000
    assert q["summary"]["total"] == "$34,123.98" and q["summary"]["balance_after_deposit"] == "$33,623.98"
    acc = api.post(f"/v1/quotes/{q['id']}/acceptance", json={"channel": "in_store"})
    assert acc.status_code == 201
    again = api.post(f"/v1/quotes/{q['id']}/acceptance", json={"channel": "in_store"})
    assert again.status_code in (409, 422)


def test_issued_quotes_are_immutable_in_the_database(as_user, factory, ids, owner_engine):
    lst = factory.listing()
    q = as_user("admin@harbourview.example").post("/v1/quotes", json={"listing_id": lst["id"], "session_reference": "anon-session-001"}).json()
    with owner_engine.connect() as c:
        for sql, code in (("UPDATE quotes SET vehicle_price_minor = 1 WHERE id = :q", "Z9003"),
                          ("UPDATE quotes SET snapshot = '{}' WHERE id = :q", "Z9003"),
                          ("UPDATE quote_lines SET amount_minor = 0 WHERE quote_id = :q", "Z9010"),
                          ("DELETE FROM quotes WHERE id = :q", "Z9010")):
            with pytest.raises(Exception) as e:
                c.execute(text(sql), {"q": q["id"]})
            assert e.value.orig.sqlstate == code, sql
            c.rollback()


def test_quote_totals_must_match_lines_at_commit(owner_engine):
    """Deferred constraint trigger: a header whose totals disagree with its lines cannot commit."""
    with owner_engine.connect() as c:
        src = c.execute(text("SELECT * FROM quotes LIMIT 1")).mappings().one()
        cols = [k for k in src.keys() if k not in ("id", "quote_number")]
        vals = dict(src)
        c.execute(text(f"INSERT INTO quotes ({', '.join(cols)}) VALUES ({', '.join(':' + k for k in cols)})"),
                  {**{k: vals[k] for k in cols}, "snapshot": json.dumps(vals["snapshot"])})
        with pytest.raises(Exception) as e:
            c.commit()  # header with no lines
        assert e.value.orig.sqlstate == "Z9011"


def test_price_and_catalogue_changes_do_not_rewrite_quotes(as_user, factory, ids, owner_engine):
    lst = factory.listing(price="43500.00")
    api = as_user("admin@harbourview.example")
    q = api.post("/v1/quotes", json={"listing_id": lst["id"], "customer_id": str(ids["customers"][1])}).json()
    cur = api.get(f"/v1/listings/{lst['id']}").json()
    api.post(f"/v1/listings/{lst['id']}/prices", json={"price": "41000.00"}, version=cur["version"])
    with owner_engine.begin() as c:
        c.execute(text("UPDATE vehicle_trims SET name = name WHERE id = :t"), {"t": ids["trims"][("Tucson", "SEL")]})
        c.execute(text("UPDATE charge_rules SET effective_to = now() WHERE organisation_id = :o AND code = 'doc_fee' AND effective_to IS NULL"),
                  {"o": ids["hv"]})
        c.execute(text("INSERT INTO charge_rules (organisation_id, charge_type, code, label, calculation, amount_minor, currency) "
                       "VALUES (:o, 'mandatory_fee', 'doc_fee', 'Dealer documentation fee (new)', 'fixed', 55000, 'USD')"), {"o": ids["hv"]})
    again = api.get(f"/v1/quotes/{q['id']}").json()
    assert again["vehicle_price_minor"] == 4350000 and again["mandatory_fees_minor"] == 40000
    assert again["snapshot"]["listing"]["asking_price_minor"] == 4350000 and again["snapshot_verified"] is True
    new_q = api.post("/v1/quotes", json={"listing_id": lst["id"], "customer_id": str(ids["customers"][1])}).json()
    assert new_q["vehicle_price_minor"] == 4100000 and new_q["mandatory_fees_minor"] == 55000
    hist = api.get(f"/v1/listings/{lst['id']}").json()["price_history"]
    assert [h["amount_minor"] for h in hist] == [4100000, 4350000] and hist[1]["effective_to"] == hist[0]["effective_from"]


# ------------------------------------------------------------------ optimistic locking
def test_if_match_required_and_enforced(as_user, factory):
    lst = factory.listing(publish=False)
    api = as_user("admin@harbourview.example")
    vid = lst["vehicle"]["id"]
    r = api.get(f"/v1/vehicles/{vid}")
    version = int(r.headers["ETag"].strip('"'))
    assert api.patch(f"/v1/vehicles/{vid}", json={"exterior_colour": "Lucid Blue"}).status_code == 428
    ok = api.patch(f"/v1/vehicles/{vid}", json={"exterior_colour": "Lucid Blue"}, version=version)
    assert ok.status_code == 200 and ok.json()["version"] == version + 1
    stale = api.patch(f"/v1/vehicles/{vid}", json={"exterior_colour": "Ultimate Red"}, version=version)
    assert stale.status_code == 409 and stale.json()["code"] == "version_conflict" and stale.json()["current_version"] == version + 1


def test_concurrent_versioned_updates_one_wins(as_user, factory):
    lst = factory.listing(publish=False)
    api = as_user("admin@harbourview.example")
    vid = lst["vehicle"]["id"]
    version = api.get(f"/v1/vehicles/{vid}").json()["version"]
    barrier = threading.Barrier(8)

    def go(i):
        barrier.wait()
        return api.patch(f"/v1/vehicles/{vid}", json={"keys_count": i}, version=version).status_code

    with ThreadPoolExecutor(8) as ex:
        codes = list(ex.map(go, range(8)))
    assert codes.count(200) == 1 and codes.count(409) == 7, codes


def test_generic_patch_cannot_change_status_or_sell(as_user, factory):
    lst = factory.listing()
    api = as_user("admin@harbourview.example")
    v = api.get(f"/v1/vehicles/{lst['vehicle']['id']}").json()
    r = api.patch(f"/v1/vehicles/{v['id']}", json={"availability_status": "sold"}, version=v["version"])
    assert r.status_code == 422
    r = api.patch(f"/v1/listings/{lst['id']}", json={"status": "sold"}, version=lst["version"])
    assert r.status_code == 422  # unknown field rejected by contract


def test_publication_validation_findings(as_user, factory, ids, owner_engine):
    api = as_user("admin@harbourview.example")
    r = api.post("/v1/vehicles", json={"trim_id": str(ids["trims"][("Kona", "SEL")]), "model_year": 2025})
    vid = r.json()["id"]
    lst = api.post("/v1/listings", json={"vehicle_id": vid, "location_id": str(ids["locs"]["HV-BVT"]), "title": "No VIN, no price"}).json()
    res = api.post(f"/v1/listings/{lst['id']}/publish", json={}, version=lst["version"])
    assert res.status_code == 422 and res.json()["code"] == "publication_blocked"
    codes = {e["code"] for e in res.json()["errors"]}
    assert {"price_missing", "vin_missing", "not_sale_eligible"} <= codes and "odometer_unknown" in codes
