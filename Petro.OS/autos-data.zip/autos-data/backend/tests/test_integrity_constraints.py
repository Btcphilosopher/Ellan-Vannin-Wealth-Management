"""Database-enforced integrity: FKs, checks, uniqueness, append-only history, unknown vs zero."""
import uuid

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from tests.conftest import new_vin


def run_fail(engine, sql, params=None):
    with engine.connect() as c:
        with pytest.raises(DBAPIError) as e:
            c.execute(text(sql), params or {})
            c.commit()
        c.rollback()
    return e.value.orig.sqlstate, str(e.value.orig)


def test_foreign_key_enforced(owner_engine, ids):
    state, _ = run_fail(owner_engine, "INSERT INTO listings (organisation_id, vehicle_id, location_id, title, currency) "
                                      "VALUES (:o, :v, :l, 'x', 'USD')",
                        {"o": ids["hv"], "v": uuid.uuid4(), "l": ids["locs"]["HV-PDX"]})
    assert state == "23503"


def test_listing_location_must_belong_to_seller(owner_engine, ids):
    """Composite FK (location_id, organisation_id): a dealer cannot list at another dealer's site."""
    with owner_engine.connect() as c:
        vid = c.execute(text("SELECT id FROM vehicles WHERE custodian_organisation_id = :o LIMIT 1"), {"o": ids["hv"]}).scalar()
    state, _ = run_fail(owner_engine, "INSERT INTO listings (organisation_id, vehicle_id, location_id, title, currency, channel) VALUES (:o,:v,:l,'x','USD','partner_syndication')",
                        {"o": ids["hv"], "v": vid, "l": ids["locs"]["RL-DEN"]})
    assert state == "23503"


def test_negative_or_zero_price_rejected(owner_engine):
    with owner_engine.connect() as c:
        lid, org = c.execute(text("SELECT id, organisation_id FROM listings LIMIT 1")).one()
    state, _ = run_fail(owner_engine, "INSERT INTO listing_price_versions (listing_id, organisation_id, amount_minor, currency, reason, effective_from) "
                                      "VALUES (:l, :o, -100, 'USD', 'correction', now() + interval '100 years')", {"l": lid, "o": org})
    assert state == "23514"


def test_price_currency_must_match_listing(owner_engine):
    with owner_engine.connect() as c:
        lid, org = c.execute(text("SELECT id, organisation_id FROM listings LIMIT 1")).one()
    state, _ = run_fail(owner_engine, "INSERT INTO listing_price_versions (listing_id, organisation_id, amount_minor, currency, reason, effective_from, effective_to) "
                                      "VALUES (:l, :o, 100, 'EUR', 'correction', '2000-01-01', '2000-01-02')", {"l": lid, "o": org})
    assert state == "23503"


def test_overlapping_price_periods_rejected(owner_engine):
    with owner_engine.connect() as c:
        lid, org = c.execute(text("SELECT id, organisation_id FROM listings WHERE current_price_version_id IS NOT NULL LIMIT 1")).one()
    state, msg = run_fail(owner_engine, "INSERT INTO listing_price_versions (listing_id, organisation_id, amount_minor, currency, reason) "
                                        "VALUES (:l, :o, 100, 'USD', 'correction')", {"l": lid, "o": org})
    assert state == "23P01"


def test_invalid_timezone_rejected(owner_engine, ids):
    for tz in ("EST", "EST5EDT", "Mars/Olympus", "+05:00"):
        state, _ = run_fail(owner_engine, "INSERT INTO locations (organisation_id, code, name, kind, address_line1, city, country_code, geog, timezone) "
                                          "VALUES (:o, 'TZ-X', 'x', 'storage', 'x', 'x', 'US', 'SRID=4326;POINT(0 0)', :tz)", {"o": ids["hv"], "tz": tz})
        assert state == "23514", tz


def test_unknown_is_not_zero(owner_engine, ids):
    with owner_engine.begin() as c:
        unknown = c.execute(text("INSERT INTO vehicles (custodian_organisation_id) VALUES (:o) RETURNING id"), {"o": ids["hv"]}).scalar()
        zero = c.execute(text("INSERT INTO vehicles (custodian_organisation_id, odometer_value, odometer_unit, odometer_recorded_at, has_open_recall) "
                              "VALUES (:o, 0, 'km', now(), false) RETURNING id"), {"o": ids["hv"]}).scalar()
        a = c.execute(text("SELECT odometer_value, has_open_recall FROM vehicles WHERE id = :i"), {"i": unknown}).one()
        b = c.execute(text("SELECT odometer_value, has_open_recall FROM vehicles WHERE id = :i"), {"i": zero}).one()
    assert tuple(a) == (None, None) and tuple(b) == (0, False)
    state, _ = run_fail(owner_engine, "INSERT INTO vehicles (custodian_organisation_id, odometer_value) VALUES (:o, 100)", {"o": ids["hv"]})
    assert state == "23514"  # a reading without a unit is rejected


def test_vin_format_and_namespaced_uniqueness(owner_engine, ids):
    with owner_engine.begin() as c:
        v1 = c.execute(text("INSERT INTO vehicles (custodian_organisation_id) VALUES (:o) RETURNING id"), {"o": ids["hv"]}).scalar()
        v2 = c.execute(text("INSERT INTO vehicles (custodian_organisation_id) VALUES (:o) RETURNING id"), {"o": ids["rl"]}).scalar()
        vin = new_vin()
        c.execute(text("INSERT INTO vehicle_identifiers (vehicle_id, namespace, value, source) VALUES (:v, 'vin', :x, 't')"), {"v": v1, "x": vin})
        # Same stock-number text issued by two different dealers is fine (namespace + issuer).
        c.execute(text("INSERT INTO vehicle_identifiers (vehicle_id, namespace, value, issuing_organisation_id, source) VALUES (:v,'stock','A100',:o,'t')"),
                  {"v": v1, "o": ids["hv"]})
        c.execute(text("INSERT INTO vehicle_identifiers (vehicle_id, namespace, value, issuing_organisation_id, source) VALUES (:v,'stock','A100',:o,'t')"),
                  {"v": v2, "o": ids["rl"]})
    state, _ = run_fail(owner_engine, "INSERT INTO vehicle_identifiers (vehicle_id, namespace, value, source) VALUES (:v, 'vin', :x, 't')",
                        {"v": v2, "x": vin.lower()})
    assert state == "23505"  # normalised value collides
    state, _ = run_fail(owner_engine, "INSERT INTO vehicle_identifiers (vehicle_id, namespace, value, source) VALUES (:v, 'vin', 'NOTAVIN', 't')", {"v": v2})
    assert state == "23514"


def test_listing_status_transitions_enforced_in_db(owner_engine):
    with owner_engine.connect() as c:
        lid = c.execute(text("SELECT id FROM listings WHERE status = 'draft' LIMIT 1")).scalar()
    state, msg = run_fail(owner_engine, "UPDATE listings SET status = 'sold' WHERE id = :l", {"l": lid})
    assert state == "Z9002" and "invalid_status_transition" in msg


@pytest.mark.parametrize("sql", [
    "UPDATE audit_events SET action = 'x.y' WHERE id = (SELECT min(id) FROM audit_events)",
    "DELETE FROM audit_events WHERE id = (SELECT min(id) FROM audit_events)",
    "DELETE FROM listing_status_events WHERE id = (SELECT id FROM listing_status_events LIMIT 1)",
    "UPDATE payment_transactions SET amount_minor = 1 WHERE id = (SELECT id FROM payment_transactions LIMIT 1)",
    "DELETE FROM vehicles WHERE id = (SELECT id FROM vehicles LIMIT 1)",
    "TRUNCATE audit_events",
])
def test_history_is_append_only_even_for_owner(owner_engine, sql):
    state, _ = run_fail(owner_engine, sql)
    assert state == "Z9010"


def test_status_events_written_by_trigger(owner_engine):
    with owner_engine.connect() as c:
        n = c.execute(text("""SELECT count(*) FROM listings l WHERE NOT EXISTS
                              (SELECT 1 FROM listing_status_events e WHERE e.listing_id = l.id)""")).scalar()
    assert n == 0
