"""Backup and restoration into a clean environment (fresh initdb cluster)."""
import os
import shutil
import subprocess

import pytest

from tests.conftest import OWNER_URL, ROOT


@pytest.mark.skipif(not shutil.which("pg_dump"), reason="PostgreSQL client tools not installed")
def test_restore_drill_into_fresh_cluster():
    url = OWNER_URL.replace("postgresql+psycopg://", "postgresql://")
    out = subprocess.run([str(ROOT / "scripts" / "restore_drill.sh")], env={**os.environ, "PGURL": url, "DRILL_PORT": "5498"},
                         capture_output=True, text=True, timeout=600)
    assert out.returncode == 0, out.stdout + out.stderr
    assert "row counts match" in out.stdout and "DRILL PASSED" in out.stdout
    assert "|0" in out.stdout and "INVARIANT VIOLATIONS" not in out.stdout
