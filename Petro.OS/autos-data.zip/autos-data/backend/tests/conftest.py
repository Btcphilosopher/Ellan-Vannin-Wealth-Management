"""Integration-test harness: a real PostgreSQL 16 + PostGIS database.

A fresh database (default `autos_test`) is created, migrated with Alembic
and seeded once per session. The API and services connect as the
non-owner `autos_api` login role (member of autos_app), so row-level
security, column grants and triggers are all in force — no SQLite, no
mocks of the database.

Environment:
  AUTOS_TEST_ADMIN_URL   superuser/owner URL used to create the database
  AUTOS_TEST_DB          database name (default autos_test)
"""
from __future__ import annotations

import datetime as dt
import os
import random
import subprocess
import sys
import uuid
from pathlib import Path

import pytest
from sqlalchemy import create_engine, text

ROOT = Path(__file__).resolve().parents[1]
ADMIN_URL = os.environ.get("AUTOS_TEST_ADMIN_URL", "postgresql+psycopg://autos_owner:autos@localhost:5432/postgres")
DB = os.environ.get("AUTOS_TEST_DB", "autos_test")
OWNER_URL = ADMIN_URL.rsplit("/", 1)[0] + f"/{DB}"
TEMPLATE = os.environ.get("AUTOS_TEST_TEMPLATE")  # e.g. autos_template when the owner is not a superuser
APP_URL = os.environ.get("AUTOS_TEST_APP_URL", f"postgresql+psycopg://autos_api:autos_api@localhost:5432/{DB}")

os.environ.setdefault("AUTOS_LOCAL_STORAGE_DIR", str(ROOT / "var" / "test-objects"))
os.environ["AUTOS_DATABASE_URL"] = APP_URL
os.environ["AUTOS_MIGRATION_DATABASE_URL"] = OWNER_URL


def _create_database() -> None:
    eng = create_engine(ADMIN_URL, isolation_level="AUTOCOMMIT")
    with eng.connect() as c:
        c.execute(text(f"DROP DATABASE IF EXISTS {DB} WITH (FORCE)"))
        c.execute(text(f"CREATE DATABASE {DB}" + (f" TEMPLATE {TEMPLATE}" if TEMPLATE else "")))
        c.execute(text("""DO $$BEGIN
            IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autos_app') THEN CREATE ROLE autos_app NOLOGIN; END IF;
            IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autos_api') THEN
              CREATE ROLE autos_api LOGIN PASSWORD 'autos_api' IN ROLE autos_app; END IF; END$$"""))
    eng.dispose()
    subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], cwd=ROOT, check=True,
                   env={**os.environ, "AUTOS_MIGRATION_DATABASE_URL": OWNER_URL})


@pytest.fixture(scope="session", autouse=True)
def database():
    _create_database()
    from seed import generate
    counts = generate.run(OWNER_URL, seed=2026)
    from app import db as appdb
    appdb.reset_engine(create_engine(APP_URL, pool_size=20, max_overflow=20))
    yield counts
    appdb.reset_engine(None)


@pytest.fixture(scope="session")
def owner_engine():
    eng = create_engine(OWNER_URL)
    yield eng
    eng.dispose()


@pytest.fixture(scope="session")
def client(database):
    from fastapi.testclient import TestClient
    from app.main import app
    with TestClient(app) as c:
        yield c


class Api:
    """Thin authenticated wrapper around TestClient."""

    def __init__(self, client, email: str, org: str | None = None):
        self.c = client
        r = client.post("/v1/auth/token", json={"email": email})
        assert r.status_code == 200, r.text
        self.headers = {"Authorization": f"Bearer {r.json()['access_token']}"}
        if org:
            self.headers["X-Organisation-Id"] = org

    def _h(self, extra):
        return {**self.headers, **(extra or {})}

    def get(self, url, **kw):
        return self.c.get(url, headers=self._h(kw.pop("headers", None)), **kw)

    def post(self, url, json=None, version=None, key=None, **kw):
        h = kw.pop("headers", None) or {}
        if version is not None:
            h["If-Match"] = f'"{version}"'
        if key is not None:
            h["Idempotency-Key"] = key
        return self.c.post(url, json=json, headers=self._h(h), **kw)

    def patch(self, url, json=None, version=None, **kw):
        h = {"If-Match": f'"{version}"'} if version is not None else {}
        return self.c.patch(url, json=json, headers=self._h(h), **kw)


@pytest.fixture(scope="session")
def as_user(client):
    cache = {}

    def make(email, org=None):
        if (email, org) not in cache:
            cache[(email, org)] = Api(client, email, org)
        return cache[(email, org)]
    return make


@pytest.fixture(scope="session")
def ids(owner_engine):
    with owner_engine.connect() as c:
        orgs = {r.slug: r.id for r in c.execute(text("SELECT slug, id FROM organisations"))}
        locs = {r.code: r.id for r in c.execute(text("SELECT code, id FROM locations"))}
        users = {r.email: r.id for r in c.execute(text("SELECT email, id FROM app_users"))}
        customers = [r.id for r in c.execute(text("SELECT id FROM customers ORDER BY created_at"))]
        trims = {(r.model, r.name): r.id for r in c.execute(text(
            "SELECT m.name AS model, t.name, t.id FROM vehicle_trims t JOIN vehicle_models m ON m.id = t.model_id"))}
    return {"orgs": orgs, "locs": locs, "users": users, "customers": customers, "trims": trims,
            "hv": orgs["harbourview-motors"], "rl": orgs["ridgeline-auto"], "cl": orgs["cityline-rentals"]}


_rng = random.Random(99)


def new_vin() -> str:
    from app.services.vehicles import vin_check_digit
    chars = "ABCDEFGHJKLMNPRSTUVWXYZ0123456789"
    body = "TST" + "".join(_rng.choice(chars) for _ in range(5)) + "0T" + "A" + "".join(_rng.choice("0123456789") for _ in range(6))
    return body[:8] + vin_check_digit(body) + body[9:]


@pytest.fixture(scope="session")
def factory(as_user, ids):
    """Builds fresh, isolated fixtures through the public API."""

    class F:
        def listing(self, dealer="admin@harbourview.example", loc="HV-PDX", price="32900.00", deposit=50000, publish=True,
                    channel="marketplace", vehicle_id=None, model=("Tucson", "SEL")):
            api = as_user(dealer)
            if vehicle_id is None:
                r = api.post("/v1/vehicles", json={"vin": new_vin(), "trim_id": str(ids["trims"][model]), "model_year": 2026,
                                                    "condition": "new", "odometer_value": 5, "odometer_unit": "mi",
                                                    "exterior_colour": "Serenity White"})
                assert r.status_code == 201, r.text
                vehicle_id = r.json()["id"]
            r = api.post("/v1/listings", json={"vehicle_id": vehicle_id, "location_id": str(ids["locs"][loc]), "title": "Test listing",
                                                "price": price, "deposit_required_minor": deposit, "sale_eligibility": "eligible",
                                                "channel": channel})
            assert r.status_code == 201, r.text
            lst = r.json()
            if publish:
                r = api.post(f"/v1/listings/{lst['id']}/publish", json={}, version=lst["version"])
                assert r.status_code == 200, r.text
                lst = r.json()
            return lst

        def reserve(self, listing_id, customer_id, dealer="admin@harbourview.example", key=None):
            return as_user(dealer).post("/v1/sale-reservations", json={"listing_id": listing_id, "customer_id": str(customer_id)},
                                        key=key or uuid.uuid4().hex)
    return F()


def utc(*a) -> dt.datetime:
    return dt.datetime(*a, tzinfo=dt.timezone.utc)
