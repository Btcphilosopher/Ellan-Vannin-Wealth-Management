"""S3-compatible object storage integration (runs when AUTOS_TEST_S3_ENDPOINT is set, e.g. MinIO or moto_server)."""
import hashlib
import os

import pytest

ENDPOINT = os.environ.get("AUTOS_TEST_S3_ENDPOINT")


@pytest.mark.skipif(not ENDPOINT, reason="set AUTOS_TEST_S3_ENDPOINT to an S3-compatible server")
def test_s3_storage_roundtrip_and_media_upload(monkeypatch, as_user, factory):
    from app import config, storage
    monkeypatch.setenv("AUTOS_STORAGE_BACKEND", "s3")
    monkeypatch.setenv("AUTOS_S3_ENDPOINT_URL", ENDPOINT)
    monkeypatch.setenv("AUTOS_S3_ACCESS_KEY", os.environ.get("AUTOS_TEST_S3_KEY", "test"))
    monkeypatch.setenv("AUTOS_S3_SECRET_KEY", os.environ.get("AUTOS_TEST_S3_SECRET", "test"))
    monkeypatch.setenv("AUTOS_S3_BUCKET", "autos-data-test")
    config.get_settings.cache_clear()
    monkeypatch.setattr(storage, "_storage", None)
    try:
        s3 = storage.get_storage()
        assert isinstance(s3, storage.S3Storage)
        obj = s3.put("probe/hello.txt", b"hello", "text/plain")
        assert s3.get("probe/hello.txt") == b"hello" and obj.sha256 == hashlib.sha256(b"hello").hexdigest()
        lst = factory.listing()
        png = b"\x89PNG\r\n\x1a\n" + b"0" * 64
        r = as_user("admin@harbourview.example").c.post(
            f"/v1/vehicles/{lst['vehicle']['id']}/media", headers=as_user("admin@harbourview.example").headers,
            files={"file": ("front.png", png, "image/png")}, data={"kind": "photo", "caption": "front"})
        assert r.status_code == 201, r.text
        m = r.json()
        assert m["storage_bucket"] == "autos-data-test" and s3.get(m["object_key"]) == png
        assert m["sha256"] == hashlib.sha256(png).hexdigest()
    finally:
        config.get_settings.cache_clear()
        storage._storage = None
