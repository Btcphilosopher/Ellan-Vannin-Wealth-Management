"""Schema management, ORM drift, privileges, and monetary arithmetic."""
import os
import subprocess
import sys
from decimal import Decimal

import pytest
from sqlalchemy import create_engine, inspect, text

from app.models import Base
from app.money import MINOR_UNITS, Money, MoneyError
from tests.conftest import ADMIN_URL, ROOT, TEMPLATE


def test_migrations_at_head(owner_engine):
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT version_num FROM alembic_version")).scalar() == "r0014"


def test_downgrade_to_base_and_upgrade_again():
    """Every migration has a working down path (fresh scratch database)."""
    name = "autos_test_migrations"
    eng = create_engine(ADMIN_URL, isolation_level="AUTOCOMMIT")
    with eng.connect() as c:
        c.execute(text(f"DROP DATABASE IF EXISTS {name} WITH (FORCE)"))
        c.execute(text(f"CREATE DATABASE {name}" + (f" TEMPLATE {TEMPLATE}" if TEMPLATE else "")))
    url = ADMIN_URL.rsplit("/", 1)[0] + f"/{name}"
    env = {**os.environ, "AUTOS_MIGRATION_DATABASE_URL": url}
    for cmd in (["upgrade", "head"], ["downgrade", "base"], ["upgrade", "head"]):
        subprocess.run([sys.executable, "-m", "alembic", *cmd], cwd=ROOT, env=env, check=True, capture_output=True)
    e2 = create_engine(url)
    with e2.connect() as c:
        assert c.execute(text("SELECT count(*) FROM pg_tables WHERE schemaname = 'public'")).scalar() >= 56
    e2.dispose()
    with eng.connect() as c:
        c.execute(text(f"DROP DATABASE {name} WITH (FORCE)"))
    eng.dispose()


def test_orm_models_match_database(owner_engine):
    """Generated ORM models must not drift from the migrated schema."""
    insp = inspect(owner_engine)
    db_tables = set(insp.get_table_names(schema="public")) - {"spatial_ref_sys", "alembic_version"}
    assert set(Base.metadata.tables) == db_tables
    for name, table in Base.metadata.tables.items():
        db_cols = {c["name"]: c for c in insp.get_columns(name)}
        assert set(db_cols) == set(table.columns.keys()), name
        for col in table.columns:
            assert db_cols[col.name]["nullable"] == col.nullable, f"{name}.{col.name} nullability"


def test_rls_enabled_on_every_tenant_table(owner_engine):
    with owner_engine.connect() as c:
        missing = c.execute(text("""
            SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
             WHERE n.nspname = 'public' AND c.relkind = 'r' AND NOT c.relrowsecurity
               AND EXISTS (SELECT 1 FROM pg_attribute a WHERE a.attrelid = c.oid AND a.attname IN ('organisation_id','custodian_organisation_id','customer_id') AND NOT a.attisdropped)
               AND c.relname NOT IN ('app_users')""")).scalars().all()
    assert missing == [], f"tables with tenant columns but no RLS: {missing}"


@pytest.mark.parametrize("table", ["audit_events", "listing_status_events", "sale_status_events", "payment_transactions",
                                   "quote_lines", "quotes", "payment_events", "vehicles", "listings"])
def test_app_role_cannot_delete_history(owner_engine, table):
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT has_table_privilege('autos_app', :t, 'DELETE')"), {"t": table}).scalar() is False
        assert c.execute(text("SELECT has_table_privilege('autos_app', :t, 'TRUNCATE')"), {"t": table}).scalar() is False


def test_app_role_cannot_write_current_reservations_directly(owner_engine):
    with owner_engine.connect() as c:
        for priv in ("INSERT", "UPDATE", "DELETE"):
            assert c.execute(text("SELECT has_table_privilege('autos_app', 'vehicle_current_reservations', :p)"),
                             {"p": priv}).scalar() is False


def test_app_role_is_not_owner_and_cannot_bypass_rls(owner_engine):
    with owner_engine.connect() as c:
        r = c.execute(text("SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = 'autos_api'")).one()
        assert (r.rolsuper, r.rolbypassrls) == (False, False)


def test_currency_table_matches_code(owner_engine):
    with owner_engine.connect() as c:
        db = dict(c.execute(text("SELECT code, minor_unit FROM currencies")).all())
    assert {k.strip(): v for k, v in db.items()} == MINOR_UNITS


# ------------------------------------------------------------------ money
def test_parse_exact_and_reject_excess_precision():
    assert Money.parse("32,900.00", "USD").amount_minor == 3290000
    assert Money.parse("1000", "JPY").amount_minor == 1000
    assert Money.parse("1.234", "BHD").amount_minor == 1234
    with pytest.raises(MoneyError):
        Money.parse("10.001", "USD")
    with pytest.raises(MoneyError):
        Money.parse("1.5", "JPY")
    with pytest.raises(MoneyError):
        Money.parse(0.1, "USD")  # floats rejected
    with pytest.raises(MoneyError):
        Money.parse("NaN", "USD")


def test_no_float_drift():
    total = Money.zero("USD")
    for _ in range(10):
        total = total + Money.parse("0.10", "USD")
    assert total == Money(100, "USD")  # 0.1 * 10 == 1.00 exactly


def test_currency_mismatch_rejected():
    with pytest.raises(MoneyError):
        Money(100, "USD") + Money(100, "EUR")


def test_rate_rounding_half_up():
    assert Money(3330000, "USD").apply_rate_bps(50) == Money(16650, "USD")     # 0.5% of 33,300.00 = 166.50
    assert Money(101, "USD").apply_rate_bps(5000) == Money(51, "USD")          # 50.5 -> 51
    assert Money(3330000, "USD").apply_rate_bps(290) == Money(96570, "USD")    # 2.9%


def test_allocate_preserves_total():
    parts = Money(10000, "USD").allocate([1, 1, 1])
    assert sum(p.amount_minor for p in parts) == 10000 and sorted(p.amount_minor for p in parts) == [3333, 3333, 3334]


def test_format():
    assert Money(3290000, "USD").format() == "$32,900.00"
    assert Money(1234, "BHD").format() == "1.234 BHD"
    assert Money(-50000, "USD").format() == "-$500.00"
    assert Money(3290000, "USD").to_decimal() == Decimal("32900.00")
