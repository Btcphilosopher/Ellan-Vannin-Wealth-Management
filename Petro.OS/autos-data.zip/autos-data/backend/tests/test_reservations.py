"""Concurrency-safe sale reservations, expiry under the same lock, lifecycle separation, idempotency."""
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

import pytest
from sqlalchemy import text

from app.db import session_scope
from app.security import load_principal
from app.services import sales as S


@pytest.fixture
def short_hold(owner_engine, ids):
    with owner_engine.begin() as c:
        c.execute(text("UPDATE organisations SET sale_hold_duration = interval '2 seconds' WHERE id = :o"), {"o": ids["hv"]})
    yield
    with owner_engine.begin() as c:
        c.execute(text("UPDATE organisations SET sale_hold_duration = interval '30 minutes' WHERE id = :o"), {"o": ids["hv"]})


def principal(ids, email):
    from app.db import new_session
    s = new_session()
    try:
        return load_principal(s, ids["users"][email], acting_org_id=None, request_id="test")
    finally:
        s.close()


def test_competing_reservations_across_listings_exactly_one_wins(factory, ids, owner_engine):
    """20 concurrent requests from different customers, through two listings of the same vehicle."""
    a = factory.listing()
    b = factory.listing(channel="dealer_site", vehicle_id=a["vehicle"]["id"])
    assert a["vehicle"]["id"] == b["vehicle"]["id"] and a["id"] != b["id"]
    p = principal(ids, "admin@harbourview.example")
    barrier = threading.Barrier(20)

    def attempt(i):
        barrier.wait()
        try:
            with session_scope(p.db_context()) as s:
                r = S.create_reservation(s, p, {"listing_id": uuid.UUID([a, b][i % 2]["id"]),
                                                "customer_id": ids["customers"][i % len(ids["customers"])]}, None)
                return ("ok", r.id)
        except Exception as e:  # noqa: BLE001
            code = getattr(getattr(e, "orig", None), "sqlstate", None) or getattr(e, "code", type(e).__name__)
            return ("err", code)

    with ThreadPoolExecutor(20) as ex:
        results = list(ex.map(attempt, range(20)))
    wins = [r for r in results if r[0] == "ok"]
    losses = [r for r in results if r[0] == "err"]
    assert len(wins) == 1, results
    assert all(code in ("Z9001", "23505") for _, code in losses), losses
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT count(*) FROM vehicle_current_reservations WHERE vehicle_id = :v"), {"v": a["vehicle"]["id"]}).scalar() == 1
        assert c.execute(text("SELECT count(*) FROM sale_reservations WHERE vehicle_id = :v AND status IN ('held','dealer_accepted')"),
                         {"v": a["vehicle"]["id"]}).scalar() == 1


def test_api_second_reservation_gets_409(factory, ids):
    lst = factory.listing()
    r1 = factory.reserve(lst["id"], ids["customers"][0])
    r2 = factory.reserve(lst["id"], ids["customers"][1])
    assert r1.status_code == 201 and r2.status_code == 409
    assert r2.json()["code"] == "vehicle_already_reserved" and r2.json()["request_id"]


def test_lapsed_hold_is_expired_inline_without_worker(factory, ids, short_hold, owner_engine):
    lst = factory.listing()
    first = factory.reserve(lst["id"], ids["customers"][0]).json()
    time.sleep(2.3)
    # No sweeper has run. The read model already reports it expired...
    second = factory.reserve(lst["id"], ids["customers"][1])
    assert second.status_code == 201, second.text  # ...and a new hold succeeds under the same vehicle lock
    with owner_engine.connect() as c:
        st, reason = c.execute(text("SELECT status, end_reason FROM sale_reservations WHERE id = :i"), {"i": first["id"]}).one()
    assert (st, reason) == ("expired", "hold_expired")


def test_acceptance_after_expiry_is_rejected(as_user, factory, ids, short_hold):
    lst = factory.listing(deposit=0)
    r = factory.reserve(lst["id"], ids["customers"][2]).json()
    time.sleep(2.3)
    api = as_user("admin@harbourview.example")
    resp = api.post(f"/v1/sale-reservations/{r['id']}/acceptance", version=r["version"])
    assert resp.status_code == 409 and resp.json()["code"] == "hold_expired"
    assert api.get(f"/v1/sale-reservations/{r['id']}").json()["status"] == "expired"


def test_effective_status_reports_expiry_before_sweep(as_user, factory, ids, short_hold):
    lst = factory.listing(deposit=0)
    r = factory.reserve(lst["id"], ids["customers"][3]).json()
    time.sleep(2.3)
    d = as_user("admin@harbourview.example").get(f"/v1/sale-reservations/{r['id']}").json()
    assert d["status"] == "held" and d["effective_status"] == "expired"


def test_db_refuses_to_expire_early_or_shorten_hold(factory, ids, owner_engine):
    lst = factory.listing(deposit=0)
    r = factory.reserve(lst["id"], ids["customers"][4]).json()
    with owner_engine.connect() as c:
        for sql in ("UPDATE sale_reservations SET status='expired', end_reason='x' WHERE id = :i",
                    "UPDATE sale_reservations SET hold_expires_at = hold_expires_at - interval '1 minute' WHERE id = :i",
                    "UPDATE sale_reservations SET vehicle_id = gen_random_uuid() WHERE id = :i"):
            with pytest.raises(Exception) as e:
                c.execute(text(sql), {"i": r["id"]})
            assert e.value.orig.sqlstate in ("Z9002", "Z9003")
            c.rollback()


def test_sweeper_and_requests_agree(factory, ids, short_hold, owner_engine):
    lst = factory.listing(deposit=0)
    r = factory.reserve(lst["id"], ids["customers"][5]).json()
    time.sleep(2.3)
    from app.db import DbContext
    with session_scope(DbContext.system()) as s:
        n = S.expire_due(s)
    assert n >= 1
    with owner_engine.connect() as c:
        assert c.execute(text("SELECT status FROM sale_reservations WHERE id = :i"), {"i": r["id"]}).scalar() == "expired"
        assert c.execute(text("SELECT count(*) FROM vehicle_current_reservations WHERE sale_reservation_id = :i"), {"i": r["id"]}).scalar() == 0


def test_lifecycle_stages_are_separate(as_user, factory, ids):
    """Hold -> deposit -> dealer acceptance -> agreement -> handover -> completion; each is its own step."""
    api = as_user("admin@harbourview.example")
    lst = factory.listing(deposit=50000)
    r = factory.reserve(lst["id"], ids["customers"][6]).json()
    assert r["status"] == "held" and r["deposit_status"] == "awaiting"
    resp = api.post(f"/v1/sale-reservations/{r['id']}/acceptance", version=r["version"])
    assert resp.status_code == 409 and resp.json()["code"] == "deposit_outstanding"
    # deposit via simulated provider
    pay = api.post("/v1/payments", json={"purpose": "sale_deposit", "sale_reservation_id": r["id"]}, key=uuid.uuid4().hex)
    assert pay.status_code == 201, pay.text
    ref = pay.json()["provider_intent_ref"]
    api.post(f"/v1/dev/simpay/payments/{ref}/settle", json={"outcome": "succeeded"})
    r = api.get(f"/v1/sale-reservations/{r['id']}").json()
    assert r["deposit_status"] == "paid" and r["status"] == "held"  # payment alone does not accept the sale
    r = api.post(f"/v1/sale-reservations/{r['id']}/acceptance", version=r["version"]).json()
    assert r["status"] == "dealer_accepted"
    o = api.post(f"/v1/sale-reservations/{r['id']}/sale-order", json={"agreed_total_minor": 3330000}, version=r["version"]).json()
    assert o["status"] == "agreement_pending"
    resp = api.post(f"/v1/sale-orders/{o['id']}/completion", version=o["version"])
    assert resp.status_code == 409  # cannot complete without agreement + handover
    o = api.post(f"/v1/sale-orders/{o['id']}/agreement", version=o["version"]).json()
    o = api.post(f"/v1/sale-orders/{o['id']}/handover", json={"location_id": str(ids["locs"]["HV-PDX"]), "odometer_value": 6,
                                                                 "odometer_unit": "mi"}, version=o["version"]).json()
    assert o["status"] == "handed_over"
    blocked = api.post(f"/v1/sale-orders/{o['id']}/completion", version=o["version"])
    assert blocked.status_code == 409 and blocked.json()["code"] == "balance_outstanding"
    assert blocked.json()["balance_outstanding_minor"] == 3330000 - 50000
    bal = api.post("/v1/payments", json={"purpose": "sale_balance", "sale_order_id": o["id"]}, key=uuid.uuid4().hex).json()
    assert bal["amount_minor"] == 3330000 - 50000
    api.post(f"/v1/dev/simpay/payments/{bal['provider_intent_ref']}/settle", json={"outcome": "succeeded"})
    o = api.post(f"/v1/sale-orders/{o['id']}/completion", version=o["version"]).json()
    assert o["status"] == "completed" and o["balance_outstanding_minor"] == 0
    v = api.get(f"/v1/vehicles/{lst['vehicle']['id']}").json()
    assert v["availability_status"] == "sold" and v["current_commitment"] is None
    assert api.get(f"/v1/listings/{lst['id']}").json()["status"] == "sold"
    assert factory.reserve(lst["id"], ids["customers"][7]).status_code == 409


def test_reservation_idempotency_replay_and_mismatch(as_user, factory, ids):
    lst = factory.listing()
    other = factory.listing()
    key = "res-" + uuid.uuid4().hex
    api = as_user("admin@harbourview.example")
    body = {"listing_id": lst["id"], "customer_id": str(ids["customers"][8])}
    r1 = api.post("/v1/sale-reservations", json=body, key=key)
    r2 = api.post("/v1/sale-reservations", json=body, key=key)
    assert r1.status_code == 201 and r2.status_code == 201 and r1.json()["id"] == r2.json()["id"]
    assert r2.headers.get("Idempotent-Replayed") == "true"
    r3 = api.post("/v1/sale-reservations", json={**body, "listing_id": other["id"]}, key=key)
    assert r3.status_code == 422 and r3.json()["code"] == "idempotency_key_reused"


def test_cancellation_frees_vehicle(as_user, factory, ids):
    api = as_user("admin@harbourview.example")
    lst = factory.listing(deposit=0)
    r = factory.reserve(lst["id"], ids["customers"][9]).json()
    c = api.post(f"/v1/sale-reservations/{r['id']}/cancellation", json={"reason": "customer changed mind"}, version=r["version"])
    assert c.status_code == 200 and c.json()["status"] == "cancelled"
    assert factory.reserve(lst["id"], ids["customers"][10]).status_code == 201


def test_completion_override_requires_reason_and_is_audited(as_user, factory, ids):
    api = as_user("admin@harbourview.example")
    lst = factory.listing(deposit=0)
    r = factory.reserve(lst["id"], ids["customers"][11]).json()
    r = api.post(f"/v1/sale-reservations/{r['id']}/acceptance", version=r["version"]).json()
    o = api.post(f"/v1/sale-reservations/{r['id']}/sale-order", json={"agreed_total_minor": 3290000}, version=r["version"]).json()
    o = api.post(f"/v1/sale-orders/{o['id']}/agreement", version=o["version"]).json()
    o = api.post(f"/v1/sale-orders/{o['id']}/handover", json={"location_id": str(ids["locs"]["HV-PDX"])}, version=o["version"]).json()
    r1 = api.post(f"/v1/sale-orders/{o['id']}/completion", json={"accept_outstanding_balance": True}, version=o["version"])
    assert r1.status_code == 422 and r1.json()["code"] == "reason_required"
    r2 = api.post(f"/v1/sale-orders/{o['id']}/completion", json={"accept_outstanding_balance": True, "reason": "lender finance (test)"},
                  version=o["version"])
    assert r2.status_code == 200 and r2.json()["status"] == "completed"
    ev = api.get("/v1/audit-events", params={"target_type": "sale_order", "target_id": o["id"], "action": "sale_order.completed"}).json()["items"]
    assert ev and ev[0]["changes"]["outstanding_at_completion_minor"] == 3290000
