"""Rental overlap/capacity (half-open, buffers, concurrency, DST) and test-drive conflicts."""
import datetime as dt
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from zoneinfo import ZoneInfo

import pytest
from sqlalchemy import text

from app.services.scheduling import rental_days

LA = ZoneInfo("America/Los_Angeles")


@pytest.fixture(scope="module")
def fleet(owner_engine, ids):
    """An isolated bucket: new category at CL-SEA with exactly 2 assets, 60-minute buffer."""
    with owner_engine.begin() as c:
        cat = c.execute(text("""INSERT INTO rental_categories (organisation_id, code, name, turnaround_buffer, daily_rate_minor, currency)
                                VALUES (:o, 'T-' || upper(substr(md5(random()::text), 1, 6)), 'Test category', interval '60 minutes', 5000, 'USD') RETURNING id"""),
                        {"o": ids["cl"]}).scalar()
        c.execute(text("INSERT INTO rental_inventory_buckets (location_id, category_id, organisation_id) VALUES (:l, :c, :o)"),
                  {"l": ids["locs"]["CL-SEA"], "c": cat, "o": ids["cl"]})
        assets = []
        for i in range(2):
            v = c.execute(text("INSERT INTO vehicles (custodian_organisation_id, current_location_id) VALUES (:o, :l) RETURNING id"),
                          {"o": ids["cl"], "l": ids["locs"]["CL-SEA"]}).scalar()
            assets.append(c.execute(text("""INSERT INTO rental_assets (organisation_id, vehicle_id, category_id, home_location_id, fleet_number, in_fleet_from)
                                            VALUES (:o, :v, :c, :l, :f, now() - interval '1 year') RETURNING id"""),
                                    {"o": ids["cl"], "v": v, "c": cat, "l": ids["locs"]["CL-SEA"], "f": f"T-{uuid.uuid4().hex[:6]}"}).scalar())
    return {"category": str(cat), "assets": [str(a) for a in assets], "location": str(ids["locs"]["CL-SEA"])}


def book(api, fleet, pickup, ret, customer, asset=None):
    body = {"category_id": fleet["category"], "location_id": fleet["location"], "pickup_at": pickup.isoformat(),
            "return_at": ret.isoformat(), "customer_id": str(customer)}
    if asset:
        body["rental_asset_id"] = asset
    return api.post("/v1/rental-bookings", json=body, key=uuid.uuid4().hex)


def test_rental_days_half_open_and_dst():
    start = dt.datetime(2027, 3, 13, 10, 0, tzinfo=LA)           # DST starts 2027-03-14 02:00 local
    assert rental_days(start, start + dt.timedelta(hours=48)) == 2  # 48 absolute hours = 2 days even across DST
    assert rental_days(start, start + dt.timedelta(hours=24)) == 1
    assert rental_days(start, start + dt.timedelta(hours=24, minutes=1)) == 2


def test_overlapping_asset_assignment_rejected_with_buffer_boundaries(as_user, fleet, ids):
    api = as_user("admin@cityline.example")
    base = dt.datetime(2027, 1, 10, 9, 0, tzinfo=LA)
    a = book(api, fleet, base, base + dt.timedelta(days=1), ids["customers"][0], asset=fleet["assets"][0])
    assert a.status_code == 201, a.text
    assert a.json()["assignments"][0]["occupied"]["upper"].startswith("2027-01-11T18:00")  # return 09:00 PST + 60 min buffer (UTC)
    # Starts 1 minute before the buffer ends -> overlaps on the same asset
    early = base + dt.timedelta(days=1, minutes=59)
    r = book(api, fleet, early, early + dt.timedelta(hours=5), ids["customers"][1], asset=fleet["assets"][0])
    assert r.status_code == 409 and r.json()["code"] == "rental_asset_conflict"
    # Exactly at return + buffer -> allowed (half-open)
    exact = base + dt.timedelta(days=1, hours=1)
    r = book(api, fleet, exact, exact + dt.timedelta(hours=5), ids["customers"][1], asset=fleet["assets"][0])
    assert r.status_code == 201, r.text
    assert r.json()["local_pickup"].endswith("-08:00") and r.json()["pickup_timezone"] == "America/Los_Angeles"


def test_category_capacity_under_concurrency(as_user, fleet, ids, owner_engine):
    """2 assets; 12 concurrent bookings for the same window -> exactly 2 succeed."""
    api = as_user("admin@cityline.example")
    base = dt.datetime(2027, 2, 1, 9, 0, tzinfo=LA)
    barrier = threading.Barrier(12)

    def go(i):
        barrier.wait()
        return book(api, fleet, base, base + dt.timedelta(days=2), ids["customers"][i % 10]).status_code

    with ThreadPoolExecutor(12) as ex:
        codes = list(ex.map(go, range(12)))
    assert codes.count(201) == 2 and codes.count(409) == 10, codes
    # Back-to-back after the buffer is still possible; overlapping inside the buffer is not.
    assert book(api, fleet, base + dt.timedelta(days=2, minutes=30), base + dt.timedelta(days=3), ids["customers"][0]).status_code == 409
    assert book(api, fleet, base + dt.timedelta(days=2, hours=1), base + dt.timedelta(days=3), ids["customers"][0]).status_code == 201


def test_maintenance_blocks_assets_and_capacity(as_user, fleet, ids):
    api = as_user("admin@cityline.example")
    base = dt.datetime(2027, 4, 5, 9, 0, tzinfo=LA)
    b = book(api, fleet, base, base + dt.timedelta(days=1), ids["customers"][2], asset=fleet["assets"][1])
    assert b.status_code == 201
    m = api.post("/v1/maintenance-blocks", json={"rental_asset_id": fleet["assets"][1], "kind": "repair", "reason": "brake check",
                                                  "starts_at": (base + dt.timedelta(hours=3)).isoformat(),
                                                  "ends_at": (base + dt.timedelta(hours=6)).isoformat()})
    assert m.status_code == 409 and m.json()["code"] == "rental_asset_conflict"
    # Block asset 0; then a second booking in the window must fail (only asset 1 left and it is booked).
    m = api.post("/v1/maintenance-blocks", json={"rental_asset_id": fleet["assets"][0], "kind": "inspection", "reason": "annual",
                                                  "starts_at": base.isoformat(), "ends_at": (base + dt.timedelta(days=1)).isoformat()})
    assert m.status_code == 201, m.text
    r = book(api, fleet, base + dt.timedelta(hours=2), base + dt.timedelta(hours=8), ids["customers"][3])
    assert r.status_code == 409 and r.json()["code"] == "rental_capacity_exceeded"
    avail = api.get("/v1/rental-availability", params={"location_id": fleet["location"], "category_id": fleet["category"],
                                                       "pickup_at": base.isoformat(), "return_at": (base + dt.timedelta(hours=8)).isoformat()}).json()
    assert avail == {**avail, "available_vehicles": 1, "peak_demand": 1, "can_book": False}


def test_maintenance_cannot_strand_committed_bookings(as_user, fleet, ids):
    api = as_user("admin@cityline.example")
    base = dt.datetime(2027, 5, 10, 9, 0, tzinfo=LA)
    for i in range(2):
        assert book(api, fleet, base, base + dt.timedelta(days=1), ids["customers"][i]).status_code == 201
    m = api.post("/v1/maintenance-blocks", json={"rental_asset_id": fleet["assets"][0], "kind": "repair", "reason": "x",
                                                  "starts_at": base.isoformat(), "ends_at": (base + dt.timedelta(hours=2)).isoformat()})
    assert m.status_code == 409 and m.json()["code"] == "rental_capacity_exceeded"


def test_cancellation_releases_capacity_and_assignment(as_user, fleet, ids):
    api = as_user("admin@cityline.example")
    base = dt.datetime(2027, 6, 1, 9, 0, tzinfo=LA)
    a = book(api, fleet, base, base + dt.timedelta(days=1), ids["customers"][0], asset=fleet["assets"][0]).json()
    b = book(api, fleet, base, base + dt.timedelta(days=1), ids["customers"][1]).json()
    assert book(api, fleet, base, base + dt.timedelta(days=1), ids["customers"][2]).status_code == 409
    c = api.post(f"/v1/rental-bookings/{a['id']}/cancellation", json={"reason": "plans changed"}, version=a["version"])
    assert c.status_code == 200 and c.json()["assignments"][0]["status"] == "cancelled"
    assert book(api, fleet, base, base + dt.timedelta(days=1), ids["customers"][2], asset=fleet["assets"][0]).status_code == 201
    assert b["status"] == "confirmed"


def test_naive_timestamps_rejected(as_user, fleet, ids):
    r = as_user("admin@cityline.example").post("/v1/rental-bookings", json={
        "category_id": fleet["category"], "location_id": fleet["location"], "pickup_at": "2027-07-01T09:00:00",
        "return_at": "2027-07-02T09:00:00", "customer_id": str(ids["customers"][0])})
    assert r.status_code == 422


# ------------------------------------------------------------------ test drives
@pytest.fixture(scope="module")
def drive_setup(owner_engine, ids):
    with owner_engine.begin() as c:
        bay = c.execute(text("""INSERT INTO appointment_resources (organisation_id, location_id, kind, name, capacity)
                                VALUES (:o, :l, 'bay', 'Test bay ' || substr(md5(random()::text),1,6), 2) RETURNING id"""),
                        {"o": ids["hv"], "l": ids["locs"]["HV-BVT"]}).scalar()
    return {"bay": str(bay)}


def drive(api, vehicle, listing, resource, start, customer, confirm=True, minutes=60):
    return api.post("/v1/test-drive-appointments", json={"vehicle_id": vehicle, "listing_id": listing, "resource_id": resource,
                                                          "customer_id": str(customer), "starts_at": start.isoformat(),
                                                          "ends_at": (start + dt.timedelta(minutes=minutes)).isoformat(), "confirm": confirm},
                    key=uuid.uuid4().hex)


def test_vehicle_cannot_be_double_booked_but_adjacent_slots_ok(as_user, factory, drive_setup, ids):
    api = as_user("admin@harbourview.example")
    lst = factory.listing(loc="HV-BVT")
    vid = lst["vehicle"]["id"]
    t = dt.datetime(2027, 1, 20, 10, 0, tzinfo=LA)
    assert drive(api, vid, lst["id"], drive_setup["bay"], t, ids["customers"][0]).status_code == 201
    r = drive(api, vid, lst["id"], drive_setup["bay"], t + dt.timedelta(minutes=30), ids["customers"][1])
    assert r.status_code == 409 and r.json()["code"] == "vehicle_slot_conflict"
    assert drive(api, vid, lst["id"], drive_setup["bay"], t + dt.timedelta(minutes=60), ids["customers"][1]).status_code == 201
    # Unconfirmed requests never block anyone.
    assert drive(api, vid, lst["id"], drive_setup["bay"], t, ids["customers"][2], confirm=False).status_code == 201


def test_resource_capacity_enforced_under_concurrency(as_user, factory, drive_setup, ids):
    api = as_user("admin@harbourview.example")
    lsts = [factory.listing(loc="HV-BVT") for _ in range(6)]
    t = dt.datetime(2027, 1, 21, 14, 0, tzinfo=LA)
    barrier = threading.Barrier(6)

    def go(i):
        barrier.wait()
        return drive(api, lsts[i]["vehicle"]["id"], lsts[i]["id"], drive_setup["bay"], t, ids["customers"][i]).status_code

    with ThreadPoolExecutor(6) as ex:
        codes = list(ex.map(go, range(6)))
    assert codes.count(201) == 2 and codes.count(409) == 4, codes  # bay capacity = 2


def test_vehicle_sale_cancels_future_drives_and_hold_flags_them(as_user, factory, drive_setup, ids, owner_engine):
    api = as_user("admin@harbourview.example")
    lst = factory.listing(loc="HV-BVT", deposit=0)
    vid = lst["vehicle"]["id"]
    t = dt.datetime(2027, 2, 2, 11, 0, tzinfo=LA)
    a = drive(api, vid, lst["id"], drive_setup["bay"], t, ids["customers"][0]).json()
    r = factory.reserve(lst["id"], ids["customers"][1]).json()
    got = api.get("/v1/test-drive-appointments", params={"vehicle_id": vid}).json()["items"][0]
    assert got["availability_notice"] == "vehicle_reserved" and got["confirmation_status"] == "confirmed"
    api.post(f"/v1/sale-reservations/{r['id']}/cancellation", json={"reason": "x"}, version=r["version"])
    got = api.get("/v1/test-drive-appointments", params={"vehicle_id": vid}).json()["items"][0]
    assert got["availability_notice"] is None
    v = api.get(f"/v1/vehicles/{vid}").json()
    api.patch(f"/v1/vehicles/{vid}", json={"availability_status": "unavailable"}, version=v["version"])
    got = api.get("/v1/test-drive-appointments", params={"vehicle_id": vid}).json()["items"][0]
    assert got["confirmation_status"] == "cancelled" and got["cancelled_by_kind"] == "system"
    assert got["cancellation_reason"].startswith("vehicle_unavailable")
