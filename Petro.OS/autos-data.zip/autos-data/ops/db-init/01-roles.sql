-- Cluster-level roles (pg_dump does not include them). Idempotent.
-- Passwords here are DEVELOPMENT defaults; production injects secrets via the orchestrator.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autos_owner') THEN
    CREATE ROLE autos_owner LOGIN PASSWORD 'autos' CREATEDB;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autos_app') THEN
    CREATE ROLE autos_app NOLOGIN NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autos_readonly') THEN
    CREATE ROLE autos_readonly NOLOGIN NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autos_api') THEN
    CREATE ROLE autos_api LOGIN PASSWORD 'autos_api' NOBYPASSRLS IN ROLE autos_app;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'autos_report') THEN
    CREATE ROLE autos_report LOGIN PASSWORD 'autos_report' NOBYPASSRLS IN ROLE autos_readonly;
  END IF;
END $$;
