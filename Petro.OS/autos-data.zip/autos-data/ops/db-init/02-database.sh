#!/bin/bash
# Docker entrypoint init: roles, then the application database owned by autos_owner.
set -euo pipefail
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" -d postgres -f /docker-entrypoint-initdb.d/01-roles.sql
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" -d postgres <<SQL
SELECT 'CREATE DATABASE autos OWNER autos_owner' WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'autos')\gexec
SQL
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" -d autos -c "CREATE EXTENSION IF NOT EXISTS postgis; CREATE EXTENSION IF NOT EXISTS btree_gist; CREATE EXTENSION IF NOT EXISTS citext; CREATE EXTENSION IF NOT EXISTS pg_trgm;"
# Template with the (superuser-only) extensions, so the non-superuser owner can
# create scratch databases for tests and restore drills: CREATE DATABASE x TEMPLATE autos_template
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" -d postgres <<SQL
SELECT 'CREATE DATABASE autos_template OWNER autos_owner' WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'autos_template')\gexec
SQL
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" -d autos_template -c "CREATE EXTENSION IF NOT EXISTS postgis; CREATE EXTENSION IF NOT EXISTS btree_gist; CREATE EXTENSION IF NOT EXISTS citext; CREATE EXTENSION IF NOT EXISTS pg_trgm;"
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" -d postgres -c "ALTER DATABASE autos_template WITH IS_TEMPLATE true"
