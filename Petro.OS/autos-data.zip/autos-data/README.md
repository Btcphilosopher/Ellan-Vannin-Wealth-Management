# AUTOS DATA — Vehicle Marketplace Database & Operations

The authoritative data platform behind a vehicle-marketplace concept: catalogue, physical vehicles, dealer inventory, listings and prices, immutable quotes, concurrency-safe sale reservations, test drives, rental fleets, payments and refunds, imports, audit and reconciliation — with an operational administration website.

> **Independent concept software.** All dealers, people, addresses, VINs and payments are fictional or synthetic; the payment provider is simulated. Branding is configuration (`AUTOS_BRAND_*`). Nothing here implies a partnership with, or access to the infrastructure of, Amazon or any marketplace operator.

**Main workflow:** import inventory → validate → publish listings → generate quotes → reserve resources → record payment outcomes → manage fulfilment → reconcile.

## What's in the box

| deliverable | where |
|---|---|
| SQL migrations (14, each with a tested downgrade) | [`backend/migrations/sql/`](backend/migrations/sql/), wrapped by Alembic in `backend/migrations/versions/` |
| Python models (generated, drift-tested) and domain services | `backend/app/models/`, `backend/app/services/` |
| FastAPI API + OpenAPI | `backend/app/api/`, [`docs/openapi.json`](docs/openapi.json), [`docs/API.md`](docs/API.md) |
| Administration website (React + TypeScript) | [`admin/`](admin/) · screenshots in [`docs/screenshots/`](docs/screenshots/) |
| Background workers | `backend/app/workers/` |
| ER diagrams | [`docs/ER_DIAGRAM.md`](docs/ER_DIAGRAM.md) (SVG + Mermaid) |
| Data dictionary (with retention/archival/deletion per entity) | [`docs/DATA_DICTIONARY.md`](docs/DATA_DICTIONARY.md) |
| Seed generator + sample import files | `backend/seed/generate.py`, `backend/seed/samples/` |
| Docker Compose | [`docker-compose.yml`](docker-compose.yml), `ops/db-init/` |
| Backup / restore / DR drill / invariant checks | `backend/scripts/backup.sh`, `restore.sh`, `restore_drill.sh`, `verify_integrity.sql` |
| Integration tests (real PostgreSQL + PostGIS) | `backend/tests/` · results in [`docs/TEST_RESULTS.md`](docs/TEST_RESULTS.md) |
| Performance dataset, plans, measurements | `backend/perf/`, [`docs/PERFORMANCE.md`](docs/PERFORMANCE.md) |
| Executed 12-scenario demonstration | [`docs/DEMO_TRANSCRIPT.md`](docs/DEMO_TRANSCRIPT.md) (`backend/scripts/demo.py`) |
| Architecture, security, operations | [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md), [`docs/SECURITY.md`](docs/SECURITY.md), [`docs/OPERATIONS.md`](docs/OPERATIONS.md) |
| Implemented vs simulated vs integrated vs deferred | [`docs/CAPABILITIES.md`](docs/CAPABILITIES.md) |

## Quick start (Docker Compose)

```bash
docker compose up -d --build
```

```bash
docker compose run --rm seed
```

Then open the admin UI at http://localhost:8080 (sign in as `admin@harbourview.example`), the API docs at http://localhost:8000/docs, and the MinIO console at http://localhost:9001.

Operations:

```bash
docker compose --profile ops run --rm backup
```

```bash
docker compose --profile ops run --rm restore-drill
```

## Quick start (local, no containers)

Requirements: PostgreSQL 16 with PostGIS 3, Python 3.11+, Node 22. A superuser creates the roles and database once:

```bash
psql -U postgres -f ops/db-init/01-roles.sql
```

```bash
psql -U postgres -c "CREATE DATABASE autos OWNER autos_owner" && psql -U postgres -d autos -c "CREATE EXTENSION postgis"
```

```bash
cd backend && pip install -r requirements.txt
```

```bash
export AUTOS_MIGRATION_DATABASE_URL=postgresql+psycopg://autos_owner:autos@localhost/autos AUTOS_DATABASE_URL=postgresql+psycopg://autos_api:autos_api@localhost/autos
```

```bash
alembic upgrade head && python -m seed.generate
```

```bash
uvicorn app.main:app --port 8000
```

```bash
python -m app.workers
```

```bash
cd admin && npm ci && VITE_API_TARGET=http://localhost:8000 npm run dev
```

Run the tests (they create and migrate their own `autos_test` database; set `AUTOS_TEST_TEMPLATE=autos_template` if the owner role is not a superuser):

```bash
cd backend && python -m pytest -q
```

## Demo accounts (fictional)

| email | role |
|---|---|
| `ops@autos-data.example` | platform_admin |
| `admin@harbourview.example` / `sales@…` / `finance@…` | Harbourview Motors dealer admin / staff / finance |
| `admin@ridgeline.example` / `sales@…` / `finance@…` | Ridgeline Auto Group dealer admin / staff / finance |
| `admin@cityline.example` / `agent@cityline.example` | Cityline Rentals admin / agent |
| `auditor@autos-data.example` | auditor (Harbourview) |
| `jamie.alvarez@customers.example` (+3 more) | customer principals |

Headline seeded listings: 2026 Tucson SEL $32,900 (also on the dealer's own site — same physical vehicle), 2026 IONIQ 5 SE $43,500, 2026 Sonata SEL $29,900, 2026 Santa Fe SE $35,900, plus 25 more listings with price history, 14 customers, 8 test drives, 11 rental assets, 3 maintenance blocks, 10 rental bookings, payments, a refund and two sale orders.

## Design in one paragraph

A modular monolith on PostgreSQL, where **the database enforces every critical invariant**: one active commitment per physical vehicle (primary key on `vehicle_current_reservations`, vehicle row lock, inline expiry), immutable quotes (triggers + deferred totals check), non-overlapping rental assignments and confirmed test drives (GiST exclusion), category capacity (locked inventory buckets + peak-concurrency check), refund limits (locked capture), duplicate/out-of-order provider events (unique keys + precedence), append-only history, and tenant isolation (row-level security behind backend authorisation). The Python services give friendly validation first; the UI is a convenience. See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).
