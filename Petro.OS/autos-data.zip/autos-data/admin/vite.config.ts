import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

// The admin UI always calls relative /v1/... URLs. In development the Vite
// server proxies them to the API (default http://localhost:8001); override
// with VITE_API_TARGET=http://host:port. In production nginx does the same.
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  const target = env.VITE_API_TARGET || process.env.VITE_API_TARGET || "http://localhost:8001";
  const proxy = { "/v1": { target, changeOrigin: true } };
  return {
    plugins: [react()],
    server: { port: 5173, strictPort: false, proxy },
    preview: { port: 4173, proxy },
    build: { outDir: "dist", sourcemap: false, chunkSizeWarningLimit: 900 },
  };
});
