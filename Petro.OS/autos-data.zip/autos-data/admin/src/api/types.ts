// Response shapes observed from the API (the OpenAPI document leaves most
// response bodies untyped). Fields not used by the UI are omitted.

export type ID = string;

export interface Page<T> {
  items: T[];
  next_cursor?: string | null;
}

export interface Branding {
  name: string;
  product: string;
  disclaimer: string;
  simulator_enabled: boolean;
  dev_auth_enabled: boolean;
}

export interface Membership {
  organisation_id: ID;
  organisation_kind: string;
  organisation_name: string;
  role: string;
  permissions: string[];
}

export interface Me {
  user_id: ID;
  email: string;
  display_name: string;
  kind: string;
  customer_id: ID | null;
  is_platform: boolean;
  memberships: Membership[];
}

export interface Money {
  amount_minor: number;
  currency: string;
  formatted: string;
  price_version_id?: ID;
}

export interface Specification {
  make: string;
  model: string;
  trim: string;
  model_year: number;
  fuel_type?: string;
  body_style?: string;
  label: string;
}

export interface Commitment {
  kind?: string;
  [k: string]: unknown;
}

export interface Identifier {
  id: ID;
  namespace: string;
  value: string;
  value_normalized: string;
  issuing_organisation_id: ID | null;
  is_synthetic: boolean;
  verification_status: string;
  source: string;
  recorded_at: string;
  retired_at: string | null;
  retired_reason: string | null;
}

export interface Vehicle {
  id: ID;
  trim_id: ID | null;
  custodian_organisation_id: ID;
  current_location_id: ID | null;
  model_year: number | null;
  exterior_colour: string | null;
  interior_colour: string | null;
  condition: string | null;
  odometer_value: number | null;
  odometer_unit: string | null;
  odometer_recorded_at: string | null;
  has_open_recall: boolean | null;
  keys_count: number | null;
  availability_status: string;
  sold_at: string | null;
  merged_into_vehicle_id: ID | null;
  created_at: string;
  updated_at: string;
  version: number;
  archived_at: string | null;
  specification: Specification | null;
  identifiers: Identifier[];
  current_commitment: Commitment | null;
  listings?: Listing[];
}

export interface ListingVehicleSummary {
  id: ID;
  specification: Specification | null;
  exterior_colour: string | null;
  odometer_value: number | null;
  odometer_unit: string | null;
  availability_status: string;
  condition: string | null;
  current_commitment: Commitment | null;
  vin: string | null;
}

export interface Finding {
  severity: "error" | "warning" | string;
  field?: string;
  code: string;
  message: string;
}

export interface Listing {
  id: ID;
  organisation_id: ID;
  vehicle_id: ID;
  location_id: ID;
  channel: string;
  title: string;
  description: string | null;
  status: string;
  status_reason: string | null;
  sale_eligibility: string;
  currency: string;
  deposit_required_minor: number;
  source_namespace: string | null;
  source_record_id: string | null;
  source_last_seen_at: string | null;
  freshness_state: string;
  effective_from: string | null;
  effective_to: string | null;
  published_at: string | null;
  withdrawn_at: string | null;
  sold_at: string | null;
  created_at: string;
  updated_at: string;
  version: number;
  price?: Money | null;
  deposit?: Money | null;
  vehicle?: ListingVehicleSummary;
  seller?: { id: ID; display_name: string };
  location?: { id: ID; name: string; city: string; timezone: string };
  price_history?: PriceVersion[];
  status_history?: StatusHistory[];
  validation?: Finding[] | { findings: Finding[] };
}

export interface PriceVersion {
  id: ID;
  amount_minor: number;
  currency: string;
  effective_from: string;
  effective_to: string | null;
  reason: string;
  source: string;
  created_by: ID | null;
  created_at: string;
}

export interface StatusHistory {
  id: ID;
  from_status: string | null;
  to_status: string;
  reason: string | null;
  actor_user_id: ID | null;
  actor_kind: string;
  request_id: string | null;
  occurred_at: string;
}

export interface Validation {
  listing_id: ID;
  publishable: boolean;
  findings: Finding[];
}

export interface Customer {
  id: ID;
  customer_type: string;
  given_name: string | null;
  family_name: string | null;
  business_name: string | null;
  display_name: string;
  email: string | null;
  phone: string | null;
  marketing_consent: boolean | null;
  status: string;
  erased_at: string | null;
  is_synthetic: boolean;
  created_by_organisation_id: ID | null;
  created_at: string;
  updated_at: string;
  version: number;
  addresses?: {
    id: ID; kind: string; line1: string; line2: string | null; city: string; region: string; postal_code: string;
    country_code: string; valid_from: string; valid_to: string | null;
  }[];
  relationships?: { organisation_id: ID; display_name: string; basis: string; first_interaction_at: string }[];
}

export interface QuoteLine {
  id: ID;
  line_no: number;
  line_type: string;
  code: string;
  description: string;
  amount_status: "known" | "unknown" | "not_applicable" | string;
  amount_minor: number | null;
  rate_bps: number | null;
  basis_minor: number | null;
  formatted: string | null;
}

export interface Quote {
  id: ID;
  quote_number: string;
  organisation_id: ID;
  listing_id: ID;
  vehicle_id: ID;
  customer_id: ID | null;
  session_reference: string | null;
  customer_region: string | null;
  currency: string;
  vehicle_price_minor: number;
  total_known_minor: number | null;
  total_minor: number | null;
  deposit_required_minor: number;
  deposit_treatment: string;
  is_complete: boolean;
  missing_charges: string[];
  snapshot: {
    seller?: { display_name: string; legal_name?: string };
    listing?: { title: string; asking_price_minor: number };
    vehicle?: { vin: string | null; specification?: Specification };
    location?: { name: string; region: string; timezone: string };
    terms?: { code: string; version: number };
    captured_at?: string;
  };
  snapshot_sha256: string;
  snapshot_verified?: boolean;
  status: string;
  effective_status?: string;
  is_expired?: boolean;
  issued_at: string;
  expires_at: string;
  lines: QuoteLine[];
  summary?: Record<string, string | null>;
  acceptance?: { accepted_at?: string; acceptance_channel?: string } | null;
}

export interface ReservationEvent {
  id: ID;
  event: string;
  from_status: string | null;
  to_status: string | null;
  detail: Record<string, unknown>;
  actor_user_id: ID | null;
  actor_kind: string;
  request_id: string | null;
  occurred_at: string;
  sale_order_id: ID | null;
}

export interface SaleOrder {
  id: ID;
  order_number: string;
  organisation_id: ID;
  sale_reservation_id: ID;
  vehicle_id: ID;
  customer_id: ID | null;
  quote_id: ID | null;
  currency: string;
  agreed_total_minor: number;
  status: string;
  agreement_signed_at: string | null;
  completed_at: string | null;
  cancelled_at: string | null;
  cancel_reason: string | null;
  created_at: string;
  updated_at: string;
  version: number;
  handovers?: { id: ID; location_id: ID; handed_over_at: string; odometer_value: number | null; odometer_unit: string | null; notes: string | null }[];
  net_received_minor?: number;
  balance_outstanding_minor?: number;
}

export interface Reservation {
  id: ID;
  reservation_number: string;
  organisation_id: ID;
  listing_id: ID;
  vehicle_id: ID;
  customer_id: ID | null;
  quote_id: ID | null;
  status: string;
  deposit_status: string;
  deposit_required_minor: number;
  currency: string;
  hold_expires_at: string | null;
  deposit_paid_at: string | null;
  accepted_at: string | null;
  ended_at: string | null;
  end_reason: string | null;
  created_at: string;
  updated_at: string;
  version: number;
  effective_status: string;
  seconds_remaining: number | null;
  deposit?: Money;
  events?: ReservationEvent[];
  sale_order?: SaleOrder | null;
  payments?: PaymentIntent[];
}

export interface TestDrive {
  id: ID;
  organisation_id: ID;
  location_id: ID;
  vehicle_id: ID;
  listing_id: ID | null;
  customer_id: ID | null;
  resource_id: ID;
  starts_at: string;
  ends_at: string;
  local_timezone: string;
  request_status: string;
  confirmation_status: string;
  availability_notice: string | null;
  cancelled_at: string | null;
  cancellation_reason: string | null;
  created_at: string;
  updated_at: string;
  version: number;
  local_start: string;
  local_end: string;
}

export interface Resource {
  id: ID;
  organisation_id: ID;
  location_id: ID;
  kind: string;
  name: string;
  capacity: number;
  status: string;
}

export interface RentalBooking {
  id: ID;
  booking_number: string;
  organisation_id: ID;
  customer_id: ID | null;
  category_id: ID;
  pickup_location_id: ID;
  return_location_id: ID;
  rental_quote_id: ID | null;
  pickup_at: string;
  return_at: string;
  pickup_timezone: string;
  return_timezone: string;
  status: string;
  total_minor: number;
  currency: string;
  cancelled_at: string | null;
  cancellation_reason: string | null;
  created_at: string;
  updated_at: string;
  version: number;
  local_pickup: string;
  local_return: string;
  total?: Money;
  assignments?: { id: ID; rental_asset_id: ID; is_upgrade?: boolean; assigned_range?: unknown; status?: string; [k: string]: unknown }[];
}

export interface RentalCategory {
  id: ID; organisation_id: ID; code: string; name: string; seats: number; transmission: string;
  turnaround_buffer: number; daily_rate_minor: number; currency: string; status: string;
}

export interface RentalAsset {
  id: ID; organisation_id: ID; vehicle_id: ID; category_id: ID; home_location_id: ID; fleet_number: string;
  status: string; in_fleet_from: string; in_fleet_to: string | null; version: number;
}

export interface PaymentIntent {
  id: ID;
  organisation_id: ID;
  provider: string;
  provider_intent_ref: string | null;
  purpose: string;
  sale_reservation_id: ID | null;
  sale_order_id: ID | null;
  rental_booking_id: ID | null;
  customer_id: ID | null;
  amount_minor: number;
  currency: string;
  status: string;
  last_provider_event_at: string | null;
  failure_code: string | null;
  idempotency_key: string | null;
  created_at: string;
  updated_at: string;
  version: number;
  transactions?: { id: ID; kind: string; amount_minor: number; currency: string; status?: string; provider_ref?: string; occurred_at?: string; created_at?: string; [k: string]: unknown }[];
  events?: {
    id: ID; provider_event_id: string; event_type: string; provider_created_at: string; received_at: string;
    signature_verified: boolean; processing_status: string; processing_note: string | null;
  }[];
  refunds?: Refund[];
  cases?: ReconciliationCase[];
}

export interface Refund {
  id: ID;
  organisation_id: ID;
  payment_intent_id: ID;
  amount_minor: number;
  currency: string;
  reason: string;
  status: string;
  provider_refund_ref: string | null;
  reconciliation_case_id: ID | null;
  failure_code: string | null;
  requested_at: string;
  completed_at: string | null;
  version: number;
}

export interface ReconciliationCase {
  id: ID;
  case_number: string;
  organisation_id: ID | null;
  case_type: string;
  status: string;
  severity: string;
  payment_intent_id: ID | null;
  payment_transaction_id: ID | null;
  payment_event_id: ID | null;
  refund_id: ID | null;
  sale_reservation_id: ID | null;
  rental_booking_id: ID | null;
  expected_amount_minor: number | null;
  observed_amount_minor: number | null;
  currency: string | null;
  summary: string | null;
  details: Record<string, unknown> | null;
  resolution: string | null;
  resolution_note: string | null;
  opened_at: string;
  resolved_at: string | null;
  updated_at: string;
  version: number;
}

export interface MaintenanceBlock {
  id: ID; organisation_id: ID; rental_asset_id: ID; kind: string; starts_at: string; ends_at: string;
  status: string; reason: string; version: number;
}

export interface Assertion {
  id: ID; vehicle_id: ID; organisation_id: ID | null; attribute: string; assertion_type: string; value: unknown;
  unit: string | null; source: string; source_reference: string | null; effective_at: string | null;
  verification_status: string; supersedes_id: ID | null; recorded_by: ID | null; recorded_at: string;
}

export interface Feature {
  id: ID; vehicle_id: ID; feature_code: string; label: string | null; assertion_type: string; source: string;
  verification_status: string; recorded_at: string;
}

export interface ImportJob {
  id: ID;
  organisation_id: ID;
  source_namespace: string;
  format: string;
  mode: string;
  status: string;
  original_filename: string;
  file_sha256: string;
  byte_size: number;
  options: Record<string, unknown>;
  row_count: number;
  valid_count: number;
  warning_count: number;
  invalid_count: number;
  applied_count: number;
  no_change_count: number;
  skipped_count: number;
  error_summary: unknown;
  uploaded_at: string;
  validated_at: string | null;
  approved_at: string | null;
  applied_at: string | null;
  version: number;
  findings_summary?: { code: string; severity: string; rows: number }[];
  planned_actions?: Record<string, number>;
  duplicate_upload?: boolean;
}

export interface ImportRow {
  id: ID;
  row_number: number;
  source_record_id: string | null;
  raw: Record<string, unknown>;
  normalized: Record<string, unknown> | null;
  status: string;
  findings: Finding[];
  planned_action: string | null;
  match_method: string | null;
  matched_vehicle_id: ID | null;
  matched_listing_id: ID | null;
  result: unknown;
}

export interface AuditEvent {
  id: number;
  occurred_at: string;
  request_id: string | null;
  actor_user_id: ID | null;
  actor_kind: string;
  actor_organisation_id: ID | null;
  organisation_id: ID | null;
  action: string;
  target_type: string;
  target_id: string;
  changes: Record<string, unknown> | null;
  metadata: Record<string, unknown> | null;
}

export interface OutboxEvent {
  id: ID;
  organisation_id: ID | null;
  aggregate_type: string;
  aggregate_id: string;
  event_type: string;
  payload: Record<string, unknown>;
  status: string;
  attempts: number;
  max_attempts: number;
  available_at: string;
  last_error: string | null;
  request_id: string | null;
  created_at: string;
  published_at: string | null;
}

export interface Location {
  id: ID;
  organisation_id: ID;
  code: string;
  name: string;
  kind: string;
  address_line1: string | null;
  city: string;
  region: string;
  postal_code: string | null;
  country_code: string;
  timezone: string;
  status: string;
  point: { lat: number; lon: number } | null;
}

export interface Organisation {
  id: ID;
  kind: string;
  legal_name?: string;
  display_name: string;
  slug: string;
  status: string;
  default_currency: string;
  default_timezone: string;
  listing_freshness_warn_after?: number | null;
  listing_freshness_suspend_after?: number | null;
  listing_freshness_action?: string;
  sale_hold_duration?: number;
  deposit_hold_extension?: number;
  is_synthetic?: boolean;
  version?: number;
  locations?: Location[];
  members?: { id: ID; display_name: string; email: string; role: string; status: string }[];
}

export interface MergeProposal {
  id: ID;
  organisation_id: ID;
  primary_vehicle_id: ID;
  duplicate_vehicle_id: ID;
  score: number | string | null;
  evidence: Record<string, unknown> | null;
  status: string;
  decided_at: string | null;
  decision_note: string | null;
  version: number;
  created_at: string;
}

export interface SavedFilter {
  id: ID;
  page: string;
  name: string;
  params: Record<string, unknown>;
}
