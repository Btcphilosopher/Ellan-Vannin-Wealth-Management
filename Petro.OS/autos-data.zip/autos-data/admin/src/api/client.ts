// Thin fetch wrapper for the Autos Data API.
// - relative /v1 URLs (proxied by Vite in dev, nginx in production)
// - bearer token + optional X-Organisation-Id from sessionStorage
// - RFC 9457 problem+json -> ApiError
// - If-Match / Idempotency-Key helpers

const TOKEN_KEY = "autosdata.token";
const ORG_KEY = "autosdata.org";

export const session = {
  get token(): string | null {
    try { return sessionStorage.getItem(TOKEN_KEY); } catch { return null; }
  },
  set token(v: string | null) {
    try { v ? sessionStorage.setItem(TOKEN_KEY, v) : sessionStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ }
  },
  get org(): string | null {
    try { return sessionStorage.getItem(ORG_KEY); } catch { return null; }
  },
  set org(v: string | null) {
    try { v ? sessionStorage.setItem(ORG_KEY, v) : sessionStorage.removeItem(ORG_KEY); } catch { /* ignore */ }
  },
};

export interface ProblemFieldError {
  field?: string;
  severity?: string;
  code?: string;
  message?: string;
}

export class ApiError extends Error {
  status: number;
  code: string;
  title: string;
  detail: string;
  errors: ProblemFieldError[];
  requestId: string | null;
  body: Record<string, unknown>;

  constructor(status: number, body: Record<string, unknown>, requestId: string | null) {
    const detail = String(body.detail ?? body.title ?? `HTTP ${status}`);
    super(detail);
    this.status = status;
    this.code = String(body.code ?? (status === 0 ? "network_error" : `http_${status}`));
    this.title = String(body.title ?? "Request failed");
    this.detail = detail;
    this.errors = Array.isArray(body.errors) ? (body.errors as ProblemFieldError[]) : [];
    this.requestId = (body.request_id as string) ?? requestId;
    this.body = body;
  }

  get isVersionConflict(): boolean {
    return this.status === 409 && this.code === "version_conflict";
  }
}

export function isApiError(e: unknown): e is ApiError {
  return e instanceof ApiError;
}

/** Fired when the API says the token is no longer valid. */
export const authEvents = new EventTarget();

type Query = Record<string, string | number | boolean | null | undefined>;

export interface RequestOptions {
  method?: string;
  query?: Query;
  body?: unknown;
  form?: FormData | URLSearchParams;
  /** record version; sent as If-Match: "<version>" */
  ifMatch?: number | string | null;
  idempotencyKey?: string;
  signal?: AbortSignal;
  /** do not send X-Organisation-Id */
  noOrg?: boolean;
  noAuth?: boolean;
}

export interface ApiResponse<T> {
  data: T;
  status: number;
  etag: string | null;
  version: number | null;
  headers: Headers;
}

export function buildQuery(q?: Query): string {
  if (!q) return "";
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(q)) {
    if (v === undefined || v === null || v === "") continue;
    p.set(k, String(v));
  }
  const s = p.toString();
  return s ? `?${s}` : "";
}

export async function request<T = unknown>(path: string, opts: RequestOptions = {}): Promise<ApiResponse<T>> {
  const headers: Record<string, string> = { Accept: "application/json, application/problem+json" };
  const token = session.token;
  if (token && !opts.noAuth) headers.Authorization = `Bearer ${token}`;
  const org = session.org;
  if (org && !opts.noOrg && !opts.noAuth) headers["X-Organisation-Id"] = org;
  if (opts.ifMatch !== undefined && opts.ifMatch !== null) headers["If-Match"] = `"${opts.ifMatch}"`;
  if (opts.idempotencyKey) headers["Idempotency-Key"] = opts.idempotencyKey;
  let body: BodyInit | undefined;
  if (opts.form) {
    body = opts.form;
  } else if (opts.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }
  const url = path + buildQuery(opts.query);
  let res: Response;
  try {
    res = await fetch(url, { method: opts.method ?? (body ? "POST" : "GET"), headers, body, signal: opts.signal });
  } catch (e) {
    if ((e as Error)?.name === "AbortError") throw e;
    throw new ApiError(0, { code: "network_error", title: "Network error", detail: "The API could not be reached. Is the backend running?" }, null);
  }
  const requestId = res.headers.get("x-request-id");
  const text = res.status === 204 ? "" : await res.text();
  let parsed: unknown = null;
  if (text) {
    try { parsed = JSON.parse(text); } catch { parsed = text; }
  }
  if (!res.ok) {
    const b = parsed && typeof parsed === "object" ? (parsed as Record<string, unknown>) : { detail: String(parsed || res.statusText) };
    // FastAPI default 422 shape {detail: [...]} -> normalise
    if (Array.isArray(b.detail)) {
      b.errors = (b.detail as { loc?: unknown[]; msg?: string; type?: string }[]).map((d) => ({
        field: (d.loc ?? []).join("."), code: d.type, message: d.msg,
      }));
      b.detail = "request did not match the contract";
      b.code = b.code ?? "validation_failed";
    }
    const err = new ApiError(res.status, b, requestId);
    if (res.status === 401 && !opts.noAuth) authEvents.dispatchEvent(new Event("unauthorized"));
    throw err;
  }
  const etag = res.headers.get("etag");
  let version: number | null = null;
  if (etag) {
    const n = parseInt(etag.replace(/^W\//, "").replace(/"/g, ""), 10);
    version = Number.isFinite(n) ? n : null;
  }
  if (version === null && parsed && typeof parsed === "object" && typeof (parsed as { version?: unknown }).version === "number") {
    version = (parsed as { version: number }).version;
  }
  return { data: parsed as T, status: res.status, etag, version, headers: res.headers };
}

export async function get<T = unknown>(path: string, query?: Query, signal?: AbortSignal): Promise<T> {
  return (await request<T>(path, { query, signal })).data;
}

export async function post<T = unknown>(path: string, body?: unknown, opts: Omit<RequestOptions, "body"> = {}): Promise<T> {
  return (await request<T>(path, { ...opts, method: "POST", body: body === undefined ? {} : body })).data;
}

export async function patch<T = unknown>(path: string, body: unknown, ifMatch: number | null | undefined): Promise<T> {
  return (await request<T>(path, { method: "PATCH", body, ifMatch })).data;
}

export async function del(path: string): Promise<void> {
  await request(path, { method: "DELETE" });
}

/** RFC 4122 v4 UUID; works in insecure contexts too (crypto.randomUUID needs a secure context). */
export function uuid(): string {
  const c = globalThis.crypto;
  if (c && typeof c.randomUUID === "function") {
    try { return c.randomUUID(); } catch { /* fall through */ }
  }
  const b = new Uint8Array(16);
  c.getRandomValues(b);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}
