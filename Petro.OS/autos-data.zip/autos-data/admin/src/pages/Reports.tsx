import { useState, type ReactNode } from "react";
import { useSearchParams } from "react-router-dom";
import { Banner, ErrorPanel, Field, Section, Spinner, StatusPill, Tabs } from "../components/ui";
import { useApp } from "../lib/app";
import { humanize, money, num } from "../lib/format";
import { useResource } from "../lib/hooks";
import { useOrgLookups } from "../lib/lookups";

const REPORTS = [
  { id: "inventory", label: "Inventory" },
  { id: "reservations", label: "Reservations" },
  { id: "payments", label: "Payments" },
  { id: "rentals", label: "Rentals" },
  { id: "imports", label: "Imports" },
  { id: "data-quality", label: "Data quality" },
];

type Row = Record<string, unknown>;

const STATUSY = /(^|_)(status|state|result|kind|severity)$/;

function cell(key: string, row: Row): ReactNode {
  const v = row[key];
  if (v === null || v === undefined) return <span className="muted">—</span>;
  if (/_minor$/.test(key)) return <span className="num">{money(v as string | number, (row.currency as string) || "USD")}</span>;
  if (STATUSY.test(key) && typeof v === "string") return <StatusPill value={v} />;
  if (/_pct$/.test(key)) return <span className="num">{String(v)}%</span>;
  if (typeof v === "number" || (typeof v === "string" && /^-?\d+$/.test(v))) return <span className="num">{num(v as number)}</span>;
  if (typeof v === "boolean") return v ? "yes" : "no";
  if (typeof v === "object") return <code>{JSON.stringify(v)}</code>;
  return String(v);
}

function ReportTable({ name, rows }: { name: string; rows: Row[] }) {
  const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))];
  const numeric = (k: string) => rows.every((r) => r[k] === null || typeof r[k] === "number" || (typeof r[k] === "string" && /^-?\d+(\.\d+)?$/.test(r[k] as string)));
  return (
    <Section title={<>{humanize(name)} <span className="muted small">({rows.length} row{rows.length === 1 ? "" : "s"})</span></>}>
      {rows.length === 0 ? <div className="empty">No data.</div> : (
        <div className="table-scroll">
          <table className="grid grid-compact">
            <thead><tr>{cols.map((c) => <th key={c} style={{ textAlign: numeric(c) ? "right" : undefined }}>{humanize(c)}</th>)}</tr></thead>
            <tbody>{rows.map((r, i) => (
              <tr key={i} className={name === "checks" && Number(r.n) > 0 ? "row-warn" : undefined}>
                {cols.map((c) => <td key={c} style={{ textAlign: numeric(c) ? "right" : undefined }}>{cell(c, r)}</td>)}
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
    </Section>
  );
}

export function Reports() {
  const { me } = useApp();
  const { organisations } = useOrgLookups();
  const [params, setParams] = useSearchParams();
  const name = params.get("report") ?? "inventory";
  const [org, setOrg] = useState("");
  const rep = useResource<Record<string, unknown>>(`/v1/reports/${name}`, { organisation_id: org || undefined });
  const data = rep.data ?? {};
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Reports</h1><p className="muted">Operational reports, tenant-scoped by row-level security. Dealers report on their own data.</p></div>
        {me?.is_platform ? (
          <div className="page-actions"><Field label="Organisation"><select value={org} onChange={(e) => setOrg(e.target.value)}>
            <option value="">All (platform)</option>{organisations.map((o) => <option key={o.id} value={o.id}>{o.display_name}</option>)}
          </select></Field></div>
        ) : null}
      </div>
      <Tabs tabs={REPORTS} active={name} onChange={(t) => { const p = new URLSearchParams(params); p.set("report", t); setParams(p); }} />
      {rep.error ? <ErrorPanel error={rep.error} onReload={rep.reload} /> : null}
      {rep.loading && !rep.data ? <Spinner /> : null}
      {rep.data && Object.keys(data).length === 0 ? <Banner kind="info">This report returned no sections.</Banner> : null}
      <div className="report-grid">
        {Object.entries(data).map(([k, v]) => (Array.isArray(v) ? <ReportTable key={k} name={k} rows={v as Row[]} /> : (
          <Section key={k} title={humanize(k)}><code>{JSON.stringify(v)}</code></Section>
        )))}
      </div>
    </div>
  );
}
