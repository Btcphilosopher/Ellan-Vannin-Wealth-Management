import { useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { post } from "../api/client";
import type { AuditEvent, OutboxEvent } from "../api/types";
import { DataTable } from "../components/DataTable";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { renderChanges } from "../components/History";
import { ActionButton, CopyId, Field, JsonView, Mono, StatusPill, Tabs } from "../components/ui";
import { useOrgName } from "../lib/app";
import { dateTime, humanize } from "../lib/format";
import { useAction, usePaged, useResource } from "../lib/hooks";
import { RecordLink, useOpenRecord, type RecordType } from "../lib/nav";

export const TARGET_TYPES = ["vehicle", "listing", "customer", "quote", "sale_reservation", "sale_order", "test_drive_appointment", "rental_booking",
  "payment_intent", "refund", "reconciliation_case", "import_job", "maintenance_block", "outbox_event", "vehicle_merge_proposal"];

const TARGET_TO_RECORD: Record<string, RecordType> = {
  vehicle: "vehicle", listing: "listing", customer: "customer", quote: "quote", sale_reservation: "reservation", sale_order: "sale_order",
  test_drive_appointment: "test_drive", rental_booking: "rental_booking", payment_intent: "payment", refund: "refund",
  reconciliation_case: "reconciliation_case", import_job: "import_job",
};

const AUDIT_INITIAL = { action: "", target_type: "", target_id: "", request_id: "" };

export function Audit() {
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") ?? "events";
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Audit</h1><p className="muted">Append-only audit trail (tenant-scoped) and the transactional outbox / dead-letter queue. Records here cannot be edited.</p></div>
      </div>
      <Tabs tabs={[{ id: "events", label: "Audit events" }, { id: "outbox", label: "Outbox" }]} active={tab}
        onChange={(t) => { const p = new URLSearchParams(); p.set("tab", t); setParams(p); }} />
      {tab === "outbox" ? <Outbox initialStatus={params.get("status") ?? ""} /> : <AuditEvents />}
    </div>
  );
}

function AuditEvents() {
  const filters = useFilters(AUDIT_INITIAL);
  const list = usePaged<AuditEvent>("/v1/audit-events", toQuery(filters.applied), { cursorParam: "before_id", limit: 100 });
  const orgName = useOrgName();
  const open = useOpenRecord();
  return <>
    <FilterBar page="audit" filters={filters}>
      <Field label="Action"><input {...filters.bind("action")} placeholder="listing.published" size={20} /></Field>
      <Field label="Target type"><select {...filters.bind("target_type")}>
        <option value="">any</option>{TARGET_TYPES.map((t) => <option key={t}>{t}</option>)}
      </select></Field>
      <Field label="Target id"><input className="mono" {...filters.bind("target_id")} placeholder="uuid" size={36} /></Field>
      <Field label="Request id"><input className="mono" {...filters.bind("request_id")} placeholder="x-request-id" size={32} /></Field>
    </FilterBar>
    <DataTable rows={list.items} rowKey={(e) => String(e.id)} loading={list.loading} error={list.error} onRetry={list.reload}
      hasMore={list.hasMore} onLoadMore={list.loadMore}
      onRowClick={(e) => { const rt = TARGET_TO_RECORD[e.target_type]; if (rt) open(rt, e.target_id); }}
      columns={[
        { key: "id", header: "#", align: "right", render: (e) => <Mono>{e.id}</Mono>, width: 50 },
        { key: "t", header: "When", render: (e) => dateTime(e.occurred_at), width: 160 },
        { key: "a", header: "Action", render: (e) => <Mono>{e.action}</Mono> },
        { key: "tt", header: "Target", render: (e) => {
          const rt = TARGET_TO_RECORD[e.target_type];
          return <>{humanize(e.target_type)} {rt ? <RecordLink type={rt} id={e.target_id} /> : <CopyId id={e.target_id} />}</>;
        } },
        { key: "c", header: "Changes", render: (e) => renderChanges(e.changes) },
        { key: "who", header: "Actor", render: (e) => <>{humanize(e.actor_kind)} {e.actor_user_id ? <CopyId id={e.actor_user_id} /> : null}</> },
        { key: "o", header: "Organisation", render: (e) => orgName(e.organisation_id) },
        { key: "r", header: "Request", render: (e) => (e.request_id ? <button type="button" className="linklike mono" title="Filter by this request id"
          onClick={() => filters.apply({ ...AUDIT_INITIAL, request_id: e.request_id! })}>{e.request_id.slice(0, 10)}…</button> : <span className="muted">—</span>) },
        { key: "m", header: "Meta", render: (e) => (e.metadata && Object.keys(e.metadata).length ? <details><summary>view</summary><JsonView value={e.metadata} /></details> : "") },
      ]} />
  </>;
}

function Outbox({ initialStatus }: { initialStatus: string }) {
  const initial = useMemo(() => ({ status: initialStatus }), [initialStatus]);
  const filters = useFilters(initial);
  const list = useResource<{ items: OutboxEvent[] }>("/v1/outbox-events", toQuery(filters.applied));
  const { run, busy } = useAction();
  const orgName = useOrgName();
  return <>
    <FilterBar page="outbox" filters={filters}>
      <Field label="Status"><select {...filters.bind("status")}>
        <option value="">any</option>{["pending", "published", "dead"].map((s) => <option key={s}>{s}</option>)}
      </select></Field>
    </FilterBar>
    <DataTable rows={list.data?.items ?? []} rowKey={(e) => e.id} loading={list.loading} error={list.error} onRetry={list.reload}
      empty="No outbox events with this status (latest 200 shown)."
      columns={[
        { key: "c", header: "Created", render: (e) => dateTime(e.created_at, true) },
        { key: "t", header: "Event", render: (e) => <Mono>{e.event_type}</Mono> },
        { key: "ag", header: "Aggregate", render: (e) => {
          const rt = TARGET_TO_RECORD[e.aggregate_type];
          return <>{humanize(e.aggregate_type)} {rt ? <RecordLink type={rt} id={e.aggregate_id} /> : <CopyId id={e.aggregate_id} />}</>;
        } },
        { key: "s", header: "Status", render: (e) => <StatusPill value={e.status} /> },
        { key: "at", header: "Attempts", align: "right", render: (e) => `${e.attempts}/${e.max_attempts}` },
        { key: "av", header: "Available at", render: (e) => dateTime(e.available_at, true) },
        { key: "p", header: "Published", render: (e) => dateTime(e.published_at, true) },
        { key: "err", header: "Last error", render: (e) => (e.last_error ? <span className="txt-bad small">{e.last_error}</span> : "") },
        { key: "o", header: "Organisation", render: (e) => orgName(e.organisation_id) },
        { key: "pl", header: "Payload", render: (e) => <details><summary>view</summary><JsonView value={e.payload} /></details> },
        { key: "act", header: "", render: (e) => (e.status === "dead" ? (
          <ActionButton perm="outbox.manage" org={e.organisation_id} small variant="primary" busy={busy === `Requeue ${e.id}`}
            onClick={() => run(`Requeue ${e.id}`, () => post(`/v1/outbox-events/${e.id}/requeue`), { success: "Event requeued" })}>Requeue</ActionButton>
        ) : null) },
      ]} />
  </>;
}
