import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { post } from "../api/client";
import type { Customer, Listing, Page, Quote } from "../api/types";
import { DataTable } from "../components/DataTable";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { ActionButton, Amount, Button, Field, Mono, StatusPill } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime } from "../lib/format";
import { useAction, useIdempotencyKey, usePaged, useResource } from "../lib/hooks";
import { useOrgLookups } from "../lib/lookups";
import { parseOpen, useOpenRecord } from "../lib/nav";

const INITIAL = { organisation_id: "", customer_id: "" };

// No API endpoint lists charge rules; these are hints only — the server
// validates codes and rejects unknown ones (unknown_reference).
const KNOWN_PRODUCTS = ["paint_protection", "ext_warranty_5y", "all_weather_mats"];
const KNOWN_PROMOS = ["winter500"];
const REGIONS = ["US-OR", "US-CO", "US-WA", "US-CA"];

export function Quotes() {
  const filters = useFilters(INITIAL);
  const [params, setParams] = useSearchParams();
  const list = usePaged<Quote>("/v1/quotes", toQuery(filters.applied), { limit: 50 });
  const { organisations } = useOrgLookups();
  const orgName = useOrgName();
  const open = useOpenRecord();
  const active = parseOpen(params.get("open"));
  const creating = params.get("new") === "1";
  const setCreating = (v: boolean) => {
    const p = new URLSearchParams(params);
    if (v) p.set("new", "1"); else { p.delete("new"); p.delete("listing"); }
    setParams(p);
  };
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Quotes</h1><p className="muted">Immutable, itemised price quotes. Unknown taxes or registration make a quote incomplete — no total is stated.</p></div>
        <div className="page-actions"><ActionButton perm="quotes.issue" variant="primary" small onClick={() => setCreating(!creating)}>Issue quote</ActionButton></div>
      </div>
      {creating ? <IssueQuote initialListing={params.get("listing") ?? ""} onCancel={() => setCreating(false)} onDone={(q) => {
        const p = new URLSearchParams(params); p.delete("new"); p.delete("listing"); p.set("open", `quote:${q.id}`); setParams(p);
      }} /> : null}
      <FilterBar page="quotes" filters={filters}>
        <Field label="Seller"><select {...filters.bind("organisation_id")}>
          <option value="">any</option>{organisations.filter((o) => o.kind === "dealer").map((o) => <option key={o.id} value={o.id}>{o.display_name}</option>)}
        </select></Field>
        <Field label="Customer id"><input size={36} className="mono" placeholder="uuid" {...filters.bind("customer_id")} /></Field>
      </FilterBar>
      <DataTable rows={list.items} rowKey={(q) => q.id} loading={list.loading} error={list.error} onRetry={list.reload}
        hasMore={list.hasMore} onLoadMore={list.loadMore} onRowClick={(q) => open("quote", q.id)} activeKey={active?.type === "quote" ? active.id : null}
        columns={[
          { key: "n", header: "Quote", render: (q) => <Mono>{q.quote_number}</Mono> },
          { key: "v", header: "Vehicle", render: (q) => q.snapshot.vehicle?.specification?.label ?? q.snapshot.listing?.title },
          { key: "s", header: "Seller", render: (q) => q.snapshot.seller?.display_name ?? orgName(q.organisation_id) },
          { key: "r", header: "Region", render: (q) => <Mono>{q.customer_region ?? "—"}</Mono> },
          { key: "p", header: "Vehicle price", align: "right", render: (q) => <Amount minor={q.vehicle_price_minor} currency={q.currency} /> },
          { key: "t", header: "Total", align: "right", render: (q) => (q.is_complete ? <Amount minor={q.total_minor} currency={q.currency} /> : <span title={`missing: ${q.missing_charges.join(", ")}`} className="pill pill-amber">incomplete</span>) },
          { key: "k", header: "Known so far", align: "right", render: (q) => <Amount minor={q.total_known_minor} currency={q.currency} /> },
          { key: "d", header: "Deposit", align: "right", render: (q) => <Amount minor={q.deposit_required_minor} currency={q.currency} /> },
          { key: "st", header: "Status", render: (q) => <StatusPill value={q.effective_status ?? q.status} /> },
          { key: "i", header: "Issued", render: (q) => dateTime(q.issued_at, true) },
          { key: "e", header: "Expires", render: (q) => dateTime(q.expires_at, true) },
        ]} />
    </div>
  );
}

function IssueQuote({ initialListing, onDone, onCancel }: { initialListing: string; onDone(q: Quote): void; onCancel(): void }) {
  const { can } = useApp();
  const listings = useResource<Page<Listing>>("/v1/listings", { status: "published", limit: 200 });
  const customers = useResource<Page<Customer>>("/v1/customers", { limit: 200 });
  const [listingId, setListingId] = useState(initialListing);
  const [customerId, setCustomerId] = useState("");
  const [region, setRegion] = useState("");
  const [products, setProducts] = useState<string[]>([]);
  const [extraProducts, setExtraProducts] = useState("");
  const [promos, setPromos] = useState("");
  const [delivery, setDelivery] = useState(false);
  const [validity, setValidity] = useState("");
  const { run, busy } = useAction();
  const idem = useIdempotencyKey();
  const issuable = (listings.data?.items ?? []).filter((l) => can("quotes.issue", l.organisation_id));
  const selected = issuable.find((l) => l.id === listingId);
  useEffect(() => { if (initialListing) setListingId(initialListing); }, [initialListing]);
  const toggle = (c: string) => setProducts(products.includes(c) ? products.filter((x) => x !== c) : [...products, c]);
  return (
    <form className="form-box" onSubmit={async (e) => {
      e.preventDefault();
      const product_codes = [...products, ...extraProducts.split(",").map((s) => s.trim()).filter(Boolean)];
      const body = {
        listing_id: listingId, customer_id: customerId || null, customer_region: region.trim() || null,
        product_codes, promo_codes: promos.split(",").map((s) => s.trim().toLowerCase()).filter(Boolean),
        delivery_requested: delivery, validity_hours: validity ? parseInt(validity, 10) : null,
      };
      const q = await run("Issue quote", () => post<Quote>("/v1/quotes", body, { idempotencyKey: idem.keyFor(body) }), { success: "Quote issued" });
      if (q) { idem.complete(); onDone(q); }
    }}>
      <h4>Issue quote <span className="muted small">(snapshots listing, vehicle, seller and price; Idempotency-Key sent)</span></h4>
      <div className="form-row">
        <Field label="Listing (published)" wide>
          <select required value={listingId} onChange={(e) => setListingId(e.target.value)}>
            <option value="">{listings.loading ? "Loading…" : "Select a listing…"}</option>
            {issuable.map((l) => <option key={l.id} value={l.id}>{l.title} — {l.price?.formatted} — {l.seller?.display_name} ({l.location?.city})</option>)}
          </select>
        </Field>
        <Field label="Customer">
          <select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
            <option value="">anonymous (no customer)</option>
            {(customers.data?.items ?? []).map((c) => <option key={c.id} value={c.id}>{c.display_name}</option>)}
          </select>
        </Field>
        <Field label="Customer region" hint="ISO 3166-2, e.g. US-OR, US-CO">
          <input list="regions" value={region} onChange={(e) => setRegion(e.target.value.toUpperCase())} placeholder="US-OR" size={8} pattern="[A-Z]{2}(-[A-Z0-9]{1,3})?" />
          <datalist id="regions">{REGIONS.map((r) => <option key={r} value={r} />)}</datalist>
        </Field>
      </div>
      <div className="form-row">
        <fieldset className="checks">
          <legend>Optional products</legend>
          {KNOWN_PRODUCTS.map((c) => <label key={c} className="check"><input type="checkbox" checked={products.includes(c)} onChange={() => toggle(c)} /> <Mono>{c}</Mono></label>)}
          <input placeholder="other codes, comma-separated" value={extraProducts} onChange={(e) => setExtraProducts(e.target.value)} size={24} />
        </fieldset>
        <Field label="Promo codes" hint={`e.g. ${KNOWN_PROMOS.join(", ")}`}><input value={promos} onChange={(e) => setPromos(e.target.value)} size={14} /></Field>
        <label className="check"><input type="checkbox" checked={delivery} onChange={(e) => setDelivery(e.target.checked)} /> Delivery requested</label>
        <Field label="Validity (hours)"><input type="number" min={1} max={720} value={validity} onChange={(e) => setValidity(e.target.value)} placeholder="default" size={6} /></Field>
      </div>
      {selected ? <p className="muted small">Asking price {selected.price?.formatted}; deposit {selected.deposit?.formatted} is part of the price, not added on top.</p> : null}
      <div className="form-actions"><Button type="submit" variant="primary" busy={busy === "Issue quote"} disabled={!listingId}>Issue quote</Button><Button variant="ghost" onClick={onCancel}>Cancel</Button></div>
    </form>
  );
}
