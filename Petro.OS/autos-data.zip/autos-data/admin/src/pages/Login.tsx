import { useState } from "react";
import { ApiError } from "../api/client";
import { ProblemDetails, Toasts } from "../components/ui";
import { useApp } from "../lib/app";

const SEEDED = [
  { email: "ops@autos-data.example", role: "platform_admin", org: "Platform Operations" },
  { email: "admin@harbourview.example", role: "dealer_admin", org: "Harbourview Motors" },
  { email: "sales@harbourview.example", role: "dealer_staff", org: "Harbourview Motors" },
  { email: "finance@harbourview.example", role: "finance", org: "Harbourview Motors" },
  { email: "admin@ridgeline.example", role: "dealer_admin", org: "Ridgeline Auto Group" },
  { email: "admin@cityline.example", role: "rental_admin", org: "Cityline Rentals" },
  { email: "agent@cityline.example", role: "rental_agent", org: "Cityline Rentals" },
  { email: "auditor@autos-data.example", role: "auditor", org: "Harbourview Motors" },
];

export function Login() {
  const { branding, login } = useApp();
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const submit = async (e?: string) => {
    const addr = (e ?? email).trim();
    if (!addr) return;
    setBusy(true);
    setError(null);
    try {
      await login(addr);
    } catch (err) {
      setError(err as ApiError);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-brand">
          <div className="brand-name">{branding?.name ?? "…"}</div>
          <div className="brand-product">{branding?.product}</div>
          <div className="login-sub">Staff administration · operational database</div>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); void submit(); }} className="login-form">
          <label className="field">
            <span className="field-label">Work email</span>
            <input type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@organisation.example" autoFocus />
          </label>
          <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
          {branding && !branding.dev_auth_enabled ? <p className="muted small">Development sign-in is disabled on this server.</p> : null}
        </form>
        {error ? <div className="error-panel"><div className="error-title">Sign-in failed</div><ProblemDetails error={error} /></div> : null}
        <div className="login-seeded">
          <div className="field-label">Seeded staff accounts (development token issuer)</div>
          <table className="grid grid-compact">
            <tbody>
              {SEEDED.map((s) => (
                <tr key={s.email} className="clickable" onClick={() => { setEmail(s.email); void submit(s.email); }}>
                  <td className="mono">{s.email}</td><td><span className="tag">{s.role}</span></td><td className="muted">{s.org}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="disclaimer login-disclaimer">{branding?.disclaimer}</p>
      </div>
      <Toasts />
    </div>
  );
}
