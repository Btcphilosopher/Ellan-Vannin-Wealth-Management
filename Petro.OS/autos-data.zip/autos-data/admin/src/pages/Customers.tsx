import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { post } from "../api/client";
import type { Customer } from "../api/types";
import { DataTable } from "../components/DataTable";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { ActionButton, Button, Check, Field, Mono, StatusPill } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime, humanize } from "../lib/format";
import { useAction, useIdempotencyKey, usePaged } from "../lib/hooks";
import { parseOpen, useOpenRecord } from "../lib/nav";

const INITIAL = { q: "" };

export function Customers() {
  const filters = useFilters(INITIAL);
  const list = usePaged<Customer>("/v1/customers", toQuery(filters.applied), { limit: 50 });
  const orgName = useOrgName();
  const open = useOpenRecord();
  const [params] = useSearchParams();
  const active = parseOpen(params.get("open"));
  const [creating, setCreating] = useState(false);
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Customers</h1><p className="muted">Relationship-scoped: you only see customers who have dealt with your organisation.</p></div>
        <div className="page-actions"><ActionButton perm="customers.write" variant="primary" small onClick={() => setCreating(!creating)}>New customer</ActionButton></div>
      </div>
      {creating ? <CreateCustomer onDone={(c) => { setCreating(false); open("customer", c.id); }} onCancel={() => setCreating(false)} /> : null}
      <FilterBar page="customers" filters={filters}>
        <Field label="Search"><input type="search" size={30} placeholder="name, email or phone" {...filters.bind("q")} /></Field>
      </FilterBar>
      <DataTable rows={list.items} rowKey={(c) => c.id} loading={list.loading} error={list.error} onRetry={list.reload}
        hasMore={list.hasMore} onLoadMore={list.loadMore} onRowClick={(c) => open("customer", c.id)} activeKey={active?.type === "customer" ? active.id : null}
        columns={[
          { key: "n", header: "Name", render: (c) => <span className="cell-title">{c.display_name}</span> },
          { key: "t", header: "Type", render: (c) => humanize(c.customer_type) },
          { key: "e", header: "Email", render: (c) => c.email ?? <span className="muted">—</span> },
          { key: "p", header: "Phone", render: (c) => <Mono>{c.phone ?? "—"}</Mono> },
          { key: "m", header: "Marketing", render: (c) => <Check value={c.marketing_consent} /> },
          { key: "o", header: "Created by", render: (c) => orgName(c.created_by_organisation_id) },
          { key: "s", header: "Status", render: (c) => <StatusPill value={c.status} /> },
          { key: "c", header: "Created", render: (c) => dateTime(c.created_at, true) },
        ]} />
    </div>
  );
}

function CreateCustomer({ onDone, onCancel }: { onDone(c: Customer): void; onCancel(): void }) {
  const { me, activeOrg } = useApp();
  const [f, setF] = useState({ customer_type: "individual", given_name: "", family_name: "", business_name: "", email: "", phone: "", marketing_consent: false });
  const { run, busy } = useAction();
  const idem = useIdempotencyKey();
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  const orgs = (me?.memberships ?? []).filter((m) => m.permissions.includes("customers.write") || me?.is_platform);
  const [org, setOrg] = useState(activeOrg ?? orgs[0]?.organisation_id ?? "");
  return (
    <form className="form-box" onSubmit={async (e) => {
      e.preventDefault();
      const display = f.customer_type === "business" ? f.business_name : `${f.given_name} ${f.family_name}`.trim();
      const body = {
        organisation_id: org || null, customer_type: f.customer_type, display_name: display,
        given_name: f.given_name || null, family_name: f.family_name || null, business_name: f.business_name || null,
        email: f.email || null, phone: f.phone || null, marketing_consent: f.marketing_consent,
      };
      const c = await run("Create customer", () => post<Customer>("/v1/customers", body, { idempotencyKey: idem.keyFor(body) }), { success: "Customer created" });
      if (c) { idem.complete(); onDone(c); }
    }}>
      <h4>New customer</h4>
      <div className="form-row">
        {orgs.length > 1 ? <Field label="For organisation"><select value={org} onChange={(e) => setOrg(e.target.value)}>{orgs.map((m) => <option key={m.organisation_id} value={m.organisation_id}>{m.organisation_name}</option>)}</select></Field> : null}
        <Field label="Type"><select value={f.customer_type} onChange={set("customer_type")}><option value="individual">individual</option><option value="business">business</option></select></Field>
        {f.customer_type === "business" ? <Field label="Business name"><input required value={f.business_name} onChange={set("business_name")} /></Field> : <>
          <Field label="Given name"><input required value={f.given_name} onChange={set("given_name")} /></Field>
          <Field label="Family name"><input value={f.family_name} onChange={set("family_name")} /></Field>
        </>}
        <Field label="Email"><input type="email" value={f.email} onChange={set("email")} /></Field>
        <Field label="Phone"><input type="tel" value={f.phone} onChange={set("phone")} placeholder="+15550100000" /></Field>
        <label className="check"><input type="checkbox" checked={f.marketing_consent} onChange={(e) => setF({ ...f, marketing_consent: e.target.checked })} /> Marketing consent</label>
      </div>
      <div className="form-actions"><Button type="submit" variant="primary" busy={busy === "Create customer"}>Create</Button><Button variant="ghost" onClick={onCancel}>Cancel</Button></div>
    </form>
  );
}
