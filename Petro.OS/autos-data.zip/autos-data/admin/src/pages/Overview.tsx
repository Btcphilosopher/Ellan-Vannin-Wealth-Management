import { Link } from "react-router-dom";
import type { ImportJob, OutboxEvent, Page, ReconciliationCase, Reservation } from "../api/types";
import { Banner, ErrorPanel, Mono, Section, Spinner, StatusPill } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime, humanize, money, num, relative } from "../lib/format";
import { useResource } from "../lib/hooks";
import { RecordLink } from "../lib/nav";

interface OverviewReport {
  counts: { metric: string; value: number }[];
  workers: { worker_name: string; last_beat_at: string; healthy: boolean }[];
}

const KPI_META: Record<string, { label: string; to: string; tone?: (n: number) => string }> = {
  published_listings: { label: "Published listings", to: "/listings" },
  active_holds: { label: "Active holds", to: "/reservations" },
  dealer_accepted: { label: "Dealer-accepted", to: "/reservations" },
  open_sale_orders: { label: "Open sale orders", to: "/reservations" },
  confirmed_test_drives_next_7d: { label: "Test drives (next 7 d)", to: "/test-drives" },
  active_rental_bookings: { label: "Active rental bookings", to: "/rentals" },
  open_reconciliation_cases: { label: "Open reconciliation cases", to: "/payments", tone: (n) => (n > 0 ? "kpi-bad" : "") },
  imports_awaiting_approval: { label: "Imports awaiting approval", to: "/imports", tone: (n) => (n > 0 ? "kpi-warn" : "") },
  outbox_pending: { label: "Outbox pending", to: "/audit", tone: (n) => (n > 500 ? "kpi-warn" : "") },
  outbox_dead: { label: "Outbox dead-letter", to: "/audit", tone: (n) => (n > 0 ? "kpi-bad" : "") },
};

export function Overview() {
  const { can, me } = useApp();
  const orgName = useOrgName();
  const rep = useResource<OverviewReport>("/v1/reports/overview");
  const cases = useResource<{ items: ReconciliationCase[] }>(can("payments.read") ? "/v1/reconciliation-cases" : null, { status: "open" });
  const imports = useResource<{ items: ImportJob[] }>(can("imports.read") ? "/v1/import-jobs" : null);
  const dead = useResource<{ items: OutboxEvent[] }>(can("outbox.read") ? "/v1/outbox-events" : null, { status: "dead" });
  const lapsed = useResource<Page<Reservation>>(can("reservations.read") ? "/v1/sale-reservations" : null, { status: "expired_effective", limit: 20 });
  const awaiting = (imports.data?.items ?? []).filter((j) => j.status === "validated");

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1>Overview</h1>
          <p className="muted">Operational snapshot{me?.is_platform ? " across all organisations" : " for your organisation"} · {dateTime(new Date().toISOString())}</p>
        </div>
      </div>
      {rep.error ? <ErrorPanel error={rep.error} onReload={rep.reload} /> : null}
      {rep.loading && !rep.data ? <Spinner /> : null}
      {rep.data ? (
        <div className="kpis" data-testid="kpis">
          {rep.data.counts.map((c) => {
            const m = KPI_META[c.metric] ?? { label: humanize(c.metric), to: "/" };
            return (
              <Link key={c.metric} to={m.to} className={`kpi ${m.tone?.(Number(c.value)) ?? ""}`}>
                <span className="kpi-v">{num(c.value)}</span>
                <span className="kpi-k">{m.label}</span>
              </Link>
            );
          })}
        </div>
      ) : null}
      <div className="cols-2">
        <Section title="Worker health">
          {rep.data && rep.data.workers.length === 0 ? (
            <Banner kind="warning">No background worker heartbeats are recorded. Hold expiry sweeps, outbox delivery, freshness checks and payment reconciliation run in workers — start them if this is not expected.</Banner>
          ) : null}
          {rep.data && rep.data.workers.length > 0 ? (
            <table className="grid grid-compact">
              <thead><tr><th>Worker</th><th>Last heartbeat</th><th>Health</th></tr></thead>
              <tbody>{rep.data.workers.map((w) => (
                <tr key={w.worker_name}><td><Mono>{w.worker_name}</Mono></td><td>{dateTime(w.last_beat_at)} <span className="muted small">{relative(w.last_beat_at)}</span></td><td><StatusPill value={w.healthy ? "healthy" : "unhealthy"} /></td></tr>
              ))}</tbody>
            </table>
          ) : null}
        </Section>
        <Section title="Needs attention">
          <ul className="attention">
            <li>
              <h4>Open reconciliation cases <span className="count">{cases.data?.items.length ?? (can("payments.read") ? "…" : "n/a")}</span></h4>
              {(cases.data?.items ?? []).slice(0, 6).map((c) => (
                <div key={c.id} className="att-row"><RecordLink type="reconciliation_case" id={c.id}><Mono>{c.case_number}</Mono> {humanize(c.case_type)}</RecordLink> <StatusPill value={c.severity} /> <span className="muted small">{money(c.observed_amount_minor, c.currency)} · {relative(c.opened_at)}</span></div>
              ))}
              {cases.data && cases.data.items.length === 0 ? <div className="muted small">None open.</div> : null}
            </li>
            <li>
              <h4>Imports awaiting approval <span className="count">{imports.data ? awaiting.length : (can("imports.read") ? "…" : "n/a")}</span></h4>
              {awaiting.slice(0, 6).map((j) => (
                <div key={j.id} className="att-row"><RecordLink type="import_job" id={j.id}>{j.original_filename}</RecordLink> <span className="muted small">{orgName(j.organisation_id)} · {j.valid_count} valid / {j.invalid_count} invalid · {relative(j.uploaded_at)}</span></div>
              ))}
              {imports.data && awaiting.length === 0 ? <div className="muted small">Nothing waiting.</div> : null}
            </li>
            <li>
              <h4>Dead outbox events <span className="count">{dead.data?.items.length ?? (can("outbox.read") ? "…" : "n/a")}</span></h4>
              {(dead.data?.items ?? []).slice(0, 6).map((e) => (
                <div key={e.id} className="att-row"><Link to="/audit?tab=outbox&status=dead"><Mono>{e.event_type}</Mono></Link> <span className="muted small">{e.attempts}/{e.max_attempts} attempts · {e.last_error?.slice(0, 60)}</span></div>
              ))}
              {dead.data && dead.data.items.length === 0 ? <div className="muted small">No dead-lettered events.</div> : null}
              {dead.error ? <div className="muted small">{dead.error.detail}</div> : null}
            </li>
            <li>
              <h4>Lapsed holds not yet swept <span className="count">{lapsed.data?.items.length ?? (can("reservations.read") ? "…" : "n/a")}</span></h4>
              {(lapsed.data?.items ?? []).slice(0, 6).map((r) => (
                <div key={r.id} className="att-row"><RecordLink type="reservation" id={r.id}><Mono>{r.reservation_number}</Mono></RecordLink> <StatusPill value={r.effective_status} /> <span className="muted small">expired {relative(r.hold_expires_at)}</span></div>
              ))}
              {lapsed.data && lapsed.data.items.length === 0 ? <div className="muted small">None.</div> : null}
            </li>
          </ul>
        </Section>
      </div>
    </div>
  );
}
