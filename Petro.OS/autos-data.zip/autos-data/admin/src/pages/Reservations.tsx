import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { post } from "../api/client";
import type { Customer, Listing, Page, Reservation } from "../api/types";
import { DataTable } from "../components/DataTable";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { ActionButton, Amount, Button, Countdown, Field, Mono, StatusPill } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime } from "../lib/format";
import { useAction, useIdempotencyKey, useNow, usePaged, useResource } from "../lib/hooks";
import { useOrgLookups } from "../lib/lookups";
import { parseOpen, RecordLink, useOpenRecord } from "../lib/nav";

const INITIAL = { status: "", organisation_id: "", customer_id: "" };
const STATUSES = ["held", "expired_effective", "dealer_accepted", "converted", "cancelled", "declined", "released", "expired"];

export function Reservations() {
  const filters = useFilters(INITIAL);
  const list = usePaged<Reservation>("/v1/sale-reservations", toQuery(filters.applied), { limit: 50 });
  const { organisations } = useOrgLookups();
  const orgName = useOrgName();
  const open = useOpenRecord();
  const [params] = useSearchParams();
  const active = parseOpen(params.get("open"));
  const [creating, setCreating] = useState(false);
  const now = useNow();
  const [loadedAt, setLoadedAt] = useState(Date.now());
  useEffect(() => setLoadedAt(Date.now()), [list.items]);
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Reservations</h1><p className="muted">Temporary holds on physical vehicles, dealer acceptance and conversion into sale orders. <Mono>expired_effective</Mono> = lapsed holds the sweeper has not yet transitioned.</p></div>
        <div className="page-actions"><ActionButton perm="reservations.create" variant="primary" small onClick={() => setCreating(!creating)}>Create hold</ActionButton></div>
      </div>
      {creating ? <CreateHold onCancel={() => setCreating(false)} onDone={(r) => { setCreating(false); open("reservation", r.id); }} /> : null}
      <FilterBar page="reservations" filters={filters}>
        <Field label="Status"><select {...filters.bind("status")}>
          <option value="">any</option>{STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select></Field>
        <Field label="Seller"><select {...filters.bind("organisation_id")}>
          <option value="">any</option>{organisations.filter((o) => o.kind === "dealer").map((o) => <option key={o.id} value={o.id}>{o.display_name}</option>)}
        </select></Field>
        <Field label="Customer id"><input size={36} className="mono" placeholder="uuid" {...filters.bind("customer_id")} /></Field>
      </FilterBar>
      <DataTable rows={list.items} rowKey={(r) => r.id} loading={list.loading} error={list.error} onRetry={list.reload}
        hasMore={list.hasMore} onLoadMore={list.loadMore} onRowClick={(r) => open("reservation", r.id)} activeKey={active?.type === "reservation" ? active.id : null}
        columns={[
          { key: "n", header: "Reservation", render: (r) => <Mono>{r.reservation_number}</Mono> },
          { key: "es", header: "Effective status", render: (r) => <StatusPill value={r.effective_status} /> },
          { key: "cd", header: "Hold remaining", render: (r) => (r.effective_status === "held" && r.seconds_remaining != null ? <Countdown seconds={r.seconds_remaining - (now - loadedAt) / 1000} /> : <span className="muted">—</span>) },
          { key: "d", header: "Deposit", render: (r) => <><Amount minor={r.deposit_required_minor} currency={r.currency} /> <StatusPill value={r.deposit_status} /></> },
          { key: "l", header: "Listing", render: (r) => <RecordLink type="listing" id={r.listing_id} /> },
          { key: "c", header: "Customer", render: (r) => <RecordLink type="customer" id={r.customer_id} /> },
          { key: "so", header: "Sale order", render: (r) => (r.sale_order ? <><Mono>{r.sale_order.order_number}</Mono> <StatusPill value={r.sale_order.status} /></> : <span className="muted">—</span>) },
          { key: "o", header: "Seller", render: (r) => orgName(r.organisation_id) },
          { key: "cr", header: "Created", render: (r) => dateTime(r.created_at, true) },
        ]} />
    </div>
  );
}

function CreateHold({ onDone, onCancel }: { onDone(r: Reservation): void; onCancel(): void }) {
  const { can } = useApp();
  const listings = useResource<Page<Listing>>("/v1/listings", { status: "published", limit: 200 });
  const customers = useResource<Page<Customer>>("/v1/customers", { limit: 200 });
  const [listingId, setListingId] = useState("");
  const [customerId, setCustomerId] = useState("");
  const { run, busy } = useAction();
  const idem = useIdempotencyKey();
  const options = (listings.data?.items ?? []).filter((l) => can("reservations.create", l.organisation_id));
  const sel = options.find((l) => l.id === listingId);
  return (
    <form className="form-box" onSubmit={async (e) => {
      e.preventDefault();
      const body = { listing_id: listingId, customer_id: customerId || null };
      const r = await run("Create hold", () => post<Reservation>("/v1/sale-reservations", body, { idempotencyKey: idem.keyFor(body) }), { success: "Hold placed" });
      if (r) { idem.complete(); onDone(r); }
    }}>
      <h4>Place a temporary hold <span className="muted small">(one active commitment per vehicle; competing holds get 409 vehicle_already_reserved)</span></h4>
      <div className="form-row">
        <Field label="Published listing" wide>
          <select required value={listingId} onChange={(e) => setListingId(e.target.value)}>
            <option value="">{listings.loading ? "Loading…" : "Select…"}</option>
            {options.map((l) => <option key={l.id} value={l.id} disabled={!!l.vehicle?.current_commitment}>
              {l.title} — {l.price?.formatted} — {l.seller?.display_name}{l.vehicle?.current_commitment ? " (committed)" : ""}
            </option>)}
          </select>
        </Field>
        <Field label="Customer">
          <select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
            <option value="">none</option>
            {(customers.data?.items ?? []).map((c) => <option key={c.id} value={c.id}>{c.display_name}</option>)}
          </select>
        </Field>
      </div>
      {sel ? <p className="muted small">Deposit required: {sel.deposit?.formatted} (part of the price).</p> : null}
      <div className="form-actions"><Button type="submit" variant="primary" busy={busy === "Create hold"} disabled={!listingId}>Place hold</Button><Button variant="ghost" onClick={onCancel}>Cancel</Button></div>
    </form>
  );
}
