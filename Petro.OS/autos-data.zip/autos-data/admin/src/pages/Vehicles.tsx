import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { request } from "../api/client";
import type { MergeProposal, Vehicle } from "../api/types";
import { ConfirmAction } from "../components/ConfirmAction";
import { DataTable } from "../components/DataTable";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { Check, ErrorPanel, Field, JsonView, Mono, StatusPill, Tabs } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime, humanize } from "../lib/format";
import { useAction, usePaged, useResource } from "../lib/hooks";
import { useOrgLookups } from "../lib/lookups";
import { parseOpen, RecordLink, useOpenRecord } from "../lib/nav";

const INITIAL = { q: "", availability: "", organisation_id: "" };

export function Vehicles() {
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") ?? "vehicles";
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Vehicles</h1><p className="muted">Physical vehicles with identifiers and sourced provenance. One vehicle can have many listings.</p></div>
      </div>
      <Tabs tabs={[{ id: "vehicles", label: "Vehicles" }, { id: "merges", label: "Merge proposals" }]} active={tab}
        onChange={(t) => { const p = new URLSearchParams(params); p.set("tab", t); setParams(p); }} />
      {tab === "merges" ? <MergeProposals /> : <VehicleList />}
    </div>
  );
}

function VehicleList() {
  const filters = useFilters(INITIAL);
  const { organisations } = useOrgLookups();
  const orgName = useOrgName();
  const open = useOpenRecord();
  const [params] = useSearchParams();
  const active = parseOpen(params.get("open"));
  const list = usePaged<Vehicle>("/v1/vehicles", toQuery(filters.applied), { limit: 50 });
  return <>
    <FilterBar page="vehicles" filters={filters}>
      <Field label="VIN / identifier / make / model"><input type="search" size={26} placeholder="e.g. SYNH67T or Tucson" {...filters.bind("q")} /></Field>
      <Field label="Availability"><select {...filters.bind("availability")}>
        <option value="">any</option>{["available", "in_transit", "unavailable", "sold", "written_off"].map((s) => <option key={s}>{s}</option>)}
      </select></Field>
      <Field label="Custodian"><select {...filters.bind("organisation_id")}>
        <option value="">any</option>{organisations.map((o) => <option key={o.id} value={o.id}>{o.display_name}</option>)}
      </select></Field>
    </FilterBar>
    <DataTable rows={list.items} rowKey={(v) => v.id} loading={list.loading} error={list.error} onRetry={list.reload}
      hasMore={list.hasMore} onLoadMore={list.loadMore} onRowClick={(v) => open("vehicle", v.id)} activeKey={active?.type === "vehicle" ? active.id : null}
      columns={[
        { key: "vin", header: "VIN", render: (v) => <Mono>{v.identifiers.find((i) => i.namespace === "vin" && !i.retired_at)?.value ?? "—"}</Mono> },
        { key: "syn", header: "Synthetic", render: (v) => <Check value={v.identifiers.find((i) => i.namespace === "vin")?.is_synthetic} /> },
        { key: "l", header: "Vehicle", render: (v) => v.specification?.label ?? <span className="muted">unmatched trim · {v.model_year}</span> },
        { key: "c", header: "Condition", render: (v) => humanize(v.condition) },
        { key: "col", header: "Colour", render: (v) => v.exterior_colour },
        { key: "o", header: "Odometer", align: "right", render: (v) => (v.odometer_value != null ? `${v.odometer_value.toLocaleString()} ${v.odometer_unit ?? ""}` : "—") },
        { key: "cu", header: "Custodian", render: (v) => orgName(v.custodian_organisation_id) },
        { key: "a", header: "Availability", render: (v) => <StatusPill value={v.availability_status} /> },
        { key: "cm", header: "Commitment", render: (v) => (v.current_commitment ? <StatusPill value={String(v.current_commitment.status ?? "committed")} /> : <span className="muted">—</span>) },
        { key: "ids", header: "IDs", align: "right", render: (v) => v.identifiers.length },
        { key: "u", header: "Updated", render: (v) => dateTime(v.updated_at, true) },
      ]} />
  </>;
}

function MergeProposals() {
  const [status, setStatus] = useState("pending");
  const list = useResource<{ items: MergeProposal[] }>("/v1/vehicle-merge-proposals", { status });
  const { run, busy, error, clearError } = useAction();
  const { can } = useApp();
  const orgName = useOrgName();
  const decide = (p: MergeProposal, decision: "accept" | "reject", note: string | null) =>
    run(`${decision === "accept" ? "Accept" : "Reject"} merge`, () => request(`/v1/vehicle-merge-proposals/${p.id}/decision`, { method: "POST", body: { decision, note }, ifMatch: p.version }),
      { silent: true, success: `Merge proposal ${decision}ed` });
  return <>
    <div className="filterbar">
      <div className="filter-fields">
        <Field label="Status"><select value={status} onChange={(e) => setStatus(e.target.value)}>
          {["pending", "accepted", "rejected"].map((s) => <option key={s}>{s}</option>)}
        </select></Field>
      </div>
      {!can("vehicles.merge") ? <span className="muted small">Deciding proposals requires <Mono>vehicles.merge</Mono>.</span> : null}
    </div>
    <ErrorPanel error={error} onReload={() => { clearError(); list.reload(); }} onDismiss={clearError} />
    <DataTable rows={list.data?.items ?? []} rowKey={(p) => p.id} loading={list.loading} error={list.error} onRetry={list.reload}
      empty="No merge proposals with this status. Uncertain duplicate matches from imports appear here for review."
      columns={[
        { key: "p", header: "Primary vehicle", render: (p) => <RecordLink type="vehicle" id={p.primary_vehicle_id} /> },
        { key: "d", header: "Possible duplicate", render: (p) => <RecordLink type="vehicle" id={p.duplicate_vehicle_id} /> },
        { key: "s", header: "Score", align: "right", render: (p) => (p.score != null ? String(p.score) : "—") },
        { key: "e", header: "Evidence", render: (p) => <details><summary>view</summary><JsonView value={p.evidence} /></details> },
        { key: "o", header: "Organisation", render: (p) => orgName(p.organisation_id) },
        { key: "st", header: "Status", render: (p) => <StatusPill value={p.status} /> },
        { key: "c", header: "Created", render: (p) => dateTime(p.created_at, true) },
        { key: "act", header: "Decision", render: (p) => (p.status === "pending" ? (
          <div className="row-actions" onClick={(e) => e.stopPropagation()}>
            <ConfirmAction label="Accept" perm="vehicles.merge" org={p.organisation_id} reason="optional" variant="primary" busy={busy === "Accept merge"}
              confirmText="Merge the duplicate into the primary?" onConfirm={(n) => decide(p, "accept", n)} />
            <ConfirmAction label="Reject" perm="vehicles.merge" org={p.organisation_id} reason="optional" busy={busy === "Reject merge"}
              onConfirm={(n) => decide(p, "reject", n)} />
          </div>
        ) : <span className="muted small">{p.decision_note ?? ""} {dateTime(p.decided_at, true)}</span>) },
      ]} />
  </>;
}
