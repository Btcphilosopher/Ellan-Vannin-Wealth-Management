import { useMemo, useState } from "react";
import { ApiError, post, session } from "../api/client";
import type { Listing } from "../api/types";
import { DataTable } from "../components/DataTable";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { ActionButton, Amount, Button, ErrorPanel, Field, Mono, Section, SeverityBadge, StatusPill } from "../components/ui";
import { useApp } from "../lib/app";
import { dateTime, parseMoneyToMinor } from "../lib/format";
import { useAction, usePaged } from "../lib/hooks";
import { useOrgLookups } from "../lib/lookups";
import { parseOpen, RecordLink, useOpenRecord } from "../lib/nav";
import { useSearchParams } from "react-router-dom";

const INITIAL = { status: "", organisation_id: "", make: "", model: "", q: "", min_price: "", max_price: "", lat: "", lon: "", radius_km: "", freshness: "" };
type F = typeof INITIAL;

interface BulkResult { results: { listing_id: string; result: string; code?: string; detail?: string; errors?: { severity?: string; code?: string; message?: string; field?: string }[] }[]; published: number; rejected: number }

export function Listings() {
  const { me } = useApp();
  const filters = useFilters<F>(INITIAL);
  const { organisations, locations } = useOrgLookups();
  const open = useOpenRecord();
  const [params] = useSearchParams();
  const active = parseOpen(params.get("open"));
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulk, setBulk] = useState<BulkResult | null>(null);
  const { run, busy } = useAction();
  const [exportErr, setExportErr] = useState<ApiError | null>(null);

  const a = filters.applied;
  const query = useMemo(() => {
    const q: Record<string, string> = toQuery({ status: a.status, organisation_id: a.organisation_id, make: a.make, model: a.model, q: a.q, freshness: a.freshness, lat: a.lat, lon: a.lon, radius_km: a.radius_km });
    const min = a.min_price ? parseMoneyToMinor(a.min_price, "USD") : null;
    const max = a.max_price ? parseMoneyToMinor(a.max_price, "USD") : null;
    if (min !== null) q.min_price_minor = String(min);
    if (max !== null) q.max_price_minor = String(max);
    return q;
  }, [a]);
  const list = usePaged<Listing>("/v1/listings", query, { limit: 50 });
  const titles = new Map(list.items.map((l) => [l.id, l.title]));
  const publishable = (l: Listing) => l.status === "draft" || l.status === "suspended";

  const exportCsv = async () => {
    setExportErr(null);
    const qs = new URLSearchParams(toQuery({ organisation_id: a.organisation_id, status: a.status })).toString();
    const headers: Record<string, string> = { Authorization: `Bearer ${session.token}` };
    if (session.org) headers["X-Organisation-Id"] = session.org;
    const r = await fetch(`/v1/listings/export.csv${qs ? `?${qs}` : ""}`, { headers });
    if (!r.ok) { setExportErr(new ApiError(r.status, await r.json().catch(() => ({})), r.headers.get("x-request-id"))); return; }
    const blob = await r.blob();
    const url = URL.createObjectURL(blob);
    const el = document.createElement("a");
    el.href = url; el.download = "listings.csv"; el.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Listings</h1><p className="muted">Commercial offers for physical vehicles. Status changes only via publish / suspend / withdraw actions.</p></div>
        <div className="page-actions">
          <Button small onClick={exportCsv}>Export CSV</Button>
        </div>
      </div>
      {exportErr ? <ErrorPanel error={exportErr} onDismiss={() => setExportErr(null)} /> : null}
      <FilterBar page="listings" filters={filters}>
        <Field label="Search"><input type="search" placeholder="title, VIN, make…" {...filters.bind("q")} /></Field>
        <Field label="Status"><select {...filters.bind("status")}>
          <option value="">any</option>{["draft", "published", "suspended", "withdrawn", "sold"].map((s) => <option key={s}>{s}</option>)}
        </select></Field>
        {me?.is_platform || organisations.length > 1 ? (
          <Field label="Seller"><select {...filters.bind("organisation_id")}>
            <option value="">any</option>{organisations.filter((o) => o.kind === "dealer").map((o) => <option key={o.id} value={o.id}>{o.display_name}</option>)}
          </select></Field>
        ) : null}
        <Field label="Make"><input {...filters.bind("make")} placeholder="Hyundai" size={10} /></Field>
        <Field label="Model"><input {...filters.bind("model")} placeholder="Tucson" size={10} /></Field>
        <Field label="Price min ($)"><input inputMode="decimal" size={8} {...filters.bind("min_price")} /></Field>
        <Field label="Price max ($)"><input inputMode="decimal" size={8} {...filters.bind("max_price")} /></Field>
        <Field label="Freshness"><select {...filters.bind("freshness")}>
          <option value="">any</option>{["fresh", "stale", "expired", "not_applicable"].map((s) => <option key={s}>{s}</option>)}
        </select></Field>
        <Field label="Near location">
          <select value="" onChange={(e) => {
            const l = locations.get(e.target.value);
            if (l?.point) { filters.set("lat", String(l.point.lat)); filters.set("lon", String(l.point.lon)); if (!filters.draft.radius_km) filters.set("radius_km", "50"); }
          }}>
            <option value="">pick to fill lat/lon…</option>
            {[...locations.values()].filter((l) => l.point).map((l) => <option key={l.id} value={l.id}>{l.code} {l.city}</option>)}
          </select>
        </Field>
        <Field label="Lat"><input inputMode="decimal" size={7} {...filters.bind("lat")} /></Field>
        <Field label="Lon"><input inputMode="decimal" size={8} {...filters.bind("lon")} /></Field>
        <Field label="Radius km"><input inputMode="decimal" size={5} {...filters.bind("radius_km")} /></Field>
      </FilterBar>

      <div className="bulkbar">
        <span className="muted">{selected.size} selected</span>
        <ActionButton perm="listings.publish" variant="primary" small disabled={selected.size === 0} busy={busy === "Bulk publish"}
          onClick={async () => {
            const r = await run("Bulk publish", () => post<BulkResult>("/v1/listings/publication-batch", { listing_ids: [...selected] }));
            if (r) { setBulk(r); setSelected(new Set()); }
          }}>Publish selected</ActionButton>
        {selected.size ? <Button small variant="ghost" onClick={() => setSelected(new Set())}>Clear selection</Button> : null}
      </div>
      {bulk ? (
        <Section title={<>Bulk publish results: <span className="pill pill-green">{bulk.published} published</span> <span className="pill pill-red">{bulk.rejected} rejected</span></>}
          actions={<Button small variant="ghost" onClick={() => setBulk(null)}>Dismiss</Button>} className="bulk-results">
          <table className="grid grid-compact">
            <thead><tr><th>Listing</th><th>Result</th><th>Code</th><th>Detail / findings</th></tr></thead>
            <tbody>{bulk.results.map((r) => (
              <tr key={r.listing_id}>
                <td><RecordLink type="listing" id={r.listing_id}>{titles.get(r.listing_id) ?? r.listing_id}</RecordLink></td>
                <td><StatusPill value={r.result} /></td>
                <td>{r.code ? <Mono>{r.code}</Mono> : "—"}</td>
                <td className="wrap">{r.detail ?? ""}{(r.errors ?? []).map((e, i) => <div key={i}>{e.severity ? <SeverityBadge severity={e.severity} /> : null} <Mono>{e.code}</Mono> {e.message}</div>)}</td>
              </tr>
            ))}</tbody>
          </table>
        </Section>
      ) : null}

      <DataTable rows={list.items} rowKey={(l) => l.id} loading={list.loading} error={list.error} onRetry={list.reload}
        hasMore={list.hasMore} onLoadMore={list.loadMore} onRowClick={(l) => open("listing", l.id)}
        activeKey={active?.type === "listing" ? active.id : null}
        selectable selected={selected} onSelectedChange={setSelected} isSelectable={publishable}
        columns={[
          { key: "t", header: "Title", render: (l) => <span className="cell-title">{l.title}</span> },
          { key: "vin", header: "VIN", render: (l) => <Mono>{l.vehicle?.vin ?? "—"}</Mono> },
          { key: "s", header: "Seller", render: (l) => l.seller?.display_name },
          { key: "loc", header: "Location", render: (l) => <span title={l.location?.timezone}>{l.location?.city}</span> },
          { key: "p", header: "Price", align: "right", render: (l) => <Amount minor={l.price?.amount_minor} currency={l.currency} formatted={l.price?.formatted} /> },
          { key: "d", header: "Deposit", align: "right", render: (l) => <Amount minor={l.deposit_required_minor} currency={l.currency} formatted={l.deposit?.formatted} /> },
          { key: "st", header: "Status", render: (l) => <StatusPill value={l.status} /> },
          { key: "f", header: "Freshness", render: (l) => <StatusPill value={l.freshness_state} /> },
          { key: "av", header: "Vehicle", render: (l) => <StatusPill value={l.vehicle?.availability_status} /> },
          { key: "u", header: "Updated", render: (l) => dateTime(l.updated_at, true) },
        ]} />
    </div>
  );
}
