import { useSearchParams } from "react-router-dom";
import type { Organisation } from "../api/types";
import { DataTable } from "../components/DataTable";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { Field, Mono, StatusPill } from "../components/ui";
import { duration, humanize } from "../lib/format";
import { useResource } from "../lib/hooks";
import { useOrgLookups } from "../lib/lookups";
import { parseOpen, useOpenRecord } from "../lib/nav";

const INITIAL = { kind: "" };

export function Dealers() {
  const filters = useFilters(INITIAL);
  const list = useResource<{ items: Organisation[] }>("/v1/organisations", toQuery(filters.applied));
  const { organisations } = useOrgLookups();
  const detail = new Map(organisations.map((o) => [o.id, o]));
  const open = useOpenRecord();
  const [params] = useSearchParams();
  const active = parseOpen(params.get("open"));
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Dealers &amp; organisations</h1><p className="muted">Dealers, rental suppliers and the platform operator, with locations, policies and members.</p></div>
      </div>
      <FilterBar page="dealers" filters={filters}>
        <Field label="Kind"><select {...filters.bind("kind")}>
          <option value="">any</option>{["dealer", "rental_supplier", "platform"].map((k) => <option key={k} value={k}>{humanize(k)}</option>)}
        </select></Field>
      </FilterBar>
      <DataTable rows={list.data?.items ?? []} rowKey={(o) => o.id} loading={list.loading} error={list.error} onRetry={list.reload}
        onRowClick={(o) => open("organisation", o.id)} activeKey={active?.type === "organisation" ? active.id : null}
        columns={[
          { key: "n", header: "Name", render: (o) => <span className="cell-title">{o.display_name}</span> },
          { key: "k", header: "Kind", render: (o) => <span className="tag">{humanize(o.kind)}</span> },
          { key: "s", header: "Slug", render: (o) => <Mono>{o.slug}</Mono> },
          { key: "st", header: "Status", render: (o) => <StatusPill value={o.status} /> },
          { key: "c", header: "Currency", render: (o) => o.default_currency },
          { key: "tz", header: "Timezone", render: (o) => <Mono>{o.default_timezone}</Mono> },
          { key: "loc", header: "Locations", align: "right", render: (o) => detail.get(o.id)?.locations?.length ?? "—" },
          { key: "h", header: "Hold duration", render: (o) => (o.sale_hold_duration != null ? duration(o.sale_hold_duration) : <span className="muted">—</span>) },
          { key: "f", header: "Freshness warn", render: (o) => (o.listing_freshness_warn_after != null ? duration(o.listing_freshness_warn_after) : <span className="muted">—</span>) },
        ]} />
    </div>
  );
}
