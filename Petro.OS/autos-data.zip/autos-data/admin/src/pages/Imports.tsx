import { useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { request } from "../api/client";
import type { ImportJob } from "../api/types";
import { DataTable } from "../components/DataTable";
import { FilterBar, useFilters } from "../components/FilterBar";
import { ActionButton, Banner, Button, Field, Mono, Section, StatusPill } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime, num } from "../lib/format";
import { useAction, useResource } from "../lib/hooks";
import { parseOpen, RecordLink, useOpenRecord } from "../lib/nav";

const CLEARABLE = ["exterior_colour", "interior_colour", "odometer_value", "description", "features"];
const INITIAL = { status: "", source_namespace: "" };

export function Imports() {
  const { can } = useApp();
  const filters = useFilters(INITIAL);
  const list = useResource<{ items: ImportJob[] }>("/v1/import-jobs");
  const orgName = useOrgName();
  const open = useOpenRecord();
  const [params] = useSearchParams();
  const active = parseOpen(params.get("open"));
  const [last, setLast] = useState<ImportJob | null>(null);
  const a = filters.applied;
  const rows = (list.data?.items ?? []).filter((j) => (!a.status || j.status === a.status) && (!a.source_namespace || j.source_namespace.includes(a.source_namespace)));
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Imports</h1><p className="muted">Dealer inventory feeds (CSV / JSON) are staged and validated, previewed row by row, then approved or rejected. Nothing is applied before approval.</p></div>
      </div>
      {can("imports.manage") ? <UploadForm onUploaded={(j) => { setLast(j); open("import_job", j.id); list.reload(); }} /> : <Banner kind="info">Uploading feeds requires <Mono>imports.manage</Mono>.</Banner>}
      {last ? (
        last.duplicate_upload ? (
          <Banner kind="warning"><strong>Duplicate upload</strong> — identical bytes for <Mono>{last.source_namespace}</Mono> were already uploaded; the existing job <RecordLink type="import_job" id={last.id}>{last.original_filename}</RecordLink> (status <StatusPill value={last.status} />) is shown instead of creating a new one.</Banner>
        ) : (
          <Banner kind="success">Uploaded <RecordLink type="import_job" id={last.id}>{last.original_filename}</RecordLink>: {last.row_count} rows, {last.valid_count} valid, {last.warning_count} warnings, {last.invalid_count} invalid. Review the preview, then approve or reject.</Banner>
        )
      ) : null}
      <FilterBar page="imports" filters={filters}>
        <Field label="Status"><select {...filters.bind("status")}>
          <option value="">any</option>{["uploaded", "validating", "validated", "approved", "applying", "applied", "applied_with_skips", "rejected", "failed"].map((s) => <option key={s}>{s}</option>)}
        </select></Field>
        <Field label="Source namespace"><input {...filters.bind("source_namespace")} placeholder="ridgeline_dms" /></Field>
      </FilterBar>
      <DataTable rows={rows} rowKey={(j) => j.id} loading={list.loading} error={list.error} onRetry={list.reload}
        onRowClick={(j) => open("import_job", j.id)} activeKey={active?.type === "import_job" ? active.id : null}
        empty="No import jobs yet. Upload a CSV or JSON feed above."
        columns={[
          { key: "u", header: "Uploaded", render: (j) => dateTime(j.uploaded_at, true) },
          { key: "f", header: "File", render: (j) => <span className="cell-title">{j.original_filename}</span> },
          { key: "n", header: "Source", render: (j) => <Mono>{j.source_namespace}</Mono> },
          { key: "fmt", header: "Format", render: (j) => j.format },
          { key: "m", header: "Mode", render: (j) => <StatusPill value={j.mode} /> },
          { key: "r", header: "Rows", align: "right", render: (j) => num(j.row_count) },
          { key: "v", header: "Valid", align: "right", render: (j) => num(j.valid_count) },
          { key: "w", header: "Warn", align: "right", render: (j) => (j.warning_count ? <span className="txt-warn">{j.warning_count}</span> : 0) },
          { key: "i", header: "Invalid", align: "right", render: (j) => (j.invalid_count ? <span className="txt-bad">{j.invalid_count}</span> : 0) },
          { key: "ap", header: "Applied", align: "right", render: (j) => num(j.applied_count) },
          { key: "s", header: "Status", render: (j) => <StatusPill value={j.status} /> },
          { key: "o", header: "Organisation", render: (j) => orgName(j.organisation_id) },
        ]} />
    </div>
  );
}

function UploadForm({ onUploaded }: { onUploaded(j: ImportJob): void }) {
  const { me, activeOrg, orgNames } = useApp();
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [ns, setNs] = useState("");
  const [mode, setMode] = useState("partial_accept");
  const [format, setFormat] = useState("");
  const [clear, setClear] = useState<string[]>([]);
  const [publish, setPublish] = useState(false);
  const orgs = (me?.memberships ?? []).filter((m) => m.permissions.includes("imports.manage"));
  const [org, setOrg] = useState(activeOrg ?? "");
  const { run, busy } = useAction();
  const options = { clear_blank_fields: clear, publish_on_apply: publish };
  return (
    <Section title="Upload inventory feed" className="upload">
      <form className="form-row" onSubmit={async (e) => {
        e.preventDefault();
        if (!file) return;
        const fd = new FormData();
        fd.append("file", file);
        fd.append("source_namespace", ns.trim());
        fd.append("mode", mode);
        if (format) fd.append("format", format);
        if (org) fd.append("organisation_id", org);
        fd.append("options", JSON.stringify(options));
        const r = await run("Upload import", () => request<ImportJob>("/v1/import-jobs", { method: "POST", form: fd }), { silent: false });
        if (r) { onUploaded(r.data); setFile(null); if (fileRef.current) fileRef.current.value = ""; }
      }}>
        <Field label="File (.csv or .json)"><input ref={fileRef} type="file" accept=".csv,.json,text/csv,application/json" required onChange={(e) => {
          const f = e.target.files?.[0] ?? null;
          setFile(f);
          if (f && !ns) {
            const guess = f.name.toLowerCase().startsWith("ridgeline") ? "ridgeline_dms" : f.name.toLowerCase().startsWith("harbourview") ? "harbourview_dms" : "";
            if (guess) setNs(guess);
          }
        }} /></Field>
        <Field label="Source namespace" hint="identifies the feed; dedupes identical files"><input required value={ns} onChange={(e) => setNs(e.target.value)} placeholder="ridgeline_dms" /></Field>
        <Field label="Mode"><select value={mode} onChange={(e) => setMode(e.target.value)}>
          <option value="partial_accept">partial_accept — skip invalid rows</option>
          <option value="all_or_nothing">all_or_nothing — block on any invalid row</option>
        </select></Field>
        <Field label="Format"><select value={format} onChange={(e) => setFormat(e.target.value)}><option value="">auto</option><option>csv</option><option>json</option></select></Field>
        {me?.is_platform || orgs.length > 1 ? (
          <Field label="Organisation"><select value={org} onChange={(e) => setOrg(e.target.value)}>
            <option value="">{me?.is_platform ? "(required for platform)" : "default"}</option>
            {[...orgNames.entries()].map(([id, name]) => <option key={id} value={id}>{name}</option>)}
          </select></Field>
        ) : null}
        <fieldset className="checks">
          <legend>Blank values may clear</legend>
          {CLEARABLE.map((c) => <label key={c} className="check"><input type="checkbox" checked={clear.includes(c)} onChange={() => setClear(clear.includes(c) ? clear.filter((x) => x !== c) : [...clear, c])} /> <Mono>{c}</Mono></label>)}
        </fieldset>
        <label className="check"><input type="checkbox" checked={publish} onChange={(e) => setPublish(e.target.checked)} /> Publish on apply</label>
        <div className="form-actions">
          <ActionButton perm="imports.manage" type="submit" variant="primary" small busy={busy === "Upload import"} disabled={!file || !ns.trim()}>Upload &amp; validate</ActionButton>
          <Button small variant="ghost" onClick={() => { setClear([]); setPublish(false); }}>Reset options</Button>
        </div>
        <div className="muted small options-preview">options = <Mono>{JSON.stringify(options)}</Mono></div>
      </form>
    </Section>
  );
}

