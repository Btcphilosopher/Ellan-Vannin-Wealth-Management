import { useSearchParams } from "react-router-dom";
import type { PaymentIntent, ReconciliationCase, Refund } from "../api/types";
import { DataTable } from "../components/DataTable";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { Amount, ErrorPanel, Field, Mono, StatusPill, Tabs } from "../components/ui";
import { useOrgName } from "../lib/app";
import { dateTime, humanize } from "../lib/format";
import { usePaged, useResource } from "../lib/hooks";
import { parseOpen, RecordLink, useOpenRecord } from "../lib/nav";
import { CasesTable, RefundsTable } from "../details/PaymentDetail";

const PAY_INITIAL = { status: "" };
const CASE_INITIAL = { status: "open" };

export function Payments() {
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") ?? "intents";
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Payments</h1><p className="muted">Payment intents, the append-only transaction ledger, provider events, refunds and reconciliation. Financial records are read-only; refunds and resolutions are separate actions.</p></div>
      </div>
      <Tabs tabs={[{ id: "intents", label: "Payment intents" }, { id: "refunds", label: "Refunds" }, { id: "cases", label: "Reconciliation cases" }]} active={tab}
        onChange={(t) => { const p = new URLSearchParams(params); p.set("tab", t); setParams(p); }} />
      {tab === "refunds" ? <RefundList /> : tab === "cases" ? <CaseList /> : <IntentList />}
    </div>
  );
}

function IntentList() {
  const filters = useFilters(PAY_INITIAL);
  const list = usePaged<PaymentIntent>("/v1/payments", toQuery(filters.applied), { limit: 50 });
  const orgName = useOrgName();
  const open = useOpenRecord();
  const [params] = useSearchParams();
  const active = parseOpen(params.get("open"));
  return <>
    <FilterBar page="payments" filters={filters}>
      <Field label="Status"><select {...filters.bind("status")}>
        <option value="">any</option>{["created", "processing", "requires_action", "succeeded", "failed", "canceled", "unknown"].map((s) => <option key={s}>{s}</option>)}
      </select></Field>
    </FilterBar>
    <DataTable rows={list.items} rowKey={(p) => p.id} loading={list.loading} error={list.error} onRetry={list.reload}
      hasMore={list.hasMore} onLoadMore={list.loadMore} onRowClick={(p) => open("payment", p.id)} activeKey={active?.type === "payment" ? active.id : null}
      columns={[
        { key: "c", header: "Created", render: (p) => dateTime(p.created_at, true) },
        { key: "pu", header: "Purpose", render: (p) => humanize(p.purpose) },
        { key: "a", header: "Amount", align: "right", render: (p) => <Amount minor={p.amount_minor} currency={p.currency} /> },
        { key: "s", header: "Status", render: (p) => <StatusPill value={p.status} /> },
        { key: "f", header: "Failure", render: (p) => (p.failure_code ? <Mono>{p.failure_code}</Mono> : "") },
        { key: "r", header: "Provider ref", render: (p) => <Mono>{p.provider_intent_ref ?? "—"}</Mono> },
        { key: "t", header: "For", render: (p) => (p.sale_reservation_id ? <RecordLink type="reservation" id={p.sale_reservation_id}>reservation</RecordLink>
          : p.sale_order_id ? <RecordLink type="sale_order" id={p.sale_order_id}>sale order</RecordLink>
          : p.rental_booking_id ? <RecordLink type="rental_booking" id={p.rental_booking_id}>rental booking</RecordLink> : "—") },
        { key: "o", header: "Organisation", render: (p) => orgName(p.organisation_id) },
        { key: "e", header: "Last event", render: (p) => dateTime(p.last_provider_event_at, true) },
      ]} />
  </>;
}

function RefundList() {
  const list = useResource<{ items: Refund[] }>("/v1/refunds");
  return <>
    <ErrorPanel error={list.error} onReload={list.reload} />
    <p className="muted small">Latest 200 refunds. Partial refunds are requested from the payment detail panel.</p>
    <RefundsTable rows={list.data?.items ?? []} />
  </>;
}

function CaseList() {
  const filters = useFilters(CASE_INITIAL);
  const list = useResource<{ items: ReconciliationCase[] }>("/v1/reconciliation-cases", toQuery(filters.applied));
  return <>
    <FilterBar page="reconciliation" filters={filters}>
      <Field label="Status"><select {...filters.bind("status")}>
        <option value="">any</option><option value="open">open (any unresolved)</option>
        {["investigating", "awaiting_provider", "resolved", "written_off"].map((s) => <option key={s}>{s}</option>)}
      </select></Field>
    </FilterBar>
    <ErrorPanel error={list.error} onReload={list.reload} />
    {list.loading ? <span className="muted">Loading…</span> : null}
    <CasesTable rows={list.data?.items ?? []} />
  </>;
}
