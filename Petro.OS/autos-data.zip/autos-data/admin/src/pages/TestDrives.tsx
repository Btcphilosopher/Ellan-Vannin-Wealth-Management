import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { post } from "../api/client";
import type { Customer, Listing, Page, TestDrive } from "../api/types";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { ActionButton, Button, Empty, ErrorPanel, Field, Mono, StatusPill } from "../components/ui";
import { useApp } from "../lib/app";
import { dayKey, dayLabel, inZone, toLocalInput, zonedInputToIso } from "../lib/format";
import { useAction, useIdempotencyKey, usePaged, useResource } from "../lib/hooks";
import { useOrgLookups, useResources } from "../lib/lookups";
import { parseOpen, RecordLink, useOpenRecord } from "../lib/nav";

const INITIAL = { status: "", organisation_id: "", vehicle_id: "" };

export function TestDrives() {
  const filters = useFilters(INITIAL);
  const list = usePaged<TestDrive>("/v1/test-drive-appointments", toQuery(filters.applied), { limit: 100 });
  const { organisations, locations } = useOrgLookups();
  const resources = useResources();
  const open = useOpenRecord();
  const [params, setParams] = useSearchParams();
  const active = parseOpen(params.get("open"));
  const creating = params.get("new") === "1";
  const setCreating = (v: boolean) => {
    const p = new URLSearchParams(params);
    if (v) p.set("new", "1"); else { p.delete("new"); p.delete("listing"); p.delete("vehicle"); }
    setParams(p);
  };

  const groups = useMemo(() => {
    const m = new Map<string, TestDrive[]>();
    for (const d of [...list.items].sort((a, b) => a.starts_at.localeCompare(b.starts_at))) {
      const k = dayKey(d.starts_at, d.local_timezone);
      m.set(k, [...(m.get(k) ?? []), d]);
    }
    return [...m.entries()];
  }, [list.items]);

  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Test drives</h1><p className="muted">Appointments grouped by day in each dealership's local time zone (IANA zone shown).</p></div>
        <div className="page-actions"><ActionButton perm="test_drives.manage" variant="primary" small onClick={() => setCreating(!creating)}>Request test drive</ActionButton></div>
      </div>
      {creating ? <RequestDrive initialListing={params.get("listing") ?? ""} onCancel={() => setCreating(false)} onDone={(d) => {
        const p = new URLSearchParams(params); p.delete("new"); p.delete("listing"); p.delete("vehicle"); p.set("open", `test_drive:${d.id}`); setParams(p);
      }} /> : null}
      <FilterBar page="test_drives" filters={filters}>
        <Field label="Confirmation status"><select {...filters.bind("status")}>
          <option value="">any</option>{["unconfirmed", "confirmed", "cancelled", "completed", "no_show"].map((s) => <option key={s}>{s}</option>)}
        </select></Field>
        <Field label="Dealer"><select {...filters.bind("organisation_id")}>
          <option value="">any</option>{organisations.filter((o) => o.kind === "dealer").map((o) => <option key={o.id} value={o.id}>{o.display_name}</option>)}
        </select></Field>
        <Field label="Vehicle id"><input className="mono" size={36} placeholder="uuid" {...filters.bind("vehicle_id")} /></Field>
      </FilterBar>
      {list.error ? <ErrorPanel error={list.error} onReload={list.reload} /> : null}
      {!list.loading && list.items.length === 0 && !list.error ? <Empty>No appointments match.</Empty> : null}
      <div className="day-groups">
        {groups.map(([day, rows]) => (
          <section key={day} className="day-group">
            <h3 className="day-head">{dayLabel(day)} <span className="muted small">{rows.length} appointment{rows.length > 1 ? "s" : ""}</span></h3>
            <div className="table-scroll">
              <table className="grid">
                <thead><tr><th style={{ width: 120 }}>Local time</th><th>Zone</th><th>Location</th><th>Resource</th><th>Vehicle</th><th>Listing</th><th>Customer</th><th>Request</th><th>Confirmation</th><th>Notice</th></tr></thead>
                <tbody>
                  {rows.map((d) => (
                    <tr key={d.id} className={`clickable${active?.type === "test_drive" && active.id === d.id ? " row-active" : ""}`} onClick={() => open("test_drive", d.id)}>
                      <td className="mono">{inZone(d.local_start, d.local_timezone, { timeOnly: true })}–{inZone(d.local_end, d.local_timezone, { timeOnly: true })}</td>
                      <td><Mono>{d.local_timezone}</Mono></td>
                      <td>{locations.get(d.location_id)?.name ?? "—"}</td>
                      <td>{resources.find((r) => r.id === d.resource_id)?.name ?? "—"}</td>
                      <td><RecordLink type="vehicle" id={d.vehicle_id} /></td>
                      <td><RecordLink type="listing" id={d.listing_id} /></td>
                      <td><RecordLink type="customer" id={d.customer_id} /></td>
                      <td><StatusPill value={d.request_status} /></td>
                      <td><StatusPill value={d.confirmation_status} /></td>
                      <td>{d.availability_notice ? <span className="pill pill-amber" title="availability notice">{d.availability_notice}</span> : ""}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        ))}
      </div>
      <div className="table-foot">
        <span className="muted">{list.items.length} appointments</span>
        {list.loading ? <span className="muted"><span className="spinner" /> Loading…</span> : null}
        {list.hasMore && !list.loading ? <Button small onClick={list.loadMore}>Load more</Button> : null}
      </div>
    </div>
  );
}

function RequestDrive({ initialListing, onDone, onCancel }: { initialListing: string; onDone(d: TestDrive): void; onCancel(): void }) {
  const { can } = useApp();
  const listings = useResource<Page<Listing>>("/v1/listings", { status: "published", limit: 200 });
  const customers = useResource<Page<Customer>>("/v1/customers", { limit: 200 });
  const resources = useResources();
  const { locations } = useOrgLookups();
  const [listingId, setListingId] = useState(initialListing);
  const [resourceId, setResourceId] = useState("");
  const [customerId, setCustomerId] = useState("");
  const tomorrow = new Date(Date.now() + 86400000);
  tomorrow.setHours(10, 0, 0, 0);
  const [start, setStart] = useState(toLocalInput(tomorrow));
  const [minutes, setMinutes] = useState(45);
  const [confirm, setConfirm] = useState(true);
  const { run, busy } = useAction();
  const idem = useIdempotencyKey();
  const options = (listings.data?.items ?? []).filter((l) => can("test_drives.manage", l.organisation_id));
  const listing = options.find((l) => l.id === listingId);
  const res = resources.filter((r) => r.organisation_id === listing?.organisation_id && r.status === "active");
  const resource = res.find((r) => r.id === resourceId);
  const tz = (resource && locations.get(resource.location_id)?.timezone) || listing?.location?.timezone || "UTC";
  const startsIso = zonedInputToIso(start, tz);
  const endsIso = startsIso ? zonedInputToIso(toLocalInput(new Date(new Date(start).getTime() + minutes * 60000)), tz) : "";
  return (
    <form className="form-box" onSubmit={async (e) => {
      e.preventDefault();
      if (!listing) return;
      const body = { vehicle_id: listing.vehicle_id, listing_id: listing.id, customer_id: customerId || null, resource_id: resourceId, starts_at: startsIso, ends_at: endsIso, confirm };
      const d = await run("Request test drive", () => post<TestDrive>("/v1/test-drive-appointments", body, { idempotencyKey: idem.keyFor(body) }), { success: confirm ? "Test drive confirmed" : "Test drive requested" });
      if (d) { idem.complete(); onDone(d); }
    }}>
      <h4>Request a test drive <span className="muted small">(times are entered in the dealership's local zone)</span></h4>
      <div className="form-row">
        <Field label="Listing / vehicle" wide>
          <select required value={listingId} onChange={(e) => { setListingId(e.target.value); setResourceId(""); }}>
            <option value="">{listings.loading ? "Loading…" : "Select…"}</option>
            {options.map((l) => <option key={l.id} value={l.id}>{l.title} — {l.seller?.display_name} ({l.location?.city})</option>)}
          </select>
        </Field>
        <Field label="Resource (staff / bay / plate)">
          <select required value={resourceId} onChange={(e) => setResourceId(e.target.value)}>
            <option value="">Select…</option>
            {res.map((r) => <option key={r.id} value={r.id}>{r.name} ({r.kind}, cap {r.capacity})</option>)}
          </select>
        </Field>
        <Field label="Customer">
          <select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
            <option value="">none</option>
            {(customers.data?.items ?? []).map((c) => <option key={c.id} value={c.id}>{c.display_name}</option>)}
          </select>
        </Field>
      </div>
      <div className="form-row">
        <Field label={`Start (local, ${tz})`} hint={startsIso ? <Mono>{startsIso}</Mono> : undefined}>
          <input type="datetime-local" required value={start} onChange={(e) => setStart(e.target.value)} />
        </Field>
        <Field label="Duration (min)"><input type="number" min={15} max={240} step={15} value={minutes} onChange={(e) => setMinutes(parseInt(e.target.value || "45", 10))} /></Field>
        <label className="check"><input type="checkbox" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} /> Confirm immediately (checks vehicle exclusivity &amp; resource capacity)</label>
      </div>
      <div className="form-actions"><Button type="submit" variant="primary" busy={busy === "Request test drive"} disabled={!listing || !resourceId}>Submit</Button><Button variant="ghost" onClick={onCancel}>Cancel</Button></div>
    </form>
  );
}
