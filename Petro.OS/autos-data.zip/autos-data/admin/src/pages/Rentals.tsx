import { useMemo, useState, type ReactNode } from "react";
import { useSearchParams } from "react-router-dom";
import { ApiError, get, post } from "../api/client";
import type { Customer, MaintenanceBlock, Page, RentalBooking } from "../api/types";
import { DataTable } from "../components/DataTable";
import { FilterBar, toQuery, useFilters } from "../components/FilterBar";
import { Amount, Banner, Button, ErrorPanel, Field, KV, Mono, Section, StatusPill, Tabs } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime, duration, inZone, money, toLocalInput, zonedInputToIso } from "../lib/format";
import { useAction, useIdempotencyKey, usePaged, useResource } from "../lib/hooks";
import { useOrgLookups, useRentalAssets, useRentalCategories } from "../lib/lookups";
import { parseOpen, RecordLink, useOpenRecord } from "../lib/nav";

const INITIAL = { status: "" };

export function Rentals() {
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") ?? "bookings";
  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Rentals</h1><p className="muted">Category bookings with capacity control, exact-vehicle assignment and maintenance blocks. Times shown in the branch's zone.</p></div>
      </div>
      <Tabs tabs={[{ id: "bookings", label: "Bookings" }, { id: "book", label: "Availability & new booking" }, { id: "fleet", label: "Fleet & maintenance" }]} active={tab}
        onChange={(t) => { const p = new URLSearchParams(params); p.set("tab", t); setParams(p); }} />
      {tab === "book" ? <AvailabilityAndBooking /> : tab === "fleet" ? <Fleet /> : <Bookings />}
    </div>
  );
}

function Bookings() {
  const filters = useFilters(INITIAL);
  const list = usePaged<RentalBooking>("/v1/rental-bookings", toQuery(filters.applied), { limit: 50 });
  const cats = useRentalCategories();
  const assets = useRentalAssets();
  const { locations } = useOrgLookups();
  const open = useOpenRecord();
  const [params] = useSearchParams();
  const active = parseOpen(params.get("open"));
  return <>
    <FilterBar page="rentals" filters={filters}>
      <Field label="Status"><select {...filters.bind("status")}>
        <option value="">any</option>{["confirmed", "checked_out", "returned", "cancelled", "no_show"].map((s) => <option key={s}>{s}</option>)}
      </select></Field>
    </FilterBar>
    <DataTable rows={list.items} rowKey={(b) => b.id} loading={list.loading} error={list.error} onRetry={list.reload}
      hasMore={list.hasMore} onLoadMore={list.loadMore} onRowClick={(b) => open("rental_booking", b.id)} activeKey={active?.type === "rental_booking" ? active.id : null}
      columns={[
        { key: "n", header: "Booking", render: (b) => <Mono>{b.booking_number}</Mono> },
        { key: "c", header: "Category", render: (b) => cats.find((c) => c.id === b.category_id)?.code ?? "—" },
        { key: "l", header: "Branch", render: (b) => locations.get(b.pickup_location_id)?.code ?? "—" },
        { key: "p", header: "Pickup (local)", render: (b) => inZone(b.local_pickup, b.pickup_timezone) },
        { key: "r", header: "Return (local)", render: (b) => inZone(b.local_return, b.return_timezone) },
        { key: "tz", header: "Zone", render: (b) => <Mono>{b.pickup_timezone}</Mono> },
        { key: "a", header: "Assigned", render: (b) => {
          const a = (b.assignments ?? []).find((x) => x.status === "active");
          return a ? <Mono>{assets.find((x) => x.id === a.rental_asset_id)?.fleet_number ?? "assigned"}</Mono> : <span className="muted">unassigned</span>;
        } },
        { key: "t", header: "Total", align: "right", render: (b) => <Amount minor={b.total_minor} currency={b.currency} formatted={b.total?.formatted} /> },
        { key: "s", header: "Status", render: (b) => <StatusPill value={b.status} /> },
        { key: "cu", header: "Customer", render: (b) => <RecordLink type="customer" id={b.customer_id} /> },
      ]} />
  </>;
}

function AvailabilityAndBooking() {
  const { can } = useApp();
  const { locations } = useOrgLookups();
  const cats = useRentalCategories();
  const assets = useRentalAssets();
  const customers = useResource<Page<Customer>>("/v1/customers", { limit: 200 });
  const rentalLocations = useMemo(() => [...locations.values()].filter((l) => cats.some((c) => c.organisation_id === l.organisation_id)), [locations, cats]);
  const [locId, setLocId] = useState("");
  const [catId, setCatId] = useState("");
  const d1 = new Date(Date.now() + 7 * 86400000); d1.setHours(10, 0, 0, 0);
  const d2 = new Date(d1.getTime() + 2 * 86400000);
  const [pickup, setPickup] = useState(toLocalInput(d1));
  const [ret, setRet] = useState(toLocalInput(d2));
  const [customerId, setCustomerId] = useState("");
  const [assetId, setAssetId] = useState("");
  const [avail, setAvail] = useState<{ peak_demand: number; available_vehicles: number; can_book: boolean; turnaround_buffer_seconds: number } | null>(null);
  const [quote, setQuote] = useState<Record<string, unknown> | null>(null);
  const [err, setErr] = useState<ApiError | null>(null);
  const { run, busy } = useAction();
  const idem = useIdempotencyKey();
  const open = useOpenRecord();
  const loc = locations.get(locId);
  const tz = loc?.timezone ?? "UTC";
  const pIso = zonedInputToIso(pickup, tz);
  const rIso = zonedInputToIso(ret, tz);
  const catOptions = cats.filter((c) => !loc || c.organisation_id === loc.organisation_id);
  const ready = locId && catId && pIso && rIso;

  const check = async () => {
    setErr(null);
    try {
      setAvail(await get("/v1/rental-availability", { location_id: locId, category_id: catId, pickup_at: pIso, return_at: rIso }));
    } catch (e) { setErr(e as ApiError); setAvail(null); }
  };

  return <>
    <Section title="Check availability">
      <div className="form-row">
        <Field label="Branch"><select value={locId} onChange={(e) => { setLocId(e.target.value); setAvail(null); }}>
          <option value="">Select…</option>{rentalLocations.map((l) => <option key={l.id} value={l.id}>{l.code} — {l.name}</option>)}
        </select></Field>
        <Field label="Category"><select value={catId} onChange={(e) => { setCatId(e.target.value); setAvail(null); }}>
          <option value="">Select…</option>{catOptions.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name} ({money(c.daily_rate_minor, c.currency)}/day)</option>)}
        </select></Field>
        <Field label={`Pickup (local ${tz})`} hint={pIso ? <Mono>{pIso}</Mono> : undefined}><input type="datetime-local" value={pickup} onChange={(e) => { setPickup(e.target.value); setAvail(null); }} /></Field>
        <Field label={`Return (local ${tz})`} hint={rIso ? <Mono>{rIso}</Mono> : undefined}><input type="datetime-local" value={ret} onChange={(e) => { setRet(e.target.value); setAvail(null); }} /></Field>
        <div className="form-actions"><Button variant="primary" small disabled={!ready} onClick={check}>Check availability</Button></div>
      </div>
      {err ? <ErrorPanel error={err} onDismiss={() => setErr(null)} /> : null}
      {avail ? (
        <div className={`avail ${avail.can_book ? "avail-ok" : "avail-no"}`} data-testid="availability">
          <strong>{avail.can_book ? "Bookable" : "Not bookable"}</strong>
          <KV rows={[
            ["Peak demand in window", avail.peak_demand],
            ["Available vehicles", avail.available_vehicles],
            ["Turnaround buffer", duration(avail.turnaround_buffer_seconds)],
          ]} />
        </div>
      ) : null}
    </Section>
    {can("rentals.book") ? (
      <Section title="New booking">
        <form onSubmit={async (e) => {
          e.preventDefault();
          const body: Record<string, unknown> = { location_id: locId, category_id: catId, pickup_at: pIso, return_at: rIso, customer_id: customerId || null };
          if (assetId) body.rental_asset_id = assetId;
          const b = await run("Create booking", () => post<RentalBooking>("/v1/rental-bookings", body, { idempotencyKey: idem.keyFor(body) }), { success: "Booking confirmed" });
          if (b) { idem.complete(); open("rental_booking", b.id); setAvail(null); }
        }}>
          <div className="form-row">
            <Field label="Customer"><select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
              <option value="">none</option>{(customers.data?.items ?? []).map((c) => <option key={c.id} value={c.id}>{c.display_name}</option>)}
            </select></Field>
            <Field label="Exact vehicle (optional)"><select value={assetId} onChange={(e) => setAssetId(e.target.value)}>
              <option value="">assign later</option>{assets.filter((a) => a.category_id === catId && a.status === "active").map((a) => <option key={a.id} value={a.id}>{a.fleet_number}</option>)}
            </select></Field>
            <div className="form-actions">
              <Button small disabled={!ready} busy={busy === "Rental quote"} onClick={async () => {
                const q = await run("Rental quote", () => post<Record<string, unknown>>("/v1/rental-quotes", { location_id: locId, category_id: catId, pickup_at: pIso, return_at: rIso, customer_id: customerId || null }), { noBump: true });
                if (q) setQuote(q);
              }}>Get price quote</Button>
              <Button type="submit" variant="primary" small disabled={!ready} busy={busy === "Create booking"}>Book category</Button>
            </div>
          </div>
          {quote ? <Banner kind="info">Rental quote: <strong>{money(quote.total_minor as number, String(quote.currency ?? "USD"))}</strong> {quote.expires_at ? <span className="muted small">valid until {dateTime(String(quote.expires_at))}</span> : null}</Banner> : null}
          {avail && !avail.can_book ? <Banner kind="warning">Availability check says this window is full; the booking will be rejected by capacity control.</Banner> : null}
        </form>
      </Section>
    ) : <Banner kind="info">Creating bookings requires <Mono>rentals.book</Mono>.</Banner>}
  </>;
}

function Fleet() {
  const assets = useRentalAssets();
  const cats = useRentalCategories();
  const { locations } = useOrgLookups();
  const orgName = useOrgName();
  const open = useOpenRecord();
  const { run, busy } = useAction();
  const [m, setM] = useState({ rental_asset_id: "", kind: "scheduled_service", starts: toLocalInput(new Date(Date.now() + 3 * 86400000)), ends: toLocalInput(new Date(Date.now() + 4 * 86400000)), reason: "" });
  const [created, setCreated] = useState<MaintenanceBlock[]>([]);
  const asset = assets.find((a) => a.id === m.rental_asset_id);
  const tz = (asset && locations.get(asset.home_location_id)?.timezone) || "UTC";
  return <>
    <Section title={`Rental assets (${assets.length})`}>
      <DataTable compact rows={assets} rowKey={(a) => a.id} onRowClick={(a) => open("rental_asset", a.id)}
        columns={[
          { key: "f", header: "Fleet #", render: (a) => <Mono>{a.fleet_number}</Mono> },
          { key: "c", header: "Category", render: (a) => cats.find((c) => c.id === a.category_id)?.code ?? "—" },
          { key: "h", header: "Home branch", render: (a) => locations.get(a.home_location_id)?.code ?? "—" },
          { key: "v", header: "Vehicle", render: (a) => <RecordLink type="vehicle" id={a.vehicle_id} /> },
          { key: "o", header: "Supplier", render: (a) => orgName(a.organisation_id) },
          { key: "s", header: "Status", render: (a) => <StatusPill value={a.status} /> },
          { key: "i", header: "In fleet since", render: (a) => dateTime(a.in_fleet_from, true) },
        ]} />
    </Section>
    <Section title="Categories">
      <DataTable compact rows={cats} rowKey={(c) => c.id}
        columns={[
          { key: "c", header: "Code", render: (c) => <Mono>{c.code}</Mono> },
          { key: "n", header: "Name", render: (c) => c.name },
          { key: "s", header: "Seats", align: "right", render: (c) => c.seats },
          { key: "t", header: "Transmission", render: (c) => c.transmission },
          { key: "b", header: "Turnaround", render: (c) => duration(c.turnaround_buffer) },
          { key: "r", header: "Daily rate", align: "right", render: (c) => <Amount minor={c.daily_rate_minor} currency={c.currency} /> },
          { key: "st", header: "Status", render: (c) => <StatusPill value={c.status} /> },
        ]} />
    </Section>
    <Section title="Block an asset for maintenance">
      <ActionGate perm="rentals.manage">
        <form className="form-row" onSubmit={async (e) => {
          e.preventDefault();
          const body = { rental_asset_id: m.rental_asset_id, kind: m.kind, starts_at: zonedInputToIso(m.starts, tz), ends_at: zonedInputToIso(m.ends, tz), reason: m.reason };
          const r = await run("Create maintenance block", () => post<MaintenanceBlock>("/v1/maintenance-blocks", body), { success: "Maintenance block created" });
          if (r) setCreated([r, ...created]);
        }}>
          <Field label="Asset"><select required value={m.rental_asset_id} onChange={(e) => setM({ ...m, rental_asset_id: e.target.value })}>
            <option value="">Select…</option>{assets.map((a) => <option key={a.id} value={a.id}>{a.fleet_number}</option>)}
          </select></Field>
          <Field label="Kind"><select value={m.kind} onChange={(e) => setM({ ...m, kind: e.target.value })}>
            {["scheduled_service", "repair", "inspection", "recall", "damage"].map((k) => <option key={k}>{k}</option>)}
          </select></Field>
          <Field label={`Starts (local ${tz})`}><input type="datetime-local" required value={m.starts} onChange={(e) => setM({ ...m, starts: e.target.value })} /></Field>
          <Field label={`Ends (local ${tz})`}><input type="datetime-local" required value={m.ends} onChange={(e) => setM({ ...m, ends: e.target.value })} /></Field>
          <Field label="Reason"><input required value={m.reason} onChange={(e) => setM({ ...m, reason: e.target.value })} /></Field>
          <div className="form-actions"><Button type="submit" variant="primary" small busy={busy === "Create maintenance block"}>Create block</Button></div>
        </form>
        <p className="muted small">Rejected if it overlaps an active assignment or would leave fewer vehicles than committed bookings.</p>
        {created.length ? (
          <DataTable compact rows={created} rowKey={(b) => b.id} columns={[
            { key: "a", header: "Asset", render: (b) => assets.find((a) => a.id === b.rental_asset_id)?.fleet_number },
            { key: "k", header: "Kind", render: (b) => b.kind },
            { key: "s", header: "Window", render: (b) => `${dateTime(b.starts_at, true)} → ${dateTime(b.ends_at, true)}` },
            { key: "st", header: "Status", render: (b) => <StatusPill value={b.status} /> },
            { key: "r", header: "Reason", render: (b) => b.reason },
          ]} />
        ) : null}
      </ActionGate>
    </Section>
  </>;
}

function ActionGate({ perm, children }: { perm: string; children: ReactNode }) {
  const { can } = useApp();
  if (!can(perm)) return <Banner kind="info">This requires <Mono>{perm}</Mono>.</Banner>;
  return <>{children}</>;
}

