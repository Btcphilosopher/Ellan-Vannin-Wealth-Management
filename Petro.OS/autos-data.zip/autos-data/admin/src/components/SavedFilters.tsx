import { useState } from "react";
import { del, post } from "../api/client";
import type { SavedFilter } from "../api/types";
import { useAction, useResource } from "../lib/hooks";
import { Button } from "./ui";

/**
 * Saved filters for a section (GET/POST/DELETE /v1/saved-filters, page key
 * per section, params = the current filter object).
 */
export function SavedFilters<F extends object>({ page, current, onApply }: { page: string; current: F; onApply(params: F): void }) {
  const list = useResource<{ items: SavedFilter[] }>("/v1/saved-filters", { page });
  const [sel, setSel] = useState("");
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);
  const { run, busy } = useAction();
  const items = list.data?.items ?? [];

  const cleaned = Object.fromEntries(Object.entries(current).filter(([, v]) => v !== "" && v !== null && v !== undefined && v !== false));
  const save = async () => {
    if (!name.trim()) return;
    const r = await run("Save filter", () => post<SavedFilter>("/v1/saved-filters", { page, name: name.trim(), params: cleaned }),
      { success: "Filter saved", noBump: true });
    if (r) { setSaving(false); setName(""); setSel(r.id); list.reload(); }
  };

  return (
    <div className="saved-filters">
      <select aria-label="Saved filters" value={sel} onChange={(e) => {
        const id = e.target.value;
        setSel(id);
        const f = items.find((x) => x.id === id);
        if (f) onApply(f.params as F);
      }}>
        <option value="">Saved filters{items.length ? ` (${items.length})` : ""}…</option>
        {items.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
      </select>
      {sel ? (
        <Button small variant="ghost" title="Delete this saved filter" busy={busy === "Delete filter"} onClick={async () => {
          await run("Delete filter", () => del(`/v1/saved-filters/${sel}`), { success: "Saved filter deleted", noBump: true });
          setSel("");
          list.reload();
        }}>Delete</Button>
      ) : null}
      {saving ? (
        // Not a <form>: this sits inside the filter bar's form (nested forms are invalid HTML).
        <span className="inline-form" role="group" aria-label="Save current filter">
          <input autoFocus placeholder="Filter name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80}
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); void save(); } }} />
          <Button small variant="primary" busy={busy === "Save filter"} onClick={() => void save()}>Save</Button>
          <Button small variant="ghost" onClick={() => setSaving(false)}>Cancel</Button>
        </span>
      ) : (
        <Button small onClick={() => setSaving(true)} title={`Save current filter: ${JSON.stringify(cleaned)}`}>Save current…</Button>
      )}
    </div>
  );
}
