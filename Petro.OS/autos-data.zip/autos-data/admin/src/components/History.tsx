import type { ReactNode } from "react";
import type { AuditEvent, StatusHistory } from "../api/types";
import { useApp } from "../lib/app";
import { dateTime, humanize } from "../lib/format";
import { usePaged } from "../lib/hooks";
import { DataTable } from "./DataTable";
import { Banner, CopyId, Mono, Section, StatusPill } from "./ui";

export function renderChanges(changes: Record<string, unknown> | null | undefined): ReactNode {
  if (!changes || Object.keys(changes).length === 0) return <span className="muted">—</span>;
  return (
    <ul className="changes">
      {Object.entries(changes).map(([k, v]) => {
        if (v && typeof v === "object" && !Array.isArray(v) && ("from" in v || "to" in v)) {
          const c = v as { from?: unknown; to?: unknown };
          return (
            <li key={k}><Mono>{k}</Mono>: <span className="from">{fmtVal(c.from)}</span> → <span className="to">{fmtVal(c.to)}</span></li>
          );
        }
        return <li key={k}><Mono>{k}</Mono>: {fmtVal(v)}</li>;
      })}
    </ul>
  );
}

function fmtVal(v: unknown): string {
  if (v === null || v === undefined) return "∅";
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

/** Change history from the append-only audit trail for one record. */
export function AuditHistory({ targetType, targetId, title = "Audit trail" }: { targetType: string; targetId: string; title?: string }) {
  const { can } = useApp();
  const allowed = can("audit.read");
  const page = usePaged<AuditEvent>(allowed ? "/v1/audit-events" : null, { target_type: targetType, target_id: targetId },
    { cursorParam: "before_id", limit: 50 });
  if (!allowed) {
    return <Banner kind="info">Audit history requires the <Mono>audit.read</Mono> permission.</Banner>;
  }
  return (
    <Section title={<>{title} <span className="muted small">target_type=<Mono>{targetType}</Mono></span></>}>
      <DataTable compact rows={page.items} rowKey={(r) => String(r.id)} loading={page.loading} error={page.error} onRetry={page.reload}
        hasMore={page.hasMore} onLoadMore={page.loadMore} empty="No audit events recorded for this record."
        columns={[
          { key: "t", header: "When", render: (r) => <span title={r.occurred_at}>{dateTime(r.occurred_at)}</span>, width: 150 },
          { key: "a", header: "Action", render: (r) => <Mono>{r.action}</Mono> },
          { key: "who", header: "Actor", render: (r) => <>{humanize(r.actor_kind)} {r.actor_user_id ? <CopyId id={r.actor_user_id} /> : null}</> },
          { key: "c", header: "Changes", render: (r) => renderChanges(r.changes) },
          { key: "rid", header: "Request", render: (r) => <CopyId id={r.request_id} /> },
        ]} />
    </Section>
  );
}

export function StatusHistoryTable({ rows }: { rows: StatusHistory[] }) {
  return (
    <DataTable compact rows={rows} rowKey={(r) => r.id} empty="No status changes."
      columns={[
        { key: "t", header: "When", render: (r) => dateTime(r.occurred_at), width: 150 },
        { key: "f", header: "From", render: (r) => <StatusPill value={r.from_status} /> },
        { key: "to", header: "To", render: (r) => <StatusPill value={r.to_status} /> },
        { key: "r", header: "Reason", render: (r) => r.reason ?? <span className="muted">—</span> },
        { key: "a", header: "Actor", render: (r) => <>{humanize(r.actor_kind)} {r.actor_user_id ? <CopyId id={r.actor_user_id} /> : null}</> },
        { key: "rid", header: "Request", render: (r) => <CopyId id={r.request_id} /> },
      ]} />
  );
}
