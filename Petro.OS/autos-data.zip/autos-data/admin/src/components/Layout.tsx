import { useState } from "react";
import { NavLink, Outlet, useSearchParams } from "react-router-dom";
import { useApp } from "../lib/app";
import { invalidateLookups } from "../lib/lookups";
import { DetailDrawer } from "./Drawer";
import { Toasts } from "./ui";

export const NAV: { to: string; label: string; icon: string }[] = [
  { to: "/", label: "Overview", icon: "◧" },
  { to: "/vehicles", label: "Vehicles", icon: "⛟" },
  { to: "/listings", label: "Listings", icon: "☰" },
  { to: "/dealers", label: "Dealers", icon: "⌂" },
  { to: "/customers", label: "Customers", icon: "☺" },
  { to: "/quotes", label: "Quotes", icon: "≡" },
  { to: "/reservations", label: "Reservations", icon: "⧗" },
  { to: "/test-drives", label: "Test Drives", icon: "◷" },
  { to: "/rentals", label: "Rentals", icon: "⇆" },
  { to: "/payments", label: "Payments", icon: "¤" },
  { to: "/imports", label: "Imports", icon: "⇪" },
  { to: "/audit", label: "Audit", icon: "✎" },
  { to: "/reports", label: "Reports", icon: "▤" },
];

export function Layout() {
  const { branding, me, activeOrg, setActiveOrg, logout } = useApp();
  const [params] = useSearchParams();
  const drawerOpen = params.has("open");
  const [navOpen, setNavOpen] = useState(false);
  const memberships = me?.memberships ?? [];
  const role = memberships.find((m) => m.organisation_id === activeOrg)?.role ?? memberships.map((m) => m.role).join(", ");
  return (
    <div className={`app${drawerOpen ? " has-drawer" : ""}`}>
      <header className="topbar">
        <button type="button" className="nav-toggle" aria-label="Toggle navigation" onClick={() => setNavOpen(!navOpen)}>☰</button>
        <div className="brand">
          <span className="brand-name">{branding?.name ?? "…"}</span>
          <span className="brand-product">{branding?.product}</span>
        </div>
        <span className="env-tag" title="Staff administration — operational database">STAFF ADMIN</span>
        <div className="topbar-spacer" />
        {memberships.length > 1 ? (
          <label className="org-switch">
            <span>Organisation</span>
            <select value={activeOrg ?? ""} onChange={(e) => { invalidateLookups(); setActiveOrg(e.target.value || null); }} aria-label="Acting organisation">
              <option value="">All my organisations</option>
              {memberships.map((m) => <option key={m.organisation_id} value={m.organisation_id}>{m.organisation_name} ({m.role})</option>)}
            </select>
          </label>
        ) : memberships.length === 1 ? (
          <span className="org-single" title={memberships[0].organisation_id}>{memberships[0].organisation_name}</span>
        ) : null}
        <div className="user">
          <span className="user-name">{me?.display_name}</span>
          <span className="user-role">{me?.email} · {me?.is_platform ? "platform_admin" : role}</span>
        </div>
        <button type="button" className="btn btn-ghost btn-sm topbar-btn" onClick={() => { invalidateLookups(); logout(); }}>Log out</button>
      </header>
      <nav className={`sidebar${navOpen ? " sidebar-open" : ""}`} aria-label="Sections">
        {NAV.map((n) => (
          <NavLink key={n.to} to={n.to} end={n.to === "/"} className={({ isActive }) => `nav-item${isActive ? " nav-active" : ""}`} onClick={() => setNavOpen(false)}>
            <span className="nav-icon" aria-hidden>{n.icon}</span>{n.label}
          </NavLink>
        ))}
        <div className="sidebar-foot">No SQL console · status changes only via domain actions</div>
      </nav>
      <div className="workspace">
        <main className="content" id="main">
          <Outlet />
        </main>
        <DetailDrawer />
      </div>
      <footer className="footer">
        <span>{branding?.name} · {branding?.product}</span>
        <span className="disclaimer">{branding?.disclaimer}</span>
      </footer>
      <Toasts />
    </div>
  );
}
