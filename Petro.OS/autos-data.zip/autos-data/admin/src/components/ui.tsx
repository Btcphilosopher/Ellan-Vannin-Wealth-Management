import { useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import { ApiError } from "../api/client";
import { useApp } from "../lib/app";
import { humanize, money } from "../lib/format";

// ---------------------------------------------------------------- status pills
const TONES: Record<string, string> = {};
const tone = (t: string, ...names: string[]) => names.forEach((n) => (TONES[n] = t));
tone("green", "published", "succeeded", "confirmed", "valid", "applied", "completed", "resolved", "active", "available", "accepted",
  "dealer_accepted", "paid", "returned", "verified", "ok", "healthy", "fresh", "known", "eligible", "issued", "create", "update", "true");
tone("amber", "draft", "pending", "held", "requested", "processing", "validated", "awaiting", "warning", "agreement_pending",
  "planned", "unverified", "stale", "pending_review", "unknown", "requires_action", "awaiting_approval", "approved", "in_progress",
  "investigating", "open", "unconfirmed", "awaiting_provider", "created", "uploaded", "validating", "applying", "retrying", "no_change", "duplicate", "out_of_order", "skip", "requires_review", "expired_effective", "partial_accept");
tone("red", "failed", "invalid", "error", "dead", "rejected", "cancelled", "canceled", "declined", "expired", "no_show", "withdrawn",
  "written_off", "suspended", "out_of_service", "revoked", "disputed", "reject", "not_eligible", "unhealthy", "released", "blocked", "false", "lapsed");
tone("blue", "sold", "converted", "checked_out", "agreement_signed", "handed_over", "in_service", "reserved", "under_offer",
  "committed", "all_or_nothing", "applied_with_skips", "skipped", "info", "published_event");
tone("grey", "not_applicable", "archived", "closed", "ignored", "merged", "inactive");

export function StatusPill({ value, title }: { value: string | null | undefined; title?: string }) {
  if (value === null || value === undefined || value === "") return <span className="muted">—</span>;
  const v = String(value);
  return <span className={`pill pill-${TONES[v] ?? "grey"}`} title={title ?? v}>{humanize(v)}</span>;
}

export function SeverityBadge({ severity }: { severity: string }) {
  return <span className={`sev sev-${severity === "error" ? "error" : severity === "warning" ? "warning" : "info"}`}>{severity}</span>;
}

export function Mono({ children, title }: { children: ReactNode; title?: string }) {
  return <span className="mono" title={title}>{children}</span>;
}

export function CopyId({ id, short = true }: { id: string | null | undefined; short?: boolean }) {
  const [copied, setCopied] = useState(false);
  if (!id) return <span className="muted">—</span>;
  return (
    <span className="mono copy-id" title={`${id} (click to copy)`}
      onClick={(e) => {
        e.stopPropagation();
        void navigator.clipboard?.writeText(id).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1000); }).catch(() => undefined);
      }}>
      {short && id.length > 13 ? `${id.slice(0, 8)}…` : id}{copied ? " ✓" : ""}
    </span>
  );
}

export function Amount({ minor, currency, formatted }: { minor: number | string | null | undefined; currency?: string | null; formatted?: string | null }) {
  return <span className="num">{formatted ?? money(minor, currency)}</span>;
}

// ---------------------------------------------------------------- buttons
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "danger" | "ghost"; busy?: boolean; small?: boolean };
export function Button({ variant = "secondary", busy, small, className, children, disabled, ...rest }: BtnProps) {
  return (
    <button type="button" {...rest} disabled={disabled || busy} aria-busy={busy || undefined}
      className={`btn btn-${variant}${small ? " btn-sm" : ""}${className ? ` ${className}` : ""}`}>
      {busy ? <span className="spinner" aria-hidden /> : null}
      {children}
    </button>
  );
}

/**
 * Action guarded by a permission. Hidden when the user lacks the permission
 * entirely; disabled (with the reason as a tooltip) when blocked by state.
 */
export function ActionButton({ perm, org, blockedReason, hideIfDenied = true, ...rest }: BtnProps & {
  perm: string; org?: string | null; blockedReason?: string | null; hideIfDenied?: boolean;
}) {
  const { can } = useApp();
  const allowed = can(perm, org);
  if (!allowed && hideIfDenied) return null;
  const reason = !allowed ? `Requires permission ${perm}` : blockedReason || undefined;
  return <Button {...rest} disabled={rest.disabled || !allowed || !!blockedReason} title={reason ?? rest.title} data-perm={perm} />;
}

// ---------------------------------------------------------------- layout bits
export function Spinner({ label }: { label?: string }) {
  return <div className="loading"><span className="spinner" aria-hidden /> {label ?? "Loading…"}</div>;
}

export function Empty({ children }: { children?: ReactNode }) {
  return <div className="empty">{children ?? "No records match."}</div>;
}

export function Section({ title, actions, children, className }: { title?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`section${className ? ` ${className}` : ""}`}>
      {(title || actions) && (
        <header className="section-head">
          {title ? <h3>{title}</h3> : <span />}
          {actions ? <div className="section-actions">{actions}</div> : null}
        </header>
      )}
      {children}
    </section>
  );
}

export function KV({ rows }: { rows: [ReactNode, ReactNode][] }) {
  return (
    <dl className="kv">
      {rows.map(([k, v], i) => (
        <div key={i} className="kv-row"><dt>{k}</dt><dd>{v === null || v === undefined || v === "" ? <span className="muted">—</span> : v}</dd></div>
      ))}
    </dl>
  );
}

export function Field({ label, children, hint, wide }: { label: string; children: ReactNode; hint?: ReactNode; wide?: boolean }) {
  return (
    <label className={`field${wide ? " field-wide" : ""}`}>
      <span className="field-label">{label}</span>
      {children}
      {hint ? <span className="field-hint">{hint}</span> : null}
    </label>
  );
}

export function Tabs({ tabs, active, onChange }: { tabs: { id: string; label: ReactNode; count?: number | null }[]; active: string; onChange(id: string): void }) {
  return (
    <div className="tabs" role="tablist">
      {tabs.map((t) => (
        <button key={t.id} type="button" role="tab" aria-selected={active === t.id} className={`tab${active === t.id ? " tab-active" : ""}`}
          onClick={() => onChange(t.id)}>
          {t.label}{t.count !== undefined && t.count !== null ? <span className="tab-count">{t.count}</span> : null}
        </button>
      ))}
    </div>
  );
}

export function Banner({ kind, children }: { kind: "error" | "warning" | "info" | "success"; children: ReactNode }) {
  return <div className={`banner banner-${kind}`} role={kind === "error" ? "alert" : "status"}>{children}</div>;
}

export function JsonView({ value }: { value: unknown }) {
  if (value === null || value === undefined) return <span className="muted">—</span>;
  return <pre className="json">{JSON.stringify(value, null, 2)}</pre>;
}

// ---------------------------------------------------------------- problem+json
export function ProblemDetails({ error }: { error: ApiError }) {
  return (
    <div className="problem">
      <div className="problem-line">
        <span className="mono problem-code">{error.code}</span>
        {error.status ? <span className="muted"> · HTTP {error.status}</span> : null}
      </div>
      <div className="problem-detail">{error.detail}</div>
      {error.errors.length > 0 && (
        <ul className="problem-errors">
          {error.errors.map((f, i) => (
            <li key={i}>
              {f.severity ? <SeverityBadge severity={f.severity} /> : null}
              {f.field ? <span className="mono">{f.field}</span> : null}
              {f.code ? <span className="mono muted"> [{f.code}]</span> : null} {f.message}
            </li>
          ))}
        </ul>
      )}
      {error.requestId ? <div className="problem-rid">request_id <span className="mono">{error.requestId}</span></div> : null}
    </div>
  );
}

export function ErrorPanel({ error, onReload, onDismiss }: { error: ApiError | null; onReload?: () => void; onDismiss?: () => void }) {
  if (!error) return null;
  const conflict = error.isVersionConflict;
  const forbidden = error.status === 403;
  return (
    <div className={`error-panel${conflict ? " error-conflict" : ""}`} role="alert">
      <div className="error-title">
        {conflict ? "This record was changed by someone else" : forbidden ? "You do not have permission for this" : error.title || "Request failed"}
      </div>
      {conflict ? <p className="muted">Reload to see the latest version, then repeat your change.</p> : null}
      <ProblemDetails error={error} />
      <div className="error-actions">
        {onReload ? <Button small variant={conflict ? "primary" : "secondary"} onClick={onReload}>Reload</Button> : null}
        {onDismiss ? <Button small variant="ghost" onClick={onDismiss}>Dismiss</Button> : null}
      </div>
    </div>
  );
}

export function Toasts() {
  const { toasts, dismiss } = useApp();
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast toast-${t.kind}`}>
          <div className="toast-head">
            <strong>{t.error?.isVersionConflict ? "Record changed by someone else — reload and retry" : t.title}</strong>
            <button type="button" className="toast-x" aria-label="Dismiss" onClick={() => dismiss(t.id)}>×</button>
          </div>
          {t.message ? <div>{t.message}</div> : null}
          {t.error ? <ProblemDetails error={t.error} /> : null}
        </div>
      ))}
    </div>
  );
}

export function Countdown({ seconds }: { seconds: number }) {
  const s = Math.max(0, Math.floor(seconds));
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const txt = h ? `${h}:${String(m % 60).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}` : `${m}:${String(s % 60).padStart(2, "0")}`;
  return <span className={`countdown${s < 300 ? " countdown-low" : ""}`}>{s === 0 ? "expired" : txt}</span>;
}

export function Check({ value }: { value: boolean | null | undefined }) {
  if (value === null || value === undefined) return <span className="muted">—</span>;
  return value ? <span className="yes">Yes</span> : <span className="no">No</span>;
}
