import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { parseOpen, RECORD_LABEL, useCloseRecord } from "../lib/nav";
import { DETAILS } from "../details";

/** Right-side drawer showing whichever record is named by ?open=<type>:<id>. */
export function DetailDrawer() {
  const [params] = useSearchParams();
  const open = parseOpen(params.get("open"));
  const close = useCloseRecord();

  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => { if (e.key === "Escape" && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement)) close(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, close]);

  if (!open) return null;
  const Detail = DETAILS[open.type];
  return (
    <aside className="drawer" aria-label={`${RECORD_LABEL[open.type]} detail`} data-testid="detail-drawer">
      <Detail key={`${open.type}:${open.id}`} id={open.id} />
    </aside>
  );
}
