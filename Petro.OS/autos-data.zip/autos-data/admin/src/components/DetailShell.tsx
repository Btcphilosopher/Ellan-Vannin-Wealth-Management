import { useState, type ReactNode } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ApiError } from "../api/client";
import { RECORD_LABEL, useCloseRecord, type RecordType } from "../lib/nav";
import { Button, ErrorPanel, Spinner, Tabs } from "./ui";

export interface ShellTab {
  id: string;
  label: ReactNode;
  count?: number | null;
  render: () => ReactNode;
}

/** Common chrome for a record detail panel: header, actions, tabs, error panel. */
export function DetailShell({ type, id, title, subtitle, status, actions, tabs, loading, error, onReload, actionError, onDismissError }: {
  type: RecordType;
  id: string;
  title?: ReactNode;
  subtitle?: ReactNode;
  status?: ReactNode;
  actions?: ReactNode;
  tabs: ShellTab[];
  loading?: boolean;
  error?: ApiError | null;
  onReload?: () => void;
  actionError?: ApiError | null;
  onDismissError?: () => void;
}) {
  const close = useCloseRecord();
  const navigate = useNavigate();
  const location = useLocation();
  const depth = (location.state as { drawerDepth?: number } | null)?.drawerDepth ?? 0;
  const [tab, setTab] = useState(tabs[0]?.id ?? "overview");
  const current = tabs.find((t) => t.id === tab) ?? tabs[0];
  return (
    <div className="detail">
      <header className="detail-head">
        <div className="detail-nav">
          {depth > 1 ? <Button small variant="ghost" onClick={() => navigate(-1)} title="Back to previous record">← Back</Button> : null}
          <span className="detail-type">{RECORD_LABEL[type]}</span>
          <span className="mono muted small" title={id}>{id}</span>
          <span className="spacer" />
          {onReload ? <Button small variant="ghost" onClick={onReload} title="Reload">↻</Button> : null}
          <Button small variant="ghost" onClick={close} aria-label="Close detail" title="Close (Esc)">✕</Button>
        </div>
        <div className="detail-title">
          <h2>{title ?? (loading ? "Loading…" : RECORD_LABEL[type])}</h2>
          {status}
        </div>
        {subtitle ? <div className="detail-sub">{subtitle}</div> : null}
        {actions ? <div className="detail-actions">{actions}</div> : null}
        {!error && tabs.length > 1 ? <Tabs tabs={tabs.map((t) => ({ id: t.id, label: t.label, count: t.count }))} active={current?.id ?? ""} onChange={setTab} /> : null}
      </header>
      {actionError ? <ErrorPanel error={actionError} onReload={actionError.isVersionConflict ? () => { onDismissError?.(); onReload?.(); } : undefined} onDismiss={onDismissError} /> : null}
      {error ? <ErrorPanel error={error} onReload={onReload} /> : null}
      <div className="detail-body">
        {loading && !title ? <Spinner /> : null}
        {!error && current && (title || !loading) ? current.render() : null}
      </div>
    </div>
  );
}
