import type { ReactNode } from "react";
import { ApiError } from "../api/client";
import { Button, Empty, ErrorPanel } from "./ui";

export interface Column<T> {
  key: string;
  header: ReactNode;
  render: (row: T) => ReactNode;
  className?: string;
  width?: number | string;
  align?: "right" | "left" | "center";
}

interface Props<T> {
  rows: T[];
  columns: Column<T>[];
  rowKey: (row: T) => string;
  onRowClick?: (row: T) => void;
  activeKey?: string | null;
  loading?: boolean;
  error?: ApiError | null;
  onRetry?: () => void;
  hasMore?: boolean;
  onLoadMore?: () => void;
  empty?: ReactNode;
  selectable?: boolean;
  selected?: Set<string>;
  onSelectedChange?: (s: Set<string>) => void;
  isSelectable?: (row: T) => boolean;
  rowClassName?: (row: T) => string | undefined;
  caption?: ReactNode;
  compact?: boolean;
  maxHeight?: number | string;
}

export function DataTable<T>(p: Props<T>) {
  const selected = p.selected ?? new Set<string>();
  const selectableRows = p.selectable ? p.rows.filter((r) => (p.isSelectable ? p.isSelectable(r) : true)) : [];
  const allSelected = selectableRows.length > 0 && selectableRows.every((r) => selected.has(p.rowKey(r)));
  const toggle = (k: string) => {
    const n = new Set(selected);
    if (n.has(k)) n.delete(k); else n.add(k);
    p.onSelectedChange?.(n);
  };
  return (
    <div className="table-wrap">
      <div className="table-scroll" style={p.maxHeight ? { maxHeight: p.maxHeight } : undefined}>
        <table className={`grid${p.compact ? " grid-compact" : ""}`}>
          {p.caption ? <caption>{p.caption}</caption> : null}
          <thead>
            <tr>
              {p.selectable ? (
                <th className="col-check">
                  <input type="checkbox" aria-label="Select all" checked={allSelected}
                    onChange={() => p.onSelectedChange?.(allSelected ? new Set() : new Set(selectableRows.map(p.rowKey)))} />
                </th>
              ) : null}
              {p.columns.map((c) => (
                <th key={c.key} style={{ width: c.width, textAlign: c.align }} className={c.className}>{c.header}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {p.rows.map((r) => {
              const k = p.rowKey(r);
              const canSel = p.selectable && (p.isSelectable ? p.isSelectable(r) : true);
              return (
                <tr key={k} className={[p.onRowClick ? "clickable" : "", p.activeKey === k ? "row-active" : "", p.rowClassName?.(r) ?? ""].join(" ").trim() || undefined}
                  onClick={p.onRowClick ? () => p.onRowClick!(r) : undefined}
                  tabIndex={p.onRowClick ? 0 : undefined}
                  onKeyDown={p.onRowClick ? (e) => { if (e.key === "Enter") p.onRowClick!(r); } : undefined}>
                  {p.selectable ? (
                    <td className="col-check" onClick={(e) => e.stopPropagation()}>
                      <input type="checkbox" aria-label="Select row" disabled={!canSel} checked={selected.has(k)} onChange={() => toggle(k)} />
                    </td>
                  ) : null}
                  {p.columns.map((c) => (
                    <td key={c.key} className={c.className} style={{ textAlign: c.align }}>{c.render(r)}</td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
        {!p.loading && !p.error && p.rows.length === 0 ? <Empty>{p.empty}</Empty> : null}
      </div>
      {p.error ? <ErrorPanel error={p.error} onReload={p.onRetry} /> : null}
      <div className="table-foot">
        <span className="muted">{p.rows.length} row{p.rows.length === 1 ? "" : "s"}{p.hasMore ? " loaded" : ""}</span>
        {p.loading ? <span className="muted"><span className="spinner" /> Loading…</span> : null}
        {p.hasMore && !p.loading ? <Button small onClick={p.onLoadMore}>Load more</Button> : null}
      </div>
    </div>
  );
}
