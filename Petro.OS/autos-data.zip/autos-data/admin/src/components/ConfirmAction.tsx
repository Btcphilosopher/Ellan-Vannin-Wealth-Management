import { useState, type ReactNode } from "react";
import { useApp } from "../lib/app";
import { Button } from "./ui";

/**
 * A permission-guarded domain action that asks for confirmation (and an
 * optional / required reason) inline before calling the action endpoint.
 */
export function ConfirmAction({ label, perm, org, reason = "none", variant = "secondary", blockedReason, confirmText, busy, onConfirm, children }: {
  label: string;
  perm: string;
  org?: string | null;
  reason?: "none" | "optional" | "required";
  variant?: "primary" | "secondary" | "danger";
  blockedReason?: string | null;
  confirmText?: ReactNode;
  busy?: boolean;
  onConfirm(reason: string | null): Promise<unknown> | void;
  children?: ReactNode;
}) {
  const { can } = useApp();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  if (!can(perm, org)) return null;
  if (!open) {
    return (
      <Button variant={variant} small disabled={!!blockedReason} title={blockedReason ?? undefined} data-perm={perm} onClick={() => setOpen(true)}>
        {label}
      </Button>
    );
  }
  return (
    <form className="confirm-box" onSubmit={async (e) => {
      e.preventDefault();
      if (reason === "required" && !text.trim()) return;
      await onConfirm(text.trim() || null);
      setOpen(false);
      setText("");
    }}>
      <span className="confirm-q">{confirmText ?? `${label}?`}</span>
      {children}
      {reason !== "none" ? (
        <input autoFocus placeholder={reason === "required" ? "Reason (required)" : "Reason (optional)"} value={text}
          onChange={(e) => setText(e.target.value)} required={reason === "required"} maxLength={500} />
      ) : null}
      <Button small type="submit" variant={variant === "secondary" ? "primary" : variant} busy={busy}>Confirm {label.toLowerCase()}</Button>
      <Button small variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
    </form>
  );
}
