import { useCallback, useState, type ReactNode } from "react";
import { SavedFilters } from "./SavedFilters";
import { Button } from "./ui";

/** Draft vs applied filter state: edits apply on submit; saved filters apply immediately. */
export function useFilters<F extends object>(initial: F) {
  const [draft, setDraft] = useState<F>(initial);
  const [applied, setApplied] = useState<F>(initial);
  const set = useCallback(<K extends keyof F>(k: K, v: F[K]) => setDraft((d) => ({ ...d, [k]: v })), []);
  const apply = useCallback((f?: F) => {
    const next = f ? { ...initial, ...f } : draft;
    setDraft(next);
    setApplied(next);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draft]);
  const reset = useCallback(() => { setDraft(initial); setApplied(initial); }, [initial]);
  /** bind a text/select input to a filter key */
  const bind = useCallback(<K extends keyof F>(k: K) => ({
    value: (draft[k] ?? "") as unknown as string,
    onChange: (e: { target: { value: string } }) => set(k, e.target.value as unknown as F[K]),
  }), [draft, set]);
  return { draft, applied, set, apply, reset, bind };
}

export function FilterBar<F extends object>({ page, filters, children, extra }: {
  page: string;
  filters: ReturnType<typeof useFilters<F>>;
  children: ReactNode;
  extra?: ReactNode;
}) {
  const active = Object.values(filters.applied).filter((v) => v !== "" && v !== null && v !== undefined && v !== false).length;
  return (
    <form className="filterbar" onSubmit={(e) => { e.preventDefault(); filters.apply(); }} role="search">
      <div className="filter-fields">{children}</div>
      <div className="filter-actions">
        <Button type="submit" variant="primary" small>Apply</Button>
        <Button small variant="ghost" onClick={filters.reset} disabled={active === 0}>Reset{active ? ` (${active})` : ""}</Button>
        <SavedFilters page={page} current={filters.applied} onApply={(p) => filters.apply(p)} />
        {extra}
      </div>
    </form>
  );
}

/** Strip empty filter values before sending as query parameters. */
export function toQuery(f: object): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(f)) {
    if (v === "" || v === null || v === undefined || v === false) continue;
    out[k] = String(v);
  }
  return out;
}
