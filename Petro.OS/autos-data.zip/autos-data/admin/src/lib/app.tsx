import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ApiError, authEvents, get, post, session, uuid } from "../api/client";
import type { Branding, Me, Organisation } from "../api/types";

// ---------------------------------------------------------------- toasts
export interface Toast {
  id: string;
  kind: "success" | "error" | "info";
  title: string;
  error?: ApiError;
  message?: string;
}

interface AppState {
  branding: Branding | null;
  me: Me | null;
  loading: boolean;
  activeOrg: string | null;
  orgNames: Map<string, string>;
  login(email: string): Promise<void>;
  logout(): void;
  setActiveOrg(id: string | null): void;
  /** true if the user holds `perm` in `orgId` (or in any org when orgId is omitted). platform_admin has all. */
  can(perm: string, orgId?: string | null): boolean;
  toasts: Toast[];
  toast(t: Omit<Toast, "id">): void;
  dismiss(id: string): void;
  /** monotonically increasing counter; lists reload when it changes */
  dataVersion: number;
  bump(): void;
}

const Ctx = createContext<AppState | null>(null);

export function useApp(): AppState {
  const c = useContext(Ctx);
  if (!c) throw new Error("AppProvider missing");
  return c;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [branding, setBranding] = useState<Branding | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeOrg, setActiveOrgState] = useState<string | null>(session.org);
  const [orgNames, setOrgNames] = useState<Map<string, string>>(new Map());
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [dataVersion, setDataVersion] = useState(0);

  const toast = useCallback((t: Omit<Toast, "id">) => {
    const id = uuid();
    setToasts((x) => [...x.slice(-4), { ...t, id }]);
    if (t.kind !== "error") setTimeout(() => setToasts((x) => x.filter((y) => y.id !== id)), 4500);
  }, []);
  const dismiss = useCallback((id: string) => setToasts((x) => x.filter((y) => y.id !== id)), []);

  const loadMe = useCallback(async () => {
    if (!session.token) {
      setMe(null);
      setLoading(false);
      return;
    }
    try {
      const m = await get<Me>("/v1/me");
      // A stale X-Organisation-Id (from another user) would be rejected; drop it.
      if (session.org && !m.memberships.some((x) => x.organisation_id === session.org) && !m.is_platform) {
        session.org = null;
        setActiveOrgState(null);
      }
      setMe(m);
      try {
        const orgs = await get<{ items: Organisation[] }>("/v1/organisations");
        setOrgNames(new Map(orgs.items.map((o) => [o.id, o.display_name])));
      } catch { /* optional */ }
    } catch (e) {
      if (e instanceof ApiError && (e.status === 401 || e.code === "organisation_not_member")) {
        session.token = null;
        session.org = null;
        setMe(null);
      } else {
        toast({ kind: "error", title: "Could not load your profile", error: e as ApiError });
      }
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    get<Branding>("/v1/branding").then(setBranding).catch(() =>
      setBranding({ name: "Autos Data", product: "Vehicle Marketplace Database & Operations", disclaimer: "", simulator_enabled: false, dev_auth_enabled: false }));
    void loadMe();
  }, [loadMe]);

  useEffect(() => {
    const h = () => {
      session.token = null;
      setMe(null);
    };
    authEvents.addEventListener("unauthorized", h);
    return () => authEvents.removeEventListener("unauthorized", h);
  }, []);

  useEffect(() => {
    if (branding) document.title = `${branding.name} — Admin`;
  }, [branding]);

  const login = useCallback(async (email: string) => {
    const r = await post<{ access_token: string }>("/v1/auth/token", { email }, { noAuth: true });
    session.token = r.access_token;
    session.org = null;
    setActiveOrgState(null);
    setLoading(true);
    await loadMe();
  }, [loadMe]);

  const logout = useCallback(() => {
    session.token = null;
    session.org = null;
    setActiveOrgState(null);
    setMe(null);
  }, []);

  const setActiveOrg = useCallback((id: string | null) => {
    session.org = id;
    setActiveOrgState(id);
    setDataVersion((v) => v + 1);
  }, []);

  const permIndex = useRef<Map<string, Set<string>>>(new Map());
  permIndex.current = useMemo(() => new Map((me?.memberships ?? []).map((m) => [m.organisation_id, new Set(m.permissions)])), [me]);

  const can = useCallback((perm: string, orgId?: string | null) => {
    if (!me) return false;
    if (me.is_platform) return true;
    if (activeOrg && orgId && orgId !== activeOrg) return false;
    if (orgId) return permIndex.current.get(orgId)?.has(perm) ?? false;
    const scope = activeOrg ? [activeOrg] : [...permIndex.current.keys()];
    return scope.some((o) => permIndex.current.get(o)?.has(perm));
  }, [me, activeOrg]);

  const bump = useCallback(() => setDataVersion((v) => v + 1), []);

  const value: AppState = {
    branding, me, loading, activeOrg, orgNames, login, logout, setActiveOrg, can, toasts, toast, dismiss, dataVersion, bump,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

/** Organisation display name lookup (falls back to a short id). */
export function useOrgName(): (id: string | null | undefined) => string {
  const { orgNames } = useApp();
  return useCallback((id) => (id ? orgNames.get(id) ?? `${id.slice(0, 8)}…` : "—"), [orgNames]);
}
