// Display helpers. Money is integer minor units: arithmetic uses BigInt and
// decimal strings, never floats; Intl.NumberFormat is used only to render.

const nfCache = new Map<string, Intl.NumberFormat>();

function currencyFormat(currency: string): Intl.NumberFormat {
  let nf = nfCache.get(currency);
  if (!nf) {
    try {
      nf = new Intl.NumberFormat(undefined, { style: "currency", currency });
    } catch {
      nf = new Intl.NumberFormat(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    nfCache.set(currency, nf);
  }
  return nf;
}

export function currencyDigits(currency: string): number {
  return currencyFormat(currency).resolvedOptions().maximumFractionDigits ?? 2;
}

function toBigInt(v: number | string | bigint): bigint | null {
  try {
    if (typeof v === "bigint") return v;
    if (typeof v === "number") return Number.isInteger(v) ? BigInt(v) : null;
    const s = String(v).trim();
    return /^-?\d+$/.test(s) ? BigInt(s) : null;
  } catch {
    return null;
  }
}

/** Exact decimal string for minor units ("123456" USD -> "1234.56"). */
export function minorToDecimal(minor: number | string | bigint, currency: string): string {
  const b = toBigInt(minor);
  if (b === null) return String(minor);
  const d = currencyDigits(currency);
  const neg = b < 0n;
  const abs = neg ? -b : b;
  if (d === 0) return (neg ? "-" : "") + abs.toString();
  const base = 10n ** BigInt(d);
  const int = abs / base;
  const frac = (abs % base).toString().padStart(d, "0");
  return `${neg ? "-" : ""}${int.toString()}.${frac}`;
}

/** Format integer minor units with Intl (exact via decimal string input). */
export function money(minor: number | string | bigint | null | undefined, currency: string | null | undefined): string {
  if (minor === null || minor === undefined || minor === "") return "—";
  const cur = currency || "USD";
  const dec = minorToDecimal(minor, cur);
  const nf = currencyFormat(cur);
  try {
    // ES2023 Intl.NumberFormat accepts exact decimal strings.
    return nf.format(dec as unknown as number);
  } catch {
    return `${dec} ${cur}`;
  }
}

/** Parse a user-entered decimal amount ("1,234.5") into integer minor units, exactly. */
export function parseMoneyToMinor(input: string, currency: string): number | null {
  const s = input.replace(/[\s,]/g, "").replace(/^\$/, "");
  if (!s) return null;
  const m = /^(-?)(\d+)(?:\.(\d*))?$/.exec(s);
  if (!m) return null;
  const d = currencyDigits(currency);
  const frac = m[3] ?? "";
  if (frac.length > d) return null;
  const str = `${m[1]}${m[2]}${frac.padEnd(d, "0")}`;
  const b = BigInt(str);
  if (b > BigInt(Number.MAX_SAFE_INTEGER) || b < -BigInt(Number.MAX_SAFE_INTEGER)) return null;
  return Number(b);
}

const dtf = new Intl.DateTimeFormat(undefined, {
  year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit",
});
const dtfShort = new Intl.DateTimeFormat(undefined, {
  month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit",
});

/** Local (browser) time for an ISO timestamp with offset. */
export function dateTime(iso: string | null | undefined, short = false): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return (short ? dtfShort : dtf).format(d);
}

const zoneFmt = new Map<string, Intl.DateTimeFormat>();

/** Wall-clock time of an instant in an IANA zone, e.g. "Tue, 01 Dec 2026, 14:00". */
export function inZone(iso: string | null | undefined, tz: string | null | undefined, opts?: { timeOnly?: boolean }): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const key = `${tz}|${opts?.timeOnly ? 1 : 0}`;
  let f = zoneFmt.get(key);
  if (!f) {
    try {
      f = new Intl.DateTimeFormat(undefined, opts?.timeOnly
        ? { hour: "2-digit", minute: "2-digit", timeZone: tz || undefined }
        : { weekday: "short", year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", timeZone: tz || undefined });
    } catch {
      f = dtf;
    }
    zoneFmt.set(key, f);
  }
  return f.format(d);
}

/** Calendar day key (YYYY-MM-DD) of an instant in a zone. */
export function dayKey(iso: string, tz: string): string {
  try {
    const parts = new Intl.DateTimeFormat("en-CA", { year: "numeric", month: "2-digit", day: "2-digit", timeZone: tz }).format(new Date(iso));
    return parts;
  } catch {
    return iso.slice(0, 10);
  }
}

export function dayLabel(key: string): string {
  const [y, m, d] = key.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d, 12));
  return new Intl.DateTimeFormat(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric", timeZone: "UTC" }).format(dt);
}

export function relative(iso: string | null | undefined): string {
  if (!iso) return "";
  const diff = (new Date(iso).getTime() - Date.now()) / 1000;
  const rtf = new Intl.RelativeTimeFormat(undefined, { numeric: "auto" });
  const abs = Math.abs(diff);
  if (abs < 60) return rtf.format(Math.round(diff), "second");
  if (abs < 3600) return rtf.format(Math.round(diff / 60), "minute");
  if (abs < 86400) return rtf.format(Math.round(diff / 3600), "hour");
  return rtf.format(Math.round(diff / 86400), "day");
}

export function duration(seconds: number | null | undefined): string {
  if (seconds === null || seconds === undefined) return "—";
  const s = Math.max(0, Math.floor(seconds));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const parts: string[] = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  if (sec || parts.length === 0) parts.push(`${sec}s`);
  return parts.join(" ");
}

export function shortId(id: string | null | undefined): string {
  if (!id) return "—";
  return id.length > 12 ? `${id.slice(0, 8)}…` : id;
}

export function humanize(s: string | null | undefined): string {
  if (!s) return "—";
  return s.replace(/[_-]+/g, " ").replace(/^\w/, (c) => c.toUpperCase());
}

export function num(n: number | string | null | undefined): string {
  if (n === null || n === undefined || n === "") return "—";
  const b = toBigInt(n as number | string);
  if (b !== null) return new Intl.NumberFormat().format(b);
  return String(n);
}

/** datetime-local input value -> ISO string with the browser's UTC offset. */
export function localInputToIso(v: string): string {
  if (!v) return "";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "";
  const off = -d.getTimezoneOffset();
  const sign = off >= 0 ? "+" : "-";
  const hh = String(Math.floor(Math.abs(off) / 60)).padStart(2, "0");
  const mm = String(Math.abs(off) % 60).padStart(2, "0");
  const pad = (x: number) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:00${sign}${hh}:${mm}`;
}

/** Build an ISO timestamp for a wall-clock time in an IANA zone (e.g. a dealership's zone). */
export function zonedInputToIso(v: string, tz: string): string {
  if (!v) return "";
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(v);
  if (!m) return "";
  const [y, mo, d, h, mi] = m.slice(1).map(Number);
  // Guess UTC, then correct by the zone's offset at that instant (twice for DST edges).
  let utc = Date.UTC(y, mo - 1, d, h, mi);
  for (let i = 0; i < 2; i++) {
    const off = zoneOffsetMinutes(new Date(utc), tz);
    utc = Date.UTC(y, mo - 1, d, h, mi) - off * 60000;
  }
  const off = zoneOffsetMinutes(new Date(utc), tz);
  const sign = off >= 0 ? "+" : "-";
  const hh = String(Math.floor(Math.abs(off) / 60)).padStart(2, "0");
  const mm = String(Math.abs(off) % 60).padStart(2, "0");
  return `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:00${sign}${hh}:${mm}`;
}

function zoneOffsetMinutes(at: Date, tz: string): number {
  try {
    const f = new Intl.DateTimeFormat("en-US", {
      timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
    });
    const p = Object.fromEntries(f.formatToParts(at).map((x) => [x.type, x.value]));
    const asUtc = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute);
    return Math.round((asUtc - Math.floor(at.getTime() / 60000) * 60000) / 60000);
  } catch {
    return -at.getTimezoneOffset();
  }
}

export function toLocalInput(d: Date): string {
  const pad = (x: number) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
