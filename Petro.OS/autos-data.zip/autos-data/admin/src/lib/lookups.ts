import { useEffect, useState } from "react";
import { get, session } from "../api/client";
import type { Location, Organisation, RentalAsset, RentalCategory, Resource } from "../api/types";

// Small reference-data caches (organisations + locations, appointment
// resources, rental categories/assets). Keyed by token+org so a different
// login never sees another user's cache.

interface Lookups {
  organisations: Organisation[];
  locations: Map<string, Location & { organisation_name: string }>;
}

const cache = new Map<string, Promise<unknown>>();

function cached<T>(name: string, load: () => Promise<T>): Promise<T> {
  const key = `${session.token}|${session.org}|${name}`;
  let p = cache.get(key) as Promise<T> | undefined;
  if (!p) {
    p = load().catch((e) => { cache.delete(key); throw e; });
    cache.set(key, p);
  }
  return p;
}

export function invalidateLookups() {
  cache.clear();
}

async function loadOrgs(): Promise<Lookups> {
  const orgs = (await get<{ items: Organisation[] }>("/v1/organisations")).items;
  const details = await Promise.all(orgs.map((o) => get<Organisation>(`/v1/organisations/${o.id}`).catch(() => o)));
  const locations = new Map<string, Location & { organisation_name: string }>();
  for (const d of details) for (const l of d.locations ?? []) locations.set(l.id, { ...l, organisation_name: d.display_name });
  return { organisations: details, locations };
}

function useCached<T>(name: string, load: () => Promise<T>, empty: T): T {
  const [v, setV] = useState<T>(empty);
  useEffect(() => {
    let live = true;
    cached(name, load).then((x) => { if (live) setV(x); }).catch(() => undefined);
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [name]);
  return v;
}

const EMPTY_ORGS: Lookups = { organisations: [], locations: new Map() };

export function useOrgLookups(): Lookups {
  return useCached("orgs", loadOrgs, EMPTY_ORGS);
}

export function useResources(): Resource[] {
  return useCached("resources", async () => (await get<{ items: Resource[] }>("/v1/appointment-resources")).items, [] as Resource[]);
}

export function useRentalCategories(): RentalCategory[] {
  return useCached("rental-categories", async () => (await get<{ items: RentalCategory[] }>("/v1/rental-categories")).items, [] as RentalCategory[]);
}

export function useRentalAssets(): RentalAsset[] {
  return useCached("rental-assets", async () => (await get<{ items: RentalAsset[] }>("/v1/rental-assets")).items, [] as RentalAsset[]);
}

export function locationLabel(l: Location | undefined): string {
  return l ? `${l.code} — ${l.name}` : "—";
}
