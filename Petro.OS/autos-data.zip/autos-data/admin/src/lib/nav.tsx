import { useCallback, type MouseEvent, type ReactNode } from "react";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";

export type RecordType =
  | "vehicle" | "listing" | "customer" | "quote" | "reservation" | "sale_order" | "test_drive" | "rental_booking"
  | "payment" | "refund" | "import_job" | "reconciliation_case" | "organisation" | "rental_asset";

export const RECORD_LABEL: Record<RecordType, string> = {
  vehicle: "Vehicle", listing: "Listing", customer: "Customer", quote: "Quote", reservation: "Reservation",
  sale_order: "Sale order", test_drive: "Test drive", rental_booking: "Rental booking", payment: "Payment intent",
  refund: "Refund", import_job: "Import job", reconciliation_case: "Reconciliation case", organisation: "Organisation",
  rental_asset: "Rental asset",
};

const PARAM = "open";

export function parseOpen(v: string | null): { type: RecordType; id: string } | null {
  if (!v) return null;
  const i = v.indexOf(":");
  if (i < 1) return null;
  const type = v.slice(0, i) as RecordType;
  if (!(type in RECORD_LABEL)) return null;
  return { type, id: v.slice(i + 1) };
}

/** Open a record in the detail drawer (kept in the URL so it is linkable and Back works). */
export function useOpenRecord() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  return useCallback((type: RecordType, id: string, opts?: { replace?: boolean }) => {
    const p = new URLSearchParams(params);
    p.set(PARAM, `${type}:${id}`);
    navigate({ pathname: location.pathname, search: p.toString() }, { replace: opts?.replace, state: { drawerDepth: ((location.state as { drawerDepth?: number } | null)?.drawerDepth ?? 0) + 1 } });
  }, [params, navigate, location.pathname, location.state]);
}

export function useCloseRecord() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  return useCallback(() => {
    const p = new URLSearchParams(params);
    p.delete(PARAM);
    navigate({ pathname: location.pathname, search: p.toString() });
  }, [params, navigate, location.pathname]);
}

export function hrefFor(type: RecordType, id: string, pathname: string, search: string): string {
  const p = new URLSearchParams(search);
  p.set(PARAM, `${type}:${id}`);
  return `${pathname}?${p.toString()}`;
}

/** Clickable link to a related record; opens it in the drawer. */
export function RecordLink({ type, id, children, title }: { type: RecordType; id: string | null | undefined; children?: ReactNode; title?: string }) {
  const open = useOpenRecord();
  const location = useLocation();
  if (!id) return <span className="muted">—</span>;
  const onClick = (e: MouseEvent) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    open(type, id);
  };
  return (
    <a className="rec-link" href={hrefFor(type, id, location.pathname, location.search)} onClick={onClick}
      title={title ?? `${RECORD_LABEL[type]} ${id}`} data-record={`${type}:${id}`}>
      {children ?? <span className="mono">{id.length > 13 ? `${id.slice(0, 8)}…` : id}</span>}
    </a>
  );
}
