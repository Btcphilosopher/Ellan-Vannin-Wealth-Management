import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError, request, uuid } from "../api/client";
import type { Page } from "../api/types";
import { useApp } from "./app";

export interface AsyncState<T> {
  data: T | null;
  error: ApiError | null;
  loading: boolean;
  version: number | null;
  reload(): void;
  setData(d: T, version?: number | null): void;
}

/** Load a single resource; exposes the ETag version for If-Match. */
export function useResource<T>(path: string | null, query?: Record<string, string | number | undefined | null>): AsyncState<T> {
  const { dataVersion } = useApp();
  const [data, setDataState] = useState<T | null>(null);
  const [version, setVersion] = useState<number | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState(false);
  const [tick, setTick] = useState(0);
  const qs = JSON.stringify(query ?? {});

  useEffect(() => {
    if (!path) return;
    // Stale responses are ignored rather than aborted (keeps the network log clean).
    let live = true;
    setLoading(true);
    setError(null);
    request<T>(path, { query: JSON.parse(qs) })
      .then((r) => {
        if (!live) return;
        setDataState(r.data);
        setVersion(r.version);
      })
      .catch((e) => {
        if (live) setError(e as ApiError);
      })
      .finally(() => {
        if (live) setLoading(false);
      });
    return () => { live = false; };
  }, [path, qs, tick, dataVersion]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  const setData = useCallback((d: T, v?: number | null) => {
    setDataState(d);
    if (v !== undefined) setVersion(v);
    else if (d && typeof d === "object" && typeof (d as { version?: unknown }).version === "number") setVersion((d as unknown as { version: number }).version);
  }, []);
  return { data, error, loading, version, reload, setData };
}

export interface PagedState<T> {
  items: T[];
  error: ApiError | null;
  loading: boolean;
  hasMore: boolean;
  loadMore(): void;
  reload(): void;
}

/** Cursor-paginated list ({items, next_cursor}); "Load more" appends the next page. */
export function usePaged<T>(path: string | null, query: Record<string, unknown>, opts?: { cursorParam?: string; limit?: number }): PagedState<T> {
  const { dataVersion } = useApp();
  const [items, setItems] = useState<T[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState(false);
  const [tick, setTick] = useState(0);
  const qs = JSON.stringify(query);
  const cursorParam = opts?.cursorParam ?? "cursor";
  const limit = opts?.limit;
  const seq = useRef(0);

  const fetchPage = useCallback(async (cur: string | null, append: boolean) => {
    if (!path) return;
    const my = ++seq.current; // only the latest request may update state
    setLoading(true);
    setError(null);
    try {
      const q = { ...(JSON.parse(qs) as Record<string, string>), ...(limit ? { limit } : {}), ...(cur ? { [cursorParam]: cur } : {}) };
      const r = await request<Page<T>>(path, { query: q });
      if (my !== seq.current) return;
      setItems((prev) => (append ? [...prev, ...r.data.items] : r.data.items));
      setCursor(r.data.next_cursor ?? null);
    } catch (e) {
      if (my !== seq.current) return;
      setError(e as ApiError);
      if (!append) setItems([]);
    } finally {
      if (my === seq.current) setLoading(false);
    }
  }, [path, qs, cursorParam, limit]);

  useEffect(() => {
    void fetchPage(null, false);
    return () => { seq.current++; };
  }, [fetchPage, tick, dataVersion]);

  return {
    items, error, loading, hasMore: !!cursor,
    loadMore: () => { if (cursor) void fetchPage(cursor, true); },
    reload: () => setTick((t) => t + 1),
  };
}

/**
 * One Idempotency-Key per user action. The same key is reused when the same
 * request body is retried (e.g. after a network error); a different body or a
 * completed action gets a fresh key.
 */
export function useIdempotencyKey() {
  const ref = useRef<{ key: string; fp: string } | null>(null);
  const keyFor = useCallback((body: unknown) => {
    const fp = JSON.stringify(body ?? null);
    if (!ref.current || ref.current.fp !== fp) ref.current = { key: uuid(), fp };
    return ref.current.key;
  }, []);
  const complete = useCallback(() => { ref.current = null; }, []);
  return { keyFor, complete };
}

/** Run an async mutation with busy/error state and toast reporting. */
export function useAction() {
  const { toast, bump } = useApp();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const run = useCallback(async <R,>(label: string, fn: () => Promise<R>, opts?: { success?: string; silent?: boolean; noBump?: boolean }): Promise<R | undefined> => {
    setBusy(label);
    setError(null);
    try {
      const r = await fn();
      if (opts?.success) toast({ kind: "success", title: opts.success });
      if (!opts?.noBump) bump();
      return r;
    } catch (e) {
      const err = e instanceof ApiError ? e : new ApiError(0, { code: "client_error", detail: String((e as Error)?.message ?? e) }, null);
      setError(err);
      if (!opts?.silent) toast({ kind: "error", title: `${label} failed`, error: err });
      return undefined;
    } finally {
      setBusy(null);
    }
  }, [toast, bump]);
  return { run, busy, error, clearError: () => setError(null) };
}

/** Ticks every second (for countdowns). */
export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}
