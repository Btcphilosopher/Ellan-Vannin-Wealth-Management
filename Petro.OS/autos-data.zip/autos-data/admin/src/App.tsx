import { Navigate, Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { Spinner } from "./components/ui";
import { useApp } from "./lib/app";
import { Audit } from "./pages/Audit";
import { Customers } from "./pages/Customers";
import { Dealers } from "./pages/Dealers";
import { Imports } from "./pages/Imports";
import { Listings } from "./pages/Listings";
import { Login } from "./pages/Login";
import { Overview } from "./pages/Overview";
import { Payments } from "./pages/Payments";
import { Quotes } from "./pages/Quotes";
import { Rentals } from "./pages/Rentals";
import { Reports } from "./pages/Reports";
import { Reservations } from "./pages/Reservations";
import { TestDrives } from "./pages/TestDrives";
import { Vehicles } from "./pages/Vehicles";

export function App() {
  const { me, loading } = useApp();
  if (loading) return <div className="boot"><Spinner label="Loading…" /></div>;
  if (!me) return <Login />;
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Overview />} />
        <Route path="vehicles" element={<Vehicles />} />
        <Route path="listings" element={<Listings />} />
        <Route path="dealers" element={<Dealers />} />
        <Route path="customers" element={<Customers />} />
        <Route path="quotes" element={<Quotes />} />
        <Route path="reservations" element={<Reservations />} />
        <Route path="test-drives" element={<TestDrives />} />
        <Route path="rentals" element={<Rentals />} />
        <Route path="payments" element={<Payments />} />
        <Route path="imports" element={<Imports />} />
        <Route path="audit" element={<Audit />} />
        <Route path="reports" element={<Reports />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
