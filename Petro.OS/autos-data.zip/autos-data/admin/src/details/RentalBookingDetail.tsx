import { useState } from "react";
import { post, request } from "../api/client";
import type { PaymentIntent, RentalBooking } from "../api/types";
import { ConfirmAction } from "../components/ConfirmAction";
import { DataTable } from "../components/DataTable";
import { DetailShell } from "../components/DetailShell";
import { AuditHistory } from "../components/History";
import { ActionButton, Amount, Button, Field, KV, Mono, Section, StatusPill } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime, inZone } from "../lib/format";
import { useAction, useIdempotencyKey, useResource } from "../lib/hooks";
import { useOrgLookups, useRentalAssets, useRentalCategories } from "../lib/lookups";
import { RecordLink, useOpenRecord } from "../lib/nav";

export function RentalBookingDetail({ id }: { id: string }) {
  const res = useResource<RentalBooking>(`/v1/rental-bookings/${id}`);
  const { run, busy, error, clearError } = useAction();
  const { can } = useApp();
  const orgName = useOrgName();
  const { locations } = useOrgLookups();
  const cats = useRentalCategories();
  const assets = useRentalAssets();
  const open = useOpenRecord();
  const idem = useIdempotencyKey();
  const [assign, setAssign] = useState(false);
  const [assetId, setAssetId] = useState("");
  const [upgrade, setUpgrade] = useState(false);
  const b = res.data;
  const org = b?.organisation_id;
  const cat = cats.find((c) => c.id === b?.category_id);
  const act = async (label: string, slug: string, reason?: string | null) => {
    const x = await run(label, () => request<RentalBooking>(`/v1/rental-bookings/${id}/${slug}`, { method: "POST", body: reason !== undefined ? { reason } : {}, ifMatch: res.version }),
      { silent: true, success: `${label}: done` });
    if (x) res.setData(x.data, x.version);
  };
  const candidateAssets = assets.filter((a) => a.organisation_id === org && (upgrade || a.category_id === b?.category_id) && a.status === "active");
  const activeAssignment = (b?.assignments ?? []).find((a) => a.status === "active");
  return (
    <DetailShell type="rental_booking" id={id} loading={res.loading} error={res.error} onReload={() => { clearError(); res.reload(); }}
      actionError={error} onDismissError={clearError}
      title={b ? <>Booking <Mono>{b.booking_number}</Mono></> : undefined}
      status={b ? <StatusPill value={b.status} /> : null}
      subtitle={b ? <>{cat ? `${cat.code} · ${cat.name}` : ""} · pickup {inZone(b.local_pickup, b.pickup_timezone)} <Mono>{b.pickup_timezone}</Mono> · total {b.total?.formatted}</> : null}
      actions={b ? <>
        {b.status === "confirmed" ? <ActionButton perm="rentals.book" org={org} small variant={activeAssignment ? "secondary" : "primary"} onClick={() => setAssign(!assign)}>{activeAssignment ? "Reassign vehicle…" : "Assign vehicle…"}</ActionButton> : null}
        {b.status === "confirmed" ? <ActionButton perm="rentals.book" org={org} small busy={busy === "Check out"} onClick={() => act("Check out", "check-out")}>Check out</ActionButton> : null}
        {b.status === "checked_out" ? <ActionButton perm="rentals.book" org={org} small variant="primary" busy={busy === "Return"} onClick={() => act("Return", "return")}>Record return</ActionButton> : null}
        {b.status === "confirmed" ? <ConfirmAction label="No-show" perm="rentals.book" org={org} reason="optional" busy={busy === "No-show"} onConfirm={(r) => act("No-show", "no-show", r)} /> : null}
        {b.status === "confirmed" ? <ConfirmAction label="Cancel" perm="rentals.book" org={org} reason="required" variant="danger" busy={busy === "Cancel"} onConfirm={(r) => act("Cancel", "cancellation", r)} /> : null}
        {b.status === "confirmed" && (can("payments.create", org) || can("rentals.book", org)) ? (
          <Button small busy={busy === "Create prepayment"} onClick={async () => {
            const body = { purpose: "rental_prepayment", rental_booking_id: id };
            const p = await run("Create prepayment", () => post<PaymentIntent>("/v1/payments", body, { idempotencyKey: idem.keyFor(body) }), { silent: true, success: "Prepayment intent created" });
            if (p) { idem.complete(); open("payment", p.id); }
          }}>Take prepayment…</Button>
        ) : null}
      </> : null}
      tabs={b ? [
        { id: "overview", label: "Overview", render: () => <>
          {assign ? (
            <form className="form-box" onSubmit={async (e) => {
              e.preventDefault();
              const x = await run("Assign vehicle", () => post(`/v1/rental-bookings/${id}/assignment`, { rental_asset_id: assetId || null, is_upgrade: upgrade }),
                { silent: true, success: "Vehicle assigned" });
              if (x) { setAssign(false); res.reload(); }
            }}>
              <h4>Assign an exact vehicle <span className="muted small">(overlaps are rejected by the database)</span></h4>
              <div className="form-row">
                <Field label="Rental asset">
                  <select value={assetId} onChange={(e) => setAssetId(e.target.value)}>
                    <option value="">Auto-select a free vehicle</option>
                    {candidateAssets.map((a) => <option key={a.id} value={a.id}>{a.fleet_number}{a.category_id !== b.category_id ? " (upgrade)" : ""}</option>)}
                  </select>
                </Field>
                <label className="check"><input type="checkbox" checked={upgrade} onChange={(e) => setUpgrade(e.target.checked)} /> Upgrade (allow other categories)</label>
              </div>
              <div className="form-actions"><Button type="submit" variant="primary" busy={busy === "Assign vehicle"}>Assign</Button><Button variant="ghost" onClick={() => setAssign(false)}>Cancel</Button></div>
            </form>
          ) : null}
          <div className="cols-2">
            <Section title="Booking">
              <KV rows={[
                ["Status", <StatusPill value={b.status} />],
                ["Category", cat ? `${cat.code} — ${cat.name} (${cat.seats} seats, ${cat.transmission})` : <Mono>{b.category_id}</Mono>],
                ["Pickup (local)", <>{inZone(b.local_pickup, b.pickup_timezone)} <Mono>{b.pickup_timezone}</Mono></>],
                ["Return (local)", <>{inZone(b.local_return, b.return_timezone)} <Mono>{b.return_timezone}</Mono></>],
                ["Pickup location", locations.get(b.pickup_location_id)?.name ?? <Mono>{b.pickup_location_id}</Mono>],
                ["Return location", locations.get(b.return_location_id)?.name ?? <Mono>{b.return_location_id}</Mono>],
                ["Total", <Amount minor={b.total_minor} currency={b.currency} formatted={b.total?.formatted} />],
                ["Cancelled", b.cancelled_at ? <>{dateTime(b.cancelled_at)} <span className="muted small">{b.cancellation_reason}</span></> : null],
                ["Version", <Mono>{b.version}</Mono>],
              ]} />
            </Section>
            <Section title="Related">
              <KV rows={[
                ["Customer", <RecordLink type="customer" id={b.customer_id}>open customer</RecordLink>],
                ["Supplier", <RecordLink type="organisation" id={b.organisation_id}>{orgName(b.organisation_id)}</RecordLink>],
                ["Rental quote", b.rental_quote_id ? <Mono>{b.rental_quote_id}</Mono> : null],
              ]} />
            </Section>
          </div>
          <Section title="Asset assignments">
            <DataTable compact rows={b.assignments ?? []} rowKey={(a) => a.id} empty="No vehicle assigned yet."
              columns={[
                { key: "a", header: "Asset", render: (a) => <RecordLink type="rental_asset" id={a.rental_asset_id}>{assets.find((x) => x.id === a.rental_asset_id)?.fleet_number ?? a.rental_asset_id}</RecordLink> },
                { key: "s", header: "Status", render: (a) => <StatusPill value={String(a.status ?? "")} /> },
                { key: "u", header: "Upgrade", render: (a) => (a.is_upgrade ? "yes" : "no") },
                { key: "t", header: "Assigned", render: (a) => dateTime(String(a.assigned_at ?? ""), true) },
                { key: "r", header: "Released", render: (a) => (a.released_at ? dateTime(String(a.released_at), true) : "—") },
              ]} />
          </Section>
        </> },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="rental_booking" targetId={id} /> },
      ] : []}
    />
  );
}

export function RentalAssetDetail({ id }: { id: string }) {
  const assets = useRentalAssets();
  const cats = useRentalCategories();
  const { locations } = useOrgLookups();
  const a = assets.find((x) => x.id === id);
  const cat = cats.find((c) => c.id === a?.category_id);
  return (
    <DetailShell type="rental_asset" id={id} loading={!a}
      title={a ? <>Fleet <Mono>{a.fleet_number}</Mono></> : undefined}
      status={a ? <StatusPill value={a.status} /> : null}
      tabs={a ? [
        { id: "overview", label: "Overview", render: () => (
          <Section title="Rental asset">
            <KV rows={[
              ["Fleet number", <Mono>{a.fleet_number}</Mono>],
              ["Category", cat ? `${cat.code} — ${cat.name}` : a.category_id],
              ["Vehicle", <RecordLink type="vehicle" id={a.vehicle_id}>open vehicle</RecordLink>],
              ["Home location", locations.get(a.home_location_id)?.name ?? a.home_location_id],
              ["In fleet", `${dateTime(a.in_fleet_from, true)} → ${a.in_fleet_to ? dateTime(a.in_fleet_to, true) : "current"}`],
              ["Version", <Mono>{a.version}</Mono>],
            ]} />
          </Section>
        ) },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="vehicle" targetId={a.vehicle_id} title="Vehicle audit trail" /> },
      ] : []}
    />
  );
}
