import { useEffect, useMemo, useState } from "react";
import { post, request } from "../api/client";
import type { PaymentIntent, Reservation, SaleOrder } from "../api/types";
import { ConfirmAction } from "../components/ConfirmAction";
import { DataTable } from "../components/DataTable";
import { DetailShell } from "../components/DetailShell";
import { AuditHistory, renderChanges } from "../components/History";
import { ActionButton, Amount, Banner, Button, CopyId, Countdown, Field, KV, Mono, Section, StatusPill } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime, humanize, money, parseMoneyToMinor } from "../lib/format";
import { useAction, useIdempotencyKey, useNow, useResource } from "../lib/hooks";
import { useOrgLookups } from "../lib/lookups";
import { RecordLink, useOpenRecord } from "../lib/nav";

function useExpiry(seconds: number | null | undefined, loadedAt: number) {
  const now = useNow();
  if (seconds === null || seconds === undefined) return null;
  return Math.max(0, seconds - (now - loadedAt) / 1000);
}

export function ReservationDetail({ id }: { id: string }) {
  const res = useResource<Reservation>(`/v1/sale-reservations/${id}`);
  const { run, busy, error, clearError } = useAction();
  const { can } = useApp();
  const orgName = useOrgName();
  const open = useOpenRecord();
  const idem = useIdempotencyKey();
  const [loadedAt, setLoadedAt] = useState(Date.now());
  const [convert, setConvert] = useState(false);
  const [agreed, setAgreed] = useState("");
  const r = res.data;
  useEffect(() => { setLoadedAt(Date.now()); }, [r]);
  const remaining = useExpiry(r?.seconds_remaining, loadedAt);
  const org = r?.organisation_id;
  const v = res.version;

  const act = async (label: string, path: string, body: unknown = {}) => {
    const x = await run(label, () => request<Reservation>(path, { method: "POST", body, ifMatch: v }), { silent: true, success: `${label}: done` });
    if (x && "reservation_number" in (x.data as object)) res.setData(x.data, x.version);
    return x;
  };

  const depositOutstanding = r ? r.deposit_required_minor > 0 && r.deposit_status !== "paid" : false;
  const isHeld = r?.effective_status === "held";
  const canPayDeposit = !!r && (can("payments.create", org) || can("reservations.create", org));

  return (
    <DetailShell type="reservation" id={id} loading={res.loading} error={res.error} onReload={() => { clearError(); res.reload(); }}
      actionError={error} onDismissError={clearError}
      title={r ? <>Reservation <Mono>{r.reservation_number}</Mono></> : undefined}
      status={r ? <><StatusPill value={r.effective_status} />{r.effective_status !== r.status ? <span className="muted small"> (stored: {r.status})</span> : null}</> : null}
      subtitle={r ? <>
        {remaining !== null && isHeld ? <>Hold expires in <Countdown seconds={remaining} /> · </> : null}
        Deposit <Amount minor={r.deposit_required_minor} currency={r.currency} formatted={r.deposit?.formatted} /> <StatusPill value={r.deposit_status} />
        <span className="muted"> · {orgName(r.organisation_id)}</span>
      </> : null}
      actions={r ? <>
        {isHeld ? (
          <ActionButton perm="reservations.manage" org={org} variant="primary" small busy={busy === "Accept"}
            blockedReason={depositOutstanding ? "Deposit must be settled before dealer acceptance" : null}
            onClick={() => act("Accept", `/v1/sale-reservations/${id}/acceptance`)}>Dealer accept</ActionButton>
        ) : null}
        {isHeld && depositOutstanding && canPayDeposit ? (
          <Button small busy={busy === "Create deposit payment"} onClick={async () => {
            const body = { purpose: "sale_deposit", sale_reservation_id: id };
            const p = await run("Create deposit payment", () => post<PaymentIntent>("/v1/payments", body, { idempotencyKey: idem.keyFor(body) }), { silent: true, success: "Payment intent created" });
            if (p) { idem.complete(); open("payment", p.id); }
          }}>Take deposit payment…</Button>
        ) : null}
        {r.effective_status === "dealer_accepted" ? (
          <ActionButton perm={can("reservations.manage", org) ? "reservations.manage" : "sales.manage"} org={org} variant="primary" small onClick={() => setConvert(!convert)}>
            Convert to sale order…
          </ActionButton>
        ) : null}
        {["held", "dealer_accepted"].includes(r.effective_status) ? <>
          <ConfirmAction label="Cancel" perm="reservations.manage" org={org} reason="required" variant="danger" busy={busy === "Cancel"}
            onConfirm={(reason) => act("Cancel", `/v1/sale-reservations/${id}/cancellation`, { reason, outcome: "cancelled" })} />
          <ConfirmAction label="Decline" perm="reservations.manage" org={org} reason="required" busy={busy === "Decline"}
            onConfirm={(reason) => act("Decline", `/v1/sale-reservations/${id}/cancellation`, { reason, outcome: "declined" })} />
          <ConfirmAction label="Release" perm="reservations.manage" org={org} reason="required" busy={busy === "Release"}
            onConfirm={(reason) => act("Release", `/v1/sale-reservations/${id}/cancellation`, { reason, outcome: "released" })} />
        </> : null}
      </> : null}
      tabs={r ? [
        { id: "overview", label: "Overview", render: () => <>
          {r.effective_status === "expired" && r.status === "held" ? <Banner kind="warning">The hold has lapsed (effective status <Mono>expired</Mono>); the sweeper has not transitioned it yet.</Banner> : null}
          {convert ? (
            <form className="form-box" onSubmit={async (e) => {
              e.preventDefault();
              const minor = agreed.trim() ? parseMoneyToMinor(agreed, r.currency) : null;
              if (agreed.trim() && minor === null) return;
              const x = await run("Convert to sale order", () => request<SaleOrder>(`/v1/sale-reservations/${id}/sale-order`,
                { method: "POST", body: { agreed_total_minor: minor }, ifMatch: v }), { silent: true, success: "Sale order created" });
              if (x) { setConvert(false); res.reload(); }
            }}>
              <h4>Convert to sale order <span className="muted small">(If-Match v{r.version})</span></h4>
              <Field label={`Agreed total (${r.currency})`} hint={r.quote_id ? "Required when the linked quote is incomplete; otherwise blank uses the quote total" : "Blank uses the listing price"}>
                <input inputMode="decimal" value={agreed} onChange={(e) => setAgreed(e.target.value)} placeholder="e.g. 33450.00" />
              </Field>
              <div className="form-actions"><Button type="submit" variant="primary" busy={busy === "Convert to sale order"}>Create sale order</Button><Button variant="ghost" onClick={() => setConvert(false)}>Cancel</Button></div>
            </form>
          ) : null}
          <div className="cols-2">
            <Section title="Reservation">
              <KV rows={[
                ["Effective status", <StatusPill value={r.effective_status} />],
                ["Stored status", <StatusPill value={r.status} />],
                ["Hold expires", r.hold_expires_at ? <>{dateTime(r.hold_expires_at)} {isHeld && remaining !== null ? <Countdown seconds={remaining} /> : null}</> : null],
                ["Deposit", <><Amount minor={r.deposit_required_minor} currency={r.currency} /> <StatusPill value={r.deposit_status} /> {r.deposit_paid_at ? <span className="muted small">paid {dateTime(r.deposit_paid_at)}</span> : null}</>],
                ["Accepted", dateTime(r.accepted_at)],
                ["Ended", r.ended_at ? <>{dateTime(r.ended_at)} <span className="muted small">{r.end_reason}</span></> : null],
                ["Created", dateTime(r.created_at)],
                ["Version", <Mono>{r.version}</Mono>],
              ]} />
            </Section>
            <Section title="Related records">
              <KV rows={[
                ["Listing", <RecordLink type="listing" id={r.listing_id}>open listing</RecordLink>],
                ["Vehicle", <RecordLink type="vehicle" id={r.vehicle_id}>open vehicle</RecordLink>],
                ["Customer", <RecordLink type="customer" id={r.customer_id}>open customer</RecordLink>],
                ["Quote", <RecordLink type="quote" id={r.quote_id}>open quote</RecordLink>],
                ["Sale order", r.sale_order ? <><RecordLink type="sale_order" id={r.sale_order.id}><Mono>{r.sale_order.order_number}</Mono></RecordLink> <StatusPill value={r.sale_order.status} /></> : null],
                ["Payments", (r.payments ?? []).length ? (
                  <ul className="link-list">{(r.payments ?? []).map((p) => <li key={p.id}><RecordLink type="payment" id={p.id}>{humanize(p.purpose)} {money(p.amount_minor, p.currency)}</RecordLink> <StatusPill value={p.status} /></li>)}</ul>
                ) : "none"],
                ["Seller", <RecordLink type="organisation" id={r.organisation_id}>{orgName(r.organisation_id)}</RecordLink>],
              ]} />
            </Section>
          </div>
        </> },
        { id: "events", label: "Events", count: r.events?.length, render: () => (
          <DataTable compact rows={r.events ?? []} rowKey={(e) => e.id} empty="No events."
            columns={[
              { key: "t", header: "When", render: (e) => dateTime(e.occurred_at), width: 150 },
              { key: "e", header: "Event", render: (e) => <Mono>{e.event}</Mono> },
              { key: "s", header: "Transition", render: (e) => (e.from_status || e.to_status ? <><StatusPill value={e.from_status} /> → <StatusPill value={e.to_status} /></> : "") },
              { key: "d", header: "Detail", render: (e) => renderChanges(e.detail) },
              { key: "a", header: "Actor", render: (e) => <>{humanize(e.actor_kind)} {e.actor_user_id ? <CopyId id={e.actor_user_id} /> : null}</> },
              { key: "o", header: "Order", render: (e) => (e.sale_order_id ? <RecordLink type="sale_order" id={e.sale_order_id} /> : "") },
            ]} />
        ) },
        { id: "payments", label: "Payments", count: r.payments?.length, render: () => <PaymentsMini rows={r.payments ?? []} /> },
        ...(r.sale_order ? [{ id: "order", label: "Sale order", render: () => <SaleOrderPanel orderId={r.sale_order!.id} /> }] : []),
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="sale_reservation" targetId={id} /> },
      ] : []}
    />
  );
}

export function PaymentsMini({ rows }: { rows: PaymentIntent[] }) {
  const open = useOpenRecord();
  return (
    <DataTable compact rows={rows} rowKey={(p) => p.id} onRowClick={(p) => open("payment", p.id)} empty="No payment intents."
      columns={[
        { key: "p", header: "Purpose", render: (p) => humanize(p.purpose) },
        { key: "a", header: "Amount", align: "right", render: (p) => <Amount minor={p.amount_minor} currency={p.currency} /> },
        { key: "s", header: "Status", render: (p) => <StatusPill value={p.status} /> },
        { key: "r", header: "Provider ref", render: (p) => <Mono>{p.provider_intent_ref ?? "—"}</Mono> },
        { key: "c", header: "Created", render: (p) => dateTime(p.created_at, true) },
      ]} />
  );
}

/** Sale order lifecycle: agreement → handover → completion (or cancellation). */
export function SaleOrderPanel({ orderId, onVersion }: { orderId: string; onVersion?: (o: SaleOrder) => void }) {
  const res = useResource<SaleOrder>(`/v1/sale-orders/${orderId}`);
  const { run, busy, error, clearError } = useAction();
  const { can } = useApp();
  const { locations } = useOrgLookups();
  const open = useOpenRecord();
  const idem = useIdempotencyKey();
  const [handover, setHandover] = useState(false);
  const o = res.data;
  const orgLocations = useMemo(() => [...locations.values()].filter((l) => l.organisation_id === o?.organisation_id), [locations, o?.organisation_id]);
  const [h, setH] = useState({ location_id: "", odometer_value: "", odometer_unit: "mi", notes: "" });
  useEffect(() => { if (o) onVersion?.(o); }, [o, onVersion]);
  if (res.error) return <Banner kind="error">{res.error.detail}</Banner>;
  if (!o) return <span className="muted">Loading sale order…</span>;
  const org = o.organisation_id;
  const act = async (label: string, path: string, body: unknown = {}) => {
    const x = await run(label, () => request<SaleOrder>(path, { method: "POST", body, ifMatch: res.version }), { silent: true, success: `${label}: done` });
    if (x) res.setData(x.data, x.version);
    return x;
  };
  const terminal = ["completed", "cancelled"].includes(o.status);
  return (
    <div>
      {error ? <Banner kind="error"><strong>{error.isVersionConflict ? "Sale order changed by someone else — " : ""}{error.code}</strong>: {error.detail}
        {error.errors.map((e, i) => <div key={i} className="small">{e.field} {e.message}</div>)}
        <div className="small muted">request_id <Mono>{error.requestId}</Mono></div>
        <Button small onClick={() => { clearError(); res.reload(); }}>Reload</Button></Banner> : null}
      <div className="detail-actions">
        {o.status === "agreement_pending" ? <ActionButton perm="sales.manage" org={org} variant="primary" small busy={busy === "Record agreement"}
          onClick={() => act("Record agreement", `/v1/sale-orders/${orderId}/agreement`)}>Record signed agreement</ActionButton> : null}
        {o.status === "agreement_signed" ? <ActionButton perm="sales.manage" org={org} small onClick={() => setHandover(!handover)}>Record handover…</ActionButton> : null}
        {o.status === "handed_over" && (o.balance_outstanding_minor ?? 0) <= 0 ? <ActionButton perm="sales.manage" org={org} variant="primary" small busy={busy === "Complete sale"}
          onClick={() => act("Complete sale", `/v1/sale-orders/${orderId}/completion`)}>Complete sale</ActionButton> : null}
        {o.status === "handed_over" && (o.balance_outstanding_minor ?? 0) > 0 ? (
          <ConfirmAction label={`Complete with ${money(o.balance_outstanding_minor, o.currency)} outstanding…`} perm="sales.manage" org={org}
            reason="required" variant="danger" busy={busy === "Complete sale"}
            onConfirm={(reason) => act("Complete sale", `/v1/sale-orders/${orderId}/completion`, { accept_outstanding_balance: true, reason })} />
        ) : null}
        {!terminal && (o.balance_outstanding_minor ?? 0) > 0 && (can("payments.create", org) || can("sales.manage", org)) ? (
          <Button small busy={busy === "Create balance payment"} onClick={async () => {
            const body = { purpose: "sale_balance", sale_order_id: orderId };
            const p = await run("Create balance payment", () => post<PaymentIntent>("/v1/payments", body, { idempotencyKey: idem.keyFor(body) }), { silent: true, success: "Balance payment intent created" });
            if (p) { idem.complete(); open("payment", p.id); }
          }}>Take balance payment…</Button>
        ) : null}
        {!terminal ? <ConfirmAction label="Cancel order" perm="reservations.manage" org={org} reason="required" variant="danger" busy={busy === "Cancel order"}
          onConfirm={(reason) => act("Cancel order", `/v1/sale-orders/${orderId}/cancellation`, { reason })} /> : null}
      </div>
      {handover ? (
        <form className="form-box" onSubmit={async (e) => {
          e.preventDefault();
          const body: Record<string, unknown> = { location_id: h.location_id };
          if (h.odometer_value) { body.odometer_value = parseInt(h.odometer_value, 10); body.odometer_unit = h.odometer_unit; }
          if (h.notes) body.notes = h.notes;
          const x = await act("Record handover", `/v1/sale-orders/${orderId}/handover`, body);
          if (x) setHandover(false);
        }}>
          <h4>Record physical handover <span className="muted small">(If-Match v{o.version})</span></h4>
          <div className="form-row">
            <Field label="Location"><select required value={h.location_id} onChange={(e) => setH({ ...h, location_id: e.target.value })}>
              <option value="">Select…</option>{orgLocations.map((l) => <option key={l.id} value={l.id}>{l.code} — {l.name}</option>)}
            </select></Field>
            <Field label="Odometer"><input inputMode="numeric" pattern="\d*" value={h.odometer_value} onChange={(e) => setH({ ...h, odometer_value: e.target.value })} /></Field>
            <Field label="Unit"><select value={h.odometer_unit} onChange={(e) => setH({ ...h, odometer_unit: e.target.value })}><option>mi</option><option>km</option></select></Field>
          </div>
          <Field label="Notes" wide><input value={h.notes} onChange={(e) => setH({ ...h, notes: e.target.value })} /></Field>
          <div className="form-actions"><Button type="submit" variant="primary" busy={busy === "Record handover"}>Record handover</Button><Button variant="ghost" onClick={() => setHandover(false)}>Cancel</Button></div>
        </form>
      ) : null}
      <div className="cols-2">
        <Section title={<>Sale order <Mono>{o.order_number}</Mono></>}>
          <KV rows={[
            ["Status", <StatusPill value={o.status} />],
            ["Agreed total", <Amount minor={o.agreed_total_minor} currency={o.currency} />],
            ["Net received", <Amount minor={o.net_received_minor} currency={o.currency} />],
            ["Balance outstanding", <Amount minor={o.balance_outstanding_minor} currency={o.currency} />],
            ["Agreement signed", dateTime(o.agreement_signed_at)],
            ["Completed", dateTime(o.completed_at)],
            ["Cancelled", o.cancelled_at ? <>{dateTime(o.cancelled_at)} <span className="muted small">{o.cancel_reason}</span></> : null],
            ["Version", <Mono>{o.version}</Mono>],
          ]} />
        </Section>
        <Section title="Related">
          <KV rows={[
            ["Reservation", <RecordLink type="reservation" id={o.sale_reservation_id}>open reservation</RecordLink>],
            ["Vehicle", <RecordLink type="vehicle" id={o.vehicle_id}>open vehicle</RecordLink>],
            ["Customer", <RecordLink type="customer" id={o.customer_id}>open customer</RecordLink>],
            ["Quote", <RecordLink type="quote" id={o.quote_id}>open quote</RecordLink>],
          ]} />
          <h4>Handovers</h4>
          {(o.handovers ?? []).length === 0 ? <span className="muted">None recorded.</span> : (
            <ul className="link-list">{(o.handovers ?? []).map((x) => <li key={x.id}>{dateTime(x.handed_over_at)} at {locations.get(x.location_id)?.name ?? x.location_id}{x.odometer_value != null ? ` · ${x.odometer_value} ${x.odometer_unit ?? ""}` : ""}{x.notes ? ` · ${x.notes}` : ""}</li>)}</ul>
          )}
        </Section>
      </div>
      <AuditHistory targetType="sale_order" targetId={orderId} title="Sale order audit trail" />
    </div>
  );
}

export function SaleOrderDetail({ id }: { id: string }) {
  const [o, setO] = useState<SaleOrder | null>(null);
  return (
    <DetailShell type="sale_order" id={id}
      title={o ? <>Sale order <Mono>{o.order_number}</Mono></> : "Sale order"}
      status={o ? <StatusPill value={o.status} /> : null}
      subtitle={o ? <>Agreed <Amount minor={o.agreed_total_minor} currency={o.currency} /> · balance <Amount minor={o.balance_outstanding_minor} currency={o.currency} /></> : null}
      tabs={[{ id: "order", label: "Sale order", render: () => <SaleOrderPanel orderId={id} onVersion={setO} /> }]} />
  );
}
