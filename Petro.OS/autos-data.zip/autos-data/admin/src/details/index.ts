import type { ComponentType } from "react";
import type { RecordType } from "../lib/nav";
import { CustomerDetail } from "./CustomerDetail";
import { ImportJobDetail } from "./ImportJobDetail";
import { ListingDetail } from "./ListingDetail";
import { OrganisationDetail } from "./OrganisationDetail";
import { PaymentDetail, ReconciliationCaseDetail, RefundDetail } from "./PaymentDetail";
import { QuoteDetail } from "./QuoteDetail";
import { RentalAssetDetail, RentalBookingDetail } from "./RentalBookingDetail";
import { ReservationDetail, SaleOrderDetail } from "./ReservationDetail";
import { TestDriveDetail } from "./TestDriveDetail";
import { VehicleDetail } from "./VehicleDetail";

/** Record type -> detail panel rendered in the right-side drawer. */
export const DETAILS: Record<RecordType, ComponentType<{ id: string }>> = {
  vehicle: VehicleDetail,
  listing: ListingDetail,
  customer: CustomerDetail,
  quote: QuoteDetail,
  reservation: ReservationDetail,
  sale_order: SaleOrderDetail,
  test_drive: TestDriveDetail,
  rental_booking: RentalBookingDetail,
  rental_asset: RentalAssetDetail,
  payment: PaymentDetail,
  refund: RefundDetail,
  import_job: ImportJobDetail,
  reconciliation_case: ReconciliationCaseDetail,
  organisation: OrganisationDetail,
};
