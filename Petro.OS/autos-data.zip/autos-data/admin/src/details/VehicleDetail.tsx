import { useState } from "react";
import { patch } from "../api/client";
import type { Assertion, Feature, Vehicle } from "../api/types";
import { DataTable } from "../components/DataTable";
import { DetailShell } from "../components/DetailShell";
import { AuditHistory } from "../components/History";
import { ActionButton, Button, Check, Empty, Field, KV, Mono, Section, StatusPill } from "../components/ui";
import { useOrgName } from "../lib/app";
import { dateTime, humanize } from "../lib/format";
import { useAction, useResource } from "../lib/hooks";
import { useOrgLookups } from "../lib/lookups";
import { RecordLink } from "../lib/nav";
import { CommitmentLink } from "./ListingDetail";

const ASSERTION_ORDER = ["manufacturer", "registry", "inspection_finding", "seller_claim"];

export function VehicleDetail({ id }: { id: string }) {
  const res = useResource<Vehicle>(`/v1/vehicles/${id}`);
  const prov = useResource<{ assertions: Assertion[]; features: Feature[] }>(`/v1/vehicles/${id}/assertions`);
  const { run, busy, error, clearError } = useAction();
  const orgName = useOrgName();
  const { locations } = useOrgLookups();
  const [editing, setEditing] = useState(false);
  const v = res.data;
  const vin = v?.identifiers.find((i) => i.namespace === "vin" && !i.retired_at);
  const assertions = prov.data?.assertions ?? [];
  const groups = new Map<string, Assertion[]>();
  for (const a of assertions) groups.set(a.assertion_type, [...(groups.get(a.assertion_type) ?? []), a]);
  const groupKeys = [...groups.keys()].sort((a, b) => (ASSERTION_ORDER.indexOf(a) + 99) % 99 - (ASSERTION_ORDER.indexOf(b) + 99) % 99);

  return (
    <DetailShell type="vehicle" id={id} loading={res.loading} error={res.error} onReload={() => { res.reload(); prov.reload(); }}
      actionError={error} onDismissError={clearError}
      title={v ? v.specification?.label ?? `Vehicle ${v.model_year ?? ""}` : undefined}
      status={v ? <StatusPill value={v.availability_status} /> : null}
      subtitle={v ? <><Mono>{vin?.value ?? "no VIN"}</Mono>{vin?.is_synthetic ? <span className="tag">synthetic</span> : null} <span className="muted">· custodian {orgName(v.custodian_organisation_id)}</span></> : null}
      actions={v ? <ActionButton perm="vehicles.write" org={v.custodian_organisation_id} small onClick={() => setEditing(!editing)}>Edit descriptive fields</ActionButton> : null}
      tabs={v ? [
        { id: "overview", label: "Overview", render: () => <>
          {editing ? <VehicleForm key={v.version} v={v} busy={busy === "Save vehicle"} onCancel={() => setEditing(false)} onSubmit={async (body) => {
            const r = await run("Save vehicle", () => patch<Vehicle>(`/v1/vehicles/${id}`, body, res.version), { silent: true, success: "Vehicle saved" });
            if (r) { setEditing(false); }
          }} /> : null}
          <div className="cols-2">
            <Section title="Vehicle">
              <KV rows={[
                ["Make / model", v.specification ? `${v.specification.make} ${v.specification.model}` : null],
                ["Trim / year", v.specification ? `${v.specification.trim} · ${v.specification.model_year}` : v.model_year],
                ["Fuel / body", v.specification ? `${humanize(v.specification.fuel_type)} · ${humanize(v.specification.body_style)}` : null],
                ["Condition", humanize(v.condition)],
                ["Colours", `${v.exterior_colour ?? "—"} / ${v.interior_colour ?? "—"}`],
                ["Odometer", v.odometer_value != null ? <>{v.odometer_value.toLocaleString()} {v.odometer_unit} <span className="muted small">recorded {dateTime(v.odometer_recorded_at)}</span></> : null],
                ["Open recall", <Check value={v.has_open_recall} />],
                ["Keys", v.keys_count],
                ["Location", locations.get(v.current_location_id ?? "")?.name ?? <Mono>{v.current_location_id ?? "—"}</Mono>],
                ["Merged into", v.merged_into_vehicle_id ? <RecordLink type="vehicle" id={v.merged_into_vehicle_id} /> : null],
                ["Version", <Mono>{v.version}</Mono>],
              ]} />
            </Section>
            <Section title="Current commitment">
              {v.current_commitment ? <CommitmentLink c={v.current_commitment} /> : <span className="muted">No active hold or sale order.</span>}
              <div className="related">
                <h4>Listings of this vehicle</h4>
                {(v.listings ?? []).length === 0 ? <span className="muted">None</span> : (
                  <ul className="link-list">
                    {(v.listings ?? []).map((l) => <li key={l.id}><RecordLink type="listing" id={l.id}>{l.title}</RecordLink> <StatusPill value={l.status} /> <span className="muted small">{orgName(l.organisation_id)} · {humanize(l.channel)}</span></li>)}
                  </ul>
                )}
              </div>
            </Section>
          </div>
          <Section title="Identifiers">
            <DataTable compact rows={v.identifiers} rowKey={(r) => r.id}
              rowClassName={(r) => (r.retired_at ? "row-muted" : undefined)}
              columns={[
                { key: "n", header: "Namespace", render: (r) => <Mono>{r.namespace}</Mono> },
                { key: "v", header: "Value", render: (r) => <Mono>{r.value}</Mono> },
                { key: "s", header: "Synthetic", render: (r) => <Check value={r.is_synthetic} /> },
                { key: "ver", header: "Verification", render: (r) => <StatusPill value={r.verification_status} /> },
                { key: "src", header: "Source", render: (r) => <Mono>{r.source}</Mono> },
                { key: "iss", header: "Issuer", render: (r) => (r.issuing_organisation_id ? orgName(r.issuing_organisation_id) : <span className="muted">—</span>) },
                { key: "rec", header: "Recorded", render: (r) => dateTime(r.recorded_at, true) },
                { key: "ret", header: "Retired", render: (r) => (r.retired_at ? <>{dateTime(r.retired_at, true)} <span className="muted small">{r.retired_reason}</span></> : "—") },
              ]} />
          </Section>
        </> },
        { id: "provenance", label: "Provenance", count: assertions.length, render: () => <>
          {prov.loading ? <span className="muted">Loading…</span> : null}
          {!prov.loading && assertions.length === 0 ? <Empty>No sourced assertions recorded for this vehicle.</Empty> : null}
          {groupKeys.map((k) => (
            <Section key={k} title={<>{humanize(k)} <span className="muted small">({groups.get(k)!.length})</span></>}>
              <DataTable compact rows={groups.get(k)!} rowKey={(r) => r.id}
                columns={[
                  { key: "a", header: "Attribute", render: (r) => <Mono>{r.attribute}</Mono> },
                  { key: "v", header: "Value", render: (r) => <>{typeof r.value === "object" ? JSON.stringify(r.value) : String(r.value)} {r.unit ?? ""}</> },
                  { key: "s", header: "Source", render: (r) => <>{r.source}{r.source_reference ? <span className="muted small"> ({r.source_reference})</span> : null}</> },
                  { key: "e", header: "Effective", render: (r) => dateTime(r.effective_at, true) },
                  { key: "ver", header: "Verification", render: (r) => <StatusPill value={r.verification_status} /> },
                  { key: "sup", header: "Supersedes", render: (r) => (r.supersedes_id ? <Mono>{r.supersedes_id.slice(0, 8)}…</Mono> : "—") },
                ]} />
            </Section>
          ))}
          <Section title="Features">
            <DataTable compact rows={prov.data?.features ?? []} rowKey={(r) => r.id} empty="No features recorded."
              columns={[
                { key: "c", header: "Feature", render: (r) => <><Mono>{r.feature_code}</Mono> {r.label}</> },
                { key: "t", header: "Assertion type", render: (r) => humanize(r.assertion_type) },
                { key: "s", header: "Source", render: (r) => r.source },
                { key: "v", header: "Verification", render: (r) => <StatusPill value={r.verification_status} /> },
                { key: "r", header: "Recorded", render: (r) => dateTime(r.recorded_at, true) },
              ]} />
          </Section>
        </> },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="vehicle" targetId={id} /> },
      ] : []}
    />
  );
}

function VehicleForm({ v, busy, onSubmit, onCancel }: { v: Vehicle; busy: boolean; onSubmit(body: Record<string, unknown>): void; onCancel(): void }) {
  const [f, setF] = useState({
    exterior_colour: v.exterior_colour ?? "", interior_colour: v.interior_colour ?? "", condition: v.condition ?? "",
    odometer_value: v.odometer_value?.toString() ?? "", odometer_unit: v.odometer_unit ?? "mi", keys_count: v.keys_count?.toString() ?? "",
    has_open_recall: !!v.has_open_recall,
  });
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  return (
    <form className="form-box" onSubmit={(e) => {
      e.preventDefault();
      const body: Record<string, unknown> = {};
      if (f.exterior_colour !== (v.exterior_colour ?? "")) body.exterior_colour = f.exterior_colour || null;
      if (f.interior_colour !== (v.interior_colour ?? "")) body.interior_colour = f.interior_colour || null;
      if (f.condition !== (v.condition ?? "")) body.condition = f.condition || null;
      if (f.odometer_value !== (v.odometer_value?.toString() ?? "")) body.odometer_value = f.odometer_value === "" ? null : parseInt(f.odometer_value, 10);
      if (f.odometer_unit !== (v.odometer_unit ?? "mi")) body.odometer_unit = f.odometer_unit;
      if (f.keys_count !== (v.keys_count?.toString() ?? "")) body.keys_count = f.keys_count === "" ? null : parseInt(f.keys_count, 10);
      if (f.has_open_recall !== !!v.has_open_recall) body.has_open_recall = f.has_open_recall;
      onSubmit(body);
    }}>
      <h4>Edit descriptive fields <span className="muted small">(If-Match v{v.version}; availability changes only via reservations/sales)</span></h4>
      <div className="form-row">
        <Field label="Exterior colour"><input value={f.exterior_colour} onChange={set("exterior_colour")} /></Field>
        <Field label="Interior colour"><input value={f.interior_colour} onChange={set("interior_colour")} /></Field>
        <Field label="Condition">
          <select value={f.condition} onChange={set("condition")}><option value="">—</option><option>new</option><option>used</option><option>certified_pre_owned</option></select>
        </Field>
      </div>
      <div className="form-row">
        <Field label="Odometer"><input inputMode="numeric" pattern="\d*" value={f.odometer_value} onChange={set("odometer_value")} /></Field>
        <Field label="Unit"><select value={f.odometer_unit} onChange={set("odometer_unit")}><option>mi</option><option>km</option></select></Field>
        <Field label="Keys"><input inputMode="numeric" pattern="\d*" value={f.keys_count} onChange={set("keys_count")} /></Field>
        <label className="check"><input type="checkbox" checked={f.has_open_recall} onChange={(e) => setF({ ...f, has_open_recall: e.target.checked })} /> Open recall</label>
      </div>
      <div className="form-actions"><Button type="submit" variant="primary" busy={busy}>Save</Button><Button variant="ghost" onClick={onCancel}>Cancel</Button></div>
    </form>
  );
}
