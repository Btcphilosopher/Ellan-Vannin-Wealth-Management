import { useState, type ReactNode } from "react";
import { post, request } from "../api/client";
import type { PaymentIntent, ReconciliationCase, Refund } from "../api/types";
import { DataTable } from "../components/DataTable";
import { DetailShell } from "../components/DetailShell";
import { AuditHistory } from "../components/History";
import { ActionButton, Amount, Banner, Button, CopyId, Field, JsonView, KV, Mono, Section, StatusPill } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime, humanize, minorToDecimal, money, parseMoneyToMinor } from "../lib/format";
import { useAction, useIdempotencyKey, useResource } from "../lib/hooks";
import { RecordLink, useOpenRecord } from "../lib/nav";

const REFUND_REASONS = ["customer_request", "hold_expired_before_payment", "duplicate_payment", "sale_cancelled", "goodwill", "reconciliation"];

export function PaymentDetail({ id }: { id: string }) {
  const res = useResource<PaymentIntent>(`/v1/payments/${id}`);
  const { branding } = useApp();
  const orgName = useOrgName();
  const open = useOpenRecord();
  const p = res.data;
  const captured = (p?.transactions ?? []).filter((t) => t.kind === "capture").reduce((s, t) => s + t.amount_minor, 0);
  const refunded = (p?.refunds ?? []).filter((r) => r.status !== "failed").reduce((s, r) => s + r.amount_minor, 0);
  return (
    <DetailShell type="payment" id={id} loading={res.loading} error={res.error} onReload={res.reload}
      title={p ? <>{humanize(p.purpose)} · {money(p.amount_minor, p.currency)}</> : undefined}
      status={p ? <StatusPill value={p.status} /> : null}
      subtitle={p ? <>Provider <Mono>{p.provider}</Mono> ref <Mono>{p.provider_intent_ref ?? "—"}</Mono> · {orgName(p.organisation_id)}{p.failure_code ? <> · failure <Mono>{p.failure_code}</Mono></> : null}</> : null}
      tabs={p ? [
        { id: "overview", label: "Overview", render: () => <>
          {p.status === "unknown" ? <Banner kind="warning">Provider outcome unknown (timeout). The reconciliation worker will query the provider; do not retry blindly.</Banner> : null}
          <div className="cols-2">
            <Section title="Intent">
              <KV rows={[
                ["Status", <StatusPill value={p.status} />],
                ["Amount", <Amount minor={p.amount_minor} currency={p.currency} />],
                ["Captured", money(captured, p.currency)],
                ["Refunded (requested/settled)", money(refunded, p.currency)],
                ["Last provider event", dateTime(p.last_provider_event_at)],
                ["Idempotency-Key", <Mono>{p.idempotency_key ?? "—"}</Mono>],
                ["Created", dateTime(p.created_at)],
                ["Version", <Mono>{p.version}</Mono>],
              ]} />
            </Section>
            <Section title="Related">
              <KV rows={[
                ["Reservation", <RecordLink type="reservation" id={p.sale_reservation_id}>open reservation</RecordLink>],
                ["Sale order", <RecordLink type="sale_order" id={p.sale_order_id}>open sale order</RecordLink>],
                ["Rental booking", <RecordLink type="rental_booking" id={p.rental_booking_id}>open booking</RecordLink>],
                ["Customer", <RecordLink type="customer" id={p.customer_id}>open customer</RecordLink>],
                ["Refunds", (p.refunds ?? []).length ? <ul className="link-list">{(p.refunds ?? []).map((r) => <li key={r.id}><RecordLink type="refund" id={r.id}>{money(r.amount_minor, r.currency)} {humanize(r.reason)}</RecordLink> <StatusPill value={r.status} /></li>)}</ul> : "none"],
                ["Reconciliation cases", (p.cases ?? []).length ? <ul className="link-list">{(p.cases ?? []).map((c) => <li key={c.id}><RecordLink type="reconciliation_case" id={c.id}><Mono>{c.case_number}</Mono> {humanize(c.case_type)}</RecordLink> <StatusPill value={c.status} /></li>)}</ul> : "none"],
              ]} />
            </Section>
          </div>
          {branding?.simulator_enabled && p.provider_intent_ref ? <SimulatorBox intent={p} onDone={res.reload} /> : null}
        </> },
        { id: "transactions", label: "Transactions", count: p.transactions?.length, render: () => (
          <DataTable compact rows={p.transactions ?? []} rowKey={(t) => t.id} empty="No transactions recorded (append-only ledger)."
            columns={[
              { key: "k", header: "Kind", render: (t) => <StatusPill value={t.kind} /> },
              { key: "a", header: "Amount", align: "right", render: (t) => <Amount minor={t.amount_minor} currency={t.currency} /> },
              { key: "r", header: "Provider txn", render: (t) => <Mono>{String(t.provider_transaction_ref ?? "—")}</Mono> },
              { key: "rf", header: "Refund", render: (t) => (t.refund_id ? <RecordLink type="refund" id={String(t.refund_id)} /> : "—") },
              { key: "o", header: "Occurred", render: (t) => dateTime(String(t.occurred_at ?? "")) },
              { key: "rec", header: "Recorded", render: (t) => dateTime(String(t.recorded_at ?? ""), true) },
            ]} />
        ) },
        { id: "events", label: "Provider events", count: p.events?.length, render: () => (
          <DataTable compact rows={p.events ?? []} rowKey={(e) => e.id} empty="No provider events received."
            columns={[
              { key: "r", header: "Received", render: (e) => dateTime(e.received_at) },
              { key: "t", header: "Event type", render: (e) => <Mono>{e.event_type}</Mono> },
              { key: "id", header: "Provider event id", render: (e) => <Mono>{e.provider_event_id}</Mono> },
              { key: "c", header: "Provider created", render: (e) => dateTime(e.provider_created_at) },
              { key: "s", header: "Signature", render: (e) => <StatusPill value={e.signature_verified ? "verified" : "invalid"} /> },
              { key: "p", header: "Processing", render: (e) => <StatusPill value={e.processing_status} /> },
              { key: "n", header: "Note", render: (e) => e.processing_note ?? "" },
            ]} />
        ) },
        { id: "refunds", label: "Refunds", count: p.refunds?.length, render: () => <>
          <RefundForm intent={p} captured={captured} refunded={refunded} onDone={(r) => { res.reload(); open("refund", r.id); }} />
          <RefundsTable rows={p.refunds ?? []} />
        </> },
        { id: "cases", label: "Reconciliation", count: p.cases?.length, render: () => <CasesTable rows={p.cases ?? []} /> },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="payment_intent" targetId={id} /> },
      ] : []}
    />
  );
}

export function RefundsTable({ rows }: { rows: Refund[] }) {
  const open = useOpenRecord();
  const { branding } = useApp();
  const { run, busy } = useAction();
  return (
    <DataTable compact rows={rows} rowKey={(r) => r.id} onRowClick={(r) => open("refund", r.id)} empty="No refunds."
      columns={[
        { key: "a", header: "Amount", align: "right", render: (r) => <Amount minor={r.amount_minor} currency={r.currency} /> },
        { key: "re", header: "Reason", render: (r) => humanize(r.reason) },
        { key: "s", header: "Status", render: (r) => <StatusPill value={r.status} /> },
        { key: "p", header: "Provider ref", render: (r) => <Mono>{r.provider_refund_ref ?? "—"}</Mono> },
        { key: "t", header: "Requested", render: (r) => dateTime(r.requested_at, true) },
        { key: "sim", header: "", render: (r) => (branding?.simulator_enabled && r.provider_refund_ref && ["requested", "pending"].includes(r.status) ? (
          <span onClick={(e) => e.stopPropagation()} className="sim-inline">
            <Button small busy={busy === `sim-${r.id}`} title="SIMULATOR: settle this refund at the provider" onClick={() =>
              run(`sim-${r.id}`, () => post(`/v1/dev/simpay/refunds/${r.provider_refund_ref}/settle`, undefined, { query: { outcome: "succeeded" } }), { success: "Simulated refund settled" })}>
              Sim: settle
            </Button>
            <Button small variant="ghost" busy={busy === `simf-${r.id}`} onClick={() =>
              run(`simf-${r.id}`, () => post(`/v1/dev/simpay/refunds/${r.provider_refund_ref}/settle`, undefined, { query: { outcome: "failed" } }), { success: "Simulated refund failure" })}>
              fail
            </Button>
          </span>
        ) : null) },
      ]} />
  );
}

export function CasesTable({ rows }: { rows: ReconciliationCase[] }) {
  const open = useOpenRecord();
  return (
    <DataTable compact rows={rows} rowKey={(c) => c.id} onRowClick={(c) => open("reconciliation_case", c.id)} empty="No reconciliation cases."
      columns={[
        { key: "n", header: "Case", render: (c) => <Mono>{c.case_number}</Mono> },
        { key: "t", header: "Type", render: (c) => humanize(c.case_type) },
        { key: "sev", header: "Severity", render: (c) => <StatusPill value={c.severity} /> },
        { key: "s", header: "Status", render: (c) => <StatusPill value={c.status} /> },
        { key: "e", header: "Expected / observed", align: "right", render: (c) => `${money(c.expected_amount_minor, c.currency)} / ${money(c.observed_amount_minor, c.currency)}` },
        { key: "o", header: "Opened", render: (c) => dateTime(c.opened_at, true) },
      ]} />
  );
}

function RefundForm({ intent, captured, refunded, onDone }: { intent: PaymentIntent; captured: number; refunded: number; onDone(r: Refund): void }) {
  const remaining = Math.max(0, captured - refunded);
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("customer_request");
  const { run, busy, error } = useAction();
  const idem = useIdempotencyKey();
  if (intent.status !== "succeeded") return <Banner kind="info">Refunds can be requested once the payment has succeeded.</Banner>;
  const minor = amount.trim() ? parseMoneyToMinor(amount, intent.currency) : null;
  const invalid = amount.trim() !== "" && (minor === null || minor <= 0);
  return (
    <form className="form-box" onSubmit={async (e) => {
      e.preventDefault();
      if (invalid) return;
      const body = { payment_intent_id: intent.id, amount_minor: minor, reason };
      const r = await run("Request refund", () => post<Refund>("/v1/refunds", body, { idempotencyKey: idem.keyFor(body) }), { success: "Refund requested" });
      if (r) { idem.complete(); setAmount(""); onDone(r); }
    }}>
      <h4>Request a refund <span className="muted small">captured {money(captured, intent.currency)} · refundable {money(remaining, intent.currency)}</span></h4>
      <div className="form-row">
        <ActionGate perm="refunds.request" org={intent.organisation_id}>
          <Field label={`Amount (${intent.currency}) — blank = full remaining`} hint={invalid ? "Enter a positive amount with at most 2 decimals" : minor !== null && minor > remaining ? "Exceeds the refundable amount; the database will reject it (refund_limit_exceeded)" : undefined}>
            <input inputMode="decimal" placeholder={minorToDecimal(remaining, intent.currency)} value={amount} onChange={(e) => setAmount(e.target.value)} aria-invalid={invalid} />
          </Field>
          <Field label="Reason">
            <select value={reason} onChange={(e) => setReason(e.target.value)}>{REFUND_REASONS.map((r) => <option key={r} value={r}>{r}</option>)}</select>
          </Field>
          <div className="form-actions"><ActionButton perm="refunds.request" org={intent.organisation_id} type="submit" variant="primary" busy={busy === "Request refund"} disabled={invalid}>
            {minor ? `Refund ${money(minor, intent.currency)}` : "Refund remaining"}
          </ActionButton></div>
        </ActionGate>
      </div>
      {error ? <span className="muted small">Last attempt failed: <Mono>{error.code}</Mono> (same Idempotency-Key is reused on retry)</span> : null}
    </form>
  );
}

function ActionGate({ perm, org, children }: { perm: string; org: string; children: ReactNode }) {
  const { can } = useApp();
  if (!can(perm, org)) return <span className="muted">Requesting refunds requires <Mono>{perm}</Mono>.</span>;
  return <>{children}</>;
}

/** Development-only payment provider simulator (only when /v1/branding simulator_enabled). */
function SimulatorBox({ intent, onDone }: { intent: PaymentIntent; onDone(): void }) {
  const [outcome, setOutcome] = useState("succeeded");
  const [times, setTimes] = useState(1);
  const [stale, setStale] = useState(false);
  const [amount, setAmount] = useState("");
  const [result, setResult] = useState<unknown>(null);
  const { run, busy } = useAction();
  return (
    <section className="simulator" aria-label="Payment simulator">
      <header><span className="sim-badge">SIMULATOR</span> SimPay test provider — development only, not a real payment</header>
      <form className="form-row" onSubmit={async (e) => {
        e.preventDefault();
        const amt = amount.trim() ? parseMoneyToMinor(amount, intent.currency) : null;
        const r = await run("Simulate settlement", () => post(`/v1/dev/simpay/payments/${intent.provider_intent_ref}/settle`,
          { outcome, deliver: true, deliver_times: times, also_send_stale_processing: stale, amount_minor: amt }), { success: "Simulated provider webhook(s) delivered" });
        if (r) { setResult(r); onDone(); }
      }}>
        <Field label="Outcome">
          <select value={outcome} onChange={(e) => setOutcome(e.target.value)}><option>succeeded</option><option>failed</option><option>canceled</option></select>
        </Field>
        <Field label="Deliver times" hint="> 1 sends duplicates">
          <input type="number" min={1} max={5} value={times} onChange={(e) => setTimes(Math.max(1, Math.min(5, parseInt(e.target.value || "1", 10))))} />
        </Field>
        <Field label="Amount override" hint="blank = intent amount">
          <input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder={minorToDecimal(intent.amount_minor, intent.currency)} />
        </Field>
        <label className="check"><input type="checkbox" checked={stale} onChange={(e) => setStale(e.target.checked)} /> Also send stale “processing” (out-of-order)</label>
        <Button type="submit" variant="primary" small busy={busy === "Simulate settlement"}>Settle at provider</Button>
      </form>
      {result ? <details open><summary>Simulator response</summary><JsonView value={result} /></details> : null}
    </section>
  );
}

export function RefundDetail({ id }: { id: string }) {
  const list = useResource<{ items: Refund[] }>("/v1/refunds");
  const r = list.data?.items.find((x) => x.id === id);
  return (
    <DetailShell type="refund" id={id} loading={list.loading} error={list.error} onReload={list.reload}
      title={r ? <>Refund {money(r.amount_minor, r.currency)}</> : list.loading ? undefined : "Refund not found"}
      status={r ? <StatusPill value={r.status} /> : null}
      tabs={r ? [
        { id: "overview", label: "Overview", render: () => <>
          <Section title="Refund (read-only financial record)">
            <KV rows={[
              ["Amount", <Amount minor={r.amount_minor} currency={r.currency} />],
              ["Reason", humanize(r.reason)],
              ["Status", <StatusPill value={r.status} />],
              ["Provider ref", <Mono>{r.provider_refund_ref ?? "—"}</Mono>],
              ["Failure", r.failure_code ? <Mono>{r.failure_code}</Mono> : null],
              ["Payment intent", <RecordLink type="payment" id={r.payment_intent_id}>open payment</RecordLink>],
              ["Reconciliation case", <RecordLink type="reconciliation_case" id={r.reconciliation_case_id}>open case</RecordLink>],
              ["Requested", dateTime(r.requested_at)],
              ["Completed", dateTime(r.completed_at)],
              ["Version", <Mono>{r.version}</Mono>],
            ]} />
          </Section>
          <RefundsTable rows={[r]} />
        </> },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="refund" targetId={id} /> },
      ] : []}
    />
  );
}

const RESOLUTIONS = ["refunded", "applied_to_new_reservation", "provider_confirmed", "manual_adjustment", "no_action"];

export function ReconciliationCaseDetail({ id }: { id: string }) {
  const res = useResource<ReconciliationCase>(`/v1/reconciliation-cases/${id}`);
  const { run, busy, error, clearError } = useAction();
  const [resolution, setResolution] = useState("provider_confirmed");
  const [status, setStatus] = useState("resolved");
  const [note, setNote] = useState("");
  const c = res.data;
  const open = !!c && !["resolved", "written_off"].includes(c.status);
  return (
    <DetailShell type="reconciliation_case" id={id} loading={res.loading} error={res.error} onReload={() => { clearError(); res.reload(); }}
      actionError={error} onDismissError={clearError}
      title={c ? <>Case <Mono>{c.case_number}</Mono> · {humanize(c.case_type)}</> : undefined}
      status={c ? <><StatusPill value={c.status} /> <StatusPill value={c.severity} /></> : null}
      subtitle={c?.summary}
      tabs={c ? [
        { id: "overview", label: "Overview", render: () => <>
          {open ? (
            <ActionGateForm perm="reconciliation.manage" org={c.organisation_id}>
              <form className="form-box" onSubmit={async (e) => {
                e.preventDefault();
                const r = await run("Resolve case", () => request<ReconciliationCase>(`/v1/reconciliation-cases/${id}/resolution`,
                  { method: "POST", body: { resolution, status, note: note || null }, ifMatch: res.version }), { silent: true, success: "Case updated" });
                if (r) res.setData(r.data, r.version);
              }}>
                <h4>Resolve case <span className="muted small">(If-Match v{c.version})</span></h4>
                <div className="form-row">
                  <Field label="Resolution"><select value={resolution} onChange={(e) => setResolution(e.target.value)}>{RESOLUTIONS.map((r) => <option key={r}>{r}</option>)}</select></Field>
                  <Field label="Outcome"><select value={status} onChange={(e) => setStatus(e.target.value)}><option value="resolved">resolved</option><option value="written_off">written_off</option></select></Field>
                </div>
                <Field label="Note" wide><textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
                <div className="form-actions"><Button type="submit" variant="primary" busy={busy === "Resolve case"}>Save resolution</Button></div>
              </form>
            </ActionGateForm>
          ) : null}
          <div className="cols-2">
            <Section title="Case">
              <KV rows={[
                ["Type", humanize(c.case_type)],
                ["Status", <StatusPill value={c.status} />],
                ["Severity", <StatusPill value={c.severity} />],
                ["Expected", money(c.expected_amount_minor, c.currency)],
                ["Observed", money(c.observed_amount_minor, c.currency)],
                ["Opened", dateTime(c.opened_at)],
                ["Resolved", dateTime(c.resolved_at)],
                ["Resolution", c.resolution ? <><Mono>{c.resolution}</Mono> {c.resolution_note ? <span className="muted small">{c.resolution_note}</span> : null}</> : null],
                ["Version", <Mono>{c.version}</Mono>],
              ]} />
            </Section>
            <Section title="Related">
              <KV rows={[
                ["Payment intent", <RecordLink type="payment" id={c.payment_intent_id}>open payment</RecordLink>],
                ["Transaction", c.payment_transaction_id ? <CopyId id={c.payment_transaction_id} /> : null],
                ["Provider event", c.payment_event_id ? <CopyId id={c.payment_event_id} /> : null],
                ["Refund", <RecordLink type="refund" id={c.refund_id}>open refund</RecordLink>],
                ["Reservation", <RecordLink type="reservation" id={c.sale_reservation_id}>open reservation</RecordLink>],
                ["Rental booking", <RecordLink type="rental_booking" id={c.rental_booking_id}>open booking</RecordLink>],
              ]} />
            </Section>
          </div>
          <Section title="Details"><JsonView value={c.details} /></Section>
        </> },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="reconciliation_case" targetId={id} /> },
      ] : []}
    />
  );
}

function ActionGateForm({ perm, org, children }: { perm: string; org: string | null; children: ReactNode }) {
  const { can } = useApp();
  if (!can(perm, org)) return <Banner kind="info">Resolving cases requires <Mono>{perm}</Mono>.</Banner>;
  return <>{children}</>;
}
