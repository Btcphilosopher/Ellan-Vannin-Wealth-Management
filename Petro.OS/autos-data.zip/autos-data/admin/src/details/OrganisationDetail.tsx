import type { Organisation } from "../api/types";
import { DataTable } from "../components/DataTable";
import { DetailShell } from "../components/DetailShell";
import { Check, KV, Mono, Section, StatusPill } from "../components/ui";
import { duration, humanize } from "../lib/format";
import { useResource } from "../lib/hooks";

export function OrganisationDetail({ id }: { id: string }) {
  const res = useResource<Organisation>(`/v1/organisations/${id}`);
  const o = res.data;
  return (
    <DetailShell type="organisation" id={id} loading={res.loading} error={res.error} onReload={res.reload}
      title={o?.display_name}
      status={o ? <><StatusPill value={o.status} /> <span className="tag">{humanize(o.kind)}</span></> : null}
      subtitle={o ? <>{o.legal_name ?? ""} · <Mono>{o.slug}</Mono> · {o.default_currency} · <Mono>{o.default_timezone}</Mono></> : null}
      tabs={o ? [
        { id: "overview", label: "Overview", render: () => <>
          <div className="cols-2">
            <Section title="Organisation">
              <KV rows={[
                ["Kind", humanize(o.kind)],
                ["Legal name", o.legal_name],
                ["Slug", <Mono>{o.slug}</Mono>],
                ["Currency", o.default_currency],
                ["Default timezone", <Mono>{o.default_timezone}</Mono>],
                ["Synthetic", <Check value={o.is_synthetic} />],
                ["Version", o.version != null ? <Mono>{o.version}</Mono> : null],
              ]} />
            </Section>
            <Section title="Policies">
              {o.sale_hold_duration === undefined ? <span className="muted">Policies are visible to members of this organisation only.</span> : (
                <KV rows={[
                  ["Sale hold duration", duration(o.sale_hold_duration)],
                  ["Hold extension after deposit", duration(o.deposit_hold_extension)],
                  ["Listing freshness: warn after", duration(o.listing_freshness_warn_after)],
                  ["Listing freshness: suspend after", o.listing_freshness_suspend_after ? duration(o.listing_freshness_suspend_after) : "never"],
                  ["Freshness action", <Mono>{o.listing_freshness_action}</Mono>],
                ]} />
              )}
            </Section>
          </div>
          <Section title={`Locations (${o.locations?.length ?? 0})`}>
            <DataTable compact rows={o.locations ?? []} rowKey={(l) => l.id} empty="No locations."
              columns={[
                { key: "c", header: "Code", render: (l) => <Mono>{l.code}</Mono> },
                { key: "n", header: "Name", render: (l) => l.name },
                { key: "k", header: "Kind", render: (l) => humanize(l.kind) },
                { key: "a", header: "Address", render: (l) => `${l.address_line1 ?? ""}, ${l.city} ${l.postal_code ?? ""}` },
                { key: "r", header: "Region", render: (l) => <Mono>{l.region}</Mono> },
                { key: "tz", header: "Timezone", render: (l) => <Mono>{l.timezone}</Mono> },
                { key: "p", header: "Coordinates", render: (l) => (l.point ? <Mono>{l.point.lat.toFixed(4)}, {l.point.lon.toFixed(4)}</Mono> : "—") },
                { key: "s", header: "Status", render: (l) => <StatusPill value={l.status} /> },
              ]} />
          </Section>
          <Section title={`Members (${o.members?.length ?? 0})`}>
            {o.members === undefined ? <span className="muted">Member list is visible to members of this organisation only.</span> : (
              <DataTable compact rows={o.members} rowKey={(m) => m.id} empty="No members."
                columns={[
                  { key: "n", header: "Name", render: (m) => m.display_name },
                  { key: "e", header: "Email", render: (m) => <Mono>{m.email}</Mono> },
                  { key: "r", header: "Role", render: (m) => <span className="tag">{m.role}</span> },
                  { key: "s", header: "Status", render: (m) => <StatusPill value={m.status} /> },
                ]} />
            )}
          </Section>
        </> },
      ] : []}
    />
  );
}
