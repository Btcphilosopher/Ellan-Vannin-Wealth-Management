import { useState } from "react";
import { patch } from "../api/client";
import type { Customer, Page, Quote, Reservation } from "../api/types";
import { DataTable } from "../components/DataTable";
import { DetailShell } from "../components/DetailShell";
import { AuditHistory } from "../components/History";
import { ActionButton, Amount, Button, Check, Field, KV, Mono, Section, StatusPill } from "../components/ui";
import { useOrgName } from "../lib/app";
import { dateTime, humanize } from "../lib/format";
import { useAction, useResource } from "../lib/hooks";
import { RecordLink, useOpenRecord } from "../lib/nav";

export function CustomerDetail({ id }: { id: string }) {
  const res = useResource<Customer>(`/v1/customers/${id}`);
  const quotes = useResource<Page<Quote>>("/v1/quotes", { customer_id: id, limit: 50 });
  const resv = useResource<Page<Reservation>>("/v1/sale-reservations", { customer_id: id, limit: 50 });
  const { run, busy, error, clearError } = useAction();
  const orgName = useOrgName();
  const open = useOpenRecord();
  const [editing, setEditing] = useState(false);
  const c = res.data;
  return (
    <DetailShell type="customer" id={id} loading={res.loading} error={res.error} onReload={res.reload}
      actionError={error} onDismissError={clearError}
      title={c?.display_name}
      status={c ? <StatusPill value={c.status} /> : null}
      subtitle={c ? <>{humanize(c.customer_type)} · {c.email ?? "no email"} · {c.phone ?? "no phone"} {c.is_synthetic ? <span className="tag">synthetic</span> : null}</> : null}
      actions={c && c.status === "active" ? <ActionButton perm="customers.write" small onClick={() => setEditing(!editing)}>Edit contact</ActionButton> : null}
      tabs={c ? [
        { id: "overview", label: "Overview", render: () => <>
          {editing ? <ContactForm key={c.version} c={c} busy={busy === "Save customer"} onCancel={() => setEditing(false)} onSubmit={async (body) => {
            const r = await run("Save customer", () => patch<Customer>(`/v1/customers/${id}`, body, res.version), { silent: true, success: "Customer saved" });
            if (r) { res.setData(r); setEditing(false); }
          }} /> : null}
          <div className="cols-2">
            <Section title="Contact">
              <KV rows={[
                ["Display name", c.display_name],
                ["Given / family", `${c.given_name ?? "—"} / ${c.family_name ?? "—"}`],
                ["Business", c.business_name],
                ["Email", c.email],
                ["Phone", c.phone ? <Mono>{c.phone}</Mono> : null],
                ["Marketing consent", <Check value={c.marketing_consent} />],
                ["Created by", c.created_by_organisation_id ? <RecordLink type="organisation" id={c.created_by_organisation_id}>{orgName(c.created_by_organisation_id)}</RecordLink> : null],
                ["Created", dateTime(c.created_at)],
                ["Erased", c.erased_at ? dateTime(c.erased_at) : null],
                ["Version", <Mono>{c.version}</Mono>],
              ]} />
            </Section>
            <Section title="Relationships">
              <DataTable compact rows={c.relationships ?? []} rowKey={(r) => r.organisation_id} empty="No organisation relationships."
                columns={[
                  { key: "o", header: "Organisation", render: (r) => <RecordLink type="organisation" id={r.organisation_id}>{r.display_name}</RecordLink> },
                  { key: "b", header: "Basis", render: (r) => humanize(r.basis) },
                  { key: "f", header: "First interaction", render: (r) => dateTime(r.first_interaction_at, true) },
                ]} />
            </Section>
          </div>
          <Section title="Addresses">
            <DataTable compact rows={c.addresses ?? []} rowKey={(r) => r.id} empty="No addresses."
              columns={[
                { key: "k", header: "Kind", render: (r) => humanize(r.kind) },
                { key: "a", header: "Address", render: (r) => `${r.line1}${r.line2 ? `, ${r.line2}` : ""}, ${r.city} ${r.postal_code}` },
                { key: "r", header: "Region", render: (r) => <Mono>{r.region}</Mono> },
                { key: "c", header: "Country", render: (r) => r.country_code },
                { key: "v", header: "Valid", render: (r) => `${dateTime(r.valid_from, true)} → ${r.valid_to ? dateTime(r.valid_to, true) : "current"}` },
              ]} />
          </Section>
        </> },
        { id: "reservations", label: "Reservations", count: resv.data?.items.length, render: () => (
          <DataTable compact rows={resv.data?.items ?? []} rowKey={(r) => r.id} loading={resv.loading} error={resv.error} onRowClick={(r) => open("reservation", r.id)}
            empty="No reservations for this customer."
            columns={[
              { key: "n", header: "Number", render: (r) => <Mono>{r.reservation_number}</Mono> },
              { key: "s", header: "Status", render: (r) => <StatusPill value={r.effective_status} /> },
              { key: "d", header: "Deposit", render: (r) => <><Amount minor={r.deposit_required_minor} currency={r.currency} /> <StatusPill value={r.deposit_status} /></> },
              { key: "o", header: "Seller", render: (r) => orgName(r.organisation_id) },
              { key: "c", header: "Created", render: (r) => dateTime(r.created_at, true) },
            ]} />
        ) },
        { id: "quotes", label: "Quotes", count: quotes.data?.items.length, render: () => (
          <DataTable compact rows={quotes.data?.items ?? []} rowKey={(r) => r.id} loading={quotes.loading} error={quotes.error} onRowClick={(r) => open("quote", r.id)}
            empty="No quotes for this customer."
            columns={[
              { key: "n", header: "Number", render: (r) => <Mono>{r.quote_number}</Mono> },
              { key: "v", header: "Vehicle", render: (r) => r.snapshot.vehicle?.specification?.label ?? "—" },
              { key: "t", header: "Total", align: "right", render: (r) => (r.is_complete ? <Amount minor={r.total_minor} currency={r.currency} /> : <span className="pill pill-amber">incomplete</span>) },
              { key: "s", header: "Status", render: (r) => <StatusPill value={r.effective_status ?? r.status} /> },
            ]} />
        ) },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="customer" targetId={id} /> },
      ] : []}
    />
  );
}

function ContactForm({ c, busy, onSubmit, onCancel }: { c: Customer; busy: boolean; onSubmit(b: Record<string, unknown>): void; onCancel(): void }) {
  const [f, setF] = useState({
    display_name: c.display_name, given_name: c.given_name ?? "", family_name: c.family_name ?? "", business_name: c.business_name ?? "",
    email: c.email ?? "", phone: c.phone ?? "", marketing_consent: !!c.marketing_consent,
  });
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  return (
    <form className="form-box" onSubmit={(e) => {
      e.preventDefault();
      const body: Record<string, unknown> = {};
      (["display_name", "given_name", "family_name", "business_name", "email", "phone"] as const).forEach((k) => {
        const before = (c[k] ?? "") as string;
        if (f[k] !== before) body[k] = f[k] === "" ? null : f[k];
      });
      if (f.marketing_consent !== !!c.marketing_consent) body.marketing_consent = f.marketing_consent;
      onSubmit(body);
    }}>
      <h4>Edit contact <span className="muted small">(If-Match v{c.version})</span></h4>
      <div className="form-row">
        <Field label="Display name"><input required value={f.display_name} onChange={set("display_name")} /></Field>
        <Field label="Given name"><input value={f.given_name} onChange={set("given_name")} /></Field>
        <Field label="Family name"><input value={f.family_name} onChange={set("family_name")} /></Field>
      </div>
      <div className="form-row">
        <Field label="Business name"><input value={f.business_name} onChange={set("business_name")} /></Field>
        <Field label="Email"><input type="email" value={f.email} onChange={set("email")} /></Field>
        <Field label="Phone"><input type="tel" value={f.phone} onChange={set("phone")} /></Field>
      </div>
      <label className="check"><input type="checkbox" checked={f.marketing_consent} onChange={(e) => setF({ ...f, marketing_consent: e.target.checked })} /> Marketing consent</label>
      <div className="form-actions"><Button type="submit" variant="primary" busy={busy}>Save</Button><Button variant="ghost" onClick={onCancel}>Cancel</Button></div>
    </form>
  );
}
