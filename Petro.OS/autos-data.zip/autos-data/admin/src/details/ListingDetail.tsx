import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { patch, post, request } from "../api/client";
import type { Listing, Reservation, Validation, Vehicle } from "../api/types";
import { ConfirmAction } from "../components/ConfirmAction";
import { DataTable } from "../components/DataTable";
import { DetailShell } from "../components/DetailShell";
import { AuditHistory, StatusHistoryTable } from "../components/History";
import { ActionButton, Amount, Banner, Button, CopyId, Field, KV, Mono, Section, SeverityBadge, StatusPill } from "../components/ui";
import { dateTime, humanize, minorToDecimal, money } from "../lib/format";
import { useAction, useIdempotencyKey, useResource } from "../lib/hooks";
import { RecordLink, useOpenRecord } from "../lib/nav";

export function FindingsList({ findings }: { findings: Validation["findings"] }) {
  if (!findings.length) return <Banner kind="success">No validation findings — the listing passes all publication checks.</Banner>;
  return (
    <ul className="findings">
      {findings.map((f, i) => (
        <li key={i} className={`finding finding-${f.severity}`}>
          <SeverityBadge severity={f.severity} />
          <Mono>{f.code}</Mono>
          {f.field ? <span className="muted"> on <Mono>{f.field}</Mono></span> : null}
          <span> — {f.message}</span>
        </li>
      ))}
    </ul>
  );
}

export function ListingDetail({ id }: { id: string }) {
  const res = useResource<Listing>(`/v1/listings/${id}`);
  const val = useResource<Validation>(`/v1/listings/${id}/validation`);
  const { run, busy, error, clearError } = useAction();
  const open = useOpenRecord();
  const navigate = useNavigate();
  const idem = useIdempotencyKey();
  const [editing, setEditing] = useState<"price" | "content" | null>(null);
  const l = res.data;
  const v = res.version;
  const findings = val.data?.findings ?? [];
  const errors = findings.filter((f) => f.severity === "error");
  const org = l?.organisation_id;

  const act = async (label: string, path: string, body: unknown = {}) => {
    const r = await run(label, () => request<Listing>(path, { method: "POST", body, ifMatch: v }), { silent: true, success: `${label}: done` });
    if (r) { res.setData(r.data, r.version); val.reload(); }
  };

  const publishBlocked = errors.length ? `Cannot publish: ${errors.map((e) => e.code).join(", ")}` : null;

  return (
    <DetailShell type="listing" id={id} loading={res.loading} error={res.error} onReload={() => { res.reload(); val.reload(); clearError(); }}
      actionError={error} onDismissError={clearError}
      title={l?.title}
      status={l ? <><StatusPill value={l.status} /> <StatusPill value={l.freshness_state} title="freshness" /></> : null}
      subtitle={l ? <>
        <span className="price-lg">{l.price?.formatted ?? "no price"}</span>
        <span className="muted"> · deposit {l.deposit?.formatted ?? money(l.deposit_required_minor, l.currency)} (part of price)</span>
        <span className="muted"> · {l.seller?.display_name} · {l.location?.name}</span>
      </> : null}
      actions={l ? <>
        {(l.status === "draft" || l.status === "suspended") ? (
          <ActionButton perm="listings.publish" org={org} variant="primary" small busy={busy === "Publish"} blockedReason={val.loading ? "Checking validation…" : publishBlocked}
            onClick={() => act("Publish", `/v1/listings/${id}/publish`)}>Publish</ActionButton>
        ) : null}
        {l.status === "published" ? (
          <ConfirmAction label="Suspend" perm="listings.write" org={org} reason="optional" busy={busy === "Suspend"}
            onConfirm={(reason) => act("Suspend", `/v1/listings/${id}/suspend`, { reason })} />
        ) : null}
        {["draft", "published", "suspended"].includes(l.status) ? (
          <ConfirmAction label="Withdraw" perm="listings.write" org={org} reason="optional" variant="danger" busy={busy === "Withdraw"}
            confirmText="Withdraw is terminal. Continue?"
            onConfirm={(reason) => act("Withdraw", `/v1/listings/${id}/withdraw`, { reason })} />
        ) : null}
        {["draft", "published", "suspended"].includes(l.status) ? <>
          <ActionButton perm="listings.write" org={org} small onClick={() => setEditing(editing === "price" ? null : "price")}>Change price</ActionButton>
          <ActionButton perm="listings.write" org={org} small onClick={() => setEditing(editing === "content" ? null : "content")}>Edit content</ActionButton>
        </> : null}
        {l.status === "published" ? (
          <ActionButton perm="reservations.create" org={org} small busy={busy === "Place hold"} blockedReason={l.vehicle?.current_commitment ? "Vehicle already has an active commitment" : null}
            onClick={async () => {
              const body = { listing_id: id };
              const r = await run("Place hold", () => post<Reservation>("/v1/sale-reservations", body, { idempotencyKey: idem.keyFor(body) }),
                { silent: true, success: "Hold placed" });
              if (r) { idem.complete(); open("reservation", r.id); }
            }}>Place hold…</ActionButton>
        ) : null}
        {l.status === "published" ? (
          <ActionButton perm="quotes.issue" org={org} small onClick={() => navigate(`/quotes?new=1&listing=${id}`)}>Issue quote…</ActionButton>
        ) : null}
        <ActionButton perm="test_drives.manage" org={org} small onClick={() => navigate(`/test-drives?new=1&listing=${id}&vehicle=${l.vehicle_id}`)}>Request test drive…</ActionButton>
      </> : null}
      tabs={l ? [
        { id: "overview", label: "Overview", render: () => <>
          {editing === "price" ? <PriceForm key={l.version} listing={l} busy={busy === "Change price"} onCancel={() => setEditing(null)} onSubmit={async (price, reason) => {
            const r = await run("Change price", () => request<Listing>(`/v1/listings/${id}/prices`, { method: "POST", body: { price, reason }, ifMatch: v }),
              { silent: true, success: "Price changed" });
            if (r) { res.setData(r.data, r.version); setEditing(null); }
          }} /> : null}
          {editing === "content" ? <ContentForm key={l.version} listing={l} busy={busy === "Save listing"} onCancel={() => setEditing(null)} onSubmit={async (body) => {
            const r = await run("Save listing", () => patch<Listing>(`/v1/listings/${id}`, body, v), { silent: true, success: "Listing saved" });
            if (r) { res.setData(r); setEditing(null); val.reload(); }
          }} /> : null}
          {errors.length > 0 && (l.status === "draft" || l.status === "suspended") ? (
            <Banner kind="error">Publish is blocked by {errors.length} validation error{errors.length > 1 ? "s" : ""}: {errors.map((e) => e.code).join(", ")}</Banner>
          ) : null}
          <div className="cols-2">
            <Section title="Listing">
              <KV rows={[
                ["Status", <><StatusPill value={l.status} /> {l.status_reason ? <span className="muted small">{l.status_reason}</span> : null}</>],
                ["Channel", humanize(l.channel)],
                ["Sale eligibility", <StatusPill value={l.sale_eligibility} />],
                ["Asking price", <Amount minor={l.price?.amount_minor} currency={l.currency} formatted={l.price?.formatted} />],
                ["Deposit", <><Amount minor={l.deposit_required_minor} currency={l.currency} formatted={l.deposit?.formatted} /> <span className="muted small">included in price</span></>],
                ["Seller", <RecordLink type="organisation" id={l.organisation_id}>{l.seller?.display_name}</RecordLink>],
                ["Location", l.location ? <>{l.location.name} <span className="muted small">{l.location.timezone}</span></> : null],
                ["Published", dateTime(l.published_at)],
                ["Effective", l.effective_from || l.effective_to ? `${dateTime(l.effective_from)} → ${dateTime(l.effective_to)}` : null],
                ["Source", l.source_namespace ? <><Mono>{l.source_namespace}</Mono> / <Mono>{l.source_record_id}</Mono> · last seen {dateTime(l.source_last_seen_at)}</> : "manual"],
                ["Version", <Mono>{l.version}</Mono>],
              ]} />
              {l.description ? <p className="desc">{l.description}</p> : null}
            </Section>
            <Section title="Vehicle">
              <KV rows={[
                ["Vehicle", <RecordLink type="vehicle" id={l.vehicle_id}>{l.vehicle?.specification?.label ?? "Open vehicle"}</RecordLink>],
                ["VIN", <Mono>{l.vehicle?.vin ?? "—"}</Mono>],
                ["Condition", humanize(l.vehicle?.condition)],
                ["Colour", l.vehicle?.exterior_colour],
                ["Odometer", l.vehicle?.odometer_value != null ? `${l.vehicle.odometer_value.toLocaleString()} ${l.vehicle.odometer_unit ?? ""}` : null],
                ["Availability", <StatusPill value={l.vehicle?.availability_status} />],
                ["Commitment", l.vehicle?.current_commitment ? <CommitmentLink c={l.vehicle.current_commitment} /> : "none"],
              ]} />
              <OtherListings vehicleId={l.vehicle_id} currentId={l.id} />
            </Section>
          </div>
          <Section title={<>Validation findings <span className="muted small">GET /v1/listings/{"{id}"}/validation</span></>}>
            {val.loading && !val.data ? <span className="muted">Checking…</span> : <FindingsList findings={findings} />}
          </Section>
          <Section title={<>Recent status history <span className="muted small">(full history in the Status history and Audit tabs)</span></>}>
            <StatusHistoryTable rows={[...(l.status_history ?? [])].slice(-4).reverse()} />
          </Section>
        </> },
        { id: "validation", label: "Validation", count: findings.length, render: () => (
          <Section title="Publication validation" actions={<Button small onClick={val.reload} busy={val.loading}>Re-check</Button>}>
            {val.data ? <p>Publishable: <StatusPill value={val.data.publishable ? "true" : "false"} /></p> : null}
            <FindingsList findings={findings} />
          </Section>
        ) },
        { id: "prices", label: "Price history", count: l.price_history?.length, render: () => (
          <DataTable compact rows={l.price_history ?? []} rowKey={(r) => r.id} empty="No price versions."
            columns={[
              { key: "a", header: "Amount", align: "right", render: (r) => <Amount minor={r.amount_minor} currency={r.currency} /> },
              { key: "f", header: "Effective from", render: (r) => dateTime(r.effective_from) },
              { key: "t", header: "Effective to", render: (r) => r.effective_to ? dateTime(r.effective_to) : <StatusPill value="active" /> },
              { key: "r", header: "Reason", render: (r) => humanize(r.reason) },
              { key: "s", header: "Source", render: (r) => <Mono>{r.source}</Mono> },
              { key: "by", header: "By", render: (r) => <CopyId id={r.created_by} /> },
            ]} />
        ) },
        { id: "status", label: "Status history", count: l.status_history?.length, render: () => <StatusHistoryTable rows={l.status_history ?? []} /> },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="listing" targetId={id} /> },
      ] : []}
    />
  );

}

export function CommitmentLink({ c }: { c: Record<string, unknown> }) {
  const rid = c.sale_reservation_id as string | undefined;
  const oid = c.sale_order_id as string | undefined;
  return <>
    {rid ? <RecordLink type="reservation" id={rid}>{String(c.reservation_number ?? "reservation")}</RecordLink> : null}{" "}
    <StatusPill value={String(c.effective_status ?? c.status ?? "")} />
    {oid ? <> · <RecordLink type="sale_order" id={oid}>sale order</RecordLink></> : null}
    {c.hold_expires_at ? <span className="muted small"> hold until {dateTime(String(c.hold_expires_at))}</span> : null}
  </>;
}

function OtherListings({ vehicleId, currentId }: { vehicleId: string; currentId: string }) {
  const r = useResource<Vehicle>(`/v1/vehicles/${vehicleId}`);
  const others = (r.data?.listings ?? []).filter((x) => x.id !== currentId);
  return (
    <div className="related">
      <h4>Other listings of this vehicle</h4>
      {r.loading ? <span className="muted">Loading…</span> : others.length === 0 ? <span className="muted">None</span> : (
        <ul className="link-list">
          {others.map((o) => <li key={o.id}><RecordLink type="listing" id={o.id}>{o.title}</RecordLink> <StatusPill value={o.status} /> <span className="muted small">{humanize(o.channel)}</span></li>)}
        </ul>
      )}
    </div>
  );
}

function PriceForm({ listing, busy, onSubmit, onCancel }: { listing: Listing; busy: boolean; onSubmit(price: string, reason: string): void; onCancel(): void }) {
  const [price, setPrice] = useState(listing.price ? minorToDecimal(listing.price.amount_minor, listing.currency) : "");
  const [reason, setReason] = useState("price_change");
  return (
    <form className="form-box" onSubmit={(e) => { e.preventDefault(); onSubmit(price.trim(), reason); }}>
      <h4>Change asking price <span className="muted small">(closes the current price version; If-Match v{listing.version})</span></h4>
      <div className="form-row">
        <Field label={`New price (${listing.currency})`}><input required inputMode="decimal" pattern="[0-9,]+(\.[0-9]{1,2})?" value={price} onChange={(e) => setPrice(e.target.value)} /></Field>
        <Field label="Reason">
          <select value={reason} onChange={(e) => setReason(e.target.value)}>
            <option value="price_change">price_change</option><option value="correction">correction</option><option value="promotion">promotion</option>
          </select>
        </Field>
      </div>
      <div className="form-actions"><Button type="submit" variant="primary" busy={busy}>Save price</Button><Button variant="ghost" onClick={onCancel}>Cancel</Button></div>
    </form>
  );
}

function ContentForm({ listing, busy, onSubmit, onCancel }: { listing: Listing; busy: boolean; onSubmit(body: Record<string, unknown>): void; onCancel(): void }) {
  const [title, setTitle] = useState(listing.title);
  const [description, setDescription] = useState(listing.description ?? "");
  const [elig, setElig] = useState(listing.sale_eligibility);
  return (
    <form className="form-box" onSubmit={(e) => {
      e.preventDefault();
      const body: Record<string, unknown> = {};
      if (title !== listing.title) body.title = title;
      if (description !== (listing.description ?? "")) body.description = description || null;
      if (elig !== listing.sale_eligibility) body.sale_eligibility = elig;
      onSubmit(body);
    }}>
      <h4>Edit listing content <span className="muted small">(status and price change only through actions)</span></h4>
      <Field label="Title" wide><input required value={title} maxLength={200} onChange={(e) => setTitle(e.target.value)} /></Field>
      <Field label="Description" wide><textarea rows={3} value={description} onChange={(e) => setDescription(e.target.value)} /></Field>
      <Field label="Sale eligibility">
        <select value={elig} onChange={(e) => setElig(e.target.value)}>
          <option value="eligible">eligible</option><option value="not_eligible">not_eligible</option><option value="pending_review">pending_review</option>
        </select>
      </Field>
      <div className="form-actions"><Button type="submit" variant="primary" busy={busy}>Save</Button><Button variant="ghost" onClick={onCancel}>Cancel</Button></div>
    </form>
  );
}
