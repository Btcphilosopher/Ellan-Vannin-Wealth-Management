import { post } from "../api/client";
import type { Quote, Reservation } from "../api/types";
import { DataTable } from "../components/DataTable";
import { DetailShell } from "../components/DetailShell";
import { AuditHistory } from "../components/History";
import { ActionButton, Amount, Banner, JsonView, KV, Mono, Section, StatusPill } from "../components/ui";
import { useOrgName } from "../lib/app";
import { dateTime, humanize, money } from "../lib/format";
import { useAction, useIdempotencyKey, useResource } from "../lib/hooks";
import { RecordLink, useOpenRecord } from "../lib/nav";

export function QuoteBody({ q }: { q: Quote }) {
  const s = q.summary ?? {};
  const orgName = useOrgName();
  return <>
    {!q.is_complete ? (
      <Banner kind="warning">
        <strong>INCOMPLETE — missing: {q.missing_charges.join(", ") || "unknown charges"}</strong>
        <div className="small">The total cannot be stated until these charges are known. Total known so far: {s.total_known_so_far ?? money(q.total_known_minor, q.currency)}.</div>
      </Banner>
    ) : null}
    {q.is_expired ? <Banner kind="error">This quote expired {dateTime(q.expires_at)}.</Banner> : null}
    <Section title="Itemised charges">
      <DataTable compact rows={q.lines} rowKey={(r) => r.id}
        rowClassName={(r) => (r.amount_status === "unknown" ? "row-warn" : r.amount_status === "not_applicable" ? "row-muted" : undefined)}
        columns={[
          { key: "n", header: "#", render: (r) => r.line_no, width: 30 },
          { key: "t", header: "Type", render: (r) => humanize(r.line_type) },
          { key: "c", header: "Code", render: (r) => <Mono>{r.code}</Mono> },
          { key: "d", header: "Description", render: (r) => r.description },
          { key: "r", header: "Rate", render: (r) => (r.rate_bps != null ? `${(r.rate_bps / 100).toFixed(2)}% of ${money(r.basis_minor, q.currency)}` : "") },
          { key: "s", header: "Amount status", render: (r) => <StatusPill value={r.amount_status} /> },
          { key: "a", header: "Amount", align: "right", render: (r) => (r.amount_status === "known" ? <Amount minor={r.amount_minor} currency={q.currency} formatted={r.formatted} /> : <span className="muted">{r.amount_status === "unknown" ? "unknown" : "n/a"}</span>) },
        ]} />
    </Section>
    <div className="cols-2">
      <Section title="Totals">
        <table className="totals">
          <tbody>
            <tr><th>Vehicle price</th><td>{s.vehicle_price ?? money(q.vehicle_price_minor, q.currency)}</td></tr>
            <tr><th>Mandatory fees</th><td>{s.mandatory_fees ?? "—"}</td></tr>
            <tr><th>Optional products</th><td>{s.optional_products ?? "—"}</td></tr>
            <tr><th>Discounts</th><td>{s.discounts ?? "—"}</td></tr>
            <tr><th>Subtotal before tax &amp; registration</th><td>{s.subtotal_before_tax_registration ?? "—"}</td></tr>
            <tr><th>Taxes</th><td>{s.taxes ?? <span className="pill pill-amber">unknown</span>}</td></tr>
            <tr><th>Registration</th><td>{s.registration ?? <span className="pill pill-amber">unknown</span>}</td></tr>
            <tr><th>Delivery</th><td>{s.delivery ?? <span className="muted">n/a</span>}</td></tr>
            <tr className="total-row"><th>Total</th><td>{q.is_complete ? (s.total ?? money(q.total_minor, q.currency)) : <span className="pill pill-amber">INCOMPLETE</span>}</td></tr>
            <tr><th>Total known so far</th><td>{s.total_known_so_far ?? money(q.total_known_minor, q.currency)}</td></tr>
            <tr><th>Deposit required</th><td>{s.deposit_required ?? money(q.deposit_required_minor, q.currency)}</td></tr>
            {s.balance_after_deposit ? <tr><th>Balance after deposit</th><td>{s.balance_after_deposit}</td></tr> : null}
          </tbody>
        </table>
        <p className="note">
          {s.deposit_note ?? "The deposit is part of the total price, not an additional charge."}
          {q.deposit_treatment ? <span className="muted small"> (deposit_treatment: <Mono>{q.deposit_treatment}</Mono>)</span> : null}
        </p>
      </Section>
      <Section title="Quote">
        <KV rows={[
          ["Number", <Mono>{q.quote_number}</Mono>],
          ["Status", <StatusPill value={q.effective_status ?? q.status} />],
          ["Seller", <RecordLink type="organisation" id={q.organisation_id}>{q.snapshot.seller?.display_name ?? orgName(q.organisation_id)}</RecordLink>],
          ["Listing", <RecordLink type="listing" id={q.listing_id}>{q.snapshot.listing?.title ?? "listing"}</RecordLink>],
          ["Vehicle", <RecordLink type="vehicle" id={q.vehicle_id}>{q.snapshot.vehicle?.specification?.label ?? "vehicle"}</RecordLink>],
          ["VIN (snapshot)", <Mono>{q.snapshot.vehicle?.vin ?? "—"}</Mono>],
          ["Customer", q.customer_id ? <RecordLink type="customer" id={q.customer_id}>open customer</RecordLink> : <span className="muted">anonymous session {q.session_reference}</span>],
          ["Customer region", <Mono>{q.customer_region ?? "—"}</Mono>],
          ["Issued", dateTime(q.issued_at)],
          ["Expires", dateTime(q.expires_at)],
          ["Terms", q.snapshot.terms ? <Mono>{q.snapshot.terms.code} v{q.snapshot.terms.version}</Mono> : null],
          ["Snapshot", <><Mono title={q.snapshot_sha256}>{q.snapshot_sha256.slice(0, 12)}…</Mono> {q.snapshot_verified !== undefined ? <StatusPill value={q.snapshot_verified ? "verified" : "invalid"} /> : null}</>],
          ["Accepted", q.acceptance ? `${dateTime(q.acceptance.accepted_at)} via ${q.acceptance.acceptance_channel}` : "not accepted"],
        ]} />
      </Section>
    </div>
  </>;
}

export function QuoteDetail({ id }: { id: string }) {
  const res = useResource<Quote>(`/v1/quotes/${id}`);
  const { run, busy, error, clearError } = useAction();
  const open = useOpenRecord();
  const idem = useIdempotencyKey();
  const q = res.data;
  const acceptBlocked = !q ? null : !q.is_complete ? "Incomplete quotes cannot be accepted" : q.is_expired ? "Quote expired" : !q.customer_id ? "Anonymous quote — re-issue to a customer" : q.acceptance ? "Already accepted" : null;
  return (
    <DetailShell type="quote" id={id} loading={res.loading} error={res.error} onReload={res.reload} actionError={error} onDismissError={clearError}
      title={q ? <>Quote <Mono>{q.quote_number}</Mono></> : undefined}
      status={q ? <><StatusPill value={q.effective_status ?? q.status} />{!q.is_complete ? <span className="pill pill-amber" title="Total cannot be stated">INCOMPLETE — missing: {q.missing_charges.join(", ")}</span> : null}</> : null}
      subtitle={q ? <>{q.snapshot.vehicle?.specification?.label} · {q.is_complete ? <strong>{q.summary?.total ?? money(q.total_minor, q.currency)}</strong> : <>known so far {q.summary?.total_known_so_far}</>} · immutable snapshot</> : null}
      actions={q ? <>
        <ActionButton perm="quotes.issue" org={q.organisation_id} small blockedReason={acceptBlocked} busy={busy === "Record acceptance"}
          onClick={() => run("Record acceptance", () => post(`/v1/quotes/${id}/acceptance`, { channel: "in_store" }), { silent: true, success: "Acceptance recorded" })}>
          Record acceptance (in store)
        </ActionButton>
        <ActionButton perm="reservations.create" org={q.organisation_id} small busy={busy === "Place hold"} blockedReason={q.is_expired ? "Quote expired" : null}
          onClick={async () => {
            const body = { listing_id: q.listing_id, customer_id: q.customer_id, quote_id: q.id };
            const r = await run("Place hold", () => post<Reservation>("/v1/sale-reservations", body, { idempotencyKey: idem.keyFor(body) }), { silent: true, success: "Hold placed" });
            if (r) { idem.complete(); open("reservation", r.id); }
          }}>Place hold from quote</ActionButton>
      </> : null}
      tabs={q ? [
        { id: "overview", label: "Quote", render: () => <QuoteBody q={q} /> },
        { id: "snapshot", label: "Snapshot", render: () => <Section title="Captured snapshot (read-only)"><JsonView value={q.snapshot} /></Section> },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="quote" targetId={id} /> },
      ] : []}
    />
  );
}
