import { Fragment, useEffect, useState } from "react";
import { request } from "../api/client";
import type { ImportJob, ImportRow } from "../api/types";
import { ConfirmAction } from "../components/ConfirmAction";
import { DetailShell } from "../components/DetailShell";
import { AuditHistory } from "../components/History";
import { ActionButton, Banner, Button, ErrorPanel, Field, JsonView, KV, Mono, Section, SeverityBadge, StatusPill } from "../components/ui";
import { useOrgName } from "../lib/app";
import { dateTime, money, num } from "../lib/format";
import { useAction, useResource } from "../lib/hooks";
import { RecordLink } from "../lib/nav";

const ROW_STATUSES = ["", "valid", "warning", "invalid", "pending", "applied", "no_change", "skipped", "failed"];
const PAGE = 100;

export function ImportJobDetail({ id }: { id: string }) {
  const res = useResource<ImportJob>(`/v1/import-jobs/${id}`);
  const { run, busy, error, clearError } = useAction();
  const orgName = useOrgName();
  const [status, setStatus] = useState("");
  const [code, setCode] = useState("");
  const [offset, setOffset] = useState(0);
  const rows = useResource<{ items: ImportRow[] }>(`/v1/import-jobs/${id}/rows`, { status: status || undefined, code: code || undefined, limit: PAGE, offset });
  useEffect(() => setOffset(0), [status, code]);
  const j = res.data;
  const org = j?.organisation_id;
  const awaiting = j?.status === "validated";
  const approveBlocked = j && j.mode === "all_or_nothing" && j.invalid_count > 0
    ? `all_or_nothing: ${j.invalid_count} invalid row(s) block approval` : j && j.valid_count + j.warning_count === 0 ? "No valid rows to apply" : null;
  const findings = j?.findings_summary ?? [];
  const byCode = new Map<string, { severity: string; rows: number }[]>();
  for (const f of findings) byCode.set(f.code, [...(byCode.get(f.code) ?? []), { severity: f.severity, rows: Number(f.rows) }]);

  return (
    <DetailShell type="import_job" id={id} loading={res.loading} error={res.error} onReload={() => { clearError(); res.reload(); rows.reload(); }}
      actionError={error} onDismissError={clearError}
      title={j ? <>{j.original_filename}</> : undefined}
      status={j ? <><StatusPill value={j.status} /> <StatusPill value={j.mode} /></> : null}
      subtitle={j ? <><Mono>{j.source_namespace}</Mono> · {j.format.toUpperCase()} · {num(j.byte_size)} bytes · {orgName(j.organisation_id)} · uploaded {dateTime(j.uploaded_at)}</> : null}
      actions={j && awaiting ? <>
        <ActionButton perm="imports.approve" org={org} variant="primary" small busy={busy === "Approve import"} blockedReason={approveBlocked}
          onClick={async () => {
            const r = await run("Approve import", () => request<ImportJob>(`/v1/import-jobs/${id}/approval`, { method: "POST", ifMatch: res.version }), { silent: true, success: "Import approved and applied" });
            if (r) { res.setData(r.data, r.version); rows.reload(); }
          }}>Approve &amp; apply</ActionButton>
        <ConfirmAction label="Reject" perm="imports.approve" org={org} reason="required" variant="danger" busy={busy === "Reject"}
          onConfirm={async (reason) => {
            const form = new URLSearchParams({ reason: reason ?? "" });
            const r = await run("Reject", () => request<ImportJob>(`/v1/import-jobs/${id}/rejection`, { method: "POST", form, ifMatch: res.version }), { silent: true, success: "Import rejected" });
            if (r) res.reload();
          }} />
      </> : null}
      tabs={j ? [
        { id: "preview", label: "Preview", render: () => <>
          {j.mode === "all_or_nothing" && j.invalid_count > 0 && awaiting ? <Banner kind="error">All-or-nothing import: approval is blocked while {j.invalid_count} row(s) are invalid. Fix the file and re-upload.</Banner> : null}
          {j.mode === "partial_accept" && j.invalid_count > 0 && awaiting ? <Banner kind="warning">Partial accept: {j.invalid_count} invalid row(s) will be skipped on approval.</Banner> : null}
          <div className="kpis kpis-sm">
            {([["Rows", j.row_count], ["Valid", j.valid_count], ["Warnings", j.warning_count], ["Invalid", j.invalid_count], ["Applied", j.applied_count], ["No change", j.no_change_count], ["Skipped", j.skipped_count]] as [string, number][]).map(([k, n]) => (
              <button type="button" key={k} className={`kpi kpi-btn${k === "Invalid" && n > 0 ? " kpi-bad" : ""}${k === "Warnings" && n > 0 ? " kpi-warn" : ""}`}
                onClick={() => setStatus(k === "Valid" ? "valid" : k === "Warnings" ? "warning" : k === "Invalid" ? "invalid" : k === "Applied" ? "applied" : k === "Skipped" ? "skipped" : k === "No change" ? "no_change" : "")}>
                <span className="kpi-v">{num(n)}</span><span className="kpi-k">{k}</span>
              </button>
            ))}
          </div>
          <div className="cols-2">
            <Section title="Findings by code">
              {findings.length === 0 ? <span className="muted">No findings.</span> : (
                <table className="grid grid-compact">
                  <thead><tr><th>Code</th><th>Severity</th><th className="num">Rows</th><th /></tr></thead>
                  <tbody>{[...byCode.entries()].map(([c, list]) => list.map((f, i) => (
                    <tr key={`${c}-${i}`} className={code === c ? "row-active" : undefined}>
                      <td><Mono>{c}</Mono></td><td><SeverityBadge severity={f.severity} /></td><td className="num">{f.rows}</td>
                      <td><Button small variant="ghost" onClick={() => setCode(code === c ? "" : c)}>{code === c ? "Clear" : "Filter"}</Button></td>
                    </tr>
                  )))}</tbody>
                </table>
              )}
            </Section>
            <Section title="Job">
              <KV rows={[
                ["Planned actions", j.planned_actions ? Object.entries(j.planned_actions).map(([k, v]) => <span key={k} className="tag">{k}: {v}</span>) : null],
                ["Options", <Mono>{JSON.stringify(j.options)}</Mono>],
                ["SHA-256", <Mono title={j.file_sha256}>{j.file_sha256.slice(0, 16)}…</Mono>],
                ["Validated", dateTime(j.validated_at)],
                ["Approved", dateTime(j.approved_at)],
                ["Applied", dateTime(j.applied_at)],
                ["Error summary", j.error_summary ? <JsonView value={j.error_summary} /> : null],
                ["Version", <Mono>{j.version}</Mono>],
              ]} />
            </Section>
          </div>
          <Section title="Row preview — raw vs normalised" actions={<div className="filters-inline">
            <Field label="Row status"><select value={status} onChange={(e) => setStatus(e.target.value)}>{ROW_STATUSES.map((s) => <option key={s} value={s}>{s || "all"}</option>)}</select></Field>
            <Field label="Finding code"><select value={code} onChange={(e) => setCode(e.target.value)}>
              <option value="">all</option>{[...byCode.keys()].map((c) => <option key={c} value={c}>{c}</option>)}
            </select></Field>
          </div>}>
            {rows.error ? <ErrorPanel error={rows.error} onReload={rows.reload} /> : null}
            <ImportRowsTable rows={rows.data?.items ?? []} loading={rows.loading} />
            <div className="table-foot">
              <span className="muted">Rows {offset + 1}–{offset + (rows.data?.items.length ?? 0)}</span>
              <Button small disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - PAGE))}>Previous</Button>
              <Button small disabled={(rows.data?.items.length ?? 0) < PAGE} onClick={() => setOffset(offset + PAGE)}>Next</Button>
            </div>
          </Section>
        </> },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="import_job" targetId={id} /> },
      ] : []}
    />
  );
}

const SHOWN = ["vin", "make", "model", "model_year", "trim", "exterior_colour", "odometer_value", "odometer_unit", "price", "currency", "deposit", "location_code", "availability", "title"];
const NORM_KEY: Record<string, string> = { price: "price_minor", deposit: "deposit_minor", location_code: "location_id" };

function fmtCell(v: unknown): string {
  if (v === null || v === undefined) return "";
  if (Array.isArray(v)) return v.join(", ");
  if (typeof v === "object") return JSON.stringify(v);
  return String(v);
}

function ImportRowsTable({ rows, loading }: { rows: ImportRow[]; loading: boolean }) {
  const [expanded, setExpanded] = useState<string | null>(null);
  return (
    <div className="table-scroll" style={{ maxHeight: 520 }}>
      <table className="grid grid-compact import-rows">
        <thead>
          <tr>
            <th>#</th><th>Source id</th><th>Status</th><th>Action</th><th>Findings</th>
            {SHOWN.map((k) => <th key={k}>{k}</th>)}
            <th />
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const bad = new Set(r.findings.map((f) => f.field));
            const n = r.normalized ?? {};
            const cur = String(n.currency ?? r.raw.currency ?? "USD");
            return (
              <Fragment key={r.id}>
                <tr className={r.status === "invalid" ? "row-bad" : r.status === "warning" ? "row-warn" : undefined}>
                  <td className="num">{r.row_number}</td>
                  <td><Mono>{r.source_record_id ?? "—"}</Mono></td>
                  <td><StatusPill value={r.status} /></td>
                  <td>{r.planned_action ? <StatusPill value={r.planned_action} /> : "—"}{r.match_method && r.match_method !== "none" ? <span className="muted small"> via {r.match_method}</span> : null}</td>
                  <td className="findings-cell">{r.findings.length === 0 ? <span className="muted">—</span> : r.findings.map((f, i) => (
                    <div key={i}><SeverityBadge severity={f.severity} /> <Mono>{f.code}</Mono></div>
                  ))}</td>
                  {SHOWN.map((k) => {
                    const raw = fmtCell(r.raw[k]);
                    const nk = NORM_KEY[k] ?? k;
                    const nv = n[nk];
                    const norm = k === "price" || k === "deposit" ? (typeof nv === "number" ? money(nv, cur) : "") : k === "location_code" ? (nv ? "✓ resolved" : "") : fmtCell(nv);
                    const changed = norm !== "" && norm !== raw;
                    return (
                      <td key={k} className={bad.has(k) ? "cell-bad" : undefined} title={`raw: ${raw}\nnormalised: ${norm}`}>
                        <div className={k === "vin" ? "mono" : undefined}>{raw || <span className="muted">∅</span>}</div>
                        {changed ? <div className="norm">→ {norm}</div> : null}
                      </td>
                    );
                  })}
                  <td><Button small variant="ghost" onClick={() => setExpanded(expanded === r.id ? null : r.id)}>{expanded === r.id ? "Hide" : "Details"}</Button></td>
                </tr>
                {expanded === r.id ? (
                  <tr className="row-expand">
                    <td colSpan={SHOWN.length + 6}>
                      <div className="cols-3">
                        <div><h4>Raw</h4><JsonView value={r.raw} /></div>
                        <div><h4>Normalised</h4><JsonView value={r.normalized} /></div>
                        <div>
                          <h4>Findings</h4>
                          {r.findings.length === 0 ? <span className="muted">None</span> : <ul className="findings">{r.findings.map((f, i) => (
                            <li key={i} className={`finding finding-${f.severity}`}><SeverityBadge severity={f.severity} /> <Mono>{f.code}</Mono> {f.field ? <>on <Mono>{f.field}</Mono></> : null} — {f.message}</li>
                          ))}</ul>}
                          <h4>Matches</h4>
                          <KV rows={[
                            ["Vehicle", <RecordLink type="vehicle" id={r.matched_vehicle_id} />],
                            ["Listing", <RecordLink type="listing" id={r.matched_listing_id} />],
                            ["Result", r.result ? <JsonView value={r.result} /> : null],
                          ]} />
                        </div>
                      </div>
                    </td>
                  </tr>
                ) : null}
              </Fragment>
            );
          })}
        </tbody>
      </table>
      {loading ? <div className="loading"><span className="spinner" /> Loading rows…</div> : null}
      {!loading && rows.length === 0 ? <div className="empty">No rows match this filter.</div> : null}
    </div>
  );
}
