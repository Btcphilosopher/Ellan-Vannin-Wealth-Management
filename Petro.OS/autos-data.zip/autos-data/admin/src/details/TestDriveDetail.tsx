import { useCallback, useEffect, useState } from "react";
import { ApiError, request } from "../api/client";
import type { Page, TestDrive } from "../api/types";
import { ConfirmAction } from "../components/ConfirmAction";
import { DetailShell } from "../components/DetailShell";
import { AuditHistory } from "../components/History";
import { ActionButton, Banner, KV, Mono, Section, StatusPill } from "../components/ui";
import { useApp, useOrgName } from "../lib/app";
import { dateTime, humanize, inZone } from "../lib/format";
import { useAction } from "../lib/hooks";
import { useOrgLookups, useResources } from "../lib/lookups";
import { RecordLink } from "../lib/nav";

// There is no GET /v1/test-drive-appointments/{id}; the detail panel pages
// through the list endpoint to find the appointment (see README "API gaps").
async function findDrive(id: string): Promise<{ drive: TestDrive | null }> {
  let cursor: string | null = null;
  for (let i = 0; i < 20; i++) {
    const r: { data: Page<TestDrive> } = await request<Page<TestDrive>>("/v1/test-drive-appointments", { query: { limit: 200, cursor } });
    const hit = r.data.items.find((x) => x.id === id);
    if (hit) return { drive: hit };
    cursor = r.data.next_cursor ?? null;
    if (!cursor) break;
  }
  return { drive: null };
}

export function TestDriveDetail({ id }: { id: string }) {
  const { dataVersion } = useApp();
  const [d, setD] = useState<TestDrive | null>(null);
  const [loadErr, setLoadErr] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState(true);
  const { run, busy, error, clearError } = useAction();
  const orgName = useOrgName();
  const resources = useResources();
  const { locations } = useOrgLookups();
  const load = useCallback(() => {
    setLoading(true);
    findDrive(id).then((r) => {
      setD(r.drive);
      setLoadErr(r.drive ? null : new ApiError(404, { code: "not_found", detail: `test drive ${id} not found or not visible to you` }, null));
    }).catch((e) => setLoadErr(e as ApiError)).finally(() => setLoading(false));
  }, [id]);
  useEffect(load, [load, dataVersion]);

  const act = async (label: string, slug: string, reason?: string | null) => {
    const x = await run(label, () => request<TestDrive>(`/v1/test-drive-appointments/${id}/${slug}`, { method: "POST", body: reason !== undefined ? { reason } : {}, ifMatch: d?.version }),
      { silent: true, success: `${label}: done` });
    if (x) setD(x.data);
  };
  const res = resources.find((r) => r.id === d?.resource_id);
  const org = d?.organisation_id;
  const active = d && ["unconfirmed", "confirmed"].includes(d.confirmation_status);

  return (
    <DetailShell type="test_drive" id={id} loading={loading} error={loadErr} onReload={load} actionError={error} onDismissError={clearError}
      title={d ? <>Test drive · {inZone(d.local_start, d.local_timezone)}</> : undefined}
      status={d ? <><StatusPill value={d.confirmation_status} /> <StatusPill value={d.request_status} title="request status" /></> : null}
      subtitle={d ? <>{inZone(d.local_start, d.local_timezone, { timeOnly: true })}–{inZone(d.local_end, d.local_timezone, { timeOnly: true })} <Mono>{d.local_timezone}</Mono> · {locations.get(d.location_id)?.name ?? orgName(d.organisation_id)}</> : null}
      actions={d ? <>
        {d.confirmation_status === "unconfirmed" && d.request_status !== "declined" ? <ActionButton perm="test_drives.manage" org={org} variant="primary" small busy={busy === "Confirm"} onClick={() => act("Confirm", "confirmation")}>Confirm</ActionButton> : null}
        {d.request_status === "requested" ? <ConfirmAction label="Decline" perm="test_drives.manage" org={org} reason="optional" busy={busy === "Decline"} onConfirm={(r) => act("Decline", "decline", r)} /> : null}
        {active ? <ConfirmAction label="Cancel" perm="test_drives.manage" org={org} reason="required" variant="danger" busy={busy === "Cancel"} onConfirm={(r) => act("Cancel", "cancellation", r)} /> : null}
        {d.confirmation_status === "confirmed" ? <>
          <ActionButton perm="test_drives.manage" org={org} small busy={busy === "Complete"} onClick={() => act("Complete", "completion")}>Mark completed</ActionButton>
          <ConfirmAction label="No-show" perm="test_drives.manage" org={org} reason="optional" busy={busy === "No-show"} onConfirm={(r) => act("No-show", "no-show", r)} />
        </> : null}
      </> : null}
      tabs={d ? [
        { id: "overview", label: "Overview", render: () => <>
          {d.availability_notice ? <Banner kind="warning">Availability notice: <Mono>{d.availability_notice}</Mono> — the vehicle may be committed elsewhere.</Banner> : null}
          <div className="cols-2">
            <Section title="Appointment">
              <KV rows={[
                ["Local start", <>{inZone(d.local_start, d.local_timezone)} <Mono>{d.local_timezone}</Mono></>],
                ["Local end", <>{inZone(d.local_end, d.local_timezone)} <Mono>{d.local_timezone}</Mono></>],
                ["Your time", `${dateTime(d.starts_at)} → ${dateTime(d.ends_at, true)}`],
                ["Request status", <StatusPill value={d.request_status} />],
                ["Confirmation", <StatusPill value={d.confirmation_status} />],
                ["Resource", res ? `${res.name} (${humanize(res.kind)}, capacity ${res.capacity})` : <Mono>{d.resource_id}</Mono>],
                ["Cancelled", d.cancelled_at ? <>{dateTime(d.cancelled_at)} <span className="muted small">{d.cancellation_reason}</span></> : null],
                ["Version", <Mono>{d.version}</Mono>],
              ]} />
            </Section>
            <Section title="Related">
              <KV rows={[
                ["Vehicle", <RecordLink type="vehicle" id={d.vehicle_id}>open vehicle</RecordLink>],
                ["Listing", <RecordLink type="listing" id={d.listing_id}>open listing</RecordLink>],
                ["Customer", <RecordLink type="customer" id={d.customer_id}>open customer</RecordLink>],
                ["Dealer", <RecordLink type="organisation" id={d.organisation_id}>{orgName(d.organisation_id)}</RecordLink>],
              ]} />
            </Section>
          </div>
        </> },
        { id: "history", label: "Audit", render: () => <AuditHistory targetType="test_drive_appointment" targetId={id} /> },
      ] : []}
    />
  );
}
