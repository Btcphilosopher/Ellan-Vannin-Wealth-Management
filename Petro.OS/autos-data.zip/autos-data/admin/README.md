# Autos Data — staff administration UI

Operational admin front end for the **Vehicle Marketplace Database & Operations** API
(`backend/`, contract in `docs/openapi.json`). It is a dense, table-first staff tool, not a
customer storefront. Branding (name, product, disclaimer, simulator flag) is loaded at runtime
from `GET /v1/branding`; nothing brand-specific is hard-coded.

Stack: Vite 6 + React 18 + TypeScript 5 + react-router 7. No UI kit, no runtime CDNs or web
fonts — all styling is hand-written in `src/styles.css`.

| Package | Version |
|---|---|
| react / react-dom | 18.3.1 |
| react-router-dom | 7.18.7 |
| vite | 6.4.6 |
| @vitejs/plugin-react | 4.7.0 |
| typescript | 5.9.3 |
| @types/react / @types/react-dom / @types/node | 18.3.32 / 18.3.7 / 22.20.7 |

## Running

```bash
cd admin
npm ci
npm run dev        # http://localhost:5173, proxies /v1 -> http://localhost:8001
VITE_API_TARGET=http://localhost:8000 npm run dev   # point the proxy elsewhere
npm run build      # tsc -b (type-check) + vite build -> dist/
npm run preview    # serve dist/ with the same /v1 proxy
```

The app only calls relative `/v1/...` URLs. In development Vite proxies them; in production
nginx does.

### Docker

```bash
docker build -t autos-data-admin ./admin
# in docker compose, next to the API service named "api" (listening on 8000):
#   admin:
#     build: ./admin
#     ports: ["8080:80"]
#     depends_on: [api]
```

`Dockerfile` is multi-stage (`node:22-alpine` build → `nginx:1.27-alpine` serve).
`nginx.conf` serves the SPA with history fallback, proxies `/v1/` to `http://api:8000`, and sets
`X-Content-Type-Options`, `Referrer-Policy: no-referrer`, `X-Frame-Options: DENY`,
`Permissions-Policy` and a self-only `Content-Security-Policy` (no inline scripts or styles are
emitted by the build; this was checked in a browser with the CSP applied).

## Structure

```
src/
  main.tsx, App.tsx          routing; login gate
  api/client.ts              fetch wrapper: bearer token, X-Organisation-Id, If-Match,
                             Idempotency-Key, problem+json -> ApiError, ETag -> version
  api/types.ts               response shapes observed from the API
  lib/app.tsx                session context: branding, /v1/me, permissions (can()), org switcher,
                             toasts, data-version bus (lists refresh after actions)
  lib/hooks.ts               useResource (ETag/version aware), usePaged (cursor "Load more"),
                             useIdempotencyKey, useAction, useNow
  lib/format.ts              money (integer minor units -> Intl, BigInt/decimal strings, no float
                             maths), local times, IANA-zone wall-clock conversion
  lib/nav.tsx                ?open=<type>:<id> drawer routing + <RecordLink> related-record links
  lib/lookups.ts             cached reference data (organisations+locations, resources, rental
                             categories/assets)
  components/                Layout, DataTable, FilterBar(+SavedFilters), Drawer, DetailShell,
                             History (audit trail), ConfirmAction, ui primitives
  details/                   one record detail panel per record type (drawer)
  pages/                     one page per navigation section
```

### Cross-cutting behaviour

* **Login** — email picker of seeded staff + free email field → `POST /v1/auth/token`; token in
  `sessionStorage`. `GET /v1/me` provides memberships and effective permissions. When a user has
  several memberships an organisation switcher sends `X-Organisation-Id`. Logout clears the session.
* **Errors** — every RFC 9457 problem is shown with `code`, `detail`, field errors and
  `request_id` (toast or inline panel). `403` renders a "You do not have permission" panel.
* **Optimistic concurrency** — edits and domain actions send `If-Match: "<version>"` (from
  `ETag`/`version`). `409 version_conflict` shows "This record was changed by someone else" with a
  **Reload** button; edit forms re-initialise from the reloaded version.
* **Idempotency** — sale reservations, quotes, payments, refunds, test drives, rental bookings and
  customer creation send an `Idempotency-Key` (UUID per user action; the same key is reused when
  the same request is retried, a new one when the body changes).
* **Lists** — `{items, next_cursor}` with **Load more** (`?cursor=`; audit uses `before_id`).
  Sticky headers, zebra rows, 13 px type, monospace ids/VINs, coloured status pills.
* **Saved filters** — every section's filter bar has a saved-filter dropdown, "Save current…" and
  Delete (`GET/POST/DELETE /v1/saved-filters`, `page` = section key, `params` = filter object).
* **Detail panels** — right-side drawer addressed by `?open=<type>:<id>` (linkable, Back works).
  Panels contain related-record links, permission-gated actions and a History/Audit tab
  (`GET /v1/audit-events?target_type=&target_id=`) plus embedded histories.
* **Permissions** — action buttons are rendered only when `/v1/me` grants the permission for the
  record's organisation (platform_admin has all) and disabled with a reason when blocked by state
  (e.g. Publish while validation errors exist). The API still enforces everything.
* **No free-form editing** of status or financial/historical records and **no SQL console**:
  status changes go only through the action endpoints listed below.

## Features → endpoints

| Section | UI | Endpoints |
|---|---|---|
| Login / shell | seeded-user picker, org switcher, footer disclaimer | `POST /v1/auth/token`, `GET /v1/me`, `GET /v1/branding`, `GET /v1/organisations` |
| Overview | KPI tiles, worker health, needs-attention (open cases, imports awaiting approval, dead outbox, lapsed holds) | `GET /v1/reports/overview`, `/v1/reconciliation-cases?status=open`, `/v1/import-jobs`, `/v1/outbox-events?status=dead`, `/v1/sale-reservations?status=expired_effective` |
| Vehicles | VIN/identifier search, availability, custodian; detail: spec, identifiers (namespace/value/synthetic/verification), current commitment, listings, provenance grouped by assertion type (source, effective date, verification), features; edit descriptive fields; **Merge proposals** tab with accept/reject | `GET /v1/vehicles`, `GET/PATCH /v1/vehicles/{id}`, `GET /v1/vehicles/{id}/assertions`, `GET /v1/vehicle-merge-proposals`, `POST /v1/vehicle-merge-proposals/{id}/decision` |
| Listings | filters: q, status, seller, make, model, price min/max (→ minor units), freshness, radius (lat/lon/radius_km, pick a known location); bulk publish with per-row results; CSV export; detail: validation findings (error/warning), publish disabled with reasons, suspend/withdraw, price change, content edit, place hold, issue quote, request test drive; price history, status history, audit; "other listings of this vehicle" | `GET /v1/listings`, `GET /v1/listings/export.csv`, `GET/PATCH /v1/listings/{id}`, `GET /v1/listings/{id}/validation`, `POST /v1/listings/{id}/publish\|suspend\|withdraw\|prices`, `POST /v1/listings/publication-batch` |
| Dealers | organisations by kind; detail: locations with timezone & coordinates, policies (hold duration, deposit extension, freshness warn/suspend/action), members | `GET /v1/organisations`, `GET /v1/organisations/{id}` |
| Customers | search, create; detail: contact, relationships, addresses, reservations, quotes, audit; edit contact (If-Match) | `GET/POST /v1/customers`, `GET/PATCH /v1/customers/{id}` |
| Quotes | list; issue form (listing, customer, customer_region, product codes, promo codes, delivery, validity); detail: itemised lines with known/unknown/not_applicable, **INCOMPLETE — missing: …** banner, totals, deposit note, snapshot (+hash verification), record acceptance, place hold from quote | `GET/POST /v1/quotes`, `GET /v1/quotes/{id}`, `POST /v1/quotes/{id}/acceptance`, `POST /v1/sale-reservations` |
| Reservations | status filter incl. `expired_effective`; create hold; countdown from `seconds_remaining`; effective vs stored status; take deposit payment; dealer accept; cancel/decline/release; convert to sale order; sale order: agreement, handover, completion, cancellation, balance payment; events, payments, audit | `GET/POST /v1/sale-reservations`, `GET /v1/sale-reservations/{id}`, `POST …/acceptance\|cancellation\|sale-order`, `GET /v1/sale-orders/{id}`, `POST /v1/sale-orders/{id}/agreement\|handover\|completion\|cancellation`, `POST /v1/payments` |
| Test Drives | grouped by local day, local times with IANA zone; request form (times entered in the dealership zone); confirm, decline, cancel, complete, no-show | `GET/POST /v1/test-drive-appointments`, `POST …/{id}/confirmation\|decline\|cancellation\|completion\|no-show`, `GET /v1/appointment-resources` |
| Rentals | bookings list; availability check; rental price quote; booking form (optional exact asset); detail: assign/reassign asset, check-out, return, no-show, cancel, prepayment; fleet list, categories, maintenance block form | `GET/POST /v1/rental-bookings`, `GET /v1/rental-bookings/{id}`, `POST …/assignment\|cancellation\|check-out\|return\|no-show`, `GET /v1/rental-availability`, `POST /v1/rental-quotes`, `GET /v1/rental-assets`, `GET /v1/rental-categories`, `POST /v1/maintenance-blocks` |
| Payments | intents (status filter), refunds, reconciliation cases (status filter); intent detail: transactions, provider events (`processing_status` incl. duplicate / ignored out-of-order), refunds, cases; partial refund form; **Simulator** box (only when `simulator_enabled`): outcome, deliver_times, amount override, stale "processing"; refund settle buttons; case resolution form (If-Match) | `GET /v1/payments`, `GET /v1/payments/{id}`, `GET/POST /v1/refunds`, `GET /v1/reconciliation-cases`, `GET /v1/reconciliation-cases/{id}`, `POST …/resolution`, `POST /v1/dev/simpay/payments/{ref}/settle`, `POST /v1/dev/simpay/refunds/{ref}/settle` |
| Imports | upload form (file, source_namespace, mode, format, options JSON: `clear_blank_fields`, `publish_on_apply`), duplicate-upload banner; job detail: counts, findings grouped by code, planned actions, row preview (status / finding-code filters, raw vs normalised, per-row findings, matches); approve (If-Match) / reject (reason) | `POST /v1/import-jobs` (multipart), `GET /v1/import-jobs`, `GET /v1/import-jobs/{id}`, `GET /v1/import-jobs/{id}/rows`, `POST …/approval`, `POST …/rejection` |
| Audit | audit events (action, target_type, target_id, request_id; click a request id to trace it; rows open the target record); Outbox tab with status filter and dead-letter requeue | `GET /v1/audit-events`, `GET /v1/outbox-events`, `POST /v1/outbox-events/{id}/requeue` |
| Reports | inventory, reservations, payments, rentals, imports, data-quality rendered as compact tables (minor-unit columns formatted); platform users can scope by organisation | `GET /v1/reports/{name}` |

## API gaps worked around

* No `GET /v1/test-drive-appointments/{id}` — the test-drive panel pages through the list endpoint
  to find the appointment.
* No `GET /v1/refunds/{id}` or rental-asset detail — panels read from the list endpoints.
* `GET /v1/quotes/{id}` and `GET /v1/payments/{id}` return no `ETag` (they have no If-Match
  actions, so this is harmless).
* No endpoint lists charge rules / product or promo codes — the quote form offers the seeded codes
  as hints and accepts free text; the API validates (`unknown_reference`).
* `GET /v1/import-jobs` and `GET /v1/outbox-events`, `/v1/refunds`, `/v1/reconciliation-cases`
  are not paginated (latest 200); import job filters are applied client-side.
