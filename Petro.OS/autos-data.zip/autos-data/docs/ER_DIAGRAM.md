# Entity-relationship diagrams

Generated from the live catalog by `backend/scripts/gen_docs.py` (Mermaid sources in [`er/`](er/), rendered to SVG locally with the `mermaid` npm package). Every arrow is a real foreign key; crow's-foot = many. Domain diagrams show their own tables in full and neighbouring tables (organisations, vehicles, listings, customers) in compact key-only form.

## Overview (keys and status columns only)

![overview](er/overview.svg)

Key relationships in words:

- An **organisation** (platform, dealer, rental supplier) has **locations**, members, charge rules and everything tenant-scoped.
- A **vehicle** is one physical car (custodian = organisation). It has namespaced **identifiers**, provenance **assertions**, features and media. A vehicle may have **several listings** (channels/sellers) but at most one row in **vehicle_current_reservations**.
- A **listing** offers a vehicle at a location; its price lives in append-only **listing_price_versions**; publication history in **listing_status_events**.
- A **quote** freezes a listing + price version + vehicle snapshot, itemised in **quote_lines**; **quote_acceptances** records the customer's acceptance.
- A **sale_reservation** (hold) may lead to a **sale_order** and **handover_records**; all transitions land in **sale_status_events**.
- **payment_intents** target a reservation, order or rental booking; **payment_events** (verified webhooks) produce **payment_transactions**; **refunds** reference a capture; **reconciliation_cases** link whatever doesn't line up.
- **rental_bookings** consume capacity of a **rental_inventory_bucket** (location × category); **rental_asset_assignments** bind an exact **rental_asset**; **maintenance_blocks** remove assets from service.
- **import_jobs** stage **import_rows**; **source_record_mappings** link external records to vehicles/listings.

## Tenancy & identity

![tenancy-identity](er/tenancy-identity.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  currencies {
    character code PK
    smallint minor_unit
    text name
  }
  organisations {
    uuid id PK
    text kind
    text legal_name
    text display_name
    text slug
    text status
    character default_currency FK
    text default_timezone
    interval listing_freshness_warn_after
    interval listing_freshness_suspend_after
    text listing_freshness_action
    interval sale_hold_duration
    interval deposit_hold_extension
    boolean is_synthetic
    timestamptz created_at
    timestamptz updated_at
    integer version
    timestamptz archived_at
  }
  app_users {
    uuid id PK
    citext email
    text display_name
    text kind
    uuid customer_id FK
    text status
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  organisation_memberships {
    uuid id PK
    uuid organisation_id FK
    uuid user_id FK
    text role
    text status
    timestamptz valid_from
    timestamptz valid_to
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  locations {
    uuid id PK
    uuid organisation_id FK
    text code
    text name
    text kind
    text address_line1
    text address_line2
    text city
    text region
    text postal_code
    character country_code
    geography geog
    text timezone
    text status
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  customers {
    uuid id PK
    text status
    uuid created_by_organisation_id FK
    integer version
  }
  customers ||--o{ app_users : "customer_fk"
  organisations ||--o{ customers : "created_by_organisation_id"
  organisations ||--o{ locations : "organisation_id"
  organisations ||--o{ organisation_memberships : "organisation_id"
  app_users ||--o{ organisation_memberships : "user_id"
  currencies ||--o{ organisations : "default_currency"
```
</details>

## Catalogue, physical vehicles, identity & provenance

![catalogue-vehicles](er/catalogue-vehicles.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  vehicle_makes {
    uuid id PK
    citext name
    text slug
    timestamptz created_at
  }
  vehicle_models {
    uuid id PK
    uuid make_id FK
    text name
    text slug
    timestamptz created_at
  }
  vehicle_trims {
    uuid id PK
    uuid model_id FK
    smallint model_year
    text name
    text body_style
    text drivetrain
    text fuel_type
    timestamptz created_at
  }
  vehicle_specification_versions {
    uuid id PK
    uuid trim_id FK
    text source
    text source_reference
    date effective_from
    date effective_to
    text verification_status
    bigint msrp_minor
    character msrp_currency FK
    smallint doors
    smallint seats
    integer engine_displacement_cc
    numeric battery_capacity_kwh
    numeric power_kw
    integer electric_range_km
    numeric combined_l_per_100km
    jsonb attributes
    timestamptz recorded_at
    uuid recorded_by FK
  }
  vehicles {
    uuid id PK
    uuid trim_id FK
    uuid custodian_organisation_id FK
    uuid current_location_id FK
    smallint model_year
    text exterior_colour
    text interior_colour
    text condition
    integer odometer_value
    text odometer_unit
    timestamptz odometer_recorded_at
    boolean has_open_recall
    smallint keys_count
    text availability_status
    timestamptz sold_at
    uuid merged_into_vehicle_id FK
    timestamptz created_at
    timestamptz updated_at
    integer version
    timestamptz archived_at
  }
  vehicle_identifiers {
    uuid id PK
    uuid vehicle_id FK
    text namespace
    text value
    text value_normalized
    uuid issuing_organisation_id FK
    boolean is_synthetic
    text verification_status
    text source
    timestamptz recorded_at
    timestamptz retired_at
    text retired_reason
  }
  vehicle_attribute_assertions {
    uuid id PK
    uuid vehicle_id FK
    uuid organisation_id FK
    text attribute FK
    text assertion_type
    jsonb value
    text unit
    text source
    text source_reference
    timestamptz effective_at
    text verification_status
    uuid supersedes_id FK
    uuid recorded_by FK
    timestamptz recorded_at
  }
  vehicle_features {
    uuid id PK
    uuid vehicle_id FK
    text feature_code
    text label
    text assertion_type
    text source
    text verification_status
    timestamptz recorded_at
  }
  vehicle_media {
    uuid id PK
    uuid vehicle_id FK
    uuid organisation_id FK
    text kind
    text storage_bucket
    text object_key
    text content_type
    bigint byte_size
    character sha256
    text caption
    integer sort_order
    uuid uploaded_by FK
    timestamptz uploaded_at
    timestamptz archived_at
  }
  vehicle_merge_proposals {
    uuid id PK
    uuid organisation_id FK
    uuid primary_vehicle_id FK
    uuid duplicate_vehicle_id FK
    numeric score
    jsonb evidence
    text proposed_by
    text status
    uuid decided_by FK
    timestamptz decided_at
    text decision_note
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  organisations ||--o{ vehicle_attribute_assertions : "organisation_id"
  vehicle_attribute_assertions ||--o{ vehicle_attribute_assertions : "supersedes_id"
  vehicles ||--o{ vehicle_attribute_assertions : "vehicle_id"
  vehicles ||--o{ vehicle_features : "vehicle_id"
  organisations ||--o{ vehicle_identifiers : "issuing_organisation_id"
  vehicles ||--o{ vehicle_identifiers : "vehicle_id"
  organisations ||--o{ vehicle_media : "organisation_id"
  vehicles ||--o{ vehicle_media : "vehicle_id"
  vehicles ||--o{ vehicle_merge_proposals : "duplicate_vehicle_id"
  organisations ||--o{ vehicle_merge_proposals : "organisation_id"
  vehicle_makes ||--o{ vehicle_models : "make_id"
  vehicle_trims ||--o{ vehicle_specification_versions : "trim_id"
  vehicle_models ||--o{ vehicle_trims : "model_id"
  organisations ||--o{ vehicles : "custodian_organisation_id"
  vehicles ||--o{ vehicles : "merged_into_vehicle_id"
  vehicle_trims ||--o{ vehicles : "trim_id"
```
</details>

## Listings, price versions, status history

![listings](er/listings.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  listings {
    uuid id PK
    uuid organisation_id FK
    uuid vehicle_id FK
    uuid location_id FK
    text channel
    text title
    text description
    text status
    text status_reason
    text sale_eligibility
    character currency FK
    uuid current_price_version_id FK
    bigint deposit_required_minor
    text source_namespace
    text source_record_id FK
    timestamptz source_last_seen_at
    text freshness_state
    timestamptz effective_from
    timestamptz effective_to
    timestamptz published_at
    timestamptz withdrawn_at
    timestamptz sold_at
    uuid created_by FK
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  listing_price_versions {
    uuid id PK
    uuid listing_id FK
    uuid organisation_id FK
    bigint amount_minor
    character currency FK
    timestamptz effective_from
    timestamptz effective_to
    text reason
    text source
    uuid created_by FK
    timestamptz created_at
  }
  listing_status_events {
    uuid id PK
    uuid listing_id FK
    uuid organisation_id FK
    text from_status
    text to_status
    text reason
    uuid actor_user_id FK
    text actor_kind
    text request_id FK
    timestamptz occurred_at
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  vehicles {
    uuid id PK
    uuid trim_id FK
    uuid custodian_organisation_id FK
    uuid current_location_id FK
    uuid merged_into_vehicle_id FK
    integer version
  }
  listings ||--o{ listing_price_versions : "listing_id_currency"
  listings ||--o{ listing_status_events : "listing_id_organisation_id"
  listing_price_versions ||--o{ listings : "current_price_fk"
  organisations ||--o{ listings : "organisation_id"
  vehicles ||--o{ listings : "vehicle_id"
  organisations ||--o{ vehicles : "custodian_organisation_id"
  vehicles ||--o{ vehicles : "merged_into_vehicle_id"
```
</details>

## Customers

![customers](er/customers.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  customers {
    uuid id PK
    text customer_type
    text given_name
    text family_name
    text business_name
    text display_name
    citext email
    text phone
    boolean marketing_consent
    text status
    timestamptz erased_at
    boolean is_synthetic
    uuid created_by_organisation_id FK
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  customer_relationships {
    uuid customer_id FK
    uuid organisation_id FK
    text basis
    timestamptz first_interaction_at
  }
  customer_addresses {
    uuid id PK
    uuid customer_id FK
    text kind
    text line1
    text line2
    text city
    text region
    text postal_code
    character country_code
    geography geog
    timestamptz valid_from
    timestamptz valid_to
    timestamptz created_at
  }
  saved_vehicles {
    uuid customer_id FK
    uuid listing_id FK
    text note
    timestamptz saved_at
  }
  saved_searches {
    uuid id PK
    uuid customer_id FK
    text name
    jsonb criteria
    boolean notify
    timestamptz last_notified_at
    timestamptz created_at
  }
  listings {
    uuid id PK
    uuid organisation_id FK
    uuid vehicle_id FK
    uuid location_id FK
    text status
    uuid current_price_version_id FK
    text source_record_id FK
    integer version
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  customers ||--o{ customer_addresses : "customer_id"
  customers ||--o{ customer_relationships : "customer_id"
  organisations ||--o{ customer_relationships : "organisation_id"
  organisations ||--o{ customers : "created_by_organisation_id"
  organisations ||--o{ listings : "organisation_id"
  customers ||--o{ saved_searches : "customer_id"
  customers ||--o{ saved_vehicles : "customer_id"
  listings ||--o{ saved_vehicles : "listing_id"
```
</details>

## Charge rules, terms, immutable quotes

![quotes](er/quotes.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  terms_versions {
    uuid id PK
    text code
    integer version
    text title
    character body_sha256
    timestamptz effective_from
    timestamptz effective_to
    timestamptz created_at
  }
  charge_rules {
    uuid id PK
    uuid organisation_id FK
    text charge_type
    text code
    text label
    text calculation
    bigint amount_minor
    integer rate_bps
    character currency FK
    text region
    timestamptz effective_from
    timestamptz effective_to
    timestamptz created_at
  }
  quotes {
    uuid id PK
    text quote_number
    uuid organisation_id FK
    uuid listing_id FK
    uuid vehicle_id FK
    uuid listing_price_version_id FK
    uuid customer_id FK
    text session_reference
    text customer_region
    character currency FK
    bigint vehicle_price_minor
    bigint mandatory_fees_minor
    bigint optional_products_minor
    bigint discounts_minor
    bigint subtotal_before_tax_registration_minor
    bigint taxes_minor
    bigint registration_minor
    bigint delivery_minor
    bigint total_known_minor
    bigint total_minor
    bigint deposit_required_minor
    text deposit_treatment
    boolean is_complete
    text[] missing_charges
    uuid terms_version_id FK
    jsonb snapshot
    character snapshot_sha256
    text status
    timestamptz issued_at
    timestamptz expires_at
    uuid issued_by FK
    text request_id FK
  }
  quote_lines {
    uuid id PK
    uuid quote_id FK
    uuid organisation_id FK
    smallint line_no
    text line_type
    text code
    text description
    text amount_status
    bigint amount_minor
    integer rate_bps
    bigint basis_minor
    uuid source_rule_id FK
  }
  quote_acceptances {
    uuid id PK
    uuid quote_id FK
    uuid organisation_id FK
    uuid customer_id FK
    uuid terms_version_id FK
    timestamptz accepted_at
    text acceptance_channel
    text request_id FK
  }
  customers {
    uuid id PK
    text status
    uuid created_by_organisation_id FK
    integer version
  }
  listings {
    uuid id PK
    uuid organisation_id FK
    uuid vehicle_id FK
    uuid location_id FK
    text status
    uuid current_price_version_id FK
    text source_record_id FK
    integer version
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  vehicles {
    uuid id PK
    uuid trim_id FK
    uuid custodian_organisation_id FK
    uuid current_location_id FK
    uuid merged_into_vehicle_id FK
    integer version
  }
  organisations ||--o{ charge_rules : "organisation_id"
  organisations ||--o{ customers : "created_by_organisation_id"
  organisations ||--o{ listings : "organisation_id"
  vehicles ||--o{ listings : "vehicle_id"
  customers ||--o{ quote_acceptances : "customer_id"
  quotes ||--o{ quote_acceptances : "quote_id_organisation_id"
  terms_versions ||--o{ quote_acceptances : "terms_version_id"
  quotes ||--o{ quote_lines : "quote_id_organisation_id"
  charge_rules ||--o{ quote_lines : "source_rule_id"
  customers ||--o{ quotes : "customer_id"
  listings ||--o{ quotes : "listing_id_organisation_id"
  organisations ||--o{ quotes : "organisation_id"
  terms_versions ||--o{ quotes : "terms_version_id"
  vehicles ||--o{ quotes : "vehicle_id"
  organisations ||--o{ vehicles : "custodian_organisation_id"
  vehicles ||--o{ vehicles : "merged_into_vehicle_id"
```
</details>

## Sale reservations, current commitment, orders, handover

![sales](er/sales.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  sale_reservations {
    uuid id PK
    text reservation_number
    uuid organisation_id FK
    uuid listing_id FK
    uuid vehicle_id FK
    uuid customer_id FK
    uuid quote_id FK
    text status
    text deposit_status
    bigint deposit_required_minor
    character currency FK
    timestamptz hold_expires_at
    timestamptz deposit_paid_at
    timestamptz accepted_at
    uuid accepted_by FK
    timestamptz ended_at
    text end_reason
    text idempotency_key
    uuid created_by FK
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  vehicle_current_reservations {
    uuid vehicle_id PK
    uuid sale_reservation_id FK
    uuid sale_order_id FK
    uuid organisation_id FK
    timestamptz hold_expires_at
    timestamptz committed_since
  }
  sale_orders {
    uuid id PK
    text order_number
    uuid organisation_id FK
    uuid sale_reservation_id FK
    uuid vehicle_id FK
    uuid customer_id FK
    uuid quote_id FK
    character currency FK
    bigint agreed_total_minor
    text status
    timestamptz agreement_signed_at
    uuid agreement_media_id FK
    timestamptz completed_at
    timestamptz cancelled_at
    text cancel_reason
    uuid created_by FK
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  sale_status_events {
    uuid id PK
    uuid organisation_id FK
    uuid sale_reservation_id FK
    uuid sale_order_id FK
    text event FK
    text from_status
    text to_status
    jsonb detail
    uuid actor_user_id FK
    text actor_kind
    text request_id FK
    timestamptz occurred_at
  }
  handover_records {
    uuid id PK
    uuid sale_order_id FK
    uuid organisation_id FK
    uuid location_id FK
    timestamptz scheduled_for
    timestamptz handed_over_at
    integer odometer_value
    text odometer_unit
    uuid staff_user_id FK
    text notes
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  customers {
    uuid id PK
    text status
    uuid created_by_organisation_id FK
    integer version
  }
  listings {
    uuid id PK
    uuid organisation_id FK
    uuid vehicle_id FK
    uuid location_id FK
    text status
    uuid current_price_version_id FK
    text source_record_id FK
    integer version
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  vehicles {
    uuid id PK
    uuid trim_id FK
    uuid custodian_organisation_id FK
    uuid current_location_id FK
    uuid merged_into_vehicle_id FK
    integer version
  }
  organisations ||--o{ customers : "created_by_organisation_id"
  sale_orders ||--o{ handover_records : "sale_order_id_organisation_id"
  organisations ||--o{ listings : "organisation_id"
  vehicles ||--o{ listings : "vehicle_id"
  customers ||--o{ sale_orders : "customer_id"
  organisations ||--o{ sale_orders : "organisation_id"
  sale_reservations ||--o{ sale_orders : "sale_reservation_id_organisati"
  vehicles ||--o{ sale_orders : "vehicle_id"
  customers ||--o{ sale_reservations : "customer_id"
  listings ||--o{ sale_reservations : "listing_id_organisation_id"
  organisations ||--o{ sale_reservations : "organisation_id"
  vehicles ||--o{ sale_reservations : "vehicle_id"
  organisations ||--o{ sale_status_events : "organisation_id"
  sale_orders ||--o{ sale_status_events : "sale_order_id"
  sale_reservations ||--o{ sale_status_events : "sale_reservation_id"
  organisations ||--o{ vehicle_current_reservations : "organisation_id"
  sale_orders ||--o{ vehicle_current_reservations : "sale_order_id"
  sale_reservations ||--o{ vehicle_current_reservations : "sale_reservation_id"
  vehicles ||--o{ vehicle_current_reservations : "vehicle_id"
  organisations ||--o{ vehicles : "custodian_organisation_id"
  vehicles ||--o{ vehicles : "merged_into_vehicle_id"
```
</details>

## Test drives

![test-drives](er/test-drives.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  appointment_resources {
    uuid id PK
    uuid organisation_id FK
    uuid location_id FK
    text kind
    text name
    uuid user_id FK
    smallint capacity
    text status
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  test_drive_appointments {
    uuid id PK
    uuid organisation_id FK
    uuid location_id FK
    uuid vehicle_id FK
    uuid listing_id FK
    uuid customer_id FK
    uuid resource_id FK
    timestamptz starts_at
    timestamptz ends_at
    tstzrange slot
    text local_timezone
    text request_status
    text confirmation_status
    text availability_notice
    timestamptz cancelled_at
    text cancelled_by_kind
    text cancellation_reason
    text idempotency_key
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  customers {
    uuid id PK
    text status
    uuid created_by_organisation_id FK
    integer version
  }
  listings {
    uuid id PK
    uuid organisation_id FK
    uuid vehicle_id FK
    uuid location_id FK
    text status
    uuid current_price_version_id FK
    text source_record_id FK
    integer version
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  vehicles {
    uuid id PK
    uuid trim_id FK
    uuid custodian_organisation_id FK
    uuid current_location_id FK
    uuid merged_into_vehicle_id FK
    integer version
  }
  organisations ||--o{ appointment_resources : "organisation_id"
  organisations ||--o{ customers : "created_by_organisation_id"
  organisations ||--o{ listings : "organisation_id"
  vehicles ||--o{ listings : "vehicle_id"
  customers ||--o{ test_drive_appointments : "customer_id"
  listings ||--o{ test_drive_appointments : "listing_id_organisation_id"
  organisations ||--o{ test_drive_appointments : "organisation_id"
  appointment_resources ||--o{ test_drive_appointments : "resource_id_organisation_id"
  vehicles ||--o{ test_drive_appointments : "vehicle_id"
  organisations ||--o{ vehicles : "custodian_organisation_id"
  vehicles ||--o{ vehicles : "merged_into_vehicle_id"
```
</details>

## Rental fleet, bookings, assignments, maintenance

![rentals](er/rentals.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  rental_categories {
    uuid id PK
    uuid organisation_id FK
    text code
    text name
    smallint seats
    text transmission
    interval turnaround_buffer
    bigint daily_rate_minor
    character currency FK
    text status
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  rental_inventory_buckets {
    uuid location_id FK
    uuid category_id FK
    uuid organisation_id FK
    integer capacity_override
    timestamptz created_at
  }
  rental_assets {
    uuid id PK
    uuid organisation_id FK
    uuid vehicle_id FK
    uuid category_id FK
    uuid home_location_id FK
    text fleet_number
    text status
    timestamptz in_fleet_from
    timestamptz in_fleet_to
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  rental_quotes {
    uuid id PK
    uuid organisation_id FK
    uuid location_id FK
    uuid category_id FK
    uuid customer_id FK
    timestamptz pickup_at
    timestamptz return_at
    text local_timezone
    integer rental_days
    bigint daily_rate_minor
    bigint total_minor
    character currency FK
    timestamptz issued_at
    timestamptz expires_at
  }
  rental_bookings {
    uuid id PK
    text booking_number
    uuid organisation_id FK
    uuid customer_id FK
    uuid category_id FK
    uuid pickup_location_id FK
    uuid return_location_id FK
    uuid rental_quote_id FK
    timestamptz pickup_at
    timestamptz return_at
    text pickup_timezone
    text return_timezone
    tstzrange booked_range
    text status
    bigint total_minor
    character currency FK
    timestamptz cancelled_at
    text cancellation_reason
    text idempotency_key
    uuid created_by FK
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  rental_asset_assignments {
    uuid id PK
    uuid organisation_id FK
    uuid rental_booking_id FK
    uuid rental_asset_id FK
    tstzrange occupied
    boolean is_upgrade
    text status
    uuid assigned_by FK
    timestamptz assigned_at
    timestamptz released_at
  }
  maintenance_blocks {
    uuid id PK
    uuid organisation_id FK
    uuid rental_asset_id FK
    text kind
    timestamptz starts_at
    timestamptz ends_at
    tstzrange block_range
    text status
    text reason
    uuid created_by FK
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  customers {
    uuid id PK
    text status
    uuid created_by_organisation_id FK
    integer version
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  vehicles {
    uuid id PK
    uuid trim_id FK
    uuid custodian_organisation_id FK
    uuid current_location_id FK
    uuid merged_into_vehicle_id FK
    integer version
  }
  organisations ||--o{ customers : "created_by_organisation_id"
  organisations ||--o{ maintenance_blocks : "organisation_id"
  rental_assets ||--o{ maintenance_blocks : "rental_asset_id_organisation_i"
  organisations ||--o{ rental_asset_assignments : "organisation_id"
  rental_assets ||--o{ rental_asset_assignments : "rental_asset_id_organisation_i"
  rental_bookings ||--o{ rental_asset_assignments : "rental_booking_id_organisation"
  rental_categories ||--o{ rental_assets : "category_id_organisation_id"
  rental_inventory_buckets ||--o{ rental_assets : "home_location_id_category_id"
  organisations ||--o{ rental_assets : "organisation_id"
  vehicles ||--o{ rental_assets : "vehicle_id"
  rental_categories ||--o{ rental_bookings : "category_id_organisation_id"
  customers ||--o{ rental_bookings : "customer_id"
  organisations ||--o{ rental_bookings : "organisation_id"
  rental_inventory_buckets ||--o{ rental_bookings : "pickup_location_id_category_id"
  rental_quotes ||--o{ rental_bookings : "rental_quote_id_organisation_i"
  organisations ||--o{ rental_categories : "organisation_id"
  rental_categories ||--o{ rental_inventory_buckets : "category_id_organisation_id"
  organisations ||--o{ rental_inventory_buckets : "organisation_id"
  rental_categories ||--o{ rental_quotes : "category_id_organisation_id"
  customers ||--o{ rental_quotes : "customer_id"
  organisations ||--o{ rental_quotes : "organisation_id"
  organisations ||--o{ vehicles : "custodian_organisation_id"
  vehicles ||--o{ vehicles : "merged_into_vehicle_id"
```
</details>

## Payments, events, transactions, refunds, reconciliation

![payments](er/payments.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  payment_intents {
    uuid id PK
    uuid organisation_id FK
    text provider
    text provider_intent_ref
    text purpose
    uuid sale_reservation_id FK
    uuid sale_order_id FK
    uuid rental_booking_id FK
    uuid customer_id FK
    bigint amount_minor
    character currency FK
    text status
    timestamptz last_provider_event_at
    text failure_code
    text idempotency_key
    character request_sha256
    uuid created_by FK
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  payment_events {
    uuid id PK
    text provider
    text provider_event_id FK
    text event_type
    timestamptz provider_created_at
    timestamptz received_at
    boolean signature_verified
    uuid organisation_id FK
    uuid payment_intent_id FK
    uuid refund_id FK
    jsonb payload
    character payload_sha256
    text processing_status
    text processing_note
    timestamptz processed_at
  }
  payment_transactions {
    uuid id PK
    uuid organisation_id FK
    uuid payment_intent_id FK
    text kind
    bigint amount_minor
    character currency FK
    text provider
    text provider_transaction_ref
    uuid refund_id FK
    uuid source_event_id FK
    timestamptz occurred_at
    timestamptz recorded_at
  }
  refunds {
    uuid id PK
    uuid organisation_id FK
    uuid payment_intent_id FK
    uuid capture_transaction_id FK
    bigint amount_minor
    character currency FK
    text reason
    text status
    text provider
    text provider_refund_ref
    uuid reconciliation_case_id FK
    text idempotency_key
    text failure_code
    uuid requested_by FK
    timestamptz requested_at
    timestamptz completed_at
    timestamptz updated_at
    integer version
  }
  reconciliation_cases {
    uuid id PK
    text case_number
    uuid organisation_id FK
    text case_type
    text status
    text severity
    uuid payment_intent_id FK
    uuid payment_transaction_id FK
    uuid payment_event_id FK
    uuid refund_id FK
    uuid sale_reservation_id FK
    uuid rental_booking_id FK
    bigint expected_amount_minor
    bigint observed_amount_minor
    character currency FK
    text summary
    jsonb details
    text resolution
    text resolution_note
    timestamptz opened_at
    timestamptz resolved_at
    uuid resolved_by FK
    timestamptz updated_at
    integer version
  }
  customers {
    uuid id PK
    text status
    uuid created_by_organisation_id FK
    integer version
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  organisations ||--o{ customers : "created_by_organisation_id"
  organisations ||--o{ payment_events : "organisation_id"
  payment_intents ||--o{ payment_events : "payment_intent_id"
  refunds ||--o{ payment_events : "refund_fk"
  customers ||--o{ payment_intents : "customer_id"
  organisations ||--o{ payment_intents : "organisation_id"
  organisations ||--o{ payment_transactions : "organisation_id"
  payment_intents ||--o{ payment_transactions : "payment_intent_id_organisation"
  refunds ||--o{ payment_transactions : "refund_fk"
  payment_events ||--o{ payment_transactions : "source_event_id"
  organisations ||--o{ reconciliation_cases : "organisation_id"
  payment_events ||--o{ reconciliation_cases : "payment_event_id"
  payment_intents ||--o{ reconciliation_cases : "payment_intent_id"
  payment_transactions ||--o{ reconciliation_cases : "payment_transaction_id"
  refunds ||--o{ reconciliation_cases : "refund_id"
  payment_transactions ||--o{ refunds : "capture_transaction_id_organis"
  reconciliation_cases ||--o{ refunds : "case_fk"
  organisations ||--o{ refunds : "organisation_id"
  payment_intents ||--o{ refunds : "payment_intent_id_organisation"
```
</details>

## Imports & source provenance

![imports](er/imports.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  import_jobs {
    uuid id PK
    uuid organisation_id FK
    text source_namespace
    text format
    text mode
    text status
    text original_filename
    text storage_bucket
    text object_key
    character file_sha256
    bigint byte_size
    jsonb options
    integer row_count
    integer valid_count
    integer warning_count
    integer invalid_count
    integer applied_count
    integer no_change_count
    integer skipped_count
    text error_summary
    integer attempts
    uuid uploaded_by FK
    timestamptz uploaded_at
    timestamptz validated_at
    uuid approved_by FK
    timestamptz approved_at
    timestamptz applied_at
    timestamptz updated_at
    integer version
  }
  import_rows {
    uuid id PK
    uuid import_job_id FK
    uuid organisation_id FK
    integer row_number
    text source_record_id FK
    jsonb raw
    jsonb normalized
    character payload_sha256
    text status
    jsonb findings
    text planned_action
    text match_method
    uuid matched_vehicle_id FK
    uuid matched_listing_id FK
    jsonb result
    timestamptz applied_at
  }
  source_record_mappings {
    uuid id PK
    uuid organisation_id FK
    text source_namespace
    text source_record_id FK
    uuid vehicle_id FK
    uuid listing_id FK
    timestamptz last_source_updated_at
    character last_payload_sha256
    uuid last_import_job_id FK
    timestamptz last_seen_at
    timestamptz created_at
    timestamptz updated_at
    integer version
  }
  listings {
    uuid id PK
    uuid organisation_id FK
    uuid vehicle_id FK
    uuid location_id FK
    text status
    uuid current_price_version_id FK
    text source_record_id FK
    integer version
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  vehicles {
    uuid id PK
    uuid trim_id FK
    uuid custodian_organisation_id FK
    uuid current_location_id FK
    uuid merged_into_vehicle_id FK
    integer version
  }
  organisations ||--o{ import_jobs : "organisation_id"
  import_jobs ||--o{ import_rows : "import_job_id_organisation_id"
  listings ||--o{ import_rows : "matched_listing_id"
  vehicles ||--o{ import_rows : "matched_vehicle_id"
  organisations ||--o{ listings : "organisation_id"
  vehicles ||--o{ listings : "vehicle_id"
  import_jobs ||--o{ source_record_mappings : "last_import_job_id"
  listings ||--o{ source_record_mappings : "listing_id"
  organisations ||--o{ source_record_mappings : "organisation_id"
  vehicles ||--o{ source_record_mappings : "vehicle_id"
  organisations ||--o{ vehicles : "custodian_organisation_id"
  vehicles ||--o{ vehicles : "merged_into_vehicle_id"
```
</details>

## Outbox, audit, idempotency, operations

![operations](er/operations.svg)

<details><summary>Mermaid source</summary>

```mermaid
erDiagram
  outbox_events {
    uuid id PK
    uuid organisation_id FK
    text aggregate_type
    uuid aggregate_id FK
    text event_type
    jsonb payload
    text status
    integer attempts
    integer max_attempts
    timestamptz available_at
    text last_error
    text request_id FK
    timestamptz created_at
    timestamptz published_at
  }
  audit_events {
    bigint id PK
    timestamptz occurred_at
    text request_id FK
    uuid actor_user_id FK
    text actor_kind
    uuid actor_organisation_id FK
    uuid organisation_id FK
    text action
    text target_type
    text target_id FK
    jsonb changes
    jsonb metadata
  }
  idempotency_keys {
    uuid id PK
    text scope
    text key
    text method
    text path
    character request_sha256
    integer response_status
    jsonb response_body
    timestamptz created_at
    timestamptz completed_at
    timestamptz expires_at
  }
  worker_heartbeats {
    text worker_name PK
    timestamptz last_beat_at
    jsonb details
  }
  admin_saved_filters {
    uuid id PK
    uuid user_id FK
    text page
    text name
    jsonb params
    timestamptz created_at
  }
  organisations {
    uuid id PK
    text status
    integer version
  }
  organisations ||--o{ audit_events : "actor_organisation_id"
  organisations ||--o{ outbox_events : "organisation_id"
```
</details>
