# Data dictionary

Generated from the live catalog at schema head `r0014` by `backend/scripts/gen_docs.py` — do not edit by hand.

Conventions: `uuid` keys from `uuid_v7()`; instants are `timestamp with time zone`; money is `bigint` minor units with an explicit `char(3)` currency; status columns are `text` + CHECK; `version` is the optimistic-concurrency counter bumped by trigger; NULL means *unknown*, never zero/false.

## Contents

- **Tenancy & identity**: [`currencies`](#currencies), [`organisations`](#organisations), [`app_users`](#app-users), [`organisation_memberships`](#organisation-memberships), [`locations`](#locations)
- **Catalogue & vehicles**: [`vehicle_makes`](#vehicle-makes), [`vehicle_models`](#vehicle-models), [`vehicle_trims`](#vehicle-trims), [`vehicle_specification_versions`](#vehicle-specification-versions), [`vehicles`](#vehicles), [`vehicle_identifiers`](#vehicle-identifiers), [`vehicle_attribute_assertions`](#vehicle-attribute-assertions), [`vehicle_features`](#vehicle-features), [`vehicle_media`](#vehicle-media), [`vehicle_merge_proposals`](#vehicle-merge-proposals)
- **Listings**: [`listings`](#listings), [`listing_price_versions`](#listing-price-versions), [`listing_status_events`](#listing-status-events)
- **Customers**: [`customers`](#customers), [`customer_relationships`](#customer-relationships), [`customer_addresses`](#customer-addresses), [`saved_vehicles`](#saved-vehicles), [`saved_searches`](#saved-searches)
- **Quotes**: [`terms_versions`](#terms-versions), [`charge_rules`](#charge-rules), [`quotes`](#quotes), [`quote_lines`](#quote-lines), [`quote_acceptances`](#quote-acceptances)
- **Sales**: [`sale_reservations`](#sale-reservations), [`vehicle_current_reservations`](#vehicle-current-reservations), [`sale_orders`](#sale-orders), [`sale_status_events`](#sale-status-events), [`handover_records`](#handover-records)
- **Test drives**: [`appointment_resources`](#appointment-resources), [`test_drive_appointments`](#test-drive-appointments)
- **Rentals**: [`rental_categories`](#rental-categories), [`rental_inventory_buckets`](#rental-inventory-buckets), [`rental_assets`](#rental-assets), [`rental_quotes`](#rental-quotes), [`rental_bookings`](#rental-bookings), [`rental_asset_assignments`](#rental-asset-assignments), [`maintenance_blocks`](#maintenance-blocks)
- **Payments**: [`payment_intents`](#payment-intents), [`payment_events`](#payment-events), [`payment_transactions`](#payment-transactions), [`refunds`](#refunds), [`reconciliation_cases`](#reconciliation-cases)
- **Imports**: [`import_jobs`](#import-jobs), [`import_rows`](#import-rows), [`source_record_mappings`](#source-record-mappings)
- **Operations**: [`outbox_events`](#outbox-events), [`audit_events`](#audit-events), [`idempotency_keys`](#idempotency-keys), [`worker_heartbeats`](#worker-heartbeats), [`admin_saved_filters`](#admin-saved-filters)


---

## Tenancy & identity

### currencies

ISO 4217 currencies accepted by the platform; minor_unit defines how *_minor integer amounts are scaled.

*RLS:* not enabled (reference / platform table)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `code` | character(3) |  |  |  |
| `minor_unit` | smallint |  |  |  |
| `name` | text |  |  |  |

<details><summary>Constraints</summary>

- **CHECK** `currencies_code_check`: `CHECK ((code ~ '^[A-Z]{3}$'::text))`
- **CHECK** `currencies_minor_unit_check`: `CHECK (((minor_unit >= 0) AND (minor_unit <= 4)))`
- **PK** `currencies_pkey`: `PRIMARY KEY (code)`

</details>

### organisations

Tenants: the platform operator, fictional dealers and rental suppliers. Archived, never deleted.

*RLS:* not enabled (reference / platform table) · *Archival:* archive (status=archived) · *Deletion:* never deleted · *Retention:* life of platform

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `kind` | text |  |  |  |
| `legal_name` | text |  |  |  |
| `display_name` | text |  |  |  |
| `slug` | text |  |  |  |
| `status` | text |  | `'active'::text` |  |
| `default_currency` | character(3) |  |  |  |
| `default_timezone` | text |  |  |  |
| `listing_freshness_warn_after` | interval |  | `'3 days'::interval` |  |
| `listing_freshness_suspend_after` | interval | yes |  |  |
| `listing_freshness_action` | text |  | `'warn'::text` | What happens when a source-fed listing stops being refreshed: warn only, or suspend after listing_freshness_suspend_after. Never fabricates availability. |
| `sale_hold_duration` | interval |  | `'00:30:00'::interval` | Length of a temporary sale hold before deposit/dealer acceptance. |
| `deposit_hold_extension` | interval |  | `'72:00:00'::interval` | How far a confirmed deposit extends an active hold (measured from deposit confirmation). |
| `is_synthetic` | boolean |  | `true` |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |
| `archived_at` | timestamp with time zone | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `organisations_check`: `CHECK (((listing_freshness_action = 'warn'::text) OR (listing_freshness_suspend_after IS NOT NULL)))`
- **CHECK** `organisations_check1`: `CHECK (((status = 'archived'::text) = (archived_at IS NOT NULL)))`
- **CHECK** `organisations_default_timezone_check`: `CHECK (is_valid_iana_timezone(default_timezone))`
- **CHECK** `organisations_deposit_hold_extension_check`: `CHECK (((deposit_hold_extension >= '00:00:00'::interval) AND (deposit_hold_extension <= '14 days'::interval)))`
- **CHECK** `organisations_display_name_check`: `CHECK ((length(btrim(display_name)) > 0))`
- **CHECK** `organisations_kind_check`: `CHECK ((kind = ANY (ARRAY['platform'::text, 'dealer'::text, 'rental_supplier'::text, 'marketplace_partner'::text])))`
- **CHECK** `organisations_legal_name_check`: `CHECK ((length(btrim(legal_name)) > 0))`
- **CHECK** `organisations_listing_freshness_action_check`: `CHECK ((listing_freshness_action = ANY (ARRAY['warn'::text, 'suspend'::text])))`
- **CHECK** `organisations_listing_freshness_suspend_after_check`: `CHECK (((listing_freshness_suspend_after IS NULL) OR (listing_freshness_suspend_after > '00:00:00'::interval)))`
- **CHECK** `organisations_listing_freshness_warn_after_check`: `CHECK ((listing_freshness_warn_after > '00:00:00'::interval))`
- **CHECK** `organisations_sale_hold_duration_check`: `CHECK (((sale_hold_duration > '00:00:00'::interval) AND (sale_hold_duration <= '7 days'::interval)))`
- **CHECK** `organisations_slug_check`: `CHECK ((slug ~ '^[a-z0-9][a-z0-9-]{1,62}$'::text))`
- **CHECK** `organisations_status_check`: `CHECK ((status = ANY (ARRAY['active'::text, 'suspended'::text, 'archived'::text])))`
- **FK** `organisations_default_currency_fkey`: `FOREIGN KEY (default_currency) REFERENCES currencies(code)`
- **PK** `organisations_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `organisations_slug_key`: `UNIQUE (slug)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `organisations_no_delete` → `trg_forbid_delete()`
- trigger `organisations_touch` → `trg_touch_row()`

</details>

### app_users

Authenticated principals. Credentials are held by the identity provider, never here.

*RLS:* enabled · *Archival:* disable (status=disabled) · *Deletion:* never deleted (audit actor) · *Retention:* life of platform

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `email` | citext |  |  |  |
| `display_name` | text |  |  |  |
| `kind` | text |  |  |  |
| `customer_id` | uuid | yes |  |  |
| `status` | text |  | `'active'::text` |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `app_users_check`: `CHECK (((kind = 'customer'::text) = (customer_id IS NOT NULL)))`
- **CHECK** `app_users_email_check`: `CHECK ((email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'::citext))`
- **CHECK** `app_users_kind_check`: `CHECK ((kind = ANY (ARRAY['staff'::text, 'customer'::text, 'service'::text])))`
- **CHECK** `app_users_status_check`: `CHECK ((status = ANY (ARRAY['active'::text, 'disabled'::text])))`
- **FK** `app_users_customer_fk`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **PK** `app_users_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `app_users_email_key`: `UNIQUE (email)`

</details>

<details><summary>Indexes</summary>

- `UNIQUE INDEX app_users_customer_uq ON app_users USING btree (customer_id) WHERE (customer_id IS NOT NULL)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `app_users_no_delete` → `trg_forbid_delete()`
- trigger `app_users_touch` → `trg_touch_row()`
- policy `app_users_read` (SELECT): USING `(app_is_platform() OR (id = app_user_id()) OR (EXISTS ( SELECT 1
   FROM organisation_memberships m
  WHERE (m.user_id = app_users.id))))`
- policy `app_users_update` (UPDATE): USING `(app_is_platform() OR (id = app_user_id()))`
- policy `app_users_write` (INSERT): USING `—`

</details>

### organisation_memberships

Grants a user a role within one organisation. Revoked rather than deleted.

*RLS:* enabled · *Archival:* revoke (status, valid_to) · *Deletion:* never deleted · *Retention:* life of platform

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `user_id` | uuid |  |  |  |
| `role` | text |  |  |  |
| `status` | text |  | `'active'::text` |  |
| `valid_from` | timestamp with time zone |  | `now()` |  |
| `valid_to` | timestamp with time zone | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `organisation_memberships_check`: `CHECK (((valid_to IS NULL) OR (valid_to > valid_from)))`
- **CHECK** `organisation_memberships_role_check`: `CHECK ((role = ANY (ARRAY['platform_admin'::text, 'dealer_admin'::text, 'dealer_staff'::text, 'rental_admin'::text, 'rental_agent'::text, 'finance'::text, 'auditor'::text])))`
- **CHECK** `organisation_memberships_status_check`: `CHECK ((status = ANY (ARRAY['active'::text, 'revoked'::text])))`
- **FK** `organisation_memberships_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `organisation_memberships_user_id_fkey`: `FOREIGN KEY (user_id) REFERENCES app_users(id)`
- **PK** `organisation_memberships_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `organisation_memberships_organisation_id_user_id_role_key`: `UNIQUE (organisation_id, user_id, role)`

</details>

<details><summary>Indexes</summary>

- `INDEX organisation_memberships_user_idx ON organisation_memberships USING btree (user_id) WHERE (status = 'active'::text)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `organisation_memberships_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### locations

Physical sites. timezone (IANA) drives local scheduling for test drives and rentals; geog drives radius search.

*RLS:* enabled · *Archival:* close (status=closed) · *Deletion:* never deleted · *Retention:* life of platform

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `code` | text |  |  |  |
| `name` | text |  |  |  |
| `kind` | text |  |  |  |
| `address_line1` | text |  |  |  |
| `address_line2` | text | yes |  |  |
| `city` | text |  |  |  |
| `region` | text | yes |  |  |
| `postal_code` | text | yes |  |  |
| `country_code` | character(2) |  |  |  |
| `geog` | geography(Point,4326) |  |  | WGS84 point; ST_DWithin on geography uses metres. |
| `timezone` | text |  |  |  |
| `status` | text |  | `'active'::text` |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `locations_code_check`: `CHECK ((code ~ '^[A-Z0-9][A-Z0-9_-]{0,31}$'::text))`
- **CHECK** `locations_country_code_check`: `CHECK ((country_code ~ '^[A-Z]{2}$'::text))`
- **CHECK** `locations_kind_check`: `CHECK ((kind = ANY (ARRAY['dealership'::text, 'rental_branch'::text, 'storage'::text, 'inspection_centre'::text])))`
- **CHECK** `locations_status_check`: `CHECK ((status = ANY (ARRAY['active'::text, 'closed'::text])))`
- **CHECK** `locations_timezone_check`: `CHECK (is_valid_iana_timezone(timezone))`
- **FK** `locations_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **PK** `locations_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `locations_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `locations_organisation_id_code_key`: `UNIQUE (organisation_id, code)`

</details>

<details><summary>Indexes</summary>

- `INDEX locations_geog_gix ON locations USING gist (geog)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `locations_no_delete` → `trg_forbid_delete()`
- trigger `locations_touch` → `trg_touch_row()`
- policy `locations_public_read` (SELECT): USING `(status = 'active'::text)`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>


---

## Catalogue & vehicles

### vehicle_makes

Manufacturer brands (catalogue reference data).

*RLS:* not enabled (reference / platform table)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `name` | citext |  |  |  |
| `slug` | text |  |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicle_makes_slug_check`: `CHECK ((slug ~ '^[a-z0-9][a-z0-9-]*$'::text))`
- **PK** `vehicle_makes_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `vehicle_makes_name_key`: `UNIQUE (name)`
- **UNIQUE** `vehicle_makes_slug_key`: `UNIQUE (slug)`

</details>

### vehicle_models

Model lines of a make (e.g. Tucson).

*RLS:* not enabled (reference / platform table)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `make_id` | uuid |  |  |  |
| `name` | text |  |  |  |
| `slug` | text |  |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicle_models_slug_check`: `CHECK ((slug ~ '^[a-z0-9][a-z0-9-]*$'::text))`
- **FK** `vehicle_models_make_id_fkey`: `FOREIGN KEY (make_id) REFERENCES vehicle_makes(id)`
- **PK** `vehicle_models_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `vehicle_models_make_id_slug_key`: `UNIQUE (make_id, slug)`

</details>

### vehicle_trims

A model-year trim (e.g. 2026 Tucson SEL). NULL attributes are unknown, not "none".

*RLS:* not enabled (reference / platform table)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `model_id` | uuid |  |  |  |
| `model_year` | smallint |  |  |  |
| `name` | text |  |  |  |
| `body_style` | text | yes |  |  |
| `drivetrain` | text | yes |  |  |
| `fuel_type` | text | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicle_trims_body_style_check`: `CHECK ((body_style = ANY (ARRAY['sedan'::text, 'suv'::text, 'crossover'::text, 'hatchback'::text, 'wagon'::text, 'coupe'::text, 'convertible'::text, 'pickup'::text, 'van'::text, 'other'::text])))`
- **CHECK** `vehicle_trims_drivetrain_check`: `CHECK ((drivetrain = ANY (ARRAY['fwd'::text, 'rwd'::text, 'awd'::text, '4wd'::text])))`
- **CHECK** `vehicle_trims_fuel_type_check`: `CHECK ((fuel_type = ANY (ARRAY['petrol'::text, 'diesel'::text, 'hybrid'::text, 'plug_in_hybrid'::text, 'electric'::text, 'hydrogen'::text, 'other'::text])))`
- **CHECK** `vehicle_trims_model_year_check`: `CHECK (((model_year >= 1950) AND (model_year <= 2100)))`
- **FK** `vehicle_trims_model_id_fkey`: `FOREIGN KEY (model_id) REFERENCES vehicle_models(id)`
- **PK** `vehicle_trims_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `vehicle_trims_model_id_model_year_name_key`: `UNIQUE (model_id, model_year, name)`

</details>

### vehicle_specification_versions

Manufacturer/catalogue specification for a trim, versioned by effective date per source. New facts create a new version; history is never rewritten.

*RLS:* not enabled (reference / platform table) · *Archival:* close (effective_to) / supersede · *Deletion:* append-only · *Retention:* permanent reference

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `trim_id` | uuid |  |  |  |
| `source` | text |  |  |  |
| `source_reference` | text | yes |  |  |
| `effective_from` | date |  |  |  |
| `effective_to` | date | yes |  |  |
| `verification_status` | text |  | `'unverified'::text` |  |
| `msrp_minor` | bigint | yes |  |  |
| `msrp_currency` | character(3) | yes |  |  |
| `doors` | smallint | yes |  |  |
| `seats` | smallint | yes |  |  |
| `engine_displacement_cc` | integer | yes |  |  |
| `battery_capacity_kwh` | numeric(6,2) | yes |  |  |
| `power_kw` | numeric(7,2) | yes |  |  |
| `electric_range_km` | integer | yes |  |  |
| `combined_l_per_100km` | numeric(5,2) | yes |  |  |
| `attributes` | jsonb |  | `'{}'::jsonb` | JSONB for long-tail spec attributes that vary by source (justified: heterogeneous, read-mostly, never joined on). Core specs are typed columns. |
| `recorded_at` | timestamp with time zone |  | `now()` |  |
| `recorded_by` | uuid | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicle_specification_versions_attributes_check`: `CHECK ((jsonb_typeof(attributes) = 'object'::text))`
- **CHECK** `vehicle_specification_versions_battery_capacity_kwh_check`: `CHECK ((battery_capacity_kwh > (0)::numeric))`
- **CHECK** `vehicle_specification_versions_check`: `CHECK (((effective_to IS NULL) OR (effective_to > effective_from)))`
- **CHECK** `vehicle_specification_versions_check1`: `CHECK (((msrp_minor IS NULL) = (msrp_currency IS NULL)))`
- **CHECK** `vehicle_specification_versions_combined_l_per_100km_check`: `CHECK ((combined_l_per_100km > (0)::numeric))`
- **CHECK** `vehicle_specification_versions_doors_check`: `CHECK (((doors >= 1) AND (doors <= 8)))`
- **CHECK** `vehicle_specification_versions_electric_range_km_check`: `CHECK ((electric_range_km > 0))`
- **CHECK** `vehicle_specification_versions_engine_displacement_cc_check`: `CHECK ((engine_displacement_cc > 0))`
- **CHECK** `vehicle_specification_versions_msrp_minor_check`: `CHECK (((msrp_minor IS NULL) OR (msrp_minor > 0)))`
- **CHECK** `vehicle_specification_versions_power_kw_check`: `CHECK ((power_kw > (0)::numeric))`
- **CHECK** `vehicle_specification_versions_seats_check`: `CHECK (((seats >= 1) AND (seats <= 15)))`
- **CHECK** `vehicle_specification_versions_source_check`: `CHECK ((source ~ '^[a-z][a-z0-9_.:-]{1,63}$'::text))`
- **CHECK** `vehicle_specification_versions_verification_status_check`: `CHECK ((verification_status = ANY (ARRAY['unverified'::text, 'verified'::text, 'superseded'::text, 'disputed'::text])))`
- **FK** `vehicle_specification_versions_msrp_currency_fkey`: `FOREIGN KEY (msrp_currency) REFERENCES currencies(code)`
- **FK** `vehicle_specification_versions_recorded_by_fkey`: `FOREIGN KEY (recorded_by) REFERENCES app_users(id)`
- **FK** `vehicle_specification_versions_trim_id_fkey`: `FOREIGN KEY (trim_id) REFERENCES vehicle_trims(id)`
- **PK** `vehicle_specification_versions_pkey`: `PRIMARY KEY (id)`
- **EXCLUDE** `vehicle_specification_versions_trim_id_source_daterange_excl`: `EXCLUDE USING gist (trim_id WITH =, source WITH =, daterange(effective_from, effective_to, '[)'::text) WITH &&)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `vehicle_specification_versions_append` → `trg_append_only()`

</details>

### vehicles

Exact physical vehicles. One vehicle may be offered by several listings; availability here is physical, independent of listing publication.

*RLS:* enabled · *Archival:* archive / merge (archived_at, merged_into) · *Deletion:* trigger-blocked · *Retention:* 10 years after last sale

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `trim_id` | uuid | yes |  |  |
| `custodian_organisation_id` | uuid |  |  | Organisation physically responsible for the vehicle (tenant boundary for unpublished data). |
| `current_location_id` | uuid | yes |  |  |
| `model_year` | smallint | yes |  |  |
| `exterior_colour` | text | yes |  |  |
| `interior_colour` | text | yes |  |  |
| `condition` | text |  | `'unknown'::text` |  |
| `odometer_value` | integer | yes |  | NULL = unknown. 0 = a genuinely zero reading. Always paired with odometer_unit. |
| `odometer_unit` | text | yes |  |  |
| `odometer_recorded_at` | timestamp with time zone | yes |  |  |
| `has_open_recall` | boolean | yes |  | NULL = not yet checked; false = checked, none open. |
| `keys_count` | smallint | yes |  |  |
| `availability_status` | text |  | `'available'::text` |  |
| `sold_at` | timestamp with time zone | yes |  |  |
| `merged_into_vehicle_id` | uuid | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |
| `archived_at` | timestamp with time zone | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicles_availability_status_check`: `CHECK ((availability_status = ANY (ARRAY['available'::text, 'in_transit'::text, 'unavailable'::text, 'sold'::text, 'written_off'::text])))`
- **CHECK** `vehicles_check`: `CHECK (((odometer_value IS NULL) = (odometer_unit IS NULL)))`
- **CHECK** `vehicles_check1`: `CHECK (((odometer_value IS NULL) OR (odometer_recorded_at IS NOT NULL)))`
- **CHECK** `vehicles_check2`: `CHECK (((availability_status = 'sold'::text) = (sold_at IS NOT NULL)))`
- **CHECK** `vehicles_check3`: `CHECK (((merged_into_vehicle_id IS NULL) OR ((merged_into_vehicle_id <> id) AND (archived_at IS NOT NULL))))`
- **CHECK** `vehicles_condition_check`: `CHECK ((condition = ANY (ARRAY['new'::text, 'used'::text, 'certified_pre_owned'::text, 'unknown'::text])))`
- **CHECK** `vehicles_keys_count_check`: `CHECK ((keys_count >= 0))`
- **CHECK** `vehicles_model_year_check`: `CHECK (((model_year >= 1950) AND (model_year <= 2100)))`
- **CHECK** `vehicles_odometer_unit_check`: `CHECK ((odometer_unit = ANY (ARRAY['km'::text, 'mi'::text])))`
- **CHECK** `vehicles_odometer_value_check`: `CHECK ((odometer_value >= 0))`
- **FK** `vehicles_current_location_id_custodian_organisation_id_fkey`: `FOREIGN KEY (current_location_id, custodian_organisation_id) REFERENCES locations(id, organisation_id)`
- **FK** `vehicles_custodian_organisation_id_fkey`: `FOREIGN KEY (custodian_organisation_id) REFERENCES organisations(id)`
- **FK** `vehicles_merged_into_vehicle_id_fkey`: `FOREIGN KEY (merged_into_vehicle_id) REFERENCES vehicles(id)`
- **FK** `vehicles_trim_id_fkey`: `FOREIGN KEY (trim_id) REFERENCES vehicle_trims(id)`
- **PK** `vehicles_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `INDEX vehicles_custodian_idx ON vehicles USING btree (custodian_organisation_id, availability_status)`
- `INDEX vehicles_trim_idx ON vehicles USING btree (trim_id)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `vehicles_availability_appointments` → `trg_vehicle_availability_appointments()`
- trigger `vehicles_no_delete` → `trg_forbid_delete()`
- trigger `vehicles_touch` → `trg_touch_row()`
- policy `vehicles_custodian_rw` (ALL): USING `app_can_access_org(custodian_organisation_id)`
- policy `vehicles_listed_read` (SELECT): USING `(EXISTS ( SELECT 1
   FROM listings l
  WHERE (l.vehicle_id = vehicles.id)))`

</details>

### vehicle_identifiers

Namespaced identifiers (vin, registration:<region>, stock:<dealer>, source:<system>). Uniqueness is per namespace (+issuer), never by descriptive attributes.

*RLS:* enabled · *Archival:* retire (retired_at + reason) · *Deletion:* trigger-blocked · *Retention:* with vehicle

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `vehicle_id` | uuid |  |  |  |
| `namespace` | text |  |  |  |
| `value` | text |  |  |  |
| `value_normalized` | text | yes | GENERATED: `upper(regexp_replace(value, '[\s-]'::text, ''::text, 'g'::text))` |  |
| `issuing_organisation_id` | uuid | yes |  |  |
| `is_synthetic` | boolean |  | `false` | True for generated demo identifiers. All demo VINs are synthetic and do not identify real vehicles. |
| `verification_status` | text |  | `'unverified'::text` |  |
| `source` | text |  |  |  |
| `recorded_at` | timestamp with time zone |  | `now()` |  |
| `retired_at` | timestamp with time zone | yes |  |  |
| `retired_reason` | text | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicle_identifiers_check`: `CHECK (((namespace <> 'vin'::text) OR (value_normalized ~ '^[A-HJ-NPR-Z0-9]{17}$'::text)))`
- **CHECK** `vehicle_identifiers_check1`: `CHECK (((retired_at IS NULL) = (retired_reason IS NULL)))`
- **CHECK** `vehicle_identifiers_namespace_check`: `CHECK ((namespace ~ '^[a-z][a-z0-9_.:-]{1,63}$'::text))`
- **CHECK** `vehicle_identifiers_value_check`: `CHECK ((length(btrim(value)) > 0))`
- **CHECK** `vehicle_identifiers_verification_status_check`: `CHECK ((verification_status = ANY (ARRAY['unverified'::text, 'verified'::text, 'disputed'::text])))`
- **FK** `vehicle_identifiers_issuing_organisation_id_fkey`: `FOREIGN KEY (issuing_organisation_id) REFERENCES organisations(id)`
- **FK** `vehicle_identifiers_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `vehicle_identifiers_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `UNIQUE INDEX vehicle_identifiers_active_uq ON vehicle_identifiers USING btree (namespace, issuing_organisation_id, value_normalized) NULLS NOT DISTINCT WHERE (retired_at IS NULL)`
- `INDEX vehicle_identifiers_lookup_idx ON vehicle_identifiers USING btree (namespace, value_normalized) WHERE (retired_at IS NULL)`
- `INDEX vehicle_identifiers_vehicle_idx ON vehicle_identifiers USING btree (vehicle_id)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `vehicle_identifiers_no_delete` → `trg_forbid_delete()`
- policy `vehicle_identifiers_read` (SELECT): USING `((EXISTS ( SELECT 1
   FROM vehicles v
  WHERE (v.id = vehicle_identifiers.vehicle_id))) AND ((issuing_organisation_id IS NULL) OR app_can_access_org(issuing_or`
- policy `vehicle_identifiers_update` (UPDATE): USING `(EXISTS ( SELECT 1
   FROM vehicles v
  WHERE ((v.id = vehicle_identifiers.vehicle_id) AND app_can_access_org(v.custodian_organisation_id))))`
- policy `vehicle_identifiers_write` (INSERT): USING `—`

</details>

### vehicle_attribute_assertions

Who said what about a vehicle, when, and whether it was verified. value is JSONB because attributes are heterogeneous (number, text, list).

*RLS:* enabled · *Archival:* supersede (verification_status) · *Deletion:* trigger-blocked · *Retention:* with vehicle

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `vehicle_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `attribute` | text |  |  |  |
| `assertion_type` | text |  |  |  |
| `value` | jsonb |  |  |  |
| `unit` | text | yes |  |  |
| `source` | text |  |  |  |
| `source_reference` | text | yes |  |  |
| `effective_at` | timestamp with time zone |  |  |  |
| `verification_status` | text |  | `'unverified'::text` |  |
| `supersedes_id` | uuid | yes |  |  |
| `recorded_by` | uuid | yes |  |  |
| `recorded_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicle_attribute_assertions_assertion_type_check`: `CHECK ((assertion_type = ANY (ARRAY['manufacturer'::text, 'seller_claim'::text, 'inspection_finding'::text, 'import_source'::text, 'registry'::text])))`
- **CHECK** `vehicle_attribute_assertions_attribute_check`: `CHECK ((attribute ~ '^[a-z][a-z0-9_]{1,63}$'::text))`
- **CHECK** `vehicle_attribute_assertions_verification_status_check`: `CHECK ((verification_status = ANY (ARRAY['unverified'::text, 'verified'::text, 'disputed'::text, 'superseded'::text])))`
- **FK** `vehicle_attribute_assertions_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `vehicle_attribute_assertions_recorded_by_fkey`: `FOREIGN KEY (recorded_by) REFERENCES app_users(id)`
- **FK** `vehicle_attribute_assertions_supersedes_id_fkey`: `FOREIGN KEY (supersedes_id) REFERENCES vehicle_attribute_assertions(id)`
- **FK** `vehicle_attribute_assertions_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `vehicle_attribute_assertions_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `INDEX vehicle_attribute_assertions_vehicle_idx ON vehicle_attribute_assertions USING btree (vehicle_id, attribute, effective_at DESC)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `vehicle_attribute_assertions_no_delete` → `trg_forbid_delete()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### vehicle_features

Equipment/features per vehicle with provenance.

*RLS:* enabled

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `vehicle_id` | uuid |  |  |  |
| `feature_code` | text |  |  |  |
| `label` | text |  |  |  |
| `assertion_type` | text |  |  |  |
| `source` | text |  |  |  |
| `verification_status` | text |  | `'unverified'::text` |  |
| `recorded_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicle_features_assertion_type_check`: `CHECK ((assertion_type = ANY (ARRAY['manufacturer'::text, 'seller_claim'::text, 'inspection_finding'::text, 'import_source'::text])))`
- **CHECK** `vehicle_features_feature_code_check`: `CHECK ((feature_code ~ '^[a-z][a-z0-9_]{1,63}$'::text))`
- **CHECK** `vehicle_features_verification_status_check`: `CHECK ((verification_status = ANY (ARRAY['unverified'::text, 'verified'::text, 'disputed'::text])))`
- **FK** `vehicle_features_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `vehicle_features_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `vehicle_features_vehicle_id_feature_code_assertion_type_sou_key`: `UNIQUE (vehicle_id, feature_code, assertion_type, source)`

</details>

<details><summary>Triggers & policies</summary>

- policy `vehicle_features_read` (SELECT): USING `(EXISTS ( SELECT 1
   FROM vehicles v
  WHERE (v.id = vehicle_features.vehicle_id)))`
- policy `vehicle_features_write` (INSERT): USING `—`

</details>

### vehicle_media

Pointers to images/documents in S3-compatible object storage (bytes are not stored in PostgreSQL).

*RLS:* enabled · *Archival:* archive (archived_at); object kept · *Deletion:* no DELETE grant · *Retention:* 7 years; documents per contract

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `vehicle_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `kind` | text |  |  |  |
| `storage_bucket` | text |  |  |  |
| `object_key` | text |  |  |  |
| `content_type` | text |  |  |  |
| `byte_size` | bigint |  |  |  |
| `sha256` | character(64) |  |  |  |
| `caption` | text | yes |  |  |
| `sort_order` | integer |  | `0` |  |
| `uploaded_by` | uuid | yes |  |  |
| `uploaded_at` | timestamp with time zone |  | `now()` |  |
| `archived_at` | timestamp with time zone | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicle_media_byte_size_check`: `CHECK ((byte_size > 0))`
- **CHECK** `vehicle_media_content_type_check`: `CHECK ((content_type ~ '^[a-z]+/[a-z0-9.+-]+$'::text))`
- **CHECK** `vehicle_media_kind_check`: `CHECK ((kind = ANY (ARRAY['photo'::text, 'document'::text, 'inspection_report'::text, 'agreement'::text])))`
- **CHECK** `vehicle_media_sha256_check`: `CHECK ((sha256 ~ '^[0-9a-f]{64}$'::text))`
- **FK** `vehicle_media_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `vehicle_media_uploaded_by_fkey`: `FOREIGN KEY (uploaded_by) REFERENCES app_users(id)`
- **FK** `vehicle_media_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `vehicle_media_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `vehicle_media_storage_bucket_object_key_key`: `UNIQUE (storage_bucket, object_key)`

</details>

<details><summary>Indexes</summary>

- `INDEX vehicle_media_vehicle_idx ON vehicle_media USING btree (vehicle_id, sort_order) WHERE (archived_at IS NULL)`

</details>

<details><summary>Triggers & policies</summary>

- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### vehicle_merge_proposals

Uncertain vehicle matches awaiting human review. Records are never merged automatically on weak evidence (make/model/colour/text similarity).

*RLS:* enabled

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `primary_vehicle_id` | uuid |  |  |  |
| `duplicate_vehicle_id` | uuid |  |  |  |
| `score` | numeric(4,3) |  |  |  |
| `evidence` | jsonb |  |  |  |
| `proposed_by` | text |  |  |  |
| `status` | text |  | `'pending'::text` |  |
| `decided_by` | uuid | yes |  |  |
| `decided_at` | timestamp with time zone | yes |  |  |
| `decision_note` | text | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `vehicle_merge_proposals_check`: `CHECK ((primary_vehicle_id <> duplicate_vehicle_id))`
- **CHECK** `vehicle_merge_proposals_check1`: `CHECK (((status = 'pending'::text) = (decided_at IS NULL)))`
- **CHECK** `vehicle_merge_proposals_evidence_check`: `CHECK ((jsonb_typeof(evidence) = 'array'::text))`
- **CHECK** `vehicle_merge_proposals_score_check`: `CHECK (((score >= (0)::numeric) AND (score <= (1)::numeric)))`
- **CHECK** `vehicle_merge_proposals_status_check`: `CHECK ((status = ANY (ARRAY['pending'::text, 'accepted'::text, 'rejected'::text])))`
- **FK** `vehicle_merge_proposals_decided_by_fkey`: `FOREIGN KEY (decided_by) REFERENCES app_users(id)`
- **FK** `vehicle_merge_proposals_duplicate_vehicle_id_fkey`: `FOREIGN KEY (duplicate_vehicle_id) REFERENCES vehicles(id)`
- **FK** `vehicle_merge_proposals_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `vehicle_merge_proposals_primary_vehicle_id_fkey`: `FOREIGN KEY (primary_vehicle_id) REFERENCES vehicles(id)`
- **PK** `vehicle_merge_proposals_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `UNIQUE INDEX vehicle_merge_proposals_pending_uq ON vehicle_merge_proposals USING btree (LEAST(primary_vehicle_id, duplicate_vehicle_id), GREATEST(primary_vehicle_id, duplicate_vehicle_id)) WHERE (status = 'pending'::text)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `vehicle_merge_proposals_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>


---

## Listings

### listings

A seller's offer of a physical vehicle on a channel. Status changes are recorded automatically in listing_status_events.

*RLS:* enabled · *Archival:* withdraw / sold (terminal) · *Deletion:* trigger-blocked · *Retention:* 7 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `vehicle_id` | uuid |  |  |  |
| `location_id` | uuid |  |  |  |
| `channel` | text |  | `'marketplace'::text` |  |
| `title` | text |  |  |  |
| `description` | text | yes |  |  |
| `status` | text |  | `'draft'::text` |  |
| `status_reason` | text | yes |  |  |
| `sale_eligibility` | text |  | `'pending_review'::text` |  |
| `currency` | character(3) |  |  |  |
| `current_price_version_id` | uuid | yes |  |  |
| `deposit_required_minor` | bigint |  | `0` | Deposit payable to secure a sale hold. A deposit is a payment towards the price, never an additional charge. |
| `source_namespace` | text | yes |  |  |
| `source_record_id` | text | yes |  |  |
| `source_last_seen_at` | timestamp with time zone | yes |  |  |
| `freshness_state` | text |  | `'not_applicable'::text` | For source-fed listings: fresh/stale/expired relative to source_last_seen_at and the organisation freshness policy. Staleness never implies availability. |
| `effective_from` | timestamp with time zone | yes |  |  |
| `effective_to` | timestamp with time zone | yes |  |  |
| `published_at` | timestamp with time zone | yes |  |  |
| `withdrawn_at` | timestamp with time zone | yes |  |  |
| `sold_at` | timestamp with time zone | yes |  |  |
| `created_by` | uuid | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `listings_channel_check`: `CHECK ((channel = ANY (ARRAY['marketplace'::text, 'dealer_site'::text, 'partner_syndication'::text])))`
- **CHECK** `listings_check`: `CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to > effective_from)))`
- **CHECK** `listings_check1`: `CHECK (((source_namespace IS NULL) = (source_record_id IS NULL)))`
- **CHECK** `listings_check2`: `CHECK (((status <> 'published'::text) OR (current_price_version_id IS NOT NULL)))`
- **CHECK** `listings_check3`: `CHECK (((status <> 'published'::text) OR (published_at IS NOT NULL)))`
- **CHECK** `listings_deposit_required_minor_check`: `CHECK ((deposit_required_minor >= 0))`
- **CHECK** `listings_freshness_state_check`: `CHECK ((freshness_state = ANY (ARRAY['fresh'::text, 'stale'::text, 'expired'::text, 'not_applicable'::text])))`
- **CHECK** `listings_sale_eligibility_check`: `CHECK ((sale_eligibility = ANY (ARRAY['eligible'::text, 'not_eligible'::text, 'pending_review'::text])))`
- **CHECK** `listings_status_check`: `CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'suspended'::text, 'withdrawn'::text, 'sold'::text])))`
- **CHECK** `listings_title_check`: `CHECK ((length(btrim(title)) > 0))`
- **FK** `listings_created_by_fkey`: `FOREIGN KEY (created_by) REFERENCES app_users(id)`
- **FK** `listings_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `listings_current_price_fk`: `FOREIGN KEY (current_price_version_id, id) REFERENCES listing_price_versions(id, listing_id) DEFERRABLE INITIALLY DEFERRED`
- **FK** `listings_location_id_organisation_id_fkey`: `FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id)`
- **FK** `listings_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `listings_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `listings_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `listings_id_currency_key`: `UNIQUE (id, currency)`
- **UNIQUE** `listings_id_organisation_id_key`: `UNIQUE (id, organisation_id)`

</details>

<details><summary>Indexes</summary>

- `INDEX listings_freshness_idx ON listings USING btree (source_last_seen_at) WHERE ((status = 'published'::text) AND (source_last_seen_at IS NOT NULL))`
- `UNIQUE INDEX listings_one_open_per_vehicle_channel_uq ON listings USING btree (organisation_id, channel, vehicle_id) WHERE (status = ANY (ARRAY['draft'::text, 'published'::text, 'suspended'::text]))`
- `INDEX listings_org_status_idx ON listings USING btree (organisation_id, status, updated_at DESC, id DESC)`
- `INDEX listings_source_idx ON listings USING btree (organisation_id, source_namespace, source_record_id) WHERE (source_record_id IS NOT NULL)`
- `INDEX listings_status_location_idx ON listings USING btree (status, location_id)`
- `INDEX listings_status_updated_idx ON listings USING btree (status, updated_at DESC, id DESC)`
- `INDEX listings_title_trgm ON listings USING gin (title gin_trgm_ops)`
- `INDEX listings_updated_idx ON listings USING btree (updated_at DESC, id DESC)`
- `INDEX listings_vehicle_idx ON listings USING btree (vehicle_id)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `listings_no_delete` → `trg_forbid_delete()`
- trigger `listings_status` → `trg_listings_status()`
- trigger `listings_status_upd` → `trg_listings_status()`
- trigger `listings_touch` → `trg_touch_row()`
- policy `listings_public_read` (SELECT): USING `(status = 'published'::text)`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### listing_price_versions

Append-only asking-price history. Non-overlapping [effective_from, effective_to) per listing (exclusion constraint). Only effective_to may be set, once, to close a version.

*RLS:* enabled · *Archival:* close (effective_to once) · *Deletion:* append-only · *Retention:* 7 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `listing_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `amount_minor` | bigint |  |  |  |
| `currency` | character(3) |  |  |  |
| `effective_from` | timestamp with time zone |  | `now()` |  |
| `effective_to` | timestamp with time zone | yes |  |  |
| `reason` | text |  |  |  |
| `source` | text |  | `'manual'::text` |  |
| `created_by` | uuid | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `listing_price_versions_amount_minor_check`: `CHECK (((amount_minor > 0) AND (amount_minor < '100000000000'::bigint)))`
- **CHECK** `listing_price_versions_check`: `CHECK (((effective_to IS NULL) OR (effective_to > effective_from)))`
- **CHECK** `listing_price_versions_reason_check`: `CHECK ((reason = ANY (ARRAY['initial'::text, 'price_change'::text, 'import'::text, 'correction'::text, 'promotion'::text])))`
- **FK** `listing_price_versions_created_by_fkey`: `FOREIGN KEY (created_by) REFERENCES app_users(id)`
- **FK** `listing_price_versions_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `listing_price_versions_listing_id_currency_fkey`: `FOREIGN KEY (listing_id, currency) REFERENCES listings(id, currency)`
- **FK** `listing_price_versions_listing_id_organisation_id_fkey`: `FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id)`
- **PK** `listing_price_versions_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `listing_price_versions_id_listing_id_key`: `UNIQUE (id, listing_id)`
- **EXCLUDE** `listing_price_versions_listing_id_tstzrange_excl`: `EXCLUDE USING gist (listing_id WITH =, tstzrange(effective_from, effective_to, '[)'::text) WITH &&)`

</details>

<details><summary>Indexes</summary>

- `INDEX listing_price_versions_amount_idx ON listing_price_versions USING btree (amount_minor) WHERE (effective_to IS NULL)`
- `INDEX listing_price_versions_listing_idx ON listing_price_versions USING btree (listing_id, effective_from DESC)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `listing_price_versions_guard` → `trg_price_versions_guard()`
- policy `listing_prices_public_read` (SELECT): USING `(EXISTS ( SELECT 1
   FROM listings l
  WHERE ((l.id = listing_price_versions.listing_id) AND (l.status = 'published'::text))))`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### listing_status_events

Append-only publication history, written by trigger on every listings.status change.

*RLS:* enabled · *Archival:* — · *Deletion:* append-only · *Retention:* 7 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `listing_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `from_status` | text | yes |  |  |
| `to_status` | text |  |  |  |
| `reason` | text | yes |  |  |
| `actor_user_id` | uuid | yes |  |  |
| `actor_kind` | text |  |  |  |
| `request_id` | text | yes |  |  |
| `occurred_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **FK** `listing_status_events_actor_user_id_fkey`: `FOREIGN KEY (actor_user_id) REFERENCES app_users(id)`
- **FK** `listing_status_events_listing_id_organisation_id_fkey`: `FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id)`
- **PK** `listing_status_events_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `INDEX listing_status_events_listing_idx ON listing_status_events USING btree (listing_id, occurred_at)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `listing_status_events_append` → `trg_append_only()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>


---

## Customers

### customers

Customer records. Erasure anonymises personal fields but keeps the row so quotes, sales and payments stay referentially intact.

*RLS:* enabled · *Archival:* erase PII (status=erased) / archive · *Deletion:* trigger-blocked · *Retention:* PII erased on request; row kept for history

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `customer_type` | text |  | `'individual'::text` |  |
| `given_name` | text | yes |  |  |
| `family_name` | text | yes |  |  |
| `business_name` | text | yes |  |  |
| `display_name` | text |  |  |  |
| `email` | citext | yes |  |  |
| `phone` | text | yes |  |  |
| `marketing_consent` | boolean | yes |  | NULL = never asked; false = declined; true = consented. |
| `status` | text |  | `'active'::text` |  |
| `erased_at` | timestamp with time zone | yes |  |  |
| `is_synthetic` | boolean |  | `true` |  |
| `created_by_organisation_id` | uuid | yes |  | Organisation whose staff registered the customer (NULL = self-registered). Grants that organisation visibility. |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `customers_check`: `CHECK (((status = 'erased'::text) = (erased_at IS NOT NULL)))`
- **CHECK** `customers_check1`: `CHECK (((status <> 'erased'::text) OR ((email IS NULL) AND (phone IS NULL) AND (given_name IS NULL) AND (family_name IS NULL))))`
- **CHECK** `customers_check2`: `CHECK (((customer_type <> 'business'::text) OR (business_name IS NOT NULL) OR (status = 'erased'::text)))`
- **CHECK** `customers_customer_type_check`: `CHECK ((customer_type = ANY (ARRAY['individual'::text, 'business'::text])))`
- **CHECK** `customers_display_name_check`: `CHECK ((length(btrim(display_name)) > 0))`
- **CHECK** `customers_email_check`: `CHECK (((email IS NULL) OR (email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'::citext)))`
- **CHECK** `customers_phone_check`: `CHECK (((phone IS NULL) OR (phone ~ '^\+[1-9][0-9]{6,14}$'::text)))`
- **CHECK** `customers_status_check`: `CHECK ((status = ANY (ARRAY['active'::text, 'archived'::text, 'erased'::text])))`
- **FK** `customers_created_by_organisation_id_fkey`: `FOREIGN KEY (created_by_organisation_id) REFERENCES organisations(id)`
- **PK** `customers_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `UNIQUE INDEX customers_email_uq ON customers USING btree (email) WHERE ((email IS NOT NULL) AND (status <> 'erased'::text))`
- `INDEX customers_name_trgm ON customers USING gin (display_name gin_trgm_ops)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `customers_no_delete` → `trg_forbid_delete()`
- trigger `customers_touch` → `trg_touch_row()`
- policy `customers_insert` (INSERT): USING `—`
- policy `customers_read` (SELECT): USING `(app_is_platform() OR (id = app_customer_id()) OR (created_by_organisation_id = ANY (app_org_ids())) OR (EXISTS ( SELECT 1
   FROM customer_relationships cr
  W`
- policy `customers_update` (UPDATE): USING `(app_is_platform() OR (id = app_customer_id()) OR (created_by_organisation_id = ANY (app_org_ids())) OR (EXISTS ( SELECT 1
   FROM customer_relationships cr
  W`

</details>

### customer_relationships

Which organisations may see a customer. The tenant boundary for customer PII.

*RLS:* enabled

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `customer_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `basis` | text |  |  |  |
| `first_interaction_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `customer_relationships_basis_check`: `CHECK ((basis = ANY (ARRAY['quote'::text, 'sale_reservation'::text, 'test_drive'::text, 'rental'::text, 'import'::text, 'manual'::text])))`
- **FK** `customer_relationships_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `customer_relationships_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **PK** `customer_relationships_pkey`: `PRIMARY KEY (customer_id, organisation_id)`

</details>

<details><summary>Indexes</summary>

- `INDEX customer_relationships_org_idx ON customer_relationships USING btree (organisation_id)`

</details>

<details><summary>Triggers & policies</summary>

- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### customer_addresses

Effective-dated addresses; superseded addresses are closed (valid_to), not overwritten.

*RLS:* enabled · *Archival:* close (valid_to); blanked on erasure · *Deletion:* no DELETE grant · *Retention:* with customer

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `customer_id` | uuid |  |  |  |
| `kind` | text |  |  |  |
| `line1` | text |  |  |  |
| `line2` | text | yes |  |  |
| `city` | text |  |  |  |
| `region` | text | yes |  |  |
| `postal_code` | text | yes |  |  |
| `country_code` | character(2) |  |  |  |
| `geog` | geography(Point,4326) | yes |  |  |
| `valid_from` | timestamp with time zone |  | `now()` |  |
| `valid_to` | timestamp with time zone | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `customer_addresses_check`: `CHECK (((valid_to IS NULL) OR (valid_to > valid_from)))`
- **CHECK** `customer_addresses_country_code_check`: `CHECK ((country_code ~ '^[A-Z]{2}$'::text))`
- **CHECK** `customer_addresses_kind_check`: `CHECK ((kind = ANY (ARRAY['home'::text, 'billing'::text, 'delivery'::text])))`
- **FK** `customer_addresses_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **PK** `customer_addresses_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `INDEX customer_addresses_customer_idx ON customer_addresses USING btree (customer_id) WHERE (valid_to IS NULL)`

</details>

<details><summary>Triggers & policies</summary>

- policy `customer_addresses_rw` (ALL): USING `(EXISTS ( SELECT 1
   FROM customers c
  WHERE (c.id = customer_addresses.customer_id)))`

</details>

### saved_vehicles

Customer shortlist. Deletable by the customer (no business history).

*RLS:* enabled · *Archival:* — · *Deletion:* DELETE allowed (no history) · *Retention:* until removed

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `customer_id` | uuid |  |  |  |
| `listing_id` | uuid |  |  |  |
| `note` | text | yes |  |  |
| `saved_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **FK** `saved_vehicles_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `saved_vehicles_listing_id_fkey`: `FOREIGN KEY (listing_id) REFERENCES listings(id)`
- **PK** `saved_vehicles_pkey`: `PRIMARY KEY (customer_id, listing_id)`

</details>

<details><summary>Triggers & policies</summary>

- policy `saved_vehicles_self` (ALL): USING `(app_is_platform() OR (customer_id = app_customer_id()))`

</details>

### saved_searches



*RLS:* enabled · *Archival:* — · *Deletion:* DELETE allowed (no history) · *Retention:* until removed

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `customer_id` | uuid |  |  |  |
| `name` | text |  |  |  |
| `criteria` | jsonb |  |  | JSONB: user-defined filter set, validated by the API contract (SavedSearchCriteria). Variable by design; never joined on. |
| `notify` | boolean |  | `false` |  |
| `last_notified_at` | timestamp with time zone | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `saved_searches_criteria_check`: `CHECK ((jsonb_typeof(criteria) = 'object'::text))`
- **FK** `saved_searches_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **PK** `saved_searches_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `saved_searches_customer_id_name_key`: `UNIQUE (customer_id, name)`

</details>

<details><summary>Triggers & policies</summary>

- policy `saved_searches_self` (ALL): USING `(app_is_platform() OR (customer_id = app_customer_id()))`

</details>


---

## Quotes

### terms_versions

Versioned terms and conditions; quotes and acceptances reference the exact version shown.

*RLS:* not enabled (reference / platform table) · *Archival:* close (effective_to) · *Deletion:* trigger-blocked · *Retention:* permanent

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `code` | text |  |  |  |
| `version` | integer |  |  |  |
| `title` | text |  |  |  |
| `body_sha256` | character(64) |  |  |  |
| `effective_from` | timestamp with time zone |  |  |  |
| `effective_to` | timestamp with time zone | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `terms_versions_body_sha256_check`: `CHECK ((body_sha256 ~ '^[0-9a-f]{64}$'::text))`
- **CHECK** `terms_versions_check`: `CHECK (((effective_to IS NULL) OR (effective_to > effective_from)))`
- **CHECK** `terms_versions_code_check`: `CHECK ((code ~ '^[a-z][a-z0-9_-]+$'::text))`
- **CHECK** `terms_versions_version_check`: `CHECK ((version > 0))`
- **PK** `terms_versions_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `terms_versions_code_version_key`: `UNIQUE (code, version)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `terms_versions_no_delete` → `trg_forbid_delete()`

</details>

### charge_rules

Seller fee/tax/registration/delivery/product rules, effective-dated. Rules are closed, never edited, so historical quotes remain explainable. A missing tax or registration rule for the customer region makes a quote incomplete.

*RLS:* enabled · *Archival:* close (effective_to) · *Deletion:* trigger-blocked · *Retention:* 7 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `charge_type` | text |  |  |  |
| `code` | text |  |  |  |
| `label` | text |  |  |  |
| `calculation` | text |  |  |  |
| `amount_minor` | bigint | yes |  |  |
| `rate_bps` | integer | yes |  | Rate in basis points (1/100 of a percent), applied to the taxable subtotal. |
| `currency` | character(3) | yes |  |  |
| `region` | text | yes |  |  |
| `effective_from` | timestamp with time zone |  | `now()` |  |
| `effective_to` | timestamp with time zone | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `charge_rules_calculation_check`: `CHECK ((calculation = ANY (ARRAY['fixed'::text, 'rate_bps'::text])))`
- **CHECK** `charge_rules_charge_type_check`: `CHECK ((charge_type = ANY (ARRAY['mandatory_fee'::text, 'tax'::text, 'registration'::text, 'delivery'::text, 'optional_product'::text, 'discount'::text])))`
- **CHECK** `charge_rules_check`: `CHECK (((effective_to IS NULL) OR (effective_to > effective_from)))`
- **CHECK** `charge_rules_check1`: `CHECK (((calculation = 'fixed'::text) = ((amount_minor IS NOT NULL) AND (currency IS NOT NULL))))`
- **CHECK** `charge_rules_check2`: `CHECK (((calculation = 'rate_bps'::text) = (rate_bps IS NOT NULL)))`
- **CHECK** `charge_rules_check3`: `CHECK (((charge_type <> 'discount'::text) OR (amount_minor IS NULL) OR (amount_minor <= 0)))`
- **CHECK** `charge_rules_check4`: `CHECK (((charge_type = 'discount'::text) OR (amount_minor IS NULL) OR (amount_minor >= 0)))`
- **CHECK** `charge_rules_code_check`: `CHECK ((code ~ '^[a-z][a-z0-9_]+$'::text))`
- **CHECK** `charge_rules_rate_bps_check`: `CHECK (((rate_bps >= 0) AND (rate_bps <= 10000)))`
- **FK** `charge_rules_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `charge_rules_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **PK** `charge_rules_pkey`: `PRIMARY KEY (id)`
- **EXCLUDE** `charge_rules_organisation_id_code_coalesce_tstzrange_excl`: `EXCLUDE USING gist (organisation_id WITH =, code WITH =, COALESCE(region, '*'::text) WITH =, tstzrange(effective_from, effective_to, '[)'::text) WITH &&)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `charge_rules_no_delete` → `trg_forbid_delete()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### quotes

Immutable issued quotes. Price/listing/vehicle data is snapshotted; later catalogue or price changes never rewrite a quote. Only status may move issued -> accepted|withdrawn. Expiry is evaluated against expires_at, not stored.

*RLS:* enabled · *Archival:* withdraw (status) · *Deletion:* append-only · *Retention:* 7 years (commercial record)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `quote_number` | text |  | `((('Q-'::text ¦¦ to_char((now() AT TIME ZONE 'UTC'::text), 'YYYY'::text)) ¦¦ '-'::text) ¦¦ lpad((nextval('quote_number_seq'::regclass))::text, 7, '0'::text))` |  |
| `organisation_id` | uuid |  |  |  |
| `listing_id` | uuid |  |  |  |
| `vehicle_id` | uuid |  |  |  |
| `listing_price_version_id` | uuid |  |  |  |
| `customer_id` | uuid | yes |  |  |
| `session_reference` | text | yes |  |  |
| `customer_region` | text | yes |  |  |
| `currency` | character(3) |  |  |  |
| `vehicle_price_minor` | bigint |  |  |  |
| `mandatory_fees_minor` | bigint |  | `0` |  |
| `optional_products_minor` | bigint |  | `0` |  |
| `discounts_minor` | bigint |  | `0` |  |
| `subtotal_before_tax_registration_minor` | bigint |  |  |  |
| `taxes_minor` | bigint | yes |  |  |
| `registration_minor` | bigint | yes |  |  |
| `delivery_minor` | bigint | yes |  |  |
| `total_known_minor` | bigint |  |  |  |
| `total_minor` | bigint | yes |  |  |
| `deposit_required_minor` | bigint |  | `0` |  |
| `deposit_treatment` | text |  | `'applied_to_price'::text` |  |
| `is_complete` | boolean |  |  |  |
| `missing_charges` | text[] |  | `'{}'::text[]` | Charge types that could not be determined (e.g. {tax,registration}). Non-empty => is_complete = false and total_minor IS NULL. |
| `terms_version_id` | uuid |  |  |  |
| `snapshot` | jsonb |  |  | Point-in-time JSONB copy of the vehicle, trim, listing and seller as shown to the customer (justified: a frozen document, not a relationship). Hash in snapshot_sha256. |
| `snapshot_sha256` | character(64) |  |  |  |
| `status` | text |  | `'issued'::text` |  |
| `issued_at` | timestamp with time zone |  | `now()` |  |
| `expires_at` | timestamp with time zone |  |  |  |
| `issued_by` | uuid | yes |  |  |
| `request_id` | text | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `quotes_check`: `CHECK (((customer_id IS NOT NULL) OR (session_reference IS NOT NULL)))`
- **CHECK** `quotes_check1`: `CHECK ((expires_at > issued_at))`
- **CHECK** `quotes_check2`: `CHECK ((subtotal_before_tax_registration_minor = (((vehicle_price_minor + mandatory_fees_minor) + optional_products_minor) + discounts_minor)))`
- **CHECK** `quotes_check3`: `CHECK ((total_known_minor = (((subtotal_before_tax_registration_minor + COALESCE(taxes_minor, (0)::bigint)) + COALESCE(registration_minor, (0)::bigint)) + COALESCE(delivery_minor, (0)::bigint))))`
- **CHECK** `quotes_check4`: `CHECK ((is_complete = (cardinality(missing_charges) = 0)))`
- **CHECK** `quotes_check5`: `CHECK ((is_complete = (total_minor IS NOT NULL)))`
- **CHECK** `quotes_check6`: `CHECK (((total_minor IS NULL) OR (total_minor = total_known_minor)))`
- **CHECK** `quotes_check7`: `CHECK ((deposit_required_minor <= total_known_minor))`
- **CHECK** `quotes_check8`: `CHECK (((deposit_treatment = 'none'::text) = (deposit_required_minor = 0)))`
- **CHECK** `quotes_delivery_minor_check`: `CHECK ((delivery_minor >= 0))`
- **CHECK** `quotes_deposit_required_minor_check`: `CHECK ((deposit_required_minor >= 0))`
- **CHECK** `quotes_deposit_treatment_check`: `CHECK ((deposit_treatment = ANY (ARRAY['applied_to_price'::text, 'none'::text])))`
- **CHECK** `quotes_discounts_minor_check`: `CHECK ((discounts_minor <= 0))`
- **CHECK** `quotes_mandatory_fees_minor_check`: `CHECK ((mandatory_fees_minor >= 0))`
- **CHECK** `quotes_optional_products_minor_check`: `CHECK ((optional_products_minor >= 0))`
- **CHECK** `quotes_registration_minor_check`: `CHECK ((registration_minor >= 0))`
- **CHECK** `quotes_session_reference_check`: `CHECK (((session_reference IS NULL) OR (session_reference ~ '^[A-Za-z0-9_-]{8,128}$'::text)))`
- **CHECK** `quotes_snapshot_check`: `CHECK ((jsonb_typeof(snapshot) = 'object'::text))`
- **CHECK** `quotes_snapshot_sha256_check`: `CHECK ((snapshot_sha256 ~ '^[0-9a-f]{64}$'::text))`
- **CHECK** `quotes_status_check`: `CHECK ((status = ANY (ARRAY['issued'::text, 'accepted'::text, 'withdrawn'::text])))`
- **CHECK** `quotes_subtotal_before_tax_registration_minor_check`: `CHECK ((subtotal_before_tax_registration_minor > 0))`
- **CHECK** `quotes_taxes_minor_check`: `CHECK ((taxes_minor >= 0))`
- **CHECK** `quotes_vehicle_price_minor_check`: `CHECK ((vehicle_price_minor > 0))`
- **FK** `quotes_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `quotes_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `quotes_issued_by_fkey`: `FOREIGN KEY (issued_by) REFERENCES app_users(id)`
- **FK** `quotes_listing_id_organisation_id_fkey`: `FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id)`
- **FK** `quotes_listing_price_version_id_listing_id_fkey`: `FOREIGN KEY (listing_price_version_id, listing_id) REFERENCES listing_price_versions(id, listing_id)`
- **FK** `quotes_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `quotes_terms_version_id_fkey`: `FOREIGN KEY (terms_version_id) REFERENCES terms_versions(id)`
- **FK** `quotes_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `quotes_pkey`: `PRIMARY KEY (id)`
- **TRIGGER** `quotes_totals_check`: `TRIGGER DEFERRABLE INITIALLY DEFERRED`
- **UNIQUE** `quotes_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `quotes_quote_number_key`: `UNIQUE (quote_number)`

</details>

<details><summary>Indexes</summary>

- `INDEX quotes_customer_idx ON quotes USING btree (customer_id, issued_at DESC) WHERE (customer_id IS NOT NULL)`
- `INDEX quotes_listing_idx ON quotes USING btree (listing_id)`
- `INDEX quotes_org_issued_idx ON quotes USING btree (organisation_id, issued_at DESC)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `quotes_immutable` → `trg_quotes_immutable()`
- trigger `quotes_totals_check` → `trg_quote_totals_check()`
- policy `quotes_customer_read` (SELECT): USING `(customer_id = app_customer_id())`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### quote_lines

Itemised, append-only quote charges. amount_status distinguishes a known amount (possibly 0) from an unknown one (NULL).

*RLS:* enabled · *Archival:* — · *Deletion:* append-only · *Retention:* with quote

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `quote_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `line_no` | smallint |  |  |  |
| `line_type` | text |  |  |  |
| `code` | text |  |  |  |
| `description` | text |  |  |  |
| `amount_status` | text |  |  |  |
| `amount_minor` | bigint | yes |  |  |
| `rate_bps` | integer | yes |  |  |
| `basis_minor` | bigint | yes |  |  |
| `source_rule_id` | uuid | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `quote_lines_amount_status_check`: `CHECK ((amount_status = ANY (ARRAY['known'::text, 'unknown'::text, 'not_applicable'::text])))`
- **CHECK** `quote_lines_basis_minor_check`: `CHECK ((basis_minor >= 0))`
- **CHECK** `quote_lines_check`: `CHECK (((amount_status = 'known'::text) = (amount_minor IS NOT NULL)))`
- **CHECK** `quote_lines_check1`: `CHECK (((line_type <> 'discount'::text) OR (amount_minor IS NULL) OR (amount_minor <= 0)))`
- **CHECK** `quote_lines_check2`: `CHECK (((line_type = 'discount'::text) OR (amount_minor IS NULL) OR (amount_minor >= 0)))`
- **CHECK** `quote_lines_check3`: `CHECK (((amount_status <> 'not_applicable'::text) OR (line_type = ANY (ARRAY['tax'::text, 'registration'::text, 'delivery'::text]))))`
- **CHECK** `quote_lines_line_no_check`: `CHECK ((line_no > 0))`
- **CHECK** `quote_lines_line_type_check`: `CHECK ((line_type = ANY (ARRAY['vehicle_price'::text, 'mandatory_fee'::text, 'tax'::text, 'registration'::text, 'delivery'::text, 'optional_product'::text, 'discount'::text])))`
- **CHECK** `quote_lines_rate_bps_check`: `CHECK (((rate_bps >= 0) AND (rate_bps <= 10000)))`
- **FK** `quote_lines_quote_id_organisation_id_fkey`: `FOREIGN KEY (quote_id, organisation_id) REFERENCES quotes(id, organisation_id)`
- **FK** `quote_lines_source_rule_id_fkey`: `FOREIGN KEY (source_rule_id) REFERENCES charge_rules(id)`
- **PK** `quote_lines_pkey`: `PRIMARY KEY (id)`
- **TRIGGER** `quote_lines_totals_check`: `TRIGGER DEFERRABLE INITIALLY DEFERRED`
- **UNIQUE** `quote_lines_quote_id_line_no_key`: `UNIQUE (quote_id, line_no)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `quote_lines_append` → `trg_append_only()`
- trigger `quote_lines_totals_check` → `trg_quote_totals_check()`
- policy `quote_lines_customer_read` (SELECT): USING `(EXISTS ( SELECT 1
   FROM quotes q
  WHERE ((q.id = quote_lines.quote_id) AND (q.customer_id = app_customer_id()))))`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### quote_acceptances

Customer acceptance of an issued, complete, unexpired quote under its terms version. At most one per quote.

*RLS:* enabled · *Archival:* — · *Deletion:* append-only · *Retention:* 7 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `quote_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `customer_id` | uuid |  |  |  |
| `terms_version_id` | uuid |  |  |  |
| `accepted_at` | timestamp with time zone |  | `now()` |  |
| `acceptance_channel` | text |  |  |  |
| `request_id` | text | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `quote_acceptances_acceptance_channel_check`: `CHECK ((acceptance_channel = ANY (ARRAY['web'::text, 'in_store'::text, 'phone'::text, 'api'::text])))`
- **FK** `quote_acceptances_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `quote_acceptances_quote_id_organisation_id_fkey`: `FOREIGN KEY (quote_id, organisation_id) REFERENCES quotes(id, organisation_id)`
- **FK** `quote_acceptances_terms_version_id_fkey`: `FOREIGN KEY (terms_version_id) REFERENCES terms_versions(id)`
- **PK** `quote_acceptances_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `quote_acceptances_quote_id_key`: `UNIQUE (quote_id)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `quote_acceptances_append` → `trg_append_only()`
- trigger `quote_acceptances_check` → `trg_quote_acceptance_check()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>


---

## Sales

### sale_reservations

Reservation history for physical vehicles. Identity columns are immutable; status moves forward only. Effective expiry = status held AND hold_expires_at <= now(), even before the row is transitioned.

*RLS:* enabled · *Archival:* end (expired/cancelled/declined/released) · *Deletion:* trigger-blocked · *Retention:* 7 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `reservation_number` | text |  | `((('R-'::text ¦¦ to_char((now() AT TIME ZONE 'UTC'::text), 'YYYY'::text)) ¦¦ '-'::text) ¦¦ lpad((nextval('sale_reservation_number_seq'::regclass))::text, 7, '0'::text))` |  |
| `organisation_id` | uuid |  |  |  |
| `listing_id` | uuid |  |  |  |
| `vehicle_id` | uuid |  |  |  |
| `customer_id` | uuid |  |  |  |
| `quote_id` | uuid | yes |  |  |
| `status` | text |  | `'held'::text` |  |
| `deposit_status` | text |  | `'not_required'::text` |  |
| `deposit_required_minor` | bigint |  | `0` |  |
| `currency` | character(3) |  |  |  |
| `hold_expires_at` | timestamp with time zone |  |  | Temporary-hold deadline. Extended (never shortened) when a deposit is confirmed in time. |
| `deposit_paid_at` | timestamp with time zone | yes |  |  |
| `accepted_at` | timestamp with time zone | yes |  |  |
| `accepted_by` | uuid | yes |  |  |
| `ended_at` | timestamp with time zone | yes |  |  |
| `end_reason` | text | yes |  |  |
| `idempotency_key` | text | yes |  |  |
| `created_by` | uuid | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `sale_reservations_check`: `CHECK ((hold_expires_at > created_at))`
- **CHECK** `sale_reservations_check1`: `CHECK (((deposit_required_minor = 0) = (deposit_status = 'not_required'::text)))`
- **CHECK** `sale_reservations_check2`: `CHECK (((status = ANY (ARRAY['held'::text, 'dealer_accepted'::text, 'converted'::text])) = ((ended_at IS NULL) OR (status = 'converted'::text))))`
- **CHECK** `sale_reservations_check3`: `CHECK (((status <> ALL (ARRAY['expired'::text, 'cancelled'::text, 'declined'::text, 'released'::text])) OR (end_reason IS NOT NULL)))`
- **CHECK** `sale_reservations_check4`: `CHECK (((status <> ALL (ARRAY['dealer_accepted'::text, 'converted'::text])) OR (accepted_at IS NOT NULL)))`
- **CHECK** `sale_reservations_check5`: `CHECK (((deposit_status <> 'paid'::text) OR (deposit_paid_at IS NOT NULL)))`
- **CHECK** `sale_reservations_deposit_required_minor_check`: `CHECK ((deposit_required_minor >= 0))`
- **CHECK** `sale_reservations_deposit_status_check`: `CHECK ((deposit_status = ANY (ARRAY['not_required'::text, 'awaiting'::text, 'paid'::text, 'refund_pending'::text, 'refunded'::text])))`
- **CHECK** `sale_reservations_status_check`: `CHECK ((status = ANY (ARRAY['held'::text, 'dealer_accepted'::text, 'converted'::text, 'expired'::text, 'cancelled'::text, 'declined'::text, 'released'::text])))`
- **FK** `sale_reservations_accepted_by_fkey`: `FOREIGN KEY (accepted_by) REFERENCES app_users(id)`
- **FK** `sale_reservations_created_by_fkey`: `FOREIGN KEY (created_by) REFERENCES app_users(id)`
- **FK** `sale_reservations_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `sale_reservations_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `sale_reservations_listing_id_organisation_id_fkey`: `FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id)`
- **FK** `sale_reservations_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `sale_reservations_quote_id_organisation_id_fkey`: `FOREIGN KEY (quote_id, organisation_id) REFERENCES quotes(id, organisation_id)`
- **FK** `sale_reservations_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `sale_reservations_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `sale_reservations_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `sale_reservations_reservation_number_key`: `UNIQUE (reservation_number)`

</details>

<details><summary>Indexes</summary>

- `INDEX sale_reservations_customer_idx ON sale_reservations USING btree (customer_id, created_at DESC)`
- `INDEX sale_reservations_expiry_idx ON sale_reservations USING btree (hold_expires_at) WHERE (status = 'held'::text)`
- `UNIQUE INDEX sale_reservations_idempotency_uq ON sale_reservations USING btree (organisation_id, idempotency_key) WHERE (idempotency_key IS NOT NULL)`
- `UNIQUE INDEX sale_reservations_one_active_per_vehicle_uq ON sale_reservations USING btree (vehicle_id) WHERE (status = ANY (ARRAY['held'::text, 'dealer_accepted'::text]))`
- `INDEX sale_reservations_org_created_idx ON sale_reservations USING btree (organisation_id, created_at DESC, id DESC)`
- `INDEX sale_reservations_org_status_idx ON sale_reservations USING btree (organisation_id, status, created_at DESC)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `sale_reservations_after_insert` → `trg_sale_reservation_after_insert()`
- trigger `sale_reservations_after_update` → `trg_sale_reservation_after_update()`
- trigger `sale_reservations_before_insert` → `trg_sale_reservation_before_insert()`
- trigger `sale_reservations_before_update` → `trg_sale_reservation_before_update()`
- trigger `sale_reservations_no_delete` → `trg_forbid_delete()`
- trigger `sale_reservations_touch` → `trg_touch_row()`
- policy `sale_reservations_customer_read` (SELECT): USING `(customer_id = app_customer_id())`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### vehicle_current_reservations

At most one row per physical vehicle: the reservation (and later sale order) currently committing it. Maintained only by SECURITY DEFINER triggers; the application role has SELECT only.

*RLS:* enabled · *Archival:* row removed when commitment ends · *Deletion:* SECURITY DEFINER triggers only · *Retention:* transient

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `vehicle_id` | uuid |  |  |  |
| `sale_reservation_id` | uuid |  |  |  |
| `sale_order_id` | uuid | yes |  |  |
| `organisation_id` | uuid |  |  |  |
| `hold_expires_at` | timestamp with time zone | yes |  |  |
| `committed_since` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **FK** `vehicle_current_reservations_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `vehicle_current_reservations_sale_order_id_fkey`: `FOREIGN KEY (sale_order_id) REFERENCES sale_orders(id)`
- **FK** `vehicle_current_reservations_sale_reservation_id_fkey`: `FOREIGN KEY (sale_reservation_id) REFERENCES sale_reservations(id)`
- **FK** `vehicle_current_reservations_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `vehicle_current_reservations_pkey`: `PRIMARY KEY (vehicle_id)`
- **UNIQUE** `vehicle_current_reservations_sale_order_id_key`: `UNIQUE (sale_order_id)`
- **UNIQUE** `vehicle_current_reservations_sale_reservation_id_key`: `UNIQUE (sale_reservation_id)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `vehicle_current_reservations_appointments` → `trg_current_reservation_appointments()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### sale_orders

Sale agreement through to completion. Created only from a dealer-accepted reservation.

*RLS:* enabled · *Archival:* complete / cancel · *Deletion:* trigger-blocked · *Retention:* 10 years (sale contract)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `order_number` | text |  | `((('S-'::text ¦¦ to_char((now() AT TIME ZONE 'UTC'::text), 'YYYY'::text)) ¦¦ '-'::text) ¦¦ lpad((nextval('sale_order_number_seq'::regclass))::text, 7, '0'::text))` |  |
| `organisation_id` | uuid |  |  |  |
| `sale_reservation_id` | uuid |  |  |  |
| `vehicle_id` | uuid |  |  |  |
| `customer_id` | uuid |  |  |  |
| `quote_id` | uuid | yes |  |  |
| `currency` | character(3) |  |  |  |
| `agreed_total_minor` | bigint |  |  |  |
| `status` | text |  | `'agreement_pending'::text` |  |
| `agreement_signed_at` | timestamp with time zone | yes |  |  |
| `agreement_media_id` | uuid | yes |  |  |
| `completed_at` | timestamp with time zone | yes |  |  |
| `cancelled_at` | timestamp with time zone | yes |  |  |
| `cancel_reason` | text | yes |  |  |
| `created_by` | uuid | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `sale_orders_agreed_total_minor_check`: `CHECK ((agreed_total_minor > 0))`
- **CHECK** `sale_orders_check`: `CHECK (((status <> ALL (ARRAY['agreement_signed'::text, 'handed_over'::text, 'completed'::text])) OR (agreement_signed_at IS NOT NULL)))`
- **CHECK** `sale_orders_check1`: `CHECK (((status = 'completed'::text) = (completed_at IS NOT NULL)))`
- **CHECK** `sale_orders_check2`: `CHECK (((status = 'cancelled'::text) = ((cancelled_at IS NOT NULL) AND (cancel_reason IS NOT NULL))))`
- **CHECK** `sale_orders_status_check`: `CHECK ((status = ANY (ARRAY['agreement_pending'::text, 'agreement_signed'::text, 'handed_over'::text, 'completed'::text, 'cancelled'::text])))`
- **FK** `sale_orders_agreement_media_id_fkey`: `FOREIGN KEY (agreement_media_id) REFERENCES vehicle_media(id)`
- **FK** `sale_orders_created_by_fkey`: `FOREIGN KEY (created_by) REFERENCES app_users(id)`
- **FK** `sale_orders_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `sale_orders_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `sale_orders_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `sale_orders_quote_id_organisation_id_fkey`: `FOREIGN KEY (quote_id, organisation_id) REFERENCES quotes(id, organisation_id)`
- **FK** `sale_orders_sale_reservation_id_organisation_id_fkey`: `FOREIGN KEY (sale_reservation_id, organisation_id) REFERENCES sale_reservations(id, organisation_id)`
- **FK** `sale_orders_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `sale_orders_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `sale_orders_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `sale_orders_order_number_key`: `UNIQUE (order_number)`
- **UNIQUE** `sale_orders_sale_reservation_id_key`: `UNIQUE (sale_reservation_id)`

</details>

<details><summary>Indexes</summary>

- `UNIQUE INDEX sale_orders_one_open_per_vehicle_uq ON sale_orders USING btree (vehicle_id) WHERE (status <> ALL (ARRAY['completed'::text, 'cancelled'::text]))`
- `INDEX sale_orders_org_status_idx ON sale_orders USING btree (organisation_id, status, created_at DESC)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `sale_orders_after_insert` → `trg_sale_order_after_insert()`
- trigger `sale_orders_after_update` → `trg_sale_order_after_update()`
- trigger `sale_orders_before_insert` → `trg_sale_order_before_insert()`
- trigger `sale_orders_before_update` → `trg_sale_order_before_update()`
- trigger `sale_orders_no_delete` → `trg_forbid_delete()`
- trigger `sale_orders_touch` → `trg_touch_row()`
- policy `sale_orders_customer_read` (SELECT): USING `(customer_id = app_customer_id())`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### sale_status_events

Append-only history of reservation and sale-order transitions (written by triggers).

*RLS:* enabled · *Archival:* — · *Deletion:* append-only · *Retention:* 10 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `sale_reservation_id` | uuid | yes |  |  |
| `sale_order_id` | uuid | yes |  |  |
| `event` | text |  |  |  |
| `from_status` | text | yes |  |  |
| `to_status` | text | yes |  |  |
| `detail` | jsonb |  | `'{}'::jsonb` |  |
| `actor_user_id` | uuid | yes |  |  |
| `actor_kind` | text |  |  |  |
| `request_id` | text | yes |  |  |
| `occurred_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `sale_status_events_check`: `CHECK ((num_nonnulls(sale_reservation_id, sale_order_id) >= 1))`
- **FK** `sale_status_events_actor_user_id_fkey`: `FOREIGN KEY (actor_user_id) REFERENCES app_users(id)`
- **FK** `sale_status_events_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `sale_status_events_sale_order_id_fkey`: `FOREIGN KEY (sale_order_id) REFERENCES sale_orders(id)`
- **FK** `sale_status_events_sale_reservation_id_fkey`: `FOREIGN KEY (sale_reservation_id) REFERENCES sale_reservations(id)`
- **PK** `sale_status_events_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `INDEX sale_status_events_order_idx ON sale_status_events USING btree (sale_order_id, occurred_at)`
- `INDEX sale_status_events_reservation_idx ON sale_status_events USING btree (sale_reservation_id, occurred_at)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `sale_status_events_append` → `trg_append_only()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### handover_records

Scheduled and completed physical handovers. Once handed_over_at is recorded the row is frozen.

*RLS:* enabled · *Archival:* frozen once handed over · *Deletion:* trigger-blocked · *Retention:* 10 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `sale_order_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `location_id` | uuid |  |  |  |
| `scheduled_for` | timestamp with time zone | yes |  |  |
| `handed_over_at` | timestamp with time zone | yes |  |  |
| `odometer_value` | integer | yes |  |  |
| `odometer_unit` | text | yes |  |  |
| `staff_user_id` | uuid | yes |  |  |
| `notes` | text | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `handover_records_check`: `CHECK (((odometer_value IS NULL) = (odometer_unit IS NULL)))`
- **CHECK** `handover_records_check1`: `CHECK (((scheduled_for IS NOT NULL) OR (handed_over_at IS NOT NULL)))`
- **CHECK** `handover_records_odometer_unit_check`: `CHECK ((odometer_unit = ANY (ARRAY['km'::text, 'mi'::text])))`
- **CHECK** `handover_records_odometer_value_check`: `CHECK ((odometer_value >= 0))`
- **FK** `handover_records_location_id_organisation_id_fkey`: `FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id)`
- **FK** `handover_records_sale_order_id_organisation_id_fkey`: `FOREIGN KEY (sale_order_id, organisation_id) REFERENCES sale_orders(id, organisation_id)`
- **FK** `handover_records_staff_user_id_fkey`: `FOREIGN KEY (staff_user_id) REFERENCES app_users(id)`
- **PK** `handover_records_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `UNIQUE INDEX handover_records_one_completed_uq ON handover_records USING btree (sale_order_id) WHERE (handed_over_at IS NOT NULL)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `handover_records_freeze` → `trg_handover_freeze()`
- trigger `handover_records_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>


---

## Test drives

### appointment_resources

Bookable test-drive resources with a concurrent capacity (staff are always capacity 1).

*RLS:* enabled

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `location_id` | uuid |  |  |  |
| `kind` | text |  |  |  |
| `name` | text |  |  |  |
| `user_id` | uuid | yes |  |  |
| `capacity` | smallint |  | `1` |  |
| `status` | text |  | `'active'::text` |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `appointment_resources_capacity_check`: `CHECK (((capacity >= 1) AND (capacity <= 50)))`
- **CHECK** `appointment_resources_check`: `CHECK (((kind <> 'staff'::text) OR (capacity = 1)))`
- **CHECK** `appointment_resources_kind_check`: `CHECK ((kind = ANY (ARRAY['staff'::text, 'bay'::text, 'demo_plate'::text])))`
- **CHECK** `appointment_resources_status_check`: `CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text])))`
- **FK** `appointment_resources_location_id_organisation_id_fkey`: `FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id)`
- **FK** `appointment_resources_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `appointment_resources_user_id_fkey`: `FOREIGN KEY (user_id) REFERENCES app_users(id)`
- **PK** `appointment_resources_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `appointment_resources_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `appointment_resources_organisation_id_location_id_name_key`: `UNIQUE (organisation_id, location_id, name)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `appointment_resources_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### test_drive_appointments

Test-drive requests and confirmations. Instants are timestamptz; local_timezone (copied from the location) is used for display and local-day rules. Independent of sale holds.

*RLS:* enabled · *Archival:* cancel / complete · *Deletion:* trigger-blocked · *Retention:* 2 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `location_id` | uuid |  |  |  |
| `vehicle_id` | uuid |  |  |  |
| `listing_id` | uuid | yes |  |  |
| `customer_id` | uuid |  |  |  |
| `resource_id` | uuid |  |  |  |
| `starts_at` | timestamp with time zone |  |  |  |
| `ends_at` | timestamp with time zone |  |  |  |
| `slot` | tstzrange | yes | GENERATED: `tstzrange(starts_at, ends_at, '[)'::text)` |  |
| `local_timezone` | text |  |  |  |
| `request_status` | text |  | `'requested'::text` | Customer request lifecycle: requested -> accepted ¦ declined ¦ withdrawn. |
| `confirmation_status` | text |  | `'unconfirmed'::text` | Slot lifecycle: unconfirmed -> confirmed -> completed ¦ no_show; any non-final -> cancelled. Conflicts are enforced only between confirmed rows. |
| `availability_notice` | text | yes |  |  |
| `cancelled_at` | timestamp with time zone | yes |  |  |
| `cancelled_by_kind` | text | yes |  |  |
| `cancellation_reason` | text | yes |  |  |
| `idempotency_key` | text | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `test_drive_appointments_availability_notice_check`: `CHECK ((availability_notice = 'vehicle_reserved'::text))`
- **CHECK** `test_drive_appointments_cancelled_by_kind_check`: `CHECK ((cancelled_by_kind = ANY (ARRAY['customer'::text, 'dealer'::text, 'system'::text])))`
- **CHECK** `test_drive_appointments_check`: `CHECK (((ends_at > starts_at) AND ((ends_at - starts_at) <= '04:00:00'::interval)))`
- **CHECK** `test_drive_appointments_check1`: `CHECK (((confirmation_status = 'cancelled'::text) = ((cancelled_at IS NOT NULL) AND (cancellation_reason IS NOT NULL) AND (cancelled_by_kind IS NOT NULL))))`
- **CHECK** `test_drive_appointments_check2`: `CHECK (((confirmation_status <> 'confirmed'::text) OR (request_status = 'accepted'::text)))`
- **CHECK** `test_drive_appointments_check3`: `CHECK (((request_status <> 'declined'::text) OR (confirmation_status = ANY (ARRAY['unconfirmed'::text, 'cancelled'::text]))))`
- **CHECK** `test_drive_appointments_confirmation_status_check`: `CHECK ((confirmation_status = ANY (ARRAY['unconfirmed'::text, 'confirmed'::text, 'cancelled'::text, 'completed'::text, 'no_show'::text])))`
- **CHECK** `test_drive_appointments_request_status_check`: `CHECK ((request_status = ANY (ARRAY['requested'::text, 'accepted'::text, 'declined'::text, 'withdrawn'::text])))`
- **FK** `test_drive_appointments_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `test_drive_appointments_listing_id_organisation_id_fkey`: `FOREIGN KEY (listing_id, organisation_id) REFERENCES listings(id, organisation_id)`
- **FK** `test_drive_appointments_location_id_organisation_id_fkey`: `FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id)`
- **FK** `test_drive_appointments_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `test_drive_appointments_resource_id_organisation_id_fkey`: `FOREIGN KEY (resource_id, organisation_id) REFERENCES appointment_resources(id, organisation_id)`
- **FK** `test_drive_appointments_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `test_drive_appointments_pkey`: `PRIMARY KEY (id)`
- **EXCLUDE** `test_drive_appointments_vehicle_id_slot_excl`: `EXCLUDE USING gist (vehicle_id WITH =, slot WITH &&) WHERE ((confirmation_status = 'confirmed'::text))`

</details>

<details><summary>Indexes</summary>

- `UNIQUE INDEX test_drive_appointments_idem_uq ON test_drive_appointments USING btree (organisation_id, idempotency_key) WHERE (idempotency_key IS NOT NULL)`
- `INDEX test_drive_appointments_org_start_idx ON test_drive_appointments USING btree (organisation_id, starts_at)`
- `INDEX test_drive_appointments_resource_idx ON test_drive_appointments USING gist (resource_id, slot) WHERE (confirmation_status = 'confirmed'::text)`
- `INDEX test_drive_appointments_vehicle_idx ON test_drive_appointments USING btree (vehicle_id, starts_at)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `test_drive_appointments_check` → `trg_test_drive_check()`
- trigger `test_drive_appointments_no_delete` → `trg_forbid_delete()`
- trigger `test_drive_appointments_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`
- policy `test_drives_customer_read` (SELECT): USING `(customer_id = app_customer_id())`

</details>


---

## Rentals

### rental_categories

Bookable rental classes. turnaround_buffer is added after each return before the asset can be used again.

*RLS:* enabled

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `code` | text |  |  |  |
| `name` | text |  |  |  |
| `seats` | smallint | yes |  |  |
| `transmission` | text | yes |  |  |
| `turnaround_buffer` | interval |  | `'01:00:00'::interval` |  |
| `daily_rate_minor` | bigint |  |  |  |
| `currency` | character(3) |  |  |  |
| `status` | text |  | `'active'::text` |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `rental_categories_code_check`: `CHECK ((code ~ '^[A-Z0-9_-]{2,16}$'::text))`
- **CHECK** `rental_categories_daily_rate_minor_check`: `CHECK ((daily_rate_minor > 0))`
- **CHECK** `rental_categories_seats_check`: `CHECK (((seats >= 1) AND (seats <= 15)))`
- **CHECK** `rental_categories_status_check`: `CHECK ((status = ANY (ARRAY['active'::text, 'retired'::text])))`
- **CHECK** `rental_categories_transmission_check`: `CHECK ((transmission = ANY (ARRAY['automatic'::text, 'manual'::text])))`
- **CHECK** `rental_categories_turnaround_buffer_check`: `CHECK (((turnaround_buffer >= '00:00:00'::interval) AND (turnaround_buffer <= '2 days'::interval)))`
- **FK** `rental_categories_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `rental_categories_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **PK** `rental_categories_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `rental_categories_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `rental_categories_organisation_id_code_key`: `UNIQUE (organisation_id, code)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `rental_categories_touch` → `trg_touch_row()`
- policy `rental_categories_public_read` (SELECT): USING `(status = 'active'::text)`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### rental_inventory_buckets

Lock target for category-capacity control at a location. capacity_override can cap sellable capacity below the physical fleet (never raise it).

*RLS:* enabled

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `location_id` | uuid |  |  |  |
| `category_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `capacity_override` | integer | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `rental_inventory_buckets_capacity_override_check`: `CHECK ((capacity_override >= 0))`
- **FK** `rental_inventory_buckets_category_id_organisation_id_fkey`: `FOREIGN KEY (category_id, organisation_id) REFERENCES rental_categories(id, organisation_id)`
- **FK** `rental_inventory_buckets_location_id_organisation_id_fkey`: `FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id)`
- **FK** `rental_inventory_buckets_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **PK** `rental_inventory_buckets_pkey`: `PRIMARY KEY (location_id, category_id)`

</details>

<details><summary>Triggers & policies</summary>

- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### rental_assets

Exact physical vehicles in a rental fleet (one rental_assets row per vehicle).

*RLS:* enabled

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `vehicle_id` | uuid |  |  |  |
| `category_id` | uuid |  |  |  |
| `home_location_id` | uuid |  |  |  |
| `fleet_number` | text |  |  |  |
| `status` | text |  | `'active'::text` |  |
| `in_fleet_from` | timestamp with time zone |  | `now()` |  |
| `in_fleet_to` | timestamp with time zone | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `rental_assets_check`: `CHECK (((in_fleet_to IS NULL) OR (in_fleet_to > in_fleet_from)))`
- **CHECK** `rental_assets_status_check`: `CHECK ((status = ANY (ARRAY['active'::text, 'out_of_service'::text, 'retired'::text])))`
- **FK** `rental_assets_category_id_organisation_id_fkey`: `FOREIGN KEY (category_id, organisation_id) REFERENCES rental_categories(id, organisation_id)`
- **FK** `rental_assets_home_location_id_category_id_fkey`: `FOREIGN KEY (home_location_id, category_id) REFERENCES rental_inventory_buckets(location_id, category_id)`
- **FK** `rental_assets_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `rental_assets_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `rental_assets_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `rental_assets_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `rental_assets_organisation_id_fleet_number_key`: `UNIQUE (organisation_id, fleet_number)`
- **UNIQUE** `rental_assets_vehicle_id_key`: `UNIQUE (vehicle_id)`

</details>

<details><summary>Indexes</summary>

- `INDEX rental_assets_bucket_idx ON rental_assets USING btree (home_location_id, category_id) WHERE (status = 'active'::text)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `rental_assets_no_delete` → `trg_forbid_delete()`
- trigger `rental_assets_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### rental_quotes

Immutable rental price quotes. rental_days = number of started 24-hour periods between pickup and return instants.

*RLS:* enabled

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `location_id` | uuid |  |  |  |
| `category_id` | uuid |  |  |  |
| `customer_id` | uuid | yes |  |  |
| `pickup_at` | timestamp with time zone |  |  |  |
| `return_at` | timestamp with time zone |  |  |  |
| `local_timezone` | text |  |  |  |
| `rental_days` | integer |  |  |  |
| `daily_rate_minor` | bigint |  |  |  |
| `total_minor` | bigint |  |  |  |
| `currency` | character(3) |  |  |  |
| `issued_at` | timestamp with time zone |  | `now()` |  |
| `expires_at` | timestamp with time zone |  |  |  |

<details><summary>Constraints</summary>

- **CHECK** `rental_quotes_check`: `CHECK ((return_at > pickup_at))`
- **CHECK** `rental_quotes_check1`: `CHECK ((expires_at > issued_at))`
- **CHECK** `rental_quotes_check2`: `CHECK ((total_minor = (rental_days * daily_rate_minor)))`
- **CHECK** `rental_quotes_daily_rate_minor_check`: `CHECK ((daily_rate_minor > 0))`
- **CHECK** `rental_quotes_rental_days_check`: `CHECK (((rental_days >= 1) AND (rental_days <= 90)))`
- **CHECK** `rental_quotes_total_minor_check`: `CHECK ((total_minor > 0))`
- **FK** `rental_quotes_category_id_organisation_id_fkey`: `FOREIGN KEY (category_id, organisation_id) REFERENCES rental_categories(id, organisation_id)`
- **FK** `rental_quotes_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `rental_quotes_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `rental_quotes_location_id_organisation_id_fkey`: `FOREIGN KEY (location_id, organisation_id) REFERENCES locations(id, organisation_id)`
- **FK** `rental_quotes_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **PK** `rental_quotes_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `rental_quotes_id_organisation_id_key`: `UNIQUE (id, organisation_id)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `rental_quotes_append` → `trg_append_only()`
- policy `rental_quotes_customer_read` (SELECT): USING `(customer_id = app_customer_id())`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### rental_bookings

Category-level rental bookings. Capacity is enforced per (pickup location, category) bucket under a row lock. Exact vehicles are attached via rental_asset_assignments.

*RLS:* enabled · *Archival:* cancel / return · *Deletion:* trigger-blocked · *Retention:* 7 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `booking_number` | text |  | `((('B-'::text ¦¦ to_char((now() AT TIME ZONE 'UTC'::text), 'YYYY'::text)) ¦¦ '-'::text) ¦¦ lpad((nextval('rental_booking_number_seq'::regclass))::text, 7, '0'::text))` |  |
| `organisation_id` | uuid |  |  |  |
| `customer_id` | uuid |  |  |  |
| `category_id` | uuid |  |  |  |
| `pickup_location_id` | uuid |  |  |  |
| `return_location_id` | uuid |  |  |  |
| `rental_quote_id` | uuid | yes |  |  |
| `pickup_at` | timestamp with time zone |  |  |  |
| `return_at` | timestamp with time zone |  |  |  |
| `pickup_timezone` | text |  |  | IANA zone of the pickup location at booking time, for local display and local-day rules. |
| `return_timezone` | text |  |  |  |
| `booked_range` | tstzrange | yes | GENERATED: `tstzrange(pickup_at, return_at, '[)'::text)` |  |
| `status` | text |  | `'confirmed'::text` |  |
| `total_minor` | bigint |  |  |  |
| `currency` | character(3) |  |  |  |
| `cancelled_at` | timestamp with time zone | yes |  |  |
| `cancellation_reason` | text | yes |  |  |
| `idempotency_key` | text | yes |  |  |
| `created_by` | uuid | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `rental_bookings_check`: `CHECK (((return_at > pickup_at) AND ((return_at - pickup_at) <= '90 days'::interval)))`
- **CHECK** `rental_bookings_check1`: `CHECK ((return_location_id = pickup_location_id))`
- **CHECK** `rental_bookings_check2`: `CHECK (((status = 'cancelled'::text) = ((cancelled_at IS NOT NULL) AND (cancellation_reason IS NOT NULL))))`
- **CHECK** `rental_bookings_status_check`: `CHECK ((status = ANY (ARRAY['confirmed'::text, 'checked_out'::text, 'returned'::text, 'cancelled'::text, 'no_show'::text])))`
- **CHECK** `rental_bookings_total_minor_check`: `CHECK ((total_minor > 0))`
- **FK** `rental_bookings_category_id_organisation_id_fkey`: `FOREIGN KEY (category_id, organisation_id) REFERENCES rental_categories(id, organisation_id)`
- **FK** `rental_bookings_created_by_fkey`: `FOREIGN KEY (created_by) REFERENCES app_users(id)`
- **FK** `rental_bookings_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `rental_bookings_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `rental_bookings_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `rental_bookings_pickup_location_id_category_id_fkey`: `FOREIGN KEY (pickup_location_id, category_id) REFERENCES rental_inventory_buckets(location_id, category_id)`
- **FK** `rental_bookings_rental_quote_id_organisation_id_fkey`: `FOREIGN KEY (rental_quote_id, organisation_id) REFERENCES rental_quotes(id, organisation_id)`
- **FK** `rental_bookings_return_location_id_organisation_id_fkey`: `FOREIGN KEY (return_location_id, organisation_id) REFERENCES locations(id, organisation_id)`
- **PK** `rental_bookings_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `rental_bookings_booking_number_key`: `UNIQUE (booking_number)`
- **UNIQUE** `rental_bookings_id_organisation_id_key`: `UNIQUE (id, organisation_id)`

</details>

<details><summary>Indexes</summary>

- `INDEX rental_bookings_bucket_range_idx ON rental_bookings USING gist (pickup_location_id, category_id, booked_range) WHERE (status = ANY (ARRAY['confirmed'::text, 'checked_out'::text]))`
- `INDEX rental_bookings_customer_idx ON rental_bookings USING btree (customer_id)`
- `UNIQUE INDEX rental_bookings_idem_uq ON rental_bookings USING btree (organisation_id, idempotency_key) WHERE (idempotency_key IS NOT NULL)`
- `INDEX rental_bookings_org_pickup_idx ON rental_bookings USING btree (organisation_id, pickup_at)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `rental_bookings_after` → `trg_rental_booking_after()`
- trigger `rental_bookings_before` → `trg_rental_booking_before()`
- trigger `rental_bookings_no_delete` → `trg_forbid_delete()`
- trigger `rental_bookings_touch` → `trg_touch_row()`
- policy `rental_bookings_customer_read` (SELECT): USING `(customer_id = app_customer_id())`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### rental_asset_assignments

Binds a booking to an exact asset for [pickup_at, return_at + turnaround_buffer). Exclusion constraint prevents overlapping active assignments.

*RLS:* enabled · *Archival:* release / cancel · *Deletion:* trigger-blocked · *Retention:* 7 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `rental_booking_id` | uuid |  |  |  |
| `rental_asset_id` | uuid |  |  |  |
| `occupied` | tstzrange |  |  |  |
| `is_upgrade` | boolean |  | `false` |  |
| `status` | text |  | `'active'::text` |  |
| `assigned_by` | uuid | yes |  |  |
| `assigned_at` | timestamp with time zone |  | `now()` |  |
| `released_at` | timestamp with time zone | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `rental_asset_assignments_check`: `CHECK (((status = 'active'::text) = (released_at IS NULL)))`
- **CHECK** `rental_asset_assignments_occupied_check`: `CHECK ((lower_inc(occupied) AND (NOT upper_inc(occupied)) AND (NOT isempty(occupied))))`
- **CHECK** `rental_asset_assignments_status_check`: `CHECK ((status = ANY (ARRAY['active'::text, 'released'::text, 'cancelled'::text])))`
- **FK** `rental_asset_assignments_assigned_by_fkey`: `FOREIGN KEY (assigned_by) REFERENCES app_users(id)`
- **FK** `rental_asset_assignments_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `rental_asset_assignments_rental_asset_id_organisation_id_fkey`: `FOREIGN KEY (rental_asset_id, organisation_id) REFERENCES rental_assets(id, organisation_id)`
- **FK** `rental_asset_assignments_rental_booking_id_organisation_id_fkey`: `FOREIGN KEY (rental_booking_id, organisation_id) REFERENCES rental_bookings(id, organisation_id)`
- **PK** `rental_asset_assignments_pkey`: `PRIMARY KEY (id)`
- **EXCLUDE** `rental_asset_assignments_rental_asset_id_occupied_excl`: `EXCLUDE USING gist (rental_asset_id WITH =, occupied WITH &&) WHERE ((status = 'active'::text))`

</details>

<details><summary>Indexes</summary>

- `UNIQUE INDEX rental_asset_assignments_one_active_uq ON rental_asset_assignments USING btree (rental_booking_id) WHERE (status = 'active'::text)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `rental_asset_assignments_before` → `trg_rental_assignment_before()`
- trigger `rental_asset_assignments_no_delete` → `trg_forbid_delete()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### maintenance_blocks

Periods an asset cannot be rented. Cannot overlap active assignments and cannot reduce bucket capacity below committed bookings.

*RLS:* enabled · *Archival:* complete / cancel · *Deletion:* trigger-blocked · *Retention:* asset life + 2 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `rental_asset_id` | uuid |  |  |  |
| `kind` | text |  |  |  |
| `starts_at` | timestamp with time zone |  |  |  |
| `ends_at` | timestamp with time zone |  |  |  |
| `block_range` | tstzrange | yes | GENERATED: `tstzrange(starts_at, ends_at, '[)'::text)` |  |
| `status` | text |  | `'planned'::text` |  |
| `reason` | text |  |  |  |
| `created_by` | uuid | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `maintenance_blocks_check`: `CHECK ((ends_at > starts_at))`
- **CHECK** `maintenance_blocks_kind_check`: `CHECK ((kind = ANY (ARRAY['scheduled_service'::text, 'repair'::text, 'inspection'::text, 'recall'::text, 'damage'::text])))`
- **CHECK** `maintenance_blocks_status_check`: `CHECK ((status = ANY (ARRAY['planned'::text, 'active'::text, 'completed'::text, 'cancelled'::text])))`
- **FK** `maintenance_blocks_created_by_fkey`: `FOREIGN KEY (created_by) REFERENCES app_users(id)`
- **FK** `maintenance_blocks_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `maintenance_blocks_rental_asset_id_organisation_id_fkey`: `FOREIGN KEY (rental_asset_id, organisation_id) REFERENCES rental_assets(id, organisation_id)`
- **PK** `maintenance_blocks_pkey`: `PRIMARY KEY (id)`
- **EXCLUDE** `maintenance_blocks_rental_asset_id_block_range_excl`: `EXCLUDE USING gist (rental_asset_id WITH =, block_range WITH &&) WHERE ((status = ANY (ARRAY['planned'::text, 'active'::text])))`

</details>

<details><summary>Indexes</summary>

- `INDEX maintenance_blocks_asset_idx ON maintenance_blocks USING gist (rental_asset_id, block_range) WHERE (status = ANY (ARRAY['planned'::text, 'active'::text]))`

</details>

<details><summary>Triggers & policies</summary>

- trigger `maintenance_blocks_after` → `trg_maintenance_after()`
- trigger `maintenance_blocks_before` → `trg_maintenance_before()`
- trigger `maintenance_blocks_no_delete` → `trg_forbid_delete()`
- trigger `maintenance_blocks_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>


---

## Payments

### payment_intents

Expected payments. Created idempotently (organisation_id, idempotency_key). Status follows verified provider events; it never by itself advances a reservation or sale.

*RLS:* enabled · *Archival:* terminal statuses · *Deletion:* trigger-blocked · *Retention:* 10 years (financial)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `provider` | text |  |  |  |
| `provider_intent_ref` | text | yes |  |  |
| `purpose` | text |  |  |  |
| `sale_reservation_id` | uuid | yes |  |  |
| `sale_order_id` | uuid | yes |  |  |
| `rental_booking_id` | uuid | yes |  |  |
| `customer_id` | uuid |  |  |  |
| `amount_minor` | bigint |  |  |  |
| `currency` | character(3) |  |  |  |
| `status` | text |  | `'created'::text` | unknown = the provider call outcome could not be determined (timeout); resolved by the reconciliation worker. |
| `last_provider_event_at` | timestamp with time zone | yes |  |  |
| `failure_code` | text | yes |  |  |
| `idempotency_key` | text |  |  |  |
| `request_sha256` | character(64) |  |  |  |
| `created_by` | uuid | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `payment_intents_amount_minor_check`: `CHECK ((amount_minor > 0))`
- **CHECK** `payment_intents_check`: `CHECK ((num_nonnulls(sale_reservation_id, sale_order_id, rental_booking_id) = 1))`
- **CHECK** `payment_intents_check1`: `CHECK (((purpose <> 'sale_deposit'::text) OR (sale_reservation_id IS NOT NULL)))`
- **CHECK** `payment_intents_check2`: `CHECK (((purpose <> 'sale_balance'::text) OR (sale_order_id IS NOT NULL)))`
- **CHECK** `payment_intents_check3`: `CHECK (((purpose <> 'rental_prepayment'::text) OR (rental_booking_id IS NOT NULL)))`
- **CHECK** `payment_intents_idempotency_key_check`: `CHECK (((length(idempotency_key) >= 8) AND (length(idempotency_key) <= 200)))`
- **CHECK** `payment_intents_provider_check`: `CHECK ((provider ~ '^[a-z][a-z0-9_]{1,31}$'::text))`
- **CHECK** `payment_intents_purpose_check`: `CHECK ((purpose = ANY (ARRAY['sale_deposit'::text, 'sale_balance'::text, 'rental_prepayment'::text])))`
- **CHECK** `payment_intents_status_check`: `CHECK ((status = ANY (ARRAY['created'::text, 'processing'::text, 'requires_action'::text, 'succeeded'::text, 'failed'::text, 'canceled'::text, 'unknown'::text])))`
- **FK** `payment_intents_created_by_fkey`: `FOREIGN KEY (created_by) REFERENCES app_users(id)`
- **FK** `payment_intents_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `payment_intents_customer_id_fkey`: `FOREIGN KEY (customer_id) REFERENCES customers(id)`
- **FK** `payment_intents_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `payment_intents_rental_booking_id_organisation_id_fkey`: `FOREIGN KEY (rental_booking_id, organisation_id) REFERENCES rental_bookings(id, organisation_id)`
- **FK** `payment_intents_sale_order_id_organisation_id_fkey`: `FOREIGN KEY (sale_order_id, organisation_id) REFERENCES sale_orders(id, organisation_id)`
- **FK** `payment_intents_sale_reservation_id_organisation_id_fkey`: `FOREIGN KEY (sale_reservation_id, organisation_id) REFERENCES sale_reservations(id, organisation_id)`
- **PK** `payment_intents_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `payment_intents_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `payment_intents_organisation_id_idempotency_key_key`: `UNIQUE (organisation_id, idempotency_key)`
- **UNIQUE** `payment_intents_provider_provider_intent_ref_key`: `UNIQUE (provider, provider_intent_ref)`

</details>

<details><summary>Indexes</summary>

- `INDEX payment_intents_org_created_idx ON payment_intents USING btree (organisation_id, created_at DESC)`
- `INDEX payment_intents_reservation_idx ON payment_intents USING btree (sale_reservation_id) WHERE (sale_reservation_id IS NOT NULL)`
- `INDEX payment_intents_unknown_idx ON payment_intents USING btree (updated_at) WHERE (status = ANY (ARRAY['unknown'::text, 'processing'::text, 'created'::text]))`

</details>

<details><summary>Triggers & policies</summary>

- trigger `payment_intents_guard` → `trg_payment_intent_guard()`
- trigger `payment_intents_no_delete` → `trg_forbid_delete()`
- trigger `payment_intents_touch` → `trg_touch_row()`
- policy `payment_intents_customer_read` (SELECT): USING `(customer_id = app_customer_id())`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### payment_events

Verified provider webhook events, stored once per (provider, provider_event_id): duplicates are detected by the unique key and never re-applied. Payload is the provider JSON minus anything sensitive. Only processing_* columns may change.

*RLS:* enabled · *Archival:* processing fields only · *Deletion:* trigger-blocked · *Retention:* 10 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `provider` | text |  |  |  |
| `provider_event_id` | text |  |  |  |
| `event_type` | text |  |  |  |
| `provider_created_at` | timestamp with time zone |  |  |  |
| `received_at` | timestamp with time zone |  | `now()` |  |
| `signature_verified` | boolean |  |  |  |
| `organisation_id` | uuid | yes |  |  |
| `payment_intent_id` | uuid | yes |  |  |
| `refund_id` | uuid | yes |  |  |
| `payload` | jsonb |  |  |  |
| `payload_sha256` | character(64) |  |  |  |
| `processing_status` | text |  | `'received'::text` |  |
| `processing_note` | text | yes |  |  |
| `processed_at` | timestamp with time zone | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `payment_events_payload_check`: `CHECK ((jsonb_typeof(payload) = 'object'::text))`
- **CHECK** `payment_events_processing_status_check`: `CHECK ((processing_status = ANY (ARRAY['received'::text, 'applied'::text, 'ignored_out_of_order'::text, 'ignored_no_effect'::text, 'unmatched'::text, 'failed'::text])))`
- **CHECK** `payment_events_signature_verified_check`: `CHECK (signature_verified)`
- **FK** `payment_events_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `payment_events_payment_intent_id_fkey`: `FOREIGN KEY (payment_intent_id) REFERENCES payment_intents(id)`
- **FK** `payment_events_refund_fk`: `FOREIGN KEY (refund_id) REFERENCES refunds(id)`
- **PK** `payment_events_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `payment_events_provider_provider_event_id_key`: `UNIQUE (provider, provider_event_id)`

</details>

<details><summary>Indexes</summary>

- `INDEX payment_events_intent_idx ON payment_events USING btree (payment_intent_id, provider_created_at)`
- `INDEX payment_events_status_idx ON payment_events USING btree (processing_status, received_at) WHERE (processing_status = ANY (ARRAY['received'::text, 'unmatched'::text, 'failed'::text]))`

</details>

<details><summary>Triggers & policies</summary>

- trigger `payment_events_guard` → `trg_payment_events_guard()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### payment_transactions

Append-only record of confirmed captures, refunds and chargebacks, one row per provider transaction reference. Not a double-entry ledger.

*RLS:* enabled · *Archival:* — · *Deletion:* append-only · *Retention:* 10 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `payment_intent_id` | uuid |  |  |  |
| `kind` | text |  |  |  |
| `amount_minor` | bigint |  |  |  |
| `currency` | character(3) |  |  |  |
| `provider` | text |  |  |  |
| `provider_transaction_ref` | text |  |  |  |
| `refund_id` | uuid | yes |  |  |
| `source_event_id` | uuid | yes |  |  |
| `occurred_at` | timestamp with time zone |  |  |  |
| `recorded_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `payment_transactions_amount_minor_check`: `CHECK ((amount_minor > 0))`
- **CHECK** `payment_transactions_check`: `CHECK (((kind = 'refund'::text) = (refund_id IS NOT NULL)))`
- **CHECK** `payment_transactions_kind_check`: `CHECK ((kind = ANY (ARRAY['capture'::text, 'refund'::text, 'chargeback'::text])))`
- **FK** `payment_transactions_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `payment_transactions_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `payment_transactions_payment_intent_id_organisation_id_fkey`: `FOREIGN KEY (payment_intent_id, organisation_id) REFERENCES payment_intents(id, organisation_id)`
- **FK** `payment_transactions_refund_fk`: `FOREIGN KEY (refund_id) REFERENCES refunds(id)`
- **FK** `payment_transactions_source_event_id_fkey`: `FOREIGN KEY (source_event_id) REFERENCES payment_events(id)`
- **PK** `payment_transactions_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `payment_transactions_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `payment_transactions_provider_provider_transaction_ref_key`: `UNIQUE (provider, provider_transaction_ref)`

</details>

<details><summary>Indexes</summary>

- `INDEX payment_transactions_intent_idx ON payment_transactions USING btree (payment_intent_id)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `payment_transactions_append` → `trg_append_only()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### refunds

Full or partial refunds against a capture. The sum of non-failed refunds can never exceed the captured amount (enforced under a row lock on the capture).

*RLS:* enabled · *Archival:* terminal statuses · *Deletion:* trigger-blocked · *Retention:* 10 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `payment_intent_id` | uuid |  |  |  |
| `capture_transaction_id` | uuid |  |  |  |
| `amount_minor` | bigint |  |  |  |
| `currency` | character(3) |  |  |  |
| `reason` | text |  |  |  |
| `status` | text |  | `'requested'::text` |  |
| `provider` | text |  |  |  |
| `provider_refund_ref` | text | yes |  |  |
| `reconciliation_case_id` | uuid | yes |  |  |
| `idempotency_key` | text |  |  |  |
| `failure_code` | text | yes |  |  |
| `requested_by` | uuid | yes |  |  |
| `requested_at` | timestamp with time zone |  | `now()` |  |
| `completed_at` | timestamp with time zone | yes |  |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `refunds_amount_minor_check`: `CHECK ((amount_minor > 0))`
- **CHECK** `refunds_check`: `CHECK (((status = ANY (ARRAY['succeeded'::text, 'failed'::text, 'canceled'::text])) = (completed_at IS NOT NULL)))`
- **CHECK** `refunds_reason_check`: `CHECK ((reason = ANY (ARRAY['customer_request'::text, 'hold_expired_before_payment'::text, 'duplicate_payment'::text, 'sale_cancelled'::text, 'goodwill'::text, 'reconciliation'::text])))`
- **CHECK** `refunds_status_check`: `CHECK ((status = ANY (ARRAY['requested'::text, 'pending'::text, 'succeeded'::text, 'failed'::text, 'canceled'::text])))`
- **FK** `refunds_capture_transaction_id_organisation_id_fkey`: `FOREIGN KEY (capture_transaction_id, organisation_id) REFERENCES payment_transactions(id, organisation_id)`
- **FK** `refunds_case_fk`: `FOREIGN KEY (reconciliation_case_id) REFERENCES reconciliation_cases(id)`
- **FK** `refunds_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `refunds_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `refunds_payment_intent_id_organisation_id_fkey`: `FOREIGN KEY (payment_intent_id, organisation_id) REFERENCES payment_intents(id, organisation_id)`
- **FK** `refunds_requested_by_fkey`: `FOREIGN KEY (requested_by) REFERENCES app_users(id)`
- **PK** `refunds_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `refunds_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `refunds_organisation_id_idempotency_key_key`: `UNIQUE (organisation_id, idempotency_key)`
- **UNIQUE** `refunds_provider_provider_refund_ref_key`: `UNIQUE (provider, provider_refund_ref)`

</details>

<details><summary>Indexes</summary>

- `INDEX refunds_intent_idx ON refunds USING btree (payment_intent_id)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `refunds_limit` → `trg_refund_limit()`
- trigger `refunds_no_delete` → `trg_forbid_delete()`
- trigger `refunds_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### reconciliation_cases

Investigation queue for money that does not line up with operational state (late settlement, unknown outcomes, mismatches). Resolved by staff or automatically when a linked refund settles.

*RLS:* enabled · *Archival:* resolve / write off · *Deletion:* trigger-blocked · *Retention:* 10 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `case_number` | text |  | `((('RC-'::text ¦¦ to_char((now() AT TIME ZONE 'UTC'::text), 'YYYY'::text)) ¦¦ '-'::text) ¦¦ lpad((nextval('reconciliation_case_number_seq'::regclass))::text, 6, '0'::text))` |  |
| `organisation_id` | uuid |  |  |  |
| `case_type` | text |  |  |  |
| `status` | text |  | `'open'::text` |  |
| `severity` | text |  | `'medium'::text` |  |
| `payment_intent_id` | uuid | yes |  |  |
| `payment_transaction_id` | uuid | yes |  |  |
| `payment_event_id` | uuid | yes |  |  |
| `refund_id` | uuid | yes |  |  |
| `sale_reservation_id` | uuid | yes |  |  |
| `rental_booking_id` | uuid | yes |  |  |
| `expected_amount_minor` | bigint | yes |  |  |
| `observed_amount_minor` | bigint | yes |  |  |
| `currency` | character(3) | yes |  |  |
| `summary` | text |  |  |  |
| `details` | jsonb |  | `'{}'::jsonb` |  |
| `resolution` | text | yes |  |  |
| `resolution_note` | text | yes |  |  |
| `opened_at` | timestamp with time zone |  | `now()` |  |
| `resolved_at` | timestamp with time zone | yes |  |  |
| `resolved_by` | uuid | yes |  |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `reconciliation_cases_case_type_check`: `CHECK ((case_type = ANY (ARRAY['payment_after_hold_expiry'::text, 'deposit_on_lapsed_hold'::text, 'amount_mismatch'::text, 'unknown_payment_outcome'::text, 'orphan_provider_event'::text, 'refund_outcome_mismatch'::text, 'duplicate_capture'::text])))`
- **CHECK** `reconciliation_cases_check`: `CHECK (((status = ANY (ARRAY['resolved'::text, 'written_off'::text])) = ((resolved_at IS NOT NULL) AND (resolution IS NOT NULL))))`
- **CHECK** `reconciliation_cases_check1`: `CHECK ((((expected_amount_minor IS NULL) AND (observed_amount_minor IS NULL)) OR (currency IS NOT NULL)))`
- **CHECK** `reconciliation_cases_resolution_check`: `CHECK ((resolution = ANY (ARRAY['refunded'::text, 'applied_to_new_reservation'::text, 'provider_confirmed'::text, 'manual_adjustment'::text, 'no_action'::text])))`
- **CHECK** `reconciliation_cases_severity_check`: `CHECK ((severity = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text])))`
- **CHECK** `reconciliation_cases_status_check`: `CHECK ((status = ANY (ARRAY['open'::text, 'investigating'::text, 'awaiting_provider'::text, 'resolved'::text, 'written_off'::text])))`
- **FK** `reconciliation_cases_currency_fkey`: `FOREIGN KEY (currency) REFERENCES currencies(code)`
- **FK** `reconciliation_cases_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `reconciliation_cases_payment_event_id_fkey`: `FOREIGN KEY (payment_event_id) REFERENCES payment_events(id)`
- **FK** `reconciliation_cases_payment_intent_id_fkey`: `FOREIGN KEY (payment_intent_id) REFERENCES payment_intents(id)`
- **FK** `reconciliation_cases_payment_transaction_id_fkey`: `FOREIGN KEY (payment_transaction_id) REFERENCES payment_transactions(id)`
- **FK** `reconciliation_cases_refund_id_fkey`: `FOREIGN KEY (refund_id) REFERENCES refunds(id)`
- **FK** `reconciliation_cases_rental_booking_id_fkey`: `FOREIGN KEY (rental_booking_id) REFERENCES rental_bookings(id)`
- **FK** `reconciliation_cases_resolved_by_fkey`: `FOREIGN KEY (resolved_by) REFERENCES app_users(id)`
- **FK** `reconciliation_cases_sale_reservation_id_fkey`: `FOREIGN KEY (sale_reservation_id) REFERENCES sale_reservations(id)`
- **PK** `reconciliation_cases_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `reconciliation_cases_case_number_key`: `UNIQUE (case_number)`

</details>

<details><summary>Indexes</summary>

- `UNIQUE INDEX reconciliation_cases_open_uq ON reconciliation_cases USING btree (case_type, payment_intent_id) WHERE ((status <> ALL (ARRAY['resolved'::text, 'written_off'::text])) AND (payment_intent_id IS NOT NULL))`
- `INDEX reconciliation_cases_org_status_idx ON reconciliation_cases USING btree (organisation_id, status, opened_at DESC)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `reconciliation_cases_no_delete` → `trg_forbid_delete()`
- trigger `reconciliation_cases_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>


---

## Imports

### import_jobs

One uploaded file. Re-uploading identical bytes for the same source returns the existing job (idempotent). mode: all_or_nothing = any invalid row blocks approval and application is one transaction; partial_accept = valid rows applied, invalid rows skipped and reported.

*RLS:* enabled · *Archival:* reject / applied · *Deletion:* trigger-blocked · *Retention:* 2 years (summary kept)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `source_namespace` | text |  |  |  |
| `format` | text |  |  |  |
| `mode` | text |  |  |  |
| `status` | text |  | `'uploaded'::text` |  |
| `original_filename` | text |  |  |  |
| `storage_bucket` | text |  |  |  |
| `object_key` | text |  |  |  |
| `file_sha256` | character(64) |  |  |  |
| `byte_size` | bigint |  |  |  |
| `options` | jsonb |  | `'{}'::jsonb` | Validated ImportOptions: {"clear_blank_fields": [...], "publish_on_apply": false}. Blank source fields never erase data unless listed in clear_blank_fields. |
| `row_count` | integer |  | `0` |  |
| `valid_count` | integer |  | `0` |  |
| `warning_count` | integer |  | `0` |  |
| `invalid_count` | integer |  | `0` |  |
| `applied_count` | integer |  | `0` |  |
| `no_change_count` | integer |  | `0` |  |
| `skipped_count` | integer |  | `0` |  |
| `error_summary` | text | yes |  |  |
| `attempts` | integer |  | `0` |  |
| `uploaded_by` | uuid | yes |  |  |
| `uploaded_at` | timestamp with time zone |  | `now()` |  |
| `validated_at` | timestamp with time zone | yes |  |  |
| `approved_by` | uuid | yes |  |  |
| `approved_at` | timestamp with time zone | yes |  |  |
| `applied_at` | timestamp with time zone | yes |  |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **CHECK** `import_jobs_byte_size_check`: `CHECK ((byte_size > 0))`
- **CHECK** `import_jobs_check`: `CHECK (((status <> ALL (ARRAY['approved'::text, 'applying'::text, 'applied'::text, 'applied_with_skips'::text])) OR (approved_at IS NOT NULL)))`
- **CHECK** `import_jobs_file_sha256_check`: `CHECK ((file_sha256 ~ '^[0-9a-f]{64}$'::text))`
- **CHECK** `import_jobs_format_check`: `CHECK ((format = ANY (ARRAY['csv'::text, 'json'::text])))`
- **CHECK** `import_jobs_mode_check`: `CHECK ((mode = ANY (ARRAY['all_or_nothing'::text, 'partial_accept'::text])))`
- **CHECK** `import_jobs_options_check`: `CHECK ((jsonb_typeof(options) = 'object'::text))`
- **CHECK** `import_jobs_row_count_check`: `CHECK ((row_count >= 0))`
- **CHECK** `import_jobs_source_namespace_check`: `CHECK ((source_namespace ~ '^[a-z][a-z0-9_.:-]{1,63}$'::text))`
- **CHECK** `import_jobs_status_check`: `CHECK ((status = ANY (ARRAY['uploaded'::text, 'validating'::text, 'validated'::text, 'approved'::text, 'applying'::text, 'applied'::text, 'applied_with_skips'::text, 'rejected'::text, 'failed'::text])))`
- **FK** `import_jobs_approved_by_fkey`: `FOREIGN KEY (approved_by) REFERENCES app_users(id)`
- **FK** `import_jobs_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `import_jobs_uploaded_by_fkey`: `FOREIGN KEY (uploaded_by) REFERENCES app_users(id)`
- **PK** `import_jobs_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `import_jobs_id_organisation_id_key`: `UNIQUE (id, organisation_id)`
- **UNIQUE** `import_jobs_organisation_id_source_namespace_file_sha256_key`: `UNIQUE (organisation_id, source_namespace, file_sha256)`

</details>

<details><summary>Indexes</summary>

- `INDEX import_jobs_org_idx ON import_jobs USING btree (organisation_id, uploaded_at DESC)`
- `INDEX import_jobs_pending_idx ON import_jobs USING btree (status, updated_at) WHERE (status = ANY (ARRAY['uploaded'::text, 'validating'::text, 'approved'::text, 'applying'::text]))`

</details>

<details><summary>Triggers & policies</summary>

- trigger `import_jobs_no_delete` → `trg_forbid_delete()`
- trigger `import_jobs_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### import_rows

Staged rows with raw source payload (provenance), normalised values, findings [{severity, field, code, message}] and outcome.

*RLS:* enabled · *Archival:* — · *Deletion:* no DELETE grant; purge job deferred · *Retention:* 180 days (planned purge)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `import_job_id` | uuid |  |  |  |
| `organisation_id` | uuid |  |  |  |
| `row_number` | integer |  |  |  |
| `source_record_id` | text | yes |  |  |
| `raw` | jsonb |  |  |  |
| `normalized` | jsonb | yes |  |  |
| `payload_sha256` | character(64) | yes |  |  |
| `status` | text |  | `'pending'::text` |  |
| `findings` | jsonb |  | `'[]'::jsonb` | JSONB array of validation findings; variable length and shape per rule (justified). Filter with findings @> '[{"code":"..."}]'. |
| `planned_action` | text | yes |  |  |
| `match_method` | text | yes |  |  |
| `matched_vehicle_id` | uuid | yes |  |  |
| `matched_listing_id` | uuid | yes |  |  |
| `result` | jsonb | yes |  |  |
| `applied_at` | timestamp with time zone | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `import_rows_findings_check`: `CHECK ((jsonb_typeof(findings) = 'array'::text))`
- **CHECK** `import_rows_match_method_check`: `CHECK ((match_method = ANY (ARRAY['source_mapping'::text, 'vin'::text, 'stock_number'::text, 'none'::text, 'proposal'::text])))`
- **CHECK** `import_rows_planned_action_check`: `CHECK ((planned_action = ANY (ARRAY['create'::text, 'update'::text, 'no_change'::text, 'reject'::text])))`
- **CHECK** `import_rows_row_number_check`: `CHECK ((row_number > 0))`
- **CHECK** `import_rows_status_check`: `CHECK ((status = ANY (ARRAY['pending'::text, 'valid'::text, 'warning'::text, 'invalid'::text, 'applied'::text, 'no_change'::text, 'skipped'::text, 'failed'::text])))`
- **FK** `import_rows_import_job_id_organisation_id_fkey`: `FOREIGN KEY (import_job_id, organisation_id) REFERENCES import_jobs(id, organisation_id)`
- **FK** `import_rows_matched_listing_id_fkey`: `FOREIGN KEY (matched_listing_id) REFERENCES listings(id)`
- **FK** `import_rows_matched_vehicle_id_fkey`: `FOREIGN KEY (matched_vehicle_id) REFERENCES vehicles(id)`
- **PK** `import_rows_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `import_rows_import_job_id_row_number_key`: `UNIQUE (import_job_id, row_number)`

</details>

<details><summary>Indexes</summary>

- `INDEX import_rows_findings_gin ON import_rows USING gin (findings jsonb_path_ops)`
- `INDEX import_rows_job_status_idx ON import_rows USING btree (import_job_id, status)`

</details>

<details><summary>Triggers & policies</summary>

- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### source_record_mappings

External source record -> internal vehicle/listing. Drives idempotent re-imports (payload hash) and stale-update rejection (last_source_updated_at).

*RLS:* enabled · *Archival:* — · *Deletion:* no DELETE grant · *Retention:* while source active

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid |  |  |  |
| `source_namespace` | text |  |  |  |
| `source_record_id` | text |  |  |  |
| `vehicle_id` | uuid |  |  |  |
| `listing_id` | uuid | yes |  |  |
| `last_source_updated_at` | timestamp with time zone | yes |  |  |
| `last_payload_sha256` | character(64) | yes |  |  |
| `last_import_job_id` | uuid | yes |  |  |
| `last_seen_at` | timestamp with time zone |  | `now()` |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `updated_at` | timestamp with time zone |  | `now()` |  |
| `version` | integer |  | `1` |  |

<details><summary>Constraints</summary>

- **FK** `source_record_mappings_last_import_job_id_fkey`: `FOREIGN KEY (last_import_job_id) REFERENCES import_jobs(id)`
- **FK** `source_record_mappings_listing_id_fkey`: `FOREIGN KEY (listing_id) REFERENCES listings(id)`
- **FK** `source_record_mappings_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **FK** `source_record_mappings_vehicle_id_fkey`: `FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)`
- **PK** `source_record_mappings_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `source_record_mappings_organisation_id_source_namespace_sou_key`: `UNIQUE (organisation_id, source_namespace, source_record_id)`

</details>

<details><summary>Indexes</summary>

- `INDEX source_record_mappings_vehicle_idx ON source_record_mappings USING btree (vehicle_id)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `source_record_mappings_touch` → `trg_touch_row()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>


---

## Operations

### outbox_events

Transactional outbox: written in the same transaction as the domain change; a worker publishes with FOR UPDATE SKIP LOCKED, exponential backoff and a dead-letter status after max_attempts. Consumers dedupe on id.

*RLS:* enabled · *Archival:* published / dead · *Deletion:* no DELETE grant; purge job deferred · *Retention:* 30 days after publish (planned)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `organisation_id` | uuid | yes |  |  |
| `aggregate_type` | text |  |  |  |
| `aggregate_id` | uuid |  |  |  |
| `event_type` | text |  |  |  |
| `payload` | jsonb |  |  |  |
| `status` | text |  | `'pending'::text` |  |
| `attempts` | integer |  | `0` |  |
| `max_attempts` | integer |  | `8` |  |
| `available_at` | timestamp with time zone |  | `now()` |  |
| `last_error` | text | yes |  |  |
| `request_id` | text | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `published_at` | timestamp with time zone | yes |  |  |

<details><summary>Constraints</summary>

- **CHECK** `outbox_events_attempts_check`: `CHECK ((attempts >= 0))`
- **CHECK** `outbox_events_check`: `CHECK (((status = 'published'::text) = (published_at IS NOT NULL)))`
- **CHECK** `outbox_events_check1`: `CHECK ((attempts <= max_attempts))`
- **CHECK** `outbox_events_event_type_check`: `CHECK ((event_type ~ '^[a-z_]+\.[a-z_.]+$'::text))`
- **CHECK** `outbox_events_max_attempts_check`: `CHECK (((max_attempts >= 1) AND (max_attempts <= 50)))`
- **CHECK** `outbox_events_payload_check`: `CHECK ((jsonb_typeof(payload) = 'object'::text))`
- **CHECK** `outbox_events_status_check`: `CHECK ((status = ANY (ARRAY['pending'::text, 'published'::text, 'dead'::text])))`
- **FK** `outbox_events_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **PK** `outbox_events_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `INDEX outbox_events_aggregate_idx ON outbox_events USING btree (aggregate_type, aggregate_id, created_at)`
- `INDEX outbox_events_dead_idx ON outbox_events USING btree (created_at) WHERE (status = 'dead'::text)`
- `INDEX outbox_events_pending_idx ON outbox_events USING btree (available_at) WHERE (status = 'pending'::text)`

</details>

<details><summary>Triggers & policies</summary>

- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### audit_events

Application audit trail: actor, organisation, action, target, time, request id and redacted changes. Append-only for the application role (no UPDATE/DELETE grants + trigger). Not tamper-proof against a database superuser; see docs/SECURITY.md for stronger measures.

*RLS:* enabled · *Archival:* — · *Deletion:* append-only + TRUNCATE trigger · *Retention:* 7 years

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | bigint |  |  |  |
| `occurred_at` | timestamp with time zone |  | `clock_timestamp()` |  |
| `request_id` | text | yes |  |  |
| `actor_user_id` | uuid | yes |  |  |
| `actor_kind` | text |  |  |  |
| `actor_organisation_id` | uuid | yes |  |  |
| `organisation_id` | uuid | yes |  |  |
| `action` | text |  |  |  |
| `target_type` | text |  |  |  |
| `target_id` | text |  |  |  |
| `changes` | jsonb |  | `'{}'::jsonb` | Redacted before/after field values. Secrets, tokens, signatures and contact details are never written here. |
| `metadata` | jsonb |  | `'{}'::jsonb` |  |

<details><summary>Constraints</summary>

- **CHECK** `audit_events_action_check`: `CHECK ((action ~ '^[a-z_]+\.[a-z_]+$'::text))`
- **CHECK** `audit_events_actor_kind_check`: `CHECK ((actor_kind = ANY (ARRAY['user'::text, 'system'::text, 'provider'::text, 'import'::text, 'unknown'::text])))`
- **CHECK** `audit_events_changes_check`: `CHECK ((jsonb_typeof(changes) = 'object'::text))`
- **CHECK** `audit_events_metadata_check`: `CHECK ((jsonb_typeof(metadata) = 'object'::text))`
- **FK** `audit_events_actor_organisation_id_fkey`: `FOREIGN KEY (actor_organisation_id) REFERENCES organisations(id)`
- **FK** `audit_events_actor_user_id_fkey`: `FOREIGN KEY (actor_user_id) REFERENCES app_users(id)`
- **FK** `audit_events_organisation_id_fkey`: `FOREIGN KEY (organisation_id) REFERENCES organisations(id)`
- **PK** `audit_events_pkey`: `PRIMARY KEY (id)`

</details>

<details><summary>Indexes</summary>

- `INDEX audit_events_org_time_idx ON audit_events USING btree (organisation_id, occurred_at DESC)`
- `INDEX audit_events_request_idx ON audit_events USING btree (request_id) WHERE (request_id IS NOT NULL)`
- `INDEX audit_events_target_idx ON audit_events USING btree (target_type, target_id, occurred_at DESC)`

</details>

<details><summary>Triggers & policies</summary>

- trigger `audit_events_append` → `trg_append_only()`
- trigger `audit_events_no_truncate` → `trg_append_only()`
- policy `tenant_rw` (ALL): USING `app_can_access_org(organisation_id)`

</details>

### idempotency_keys

Stored responses for Idempotency-Key requests. The row is inserted at the start of the request transaction, so a concurrent duplicate blocks on the unique index and then replays the committed response. Errors roll the key back (retry is safe).

*RLS:* not enabled (reference / platform table) · *Archival:* expires_at · *Deletion:* DELETE allowed after expiry · *Retention:* 7 days

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `scope` | text |  |  |  |
| `key` | text |  |  |  |
| `method` | text |  |  |  |
| `path` | text |  |  |  |
| `request_sha256` | character(64) |  |  |  |
| `response_status` | integer | yes |  |  |
| `response_body` | jsonb | yes |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |
| `completed_at` | timestamp with time zone | yes |  |  |
| `expires_at` | timestamp with time zone |  | `(now() + '7 days'::interval)` |  |

<details><summary>Constraints</summary>

- **CHECK** `idempotency_keys_key_check`: `CHECK (((length(key) >= 8) AND (length(key) <= 200)))`
- **PK** `idempotency_keys_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `idempotency_keys_scope_key_key`: `UNIQUE (scope, key)`

</details>

<details><summary>Indexes</summary>

- `INDEX idempotency_keys_expiry_idx ON idempotency_keys USING btree (expires_at)`

</details>

### worker_heartbeats

Liveness of background workers, surfaced by /v1/health/ready and the admin overview.

*RLS:* not enabled (reference / platform table)

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `worker_name` | text |  |  |  |
| `last_beat_at` | timestamp with time zone |  | `now()` |  |
| `details` | jsonb |  | `'{}'::jsonb` |  |

<details><summary>Constraints</summary>

- **PK** `worker_heartbeats_pkey`: `PRIMARY KEY (worker_name)`

</details>

### admin_saved_filters

Per-staff-user saved table filters in the administration UI. Deletable.

*RLS:* enabled · *Archival:* — · *Deletion:* DELETE allowed · *Retention:* until removed

| column | type | null | default / generated | notes |
|---|---|---|---|---|
| `id` | uuid |  | `uuid_v7()` |  |
| `user_id` | uuid |  |  |  |
| `page` | text |  |  |  |
| `name` | text |  |  |  |
| `params` | jsonb |  |  |  |
| `created_at` | timestamp with time zone |  | `now()` |  |

<details><summary>Constraints</summary>

- **CHECK** `admin_saved_filters_name_check`: `CHECK (((length(name) >= 1) AND (length(name) <= 80)))`
- **CHECK** `admin_saved_filters_page_check`: `CHECK ((page ~ '^[a-z_-]+$'::text))`
- **CHECK** `admin_saved_filters_params_check`: `CHECK ((jsonb_typeof(params) = 'object'::text))`
- **FK** `admin_saved_filters_user_id_fkey`: `FOREIGN KEY (user_id) REFERENCES app_users(id)`
- **PK** `admin_saved_filters_pkey`: `PRIMARY KEY (id)`
- **UNIQUE** `admin_saved_filters_user_id_page_name_key`: `UNIQUE (user_id, page, name)`

</details>

<details><summary>Triggers & policies</summary>

- policy `admin_saved_filters_self` (ALL): USING `(user_id = app_user_id())`

</details>

