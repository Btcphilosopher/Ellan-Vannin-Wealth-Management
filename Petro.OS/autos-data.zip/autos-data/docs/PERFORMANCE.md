# Performance report

**Scope and honesty statement.** These are single-machine measurements on a synthetic dataset, intended to show that the query patterns are index-backed and that the concurrency controls behave correctly under contention. They are **not** a capacity claim: no representative load test (realistic request mix, network, replicas, production-sized hardware, sustained duration) has been run. Do not extrapolate them to enterprise-scale throughput.

## Environment

| item | value |
|---|---|
| PostgreSQL | 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1) (default config: shared_buffers 128MB, work_mem 4MB) |
| PostGIS | 3.4.2 |
| CPUs visible | 4 (x86_64), shared cloud container |
| Python | 3.13.18; API: uvicorn, 4 workers |
| Database size | 827 MB |

## Synthetic dataset (`backend/perf/generate_dataset.py`)

Seed data plus 60 synthetic dealers × 8 locations scattered uniformly across the contiguous US, 200,000 vehicles with VIN identifiers, one listing each (90 % published) with a price version, 50,000 customers, 50,000 reservations (80 % ended), and 3 audit events per listing. Generated set-based as the owner **with all integrity triggers firing** (status history, commitment rows), deterministic via `setseed`.

| table | rows |
|---|---|
| vehicles | 200,039 |
| listings | 200,029 |
| listing_price_versions | 200,035 |
| sale_reservations | 55,104 |
| audit_events | 600,114 |
| locations | 486 |
| customers | 50,014 |

## Read queries (database level, as the RLS-subject application role)

Each query: 20 warm-up runs, then 200 timed runs with varying parameters; `EXPLAIN (ANALYZE, BUFFERS)` plans are in [`perf/plans/`](perf/plans/).

| query | p50 ms | p95 ms | p99 ms | max ms | plan (main nodes) |
|---|---|---|---|---|---|
| radius_search_50km_price_band (customer context, public listings) | 1.543 | 3.663 | 3.798 | 6.902 | ->  Nested Loop; ->  Index Scan using listings_status_location_idx on listings l; ->  Index Scan using listing_price_versions_pkey on listing_price_versions p |
| dealer_inventory_page (dealer context) | 0.218 | 0.277 | 0.313 | 0.501 | ->  Index Scan using listings_org_status_idx on listings l |
| vin_lookup (dealer context, RLS via vehicle visibility) | 0.222 | 0.376 | 0.438 | 0.501 | Index Scan using vehicle_identifiers_lookup_idx on vehicle_identifiers; ->  Index Scan using vehicles_pkey on vehicles v; ->  Index Scan using listings_vehicle_idx on listings l |
| listing_audit_history (dealer context) | 0.134 | 0.176 | 0.257 | 0.376 | ->  Index Scan using audit_events_target_idx on audit_events |
| listing_detail_with_price_history (dealer context) | 0.214 | 0.296 | 0.378 | 0.513 | Nested Loop Left Join; ->  Index Scan using listings_id_currency_key on listings l; ->  Index Scan using listing_price_versions_listing_id_tstzrange_excl on listing_price_versions p |
| reservation_funnel_report (dealer context) | 6.887 | 8.504 | 9.864 | 11.53 | ->  Bitmap Heap Scan on sale_reservations; ->  Bitmap Index Scan on sale_reservations_org_status_idx |

## HTTP end-to-end (curl `time_total`, keep-alive off, 60 timed requests after 5 warm-up)

Includes JWT verification, principal/membership lookup, tenant-context setup, the query, serialisation and response.

| endpoint | p50 ms | p95 ms | max ms |
|---|---|---|---|
| GET /v1/listings radius 50km (Denver) | 20.09 | 25.84 | 368.38 |
| GET /v1/listings radius 100km (Chicago) | 31.68 | 33.79 | 35.53 |
| GET /v1/listings published page | 21.53 | 23.49 | 25.82 |
| GET /v1/listings dealer page (all statuses) | 19.65 | 22.22 | 22.69 |
| GET /v1/reports/overview | 10.55 | 12.72 | 15.68 |
| GET /v1/me | 6.0 | 7.87 | 8.91 |

## Reservation writes (database transactions, full trigger path)

- **Sequential hold creation** (each its own transaction: tenant context, vehicle row lock, commitment row, status event): n=300, p50 1.477 ms, p95 1.988 ms, max 16.013 ms.
- **4 concurrent clients, distinct vehicles**: 600 transactions in 0.55 s ≈ **1084.0 tx/s**, errors 0.
- **16 concurrent clients, distinct vehicles**: 800 transactions in 0.99 s ≈ **806.8 tx/s**, errors 0.
- **32 concurrent clients, same vehicle**: outcomes {'ok': 1, 'Z9001': 31} (Z9001 = `vehicle_already_reserved`); longest wait 123.0 ms. Exactly one commitment was created.

## What the plans showed, and what was changed (migration `0014_query_indexes`)

The first run exposed four problems; each fix was re-measured on the same dataset.

| finding (first run) | cause | fix | before → after (p50) |
|---|---|---|---|
| VIN lookup 12.2 ms | only index was the uniqueness index `(namespace, issuing_organisation_id, value_normalized)`; the issuer column in the middle forced a scan of every VIN | `vehicle_identifiers_lookup_idx (namespace, value_normalized) WHERE retired_at IS NULL` | 12.2 → ~0.2 ms |
| Dealer inventory page 7.3 ms | keyset order is `(updated_at DESC, id DESC)` but the index lacked `id` → incremental sort of ~3,000 rows | `listings_org_status_idx (organisation_id, status, updated_at DESC, id DESC)`, `listings_status_updated_idx`, `listings_updated_idx` | 7.3 → ~0.2 ms |
| HTTP radius search 364 ms | (a) PostGIS functions are not `LEAKPROOF`, so under RLS `ST_DWithin` was evaluated as a filter instead of a GiST index condition; (b) the planner assumed ~411 listings per location and walked the whole date index | `locations_within()` SECURITY DEFINER lookup (active locations are public data) feeding a constant id list; for radius queries the ORDER BY uses an equivalent non-indexable expression so the planner filters by location first | 364 → ~20 ms |
| HTTP list endpoints 160–220 ms | N+1 serialisation (~10 queries per listing) | `listings.summaries()` builds a page in one query | dealer page 164 → ~20 ms |

A note on method: an early HTTP measurement using a Python keep-alive client reported a constant ~44 ms even for `/v1/health/live`. curl showed 2–3 ms for the same endpoint, so that floor was a client/TCP delayed-ACK artefact, not server time. The HTTP figures above use curl.

## Known limits / next steps

* `GET /v1/sale-reservations` and `GET /v1/vehicles` still serialise row-by-row (N+1); fine at page size 50 but should get the `summaries()` treatment before high traffic.
* Reports (`reservation_funnel_report` ~7 ms) aggregate on the fly; materialised rollups would be needed at much larger volumes.
* Not measured: write throughput through the full HTTP stack under mixed load, replica lag, connection-pool sizing under saturation, long-running vacuum/bloat behaviour, and multi-node deployment.

Reproduce:

```bash
python -m perf.generate_dataset            # AUTOS_MIGRATION_DATABASE_URL -> a seeded database
AUTOS_PERF_APP_URL=postgresql://autos_api:...@host/db AUTOS_PERF_OWNER_URL=postgresql://autos_owner:...@host/db \
AUTOS_PERF_API=http://localhost:8020 python -m perf.run_perf --out ../docs/perf
```
