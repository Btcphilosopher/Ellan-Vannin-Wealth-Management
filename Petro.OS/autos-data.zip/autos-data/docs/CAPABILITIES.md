# Capability status

Every capability is labelled with exactly one status:

* **Implemented** — production-shaped code in this repository, exercised by tests against real PostgreSQL.
* **Integrated** — implemented against a real external component (PostgreSQL/PostGIS, S3 API, Docker) and exercised end to end.
* **Simulated** — a stand-in for an external system, clearly separated from the authoritative model (do not deploy as-is).
* **Deferred** — designed/documented but not built.

## Data platform

| capability | status | evidence |
|---|---|---|
| Normalised schema (55 tables), FKs, CHECKs, exclusion constraints, triggers | Implemented | `backend/migrations/sql/0001–0014`, `tests/test_integrity_constraints.py` |
| Alembic migration management with up/down for every revision | Implemented | `tests/test_schema_and_money.py::test_downgrade_to_base_and_upgrade_again` |
| ORM models mirror schema; drift test | Implemented | `scripts/gen_models.py`, `test_orm_models_match_database` |
| PostGIS radius search (geography, GiST) | Integrated | `locations_within()`, `docs/PERFORMANCE.md` |
| Row-level security + backend authorisation + pooled-connection hygiene | Implemented | `0012_security.sql`, `tests/test_tenant_isolation.py` |
| Optimistic concurrency (ETag / If-Match, DB-bumped version) | Implemented | `test_if_match_required_and_enforced`, `test_concurrent_versioned_updates_one_wins` |
| Idempotency keys (generic + domain-level) | Implemented | `test_reservation_idempotency_replay_and_mismatch`, `test_concurrent_identical_payment_requests_create_one_intent` |
| Money as integer minor units + explicit currency | Implemented | `app/money.py`, money tests |
| Append-only history (audit, status events, transactions, quote lines) | Implemented | triggers + grants; `test_history_is_append_only_even_for_owner` |

## Workflows

| capability | status | notes |
|---|---|---|
| Vehicle identity: namespaced identifiers, VIN validation, provenance assertions | Implemented | manufacturer / seller claim / inspection / import kept separate |
| Uncertain-match merge proposals (never auto-merge on weak evidence) | Implemented | `test_weak_match_creates_merge_proposal_not_merge` |
| Listings: draft → published → suspended/withdrawn/sold, validation findings, price versions | Implemented | transitions enforced in service **and** trigger |
| Source freshness: warn or suspend per organisation policy | Implemented | `listings.evaluate_freshness` worker; never fabricates availability |
| Immutable itemised quotes with snapshot hash, incomplete-quote handling | Implemented | `test_quotes_and_locking.py` |
| Concurrency-safe sale reservations (one commitment per physical vehicle across listings) | Implemented | 20-thread test + 32-client perf contention test |
| Expiry under the same lock; sweeper optional | Implemented | `test_lapsed_hold_is_expired_inline_without_worker` |
| Hold / deposit / dealer acceptance / agreement / handover / completion kept separate | Implemented | `test_lifecycle_stages_are_separate` |
| Completion refused while a balance is outstanding (explicit, reasoned, audited override for third-party finance) | Implemented | `test_completion_override_requires_reason_and_is_audited` |
| Test drives: vehicle exclusivity, resource capacity, availability policy | Implemented | `test_scheduling.py` |
| Rentals: category capacity (locked buckets), exact-asset exclusion, buffers, maintenance, DST-safe days | Implemented | `test_scheduling.py` |
| One-way rentals (return elsewhere) | **Deferred** | rejected by CHECK; needs fleet relocation model |
| Imports: CSV/JSON → staging → validation → preview → approval → application | Implemented | `test_imports_outbox_audit.py` |
| CSV export protected against formula injection | Implemented | `test_csv_export_neutralises_formulas` |
| Payments: idempotent intents, verified webhooks, dedupe, ordering, late settlement → case | Implemented | `test_payments.py` |
| Refunds: partial, limit enforced under concurrency, reconciliation auto-resolve | Implemented | `test_concurrent_refunds_never_exceed_capture` |
| Unknown-outcome reconciliation worker | Implemented | `test_unknown_outcome_is_reconciled_by_worker` |
| Payment provider | **Simulated** | `app/simulator.py`, schema `simpay`; HMAC-signed events; no card data anywhere |
| General ledger (double-entry postings) | **Deferred** | `payment_transactions` is a transaction record, explicitly *not* a ledger |
| Settlement-file (bank/provider report) reconciliation | **Deferred** | case model supports it; importer not built |

## Platform & operations

| capability | status | notes |
|---|---|---|
| FastAPI service, OpenAPI 3.1 (`docs/openapi.json`, `/docs`) | Implemented | 85 paths |
| Authentication | **Simulated** | `POST /v1/auth/token` is a dev HS256 issuer; replace with OIDC (validate issuer/audience/JWKS) |
| Transactional outbox, SKIP LOCKED dispatch, backoff, dead letter, requeue | Implemented | `test_outbox_retry_backoff_and_dead_letter` |
| Outbox consumer / message broker | **Deferred** | publisher posts to a webhook URL or log; Kafka/SNS adapters not built |
| Background workers (expiry, outbox, reconciliation, freshness, import retry), heartbeats | Implemented | `python -m app.workers` |
| S3-compatible object storage (images, documents, import files) | Integrated (S3 API) | verified against an S3-compatible server (moto) in this environment; MinIO is the Compose default but its image could not be pulled here |
| Backups (`pg_dump -Fc` + checksum + counts) and restore into a clean cluster with invariant checks | Integrated | `scripts/restore_drill.sh`, run locally **and** as the Compose `restore-drill` container |
| Point-in-time recovery (WAL archiving) | **Deferred** | documented in `OPERATIONS.md` |
| Docker Compose stack | Integrated (partially executed) | `db` and `restore-drill` services executed here; `api`/`worker`/`admin`/`minio` images could not be pulled/built in this sandbox (Docker Hub rate limit, no build network). The same code ran natively against the Compose database (101 tests passed). |
| Admin UI (React + TypeScript) | Implemented | `admin/`; `npm run build` clean; Playwright click-through of all 13 sections, cross-dealer check and permission-denied paths; see `admin/README.md` and `docs/screenshots/`. Its Docker image was not built here (no registry access). |
| Cursor pagination on imports / outbox / refunds / reconciliation lists | **Deferred** | these return the latest 200; main entity lists are keyset-paginated |
| Create-listing / create-vehicle / media-upload / customer-erasure screens in the UI | **Deferred** (API implemented) | available via the API |
| Notifications to customers (email/SMS) | **Deferred** | outbox events exist (`test_drive.cancel`, `sale_reservation.expired`…); no sender |
| Data-retention purge jobs (import rows, published outbox) | **Deferred** | retention periods defined in the data dictionary |
| External audit tamper-evidence (hash chain / WORM export) | **Deferred** | see `SECURITY.md` |
