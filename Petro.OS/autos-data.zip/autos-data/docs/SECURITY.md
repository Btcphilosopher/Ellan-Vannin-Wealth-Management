# Security, tenancy and audit

## Access model

* **Backend authorisation** on every request: role → permission matrix in `app/security.py` (`platform_admin`, `dealer_admin`, `dealer_staff`, `rental_admin`, `rental_agent`, `finance`, `auditor`, plus customer principals). `X-Organisation-Id` narrows a multi-org user to one tenant.
* **PostgreSQL row-level security** as defence in depth (`0012_security.sql`): every tenant table has a policy; writes have `WITH CHECK`. Published listings, their price versions/vehicles and active locations are deliberately public. Customers are visible only to themselves, the registering organisation, or organisations with a recorded `customer_relationships` row.
* **Least privilege roles**: the API/worker log in as `autos_api` (member of `autos_app`, `NOBYPASSRLS`, not owner). No DDL, no `TRUNCATE`, no `DELETE` on business history, column-level `UPDATE` grants on otherwise frozen tables, no direct writes to `vehicle_current_reservations`.
* **No unrestricted SQL** anywhere in the API or UI; status changes only via domain actions.

### Tenant context and connection pools

Context is set with `set_config(name, value, is_local => true)` at the start of each transaction (and re-applied by an `after_begin` hook). Transaction-local settings vanish at COMMIT/ROLLBACK, so a pooled connection cannot carry tenant A's context into tenant B's request. `test_pooled_connection_does_not_leak_tenant_context` proves this with a pool of size 1 on both commit and rollback paths, and that an un-contexted transaction sees **zero** tenant rows.

### SECURITY DEFINER functions

Used only where a trigger must see across tenants to keep an invariant (e.g. expiring another customer's lapsed hold before granting a new one) or for public-data lookups (`locations_within`). All pin `search_path = public, pg_temp`. They return only what the invariant needs (`vin_registered_elsewhere` returns a boolean, never the other tenant's data).

### Known RLS performance pitfall (handled)

PostGIS functions are not `LEAKPROOF`, so under RLS the planner may refuse to use them as index conditions. Radius search therefore resolves nearby *public* locations through an index-backed SECURITY DEFINER function. See `PERFORMANCE.md`.

## Sensitive data

* **No card data**: the provider holds instruments; we store provider references, amounts and verified outcomes. `test_no_card_data_columns_exist` checks the schema.
* **Webhooks**: HMAC-SHA256 over `timestamp.body`, constant-time comparison, 5-minute replay window; unverified bodies are rejected and never stored.
* **Audit redaction**: keys matching secrets/tokens/signatures and contact PII (email, phone, names, address lines) are replaced with `[redacted]` before writing `audit_events.changes` (`test_audit_records_actor_request_and_redacts`).
* **Customer erasure** anonymises PII but keeps the row, so commercial history stays referentially intact.
* **CSV exports** neutralise spreadsheet formulas (`=`, `+`, `-`, `@`, tab, CR/LF, `|`, `%` prefixes) per OWASP guidance.
* **Demo data** is fictional; VINs use prefix `SYN`/`TST`/`PRF` and `is_synthetic = true`.

## Audit trail — what it is and is not

`audit_events` records actor, actor organisation, target organisation, action, target, timestamp, request id, redacted changes and metadata. Under normal permissions it is **append-only**: the application role has no UPDATE/DELETE/TRUNCATE privilege, and row/statement triggers reject modification even by the owner.

It is **not** absolutely immutable: a PostgreSQL superuser (or the owner, by disabling triggers) can alter it, and a backup can be edited before restore. Stronger tamper-resistance, recommended for production and **not implemented here**:

1. **Hash chaining** — each row stores `sha256(prev_hash ‖ canonical(row))`, computed under a lock or per-partition sequence; a verifier recomputes the chain.
2. **External anchoring** — periodically publish the latest chain head (or a Merkle root per day) to a separate system the database administrators cannot write (e.g. an object-lock bucket, a transparency log).
3. **WORM export** — stream audit rows via the outbox to object storage with S3 Object Lock (compliance mode) or an append-only SIEM.
4. **Separation of duties** — DBA credentials distinct from application admins; `pgaudit` for superuser activity; alert on `ALTER TABLE … DISABLE TRIGGER`.

## Branding

The brand name, product line and disclaimer come from configuration (`AUTOS_BRAND_*`) and `/v1/branding`. The default disclaimer states the software is independent concept software, not affiliated with Amazon or any marketplace operator; nothing in the code implies access to Amazon infrastructure.
