# API guide

Machine-readable contract: [`openapi.json`](openapi.json) (OpenAPI 3.1, 85 paths). Interactive docs: `http://localhost:8000/docs` (Swagger UI) and `/redoc`.

## Conventions

| topic | rule |
|---|---|
| Auth | `Authorization: Bearer <token>`. `POST /v1/auth/token {"email"}` is a **development** issuer (disable with `AUTOS_ENABLE_DEV_AUTH=false`). Optional `X-Organisation-Id` narrows scope to one membership. |
| Errors | RFC 9457 `application/problem+json`: `{type, title, status, code, detail, request_id, errors?}`. `code` is stable and machine-readable. |
| Request ids | Send `X-Request-Id` (8–64 chars) or one is generated; it is echoed and written to audit events. |
| Pagination | Keyset: `?limit=1..200&cursor=…`; response `{items, next_cursor}`. Cursors are opaque. Audit uses `before_id`. |
| Filtering | Explicit query parameters per endpoint (see OpenAPI). No free-form query language. |
| Versions | Mutable resources return `ETag: "<version>"` and a `version` field. PATCH and domain actions require `If-Match: "<version>"`. Missing → **428** `precondition_required`; stale → **409** `version_conflict` (body includes `current_version`). |
| Idempotency | `Idempotency-Key` (8–200 chars) on consequential POSTs. Same key + same body → stored response replayed with `Idempotent-Replayed: true`. Same key + different body → **422** `idempotency_key_reused`. Errors are not stored (a failed attempt can be retried). Required for `/v1/payments` and `/v1/refunds`. Concurrent duplicates block on a unique index and then replay. |
| Money | `*_minor` integers + `currency` (ISO 4217). Inputs that take major units (`price: "32900.00"`) are parsed exactly; excess precision and floats are rejected. |
| Time | ISO 8601 **with offset**; naive timestamps → 422 `naive_timestamp`. Local display fields (`local_start`, `local_pickup`) use the location's IANA zone. Intervals are half-open `[start, end)`. |
| Permissions | 403 `permission_denied` when you can see a record but lack the action permission; **404** when the record is outside your tenant (existence is not disclosed). |

## Selected error codes

| HTTP | code | meaning |
|---|---|---|
| 409 | `vehicle_already_reserved` | another reservation/sale order commits this physical vehicle |
| 409 | `hold_expired` | the temporary hold lapsed (acceptance/deposit refused) |
| 409 | `deposit_outstanding` | dealer acceptance requires a settled deposit |
| 409 | `balance_outstanding` | sale completion while money is owed; override with `accept_outstanding_balance` + `reason` (audited) |
| 409 | `invalid_status_transition` | action not allowed from the current state |
| 409 | `immutable_record` / `append_only` | history cannot be changed |
| 409 | `rental_capacity_exceeded` / `rental_asset_conflict` / `maintenance_overlap` | rental conflicts |
| 409 | `vehicle_slot_conflict` / `resource_capacity_exceeded` | test-drive conflicts |
| 422 | `publication_blocked` | `errors[]` lists validation findings |
| 422 | `quote_not_acceptable` | incomplete, expired, accepted, or wrong customer |
| 422 | `refund_limit_exceeded` | refunds would exceed the capture |
| 422 | `import_has_invalid_rows` | all-or-nothing import cannot be approved |
| 401 | `invalid_signature` | provider webhook failed HMAC/timestamp verification |

## Endpoint map (abridged — see OpenAPI for all 85)

```
Auth        POST /v1/auth/token · GET /v1/me
Catalogue   GET /v1/catalogue/trims · GET /v1/catalogue/trims/{id}/specifications
Vehicles    GET|POST /v1/vehicles · GET|PATCH /v1/vehicles/{id} · GET|POST /v1/vehicles/{id}/assertions
            POST /v1/vehicles/{id}/media · GET /v1/vehicle-merge-proposals · POST …/{id}/decision
Listings    GET|POST /v1/listings · GET|PATCH /v1/listings/{id} · GET /v1/listings/{id}/validation
            POST /v1/listings/{id}/publish|suspend|withdraw · POST /v1/listings/{id}/prices
            POST /v1/listings/publication-batch · GET /v1/listings/export.csv
Dealers     GET /v1/organisations · GET /v1/organisations/{id}
Customers   GET|POST /v1/customers · GET|PATCH /v1/customers/{id} · POST /v1/customers/{id}/erasure
            GET /v1/me/saved-vehicles · PUT /v1/me/saved-vehicles/{listing_id} · POST /v1/me/saved-searches
Quotes      POST|GET /v1/quotes · GET /v1/quotes/{id} · POST /v1/quotes/{id}/acceptance
Reservations POST|GET /v1/sale-reservations · GET /v1/sale-reservations/{id}
            POST /v1/sale-reservations/{id}/acceptance|cancellation|sale-order
            GET /v1/sale-orders/{id}   (completion refuses while a balance is outstanding unless explicitly overridden)
            · POST /v1/sale-orders/{id}/agreement|handover|completion|cancellation
Test drives GET /v1/appointment-resources · POST|GET /v1/test-drive-appointments
            POST /v1/test-drive-appointments/{id}/confirmation|decline|cancellation|completion|no-show
Rentals     GET /v1/rental-categories · GET /v1/rental-assets · GET /v1/rental-availability
            POST /v1/rental-quotes · POST|GET /v1/rental-bookings · GET /v1/rental-bookings/{id}
            POST /v1/rental-bookings/{id}/assignment|cancellation|check-out|return|no-show · POST /v1/maintenance-blocks
Payments    POST|GET /v1/payments · GET /v1/payments/{id} · POST /v1/providers/{provider}/events
            POST|GET /v1/refunds · GET /v1/reconciliation-cases · POST /v1/reconciliation-cases/{id}/resolution
Imports     POST|GET /v1/import-jobs · GET /v1/import-jobs/{id} · GET /v1/import-jobs/{id}/rows
            POST /v1/import-jobs/{id}/approval|rejection
Audit       GET /v1/audit-events · GET /v1/outbox-events · POST /v1/outbox-events/{id}/requeue
Reports     GET /v1/reports/{overview|inventory|reservations|payments|rentals|imports|data-quality}
Operations  GET /v1/health/live · GET /v1/health/ready · GET /v1/branding · GET|POST|DELETE /v1/saved-filters
Simulator   POST /v1/dev/simpay/payments/{ref}/settle · POST /v1/dev/simpay/refunds/{ref}/settle   (SIMULATED)
```

## Example: reserve → deposit → accept

```bash
TOKEN=$(curl -s -XPOST localhost:8000/v1/auth/token -H 'content-type: application/json' \
  -d '{"email":"admin@harbourview.example"}' | jq -r .access_token)
curl -s -XPOST localhost:8000/v1/sale-reservations -H "Authorization: Bearer $TOKEN" \
  -H 'Idempotency-Key: 5d0f6a52-hold-001' -H 'content-type: application/json' \
  -d '{"listing_id":"<listing>","customer_id":"<customer>"}'
curl -s -XPOST localhost:8000/v1/payments -H "Authorization: Bearer $TOKEN" \
  -H 'Idempotency-Key: 5d0f6a52-dep-001' -H 'content-type: application/json' \
  -d '{"purpose":"sale_deposit","sale_reservation_id":"<reservation>"}'
curl -s -XPOST localhost:8000/v1/sale-reservations/<reservation>/acceptance \
  -H "Authorization: Bearer $TOKEN" -H 'If-Match: "3"'
```

A complete, executed walkthrough of every scenario is in [`DEMO_TRANSCRIPT.md`](DEMO_TRANSCRIPT.md).
