# Test results

Run: 2026-11-26 19:57 UTC · **104 passed in 39.35s** · JUnit XML: [`test-results.xml`](test-results.xml)

**Database under test:** the Docker Compose `db` service (`postgis/postgis:16-3.5` → PostgreSQL 16.9, PostGIS 3.5) initialised by `ops/db-init/`, with a **non-superuser** schema owner; the API and services connect as `autos_api` (RLS enforced). No SQLite, no database mocks. The suite also passes (101 tests; S3 test skipped) against a local PostgreSQL 16.15 / PostGIS 3.4 install.

**Object storage:** `test_object_storage.py` ran against an S3-compatible server (`moto_server`) because the MinIO image could not be pulled in this sandbox.

Command:

```bash
cd backend && AUTOS_TEST_TEMPLATE=autos_template AUTOS_TEST_S3_ENDPOINT=http://localhost:9100 python -m pytest -v
```

| file | tests | passed | what it proves |
|---|---|---|---|
| `tests/test_backup_restore.py` | 1 | 1 | Backup → fresh initdb cluster → restore → row counts, schema head, 10 invariants, RLS smoke test |
| `tests/test_imports_outbox_audit.py` | 12 | 12 | Import validation/preview, modes, idempotency, stale & blank rules, cross-tenant VIN, merge proposals, CSV formula safety, outbox retry/dead-letter, audit redaction & append-only |
| `tests/test_integrity_constraints.py` | 10 | 10 | Foreign keys, composite tenant FKs, CHECKs, exclusion constraints, IANA zones, unknown vs zero, namespaced identifiers, DB-level transitions, append-only history |
| `tests/test_object_storage.py` | 1 | 1 | S3 API round trip and media upload (run against an S3-compatible server) |
| `tests/test_payments.py` | 13 | 13 | Idempotent intents (incl. concurrent), HMAC verification & replay window, duplicate & out-of-order events, late settlement → case, partial & concurrent refunds, refund reconciliation, unknown-outcome worker, no card data |
| `tests/test_quotes_and_locking.py` | 9 | 9 | $32,900 + $400 = $33,300 example, incomplete quotes, deposit not added, immutability, deferred totals check, quote preservation across price/fee changes, If-Match / 428 / 409, concurrent versioned updates, publication findings |
| `tests/test_reservations.py` | 11 | 11 | 20-thread competing reservations across two listings, 409 mapping, inline expiry without worker, acceptance after expiry, DB refuses early expiry, sweeper agreement, lifecycle separation, idempotency |
| `tests/test_scheduling.py` | 10 | 10 | Rental half-open + buffer boundaries, 12-thread category capacity, maintenance vs assignments & capacity, cancellation releases, DST day counting, naive timestamps; test-drive vehicle exclusivity, 6-thread resource capacity, sale/hold effects on appointments |
| `tests/test_schema_and_money.py` | 22 | 22 | Migration head, full downgrade/upgrade, ORM drift, RLS coverage, app-role privileges, money parsing/arithmetic/rounding/allocation |
| `tests/test_tenant_isolation.py` | 9 | 9 | Cross-dealer API denial, relationship-scoped customers, public vs draft listings, permission matrix, customer self-scope, RLS on unfiltered SQL, WITH CHECK, pooled-connection leak test, acting-org header |

## Individual results

<details><summary><code>tests/test_backup_restore.py</code> — 1 tests</summary>

- ✅ `test_restore_drill_into_fresh_cluster`

</details>

<details><summary><code>tests/test_imports_outbox_audit.py</code> — 12 tests</summary>

- ✅ `test_sample_file_validation_and_preview`
- ✅ `test_partial_accept_applies_valid_rows_then_publish`
- ✅ `test_repeat_import_is_idempotent_and_stale_updates_rejected`
- ✅ `test_blank_fields_do_not_erase_without_rule`
- ✅ `test_all_or_nothing_success_and_json_format`
- ✅ `test_cross_tenant_vin_conflict_detected_without_disclosure`
- ✅ `test_weak_match_creates_merge_proposal_not_merge`
- ✅ `test_csv_export_neutralises_formulas`
- ✅ `test_outbox_retry_backoff_and_dead_letter`
- ✅ `test_outbox_publishes_each_event_once`
- ✅ `test_audit_records_actor_request_and_redacts`
- ✅ `test_app_role_cannot_tamper_with_audit`

</details>

<details><summary><code>tests/test_integrity_constraints.py</code> — 10 tests</summary>

- ✅ `test_foreign_key_enforced`
- ✅ `test_listing_location_must_belong_to_seller`
- ✅ `test_negative_or_zero_price_rejected`
- ✅ `test_price_currency_must_match_listing`
- ✅ `test_overlapping_price_periods_rejected`
- ✅ `test_invalid_timezone_rejected`
- ✅ `test_unknown_is_not_zero`
- ✅ `test_vin_format_and_namespaced_uniqueness`
- ✅ `test_listing_status_transitions_enforced_in_db`
- ✅ `test_status_events_written_by_trigger`

</details>

<details><summary><code>tests/test_object_storage.py</code> — 1 tests</summary>

- ✅ `test_s3_storage_roundtrip_and_media_upload`

</details>

<details><summary><code>tests/test_payments.py</code> — 13 tests</summary>

- ✅ `test_payment_creation_is_idempotent`
- ✅ `test_concurrent_identical_payment_requests_create_one_intent`
- ✅ `test_unsigned_or_forged_events_are_rejected_and_not_stored`
- ✅ `test_duplicate_event_processed_once`
- ✅ `test_concurrent_duplicate_deliveries`
- ✅ `test_out_of_order_events`
- ✅ `test_settlement_after_hold_expiry_opens_case_and_never_seizes`
- ✅ `test_partial_refunds_and_limit`
- ✅ `test_concurrent_refunds_never_exceed_capture`
- ✅ `test_refund_reconciles_late_payment_case`
- ✅ `test_unknown_outcome_is_reconciled_by_worker`
- ✅ `test_no_card_data_columns_exist`
- ✅ `test_duplicate_deliveries_are_visible_in_audit`

</details>

<details><summary><code>tests/test_quotes_and_locking.py</code> — 9 tests</summary>

- ✅ `test_quote_example_incomplete_without_region`
- ✅ `test_quote_complete_with_region_and_options`
- ✅ `test_issued_quotes_are_immutable_in_the_database`
- ✅ `test_quote_totals_must_match_lines_at_commit`
- ✅ `test_price_and_catalogue_changes_do_not_rewrite_quotes`
- ✅ `test_if_match_required_and_enforced`
- ✅ `test_concurrent_versioned_updates_one_wins`
- ✅ `test_generic_patch_cannot_change_status_or_sell`
- ✅ `test_publication_validation_findings`

</details>

<details><summary><code>tests/test_reservations.py</code> — 11 tests</summary>

- ✅ `test_competing_reservations_across_listings_exactly_one_wins`
- ✅ `test_api_second_reservation_gets_409`
- ✅ `test_lapsed_hold_is_expired_inline_without_worker`
- ✅ `test_acceptance_after_expiry_is_rejected`
- ✅ `test_effective_status_reports_expiry_before_sweep`
- ✅ `test_db_refuses_to_expire_early_or_shorten_hold`
- ✅ `test_sweeper_and_requests_agree`
- ✅ `test_lifecycle_stages_are_separate`
- ✅ `test_reservation_idempotency_replay_and_mismatch`
- ✅ `test_cancellation_frees_vehicle`
- ✅ `test_completion_override_requires_reason_and_is_audited`

</details>

<details><summary><code>tests/test_scheduling.py</code> — 10 tests</summary>

- ✅ `test_rental_days_half_open_and_dst`
- ✅ `test_overlapping_asset_assignment_rejected_with_buffer_boundaries`
- ✅ `test_category_capacity_under_concurrency`
- ✅ `test_maintenance_blocks_assets_and_capacity`
- ✅ `test_maintenance_cannot_strand_committed_bookings`
- ✅ `test_cancellation_releases_capacity_and_assignment`
- ✅ `test_naive_timestamps_rejected`
- ✅ `test_vehicle_cannot_be_double_booked_but_adjacent_slots_ok`
- ✅ `test_resource_capacity_enforced_under_concurrency`
- ✅ `test_vehicle_sale_cancels_future_drives_and_hold_flags_them`

</details>

<details><summary><code>tests/test_schema_and_money.py</code> — 22 tests</summary>

- ✅ `test_migrations_at_head`
- ✅ `test_downgrade_to_base_and_upgrade_again`
- ✅ `test_orm_models_match_database`
- ✅ `test_rls_enabled_on_every_tenant_table`
- ✅ `test_app_role_cannot_delete_history[audit_events]`
- ✅ `test_app_role_cannot_delete_history[listing_status_events]`
- ✅ `test_app_role_cannot_delete_history[sale_status_events]`
- ✅ `test_app_role_cannot_delete_history[payment_transactions]`
- ✅ `test_app_role_cannot_delete_history[quote_lines]`
- ✅ `test_app_role_cannot_delete_history[quotes]`
- ✅ `test_app_role_cannot_delete_history[payment_events]`
- ✅ `test_app_role_cannot_delete_history[vehicles]`
- ✅ `test_app_role_cannot_delete_history[listings]`
- ✅ `test_app_role_cannot_write_current_reservations_directly`
- ✅ `test_app_role_is_not_owner_and_cannot_bypass_rls`
- ✅ `test_currency_table_matches_code`
- ✅ `test_parse_exact_and_reject_excess_precision`
- ✅ `test_no_float_drift`
- ✅ `test_currency_mismatch_rejected`
- ✅ `test_rate_rounding_half_up`
- ✅ `test_allocate_preserves_total`
- ✅ `test_format`

</details>

<details><summary><code>tests/test_tenant_isolation.py</code> — 9 tests</summary>

- ✅ `test_cross_dealer_api_access_is_denied`
- ✅ `test_cross_dealer_customers_quotes_and_imports_are_invisible`
- ✅ `test_published_listings_are_public_but_drafts_are_not`
- ✅ `test_permission_matrix_dealer_staff_cannot_approve_or_publish`
- ✅ `test_customer_principal_sees_only_own_records`
- ✅ `test_rls_blocks_rows_even_with_unfiltered_sql`
- ✅ `test_rls_with_check_blocks_cross_tenant_writes`
- ✅ `test_pooled_connection_does_not_leak_tenant_context`
- ✅ `test_acting_organisation_header_narrows_scope`

</details>

## Other executed verification

- **12-scenario demonstration** against a live multi-worker API: [`DEMO_TRANSCRIPT.md`](DEMO_TRANSCRIPT.md).
- **Performance** on a 200k-listing synthetic dataset: [`PERFORMANCE.md`](PERFORMANCE.md).
- **Compose restore drill** executed as the `restore-drill` service container (see `OPERATIONS.md`).
- **Admin UI**: `npm run build` (tsc + vite) and a Playwright click-through; see `admin/README.md`.
