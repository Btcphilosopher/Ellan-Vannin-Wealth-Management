# AUTOS DATA — demonstration transcript

Generated 2026-11-26T19:57:11+00:00 against `http://localhost:8010` (PostgreSQL 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1), PostGIS 3.4.2). All organisations, people, VINs and payments are fictional/synthetic; the payment provider is simulated.

## 1. Import dealer inventory

Ridgeline uploads a 10-row CSV in `partial_accept` mode. The file is stored in object storage, staged row by row (raw payload kept for provenance) and validated immediately.
`POST /v1/import-jobs` → **201**
```json
{
  "id": "0c55bb10-1027-418f-8ac4-35212bf0a740",
  "status": "validated",
  "mode": "partial_accept",
  "row_count": 10,
  "valid_count": 4,
  "warning_count": 0,
  "invalid_count": 6,
  "file_sha256": "7e33d0d4066d5d4cc0dcdf4363f87c437bda6bc43d0104f4fe976742f0b1a9dc"
}
```
Re-uploading identical bytes is idempotent:
`POST /v1/import-jobs` → **200**
```json
{
  "id": "0c55bb10-1027-418f-8ac4-35212bf0a740",
  "duplicate_upload": true
}
```

## 2. Review invalid rows

| row | source_record_id | findings (errors) |
|---|---|---|
| 4 | RL-1004 | `invalid_vin` VIN must be 17 characters from A-Z/0-9 excluding I, O, Q |
| 5 | RL-1005 | `invalid_price` price must be > 0 and below 10,000,000; `invalid_deposit` deposit must be between 0 and the price |
| 6 | RL-1006 | `unknown_reference` no location RL-XXX for this dealer |
| 7 | RL-1007 | `unit_required` odometer_unit must be km or mi when odometer_value is given |
| 8 | RL-1001 | `duplicate_source_identifier` duplicate of row 1 |
| 10 | RL-1009 | `unsupported_currency` XYZ is not a supported currency |

## 3. Publish valid listings

`POST /v1/import-jobs/0c55bb10-1027-418f-8ac4-35212bf0a740/approval` → **200**
```json
{
  "status": "applied_with_skips",
  "applied_count": 4,
  "skipped_count": 6,
  "no_change_count": 0
}
```
`POST /v1/listings/publication-batch` → **200**
```json
{
  "published": 4,
  "rejected": 0
}
```

## 4. Generate an immutable quote

Without a customer region the tax and registration are unknown, so the quote is **incomplete** (no total is invented):
`POST /v1/quotes` → **201** Q-2026-0000002

| line | status | amount |
|---|---|---|
| Vehicle price | known | $32,900.00 |
| Dealer documentation fee | known | $400.00 |
| Sales tax (unknown until customer region and rule are known) | unknown | — |
| Registration and title (unknown) | unknown | — |
| Customer collects (no delivery) | not_applicable | — |

Subtotal before tax/registration **$33,300.00**; is_complete=False, missing=['registration', 'tax'], total=None; deposit $500.00 — The deposit is part of the total, not an additional charge.

With `customer_region=US-OR` the quote is complete: total **$33,778.50**, balance after deposit $33,278.50.

Immutability is enforced by the database (direct SQL as owner):
```
immutable_record: issued quotes cannot be modified
```
After the listing price changes to $31,900.00 the issued quote still shows vehicle price **$32,900.00** (snapshot_verified=True).

## 5. Submit competing reservations

The same physical Tucson is offered through two listings (marketplace + dealer site). 20 concurrent HTTP requests from 10 different customers race for it, split across both listings.

## 6. Confirm only one succeeds

Outcomes in 515 ms: 409 vehicle_already_reserved ×19, 201 created ×1

Winner: **R-2026-0000003**. Database check: vehicle_current_reservations rows = 1, active reservations = 1.

## 7. Process a duplicate payment event once

`POST /v1/payments` → **201**
```json
{
  "id": "190f430c-af8b-485c-8f75-ce5bd615fa33",
  "status": "processing",
  "amount_minor": 50000,
  "currency": "USD",
  "provider_intent_ref": "sp_pi_ca6dd4424da24154802f"
}
```
Retrying with the same Idempotency-Key → **200**, same id: True, `Idempotent-Replayed: true`
The simulated provider delivers the signed `payment.succeeded` webhook three times, then a stale `payment.processing`:
```json
[
  {
    "result": "applied",
    "note": "deposit recorded; reservation still awaits dealer acceptance"
  },
  {
    "result": "duplicate",
    "note": null
  },
  {
    "result": "duplicate",
    "note": null
  },
  {
    "result": "ignored_out_of_order",
    "note": "payment.processing after final status succeeded"
  }
]
```
Capture transactions recorded: **1**. Reservation status `held` (still awaiting dealer acceptance), deposit `paid`, hold extended to 2026-11-29T19:57:14.508782+00:00.

## 8. Handle settlement after hold expiry

To simulate time passing, Harbourview's hold policy is shortened to 3 seconds (direct SQL as owner).
Customer A holds the IONIQ 5 (R-2026-0000023) and starts paying a deposit; the provider is slow. 3.5 s later…
Customer B reserves the same vehicle → **201** R-2026-0000024 (A's lapsed hold is expired inline under the vehicle lock).
Now A's payment settles: webhook result `applied` — late/mismatched deposit -> RC-2026-000001
```json
{
  "case_number": "RC-2026-000001",
  "case_type": "payment_after_hold_expiry",
  "status": "open",
  "summary": "Deposit settled while reservation R-2026-0000023 was expired. Vehicle is now committed to another reservation; it was not reassigned.",
  "details": {
    "current_holder": "R-2026-0000024",
    "recommended_action": "refund the deposit or re-reserve if the vehicle is free",
    "reservation_status": "expired"
  }
}
```
B's reservation is untouched: `held` for customer B; A's is `expired`.

## 9. Reject an overlapping rental booking

Booking 1 on asset CL-SFAR-001: 2027-01-15T09:00:00-08:00 → +2 days → **201**; occupied `{'lower': '2027-01-15T17:00:00+00:00', 'upper': '2027-01-17T18:00:00+00:00', 'bounds': '[)'}` (includes the 60-minute turnaround buffer).
Booking 2 on the same asset starting 30 min after return (inside the buffer) → **409** `rental_asset_conflict`: the asset is already assigned for an overlapping period (including turnaround buffer)
Booking 3 starting exactly at return + buffer (half-open interval) → **201**

## 10. Prevent cross-dealer access

- Ridgeline reads a Harbourview draft listing → **404** `not_found`
- Ridgeline reads a Harbourview customer → **404** `not_found`
- Ridgeline reads Harbourview's payment → **404** `not_found`
- Ridgeline tries to accept Harbourview's reservation → **404** `not_found`
- Ridgeline's quote list contains only Ridgeline quotes: True
- Defence in depth: as the application DB role with Ridgeline context, `SELECT count(*) FROM payment_intents WHERE organisation_id = <Harbourview>` → **0** (row-level security).

## 11. Reconcile a refund

Finance resolves RC-2026-000001 by refunding customer A's late deposit, linked to the case:
`POST /v1/refunds` → **201**
```json
{
  "id": "16a2db6a-75a3-4727-8d66-a2d020a81f05",
  "status": "pending",
  "amount_minor": 100000,
  "provider_refund_ref": "sp_re_3b5ffdb1150448629fbe"
}
```
Case is now `awaiting_provider`. Over-refunding is impossible:
Extra 1-cent refund → **422** `refund_limit_exceeded`: requested 1 + already refunded/pending 100000 exceeds captured 100000
Provider confirms the refund (`refund.succeeded` webhook → `applied`).
Case **resolved** / resolution `refunded`: Auto-resolved: refund sp_re_3b5ffdb1150448629fbe settled (100000 of 100000 refunded).
Money movements: capture 100000 USD, refund 100000 USD

## 12. Restore a backup into a clean environment

`scripts/restore_drill.sh` (fresh `initdb` cluster on another port; 3.5 s, exit 0):
```
== 1. backup
   /tmp/autos-drill.kJMAY3/backups/autos-20261126T195719Z.dump (488K)
== 2. fresh cluster on port 5499
== 3. restore + verify
row counts match for 11 tables; schema head r0014
  invariant: multiple_active_reservations_per_vehicle|0
  invariant: current_reservation_points_to_ended_reservation|0
  invariant: refunds_exceed_capture|0
  invariant: quote_header_line_mismatch|0
  invariant: overlapping_active_assignments|0
  invariant: published_listing_without_price|0
  invariant: sold_vehicle_with_open_listing|0
  invariant: listing_without_status_history|0
  invariant: rls_disabled_on_tenant_table|0
  invariant: invalid_constraints|0
restore verified: postgresql://postgres@localhost:5499/autos_restored
== 4. smoke test as autos_api (RLS applies)
   customers visible without tenant context: 0 ; with platform context: 14
DRILL PASSED
```
