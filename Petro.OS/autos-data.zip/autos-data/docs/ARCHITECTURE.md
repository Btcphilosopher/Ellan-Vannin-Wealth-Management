# Architecture

## Shape: a modular monolith on PostgreSQL

```
                ┌───────────────────────────── admin (React/TS, nginx) ─────────────────────────────┐
                │  Overview · Vehicles · Listings · Dealers · Customers · Quotes · Reservations ·   │
                │  Test Drives · Rentals · Payments · Imports · Audit · Reports                    │
                └───────────────────────────────────────┬───────────────────────────────────────────┘
                                                        │ /v1 (JSON, problem+json, ETag/If-Match, Idempotency-Key)
┌──────────────────────────────────────── api (FastAPI, uvicorn) ────────────────────────────────────────┐
│ api/ routers ─► security (principal, role→permission) ─► services/ (one module per domain)             │
│   inventory: vehicles, listings     commerce: quotes, sales     scheduling: test drives, rentals        │
│   money: payments, refunds, reconciliation     imports     operations: outbox, audit, reports          │
│ db.py: one transaction per request; set_config(app.*, is_local=true) → RLS context                     │
└───────────────┬──────────────────────────────────────────────────────────────┬────────────────────────┘
                │ autos_api (member of autos_app, NOBYPASSRLS)                 │ boto3
┌───────────────▼───────────────────────────────┐                     ┌────────▼──────────┐
│ PostgreSQL 16 + PostGIS 3                      │                     │ S3-compatible      │
│  constraints, exclusion constraints, triggers  │                     │ (MinIO / S3)       │
│  RLS policies, column grants, SECURITY DEFINER │                     │ media, import files│
│  outbox_events, audit_events (append-only)     │                     └───────────────────┘
└───────────────▲───────────────────────────────┘
                │
┌───────────────┴──────── worker (python -m app.workers) ───────────────┐      ┌── simpay (SIMULATED) ──┐
│ reservation_expiry · outbox_dispatch · payment_reconciliation ·        │◄────►│ schema simpay, HMAC    │
│ listing_freshness · import_processing (+ heartbeats)                   │      │ signed webhooks        │
└────────────────────────────────────────────────────────────────────────┘      └────────────────────────┘
```

**Why a modular monolith:** every critical invariant spans several aggregates (vehicle ↔ listing ↔ reservation ↔ payment). Keeping them in one database lets a single ACID transaction protect them; module boundaries are enforced in code (one service module per domain, routers depend on services, services never import routers).

## Where each invariant is enforced

The rule throughout: **the database is the last line of defence; the service layer gives friendly errors first.** Frontend validation is a convenience only.

| invariant | database mechanism | service behaviour |
|---|---|---|
| One active commitment per physical vehicle, across all listings | `vehicle_current_reservations` PK(vehicle_id) maintained by SECURITY DEFINER triggers; vehicle row lock (`FOR NO KEY UPDATE`) in BEFORE INSERT; partial unique index on active reservations | maps SQLSTATE Z9001 → 409 `vehicle_already_reserved` |
| Lapsed holds don't block, and don't need a cron | expiry evaluated against `now()` under the same vehicle lock inside the insert trigger; transitions to `expired` refused before `hold_expires_at` | `effective_status`; sweeper uses SKIP LOCKED and is optional |
| Payment ≠ sale | no trigger moves reservation status on payment; acceptance requires a separate staff action | late deposit → reconciliation case, never touches the vehicle |
| Quotes immutable, totals = lines | update trigger allows only `status` forward; deferred constraint trigger checks header vs lines at COMMIT; lines append-only | snapshot JSON + sha256 |
| No overlapping asset use | GiST `EXCLUDE (rental_asset_id WITH =, occupied WITH &&)`; maintenance exclusion; cross-table checks under asset lock | 409 `rental_asset_conflict` |
| Category capacity | bucket row lock + peak-concurrency sweep over half-open ranges in AFTER trigger (fresh snapshot after the lock) | 409 `rental_capacity_exceeded` |
| Test-drive conflicts | GiST exclusion per vehicle for confirmed slots; resource capacity under resource lock | 409 `vehicle_slot_conflict` / `resource_capacity_exceeded` |
| Refunds ≤ capture | refund trigger locks the capture transaction and sums committed refunds | 422 `refund_limit_exceeded` |
| Duplicate provider events | `UNIQUE (provider, provider_event_id)`; `INSERT … ON CONFLICT DO NOTHING` | 200 `{result: duplicate}` |
| Out-of-order provider events | final statuses can't regress (trigger); timestamp precedence for non-final events | recorded as `ignored_out_of_order` |
| Tenant isolation | RLS on every tenant table; `WITH CHECK` on writes; context via transaction-local settings | permission checks per org; 404 for invisible rows |
| History can't be rewritten | append-only triggers on history tables, `TRUNCATE` trigger on audit, no UPDATE/DELETE grants | domain actions instead of generic PATCH |
| Prices periods don't overlap | `EXCLUDE … tstzrange(effective_from, effective_to) WITH &&` | price change closes current version, opens a new one |

### Lock discipline

Always: **vehicle → reservation/order**; **inventory bucket → rental asset**; **appointment resource** alone; **capture transaction** for refunds. Serialisation locks on parent rows use `FOR NO KEY UPDATE`, which serialises writers but stays compatible with the `FOR KEY SHARE` locks that foreign-key checks take — using `FOR UPDATE` caused lock-upgrade deadlocks under contention (found by `test_resource_capacity_enforced_under_concurrency`). All transactions run at READ COMMITTED; checks that follow a lock run in a new statement snapshot, so they see every transaction that committed before the lock was granted.

## Request lifecycle

1. Middleware assigns/propagates `X-Request-Id`.
2. Bearer token → principal: a short system-context transaction loads memberships, then commits (identity before tenancy).
3. A new session is opened with `DbContext(org_ids, is_platform, user_id, customer_id, request_id)`; an `after_begin` hook applies it with `set_config(…, true)` to every transaction on that session.
4. Router validates the Pydantic contract → service checks permissions and invariants → DB enforces.
5. Write endpoints commit explicitly (so deferred-constraint failures surface as API errors), store the idempotent response in the same transaction, and return `ETag`.
6. Customer-initiated actions on a dealer's data run in the **dealer's tenant scope after authorisation** (`elevated()`), so locks and triggers operate on real rows; RLS still blocks every other tenant.

## Modules

| path | responsibility |
|---|---|
| `backend/migrations/sql/` | authoritative schema, integrity rules, RLS, grants |
| `backend/app/models/tables.py` | generated ORM mirror (drift-tested) |
| `backend/app/services/*.py` | domain logic per module |
| `backend/app/api/*.py` | HTTP contracts, auth, idempotency, If-Match |
| `backend/app/workers/` | background loops |
| `backend/app/simulator.py` | simulated payment provider |
| `backend/seed/` | deterministic fictional data + sample import files |
| `backend/perf/` | synthetic dataset + benchmarks |
| `backend/scripts/` | backup/restore/drill, integrity checks, demo, doc/model generators |
| `admin/` | operational UI |

## Domain policies (as implemented)

| situation | policy | enforced by |
|---|---|---|
| Another customer places a sale hold on a vehicle with future test drives | appointments are **kept** and flagged `availability_notice = vehicle_reserved`; flag clears when the hold ends | trigger on `vehicle_current_reservations` |
| Vehicle becomes sold / unavailable / written off | future requested/confirmed appointments are **cancelled by the system** (`cancelled_by_kind = system`, reason `vehicle_unavailable:<status>`); an outbox event allows customer notification | trigger on `vehicles.availability_status` |
| Source feed stops confirming a listing | `fresh` → `stale` after the organisation's warn threshold; optionally `expired` + automatic **suspension** after the suspend threshold. Availability is never inferred from the feed | `listing_freshness` worker + publication validation |
| Deposit settles while the hold is active | `deposit_status = paid`; hold extended to `max(current, now + deposit_hold_extension)`; reservation still needs dealer acceptance | payment event handler under the vehicle lock |
| Deposit settles after the hold lapsed | reservation stays expired; **reconciliation case** `payment_after_hold_expiry` naming the current holder (if any); vehicle never reassigned | payment event handler |
| Paid hold lapses without acceptance | case `deposit_on_lapsed_hold` (refund or re-reserve) | expiry path |
| Dealer acceptance | requires an unexpired hold and, where required, a settled deposit; accepted reservations no longer expire automatically | service + trigger |
| Quote with unknown tax/registration/delivery | issued as **incomplete** (`total = NULL`, `missing_charges`), cannot be accepted; a sale order then needs an explicit agreed total | quote triggers + service |
| Rental day count | started 24-hour periods between absolute instants (DST cannot add/lose a billable day); local times shown in the location's IANA zone | `rental_days()` |

## Compatibility notes

Verified by execution in this repository (tests, demo, Compose run), not only by reading documentation:

* **PostgreSQL 16** (tested 16.9 in the official PostGIS image and 16.15 on Ubuntu). Features relied on: `UNIQUE … NULLS NOT DISTINCT` (15+), `security_invoker` views (15+), stored generated columns (12+), GiST exclusion constraints with `btree_gist`, row-level security, column-level privileges, deferrable constraint triggers, `FOR NO KEY UPDATE`/`SKIP LOCKED`, trusted extensions (`citext`, `pg_trgm`, `btree_gist`; `postgis` requires a superuser or a template database). PostgreSQL 18 ships a native `uuidv7()`; this schema provides `uuid_v7()` for 16.
* **PostGIS 3.4 / 3.5**: `geography(Point,4326)`, `ST_DWithin`/`ST_Distance` in metres, GiST indexes. PostGIS functions are not `LEAKPROOF` (see Security/Performance).
* **Python 3.11–3.13**, FastAPI 0.165, Starlette (bundled), Pydantic 2.13, SQLAlchemy 2.1, Alembic 1.20, psycopg 3.3 (binary), GeoAlchemy2 0.21, PyJWT 2.15, boto3 1.44 — pinned in `backend/requirements.txt`.
* **Node 22**, React 18, TypeScript 5, Vite — pinned in `admin/package.json`.
