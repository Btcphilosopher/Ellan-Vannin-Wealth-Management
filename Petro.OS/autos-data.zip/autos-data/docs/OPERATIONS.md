# Operations

## Processes

| process | command | notes |
|---|---|---|
| API | `uvicorn app.main:app --workers 4` | stateless; scale horizontally |
| Workers | `python -m app.workers` (`--once`, `--only <job>`) | safe on several replicas |
| Migrations | `alembic upgrade head` as `autos_owner` | one revision per SQL file; every revision has a tested downgrade |

### Worker jobs

| job | interval | idempotency / concurrency | failure handling |
|---|---|---|---|
| `reservation_expiry` | 15 s | vehicle lock `SKIP LOCKED`; re-checks under lock | optional — requests expire lapsed holds inline |
| `outbox_dispatch` | 2 s | `FOR UPDATE SKIP LOCKED`; event id = consumer idempotency key | exponential backoff with full jitter (cap 1 h); `dead` after `max_attempts` (default 8); requeue via API |
| `payment_reconciliation` | 30 s | resolves `unknown` intents by querying the provider and feeding the result through the deduplicating event path | opens `unknown_payment_outcome` case; fails intents the provider never received after 10 min |
| `listing_freshness` | 5 min | row locks `SKIP LOCKED` | warn (`stale`) or suspend per organisation policy; never touches physical availability |
| `import_processing` | 5 s | jobs left `approved/applying` by an interrupted request | bounded: 3 attempts |

Each run writes `worker_heartbeats`; `/v1/health/ready` and the admin Overview show worker health.

## Health checks

* `GET /v1/health/live` — process up.
* `GET /v1/health/ready` — database reachable, migration head, worker heartbeats (503 if the DB is unreachable).

## Backups and restoration

| script | what it does |
|---|---|
| `scripts/backup.sh [out_dir]` | `pg_dump -Fc --serializable-deferrable` as the owner (so RLS doesn't filter the dump), plus `.sha256`, `.head` (schema revision), `.counts.tsv` and a JSON manifest |
| `scripts/restore.sh <dump>` | verifies checksum, creates cluster roles, refuses to overwrite an existing database, `pg_restore --single-transaction --exit-on-error`, compares schema head + row counts, runs `verify_integrity.sql` (10 invariant checks) |
| `scripts/restore_drill.sh` | full DR drill: backup → **fresh `initdb` cluster** on another port → restore → verify → smoke test as the RLS-subject app role → teardown |
| `scripts/verify_integrity.sql` | invariants: single active commitment per vehicle, refunds ≤ captures, quote header = lines, no overlapping assignments, RLS still enabled, all constraints validated, … |

Tested: `tests/test_backup_restore.py` (local), demo step 12, and the Compose `restore-drill` service (throwaway PostGIS container) all pass.

**Production recommendations (deferred):** continuous WAL archiving (pgBackRest/WAL-G) for point-in-time recovery; encrypted off-site copies; a scheduled restore drill with alerting; retention of daily logical dumps for 35 days.

## Configuration (environment, prefix `AUTOS_`)

`DATABASE_URL` (app role), `MIGRATION_DATABASE_URL` (owner), `JWT_SECRET`, `ENABLE_DEV_AUTH`, `ENABLE_SIMULATOR`, `SIMPAY_WEBHOOK_SECRET`, `STORAGE_BACKEND` (`s3`|`local`), `S3_ENDPOINT_URL`, `S3_BUCKET`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `WEBHOOK_SINK_URL`, `BRAND_NAME`, `BRAND_PRODUCT`, `BRAND_DISCLAIMER`, `DB_STATEMENT_TIMEOUT_MS`, `DB_LOCK_TIMEOUT_MS`, `QUOTE_VALIDITY_HOURS`, `IMPORT_MAX_BYTES`, `IMPORT_MAX_ROWS`. See `backend/app/config.py`.

Before any non-demo deployment: set `ENABLE_DEV_AUTH=false` and integrate a real identity provider, set `ENABLE_SIMULATOR=false` and do not apply the `simpay` schema, rotate every secret in `docker-compose.yml`, and put the API behind TLS.

## Imports — behaviour contract

1. **Upload** (CSV with header row, or JSON array / `{"records": [...]}`), max 10 MB / 20,000 rows. Bytes are stored in object storage with their sha256. Same bytes + same source namespace → existing job returned (`duplicate_upload: true`).
2. **Staging**: one `import_rows` row per record with the untouched raw payload.
3. **Validation**: required fields, types, units (`odometer_unit` required with a value), currency support, VIN format/check digit, price range, deposit ≤ price, location belongs to the dealer, duplicate source ids / VINs in the file, stale source updates, cross-tenant VIN conflicts (boolean probe, no disclosure), availability conflicts with reservations, weak-similarity duplicates (→ merge proposal, never merge).
4. **Preview**: `GET /v1/import-jobs/{id}/rows?status=…&code=…` shows raw vs normalised values, findings and the planned action (`create`/`update`/`no_change`/`reject`).
5. **Approval**: `all_or_nothing` is refused while any row is invalid and applies in one transaction (any failure rolls back all rows); `partial_accept` skips invalid rows and applies each valid row in its own savepoint.
6. **Results**: per-row `result` (vehicle/listing ids, created/updated, publication findings), job counts, audit + outbox events.

Mapping rules: blank source fields **never** erase data unless listed in `options.clear_blank_fields`; repeated identical rows are `no_change`; older `source_updated_at` with different content is rejected as `stale_source_update`; import attributes are stored as provenance assertions (`seller_claim` / `import_source`) with source, job/row reference and effective date. `publish_on_apply` publishes only listings that pass publication validation.
