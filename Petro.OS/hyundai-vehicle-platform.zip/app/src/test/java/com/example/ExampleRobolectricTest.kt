package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.DriveMode
import com.example.repository.VehicleRepository
import com.example.ui.viewmodel.VehicleViewModel
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var repository: VehicleRepository
    private lateinit var viewModel: VehicleViewModel

    @Before
    fun setUp() {
        repository = VehicleRepository()
        viewModel = VehicleViewModel(repository)
    }

    @Test
    fun `read app_name string resource`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("HVDP", appName)
    }

    @Test
    fun `verify trilingual localization translations`() {
        assertEquals("Range", Translations.get("range", Language.ENGLISH))
        assertEquals("주행 가능 거리", Translations.get("range", Language.KOREAN))
        assertEquals("续航里程", Translations.get("range", Language.CHINESE))

        assertEquals("Battery", Translations.get("tab_battery", Language.ENGLISH))
        assertEquals("배터리", Translations.get("tab_battery", Language.KOREAN))
        assertEquals("电池", Translations.get("tab_battery", Language.CHINESE))
    }

    @Test
    fun `test drive mode state transition`() {
        val result = repository.setDriveMode("SPORT")
        assertTrue(result.isSuccess)
        val data = result.getOrThrow()
        assertEquals("NORMAL", data.previousMode)
        assertEquals("SPORT", data.currentMode)
        assertEquals(DriveMode.SPORT, repository.vehicleState.value.driveMode)
    }

    @Test
    fun `test invalid drive mode rejected`() {
        val result = repository.setDriveMode("INVALID_MODE")
        assertTrue(result.isFailure)
    }

    @Test
    fun `test battery charging state machine and target SOC bounds`() {
        // Valid target SOC
        val validRes = repository.startCharging(85f, isDcFast = true)
        assertTrue(validRes.isSuccess)
        assertTrue(repository.vehicleState.value.charging)

        // Invalid target SOC < 10 or > 100
        val invalidLow = repository.startCharging(-1f, isDcFast = true)
        assertTrue(invalidLow.isFailure)

        val invalidHigh = repository.startCharging(101f, isDcFast = true)
        assertTrue(invalidHigh.isFailure)

        // Stop charging
        val stopRes = repository.stopCharging()
        assertTrue(stopRes.isSuccess)
        assertFalse(repository.vehicleState.value.charging)
    }

    @Test
    fun `test climate temperature bounds validation`() {
        val validClimate = repository.setClimate(22f, 3, true, null, null)
        assertTrue(validClimate.isSuccess)

        val invalidCold = repository.setClimate(12f, 3, true, null, null)
        assertTrue(invalidCold.isFailure)

        val invalidHot = repository.setClimate(35f, 3, true, null, null)
        assertTrue(invalidHot.isFailure)
    }

    @Test
    fun `test navigation destination request`() {
        val res = repository.setNavigation("Incheon International Airport")
        assertTrue(res.isSuccess)
        assertEquals("Incheon International Airport", repository.vehicleState.value.navDestination)

        val emptyRes = repository.setNavigation("  ")
        assertTrue(emptyRes.isFailure)
    }

    @Test
    fun `test API console execution and error model`() {
        // Test valid endpoint GET /api/v1/vehicle
        viewModel.setSelectedEndpoint("GET /api/v1/vehicle")
        viewModel.executeConsoleApiRequest()
        var lastRes = viewModel.lastApiResult.value
        assertNotNull(lastRes)
        assertEquals(200, lastRes?.statusCode)
        assertTrue(lastRes?.responseBodyJson?.contains("HVDP-DEMO-001") == true)

        // Test invalid drive mode API request (422)
        viewModel.setSelectedEndpoint("POST /api/v1/drive-mode")
        viewModel.setApiConsolePayload("{\"mode\": \"HYPERSPACE\"}")
        viewModel.executeConsoleApiRequest()
        lastRes = viewModel.lastApiResult.value
        assertNotNull(lastRes)
        assertEquals(422, lastRes?.statusCode)
        assertTrue(lastRes?.responseBodyJson?.contains("INVALID_PARAMETER") == true)
    }
}
