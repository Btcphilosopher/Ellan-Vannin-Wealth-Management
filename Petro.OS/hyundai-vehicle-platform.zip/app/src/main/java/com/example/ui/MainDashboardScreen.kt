package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Translations
import com.example.model.TelemetryEvent
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.VehicleViewModel

data class NavTabItem(
    val titleKey: String,
    val icon: ImageVector,
    val tag: String
)

@Composable
fun MainDashboardScreen(
    viewModel: VehicleViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.language.collectAsState()
    val state by viewModel.vehicleState.collectAsState()
    val history by viewModel.telemetryHistory.collectAsState()
    val selectedWindow by viewModel.timeWindow.collectAsState()
    val selectedEndpoint by viewModel.selectedEndpoint.collectAsState()
    val apiPayload by viewModel.apiConsolePayload.collectAsState()
    val lastApiResult by viewModel.lastApiResult.collectAsState()
    val aiResponse by viewModel.aiResponse.collectAsState()
    val aiLoading by viewModel.aiLoading.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }

    val tabs = listOf(
        NavTabItem("tab_cockpit", Icons.Default.Speed, "tab_cockpit"),
        NavTabItem("tab_vehicle", Icons.Default.DirectionsCar, "tab_vehicle"),
        NavTabItem("tab_battery", Icons.Default.BatteryChargingFull, "tab_battery"),
        NavTabItem("tab_charging", Icons.Default.Bolt, "tab_charging"),
        NavTabItem("tab_climate", Icons.Default.AcUnit, "tab_climate"),
        NavTabItem("tab_navigation", Icons.Default.Navigation, "tab_nav"),
        NavTabItem("tab_energy", Icons.Default.ElectricBolt, "tab_energy"),
        NavTabItem("tab_diagnostics", Icons.Default.Build, "tab_diagnostics"),
        NavTabItem("tab_api_console", Icons.Default.Code, "tab_api"),
        NavTabItem("tab_telemetry_terminal", Icons.Default.Terminal, "tab_terminal"),
        NavTabItem("tab_graphs", Icons.Default.ShowChart, "tab_graphs"),
        NavTabItem("tab_ai_assistant", Icons.Default.AutoAwesome, "tab_ai")
    )

    // Collect telemetry stream into a list state for terminal UI
    val streamList = remember { mutableStateListOf<TelemetryEvent>() }
    LaunchedEffect(Unit) {
        viewModel.telemetryEvents.collect { ev ->
            streamList.add(0, ev)
            if (streamList.size > 100) streamList.removeAt(streamList.size - 1)
        }
    }

    Scaffold(
        topBar = {
            HeaderBar(
                currentLanguage = language,
                onLanguageSelected = { viewModel.setLanguage(it) }
            )
        },
        containerColor = DarkGraphite,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DarkGraphite)
        ) {
            // Scrollable Tab Navigation Bar
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = DeepCharcoal,
                contentColor = TextHighContrast,
                edgePadding = 8.dp,
                divider = { Divider(color = BorderGrey) }
            ) {
                tabs.forEachIndexed { index, tab ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        modifier = Modifier.testTag(tab.tag),
                        text = {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (selectedTabIndex == index) HyundaiElectricBlue else TextMuted
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = Translations.get(tab.titleKey, language),
                                    fontSize = 12.sp,
                                    color = if (selectedTabIndex == index) HyundaiElectricBlue else TextSecondary
                                )
                            }
                        }
                    )
                }
            }

            // Tab Content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTabIndex) {
                    0 -> DigitalCockpit(state = state, language = language)
                    1 -> VehicleStatusPanel(
                        state = state,
                        language = language,
                        onLockDoors = { viewModel.repository.setDoorsLock(it) },
                        onSetLights = { viewModel.repository.setLights(it) },
                        onToggleHorn = { viewModel.repository.toggleHorn() }
                    )
                    2 -> BatteryPanel(state = state, language = language)
                    3 -> ChargingPanel(
                        state = state,
                        language = language,
                        onStartCharging = { soc, isDc -> viewModel.repository.startCharging(soc, isDc) },
                        onStopCharging = { viewModel.repository.stopCharging() }
                    )
                    4 -> ClimatePanel(
                        state = state,
                        language = language,
                        onSetClimate = { req ->
                            viewModel.repository.setClimate(req.temperatureC, req.fanLevel, req.ac, req.seatHeatingLeft, req.steeringWheelHeating)
                        }
                    )
                    5 -> NavigationPanel(
                        state = state,
                        language = language,
                        onSetDestination = { viewModel.repository.setNavigation(it) }
                    )
                    6 -> EnergyPanel(state = state, language = language)
                    7 -> DiagnosticsPanel(
                        state = state,
                        language = language,
                        onTriggerSyntheticFault = { viewModel.repository.triggerSyntheticFault() },
                        onClearFaults = { viewModel.repository.clearFaults() }
                    )
                    8 -> ApiConsolePanel(
                        selectedEndpoint = selectedEndpoint,
                        onEndpointSelected = { viewModel.setSelectedEndpoint(it) },
                        payloadText = apiPayload,
                        onPayloadChanged = { viewModel.setApiConsolePayload(it) },
                        onExecuteRequest = { viewModel.executeConsoleApiRequest() },
                        lastResult = lastApiResult,
                        language = language
                    )
                    9 -> EventStreamPanel(events = streamList)
                    10 -> TelemetryGraphPanel(
                        points = history,
                        selectedWindow = selectedWindow,
                        onSelectWindow = { viewModel.setTimeWindow(it) }
                    )
                    11 -> AiAssistantPanel(
                        response = aiResponse,
                        isLoading = aiLoading,
                        onSendQuery = { viewModel.askAiAssistant(it) }
                    )
                }
            }
        }
    }
}
