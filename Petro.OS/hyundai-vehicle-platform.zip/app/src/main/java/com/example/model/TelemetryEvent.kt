package com.example.model

data class TelemetryEvent(
    val timestamp: String,
    val topic: String,
    val value: String,
    val level: String = "INFO" // INFO, WARN, ERROR
)

data class TelemetryPoint(
    val timestampMs: Long,
    val speedKph: Float,
    val batterySoc: Float,
    val powerKw: Float,
    val motorTempC: Float,
    val batteryTempC: Float,
    val energyConsumption: Float
)
