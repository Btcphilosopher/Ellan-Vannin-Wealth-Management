package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun AiAssistantPanel(
    response: String,
    isLoading: Boolean,
    onSendQuery: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var queryInput by remember { mutableStateOf("") }

    val sampleQueries = listOf(
        "Explain active fault codes & resolution steps",
        "Analyze EV battery health & range efficiency",
        "Suggest optimal DC fast charging strategy"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Query Box
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                .testTag("ai_assistant_panel")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = HyundaiElectricBlue)
                    Text("HYUNDAI AI DIAGNOSTICS & TELEMETRY SPECIALIST", color = TextHighContrast, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }

                // Sample Prompt Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    sampleQueries.forEach { q ->
                        Surface(
                            color = DeepCharcoal,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.border(1.dp, BorderGrey, RoundedCornerShape(6.dp))
                        ) {
                            TextButton(
                                onClick = {
                                    queryInput = q
                                    onSendQuery(q)
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(q, color = TextSecondary, fontSize = 10.sp)
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = queryInput,
                        onValueChange = { queryInput = it },
                        placeholder = { Text("Ask Gemini AI about vehicle state or API...", color = TextMuted) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_query_input"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = HyundaiElectricBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedTextColor = TextHighContrast,
                            unfocusedTextColor = TextHighContrast
                        )
                    )

                    Button(
                        onClick = {
                            if (queryInput.isNotBlank()) {
                                onSendQuery(queryInput)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HyundaiDarkBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_send_ai_query")
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null)
                    }
                }
            }
        }

        // Response Display Box
        if (isLoading || response.isNotBlank()) {
            Surface(
                color = CardBackground,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                    .testTag("ai_response_box")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("DIAGNOSTIC ANALYSIS", color = HyundaiElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    if (isLoading) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = HyundaiElectricBlue, strokeWidth = 2.dp)
                            Text("Analyzing telemetry with Gemini 3.5 Flash...", color = TextMuted, fontSize = 12.sp)
                        }
                    } else {
                        Text(response, color = TextHighContrast, fontSize = 13.sp, lineHeight = 20.sp)
                    }
                }
            }
        }
    }
}
