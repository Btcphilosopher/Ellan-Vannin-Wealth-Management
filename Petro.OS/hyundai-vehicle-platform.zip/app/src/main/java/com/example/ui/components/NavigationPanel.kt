package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun NavigationPanel(
    state: VehicleState,
    language: Language,
    onSetDestination: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var destInput by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Destination Search & Route Box
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                .testTag("nav_panel")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("SATELLITE EV NAVIGATION ENGINE", color = HyundaiElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = destInput,
                    onValueChange = { destInput = it },
                    placeholder = { Text("e.g., Incheon International Airport / 서울역", color = TextMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("nav_input_field"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = HyundaiElectricBlue,
                        unfocusedBorderColor = BorderGrey,
                        focusedTextColor = TextHighContrast,
                        unfocusedTextColor = TextHighContrast
                    )
                )

                Button(
                    onClick = {
                        if (destInput.isNotBlank()) {
                            onSetDestination(destInput)
                            destInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HyundaiDarkBlue),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_set_destination")
                ) {
                    Icon(imageVector = Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("CALCULATE EV ROUTE", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Active Route Summary
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = StatusHealthy)
                    Text("ACTIVE DESTINATION: ${state.navDestination}", color = TextHighContrast, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }

                Divider(color = BorderGrey)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("DISTANCE", color = TextMuted, fontSize = 10.sp)
                        Text("${state.navDistanceKm} km", color = TextHighContrast, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }

                    Column {
                        Text("DURATION", color = TextMuted, fontSize = 10.sp)
                        Text("${state.navDurationMin} min", color = HyundaiElectricBlue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }

                    Column {
                        Text("ARRIVAL ETA", color = TextMuted, fontSize = 10.sp)
                        Text(state.navArrivalTime, color = TextHighContrast, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }

                    Column {
                        Text("TRAFFIC", color = TextMuted, fontSize = 10.sp)
                        Text(state.navTraffic, color = StatusHealthy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
