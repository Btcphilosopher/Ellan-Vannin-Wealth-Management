package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Power
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.ChargingStatus
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun ChargingPanel(
    state: VehicleState,
    language: Language,
    onStartCharging: (Float, Boolean) -> Unit,
    onStopCharging: () -> Unit,
    modifier: Modifier = Modifier
) {
    var targetSocInput by remember(state.targetSocPercent) { mutableStateOf(state.targetSocPercent) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Charging Status Banner Card
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                .testTag("charging_panel")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (state.charging) StatusHealthy else HyundaiDarkBlue),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }

                        Column {
                            Text(
                                text = if (state.charging) "CHARGING IN PROGRESS" else "STANDBY / DISCHARGING",
                                color = TextHighContrast,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Status: ${state.chargingStatus.name}",
                                color = if (state.charging) StatusHealthy else TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    if (state.charging) {
                        Text(
                            text = "${state.chargingPowerKw} kW",
                            color = StatusHealthy,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (state.charging) {
                    Divider(color = BorderGrey)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Target: ${state.batteryPercent.toInt()}% → ${state.targetSocPercent.toInt()}%",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "${state.chargingTimeRemainingMin} min remaining",
                            color = HyundaiElectricBlue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    LinearProgressIndicator(
                        progress = { (state.batteryPercent / state.targetSocPercent).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = StatusHealthy,
                        trackColor = DeepCharcoal
                    )
                }
            }
        }

        // Target SOC & Charging Controls Card
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = Translations.get("target_soc", language) + ": ${targetSocInput.toInt()}%",
                    color = TextHighContrast,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Slider(
                    value = targetSocInput,
                    onValueChange = { targetSocInput = it },
                    valueRange = 20f..100f,
                    steps = 15,
                    colors = SliderDefaults.colors(
                        thumbColor = HyundaiElectricBlue,
                        activeTrackColor = HyundaiDarkBlue
                    ),
                    modifier = Modifier.testTag("target_soc_slider")
                )

                if (!state.charging) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { onStartCharging(targetSocInput, true) },
                            colors = ButtonDefaults.buttonColors(containerColor = HyundaiDarkBlue),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_dc_fast_charge")
                        ) {
                            Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("DC Fast (350kW)", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { onStartCharging(targetSocInput, false) },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_ac_charge")
                        ) {
                            Icon(imageVector = Icons.Default.Power, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("AC Standard (11kW)", fontSize = 11.sp, color = TextHighContrast)
                        }
                    }
                } else {
                    Button(
                        onClick = onStopCharging,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusFault),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_stop_charge")
                    ) {
                        Text(Translations.get("stop_charging", language), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
