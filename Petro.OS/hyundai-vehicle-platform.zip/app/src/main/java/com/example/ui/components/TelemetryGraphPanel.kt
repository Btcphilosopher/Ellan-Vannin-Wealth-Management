package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TelemetryPoint
import com.example.ui.theme.*
import com.example.ui.viewmodel.TimeWindow

@Composable
fun TelemetryGraphPanel(
    points: List<TelemetryPoint>,
    selectedWindow: TimeWindow,
    onSelectWindow: (TimeWindow) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Window Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("REAL-TIME TELEMETRY PLOTS", color = TextHighContrast, fontSize = 15.sp, fontWeight = FontWeight.Bold)

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TimeWindow.entries.forEach { win ->
                    val isSel = win == selectedWindow
                    Surface(
                        color = if (isSel) HyundaiElectricBlue else CardBackground,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .testTag("win_btn_${win.name}")
                            .border(1.dp, BorderGrey, RoundedCornerShape(6.dp))
                    ) {
                        TextButton(
                            onClick = { onSelectWindow(win) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(win.label, color = if (isSel) Color.Black else TextHighContrast, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Plot 1: Speed (km/h)
        GraphCard("VEHICLE SPEED (km/h)", points, HyundaiElectricBlue) { it.speedKph }

        // Plot 2: Battery SOC (%)
        GraphCard("BATTERY SOC (%)", points, StatusHealthy) { it.batterySoc }

        // Plot 3: Power Output (kW)
        GraphCard("POWER OUTPUT (kW)", points, HyundaiPerformanceBlue) { it.powerKw }
    }
}

@Composable
private fun GraphCard(
    title: String,
    points: List<TelemetryPoint>,
    lineColor: Color,
    valueExtractor: (TelemetryPoint) -> Float
) {
    Surface(
        color = CardBackground,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
            .testTag("graph_card_${title.take(5)}")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (points.size >= 2) {
                        val maxVal = maxOf(1f, points.maxOf(valueExtractor))
                        val minVal = minOf(0f, points.minOf(valueExtractor))
                        val range = maxOf(1f, maxVal - minVal)

                        val path = Path()
                        val stepX = size.width / (points.size - 1)

                        points.forEachIndexed { idx, pt ->
                            val x = idx * stepX
                            val valNorm = (valueExtractor(pt) - minVal) / range
                            val y = size.height - (valNorm * size.height)

                            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }

                        drawPath(
                            path = path,
                            color = lineColor,
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }
                }
            }
        }
    }
}
