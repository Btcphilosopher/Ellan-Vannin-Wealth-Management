package com.example.repository

import com.example.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class VehicleRepository(
    private val externalScope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) {
    private val _vehicleState = MutableStateFlow(VehicleState())
    val vehicleState: StateFlow<VehicleState> = _vehicleState.asStateFlow()

    private val _telemetryEvents = MutableSharedFlow<TelemetryEvent>(extraBufferCapacity = 100)
    val telemetryEvents: SharedFlow<TelemetryEvent> = _telemetryEvents.asSharedFlow()

    private val _telemetryHistory = MutableStateFlow<List<TelemetryPoint>>(emptyList())
    val telemetryHistory: StateFlow<List<TelemetryPoint>> = _telemetryHistory.asStateFlow()

    private val timeFormatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val timeOnlyFormatter = SimpleDateFormat("HH:mm:ss", Locale.US)

    init {
        startSimulationLoop()
    }

    private fun startSimulationLoop() {
        externalScope.launch {
            while (isActive) {
                delay(100) // 10 Hz update frequency
                updatePhysicsTick()
            }
        }
    }

    private fun updatePhysicsTick() {
        val current = _vehicleState.value
        val now = System.currentTimeMillis()
        val timestampStr = timeFormatter.format(Date(now))

        var newSpeed = current.speedKph
        var newSoc = current.batteryPercent
        var newCharging = current.charging
        var newChargingStatus = current.chargingStatus
        var newChargingPowerKw = current.chargingPowerKw
        var newChargingTimeRemaining = current.chargingTimeRemainingMin
        var newRange = current.rangeKm
        var newPowerKw = current.batteryPowerKw
        var newCurrentA = current.batteryCurrentA
        var newNavDist = current.navDistanceKm
        var newCabinTemp = current.cabinTemperatureC
        var newMotorTemp = current.motorTempC
        var newBatteryTemp = current.batteryTempC

        if (newCharging) {
            // Charging Physics
            newSpeed = 0f
            val isDcFast = current.chargingStatus == ChargingStatus.DC_FAST_CHARGING
            val maxRateKw = if (isDcFast) 125f else 11f
            // Fast charging slows down as SOC increases (SOC > 80% taper curve)
            val taperFactor = if (newSoc > 80f) max(0.2f, (100f - newSoc) / 20f) else 1.0f
            newChargingPowerKw = maxRateKw * taperFactor

            // SOC increase per tick (77.4 kWh battery capacity)
            val socGainPerTick = (newChargingPowerKw / 36000f) / 77.4f * 100f
            newSoc = min(current.targetSocPercent, newSoc + socGainPerTick)

            val remainingEnergyKwh = (current.targetSocPercent - newSoc) / 100f * 77.4f
            newChargingTimeRemaining = if (newChargingPowerKw > 0) {
                max(1, (remainingEnergyKwh / newChargingPowerKw * 60).toInt())
            } else 0

            if (newSoc >= current.targetSocPercent) {
                newCharging = false
                newChargingStatus = ChargingStatus.COMPLETE
                newChargingPowerKw = 0f
                newChargingTimeRemaining = 0
                emitTelemetry(timestampStr, "CHARGING_COMPLETE", "Target SOC ${current.targetSocPercent.toInt()}% reached")
            }
            newPowerKw = -newChargingPowerKw
            newCurrentA = -newChargingPowerKw * 1000f / current.batteryVoltageV
            newBatteryTemp = min(42f, newBatteryTemp + 0.01f)
            newMotorTemp = max(25f, newMotorTemp - 0.05f)
        } else {
            // Driving Physics
            // Slight cruise speed fluctuation
            val speedNoise = (Random.nextFloat() - 0.5f) * 0.2f
            newSpeed = max(0f, min(180f, current.speedKph + speedNoise))

            val modeMultiplier = when (current.driveMode) {
                DriveMode.ECO -> 0.75f
                DriveMode.NORMAL -> 1.0f
                DriveMode.SPORT -> 1.4f
                DriveMode.SNOW -> 0.85f
            }

            // Power kW derived from speed & mode
            val basePower = (newSpeed / 130f) * 45f * modeMultiplier
            newPowerKw = basePower + (Random.nextFloat() * 1.5f - 0.75f)
            newCurrentA = (newPowerKw * 1000f) / current.batteryVoltageV

            // SOC drain rate
            val socDrainPerTick = (newPowerKw / 36000f) / 77.4f * 100f
            newSoc = max(0f, newSoc - socDrainPerTick)

            // Motor and Battery thermal dynamics
            newMotorTemp = min(95f, max(25f, 35f + (newSpeed * 0.25f)))
            newBatteryTemp = min(55f, max(20f, 25f + (newPowerKw * 0.15f)))

            // Distance progression
            if (newSpeed > 0 && newNavDist > 0) {
                val distTravelledKm = (newSpeed / 36000f) // 100ms interval
                newNavDist = max(0f, newNavDist - distTravelledKm)
            }
        }

        // Range calculation (77.4 kWh * SOC% / consumption rate ~ 14.5 kWh/100km)
        val efficiencyKmPerKwh = 5.3f / when (current.driveMode) {
            DriveMode.ECO -> 0.85f
            DriveMode.NORMAL -> 1.0f
            DriveMode.SPORT -> 1.25f
            DriveMode.SNOW -> 1.1f
        }
        newRange = (77.4f * (newSoc / 100f) * efficiencyKmPerKwh).toInt()

        // Cabin Temp thermal regulation towards target
        val targetCabin = current.driverTargetTempC
        val tempDiff = targetCabin - newCabinTemp
        if (kotlin.math.abs(tempDiff) > 0.1f && current.acOn) {
            newCabinTemp += tempDiff * 0.02f
        }

        val updatedState = current.copy(
            speedKph = newSpeed,
            motorRpm = (newSpeed * 51.8f).toInt(),
            batteryPercent = (newSoc * 10f).toInt() / 10f,
            charging = newCharging,
            chargingStatus = newChargingStatus,
            chargingPowerKw = (newChargingPowerKw * 10f).toInt() / 10f,
            chargingTimeRemainingMin = newChargingTimeRemaining,
            rangeKm = newRange,
            batteryPowerKw = (newPowerKw * 10f).toInt() / 10f,
            batteryCurrentA = (newCurrentA * 10f).toInt() / 10f,
            cabinTemperatureC = (newCabinTemp * 10f).toInt() / 10f,
            motorTempC = (newMotorTemp * 10f).toInt() / 10f,
            batteryTempC = (newBatteryTemp * 10f).toInt() / 10f,
            navDistanceKm = (newNavDist * 10f).toInt() / 10f
        )

        _vehicleState.value = updatedState

        // Update history buffer
        val point = TelemetryPoint(
            timestampMs = now,
            speedKph = updatedState.speedKph,
            batterySoc = updatedState.batteryPercent,
            powerKw = updatedState.batteryPowerKw,
            motorTempC = updatedState.motorTempC,
            batteryTempC = updatedState.batteryTempC,
            energyConsumption = 16.4f
        )

        val historyList = _telemetryHistory.value.toMutableList()
        historyList.add(point)
        // Keep last 300 points (30 seconds at 10Hz or sample down for longer view)
        if (historyList.size > 300) {
            historyList.removeAt(0)
        }
        _telemetryHistory.value = historyList

        // Periodically emit telemetry stream logs
        if (now % 1000 < 100) {
            emitTelemetry(timestampStr, "VEHICLE_SPEED", "${updatedState.speedKph.toInt()} km/h")
            emitTelemetry(timestampStr, "BATTERY_SOC", "${updatedState.batteryPercent}%")
            emitTelemetry(timestampStr, "MOTOR_POWER", "${updatedState.batteryPowerKw} kW")
        }
    }

    private fun emitTelemetry(timestamp: String, topic: String, value: String, level: String = "INFO") {
        _telemetryEvents.tryEmit(TelemetryEvent(timestamp, topic, value, level))
    }

    // --- Simulated REST API Endpoints ---

    fun setDriveMode(modeStr: String): Result<DriveModeResponse> {
        val current = _vehicleState.value
        val newMode = try {
            DriveMode.valueOf(modeStr.uppercase())
        } catch (e: Exception) {
            return Result.failure(IllegalArgumentException("Invalid drive mode: $modeStr. Allowed: ECO, NORMAL, SPORT, SNOW"))
        }

        val previous = current.driveMode
        _vehicleState.value = current.copy(driveMode = newMode)
        emitTelemetry(timeOnlyFormatter.format(Date()), "DRIVE_MODE_CHANGE", "$previous -> $newMode")
        return Result.success(DriveModeResponse(true, previous.name, newMode.name))
    }

    fun startCharging(targetSoc: Float, isDcFast: Boolean): Result<String> {
        if (targetSoc < 10f || targetSoc > 100f) {
            return Result.failure(IllegalArgumentException("targetSoc must be between 10 and 100"))
        }
        val current = _vehicleState.value
        val status = if (isDcFast) ChargingStatus.DC_FAST_CHARGING else ChargingStatus.AC_CHARGING
        _vehicleState.value = current.copy(
            charging = true,
            pluggedIn = true,
            chargingStatus = status,
            targetSocPercent = targetSoc,
            speedKph = 0f
        )
        val modeName = if (isDcFast) "DC 350kW Fast" else "AC 11kW Standard"
        emitTelemetry(timeOnlyFormatter.format(Date()), "CHARGING_STARTED", "$modeName to $targetSoc%")
        return Result.success("Charging initiated via $modeName")
    }

    fun stopCharging(): Result<String> {
        val current = _vehicleState.value
        _vehicleState.value = current.copy(
            charging = false,
            chargingStatus = ChargingStatus.DISCHARGING,
            chargingPowerKw = 0f,
            chargingTimeRemainingMin = 0
        )
        emitTelemetry(timeOnlyFormatter.format(Date()), "CHARGING_STOPPED", "Charging stopped by user")
        return Result.success("Charging terminated")
    }

    fun setClimate(tempC: Float?, fanLevel: Int?, ac: Boolean?, seatHeatingLeft: Int?, steeringWheelHeat: Boolean?): Result<String> {
        var current = _vehicleState.value
        if (tempC != null) {
            if (tempC < 16f || tempC > 30f) {
                return Result.failure(IllegalArgumentException("temperatureC must be between 16.0 and 30.0"))
            }
            current = current.copy(driverTargetTempC = tempC, passengerTargetTempC = tempC)
        }
        if (fanLevel != null) {
            if (fanLevel < 0 || fanLevel > 5) {
                return Result.failure(IllegalArgumentException("fanLevel must be between 0 and 5"))
            }
            current = current.copy(fanSpeed = fanLevel)
        }
        if (ac != null) current = current.copy(acOn = ac)
        if (seatHeatingLeft != null) current = current.copy(seatHeatLeft = seatHeatingLeft)
        if (steeringWheelHeat != null) current = current.copy(steeringWheelHeat = steeringWheelHeat)

        _vehicleState.value = current
        emitTelemetry(timeOnlyFormatter.format(Date()), "CLIMATE_UPDATE", "Temp: ${current.driverTargetTempC}°C, AC: ${current.acOn}")
        return Result.success("Climate settings updated")
    }

    fun setNavigation(destination: String): Result<NavDestinationResponse> {
        if (destination.isBlank()) {
            return Result.failure(IllegalArgumentException("destination cannot be empty"))
        }
        val current = _vehicleState.value
        val dist = 30f + Random.nextInt(40)
        val duration = (dist * 1.1f).toInt()
        val response = NavDestinationResponse(
            destination = destination,
            distanceKm = dist,
            durationMinutes = duration,
            arrivalTime = "20:15",
            traffic = "LIGHT"
        )
        _vehicleState.value = current.copy(
            navDestination = destination,
            navDistanceKm = dist,
            navDurationMin = duration,
            navArrivalTime = "20:15",
            navTraffic = "LIGHT",
            navNextManoeuvre = "Proceed 2.4 km to expressway"
        )
        emitTelemetry(timeOnlyFormatter.format(Date()), "NAV_REROUTE", "Destination set: $destination")
        return Result.success(response)
    }

    fun setLights(req: LightsSetRequest): Result<String> {
        val current = _vehicleState.value
        val currentLights = current.lights
        val newLights = currentLights.copy(
            headlights = req.headlights ?: currentLights.headlights,
            highBeam = req.highBeam ?: currentLights.highBeam,
            drl = req.drl ?: currentLights.drl,
            hazardLights = req.hazardLights ?: currentLights.hazardLights,
            interiorLights = req.interiorLights ?: currentLights.interiorLights
        )
        _vehicleState.value = current.copy(lights = newLights)
        emitTelemetry(timeOnlyFormatter.format(Date()), "LIGHTS_UPDATE", "Headlights: ${newLights.headlights}, HighBeam: ${newLights.highBeam}")
        return Result.success("Lighting state updated")
    }

    fun setDoorsLock(lockAll: Boolean): Result<String> {
        val current = _vehicleState.value
        val newDoors = current.doors.copy(
            frontLeftLocked = lockAll,
            frontRightLocked = lockAll,
            rearLeftLocked = lockAll,
            rearRightLocked = lockAll
        )
        _vehicleState.value = current.copy(doorsLocked = lockAll, doors = newDoors)
        val action = if (lockAll) "LOCKED" else "UNLOCKED"
        emitTelemetry(timeOnlyFormatter.format(Date()), "DOOR_LOCK_STATE", "All doors $action", if (lockAll) "INFO" else "WARN")
        return Result.success("Doors $action successfully")
    }

    fun toggleHorn(): Result<String> {
        val current = _vehicleState.value
        val newHorn = !current.hornActive
        _vehicleState.value = current.copy(hornActive = newHorn)
        if (newHorn) {
            emitTelemetry(timeOnlyFormatter.format(Date()), "HORN_ACTIVE", "Horn sounded", "WARN")
        }
        return Result.success("Horn state: $newHorn")
    }

    fun triggerSyntheticFault(): Result<FaultCode> {
        val codes = listOf(
            FaultCode("HVAC-204", "Cabin temperature sensor deviation", Severity.WARNING, timeOnlyFormatter.format(Date())),
            FaultCode("BMS-302", "High voltage battery cell temperature delta > 3°C", Severity.WARNING, timeOnlyFormatter.format(Date())),
            FaultCode("MCU-105", "Motor inverter switching frequency anomaly", Severity.FAULT, timeOnlyFormatter.format(Date())),
            FaultCode("TPMS-101", "Rear right tire pressure low (31 PSI)", Severity.WARNING, timeOnlyFormatter.format(Date()))
        )
        val selected = codes.random()
        val current = _vehicleState.value
        val updatedFaults = current.faults.toMutableList()
        updatedFaults.add(0, selected)
        _vehicleState.value = current.copy(faults = updatedFaults)
        emitTelemetry(timeOnlyFormatter.format(Date()), "FAULT_CODE_GENERATED", "[${selected.code}] ${selected.description}", "ERROR")
        return Result.success(selected)
    }

    fun clearFaults(): Result<String> {
        val current = _vehicleState.value
        _vehicleState.value = current.copy(faults = emptyList())
        emitTelemetry(timeOnlyFormatter.format(Date()), "FAULTS_CLEARED", "Diagnostic fault log cleared")
        return Result.success("Fault log cleared")
    }
}
