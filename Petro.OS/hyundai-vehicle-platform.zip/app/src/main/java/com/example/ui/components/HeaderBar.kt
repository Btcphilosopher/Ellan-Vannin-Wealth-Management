package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.ui.theme.*

@Composable
fun HeaderBar(
    currentLanguage: Language,
    onLanguageSelected: (Language) -> Unit,
    modifier: Modifier = Modifier
) {
    var showSafetyDialog by remember { mutableStateOf(false) }

    Surface(
        color = DeepCharcoal,
        tonalElevation = 4.dp,
        modifier = modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = BorderGrey)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Title & Model Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(HyundaiDarkBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "H",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = Translations.get("app_title", currentLanguage),
                                color = TextHighContrast,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Surface(
                                color = HyundaiDarkBlue,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "HVDP v1.0",
                                    color = HyundaiElectricBlue,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = Translations.get("vehicle_model", currentLanguage),
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                // Language Selector & Safety Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Safety Info Button
                    IconButton(
                        onClick = { showSafetyDialog = true },
                        modifier = Modifier
                            .testTag("safety_info_button")
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Safety Notice",
                            tint = StatusHealthy
                        )
                    }

                    // Trilingual Selector Buttons
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CardBackground)
                            .border(1.dp, BorderGrey, RoundedCornerShape(6.dp))
                            .padding(2.dp)
                    ) {
                        Language.entries.forEach { lang ->
                            val isSelected = lang == currentLanguage
                            Box(
                                modifier = Modifier
                                    .testTag("lang_btn_${lang.code}")
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) HyundaiElectricBlue else Color.Transparent)
                                    .clickable { onLanguageSelected(lang) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = lang.displayName,
                                    color = if (isSelected) Color.Black else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSafetyDialog) {
        SafetyBoundaryDialog(
            currentLanguage = currentLanguage,
            onDismiss = { showSafetyDialog = false }
        )
    }
}

@Composable
fun SafetyBoundaryDialog(
    currentLanguage: Language,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DeepCharcoal,
        titleContentColor = TextHighContrast,
        textContentColor = TextSecondary,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = StatusWarning
                )
                Text(
                    text = Translations.get("safety_boundary_title", currentLanguage),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = Translations.get("safety_boundary_desc", currentLanguage),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Divider(color = BorderGrey)
                Text(
                    text = "SAFE SIMULATOR FUNCTIONS:\n• Dashboard state & Telemetry\n• Climate, Charging & Battery\n• Door locks, Windows, Lighting & Horn\n• Navigation & Diagnostics",
                    fontSize = 11.sp,
                    color = StatusHealthy
                )
                Text(
                    text = "SAFETY-CRITICAL CONTROLS (UNAVAILABLE):\n• Steering, Braking, Accelerator actuation\n• ADAS override & Autonomous driving",
                    fontSize = 11.sp,
                    color = StatusWarning
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("close_safety_dialog")
            ) {
                Text("ACKNOWLEDGEMENT", color = HyundaiElectricBlue, fontWeight = FontWeight.Bold)
            }
        }
    )
}
