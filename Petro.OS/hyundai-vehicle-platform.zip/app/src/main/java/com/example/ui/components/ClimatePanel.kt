package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Chair
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.ClimateSetRequest
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun ClimatePanel(
    state: VehicleState,
    language: Language,
    onSetClimate: (ClimateSetRequest) -> Unit,
    modifier: Modifier = Modifier
) {
    var tempVal by remember(state.driverTargetTempC) { mutableStateOf(state.driverTargetTempC) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Dual Zone Temperature Control
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                .testTag("climate_panel")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("DUAL-ZONE HVAC CLIMATE", color = TextHighContrast, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        color = if (state.acOn) HyundaiDarkBlue else DeepCharcoal,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (state.acOn) "AC ACTIVE" else "AC OFF",
                            color = if (state.acOn) HyundaiElectricBlue else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Temperature Adjuster
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (tempVal > 16.5f) {
                                    tempVal -= 0.5f
                                    onSetClimate(ClimateSetRequest(temperatureC = tempVal))
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_temp_down")
                        ) {
                            Text("-", fontSize = 18.sp, color = TextHighContrast)
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${tempVal}°C", color = TextHighContrast, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                            Text("TARGET TEMP", color = TextMuted, fontSize = 10.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                if (tempVal < 29.5f) {
                                    tempVal += 0.5f
                                    onSetClimate(ClimateSetRequest(temperatureC = tempVal))
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_temp_up")
                        ) {
                            Text("+", fontSize = 18.sp, color = TextHighContrast)
                        }
                    }
                }

                Divider(color = BorderGrey)

                // Fan Speed Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("FAN SPEED (1-5)", color = TextSecondary, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..5).forEach { level ->
                            val isSel = level == state.fanSpeed
                            Surface(
                                color = if (isSel) HyundaiElectricBlue else DeepCharcoal,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .testTag("btn_fan_level_$level")
                                    .border(1.dp, BorderGrey, RoundedCornerShape(6.dp))
                            ) {
                                TextButton(
                                    onClick = { onSetClimate(ClimateSetRequest(fanLevel = level)) },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text("$level", color = if (isSel) Color.Black else TextHighContrast, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Quick Toggles: AC & Seat Comfort
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.AcUnit, contentDescription = null, tint = HyundaiElectricBlue)
                        Text("Air Conditioning (A/C)", color = TextSecondary, fontSize = 13.sp)
                    }
                    Switch(
                        checked = state.acOn,
                        onCheckedChange = { onSetClimate(ClimateSetRequest(ac = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = HyundaiElectricBlue)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.WbSunny, contentDescription = null, tint = StatusWarning)
                        Text("Steering Wheel Heater", color = TextSecondary, fontSize = 13.sp)
                    }
                    Switch(
                        checked = state.steeringWheelHeat,
                        onCheckedChange = { onSetClimate(ClimateSetRequest(steeringWheelHeating = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = StatusWarning)
                    )
                }
            }
        }
    }
}
