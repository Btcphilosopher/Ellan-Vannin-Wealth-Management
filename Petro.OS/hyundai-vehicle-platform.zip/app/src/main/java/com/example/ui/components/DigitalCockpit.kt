package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.DriveMode
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun DigitalCockpit(
    state: VehicleState,
    language: Language,
    modifier: Modifier = Modifier
) {
    val modeColor = when (state.driveMode) {
        DriveMode.ECO -> StatusHealthy
        DriveMode.NORMAL -> HyundaiElectricBlue
        DriveMode.SPORT -> StatusFault
        DriveMode.SNOW -> HyundaiPerformanceBlue
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Navigation Turn-by-Turn Banner
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(HyundaiDarkBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Navigation,
                            contentDescription = "Turn icon",
                            tint = HyundaiElectricBlue,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = state.navNextManoeuvre,
                            color = TextHighContrast,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Route: A12 → ${state.navDestination}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${state.navDurationMin} min",
                        color = HyundaiElectricBlue,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${state.navDistanceKm} km | ETA ${state.navArrivalTime}",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Primary Cockpit Instrument Cluster Box
        Surface(
            color = DeepCharcoal,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(16.dp))
                .testTag("digital_cockpit_cluster")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Secondary Bar: Temp & Drive Mode
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Temperatures
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(imageVector = Icons.Default.Thermostat, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
                            Text(text = "EXT: ${state.outsideTemperatureC.toInt()}°C", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(imageVector = Icons.Default.Thermostat, contentDescription = null, tint = HyundaiElectricBlue, modifier = Modifier.size(16.dp))
                            Text(text = "CABIN: ${state.cabinTemperatureC.toInt()}°C", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }

                    // Drive Mode Badge
                    Surface(
                        color = modeColor.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.border(1.dp, modeColor, RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            text = state.driveMode.name,
                            color = modeColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }

                // Center Speedometer & SOC Gauge Layout
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left: Battery SOC Ring Gauge
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(130.dp)
                    ) {
                        val socAngle = (state.batteryPercent / 100f) * 260f
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Background Track
                            drawArc(
                                color = BorderGrey,
                                startAngle = 140f,
                                sweepAngle = 260f,
                                useCenter = false,
                                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                            )
                            // Filled SOC Arc
                            drawArc(
                                brush = Brush.horizontalGradient(listOf(HyundaiDarkBlue, HyundaiElectricBlue)),
                                startAngle = 140f,
                                sweepAngle = socAngle,
                                useCenter = false,
                                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${state.batteryPercent.toInt()}%",
                                color = TextHighContrast,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = Translations.get("battery_soc", language),
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Center: Large Speed & Gear Display
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        // Gear Selector Display
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            listOf("P", "R", "N", "D").forEach { g ->
                                val isCurrentGear = g == state.gear
                                Text(
                                    text = g,
                                    color = if (isCurrentGear) HyundaiElectricBlue else BorderGrey,
                                    fontSize = if (isCurrentGear) 22.sp else 16.sp,
                                    fontWeight = if (isCurrentGear) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }

                        // Digital Speedometer Number
                        Text(
                            text = "${state.speedKph.toInt()}",
                            color = TextHighContrast,
                            fontSize = 64.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = (-2).sp,
                            modifier = Modifier.testTag("speedometer_value")
                        )
                        Text(
                            text = "km/h",
                            color = TextSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Right: Range Gauge
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(130.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawArc(
                                color = BorderGrey,
                                startAngle = 140f,
                                sweepAngle = 260f,
                                useCenter = false,
                                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                            )
                            drawArc(
                                color = StatusHealthy,
                                startAngle = 140f,
                                sweepAngle = minOf(260f, (state.rangeKm / 520f) * 260f),
                                useCenter = false,
                                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${state.rangeKm}",
                                color = TextHighContrast,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "km " + Translations.get("range", language),
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                // Bottom Gauge: Power output & Regenerative Braking bar
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (state.batteryPowerKw < 0) "CHARGE / REGEN: ${-state.batteryPowerKw} kW" else "POWER OUTPUT: ${state.batteryPowerKw} kW",
                            color = if (state.batteryPowerKw < 0) StatusHealthy else HyundaiElectricBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "77.4 kWh EV POWERTRAIN",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    // Power / Regen Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(CircleShape)
                            .background(CardBackground)
                    ) {
                        val powerRatio = minOf(1.0f, maxOf(0.05f, state.batteryPowerKw / 150f))
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(powerRatio)
                                .background(
                                    Brush.horizontalGradient(
                                        if (state.batteryPowerKw < 0) listOf(StatusHealthy, StatusHealthy)
                                        else listOf(HyundaiDarkBlue, HyundaiElectricBlue)
                                    )
                                )
                        )
                    }
                }
            }
        }
    }
}
