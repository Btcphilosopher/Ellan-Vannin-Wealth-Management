package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.ApiExecutionResult
import com.example.ui.theme.*

@Composable
fun ApiConsolePanel(
    selectedEndpoint: String,
    onEndpointSelected: (String) -> Unit,
    payloadText: String,
    onPayloadChanged: (String) -> Unit,
    onExecuteRequest: () -> Unit,
    lastResult: ApiExecutionResult?,
    language: Language,
    modifier: Modifier = Modifier
) {
    val endpoints = listOf(
        "GET /api/v1/vehicle",
        "GET /api/v1/battery",
        "POST /api/v1/drive-mode",
        "POST /api/v1/charging/start",
        "POST /api/v1/charging/stop",
        "POST /api/v1/climate",
        "POST /api/v1/navigation",
        "GET /api/v1/doors",
        "GET /api/v1/diagnostics"
    )

    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Endpoint Selection & Request Builder Box
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                .testTag("api_console_panel")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Code, contentDescription = null, tint = HyundaiElectricBlue)
                    Text("HVDP DEVELOPER API TESTBENCH", color = TextHighContrast, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }

                // Dropdown Selector
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { expanded = true },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("endpoint_selector"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextHighContrast)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedEndpoint, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text("▼", fontSize = 10.sp)
                        }
                    }

                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier
                            .background(DeepCharcoal)
                            .border(1.dp, BorderGrey)
                    ) {
                        endpoints.forEach { ep ->
                            DropdownMenuItem(
                                text = { Text(ep, fontFamily = FontFamily.Monospace, color = TextHighContrast, fontSize = 12.sp) },
                                onClick = {
                                    onEndpointSelected(ep)
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                // Payload Input if POST
                if (selectedEndpoint.startsWith("POST")) {
                    Text(Translations.get("request_payload", language), color = TextSecondary, fontSize = 12.sp)
                    OutlinedTextField(
                        value = payloadText,
                        onValueChange = onPayloadChanged,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("api_payload_input"),
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = HyundaiElectricBlue,
                            unfocusedBorderColor = BorderGrey,
                            focusedTextColor = TextHighContrast,
                            unfocusedTextColor = TextHighContrast
                        )
                    )
                }

                Button(
                    onClick = onExecuteRequest,
                    colors = ButtonDefaults.buttonColors(containerColor = HyundaiDarkBlue),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_try_request")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(Translations.get("try_request", language), fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        }

        // Response Inspector Panel
        if (lastResult != null) {
            val statusColor = when (lastResult.statusCode) {
                200 -> StatusHealthy
                400, 422 -> StatusWarning
                else -> StatusFault
            }

            Surface(
                color = CardBackground,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                    .testTag("api_response_inspector")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = statusColor.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "HTTP ${lastResult.statusCode}",
                                color = statusColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Text("Latency: ${lastResult.latencyMs} ms | ${lastResult.timestamp}", color = TextMuted, fontSize = 11.sp)
                    }

                    Text("Generated cURL Command:", color = TextMuted, fontSize = 10.sp)
                    Surface(
                        color = DeepCharcoal,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "curl -X ${lastResult.method} \"https://hvdp.hyundai.com${lastResult.endpoint}\" -H \"Content-Type: application/json\" ${if (lastResult.requestBodyJson != null) "-d '${lastResult.requestBodyJson}'" else ""}",
                            color = HyundaiElectricBlue,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(8.dp)
                        )
                    }

                    Text(Translations.get("response_payload", language), color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        color = DeepCharcoal,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = lastResult.responseBodyJson,
                            color = TextHighContrast,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}
