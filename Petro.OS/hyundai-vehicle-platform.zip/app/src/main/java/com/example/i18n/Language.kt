package com.example.i18n

enum class Language(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    KOREAN("ko", "한국어"),
    CHINESE("zh", "中文")
}
