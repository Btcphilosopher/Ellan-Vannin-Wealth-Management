package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.FaultCode
import com.example.model.Severity
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun DiagnosticsPanel(
    state: VehicleState,
    language: Language,
    onTriggerSyntheticFault: () -> Unit,
    onClearFaults: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // System Health Overview Grid
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                .testTag("diagnostics_panel")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = Translations.get("vehicle_health", language),
                        color = TextHighContrast,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onTriggerSyntheticFault,
                            colors = ButtonDefaults.buttonColors(containerColor = HyundaiDarkBlue),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.testTag("btn_trigger_fault")
                        ) {
                            Icon(imageVector = Icons.Default.BugReport, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(Translations.get("trigger_synthetic_fault", language), fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = onClearFaults,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.testTag("btn_clear_faults")
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(Translations.get("clear_faults", language), fontSize = 11.sp, color = TextHighContrast)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HealthStatusCard("Battery System", "${state.sohPercent}% SOH", StatusHealthy)
                    HealthStatusCard("Motor / Powertrain", "NORMAL", StatusHealthy)
                    HealthStatusCard("Braking & ABS", "NORMAL", StatusHealthy)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HealthStatusCard("Tire TPMS", "NORMAL 35 PSI", StatusHealthy)
                    HealthStatusCard("HVAC System", if (state.faults.any { it.code.contains("HVAC") }) "DEV_WARNING" else "NORMAL", if (state.faults.any { it.code.contains("HVAC") }) StatusWarning else StatusHealthy)
                    HealthStatusCard("Connectivity", state.connectivityStatus, StatusHealthy)
                }
            }
        }

        // Active Fault Codes (DTC) Log
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ACTIVE DIAGNOSTIC TROUBLE CODES (DTC)",
                    color = TextHighContrast,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                if (state.faults.isEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = StatusHealthy)
                        Spacer(Modifier.width(8.dp))
                        Text("No active diagnostic fault codes detected.", color = StatusHealthy, fontSize = 13.sp)
                    }
                } else {
                    state.faults.forEach { fault ->
                        FaultCodeItem(fault)
                    }
                }
            }
        }
    }
}

@Composable
private fun HealthStatusCard(title: String, status: String, color: Color) {
    Column {
        Text(title, color = TextMuted, fontSize = 10.sp)
        Text(status, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FaultCodeItem(fault: FaultCode) {
    val badgeColor = when (fault.severity) {
        Severity.INFO -> HyundaiElectricBlue
        Severity.WARNING -> StatusWarning
        Severity.FAULT -> StatusFault
    }

    Surface(
        color = DeepCharcoal,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderGrey, RoundedCornerShape(8.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = badgeColor.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = fault.code,
                        color = badgeColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Column {
                    Text(fault.description, color = TextHighContrast, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text("Severity: ${fault.severity.name}", color = TextMuted, fontSize = 10.sp)
                }
            }

            Text(fault.timestamp, color = TextMuted, fontSize = 11.sp)
        }
    }
}
