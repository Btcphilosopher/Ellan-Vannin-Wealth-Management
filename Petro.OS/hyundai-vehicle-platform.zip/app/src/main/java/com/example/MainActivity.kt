package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.MainDashboardScreen
import com.example.ui.theme.HyundaiVehiclePlatformTheme
import com.example.ui.viewmodel.VehicleViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: VehicleViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HyundaiVehiclePlatformTheme {
                MainDashboardScreen(viewModel = viewModel)
            }
        }
    }
}
