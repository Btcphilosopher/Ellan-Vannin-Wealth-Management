package com.example.ui.components

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun BatteryPanel(
    state: VehicleState,
    language: Language,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Battery Core Metrics Card
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                .testTag("battery_metrics_card")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "77.4 kWh HIGH-VOLTAGE LITHIUM BATTERY",
                            color = HyundaiElectricBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "800V Ultra-Fast Architecture",
                            color = TextHighContrast,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        color = StatusHealthy.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "HEALTHY",
                            color = StatusHealthy,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Divider(color = BorderGrey)

                // Grid of telemetry values
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricBox(Translations.get("battery_soc", language), "${state.batteryPercent}%", HyundaiElectricBlue)
                    MetricBox(Translations.get("soh", language), "${state.sohPercent}%", StatusHealthy)
                    MetricBox(Translations.get("range", language), "${state.rangeKm} km", TextHighContrast)
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricBox(Translations.get("voltage", language), "${state.batteryVoltageV} V", TextSecondary)
                    MetricBox(Translations.get("current", language), "${state.batteryCurrentA} A", TextSecondary)
                    MetricBox(Translations.get("power", language), "${state.batteryPowerKw} kW", if (state.batteryPowerKw < 0) StatusHealthy else TextHighContrast)
                }
            }
        }

        // Thermal Dynamics Card
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "EV POWERTRAIN THERMAL SYSTEM",
                    color = TextHighContrast,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                ThermalItem(Translations.get("battery_temp", language), state.batteryTempC, 20f, 45f)
                ThermalItem(Translations.get("motor_temp", language), state.motorTempC, 30f, 90f)
                ThermalItem(Translations.get("inverter_temp", language), state.inverterTempC, 25f, 80f)
            }
        }
    }
}

@Composable
private fun MetricBox(title: String, value: String, valueColor: Color) {
    Column {
        Text(title, color = TextMuted, fontSize = 11.sp)
        Text(value, color = valueColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ThermalItem(title: String, tempC: Float, minNormal: Float, maxNormal: Float) {
    val isWarning = tempC > maxNormal
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, color = TextSecondary, fontSize = 12.sp)
            Text(
                text = "${tempC.toInt()}°C",
                color = if (isWarning) StatusWarning else StatusHealthy,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
        LinearProgressIndicator(
            progress = { (tempC / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color = if (isWarning) StatusWarning else StatusHealthy,
            trackColor = DeepCharcoal
        )
    }
}
