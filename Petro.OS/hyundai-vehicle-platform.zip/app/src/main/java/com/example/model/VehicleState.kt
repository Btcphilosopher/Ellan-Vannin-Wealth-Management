package com.example.model

enum class DriveMode {
    ECO, NORMAL, SPORT, SNOW
}

enum class ChargingStatus {
    DISCHARGING, AC_CHARGING, DC_FAST_CHARGING, COMPLETE, ERROR
}

data class DoorState(
    val frontLeftLocked: Boolean = true,
    val frontRightLocked: Boolean = true,
    val rearLeftLocked: Boolean = true,
    val rearRightLocked: Boolean = true,
    val trunkClosed: Boolean = true,
    val frontLeftOpen: Boolean = false,
    val frontRightOpen: Boolean = false,
    val rearLeftOpen: Boolean = false,
    val rearRightOpen: Boolean = false,
    val trunkOpen: Boolean = false
)

data class WindowState(
    val frontLeftPercent: Float = 0f, // 0 = Closed, 100 = Fully open
    val frontRightPercent: Float = 0f,
    val rearLeftPercent: Float = 0f,
    val rearRightPercent: Float = 0f
)

enum class IndicatorState {
    OFF, LEFT, RIGHT, HAZARD
}

data class LightState(
    val headlights: Boolean = true,
    val highBeam: Boolean = false,
    val drl: Boolean = true,
    val hazardLights: Boolean = false,
    val indicators: IndicatorState = IndicatorState.OFF,
    val interiorLights: Boolean = false,
    val ambientColorHex: String = "#00AAD2"
)

data class TirePressure(
    val frontLeftPsi: Float = 35.0f,
    val frontRightPsi: Float = 35.2f,
    val rearLeftPsi: Float = 34.8f,
    val rearRightPsi: Float = 35.1f
)

enum class Severity {
    INFO, WARNING, FAULT
}

data class FaultCode(
    val code: String,
    val description: String,
    val severity: Severity,
    val timestamp: String
)

data class VehicleState(
    val vehicleId: String = "HVDP-DEMO-001",
    val model: String = "IONIQ 6",
    val variant: String = "Long Range AWD",
    val vin: String = "KMHE84EV2PU019612",
    val speedKph: Float = 82f,
    val accelerationMps2: Float = 0.2f,
    val motorRpm: Int = 4250,
    val gear: String = "D",
    val batteryPercent: Float = 78.2f,
    val rangeKm: Int = 412,
    val outsideTemperatureC: Float = 17f,
    val cabinTemperatureC: Float = 21f,
    val driverTargetTempC: Float = 22f,
    val passengerTargetTempC: Float = 22f,
    val fanSpeed: Int = 3,
    val acOn: Boolean = true,
    val seatHeatLeft: Int = 1,
    val seatHeatRight: Int = 0,
    val seatVentLeft: Int = 0,
    val seatVentRight: Int = 0,
    val steeringWheelHeat: Boolean = false,
    val defrostOn: Boolean = false,
    val recirculationOn: Boolean = true,
    val driveMode: DriveMode = DriveMode.NORMAL,
    val charging: Boolean = false,
    val pluggedIn: Boolean = false,
    val chargingStatus: ChargingStatus = ChargingStatus.DISCHARGING,
    val chargingPowerKw: Float = 0f,
    val targetSocPercent: Float = 80f,
    val chargingTimeRemainingMin: Int = 0,
    val doorsLocked: Boolean = true,
    val doors: DoorState = DoorState(),
    val windows: WindowState = WindowState(),
    val lights: LightState = LightState(),
    val tires: TirePressure = TirePressure(),
    val sohPercent: Float = 98.7f,
    val batteryVoltageV: Float = 712.4f,
    val batteryCurrentA: Float = -42.1f,
    val batteryPowerKw: Float = 30.0f,
    val batteryTempC: Float = 29.4f,
    val motorTempC: Float = 48.2f,
    val inverterTempC: Float = 42.0f,
    val brakePressureBar: Float = 12.5f,
    val steeringAngleDeg: Float = -1.2f,
    val acceleratorPosPercent: Float = 24.0f,
    val latitude: Double = 37.5665,
    val longitude: Double = 126.9780,
    val navDestination: String = "Incheon International Airport",
    val navDistanceKm: Float = 58.4f,
    val navDurationMin: Int = 54,
    val navArrivalTime: String = "19:42",
    val navTraffic: String = "MODERATE",
    val navNextManoeuvre: String = "Exit in 800 m",
    val energyDriveKwh: Float = 18.4f,
    val energyClimateKwh: Float = 1.2f,
    val energyConditioningKwh: Float = 0.6f,
    val energyRegenKwh: Float = -3.8f,
    val netEnergyKwh: Float = 16.4f,
    val connectivityStatus: String = "5G CONNECTED",
    val hornActive: Boolean = false,
    val faults: List<FaultCode> = listOf(
        FaultCode("HVAC-204", "Cabin temperature sensor deviation", Severity.WARNING, "18:32:10"),
        FaultCode("BMS-101", "Cell voltage equilibrium check normal", Severity.INFO, "18:20:00")
    )
)
