package com.example.i18n

object Translations {
    fun get(key: String, lang: Language): String {
        return translations[key]?.get(lang) ?: key
    }

    private val translations = mapOf(
        // App & System
        "app_title" to mapOf(
            Language.ENGLISH to "HYUNDAI VEHICLE PLATFORM",
            Language.KOREAN to "현대 자동차 플랫폼",
            Language.CHINESE to "现代汽车软件平台"
        ),
        "app_subtitle" to mapOf(
            Language.ENGLISH to "HVDP — Hyundai Vehicle Dashboard Platform",
            Language.KOREAN to "HVDP — 현대 차량 대시보드 플랫폼",
            Language.CHINESE to "HVDP — 现代汽车仪表盘平台"
        ),
        "vehicle_model" to mapOf(
            Language.ENGLISH to "IONIQ 6 Long Range AWD",
            Language.KOREAN to "아이오닉 6 Long Range AWD",
            Language.CHINESE to "艾尼氪 6 长续航四驱版"
        ),
        "safety_boundary_title" to mapOf(
            Language.ENGLISH to "Safety Boundary Notice",
            Language.KOREAN to "안전 경계 고지",
            Language.CHINESE to "安全边界声明"
        ),
        "safety_boundary_desc" to mapOf(
            Language.ENGLISH to "This simulator controls only safe vehicle auxiliary systems (doors, climate, charging, lights). Safety-critical steering and braking controls are read-only simulated states.",
            Language.KOREAN to "본 시뮬레이터는 안전한 차량 부가 시스템(도어, 공조, 충전, 조명)만 제어합니다. 조향 및 제동 등 안전 핵심 기능은 읽기 전용 시뮬레이션 상태로 제한됩니다.",
            Language.CHINESE to "本仿真系统仅控制安全车身辅助系统（车门、空调、充电、灯光）。转向和制动等关键安全控制仅作为只读模拟状态展示。"
        ),

        // Nav Tabs
        "tab_cockpit" to mapOf(
            Language.ENGLISH to "Digital Cockpit",
            Language.KOREAN to "디지털 콕핏",
            Language.CHINESE to "数字座舱"
        ),
        "tab_vehicle" to mapOf(
            Language.ENGLISH to "Vehicle Control",
            Language.KOREAN to "차량 제어",
            Language.CHINESE to "车辆控制"
        ),
        "tab_battery" to mapOf(
            Language.ENGLISH to "Battery",
            Language.KOREAN to "배터리",
            Language.CHINESE to "电池"
        ),
        "tab_charging" to mapOf(
            Language.ENGLISH to "Charging",
            Language.KOREAN to "충전",
            Language.CHINESE to "充电"
        ),
        "tab_climate" to mapOf(
            Language.ENGLISH to "Climate",
            Language.KOREAN to "공조",
            Language.CHINESE to "空调"
        ),
        "tab_navigation" to mapOf(
            Language.ENGLISH to "Navigation",
            Language.KOREAN to "내비게이션",
            Language.CHINESE to "导航"
        ),
        "tab_energy" to mapOf(
            Language.ENGLISH to "Energy",
            Language.KOREAN to "에너지",
            Language.CHINESE to "能量"
        ),
        "tab_diagnostics" to mapOf(
            Language.ENGLISH to "Diagnostics",
            Language.KOREAN to "차량 진단",
            Language.CHINESE to "车辆诊断"
        ),
        "tab_api_console" to mapOf(
            Language.ENGLISH to "API Console",
            Language.KOREAN to "API 콘솔",
            Language.CHINESE to "API 控制台"
        ),
        "tab_telemetry_terminal" to mapOf(
            Language.ENGLISH to "Telemetry Stream",
            Language.KOREAN to "텔레메트리 스트림",
            Language.CHINESE to "遥测数据流"
        ),
        "tab_graphs" to mapOf(
            Language.ENGLISH to "Live Graphs",
            Language.KOREAN to "실시간 그래프",
            Language.CHINESE to "实时图表"
        ),
        "tab_ai_assistant" to mapOf(
            Language.ENGLISH to "AI Diagnostics",
            Language.KOREAN to "AI 진단 보조",
            Language.CHINESE to "AI 智能诊断"
        ),

        // Cockpit & Metrics
        "speed" to mapOf(
            Language.ENGLISH to "Speed",
            Language.KOREAN to "속도",
            Language.CHINESE to "车速"
        ),
        "range" to mapOf(
            Language.ENGLISH to "Range",
            Language.KOREAN to "주행 가능 거리",
            Language.CHINESE to "续航里程"
        ),
        "battery_soc" to mapOf(
            Language.ENGLISH to "Battery SOC",
            Language.KOREAN to "배터리 충전율",
            Language.CHINESE to "电池电量"
        ),
        "drive_mode" to mapOf(
            Language.ENGLISH to "Drive Mode",
            Language.KOREAN to "주행 모드",
            Language.CHINESE to "驾驶模式"
        ),
        "outside_temp" to mapOf(
            Language.ENGLISH to "Outside Temp",
            Language.KOREAN to "외기 온도",
            Language.CHINESE to "室外温度"
        ),
        "cabin_temp" to mapOf(
            Language.ENGLISH to "Cabin Temp",
            Language.KOREAN to "실내 온도",
            Language.CHINESE to "车内温度"
        ),
        "next_turn" to mapOf(
            Language.ENGLISH to "Next Manoeuvre",
            Language.KOREAN to "다음 회전",
            Language.CHINESE to "下一转向"
        ),
        "destination" to mapOf(
            Language.ENGLISH to "Destination",
            Language.KOREAN to "목적지",
            Language.CHINESE to "目的地"
        ),
        "eta" to mapOf(
            Language.ENGLISH to "Arrival Time",
            Language.KOREAN to "도착 예정 시간",
            Language.CHINESE to "预计到达时间"
        ),

        // Battery & Charging
        "soh" to mapOf(
            Language.ENGLISH to "State of Health",
            Language.KOREAN to "배터리 수명 (SOH)",
            Language.CHINESE to "电池健康度"
        ),
        "voltage" to mapOf(
            Language.ENGLISH to "Voltage",
            Language.KOREAN to "전압",
            Language.CHINESE to "电压"
        ),
        "current" to mapOf(
            Language.ENGLISH to "Current",
            Language.KOREAN to "전류",
            Language.CHINESE to "电流"
        ),
        "power" to mapOf(
            Language.ENGLISH to "Power Output",
            Language.KOREAN to "출력",
            Language.CHINESE to "功率"
        ),
        "battery_temp" to mapOf(
            Language.ENGLISH to "Battery Temp",
            Language.KOREAN to "배터리 온도",
            Language.CHINESE to "电池温度"
        ),
        "motor_temp" to mapOf(
            Language.ENGLISH to "Motor Temp",
            Language.KOREAN to "모터 온도",
            Language.CHINESE to "电机温度"
        ),
        "inverter_temp" to mapOf(
            Language.ENGLISH to "Inverter Temp",
            Language.KOREAN to "인버터 온도",
            Language.CHINESE to "逆变器温度"
        ),
        "plugged_in" to mapOf(
            Language.ENGLISH to "Plug Status",
            Language.KOREAN to "플러그 연결 상태",
            Language.CHINESE to "插头状态"
        ),
        "start_charging" to mapOf(
            Language.ENGLISH to "Start Charging",
            Language.KOREAN to "충전 시작",
            Language.CHINESE to "开始充电"
        ),
        "stop_charging" to mapOf(
            Language.ENGLISH to "Stop Charging",
            Language.KOREAN to "충전 중지",
            Language.CHINESE to "停止充电"
        ),
        "target_soc" to mapOf(
            Language.ENGLISH to "Target Charge Level",
            Language.KOREAN to "목표 충전율",
            Language.CHINESE to "目标充电电量"
        ),
        "charging_type" to mapOf(
            Language.ENGLISH to "Charging Type",
            Language.KOREAN to "충전 방식",
            Language.CHINESE to "充电类型"
        ),
        "charging_fast_dc" to mapOf(
            Language.ENGLISH to "DC Ultra-Fast (350kW)",
            Language.KOREAN to "DC 초급속 (350kW)",
            Language.CHINESE to "DC 超级快充 (350kW)"
        ),
        "charging_ac" to mapOf(
            Language.ENGLISH to "AC Standard (11kW)",
            Language.KOREAN to "AC 완속 (11kW)",
            Language.CHINESE to "AC 交流慢充 (11kW)"
        ),
        "time_remaining" to mapOf(
            Language.ENGLISH to "Time Remaining",
            Language.KOREAN to "남은 시간",
            Language.CHINESE to "剩余时间"
        ),

        // Controls
        "doors" to mapOf(
            Language.ENGLISH to "Doors & Lock State",
            Language.KOREAN to "도어 및 잠금 상태",
            Language.CHINESE to "车门与锁止状态"
        ),
        "lock_all" to mapOf(
            Language.ENGLISH to "Lock All Doors",
            Language.KOREAN to "전체 도어 잠금",
            Language.CHINESE to "锁定全车门"
        ),
        "unlock_all" to mapOf(
            Language.ENGLISH to "Unlock All Doors",
            Language.KOREAN to "전체 도어 잠금 해제",
            Language.CHINESE to "解锁全车门"
        ),
        "windows" to mapOf(
            Language.ENGLISH to "Windows Control",
            Language.KOREAN to "창문 제어",
            Language.CHINESE to "车窗控制"
        ),
        "lights" to mapOf(
            Language.ENGLISH to "Exterior & Interior Lighting",
            Language.KOREAN to "외부 및 내부 조명",
            Language.CHINESE to "车外与车内灯光"
        ),
        "headlights" to mapOf(
            Language.ENGLISH to "Headlights",
            Language.KOREAN to "전조등",
            Language.CHINESE to "前大灯"
        ),
        "high_beam" to mapOf(
            Language.ENGLISH to "High Beam",
            Language.KOREAN to "상향등",
            Language.CHINESE to "远光灯"
        ),
        "drl" to mapOf(
            Language.ENGLISH to "DRL",
            Language.KOREAN to "주간주행등 (DRL)",
            Language.CHINESE to "日间行车灯"
        ),
        "hazard_lights" to mapOf(
            Language.ENGLISH to "Hazard Lights",
            Language.KOREAN to "비상경고등",
            Language.CHINESE to "危险警示灯"
        ),
        "interior_lights" to mapOf(
            Language.ENGLISH to "Interior Ambient Light",
            Language.KOREAN to "실내 앰비언트 무드램프",
            Language.CHINESE to "车内氛围灯"
        ),
        "horn" to mapOf(
            Language.ENGLISH to "Sound Horn",
            Language.KOREAN to "경적 울림",
            Language.CHINESE to "鸣笛"
        ),

        // Energy Flow
        "energy_flow" to mapOf(
            Language.ENGLISH to "EV Powertrain Energy Flow",
            Language.KOREAN to "EV 파워트레인 에너지 흐름",
            Language.CHINESE to "纯电动力总成能量流"
        ),
        "energy_drive" to mapOf(
            Language.ENGLISH to "Drive Consumption",
            Language.KOREAN to "주행 소비",
            Language.CHINESE to "行驶消耗"
        ),
        "energy_climate" to mapOf(
            Language.ENGLISH to "Climate Systems",
            Language.KOREAN to "공조 시스템",
            Language.CHINESE to "空调消耗"
        ),
        "energy_conditioning" to mapOf(
            Language.ENGLISH to "Battery Conditioning",
            Language.KOREAN to "배터리 컨디셔닝",
            Language.CHINESE to "电池预热/冷却"
        ),
        "energy_regen" to mapOf(
            Language.ENGLISH to "Regenerative Braking",
            Language.KOREAN to "회생 제동 에너지 회수",
            Language.CHINESE to "能量回收"
        ),
        "energy_net" to mapOf(
            Language.ENGLISH to "Net Energy Balance",
            Language.KOREAN to "순 에너지 소비량",
            Language.CHINESE to "净能量消耗"
        ),

        // Diagnostics
        "vehicle_health" to mapOf(
            Language.ENGLISH to "Vehicle Health Status",
            Language.KOREAN to "차량 건강 상태",
            Language.CHINESE to "车辆健康状态"
        ),
        "trigger_synthetic_fault" to mapOf(
            Language.ENGLISH to "Simulate Synthetic Fault",
            Language.KOREAN to "가상 고장 코드 발생",
            Language.CHINESE to "模拟合成故障码"
        ),
        "clear_faults" to mapOf(
            Language.ENGLISH to "Clear Fault Log",
            Language.KOREAN to "고장 이력 소거",
            Language.CHINESE to "清除故障记录"
        ),

        // API Console
        "try_request" to mapOf(
            Language.ENGLISH to "TRY REQUEST",
            Language.KOREAN to "요청 실행",
            Language.CHINESE to "发送请求"
        ),
        "request_payload" to mapOf(
            Language.ENGLISH to "Request Body (JSON)",
            Language.KOREAN to "요청 본문 (JSON)",
            Language.CHINESE to "请求体 (JSON)"
        ),
        "response_payload" to mapOf(
            Language.ENGLISH to "Response Body (JSON)",
            Language.KOREAN to "응답 본문 (JSON)",
            Language.CHINESE to "响应体 (JSON)"
        ),
        "status_code" to mapOf(
            Language.ENGLISH to "HTTP Status",
            Language.KOREAN to "HTTP 상태",
            Language.CHINESE to "HTTP 状态码"
        ),
        "latency" to mapOf(
            Language.ENGLISH to "Latency",
            Language.KOREAN to "응답 지연 시간",
            Language.CHINESE to "响应延迟"
        ),
        "curl_cmd" to mapOf(
            Language.ENGLISH to "cURL Command",
            Language.KOREAN to "cURL 명령어",
            Language.CHINESE to "cURL 命令"
        )
    )
}
