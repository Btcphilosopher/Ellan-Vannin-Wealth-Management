package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val HyundaiDarkBlue = Color(0xFF002C5F)
val HyundaiElectricBlue = Color(0xFF00AAD2)
val HyundaiPerformanceBlue = Color(0xFF80B3FF)

val DarkGraphite = Color(0xFF0A0C10)
val DeepCharcoal = Color(0xFF12161F)
val CardBackground = Color(0xFF1B202B)
val CardElevated = Color(0xFF242A38)
val BorderGrey = Color(0xFF2A3241)

val TextHighContrast = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF818CF8)

val StatusHealthy = Color(0xFF10B981)
val StatusWarning = Color(0xFFF59E0B)
val StatusFault = Color(0xFFEF4444)
