package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val HyundaiColorScheme = darkColorScheme(
    primary = HyundaiElectricBlue,
    onPrimary = Color.White,
    primaryContainer = HyundaiDarkBlue,
    onPrimaryContainer = Color.White,
    secondary = HyundaiPerformanceBlue,
    onSecondary = Color.Black,
    background = DarkGraphite,
    onBackground = TextHighContrast,
    surface = DeepCharcoal,
    onSurface = TextHighContrast,
    surfaceVariant = CardBackground,
    onSurfaceVariant = TextSecondary,
    outline = BorderGrey,
    error = StatusFault,
    onError = Color.White
)

@Composable
fun HyundaiVehiclePlatformTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HyundaiColorScheme,
        typography = Typography,
        content = content
    )
}
