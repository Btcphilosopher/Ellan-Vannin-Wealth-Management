package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.i18n.Language
import com.example.model.*
import com.example.repository.VehicleRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.random.Random

enum class TimeWindow(val label: String, val pointCount: Int) {
    SEC_10("10 sec", 100),
    MIN_1("1 min", 200),
    MIN_5("5 min", 300),
    MIN_30("30 min", 300)
}

class VehicleViewModel(
    val repository: VehicleRepository = VehicleRepository()
) : ViewModel() {

    private val _language = MutableStateFlow(Language.ENGLISH)
    val language: StateFlow<Language> = _language.asStateFlow()

    val vehicleState: StateFlow<VehicleState> = repository.vehicleState
    val telemetryEvents: SharedFlow<TelemetryEvent> = repository.telemetryEvents
    val telemetryHistory: StateFlow<List<TelemetryPoint>> = repository.telemetryHistory

    private val _timeWindow = MutableStateFlow(TimeWindow.MIN_1)
    val timeWindow: StateFlow<TimeWindow> = _timeWindow.asStateFlow()

    // API Console State
    private val _selectedEndpoint = MutableStateFlow("GET /api/v1/vehicle")
    val selectedEndpoint: StateFlow<String> = _selectedEndpoint.asStateFlow()

    private val _apiConsolePayload = MutableStateFlow("{\n  \"mode\": \"SPORT\"\n}")
    val apiConsolePayload: StateFlow<String> = _apiConsolePayload.asStateFlow()

    private val _lastApiResult = MutableStateFlow<ApiExecutionResult?>(null)
    val lastApiResult: StateFlow<ApiExecutionResult?> = _lastApiResult.asStateFlow()

    // Gemini AI State
    private val _aiResponse = MutableStateFlow("")
    val aiResponse: StateFlow<String> = _aiResponse.asStateFlow()

    private val _aiLoading = MutableStateFlow(false)
    val aiLoading: StateFlow<Boolean> = _aiLoading.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun setLanguage(lang: Language) {
        _language.value = lang
    }

    fun setTimeWindow(window: TimeWindow) {
        _timeWindow.value = window
    }

    fun setSelectedEndpoint(endpoint: String) {
        _selectedEndpoint.value = endpoint
        // Set default template payload based on endpoint
        _apiConsolePayload.value = when {
            endpoint.contains("/drive-mode") -> "{\n  \"mode\": \"SPORT\"\n}"
            endpoint.contains("/charging/start") -> "{\n  \"targetSoc\": 80.0,\n  \"chargingType\": \"DC_FAST\"\n}"
            endpoint.contains("/climate") -> "{\n  \"temperatureC\": 22.0,\n  \"fanLevel\": 3,\n  \"ac\": true\n}"
            endpoint.contains("/navigation") -> "{\n  \"destination\": \"Incheon International Airport\"\n}"
            endpoint.contains("/lights") -> "{\n  \"headlights\": true,\n  \"highBeam\": false,\n  \"hazardLights\": false\n}"
            endpoint.contains("/doors") -> "{\n  \"lockAll\": true\n}"
            else -> "{}"
        }
    }

    fun setApiConsolePayload(payload: String) {
        _apiConsolePayload.value = payload
    }

    // Direct Simulated REST API Dispatcher
    fun executeConsoleApiRequest() {
        val endpoint = _selectedEndpoint.value
        val payload = _apiConsolePayload.value
        val startTime = System.currentTimeMillis()

        val method = endpoint.split(" ")[0]
        val path = endpoint.split(" ")[1]

        var statusCode = 200
        var responseJson = "{}"

        try {
            when {
                path == "/api/v1/vehicle" -> {
                    responseJson = formatStateToJson(vehicleState.value)
                }
                path == "/api/v1/battery" -> {
                    val st = vehicleState.value
                    responseJson = """
                    {
                      "soc": ${st.batteryPercent},
                      "soh": ${st.sohPercent},
                      "voltage": ${st.batteryVoltageV},
                      "current": ${st.batteryCurrentA},
                      "powerKw": ${st.batteryPowerKw},
                      "temperatureC": ${st.batteryTempC},
                      "rangeKm": ${st.rangeKm}
                    }
                    """.trimIndent()
                }
                path == "/api/v1/drive-mode" && method == "POST" -> {
                    val mode = JSONObject(payload).optString("mode", "")
                    val res = repository.setDriveMode(mode)
                    if (res.isSuccess) {
                        val d = res.getOrThrow()
                        responseJson = """
                        {
                          "success": true,
                          "previousMode": "${d.previousMode}",
                          "currentMode": "${d.currentMode}"
                        }
                        """.trimIndent()
                    } else {
                        statusCode = 422
                        responseJson = formatError("INVALID_PARAMETER", res.exceptionOrNull()?.message ?: "Invalid drive mode")
                    }
                }
                path == "/api/v1/charging/start" && method == "POST" -> {
                    val obj = JSONObject(payload)
                    val targetSoc = obj.optDouble("targetSoc", 80.0).toFloat()
                    val cType = obj.optString("chargingType", "DC_FAST")
                    val isDc = cType.contains("DC")
                    val res = repository.startCharging(targetSoc, isDc)
                    if (res.isSuccess) {
                        responseJson = """
                        {
                          "status": "CHARGING_STARTED",
                          "targetSoc": $targetSoc,
                          "type": "$cType"
                        }
                        """.trimIndent()
                    } else {
                        statusCode = 400
                        responseJson = formatError("INVALID_PARAMETER", res.exceptionOrNull()?.message ?: "Invalid charging parameters")
                    }
                }
                path == "/api/v1/charging/stop" && method == "POST" -> {
                    repository.stopCharging()
                    responseJson = "{\n  \"status\": \"CHARGING_STOPPED\"\n}"
                }
                path == "/api/v1/climate" && method == "POST" -> {
                    val obj = JSONObject(payload)
                    val temp = if (obj.has("temperatureC")) obj.getDouble("temperatureC").toFloat() else null
                    val fan = if (obj.has("fanLevel")) obj.getInt("fanLevel") else null
                    val ac = if (obj.has("ac")) obj.getBoolean("ac") else null
                    val res = repository.setClimate(temp, fan, ac, null, null)
                    if (res.isSuccess) {
                        responseJson = "{\n  \"status\": \"CLIMATE_UPDATED\"\n}"
                    } else {
                        statusCode = 400
                        responseJson = formatError("INVALID_PARAMETER", res.exceptionOrNull()?.message ?: "Invalid climate parameter")
                    }
                }
                path == "/api/v1/navigation" && method == "POST" -> {
                    val dest = JSONObject(payload).optString("destination", "")
                    val res = repository.setNavigation(dest)
                    if (res.isSuccess) {
                        val d = res.getOrThrow()
                        responseJson = """
                        {
                          "destination": "${d.destination}",
                          "distanceKm": ${d.distanceKm},
                          "durationMinutes": ${d.durationMinutes},
                          "arrivalTime": "${d.arrivalTime}",
                          "traffic": "${d.traffic}"
                        }
                        """.trimIndent()
                    } else {
                        statusCode = 400
                        responseJson = formatError("INVALID_PARAMETER", res.exceptionOrNull()?.message ?: "Invalid destination")
                    }
                }
                path == "/api/v1/doors" -> {
                    val st = vehicleState.value
                    responseJson = """
                    {
                      "doorsLocked": ${st.doorsLocked},
                      "frontLeft": "${if (st.doors.frontLeftLocked) "LOCKED" else "UNLOCKED"}",
                      "frontRight": "${if (st.doors.frontRightLocked) "LOCKED" else "UNLOCKED"}",
                      "rearLeft": "${if (st.doors.rearLeftLocked) "LOCKED" else "UNLOCKED"}",
                      "rearRight": "${if (st.doors.rearRightLocked) "LOCKED" else "UNLOCKED"}",
                      "trunk": "${if (st.doors.trunkClosed) "CLOSED" else "OPEN"}"
                    }
                    """.trimIndent()
                }
                path == "/api/v1/diagnostics" -> {
                    val st = vehicleState.value
                    val faultArray = st.faults.joinToString(",") { f ->
                        "{\"code\": \"${f.code}\", \"description\": \"${f.description}\", \"severity\": \"${f.severity}\"}"
                    }
                    responseJson = """
                    {
                      "overallStatus": "${if (st.faults.isEmpty()) "HEALTHY" else "WARNING"}",
                      "battery": "${st.sohPercent}% HEALTHY",
                      "motor": "NORMAL",
                      "brakes": "NORMAL",
                      "tyres": "NORMAL 35 PSI",
                      "hvac": "${if (st.faults.any { it.code.contains("HVAC") }) "SENSOR_WARNING" else "NORMAL"}",
                      "connectivity": "${st.connectivityStatus}",
                      "activeFaults": [$faultArray]
                    }
                    """.trimIndent()
                }
                else -> {
                    statusCode = 404
                    responseJson = formatError("NOT_FOUND", "Endpoint $path not found")
                }
            }
        } catch (e: Exception) {
            statusCode = 400
            responseJson = formatError("BAD_REQUEST", "Malformed JSON or parameter type error: ${e.message}")
        }

        val latency = max(12L, System.currentTimeMillis() - startTime)
        val result = ApiExecutionResult(
            method = method,
            endpoint = path,
            statusCode = statusCode,
            latencyMs = latency,
            requestBodyJson = if (method == "POST") payload else null,
            responseBodyJson = responseJson,
            timestamp = timeFormat.format(Date())
        )
        _lastApiResult.value = result
    }

    private fun formatError(code: String, msg: String): String {
        val reqId = "req-demo-${Random.nextInt(1000, 9999)}"
        return """
        {
          "error": {
            "code": "$code",
            "message": "$msg",
            "requestId": "$reqId"
          }
        }
        """.trimIndent()
    }

    private fun formatStateToJson(st: VehicleState): String {
        return """
        {
          "vehicleId": "${st.vehicleId}",
          "model": "${st.model}",
          "variant": "${st.variant}",
          "speedKph": ${st.speedKph},
          "gear": "${st.gear}",
          "batteryPercent": ${st.batteryPercent},
          "rangeKm": ${st.rangeKm},
          "outsideTemperatureC": ${st.outsideTemperatureC},
          "cabinTemperatureC": ${st.cabinTemperatureC},
          "driveMode": "${st.driveMode}",
          "charging": ${st.charging},
          "doorsLocked": ${st.doorsLocked},
          "latitude": ${st.latitude},
          "longitude": ${st.longitude}
        }
        """.trimIndent()
    }

    // AI Telemetry Assistant Integration via Gemini API
    fun askAiAssistant(query: String) {
        if (query.isBlank()) return
        _aiLoading.value = true
        _aiResponse.value = ""

        viewModelScope.launch(Dispatchers.IO) {
            val st = vehicleState.value
            val faultsSummary = st.faults.joinToString { f -> "[${f.code}: ${f.description}]" }
            val contextPrompt = """
            You are the Hyundai Vehicle Platform (HVDP) AI Diagnostics Specialist for IONIQ 6 Long Range AWD.
            Current Vehicle Context:
            - Speed: ${st.speedKph} km/h, Drive Mode: ${st.driveMode}
            - Battery SOC: ${st.batteryPercent}%, Range: ${st.rangeKm} km, SOH: ${st.sohPercent}%
            - Active Faults: $faultsSummary
            - Charging Status: ${st.chargingStatus}, Power: ${st.chargingPowerKw} kW
            - Cabin Temp: ${st.cabinTemperatureC}°C (Target: ${st.driverTargetTempC}°C)

            User Query: $query

            Provide a concise, professional automotive engineering diagnostic answer in 2-4 bullet points.
            """.trimIndent()

            val apiKey = com.example.BuildConfig.GEMINI_API_KEY
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                // Fallback deterministic smart analysis if API key is not configured in secrets
                delay(800)
                val fallbackAnswer = when {
                    query.contains("fault", ignoreCase = true) || query.contains("diagnostic", ignoreCase = true) ->
                        "• Diagnostics Scan: ${if (st.faults.isEmpty()) "All 12 vehicle ECUs operating within nominal thresholds." else "Detected ${st.faults.size} fault code(s). Primary: ${st.faults.first().code} (${st.faults.first().description})."}\n" +
                        "• Recommendation: Inspect HVAC cabin thermistor resistance values. Reset fault code after calibration.\n" +
                        "• Safety Status: Non-safety critical fault. Vehicle driveability unaffected."
                    query.contains("battery", ignoreCase = true) || query.contains("range", ignoreCase = true) ->
                        "• Battery Health: SOH is at ${st.sohPercent}%. Active thermal management maintains cells at ${st.batteryTempC}°C.\n" +
                        "• Efficiency Analysis: Cruising at ${st.speedKph.toInt()} km/h under ${st.driveMode} mode yields an estimated ${st.rangeKm} km remaining range.\n" +
                        "• Charging Strategy: Pre-condition battery 20 mins prior to DC fast charging to achieve peak 220kW charge curve."
                    else ->
                        "• Vehicle Systems Nominal: Motor RPM ${st.motorRpm}, Voltage ${st.batteryVoltageV}V, Power ${st.batteryPowerKw} kW.\n" +
                        "• API Telemetry: All REST & WebSocket sensor streams broadcast at 10 Hz frequency.\n" +
                        "• Guidance: Use the API Console tab to execute live HTTP endpoints or inspect synthetic vehicle logs."
                }
                withContext(Dispatchers.Main) {
                    _aiResponse.value = fallbackAnswer
                    _aiLoading.value = false
                }
                return@launch
            }

            // Real Gemini REST API Call
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true

                val jsonBody = JSONObject().apply {
                    put("contents", org.json.JSONArray().apply {
                        put(JSONObject().apply {
                            put("parts", org.json.JSONArray().apply {
                                put(JSONObject().apply {
                                    put("text", contextPrompt)
                                })
                            })
                        })
                    })
                }

                OutputStreamWriter(conn.outputStream).use { it.write(jsonBody.toString()) }

                val respCode = conn.responseCode
                if (respCode == 200) {
                    val respText = conn.inputStream.bufferedReader().readText()
                    val respJson = JSONObject(respText)
                    val text = respJson.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                    withContext(Dispatchers.Main) {
                        _aiResponse.value = text
                        _aiLoading.value = false
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        _aiResponse.value = "Gemini API HTTP $respCode. Please check GEMINI_API_KEY."
                        _aiLoading.value = false
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _aiResponse.value = "AI Assistant Error: ${e.message}"
                    _aiLoading.value = false
                }
            }
        }
    }
}
