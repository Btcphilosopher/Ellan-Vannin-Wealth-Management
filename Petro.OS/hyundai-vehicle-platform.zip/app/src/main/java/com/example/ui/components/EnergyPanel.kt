package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun EnergyPanel(
    state: VehicleState,
    language: Language,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "energy_flow")
    val alphaAnim by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Energy Flow Diagram
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
                .testTag("energy_flow_diagram")
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = Translations.get("energy_flow", language),
                    color = TextHighContrast,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                // Flow path: BATTERY -> INVERTER -> MOTOR -> WHEELS
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DeepCharcoal, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EnergyNode("BATTERY", "${state.batteryPercent.toInt()}%", HyundaiElectricBlue)
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = HyundaiElectricBlue.copy(alpha = alphaAnim))
                    EnergyNode("INVERTER", "${state.batteryPowerKw} kW", TextHighContrast)
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = HyundaiElectricBlue.copy(alpha = alphaAnim))
                    EnergyNode("MOTOR", "${state.motorRpm} RPM", TextHighContrast)
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, tint = HyundaiElectricBlue.copy(alpha = alphaAnim))
                    EnergyNode("WHEELS", "${state.speedKph.toInt()} km/h", StatusHealthy)
                }
            }
        }

        // Energy Breakdown Table
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ENERGY CONSUMPTION BREAKDOWN",
                    color = TextHighContrast,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                EnergyRow(Translations.get("energy_drive", language), "${state.energyDriveKwh} kWh", TextHighContrast)
                EnergyRow(Translations.get("energy_climate", language), "${state.energyClimateKwh} kWh", TextSecondary)
                EnergyRow(Translations.get("energy_conditioning", language), "${state.energyConditioningKwh} kWh", TextSecondary)
                EnergyRow(Translations.get("energy_regen", language), "${state.energyRegenKwh} kWh", StatusHealthy)

                Divider(color = BorderGrey)

                EnergyRow(Translations.get("energy_net", language), "${state.netEnergyKwh} kWh", HyundaiElectricBlue, isBold = true)
            }
        }
    }
}

@Composable
private fun EnergyNode(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun EnergyRow(label: String, value: String, color: Color, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = if (isBold) TextHighContrast else TextSecondary, fontSize = 13.sp, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal)
        Text(value, color = color, fontSize = 13.sp, fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium)
    }
}
