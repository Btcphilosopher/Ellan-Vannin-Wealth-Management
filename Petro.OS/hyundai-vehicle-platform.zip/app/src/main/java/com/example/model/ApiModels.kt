package com.example.model

data class ApiErrorDetails(
    val code: String,
    val message: String,
    val requestId: String = "req-hvdp-${System.currentTimeMillis() % 10000}"
)

data class ApiErrorResponse(
    val error: ApiErrorDetails
)

data class DriveModeRequest(
    val mode: String
)

data class DriveModeResponse(
    val success: Boolean,
    val previousMode: String,
    val currentMode: String
)

data class ChargingStartRequest(
    val targetSoc: Float = 80f,
    val chargingType: String = "DC_FAST" // "AC" or "DC_FAST"
)

data class ClimateSetRequest(
    val temperatureC: Float? = null,
    val fanLevel: Int? = null,
    val ac: Boolean? = null,
    val seatHeatingLeft: Int? = null,
    val steeringWheelHeating: Boolean? = null
)

data class NavDestinationRequest(
    val destination: String
)

data class NavDestinationResponse(
    val destination: String,
    val distanceKm: Float,
    val durationMinutes: Int,
    val arrivalTime: String,
    val traffic: String
)

data class LightsSetRequest(
    val headlights: Boolean? = null,
    val highBeam: Boolean? = null,
    val drl: Boolean? = null,
    val hazardLights: Boolean? = null,
    val interiorLights: Boolean? = null
)

data class DoorLockRequest(
    val lockAll: Boolean
)

data class ApiExecutionResult(
    val method: String,
    val endpoint: String,
    val statusCode: Int,
    val latencyMs: Long,
    val requestBodyJson: String?,
    val responseBodyJson: String,
    val timestamp: String
)
