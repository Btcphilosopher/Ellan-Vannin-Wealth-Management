package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.i18n.Language
import com.example.i18n.Translations
import com.example.model.LightsSetRequest
import com.example.model.VehicleState
import com.example.ui.theme.*

@Composable
fun VehicleStatusPanel(
    state: VehicleState,
    language: Language,
    onLockDoors: (Boolean) -> Unit,
    onSetLights: (LightsSetRequest) -> Unit,
    onToggleHorn: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Doors & Lock Controls
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = Translations.get("doors", language),
                        color = TextHighContrast,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onLockDoors(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = HyundaiDarkBlue),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.testTag("btn_lock_all")
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(Translations.get("lock_all", language), fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { onLockDoors(false) },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.testTag("btn_unlock_all")
                        ) {
                            Icon(imageVector = Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(Translations.get("unlock_all", language), fontSize = 11.sp, color = TextHighContrast)
                        }
                    }
                }

                // Top-Down EV Door Grid View
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DeepCharcoal, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    DoorStatusCard("Front Left", state.doors.frontLeftLocked, false)
                    DoorStatusCard("Front Right", state.doors.frontRightLocked, false)
                    DoorStatusCard("Rear Left", state.doors.rearLeftLocked, false)
                    DoorStatusCard("Rear Right", state.doors.rearRightLocked, false)
                    DoorStatusCard("Trunk", state.doors.rearRightLocked, state.doors.trunkOpen)
                }
            }
        }

        // Lighting Controls
        Surface(
            color = CardBackground,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = Translations.get("lights", language),
                    color = TextHighContrast,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Translations.get("headlights", language), color = TextSecondary, fontSize = 13.sp)
                        Switch(
                            checked = state.lights.headlights,
                            onCheckedChange = { onSetLights(LightsSetRequest(headlights = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = HyundaiElectricBlue)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Translations.get("high_beam", language), color = TextSecondary, fontSize = 13.sp)
                        Switch(
                            checked = state.lights.highBeam,
                            onCheckedChange = { onSetLights(LightsSetRequest(highBeam = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = HyundaiElectricBlue)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Translations.get("hazard_lights", language), color = TextSecondary, fontSize = 13.sp)
                        Switch(
                            checked = state.lights.hazardLights,
                            onCheckedChange = { onSetLights(LightsSetRequest(hazardLights = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = StatusWarning)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Translations.get("interior_lights", language), color = TextSecondary, fontSize = 13.sp)
                        Switch(
                            checked = state.lights.interiorLights,
                            onCheckedChange = { onSetLights(LightsSetRequest(interiorLights = it)) },
                            colors = SwitchDefaults.colors(checkedThumbColor = HyundaiPerformanceBlue)
                        )
                    }
                }
            }
        }

        // Horn & Tire Pressure (TPMS)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Horn Box
            Surface(
                color = CardBackground,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("HORN SYSTEM", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Button(
                        onClick = onToggleHorn,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.hornActive) StatusFault else HyundaiDarkBlue
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("btn_horn")
                    ) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (state.hornActive) "HORN ACTIVE" else Translations.get("horn", language), fontSize = 12.sp)
                    }
                }
            }

            // TPMS Box
            Surface(
                color = CardBackground,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("TPMS TIRE PRESSURE", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("FL: ${state.tires.frontLeftPsi} PSI", color = StatusHealthy, fontSize = 11.sp)
                    Text("FR: ${state.tires.frontRightPsi} PSI", color = StatusHealthy, fontSize = 11.sp)
                    Text("RL: ${state.tires.rearLeftPsi} PSI", color = StatusHealthy, fontSize = 11.sp)
                    Text("RR: ${state.tires.rearRightPsi} PSI", color = StatusHealthy, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun DoorStatusCard(label: String, locked: Boolean, open: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextMuted, fontSize = 10.sp)
        Spacer(Modifier.height(4.dp))
        Surface(
            color = if (locked) HyundaiDarkBlue else StatusWarning.copy(alpha = 0.2f),
            shape = RoundedCornerShape(4.dp)
        ) {
            Text(
                text = if (open) "OPEN" else if (locked) "LOCKED" else "UNLOCKED",
                color = if (locked) HyundaiElectricBlue else StatusWarning,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
