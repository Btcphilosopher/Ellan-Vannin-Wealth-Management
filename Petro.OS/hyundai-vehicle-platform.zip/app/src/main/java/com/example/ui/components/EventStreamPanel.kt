package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TelemetryEvent
import com.example.ui.theme.*

@Composable
fun EventStreamPanel(
    events: List<TelemetryEvent>,
    modifier: Modifier = Modifier
) {
    Surface(
        color = DeepCharcoal,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .border(1.dp, BorderGrey, RoundedCornerShape(12.dp))
            .testTag("telemetry_stream_terminal")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LIVE TELEMETRY STREAM LOG (10 Hz)",
                    color = HyundaiElectricBlue,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Surface(
                    color = StatusHealthy.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "WEBSOCKET STREAM ACTIVE",
                        color = StatusHealthy,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Divider(color = BorderGrey)

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(events) { ev ->
                    val color = when (ev.level) {
                        "WARN" -> StatusWarning
                        "ERROR" -> StatusFault
                        else -> TextSecondary
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(ev.timestamp, color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text(ev.topic.padEnd(22), color = HyundaiElectricBlue, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Text(ev.value, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}
