package com.example

import com.example.api.SignalRegistry
import com.example.domain.models.*
import com.example.localization.Language
import com.example.localization.StringDictionary
import com.example.localization.StringKeys
import com.example.replay.SessionArchive
import com.example.safety.SafetyPolicyManager
import com.example.simulator.PhysicsEngine
import com.example.simulator.ScenarioPresets
import org.junit.Assert.*
import org.junit.Test

class VehicleApiUnitTest {

    @Test
    fun testPhysicsMotorRpmCalculation() {
        val rpmAt100 = PhysicsEngine.calculateMotorRpm(100f)
        assertTrue("RPM at 100km/h should be within normal EV range (7000-9000)", rpmAt100 in 7000f..9000f)

        val rpmAtZero = PhysicsEngine.calculateMotorRpm(0f)
        assertEquals(0f, rpmAtZero, 0.01f)
    }

    @Test
    fun testPhysicsPackVoltageCalculation() {
        val vFull = PhysicsEngine.calculatePackVoltage(95f, 0f)
        val vEmpty = PhysicsEngine.calculatePackVoltage(5f, 0f)
        assertTrue("Full pack voltage should exceed empty pack voltage", vFull > vEmpty)
        assertTrue("LFP Pack voltage should stay within 300V..400V", vFull in 300f..400f)
    }

    @Test
    fun testSafetyPolicyChargingRejectionWhileDriving() {
        val movingState = VehicleState(speedKmH = 80f, gear = GearState.D)
        val cmd = VehicleCommand(
            commandType = CommandType.SET_CHARGING_STATE,
            payload = mapOf("action" to "START")
        )
        val result = SafetyPolicyManager.evaluateCommand(cmd, movingState, isSimulator = true)
        assertFalse("Charging while vehicle is in motion must be rejected by ASIL safety policy", result.isApproved)
        assertEquals(SafetyClassification.ASIL_D, result.safetyLevel)
    }

    @Test
    fun testSafetyPolicyChargingApprovalWhenStationary() {
        val stationaryState = VehicleState(speedKmH = 0f, gear = GearState.P)
        val cmd = VehicleCommand(
            commandType = CommandType.SET_CHARGING_STATE,
            payload = mapOf("action" to "START")
        )
        val result = SafetyPolicyManager.evaluateCommand(cmd, stationaryState, isSimulator = true)
        assertTrue("Charging when stationary must be approved in simulation", result.isApproved)
    }

    @Test
    fun testSignalRegistryCoverage() {
        val testState = VehicleState(
            speedKmH = 88.5f,
            gear = GearState.D,
            battery = BatteryState(socPercent = 75.0f, voltageV = 354.0f)
        )

        assertTrue("Signal definitions must not be empty", SignalRegistry.definitions.isNotEmpty())

        val speedSignal = SignalRegistry.extractSignalValue("vehicle.speed", testState)
        assertNotNull("vehicle.speed must resolve correctly", speedSignal)
        assertEquals(88.5f, speedSignal!!.rawValue)

        val socSignal = SignalRegistry.extractSignalValue("battery.soc", testState)
        assertNotNull("battery.soc must resolve correctly", socSignal)
        assertEquals(75.0f, socSignal!!.rawValue)

        val json = SignalRegistry.generateJsonPayload(speedSignal)
        assertTrue("JSON payload must contain signal ID", json.contains("vehicle.speed"))
        assertTrue("JSON payload must contain BYD_DILINK_CAN protocol", json.contains("BYD_DILINK_CAN"))
    }

    @Test
    fun testLocalizationDictionaryBilingualIntegrity() {
        val keys = listOf(
            StringKeys.APP_NAME,
            StringKeys.NAV_DASHBOARD,
            StringKeys.NAV_BATTERY,
            StringKeys.NAV_CHARGING,
            StringKeys.NAV_POWERTRAIN,
            StringKeys.NAV_BODY,
            StringKeys.NAV_CLIMATE,
            StringKeys.NAV_TYRES,
            StringKeys.NAV_DIAGNOSTICS,
            StringKeys.NAV_API_EXPLORER,
            StringKeys.NAV_TELEMETRY,
            StringKeys.NAV_SCENARIO_LAB,
            StringKeys.NAV_REPLAY,
            StringKeys.NAV_SETTINGS
        )

        keys.forEach { key ->
            val en = StringDictionary.get(key, Language.EN)
            val zh = StringDictionary.get(key, Language.ZH)
            assertNotNull("EN translation must exist for $key", en)
            assertNotNull("ZH translation must exist for $key", zh)
            assertNotEquals("ZH and EN should be distinct for $key", en, zh)
        }
    }

    @Test
    fun testScenarioPresetsAndReplayDataIntegrity() {
        assertEquals("Scenario presets catalog must contain 8 distinct presets", 8, ScenarioPresets.list.size)
        assertTrue("Session archive must contain sessions", SessionArchive.allSessions.isNotEmpty())
        SessionArchive.allSessions.forEach { session ->
            assertTrue("Snapshots list must not be empty", session.snapshots.isNotEmpty())
            assertEquals("Duration seconds must match snapshot count", session.durationSeconds, session.snapshots.size)
        }
    }
}
