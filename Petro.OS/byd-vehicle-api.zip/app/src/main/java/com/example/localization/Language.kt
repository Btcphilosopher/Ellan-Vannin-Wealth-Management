package com.example.localization

enum class Language(val code: String, val displayName: String, val nativeName: String) {
    EN("en", "English", "English"),
    ZH("zh", "Chinese (Simplified)", "简体中文")
}

object StringKeys {
    // App & Header
    const val APP_TITLE = "app_title"
    const val APP_SUBTITLE = "app_subtitle"
    const val VEHICLE_IDENTITY = "vehicle_identity"
    const val CONNECTION_STATUS = "connection_status"
    const val CONNECTED = "connected"
    const val DISCONNECTED = "disconnected"
    const val SIMULATION_MODE = "simulation_mode"
    const val REPLAY_MODE = "replay_mode"
    const val OEM_DILINK_MODE = "oem_dilink_mode"
    const val LIVE_DATA = "live_data"
    
    // Navigation
    const val NAV_DASHBOARD = "nav_dashboard"
    const val NAV_BATTERY = "nav_battery"
    const val NAV_CHARGING = "nav_charging"
    const val NAV_POWERTRAIN = "nav_powertrain"
    const val NAV_BODY = "nav_body"
    const val NAV_CLIMATE = "nav_climate"
    const val NAV_TYRES = "nav_tyres"
    const val NAV_DIAGNOSTICS = "nav_diagnostics"
    const val NAV_API_EXPLORER = "nav_api_explorer"
    const val NAV_TELEMETRY = "nav_telemetry"
    const val NAV_SCENARIO_LAB = "nav_scenario_lab"
    const val NAV_REPLAY = "nav_replay"
    const val NAV_LOGS = "nav_logs"
    const val NAV_SETTINGS = "nav_settings"

    // Dashboard Items
    const val SPEED = "speed"
    const val GEAR = "gear"
    const val DRIVE_MODE = "drive_mode"
    const val BATTERY_SOC = "battery_soc"
    const val ESTIMATED_RANGE = "estimated_range"
    const val POWER_OUTPUT = "power_output"
    const val ENERGY_CONSUMPTION = "energy_consumption"
    const val CABIN_TEMP = "cabin_temp"
    const val OUTSIDE_TEMP = "outside_temp"
    const val ODOMETER = "odometer"
    const val STEERING_ANGLE = "steering_angle"
    const val ACCEL_POSITION = "accel_position"
    const val BRAKE_STATE = "brake_state"
    const val PARKING_BRAKE = "parking_brake"
    const val REGEN_STATUS = "regen_status"
    const val ADAS_STATUS = "adas_status"
    const val READY = "ready"
    const val ACTIVE = "active"
    const val STANDBY = "standby"
    const val ENGAGED = "engaged"
    const val RELEASED = "released"

    // Battery & Energy
    const val BLADE_BATTERY = "blade_battery"
    const val BATTERY_VOLTAGE = "battery_voltage"
    const val BATTERY_CURRENT = "battery_current"
    const val BATTERY_POWER = "battery_power"
    const val PACK_TEMP = "pack_temp"
    const val CELL_TEMP_RANGE = "cell_temp_range"
    const val ENERGY_REMAINING = "energy_remaining"
    const val TOTAL_CAPACITY = "total_capacity"
    const val HEALTH_SOH = "health_soh"
    const val CHARGE_CYCLES = "charge_cycles"
    const val THERMAL_MGMT = "thermal_mgmt"
    const val POWER_FLOW = "power_flow"
    const val DISCHARGE = "discharge"
    const val REGEN = "regen"
    const val IDLE = "idle"

    // Charging
    const val CHARGING_TITLE = "charging_title"
    const val CHARGE_STATE = "charge_state"
    const val CHARGING_POWER = "charging_power"
    const val CHARGING_VOLTAGE = "charging_voltage"
    const val CHARGING_CURRENT = "charging_current"
    const val TARGET_SOC = "target_soc"
    const val TIME_REMAINING = "time_remaining"
    const val ENERGY_DELIVERED = "energy_delivered"
    const val SESSION_DURATION = "session_duration"
    const val CHARGER_TYPE = "charger_type"
    const val DC_FAST = "dc_fast"
    const val AC_SLOW = "ac_slow"
    const val START_CHARGING = "start_charging"
    const val PAUSE_CHARGING = "pause_charging"
    const val RESUME_CHARGING = "resume_charging"
    const val STOP_CHARGING = "stop_charging"

    // Powertrain
    const val POWERTRAIN_TITLE = "powertrain_title"
    const val MOTOR_RPM = "motor_rpm"
    const val MOTOR_TORQUE = "motor_torque"
    const val MOTOR_POWER = "motor_power"
    const val MOTOR_TEMP = "motor_temp"
    const val INVERTER_TEMP = "inverter_temp"
    const val EFFICIENCY = "efficiency"
    const val ECO = "eco"
    const val NORMAL = "normal"
    const val SPORT = "sport"
    const val SNOW = "snow"

    // Body
    const val BODY_TITLE = "body_title"
    const val DOOR_FL = "door_fl"
    const val DOOR_FR = "door_fr"
    const val DOOR_RL = "door_rl"
    const val DOOR_RR = "door_rr"
    const val TRUNK = "trunk"
    const val HOOD = "hood"
    const val WINDOWS = "windows"
    const val LIGHTS = "lights"
    const val CHARGE_PORT = "charge_port"
    const val OPEN = "open"
    const val CLOSED = "closed"
    const val LOCKED = "locked"
    const val UNLOCKED = "unlocked"

    // Climate
    const val CLIMATE_TITLE = "climate_title"
    const val TARGET_TEMP = "target_temp"
    const val FAN_SPEED = "fan_speed"
    const val AC_MODE = "ac_mode"
    const val HEAT_MODE = "heat_mode"
    const val RECIRCULATION = "recirculation"
    const val FRONT_DEFROST = "front_defrost"
    const val REAR_DEFROST = "rear_defrost"
    const val AUX_POWER = "aux_power"

    // Tyres
    const val TYRES_TITLE = "tyres_title"
    const val PRESSURE = "pressure"
    const val TEMPERATURE = "temperature"
    const val TYRE_FL = "tyre_fl"
    const val TYRE_FR = "tyre_fr"
    const val TYRE_RL = "tyre_rl"
    const val TYRE_RR = "tyre_rr"
    const val SIMULATE_PUNCTURE = "simulate_puncture"
    const val RESTORE_PRESSURE = "restore_pressure"

    // Diagnostics
    const val DIAGNOSTICS_TITLE = "diagnostics_title"
    const val SYSTEM_HEALTH = "system_health"
    const val DTC_CODES = "dtc_codes"
    const val FAULTS = "faults"
    const val STATUS_NORMAL = "status_normal"
    const val STATUS_WARNING = "status_warning"
    const val STATUS_FAULT = "status_fault"
    const val STATUS_OFFLINE = "status_offline"
    const val CLEAR_DTC = "clear_dtc"
    const val INJECT_FAULT = "inject_fault"

    // API Explorer
    const val API_EXPLORER_TITLE = "api_explorer_title"
    const val SIGNAL_ID = "signal_id"
    const val DATA_TYPE = "data_type"
    const val UNIT = "unit"
    const val QUALITY = "quality"
    const val SOURCE = "source"
    const val UPDATE_FREQ = "update_freq"
    const val ACCESS_PERMISSION = "access_permission"
    const val SAFETY_CLASS = "safety_class"
    const val JSON_PREVIEW = "json_preview"
    const val COPY_JSON = "copy_json"
    const val COPIED = "copied"
    const val SEARCH_SIGNALS = "search_signals"

    // Telemetry & Logs
    const val TELEMETRY_TITLE = "telemetry_title"
    const val TIME_SPAN = "time_span"
    const val LIVE_STREAM = "live_stream"
    const val PAUSE_STREAM = "pause_stream"
    const val EXPORT_DATA = "export_data"
    const val LOGS_TITLE = "logs_title"
    const val LOG_LEVEL = "log_level"
    const val ALL_MODULES = "all_modules"
    const val CLEAR_LOGS = "clear_logs"

    // Scenario & Replay
    const val SCENARIO_LAB_TITLE = "scenario_lab_title"
    const val PRESETS = "presets"
    const val URBAN_DRIVING = "urban_driving"
    const val MOTORWAY = "motorway"
    const val HEAVY_TRAFFIC = "heavy_traffic"
    const val COLD_WEATHER = "cold_weather"
    const val HOT_WEATHER = "hot_weather"
    const val FAST_CHARGING = "fast_charging"
    const val LONG_JOURNEY = "long_journey"
    const val LOW_BATTERY = "low_battery"
    const val SIM_SPEED = "sim_speed"
    const val RUN_SCENARIO = "run_scenario"
    const val REPLAY_TITLE = "replay_title"
    const val SESSIONS = "sessions"
    const val PLAY = "play"
    const val PAUSE = "pause"
    const val STEP = "step"
    const val RESTART = "restart"

    // Settings
    const val SETTINGS_TITLE = "settings_title"
    const val LANGUAGE = "language"
    const val THEME = "theme"
    const val UNITS = "units"
    const val DATA_PROVIDER = "data_provider"
    const val DILINK_INFO = "dilink_info"
    const val SAFETY_ARCHITECTURE = "safety_architecture"
    const val DEVELOPER_MODE = "developer_mode"
}

object StringDictionary {
    private val en = mapOf(
        StringKeys.APP_TITLE to "BYD VEHICLE API",
        StringKeys.APP_SUBTITLE to "Intelligent Cockpit Vehicle Data & Telemetry Platform",
        StringKeys.VEHICLE_IDENTITY to "BYD SEAL (CTB Platform)",
        StringKeys.CONNECTION_STATUS to "Connection",
        StringKeys.CONNECTED to "CONNECTED",
        StringKeys.DISCONNECTED to "DISCONNECTED",
        StringKeys.SIMULATION_MODE to "SIMULATION ENGINE",
        StringKeys.REPLAY_MODE to "REPLAY LOG",
        StringKeys.OEM_DILINK_MODE to "BYD DiLink SDK (STUB)",
        StringKeys.LIVE_DATA to "LIVE DATA",

        StringKeys.NAV_DASHBOARD to "Dashboard",
        StringKeys.NAV_BATTERY to "Blade Battery",
        StringKeys.NAV_CHARGING to "Charging",
        StringKeys.NAV_POWERTRAIN to "Powertrain",
        StringKeys.NAV_BODY to "Body & Closures",
        StringKeys.NAV_CLIMATE to "HVAC Climate",
        StringKeys.NAV_TYRES to "TPMS Tyres",
        StringKeys.NAV_DIAGNOSTICS to "Diagnostics",
        StringKeys.NAV_API_EXPLORER to "API Explorer",
        StringKeys.NAV_TELEMETRY to "Telemetry Graphs",
        StringKeys.NAV_SCENARIO_LAB to "Scenario Lab",
        StringKeys.NAV_REPLAY to "Session Replay",
        StringKeys.NAV_LOGS to "Engineering Logs",
        StringKeys.NAV_SETTINGS to "Settings & Arch",

        StringKeys.SPEED to "Speed",
        StringKeys.GEAR to "Gear",
        StringKeys.DRIVE_MODE to "Drive Mode",
        StringKeys.BATTERY_SOC to "Battery SOC",
        StringKeys.ESTIMATED_RANGE to "Est. Range",
        StringKeys.POWER_OUTPUT to "Power Output",
        StringKeys.ENERGY_CONSUMPTION to "Consumption",
        StringKeys.CABIN_TEMP to "Cabin Temp",
        StringKeys.OUTSIDE_TEMP to "Outside Temp",
        StringKeys.ODOMETER to "Odometer",
        StringKeys.STEERING_ANGLE to "Steering Angle",
        StringKeys.ACCEL_POSITION to "Accelerator",
        StringKeys.BRAKE_STATE to "Brake",
        StringKeys.PARKING_BRAKE to "EPB (Handbrake)",
        StringKeys.REGEN_STATUS to "Regen Braking",
        StringKeys.ADAS_STATUS to "DiPilot ADAS",
        StringKeys.READY to "READY",
        StringKeys.ACTIVE to "ACTIVE",
        StringKeys.STANDBY to "STANDBY",
        StringKeys.ENGAGED to "ENGAGED",
        StringKeys.RELEASED to "RELEASED",

        StringKeys.BLADE_BATTERY to "Blade Battery System",
        StringKeys.BATTERY_VOLTAGE to "Pack Voltage",
        StringKeys.BATTERY_CURRENT to "Pack Current",
        StringKeys.BATTERY_POWER to "Instant Power",
        StringKeys.PACK_TEMP to "Pack Temperature",
        StringKeys.CELL_TEMP_RANGE to "Cell Temp Range",
        StringKeys.ENERGY_REMAINING to "Energy Remaining",
        StringKeys.TOTAL_CAPACITY to "Total Pack Capacity",
        StringKeys.HEALTH_SOH to "Battery SOH",
        StringKeys.CHARGE_CYCLES to "Cycle Count",
        StringKeys.THERMAL_MGMT to "Liquid Thermal Control",
        StringKeys.POWER_FLOW to "Power Flow",
        StringKeys.DISCHARGE to "DISCHARGING",
        StringKeys.REGEN to "REGENERATING",
        StringKeys.IDLE to "STANDBY",

        StringKeys.CHARGING_TITLE to "Intelligent Charging Management",
        StringKeys.CHARGE_STATE to "Charging State",
        StringKeys.CHARGING_POWER to "Charging Power",
        StringKeys.CHARGING_VOLTAGE to "Charging Voltage",
        StringKeys.CHARGING_CURRENT to "Charging Current",
        StringKeys.TARGET_SOC to "Target SOC Limit",
        StringKeys.TIME_REMAINING to "Est. Time to Full",
        StringKeys.ENERGY_DELIVERED to "Energy Delivered",
        StringKeys.SESSION_DURATION to "Session Time",
        StringKeys.CHARGER_TYPE to "Charger Type",
        StringKeys.DC_FAST to "High Voltage DC Fast",
        StringKeys.AC_SLOW to "AC Wallbox Slow",
        StringKeys.START_CHARGING to "Start Charging",
        StringKeys.PAUSE_CHARGING to "Pause",
        StringKeys.RESUME_CHARGING to "Resume",
        StringKeys.STOP_CHARGING to "Stop Charging",

        StringKeys.POWERTRAIN_TITLE to "Electric Powertrain Dynamics",
        StringKeys.MOTOR_RPM to "Motor RPM",
        StringKeys.MOTOR_TORQUE to "Motor Torque",
        StringKeys.MOTOR_POWER to "Motor Output",
        StringKeys.MOTOR_TEMP to "Motor Temp",
        StringKeys.INVERTER_TEMP to "Inverter (SiC) Temp",
        StringKeys.EFFICIENCY to "Powertrain Efficiency",
        StringKeys.ECO to "ECO",
        StringKeys.NORMAL to "NORMAL",
        StringKeys.SPORT to "SPORT",
        StringKeys.SNOW to "SNOW",

        StringKeys.BODY_TITLE to "Vehicle Body & Access Closures",
        StringKeys.DOOR_FL to "Front Left Door",
        StringKeys.DOOR_FR to "Front Right Door",
        StringKeys.DOOR_RL to "Rear Left Door",
        StringKeys.DOOR_RR to "Rear Right Door",
        StringKeys.TRUNK to "Power Tailgate / Boot",
        StringKeys.HOOD to "Frunk / Hood",
        StringKeys.WINDOWS to "Power Windows",
        StringKeys.LIGHTS to "LED Exterior Lights",
        StringKeys.CHARGE_PORT to "Charge Port Door",
        StringKeys.OPEN to "OPEN",
        StringKeys.CLOSED to "CLOSED",
        StringKeys.LOCKED to "LOCKED",
        StringKeys.UNLOCKED to "UNLOCKED",

        StringKeys.CLIMATE_TITLE to "Heat Pump Thermal & HVAC",
        StringKeys.TARGET_TEMP to "Target Temp",
        StringKeys.FAN_SPEED to "Fan Speed",
        StringKeys.AC_MODE to "A/C Compressor",
        StringKeys.HEAT_MODE to "Heat Pump",
        StringKeys.RECIRCULATION to "Air Recirculation",
        StringKeys.FRONT_DEFROST to "Front Windshield Defrost",
        StringKeys.REAR_DEFROST to "Rear Screen Demist",
        StringKeys.AUX_POWER to "HVAC Auxiliary Power",

        StringKeys.TYRES_TITLE to "Direct TPMS Tyre Pressure",
        StringKeys.PRESSURE to "Pressure",
        StringKeys.TEMPERATURE to "Temperature",
        StringKeys.TYRE_FL to "Front Left (FL)",
        StringKeys.TYRE_FR to "Front Right (FR)",
        StringKeys.TYRE_RL to "Rear Left (RL)",
        StringKeys.TYRE_RR to "Rear Right (RR)",
        StringKeys.SIMULATE_PUNCTURE to "Simulate Puncture (FL)",
        StringKeys.RESTORE_PRESSURE to "Restore Pressure",

        StringKeys.DIAGNOSTICS_TITLE to "Automotive OBD / DTC Diagnostic Centre",
        StringKeys.SYSTEM_HEALTH to "System Health Matrix",
        StringKeys.DTC_CODES to "Diagnostic Trouble Codes",
        StringKeys.FAULTS to "Active Faults",
        StringKeys.STATUS_NORMAL to "NORMAL",
        StringKeys.STATUS_WARNING to "WARNING",
        StringKeys.STATUS_FAULT to "FAULT",
        StringKeys.STATUS_OFFLINE to "OFFLINE",
        StringKeys.CLEAR_DTC to "Clear DTC Log",
        StringKeys.INJECT_FAULT to "Inject Test DTC",

        StringKeys.API_EXPLORER_TITLE to "Signal Registry & REST/WebSocket API Explorer",
        StringKeys.SIGNAL_ID to "Signal ID",
        StringKeys.DATA_TYPE to "Data Type",
        StringKeys.UNIT to "Unit",
        StringKeys.QUALITY to "Data Quality",
        StringKeys.SOURCE to "Source",
        StringKeys.UPDATE_FREQ to "Update Frequency",
        StringKeys.ACCESS_PERMISSION to "Access Permission",
        StringKeys.SAFETY_CLASS to "Safety Classification",
        StringKeys.JSON_PREVIEW to "REST / Telemetry Payload",
        StringKeys.COPY_JSON to "Copy JSON Payload",
        StringKeys.COPIED to "Copied to Clipboard!",
        StringKeys.SEARCH_SIGNALS to "Filter signals (e.g. battery, speed, door)...",

        StringKeys.TELEMETRY_TITLE to "Multi-Channel Live Telemetry Oscilloscope",
        StringKeys.TIME_SPAN to "Time Span",
        StringKeys.LIVE_STREAM to "LIVE STREAM",
        StringKeys.PAUSE_STREAM to "PAUSE",
        StringKeys.EXPORT_DATA to "Export Dataset",
        StringKeys.LOGS_TITLE to "Vehicle Bus & API Engineering Log",
        StringKeys.LOG_LEVEL to "Severity Level",
        StringKeys.ALL_MODULES to "All Modules",
        StringKeys.CLEAR_LOGS to "Clear Logs",

        StringKeys.SCENARIO_LAB_TITLE to "Scenario Lab & Driving Physics Simulation",
        StringKeys.PRESETS to "Preset Scenarios",
        StringKeys.URBAN_DRIVING to "Urban Stop & Go",
        StringKeys.MOTORWAY to "High-Speed Motorway",
        StringKeys.HEAVY_TRAFFIC to "Congested Traffic",
        StringKeys.COLD_WEATHER to "Cold Winter (-15°C)",
        StringKeys.HOT_WEATHER to "Summer Heatwave (38°C)",
        StringKeys.FAST_CHARGING to "150kW DC Fast Charge",
        StringKeys.LONG_JOURNEY to "Highway Endurance",
        StringKeys.LOW_BATTERY to "Low SOC Warning (12%)",
        StringKeys.SIM_SPEED to "Simulation Speed",
        StringKeys.RUN_SCENARIO to "Apply Scenario",
        StringKeys.REPLAY_TITLE to "Drive Session Telemetry Replay",
        StringKeys.SESSIONS to "Session Archive",
        StringKeys.PLAY to "PLAY",
        StringKeys.PAUSE to "PAUSE",
        StringKeys.STEP to "STEP +1s",
        StringKeys.RESTART to "RESTART",

        StringKeys.SETTINGS_TITLE to "System Settings & Vehicle Architecture",
        StringKeys.LANGUAGE to "Interface Language",
        StringKeys.THEME to "Color Theme",
        StringKeys.UNITS to "Measurement Units",
        StringKeys.DATA_PROVIDER to "Active Vehicle Data Provider",
        StringKeys.DILINK_INFO to "BYD DiLink Ecosystem Bridge",
        StringKeys.SAFETY_ARCHITECTURE to "Automotive Safety & Security Architecture",
        StringKeys.DEVELOPER_MODE to "Developer Instrumentation"
    )

    private val zh = mapOf(
        StringKeys.APP_TITLE to "比亚迪车辆 API",
        StringKeys.APP_SUBTITLE to "智能座舱整车数据与遥测开发平台",
        StringKeys.VEHICLE_IDENTITY to "比亚迪 海豹 (CTB 车身电池一体化)",
        StringKeys.CONNECTION_STATUS to "连接状态",
        StringKeys.CONNECTED to "已连接",
        StringKeys.DISCONNECTED to "未连接",
        StringKeys.SIMULATION_MODE to "仿真动力学引擎",
        StringKeys.REPLAY_MODE to "回放日志流",
        StringKeys.OEM_DILINK_MODE to "BYD DiLink SDK (桩模块)",
        StringKeys.LIVE_DATA to "实时数据",

        StringKeys.NAV_DASHBOARD to "车辆仪表盘",
        StringKeys.NAV_BATTERY to "动力电池",
        StringKeys.NAV_CHARGING to "充电管理",
        StringKeys.NAV_POWERTRAIN to "动力系统",
        StringKeys.NAV_BODY to "车身与车门",
        StringKeys.NAV_CLIMATE to "智能空调",
        StringKeys.NAV_TYRES to "胎压监测",
        StringKeys.NAV_DIAGNOSTICS to "车辆诊断",
        StringKeys.NAV_API_EXPLORER to "API 浏览器",
        StringKeys.NAV_TELEMETRY to "遥测图表",
        StringKeys.NAV_SCENARIO_LAB to "场景实验室",
        StringKeys.NAV_REPLAY to "会话回放",
        StringKeys.NAV_LOGS to "工程日志",
        StringKeys.NAV_SETTINGS to "设置与架构",

        StringKeys.SPEED to "车速",
        StringKeys.GEAR to "挡位",
        StringKeys.DRIVE_MODE to "驾驶模式",
        StringKeys.BATTERY_SOC to "电池荷电状态 (SOC)",
        StringKeys.ESTIMATED_RANGE to "预计续航",
        StringKeys.POWER_OUTPUT to "输出功率",
        StringKeys.ENERGY_CONSUMPTION to "综合能耗",
        StringKeys.CABIN_TEMP to "车内温度",
        StringKeys.OUTSIDE_TEMP to "室外温度",
        StringKeys.ODOMETER to "总里程",
        StringKeys.STEERING_ANGLE to "方向盘转角",
        StringKeys.ACCEL_POSITION to "油门开度",
        StringKeys.BRAKE_STATE to "制动踏板",
        StringKeys.PARKING_BRAKE to "电子手刹 (EPB)",
        StringKeys.REGEN_STATUS to "能量回收",
        StringKeys.ADAS_STATUS to "DiPilot 智能驾驶",
        StringKeys.READY to "就绪 (READY)",
        StringKeys.ACTIVE to "激活中",
        StringKeys.STANDBY to "待命",
        StringKeys.ENGAGED to "已拉起",
        StringKeys.RELEASED to "已释放",

        StringKeys.BLADE_BATTERY to "刀片电池系统 (Blade Battery)",
        StringKeys.BATTERY_VOLTAGE to "总电压",
        StringKeys.BATTERY_CURRENT to "总电流",
        StringKeys.BATTERY_POWER to "瞬时功率",
        StringKeys.PACK_TEMP to "电池包温度",
        StringKeys.CELL_TEMP_RANGE to "单体温差区间",
        StringKeys.ENERGY_REMAINING to "剩余电量",
        StringKeys.TOTAL_CAPACITY to "额定容量",
        StringKeys.HEALTH_SOH to "电池健康度 (SOH)",
        StringKeys.CHARGE_CYCLES to "循环充放次数",
        StringKeys.THERMAL_MGMT to "直冷直热温控系统",
        StringKeys.POWER_FLOW to "能量流向",
        StringKeys.DISCHARGE to "放电驱动",
        StringKeys.REGEN to "动能回收",
        StringKeys.IDLE to "待机",

        StringKeys.CHARGING_TITLE to "智能充电控制与曲线监测",
        StringKeys.CHARGE_STATE to "充电状态",
        StringKeys.CHARGING_POWER to "充电功率",
        StringKeys.CHARGING_VOLTAGE to "充电电压",
        StringKeys.CHARGING_CURRENT to "充电电流",
        StringKeys.TARGET_SOC to "目标充电限额",
        StringKeys.TIME_REMAINING to "预计充满时间",
        StringKeys.ENERGY_DELIVERED to "本次充入电量",
        StringKeys.SESSION_DURATION to "充电持续时间",
        StringKeys.CHARGER_TYPE to "充电桩协议",
        StringKeys.DC_FAST to "直流高压快充 (DC)",
        StringKeys.AC_SLOW to "交流家用慢充 (AC)",
        StringKeys.START_CHARGING to "开始充电",
        StringKeys.PAUSE_CHARGING to "暂停充电",
        StringKeys.RESUME_CHARGING to "恢复充电",
        StringKeys.STOP_CHARGING to "停止充电",

        StringKeys.POWERTRAIN_TITLE to "电驱动力学与电机工况",
        StringKeys.MOTOR_RPM to "驱动电机转速",
        StringKeys.MOTOR_TORQUE to "输出扭矩",
        StringKeys.MOTOR_POWER to "电机功率",
        StringKeys.MOTOR_TEMP to "电机温度",
        StringKeys.INVERTER_TEMP to "碳化硅(SiC)电控温度",
        StringKeys.EFFICIENCY to "电驱综合效率",
        StringKeys.ECO to "经济 (ECO)",
        StringKeys.NORMAL to "标准 (NORMAL)",
        StringKeys.SPORT to "运动 (SPORT)",
        StringKeys.SNOW to "雪地 (SNOW)",

        StringKeys.BODY_TITLE to "车身状态与闭锁监控",
        StringKeys.DOOR_FL to "左前门 (FL)",
        StringKeys.DOOR_FR to "右前门 (FR)",
        StringKeys.DOOR_RL to "左后门 (RL)",
        StringKeys.DOOR_RR to "右后门 (RR)",
        StringKeys.TRUNK to "电动后尾门",
        StringKeys.HOOD to "前机舱盖",
        StringKeys.WINDOWS to "四门车窗",
        StringKeys.LIGHTS to "LED 外车灯",
        StringKeys.CHARGE_PORT to "充电口盖",
        StringKeys.OPEN to "打开",
        StringKeys.CLOSED to "关闭",
        StringKeys.LOCKED to "已锁定",
        StringKeys.UNLOCKED to "未锁定",

        StringKeys.CLIMATE_TITLE to "宽温域高效热泵空调系统",
        StringKeys.TARGET_TEMP to "设定温度",
        StringKeys.FAN_SPEED to "风量挡位",
        StringKeys.AC_MODE to "压缩机制冷 (A/C)",
        StringKeys.HEAT_MODE to "热泵制热",
        StringKeys.RECIRCULATION to "内/外循环",
        StringKeys.FRONT_DEFROST to "前挡风除雾",
        StringKeys.REAR_DEFROST to "后视镜除霜",
        StringKeys.AUX_POWER to "空调辅件功耗",

        StringKeys.TYRES_TITLE to "直接式胎压监测系统 (TPMS)",
        StringKeys.PRESSURE to "胎压",
        StringKeys.TEMPERATURE to "胎温",
        StringKeys.TYRE_FL to "左前轮 (FL)",
        StringKeys.TYRE_FR to "右前轮 (FR)",
        StringKeys.TYRE_RL to "左后轮 (RL)",
        StringKeys.TYRE_RR to "右后轮 (RR)",
        StringKeys.SIMULATE_PUNCTURE to "模拟慢撒气/漏气 (左前轮)",
        StringKeys.RESTORE_PRESSURE to "恢复标称胎压",

        StringKeys.DIAGNOSTICS_TITLE to "整车 OBD / DTC 诊断中心",
        StringKeys.SYSTEM_HEALTH to "域控制器健康矩阵",
        StringKeys.DTC_CODES to "故障诊断码 (DTC)",
        StringKeys.FAULTS to "当前告警",
        StringKeys.STATUS_NORMAL to "正常",
        StringKeys.STATUS_WARNING to "警告",
        StringKeys.STATUS_FAULT to "故障",
        StringKeys.STATUS_OFFLINE to "离线",
        StringKeys.CLEAR_DTC to "清除诊断码",
        StringKeys.INJECT_FAULT to "注入测试故障码",

        StringKeys.API_EXPLORER_TITLE to "信号注册表与 REST/WebSocket API 浏览器",
        StringKeys.SIGNAL_ID to "信号标识 (Signal ID)",
        StringKeys.DATA_TYPE to "数据类型",
        StringKeys.UNIT to "工程单位",
        StringKeys.QUALITY to "数据质量",
        StringKeys.SOURCE to "数据源",
        StringKeys.UPDATE_FREQ to "采样/上报周期",
        StringKeys.ACCESS_PERMISSION to "读写权限",
        StringKeys.SAFETY_CLASS to "功能安全分级 (ASIL)",
        StringKeys.JSON_PREVIEW to "REST / 遥测 Payload 报文",
        StringKeys.COPY_JSON to "复制 JSON 报文",
        StringKeys.COPIED to "已复制到剪贴板！",
        StringKeys.SEARCH_SIGNALS to "筛选信号 (如 battery, speed, door)...",

        StringKeys.TELEMETRY_TITLE to "多通道实时工程遥测示波器",
        StringKeys.TIME_SPAN to "时基范围",
        StringKeys.LIVE_STREAM to "实时流",
        StringKeys.PAUSE_STREAM to "暂停",
        StringKeys.EXPORT_DATA to "导出数据集",
        StringKeys.LOGS_TITLE to "车载总线与 API 架构工程日志",
        StringKeys.LOG_LEVEL to "日志等级",
        StringKeys.ALL_MODULES to "全部模块",
        StringKeys.CLEAR_LOGS to "清空日志",

        StringKeys.SCENARIO_LAB_TITLE to "场景实验室与整车动力学仿真",
        StringKeys.PRESETS to "预设工况",
        StringKeys.URBAN_DRIVING to "城市拥堵起停",
        StringKeys.MOTORWAY to "高速巡航工况",
        StringKeys.HEAVY_TRAFFIC to "走走停停高能耗",
        StringKeys.COLD_WEATHER to "冬季极寒环境 (-15°C)",
        StringKeys.HOT_WEATHER to "夏季高温暴晒 (38°C)",
        StringKeys.FAST_CHARGING to "150kW 高压超充",
        StringKeys.LONG_JOURNEY to "长途跨城巡航",
        StringKeys.LOW_BATTERY to "低电量预警 (12%)",
        StringKeys.SIM_SPEED to "仿真倍速",
        StringKeys.RUN_SCENARIO to "加载并运行工况",
        StringKeys.REPLAY_TITLE to "历史行驶工况遥测回放",
        StringKeys.SESSIONS to "回放会话库",
        StringKeys.PLAY to "播放",
        StringKeys.PAUSE to "暂停",
        StringKeys.STEP to "单步 (+1s)",
        StringKeys.RESTART to "从头开始",

        StringKeys.SETTINGS_TITLE to "系统设置与车机架构说明",
        StringKeys.LANGUAGE to "界面语言 (Language)",
        StringKeys.THEME to "色彩主题",
        StringKeys.UNITS to "度量衡单位",
        StringKeys.DATA_PROVIDER to "活跃数据提供程序",
        StringKeys.DILINK_INFO to "比亚迪 DiLink 生态适配层",
        StringKeys.SAFETY_ARCHITECTURE to "车规级功能安全与控制隔离架构",
        StringKeys.DEVELOPER_MODE to "开发者调试工具"
    )

    fun get(key: String, language: Language): String {
        val dict = if (language == Language.ZH) zh else en
        return dict[key] ?: en[key] ?: key
    }
}
