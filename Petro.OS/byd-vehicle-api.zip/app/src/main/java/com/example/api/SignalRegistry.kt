package com.example.api

import com.example.domain.models.*

object SignalRegistry {
    val definitions: List<SignalDefinition> = listOf(
        // Vehicle Dynamics
        SignalDefinition(
            id = "vehicle.speed",
            category = SignalCategory.VEHICLE,
            nameEn = "Vehicle Speed",
            nameZh = "车速",
            dataType = "FLOAT",
            unit = "km/h",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 50,
            source = "CAN_ESP_NODE",
            descriptionEn = "Real-time calibrated wheel speed from electronic stability program",
            descriptionZh = "车身电子稳定系统测算的轮速平均值"
        ),
        SignalDefinition(
            id = "vehicle.gear",
            category = SignalCategory.VEHICLE,
            nameEn = "Shift Selector Position",
            nameZh = "挡位状态",
            dataType = "ENUM",
            unit = "-",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 100,
            source = "CAN_TCU_NODE",
            descriptionEn = "Current drive position: P (Park), R (Reverse), N (Neutral), D (Drive)",
            descriptionZh = "电子换挡杆当前所处挡位 (P/R/N/D)"
        ),
        SignalDefinition(
            id = "vehicle.driveMode",
            category = SignalCategory.VEHICLE,
            nameEn = "Drive Mode Setting",
            nameZh = "驾驶模式",
            dataType = "ENUM",
            unit = "-",
            readable = true,
            writable = true,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 200,
            source = "CAN_VCU_NODE",
            descriptionEn = "Drive mapping mode: ECO, NORMAL, SPORT, SNOW",
            descriptionZh = "整车控制器驱动响应特性映射模式"
        ),
        SignalDefinition(
            id = "vehicle.odometer",
            category = SignalCategory.VEHICLE,
            nameEn = "Total Odometer",
            nameZh = "总行驶里程",
            dataType = "DOUBLE",
            unit = "km",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 1000,
            source = "CAN_ICM_NODE",
            descriptionEn = "Cumulative vehicle odometer reading",
            descriptionZh = "仪表域记录的整车累计行驶公里数"
        ),
        SignalDefinition(
            id = "vehicle.acceleratorPosition",
            category = SignalCategory.VEHICLE,
            nameEn = "Accelerator Pedal Depth",
            nameZh = "油门踏板开度",
            dataType = "FLOAT",
            unit = "%",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 50,
            source = "CAN_VCU_NODE",
            descriptionEn = "Dual-channel accelerator pedal travel percentage",
            descriptionZh = "电子加速踏板行程深度百分比"
        ),
        SignalDefinition(
            id = "vehicle.brakePedal",
            category = SignalCategory.VEHICLE,
            nameEn = "Brake Pedal Depth",
            nameZh = "制动踏板行程",
            dataType = "FLOAT",
            unit = "%",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 50,
            source = "CAN_IBOOSTER_NODE",
            descriptionEn = "Intelligent electronic brake booster position",
            descriptionZh = "智能刹车助力泵制动行程传感器深度"
        ),
        SignalDefinition(
            id = "vehicle.steeringAngle",
            category = SignalCategory.VEHICLE,
            nameEn = "Steering Angle",
            nameZh = "方向盘转角",
            dataType = "FLOAT",
            unit = "deg",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 50,
            source = "CAN_EPS_NODE",
            descriptionEn = "Electric power steering sensor angle (-540 to +540)",
            descriptionZh = "电动助力转向管柱角度传感器输入"
        ),
        SignalDefinition(
            id = "vehicle.parkingBrake",
            category = SignalCategory.VEHICLE,
            nameEn = "Electric Parking Brake",
            nameZh = "电子驻车制动 (EPB)",
            dataType = "BOOLEAN",
            unit = "-",
            readable = true,
            writable = true,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 200,
            source = "CAN_EPB_NODE",
            descriptionEn = "State of caliper EPB motor clamp",
            descriptionZh = "后轮制动钳电子驻车电机夹紧状态"
        ),

        // Battery
        SignalDefinition(
            id = "battery.soc",
            category = SignalCategory.BATTERY,
            nameEn = "Battery State of Charge",
            nameZh = "电池荷电状态 (SOC)",
            dataType = "FLOAT",
            unit = "%",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_C,
            updateFrequencyMs = 200,
            source = "CAN_BMS_NODE",
            descriptionEn = "Calibrated state of charge of Blade Battery pack",
            descriptionZh = "刀片电池 BMS 高精度安时积分与开路电压校准电量"
        ),
        SignalDefinition(
            id = "battery.voltage",
            category = SignalCategory.BATTERY,
            nameEn = "Total Pack Voltage",
            nameZh = "电池包总电压",
            dataType = "FLOAT",
            unit = "V",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_C,
            updateFrequencyMs = 100,
            source = "CAN_BMS_NODE",
            descriptionEn = "High-voltage bus aggregate potential across all series cells",
            descriptionZh = "全串联刀片电芯高压母线总端电压"
        ),
        SignalDefinition(
            id = "battery.current",
            category = SignalCategory.BATTERY,
            nameEn = "Pack Current",
            nameZh = "电池包总电流",
            dataType = "FLOAT",
            unit = "A",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_C,
            updateFrequencyMs = 50,
            source = "CAN_BMS_NODE",
            descriptionEn = "Current flow (+ discharge, - charging)",
            descriptionZh = "主回路霍尔电流传感器读数 (正为放电，负为充电)"
        ),
        SignalDefinition(
            id = "battery.power",
            category = SignalCategory.BATTERY,
            nameEn = "Battery Power",
            nameZh = "电池瞬时功率",
            dataType = "FLOAT",
            unit = "kW",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_C,
            updateFrequencyMs = 50,
            source = "CALCULATED_V_x_I",
            descriptionEn = "Calculated instant power: Voltage × Current / 1000",
            descriptionZh = "实时高压母线瞬时功率 (P = U × I)"
        ),
        SignalDefinition(
            id = "battery.temperature",
            category = SignalCategory.BATTERY,
            nameEn = "Pack Average Temperature",
            nameZh = "电池包平均温度",
            dataType = "FLOAT",
            unit = "°C",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_C,
            updateFrequencyMs = 500,
            source = "CAN_BMS_NTC_ARRAY",
            descriptionEn = "Mean temperature across all Blade cell NTC probes",
            descriptionZh = "刀片电芯阵列 NTC 温度传感器矩阵平均值"
        ),
        SignalDefinition(
            id = "battery.range",
            category = SignalCategory.BATTERY,
            nameEn = "Estimated Remaining Range",
            nameZh = "预计剩余续航里程",
            dataType = "FLOAT",
            unit = "km",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 1000,
            source = "CAN_VCU_ALGO",
            descriptionEn = "Dynamic range estimate based on energy buffer and driving consumption history",
            descriptionZh = "根据历史综合能耗与可用电量动态推算的续航里程"
        ),
        SignalDefinition(
            id = "battery.soh",
            category = SignalCategory.BATTERY,
            nameEn = "State of Health",
            nameZh = "电池健康度 (SOH)",
            dataType = "FLOAT",
            unit = "%",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 5000,
            source = "CAN_BMS_INTERNAL",
            descriptionEn = "Blade battery cell capacity retention vs nominal rating",
            descriptionZh = "刀片电池可用衰减健康百分比"
        ),

        // Charging
        SignalDefinition(
            id = "charging.state",
            category = SignalCategory.CHARGING,
            nameEn = "Charging Operational State",
            nameZh = "充电工况状态",
            dataType = "ENUM",
            unit = "-",
            readable = true,
            writable = true,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 200,
            source = "CAN_OBC_NODE",
            descriptionEn = "Active charging state (DISCONNECTED, CONNECTED, CHARGING, PAUSED, COMPLETE)",
            descriptionZh = "车载充电机/直流高压充电子系统状态"
        ),
        SignalDefinition(
            id = "charging.power",
            category = SignalCategory.CHARGING,
            nameEn = "Charging Power",
            nameZh = "充电输入功率",
            dataType = "FLOAT",
            unit = "kW",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 100,
            source = "CAN_BMS_OBC_COMBO",
            descriptionEn = "Real-time energy transfer rate into vehicle pack",
            descriptionZh = "从充电桩注入电池包的实时充电功率"
        ),
        SignalDefinition(
            id = "charging.voltage",
            category = SignalCategory.CHARGING,
            nameEn = "Charging Voltage",
            nameZh = "充电桩输出电压",
            dataType = "FLOAT",
            unit = "V",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 100,
            source = "CAN_GB_T_DC_COMM",
            descriptionEn = "DC / AC charge port measured voltage",
            descriptionZh = "快充国标通信握手输出电压"
        ),
        SignalDefinition(
            id = "charging.current",
            category = SignalCategory.CHARGING,
            nameEn = "Charging Current",
            nameZh = "充电输入电流",
            dataType = "FLOAT",
            unit = "A",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 100,
            source = "CAN_GB_T_DC_COMM",
            descriptionEn = "DC charge port measured current injection",
            descriptionZh = "快充国标通信握手输入电流"
        ),
        SignalDefinition(
            id = "charging.timeRemaining",
            category = SignalCategory.CHARGING,
            nameEn = "Estimated Time to Target SOC",
            nameZh = "预计充满剩余时间",
            dataType = "INT",
            unit = "min",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 1000,
            source = "CAN_BMS_PREDICTOR",
            descriptionEn = "Minutes remaining to hit programmed target charge threshold",
            descriptionZh = "充至预设目标限额所需的预计分钟数"
        ),

        // Powertrain & Motor
        SignalDefinition(
            id = "motor.rpm",
            category = SignalCategory.POWERTRAIN,
            nameEn = "Permanent Magnet Motor RPM",
            nameZh = "永磁同步电机转速",
            dataType = "FLOAT",
            unit = "rpm",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 50,
            source = "CAN_MCU_RESOLVER",
            descriptionEn = "Motor rotor speed derived from high-resolution resolver",
            descriptionZh = "电机旋变传感器反馈的转子实时机械转速"
        ),
        SignalDefinition(
            id = "motor.torque",
            category = SignalCategory.POWERTRAIN,
            nameEn = "Delivered Motor Torque",
            nameZh = "电机输出扭矩",
            dataType = "FLOAT",
            unit = "Nm",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 50,
            source = "CAN_MCU_NODE",
            descriptionEn = "Electromagnetic torque generated at rotor shaft",
            descriptionZh = "电机电磁轴端输出实际扭矩"
        ),
        SignalDefinition(
            id = "motor.power",
            category = SignalCategory.POWERTRAIN,
            nameEn = "Mechanical Shaft Power",
            nameZh = "电机机械输出功率",
            dataType = "FLOAT",
            unit = "kW",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 50,
            source = "CALCULATED_TORQUE_x_RPM",
            descriptionEn = "Shaft power (Torque × RPM / 9550)",
            descriptionZh = "电机输出机械轴功率"
        ),
        SignalDefinition(
            id = "motor.temperature",
            category = SignalCategory.POWERTRAIN,
            nameEn = "Motor Stator Temperature",
            nameZh = "电机定子绕组温度",
            dataType = "FLOAT",
            unit = "°C",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_C,
            updateFrequencyMs = 500,
            source = "CAN_MCU_PT1000",
            descriptionEn = "Direct winding temperature probe inside motor stator",
            descriptionZh = "电机内部定子绕组埋设 PT1000 温度传感器读数"
        ),

        // Body & Doors
        SignalDefinition(
            id = "body.doors.frontLeft",
            category = SignalCategory.BODY,
            nameEn = "Front Left Door State",
            nameZh = "左前门开闭状态",
            dataType = "ENUM",
            unit = "-",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_A,
            updateFrequencyMs = 200,
            source = "CAN_BCM_NODE",
            descriptionEn = "Driver door micro-switch contact state",
            descriptionZh = "主驾车门行程微动开关检测状态"
        ),
        SignalDefinition(
            id = "body.doors.frontRight",
            category = SignalCategory.BODY,
            nameEn = "Front Right Door State",
            nameZh = "右前门开闭状态",
            dataType = "ENUM",
            unit = "-",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_A,
            updateFrequencyMs = 200,
            source = "CAN_BCM_NODE",
            descriptionEn = "Front passenger door contact state",
            descriptionZh = "副驾车门微动开关状态"
        ),
        SignalDefinition(
            id = "body.trunk",
            category = SignalCategory.BODY,
            nameEn = "Power Tailgate / Trunk",
            nameZh = "电动尾门状态",
            dataType = "ENUM",
            unit = "-",
            readable = true,
            writable = true,
            safetyClass = SafetyClassification.ASIL_A,
            updateFrequencyMs = 200,
            source = "CAN_PLG_NODE",
            descriptionEn = "Rear power tailgate latch status",
            descriptionZh = "后尾门电动锁舌及举升状态"
        ),
        SignalDefinition(
            id = "body.hood",
            category = SignalCategory.BODY,
            nameEn = "Front Hood / Frunk",
            nameZh = "前机舱盖状态",
            dataType = "ENUM",
            unit = "-",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_A,
            updateFrequencyMs = 200,
            source = "CAN_BCM_NODE",
            descriptionEn = "Frunk security micro-latch status",
            descriptionZh = "前舱锁闩微动传感器状态"
        ),
        SignalDefinition(
            id = "body.centralLock",
            category = SignalCategory.BODY,
            nameEn = "Central Lock Security",
            nameZh = "中控闭锁状态",
            dataType = "ENUM",
            unit = "-",
            readable = true,
            writable = true,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 200,
            source = "CAN_BCM_SECURITY",
            descriptionEn = "Vehicle four-door central deadlocking state",
            descriptionZh = "整车四门电子中控锁防盗状态"
        ),

        // Climate / HVAC
        SignalDefinition(
            id = "climate.cabinTemperature",
            category = SignalCategory.CLIMATE,
            nameEn = "Cabin Ambient Temperature",
            nameZh = "座舱内部温度",
            dataType = "FLOAT",
            unit = "°C",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 500,
            source = "CAN_HVAC_AIR_TEMP",
            descriptionEn = "Aspirated cabin thermistor sensor value",
            descriptionZh = "座舱内吸气式温度传感器读数"
        ),
        SignalDefinition(
            id = "climate.targetTemperature",
            category = SignalCategory.CLIMATE,
            nameEn = "HVAC Setpoint Temperature",
            nameZh = "空调目标设定温度",
            dataType = "FLOAT",
            unit = "°C",
            readable = true,
            writable = true,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 200,
            source = "CAN_HVAC_PANEL",
            descriptionEn = "Driver desired target temperature setpoint",
            descriptionZh = "驾驶员设定的空调目标期望温区"
        ),
        SignalDefinition(
            id = "climate.outsideTemperature",
            category = SignalCategory.CLIMATE,
            nameEn = "Outside Ambient Temperature",
            nameZh = "车外环境温度",
            dataType = "FLOAT",
            unit = "°C",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 1000,
            source = "CAN_FRONT_BUMPER_NTC",
            descriptionEn = "External air temp behind front grille",
            descriptionZh = "前格栅后方外置温度传感器读数"
        ),
        SignalDefinition(
            id = "climate.fanSpeed",
            category = SignalCategory.CLIMATE,
            nameEn = "Blower Fan Level",
            nameZh = "空调鼓风机挡位",
            dataType = "INT",
            unit = "steps",
            readable = true,
            writable = true,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 200,
            source = "CAN_HVAC_BLOWER",
            descriptionEn = "PWM blower fan speed (1 to 8)",
            descriptionZh = "空调 PWM 无级调速鼓风机当前挡位 (1-8)"
        ),
        SignalDefinition(
            id = "climate.auxiliaryPower",
            category = SignalCategory.CLIMATE,
            nameEn = "HVAC Electrical Draw",
            nameZh = "空调及附件功耗",
            dataType = "FLOAT",
            unit = "kW",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 200,
            source = "CAN_DCDC_HVAC_MONITOR",
            descriptionEn = "High-voltage electric compressor & heat pump power draw",
            descriptionZh = "高压电动压缩机与热泵系统瞬时电功率消耗"
        ),

        // Tyres / TPMS
        SignalDefinition(
            id = "tyres.frontLeft.pressure",
            category = SignalCategory.TYRES,
            nameEn = "Front Left Tyre Pressure",
            nameZh = "左前轮胎压",
            dataType = "FLOAT",
            unit = "kPa",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 500,
            source = "CAN_TPMS_RF_FL",
            descriptionEn = "Direct internal valve RF transmitter pressure",
            descriptionZh = "左前气门嘴高频射频胎压传感器直接测量值"
        ),
        SignalDefinition(
            id = "tyres.frontRight.pressure",
            category = SignalCategory.TYRES,
            nameEn = "Front Right Tyre Pressure",
            nameZh = "右前轮胎压",
            dataType = "FLOAT",
            unit = "kPa",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 500,
            source = "CAN_TPMS_RF_FR",
            descriptionEn = "Direct internal valve RF transmitter pressure",
            descriptionZh = "右前气门嘴高频射频胎压传感器测量值"
        ),
        SignalDefinition(
            id = "tyres.rearLeft.pressure",
            category = SignalCategory.TYRES,
            nameEn = "Rear Left Tyre Pressure",
            nameZh = "左后轮胎压",
            dataType = "FLOAT",
            unit = "kPa",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 500,
            source = "CAN_TPMS_RF_RL",
            descriptionEn = "Direct internal valve RF transmitter pressure",
            descriptionZh = "左后气门嘴高频射频胎压传感器测量值"
        ),
        SignalDefinition(
            id = "tyres.rearRight.pressure",
            category = SignalCategory.TYRES,
            nameEn = "Rear Right Tyre Pressure",
            nameZh = "右后轮胎压",
            dataType = "FLOAT",
            unit = "kPa",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_B,
            updateFrequencyMs = 500,
            source = "CAN_TPMS_RF_RR",
            descriptionEn = "Direct internal valve RF transmitter pressure",
            descriptionZh = "右后气门嘴高频射频胎压传感器测量值"
        ),

        // ADAS
        SignalDefinition(
            id = "adas.dipilot.status",
            category = SignalCategory.ADAS,
            nameEn = "DiPilot Driver Assist State",
            nameZh = "DiPilot 智能驾驶状态",
            dataType = "STRING",
            unit = "-",
            readable = true,
            writable = false,
            safetyClass = SafetyClassification.ASIL_D,
            updateFrequencyMs = 100,
            source = "CAN_ADAS_DOMAIN_CONTROLLER",
            descriptionEn = "Integrated L2+ highway driving assist pipeline status",
            descriptionZh = "智能驾驶域控制器集成辅助驾驶状态"
        ),

        // Diagnostics
        SignalDefinition(
            id = "diagnostics.dtc.count",
            category = SignalCategory.DIAGNOSTICS,
            nameEn = "Active Diagnostic Trouble Codes",
            nameZh = "活动故障码计数",
            dataType = "INT",
            unit = "count",
            readable = true,
            writable = true,
            safetyClass = SafetyClassification.QM,
            updateFrequencyMs = 1000,
            source = "OBD2_UDS_SERVICE_19",
            descriptionEn = "Count of confirmed emission & high-voltage DTC records in flash",
            descriptionZh = "整车网关当前存储的确诊故障码 (DTC) 总数"
        )
    )

    fun getDefinition(id: String): SignalDefinition? = definitions.find { it.id == id }

    fun extractSignalValue(id: String, state: VehicleState): VehicleSignalValue? {
        val def = getDefinition(id) ?: return null
        val (raw, formatted) = when (id) {
            "vehicle.speed" -> Pair(state.speedKmH, "%.1f".format(state.speedKmH))
            "vehicle.gear" -> Pair(state.gear.name, state.gear.label)
            "vehicle.driveMode" -> Pair(state.driveMode.name, state.driveMode.enName)
            "vehicle.odometer" -> Pair(state.odometerKm, "%.1f".format(state.odometerKm))
            "vehicle.acceleratorPosition" -> Pair(state.acceleratorPositionPercent, "%.0f".format(state.acceleratorPositionPercent))
            "vehicle.brakePedal" -> Pair(state.brakePedalPercent, "%.0f".format(state.brakePedalPercent))
            "vehicle.steeringAngle" -> Pair(state.steeringAngleDeg, "%.1f".format(state.steeringAngleDeg))
            "vehicle.parkingBrake" -> Pair(state.parkingBrakeEngaged, if (state.parkingBrakeEngaged) "ENGAGED" else "RELEASED")

            "battery.soc" -> Pair(state.battery.socPercent, "%.1f".format(state.battery.socPercent))
            "battery.voltage" -> Pair(state.battery.voltageV, "%.1f".format(state.battery.voltageV))
            "battery.current" -> Pair(state.battery.currentA, "%.1f".format(state.battery.currentA))
            "battery.power" -> Pair(state.battery.powerKw, "%.2f".format(state.battery.powerKw))
            "battery.temperature" -> Pair(state.battery.packTemperatureC, "%.1f".format(state.battery.packTemperatureC))
            "battery.range" -> Pair(state.battery.estimatedRangeKm, "%.0f".format(state.battery.estimatedRangeKm))
            "battery.soh" -> Pair(state.battery.sohPercent, "%.1f".format(state.battery.sohPercent))

            "charging.state" -> Pair(state.charging.status.name, state.charging.status.name)
            "charging.power" -> Pair(state.charging.chargingPowerKw, "%.1f".format(state.charging.chargingPowerKw))
            "charging.voltage" -> Pair(state.charging.chargingVoltageV, "%.1f".format(state.charging.chargingVoltageV))
            "charging.current" -> Pair(state.charging.chargingCurrentA, "%.1f".format(state.charging.chargingCurrentA))
            "charging.timeRemaining" -> Pair(state.charging.estimatedMinutesRemaining, "${state.charging.estimatedMinutesRemaining}")

            "motor.rpm" -> Pair(state.powertrain.motorRpm, "%.0f".format(state.powertrain.motorRpm))
            "motor.torque" -> Pair(state.powertrain.motorTorqueNm, "%.1f".format(state.powertrain.motorTorqueNm))
            "motor.power" -> Pair(state.powertrain.motorPowerKw, "%.1f".format(state.powertrain.motorPowerKw))
            "motor.temperature" -> Pair(state.powertrain.motorTempC, "%.1f".format(state.powertrain.motorTempC))

            "body.doors.frontLeft" -> Pair(state.body.doorFrontLeft.name, state.body.doorFrontLeft.name)
            "body.doors.frontRight" -> Pair(state.body.doorFrontRight.name, state.body.doorFrontRight.name)
            "body.trunk" -> Pair(state.body.trunk.name, state.body.trunk.name)
            "body.hood" -> Pair(state.body.hood.name, state.body.hood.name)
            "body.centralLock" -> Pair(state.body.centralLock.name, state.body.centralLock.name)

            "climate.cabinTemperature" -> Pair(state.cabin.cabinTempC, "%.1f".format(state.cabin.cabinTempC))
            "climate.targetTemperature" -> Pair(state.cabin.targetTempC, "%.1f".format(state.cabin.targetTempC))
            "climate.outsideTemperature" -> Pair(state.cabin.outsideTempC, "%.1f".format(state.cabin.outsideTempC))
            "climate.fanSpeed" -> Pair(state.cabin.fanSpeed, "${state.cabin.fanSpeed}")
            "climate.auxiliaryPower" -> Pair(state.cabin.auxiliaryPowerKw, "%.2f".format(state.cabin.auxiliaryPowerKw))

            "tyres.frontLeft.pressure" -> Pair(state.tyres.frontLeft.pressureKpa, "%.0f".format(state.tyres.frontLeft.pressureKpa))
            "tyres.frontRight.pressure" -> Pair(state.tyres.frontRight.pressureKpa, "%.0f".format(state.tyres.frontRight.pressureKpa))
            "tyres.rearLeft.pressure" -> Pair(state.tyres.rearLeft.pressureKpa, "%.0f".format(state.tyres.rearLeft.pressureKpa))
            "tyres.rearRight.pressure" -> Pair(state.tyres.rearRight.pressureKpa, "%.0f".format(state.tyres.rearRight.pressureKpa))

            "adas.dipilot.status" -> Pair(if (state.adas.laneKeepAssistActive) "ACTIVE_L2_LKA" else "STANDBY", if (state.adas.laneKeepAssistActive) "ACTIVE" else "STANDBY")
            "diagnostics.dtc.count" -> Pair(state.diagnostics.activeDtcs.size, "${state.diagnostics.activeDtcs.size}")

            else -> Pair("N/A", "N/A")
        }

        return VehicleSignalValue(
            definition = def,
            rawValue = raw,
            formattedValue = formatted,
            quality = DataQuality.VALID,
            timestamp = state.timestamp
        )
    }

    fun generateJsonPayload(signal: VehicleSignalValue): String {
        return """{
  "signal": "${signal.definition.id}",
  "name_en": "${signal.definition.nameEn}",
  "name_zh": "${signal.definition.nameZh}",
  "category": "${signal.definition.category.name}",
  "value": ${if (signal.rawValue is Number || signal.rawValue is Boolean) signal.rawValue else "\"${signal.rawValue}\""},
  "unit": "${signal.definition.unit}",
  "data_type": "${signal.definition.dataType}",
  "quality": "${signal.quality.name}",
  "safety_class": "${signal.definition.safetyClass.code}",
  "source": "${signal.definition.source}",
  "timestamp": ${signal.timestamp},
  "protocol": "BYD_DILINK_CAN_V3.2"
}"""
    }
}
