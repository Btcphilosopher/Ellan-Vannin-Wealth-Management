package com.example.ui.simulator

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.simulator.ScenarioConfig
import com.example.simulator.ScenarioPresets
import com.example.ui.components.AutomotiveCard
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun ScenarioLabScreen(
    activeScenarioId: String,
    simSpeedMultiplier: Float,
    isPaused: Boolean,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Simulation Control Bar
        AutomotiveCard(
            titleEn = "Simulation Speed Multiplier & Execution Control",
            titleZh = "仿真时钟倍率与物理引擎控制",
            language = language
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Multiplier Buttons: 1x, 2x, 5x, 10x
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1.0f, 2.0f, 5.0f, 10.0f).forEach { spd ->
                        val isSel = simSpeedMultiplier == spd
                        Button(
                            onClick = { viewModel.setSimSpeed(spd) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSel) BydElectricCyan else CockpitSurfaceDark
                            ),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.border(
                                1.dp,
                                if (isSel) BydElectricCyan else CockpitBorder,
                                RoundedCornerShape(6.dp)
                            )
                        ) {
                            Text(
                                text = "${spd.toInt()}x",
                                color = if (isSel) CockpitBackground else TechWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Pause / Play Toggle
                Button(
                    onClick = { viewModel.toggleSimPause() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPaused) BydEnergyGreen else CockpitSurfaceElevated
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.border(1.dp, CockpitBorder, RoundedCornerShape(6.dp))
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = "Sim Control",
                        tint = if (isPaused) CockpitBackground else BydWarningAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isPaused)
                            (if (language == Language.ZH) "继续运行" else "Resume Physics")
                        else
                            (if (language == Language.ZH) "暂停仿真" else "Freeze Physics"),
                        color = if (isPaused) CockpitBackground else TechWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Scenario Preset Grid
        AutomotiveCard(
            titleEn = "Standard Automotive Engineering Preset Scenarios",
            titleZh = "标准汽车工程仿真测试工况预设库",
            language = language,
            badgeText = "${ScenarioPresets.list.size} PRESETS",
            badgeColor = BydElectricCyan,
            modifier = Modifier.weight(1f)
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(ScenarioPresets.list) { preset ->
                    val isSelected = preset.id == activeScenarioId
                    ScenarioPresetCard(
                        preset = preset,
                        isSelected = isSelected,
                        language = language,
                        onSelect = { viewModel.loadScenario(preset) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ScenarioPresetCard(
    preset: ScenarioConfig,
    isSelected: Boolean,
    language: Language,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = if (isSelected) CockpitSurfaceElevated else CockpitSurfaceDark,
                shape = RoundedCornerShape(8.dp)
            )
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) BydElectricCyan else CockpitBorder,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onSelect() }
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (language == Language.ZH) preset.nameZh else preset.nameEn,
                    color = if (isSelected) BydElectricCyan else TechWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .background(BydElectricCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (language == Language.ZH) "运行中" else "ACTIVE",
                            color = BydElectricCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (language == Language.ZH) preset.descriptionZh else preset.descriptionEn,
                color = TechMuted,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "SOC: ${preset.initialSoc.toInt()}%",
                    color = TechSilver,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Amb: ${preset.outsideTempC.toInt()}°C",
                    color = TechSilver,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Speed: ${preset.baseSpeedKmH.toInt()} km/h",
                    color = TechSilver,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
