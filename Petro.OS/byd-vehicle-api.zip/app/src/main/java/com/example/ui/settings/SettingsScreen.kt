package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.components.AutomotiveCard
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun SettingsScreen(
    viewModel: VehicleViewModel,
    language: Language,
    selectedProvider: String,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Vehicle Data Provider Selection Card
        AutomotiveCard(
            titleEn = "Active Vehicle Data Provider & Abstraction Source",
            titleZh = "活跃整车数据提供程序与抽象适配源",
            language = language,
            badgeText = selectedProvider,
            badgeColor = BydElectricCyan
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ProviderOption(
                    titleEn = "Deterministic Simulation Engine",
                    titleZh = "确定性动力学物理仿真引擎 (推荐开发环境)",
                    descriptionEn = "Real-time physics calculation of torque, aerodynamic drag, Blade Battery thermal, and CC-CV charging curves.",
                    descriptionZh = "基于动力学公式实时解算电机转矩、风阻滚阻、刀片电池发热直冷与快充阶梯曲线。",
                    isSelected = selectedProvider == "SIMULATOR",
                    onSelect = { viewModel.setProvider("SIMULATOR") }
                )

                ProviderOption(
                    titleEn = "Recorded Telemetry Replay Engine",
                    titleZh = "实车遥测回放引擎 (历史工况复现)",
                    descriptionEn = "Play synchronized drive cycle sessions captured from high-speed highway & dense urban commutes.",
                    descriptionZh = "逐帧回放真实采集的高速巡航与城市拥堵工况，支持时间轴拖动与定帧单步调试。",
                    isSelected = selectedProvider == "REPLAY",
                    onSelect = { viewModel.setProvider("REPLAY") }
                )

                ProviderOption(
                    titleEn = "BYD DiLink Ecosystem SDK Bridge",
                    titleZh = "比亚迪 DiLink 车机生态 SDK (OEM 适配桩)",
                    descriptionEn = "Production AIDL integration bridge reserved for verified BYD in-cockpit CarService authorization.",
                    descriptionZh = "预留给官方车机生态认证授权的 AIDL 适配层，支持 ECDSA 双向签名与沙盒权限校验。",
                    isSelected = selectedProvider == "OEM",
                    onSelect = { viewModel.setProvider("OEM") }
                )
            }
        }

        // Language & Localization Preferences Card
        AutomotiveCard(
            titleEn = "Cockpit System Language & Engineering Units",
            titleZh = "座舱系统语言与工程单位偏好",
            language = language
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                LanguageButton(
                    label = "English (EN)",
                    isSelected = language == Language.EN,
                    onClick = { viewModel.setLanguage(Language.EN) },
                    modifier = Modifier.weight(1f)
                )

                LanguageButton(
                    label = "简体中文 (ZH)",
                    isSelected = language == Language.ZH,
                    onClick = { viewModel.setLanguage(Language.ZH) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Automotive Safety & Platform Architecture Disclaimers Card
        AutomotiveCard(
            titleEn = "Automotive Safety Architecture & Integrity Notice",
            titleZh = "汽车功能安全架构与开发者规范声明",
            language = language
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = if (language == Language.ZH)
                        "1. 本系统为面向比亚迪智能座舱生态的高级车辆数据 API 开发与仿真平台，不直接对物理真车发起未经认证的底层总线控制。"
                    else
                        "1. This platform provides developer-grade BYD intelligent-cockpit vehicle data APIs and simulation without bypassing vehicle security boundaries.",
                    color = TechSilver,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
                Text(
                    text = if (language == Language.ZH)
                        "2. 平台遵循严格的读写分离机制：只读遥测提供确定性更新，写控制指令受 ASIL-B/D 安全策略网关审计与工况前置条件校验（如车速、驻车挡位制动）。"
                    else
                        "2. Strict Read/Write separation is enforced: telemetry is observational, while write actuations pass through ASIL-B/D safety gating and speed/gear preconditions.",
                    color = TechSilver,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
                Text(
                    text = if (language == Language.ZH)
                        "3. 适配层通过 VehicleDataProvider 接口实现完全解耦，未来可无缝无感接入官方授权的 BYD DiLink 车载 SDK 或云端车联网平台。"
                    else
                        "3. Decoupled VehicleDataProvider interface allows seamless binding to authentic authorized BYD DiLink SDK or Cloud Telematics APIs in production.",
                    color = TechSilver,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }
    }
}

@Composable
private fun ProviderOption(
    titleEn: String,
    titleZh: String,
    descriptionEn: String,
    descriptionZh: String,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isSelected) CockpitSurfaceElevated else CockpitSurfaceDark, RoundedCornerShape(6.dp))
            .border(1.dp, if (isSelected) BydElectricCyan else CockpitBorder, RoundedCornerShape(6.dp))
            .clickable { onSelect() }
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$titleEn · $titleZh",
                    color = if (isSelected) BydElectricCyan else TechWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .background(BydElectricCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("ACTIVE", color = BydElectricCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "$descriptionEn $descriptionZh",
                color = TechMuted,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
private fun LanguageButton(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) BydElectricCyan else CockpitSurfaceElevated
        ),
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
            .height(42.dp)
            .border(1.dp, if (isSelected) BydElectricCyan else CockpitBorder, RoundedCornerShape(6.dp))
    ) {
        Text(
            text = label,
            color = if (isSelected) CockpitBackground else TechWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
