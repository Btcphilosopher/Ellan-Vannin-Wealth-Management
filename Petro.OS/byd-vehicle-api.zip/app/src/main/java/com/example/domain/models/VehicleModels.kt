package com.example.domain.models

enum class DriveMode(val enName: String, val zhName: String) {
    ECO("ECO", "经济"),
    NORMAL("NORMAL", "标准"),
    SPORT("SPORT", "运动"),
    SNOW("SNOW", "雪地")
}

enum class GearState(val label: String) {
    P("P"),
    R("R"),
    N("N"),
    D("D")
}

enum class ChargingStatus(val enName: String, val zhName: String) {
    DISCONNECTED("DISCONNECTED", "未连接"),
    CONNECTED("CONNECTED", "已连接"),
    CHARGING("CHARGING", "充电中"),
    PAUSED("PAUSED", "已暂停"),
    COMPLETE("COMPLETE", "充电完成"),
    FAULT("FAULT", "充电故障")
}

enum class ChargerType(val enName: String, val zhName: String) {
    DC_FAST("DC Fast Charge", "直流高压超充"),
    AC_SLOW("AC Wallbox", "交流慢充"),
    V2L("V2L Discharge", "对外放电")
}

enum class DoorState(val enName: String, val zhName: String) {
    CLOSED("Closed", "关闭"),
    OPEN("Open", "打开")
}

enum class LockState(val enName: String, val zhName: String) {
    LOCKED("Locked", "已上锁"),
    UNLOCKED("Unlocked", "已解锁")
}

enum class LightState(val enName: String, val zhName: String) {
    OFF("Off", "关闭"),
    AUTO("Auto", "自动"),
    LOW_BEAM("Low Beam", "近光灯"),
    HIGH_BEAM("High Beam", "远光灯")
}

enum class PowerFlowState(val enName: String, val zhName: String) {
    IDLE("Idle", "静止待机"),
    DISCHARGING("Powering Motor", "电池放电"),
    REGENERATING("Regen Braking", "动能回收"),
    CHARGING("Grid to Battery", "电网充入")
}

enum class DataQuality(val enName: String, val zhName: String) {
    VALID("VALID", "有效"),
    STALE("STALE", "过期"),
    INVALID("INVALID", "无效"),
    UNAVAILABLE("UNAVAILABLE", "不可用")
}

enum class SafetyClassification(val code: String, val description: String) {
    ASIL_D("ASIL-D", "Highest Safety Critical (Steering, Braking, Powertrain)"),
    ASIL_C("ASIL-C", "High Safety (Airbag, High Voltage Battery)"),
    ASIL_B("ASIL-B", "Medium Safety (ADAS, Lights, TPMS)"),
    ASIL_A("ASIL-A", "Low Safety (Climate, Body Closures)"),
    QM("QM", "Quality Management (Infotainment, Telemetry, Replay)")
}

data class IndividualTyre(
    val id: String,
    val nameEn: String,
    val nameZh: String,
    val pressureKpa: Float = 248f,
    val temperatureC: Float = 28f,
    val isPunctured: Boolean = false,
    val isLowPressure: Boolean = false
)

data class TyreState(
    val frontLeft: IndividualTyre = IndividualTyre("fl", "Front Left", "左前轮", 248f, 28f),
    val frontRight: IndividualTyre = IndividualTyre("fr", "Front Right", "右前轮", 251f, 29f),
    val rearLeft: IndividualTyre = IndividualTyre("rl", "Rear Left", "左后轮", 246f, 27f),
    val rearRight: IndividualTyre = IndividualTyre("rr", "Rear Right", "右后轮", 249f, 28f)
)

data class BodyState(
    val doorFrontLeft: DoorState = DoorState.CLOSED,
    val doorFrontRight: DoorState = DoorState.CLOSED,
    val doorRearLeft: DoorState = DoorState.CLOSED,
    val doorRearRight: DoorState = DoorState.CLOSED,
    val trunk: DoorState = DoorState.CLOSED,
    val hood: DoorState = DoorState.CLOSED,
    val windowFrontLeft: Float = 0f, // 0 = closed, 100 = open
    val windowFrontRight: Float = 0f,
    val windowRearLeft: Float = 0f,
    val windowRearRight: Float = 0f,
    val centralLock: LockState = LockState.LOCKED,
    val exteriorLights: LightState = LightState.AUTO,
    val hazardLights: Boolean = false,
    val chargePortDoor: DoorState = DoorState.CLOSED,
    val seatbeltDriver: Boolean = true,
    val seatbeltPassenger: Boolean = true
)

data class BatteryState(
    val socPercent: Float = 78.2f,
    val sohPercent: Float = 99.4f,
    val voltageV: Float = 352.4f,
    val currentA: Float = 118.0f,
    val powerKw: Float = 41.58f,
    val packTemperatureC: Float = 25.8f,
    val minCellTempC: Float = 24.9f,
    val maxCellTempC: Float = 26.5f,
    val remainingEnergyKwh: Float = 64.5f,
    val totalCapacityKwh: Float = 82.5f,
    val cycleCount: Int = 42,
    val thermalManagementActive: Boolean = true,
    val powerFlow: PowerFlowState = PowerFlowState.DISCHARGING,
    val estimatedRangeKm: Float = 412.0f
)

data class ChargingState(
    val status: ChargingStatus = ChargingStatus.DISCONNECTED,
    val chargerType: ChargerType = ChargerType.DC_FAST,
    val chargingPowerKw: Float = 0f,
    val chargingVoltageV: Float = 0f,
    val chargingCurrentA: Float = 0f,
    val targetSocPercent: Float = 90f,
    val estimatedMinutesRemaining: Int = 0,
    val energyDeliveredKwh: Float = 0f,
    val sessionSeconds: Long = 0L,
    val maxPowerLimitKw: Float = 150f
)

data class PowertrainState(
    val motorRpm: Float = 3450f,
    val motorTorqueNm: Float = 160f,
    val motorPowerKw: Float = 42.0f,
    val motorTempC: Float = 58.4f,
    val inverterTempC: Float = 46.2f,
    val efficiencyPercent: Float = 94.2f,
    val regenLevel: String = "STANDARD",
    val isRegenerating: Boolean = false,
    val frontMotorPowerKw: Float = 18.0f,
    val rearMotorPowerKw: Float = 24.0f
)

data class CabinState(
    val cabinTempC: Float = 21.4f,
    val targetTempC: Float = 22.0f,
    val outsideTempC: Float = 12.8f,
    val fanSpeed: Int = 3, // 1 to 8
    val acCompressorOn: Boolean = true,
    val heatPumpOn: Boolean = false,
    val recirculationOn: Boolean = false,
    val frontDefrostOn: Boolean = false,
    val rearDefrostOn: Boolean = false,
    val auxiliaryPowerKw: Float = 1.4f
)

data class DtcItem(
    val code: String,
    val system: String,
    val descriptionEn: String,
    val descriptionZh: String,
    val severity: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class DiagnosticState(
    val powertrainHealth: String = "NORMAL",
    val batteryHealth: String = "NORMAL",
    val chargingHealth: String = "NORMAL",
    val thermalHealth: String = "NORMAL",
    val bodyHealth: String = "NORMAL",
    val adasHealth: String = "NORMAL",
    val infotainmentHealth: String = "NORMAL",
    val gatewayHealth: String = "NORMAL",
    val activeDtcs: List<DtcItem> = emptyList()
)

data class ADASState(
    val diPilotAvailable: Boolean = true,
    val laneKeepAssistActive: Boolean = true,
    val adaptiveCruiseControlActive: Boolean = false,
    val targetSpeedKmH: Float = 100f,
    val blindSpotMonitoring: Boolean = true,
    val forwardCollisionWarning: Boolean = true
)

data class VehicleState(
    val vin: String = "LBYDSEAL8NA009281",
    val modelName: String = "BYD SEAL (Demo CTB)",
    val modelNameZh: String = "比亚迪海豹 (CTB 纯电平台)",
    val speedKmH: Float = 64.0f,
    val gear: GearState = GearState.D,
    val driveMode: DriveMode = DriveMode.NORMAL,
    val odometerKm: Double = 14280.5,
    val acceleratorPositionPercent: Float = 24f,
    val brakePedalPercent: Float = 0f,
    val steeringAngleDeg: Float = -2.4f,
    val parkingBrakeEngaged: Boolean = false,
    val avgConsumptionKwhPer100Km: Float = 14.8f,
    val instantConsumptionKwhPer100Km: Float = 15.2f,
    val isReady: Boolean = true,
    val battery: BatteryState = BatteryState(),
    val charging: ChargingState = ChargingState(),
    val powertrain: PowertrainState = PowertrainState(),
    val cabin: CabinState = CabinState(),
    val body: BodyState = BodyState(),
    val tyres: TyreState = TyreState(),
    val diagnostics: DiagnosticState = DiagnosticState(),
    val adas: ADASState = ADASState(),
    val timestamp: Long = System.currentTimeMillis()
)
