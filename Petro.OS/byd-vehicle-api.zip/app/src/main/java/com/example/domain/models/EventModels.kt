package com.example.domain.models

enum class EventType(val enName: String, val zhName: String) {
    VEHICLE_CONNECTED("Vehicle Connected", "车辆已连接"),
    VEHICLE_DISCONNECTED("Vehicle Disconnected", "车辆已断开"),
    VEHICLE_STARTED("Vehicle Ready", "高压系统就绪 (READY)"),
    GEAR_CHANGED("Gear Changed", "挡位切换"),
    DRIVE_MODE_CHANGED("Drive Mode Changed", "驾驶模式切换"),
    SPEED_UPDATED("Speed Shift", "车速变动"),
    SOC_UPDATED("Battery SOC Updated", "电池 SOC 变化"),
    CHARGING_STARTED("Charging Started", "充电开始"),
    CHARGING_STOPPED("Charging Stopped", "充电结束"),
    CHARGING_PAUSED("Charging Paused", "充电暂停"),
    DOOR_OPENED("Door Opened", "车门开启"),
    DOOR_CLOSED("Door Closed", "车门关闭"),
    HVAC_CHANGED("HVAC Setpoint Updated", "空调工况调整"),
    FAULT_RAISED("DTC Fault Raised", "触发诊断告警"),
    FAULT_CLEARED("DTC Cleared", "清除诊断告警"),
    SAFETY_POLICY_CHECK("Safety Policy Evaluated", "安全策略评估")
}

enum class LogLevel {
    INFO,
    DEBUG,
    WARNING,
    ERROR
}

data class VehicleEvent(
    val id: String = java.util.UUID.randomUUID().toString().take(8),
    val type: EventType,
    val summaryEn: String,
    val summaryZh: String,
    val detail: String,
    val source: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class LogEntry(
    val id: Long = System.currentTimeMillis(),
    val timestamp: String,
    val level: LogLevel,
    val module: String,
    val event: String,
    val payload: String
)
