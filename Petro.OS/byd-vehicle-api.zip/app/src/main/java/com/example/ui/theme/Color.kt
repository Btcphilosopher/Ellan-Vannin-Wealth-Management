package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep automotive cockpit surfaces
val CockpitBackground = Color(0xFF080B10)
val CockpitSurfaceDark = Color(0xFF0E131C)
val CockpitSurfaceCard = Color(0xFF141C28)
val CockpitSurfaceElevated = Color(0xFF1B2536)
val CockpitBorder = Color(0xFF25334A)
val CockpitDivider = Color(0xFF1E2A3D)

// Brand accents: BYD EV Electric Cyan & Ruby Red
val BydElectricCyan = Color(0xFF00D2FF)
val BydCyanGlow = Color(0xFF00A3FF)
val BydCrimsonRed = Color(0xFFFF3B30)
val BydEnergyGreen = Color(0xFF00E676)
val BydWarningAmber = Color(0xFFFFB300)
val BydSpeedBlue = Color(0xFF2979FF)

// Text and technical labels
val TechWhite = Color(0xFFFFFFFF)
val TechSilver = Color(0xFFE1E7F0)
val TechMuted = Color(0xFF8A99AD)
val TechDarkText = Color(0xFF5A6980)

// Quality colors
val QualityValid = Color(0xFF00E676)
val QualityStale = Color(0xFFFFB300)
val QualityInvalid = Color(0xFFFF3B30)
val QualityUnavailable = Color(0xFF78909C)
