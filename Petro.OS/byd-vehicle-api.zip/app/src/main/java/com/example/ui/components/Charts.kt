package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.telemetry.TelemetryDataPoint
import com.example.ui.theme.*

@Composable
fun TelemetryMultiLineChart(
    history: List<TelemetryDataPoint>,
    showSpeed: Boolean = true,
    showPower: Boolean = true,
    showSoc: Boolean = true,
    showRpm: Boolean = false,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
            .background(CockpitSurfaceDark, RoundedCornerShape(6.dp))
            .border(1.dp, CockpitBorder, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        if (history.size < 2) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "Awaiting Live Telemetry Streams...",
                    color = TechMuted,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val count = history.size
                val stepX = w / (count - 1).coerceAtLeast(1)

                // Grid lines (4 horizontal)
                for (i in 0..4) {
                    val y = h * (i / 4f)
                    drawLine(
                        color = CockpitDivider,
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                // Plot Speed (0 - 160 km/h)
                if (showSpeed) {
                    val path = Path()
                    history.forEachIndexed { i, pt ->
                        val x = i * stepX
                        val norm = (pt.speed / 160f).coerceIn(0f, 1f)
                        val y = h - (norm * h)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = BydSpeedBlue,
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Plot Power (-50 kW to +150 kW)
                if (showPower) {
                    val path = Path()
                    history.forEachIndexed { i, pt ->
                        val x = i * stepX
                        val norm = ((pt.powerKw + 50f) / 200f).coerceIn(0f, 1f)
                        val y = h - (norm * h)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = BydElectricCyan,
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Plot SOC (0 - 100%)
                if (showSoc) {
                    val path = Path()
                    history.forEachIndexed { i, pt ->
                        val x = i * stepX
                        val norm = (pt.soc / 100f).coerceIn(0f, 1f)
                        val y = h - (norm * h)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = BydEnergyGreen,
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Plot RPM (0 - 12000)
                if (showRpm) {
                    val path = Path()
                    history.forEachIndexed { i, pt ->
                        val x = i * stepX
                        val norm = (pt.rpm / 12000f).coerceIn(0f, 1f)
                        val y = h - (norm * h)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = BydCrimsonRed,
                        style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
        }
    }
}
