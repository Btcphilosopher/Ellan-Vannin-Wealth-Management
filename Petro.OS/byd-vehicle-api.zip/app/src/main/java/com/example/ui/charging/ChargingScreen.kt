package com.example.ui.charging

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.ChargingState
import com.example.domain.models.ChargingStatus
import com.example.domain.models.CommandType
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.MetricReadout
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun ChargingScreen(
    charging: ChargingState,
    socPercent: Float,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Charging State Banner
        val statusColor = when (charging.status) {
            ChargingStatus.CHARGING -> BydEnergyGreen
            ChargingStatus.CONNECTED -> BydElectricCyan
            ChargingStatus.PAUSED -> BydWarningAmber
            ChargingStatus.COMPLETE -> BydSpeedBlue
            ChargingStatus.FAULT -> BydCrimsonRed
            ChargingStatus.DISCONNECTED -> TechMuted
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AutomotiveCard(
                titleEn = "Charging Protocol & Real-Time Power",
                titleZh = "充电协议握手与实时功率曲线",
                language = language,
                badgeText = if (language == Language.ZH) charging.status.zhName else charging.status.enName,
                badgeColor = statusColor,
                modifier = Modifier.weight(1.3f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MetricReadout(
                        labelEn = "Charging Power",
                        labelZh = "输入功率",
                        value = "${"%.1f".format(charging.chargingPowerKw)}",
                        unit = "kW",
                        language = language,
                        accentColor = if (charging.chargingPowerKw > 0) BydEnergyGreen else TechWhite
                    )
                    MetricReadout(
                        labelEn = "Charging Voltage",
                        labelZh = "高压母线电压",
                        value = "${"%.1f".format(charging.chargingVoltageV)}",
                        unit = "V",
                        language = language
                    )
                    MetricReadout(
                        labelEn = "Charging Current",
                        labelZh = "充电电流",
                        value = "${"%.1f".format(charging.chargingCurrentA)}",
                        unit = "A",
                        language = language
                    )
                    MetricReadout(
                        labelEn = "Est. Time Left",
                        labelZh = "预计充满剩余",
                        value = "${charging.estimatedMinutesRemaining}",
                        unit = "min",
                        language = language
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricReadout(
                        labelEn = "Energy Delivered",
                        labelZh = "已充入电量",
                        value = "${"%.2f".format(charging.energyDeliveredKwh)}",
                        unit = "kWh",
                        language = language
                    )
                    MetricReadout(
                        labelEn = "Session Time",
                        labelZh = "本次充电耗时",
                        value = "${charging.sessionSeconds / 60}m ${charging.sessionSeconds % 60}s",
                        unit = "-",
                        language = language
                    )
                    MetricReadout(
                        labelEn = "Charger Standard",
                        labelZh = "充电接口协议",
                        value = if (language == Language.ZH) charging.chargerType.zhName else charging.chargerType.enName,
                        unit = "-",
                        language = language
                    )
                }
            }

            // Target SOC & Simulator Controls
            AutomotiveCard(
                titleEn = "Target SOC Limit & Simulation Actuators",
                titleZh = "目标充电限额与仿真控制指令",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "${viewModel.getString(StringKeys.TARGET_SOC)}: ${charging.targetSocPercent.toInt()}%",
                    color = TechSilver,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = charging.targetSocPercent,
                    onValueChange = { newVal ->
                        viewModel.executeCommand(
                            CommandType.SET_TARGET_SOC,
                            mapOf("targetSoc" to newVal)
                        )
                    },
                    valueRange = 50f..100f,
                    steps = 9,
                    colors = SliderDefaults.colors(
                        thumbColor = BydElectricCyan,
                        activeTrackColor = BydElectricCyan,
                        inactiveTrackColor = CockpitBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.executeCommand(
                                CommandType.SET_CHARGING_STATE,
                                mapOf("action" to if (charging.status == ChargingStatus.CHARGING) "STOP" else "START")
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (charging.status == ChargingStatus.CHARGING) BydCrimsonRed else BydEnergyGreen
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = if (charging.status == ChargingStatus.CHARGING) viewModel.getString(StringKeys.STOP_CHARGING) else viewModel.getString(StringKeys.START_CHARGING),
                            color = CockpitBackground,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (charging.status == ChargingStatus.CHARGING) {
                        Button(
                            onClick = {
                                viewModel.executeCommand(
                                    CommandType.SET_CHARGING_STATE,
                                    mapOf("action" to "PAUSE")
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceElevated),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, CockpitBorder, RoundedCornerShape(6.dp))
                        ) {
                            Text(viewModel.getString(StringKeys.PAUSE_CHARGING), color = TechWhite, fontSize = 12.sp)
                        }
                    } else if (charging.status == ChargingStatus.PAUSED) {
                        Button(
                            onClick = {
                                viewModel.executeCommand(
                                    CommandType.SET_CHARGING_STATE,
                                    mapOf("action" to "RESUME")
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceElevated),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, BydElectricCyan, RoundedCornerShape(6.dp))
                        ) {
                            Text(viewModel.getString(StringKeys.RESUME_CHARGING), color = BydElectricCyan, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
