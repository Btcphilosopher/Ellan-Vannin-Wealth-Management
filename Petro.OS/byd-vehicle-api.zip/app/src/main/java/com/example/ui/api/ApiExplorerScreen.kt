package com.example.ui.api

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api.SignalRegistry
import com.example.domain.models.VehicleState
import com.example.localization.Language
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.QualityBadge
import com.example.ui.components.SafetyClassBadge
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun ApiExplorerScreen(
    state: VehicleState,
    viewModel: VehicleViewModel,
    language: Language,
    selectedSignalId: String,
    searchQuery: String,
    modifier: Modifier = Modifier
) {
    val filteredSignals = SignalRegistry.definitions.filter { def ->
        if (searchQuery.isEmpty()) true
        else def.id.contains(searchQuery, ignoreCase = true) ||
                def.nameEn.contains(searchQuery, ignoreCase = true) ||
                def.nameZh.contains(searchQuery, ignoreCase = true) ||
                def.category.name.contains(searchQuery, ignoreCase = true)
    }

    val activeDef = SignalRegistry.definitions.find { it.id == selectedSignalId } ?: SignalRegistry.definitions.first()
    val activeSignalValue = SignalRegistry.extractSignalValue(activeDef.id, state)
    val jsonPayload = if (activeSignalValue != null) SignalRegistry.generateJsonPayload(activeSignalValue) else "{}"

    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Signal Browser & Search
        AutomotiveCard(
            titleEn = "Vehicle Signal Catalog",
            titleZh = "整车标准信号目录",
            language = language,
            badgeText = "${filteredSignals.size} / ${SignalRegistry.definitions.size} SIGNALS",
            badgeColor = BydElectricCyan,
            modifier = Modifier.weight(1f).fillMaxHeight()
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSignalSearch(it) },
                placeholder = { Text(if (language == Language.ZH) "搜索信号 ID 或名称..." else "Search signal ID or name...", color = TechDarkText, fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TechMuted, modifier = Modifier.size(16.dp)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BydElectricCyan,
                    unfocusedBorderColor = CockpitBorder,
                    focusedTextColor = TechWhite,
                    unfocusedTextColor = TechWhite,
                    cursorColor = BydElectricCyan
                ),
                shape = RoundedCornerShape(6.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Signals List
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(filteredSignals) { def ->
                    val isSelected = def.id == activeDef.id
                    val valueObj = SignalRegistry.extractSignalValue(def.id, state)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = if (isSelected) CockpitSurfaceElevated else CockpitSurfaceDark,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(
                                width = if (isSelected) 1.dp else 0.dp,
                                color = if (isSelected) BydElectricCyan else androidx.compose.ui.graphics.Color.Transparent,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable { viewModel.selectSignal(def.id) }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = def.id,
                                color = if (isSelected) BydElectricCyan else TechWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (language == Language.ZH) def.nameZh else def.nameEn,
                                color = TechMuted,
                                fontSize = 11.sp
                            )
                        }

                        if (valueObj != null) {
                            Text(
                                text = "${valueObj.formattedValue} ${if (valueObj.definition.unit != "-") valueObj.definition.unit else ""}",
                                color = TechSilver,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Right Column: Signal Inspector & JSON Payload
        val rightScroll = rememberScrollState()
        Column(
            modifier = Modifier
                .weight(1.3f)
                .fillMaxHeight()
                .verticalScroll(rightScroll),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Signal Definition Card
            AutomotiveCard(
                titleEn = "Signal Specification",
                titleZh = "信号规格与元数据",
                language = language
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = activeDef.id,
                            color = BydElectricCyan,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            SafetyClassBadge(activeDef.safetyClass)
                            if (activeSignalValue != null) {
                                QualityBadge(activeSignalValue.quality, language)
                            }
                        }
                    }

                    Text(
                        text = if (language == Language.ZH) "${activeDef.nameZh} · ${activeDef.nameEn}" else "${activeDef.nameEn} · ${activeDef.nameZh}",
                        color = TechWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = if (language == Language.ZH) activeDef.descriptionZh else activeDef.descriptionEn,
                        color = TechSilver,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(if (language == Language.ZH) "数据类型" else "Data Type", color = TechMuted, fontSize = 11.sp)
                            Text(activeDef.dataType, color = TechWhite, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text(if (language == Language.ZH) "物理单位" else "Unit", color = TechMuted, fontSize = 11.sp)
                            Text(activeDef.unit, color = TechWhite, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text(if (language == Language.ZH) "刷新周期" else "Cycle Rate", color = TechMuted, fontSize = 11.sp)
                            Text("${activeDef.updateFrequencyMs} ms", color = TechWhite, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                        Column {
                            Text(if (language == Language.ZH) "总线来源" else "Source Bus", color = TechMuted, fontSize = 11.sp)
                            Text(activeDef.source, color = TechWhite, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            // Real-Time JSON Telemetry Feed Card
            AutomotiveCard(
                titleEn = "REST / AIDL Telemetry Payload",
                titleZh = "REST / AIDL 实时遥测数据报文",
                language = language,
                badgeText = "LIVE JSON",
                badgeColor = BydEnergyGreen
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CockpitBackground, RoundedCornerShape(6.dp))
                        .border(1.dp, CockpitBorder, RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = jsonPayload,
                        color = BydElectricCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}
