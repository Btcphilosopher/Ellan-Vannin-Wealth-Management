package com.example.ui.tyres

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.CommandType
import com.example.domain.models.IndividualTyre
import com.example.domain.models.TyreState
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.MetricReadout
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun TyresScreen(
    tyres: TyreState,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // TPMS 4-Wheel Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Front Left
            TyreCard(
                titleEn = "Front Left (FL)",
                titleZh = "左前轮 (FL)",
                tyre = tyres.frontLeft,
                language = language,
                modifier = Modifier.weight(1f)
            )

            // Front Right
            TyreCard(
                titleEn = "Front Right (FR)",
                titleZh = "右前轮 (FR)",
                tyre = tyres.frontRight,
                language = language,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Rear Left
            TyreCard(
                titleEn = "Rear Left (RL)",
                titleZh = "左后轮 (RL)",
                tyre = tyres.rearLeft,
                language = language,
                modifier = Modifier.weight(1f)
            )

            // Rear Right
            TyreCard(
                titleEn = "Rear Right (RR)",
                titleZh = "右后轮 (RR)",
                tyre = tyres.rearRight,
                language = language,
                modifier = Modifier.weight(1f)
            )
        }

        // TPMS Testing & Simulation Card
        AutomotiveCard(
            titleEn = "Tyre Pressure Monitoring System (TPMS) Testing",
            titleZh = "胎压监测系统 (TPMS) 故障模拟测试",
            language = language
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (language == Language.ZH) "左前轮扎钉漏气快速验证" else "Simulate Front Left Tyre Puncture Leak",
                        color = TechWhite,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (language == Language.ZH) "触发 TPMS 欠压报警与仪表盘故障灯标定" else "Triggers TPMS undervoltage alarm and cluster indicator alert",
                        color = TechMuted,
                        fontSize = 11.sp
                    )
                }
                Button(
                    onClick = {
                        val isPunctured = tyres.frontLeft.isPunctured
                        viewModel.executeCommand(
                            CommandType.SIMULATE_TYRE_PUNCTURE,
                            mapOf("puncture" to !isPunctured)
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (tyres.frontLeft.isPunctured) BydEnergyGreen else BydCrimsonRed
                    ),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (tyres.frontLeft.isPunctured)
                            (if (language == Language.ZH) "修复充气 (Restore)" else "Restore Tyre")
                        else
                            (if (language == Language.ZH) "模拟漏气 (Puncture)" else "Trigger Puncture"),
                        color = CockpitBackground,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun TyreCard(
    titleEn: String,
    titleZh: String,
    tyre: IndividualTyre,
    language: Language,
    modifier: Modifier = Modifier
) {
    AutomotiveCard(
        titleEn = titleEn,
        titleZh = titleZh,
        language = language,
        badgeText = if (tyre.isLowPressure) "LOW PRESSURE" else "NOMINAL",
        badgeColor = if (tyre.isLowPressure) BydCrimsonRed else BydEnergyGreen,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            MetricReadout(
                labelEn = "Pressure",
                labelZh = "当前胎压",
                value = "${"%.0f".format(tyre.pressureKpa)}",
                unit = "kPa",
                language = language,
                accentColor = if (tyre.isLowPressure) BydCrimsonRed else TechWhite
            )
            MetricReadout(
                labelEn = "Temperature",
                labelZh = "胎面温度",
                value = "${"%.1f".format(tyre.temperatureC)}",
                unit = "°C",
                language = language
            )
        }
    }
}
