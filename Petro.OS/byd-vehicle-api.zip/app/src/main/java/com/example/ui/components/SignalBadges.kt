package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.DataQuality
import com.example.domain.models.SafetyClassification
import com.example.localization.Language
import com.example.ui.theme.*

@Composable
fun QualityBadge(quality: DataQuality, language: Language, modifier: Modifier = Modifier) {
    val (bgColor, textColor) = when (quality) {
        DataQuality.VALID -> Pair(QualityValid.copy(alpha = 0.15f), QualityValid)
        DataQuality.STALE -> Pair(QualityStale.copy(alpha = 0.15f), QualityStale)
        DataQuality.INVALID -> Pair(QualityInvalid.copy(alpha = 0.15f), QualityInvalid)
        DataQuality.UNAVAILABLE -> Pair(QualityUnavailable.copy(alpha = 0.15f), QualityUnavailable)
    }

    val label = if (language == Language.ZH) quality.zhName else quality.enName

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(4.dp))
            .border(1.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun SafetyClassBadge(safetyClass: SafetyClassification, modifier: Modifier = Modifier) {
    val (bgColor, textColor) = when (safetyClass) {
        SafetyClassification.ASIL_D -> Pair(BydCrimsonRed.copy(alpha = 0.2f), BydCrimsonRed)
        SafetyClassification.ASIL_C -> Pair(BydWarningAmber.copy(alpha = 0.2f), BydWarningAmber)
        SafetyClassification.ASIL_B -> Pair(BydElectricCyan.copy(alpha = 0.2f), BydElectricCyan)
        SafetyClassification.ASIL_A -> Pair(BydEnergyGreen.copy(alpha = 0.2f), BydEnergyGreen)
        SafetyClassification.QM -> Pair(TechMuted.copy(alpha = 0.15f), TechSilver)
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(4.dp))
            .border(1.dp, textColor.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = safetyClass.code,
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun MetricReadout(
    labelEn: String,
    labelZh: String,
    value: String,
    unit: String,
    language: Language,
    modifier: Modifier = Modifier,
    accentColor: Color = TechWhite
) {
    Column(modifier = modifier) {
        Text(
            text = if (language == Language.ZH) "$labelZh $labelEn" else "$labelEn · $labelZh",
            color = TechMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = value,
                color = accentColor,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif
            )
            if (unit.isNotEmpty() && unit != "-") {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = unit,
                    color = TechMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(bottom = 3.dp)
                )
            }
        }
    }
}
