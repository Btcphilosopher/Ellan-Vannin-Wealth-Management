package com.example.domain.models

enum class SafetyCapability {
    CAN_READ,
    CAN_WRITE_SIMULATION,
    REQUIRES_AUTH,
    REQUIRES_STATIONARY,
    REQUIRES_OEM_PERMISSION,
    PROHIBITED_IN_MOTION
}

enum class CommandType(val enName: String, val zhName: String, val requiredCapability: SafetyCapability) {
    SET_CHARGING_STATE("Set Charging State", "控制充电启停", SafetyCapability.REQUIRES_STATIONARY),
    SET_TARGET_SOC("Set Target SOC Limit", "设定充电上限", SafetyCapability.CAN_WRITE_SIMULATION),
    SET_CLIMATE_TARGET("Set Target Climate Temp", "设定空调温度", SafetyCapability.CAN_WRITE_SIMULATION),
    SET_CLIMATE_FAN("Set HVAC Fan Speed", "设定空调风量", SafetyCapability.CAN_WRITE_SIMULATION),
    SET_CLIMATE_POWER("Toggle Climate Power", "开关空调系统", SafetyCapability.CAN_WRITE_SIMULATION),
    SET_DRIVE_MODE("Select Drive Mode", "切换驾驶模式", SafetyCapability.CAN_WRITE_SIMULATION),
    SET_DOOR_LOCK("Toggle Door Lock", "控制车门闭锁", SafetyCapability.REQUIRES_STATIONARY),
    SIMULATE_TYRE_PUNCTURE("Simulate Tyre Puncture", "模拟轮胎漏气", SafetyCapability.CAN_WRITE_SIMULATION),
    CLEAR_DTC_CODES("Clear Diagnostic Codes", "清除整车故障码", SafetyCapability.REQUIRES_AUTH)
}

data class VehicleCommand(
    val id: String = java.util.UUID.randomUUID().toString(),
    val commandType: CommandType,
    val payload: Map<String, Any>,
    val targetModule: String,
    val origin: String = "DEVELOPER_UI",
    val timestamp: Long = System.currentTimeMillis()
)

data class SafetyPolicyResult(
    val isApproved: Boolean,
    val reasonEn: String,
    val reasonZh: String,
    val safetyLevel: SafetyClassification = SafetyClassification.QM
)
