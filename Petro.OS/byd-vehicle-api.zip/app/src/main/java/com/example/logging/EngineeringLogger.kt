package com.example.logging

import com.example.domain.models.LogEntry
import com.example.domain.models.LogLevel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

object EngineeringLogger {
    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private const val MAX_LOGS = 250

    fun log(level: LogLevel, module: String, event: String, payload: String = "") {
        val entry = LogEntry(
            timestamp = timeFormat.format(Date()),
            level = level,
            module = module,
            event = event,
            payload = payload
        )
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        if (current.size > MAX_LOGS) {
            _logs.value = current.take(MAX_LOGS)
        } else {
            _logs.value = current
        }
    }

    fun i(module: String, event: String, payload: String = "") = log(LogLevel.INFO, module, event, payload)
    fun d(module: String, event: String, payload: String = "") = log(LogLevel.DEBUG, module, event, payload)
    fun w(module: String, event: String, payload: String = "") = log(LogLevel.WARNING, module, event, payload)
    fun e(module: String, event: String, payload: String = "") = log(LogLevel.ERROR, module, event, payload)

    fun clear() {
        _logs.value = emptyList()
    }
}
