package com.example.api

import com.example.domain.models.EventType
import com.example.domain.models.VehicleEvent
import com.example.logging.EngineeringLogger
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object EventBus {
    private val _events = MutableSharedFlow<VehicleEvent>(replay = 50)
    val events: SharedFlow<VehicleEvent> = _events.asSharedFlow()

    suspend fun emit(event: VehicleEvent) {
        _events.emit(event)
        EngineeringLogger.i(
            module = event.source,
            event = "[EVENT] ${event.type.name}",
            payload = "${event.summaryEn} / ${event.summaryZh}: ${event.detail}"
        )
    }

    suspend fun emit(
        type: EventType,
        summaryEn: String,
        summaryZh: String,
        detail: String,
        source: String
    ) {
        val event = VehicleEvent(
            type = type,
            summaryEn = summaryEn,
            summaryZh = summaryZh,
            detail = detail,
            source = source
        )
        emit(event)
    }
}
