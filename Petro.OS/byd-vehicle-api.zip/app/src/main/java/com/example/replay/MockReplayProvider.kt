package com.example.replay

import com.example.api.EventBus
import com.example.api.SignalRegistry
import com.example.api.VehicleDataProvider
import com.example.domain.models.*
import com.example.logging.EngineeringLogger
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class MockReplayProvider(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) : VehicleDataProvider {

    override val providerId: String = "REPLAY_LOG_STREAM"
    override val providerNameEn: String = "Deterministic Telemetry Replay Engine"
    override val providerNameZh: String = "高精度车载历史遥测回放引擎"

    private val _isConnected = MutableStateFlow(true)
    private val _vehicleState = MutableStateFlow(VehicleState())
    private var replayJob: Job? = null

    var currentSession: ReplaySession = SessionArchive.SHANGHAI_HIGHWAY
    var currentCursorIndex: Int = 0
    var isPlaying: Boolean = false

    init {
        loadSnapshot(0)
    }

    fun selectSession(session: ReplaySession) {
        currentSession = session
        currentCursorIndex = 0
        loadSnapshot(0)
        EngineeringLogger.i("REPLAY", "Selected session: ${session.titleEn}", "Duration: ${session.durationSeconds}s")
    }

    fun play() {
        if (isPlaying) return
        isPlaying = true
        replayJob?.cancel()
        replayJob = scope.launch {
            while (isActive && isPlaying) {
                if (currentCursorIndex >= currentSession.snapshots.size - 1) {
                    currentCursorIndex = 0 // loop or pause
                } else {
                    currentCursorIndex++
                }
                loadSnapshot(currentCursorIndex)
                delay(1000L)
            }
        }
    }

    fun pause() {
        isPlaying = false
        replayJob?.cancel()
    }

    fun seek(index: Int) {
        currentCursorIndex = index.coerceIn(0, currentSession.snapshots.size - 1)
        loadSnapshot(currentCursorIndex)
    }

    fun step() {
        if (currentCursorIndex < currentSession.snapshots.size - 1) {
            currentCursorIndex++
            loadSnapshot(currentCursorIndex)
        }
    }

    fun restart() {
        currentCursorIndex = 0
        loadSnapshot(0)
    }

    private fun loadSnapshot(index: Int) {
        if (index !in currentSession.snapshots.indices) return
        val snap = currentSession.snapshots[index]
        val current = _vehicleState.value

        val isRegen = snap.batteryPowerKw < 0f
        val gear = if (snap.speedKmH > 0.5f) GearState.D else GearState.P

        _vehicleState.value = current.copy(
            speedKmH = snap.speedKmH,
            gear = gear,
            acceleratorPositionPercent = snap.acceleratorPercent,
            brakePedalPercent = snap.brakePercent,
            battery = current.battery.copy(
                socPercent = snap.socPercent,
                voltageV = snap.batteryVoltageV,
                currentA = snap.batteryCurrentA,
                powerKw = snap.batteryPowerKw,
                remainingEnergyKwh = (snap.socPercent / 100f) * 82.5f,
                estimatedRangeKm = (snap.socPercent / 100f) * 520f,
                powerFlow = if (isRegen) PowerFlowState.REGENERATING else if (snap.batteryPowerKw > 0.5f) PowerFlowState.DISCHARGING else PowerFlowState.IDLE
            ),
            powertrain = current.powertrain.copy(
                motorRpm = snap.motorRpm,
                motorTorqueNm = snap.motorTorqueNm,
                motorPowerKw = kotlin.math.abs(snap.batteryPowerKw),
                isRegenerating = isRegen
            ),
            cabin = current.cabin.copy(
                cabinTempC = snap.cabinTempC,
                outsideTempC = snap.outsideTempC
            ),
            timestamp = System.currentTimeMillis()
        )
    }

    override fun isConnected(): Boolean = _isConnected.value
    override suspend fun connect(): Boolean {
        _isConnected.value = true
        return true
    }
    override suspend fun disconnect() {
        _isConnected.value = false
        pause()
    }
    override fun observeVehicleState(): StateFlow<VehicleState> = _vehicleState.asStateFlow()
    override fun observeSignals(): Flow<List<VehicleSignalValue>> {
        return _vehicleState.map { state ->
            SignalRegistry.definitions.mapNotNull { def ->
                SignalRegistry.extractSignalValue(def.id, state)
            }
        }
    }
    override fun getSignal(id: String): VehicleSignalValue? = SignalRegistry.extractSignalValue(id, _vehicleState.value)
    override suspend fun executeCommand(command: VehicleCommand): SafetyPolicyResult {
        return SafetyPolicyResult(
            isApproved = false,
            reasonEn = "Commands disabled in Replay Mode. Switch to Simulation Engine to execute controls.",
            reasonZh = "回放模式下已禁用控制指令。请切换至仿真动力学引擎以执行调节。",
            safetyLevel = SafetyClassification.QM
        )
    }
}
