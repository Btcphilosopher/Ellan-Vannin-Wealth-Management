package com.example.ui.logging

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.LogLevel
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.logging.EngineeringLogger
import com.example.ui.components.AutomotiveCard
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun LoggingScreen(
    viewModel: VehicleViewModel,
    language: Language,
    activeFilter: LogLevel?,
    modifier: Modifier = Modifier
) {
    val allLogs by EngineeringLogger.logs.collectAsState()

    val filteredLogs = allLogs.filter { entry ->
        if (activeFilter == null) true else entry.level == activeFilter
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Filter Bar & Clear Actions
        AutomotiveCard(
            titleEn = "Bus Event Stream & Security Audit Filter",
            titleZh = "整车总线事件流与安全审计过滤",
            language = language
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Filter Chips
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val levels = listOf(null, LogLevel.INFO, LogLevel.DEBUG, LogLevel.WARNING, LogLevel.ERROR)
                    levels.forEach { lvl ->
                        val isSel = activeFilter == lvl
                        val label = lvl?.name ?: if (language == Language.ZH) "全部 (ALL)" else "ALL"
                        val chipColor = when (lvl) {
                            LogLevel.ERROR -> BydCrimsonRed
                            LogLevel.WARNING -> BydWarningAmber
                            LogLevel.INFO -> BydElectricCyan
                            LogLevel.DEBUG -> TechSilver
                            null -> TechWhite
                        }

                        Box(
                            modifier = Modifier
                                .background(if (isSel) chipColor.copy(alpha = 0.2f) else CockpitSurfaceDark, RoundedCornerShape(4.dp))
                                .border(1.dp, if (isSel) chipColor else CockpitBorder, RoundedCornerShape(4.dp))
                                .clickable { viewModel.setLogFilter(lvl) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = label,
                                color = if (isSel) chipColor else TechMuted,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Clear Button
                Button(
                    onClick = { EngineeringLogger.clear() },
                    colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceElevated),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.border(1.dp, CockpitBorder, RoundedCornerShape(6.dp))
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Clear", tint = TechSilver, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (language == Language.ZH) "清空日志" else "Clear Stream",
                        color = TechWhite,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Live Log Terminal View
        AutomotiveCard(
            titleEn = "Live CAN / Ethernet & Diagnostic Frame Log",
            titleZh = "实时 CAN/以太网总线及诊断帧事件日志",
            language = language,
            badgeText = "${filteredLogs.size} ENTRIES",
            badgeColor = BydElectricCyan,
            modifier = Modifier.weight(1f)
        ) {
            if (filteredLogs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (language == Language.ZH) "暂无匹配的总线事件日志" else "No matching bus log entries recorded.",
                        color = TechMuted,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filteredLogs) { entry ->
                        val color = when (entry.level) {
                            LogLevel.ERROR -> BydCrimsonRed
                            LogLevel.WARNING -> BydWarningAmber
                            LogLevel.INFO -> BydElectricCyan
                            LogLevel.DEBUG -> TechSilver
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CockpitBackground, RoundedCornerShape(3.dp))
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = entry.timestamp,
                                color = TechDarkText,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .background(color.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = entry.level.name,
                                    color = color,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "[${entry.module}]",
                                color = TechMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = entry.event,
                                color = TechWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (entry.payload.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = entry.payload,
                                    color = TechSilver,
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
