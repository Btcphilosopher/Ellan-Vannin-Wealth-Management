package com.example.ui.body

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.BodyState
import com.example.domain.models.CommandType
import com.example.domain.models.DoorState
import com.example.domain.models.LockState
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.MetricReadout
import com.example.ui.components.VehicleTopDownDiagram
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun BodyScreen(
    body: BodyState,
    vehicleState: com.example.domain.models.VehicleState,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left: Top-Down Diagram
            AutomotiveCard(
                titleEn = "Access Closures & Door State Topology",
                titleZh = "车门闭锁与开闭状态拓扑",
                language = language,
                badgeText = if (body.centralLock == LockState.LOCKED) "LOCKED" else "UNLOCKED",
                badgeColor = if (body.centralLock == LockState.LOCKED) BydEnergyGreen else BydWarningAmber,
                modifier = Modifier.weight(1f)
            ) {
                VehicleTopDownDiagram(
                    state = vehicleState,
                    language = language
                )
            }

            // Right: Detailed Status & Lock Control
            AutomotiveCard(
                titleEn = "Body Control Module (BCM) Status",
                titleZh = "车身控制模块 (BCM) 状态与闭锁",
                language = language,
                modifier = Modifier.weight(1.2f)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricReadout("Front Left Door", "左前门", body.doorFrontLeft.enName, "-", language,
                            accentColor = if (body.doorFrontLeft == DoorState.OPEN) BydCrimsonRed else BydEnergyGreen)
                        MetricReadout("Front Right Door", "右前门", body.doorFrontRight.enName, "-", language,
                            accentColor = if (body.doorFrontRight == DoorState.OPEN) BydCrimsonRed else BydEnergyGreen)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricReadout("Rear Left Door", "左后门", body.doorRearLeft.enName, "-", language,
                            accentColor = if (body.doorRearLeft == DoorState.OPEN) BydCrimsonRed else BydEnergyGreen)
                        MetricReadout("Rear Right Door", "右后门", body.doorRearRight.enName, "-", language,
                            accentColor = if (body.doorRearRight == DoorState.OPEN) BydCrimsonRed else BydEnergyGreen)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MetricReadout("Power Tailgate", "电动尾门", body.trunk.enName, "-", language,
                            accentColor = if (body.trunk == DoorState.OPEN) BydCrimsonRed else BydEnergyGreen)
                        MetricReadout("Front Hood (Frunk)", "前机舱盖", body.hood.enName, "-", language,
                            accentColor = if (body.hood == DoorState.OPEN) BydCrimsonRed else BydEnergyGreen)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            viewModel.executeCommand(CommandType.SET_DOOR_LOCK)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (body.centralLock == LockState.LOCKED) CockpitSurfaceElevated else BydElectricCyan
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .border(1.dp, BydElectricCyan, RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            text = if (body.centralLock == LockState.LOCKED)
                                (if (language == Language.ZH) "解锁中控门锁 (Unlock)" else "Unlock Central Doors")
                            else
                                (if (language == Language.ZH) "上锁中控门锁 (Lock)" else "Lock Central Doors"),
                            color = if (body.centralLock == LockState.LOCKED) TechWhite else CockpitBackground,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
