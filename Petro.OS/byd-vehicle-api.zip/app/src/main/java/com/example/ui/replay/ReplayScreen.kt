package com.example.ui.replay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.VehicleState
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.replay.SessionArchive
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.MetricReadout
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun ReplayScreen(
    state: VehicleState,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    val replayProvider = viewModel.replayProvider
    val session = replayProvider.currentSession
    val cursor = replayProvider.currentCursorIndex
    val isPlaying = replayProvider.isPlaying
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Session Picker
        AutomotiveCard(
            titleEn = "Recorded Vehicle Drive Session Archive",
            titleZh = "实车行驶历史遥测数据记录档案",
            language = language,
            badgeText = "DILINK TELEMETRY LOGS",
            badgeColor = BydElectricCyan
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SessionArchive.allSessions.forEach { sess ->
                    val isSel = sess.id == session.id
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSel) CockpitSurfaceElevated else CockpitSurfaceDark, RoundedCornerShape(6.dp))
                            .border(1.dp, if (isSel) BydElectricCyan else CockpitBorder, RoundedCornerShape(6.dp))
                            .clickable {
                                viewModel.setProvider("REPLAY")
                                viewModel.replaySelectSession(sess)
                            }
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = if (language == Language.ZH) sess.titleZh else sess.titleEn,
                                color = if (isSel) BydElectricCyan else TechWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${sess.date} · ${sess.durationSeconds}s · ${"%.1f".format(sess.distanceKm)} km · Avg ${"%.0f".format(sess.avgSpeedKmH)} km/h",
                                color = TechMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Playback Timeline & VCR Controls
        AutomotiveCard(
            titleEn = "Synchronized Frame Player & Scrubber",
            titleZh = "时间轴同步逐帧回放控制器",
            language = language,
            badgeText = "${cursor + 1} / ${session.snapshots.size} FRAMES",
            badgeColor = BydEnergyGreen
        ) {
            // Scrubber Slider
            Slider(
                value = cursor.toFloat(),
                onValueChange = { viewModel.replaySeek(it.toInt()) },
                valueRange = 0f..(session.snapshots.size - 1).coerceAtLeast(1).toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = BydElectricCyan,
                    activeTrackColor = BydElectricCyan,
                    inactiveTrackColor = CockpitBorder
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "T + ${cursor}s",
                    color = TechWhite,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                // VCR Control Buttons
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(onClick = { viewModel.replayRestart() }) {
                        Icon(Icons.Default.Replay, contentDescription = "Restart", tint = TechSilver)
                    }
                    IconButton(
                        onClick = {
                            if (isPlaying) viewModel.replayPause() else viewModel.replayPlay()
                        }
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = BydElectricCyan
                        )
                    }
                    IconButton(onClick = { viewModel.replayStep() }) {
                        Icon(Icons.Default.SkipNext, contentDescription = "Step Forward", tint = TechSilver)
                    }
                }

                Text(
                    text = "Total ${session.durationSeconds}s",
                    color = TechMuted,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Live Replay Frame Telemetry Snapshot
        AutomotiveCard(
            titleEn = "Telemetry Readouts at Current Replay Cursor",
            titleZh = "当前回放时刻车辆物理量采样快照",
            language = language
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                MetricReadout("Playback Speed", "回放车速", "${"%.1f".format(state.speedKmH)}", "km/h", language,
                    accentColor = BydSpeedBlue)
                MetricReadout("Motor RPM", "电机转速", "${"%.0f".format(state.powertrain.motorRpm)}", "rpm", language)
                MetricReadout("Battery Power", "电池功率", "${"%.2f".format(state.battery.powerKw)}", "kW", language,
                    accentColor = if (state.battery.powerKw < 0) BydEnergyGreen else BydElectricCyan)
                MetricReadout("Battery SOC", "剩余电量", "${"%.1f".format(state.battery.socPercent)}", "%", language,
                    accentColor = BydEnergyGreen)
            }
        }
    }
}
