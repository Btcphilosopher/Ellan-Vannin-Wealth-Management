package com.example.api

import com.example.domain.models.SafetyPolicyResult
import com.example.domain.models.VehicleCommand
import com.example.domain.models.VehicleSignalValue
import com.example.domain.models.VehicleState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface VehicleDataProvider {
    val providerId: String
    val providerNameEn: String
    val providerNameZh: String

    fun isConnected(): Boolean
    suspend fun connect(): Boolean
    suspend fun disconnect()

    fun observeVehicleState(): StateFlow<VehicleState>
    fun observeSignals(): Flow<List<VehicleSignalValue>>
    fun getSignal(id: String): VehicleSignalValue?

    suspend fun executeCommand(command: VehicleCommand): SafetyPolicyResult
}
