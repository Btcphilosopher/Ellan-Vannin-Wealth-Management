package com.example.ui.telemetry

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.telemetry.TelemetryDataPoint
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.TelemetryMultiLineChart
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun TelemetryGraphScreen(
    telemetryHistory: List<TelemetryDataPoint>,
    isPaused: Boolean,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    var showSpeed by remember { mutableStateOf(true) }
    var showPower by remember { mutableStateOf(true) }
    var showSoc by remember { mutableStateOf(true) }
    var showRpm by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Controls and Channel Toggles
        AutomotiveCard(
            titleEn = "Live Oscilloscope Channels & Stream Control",
            titleZh = "实时多通道示波器与数据流控制",
            language = language
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Channel Checkboxes
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ChannelToggleChip(
                        label = if (language == Language.ZH) "车速 (Speed)" else "Speed (km/h)",
                        color = BydSpeedBlue,
                        isActive = showSpeed,
                        onToggle = { showSpeed = !showSpeed }
                    )
                    ChannelToggleChip(
                        label = if (language == Language.ZH) "功率 (Power)" else "Power (kW)",
                        color = BydElectricCyan,
                        isActive = showPower,
                        onToggle = { showPower = !showPower }
                    )
                    ChannelToggleChip(
                        label = if (language == Language.ZH) "电量 (SOC)" else "SOC (%)",
                        color = BydEnergyGreen,
                        isActive = showSoc,
                        onToggle = { showSoc = !showSoc }
                    )
                    ChannelToggleChip(
                        label = if (language == Language.ZH) "转速 (RPM)" else "Motor RPM",
                        color = BydCrimsonRed,
                        isActive = showRpm,
                        onToggle = { showRpm = !showRpm }
                    )
                }

                // Actions: Pause / Export
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.toggleTelemetryChartPause() },
                        colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceElevated),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.border(1.dp, CockpitBorder, RoundedCornerShape(6.dp))
                    ) {
                        Icon(
                            imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = "Pause",
                            tint = if (isPaused) BydEnergyGreen else BydWarningAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isPaused) (if (language == Language.ZH) "继续采集" else "Resume") else (if (language == Language.ZH) "暂停画面" else "Pause"),
                            color = TechWhite,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Main Oscilloscope Canvas
        AutomotiveCard(
            titleEn = "Telemetry Waveform Stream (Rolling 60s Window)",
            titleZh = "实时遥测波形流 (滑动 60 秒时间窗口)",
            language = language,
            badgeText = "${telemetryHistory.size} SAMPLES",
            badgeColor = BydElectricCyan
        ) {
            TelemetryMultiLineChart(
                history = telemetryHistory,
                showSpeed = showSpeed,
                showPower = showPower,
                showSoc = showSoc,
                showRpm = showRpm,
                modifier = Modifier.fillMaxWidth().height(260.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (language == Language.ZH) "T-60s" else "-60s",
                    color = TechMuted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = if (language == Language.ZH) "实时 T-0 (10Hz 采样率)" else "LIVE T-0 (100ms / 10Hz)",
                    color = BydEnergyGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun ChannelToggleChip(
    label: String,
    color: Color,
    isActive: Boolean,
    onToggle: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(if (isActive) color.copy(alpha = 0.15f) else CockpitSurfaceDark, RoundedCornerShape(4.dp))
            .border(1.dp, if (isActive) color else CockpitBorder, RoundedCornerShape(4.dp))
            .clickable { onToggle() }
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(if (isActive) color else TechDarkText, RoundedCornerShape(4.dp))
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = if (isActive) TechWhite else TechMuted,
                fontSize = 11.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
