package com.example.simulator

import com.example.domain.models.*
import kotlin.math.*

object PhysicsEngine {
    const val GEAR_RATIO = 10.5f
    const val WHEEL_RADIUS_M = 0.34f // 235/45 R19
    const val VEHICLE_MASS_KG = 2150f
    const val TOTAL_BATTERY_CAPACITY_KWH = 82.5f
    const val NOMINAL_PACK_VOLTAGE_V = 352.0f

    /**
     * Compute speed-to-RPM translation
     */
    fun calculateMotorRpm(speedKmH: Float): Float {
        if (speedKmH <= 0.1f) return 0f
        val speedMps = speedKmH / 3.6f
        val wheelAngularVelocity = speedMps / WHEEL_RADIUS_M
        val motorAngularVelocity = wheelAngularVelocity * GEAR_RATIO
        return (motorAngularVelocity * 60f / (2f * Math.PI.toFloat())).coerceIn(0f, 16000f)
    }

    /**
     * Compute aerodynamic + rolling resistance drag power requirement (in kW)
     */
    fun calculateTractionPower(speedKmH: Float, accelMps2: Float): Float {
        if (speedKmH <= 0.1f && accelMps2 <= 0f) return 0f
        val speedMps = (speedKmH / 3.6f).coerceAtLeast(0f)
        
        // Aerodynamic drag: 0.5 * rho * Cd * A * v^3 (Cd = 0.219 for BYD SEAL, A = 2.29 m^2)
        val aeroPowerKw = (0.5f * 1.225f * 0.219f * 2.29f * speedMps.pow(3)) / 1000f

        // Rolling resistance: Crr * m * g * v (Crr = 0.010)
        val rollingPowerKw = (0.010f * VEHICLE_MASS_KG * 9.81f * speedMps) / 1000f

        // Acceleration force power: m * a * v
        val accelPowerKw = if (accelMps2 > 0f) {
            (VEHICLE_MASS_KG * accelMps2 * speedMps) / 1000f
        } else if (accelMps2 < 0f) {
            // Regen recovery (efficiency ~75%)
            (VEHICLE_MASS_KG * accelMps2 * speedMps * 0.75f) / 1000f
        } else 0f

        return (aeroPowerKw + rollingPowerKw + accelPowerKw).coerceIn(-75f, 390f)
    }

    /**
     * Determine battery pack voltage as a function of SOC and loaded current
     */
    fun calculatePackVoltage(socPercent: Float, currentA: Float): Float {
        // OCV curve for LFP (Blade Battery) with flat middle plateau
        val ocv = when {
            socPercent >= 98f -> 385f
            socPercent >= 90f -> 365f + (socPercent - 90f) * 2.5f
            socPercent >= 20f -> 345f + (socPercent - 20f) * 0.28f
            socPercent >= 10f -> 330f + (socPercent - 10f) * 1.5f
            else -> 310f + (socPercent * 2.0f)
        }
        // Internal resistance drop: V = OCV - I * R_int (R_int approx 0.055 ohm)
        val internalResistance = 0.055f
        return (ocv - (currentA * internalResistance)).coerceIn(300f, 400f)
    }

    /**
     * Compute motor torque (Nm) from power (kW) and RPM
     */
    fun calculateTorque(powerKw: Float, rpm: Float): Float {
        if (rpm < 50f) {
            return (powerKw.coerceAtLeast(0f) * 25f).coerceIn(-350f, 670f)
        }
        val torque = (powerKw * 9549f) / rpm
        return torque.coerceIn(-350f, 670f)
    }

    /**
     * Compute DC Fast charging curve based on SOC
     */
    fun calculateChargingPower(socPercent: Float, maxChargerPowerKw: Float, packTempC: Float): Float {
        var baseRate = when {
            socPercent < 10f -> 85f
            socPercent < 55f -> 150f
            socPercent < 75f -> 110f
            socPercent < 85f -> 65f
            socPercent < 95f -> 35f
            else -> 12f
        }
        // Cold or hot throttling
        if (packTempC < 10f) baseRate *= 0.65f
        if (packTempC > 45f) baseRate *= 0.70f

        return min(baseRate, maxChargerPowerKw).coerceAtLeast(0f)
    }

    /**
     * Step simulation forward by dtSeconds
     */
    fun step(
        currentState: VehicleState,
        targetSpeedKmH: Float,
        dtSeconds: Float,
        hvacAuxKw: Float,
        scenarioCharging: Boolean,
        maxChargingPowerKw: Float
    ): VehicleState {
        var speed = currentState.speedKmH
        var accel = 0f

        if (scenarioCharging || currentState.charging.status == ChargingStatus.CHARGING) {
            speed = 0f
            accel = 0f
        } else {
            // Smooth speed change toward targetSpeedKmH
            val speedDiff = targetSpeedKmH - speed
            if (abs(speedDiff) > 0.2f) {
                val maxAcc = if (currentState.driveMode == DriveMode.SPORT) 3.5f else 1.8f
                val maxDec = 4.0f
                val deltaV = speedDiff.coerceIn(-maxDec * 3.6f * dtSeconds, maxAcc * 3.6f * dtSeconds)
                speed = (speed + deltaV).coerceAtLeast(0f)
                accel = (deltaV / 3.6f) / dtSeconds
            } else {
                speed = targetSpeedKmH
                accel = 0f
            }
        }

        // Distance covered
        val distanceKm = (speed * dtSeconds / 3600f).toDouble()
        val newOdo = currentState.odometerKm + distanceKm

        // Gear selection logic
        val gear = when {
            scenarioCharging || currentState.charging.status == ChargingStatus.CHARGING -> GearState.P
            speed > 0.5f -> GearState.D
            targetSpeedKmH < 0f -> GearState.R
            else -> currentState.gear
        }

        // Motor dynamics
        val motorRpm = calculateMotorRpm(speed)
        val tractionKw = if (gear == GearState.P || gear == GearState.N) 0f else calculateTractionPower(speed, accel)
        val motorTorque = calculateTorque(tractionKw, motorRpm)
        val isRegen = tractionKw < -0.5f

        // Powertrain state
        val newPowertrain = currentState.powertrain.copy(
            motorRpm = motorRpm,
            motorTorqueNm = motorTorque,
            motorPowerKw = abs(tractionKw),
            isRegenerating = isRegen,
            motorTempC = (currentState.powertrain.motorTempC + (abs(tractionKw) * 0.003f - 0.001f * (currentState.powertrain.motorTempC - currentState.cabin.outsideTempC)) * dtSeconds).coerceIn(20f, 110f),
            inverterTempC = (currentState.powertrain.inverterTempC + (abs(tractionKw) * 0.002f - 0.001f * (currentState.powertrain.inverterTempC - currentState.cabin.outsideTempC)) * dtSeconds).coerceIn(20f, 95f),
            efficiencyPercent = if (speed > 10f) (92f + min(4f, (speed / 30f))).coerceIn(85f, 96.5f) else 90.0f
        )

        // Electrical & Battery calculation
        var batteryPowerKw: Float
        var currentA: Float
        var soc = currentState.battery.socPercent
        var chargingState = currentState.charging

        if (scenarioCharging || currentState.charging.status == ChargingStatus.CHARGING) {
            val chargeKw = calculateChargingPower(soc, maxChargingPowerKw, currentState.battery.packTemperatureC)
            batteryPowerKw = -chargeKw
            val packVoltage = calculatePackVoltage(soc, -chargeKw * 1000f / NOMINAL_PACK_VOLTAGE_V)
            currentA = -(chargeKw * 1000f) / packVoltage

            // Increase SOC
            val energyInKwh = (chargeKw * dtSeconds) / 3600f
            soc = (soc + (energyInKwh / TOTAL_BATTERY_CAPACITY_KWH) * 100f).coerceIn(0f, 100f)

            val newEnergyDelivered = chargingState.energyDeliveredKwh + energyInKwh
            val newSessionSeconds = chargingState.sessionSeconds + dtSeconds.toLong()
            val remainingKwh = max(0f, ((chargingState.targetSocPercent - soc) / 100f) * TOTAL_BATTERY_CAPACITY_KWH)
            val minutesRemaining = if (chargeKw > 1f) ((remainingKwh / chargeKw) * 60f).roundToInt() else 0

            val status = if (soc >= chargingState.targetSocPercent) ChargingStatus.COMPLETE else ChargingStatus.CHARGING

            chargingState = chargingState.copy(
                status = status,
                chargingPowerKw = chargeKw,
                chargingVoltageV = packVoltage + 2.5f,
                chargingCurrentA = abs(currentA),
                estimatedMinutesRemaining = minutesRemaining,
                energyDeliveredKwh = newEnergyDelivered,
                sessionSeconds = newSessionSeconds
            )
        } else {
            // Net electrical load = traction + HVAC + 0.35kW base 12V/accessories
            val netKw = tractionKw + hvacAuxKw + 0.35f
            batteryPowerKw = netKw
            val packVoltage = calculatePackVoltage(soc, netKw * 1000f / NOMINAL_PACK_VOLTAGE_V)
            currentA = (netKw * 1000f) / packVoltage

            // Decrease/Increase SOC
            val energyDeltaKwh = (netKw * dtSeconds) / 3600f
            soc = (soc - (energyDeltaKwh / TOTAL_BATTERY_CAPACITY_KWH) * 100f).coerceIn(0f, 100f)

            if (chargingState.status == ChargingStatus.CHARGING) {
                chargingState = chargingState.copy(
                    status = ChargingStatus.DISCONNECTED,
                    chargingPowerKw = 0f,
                    chargingVoltageV = 0f,
                    chargingCurrentA = 0f
                )
            }
        }

        val packVoltage = calculatePackVoltage(soc, currentA)
        val remainingEnergyKwh = (soc / 100f) * TOTAL_BATTERY_CAPACITY_KWH
        val estRangeKm = (remainingEnergyKwh / 0.155f).coerceIn(0f, 650f) // ~15.5 kWh/100km

        // Thermal simulation for cabin
        val targetCabin = currentState.cabin.targetTempC
        val outsideTemp = currentState.cabin.outsideTempC
        val cabinDiff = targetCabin - currentState.cabin.cabinTempC
        val thermalRate = (cabinDiff * 0.05f * (currentState.cabin.fanSpeed / 4f)).coerceIn(-0.1f, 0.1f)
        val newCabinTemp = currentState.cabin.cabinTempC + (thermalRate * dtSeconds)

        // Pack temp dynamics
        val packTempDelta = ((abs(currentA) * 0.0015f - 0.0005f * (currentState.battery.packTemperatureC - 25f)) * dtSeconds)
        val newPackTemp = (currentState.battery.packTemperatureC + packTempDelta).coerceIn(-20f, 55f)

        // Tyres temperature and pressure response (Gay-Lussac law: P proportional to T)
        val tyreHeating = if (speed > 10f) (speed / 120f) * 0.02f * dtSeconds else -0.01f * dtSeconds
        fun updateTyre(t: IndividualTyre): IndividualTyre {
            val newT = (t.temperatureC + tyreHeating).coerceIn(15f, 60f)
            val baseP = if (t.isPunctured) max(110f, t.pressureKpa - (1.2f * dtSeconds)) else (248f + (newT - 25f) * 1.1f)
            return t.copy(
                temperatureC = newT,
                pressureKpa = baseP,
                isLowPressure = baseP < 200f
            )
        }

        val newTyres = TyreState(
            frontLeft = updateTyre(currentState.tyres.frontLeft),
            frontRight = updateTyre(currentState.tyres.frontRight),
            rearLeft = updateTyre(currentState.tyres.rearLeft),
            rearRight = updateTyre(currentState.tyres.rearRight)
        )

        // Pedals
        val accelPercent = if (accel > 0f) (accel / 3.0f * 100f).coerceIn(0f, 100f) else if (speed > 5f && targetSpeedKmH > 0f) 18f else 0f
        val brakePercent = if (accel < -0.1f) (abs(accel) / 4.0f * 100f).coerceIn(0f, 100f) else 0f

        val powerFlow = when {
            scenarioCharging || chargingState.status == ChargingStatus.CHARGING -> PowerFlowState.CHARGING
            isRegen -> PowerFlowState.REGENERATING
            abs(batteryPowerKw) < 0.5f -> PowerFlowState.IDLE
            else -> PowerFlowState.DISCHARGING
        }

        return currentState.copy(
            speedKmH = speed,
            gear = gear,
            odometerKm = newOdo,
            acceleratorPositionPercent = accelPercent,
            brakePedalPercent = brakePercent,
            battery = currentState.battery.copy(
                socPercent = soc,
                voltageV = packVoltage,
                currentA = currentA,
                powerKw = batteryPowerKw,
                packTemperatureC = newPackTemp,
                minCellTempC = newPackTemp - 0.7f,
                maxCellTempC = newPackTemp + 0.9f,
                remainingEnergyKwh = remainingEnergyKwh,
                estimatedRangeKm = estRangeKm,
                powerFlow = powerFlow
            ),
            charging = chargingState,
            powertrain = newPowertrain,
            cabin = currentState.cabin.copy(
                cabinTempC = newCabinTemp,
                auxiliaryPowerKw = hvacAuxKw
            ),
            tyres = newTyres,
            timestamp = System.currentTimeMillis()
        )
    }
}
