package com.example.safety

import com.example.domain.models.*

object SafetyPolicyManager {

    fun evaluateCommand(command: VehicleCommand, currentState: VehicleState, isSimulator: Boolean): SafetyPolicyResult {
        // Enforce write separation: only allowed in simulation sandbox or authorized OEM provider
        if (!isSimulator) {
            return SafetyPolicyResult(
                isApproved = false,
                reasonEn = "Direct physical vehicle actuation blocked. Real vehicle requires cryptographic OEM signing and handshake.",
                reasonZh = "直接物理车辆执行已被安全隔离阻断。真车控制需要 OEM 密码学双向签名与安全握手。",
                safetyLevel = SafetyClassification.ASIL_D
            )
        }

        return when (command.commandType) {
            CommandType.SET_CHARGING_STATE -> {
                if (currentState.speedKmH > 0.5f) {
                    SafetyPolicyResult(
                        isApproved = false,
                        reasonEn = "Vehicle is currently in motion. Charging cannot be engaged while driving.",
                        reasonZh = "车辆当前处于行驶状态。行驶中禁止接通或控制充电回路。",
                        safetyLevel = SafetyClassification.ASIL_D
                    )
                } else {
                    SafetyPolicyResult(
                        isApproved = true,
                        reasonEn = "Vehicle is stationary with EPB ready. Charging command authorized.",
                        reasonZh = "车辆静止且驻车制动就绪。充电指令通过安全检查。",
                        safetyLevel = SafetyClassification.ASIL_B
                    )
                }
            }
            CommandType.SET_DOOR_LOCK -> {
                if (currentState.speedKmH > 15f) {
                    SafetyPolicyResult(
                        isApproved = false,
                        reasonEn = "Door unlock command prohibited at vehicle speed > 15 km/h for occupant protection.",
                        reasonZh = "车速高于 15 km/h 时禁止向外解锁车门以保障乘员安全。",
                        safetyLevel = SafetyClassification.ASIL_B
                    )
                } else {
                    SafetyPolicyResult(
                        isApproved = true,
                        reasonEn = "Speed check passed. Door actuation approved.",
                        reasonZh = "车速安全校验通过。车门闭锁控制已批准。",
                        safetyLevel = SafetyClassification.ASIL_A
                    )
                }
            }
            CommandType.CLEAR_DTC_CODES -> {
                SafetyPolicyResult(
                    isApproved = true,
                    reasonEn = "OBD-II Service \$04 DTC clear diagnostic request approved in simulation session.",
                    reasonZh = "OBD-II 服务 \$04 故障码清除请求在仿真会话中已批准。",
                    safetyLevel = SafetyClassification.QM
                )
            }
            else -> {
                SafetyPolicyResult(
                    isApproved = true,
                    reasonEn = "Non-safety-critical property modified within simulation sandbox.",
                    reasonZh = "非安全关键属性在仿真沙盒内已允许修改。",
                    safetyLevel = SafetyClassification.QM
                )
            }
        }
    }
}
