package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.domain.models.LogLevel
import com.example.localization.Language
import com.example.ui.api.ApiExplorerScreen
import com.example.ui.battery.BatteryScreen
import com.example.ui.body.BodyScreen
import com.example.ui.charging.ChargingScreen
import com.example.ui.climate.ClimateScreen
import com.example.ui.components.AutomotiveNavigationRail
import com.example.ui.components.TopBar
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.diagnostics.DiagnosticsScreen
import com.example.ui.logging.LoggingScreen
import com.example.ui.powertrain.PowertrainScreen
import com.example.ui.replay.ReplayScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.simulator.ScenarioLabScreen
import com.example.ui.telemetry.TelemetryGraphScreen
import com.example.ui.theme.CockpitBackground
import com.example.ui.tyres.TyresScreen
import com.example.viewmodel.ScreenSection
import com.example.viewmodel.VehicleViewModel

@Composable
fun MainScreen(
    viewModel: VehicleViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Show toast messages from ViewModel (e.g. Safety Gate approval / denial)
    LaunchedEffect(uiState.toastMessage) {
        uiState.toastMessage?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
            viewModel.clearToast()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopBar(
                viewModel = viewModel,
                uiState = uiState
            )
        },
        containerColor = CockpitBackground
    ) { innerPadding ->
        Row(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Left Cockpit Navigation Rail
            AutomotiveNavigationRail(
                currentSection = uiState.currentSection,
                onSelectSection = { section -> viewModel.navigateTo(section) },
                viewModel = viewModel,
                language = uiState.language
            )

            // Main Content Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(CockpitBackground)
            ) {
                when (uiState.currentSection) {
                    ScreenSection.DASHBOARD -> DashboardScreen(
                        state = uiState.vehicleState,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.BATTERY -> BatteryScreen(
                        battery = uiState.vehicleState.battery,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.CHARGING -> ChargingScreen(
                        charging = uiState.vehicleState.charging,
                        socPercent = uiState.vehicleState.battery.socPercent,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.POWERTRAIN -> PowertrainScreen(
                        powertrain = uiState.vehicleState.powertrain,
                        driveMode = uiState.vehicleState.driveMode,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.BODY -> BodyScreen(
                        body = uiState.vehicleState.body,
                        vehicleState = uiState.vehicleState,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.CLIMATE -> ClimateScreen(
                        cabin = uiState.vehicleState.cabin,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.TYRES -> TyresScreen(
                        tyres = uiState.vehicleState.tyres,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.DIAGNOSTICS -> DiagnosticsScreen(
                        diagnostics = uiState.vehicleState.diagnostics,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.API_EXPLORER -> ApiExplorerScreen(
                        state = uiState.vehicleState,
                        viewModel = viewModel,
                        language = uiState.language,
                        selectedSignalId = uiState.selectedSignalId,
                        searchQuery = uiState.signalSearchQuery
                    )
                    ScreenSection.TELEMETRY_GRAPH -> TelemetryGraphScreen(
                        telemetryHistory = uiState.telemetryHistory,
                        isPaused = uiState.isTelemetryChartPaused,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.SCENARIO_LAB -> ScenarioLabScreen(
                        activeScenarioId = uiState.activeScenarioId,
                        simSpeedMultiplier = uiState.simSpeedMultiplier,
                        isPaused = uiState.isSimulationPaused,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.REPLAY -> ReplayScreen(
                        state = uiState.vehicleState,
                        viewModel = viewModel,
                        language = uiState.language
                    )
                    ScreenSection.LOGS -> LoggingScreen(
                        viewModel = viewModel,
                        language = uiState.language,
                        activeFilter = uiState.activeLogFilter
                    )
                    ScreenSection.SETTINGS -> SettingsScreen(
                        viewModel = viewModel,
                        language = uiState.language,
                        selectedProvider = uiState.selectedProviderType
                    )
                }
            }
        }
    }
}
