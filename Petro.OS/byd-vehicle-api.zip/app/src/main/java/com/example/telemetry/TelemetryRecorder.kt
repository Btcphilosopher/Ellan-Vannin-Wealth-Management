package com.example.telemetry

import com.example.domain.models.VehicleState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class TelemetryDataPoint(
    val timestampMs: Long,
    val speed: Float,
    val powerKw: Float,
    val soc: Float,
    val rpm: Float,
    val cabinTemp: Float,
    val packVoltage: Float,
    val packCurrent: Float
)

class TelemetryRecorder(private val maxCapacity: Int = 120) {
    private val _history = MutableStateFlow<List<TelemetryDataPoint>>(emptyList())
    val history: StateFlow<List<TelemetryDataPoint>> = _history.asStateFlow()

    fun record(state: VehicleState) {
        val point = TelemetryDataPoint(
            timestampMs = state.timestamp,
            speed = state.speedKmH,
            powerKw = state.battery.powerKw,
            soc = state.battery.socPercent,
            rpm = state.powertrain.motorRpm,
            cabinTemp = state.cabin.cabinTempC,
            packVoltage = state.battery.voltageV,
            packCurrent = state.battery.currentA
        )
        val current = _history.value.toMutableList()
        current.add(point)
        if (current.size > maxCapacity) {
            _history.value = current.takeLast(maxCapacity)
        } else {
            _history.value = current
        }
    }

    fun clear() {
        _history.value = emptyList()
    }

    fun exportCsv(): String {
        val sb = java.lang.StringBuilder()
        sb.append("Timestamp,Speed_kmh,Power_kW,SOC_percent,Motor_RPM,CabinTemp_C,Voltage_V,Current_A\n")
        _history.value.forEach { p ->
            sb.append("${p.timestampMs},${"%.1f".format(p.speed)},${"%.2f".format(p.powerKw)},${"%.1f".format(p.soc)},${"%.0f".format(p.rpm)},${"%.1f".format(p.cabinTemp)},${"%.1f".format(p.packVoltage)},${"%.1f".format(p.packCurrent)}\n")
        }
        return sb.toString()
    }
}
