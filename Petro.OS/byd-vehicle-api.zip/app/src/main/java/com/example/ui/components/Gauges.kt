package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedometerGauge(
    speedKmH: Float,
    gear: String,
    driveMode: String,
    language: Language,
    modifier: Modifier = Modifier
) {
    val animatedSpeed by animateFloatAsState(
        targetValue = speedKmH,
        animationSpec = tween(durationMillis = 250),
        label = "speed"
    )

    Box(
        modifier = modifier.aspectRatio(1f),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = (size.minDimension / 2f) - 16.dp.toPx()

            // Background Track Arc (240 degrees: from 150° to 390°)
            drawArc(
                color = CockpitBorder,
                startAngle = 150f,
                sweepAngle = 240f,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            )

            // Speed Arc Gradient
            val speedFraction = (animatedSpeed / 220f).coerceIn(0f, 1f)
            val activeSweep = 240f * speedFraction

            drawArc(
                brush = Brush.sweepGradient(
                    0.4f to BydElectricCyan,
                    0.8f to BydCyanGlow,
                    1.0f to BydCrimsonRed
                ),
                startAngle = 150f,
                sweepAngle = activeSweep,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            )

            // Tick Marks (every 20 km/h)
            for (i in 0..11) {
                val tickAngle = 150f + (i * 240f / 11f)
                val rad = Math.toRadians(tickAngle.toDouble())
                val innerR = radius - 14.dp.toPx()
                val outerR = radius - 6.dp.toPx()
                val start = Offset(
                    (center.x + innerR * cos(rad)).toFloat(),
                    (center.y + innerR * sin(rad)).toFloat()
                )
                val end = Offset(
                    (center.x + outerR * cos(rad)).toFloat(),
                    (center.y + outerR * sin(rad)).toFloat()
                )
                drawCircle(
                    color = if (i * 20 <= animatedSpeed) BydElectricCyan else TechDarkText,
                    radius = 2.dp.toPx(),
                    center = end
                )
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = gear,
                    color = BydElectricCyan,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = driveMode,
                    color = TechMuted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                text = "%.0f".format(animatedSpeed),
                color = TechWhite,
                fontSize = 46.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = (-1).sp
            )
            Text(
                text = "km/h",
                color = TechMuted,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun BatterySocGauge(
    socPercent: Float,
    rangeKm: Float,
    powerKw: Float,
    language: Language,
    modifier: Modifier = Modifier
) {
    val animatedSoc by animateFloatAsState(
        targetValue = socPercent,
        animationSpec = tween(durationMillis = 250),
        label = "soc"
    )

    Box(
        modifier = modifier.aspectRatio(1f),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = (size.minDimension / 2f) - 16.dp.toPx()

            // Background Track Arc
            drawArc(
                color = CockpitBorder,
                startAngle = 150f,
                sweepAngle = 240f,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            )

            // SOC Active Arc
            val fraction = (animatedSoc / 100f).coerceIn(0f, 1f)
            val sweep = 240f * fraction
            val color = when {
                animatedSoc > 20f -> BydEnergyGreen
                animatedSoc > 10f -> BydWarningAmber
                else -> BydCrimsonRed
            }

            drawArc(
                color = color,
                startAngle = 150f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = if (language == Language.ZH) "电池电量" else "BATTERY SOC",
                color = TechMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "%.1f".format(animatedSoc),
                    color = TechWhite,
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif
                )
                Text(
                    text = "%",
                    color = BydEnergyGreen,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 4.dp, start = 2.dp)
                )
            }
            Text(
                text = "${"%.0f".format(rangeKm)} km · ${if (language == Language.ZH) "预估续航" else "Range"}",
                color = TechSilver,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
