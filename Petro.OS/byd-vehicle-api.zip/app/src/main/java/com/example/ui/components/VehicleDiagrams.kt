package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.*
import com.example.localization.Language
import com.example.ui.theme.*

@Composable
fun VehicleSilhouetteCanvas(
    state: VehicleState,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f

            // Sleek Sedan Silhouette (BYD SEAL streamline contour)
            val carPath = Path().apply {
                moveTo(cx - 160f, cy + 30f)
                // Front bumper & hood
                cubicTo(cx - 150f, cy + 15f, cx - 120f, cy - 10f, cx - 70f, cy - 20f)
                // Windshield & roof
                cubicTo(cx - 40f, cy - 38f, cx + 20f, cy - 40f, cx + 70f, cy - 25f)
                // Rear fastback window & boot
                cubicTo(cx + 110f, cy - 10f, cx + 140f, cy + 15f, cx + 160f, cy + 30f)
                // Rear bumper & undertray
                lineTo(cx + 145f, cy + 45f)
                lineTo(cx + 105f, cy + 45f)
                // Rear wheel arch
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(cx + 70f, cy + 20f, cx + 110f, cy + 60f),
                    startAngleDegrees = 0f,
                    sweepAngleDegrees = -180f,
                    forceMoveTo = false
                )
                lineTo(cx - 70f, cy + 45f)
                // Front wheel arch
                arcTo(
                    rect = androidx.compose.ui.geometry.Rect(cx - 110f, cy + 20f, cx - 70f, cy + 60f),
                    startAngleDegrees = 0f,
                    sweepAngleDegrees = -180f,
                    forceMoveTo = false
                )
                lineTo(cx - 145f, cy + 45f)
                close()
            }

            // Chassis line & wheel glow
            drawPath(
                path = carPath,
                color = BydElectricCyan.copy(alpha = 0.85f),
                style = Stroke(width = 2.5.dp.toPx())
            )

            // Front wheel
            drawCircle(
                color = CockpitBorder,
                radius = 18f,
                center = Offset(cx - 90f, cy + 40f)
            )
            drawCircle(
                color = BydElectricCyan,
                radius = 18f,
                center = Offset(cx - 90f, cy + 40f),
                style = Stroke(width = 3f)
            )

            // Rear wheel
            drawCircle(
                color = CockpitBorder,
                radius = 18f,
                center = Offset(cx + 90f, cy + 40f)
            )
            drawCircle(
                color = BydElectricCyan,
                radius = 18f,
                center = Offset(cx + 90f, cy + 40f),
                style = Stroke(width = 3f)
            )

            // Headlight beam (if headlights active)
            if (state.body.exteriorLights != LightState.OFF) {
                val lightBeam = Path().apply {
                    moveTo(cx - 155f, cy + 18f)
                    lineTo(cx - 240f, cy - 10f)
                    lineTo(cx - 240f, cy + 45f)
                    close()
                }
                drawPath(
                    path = lightBeam,
                    color = Color(0x3300D2FF)
                )
            }
        }
    }
}

@Composable
fun VehicleTopDownDiagram(
    state: VehicleState,
    language: Language,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .background(CockpitSurfaceDark, RoundedCornerShape(8.dp))
            .border(1.dp, CockpitBorder, RoundedCornerShape(8.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f

            // Top-down vehicle body shape (centered vertical oriented car)
            val carW = 100f
            val carH = 190f

            drawRoundRect(
                color = CockpitSurfaceElevated,
                topLeft = Offset(cx - carW / 2f, cy - carH / 2f),
                size = Size(carW, carH),
                cornerRadius = CornerRadius(24f, 24f)
            )
            drawRoundRect(
                color = BydElectricCyan.copy(alpha = 0.6f),
                topLeft = Offset(cx - carW / 2f, cy - carH / 2f),
                size = Size(carW, carH),
                cornerRadius = CornerRadius(24f, 24f),
                style = Stroke(width = 2f)
            )

            // Windshield & Sunroof
            drawRoundRect(
                color = CockpitBackground,
                topLeft = Offset(cx - (carW * 0.7f) / 2f, cy - (carH * 0.5f) / 2f),
                size = Size(carW * 0.7f, carH * 0.5f),
                cornerRadius = CornerRadius(10f, 10f)
            )

            // Front Left Door (FL)
            val flOpen = state.body.doorFrontLeft == DoorState.OPEN
            drawRoundRect(
                color = if (flOpen) BydCrimsonRed else BydEnergyGreen,
                topLeft = Offset(cx - carW / 2f - (if (flOpen) 16f else 4f), cy - 40f),
                size = Size(if (flOpen) 14f else 4f, 35f),
                cornerRadius = CornerRadius(2f, 2f)
            )

            // Front Right Door (FR)
            val frOpen = state.body.doorFrontRight == DoorState.OPEN
            drawRoundRect(
                color = if (frOpen) BydCrimsonRed else BydEnergyGreen,
                topLeft = Offset(cx + carW / 2f, cy - 40f),
                size = Size(if (frOpen) 14f else 4f, 35f),
                cornerRadius = CornerRadius(2f, 2f)
            )

            // Rear Left Door (RL)
            val rlOpen = state.body.doorRearLeft == DoorState.OPEN
            drawRoundRect(
                color = if (rlOpen) BydCrimsonRed else BydEnergyGreen,
                topLeft = Offset(cx - carW / 2f - (if (rlOpen) 16f else 4f), cy + 5f),
                size = Size(if (rlOpen) 14f else 4f, 35f),
                cornerRadius = CornerRadius(2f, 2f)
            )

            // Rear Right Door (RR)
            val rrOpen = state.body.doorRearRight == DoorState.OPEN
            drawRoundRect(
                color = if (rrOpen) BydCrimsonRed else BydEnergyGreen,
                topLeft = Offset(cx + carW / 2f, cy + 5f),
                size = Size(if (rrOpen) 14f else 4f, 35f),
                cornerRadius = CornerRadius(2f, 2f)
            )

            // Boot (Trunk)
            val trunkOpen = state.body.trunk == DoorState.OPEN
            drawRoundRect(
                color = if (trunkOpen) BydCrimsonRed else BydEnergyGreen,
                topLeft = Offset(cx - 20f, cy + carH / 2f - 4f),
                size = Size(40f, if (trunkOpen) 12f else 4f),
                cornerRadius = CornerRadius(2f, 2f)
            )

            // Frunk / Hood
            val hoodOpen = state.body.hood == DoorState.OPEN
            drawRoundRect(
                color = if (hoodOpen) BydCrimsonRed else BydEnergyGreen,
                topLeft = Offset(cx - 20f, cy - carH / 2f),
                size = Size(40f, if (hoodOpen) 12f else 4f),
                cornerRadius = CornerRadius(2f, 2f)
            )
        }
    }
}
