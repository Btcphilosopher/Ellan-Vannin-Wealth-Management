package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.theme.*
import com.example.viewmodel.ScreenSection
import com.example.viewmodel.VehicleViewModel

data class NavItem(
    val section: ScreenSection,
    val icon: ImageVector,
    val stringKey: String
)

val NAV_ITEMS = listOf(
    NavItem(ScreenSection.DASHBOARD, Icons.Default.Speed, StringKeys.NAV_DASHBOARD),
    NavItem(ScreenSection.BATTERY, Icons.Default.BatteryChargingFull, StringKeys.NAV_BATTERY),
    NavItem(ScreenSection.CHARGING, Icons.Default.EvStation, StringKeys.NAV_CHARGING),
    NavItem(ScreenSection.POWERTRAIN, Icons.Default.ElectricBolt, StringKeys.NAV_POWERTRAIN),
    NavItem(ScreenSection.BODY, Icons.Default.DirectionsCar, StringKeys.NAV_BODY),
    NavItem(ScreenSection.CLIMATE, Icons.Default.AcUnit, StringKeys.NAV_CLIMATE),
    NavItem(ScreenSection.TYRES, Icons.Default.TireRepair, StringKeys.NAV_TYRES),
    NavItem(ScreenSection.DIAGNOSTICS, Icons.Default.Build, StringKeys.NAV_DIAGNOSTICS),
    NavItem(ScreenSection.API_EXPLORER, Icons.Default.Code, StringKeys.NAV_API_EXPLORER),
    NavItem(ScreenSection.TELEMETRY_GRAPH, Icons.Default.Timeline, StringKeys.NAV_TELEMETRY),
    NavItem(ScreenSection.SCENARIO_LAB, Icons.Default.Science, StringKeys.NAV_SCENARIO_LAB),
    NavItem(ScreenSection.REPLAY, Icons.Default.PlayCircle, StringKeys.NAV_REPLAY),
    NavItem(ScreenSection.LOGS, Icons.Default.ListAlt, StringKeys.NAV_LOGS),
    NavItem(ScreenSection.SETTINGS, Icons.Default.Settings, StringKeys.NAV_SETTINGS)
)

@Composable
fun AutomotiveNavigationRail(
    currentSection: ScreenSection,
    onSelectSection: (ScreenSection) -> Unit,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .width(200.dp)
            .fillMaxHeight()
            .background(CockpitSurfaceDark)
            .border(width = 1.dp, color = CockpitBorder)
            .padding(vertical = 8.dp, horizontal = 6.dp)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(NAV_ITEMS) { item ->
                val isSelected = item.section == currentSection
                val label = viewModel.getString(item.stringKey)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .background(
                            color = if (isSelected) CockpitSurfaceElevated else Color.Transparent,
                            shape = RoundedCornerShape(6.dp)
                        )
                        .border(
                            width = if (isSelected) 1.dp else 0.dp,
                            color = if (isSelected) BydElectricCyan.copy(alpha = 0.6f) else Color.Transparent,
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectSection(item.section) }
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = label,
                        tint = if (isSelected) BydElectricCyan else TechMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = label,
                        color = if (isSelected) TechWhite else TechSilver,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
