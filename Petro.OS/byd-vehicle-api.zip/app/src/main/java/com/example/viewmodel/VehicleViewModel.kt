package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.EventBus
import com.example.api.SignalRegistry
import com.example.api.VehicleDataProvider
import com.example.domain.models.*
import com.example.localization.Language
import com.example.localization.StringDictionary
import com.example.oem.BydDilinkAdapter
import com.example.replay.MockReplayProvider
import com.example.replay.ReplaySession
import com.example.replay.SessionArchive
import com.example.simulator.ScenarioConfig
import com.example.simulator.ScenarioPresets
import com.example.simulator.SimulatorVehicleProvider
import com.example.telemetry.TelemetryDataPoint
import com.example.telemetry.TelemetryRecorder
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ScreenSection {
    DASHBOARD,
    BATTERY,
    CHARGING,
    POWERTRAIN,
    BODY,
    CLIMATE,
    TYRES,
    DIAGNOSTICS,
    API_EXPLORER,
    TELEMETRY_GRAPH,
    SCENARIO_LAB,
    REPLAY,
    LOGS,
    SETTINGS
}

data class VehicleUiState(
    val currentSection: ScreenSection = ScreenSection.DASHBOARD,
    val language: Language = Language.EN,
    val selectedProviderType: String = "SIMULATOR", // "SIMULATOR", "REPLAY", "OEM"
    val vehicleState: VehicleState = VehicleState(),
    val isConnected: Boolean = true,
    val selectedSignalId: String = "battery.soc",
    val signalSearchQuery: String = "",
    val activeLogFilter: LogLevel? = null,
    val logModuleFilter: String = "",
    val activeScenarioId: String = "urban_driving",
    val simSpeedMultiplier: Float = 1.0f,
    val isSimulationPaused: Boolean = false,
    val isTelemetryChartPaused: Boolean = false,
    val telemetryHistory: List<TelemetryDataPoint> = emptyList(),
    val toastMessage: String? = null
)

class VehicleViewModel(
    val simulatorProvider: SimulatorVehicleProvider = SimulatorVehicleProvider(),
    val replayProvider: MockReplayProvider = MockReplayProvider(),
    val oemProvider: BydDilinkAdapter = BydDilinkAdapter()
) : ViewModel() {

    private val telemetryRecorder = TelemetryRecorder(maxCapacity = 120)
    private var activeProvider: VehicleDataProvider = simulatorProvider

    private val _uiState = MutableStateFlow(VehicleUiState())
    val uiState: StateFlow<VehicleUiState> = _uiState.asStateFlow()

    init {
        observeActiveProvider()
        observeTelemetry()
    }

    private fun observeActiveProvider() {
        viewModelScope.launch {
            activeProvider.observeVehicleState().collect { state ->
                telemetryRecorder.record(state)
                _uiState.update { it.copy(vehicleState = state, isConnected = activeProvider.isConnected()) }
            }
        }
    }

    private fun observeTelemetry() {
        viewModelScope.launch {
            telemetryRecorder.history.collect { hist ->
                if (!_uiState.value.isTelemetryChartPaused) {
                    _uiState.update { it.copy(telemetryHistory = hist) }
                }
            }
        }
    }

    fun setLanguage(lang: Language) {
        _uiState.update { it.copy(language = lang) }
    }

    fun toggleLanguage() {
        val next = if (_uiState.value.language == Language.EN) Language.ZH else Language.EN
        setLanguage(next)
    }

    fun navigateTo(section: ScreenSection) {
        _uiState.update { it.copy(currentSection = section) }
    }

    fun selectSignal(signalId: String) {
        _uiState.update { it.copy(selectedSignalId = signalId) }
    }

    fun setSignalSearch(query: String) {
        _uiState.update { it.copy(signalSearchQuery = query) }
    }

    fun setLogFilter(level: LogLevel?) {
        _uiState.update { it.copy(activeLogFilter = level) }
    }

    fun setLogModuleFilter(module: String) {
        _uiState.update { it.copy(logModuleFilter = module) }
    }

    fun setProvider(providerType: String) {
        when (providerType) {
            "SIMULATOR" -> {
                activeProvider = simulatorProvider
                _uiState.update { it.copy(selectedProviderType = "SIMULATOR") }
            }
            "REPLAY" -> {
                activeProvider = replayProvider
                _uiState.update { it.copy(selectedProviderType = "REPLAY") }
            }
            "OEM" -> {
                activeProvider = oemProvider
                _uiState.update { it.copy(selectedProviderType = "OEM") }
            }
        }
        observeActiveProvider()
    }

    fun executeCommand(commandType: CommandType, payload: Map<String, Any> = emptyMap()) {
        viewModelScope.launch {
            val cmd = VehicleCommand(
                commandType = commandType,
                payload = payload,
                targetModule = commandType.name
            )
            val result = activeProvider.executeCommand(cmd)
            val msg = if (_uiState.value.language == Language.ZH) result.reasonZh else result.reasonEn
            _uiState.update { it.copy(toastMessage = msg) }
        }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    fun loadScenario(preset: ScenarioConfig) {
        _uiState.update { it.copy(activeScenarioId = preset.id) }
        simulatorProvider.loadScenario(preset)
    }

    fun setSimSpeed(speed: Float) {
        simulatorProvider.simSpeedMultiplier = speed
        _uiState.update { it.copy(simSpeedMultiplier = speed) }
    }

    fun toggleSimPause() {
        val paused = !_uiState.value.isSimulationPaused
        simulatorProvider.isSimulationRunning = !paused
        _uiState.update { it.copy(isSimulationPaused = paused) }
    }

    fun toggleTelemetryChartPause() {
        _uiState.update { it.copy(isTelemetryChartPaused = !it.isTelemetryChartPaused) }
    }

    fun exportTelemetryCsv(): String = telemetryRecorder.exportCsv()

    // Replay controls
    fun replayPlay() = replayProvider.play()
    fun replayPause() = replayProvider.pause()
    fun replayStep() = replayProvider.step()
    fun replayRestart() = replayProvider.restart()
    fun replaySeek(index: Int) = replayProvider.seek(index)
    fun replaySelectSession(session: ReplaySession) = replayProvider.selectSession(session)

    fun injectTestDtc() = simulatorProvider.injectTestDtc()
    fun clearDtc() {
        executeCommand(CommandType.CLEAR_DTC_CODES)
    }

    fun getString(key: String): String {
        return StringDictionary.get(key, _uiState.value.language)
    }
}
