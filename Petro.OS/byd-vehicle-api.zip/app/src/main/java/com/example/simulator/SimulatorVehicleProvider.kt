package com.example.simulator

import com.example.api.EventBus
import com.example.api.SignalRegistry
import com.example.api.VehicleDataProvider
import com.example.domain.models.*
import com.example.logging.EngineeringLogger
import com.example.safety.SafetyPolicyManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class SimulatorVehicleProvider(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) : VehicleDataProvider {

    override val providerId: String = "SIMULATOR_CORE_V3"
    override val providerNameEn: String = "BYD Simulation Engine (Deterministic Physics)"
    override val providerNameZh: String = "比亚迪动力学仿真引擎 (高精度确定性模型)"

    private val _isConnected = MutableStateFlow(true)
    private val _vehicleState = MutableStateFlow(createInitialState())
    private var simulationJob: Job? = null

    // Simulation controls
    var simSpeedMultiplier: Float = 1.0f
    var targetSpeedKmH: Float = 64.0f
    var isSimulationRunning: Boolean = true
    var activeScenario: ScenarioConfig? = null

    init {
        startSimulation()
    }

    private fun createInitialState(): VehicleState {
        return VehicleState(
            vin = "LBYDSEAL8NA009281",
            modelName = "BYD SEAL (CTB e-Platform 3.0)",
            modelNameZh = "比亚迪海豹 (CTB 刀片电池平台)",
            speedKmH = 64.0f,
            gear = GearState.D,
            driveMode = DriveMode.NORMAL,
            odometerKm = 14280.5,
            battery = BatteryState(
                socPercent = 78.2f,
                sohPercent = 99.4f,
                voltageV = 352.4f,
                currentA = 118.0f,
                powerKw = 41.58f,
                packTemperatureC = 25.8f,
                minCellTempC = 25.1f,
                maxCellTempC = 26.5f,
                remainingEnergyKwh = 64.5f,
                totalCapacityKwh = 82.5f,
                estimatedRangeKm = 412.0f
            ),
            charging = ChargingState(
                status = ChargingStatus.DISCONNECTED,
                chargingPowerKw = 0f,
                targetSocPercent = 90f
            ),
            powertrain = PowertrainState(
                motorRpm = 3450f,
                motorTorqueNm = 160f,
                motorPowerKw = 42.0f,
                motorTempC = 58.4f,
                inverterTempC = 46.2f,
                efficiencyPercent = 94.2f
            ),
            cabin = CabinState(
                cabinTempC = 21.4f,
                targetTempC = 22.0f,
                outsideTempC = 12.8f,
                fanSpeed = 3,
                auxiliaryPowerKw = 1.4f
            ),
            tyres = TyreState(),
            diagnostics = DiagnosticState(),
            adas = ADASState()
        )
    }

    fun startSimulation() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            EngineeringLogger.i("SIMULATOR", "Simulation loop initialized with fixed dt=100ms", "Provider: $providerId")
            EventBus.emit(
                EventType.VEHICLE_CONNECTED,
                "BYD Vehicle Bus Connected",
                "比亚迪整车总线通信已建立",
                "Model: BYD SEAL CTB, 82.5kWh Blade Battery",
                "SIMULATOR"
            )

            var lastSocFloor = _vehicleState.value.battery.socPercent.toInt()
            while (isActive) {
                if (isSimulationRunning && _isConnected.value) {
                    val dt = (0.1f * simSpeedMultiplier).coerceIn(0.01f, 2.0f)
                    val current = _vehicleState.value

                    val isCharging = current.charging.status == ChargingStatus.CHARGING
                    val hvacLoad = if (current.cabin.acCompressorOn || current.cabin.heatPumpOn) {
                        (0.4f + (current.cabin.fanSpeed * 0.25f) + (if (current.cabin.outsideTempC < 0f || current.cabin.outsideTempC > 30f) 1.5f else 0.5f))
                    } else 0.35f

                    val nextState = PhysicsEngine.step(
                        currentState = current,
                        targetSpeedKmH = if (isCharging) 0f else targetSpeedKmH,
                        dtSeconds = dt,
                        hvacAuxKw = hvacLoad,
                        scenarioCharging = isCharging,
                        maxChargingPowerKw = current.charging.maxPowerLimitKw
                    )

                    _vehicleState.value = nextState

                    // Check events
                    val newSocFloor = nextState.battery.socPercent.toInt()
                    if (newSocFloor != lastSocFloor) {
                        lastSocFloor = newSocFloor
                        EventBus.emit(
                            EventType.SOC_UPDATED,
                            "Battery SOC Step",
                            "电池电量阶跃",
                            "${"%.1f".format(nextState.battery.socPercent)}% | ${"%.0f".format(nextState.battery.estimatedRangeKm)} km",
                            "CAN_BMS"
                        )
                    }
                }
                delay(100L)
            }
        }
    }

    fun loadScenario(preset: ScenarioConfig) {
        activeScenario = preset
        targetSpeedKmH = preset.baseSpeedKmH
        val current = _vehicleState.value

        val newCharging = if (preset.isCharging) {
            current.charging.copy(
                status = ChargingStatus.CHARGING,
                chargingPowerKw = preset.chargingPowerKw,
                chargerType = ChargerType.DC_FAST
            )
        } else {
            current.charging.copy(
                status = ChargingStatus.DISCONNECTED,
                chargingPowerKw = 0f
            )
        }

        _vehicleState.value = current.copy(
            speedKmH = preset.baseSpeedKmH,
            gear = preset.gear,
            driveMode = preset.driveMode,
            battery = current.battery.copy(
                socPercent = preset.initialSoc,
                remainingEnergyKwh = (preset.initialSoc / 100f) * PhysicsEngine.TOTAL_BATTERY_CAPACITY_KWH,
                packTemperatureC = if (preset.outsideTempC < 0f) 2.0f else if (preset.outsideTempC > 35f) 34f else 25f
            ),
            charging = newCharging,
            cabin = current.cabin.copy(
                outsideTempC = preset.outsideTempC,
                targetTempC = preset.targetCabinTempC,
                auxiliaryPowerKw = preset.hvacPowerLoadKw
            )
        )

        scope.launch {
            EventBus.emit(
                EventType.DRIVE_MODE_CHANGED,
                "Applied Scenario: ${preset.nameEn}",
                "已载入仿真工况: ${preset.nameZh}",
                "SOC: ${preset.initialSoc}%, Ambient: ${preset.outsideTempC}°C, Speed: ${preset.baseSpeedKmH} km/h",
                "SCENARIO_LAB"
            )
        }
    }

    override fun isConnected(): Boolean = _isConnected.value

    override suspend fun connect(): Boolean {
        _isConnected.value = true
        EventBus.emit(
            EventType.VEHICLE_CONNECTED,
            "Vehicle Data Provider Connected",
            "整车数据提供程序已上线",
            "Provider: $providerNameEn",
            "SIMULATOR"
        )
        return true
    }

    override suspend fun disconnect() {
        _isConnected.value = false
        EventBus.emit(
            EventType.VEHICLE_DISCONNECTED,
            "Vehicle Data Provider Disconnected",
            "整车数据提供程序已断开",
            "Link suspended by user",
            "SIMULATOR"
        )
    }

    override fun observeVehicleState(): StateFlow<VehicleState> = _vehicleState.asStateFlow()

    override fun observeSignals(): Flow<List<VehicleSignalValue>> {
        return _vehicleState.map { state ->
            SignalRegistry.definitions.mapNotNull { def ->
                SignalRegistry.extractSignalValue(def.id, state)
            }
        }
    }

    override fun getSignal(id: String): VehicleSignalValue? {
        return SignalRegistry.extractSignalValue(id, _vehicleState.value)
    }

    override suspend fun executeCommand(command: VehicleCommand): SafetyPolicyResult {
        val result = SafetyPolicyManager.evaluateCommand(command, _vehicleState.value, isSimulator = true)
        
        EngineeringLogger.i(
            module = "SAFETY_AUDIT",
            event = "[CMD] ${command.commandType.name}",
            payload = "Approved: ${result.isApproved} | Level: ${result.safetyLevel.code} | Reason: ${result.reasonEn}"
        )

        if (!result.isApproved) {
            EventBus.emit(
                EventType.SAFETY_POLICY_CHECK,
                "Command Rejected by Safety Gate",
                "指令被安全网关拦截",
                "${command.commandType.enName}: ${result.reasonEn}",
                "SAFETY_CONTROLLER"
            )
            return result
        }

        // Apply mutation
        val current = _vehicleState.value
        when (command.commandType) {
            CommandType.SET_CHARGING_STATE -> {
                val action = command.payload["action"] as? String ?: "START"
                when (action) {
                    "START" -> {
                        _vehicleState.value = current.copy(
                            speedKmH = 0f,
                            gear = GearState.P,
                            charging = current.charging.copy(
                                status = ChargingStatus.CHARGING,
                                chargingPowerKw = 120.0f
                            )
                        )
                        EventBus.emit(EventType.CHARGING_STARTED, "Charging Initiated", "直流充电已启动", "Power: 120kW DC", "OBC_CONTROLLER")
                    }
                    "PAUSE" -> {
                        _vehicleState.value = current.copy(
                            charging = current.charging.copy(
                                status = ChargingStatus.PAUSED,
                                chargingPowerKw = 0f
                            )
                        )
                        EventBus.emit(EventType.CHARGING_PAUSED, "Charging Paused", "充电已暂停", "Interrupted by user command", "OBC_CONTROLLER")
                    }
                    "RESUME" -> {
                        _vehicleState.value = current.copy(
                            charging = current.charging.copy(
                                status = ChargingStatus.CHARGING,
                                chargingPowerKw = 120.0f
                            )
                        )
                        EventBus.emit(EventType.CHARGING_STARTED, "Charging Resumed", "充电已恢复", "Resumed at 120kW", "OBC_CONTROLLER")
                    }
                    "STOP" -> {
                        _vehicleState.value = current.copy(
                            charging = current.charging.copy(
                                status = ChargingStatus.DISCONNECTED,
                                chargingPowerKw = 0f
                            )
                        )
                        EventBus.emit(EventType.CHARGING_STOPPED, "Charging Terminated", "充电已停止", "Connector disengaged", "OBC_CONTROLLER")
                    }
                }
            }
            CommandType.SET_TARGET_SOC -> {
                val target = (command.payload["targetSoc"] as? Number)?.toFloat() ?: 90f
                _vehicleState.value = current.copy(
                    charging = current.charging.copy(targetSocPercent = target)
                )
            }
            CommandType.SET_CLIMATE_TARGET -> {
                val temp = (command.payload["targetTemp"] as? Number)?.toFloat() ?: 22f
                _vehicleState.value = current.copy(
                    cabin = current.cabin.copy(targetTempC = temp)
                )
                EventBus.emit(EventType.HVAC_CHANGED, "Cabin Setpoint: ${temp}°C", "空调设定温度: ${temp}°C", "Zone: Dual-Zone Auto", "HVAC_NODE")
            }
            CommandType.SET_CLIMATE_FAN -> {
                val fan = (command.payload["fanSpeed"] as? Number)?.toInt() ?: 3
                _vehicleState.value = current.copy(
                    cabin = current.cabin.copy(fanSpeed = fan)
                )
            }
            CommandType.SET_CLIMATE_POWER -> {
                val acOn = command.payload["acOn"] as? Boolean ?: (!current.cabin.acCompressorOn)
                _vehicleState.value = current.copy(
                    cabin = current.cabin.copy(acCompressorOn = acOn, heatPumpOn = acOn)
                )
            }
            CommandType.SET_DRIVE_MODE -> {
                val mode = DriveMode.valueOf((command.payload["driveMode"] as? String) ?: "NORMAL")
                _vehicleState.value = current.copy(driveMode = mode)
                EventBus.emit(EventType.DRIVE_MODE_CHANGED, "Drive Mode: ${mode.enName}", "驾驶模式已切为: ${mode.zhName}", "ECU mapping updated", "VCU")
            }
            CommandType.SET_DOOR_LOCK -> {
                val newLock = if (current.body.centralLock == LockState.LOCKED) LockState.UNLOCKED else LockState.LOCKED
                _vehicleState.value = current.copy(
                    body = current.body.copy(centralLock = newLock)
                )
                EventBus.emit(
                    if (newLock == LockState.LOCKED) EventType.DOOR_CLOSED else EventType.DOOR_OPENED,
                    "Central Lock: ${newLock.enName}",
                    "中控闭锁: ${newLock.zhName}",
                    "All 4 door actuators synchronized",
                    "BCM"
                )
            }
            CommandType.SIMULATE_TYRE_PUNCTURE -> {
                val puncture = command.payload["puncture"] as? Boolean ?: true
                val updatedTyre = current.tyres.frontLeft.copy(
                    isPunctured = puncture,
                    pressureKpa = if (puncture) 145f else 248f,
                    isLowPressure = puncture
                )
                _vehicleState.value = current.copy(
                    tyres = current.tyres.copy(frontLeft = updatedTyre)
                )
                if (puncture) {
                    EventBus.emit(
                        EventType.FAULT_RAISED,
                        "TPMS Alert: Low Pressure FL",
                        "胎压告警: 左前轮气压异常偏低",
                        "Measured: 145 kPa (Ref: 250 kPa)",
                        "TPMS_ECU"
                    )
                }
            }
            CommandType.CLEAR_DTC_CODES -> {
                _vehicleState.value = current.copy(
                    diagnostics = current.diagnostics.copy(activeDtcs = emptyList())
                )
                EventBus.emit(
                    EventType.FAULT_CLEARED,
                    "Diagnostic DTC Memory Cleared",
                    "诊断故障码记录已清除",
                    "OBD2 Service \$04 broadcast",
                    "GATEWAY"
                )
            }
        }

        return result
    }

    fun injectTestDtc() {
        val testDtc = DtcItem(
            code = "P1A42-13",
            system = "Blade Battery Thermal",
            descriptionEn = "Battery Pack NTC Sensor Module 3 Temperature Variance Alert",
            descriptionZh = "动力电池包第 3 组 NTC 采样温差超出标定阈值",
            severity = "WARNING"
        )
        val current = _vehicleState.value
        _vehicleState.value = current.copy(
            diagnostics = current.diagnostics.copy(
                activeDtcs = current.diagnostics.activeDtcs + testDtc,
                thermalHealth = "WARNING"
            )
        )
        scope.launch {
            EventBus.emit(
                EventType.FAULT_RAISED,
                "DTC Injected: ${testDtc.code}",
                "已注入故障诊断码: ${testDtc.code}",
                testDtc.descriptionZh,
                "DIAGNOSTIC_SIM"
            )
        }
    }
}
