package com.example.replay

import com.example.domain.models.*

data class TelemetrySnapshot(
    val relativeTimeSeconds: Float,
    val speedKmH: Float,
    val motorRpm: Float,
    val motorTorqueNm: Float,
    val batteryPowerKw: Float,
    val batteryVoltageV: Float,
    val batteryCurrentA: Float,
    val socPercent: Float,
    val cabinTempC: Float,
    val outsideTempC: Float,
    val acceleratorPercent: Float,
    val brakePercent: Float
)

data class ReplaySession(
    val id: String,
    val titleEn: String,
    val titleZh: String,
    val date: String,
    val durationSeconds: Int,
    val distanceKm: Float,
    val energyConsumedKwh: Float,
    val avgSpeedKmH: Float,
    val initialSoc: Float,
    val finalSoc: Float,
    val snapshots: List<TelemetrySnapshot>
)

object SessionArchive {
    val SHANGHAI_HIGHWAY = createHighwaySession()
    val SHENZHEN_URBAN = createUrbanSession()

    val allSessions = listOf(SHANGHAI_HIGHWAY, SHENZHEN_URBAN)

    private fun createHighwaySession(): ReplaySession {
        val count = 120 // 120 seconds cycle
        val list = mutableListOf<TelemetrySnapshot>()
        var soc = 88.0f
        for (i in 0 until count) {
            val t = i.toFloat()
            val speed = when {
                i < 15 -> (i / 15f) * 110f
                i < 80 -> 110f + kotlin.math.sin(i * 0.1).toFloat() * 8f
                i < 95 -> 110f - ((i - 80) / 15f) * 40f
                else -> 70f + kotlin.math.sin(i * 0.2).toFloat() * 4f
            }
            val rpm = speed * 81.3f
            val power = (speed * 0.45f) + if (i in 80..95) -18f else 12f
            soc -= 0.02f
            val voltage = 358f - (soc * 0.05f)
            val current = (power * 1000f) / voltage

            list.add(
                TelemetrySnapshot(
                    relativeTimeSeconds = t,
                    speedKmH = speed,
                    motorRpm = rpm,
                    motorTorqueNm = if (rpm > 0) (power * 9549f / rpm).coerceIn(-120f, 350f) else 0f,
                    batteryPowerKw = power,
                    batteryVoltageV = voltage,
                    batteryCurrentA = current,
                    socPercent = soc,
                    cabinTempC = 21.8f,
                    outsideTempC = 17.5f,
                    acceleratorPercent = if (power > 0) 35f else 0f,
                    brakePercent = if (power < 0) 25f else 0f
                )
            )
        }

        return ReplaySession(
            id = "sess_g60_shanghai",
            titleEn = "G60 Highway Cruise (Shanghai - Hangzhou)",
            titleZh = "G60 沪昆高速高速巡航工况 (上海-杭州)",
            date = "2026-09-18 14:32",
            durationSeconds = count,
            distanceKm = 3.65f,
            energyConsumedKwh = 0.58f,
            avgSpeedKmH = 104.5f,
            initialSoc = 88.0f,
            finalSoc = soc,
            snapshots = list
        )
    }

    private fun createUrbanSession(): ReplaySession {
        val count = 100
        val list = mutableListOf<TelemetrySnapshot>()
        var soc = 64.5f
        for (i in 0 until count) {
            val t = i.toFloat()
            val speed = when {
                i % 25 < 8 -> 0f
                i % 25 < 16 -> ((i % 25 - 8) / 8f) * 48f
                else -> 48f - ((i % 25 - 16) / 9f) * 48f
            }
            val rpm = speed * 81.3f
            val power = if (speed > 10f) (speed * 0.38f) else if (speed == 0f) 0.8f else -14f
            soc -= 0.012f
            val voltage = 349f - (soc * 0.04f)
            val current = (power * 1000f) / voltage

            list.add(
                TelemetrySnapshot(
                    relativeTimeSeconds = t,
                    speedKmH = speed,
                    motorRpm = rpm,
                    motorTorqueNm = if (rpm > 0) (power * 9549f / rpm).coerceIn(-150f, 400f) else 0f,
                    batteryPowerKw = power,
                    batteryVoltageV = voltage,
                    batteryCurrentA = current,
                    socPercent = soc,
                    cabinTempC = 22.2f,
                    outsideTempC = 28.0f,
                    acceleratorPercent = if (power > 2f) 28f else 0f,
                    brakePercent = if (power < 0) 30f else 0f
                )
            )
        }

        return ReplaySession(
            id = "sess_shenzhen_cbd",
            titleEn = "Shenzhen Futian CBD Stop & Go",
            titleZh = "深圳福田 CBD 拥堵走停工况",
            date = "2026-09-20 08:45",
            durationSeconds = count,
            distanceKm = 1.15f,
            energyConsumedKwh = 0.22f,
            avgSpeedKmH = 26.2f,
            initialSoc = 64.5f,
            finalSoc = soc,
            snapshots = list
        )
    }
}
