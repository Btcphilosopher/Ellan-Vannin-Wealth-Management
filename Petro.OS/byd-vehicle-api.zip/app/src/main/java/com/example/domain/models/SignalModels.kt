package com.example.domain.models

enum class SignalCategory(val enName: String, val zhName: String) {
    VEHICLE("Vehicle Dynamics", "整车动力学"),
    BATTERY("Blade Battery", "动力电池"),
    CHARGING("Charging System", "充电系统"),
    POWERTRAIN("Powertrain / Motor", "电驱系统"),
    BODY("Body & Closures", "车身与闭锁"),
    CLIMATE("HVAC & Thermal", "热管理与空调"),
    TYRES("TPMS Tyres", "轮胎胎压"),
    DIAGNOSTICS("Diagnostics & DTC", "诊断监控"),
    ADAS("DiPilot ADAS", "智能驾驶")
}

data class SignalDefinition(
    val id: String,
    val category: SignalCategory,
    val nameEn: String,
    val nameZh: String,
    val dataType: String, // "FLOAT", "INT", "STRING", "BOOLEAN", "ENUM"
    val unit: String,
    val readable: Boolean = true,
    val writable: Boolean = false,
    val safetyClass: SafetyClassification = SafetyClassification.QM,
    val updateFrequencyMs: Int = 100,
    val source: String = "CAN_BUS_VEHICLE",
    val descriptionEn: String = "",
    val descriptionZh: String = ""
)

data class VehicleSignalValue(
    val definition: SignalDefinition,
    val rawValue: Any,
    val formattedValue: String,
    val quality: DataQuality = DataQuality.VALID,
    val timestamp: Long = System.currentTimeMillis()
)
