package com.example.simulator

import com.example.domain.models.ChargingStatus
import com.example.domain.models.DriveMode
import com.example.domain.models.GearState

data class ScenarioConfig(
    val id: String,
    val nameEn: String,
    val nameZh: String,
    val descriptionEn: String,
    val descriptionZh: String,
    val initialSoc: Float,
    val outsideTempC: Float,
    val targetCabinTempC: Float,
    val baseSpeedKmH: Float,
    val gear: GearState,
    val driveMode: DriveMode,
    val isCharging: Boolean = false,
    val chargingPowerKw: Float = 0f,
    val hvacPowerLoadKw: Float = 1.2f,
    val initialOdometerKm: Double = 14280.5
)

object ScenarioPresets {
    val URBAN_DRIVING = ScenarioConfig(
        id = "urban_driving",
        nameEn = "Urban Stop & Go",
        nameZh = "城市拥堵起停",
        descriptionEn = "City traffic with frequent regenerative braking and stop-start cycles.",
        descriptionZh = "典型城市路况，包含频繁起步、加减速以及高回收率能量回收工况。",
        initialSoc = 78.0f,
        outsideTempC = 22.0f,
        targetCabinTempC = 22.0f,
        baseSpeedKmH = 45.0f,
        gear = GearState.D,
        driveMode = DriveMode.ECO,
        isCharging = false,
        hvacPowerLoadKw = 1.0f
    )

    val MOTORWAY = ScenarioConfig(
        id = "motorway",
        nameEn = "High-Speed Motorway",
        nameZh = "高速巡航工况",
        descriptionEn = "Consistent 115 km/h high-power aerodynamic cruise with active ADAS DiPilot.",
        descriptionZh = "持续 115 km/h 高速恒速巡航，DiPilot 智能领航全开，电驱处于高效稳定区间。",
        initialSoc = 85.0f,
        outsideTempC = 18.0f,
        targetCabinTempC = 21.5f,
        baseSpeedKmH = 115.0f,
        gear = GearState.D,
        driveMode = DriveMode.NORMAL,
        isCharging = false,
        hvacPowerLoadKw = 1.2f
    )

    val HEAVY_TRAFFIC = ScenarioConfig(
        id = "heavy_traffic",
        nameEn = "Heavy Traffic Crawl",
        nameZh = "走走停停高能耗",
        descriptionEn = "Peak hour traffic jam with high cabin HVAC draw vs low distance covered.",
        descriptionZh = "早晚高峰严重拥堵，蠕行速度低，空调热泵消耗占总电耗比例较高。",
        initialSoc = 62.0f,
        outsideTempC = 26.0f,
        targetCabinTempC = 21.0f,
        baseSpeedKmH = 18.0f,
        gear = GearState.D,
        driveMode = DriveMode.ECO,
        isCharging = false,
        hvacPowerLoadKw = 1.8f
    )

    val COLD_WEATHER = ScenarioConfig(
        id = "cold_weather",
        nameEn = "Cold Winter (-15°C)",
        nameZh = "冬季极寒环境 (-15°C)",
        descriptionEn = "Sub-zero climate stress test with heat pump heating and battery preheating active.",
        descriptionZh = "零下15度极寒工况，全负荷热泵制热与电池脉冲自加热开启，验证低温能耗与衰减。",
        initialSoc = 55.0f,
        outsideTempC = -15.0f,
        targetCabinTempC = 23.0f,
        baseSpeedKmH = 60.0f,
        gear = GearState.D,
        driveMode = DriveMode.SNOW,
        isCharging = false,
        hvacPowerLoadKw = 3.5f
    )

    val HOT_WEATHER = ScenarioConfig(
        id = "hot_weather",
        nameEn = "Summer Heatwave (38°C)",
        nameZh = "夏季高温暴晒 (38°C)",
        descriptionEn = "High ambient temperature with maximum dual-zone cooling and battery liquid chilling.",
        descriptionZh = "38度酷暑高温，双温区强劲制冷叠加电池包主动冷媒直冷循环。",
        initialSoc = 70.0f,
        outsideTempC = 38.0f,
        targetCabinTempC = 20.0f,
        baseSpeedKmH = 70.0f,
        gear = GearState.D,
        driveMode = DriveMode.SPORT,
        isCharging = false,
        hvacPowerLoadKw = 3.2f
    )

    val FAST_CHARGING = ScenarioConfig(
        id = "fast_charging",
        nameEn = "150kW DC Fast Charge",
        nameZh = "150kW 高压超充",
        descriptionEn = "High-voltage DC fast charging curve from 20% to 80% with battery active cooling.",
        descriptionZh = "高压大功率直流快充仿真，从 20% 快速充入，实时呈现刀片电池宽温域阶梯充电曲线。",
        initialSoc = 22.0f,
        outsideTempC = 24.0f,
        targetCabinTempC = 22.0f,
        baseSpeedKmH = 0.0f,
        gear = GearState.P,
        driveMode = DriveMode.NORMAL,
        isCharging = true,
        chargingPowerKw = 142.0f,
        hvacPowerLoadKw = 0.6f
    )

    val LONG_JOURNEY = ScenarioConfig(
        id = "long_journey",
        nameEn = "Long Distance Trip",
        nameZh = "长途跨城巡航",
        descriptionEn = "Endurance test simulating extended battery discharge and range recalculations.",
        descriptionZh = "跨城长途高速续航仿真，综合监测电量消耗曲线、动能回收及续航预估动态修正。",
        initialSoc = 98.0f,
        outsideTempC = 19.0f,
        targetCabinTempC = 22.0f,
        baseSpeedKmH = 95.0f,
        gear = GearState.D,
        driveMode = DriveMode.NORMAL,
        isCharging = false,
        hvacPowerLoadKw = 1.3f
    )

    val LOW_BATTERY = ScenarioConfig(
        id = "low_battery",
        nameEn = "Low SOC Warning (12%)",
        nameZh = "低电量预警 (12%)",
        descriptionEn = "Low battery safety mode with automatic power throttling and turtle indicator warning.",
        descriptionZh = "电量低于 15% 自动进入整车功率受限保护模式，仪表点亮低电量黄色告警与节能限速提示。",
        initialSoc = 12.5f,
        outsideTempC = 16.0f,
        targetCabinTempC = 21.0f,
        baseSpeedKmH = 35.0f,
        gear = GearState.D,
        driveMode = DriveMode.ECO,
        isCharging = false,
        hvacPowerLoadKw = 0.8f
    )

    val list: List<ScenarioConfig> = listOf(
        URBAN_DRIVING,
        MOTORWAY,
        HEAVY_TRAFFIC,
        COLD_WEATHER,
        HOT_WEATHER,
        FAST_CHARGING,
        LONG_JOURNEY,
        LOW_BATTERY
    )
}
