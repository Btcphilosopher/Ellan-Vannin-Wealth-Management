package com.example.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.VehicleState
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun DashboardScreen(
    state: VehicleState,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Status Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CockpitSurfaceDark, RoundedCornerShape(8.dp))
                .border(1.dp, CockpitBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (state.isReady) "READY" else "OFF",
                    color = if (state.isReady) BydEnergyGreen else BydCrimsonRed,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "${viewModel.getString(StringKeys.ODOMETER)}: ${"%.1f".format(state.odometerKm)} km",
                    color = TechSilver,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${viewModel.getString(StringKeys.CABIN_TEMP)}: ${"%.1f".format(state.cabin.cabinTempC)}°C",
                    color = TechSilver,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.width(14.dp))
                Text(
                    text = "${viewModel.getString(StringKeys.OUTSIDE_TEMP)}: ${"%.1f".format(state.cabin.outsideTempC)}°C",
                    color = TechMuted,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.width(14.dp))
                Text(
                    text = "${viewModel.getString(StringKeys.ADAS_STATUS)}: ${if (state.adas.laneKeepAssistActive) "DiPilot Active" else "Standby"}",
                    color = BydElectricCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Main Cockpit Gauges & Center Silhouette
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left: Speedometer Gauge Card
            AutomotiveCard(
                titleEn = "Vehicle Speed",
                titleZh = "实时车速",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                SpeedometerGauge(
                    speedKmH = state.speedKmH,
                    gear = state.gear.label,
                    driveMode = state.driveMode.name,
                    language = language,
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MetricReadout(
                        labelEn = "Power Output",
                        labelZh = "输出功率",
                        value = "${"%.1f".format(state.battery.powerKw)}",
                        unit = "kW",
                        language = language,
                        accentColor = if (state.battery.powerKw < 0) BydEnergyGreen else BydElectricCyan
                    )
                    MetricReadout(
                        labelEn = "Consumption",
                        labelZh = "百公里电耗",
                        value = "${"%.1f".format(state.avgConsumptionKwhPer100Km)}",
                        unit = "kWh",
                        language = language
                    )
                }
            }

            // Center: Vehicle Silhouette & Dynamics
            AutomotiveCard(
                titleEn = "Vehicle Dynamics & Body",
                titleZh = "整车动力学与车身姿态",
                language = language,
                modifier = Modifier.weight(1.3f)
            ) {
                VehicleSilhouetteCanvas(
                    state = state,
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MetricReadout(
                        labelEn = "Accelerator",
                        labelZh = "油门深度",
                        value = "${"%.0f".format(state.acceleratorPositionPercent)}",
                        unit = "%",
                        language = language
                    )
                    MetricReadout(
                        labelEn = "Steering Angle",
                        labelZh = "转向角度",
                        value = "${"%.1f".format(state.steeringAngleDeg)}",
                        unit = "°",
                        language = language
                    )
                    MetricReadout(
                        labelEn = "Brake Pressure",
                        labelZh = "制动深度",
                        value = "${"%.0f".format(state.brakePedalPercent)}",
                        unit = "%",
                        language = language,
                        accentColor = if (state.brakePedalPercent > 0) BydCrimsonRed else TechWhite
                    )
                }
            }

            // Right: Battery Gauge Card
            AutomotiveCard(
                titleEn = "Blade Battery SOC",
                titleZh = "刀片电池电量",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                BatterySocGauge(
                    socPercent = state.battery.socPercent,
                    rangeKm = state.battery.estimatedRangeKm,
                    powerKw = state.battery.powerKw,
                    language = language,
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MetricReadout(
                        labelEn = "Pack Voltage",
                        labelZh = "总电压",
                        value = "${"%.1f".format(state.battery.voltageV)}",
                        unit = "V",
                        language = language
                    )
                    MetricReadout(
                        labelEn = "Pack Current",
                        labelZh = "总电流",
                        value = "${"%.1f".format(state.battery.currentA)}",
                        unit = "A",
                        language = language
                    )
                }
            }
        }

        // Bottom 4 Telemetry Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AutomotiveCard(
                titleEn = "Electric Powertrain",
                titleZh = "电驱系统",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricReadout("Motor RPM", "电机转速", "${"%.0f".format(state.powertrain.motorRpm)}", "rpm", language)
                    MetricReadout("Torque", "输出扭矩", "${"%.1f".format(state.powertrain.motorTorqueNm)}", "Nm", language)
                }
            }

            AutomotiveCard(
                titleEn = "HVAC Climate",
                titleZh = "智能空调",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricReadout("Cabin Target", "目标温区", "${"%.1f".format(state.cabin.targetTempC)}", "°C", language)
                    MetricReadout("Fan Speed", "风量挡位", "${state.cabin.fanSpeed} / 8", "step", language)
                }
            }

            AutomotiveCard(
                titleEn = "Tyres TPMS",
                titleZh = "胎压监测",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricReadout("FL Pressure", "左前胎压", "${"%.0f".format(state.tyres.frontLeft.pressureKpa)}", "kPa", language,
                        accentColor = if (state.tyres.frontLeft.isLowPressure) BydCrimsonRed else TechWhite)
                    MetricReadout("FR Pressure", "右前胎压", "${"%.0f".format(state.tyres.frontRight.pressureKpa)}", "kPa", language)
                }
            }

            AutomotiveCard(
                titleEn = "Diagnostics Health",
                titleZh = "系统诊断健康",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricReadout("Active DTCs", "活动故障码", "${state.diagnostics.activeDtcs.size}", "codes", language,
                        accentColor = if (state.diagnostics.activeDtcs.isNotEmpty()) BydWarningAmber else TechWhite)
                    MetricReadout("System", "总线状态", if (state.diagnostics.activeDtcs.isEmpty()) "OK" else "WARN", "-", language,
                        accentColor = if (state.diagnostics.activeDtcs.isEmpty()) BydEnergyGreen else BydWarningAmber)
                }
            }
        }
    }
}
