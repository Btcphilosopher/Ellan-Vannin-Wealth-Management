package com.example.ui.powertrain

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.CommandType
import com.example.domain.models.DriveMode
import com.example.domain.models.PowertrainState
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.MetricReadout
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun PowertrainScreen(
    powertrain: PowertrainState,
    driveMode: DriveMode,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Drive Mode Selector & Status
        AutomotiveCard(
            titleEn = "Drive Dynamics Mode Mapping",
            titleZh = "整车动力特性与驾驶模式映射",
            language = language
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DriveMode.values().forEach { mode ->
                    val isSelected = mode == driveMode
                    Button(
                        onClick = {
                            viewModel.executeCommand(
                                CommandType.SET_DRIVE_MODE,
                                mapOf("driveMode" to mode.name)
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) BydElectricCyan else CockpitSurfaceElevated
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) BydElectricCyan else CockpitBorder,
                                shape = RoundedCornerShape(6.dp)
                            )
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = mode.enName,
                                color = if (isSelected) CockpitBackground else TechWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = mode.zhName,
                                color = if (isSelected) CockpitBackground else TechMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Motor Telemetry Matrix
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AutomotiveCard(
                titleEn = "Permanent Magnet Synchronous Motor (PMSM)",
                titleZh = "永磁同步电机转速与轴端扭矩",
                language = language,
                badgeText = "Max 16,000 RPM",
                badgeColor = BydElectricCyan,
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MetricReadout("Motor Speed", "电机转速", "${"%.0f".format(powertrain.motorRpm)}", "rpm", language,
                        accentColor = BydElectricCyan)
                    MetricReadout("Delivered Torque", "实际扭矩", "${"%.1f".format(powertrain.motorTorqueNm)}", "Nm", language)
                    MetricReadout("Mechanical Power", "轴输出功率", "${"%.1f".format(powertrain.motorPowerKw)}", "kW", language)
                }
            }

            AutomotiveCard(
                titleEn = "Silicon Carbide (SiC) Inverter & Temperatures",
                titleZh = "碳化硅 (SiC) 电控与热负荷监测",
                language = language,
                badgeText = "8-in-1 Electric Drive",
                badgeColor = BydEnergyGreen,
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MetricReadout("Motor Stator Temp", "电机定子温度", "${"%.1f".format(powertrain.motorTempC)}", "°C", language)
                    MetricReadout("SiC Module Temp", "碳化硅模块温", "${"%.1f".format(powertrain.inverterTempC)}", "°C", language)
                    MetricReadout("System Efficiency", "综合电驱效率", "${"%.1f".format(powertrain.efficiencyPercent)}", "%", language,
                        accentColor = BydEnergyGreen)
                }
            }
        }
    }
}
