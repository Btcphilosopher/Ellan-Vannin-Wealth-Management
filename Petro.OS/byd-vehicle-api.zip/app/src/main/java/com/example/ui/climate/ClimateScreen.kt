package com.example.ui.climate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.CabinState
import com.example.domain.models.CommandType
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.MetricReadout
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun ClimateScreen(
    cabin: CabinState,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Temperature Setpoint & Fan Controls
            AutomotiveCard(
                titleEn = "Heat Pump Thermal Comfort & Setpoint",
                titleZh = "宽温域热泵温控与温度设定",
                language = language,
                badgeText = if (cabin.acCompressorOn) "HEAT PUMP ACTIVE" else "FAN ONLY",
                badgeColor = if (cabin.acCompressorOn) BydElectricCyan else TechMuted,
                modifier = Modifier.weight(1.2f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MetricReadout("Cabin Temp", "当前座舱温度", "${"%.1f".format(cabin.cabinTempC)}", "°C", language)
                    MetricReadout("Target Temp", "设定目标温度", "${"%.1f".format(cabin.targetTempC)}", "°C", language,
                        accentColor = BydElectricCyan)
                    MetricReadout("Outside Ambient", "车外环境温度", "${"%.1f".format(cabin.outsideTempC)}", "°C", language)
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "${viewModel.getString(StringKeys.TARGET_TEMP)}: ${"%.1f".format(cabin.targetTempC)}°C",
                    color = TechSilver,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = cabin.targetTempC,
                    onValueChange = { newVal ->
                        viewModel.executeCommand(
                            CommandType.SET_CLIMATE_TARGET,
                            mapOf("targetTemp" to newVal)
                        )
                    },
                    valueRange = 16f..30f,
                    steps = 27,
                    colors = SliderDefaults.colors(
                        thumbColor = BydElectricCyan,
                        activeTrackColor = BydElectricCyan,
                        inactiveTrackColor = CockpitBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "${viewModel.getString(StringKeys.FAN_SPEED)}: ${cabin.fanSpeed} / 8",
                    color = TechSilver,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Slider(
                    value = cabin.fanSpeed.toFloat(),
                    onValueChange = { newVal ->
                        viewModel.executeCommand(
                            CommandType.SET_CLIMATE_FAN,
                            mapOf("fanSpeed" to newVal.toInt())
                        )
                    },
                    valueRange = 1f..8f,
                    steps = 6,
                    colors = SliderDefaults.colors(
                        thumbColor = BydElectricCyan,
                        activeTrackColor = BydElectricCyan,
                        inactiveTrackColor = CockpitBorder
                    )
                )
            }

            // Power Consumption & Toggle Controls
            AutomotiveCard(
                titleEn = "Auxiliary Electrical Load & Modes",
                titleZh = "辅件电功率消耗与空调模式",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                MetricReadout("HVAC Auxiliary Draw", "空调瞬时电功耗", "${"%.2f".format(cabin.auxiliaryPowerKw)}", "kW", language,
                    accentColor = BydElectricCyan)

                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        viewModel.executeCommand(CommandType.SET_CLIMATE_POWER)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (cabin.acCompressorOn) BydCrimsonRed.copy(alpha = 0.8f) else BydEnergyGreen
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Text(
                        text = if (cabin.acCompressorOn)
                            (if (language == Language.ZH) "关闭空调压缩机 (Turn OFF)" else "Turn OFF Compressor")
                        else
                            (if (language == Language.ZH) "开启高效热泵 (Turn ON)" else "Turn ON Heat Pump"),
                        color = CockpitBackground,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
