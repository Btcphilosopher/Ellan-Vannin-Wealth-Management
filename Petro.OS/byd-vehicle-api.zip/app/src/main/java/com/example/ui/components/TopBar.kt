package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.VehicleState
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun TopBar(
    viewModel: VehicleViewModel,
    uiState: com.example.viewmodel.VehicleUiState,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CockpitSurfaceDark,
        modifier = modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = CockpitBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App Title and Vehicle Identity
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(
                            if (uiState.isConnected) BydEnergyGreen else BydCrimsonRed,
                            RoundedCornerShape(4.dp)
                        )
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "BYD VEHICLE API",
                            color = TechWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "比亚迪车辆 API",
                            color = TechMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }
                    Text(
                        text = "${uiState.vehicleState.modelName} · VIN: ${uiState.vehicleState.vin.take(12)}...",
                        color = TechDarkText,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Center: Active Provider / Mode Pill
            Row(verticalAlignment = Alignment.CenterVertically) {
                val modeLabel = when (uiState.selectedProviderType) {
                    "SIMULATOR" -> viewModel.getString(StringKeys.SIMULATION_MODE)
                    "REPLAY" -> viewModel.getString(StringKeys.REPLAY_MODE)
                    else -> viewModel.getString(StringKeys.OEM_DILINK_MODE)
                }

                Box(
                    modifier = Modifier
                        .background(CockpitSurfaceElevated, RoundedCornerShape(16.dp))
                        .border(1.dp, CockpitBorder, RoundedCornerShape(16.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = modeLabel,
                        color = BydElectricCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Right: Language Switcher and Status
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Instant Bilingual Language Toggle
                Button(
                    onClick = { viewModel.toggleLanguage() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CockpitSurfaceElevated,
                        contentColor = TechWhite
                    ),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .height(34.dp)
                        .border(1.dp, BydElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language",
                        tint = BydElectricCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (uiState.language == Language.EN) "中文 (ZH)" else "EN (English)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
