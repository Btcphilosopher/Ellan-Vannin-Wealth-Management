package com.example.oem

import com.example.api.VehicleDataProvider
import com.example.domain.models.SafetyClassification
import com.example.domain.models.SafetyPolicyResult
import com.example.domain.models.VehicleCommand
import com.example.domain.models.VehicleSignalValue
import com.example.domain.models.VehicleState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface OemVehicleProvider : VehicleDataProvider {
    val oemSdkAvailable: Boolean
    val oemAuthToken: String?
    fun validateOemSignature(payload: ByteArray, signature: ByteArray): Boolean
    fun requestVehiclePermission(permissionKey: String): Boolean
}

class BydDilinkAdapter : OemVehicleProvider {
    override val providerId: String = "BYD_DILINK_SDK_ADAPTER"
    override val providerNameEn: String = "BYD DiLink Ecosystem SDK (OEM Integration Bridge)"
    override val providerNameZh: String = "比亚迪 DiLink 车机生态 SDK (OEM 适配桥接层)"

    override val oemSdkAvailable: Boolean = false // Set to true when authentic BYD DiLink CarService AIDL/SDK is linked
    override val oemAuthToken: String? = null

    private val _isConnected = MutableStateFlow(false)
    private val _vehicleState = MutableStateFlow(
        VehicleState(
            vin = "LBYDSEAL8OEM99281",
            modelName = "BYD SEAL (DiLink 5.0 Standby)",
            modelNameZh = "比亚迪海豹 (DiLink 5.0 待命)"
        )
    )

    override fun isConnected(): Boolean = _isConnected.value

    override suspend fun connect(): Boolean {
        // [INTEGRATION POINT]: Connect to authorised BYD DiLink AIDL CarService:
        // e.g., com.byd.car.service.IBydCarService / com.byd.dilink.cockpit.VehicleManager
        // Map OEM signals to internal VehicleSignal definitions
        // Validate OAuth token & DiLink client certificates
        _isConnected.value = false // Standby placeholder
        return false
    }

    override suspend fun disconnect() {
        // [INTEGRATION POINT]: Unbind AIDL CarService & release CAN bus filters
        _isConnected.value = false
    }

    override fun observeVehicleState(): StateFlow<VehicleState> = _vehicleState.asStateFlow()

    override fun observeSignals(): Flow<List<VehicleSignalValue>> {
        // [INTEGRATION POINT]: Stream CAN message frames and dispatch to typed VehicleSignalValue
        return kotlinx.coroutines.flow.emptyFlow()
    }

    override fun getSignal(id: String): VehicleSignalValue? = null

    override suspend fun executeCommand(command: VehicleCommand): SafetyPolicyResult {
        return SafetyPolicyResult(
            isApproved = false,
            reasonEn = "OEM Provider is in sandbox mode. Direct hardware bus access requires BYD OEM cryptokey signing.",
            reasonZh = "OEM 适配层当前处于沙箱桩模式。直连硬件总线需要比亚迪官方安全证书签名与鉴权。",
            safetyLevel = SafetyClassification.ASIL_D
        )
    }

    override fun validateOemSignature(payload: ByteArray, signature: ByteArray): Boolean {
        // [INTEGRATION POINT]: Check ECDSA secp256r1 signature against BYD OEM Public Key Root
        return false
    }

    override fun requestVehiclePermission(permissionKey: String): Boolean {
        // [INTEGRATION POINT]: Check Android Manifest permission e.g. com.byd.permission.VEHICLE_DATA
        return false
    }
}
