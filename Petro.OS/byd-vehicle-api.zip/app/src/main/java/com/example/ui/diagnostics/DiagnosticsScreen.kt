package com.example.ui.diagnostics

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.DiagnosticState
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.MetricReadout
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun DiagnosticsScreen(
    diagnostics: DiagnosticState,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Subsystem Health Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AutomotiveCard(
                titleEn = "ECU / Domain Subsystem Health Matrix",
                titleZh = "整车 ECU 与各域控制器健康体检矩阵",
                language = language,
                modifier = Modifier.weight(1.3f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MetricReadout("VCU/Powertrain", "动力总成域", diagnostics.powertrainHealth, "-", language,
                        accentColor = if (diagnostics.powertrainHealth == "NORMAL") BydEnergyGreen else BydWarningAmber)
                    MetricReadout("BMS Battery", "电池管理域", diagnostics.batteryHealth, "-", language,
                        accentColor = if (diagnostics.batteryHealth == "NORMAL") BydEnergyGreen else BydWarningAmber)
                    MetricReadout("Chassis/Body", "车身控制域", diagnostics.bodyHealth, "-", language,
                        accentColor = if (diagnostics.bodyHealth == "NORMAL") BydEnergyGreen else BydWarningAmber)
                    MetricReadout("Thermal Mgmt", "热管理域", diagnostics.thermalHealth, "-", language,
                        accentColor = if (diagnostics.thermalHealth == "NORMAL") BydEnergyGreen else BydWarningAmber)
                }
            }

            // Diagnostic Actions Card
            AutomotiveCard(
                titleEn = "UDS / OBD-II Diagnostic Actions",
                titleZh = "UDS 与 OBD-II 诊断指令操作",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.injectTestDtc() },
                        colors = ButtonDefaults.buttonColors(containerColor = CockpitSurfaceElevated),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, BydWarningAmber, RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            text = if (language == Language.ZH) "注入测试故障码" else "Inject Test DTC",
                            color = BydWarningAmber,
                            fontSize = 12.sp
                        )
                    }

                    Button(
                        onClick = { viewModel.clearDtc() },
                        colors = ButtonDefaults.buttonColors(containerColor = BydElectricCyan),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = viewModel.getString(StringKeys.CLEAR_DTC),
                            color = CockpitBackground,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Active Diagnostic Trouble Codes (DTCs) List
        AutomotiveCard(
            titleEn = "Active Diagnostic Trouble Codes (DTC Memory)",
            titleZh = "当前活动故障诊断码 (DTC 内存列表)",
            language = language,
            badgeText = "${diagnostics.activeDtcs.size} CODES",
            badgeColor = if (diagnostics.activeDtcs.isNotEmpty()) BydWarningAmber else BydEnergyGreen,
            modifier = Modifier.weight(1f)
        ) {
            if (diagnostics.activeDtcs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (language == Language.ZH) "系统正常：无活动故障码 (No DTCs Found)" else "System Nominal: No active diagnostic trouble codes",
                        color = BydEnergyGreen,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(diagnostics.activeDtcs) { dtc ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CockpitSurfaceDark, RoundedCornerShape(6.dp))
                                .border(1.dp, BydWarningAmber.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = dtc.code,
                                            color = BydWarningAmber,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = dtc.system,
                                            color = TechMuted,
                                            fontSize = 11.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (language == Language.ZH) dtc.descriptionZh else dtc.descriptionEn,
                                        color = TechSilver,
                                        fontSize = 13.sp
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .background(BydWarningAmber.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = dtc.severity,
                                        color = BydWarningAmber,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
