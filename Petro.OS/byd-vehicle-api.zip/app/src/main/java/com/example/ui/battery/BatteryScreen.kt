package com.example.ui.battery

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.BatteryState
import com.example.domain.models.PowerFlowState
import com.example.localization.Language
import com.example.localization.StringKeys
import com.example.ui.components.AutomotiveCard
import com.example.ui.components.BatterySocGauge
import com.example.ui.components.MetricReadout
import com.example.ui.theme.*
import com.example.viewmodel.VehicleViewModel

@Composable
fun BatteryScreen(
    battery: BatteryState,
    viewModel: VehicleViewModel,
    language: Language,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Battery Architecture Overview Card
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AutomotiveCard(
                titleEn = "Blade Battery Pack Architecture",
                titleZh = "刀片电池系统架构与荷电状态",
                language = language,
                badgeText = "LFP · CTB 82.5 kWh",
                badgeColor = BydEnergyGreen,
                modifier = Modifier.weight(1.2f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BatterySocGauge(
                        socPercent = battery.socPercent,
                        rangeKm = battery.estimatedRangeKm,
                        powerKw = battery.powerKw,
                        language = language,
                        modifier = Modifier.size(160.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            MetricReadout("Total Capacity", "额定容量", "${battery.totalCapacityKwh}", "kWh", language)
                            MetricReadout("Remaining Energy", "可用电量", "${"%.1f".format(battery.remainingEnergyKwh)}", "kWh", language)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                            MetricReadout("Health (SOH)", "健康度 (SOH)", "${"%.1f".format(battery.sohPercent)}", "%", language,
                                accentColor = BydEnergyGreen)
                            MetricReadout("Cycle Count", "循环充放次数", "${battery.cycleCount}", "cycles", language)
                        }
                    }
                }
            }

            // Power Flow & Bus Voltage
            AutomotiveCard(
                titleEn = "High-Voltage DC Link & Power Flow",
                titleZh = "高压母线与能量流向",
                language = language,
                modifier = Modifier.weight(1f)
            ) {
                val flowColor = when (battery.powerFlow) {
                    PowerFlowState.DISCHARGING -> BydElectricCyan
                    PowerFlowState.REGENERATING -> BydEnergyGreen
                    PowerFlowState.CHARGING -> BydSpeedBlue
                    PowerFlowState.IDLE -> TechMuted
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(flowColor.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                        .border(1.dp, flowColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (language == Language.ZH) "当前流向: ${battery.powerFlow.zhName}" else "Power Flow: ${battery.powerFlow.enName}",
                            color = flowColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "${"%.2f".format(battery.powerKw)} kW",
                            color = TechWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricReadout("Pack Voltage", "电池包总电压", "${"%.1f".format(battery.voltageV)}", "V", language)
                    MetricReadout("Pack Current", "充放电总电流", "${"%.1f".format(battery.currentA)}", "A", language,
                        accentColor = if (battery.currentA < 0) BydEnergyGreen else TechWhite)
                }
            }
        }

        // Thermal Distribution & Cell Balancing
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AutomotiveCard(
                titleEn = "Liquid Thermal Management & Cell Temperatures",
                titleZh = "直冷直热液冷温控与电芯温差分布",
                language = language,
                badgeText = if (battery.thermalManagementActive) "ACTIVE COOLING" else "STANDBY",
                badgeColor = BydElectricCyan,
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MetricReadout("Pack Avg Temp", "包内平均温度", "${"%.1f".format(battery.packTemperatureC)}", "°C", language)
                    MetricReadout("Min Cell Temp", "最低单体温度", "${"%.1f".format(battery.minCellTempC)}", "°C", language)
                    MetricReadout("Max Cell Temp", "最高单体温度", "${"%.1f".format(battery.maxCellTempC)}", "°C", language)
                    MetricReadout("Delta T Variance", "单体最大温差", "${"%.1f".format(battery.maxCellTempC - battery.minCellTempC)}", "°C", language,
                        accentColor = BydEnergyGreen)
                }
            }
        }
    }
}
