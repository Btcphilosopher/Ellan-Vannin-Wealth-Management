/**
 * GASTURBINE.OS — Synthetic Plant & Telemetry Engine
 * Reference GT-500-DEMO machine configuration, multi-class presets,
 * synthetic sensors with noise models, and 20-year operational historian generator.
 */

import { TurbineConfig } from '../cycle/cycle-solver';

export interface SyntheticSensor {
  id: string;
  tag: string;
  name: string;
  engineeringUnit: string;
  measuredValue: number;
  expectedNominalValue: number;
  modelledValue: number;
  residual: number;
  noiseSigma: number;
  bias: number;
  drift: number;
  isStuck: boolean;
  isDropout: boolean;
  quality: 'GOOD' | 'FAIR' | 'DEGRADED' | 'FAILED' | 'CALIBRATING';
  minRange: number;
  maxRange: number;
  alarmLow: number;
  alarmHigh: number;
}

export interface HistorianTimePoint {
  timestamp: string;
  dateStr: string;
  monthIndex: number;
  loadMW: number;
  efficiencyPercent: number;
  heatRateKJKWh: number;
  ambientTempC: number;
  compressorHealthPercent: number;
  turbineHealthPercent: number;
  overallHealthPercent: number;
  events: string[];
  isMaintenanceWash: boolean;
}

export const TURBINE_PRESETS: Record<string, TurbineConfig> = {
  'GT-500-DEMO': {
    name: 'GT-500-DEMO (F-Class Heavy Frame)',
    classType: 'HEAVY_DUTY',
    compressorStages: 18,
    turbineStages: 4,
    designPressureRatio: 24.2,
    designAirMassFlowKgS: 740,
    designFiringTempK: 1773.15, // 1500°C
    compressorIsentropicEta: 0.895,
    turbineIsentropicEta: 0.925,
    combustorEfficiency: 0.998,
    combustorPressureLossFraction: 0.038,
    shaftMechanicalEta: 0.992,
    generatorElectricalEta: 0.988,
    ratedPowerMW: 487.5,
    ratedShaftSpeedRpm: 3000,
    allowHydrogenBlend: true,
  },
  'GT-H-FLEX': {
    name: 'GT-600-H (H-Class Ultra High Temp)',
    classType: 'H_CLASS',
    compressorStages: 20,
    turbineStages: 4,
    designPressureRatio: 28.5,
    designAirMassFlowKgS: 820,
    designFiringTempK: 1873.15, // 1600°C
    compressorIsentropicEta: 0.910,
    turbineIsentropicEta: 0.935,
    combustorEfficiency: 0.9985,
    combustorPressureLossFraction: 0.035,
    shaftMechanicalEta: 0.994,
    generatorElectricalEta: 0.990,
    ratedPowerMW: 615.0,
    ratedShaftSpeedRpm: 3000,
    allowHydrogenBlend: true,
  },
  'GT-150-AERO': {
    name: 'GT-150-AERO (Aeroderivative Fast Ramp)',
    classType: 'AERODERIVATIVE',
    compressorStages: 14,
    turbineStages: 3,
    designPressureRatio: 32.0,
    designAirMassFlowKgS: 240,
    designFiringTempK: 1623.15, // 1350°C
    compressorIsentropicEta: 0.885,
    turbineIsentropicEta: 0.915,
    combustorEfficiency: 0.997,
    combustorPressureLossFraction: 0.042,
    shaftMechanicalEta: 0.990,
    generatorElectricalEta: 0.985,
    ratedPowerMW: 148.0,
    ratedShaftSpeedRpm: 3600,
    allowHydrogenBlend: true,
  },
  'GT-30-IND': {
    name: 'GT-30-IND (Industrial Cogeneration)',
    classType: 'INDUSTRIAL',
    compressorStages: 12,
    turbineStages: 2,
    designPressureRatio: 16.5,
    designAirMassFlowKgS: 95,
    designFiringTempK: 1473.15, // 1200°C
    compressorIsentropicEta: 0.865,
    turbineIsentropicEta: 0.895,
    combustorEfficiency: 0.996,
    combustorPressureLossFraction: 0.045,
    shaftMechanicalEta: 0.988,
    generatorElectricalEta: 0.982,
    ratedPowerMW: 32.4,
    ratedShaftSpeedRpm: 6000,
    allowHydrogenBlend: false,
  },
  'GT-1-MICRO': {
    name: 'GT-1-MICRO (Recuperated Microturbine)',
    classType: 'MICROTURBINE',
    compressorStages: 1, // Centrifugal
    turbineStages: 1,    // Radial
    designPressureRatio: 4.8,
    designAirMassFlowKgS: 5.2,
    designFiringTempK: 1223.15, // 950°C
    compressorIsentropicEta: 0.820,
    turbineIsentropicEta: 0.840,
    combustorEfficiency: 0.992,
    combustorPressureLossFraction: 0.050,
    shaftMechanicalEta: 0.975,
    generatorElectricalEta: 0.965,
    ratedPowerMW: 1.05,
    ratedShaftSpeedRpm: 45000,
    allowHydrogenBlend: false,
  },
};

export class SyntheticPlantEngine {
  /**
   * Generates realistic 20-year synthetic operational history.
   */
  static generateHistorianHistory(baseMW = 487.5): HistorianTimePoint[] {
    const points: HistorianTimePoint[] = [];
    const startYear = 2006;
    const totalMonths = 240; // 20 years

    let currentCompHealth = 99.5;
    let currentTurbHealth = 99.8;

    for (let m = 0; m <= totalMonths; m += 3) {
      const year = startYear + Math.floor(m / 12);
      const monthInYear = (m % 12) + 1;
      const dateStr = `${year}-${monthInYear.toString().padStart(2, '0')}-01`;

      // Seasonal ambient temperature oscillation: 2°C in winter, 28°C in summer
      const seasonalAmbient = 15 + 13 * Math.sin((m / 12) * 2 * Math.PI - Math.PI / 2);

      // Continuous fouling & thermal degradation over time
      currentCompHealth -= (0.45 + 0.15 * Math.random());
      currentTurbHealth -= (0.22 + 0.08 * Math.random());

      const events: string[] = [];
      let isMaintenanceWash = false;

      // Online/offline wash every 6-9 months when comp health < 92%
      if (currentCompHealth < 92.0) {
        currentCompHealth = Math.min(99.0, currentCompHealth + 6.5);
        events.push('Compressor Offline Foam Water Wash Performed');
        isMaintenanceWash = true;
      }

      // Major hot-gas path inspection & re-coating every 4 years (48 months)
      if (m > 0 && m % 48 === 0) {
        currentTurbHealth = Math.min(99.5, currentTurbHealth + 5.0);
        events.push('Major Overhaul: Hot Gas Path Blade Re-coating & Seal Replacement');
      }

      const overallHealth = currentCompHealth * 0.55 + currentTurbHealth * 0.45;
      const loadMW = baseMW * (overallHealth / 100) * (1 - (seasonalAmbient - 15) * 0.0035);
      const efficiency = 39.8 * (overallHealth / 100) - (seasonalAmbient - 15) * 0.04;
      const heatRate = 9050 / (efficiency / 39.8);

      points.push({
        timestamp: new Date(dateStr).toISOString(),
        dateStr,
        monthIndex: m,
        loadMW,
        efficiencyPercent: efficiency,
        heatRateKJKWh: heatRate,
        ambientTempC: seasonalAmbient,
        compressorHealthPercent: currentCompHealth,
        turbineHealthPercent: currentTurbHealth,
        overallHealthPercent: overallHealth,
        events,
        isMaintenanceWash,
      });
    }

    return points;
  }

  /**
   * Generates synthetic sensor readings with realistic noise, bias, and drift.
   */
  static generateSensorReadings(
    simData: {
      powerMW: number;
      fuelFlowKgS: number;
      cdpBar: number;
      cdtC: number;
      titC: number;
      egtC: number;
      rpm: number;
      ambientTempC: number;
      ambientBar: number;
      airFlowKgS: number;
      noxPpm: number;
      coPpm: number;
    },
    injectedFaults: {
      sensorDriftTag?: string;
      sensorStuckTag?: string;
      sensorNoiseTag?: string;
      biasPercent?: number;
    } = {}
  ): SyntheticSensor[] {
    const rawSensors: {
      tag: string;
      name: string;
      unit: string;
      modelled: number;
      sigma: number;
      minR: number;
      maxR: number;
      alLo: number;
      alHi: number;
    }[] = [
      { tag: 'TT-001', name: 'Ambient Air Temperature', unit: '°C', modelled: simData.ambientTempC, sigma: 0.15, minR: -30, maxR: 60, alLo: -15, alHi: 45 },
      { tag: 'PT-001', name: 'Ambient Barometric Pressure', unit: 'bar', modelled: simData.ambientBar, sigma: 0.001, minR: 0.8, maxR: 1.1, alLo: 0.9, alHi: 1.05 },
      { tag: 'DP-101', name: 'Inlet Air Filter Delta-P', unit: 'mbar', modelled: 10.2, sigma: 0.2, minR: 0, maxR: 40, alLo: 2, alHi: 25 },
      { tag: 'FT-101', name: 'Inlet Air Mass Flow', unit: 'kg/s', modelled: simData.airFlowKgS, sigma: 1.2, minR: 50, maxR: 900, alLo: 100, alHi: 880 },
      { tag: 'PT-201', name: 'Compressor Discharge Pressure (CDP)', unit: 'bar', modelled: simData.cdpBar, sigma: 0.08, minR: 1, maxR: 35, alLo: 5, alHi: 30 },
      { tag: 'TT-201', name: 'Compressor Discharge Temperature (CDT)', unit: '°C', modelled: simData.cdtC, sigma: 0.8, minR: 50, maxR: 600, alLo: 100, alHi: 520 },
      { tag: 'FT-301', name: 'Natural Gas Fuel Mass Flow', unit: 'kg/s', modelled: simData.fuelFlowKgS, sigma: 0.08, minR: 1, maxR: 40, alLo: 2, alHi: 35 },
      { tag: 'PT-301', name: 'Fuel Gas Header Supply Pressure', unit: 'bar', modelled: 38.5, sigma: 0.15, minR: 20, maxR: 50, alLo: 28, alHi: 45 },
      { tag: 'TT-301', name: 'Turbine Firing Temperature (TIT)', unit: '°C', modelled: simData.titC, sigma: 3.5, minR: 500, maxR: 1750, alLo: 800, alHi: 1560 },
      { tag: 'TT-401', name: 'Turbine Exhaust Gas Temperature (EGT Avg)', unit: '°C', modelled: simData.egtC, sigma: 1.5, minR: 200, maxR: 800, alLo: 350, alHi: 660 },
      { tag: 'TT-402', name: 'EGT Thermocouple Radial Spread', unit: '°C', modelled: 12.4, sigma: 0.6, minR: 0, maxR: 80, alLo: 0, alHi: 40 },
      { tag: 'ST-501', name: 'Main Rotor Shaft Rotational Speed', unit: 'RPM', modelled: simData.rpm, sigma: 0.5, minR: 0, maxR: 4000, alLo: 2950, alHi: 3060 },
      { tag: 'WT-601', name: 'Generator Gross Active Power Output', unit: 'MW', modelled: simData.powerMW, sigma: 0.4, minR: 0, maxR: 700, alLo: 20, alHi: 650 },
      { tag: 'VT-701', name: 'Compressor Front Bearing Vibration', unit: 'mm/s RMS', modelled: 2.1, sigma: 0.08, minR: 0, maxR: 20, alLo: 0, alHi: 7.1 },
      { tag: 'VT-702', name: 'Turbine Rear Bearing Vibration', unit: 'mm/s RMS', modelled: 2.8, sigma: 0.12, minR: 0, maxR: 20, alLo: 0, alHi: 7.1 },
      { tag: 'TT-701', name: 'Generator Drive-End Journal Bearing Temp', unit: '°C', modelled: 78.5, sigma: 0.4, minR: 20, maxR: 140, alLo: 40, alHi: 105 },
      { tag: 'AT-801', name: 'Exhaust Stack NOx Concentration @ 15% O2', unit: 'ppmvd', modelled: simData.noxPpm, sigma: 0.3, minR: 0, maxR: 100, alLo: 0, alHi: 25 },
      { tag: 'AT-802', name: 'Exhaust Stack CO Concentration @ 15% O2', unit: 'ppmvd', modelled: simData.coPpm, sigma: 0.2, minR: 0, maxR: 150, alLo: 0, alHi: 30 },
    ];

    return rawSensors.map((s, idx) => {
      let isStuck = false;
      const isDropout = false;
      let bias = 0;
      let drift = 0;

      // Fault injection handling
      if (injectedFaults.sensorStuckTag === s.tag) {
        isStuck = true;
      }
      if (injectedFaults.sensorDriftTag === s.tag) {
        bias = (s.modelled * (injectedFaults.biasPercent || 8.0)) / 100;
        drift = bias * 0.5;
      }

      // Box-Muller Gaussian noise
      const u1 = Math.max(1e-6, Math.random());
      const u2 = Math.random();
      const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      const noise = z0 * s.sigma;

      let measured = s.modelled + noise + bias + drift;
      if (isStuck) {
        measured = s.modelled * 0.92; // Frozen at fixed reading
      }

      const residual = measured - s.modelled;
      const residualPercent = Math.abs(residual / Math.max(1, s.modelled)) * 100;

      let quality: 'GOOD' | 'FAIR' | 'DEGRADED' | 'FAILED' | 'CALIBRATING' = 'GOOD';
      if (isStuck || isDropout) quality = 'FAILED';
      else if (residualPercent > 5.0) quality = 'DEGRADED';
      else if (residualPercent > 2.0) quality = 'FAIR';

      return {
        id: `sensor_${idx + 1}`,
        tag: s.tag,
        name: s.name,
        engineeringUnit: s.unit,
        measuredValue: measured,
        expectedNominalValue: s.modelled,
        modelledValue: s.modelled,
        residual,
        noiseSigma: s.sigma,
        bias,
        drift,
        isStuck,
        isDropout,
        quality,
        minRange: s.minR,
        maxRange: s.maxR,
        alarmLow: s.alLo,
        alarmHigh: s.alHi,
      };
    });
  }
}
