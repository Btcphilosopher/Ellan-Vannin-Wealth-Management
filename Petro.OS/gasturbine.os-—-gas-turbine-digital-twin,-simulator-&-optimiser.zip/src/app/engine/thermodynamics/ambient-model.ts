/**
 * GASTURBINE.OS — Ambient Atmosphere & Psychrometric Model
 * ISO standard reference, Hot/Cold weather extremes, altitude lapse rates.
 */

import { FluidComposition, UnitConverter } from './thermo-state';

export interface AmbientState {
  presetName: 'ISO_DAY' | 'HOT_DAY' | 'COLD_DAY' | 'HIGH_ALTITUDE' | 'CUSTOM';
  temperatureC: number;
  temperatureK: number;
  pressureBar: number;
  pressurePa: number;
  relativeHumidityPercent: number;
  altitudeM: number;
  windSpeedMS: number;
  airDensityKgM3: number;
  humidityRatioKgWaterKgDryAir: number;
  composition: FluidComposition;
}

export class AmbientModel {
  /**
   * Standard atmospheric pressure at altitude [Pa] using International Standard Atmosphere (ISA).
   */
  static getPressureAtAltitude(altitudeM: number, seaLevelPressurePa = 101325): number {
    // ISA formula for troposphere (< 11,000m)
    const T0 = 288.15;
    const L = 0.0065; // K/m temperature lapse rate
    const g = 9.80665;
    const M = 0.0289644;
    const R = 8.3144598;
    return seaLevelPressurePa * Math.pow(1 - (L * altitudeM) / T0, (g * M) / (R * L));
  }

  /**
   * Saturation vapor pressure of water [Pa] via Magnus-Tetens formula.
   */
  static getSaturationVaporPressure(tempC: number): number {
    return 610.78 * Math.exp((17.27 * tempC) / (tempC + 237.3));
  }

  /**
   * Computes dry air + water vapor composition based on relative humidity and pressure.
   */
  static createAmbientState(
    presetName: 'ISO_DAY' | 'HOT_DAY' | 'COLD_DAY' | 'HIGH_ALTITUDE' | 'CUSTOM',
    temperatureC = 15,
    pressureBar = 1.01325,
    relativeHumidityPercent = 60,
    altitudeM = 0,
    windSpeedMS = 2.5
  ): AmbientState {
    const temperatureK = UnitConverter.CToK(temperatureC);
    let pressurePa = UnitConverter.BarToPa(pressureBar);

    if (altitudeM > 0 && presetName === 'HIGH_ALTITUDE') {
      pressurePa = this.getPressureAtAltitude(altitudeM, pressurePa);
      pressureBar = UnitConverter.PaToBar(pressurePa);
    }

    // Psychrometrics
    const pSat = this.getSaturationVaporPressure(temperatureC);
    const pVapor = (relativeHumidityPercent / 100) * pSat;
    const pDry = Math.max(100, pressurePa - pVapor);

    // Molar fraction of water vapor:
    const x_H2O = Math.min(0.08, pVapor / pressurePa);
    const dryFraction = 1 - x_H2O;

    // Standard dry air components scaled:
    const comp: FluidComposition = {
      N2: 0.78084 * dryFraction,
      O2: 0.20946 * dryFraction,
      Ar: 0.00934 * dryFraction,
      CO2: 0.00042 * dryFraction,
      H2O: x_H2O,
      CH4: 0,
      H2: 0,
      CO: 0,
      C2H6: 0,
    };

    // Humidity ratio w = 0.62198 * pVapor / (p - pVapor)
    const humidityRatio = (0.62198 * pVapor) / pDry;

    // Air density [kg/m³]
    const R_dry = 287.058;
    const R_vapor = 461.495;
    const airDensityKgM3 = (pDry / (R_dry * temperatureK)) + (pVapor / (R_vapor * temperatureK));

    return {
      presetName,
      temperatureC,
      temperatureK,
      pressureBar,
      pressurePa,
      relativeHumidityPercent,
      altitudeM,
      windSpeedMS,
      airDensityKgM3,
      humidityRatioKgWaterKgDryAir: humidityRatio,
      composition: comp,
    };
  }

  static getPresets(): Record<string, AmbientState> {
    return {
      ISO_DAY: this.createAmbientState('ISO_DAY', 15, 1.01325, 60, 0, 2.0),
      HOT_DAY: this.createAmbientState('HOT_DAY', 35, 1.005, 40, 0, 3.5),
      COLD_DAY: this.createAmbientState('COLD_DAY', -10, 1.025, 80, 0, 4.0),
      HIGH_ALTITUDE: this.createAmbientState('HIGH_ALTITUDE', 10, 1.01325, 45, 1800, 5.0),
    };
  }
}
