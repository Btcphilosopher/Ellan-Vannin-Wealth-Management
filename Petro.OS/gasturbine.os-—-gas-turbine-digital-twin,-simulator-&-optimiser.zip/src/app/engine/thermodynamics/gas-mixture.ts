/**
 * GASTURBINE.OS — Gas Mixture Thermodynamics & Fuel Properties
 * Real gas mixture equations of state, polynomial heat capacity cp(T),
 * enthalpy h(T), entropy s(T), and stoichiometric combustion calculations.
 */

import { FluidComposition, ThermoStateData } from './thermo-state';

export interface FuelProperties {
  name: string;
  composition: FluidComposition;
  molarMassKgKmol: number;
  lhvMJkg: number;          // Lower Heating Value [MJ/kg]
  hhvMJkg: number;          // Higher Heating Value [MJ/kg]
  wobbeIndexMJNm3: number;  // Wobbe Index [MJ/Nm³]
  specificGravity: number;  // Relative to air
  stoichiometricAfr: number;// Stoichiometric Air-Fuel Ratio [kg air / kg fuel]
  h2VolPercent: number;     // Hydrogen volume percentage [%]
  ch4VolPercent: number;    // Methane volume percentage [%]
  densityNormalKgM3: number;// Normal density [kg/Nm³]
  maxFlameTempK: number;    // Adiabatic flame temp at stoichiometric [K]
}

// Molecular Weights [kg/kmol]
const MW: Record<keyof FluidComposition, number> = {
  N2: 28.0134,
  O2: 31.9988,
  CO2: 44.01,
  H2O: 18.0153,
  Ar: 39.948,
  CH4: 16.0425,
  H2: 2.016,
  CO: 28.01,
  C2H6: 30.07,
};

// Universal Gas Constant [kJ / kmol·K]
export const R_UNIVERSAL = 8.314462618;

// Reference dead state
export const T0_REF = 288.15; // 15°C [K]
export const P0_REF = 101325; // 1.01325 bar [Pa]

export class GasMixtureCalculator {
  /**
   * Computes molar mass of a gas mixture given molar fractions.
   */
  static getMolarMass(comp: FluidComposition): number {
    let mm = 0;
    for (const key of Object.keys(MW) as (keyof FluidComposition)[]) {
      mm += (comp[key] || 0) * MW[key];
    }
    return mm > 0 ? mm : 28.9647; // Default to air
  }

  /**
   * Computes specific gas constant R = R_u / M [kJ / kg·K]
   */
  static getSpecificGasConstant(comp: FluidComposition): number {
    return R_UNIVERSAL / this.getMolarMass(comp);
  }

  /**
   * High-accuracy temperature-dependent specific heat cp(T) [kJ/kg·K]
   * using NASA Shomate-type polynomials for individual species.
   */
  static getSpeciesCp(species: keyof FluidComposition, T: number): number {
    const t = T / 1000;
    switch (species) {
      case 'N2':
        // 300K - 2000K
        return (28.986 - 1.579 * t + 8.081 * t * t - 2.873 * t * t * t) / MW.N2;
      case 'O2':
        return (29.659 + 6.137 * t - 1.186 * t * t + 0.095 * t * t * t) / MW.O2;
      case 'CO2':
        return (24.997 + 55.187 * t - 33.691 * t * t + 7.948 * t * t * t) / MW.CO2;
      case 'H2O':
        return (30.092 + 6.832 * t + 6.793 * t * t - 2.534 * t * t * t) / MW.H2O;
      case 'Ar':
        return 20.786 / MW.Ar;
      case 'CH4':
        return (-0.703 + 108.479 * t - 42.521 * t * t + 5.862 * t * t * t) / MW.CH4;
      case 'H2':
        return (33.066 - 11.363 * t + 11.432 * t * t - 2.772 * t * t * t) / MW.H2;
      case 'CO':
        return (25.567 + 6.096 * t + 4.054 * t * t - 2.671 * t * t * t) / MW.CO;
      case 'C2H6':
        return (5.0 + 170.0 * t - 65.0 * t * t) / MW.C2H6;
      default:
        return 1.005; // Air fallback
    }
  }

  /**
   * Mixture cp(T) [kJ/kg·K] based on mass fractions.
   */
  static getMixtureCp(comp: FluidComposition, T: number): number {
    const M_mix = this.getMolarMass(comp);
    let cp_molar = 0;
    for (const key of Object.keys(MW) as (keyof FluidComposition)[]) {
      const xi = comp[key] || 0;
      if (xi > 0) {
        const cp_spec = this.getSpeciesCp(key, T);
        cp_molar += xi * (cp_spec * MW[key]);
      }
    }
    return cp_molar / M_mix;
  }

  /**
   * Specific enthalpy h(T) [kJ/kg] integrated from T0_REF to T.
   */
  static getMixtureEnthalpy(comp: FluidComposition, T: number): number {
    const steps = 10;
    const dT = (T - T0_REF) / steps;
    let h = 0;
    for (let i = 0; i < steps; i++) {
      const T_mid = T0_REF + (i + 0.5) * dT;
      h += this.getMixtureCp(comp, T_mid) * dT;
    }
    return h;
  }

  /**
   * Specific entropy s(T, P) [kJ/kg·K] referenced to T0_REF, P0_REF.
   */
  static getMixtureEntropy(comp: FluidComposition, T: number, P: number): number {
    const R = this.getSpecificGasConstant(comp);
    const steps = 10;
    const dT = (T - T0_REF) / steps;
    let s_T = 0;
    for (let i = 0; i < steps; i++) {
      const T_mid = T0_REF + (i + 0.5) * dT;
      s_T += (this.getMixtureCp(comp, T_mid) / T_mid) * dT;
    }
    const s_P = -R * Math.log(Math.max(P, 100) / P0_REF);
    return s_T + s_P;
  }

  /**
   * Creates a full ThermoStateData point.
   */
  static computeState(
    id: string,
    name: string,
    station: string,
    temperatureK: number,
    pressurePa: number,
    massFlowKgS: number,
    composition: FluidComposition
  ): ThermoStateData {
    const R = this.getSpecificGasConstant(composition);
    const cp = this.getMixtureCp(composition, temperatureK);
    const cv = cp - R;
    const gamma = cp / cv;
    const density = pressurePa / (R * 1000 * temperatureK);
    const specificVolume = 1 / density;
    const enthalpy = this.getMixtureEnthalpy(composition, temperatureK);
    const internalEnergy = enthalpy - (pressurePa * specificVolume) / 1000;
    const entropy = this.getMixtureEntropy(composition, temperatureK, pressurePa);

    // Physical exergy: e_ph = (h - h0) - T0*(s - s0)
    const h0 = this.getMixtureEnthalpy(composition, T0_REF);
    const s0 = this.getMixtureEntropy(composition, T0_REF, P0_REF);
    const physicalExergyKJkg = (enthalpy - h0) - T0_REF * (entropy - s0);
    const totalExergyMW = (massFlowKgS * Math.max(0, physicalExergyKJkg)) / 1000;

    return {
      id,
      name,
      station,
      temperatureK,
      pressurePa,
      enthalpyKJkg: enthalpy,
      entropyKJkgK: entropy,
      densityKgM3: density,
      specificVolumeM3Kg: specificVolume,
      internalEnergyKJkg: internalEnergy,
      cpKJkgK: cp,
      cvKJkgK: cv,
      gamma,
      gasConstantKJkgK: R,
      massFlowKgS,
      composition,
      physicalExergyKJkg,
      totalExergyMW,
    };
  }

  /**
   * Calculates fuel mixture properties including Wobbe index and LHV.
   */
  static calculateFuelProperties(
    name: string,
    composition: FluidComposition
  ): FuelProperties {
    const M_mix = this.getMolarMass(composition);
    const M_air = 28.9647;
    const specificGravity = M_mix / M_air;

    // Heating values per mole [MJ/kmol]
    // CH4: 802.3 MJ/kmol LHV, 890.8 MJ/kmol HHV
    // H2:  241.8 MJ/kmol LHV, 285.8 MJ/kmol HHV
    // CO:  283.0 MJ/kmol LHV, 283.0 MJ/kmol HHV
    // C2H6: 1428 MJ/kmol LHV, 1560 MJ/kmol HHV
    const x_CH4 = composition.CH4 || 0;
    const x_H2 = composition.H2 || 0;
    const x_CO = composition.CO || 0;
    const x_C2H6 = composition.C2H6 || 0;

    const lhvMolar = x_CH4 * 802.3 + x_H2 * 241.8 + x_CO * 283.0 + x_C2H6 * 1428.0;
    const hhvMolar = x_CH4 * 890.8 + x_H2 * 285.8 + x_CO * 283.0 + x_C2H6 * 1560.0;

    const lhvMJkg = lhvMolar / M_mix;
    const hhvMJkg = hhvMolar / M_mix;

    // Normal volume = 22.414 Nm³/kmol
    const densityNormalKgM3 = M_mix / 22.414;
    const lhvVolumetricMJNm3 = lhvMolar / 22.414;
    const wobbeIndexMJNm3 = lhvVolumetricMJNm3 / Math.sqrt(Math.max(0.01, specificGravity));

    // Stoichiometric air-fuel ratio:
    // CH4 + 2 O2 -> CO2 + 2 H2O (2 mol O2 / mol CH4)
    // H2 + 0.5 O2 -> H2O (0.5 mol O2 / mol H2)
    // CO + 0.5 O2 -> CO2 (0.5 mol O2 / mol CO)
    // C2H6 + 3.5 O2 -> 2 CO2 + 3 H2O (3.5 mol O2 / mol C2H6)
    const O2_mols_required = x_CH4 * 2.0 + x_H2 * 0.5 + x_CO * 0.5 + x_C2H6 * 3.5 - (composition.O2 || 0);
    const air_mols_required = O2_mols_required / 0.20946; // Air is 20.946% O2
    const stoichiometricAfr = (air_mols_required * M_air) / M_mix;

    // Adiabatic flame temp estimation (K)
    const maxFlameTempK = 2220 + x_H2 * 120 - (composition.CO2 || 0) * 400;

    return {
      name,
      composition,
      molarMassKgKmol: M_mix,
      lhvMJkg,
      hhvMJkg,
      wobbeIndexMJNm3,
      specificGravity,
      stoichiometricAfr: Math.max(1, stoichiometricAfr),
      h2VolPercent: x_H2 * 100,
      ch4VolPercent: x_CH4 * 100,
      densityNormalKgM3,
      maxFlameTempK,
    };
  }

  /**
   * Computes combustion products composition given air and fuel composition
   * and air-to-fuel ratio (AFR).
   */
  static computeCombustionProducts(
    airComp: FluidComposition,
    fuelComp: FluidComposition,
    actualAfr: number
  ): FluidComposition {
    const M_air = this.getMolarMass(airComp);
    const M_fuel = this.getMolarMass(fuelComp);

    // Moles of fuel = 1 / M_fuel, moles of air = actualAfr / M_air
    const n_f = 1 / M_fuel;
    const n_a = actualAfr / M_air;

    const x_CH4 = fuelComp.CH4 || 0;
    const x_H2 = fuelComp.H2 || 0;
    const x_CO = fuelComp.CO || 0;
    const x_C2H6 = fuelComp.C2H6 || 0;

    // Reactants elemental breakdown:
    const n_C = n_f * (x_CH4 + x_CO + 2 * x_C2H6) + n_a * (airComp.CO2 || 0);
    const n_H = n_f * (4 * x_CH4 + 2 * x_H2 + 6 * x_C2H6) + n_a * 2 * (airComp.H2O || 0);
    const n_O_in = n_a * 2 * (airComp.O2 || 0) + n_f * (fuelComp.O2 ? 2 * fuelComp.O2 : 0) + n_f * (x_CO || 0);
    const n_N2_in = n_a * (airComp.N2 || 0) + n_f * (fuelComp.N2 || 0);
    const n_Ar_in = n_a * (airComp.Ar || 0);

    // Complete combustion products:
    const n_CO2 = n_C;
    const n_H2O = n_H / 2;
    const n_O2 = Math.max(0.001, (n_O_in - 2 * n_CO2 - n_H2O) / 2);
    const n_N2 = n_N2_in;
    const n_Ar = n_Ar_in;

    const total_moles = n_CO2 + n_H2O + n_O2 + n_N2 + n_Ar;

    return {
      N2: n_N2 / total_moles,
      O2: n_O2 / total_moles,
      CO2: n_CO2 / total_moles,
      H2O: n_H2O / total_moles,
      Ar: n_Ar / total_moles,
      CH4: 0,
      H2: 0,
      CO: 0,
      C2H6: 0,
    };
  }
}
