/**
 * GASTURBINE.OS — Thermodynamic State Definition & Physical Units
 * Rigorous thermodynamic properties tracking with SI base representation
 * and explicit unit conversion.
 */

export interface FluidComposition {
  N2: number;   // Molar fraction
  O2: number;
  CO2: number;
  H2O: number;
  Ar: number;
  CH4: number;
  H2: number;
  CO: number;
  C2H6: number;
}

export interface ThermoStateData {
  id: string;
  name: string;
  station: string;          // e.g., '0' (Ambient), '1' (Inlet), '2' (CDP), '3' (TIT), '4' (EGT)
  temperatureK: number;     // Kelvin [K]
  pressurePa: number;       // Pascal [Pa]
  enthalpyKJkg: number;     // Specific enthalpy [kJ/kg]
  entropyKJkgK: number;     // Specific entropy [kJ/kg·K]
  densityKgM3: number;      // Density [kg/m³]
  specificVolumeM3Kg: number; // Specific volume [m³/kg]
  internalEnergyKJkg: number; // Internal energy [kJ/kg]
  cpKJkgK: number;          // Specific heat at constant pressure [kJ/kg·K]
  cvKJkgK: number;          // Specific heat at constant volume [kJ/kg·K]
  gamma: number;            // Specific heat ratio cp / cv
  gasConstantKJkgK: number; // Specific gas constant R [kJ/kg·K]
  massFlowKgS: number;      // Mass flow rate [kg/s]
  composition: FluidComposition;
  physicalExergyKJkg: number; // Specific physical exergy [kJ/kg]
  totalExergyMW: number;     // Total exergy rate [MW]
}

export class UnitConverter {
  // Pressure
  static PaToBar(pa: number): number { return pa / 100000; }
  static BarToPa(bar: number): number { return bar * 100000; }
  static PaToKPa(pa: number): number { return pa / 1000; }
  static KPaToPa(kpa: number): number { return kpa * 1000; }
  static PaToPsi(pa: number): number { return pa * 0.0001450377; }
  static PsiToPa(psi: number): number { return psi / 0.0001450377; }

  // Temperature
  static KToC(k: number): number { return k - 273.15; }
  static CToK(c: number): number { return c + 273.15; }
  static KToF(k: number): number { return (k - 273.15) * 1.8 + 32; }

  // Energy & Power
  static JToKJ(j: number): number { return j / 1000; }
  static KJToJ(kj: number): number { return kj * 1000; }
  static WToMW(w: number): number { return w / 1e6; }
  static MWToKW(mw: number): number { return mw * 1000; }
  static KWToMW(kw: number): number { return kw / 1000; }
  static MWToHP(mw: number): number { return mw * 1341.02; }

  // Heat Rate
  static KJPerKWhToBtuPerKWh(kjKwh: number): number { return kjKwh * 0.947817; }
  static BtuPerKWhToKJPerKWh(btuKwh: number): number { return btuKwh / 0.947817; }

  // Mass Flow
  static KgSToKgH(kgs: number): number { return kgs * 3600; }
  static KgSToLbS(kgs: number): number { return kgs * 2.20462; }
}

export function createStandardAirComposition(): FluidComposition {
  return {
    N2: 0.78084,
    O2: 0.20946,
    CO2: 0.00042,
    H2O: 0.00994, // Standard 60% RH at 15°C
    Ar: 0.00934,
    CH4: 0,
    H2: 0,
    CO: 0,
    C2H6: 0,
  };
}

export function createNaturalGasComposition(): FluidComposition {
  return {
    N2: 0.015,
    O2: 0,
    CO2: 0.010,
    H2O: 0,
    Ar: 0,
    CH4: 0.945,
    H2: 0,
    CO: 0,
    C2H6: 0.030,
  };
}
