/**
 * GASTURBINE.OS — Gas Turbine Thermodynamic Cycle Solver
 * Solves coupled Brayton cycle, First-Law mass/energy balances,
 * heat rate, efficiencies, emissions, and combined-cycle extension.
 */

import { AmbientState } from '../thermodynamics/ambient-model';
import { FuelProperties, GasMixtureCalculator } from '../thermodynamics/gas-mixture';
import { FluidComposition, ThermoStateData, UnitConverter } from '../thermodynamics/thermo-state';
import { CombustorModel, CompressorModel, CompressorStage, InletModel, TurbineModel, TurbineStage } from '../components/turbine-components';

export interface TurbineConfig {
  name: string;
  classType: 'MICROTURBINE' | 'AERODERIVATIVE' | 'INDUSTRIAL' | 'HEAVY_DUTY' | 'F_CLASS' | 'H_CLASS';
  compressorStages: number;
  turbineStages: number;
  designPressureRatio: number;
  designAirMassFlowKgS: number;
  designFiringTempK: number; // TIT (e.g. 1773.15 K / 1500°C for F-class)
  compressorIsentropicEta: number;
  turbineIsentropicEta: number;
  combustorEfficiency: number;
  combustorPressureLossFraction: number;
  shaftMechanicalEta: number;
  generatorElectricalEta: number;
  ratedPowerMW: number;
  ratedShaftSpeedRpm: number;
  allowHydrogenBlend: boolean;
}

export interface EmissionsBreakdown {
  co2RateKgH: number;
  co2SpecificGPerKWh: number;
  noxPpmvd15O2: number;
  noxRateKgH: number;
  coPpmvd15O2: number;
  uhcPpmvd15O2: number;
}

export interface EnergyBalance {
  fuelEnergyInputMW: number;     // LHV basis
  airSensibleEnthalpyInMW: number;
  totalEnergyInMW: number;
  netElectricalPowerMW: number;
  compressorWorkMW: number;
  turbineGrossPowerMW: number;
  shaftMechanicalLossMW: number;
  generatorElectricalLossMW: number;
  combustorHeatLossMW: number;
  exhaustSensibleLossMW: number;
  totalEnergyOutMW: number;
  residualErrorMW: number;
  residualPercent: number;
  isConserved: boolean;          // true if residual < 0.05%
}

export interface CombinedCycleState {
  enabled: boolean;
  hrsgHpSteamTempC: number;
  hrsgHpSteamPressureBar: number;
  hrsgSteamFlowKgS: number;
  steamTurbinePowerMW: number;
  totalCombinedPowerMW: number;
  combinedEfficiencyPercent: number;
  combinedHeatRateKJKWh: number;
}

export interface CycleSimulationResult {
  id: string;
  timestamp: string;
  config: TurbineConfig;
  ambient: AmbientState;
  fuel: FuelProperties;
  loadFraction: number; // 0.2 to 1.05
  igvAngleDeg: number;  // -10° to +15°
  
  // Thermodynamic Station States
  state0_ambient: ThermoStateData;
  state1_inlet: ThermoStateData;
  state2_cdp: ThermoStateData;
  state3_tit: ThermoStateData;
  state4_egt: ThermoStateData;

  // Component Breakdowns
  compressorStages: CompressorStage[];
  turbineStages: TurbineStage[];
  compressorPowerMW: number;
  turbineGrossPowerMW: number;
  shaftMechanicalPowerMW: number;
  netElectricalPowerMW: number;

  // Key Efficiencies & Performance
  thermalEfficiencyPercent: number;
  compressorEfficiencyPercent: number;
  combustorEfficiencyPercent: number;
  turbineEfficiencyPercent: number;
  shaftEfficiencyPercent: number;
  generatorEfficiencyPercent: number;

  // Heat Rates
  grossHeatRateKJKWh_LHV: number;
  netHeatRateKJKWh_LHV: number;
  netHeatRateKJKWh_HHV: number;
  netHeatRateBtuKWh: number;
  specificFuelConsumptionGPerKWh: number;

  // Flows & Combustion
  fuelFlowKgS: number;
  airMassFlowKgS: number;
  airFuelRatio: number;
  equivalenceRatio: number;
  surgeMarginPercent: number;
  correctedAirFlowKgS: number;

  // Degradation states applied
  compressorFoulingPercent: number;
  turbineDegradationPercent: number;
  inletFilterLossPercent: number;

  // Balances & Emissions
  energyBalance: EnergyBalance;
  emissions: EmissionsBreakdown;
  combinedCycle: CombinedCycleState;
}

export class CycleSolver {
  static solve(
    config: TurbineConfig,
    ambient: AmbientState,
    fuelComp: FluidComposition,
    loadFraction = 1.0,
    igvAngleDeg = 0.0,
    compressorFoulingFraction = 0.0,
    turbineDegradationFraction = 0.0,
    filterFoulingFactor = 1.0,
    enableCombinedCycle = false
  ): CycleSimulationResult {
    // 1. Ambient State 0
    const state0 = GasMixtureCalculator.computeState(
      'state_0',
      'Ambient Air',
      '0',
      ambient.temperatureK,
      ambient.pressurePa,
      config.designAirMassFlowKgS,
      ambient.composition
    );

    // 2. Inlet & IGV Modulation (IGV changes air mass flow: ~ +1.2% per degree)
    const igvFlowMultiplier = 1.0 + (igvAngleDeg * 0.012);
    // Part-load air flow modulation (modern GTs use IGVs to hold EGT high at part-load down to ~60%)
    let partLoadFlowFactor = 1.0;
    if (loadFraction < 1.0) {
      partLoadFlowFactor = Math.max(0.45, 0.55 + 0.45 * loadFraction);
    }

    const effectiveDesignFlow = config.designAirMassFlowKgS * igvFlowMultiplier * partLoadFlowFactor;
    const inletResult = InletModel.compute(ambient, effectiveDesignFlow, filterFoulingFactor);

    // 3. Compressor (PR scales with load & speed)
    const effectivePr = config.designPressureRatio * (0.35 + 0.65 * loadFraction);
    const compressorResult = CompressorModel.compute(
      inletResult.state1,
      effectivePr,
      config.compressorIsentropicEta,
      config.compressorStages,
      config.ratedShaftSpeedRpm,
      compressorFoulingFraction
    );

    // 4. Combustor & Target TIT (TIT modulates with load)
    const maxTit = config.designFiringTempK;
    const baseTit = 1100; // Idle TIT ~ 827°C (1100 K)
    const targetTit = baseTit + (maxTit - baseTit) * Math.pow(loadFraction, 0.75);

    const combustorResult = CombustorModel.compute(
      compressorResult.state2,
      fuelComp,
      targetTit,
      config.combustorEfficiency,
      config.combustorPressureLossFraction
    );

    // 5. Turbine Expansion
    const exhaustPressurePa = ambient.pressurePa + 3500; // ~35 mbar exhaust diffuser backpressure
    const turbineResult = TurbineModel.compute(
      combustorResult.state3,
      exhaustPressurePa,
      config.turbineIsentropicEta,
      config.turbineStages,
      turbineDegradationFraction
    );

    // 6. Shaft & Generator Power
    const grossTurbinePower = turbineResult.powerMW;
    const compressorPower = compressorResult.powerMW;
    const shaftMechanicalPower = Math.max(0, (grossTurbinePower - compressorPower) * config.shaftMechanicalEta);
    const shaftLossMW = (grossTurbinePower - compressorPower) * (1 - config.shaftMechanicalEta);

    const netElectricalPowerMW = shaftMechanicalPower * config.generatorElectricalEta;
    const genLossMW = shaftMechanicalPower * (1 - config.generatorElectricalEta);

    // 7. Fuel & Efficiencies
    const fuelProps = GasMixtureCalculator.calculateFuelProperties('Fuel', fuelComp);
    const fuelEnergyMW = combustorResult.fuelFlowKgS * fuelProps.lhvMJkg; // LHV
    const fuelEnergyHHVMW = combustorResult.fuelFlowKgS * fuelProps.hhvMJkg; // HHV

    const thermalEfficiencyPercent = fuelEnergyMW > 0 ? (netElectricalPowerMW / fuelEnergyMW) * 100 : 0;

    // 8. Heat Rates [kJ/kWh]
    const netHeatRateKJKWh_LHV = netElectricalPowerMW > 0 ? (fuelEnergyMW * 3600) / netElectricalPowerMW : 0;
    const netHeatRateKJKWh_HHV = netElectricalPowerMW > 0 ? (fuelEnergyHHVMW * 3600) / netElectricalPowerMW : 0;
    const grossHeatRateKJKWh_LHV = shaftMechanicalPower > 0 ? (fuelEnergyMW * 3600) / shaftMechanicalPower : 0;
    const netHeatRateBtuKWh = UnitConverter.KJPerKWhToBtuPerKWh(netHeatRateKJKWh_LHV);
    const specificFuelConsumptionGPerKWh = netElectricalPowerMW > 0
      ? (combustorResult.fuelFlowKgS * 3600 * 1000) / (netElectricalPowerMW * 1000)
      : 0;

    // 9. Emissions Models
    // CO2 from carbon balance
    const c_mass_fraction = (fuelProps.ch4VolPercent * 0.7487) / 100;
    const co2RateKgH = combustorResult.fuelFlowKgS * 3600 * c_mass_fraction * (44.01 / 12.011);
    const co2SpecificGPerKWh = netElectricalPowerMW > 0 ? (co2RateKgH * 1000) / (netElectricalPowerMW * 1000) : 0;

    // NOx empirical correlation with flame temperature: NOx ~ A * exp(B * T_flame)
    const flameTempC = UnitConverter.KToC(combustorResult.flameTempK);
    const noxPpmvd15O2 = Math.max(3.5, 2.5 * Math.exp(0.0035 * (flameTempC - 1200)) * (1 + fuelProps.h2VolPercent * 0.015));
    const noxRateKgH = (noxPpmvd15O2 * 1e-6 * combustorResult.state3.massFlowKgS * 3600 * 46.0055) / 28.9;

    // CO increases significantly below 60% load due to lower flame temp
    const coPpmvd15O2 = loadFraction < 0.65
      ? Math.min(80, 5 + 75 * Math.pow((0.65 - loadFraction) / 0.45, 2))
      : 3.2;

    const uhcPpmvd15O2 = loadFraction < 0.6 ? 4.5 * (0.6 - loadFraction) * 10 : 1.2;

    // 10. Energy Balance
    const airSensibleMW = (inletResult.state1.massFlowKgS * inletResult.state1.enthalpyKJkg) / 1000;
    const totalInMW = fuelEnergyMW + airSensibleMW;
    const exhaustSensibleMW = (turbineResult.state4.massFlowKgS * turbineResult.state4.enthalpyKJkg) / 1000;
    const totalOutMW = netElectricalPowerMW + exhaustSensibleMW + combustorResult.combustorLossMW + shaftLossMW + genLossMW;
    const residualMW = totalInMW - totalOutMW;
    const residualPercent = Math.abs(residualMW / Math.max(1, totalInMW)) * 100;

    const energyBalance: EnergyBalance = {
      fuelEnergyInputMW: fuelEnergyMW,
      airSensibleEnthalpyInMW: airSensibleMW,
      totalEnergyInMW: totalInMW,
      netElectricalPowerMW,
      compressorWorkMW: compressorPower,
      turbineGrossPowerMW: grossTurbinePower,
      shaftMechanicalLossMW: shaftLossMW,
      generatorElectricalLossMW: genLossMW,
      combustorHeatLossMW: combustorResult.combustorLossMW,
      exhaustSensibleLossMW: exhaustSensibleMW,
      totalEnergyOutMW: totalOutMW,
      residualErrorMW: residualMW,
      residualPercent,
      isConserved: residualPercent < 0.05,
    };

    // 11. Combined Cycle HRSG Extension
    const egtC = UnitConverter.KToC(turbineResult.state4.temperatureK);
    let steamPowerMW = 0;
    let combinedPowerMW = netElectricalPowerMW;
    let combinedEfficiency = thermalEfficiencyPercent;
    let combinedHeatRate = netHeatRateKJKWh_LHV;

    if (enableCombinedCycle && egtC > 350) {
      // HRSG recovers heat from EGT down to stack temp ~ 90°C
      const deltaT_hrsg = Math.max(0, egtC - 95);
      const heatRecoveredMW = (turbineResult.state4.massFlowKgS * 1.12 * deltaT_hrsg) / 1000;
      const steamCycleEta = 0.36; // Modern Rankine cycle efficiency ~ 36%
      steamPowerMW = heatRecoveredMW * steamCycleEta;
      combinedPowerMW = netElectricalPowerMW + steamPowerMW;
      combinedEfficiency = fuelEnergyMW > 0 ? (combinedPowerMW / fuelEnergyMW) * 100 : 0;
      combinedHeatRate = combinedPowerMW > 0 ? (fuelEnergyMW * 3600) / combinedPowerMW : 0;
    }

    const combinedCycle: CombinedCycleState = {
      enabled: enableCombinedCycle,
      hrsgHpSteamTempC: Math.min(565, egtC - 25),
      hrsgHpSteamPressureBar: 125,
      hrsgSteamFlowKgS: (turbineResult.state4.massFlowKgS * 0.14),
      steamTurbinePowerMW: steamPowerMW,
      totalCombinedPowerMW: combinedPowerMW,
      combinedEfficiencyPercent: combinedEfficiency,
      combinedHeatRateKJKWh: combinedHeatRate,
    };

    return {
      id: `sim_${Date.now()}`,
      timestamp: new Date().toISOString(),
      config,
      ambient,
      fuel: fuelProps,
      loadFraction,
      igvAngleDeg,
      state0_ambient: state0,
      state1_inlet: inletResult.state1,
      state2_cdp: compressorResult.state2,
      state3_tit: combustorResult.state3,
      state4_egt: turbineResult.state4,
      compressorStages: compressorResult.stages,
      turbineStages: turbineResult.stages,
      compressorPowerMW: compressorPower,
      turbineGrossPowerMW: grossTurbinePower,
      shaftMechanicalPowerMW: shaftMechanicalPower,
      netElectricalPowerMW,
      thermalEfficiencyPercent,
      compressorEfficiencyPercent: config.compressorIsentropicEta * (1 - compressorFoulingFraction * 0.7) * 100,
      combustorEfficiencyPercent: config.combustorEfficiency * 100,
      turbineEfficiencyPercent: config.turbineIsentropicEta * (1 - turbineDegradationFraction * 0.8) * 100,
      shaftEfficiencyPercent: config.shaftMechanicalEta * 100,
      generatorEfficiencyPercent: config.generatorElectricalEta * 100,
      grossHeatRateKJKWh_LHV: grossHeatRateKJKWh_LHV,
      netHeatRateKJKWh_LHV,
      netHeatRateKJKWh_HHV,
      netHeatRateBtuKWh,
      specificFuelConsumptionGPerKWh,
      fuelFlowKgS: combustorResult.fuelFlowKgS,
      airMassFlowKgS: inletResult.massFlowKgS,
      airFuelRatio: combustorResult.airFuelRatio,
      equivalenceRatio: combustorResult.equivalenceRatio,
      surgeMarginPercent: compressorResult.surgeMargin,
      correctedAirFlowKgS: compressorResult.correctedFlow,
      compressorFoulingPercent: compressorFoulingFraction * 100,
      turbineDegradationPercent: turbineDegradationFraction * 100,
      inletFilterLossPercent: inletResult.pressureLossPercent,
      energyBalance,
      emissions: {
        co2RateKgH,
        co2SpecificGPerKWh,
        noxPpmvd15O2,
        noxRateKgH,
        coPpmvd15O2,
        uhcPpmvd15O2,
      },
      combinedCycle,
    };
  }
}
