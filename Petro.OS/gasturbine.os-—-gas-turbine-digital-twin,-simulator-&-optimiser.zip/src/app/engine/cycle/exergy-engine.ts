/**
 * GASTURBINE.OS — Second-Law & Exergy Engine
 * Computes physical & chemical exergies, exergy destruction (irreversibility)
 * per component, exergy efficiencies, and Sankey diagram flow balances.
 */

import { CycleSimulationResult } from './cycle-solver';

export interface ExergyComponentDestruction {
  componentName: string;
  stationIn: string;
  stationOut: string;
  exergyInMW: number;
  exergyOutMW: number;
  exergyDestructionMW: number;
  exergyLossMW: number;
  exergyEfficiencyPercent: number;
  percentOfTotalDestruction: number;
  thermodynamicCause: string;
}

export interface ExergyAnalysisResult {
  fuelTotalExergyMW: number;       // Chemical + Physical exergy of fuel
  fuelChemicalExergyMW: number;
  netExergyOutputMW: number;       // Electrical net power output
  totalExergyDestructionMW: number;
  overallExergyEfficiencyPercent: number;
  components: ExergyComponentDestruction[];
  sankeyNodes: { id: string; label: string; color: string }[];
  sankeyLinks: { source: string; target: string; value: number; label: string }[];
}

export class ExergyEngine {
  static analyze(cycle: CycleSimulationResult): ExergyAnalysisResult {
    const T0 = cycle.ambient.temperatureK; // Local dead-state temperature

    // Chemical exergy of fuel: e_ch = phi_fuel * LHV (phi ~ 1.04 for methane/natural gas)
    const phi_fuel = 1.04 + 0.01 * (cycle.fuel.h2VolPercent / 100);
    const fuelLhvMW = cycle.fuelFlowKgS * cycle.fuel.lhvMJkg;
    const fuelChemicalExergyMW = fuelLhvMW * phi_fuel;
    const fuelTotalExergyMW = fuelChemicalExergyMW;

    // Station Exergy Flows [MW]: E_x = m * [ (h - h0) - T0 * (s - s0) ]
    const Ex_0 = cycle.state0_ambient.totalExergyMW; // ~ 0 MW relative to dead state
    const Ex_1 = cycle.state1_inlet.totalExergyMW;
    const Ex_2 = cycle.state2_cdp.totalExergyMW;
    const Ex_3 = cycle.state3_tit.totalExergyMW;
    const Ex_4 = cycle.state4_egt.totalExergyMW;

    // 1. Inlet Exergy Destruction (Pressure drop dissipation)
    const Ed_inlet = Math.max(0.01, (Ex_0 - Ex_1) + (cycle.airMassFlowKgS * T0 * (cycle.state1_inlet.entropyKJkgK - cycle.state0_ambient.entropyKJkgK)) / 1000);
    const eta_ex_inlet = Ex_0 > 0 ? (Ex_1 / Ex_0) * 100 : 99.5;

    // 2. Compressor Exergy Destruction: Ed_c = W_c - (Ex_2 - Ex_1)
    const W_c = cycle.compressorPowerMW;
    const dEx_c = Ex_2 - Ex_1;
    const Ed_c = Math.max(0.1, W_c - dEx_c);
    const eta_ex_c = W_c > 0 ? (dEx_c / W_c) * 100 : 90;

    // 3. Combustor Exergy Destruction: Ed_comb = Ex_fuel + Ex_2 - Ex_3
    const Ed_comb = Math.max(1.0, fuelTotalExergyMW + Ex_2 - Ex_3);
    const eta_ex_comb = (fuelTotalExergyMW + Ex_2) > 0 ? (Ex_3 / (fuelTotalExergyMW + Ex_2)) * 100 : 70;

    // 4. Turbine Exergy Destruction: Ed_t = (Ex_3 - Ex_4) - W_t_gross
    const W_t = cycle.turbineGrossPowerMW;
    const dEx_t = Ex_3 - Ex_4;
    const Ed_t = Math.max(0.1, dEx_t - W_t);
    const eta_ex_t = dEx_t > 0 ? (W_t / dEx_t) * 100 : 92;

    // 5. Generator & Shaft Exergy Destruction: Mechanical + Electrical friction
    const Ed_gen = Math.max(0.05, (W_t - W_c) - cycle.netElectricalPowerMW);
    const eta_ex_gen = (W_t - W_c) > 0 ? (cycle.netElectricalPowerMW / (W_t - W_c)) * 100 : 97.6;

    // 6. Exhaust Exergy Loss (Lost to ambient atmosphere)
    const Ed_exhaust = Ex_4;

    const totalDestructionMW = Ed_inlet + Ed_c + Ed_comb + Ed_t + Ed_gen + Ed_exhaust;

    const components: ExergyComponentDestruction[] = [
      {
        componentName: 'Inlet System',
        stationIn: '0',
        stationOut: '1',
        exergyInMW: Ex_0,
        exergyOutMW: Ex_1,
        exergyDestructionMW: Ed_inlet,
        exergyLossMW: 0,
        exergyEfficiencyPercent: eta_ex_inlet,
        percentOfTotalDestruction: (Ed_inlet / totalDestructionMW) * 100,
        thermodynamicCause: 'Filter pressure drop dissipation & air throttling',
      },
      {
        componentName: 'Compressor',
        stationIn: '1',
        stationOut: '2',
        exergyInMW: Ex_1 + W_c,
        exergyOutMW: Ex_2,
        exergyDestructionMW: Ed_c,
        exergyLossMW: 0,
        exergyEfficiencyPercent: eta_ex_c,
        percentOfTotalDestruction: (Ed_c / totalDestructionMW) * 100,
        thermodynamicCause: 'Blade boundary layer fluid friction & aerodynamic shock losses',
      },
      {
        componentName: 'Combustor',
        stationIn: '2',
        stationOut: '3',
        exergyInMW: Ex_2 + fuelTotalExergyMW,
        exergyOutMW: Ex_3,
        exergyDestructionMW: Ed_comb,
        exergyLossMW: cycle.energyBalance.combustorHeatLossMW,
        exergyEfficiencyPercent: eta_ex_comb,
        percentOfTotalDestruction: (Ed_comb / totalDestructionMW) * 100,
        thermodynamicCause: 'Uncontrolled chemical reaction, huge internal temperature gradients & species mixing',
      },
      {
        componentName: 'Turbine Expander',
        stationIn: '3',
        stationOut: '4',
        exergyInMW: Ex_3,
        exergyOutMW: Ex_4 + W_t,
        exergyDestructionMW: Ed_t,
        exergyLossMW: 0,
        exergyEfficiencyPercent: eta_ex_t,
        percentOfTotalDestruction: (Ed_t / totalDestructionMW) * 100,
        thermodynamicCause: 'Aerodynamic blade profile losses, secondary flow leakage & cooling air mixing',
      },
      {
        componentName: 'Shaft & Generator',
        stationIn: 'Shaft',
        stationOut: 'Grid',
        exergyInMW: W_t - W_c,
        exergyOutMW: cycle.netElectricalPowerMW,
        exergyDestructionMW: Ed_gen,
        exergyLossMW: 0,
        exergyEfficiencyPercent: eta_ex_gen,
        percentOfTotalDestruction: (Ed_gen / totalDestructionMW) * 100,
        thermodynamicCause: 'Bearing mechanical shear friction & generator copper/iron magnetic hysteresis',
      },
      {
        componentName: 'Exhaust Stack',
        stationIn: '4',
        stationOut: 'Atmosphere',
        exergyInMW: Ex_4,
        exergyOutMW: 0,
        exergyDestructionMW: Ed_exhaust,
        exergyLossMW: Ed_exhaust,
        exergyEfficiencyPercent: 0,
        percentOfTotalDestruction: (Ed_exhaust / totalDestructionMW) * 100,
        thermodynamicCause: 'Thermal dissipation of hot flue gases rejected into surrounding ambient dead-state',
      },
    ];

    const overallExergyEfficiencyPercent = (cycle.netElectricalPowerMW / fuelTotalExergyMW) * 100;

    // Sankey Flow Diagram representation
    const sankeyNodes = [
      { id: 'fuel', label: 'Fuel Exergy', color: '#f59e0b' },
      { id: 'combustor', label: 'Combustor', color: '#ef4444' },
      { id: 'compressor', label: 'Compressor', color: '#06b6d4' },
      { id: 'turbine', label: 'Turbine', color: '#3b82f6' },
      { id: 'generator', label: 'Generator', color: '#10b981' },
      { id: 'grid', label: 'Net Power (Grid)', color: '#10b981' },
      { id: 'ed_comb', label: 'Combustion Irreversibility', color: '#64748b' },
      { id: 'ed_turb', label: 'Turbine Losses', color: '#64748b' },
      { id: 'ed_comp', label: 'Compressor Losses', color: '#64748b' },
      { id: 'exhaust', label: 'Exhaust Heat Loss', color: '#94a3b8' },
    ];

    const sankeyLinks = [
      { source: 'fuel', target: 'combustor', value: fuelTotalExergyMW, label: `${fuelTotalExergyMW.toFixed(1)} MW` },
      { source: 'compressor', target: 'combustor', value: Ex_2, label: `${Ex_2.toFixed(1)} MW` },
      { source: 'combustor', target: 'ed_comb', value: Ed_comb, label: `${Ed_comb.toFixed(1)} MW` },
      { source: 'combustor', target: 'turbine', value: Ex_3, label: `${Ex_3.toFixed(1)} MW` },
      { source: 'turbine', target: 'compressor', value: W_c, label: `Shaft ${W_c.toFixed(1)} MW` },
      { source: 'turbine', target: 'generator', value: (W_t - W_c), label: `Net Mech ${(W_t - W_c).toFixed(1)} MW` },
      { source: 'turbine', target: 'ed_turb', value: Ed_t, label: `${Ed_t.toFixed(1)} MW` },
      { source: 'turbine', target: 'exhaust', value: Ed_exhaust, label: `${Ed_exhaust.toFixed(1)} MW` },
      { source: 'compressor', target: 'ed_comp', value: Ed_c, label: `${Ed_c.toFixed(1)} MW` },
      { source: 'generator', target: 'grid', value: cycle.netElectricalPowerMW, label: `${cycle.netElectricalPowerMW.toFixed(1)} MW` },
    ];

    return {
      fuelTotalExergyMW,
      fuelChemicalExergyMW,
      netExergyOutputMW: cycle.netElectricalPowerMW,
      totalExergyDestructionMW: totalDestructionMW,
      overallExergyEfficiencyPercent,
      components,
      sankeyNodes,
      sankeyLinks,
    };
  }
}
