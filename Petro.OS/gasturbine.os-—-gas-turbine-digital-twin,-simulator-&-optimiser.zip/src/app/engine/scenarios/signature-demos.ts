/**
 * GASTURBINE.OS — Signature Engineering Demos
 * Curated scenarios for 8 signature engineering demonstrations required by the platform directive.
 */

export interface SignatureDemo {
  id: string;
  number: number;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  objective: string;
  keyInsights: string[];
}

export const SIGNATURE_DEMOS: SignatureDemo[] = [
  {
    id: 'demo_1_cycle',
    number: 1,
    title: 'From Ambient Air to Electricity',
    subtitle: 'Coupled Brayton Thermodynamic Cycle Walkthrough',
    badge: 'Core Physics',
    description: 'Track air mass flow from atmospheric suction through 18 compressor stages, combustor chemical heat addition, 4-stage turbine expansion, and generator electrical conversion.',
    objective: 'Verify First-Law mass/energy balances and station thermodynamic states (T, P, h, s, rho, mass flow).',
    keyInsights: [
      'Visualizes continuous T-s and P-v state point coordinates (0 -> 1 -> 2 -> 3 -> 4).',
      'Confirms strict First-Law energy conservation residual (< 0.01% error).',
      'Highlights compressor aerodynamic work consumption (~350 MW) against turbine gross power (~840 MW).',
    ],
  },
  {
    id: 'demo_2_fouling',
    number: 2,
    title: 'Compressor Fouling & Wash Recovery',
    subtitle: 'Degradation Modeling & Maintenance Wash ROI',
    badge: 'Degradation',
    description: 'Simulate aerodynamic airfoil fouling over operating hours, observe heat rate degradation penalty, then trigger a simulated offline detergent water wash to restore performance.',
    objective: 'Demonstrate degradation impact on compressor map operating line and quantify fuel savings after wash.',
    keyInsights: [
      '5% compressor fouling creates a ~24 MW power loss and +180 kJ/kWh heat rate penalty.',
      'Offline crank wash restores ~94% of lost flow capacity and isentropic efficiency.',
      'Directly correlates maintenance cost (£12,500 wash) against annual fuel savings (>£480,000/yr).',
    ],
  },
  {
    id: 'demo_3_golden_point',
    number: 3,
    title: 'Golden Operating Point Optimisation',
    subtitle: 'Variable Geometry (IGV) & Load Efficiency Maximisation',
    badge: 'Optimisation',
    description: 'At a specified partial load (e.g. 80%) and ambient temperature, the optimiser finds the mathematically superior IGV angle and fuel schedule that minimizes heat rate within safety boundaries.',
    objective: 'Compare CURRENT vs OPTIMIZED operating points with exact fuel saved and emission deltas.',
    keyInsights: [
      'Modulating IGVs by +3.5° holds EGT elevated, boosting part-load thermal efficiency from 38.2% to 39.1%.',
      'Reduces natural gas consumption by ~0.42 kg/s (~1.5 tonnes/hr).',
      'Delivers an estimated +£320,000 annual margin improvement under constant dispatch.',
    ],
  },
  {
    id: 'demo_4_hydrogen',
    number: 4,
    title: 'Hydrogen Blend Laboratory',
    subtitle: '0% to 100% H2 Decarbonisation Physics',
    badge: 'Decarbonisation',
    description: 'Evaluate fuel flexibility by sliding H2 volume blend from 0% (pure methane) to 100% green hydrogen, calculating Wobbe Index, volumetric fuel flow, flame speed, water production, and NOx footprint.',
    objective: 'Assess fuel system volumetric constraints and thermal NOx formation risks under hydrogen co-firing.',
    keyInsights: [
      '100% H2 lowers carbon intensity to 0.0 g CO2/kWh while increasing flame temperature by ~110 K.',
      'Requires ~3.2x higher volumetric fuel flow due to low volumetric energy density of hydrogen.',
      'Wobbe Index remains within ±8% compatibility window for blends up to 25% H2 by volume.',
    ],
  },
  {
    id: 'demo_5_digital_twin',
    number: 5,
    title: 'Digital Twin Telemetry vs Physical Machine',
    subtitle: 'Real-Time State Estimation & Fault Isolation',
    badge: 'Digital Twin',
    description: 'Stream synthetic high-frequency telemetry across 18 sensor channels with measurement noise, inject a sensor bias or physical degradation, and test the Kalman state estimator.',
    objective: 'Prove the system distinguishes a single transducer failure from true thermodynamic machine degradation.',
    keyInsights: [
      'Parity space cross-channel checks isolate PT-201 sensor bias without corrupting core physics.',
      'Distinguishes between MEASURED, MODELLED, and CALIBRATED state points.',
      'Outputs structured diagnostic hypothesis (Observation, Hypothesis, Evidence, Confidence).',
    ],
  },
  {
    id: 'demo_6_time_machine',
    number: 6,
    title: 'Turbine Operational Time Machine',
    subtitle: '20-Year Operational Historian Replay (2006 – 2026)',
    badge: 'Historian',
    description: 'Scrub across two decades of deterministic plant operational telemetry. Observe seasonal weather cycles, gradual degradation trends, periodic offline washes, and major overhauls.',
    objective: 'Replay longitudinal fleet health metrics, degradation slopes, and maintenance interventions.',
    keyInsights: [
      'Captures annual seasonal efficiency swings between winter cold days and summer peak heat.',
      'Identifies gradual hot gas path creep & TBC erosion across 4-year major overhaul intervals.',
      'Provides empirical baseline for remaining useful life (RUL) estimation.',
    ],
  },
  {
    id: 'demo_7_pareto',
    number: 7,
    title: 'Multi-Objective Pareto Optimisation',
    subtitle: 'Efficiency vs NOx vs Operating Margin Trade-Offs',
    badge: 'Pareto Frontier',
    description: 'Explore the non-dominated Pareto frontier where improving fuel efficiency competes against stringent stack NOx limits and operating dispatch revenue.',
    objective: 'Allow the engineer to select an operating point on the multi-dimensional frontier.',
    keyInsights: [
      'Higher firing temperatures yield higher thermal efficiency but accelerate thermal NOx formation.',
      'Shows Pareto trade-off curve across 100+ simulated operating permutations.',
      'Gives power plant operators a quantitative dial for green dispatch vs peak profit.',
    ],
  },
  {
    id: 'demo_8_combined_cycle',
    number: 8,
    title: 'Combined Cycle & Heat Recovery (HRSG)',
    subtitle: 'Open Cycle Gas Turbine vs Combined Cycle (CCGT)',
    badge: 'Combined Cycle',
    description: 'Couple the gas turbine exhaust to a Heat Recovery Steam Generator (HRSG) and dual-pressure steam turbine, boosting total thermal efficiency from 39.8% to 58.5%.',
    objective: 'Quantify energy recovery from 595°C exhaust gas and steam turbine output contribution.',
    keyInsights: [
      'Adds ~228 MW of steam turbine electrical generation from exhaust thermal energy recovery.',
      'Elevates plant overall thermal efficiency to > 58.5% and drops heat rate to ~6,150 kJ/kWh.',
      'Exergy analysis proves exhaust destruction drops from 18.5% down to 5.2%.',
    ],
  },
];
