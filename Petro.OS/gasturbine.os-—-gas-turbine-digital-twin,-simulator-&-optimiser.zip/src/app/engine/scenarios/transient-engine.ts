/**
 * GASTURBINE.OS — Transient Dynamics & Startup/Trip Simulator
 * Time-domain physical simulation: Startup sequence (Zero Speed -> Crank -> Purge ->
 * Ignition -> Acceleration -> FSNL Synchronisation -> Base Load Ramp) and Trip Dynamics.
 */

export interface TransientTimeStep {
  timeSeconds: number;
  phaseName: 'TURNING_GEAR' | 'CRANK_PURGE' | 'IGNITION_LIGHTOFF' | 'ACCELERATING' | 'FSNL_SYNCHRONIZED' | 'BASE_LOAD_RAMP' | 'FULL_LOAD' | 'TRIP_COASTDOWN';
  shaftSpeedRpm: number;
  shaftSpeedPercent: number;
  fuelFlowKgS: number;
  compressorDischargePressureBar: number;
  turbineInletTempC: number;
  exhaustTempC: number;
  generatorPowerMW: number;
  vibrationRMS: number;
  eventDescription: string;
}

export class TransientEngine {
  /**
   * Generates a 600-second Startup Sequence time-series.
   */
  static simulateStartupSequence(ratedRpm = 3000, ratedMW = 487.5): TransientTimeStep[] {
    const steps: TransientTimeStep[] = [];
    const totalTimeSec = 600;
    const dt = 5;

    for (let t = 0; t <= totalTimeSec; t += dt) {
      let phase: TransientTimeStep['phaseName'] = 'TURNING_GEAR';
      let rpm = 0;
      let fuel = 0;
      let cdp = 1.01;
      let tit = 15;
      let egt = 15;
      let mw = 0;
      let vib = 0.5;
      let desc = '';

      if (t < 40) {
        // Turning gear & Starter motor crank to 600 RPM
        phase = 'TURNING_GEAR';
        rpm = 100 + (t / 40) * 500;
        cdp = 1.01 + (rpm / ratedRpm) * 0.5;
        tit = 15;
        egt = 15;
        vib = 0.8 + 0.3 * Math.random();
        desc = `Hydraulic starter motor engagement; rotor breakaway & turning gear speed at ${rpm.toFixed(0)} RPM.`;
      } else if (t < 90) {
        // Purge cycle (vent gas path of combustible residuals)
        phase = 'CRANK_PURGE';
        rpm = 600 + ((t - 40) / 50) * 200;
        cdp = 1.35;
        tit = 18;
        egt = 18;
        vib = 1.1 + 0.2 * Math.random();
        desc = 'Gas path volumetric purge active; combustor casing ventilation verifying no combustible accumulation.';
      } else if (t < 140) {
        // Ignition & Light-off (spark plugs active, light-off fuel flow)
        phase = 'IGNITION_LIGHTOFF';
        rpm = 800 + ((t - 90) / 50) * 300;
        fuel = 2.8 + ((t - 90) / 50) * 1.5;
        cdp = 1.8;
        tit = 450 + ((t - 90) / 50) * 250;
        egt = 280 + ((t - 90) / 50) * 120;
        vib = 1.8 + 0.4 * Math.random();
        desc = 'High-energy spark ignition active; optical flame detectors confirmed light-off across all burner cans.';
      } else if (t < 280) {
        // Acceleration through critical rotor resonance band to self-sustaining speed
        phase = 'ACCELERATING';
        const frac = (t - 140) / 140;
        rpm = 1100 + frac * 1700;
        fuel = 4.3 + frac * 8.5;
        cdp = 1.8 + frac * 12.0;
        tit = 700 + frac * 400;
        egt = 400 + frac * 150;
        // Resonance peak around 1800 RPM
        vib = Math.abs(rpm - 1800) < 250 ? 4.8 : 2.2 + 0.3 * Math.random();
        desc = `Rotor acceleration under net turbine torque; passed critical bearing resonance at 1,800 RPM. Current speed ${rpm.toFixed(0)} RPM.`;
      } else if (t < 360) {
        // Full Speed No Load (FSNL) Synchronisation
        phase = 'FSNL_SYNCHRONIZED';
        rpm = ratedRpm;
        fuel = 6.8;
        cdp = 14.5;
        tit = 850;
        egt = 480;
        mw = 0;
        vib = 1.5 + 0.2 * Math.random();
        desc = `Full Speed No Load (3,000 RPM 50.0 Hz). Generator automatic synchroniser matched grid voltage and closed breaker.`;
      } else if (t < 520) {
        // Base Load Ramp (e.g. 25 MW/min)
        phase = 'BASE_LOAD_RAMP';
        const frac = (t - 360) / 160;
        rpm = ratedRpm;
        mw = frac * ratedMW;
        fuel = 6.8 + frac * 21.2;
        cdp = 14.5 + frac * 10.0;
        tit = 850 + frac * 650;
        egt = 480 + frac * 115;
        vib = 2.1 + 0.2 * Math.random();
        desc = `Loading ramp active at +30 MW/min. Current active electrical dispatch: ${mw.toFixed(1)} MW.`;
      } else {
        // Full Base Load steady state
        phase = 'FULL_LOAD';
        rpm = ratedRpm;
        mw = ratedMW;
        fuel = 28.0;
        cdp = 24.5;
        tit = 1500;
        egt = 595;
        vib = 2.2 + 0.1 * Math.random();
        desc = `Base Load steady-state dispatch achieved (${ratedMW.toFixed(1)} MW @ 39.8% thermal efficiency).`;
      }

      steps.push({
        timeSeconds: t,
        phaseName: phase,
        shaftSpeedRpm: rpm,
        shaftSpeedPercent: (rpm / ratedRpm) * 100,
        fuelFlowKgS: fuel,
        compressorDischargePressureBar: cdp,
        turbineInletTempC: tit,
        exhaustTempC: egt,
        generatorPowerMW: mw,
        vibrationRMS: vib,
        eventDescription: desc,
      });
    }

    return steps;
  }

  /**
   * Generates a 120-second Emergency Trip & Coast-Down sequence.
   */
  static simulateTripSequence(tripCause: 'OVERSPEED' | 'EGT_OVERTEMP' | 'GRID_LOSS' | 'SURGE', ratedRpm = 3000, initialMW = 487.5): TransientTimeStep[] {
    const steps: TransientTimeStep[] = [];
    const totalTimeSec = 120;
    const dt = 2;

    for (let t = 0; t <= totalTimeSec; t += dt) {
      // Rapid fuel valve closure within 100ms
      const fuel = t === 0 ? 28.0 : 0;
      const mw = t === 0 ? initialMW : 0;
      // Exponential rotor deceleration based on inertia J
      const speedDecay = Math.exp(-t / 32);
      const rpm = ratedRpm * speedDecay;
      const cdp = 1.01 + 23.5 * Math.pow(rpm / ratedRpm, 1.8);
      const egt = 595 * Math.exp(-t / 45) + 25;
      const tit = 1500 * Math.exp(-t / 15) + 30;

      let vib = 2.0;
      if (tripCause === 'SURGE' && t < 10) vib = 8.5; // High vibration spike on surge
      else if (tripCause === 'OVERSPEED' && t < 6) vib = 6.2;
      else vib = 1.0 + 1.5 * (rpm / ratedRpm);

      steps.push({
        timeSeconds: t,
        phaseName: 'TRIP_COASTDOWN',
        shaftSpeedRpm: rpm,
        shaftSpeedPercent: (rpm / ratedRpm) * 100,
        fuelFlowKgS: fuel,
        compressorDischargePressureBar: cdp,
        turbineInletTempC: tit,
        exhaustTempC: egt,
        generatorPowerMW: mw,
        vibrationRMS: vib,
        eventDescription: `EMERGENCY TRIP INITIATED (${tripCause}). Master fuel trip solenoid de-energized; generator breaker opened; rotor coasting down at ${rpm.toFixed(0)} RPM.`,
      });
    }

    return steps;
  }
}
