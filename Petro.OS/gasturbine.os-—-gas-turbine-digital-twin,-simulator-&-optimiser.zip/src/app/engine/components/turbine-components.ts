/**
 * GASTURBINE.OS — Component Physics Models
 * Inlet, Compressor (multi-stage + map), Combustor, Turbine (expansion + loading),
 * Shaft & Electrical Generator with degradation parameters and mechanical balances.
 */

import { AmbientState } from '../thermodynamics/ambient-model';
import { GasMixtureCalculator } from '../thermodynamics/gas-mixture';
import { FluidComposition, ThermoStateData } from '../thermodynamics/thermo-state';

export interface CompressorStage {
  stageNumber: number;
  rotorTipSpeedMS: number;
  pressureRatio: number;
  isentropicEfficiency: number;
  temperatureRiseK: number;
  workKJkg: number;
  inletPressurePa: number;
  exitPressurePa: number;
  inletTempK: number;
  exitTempK: number;
}

export interface TurbineStage {
  stageNumber: number;
  expansionRatio: number;
  isentropicEfficiency: number;
  enthalpyDropKJkg: number;
  temperatureDropK: number;
  workOutputMW: number;
  stageLoadingFactor: number; // psi = Delta h / u^2
  flowCoefficient: number;    // phi = c_a / u
}

export interface CompressorMapPoint {
  correctedMassFlowKgS: number;
  pressureRatio: number;
  efficiency: number;
  speedRatio: number;
  surgeMarginPercent: number;
}

export class InletModel {
  static compute(
    ambient: AmbientState,
    designMassFlowKgS: number,
    filterFoulingFactor = 1.0, // 1.0 = clean, > 1.0 = fouled
    antiIcingBleedFraction = 0.0
  ): {
    state1: ThermoStateData;
    pressureLossPa: number;
    pressureLossPercent: number;
    massFlowKgS: number;
  } {
    // Nominal inlet pressure loss ~ 1.0 kPa (10 mbar)
    const baseDeltaP = 1000 * Math.pow(designMassFlowKgS / 700, 1.8);
    const pressureLossPa = baseDeltaP * filterFoulingFactor;
    const p1 = Math.max(80000, ambient.pressurePa - pressureLossPa);

    // Temperature recovery: slight adiabatic cooling + anti-icing heating if active
    let t1 = ambient.temperatureK;
    if (antiIcingBleedFraction > 0) {
      t1 += antiIcingBleedFraction * 20; // Bleed heating effect
    }

    const massFlowKgS = designMassFlowKgS * (1 - antiIcingBleedFraction);

    const state1 = GasMixtureCalculator.computeState(
      'state_1',
      'Compressor Inlet',
      '1',
      t1,
      p1,
      massFlowKgS,
      ambient.composition
    );

    return {
      state1,
      pressureLossPa,
      pressureLossPercent: (pressureLossPa / ambient.pressurePa) * 100,
      massFlowKgS,
    };
  }
}

export class CompressorModel {
  static compute(
    inletState: ThermoStateData,
    pressureRatio: number,
    isentropicEfficiency: number,
    stageCount = 18,
    shaftSpeedRpm = 3000,
    foulingDegradation = 0 // 0 to 0.15 (15% fouling)
  ): {
    state2: ThermoStateData;
    powerMW: number;
    workKJkg: number;
    exitTempK: number;
    stages: CompressorStage[];
    correctedFlow: number;
    correctedSpeed: number;
    surgeMargin: number;
    mapPoint: CompressorMapPoint;
  } {
    // Degradation drops efficiency and mass flow capacity
    const effectiveEta = Math.max(0.70, isentropicEfficiency * (1 - foulingDegradation * 0.7));
    const effectivePr = Math.max(1.1, pressureRatio * (1 - foulingDegradation * 0.3));

    const p1 = inletState.pressurePa;
    const t1 = inletState.temperatureK;
    const p2 = p1 * effectivePr;

    // Isentropic temperature ratio
    const gamma = inletState.gamma;
    const exp = (gamma - 1) / gamma;
    const t2_isen = t1 * Math.pow(effectivePr, exp);
    const t2 = t1 + (t2_isen - t1) / effectiveEta;

    const massFlow = inletState.massFlowKgS * (1 - foulingDegradation * 0.4);

    const state2 = GasMixtureCalculator.computeState(
      'state_2',
      'Compressor Discharge (CDP)',
      '2',
      t2,
      p2,
      massFlow,
      inletState.composition
    );

    const workKJkg = state2.enthalpyKJkg - inletState.enthalpyKJkg;
    const powerMW = (massFlow * workKJkg) / 1000;

    // Corrected parameters (reference: 15°C, 101.325 kPa)
    const theta = t1 / 288.15;
    const delta = p1 / 101325;
    const correctedFlow = (massFlow * Math.sqrt(theta)) / delta;
    const correctedSpeed = (shaftSpeedRpm / 3000) / Math.sqrt(theta);

    // Multi-stage meanline breakdown
    const stagePr = Math.pow(effectivePr, 1 / stageCount);
    const stages: CompressorStage[] = [];
    let curP = p1;
    let curT = t1;

    for (let i = 1; i <= stageCount; i++) {
      const nextP = curP * stagePr;
      const nextT_is = curT * Math.pow(stagePr, exp);
      const stageEta = effectiveEta - 0.002 * Math.abs(i - stageCount / 2);
      const nextT = curT + (nextT_is - curT) / stageEta;
      const dH = inletState.cpKJkgK * (nextT - curT);

      stages.push({
        stageNumber: i,
        rotorTipSpeedMS: 380 - (i * 4.5), // Tapers down from front to rear
        pressureRatio: stagePr,
        isentropicEfficiency: stageEta,
        temperatureRiseK: nextT - curT,
        workKJkg: dH,
        inletPressurePa: curP,
        exitPressurePa: nextP,
        inletTempK: curT,
        exitTempK: nextT,
      });

      curP = nextP;
      curT = nextT;
    }

    // Surge line approximation: PR_surge = 1.0 + 1.25 * (correctedFlow / 500)^1.4
    const surgePrAtFlow = 1.0 + 1.45 * Math.pow(Math.max(10, correctedFlow) / 450, 1.25);
    const surgeMargin = Math.max(2, ((surgePrAtFlow - effectivePr) / effectivePr) * 100);

    const mapPoint: CompressorMapPoint = {
      correctedMassFlowKgS: correctedFlow,
      pressureRatio: effectivePr,
      efficiency: effectiveEta,
      speedRatio: correctedSpeed,
      surgeMarginPercent: surgeMargin,
    };

    return {
      state2,
      powerMW,
      workKJkg,
      exitTempK: t2,
      stages,
      correctedFlow,
      correctedSpeed,
      surgeMargin,
      mapPoint,
    };
  }
}

export class CombustorModel {
  static compute(
    cdpState: ThermoStateData,
    fuelComposition: FluidComposition,
    targetTitK: number,
    combustionEfficiency = 0.998,
    combustorPressureDropFraction = 0.038 // 3.8% delta P
  ): {
    state3: ThermoStateData;
    fuelFlowKgS: number;
    airFuelRatio: number;
    equivalenceRatio: number;
    heatReleaseMW: number;
    combustorLossMW: number;
    flameTempK: number;
    combustorExitP: number;
    productsComposition: FluidComposition;
  } {
    const p3 = cdpState.pressurePa * (1 - combustorPressureDropFraction);
    const fuelProps = GasMixtureCalculator.calculateFuelProperties('Fuel', fuelComposition);

    // Enthalpy balance: m_air * h_cdp + m_fuel * (LHV * eta_comb + h_fuel) = (m_air + m_fuel) * h_tit
    // First estimate enthalpy of products at TIT
    const estimatedProductsComp = GasMixtureCalculator.computeCombustionProducts(
      cdpState.composition,
      fuelComposition,
      40 // initial AFR estimate
    );

    const h_tit = GasMixtureCalculator.getMixtureEnthalpy(estimatedProductsComp, targetTitK);
    const h_cdp = cdpState.enthalpyKJkg;
    const lhv_kJ = fuelProps.lhvMJkg * 1000;

    // (h_tit - h_cdp) / (LHV * eta_comb - h_tit)
    const fuelAirMassRatio = (h_tit - h_cdp) / (lhv_kJ * combustionEfficiency - h_tit + 50);
    const airFuelRatio = Math.max(10, 1 / Math.max(0.001, fuelAirMassRatio));
    const fuelFlowKgS = cdpState.massFlowKgS / airFuelRatio;
    const totalMassFlow = cdpState.massFlowKgS + fuelFlowKgS;

    const equivalenceRatio = fuelProps.stoichiometricAfr / airFuelRatio;
    const productsComposition = GasMixtureCalculator.computeCombustionProducts(
      cdpState.composition,
      fuelComposition,
      airFuelRatio
    );

    const state3 = GasMixtureCalculator.computeState(
      'state_3',
      'Turbine Inlet (TIT / Firing Temp)',
      '3',
      targetTitK,
      p3,
      totalMassFlow,
      productsComposition
    );

    const heatReleaseMW = (fuelFlowKgS * fuelProps.lhvMJkg * combustionEfficiency);
    const combustorLossMW = (fuelFlowKgS * fuelProps.lhvMJkg * (1 - combustionEfficiency));
    const flameTempK = Math.min(2350, targetTitK + (1 - equivalenceRatio) * 150 + (fuelProps.h2VolPercent * 2.5));

    return {
      state3,
      fuelFlowKgS,
      airFuelRatio,
      equivalenceRatio,
      heatReleaseMW,
      combustorLossMW,
      flameTempK,
      combustorExitP: p3,
      productsComposition,
    };
  }
}

export class TurbineModel {
  static compute(
    titState: ThermoStateData,
    exhaustPressurePa: number,
    isentropicEfficiency: number,
    stageCount = 4,
    bladeDegradation = 0 // 0 to 0.10 (10% degradation)
  ): {
    state4: ThermoStateData;
    powerMW: number;
    workKJkg: number;
    exitTempK: number;
    expansionRatio: number;
    stages: TurbineStage[];
  } {
    const effectiveEta = Math.max(0.72, isentropicEfficiency * (1 - bladeDegradation * 0.8));
    const p3 = titState.pressurePa;
    const p4 = exhaustPressurePa;
    const expansionRatio = p3 / p4;
    const t3 = titState.temperatureK;

    const gamma = titState.gamma;
    const exp = (gamma - 1) / gamma;
    const t4_is = t3 / Math.pow(expansionRatio, exp);
    const t4 = t3 - effectiveEta * (t3 - t4_is);

    const state4 = GasMixtureCalculator.computeState(
      'state_4',
      'Turbine Exhaust (EGT)',
      '4',
      t4,
      p4,
      titState.massFlowKgS,
      titState.composition
    );

    const workKJkg = titState.enthalpyKJkg - state4.enthalpyKJkg;
    const powerMW = (titState.massFlowKgS * workKJkg) / 1000;

    // Multi-stage turbine breakdown
    const stagePr = Math.pow(expansionRatio, 1 / stageCount);
    const stages: TurbineStage[] = [];
    let curP = p3;
    let curT = t3;

    for (let i = 1; i <= stageCount; i++) {
      const nextP = curP / stagePr;
      const nextT_is = curT / Math.pow(stagePr, exp);
      const stageEta = effectiveEta - 0.004 * (i - 1);
      const nextT = curT - stageEta * (curT - nextT_is);
      const stageWorkKJ = titState.cpKJkgK * (curT - nextT);
      const stageWorkMW = (titState.massFlowKgS * stageWorkKJ) / 1000;

      stages.push({
        stageNumber: i,
        expansionRatio: stagePr,
        isentropicEfficiency: stageEta,
        enthalpyDropKJkg: stageWorkKJ,
        temperatureDropK: curT - nextT,
        workOutputMW: stageWorkMW,
        stageLoadingFactor: 1.4 + (i * 0.15),
        flowCoefficient: 0.55 + (i * 0.04),
      });

      curP = nextP;
      curT = nextT;
    }

    return {
      state4,
      powerMW,
      workKJkg,
      exitTempK: t4,
      expansionRatio,
      stages,
    };
  }
}
