import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';
import { TurbineSchematic } from '../turbine-schematic/turbine-schematic';
import { SIGNATURE_DEMOS } from '../../engine/scenarios/signature-demos';

@Component({
  selector: 'app-overview-view',
  imports: [CommonModule, MatIconModule, TurbineSchematic],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let cycle = service.currentCycle();

    <div class="space-y-6">
      
      <!-- Gas-Path Longitudinal Cross-Section -->
      <app-turbine-schematic />

      <!-- Quick Signature Demos Ribbon -->
      <div class="p-4 rounded-xl bg-card border border-border">
        <div class="flex items-center justify-between mb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="!text-sm !w-4 !h-4 text-primary">play_circle</mat-icon>
            <span class="font-mono text-xs font-bold text-foreground">SIGNATURE ENGINEERING DEMONSTRATIONS</span>
          </div>
          <button (click)="service.setMode('SCENARIOS')" class="text-xs font-mono text-primary hover:underline">
            View All 8 Labs →
          </button>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          @for (demo of demos.slice(0, 4); track demo.id) {
            <button
              (click)="service.launchDemo(demo)"
              class="p-2.5 rounded-lg bg-muted/40 hover:bg-primary/10 border border-border hover:border-primary/40 text-left transition-all group">
              <span class="text-[10px] font-mono text-primary font-bold">DEMO 0{{ demo.number }}</span>
              <div class="font-mono text-xs font-bold text-foreground mt-0.5 truncate group-hover:text-primary">
                {{ demo.title }}
              </div>
              <div class="text-[10px] text-muted-foreground truncate mt-0.5">{{ demo.badge }}</div>
            </button>
          }
        </div>
      </div>

      <!-- Quick Telemetry & Emissions Split -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Live Station Thermodynamic Summary -->
        <div class="p-4 rounded-xl bg-card border border-border flex flex-col justify-between">
          <div class="flex items-center justify-between pb-3 border-b border-border/60 mb-3">
            <span class="font-mono text-xs font-bold text-foreground">GAS-PATH PROCESS STATIONS SNAPSHOT</span>
            <button (click)="service.setMode('CYCLE')" class="text-xs font-mono text-primary hover:underline">
              Full T-s Diagram →
            </button>
          </div>

          <div class="space-y-2 text-xs font-mono">
            <div class="flex items-center justify-between p-2 rounded bg-muted/30">
              <span class="text-muted-foreground">Station 1 (Compressor Inlet):</span>
              <span class="font-semibold text-foreground">
                {{ (cycle.state1_inlet.temperatureK - 273.15).toFixed(1) }}°C · {{ (cycle.state1_inlet.pressurePa / 100000).toFixed(3) }} bar
              </span>
            </div>

            <div class="flex items-center justify-between p-2 rounded bg-muted/30">
              <span class="text-muted-foreground">Station 2 (Compressor Discharge CDP):</span>
              <span class="font-semibold text-foreground">
                {{ (cycle.state2_cdp.temperatureK - 273.15).toFixed(0) }}°C · {{ (cycle.state2_cdp.pressurePa / 100000).toFixed(2) }} bar
              </span>
            </div>

            <div class="flex items-center justify-between p-2 rounded bg-muted/30">
              <span class="text-muted-foreground">Station 3 (Turbine Firing TIT):</span>
              <span class="font-semibold text-red-400">
                {{ (cycle.state3_tit.temperatureK - 273.15).toFixed(0) }}°C · {{ (cycle.state3_tit.pressurePa / 100000).toFixed(2) }} bar
              </span>
            </div>

            <div class="flex items-center justify-between p-2 rounded bg-muted/30">
              <span class="text-muted-foreground">Station 4 (Turbine Exhaust EGT):</span>
              <span class="font-semibold text-foreground">
                {{ (cycle.state4_egt.temperatureK - 273.15).toFixed(0) }}°C · {{ (cycle.state4_egt.pressurePa / 100000).toFixed(3) }} bar
              </span>
            </div>
          </div>
        </div>

        <!-- Environmental Emissions & Carbon Footprint -->
        <div class="p-4 rounded-xl bg-card border border-border flex flex-col justify-between">
          <div class="flex items-center justify-between pb-3 border-b border-border/60 mb-3">
            <span class="font-mono text-xs font-bold text-foreground">ENVIRONMENTAL EMISSIONS PROFILE</span>
            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              COMPLIANT
            </span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs font-mono">
            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">STACK NOX (15% O2)</span>
              <div class="text-base font-bold text-foreground mt-1">{{ cycle.emissions.noxPpmvd15O2.toFixed(1) }} ppmvd</div>
              <span class="text-[10px] text-muted-foreground">Limit: 25.0 ppmvd</span>
            </div>

            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">SPECIFIC CO2 RATE</span>
              <div class="text-base font-bold text-foreground mt-1">{{ cycle.emissions.co2SpecificGPerKWh.toFixed(0) }} g/kWh</div>
              <span class="text-[10px] text-muted-foreground">{{ (cycle.emissions.co2RateKgH / 1000).toFixed(1) }} tonnes/hr</span>
            </div>

            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">STACK CO CONCENTRATION</span>
              <div class="text-base font-bold text-foreground mt-1">{{ cycle.emissions.coPpmvd15O2.toFixed(1) }} ppmvd</div>
              <span class="text-[10px] text-muted-foreground">Incomplete combustion</span>
            </div>

            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">AIR-FUEL RATIO (AFR)</span>
              <div class="text-base font-bold text-foreground mt-1">{{ cycle.airFuelRatio.toFixed(1) }} : 1</div>
              <span class="text-[10px] text-muted-foreground">Equivalence Φ = {{ cycle.equivalenceRatio.toFixed(3) }}</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  `,
})
export class OverviewView {
  readonly service = inject(TurbineService);
  readonly demos = SIGNATURE_DEMOS;
}
