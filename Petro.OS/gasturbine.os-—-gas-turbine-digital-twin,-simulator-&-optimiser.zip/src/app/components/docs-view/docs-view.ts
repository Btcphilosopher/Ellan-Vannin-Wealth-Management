import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-docs-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6 max-w-5xl mx-auto">
      
      <!-- Top Title -->
      <div class="p-4 rounded-xl bg-card border border-border">
        <h2 class="text-base font-bold font-mono text-foreground">THERMODYNAMIC GOVERNING EQUATIONS & FORMULATIONS</h2>
        <p class="text-xs text-muted-foreground mt-1">
          Complete mathematical reference documentation for GASTURBINE.OS physics models, NASA Glenn polynomials, and First/Second Law energy conservation.
        </p>
      </div>

      <!-- Section 1: Real-Gas Polynomial Equations -->
      <div class="p-5 rounded-xl bg-card border border-border space-y-3">
        <div class="flex items-center gap-2 pb-2 border-b border-border/60">
          <mat-icon class="!text-base !w-4 !h-4 text-primary">functions</mat-icon>
          <span class="font-mono text-xs font-bold text-foreground">1. NASA GLENN REAL-GAS THERMODYNAMIC POLYNOMIALS</span>
        </div>

        <p class="text-xs text-muted-foreground">
          Specific heat capacity cp(T), specific enthalpy h(T), and specific entropy s(T, P) are computed for each constituent species (N2, O2, CO2, H2O, Ar, CH4, H2, CO) using temperature-dependent NASA polynomial approximations:
        </p>

        <div class="p-3.5 rounded-lg bg-slate-950 font-mono text-xs text-primary border border-border space-y-1.5">
          <div>cp(T) / R = a1 + a2*T + a3*T^2 + a4*T^3 + a5*T^4</div>
          <div>h(T) = R * [ a1*T + (a2/2)*T^2 + (a3/3)*T^3 + (a4/4)*T^4 + (a5/5)*T^5 + b1 ]</div>
          <div>s(T, P) = R * [ a1*ln(T) + a2*T + (a3/2)*T^2 + (a4/3)*T^3 + (a5/4)*T^4 + b2 ] - R*ln(P / P0)</div>
        </div>
      </div>

      <!-- Section 2: Brayton Cycle & Component Efficiencies -->
      <div class="p-5 rounded-xl bg-card border border-border space-y-3">
        <div class="flex items-center gap-2 pb-2 border-b border-border/60">
          <mat-icon class="!text-base !w-4 !h-4 text-primary">sync_alt</mat-icon>
          <span class="font-mono text-xs font-bold text-foreground">2. BRAYTON CYCLE COMPONENT THERMODYNAMICS</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          <div class="p-3 rounded-lg bg-muted/40 border border-border space-y-1 text-muted-foreground">
            <span class="text-foreground font-bold">Compressor Exit Temperature (T2):</span>
            <div class="text-primary mt-1">T2 = T1 * [ 1 + (1 / eta_comp) * ( (P2/P1)^((gamma - 1)/gamma) - 1 ) ]</div>
            <div>Compressor Work: W_c = m_air * (h2 - h1)</div>
          </div>

          <div class="p-3 rounded-lg bg-muted/40 border border-border space-y-1 text-muted-foreground">
            <span class="text-foreground font-bold">Turbine Exhaust Temperature (T4):</span>
            <div class="text-primary mt-1">T4 = T3 - eta_turb * [ T3 - T3 / ((P3/P4)^((gamma - 1)/gamma)) ]</div>
            <div>Turbine Gross Power: W_t = m_gas * (h3 - h4)</div>
          </div>
        </div>
      </div>

      <!-- Section 3: Second-Law Exergy Formulation -->
      <div class="p-5 rounded-xl bg-card border border-border space-y-3">
        <div class="flex items-center gap-2 pb-2 border-b border-border/60">
          <mat-icon class="!text-base !w-4 !h-4 text-purple-400">account_tree</mat-icon>
          <span class="font-mono text-xs font-bold text-foreground">3. SECOND-LAW EXERGY & IRREVERSIBILITY BALANCE</span>
        </div>

        <p class="text-xs text-muted-foreground">
          Specific physical exergy e_ph and total exergy destruction E_D (Gouy-Stodola theorem) relative to dead-state environment (T0 = 288.15 K, P0 = 101.325 kPa):
        </p>

        <div class="p-3.5 rounded-lg bg-slate-950 font-mono text-xs text-purple-300 border border-border space-y-1.5">
          <div>e_ph = (h - h0) - T0 * (s - s0)</div>
          <div>E_D,comb = E_x,fuel + E_x,2 - E_x,3  (Dominant chemical combustion irreversibility)</div>
          <div>E_D,i = T0 * S_gen,i = m * T0 * (s_out - s_in)</div>
        </div>
      </div>

      <!-- Section 4: GT-500-DEMO Reference Machine Configuration -->
      <div class="p-5 rounded-xl bg-card border border-border space-y-3">
        <div class="flex items-center gap-2 pb-2 border-b border-border/60">
          <mat-icon class="!text-base !w-4 !h-4 text-emerald-400">precision_manufacturing</mat-icon>
          <span class="font-mono text-xs font-bold text-foreground">4. SYNTHETIC GT-500-DEMO REFERENCE MACHINE SPECIFICATION</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div class="p-2.5 rounded bg-muted/40 border border-border">
            <span class="text-muted-foreground">Rated Power:</span>
            <div class="font-bold text-foreground mt-0.5">487.5 MW</div>
          </div>
          <div class="p-2.5 rounded bg-muted/40 border border-border">
            <span class="text-muted-foreground">Shaft Speed:</span>
            <div class="font-bold text-foreground mt-0.5">3,000 RPM (50 Hz)</div>
          </div>
          <div class="p-2.5 rounded bg-muted/40 border border-border">
            <span class="text-muted-foreground">Pressure Ratio:</span>
            <div class="font-bold text-foreground mt-0.5">24.2 : 1</div>
          </div>
          <div class="p-2.5 rounded bg-muted/40 border border-border">
            <span class="text-muted-foreground">Air Mass Flow:</span>
            <div class="font-bold text-foreground mt-0.5">740.0 kg/s</div>
          </div>
          <div class="p-2.5 rounded bg-muted/40 border border-border">
            <span class="text-muted-foreground">Firing Temp (TIT):</span>
            <div class="font-bold text-foreground mt-0.5">1,500°C (1,773 K)</div>
          </div>
          <div class="p-2.5 rounded bg-muted/40 border border-border">
            <span class="text-muted-foreground">Compressor Stages:</span>
            <div class="font-bold text-foreground mt-0.5">18 Axial Stages</div>
          </div>
          <div class="p-2.5 rounded bg-muted/40 border border-border">
            <span class="text-muted-foreground">Turbine Stages:</span>
            <div class="font-bold text-foreground mt-0.5">4 Axial Stages</div>
          </div>
          <div class="p-2.5 rounded bg-muted/40 border border-border">
            <span class="text-muted-foreground">Base Thermal Efficiency:</span>
            <div class="font-bold text-foreground mt-0.5">39.80% (ISO Day)</div>
          </div>
        </div>
      </div>

    </div>
  `,
})
export class DocsView {}
