import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';

@Component({
  selector: 'app-transient-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let steps = service.transientSteps();
    @let curIdx = service.currentTransientStepIndex();
    @let currentStep = steps[curIdx] || steps[0];

    <div class="space-y-6">
      
      <!-- Top Title & Action Controls -->
      <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-card border border-border">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-base font-bold font-mono text-foreground">TIME-DOMAIN TRANSIENT DYNAMICS SIMULATOR</h2>
            <span class="text-xs px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 font-mono border border-blue-500/20">
              PHASE: {{ currentStep.phaseName }}
            </span>
          </div>
          <p class="text-xs text-muted-foreground mt-1">
            Dynamic rotor acceleration, thermal inertia lag, starter motor cranking, flame ignition, and critical bearing vibration resonance.
          </p>
        </div>

        <div class="flex flex-wrap items-center gap-2 text-xs font-mono">
          <button
            (click)="service.startStartupSimulation()"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors shadow-sm">
            <mat-icon class="!text-sm !w-4 !h-4">play_arrow</mat-icon>
            <span>Run 600s Startup Ramp</span>
          </button>
          
          <button
            (click)="service.startTripSimulation('SURGE')"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600/90 hover:bg-red-500 text-white font-bold transition-colors shadow-sm">
            <mat-icon class="!text-sm !w-4 !h-4">warning</mat-icon>
            <span>Trigger Surge Trip</span>
          </button>

          <button
            (click)="service.startTripSimulation('GRID_LOSS')"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-600/90 hover:bg-amber-500 text-white font-bold transition-colors shadow-sm">
            <mat-icon class="!text-sm !w-4 !h-4">power_off</mat-icon>
            <span>Grid Loss Trip</span>
          </button>
        </div>
      </div>

      <!-- Time Scrubber & Phase Banner -->
      <div class="p-5 rounded-xl bg-card border border-border">
        <div class="flex items-center justify-between pb-3 border-b border-border/60 mb-4">
          <span class="font-mono text-xs font-bold text-foreground">TRANSIENT TIMELINE SCRUBBER</span>
          <span class="font-mono text-xs font-bold text-primary">
            TIME: {{ currentStep.timeSeconds }}s / {{ steps[steps.length - 1]?.timeSeconds || 600 }}s
          </span>
        </div>

        <input
          type="range"
          min="0"
          [max]="steps.length - 1"
          step="1"
          [value]="curIdx"
          (input)="onScrub($event)"
          class="w-full h-2 bg-border rounded-lg appearance-none cursor-pointer accent-primary"/>

        <div class="mt-3 p-3 rounded-lg bg-muted/40 border border-border text-xs font-mono text-foreground flex items-center gap-2">
          <mat-icon class="!text-base !w-4 !h-4 text-primary shrink-0">info</mat-icon>
          <span>{{ currentStep.eventDescription }}</span>
        </div>
      </div>

      <!-- Live Dynamic Gauges Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 font-mono text-xs">
        
        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-muted-foreground">ROTOR SPEED</span>
          <div class="text-xl font-bold text-foreground mt-1 tabular-nums">
            {{ currentStep.shaftSpeedRpm.toFixed(0) }} RPM
          </div>
          <span class="text-[10px] text-muted-foreground">({{ currentStep.shaftSpeedPercent.toFixed(1) }}% rated)</span>
        </div>

        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-muted-foreground">GENERATOR POWER</span>
          <div class="text-xl font-bold text-emerald-400 mt-1 tabular-nums">
            {{ currentStep.generatorPowerMW.toFixed(1) }} MW
          </div>
          <span class="text-[10px] text-muted-foreground">Active grid dispatch</span>
        </div>

        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-muted-foreground">FUEL MASS FLOW</span>
          <div class="text-xl font-bold text-foreground mt-1 tabular-nums">
            {{ currentStep.fuelFlowKgS.toFixed(2) }} kg/s
          </div>
          <span class="text-[10px] text-muted-foreground">Gas manifold feed</span>
        </div>

        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-muted-foreground">CDP DISCHARGE</span>
          <div class="text-xl font-bold text-foreground mt-1 tabular-nums">
            {{ currentStep.compressorDischargePressureBar.toFixed(2) }} bar
          </div>
          <span class="text-[10px] text-muted-foreground">Compressor exit</span>
        </div>

        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-muted-foreground">EXHAUST TEMP (EGT)</span>
          <div class="text-xl font-bold text-foreground mt-1 tabular-nums">
            {{ currentStep.exhaustTempC.toFixed(0) }}°C
          </div>
          <span class="text-[10px] text-muted-foreground">TIT: {{ currentStep.turbineInletTempC.toFixed(0) }}°C</span>
        </div>

        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-muted-foreground">BEARING VIBRATION</span>
          <div class="text-xl font-bold mt-1 tabular-nums" [class.text-red-400]="currentStep.vibrationRMS > 4.5" [class.text-foreground]="currentStep.vibrationRMS <= 4.5">
            {{ currentStep.vibrationRMS.toFixed(2) }} mm/s
          </div>
          <span class="text-[10px]" [class.text-red-400]="currentStep.vibrationRMS > 4.5" [class.text-muted-foreground]="currentStep.vibrationRMS <= 4.5">
            {{ currentStep.vibrationRMS > 4.5 ? 'CRITICAL RESONANCE' : 'ACCEPTABLE' }}
          </span>
        </div>

      </div>

    </div>
  `,
})
export class TransientView {
  readonly service = inject(TurbineService);

  onScrub(event: Event): void {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.service.setTransientStep(val);
  }
}
