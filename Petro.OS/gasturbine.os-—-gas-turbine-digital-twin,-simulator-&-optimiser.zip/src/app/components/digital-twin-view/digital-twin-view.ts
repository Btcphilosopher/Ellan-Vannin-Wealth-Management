import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';

@Component({
  selector: 'app-digital-twin-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let est = service.estimatedStateResult();
    @let sensors = service.currentSensors();

    <div class="space-y-6">
      
      <!-- Top Title & Estimator Status -->
      <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-card border border-border">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-base font-bold font-mono text-foreground">DIGITAL TWIN & STATE ESTIMATOR WORKSTATION</h2>
            <span class="text-xs px-2 py-0.5 rounded font-mono border"
              [class.bg-emerald-500/10]="!est.state.isSensorFaultDetected"
              [class.text-emerald-400]="!est.state.isSensorFaultDetected"
              [class.border-emerald-500/20]="!est.state.isSensorFaultDetected"
              [class.bg-amber-500/10]="est.state.isSensorFaultDetected"
              [class.text-amber-400]="est.state.isSensorFaultDetected"
              [class.border-amber-500/20]="est.state.isSensorFaultDetected">
              {{ est.state.isSensorFaultDetected ? 'FAULT ISOLATED: ' + est.state.faultySensorTag : 'ALL CHANNELS CONSISTENT' }}
            </span>
          </div>
          <p class="text-xs text-muted-foreground mt-1">
            Hybrid physics-constrained Kalman state estimator filtering Gaussian noise, detecting instrument bias drift, and tracking real hot-gas path degradation.
          </p>
        </div>

        <!-- Quick Fault Injection Buttons -->
        <div class="flex flex-wrap items-center gap-2 text-xs font-mono">
          <button
            (click)="service.injectSensorFault('PT-201', 'DRIFT')"
            class="px-2.5 py-1 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20 transition-colors">
            + Inject CDP Drift (PT-201)
          </button>
          <button
            (click)="service.injectSensorFault('TT-401', 'STUCK')"
            class="px-2.5 py-1 rounded bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20 transition-colors">
            + Inject Stuck EGT (TT-401)
          </button>
          <button
            (click)="service.clearFaults()"
            class="px-2.5 py-1 rounded bg-muted text-muted-foreground border border-border hover:text-foreground">
            Clear Faults
          </button>
        </div>
      </div>

      <!-- State Estimator Accuracy Comparison Strip -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-[11px] font-mono text-muted-foreground">PHYSICS-ONLY RMSE</span>
          <div class="mt-1 flex items-baseline gap-1.5">
            <span class="text-xl font-bold font-mono text-foreground">{{ est.metrics.physicsOnlyRMSE.toFixed(2) }}</span>
            <span class="text-xs text-muted-foreground font-mono">MW</span>
          </div>
          <span class="text-[10px] text-muted-foreground font-mono">Uncalibrated Brayton equations</span>
        </div>

        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-[11px] font-mono text-muted-foreground">CALIBRATED MODEL RMSE</span>
          <div class="mt-1 flex items-baseline gap-1.5">
            <span class="text-xl font-bold font-mono text-emerald-400">{{ est.metrics.calibratedPhysicsRMSE.toFixed(2) }}</span>
            <span class="text-xs text-muted-foreground font-mono">MW</span>
          </div>
          <span class="text-[10px] text-muted-foreground font-mono">Site-tuned multipliers</span>
        </div>

        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-[11px] font-mono text-muted-foreground">HYBRID DIGITAL TWIN RMSE</span>
          <div class="mt-1 flex items-baseline gap-1.5">
            <span class="text-xl font-bold font-mono text-primary">{{ est.metrics.hybridTwinRMSE.toFixed(2) }}</span>
            <span class="text-xs text-muted-foreground font-mono">MW</span>
          </div>
          <span class="text-[10px] text-muted-foreground font-mono">Physics + ML Residual correction</span>
        </div>

        <div class="p-3.5 rounded-xl bg-card border border-border">
          <span class="text-[11px] font-mono text-muted-foreground">ISOLATION CONFIDENCE</span>
          <div class="mt-1 flex items-baseline gap-1.5">
            <span class="text-xl font-bold font-mono text-foreground">{{ est.metrics.sensorIsolationConfidencePercent.toFixed(1) }}</span>
            <span class="text-xs text-muted-foreground font-mono">%</span>
          </div>
          <span class="text-[10px] text-muted-foreground font-mono">Statistical chi-square parity</span>
        </div>

      </div>

      <!-- 18 Synthetic Sensor Telemetry Table -->
      <div class="rounded-xl bg-card border border-border overflow-hidden">
        <div class="px-4 py-3 border-b border-border bg-muted/30 flex items-center justify-between">
          <span class="font-mono text-xs font-bold text-foreground">18-CHANNEL SYNTHETIC FIELD SENSOR TELEMETRY</span>
          <span class="font-mono text-[11px] text-muted-foreground">Sampling Rate: 10 Hz · Gaussian Noise & Bias Enabled</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono">
            <thead class="bg-muted/60 text-muted-foreground border-b border-border text-left">
              <tr>
                <th class="py-2.5 px-3">TAG</th>
                <th class="py-2.5 px-3">CHANNEL NAME</th>
                <th class="py-2.5 px-3 text-right">MEASURED</th>
                <th class="py-2.5 px-3 text-right">MODELLED</th>
                <th class="py-2.5 px-3 text-right">RESIDUAL (Δ)</th>
                <th class="py-2.5 px-3 text-center">UNIT</th>
                <th class="py-2.5 px-3 text-center">STATUS</th>
                <th class="py-2.5 px-3 text-center">ACTION</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-border/60">
              @for (s of sensors; track s.tag) {
                <tr class="hover:bg-muted/30 transition-colors" [class.bg-amber-500/5]="s.quality === 'DEGRADED'" [class.bg-red-500/5]="s.quality === 'FAILED'">
                  <td class="py-2.5 px-3 font-bold text-primary">{{ s.tag }}</td>
                  <td class="py-2.5 px-3 text-foreground">{{ s.name }}</td>
                  <td class="py-2.5 px-3 text-right font-bold tabular-nums" [class.text-amber-400]="s.quality === 'DEGRADED'" [class.text-red-400]="s.quality === 'FAILED'">
                    {{ s.measuredValue.toFixed(2) }}
                  </td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-muted-foreground">{{ s.modelledValue.toFixed(2) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums font-semibold" [class.text-amber-400]="Math.abs(s.residual) > 1" [class.text-muted-foreground]="Math.abs(s.residual) <= 1">
                    {{ s.residual >= 0 ? '+' : '' }}{{ s.residual.toFixed(2) }}
                  </td>
                  <td class="py-2.5 px-3 text-center text-muted-foreground">{{ s.engineeringUnit }}</td>
                  <td class="py-2.5 px-3 text-center">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-emerald-500/10]="s.quality === 'GOOD'"
                      [class.text-emerald-400]="s.quality === 'GOOD'"
                      [class.bg-blue-500/10]="s.quality === 'FAIR'"
                      [class.text-blue-400]="s.quality === 'FAIR'"
                      [class.bg-amber-500/10]="s.quality === 'DEGRADED'"
                      [class.text-amber-400]="s.quality === 'DEGRADED'"
                      [class.bg-red-500/10]="s.quality === 'FAILED'"
                      [class.text-red-400]="s.quality === 'FAILED'">
                      {{ s.quality }}
                    </span>
                  </td>
                  <td class="py-2.5 px-3 text-center">
                    <button
                      (click)="service.injectSensorFault(s.tag, 'DRIFT')"
                      title="Simulate drift on this sensor"
                      class="px-1.5 py-0.5 rounded text-[10px] bg-muted hover:bg-primary/20 text-muted-foreground hover:text-primary transition-colors">
                      Fault
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `,
})
export class DigitalTwinView {
  readonly service = inject(TurbineService);
  readonly Math = Math;
}
