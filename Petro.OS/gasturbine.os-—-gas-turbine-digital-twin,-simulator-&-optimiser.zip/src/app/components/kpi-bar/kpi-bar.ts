import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';

@Component({
  selector: 'app-kpi-bar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let cycle = service.currentCycle();
    @let exergy = service.currentExergy();
    @let health = service.componentHealth();
    @let gap = service.performanceGap();

    <section class="bg-card border-b border-border py-2.5 px-4 sm:px-6">
      <div class="max-w-7xl mx-auto">
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          
          <!-- KPI 1: Net Power -->
          <div class="p-2.5 rounded-lg bg-muted/40 border border-border/80 flex flex-col justify-between">
            <div class="flex items-center justify-between text-[11px] text-muted-foreground font-mono">
              <span>NET POWER</span>
              <span class="text-[9px] px-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">SIMULATED</span>
            </div>
            <div class="mt-1 flex items-baseline gap-1.5">
              <span class="text-xl font-bold font-mono tracking-tight text-foreground tabular-nums">
                {{ cycle.netElectricalPowerMW.toFixed(1) }}
              </span>
              <span class="text-xs text-muted-foreground font-mono">MW</span>
            </div>
            <div class="text-[10px] text-muted-foreground font-mono mt-0.5 flex items-center gap-1">
              <span [class.text-emerald-400]="gap.powerGapMW >= -1" [class.text-amber-400]="gap.powerGapMW < -1">
                {{ gap.powerGapMW >= 0 ? '+' : '' }}{{ gap.powerGapMW.toFixed(1) }} MW vs rated
              </span>
            </div>
          </div>

          <!-- KPI 2: Thermal Efficiency -->
          <div class="p-2.5 rounded-lg bg-muted/40 border border-border/80 flex flex-col justify-between">
            <div class="flex items-center justify-between text-[11px] text-muted-foreground font-mono">
              <span>THERMAL η</span>
              <span class="text-[9px] px-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">1ST LAW</span>
            </div>
            <div class="mt-1 flex items-baseline gap-1.5">
              <span class="text-xl font-bold font-mono tracking-tight text-foreground tabular-nums">
                {{ cycle.thermalEfficiencyPercent.toFixed(2) }}
              </span>
              <span class="text-xs text-muted-foreground font-mono">%</span>
            </div>
            <div class="text-[10px] text-muted-foreground font-mono mt-0.5">
              <span>Gross: {{ ((cycle.shaftMechanicalPowerMW / (cycle.fuelFlowKgS * cycle.fuel.lhvMJkg)) * 100).toFixed(2) }}%</span>
            </div>
          </div>

          <!-- KPI 3: Heat Rate -->
          <div class="p-2.5 rounded-lg bg-muted/40 border border-border/80 flex flex-col justify-between">
            <div class="flex items-center justify-between text-[11px] text-muted-foreground font-mono">
              <span>HEAT RATE (LHV)</span>
              <span class="text-[9px] px-1 rounded bg-muted text-muted-foreground">ISO BASIS</span>
            </div>
            <div class="mt-1 flex items-baseline gap-1.5">
              <span class="text-xl font-bold font-mono tracking-tight text-foreground tabular-nums">
                {{ cycle.netHeatRateKJKWh_LHV.toFixed(0) }}
              </span>
              <span class="text-xs text-muted-foreground font-mono">kJ/kWh</span>
            </div>
            <div class="text-[10px] text-muted-foreground font-mono mt-0.5">
              <span>{{ cycle.netHeatRateBtuKWh.toFixed(0) }} Btu/kWh</span>
            </div>
          </div>

          <!-- KPI 4: Exergy Efficiency -->
          <div class="p-2.5 rounded-lg bg-muted/40 border border-border/80 flex flex-col justify-between">
            <div class="flex items-center justify-between text-[11px] text-muted-foreground font-mono">
              <span>EXERGY η</span>
              <span class="text-[9px] px-1 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">2ND LAW</span>
            </div>
            <div class="mt-1 flex items-baseline gap-1.5">
              <span class="text-xl font-bold font-mono tracking-tight text-foreground tabular-nums">
                {{ exergy.overallExergyEfficiencyPercent.toFixed(2) }}
              </span>
              <span class="text-xs text-muted-foreground font-mono">%</span>
            </div>
            <div class="text-[10px] text-muted-foreground font-mono mt-0.5">
              <span>Destruction: {{ exergy.totalExergyDestructionMW.toFixed(1) }} MW</span>
            </div>
          </div>

          <!-- KPI 5: Machine Health -->
          <div class="p-2.5 rounded-lg bg-muted/40 border border-border/80 flex flex-col justify-between">
            <div class="flex items-center justify-between text-[11px] text-muted-foreground font-mono">
              <span>TURBINE HEALTH</span>
              <span class="text-[9px] px-1 rounded"
                [class.bg-emerald-500/10]="health.overallTurbineHealthPercent >= 90"
                [class.text-emerald-400]="health.overallTurbineHealthPercent >= 90"
                [class.bg-amber-500/10]="health.overallTurbineHealthPercent < 90"
                [class.text-amber-400]="health.overallTurbineHealthPercent < 90">
                {{ health.overallTurbineHealthPercent >= 90 ? 'HEALTHY' : 'DEGRADED' }}
              </span>
            </div>
            <div class="mt-1 flex items-baseline gap-1.5">
              <span class="text-xl font-bold font-mono tracking-tight text-foreground tabular-nums">
                {{ health.overallTurbineHealthPercent.toFixed(1) }}
              </span>
              <span class="text-xs text-muted-foreground font-mono">%</span>
            </div>
            <div class="text-[10px] text-muted-foreground font-mono mt-0.5">
              <span>Comp: {{ health.compressorHealthPercent.toFixed(0) }}% | Turb: {{ health.turbineHealthPercent.toFixed(0) }}%</span>
            </div>
          </div>

          <!-- KPI 6: Conservation Balance -->
          <div class="p-2.5 rounded-lg bg-muted/40 border border-border/80 flex flex-col justify-between">
            <div class="flex items-center justify-between text-[11px] text-muted-foreground font-mono">
              <span>ENERGY BALANCE</span>
              <span class="text-[9px] px-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">CLOSED</span>
            </div>
            <div class="mt-1 flex items-baseline gap-1.5">
              <span class="text-xl font-bold font-mono tracking-tight text-foreground tabular-nums">
                {{ cycle.energyBalance.residualPercent.toFixed(3) }}
              </span>
              <span class="text-xs text-muted-foreground font-mono">% err</span>
            </div>
            <div class="text-[10px] text-emerald-400/80 font-mono mt-0.5 flex items-center gap-1">
              <mat-icon class="!text-xs !w-3 !h-3">check_circle</mat-icon>
              <span>Mass & Energy Conserved</span>
            </div>
          </div>

        </div>
      </div>
    </section>
  `,
})
export class KpiBar {
  readonly service = inject(TurbineService);
}
