import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';

@Component({
  selector: 'app-diagnostics-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let health = service.componentHealth();
    @let gap = service.performanceGap();
    @let findings = service.diagnosticFindings();
    @let cycle = service.currentCycle();

    <div class="space-y-6">
      
      <!-- Top Title & Health Index -->
      <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-card border border-border">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-base font-bold font-mono text-foreground">FAULT DIAGNOSTICS & HEALTH INDEX ENGINE</h2>
            <span class="text-xs px-2 py-0.5 rounded font-mono border"
              [class.bg-emerald-500/10]="health.overallTurbineHealthPercent >= 90"
              [class.text-emerald-400]="health.overallTurbineHealthPercent >= 90"
              [class.border-emerald-500/20]="health.overallTurbineHealthPercent >= 90"
              [class.bg-amber-500/10]="health.overallTurbineHealthPercent < 90"
              [class.text-amber-400]="health.overallTurbineHealthPercent < 90"
              [class.border-amber-500/20]="health.overallTurbineHealthPercent < 90">
              FLEET HEALTH: {{ health.overallTurbineHealthPercent.toFixed(1) }}% ({{ health.compressorHealthStatus }})
            </span>
          </div>
          <p class="text-xs text-muted-foreground mt-1">
            Deterministic diagnostic reasoning engine generating structured hypotheses, physical evidence citations, and confidence scores.
          </p>
        </div>

        <button
          (click)="service.simulateCompressorWash()"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-mono font-medium hover:bg-primary/90 transition-colors shadow-sm">
          <mat-icon class="!text-sm !w-4 !h-4">water_drop</mat-icon>
          <span>Trigger Compressor Wash</span>
        </button>
      </div>

      <!-- Component Health Cards Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
        
        <!-- Compressor Health -->
        <div class="p-3.5 rounded-xl bg-card border border-border flex flex-col justify-between">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="text-muted-foreground">COMPRESSOR</span>
            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold"
              [class.bg-emerald-500/10]="health.compressorHealthPercent >= 90"
              [class.text-emerald-400]="health.compressorHealthPercent >= 90"
              [class.bg-amber-500/10]="health.compressorHealthPercent < 90"
              [class.text-amber-400]="health.compressorHealthPercent < 90">
              {{ health.compressorHealthStatus }}
            </span>
          </div>
          <div class="my-2">
            <span class="text-2xl font-bold font-mono text-foreground">{{ health.compressorHealthPercent.toFixed(1) }}%</span>
          </div>
          <div class="text-[10px] text-muted-foreground font-mono truncate" title="{{ health.underlyingMath.compressorFormula }}">
            {{ health.underlyingMath.compressorFormula }}
          </div>
        </div>

        <!-- Turbine Health -->
        <div class="p-3.5 rounded-xl bg-card border border-border flex flex-col justify-between">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="text-muted-foreground">TURBINE HOT PATH</span>
            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold"
              [class.bg-emerald-500/10]="health.turbineHealthPercent >= 90"
              [class.text-emerald-400]="health.turbineHealthPercent >= 90"
              [class.bg-amber-500/10]="health.turbineHealthPercent < 90"
              [class.text-amber-400]="health.turbineHealthPercent < 90">
              {{ health.turbineHealthStatus }}
            </span>
          </div>
          <div class="my-2">
            <span class="text-2xl font-bold font-mono text-foreground">{{ health.turbineHealthPercent.toFixed(1) }}%</span>
          </div>
          <div class="text-[10px] text-muted-foreground font-mono truncate" title="{{ health.underlyingMath.turbineFormula }}">
            {{ health.underlyingMath.turbineFormula }}
          </div>
        </div>

        <!-- Combustor Health -->
        <div class="p-3.5 rounded-xl bg-card border border-border flex flex-col justify-between">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="text-muted-foreground">COMBUSTOR</span>
            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400">
              {{ health.combustorHealthStatus }}
            </span>
          </div>
          <div class="my-2">
            <span class="text-2xl font-bold font-mono text-foreground">{{ health.combustorHealthPercent.toFixed(1) }}%</span>
          </div>
          <div class="text-[10px] text-muted-foreground font-mono truncate">
            η_comb: {{ cycle.combustorEfficiencyPercent.toFixed(1) }}%
          </div>
        </div>

        <!-- Inlet Filter Health -->
        <div class="p-3.5 rounded-xl bg-card border border-border flex flex-col justify-between">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="text-muted-foreground">INLET FILTER</span>
            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold"
              [class.bg-emerald-500/10]="health.inletHealthPercent >= 90"
              [class.text-emerald-400]="health.inletHealthPercent >= 90"
              [class.bg-amber-500/10]="health.inletHealthPercent < 90"
              [class.text-amber-400]="health.inletHealthPercent < 90">
              {{ health.inletHealthStatus }}
            </span>
          </div>
          <div class="my-2">
            <span class="text-2xl font-bold font-mono text-foreground">{{ health.inletHealthPercent.toFixed(1) }}%</span>
          </div>
          <div class="text-[10px] text-muted-foreground font-mono truncate">
            ΔP: {{ (cycle.inletFilterLossPercent * 10).toFixed(1) }} mbar
          </div>
        </div>

        <!-- Generator Health -->
        <div class="p-3.5 rounded-xl bg-card border border-border flex flex-col justify-between">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="text-muted-foreground">GENERATOR</span>
            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400">
              EXCELLENT
            </span>
          </div>
          <div class="my-2">
            <span class="text-2xl font-bold font-mono text-foreground">{{ health.generatorHealthPercent.toFixed(1) }}%</span>
          </div>
          <div class="text-[10px] text-muted-foreground font-mono truncate">
            η_gen: {{ cycle.generatorEfficiencyPercent.toFixed(2) }}%
          </div>
        </div>

      </div>

      <!-- Performance Gap Ledger -->
      <div class="p-4 rounded-xl bg-card border border-border">
        <div class="flex items-center justify-between pb-3 border-b border-border/60 mb-3">
          <span class="font-mono text-xs font-bold text-foreground">PERFORMANCE GAP LEDGER (ACTUAL VS NOMINAL DESIGN BASELINE)</span>
          <span class="text-[11px] font-mono text-muted-foreground">Quantified Output Penalties</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
          <div class="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">POWER DEFICIT</span>
            <div class="text-sm font-bold mt-1" [class.text-emerald-400]="gap.powerGapMW >= 0" [class.text-amber-400]="gap.powerGapMW < 0">
              {{ gap.powerGapMW >= 0 ? '+' : '' }}{{ gap.powerGapMW.toFixed(1) }} MW
            </div>
          </div>

          <div class="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">HEAT RATE PENALTY</span>
            <div class="text-sm font-bold mt-1" [class.text-emerald-400]="gap.heatRateGapKJKWh <= 0" [class.text-amber-400]="gap.heatRateGapKJKWh > 0">
              {{ gap.heatRateGapKJKWh >= 0 ? '+' : '' }}{{ gap.heatRateGapKJKWh.toFixed(0) }} kJ/kWh
            </div>
          </div>

          <div class="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">EFFICIENCY GAP</span>
            <div class="text-sm font-bold mt-1" [class.text-emerald-400]="gap.efficiencyGapPercent >= 0" [class.text-amber-400]="gap.efficiencyGapPercent < 0">
              {{ gap.efficiencyGapPercent >= 0 ? '+' : '' }}{{ gap.efficiencyGapPercent.toFixed(2) }}%
            </div>
          </div>

          <div class="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">EGT DEVIATION</span>
            <div class="text-sm font-bold mt-1" [class.text-amber-400]="gap.exhaustTempGapC > 5" [class.text-foreground]="gap.exhaustTempGapC <= 5">
              {{ gap.exhaustTempGapC >= 0 ? '+' : '' }}{{ gap.exhaustTempGapC.toFixed(1) }}°C
            </div>
          </div>

          <div class="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">AIR FLOW DEFICIT</span>
            <div class="text-sm font-bold mt-1" [class.text-amber-400]="gap.airMassFlowGapKgS < -10" [class.text-foreground]="gap.airMassFlowGapKgS >= -10">
              {{ gap.airMassFlowGapKgS >= 0 ? '+' : '' }}{{ gap.airMassFlowGapKgS.toFixed(1) }} kg/s
            </div>
          </div>

          <div class="p-2.5 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">SURGE MARGIN</span>
            <div class="text-sm font-bold mt-1 text-emerald-400">
              {{ cycle.surgeMarginPercent.toFixed(1) }}%
            </div>
          </div>
        </div>
      </div>

      <!-- Structured Diagnostic Findings (Observation, Hypothesis, Evidence, Confidence) -->
      <div class="space-y-4">
        <div class="flex items-center justify-between">
          <span class="font-mono text-xs font-bold text-foreground">ACTIVE DIAGNOSTIC FINDINGS & PHYSICAL REASONING</span>
          <span class="text-xs font-mono text-muted-foreground">{{ findings.length }} finding(s) identified</span>
        </div>

        @for (f of findings; track f.id) {
          <div class="p-4 rounded-xl bg-card border"
            [class.border-red-500/40]="f.severity === 'CRITICAL'"
            [class.border-amber-500/40]="f.severity === 'WARNING'"
            [class.border-border]="f.severity === 'INFO'">
            
            <!-- Header -->
            <div class="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-border/60">
              <div class="flex items-center gap-2">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                  [class.bg-red-500/10]="f.severity === 'CRITICAL'"
                  [class.text-red-400]="f.severity === 'CRITICAL'"
                  [class.bg-amber-500/10]="f.severity === 'WARNING'"
                  [class.text-amber-400]="f.severity === 'WARNING'"
                  [class.bg-blue-500/10]="f.severity === 'INFO'"
                  [class.text-blue-400]="f.severity === 'INFO'">
                  {{ f.severity }}
                </span>
                <span class="font-mono text-sm font-bold text-foreground">{{ f.title }}</span>
              </div>

              <div class="flex items-center gap-2 text-xs font-mono">
                <span class="text-muted-foreground">CONFIDENCE:</span>
                <span class="font-bold text-primary">{{ f.confidencePercent.toFixed(1) }}%</span>
              </div>
            </div>

            <!-- Body -->
            <div class="mt-3 space-y-2 text-xs font-mono">
              <div>
                <span class="font-bold text-muted-foreground">OBSERVATION:</span>
                <p class="text-foreground mt-0.5">{{ f.observation }}</p>
              </div>

              <div>
                <span class="font-bold text-muted-foreground">HYPOTHESIS:</span>
                <p class="text-foreground mt-0.5">{{ f.hypothesis }}</p>
              </div>

              <div>
                <span class="font-bold text-muted-foreground">PHYSICAL EVIDENCE:</span>
                <ul class="list-disc list-inside mt-0.5 space-y-0.5 text-muted-foreground">
                  @for (e of f.evidence; track e) {
                    <li>{{ e }}</li>
                  }
                </ul>
              </div>

              <div class="pt-2 border-t border-border/60 flex items-start gap-2">
                <mat-icon class="!text-sm !w-4 !h-4 text-emerald-400 shrink-0 mt-0.5">build</mat-icon>
                <div>
                  <span class="font-bold text-emerald-400">RECOMMENDED ACTION:</span>
                  <span class="text-foreground ml-1">{{ f.recommendedAction }}</span>
                </div>
              </div>
            </div>

          </div>
        }
      </div>

    </div>
  `,
})
export class DiagnosticsView {
  readonly service = inject(TurbineService);
}
