import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';

@Component({
  selector: 'app-exergy-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let exergy = service.currentExergy();
    @let cycle = service.currentCycle();

    <div class="space-y-6">
      
      <!-- Top Title & 2nd Law Summary -->
      <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-card border border-border">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-base font-bold font-mono text-foreground">SECOND-LAW EXERGY & IRREVERSIBILITY ENGINE</h2>
            <span class="text-xs px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 font-mono border border-purple-500/20">
              SECOND-LAW EFFICIENCY: {{ exergy.overallExergyEfficiencyPercent.toFixed(2) }}%
            </span>
          </div>
          <p class="text-xs text-muted-foreground mt-1">
            Pinpoints exact physical irreversibilities, entropy generation rates (S_gen), and thermodynamic degradation across every machine component.
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono">
          <span class="px-2.5 py-1 rounded bg-muted border border-border text-foreground">
            FUEL EXERGY: {{ exergy.fuelTotalExergyMW.toFixed(1) }} MW
          </span>
          <span class="px-2.5 py-1 rounded bg-muted border border-border text-foreground">
            WORK PRODUCED: {{ exergy.netExergyOutputMW.toFixed(1) }} MW
          </span>
          <span class="px-2.5 py-1 rounded bg-purple-500/10 border border-purple-500/30 text-purple-400">
            TOTAL DESTRUCTION: {{ exergy.totalExergyDestructionMW.toFixed(1) }} MW
          </span>
        </div>
      </div>

      <!-- Exergy Flow Sankey Diagram Canvas -->
      <div class="p-4 rounded-xl bg-card border border-border">
        <div class="flex items-center justify-between pb-3 border-b border-border/60 mb-3">
          <span class="font-mono text-xs font-bold text-foreground">EXERGY SANKEY FLOW & IRREVERSIBILITY PARTITION</span>
          <span class="text-[11px] font-mono text-muted-foreground">Dead-State Reference T0 = 288.15 K, P0 = 1.013 bar</span>
        </div>

        <div class="w-full h-72 bg-slate-950/70 rounded-lg p-3 border border-border/60 flex items-center justify-center">
          <svg viewBox="0 0 800 240" class="w-full h-full select-none" xmlns="http://www.w3.org/2000/svg">
            <!-- Node: Fuel Exergy Input (Left) -->
            <rect x="20" y="80" width="130" height="70" rx="6" fill="#f59e0b" fill-opacity="0.2" stroke="#f59e0b" stroke-width="2"/>
            <text x="85" y="110" fill="#f59e0b" font-family="monospace" font-size="11" font-weight="bold" text-anchor="middle">FUEL EXERGY</text>
            <text x="85" y="130" fill="#ffffff" font-family="monospace" font-size="12" font-weight="bold" text-anchor="middle">{{ exergy.fuelTotalExergyMW.toFixed(1) }} MW</text>

            <!-- Flow link 1: Fuel to Combustor -->
            <path d="M 150 115 L 260 115" stroke="#f59e0b" stroke-width="32" fill="none" opacity="0.6"/>

            <!-- Node: Combustor (Center) -->
            <rect x="260" y="45" width="140" height="140" rx="6" fill="#ef4444" fill-opacity="0.2" stroke="#ef4444" stroke-width="2"/>
            <text x="330" y="80" fill="#ef4444" font-family="monospace" font-size="11" font-weight="bold" text-anchor="middle">COMBUSTOR</text>
            <text x="330" y="100" fill="#ffffff" font-family="monospace" font-size="10" text-anchor="middle">TIT {{ (cycle.state3_tit.temperatureK - 273.15).toFixed(0) }}°C</text>

            <!-- Destruction branch 1: Combustor Irreversibility (Upwards) -->
            <path d="M 330 45 L 330 15 L 430 15" stroke="#94a3b8" stroke-width="16" fill="none" stroke-dasharray="4 2" opacity="0.7"/>
            <text x="440" y="19" fill="#f87171" font-family="monospace" font-size="10" font-weight="bold">
              Combustor Destruction ({{ exergy.components[2].exergyDestructionMW.toFixed(1) }} MW · {{ exergy.components[2].percentOfTotalDestruction.toFixed(0) }}%)
            </text>

            <!-- Flow link 2: Combustor to Turbine Expander -->
            <path d="M 400 115 L 490 115" stroke="#38bdf8" stroke-width="24" fill="none" opacity="0.6"/>

            <!-- Node: Turbine Expander -->
            <rect x="490" y="60" width="130" height="110" rx="6" fill="#0284c7" fill-opacity="0.2" stroke="#0284c7" stroke-width="2"/>
            <text x="555" y="95" fill="#38bdf8" font-family="monospace" font-size="11" font-weight="bold" text-anchor="middle">TURBINE</text>
            <text x="555" y="115" fill="#ffffff" font-family="monospace" font-size="10" text-anchor="middle">Gross: {{ cycle.turbineGrossPowerMW.toFixed(1) }} MW</text>

            <!-- Destruction branch 2: Exhaust Stack Loss (Downwards) -->
            <path d="M 555 170 L 555 210 L 440 210" stroke="#94a3b8" stroke-width="10" fill="none" stroke-dasharray="4 2" opacity="0.7"/>
            <text x="430" y="214" fill="#94a3b8" font-family="monospace" font-size="10" text-anchor="end">
              Exhaust Exergy Loss ({{ exergy.components[5].exergyDestructionMW.toFixed(1) }} MW)
            </text>

            <!-- Flow link 3: Shaft to Generator -->
            <path d="M 620 115 L 680 115" stroke="#10b981" stroke-width="16" fill="none" opacity="0.8"/>

            <!-- Node: Electrical Power Output (Right) -->
            <rect x="680" y="80" width="105" height="70" rx="6" fill="#10b981" fill-opacity="0.25" stroke="#10b981" stroke-width="2"/>
            <text x="732" y="110" fill="#10b981" font-family="monospace" font-size="11" font-weight="bold" text-anchor="middle">NET WORK</text>
            <text x="732" y="130" fill="#ffffff" font-family="monospace" font-size="12" font-weight="bold" text-anchor="middle">{{ exergy.netExergyOutputMW.toFixed(1) }} MW</text>
          </svg>
        </div>
      </div>

      <!-- Component-by-Component Irreversibility Table -->
      <div class="rounded-xl bg-card border border-border overflow-hidden">
        <div class="px-4 py-3 border-b border-border bg-muted/30 flex items-center justify-between">
          <span class="font-mono text-xs font-bold text-foreground">COMPONENT EXERGY DESTRUCTION & THERMODYNAMIC LOSS MECHANISMS</span>
          <span class="font-mono text-[11px] text-muted-foreground">Detailed Irreversibility Ledger</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono">
            <thead class="bg-muted/60 text-muted-foreground border-b border-border text-left">
              <tr>
                <th class="py-2.5 px-3">COMPONENT</th>
                <th class="py-2.5 px-3 text-right">EXERGY IN [MW]</th>
                <th class="py-2.5 px-3 text-right">EXERGY OUT [MW]</th>
                <th class="py-2.5 px-3 text-right">DESTRUCTION [MW]</th>
                <th class="py-2.5 px-3 text-right">SHARE [%]</th>
                <th class="py-2.5 px-3 text-right">EXERGY η [%]</th>
                <th class="py-2.5 px-4">PHYSICAL ROOT CAUSE</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-border/60">
              @for (c of exergy.components; track c.componentName) {
                <tr class="hover:bg-muted/30 transition-colors">
                  <td class="py-2.5 px-3 font-bold text-foreground">{{ c.componentName }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-muted-foreground">{{ c.exergyInMW.toFixed(1) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-muted-foreground">{{ c.exergyOutMW.toFixed(1) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums font-bold" [class.text-amber-400]="c.exergyDestructionMW > 50" [class.text-foreground]="c.exergyDestructionMW <= 50">
                    {{ c.exergyDestructionMW.toFixed(2) }}
                  </td>
                  <td class="py-2.5 px-3 text-right tabular-nums font-semibold text-purple-400">
                    {{ c.percentOfTotalDestruction.toFixed(1) }}%
                  </td>
                  <td class="py-2.5 px-3 text-right tabular-nums font-semibold text-emerald-400">
                    {{ c.exergyEfficiencyPercent.toFixed(1) }}%
                  </td>
                  <td class="py-2.5 px-4 text-muted-foreground text-[11px]">{{ c.thermodynamicCause }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `,
})
export class ExergyView {
  readonly service = inject(TurbineService);
}
