import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';
import { SIGNATURE_DEMOS } from '../../engine/scenarios/signature-demos';

@Component({
  selector: 'app-scenarios-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let cycle = service.currentCycle();
    @let hPoints = service.historianPoints();
    @let selHPoint = hPoints[service.selectedHistorianIndex()] || hPoints[0];

    <div class="space-y-6">
      
      <!-- Top Title -->
      <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-card border border-border">
        <div>
          <h2 class="text-base font-bold font-mono text-foreground">SIGNATURE ENGINEERING DEMOS & PHYSICAL LABS</h2>
          <p class="text-xs text-muted-foreground mt-1">
            Curated interactive demonstration suites showcasing Brayton thermodynamics, hydrogen co-firing, degradation recovery, and 20-year fleet historian replay.
          </p>
        </div>
      </div>

      <!-- 8 Signature Demos Launcher Grid -->
      <div>
        <div class="flex items-center justify-between mb-3">
          <span class="font-mono text-xs font-bold text-foreground">8 SIGNATURE ENGINEERING DEMONSTRATIONS</span>
          <span class="text-xs font-mono text-muted-foreground">Select a demo to load its operational baseline</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
          @for (demo of demos; track demo.id) {
            <button
              type="button"
              (click)="service.launchDemo(demo)"
              [class.border-primary]="service.selectedDemo().id === demo.id"
              [class.bg-primary/5]="service.selectedDemo().id === demo.id"
              class="p-4 rounded-xl bg-card border border-border hover:border-primary/60 cursor-pointer transition-all flex flex-col justify-between group text-left">
              
              <div>
                <div class="flex items-center justify-between gap-2 mb-2">
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-muted text-muted-foreground border border-border group-hover:border-primary/30">
                    DEMO 0{{ demo.number }}
                  </span>
                  <span class="text-[10px] font-mono text-primary font-bold">{{ demo.badge }}</span>
                </div>
                <h3 class="font-mono text-xs font-bold text-foreground group-hover:text-primary transition-colors">
                  {{ demo.title }}
                </h3>
                <p class="text-[11px] text-muted-foreground mt-1.5 line-clamp-2">
                  {{ demo.description }}
                </p>
              </div>

              <div class="mt-3 pt-2.5 border-t border-border/60 flex items-center justify-between text-xs font-mono text-primary">
                <span>Run Scenario</span>
                <mat-icon class="!text-sm !w-4 !h-4 group-hover:translate-x-0.5 transition-transform">arrow_forward</mat-icon>
              </div>

            </button>
          }
        </div>
      </div>

      <!-- Laboratory 1: Hydrogen Co-Firing Decarbonisation Lab -->
      <div class="p-5 rounded-xl bg-card border border-border">
        <div class="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-border/60 mb-4">
          <div>
            <span class="font-mono text-xs font-bold text-foreground">HYDROGEN BLEND CO-FIRING LABORATORY (0% – 100% H2)</span>
            <div class="text-[11px] text-muted-foreground font-mono mt-0.5">
              Evaluating volumetric fuel demands, Wobbe Index stability, and thermal NOx formation.
            </div>
          </div>

          <span class="text-xs px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 font-mono border border-emerald-500/20 font-bold">
            CO2 REDUCTION: -{{ (service.hydrogenVolPercent() * 0.75).toFixed(1) }}%
          </span>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <!-- Slider Control -->
          <div class="lg:col-span-1 p-4 rounded-lg bg-muted/40 border border-border flex flex-col justify-between">
            <div>
              <div class="flex items-center justify-between text-xs font-mono mb-2">
                <span class="text-muted-foreground font-bold">H2 VOLUME FRACTION:</span>
                <span class="text-base font-bold text-emerald-400">{{ service.hydrogenVolPercent() }}% H2</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                [value]="service.hydrogenVolPercent()"
                (input)="onH2Slide($event)"
                class="w-full h-2 bg-border rounded-lg appearance-none cursor-pointer accent-emerald-500"/>
              <div class="flex justify-between text-[10px] text-muted-foreground font-mono mt-1">
                <span>0% (Natural Gas)</span>
                <span>50%</span>
                <span>100% (Green H2)</span>
              </div>
            </div>

            <div class="mt-4 text-[11px] text-muted-foreground font-mono space-y-1">
              <div>• Fuel LHV: <strong>{{ cycle.fuel.lhvMJkg.toFixed(2) }} MJ/kg</strong></div>
              <div>• Stoichiometric AFR: <strong>{{ cycle.fuel.stoichiometricAfr.toFixed(2) }}</strong></div>
            </div>
          </div>

          <!-- Decarbonisation Physics Grid -->
          <div class="lg:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">WOBBE INDEX</span>
              <div class="text-sm font-bold text-foreground mt-1">{{ cycle.fuel.wobbeIndexMJNm3.toFixed(1) }} MJ/Nm³</div>
              <span class="text-[10px] text-muted-foreground">Burner interchangeability</span>
            </div>

            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">SPECIFIC CO2</span>
              <div class="text-sm font-bold text-emerald-400 mt-1">{{ cycle.emissions.co2SpecificGPerKWh.toFixed(0) }} g/kWh</div>
              <span class="text-[10px] text-muted-foreground">Carbon mass intensity</span>
            </div>

            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">STACK NOX</span>
              <div class="text-sm font-bold mt-1" [class.text-amber-400]="cycle.emissions.noxPpmvd15O2 > 15" [class.text-foreground]="cycle.emissions.noxPpmvd15O2 <= 15">
                {{ cycle.emissions.noxPpmvd15O2.toFixed(1) }} ppmvd
              </div>
              <span class="text-[10px] text-muted-foreground">Thermal flame peak</span>
            </div>

            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">VOLUMETRIC MULTIPLIER</span>
              <div class="text-sm font-bold text-foreground mt-1">{{ (1.0 + service.hydrogenVolPercent() * 0.022).toFixed(2) }}x</div>
              <span class="text-[10px] text-muted-foreground">Gas manifold capacity required</span>
            </div>

            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">MOISTURE IN EXHAUST</span>
              <div class="text-sm font-bold text-foreground mt-1">{{ (cycle.state4_egt.composition.H2O * 100).toFixed(1) }}% mol</div>
              <span class="text-[10px] text-muted-foreground">H2O vapor mass fraction</span>
            </div>

            <div class="p-3 rounded-lg bg-muted/30 border border-border">
              <span class="text-muted-foreground">FLAME TEMPERATURE</span>
              <div class="text-sm font-bold text-foreground mt-1">{{ cycle.fuel.maxFlameTempK.toFixed(0) }} K</div>
              <span class="text-[10px] text-muted-foreground">Adiabatic flame speed boost</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Laboratory 2: 20-Year Operational Historian Time Machine -->
      <div class="p-5 rounded-xl bg-card border border-border">
        <div class="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-border/60 mb-4">
          <div>
            <span class="font-mono text-xs font-bold text-foreground">20-YEAR OPERATIONAL HISTORIAN TIME MACHINE (2006 – 2026)</span>
            <div class="text-[11px] text-muted-foreground font-mono mt-0.5">
              Deterministic plant operational history scrubbing across 240 operating months.
            </div>
          </div>

          <div class="text-xs font-mono text-foreground font-bold px-2.5 py-1 rounded bg-muted border border-border">
            REPLAY DATE: {{ selHPoint.dateStr }} (Month {{ selHPoint.monthIndex }})
          </div>
        </div>

        <!-- Historian Slider -->
        <div class="mb-4">
          <input
            type="range"
            min="0"
            [max]="hPoints.length - 1"
            step="1"
            [value]="service.selectedHistorianIndex()"
            (input)="onHistorianSlide($event)"
            class="w-full h-2 bg-border rounded-lg appearance-none cursor-pointer accent-primary"/>
          <div class="flex justify-between text-[10px] text-muted-foreground font-mono mt-1">
            <span>2006 (Commissioning)</span>
            <span>2016 (Mid-Life Overhaul)</span>
            <span>2026 (Present Day)</span>
          </div>
        </div>

        <!-- Historian Snapshot Card -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
          <div class="p-3 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">RECORDED POWER</span>
            <div class="text-sm font-bold text-foreground mt-1">{{ selHPoint.loadMW.toFixed(1) }} MW</div>
          </div>
          <div class="p-3 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">HISTORIC EFFICIENCY</span>
            <div class="text-sm font-bold text-foreground mt-1">{{ selHPoint.efficiencyPercent.toFixed(2) }}%</div>
          </div>
          <div class="p-3 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">HISTORIC HEAT RATE</span>
            <div class="text-sm font-bold text-foreground mt-1">{{ selHPoint.heatRateKJKWh.toFixed(0) }} kJ/kWh</div>
          </div>
          <div class="p-3 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">SEASONAL AMBIENT</span>
            <div class="text-sm font-bold text-foreground mt-1">{{ selHPoint.ambientTempC.toFixed(1) }}°C</div>
          </div>
          <div class="p-3 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">COMPRESSOR HEALTH</span>
            <div class="text-sm font-bold text-emerald-400 mt-1">{{ selHPoint.compressorHealthPercent.toFixed(1) }}%</div>
          </div>
          <div class="p-3 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground">TURBINE HEALTH</span>
            <div class="text-sm font-bold text-emerald-400 mt-1">{{ selHPoint.turbineHealthPercent.toFixed(1) }}%</div>
          </div>
        </div>

        @if (selHPoint.events.length > 0) {
          <div class="mt-3 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 text-xs font-mono text-blue-400 flex items-center gap-2">
            <mat-icon class="!text-sm !w-4 !h-4">event_note</mat-icon>
            <span>MAINTENANCE EVENT LOGGED: {{ selHPoint.events.join(' · ') }}</span>
          </div>
        }
      </div>

    </div>
  `,
})
export class ScenariosView {
  readonly service = inject(TurbineService);
  readonly demos = SIGNATURE_DEMOS;

  onH2Slide(event: Event): void {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.service.setHydrogenBlend(val);
  }

  onHistorianSlide(event: Event): void {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.service.selectedHistorianIndex.set(val);
  }
}
