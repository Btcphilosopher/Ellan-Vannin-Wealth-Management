import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OperatingMode, TurbineService } from '../../services/turbine.service';
import { TURBINE_PRESETS } from '../../engine/digital-twin/synthetic-plant';

@Component({
  selector: 'app-header-bar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="border-b border-border bg-card/90 backdrop-blur-md sticky top-0 z-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        
        <!-- Brand & Machine Spec -->
        <div class="flex items-center gap-3 min-w-0">
          <div class="flex items-center gap-2">
            <div class="w-7 h-7 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center text-primary">
              <mat-icon class="!text-lg !w-5 !h-5 leading-none">precision_manufacturing</mat-icon>
            </div>
            <div>
              <span class="font-bold text-sm tracking-tight text-foreground font-mono">GASTURBINE.OS</span>
              <span class="hidden sm:inline-block ml-2 text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-muted text-muted-foreground border border-border">v3.7-ENG</span>
            </div>
          </div>

          <div class="h-4 w-px bg-border hidden md:block"></div>

          <!-- Machine Preset Selector -->
          <div class="hidden lg:flex items-center gap-1.5">
            <span class="text-xs text-muted-foreground font-mono">FRAME:</span>
            <select
              [value]="service.activePresetKey()"
              (change)="onPresetChange($event)"
              class="text-xs bg-muted/60 border border-border rounded px-2 py-1 text-foreground font-mono focus:outline-none focus:border-primary/60 cursor-pointer">
              @for (preset of presetKeys; track preset) {
                <option [value]="preset">{{ presets[preset].name }}</option>
              }
            </select>
          </div>
        </div>

        <!-- Navigation Mode Tabs -->
        <nav class="flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
          @for (tab of navTabs; track tab.mode) {
            <button
              (click)="service.setMode(tab.mode)"
              [class]="service.currentMode() === tab.mode 
                ? 'bg-primary text-primary-foreground font-medium shadow-sm' 
                : 'text-muted-foreground hover:text-foreground hover:bg-muted/60'"
              class="flex items-center gap-1.5 px-2.5 py-1.2 rounded-md text-xs transition-all whitespace-nowrap">
              <mat-icon class="!text-base !w-4 !h-4">{{ tab.icon }}</mat-icon>
              <span>{{ tab.label }}</span>
            </button>
          }
        </nav>

        <!-- Right Quick Actions -->
        <div class="flex items-center gap-2">
          <!-- Ambient Selector -->
          <div class="hidden sm:flex items-center gap-1 text-xs">
            <button
              (click)="service.setAmbientPreset('ISO_DAY')"
              [class.bg-muted]="service.ambientPresetKey() === 'ISO_DAY'"
              class="px-2 py-1 rounded text-[11px] font-mono border border-border text-muted-foreground hover:text-foreground">
              ISO 15°C
            </button>
            <button
              (click)="service.setAmbientPreset('HOT_DAY')"
              [class.bg-muted]="service.ambientPresetKey() === 'HOT_DAY'"
              class="px-2 py-1 rounded text-[11px] font-mono border border-border text-muted-foreground hover:text-foreground">
              HOT 35°C
            </button>
          </div>

          <!-- Reset / Clear Faults -->
          <button
            (click)="service.clearFaults()"
            title="Reset to Nominal Baseline"
            class="p-1.5 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground border border-border transition-colors">
            <mat-icon class="!text-sm !w-4 !h-4">restart_alt</mat-icon>
          </button>
        </div>

      </div>
    </header>
  `,
})
export class HeaderBar {
  readonly service = inject(TurbineService);
  readonly presets = TURBINE_PRESETS;
  readonly presetKeys = Object.keys(TURBINE_PRESETS);

  readonly navTabs: { mode: OperatingMode; label: string; icon: string }[] = [
    { mode: 'OVERVIEW', label: 'Overview', icon: 'dashboard' },
    { mode: 'CYCLE', label: 'Cycle & Physics', icon: 'sync_alt' },
    { mode: 'EXERGY', label: 'Exergy 2nd Law', icon: 'account_tree' },
    { mode: 'DIGITAL_TWIN', label: 'Digital Twin', icon: 'sensors' },
    { mode: 'DIAGNOSTICS', label: 'Diagnostics', icon: 'healing' },
    { mode: 'OPTIMISATION', label: 'Optimiser', icon: 'auto_graph' },
    { mode: 'SCENARIOS', label: 'Demos & Labs', icon: 'science' },
    { mode: 'TRANSIENT', label: 'Transient', icon: 'timeline' },
    { mode: 'DOCS', label: 'Formulations', icon: 'menu_book' },
  ];

  onPresetChange(event: Event): void {
    const select = event.target as HTMLSelectElement;
    if (select) {
      this.service.setTurbinePreset(select.value);
    }
  }
}
