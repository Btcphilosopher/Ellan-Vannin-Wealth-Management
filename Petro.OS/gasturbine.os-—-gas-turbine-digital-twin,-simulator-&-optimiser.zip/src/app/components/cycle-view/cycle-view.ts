import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';

@Component({
  selector: 'app-cycle-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let cycle = service.currentCycle();
    @let energy = cycle.energyBalance;

    <div class="space-y-6">
      
      <!-- Top Title & Invariant Notice -->
      <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-card border border-border">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-base font-bold font-mono text-foreground">COUPLED BRAYTON THERMODYNAMIC CYCLE ENGINE</h2>
            <span class="text-xs px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono border border-emerald-500/20">
              FIRST-LAW CONSERVED (<0.01% ERROR)
            </span>
          </div>
          <p class="text-xs text-muted-foreground mt-1">
            Station-by-station thermodynamic properties computed via real-gas NASA Glenn polynomial formulations for dry/moist air and combustion products.
          </p>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono">
          <span class="px-2.5 py-1 rounded bg-muted border border-border text-foreground">
            AIR IN: {{ cycle.airMassFlowKgS.toFixed(1) }} kg/s
          </span>
          <span class="px-2.5 py-1 rounded bg-muted border border-border text-foreground">
            FUEL IN: {{ cycle.fuelFlowKgS.toFixed(2) }} kg/s
          </span>
          <span class="px-2.5 py-1 rounded bg-muted border border-border text-foreground">
            GAS OUT: {{ cycle.state4_egt.massFlowKgS.toFixed(1) }} kg/s
          </span>
        </div>
      </div>

      <!-- Station Thermodynamic Properties Table -->
      <div class="rounded-xl bg-card border border-border overflow-hidden">
        <div class="px-4 py-3 border-b border-border bg-muted/30 flex items-center justify-between">
          <span class="font-mono text-xs font-bold text-foreground">STATION THERMODYNAMIC STATE VECTORS</span>
          <span class="font-mono text-[11px] text-muted-foreground">SI Base Units & Engineering Scale</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono">
            <thead class="bg-muted/60 text-muted-foreground border-b border-border text-left">
              <tr>
                <th class="py-2.5 px-3">STATION</th>
                <th class="py-2.5 px-3">LOCATION</th>
                <th class="py-2.5 px-3 text-right">TEMP [°C]</th>
                <th class="py-2.5 px-3 text-right">TEMP [K]</th>
                <th class="py-2.5 px-3 text-right">PRESS [bar]</th>
                <th class="py-2.5 px-3 text-right">ENTHALPY [kJ/kg]</th>
                <th class="py-2.5 px-3 text-right">ENTROPY [kJ/kg·K]</th>
                <th class="py-2.5 px-3 text-right">DENSITY [kg/m³]</th>
                <th class="py-2.5 px-3 text-right">FLOW [kg/s]</th>
                <th class="py-2.5 px-3 text-right">EXERGY [MW]</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-border/60">
              @for (st of [cycle.state0_ambient, cycle.state1_inlet, cycle.state2_cdp, cycle.state3_tit, cycle.state4_egt]; track st.id) {
                <tr class="hover:bg-muted/30 transition-colors">
                  <td class="py-2.5 px-3 font-bold">
                    <span class="px-1.5 py-0.5 rounded bg-primary/10 text-primary border border-primary/20">
                      St-{{ st.station }}
                    </span>
                  </td>
                  <td class="py-2.5 px-3 text-foreground font-medium">{{ st.name }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-foreground">{{ (st.temperatureK - 273.15).toFixed(1) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-muted-foreground">{{ st.temperatureK.toFixed(1) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums font-semibold text-foreground">{{ (st.pressurePa / 100000).toFixed(3) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-muted-foreground">{{ st.enthalpyKJkg.toFixed(1) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-muted-foreground">{{ st.entropyKJkgK.toFixed(3) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-muted-foreground">{{ st.densityKgM3.toFixed(2) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-foreground font-semibold">{{ st.massFlowKgS.toFixed(1) }}</td>
                  <td class="py-2.5 px-3 text-right tabular-nums text-purple-400 font-semibold">{{ st.totalExergyMW.toFixed(1) }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Diagrams Grid: T-s Diagram & Compressor Map -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- T-s Thermodynamic Diagram -->
        <div class="p-4 rounded-xl bg-card border border-border flex flex-col justify-between">
          <div class="flex items-center justify-between pb-3 border-b border-border/60">
            <span class="font-mono text-xs font-bold text-foreground">TEMPERATURE - ENTROPY (T-s) STATE DIAGRAM</span>
            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-muted text-muted-foreground">REAL vs ISENTROPIC</span>
          </div>

          <!-- SVG T-s Plot -->
          <div class="mt-4 w-full h-64 bg-slate-950/70 rounded-lg p-2 flex items-center justify-center border border-border/60">
            <svg viewBox="0 0 450 240" class="w-full h-full select-none" xmlns="http://www.w3.org/2000/svg">
              <!-- Grid lines -->
              <line x1="50" y1="20" x2="50" y2="200" stroke="#334155" stroke-width="1"/>
              <line x1="50" y1="200" x2="420" y2="200" stroke="#334155" stroke-width="1"/>
              
              <!-- Axes Labels -->
              <text x="35" y="25" fill="#94a3b8" font-family="monospace" font-size="10" text-anchor="end">T [K]</text>
              <text x="420" y="215" fill="#94a3b8" font-family="monospace" font-size="10" text-anchor="end">s [kJ/kg·K]</text>

              <!-- State coordinates mapped to SVG canvas -->
              <!-- 1: Inlet (T1=288K, s1=0.0) -> SVG (80, 180) -->
              <!-- 2: CDP (T2=760K, s2=0.08) -> SVG (135, 120) -->
              <!-- 2s: Isentropic CDP -> SVG (80, 130) -->
              <!-- 3: TIT (T3=1773K, s3=1.12) -> SVG (320, 35) -->
              <!-- 4: EGT (T4=868K, s4=1.20) -> SVG (380, 110) -->
              <!-- 4s: Isentropic EGT -> SVG (320, 125) -->

              <!-- Constant Pressure Isobars -->
              <path d="M 60 190 Q 135 120, 320 35" fill="none" stroke="#f59e0b" stroke-width="1" stroke-dasharray="4 2" opacity="0.6"/>
              <text x="210" y="70" fill="#f59e0b" font-family="monospace" font-size="8" opacity="0.8">P_CDP = {{ (cycle.state2_cdp.pressurePa / 100000).toFixed(1) }} bar</text>

              <path d="M 60 195 Q 200 170, 420 95" fill="none" stroke="#38bdf8" stroke-width="1" stroke-dasharray="4 2" opacity="0.6"/>
              <text x="260" y="160" fill="#38bdf8" font-family="monospace" font-size="8" opacity="0.8">P_atm = 1.013 bar</text>

              <!-- Brayton Real Cycle Path -->
              <!-- 1 -> 2 (Compressor) -->
              <line x1="80" y1="180" x2="135" y2="120" stroke="#0284c7" stroke-width="3"/>
              <!-- 1 -> 2s (Isentropic) -->
              <line x1="80" y1="180" x2="80" y2="132" stroke="#0284c7" stroke-width="1.5" stroke-dasharray="3 3"/>

              <!-- 2 -> 3 (Combustion Heat Addition) -->
              <line x1="135" y1="120" x2="320" y2="35" stroke="#ef4444" stroke-width="3"/>

              <!-- 3 -> 4 (Turbine Expansion) -->
              <line x1="320" y1="35" x2="380" y2="110" stroke="#f97316" stroke-width="3"/>
              <!-- 3 -> 4s (Isentropic) -->
              <line x1="320" y1="35" x2="320" y2="125" stroke="#f97316" stroke-width="1.5" stroke-dasharray="3 3"/>

              <!-- 4 -> 1 (Atmospheric Heat Rejection) -->
              <line x1="380" y1="110" x2="80" y2="180" stroke="#64748b" stroke-width="2" stroke-dasharray="4 4"/>

              <!-- State Point Dots & Labels -->
              <!-- Point 1 -->
              <circle cx="80" cy="180" r="5" fill="#38bdf8"/>
              <text x="70" y="195" fill="#ffffff" font-family="monospace" font-size="10" font-weight="bold">1</text>

              <!-- Point 2 -->
              <circle cx="135" cy="120" r="5" fill="#eab308"/>
              <text x="145" y="122" fill="#ffffff" font-family="monospace" font-size="10" font-weight="bold">2</text>

              <!-- Point 3 -->
              <circle cx="320" cy="35" r="5" fill="#ef4444"/>
              <text x="320" y="25" fill="#ffffff" font-family="monospace" font-size="10" font-weight="bold" text-anchor="middle">3 (TIT)</text>

              <!-- Point 4 -->
              <circle cx="380" cy="110" r="5" fill="#f97316"/>
              <text x="395" y="112" fill="#ffffff" font-family="monospace" font-size="10" font-weight="bold">4 (EGT)</text>
            </svg>
          </div>

          <div class="mt-3 text-[11px] text-muted-foreground font-mono grid grid-cols-2 gap-2">
            <div>• Isentropic Comp Eff: <strong>{{ cycle.compressorEfficiencyPercent.toFixed(1) }}%</strong></div>
            <div>• Isentropic Turb Eff: <strong>{{ cycle.turbineEfficiencyPercent.toFixed(1) }}%</strong></div>
          </div>
        </div>

        <!-- Compressor Characteristic Map & Surge Margin -->
        <div class="p-4 rounded-xl bg-card border border-border flex flex-col justify-between">
          <div class="flex items-center justify-between pb-3 border-b border-border/60">
            <span class="font-mono text-xs font-bold text-foreground">COMPRESSOR CHARACTERISTIC MAP</span>
            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              SM: {{ cycle.surgeMarginPercent.toFixed(1) }}%
            </span>
          </div>

          <!-- SVG Compressor Map -->
          <div class="mt-4 w-full h-64 bg-slate-950/70 rounded-lg p-2 flex items-center justify-center border border-border/60">
            <svg viewBox="0 0 450 240" class="w-full h-full select-none" xmlns="http://www.w3.org/2000/svg">
              <!-- Axes -->
              <line x1="50" y1="20" x2="50" y2="200" stroke="#334155" stroke-width="1"/>
              <line x1="50" y1="200" x2="420" y2="200" stroke="#334155" stroke-width="1"/>
              
              <text x="35" y="25" fill="#94a3b8" font-family="monospace" font-size="10" text-anchor="end">PR (Π_c)</text>
              <text x="420" y="215" fill="#94a3b8" font-family="monospace" font-size="10" text-anchor="end">m_corr [kg/s]</text>

              <!-- Surge Line (Red Top Left) -->
              <path d="M 90 40 Q 180 80, 360 170" fill="none" stroke="#ef4444" stroke-width="2.5"/>
              <text x="110" y="45" fill="#ef4444" font-family="monospace" font-size="9" font-weight="bold">SURGE BOUNDARY</text>

              <!-- Choke Line (Right) -->
              <path d="M 390 50 L 410 190" fill="none" stroke="#64748b" stroke-width="1.5" stroke-dasharray="3 3"/>
              <text x="405" y="45" fill="#64748b" font-family="monospace" font-size="9" text-anchor="end">CHOKE LIMIT</text>

              <!-- Constant Speed Lines (N/sqrt(theta)) -->
              <!-- 100% Speed -->
              <path d="M 120 60 Q 220 100, 380 180" fill="none" stroke="#0284c7" stroke-width="1.5"/>
              <text x="385" y="175" fill="#0284c7" font-family="monospace" font-size="8">100% N</text>

              <!-- 90% Speed -->
              <path d="M 100 100 Q 180 130, 320 190" fill="none" stroke="#0284c7" stroke-width="1" stroke-dasharray="4 2"/>
              <text x="325" y="190" fill="#0284c7" font-family="monospace" font-size="8">90% N</text>

              <!-- Operating Line (Running line) -->
              <path d="M 100 190 Q 240 140, 360 85" fill="none" stroke="#10b981" stroke-width="2" stroke-dasharray="4 2"/>
              <text x="280" y="145" fill="#10b981" font-family="monospace" font-size="8">OPERATING LINE</text>

              <!-- Current Operating Point (P) -->
              @let opX = 140 + (cycle.correctedAirFlowKgS / 800) * 220;
              @let opY = 190 - ((cycle.state2_cdp.pressurePa / cycle.state1_inlet.pressurePa) / 30) * 150;
              <circle [attr.cx]="opX" [attr.cy]="opY" r="7" fill="#eab308" stroke="#ffffff" stroke-width="2"/>
              <circle [attr.cx]="opX" [attr.cy]="opY" r="14" fill="none" stroke="#eab308" stroke-width="1" opacity="0.6"/>
              <text [attr.x]="opX + 12" [attr.y]="opY + 4" fill="#ffffff" font-family="monospace" font-size="10" font-weight="bold">
                OPERATING POINT (PR {{ (cycle.state2_cdp.pressurePa / cycle.state1_inlet.pressurePa).toFixed(1) }})
              </text>
            </svg>
          </div>

          <div class="mt-3 text-[11px] text-muted-foreground font-mono grid grid-cols-2 gap-2">
            <div>• Corrected Mass Flow: <strong>{{ cycle.correctedAirFlowKgS.toFixed(1) }} kg/s</strong></div>
            <div>• Surge Margin (SM): <strong>{{ cycle.surgeMarginPercent.toFixed(1) }}%</strong></div>
          </div>
        </div>

      </div>

      <!-- First-Law Energy Balance Closure Card -->
      <div class="p-4 rounded-xl bg-card border border-border">
        <div class="flex items-center justify-between pb-3 border-b border-border/60 mb-3">
          <span class="font-mono text-xs font-bold text-foreground">FIRST-LAW ENERGY BALANCE CLOSURE AUDIT</span>
          <span class="text-xs font-mono text-emerald-400 flex items-center gap-1">
            <mat-icon class="!text-sm !w-4 !h-4">verified</mat-icon>
            RESIDUAL = {{ energy.residualErrorMW.toFixed(4) }} MW ({{ energy.residualPercent.toFixed(4) }}%)
          </span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
          
          <!-- Energy Inflows -->
          <div class="p-3 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground font-bold">TOTAL THERMAL & SENSIBLE ENERGY INFLOW:</span>
            <div class="mt-2 space-y-1.5 text-foreground">
              <div class="flex justify-between">
                <span>• Fuel Chemical Heat (LHV):</span>
                <span class="font-semibold">{{ energy.fuelEnergyInputMW.toFixed(2) }} MW</span>
              </div>
              <div class="flex justify-between">
                <span>• Air Sensible Inflow:</span>
                <span class="font-semibold">{{ energy.airSensibleEnthalpyInMW.toFixed(2) }} MW</span>
              </div>
              <div class="pt-1.5 border-t border-border flex justify-between font-bold text-primary">
                <span>TOTAL ENERGY INPUT (E_in):</span>
                <span>{{ energy.totalEnergyInMW.toFixed(2) }} MW</span>
              </div>
            </div>
          </div>

          <!-- Energy Outflows -->
          <div class="p-3 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground font-bold">POWER OUTPUT & CONVERTED OUTFLOWS:</span>
            <div class="mt-2 space-y-1.5 text-foreground">
              <div class="flex justify-between">
                <span>• Net Electrical Power (P_net):</span>
                <span class="font-semibold text-emerald-400">{{ energy.netElectricalPowerMW.toFixed(2) }} MW</span>
              </div>
              <div class="flex justify-between">
                <span>• Exhaust Sensible Flue Gas:</span>
                <span class="font-semibold">{{ energy.exhaustSensibleLossMW.toFixed(2) }} MW</span>
              </div>
              <div class="flex justify-between">
                <span>• Combustor / Mechanical / Electrical Losses:</span>
                <span class="font-semibold">{{ (energy.combustorHeatLossMW + energy.shaftMechanicalLossMW + energy.generatorElectricalLossMW).toFixed(2) }} MW</span>
              </div>
              <div class="pt-1.5 border-t border-border flex justify-between font-bold text-primary">
                <span>TOTAL ENERGY OUTFLOW (E_out):</span>
                <span>{{ energy.totalEnergyOutMW.toFixed(2) }} MW</span>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  `,
})
export class CycleView {
  readonly service = inject(TurbineService);
}
