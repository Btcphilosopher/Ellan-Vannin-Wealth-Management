import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';

@Component({
  selector: 'app-optimisation-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let golden = service.goldenPointComparison();
    @let pareto = service.paretoFrontier();

    <div class="space-y-6">
      
      <!-- Top Title & Action -->
      <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-card border border-border">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-base font-bold font-mono text-foreground">MULTI-OBJECTIVE OPTIMISATION & GOLDEN OPERATING POINT</h2>
            <span class="text-xs px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono border border-emerald-500/20">
              ALGORITHM: SLSQP MULTI-GRID
            </span>
          </div>
          <p class="text-xs text-muted-foreground mt-1">
            Finds the mathematically optimal variable geometry (IGV schedule) and firing control to maximize dispatch spark spread within strict emission and surge constraints.
          </p>
        </div>

        <button
          (click)="service.applyGoldenOperatingPoint()"
          class="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-mono font-bold transition-colors shadow-sm">
          <mat-icon class="!text-sm !w-4 !h-4">auto_fix_high</mat-icon>
          <span>Apply Golden Point Setpoints</span>
        </button>
      </div>

      <!-- Golden Operating Point Comparison Card (Current vs Optimal) -->
      <div class="p-5 rounded-xl bg-card border border-primary/30 relative overflow-hidden">
        <div class="flex items-center justify-between pb-3 border-b border-border/60 mb-4">
          <div>
            <span class="font-mono text-xs font-bold text-primary">GOLDEN OPERATING POINT COMPARISON</span>
            <div class="text-[11px] text-muted-foreground font-mono mt-0.5">
              Target Load: {{ (golden.current.loadFraction * 100).toFixed(0) }}% · Objective: {{ golden.objective }}
            </div>
          </div>

          <div class="flex items-center gap-2 text-xs font-mono">
            <span class="px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">
              EST. ANNUAL GAIN: +£{{ (golden.deltas.annualEconomicGainGBP / 1000).toFixed(0) }}k / yr
            </span>
          </div>
        </div>

        <!-- Side-by-Side Comparison -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          
          <!-- Column 1: Current Operating Point -->
          <div class="p-4 rounded-lg bg-muted/40 border border-border">
            <span class="text-muted-foreground font-bold">CURRENT SETTINGS:</span>
            <div class="mt-3 space-y-2">
              <div class="flex justify-between">
                <span class="text-muted-foreground">IGV Angle:</span>
                <span class="font-semibold text-foreground">{{ golden.current.igvAngleDeg > 0 ? '+' : '' }}{{ golden.current.igvAngleDeg.toFixed(1) }}°</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Net Power:</span>
                <span class="font-semibold text-foreground">{{ golden.current.powerMW.toFixed(1) }} MW</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Thermal Efficiency:</span>
                <span class="font-semibold text-foreground">{{ golden.current.thermalEfficiencyPercent.toFixed(2) }}%</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Heat Rate (LHV):</span>
                <span class="font-semibold text-foreground">{{ golden.current.heatRateKJKWh.toFixed(0) }} kJ/kWh</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Fuel Flow:</span>
                <span class="font-semibold text-foreground">{{ golden.current.fuelFlowKgS.toFixed(2) }} kg/s</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Hourly Net Margin:</span>
                <span class="font-semibold text-foreground">£{{ golden.current.hourlyMarginGBP.toFixed(0) }} / hr</span>
              </div>
            </div>
          </div>

          <!-- Column 2: Optimal Golden Point -->
          <div class="p-4 rounded-lg bg-emerald-500/5 border border-emerald-500/30">
            <span class="text-emerald-400 font-bold">OPTIMAL GOLDEN SETTINGS:</span>
            <div class="mt-3 space-y-2">
              <div class="flex justify-between">
                <span class="text-muted-foreground">Optimal IGV:</span>
                <span class="font-bold text-emerald-400">{{ golden.optimal.igvAngleDeg > 0 ? '+' : '' }}{{ golden.optimal.igvAngleDeg.toFixed(1) }}°</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Net Power:</span>
                <span class="font-bold text-emerald-400">{{ golden.optimal.powerMW.toFixed(1) }} MW</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Thermal Efficiency:</span>
                <span class="font-bold text-emerald-400">{{ golden.optimal.thermalEfficiencyPercent.toFixed(2) }}%</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Heat Rate (LHV):</span>
                <span class="font-bold text-emerald-400">{{ golden.optimal.heatRateKJKWh.toFixed(0) }} kJ/kWh</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Fuel Flow:</span>
                <span class="font-bold text-emerald-400">{{ golden.optimal.fuelFlowKgS.toFixed(2) }} kg/s</span>
              </div>
              <div class="flex justify-between">
                <span class="text-muted-foreground">Hourly Net Margin:</span>
                <span class="font-bold text-emerald-400">£{{ golden.optimal.hourlyMarginGBP.toFixed(0) }} / hr</span>
              </div>
            </div>
          </div>

          <!-- Column 3: Verified Deltas & Gains -->
          <div class="p-4 rounded-lg bg-primary/5 border border-primary/20 flex flex-col justify-between">
            <div>
              <span class="text-primary font-bold">VERIFIED SAVINGS & DELTAS:</span>
              <div class="mt-3 space-y-2">
                <div class="flex justify-between">
                  <span class="text-muted-foreground">Efficiency Gain:</span>
                  <span class="font-bold text-emerald-400">+{{ golden.deltas.efficiencyGainPercent.toFixed(2) }}%</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-muted-foreground">Heat Rate Drop:</span>
                  <span class="font-bold text-emerald-400">-{{ golden.deltas.heatRateReductionKJKWh.toFixed(0) }} kJ/kWh</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-muted-foreground">Fuel Saved:</span>
                  <span class="font-bold text-emerald-400">{{ (golden.deltas.fuelSavedKgH / 1000).toFixed(2) }} t / hr</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-muted-foreground">Margin Uplift:</span>
                  <span class="font-bold text-emerald-400">+£{{ golden.deltas.hourlyMarginImprovementGBP.toFixed(1) }} / hr</span>
                </div>
              </div>
            </div>

            <div class="pt-3 border-t border-border/60 text-[11px] text-muted-foreground">
              Guaranteed compliant with Surge Margin ≥ 15% and TIT ≤ 1520°C.
            </div>
          </div>

        </div>
      </div>

      <!-- Multi-Objective Pareto Frontier Scatter Plot -->
      <div class="p-4 rounded-xl bg-card border border-border">
        <div class="flex items-center justify-between pb-3 border-b border-border/60 mb-3">
          <span class="font-mono text-xs font-bold text-foreground">MULTI-OBJECTIVE PARETO FRONTIER (EFFICIENCY VS NOX EMISSIONS)</span>
          <span class="text-[11px] font-mono text-muted-foreground">Non-Dominated Operating Envelopes</span>
        </div>

        <div class="w-full h-64 bg-slate-950/70 rounded-lg p-3 border border-border/60 flex items-center justify-center">
          <svg viewBox="0 0 600 220" class="w-full h-full select-none" xmlns="http://www.w3.org/2000/svg">
            <!-- Axes -->
            <line x1="60" y1="20" x2="60" y2="180" stroke="#334155" stroke-width="1"/>
            <line x1="60" y1="180" x2="560" y2="180" stroke="#334155" stroke-width="1"/>

            <text x="45" y="25" fill="#94a3b8" font-family="monospace" font-size="10" text-anchor="end">η [%]</text>
            <text x="560" y="195" fill="#94a3b8" font-family="monospace" font-size="10" text-anchor="end">NOx [ppmvd @ 15% O2]</text>

            <!-- Scatter points -->
            @for (p of pareto; track p.id) {
              <!-- Map: NOx (0..35 ppm) -> X (70..540), Eff (30..42%) -> Y (170..30) -->
              @let xPos = 70 + (p.noxPpmvd / 35) * 460;
              @let yPos = 175 - ((p.thermalEfficiencyPercent - 30) / 12) * 145;
              
              @if (p.isParetoOptimal) {
                <circle [attr.cx]="xPos" [attr.cy]="yPos" r="4.5" fill="#10b981" stroke="#ffffff" stroke-width="1"/>
              } @else {
                <circle [attr.cx]="xPos" [attr.cy]="yPos" r="2.5" fill="#475569" opacity="0.6"/>
              }
            }

            <text x="540" y="45" fill="#10b981" font-family="monospace" font-size="10" font-weight="bold" text-anchor="end">
              ● Pareto Optimal Points
            </text>
            <text x="540" y="60" fill="#64748b" font-family="monospace" font-size="9" text-anchor="end">
              ● Sub-Optimal Permutations
            </text>
          </svg>
        </div>
      </div>

      <!-- 2D Operating Map Grid (Load vs Ambient Temperature) -->
      <div class="rounded-xl bg-card border border-border overflow-hidden">
        <div class="px-4 py-3 border-b border-border bg-muted/30 flex items-center justify-between">
          <span class="font-mono text-xs font-bold text-foreground">2D OPERATING ENVELOPE (LOAD VS AMBIENT TEMPERATURE)</span>
          <span class="font-mono text-[11px] text-muted-foreground">Thermal Efficiency Matrix [%]</span>
        </div>

        <div class="p-4 overflow-x-auto">
          <table class="w-full text-xs font-mono text-center">
            <thead>
              <tr class="text-muted-foreground border-b border-border">
                <th class="py-2 px-3 text-left">AMBIENT T</th>
                <th class="py-2 px-2">30% LOAD</th>
                <th class="py-2 px-2">40% LOAD</th>
                <th class="py-2 px-2">50% LOAD</th>
                <th class="py-2 px-2">60% LOAD</th>
                <th class="py-2 px-2">70% LOAD</th>
                <th class="py-2 px-2">80% LOAD</th>
                <th class="py-2 px-2">90% LOAD</th>
                <th class="py-2 px-2">100% LOAD</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-border/60">
              @for (temp of [-10, 0, 10, 15, 20, 30, 40]; track temp) {
                <tr>
                  <td class="py-2.5 px-3 text-left font-bold text-foreground">{{ temp }}°C</td>
                  @for (load of [30, 40, 50, 60, 70, 80, 90, 100]; track load) {
                    <!-- Approximate cell efficiency value -->
                    @let eff = (39.8 - (temp - 15) * 0.04) * (0.65 + 0.35 * (load / 100));
                    <td class="py-2.5 px-2 tabular-nums font-semibold"
                      [class.text-emerald-400]="eff >= 38"
                      [class.text-blue-400]="eff >= 34 && eff < 38"
                      [class.text-amber-400]="eff < 34">
                      {{ eff.toFixed(1) }}%
                    </td>
                  }
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `,
})
export class OptimisationView {
  readonly service = inject(TurbineService);
}
