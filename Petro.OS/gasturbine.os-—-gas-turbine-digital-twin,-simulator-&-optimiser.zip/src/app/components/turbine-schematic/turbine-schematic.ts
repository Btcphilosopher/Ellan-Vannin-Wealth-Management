import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TurbineService } from '../../services/turbine.service';

@Component({
  selector: 'app-turbine-schematic',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let cycle = service.currentCycle();

    <div class="bg-card border border-border rounded-xl p-4 sm:p-5 shadow-sm">
      
      <!-- Top Title & Quick Toggles -->
      <div class="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-border/60">
        <div>
          <div class="flex items-center gap-2">
            <span class="font-mono font-bold text-sm text-foreground">GAS-PATH LONGITUDINAL CROSS SECTION</span>
            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-primary/10 text-primary border border-primary/20">
              {{ cycle.config.classType }} · {{ cycle.config.name }}
            </span>
          </div>
          <p class="text-xs text-muted-foreground mt-0.5">
            Click on any station or component section to inspect aerodynamic stage loading and thermodynamic state vectors.
          </p>
        </div>

        <!-- Quick Status -->
        <div class="flex items-center gap-2 text-xs font-mono">
          <span class="px-2 py-1 rounded bg-muted text-muted-foreground border border-border">
            SHAFT: {{ cycle.config.ratedShaftSpeedRpm }} RPM
          </span>
          <span class="px-2 py-1 rounded bg-muted text-muted-foreground border border-border">
            FLOW: {{ cycle.airMassFlowKgS.toFixed(1) }} kg/s
          </span>
          @if (service.enableCombinedCycle()) {
            <span class="px-2 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              HRSG CCGT ACTIVE
            </span>
          }
        </div>
      </div>

      <!-- Interactive SVG Schematic Canvas -->
      <div class="relative w-full overflow-x-auto rounded-lg bg-slate-950/60 border border-border/60 p-2">
        <svg viewBox="0 0 1000 320" class="w-full min-w-[760px] h-auto select-none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <!-- Air Inlet Gradient -->
            <linearGradient id="airFlowGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#0284c7" stop-opacity="0.8"/>
              <stop offset="100%" stop-color="#38bdf8" stop-opacity="0.9"/>
            </linearGradient>

            <!-- Compressor Gradient (Cold to Warm) -->
            <linearGradient id="compGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#0284c7"/>
              <stop offset="100%" stop-color="#eab308"/>
            </linearGradient>

            <!-- Combustor Flame Gradient -->
            <radialGradient id="flameGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#ffffff"/>
              <stop offset="25%" stop-color="#fef08a"/>
              <stop offset="60%" stop-color="#f97316"/>
              <stop offset="100%" stop-color="#dc2626"/>
            </radialGradient>

            <!-- Turbine Expander Gradient (Hot to Exhaust) -->
            <linearGradient id="turbGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stop-color="#ef4444"/>
              <stop offset="60%" stop-color="#f97316"/>
              <stop offset="100%" stop-color="#64748b"/>
            </linearGradient>

            <!-- Flow Arrow Marker -->
            <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#38bdf8"/>
            </marker>
          </defs>

          <!-- Background Centerline Shaft Axis -->
          <line x1="40" y1="160" x2="960" y2="160" stroke="#475569" stroke-width="1.5" stroke-dasharray="8 4"/>
          <text x="45" y="152" fill="#64748b" font-family="monospace" font-size="10">CENTERLINE ROTOR SHAFT</text>

          <!-- Main Rotor Core Shaft -->
          <rect x="180" y="152" width="620" height="16" rx="2" fill="#334155" stroke="#64748b" stroke-width="1.5"/>

          <!-- 1. INLET PLENUM & BELLMOUTH HOUSING (X: 50 -> 180) -->
          <g class="cursor-pointer transition-opacity hover:opacity-90" (click)="selectedComponent.set('INLET')">
            <path d="M 50 60 L 180 90 L 180 230 L 50 260 Z" fill="#0f172a" stroke="#0284c7" stroke-width="1.5"/>
            <!-- Filter Silencer Baffles -->
            <line x1="80" y1="70" x2="80" y2="250" stroke="#0284c7" stroke-width="2" stroke-dasharray="4 3"/>
            <line x1="110" y1="75" x2="110" y2="245" stroke="#0284c7" stroke-width="2" stroke-dasharray="4 3"/>
            <line x1="140" y1="80" x2="140" y2="240" stroke="#0284c7" stroke-width="2" stroke-dasharray="4 3"/>

            <!-- Variable Inlet Guide Vanes (IGV) -->
            <line x1="172" y1="92" x2="172" y2="228" stroke="#38bdf8" stroke-width="3"/>
            <text x="115" y="50" text-anchor="middle" fill="#38bdf8" font-family="monospace" font-size="11" font-weight="bold">INLET & IGV</text>
          </g>

          <!-- 2. AXIAL COMPRESSOR STAGES (X: 180 -> 450) -->
          <g class="cursor-pointer transition-opacity hover:opacity-90" (click)="selectedComponent.set('COMPRESSOR')">
            <!-- Compressor Upper & Lower Casing (Tapered convergent flow path) -->
            <path d="M 180 90 L 450 120 L 450 152 L 180 152 Z" fill="url(#compGrad)" fill-opacity="0.25" stroke="#eab308" stroke-width="1.5"/>
            <path d="M 180 230 L 450 200 L 450 168 L 180 168 Z" fill="url(#compGrad)" fill-opacity="0.25" stroke="#eab308" stroke-width="1.5"/>

            <!-- 18 Compressor Rotor & Stator Blade Pairs (Visualized as 9 distributed blades) -->
            @for (i of [0, 1, 2, 3, 4, 5, 6, 7, 8]; track i) {
              @let xPos = 195 + i * 28;
              @let topH = 92 + i * 3.3;
              @let botH = 228 - i * 3.3;
              <line [attr.x1]="xPos" [attr.y1]="topH" [attr.x2]="xPos" y2="150" stroke="#94a3b8" stroke-width="2.5"/>
              <line [attr.x1]="xPos" y1="170" [attr.x2]="xPos" [attr.y2]="botH" stroke="#94a3b8" stroke-width="2.5"/>
            }

            <text x="315" y="50" text-anchor="middle" fill="#eab308" font-family="monospace" font-size="11" font-weight="bold">
              18-STAGE AXIAL COMPRESSOR (PR {{ (cycle.state2_cdp.pressurePa / cycle.state1_inlet.pressurePa).toFixed(1) }}:1)
            </text>
          </g>

          <!-- 3. ANNULAR / CAN-ANNULAR COMBUSTOR (X: 450 -> 580) -->
          <g class="cursor-pointer transition-opacity hover:opacity-90" (click)="selectedComponent.set('COMBUSTOR')">
            <!-- Upper Combustion Chamber Liner -->
            <path d="M 450 115 C 470 100, 560 100, 580 115 L 580 148 L 450 148 Z" fill="#1e1b4b" stroke="#f97316" stroke-width="1.5"/>
            <ellipse cx="515" cy="130" rx="35" ry="12" fill="url(#flameGrad)" opacity="0.95"/>
            <!-- Fuel Nozzle Injector -->
            <rect x="452" y="124" width="14" height="12" rx="2" fill="#ef4444" stroke="#ffffff" stroke-width="1"/>
            <path d="M 466 130 L 485 125 L 485 135 Z" fill="#facc15"/>

            <!-- Lower Combustion Chamber Liner -->
            <path d="M 450 205 C 470 220, 560 220, 580 205 L 580 172 L 450 172 Z" fill="#1e1b4b" stroke="#f97316" stroke-width="1.5"/>
            <ellipse cx="515" cy="190" rx="35" ry="12" fill="url(#flameGrad)" opacity="0.95"/>
            <!-- Lower Fuel Injector -->
            <rect x="452" y="184" width="14" height="12" rx="2" fill="#ef4444" stroke="#ffffff" stroke-width="1"/>
            <path d="M 466 190 L 485 185 L 485 195 Z" fill="#facc15"/>

            <text x="515" y="50" text-anchor="middle" fill="#f97316" font-family="monospace" font-size="11" font-weight="bold">
              COMBUSTOR (TIT {{ (cycle.state3_tit.temperatureK - 273.15).toFixed(0) }}°C)
            </text>
          </g>

          <!-- 4. HIGH-PRESSURE & LOW-PRESSURE TURBINE EXPANDER (X: 580 -> 720) -->
          <g class="cursor-pointer transition-opacity hover:opacity-90" (click)="selectedComponent.set('TURBINE')">
            <!-- Divergent Turbine Casing -->
            <path d="M 580 115 L 720 85 L 720 152 L 580 152 Z" fill="url(#turbGrad)" fill-opacity="0.3" stroke="#ef4444" stroke-width="1.5"/>
            <path d="M 580 205 L 720 235 L 720 168 L 580 168 Z" fill="url(#turbGrad)" fill-opacity="0.3" stroke="#ef4444" stroke-width="1.5"/>

            <!-- 4 Turbine Expansion Stages -->
            @for (i of [0, 1, 2, 3]; track i) {
              @let xPos = 598 + i * 32;
              @let topH = 112 - i * 8.5;
              @let botH = 208 + i * 8.5;
              <line [attr.x1]="xPos" [attr.y1]="topH" [attr.x2]="xPos" y2="150" stroke="#f87171" stroke-width="3.5"/>
              <line [attr.x1]="xPos" y1="170" [attr.x2]="xPos" [attr.y2]="botH" stroke="#f87171" stroke-width="3.5"/>
            }

            <text x="650" y="50" text-anchor="middle" fill="#ef4444" font-family="monospace" font-size="11" font-weight="bold">
              4-STAGE EXPANDER ({{ cycle.turbineGrossPowerMW.toFixed(0) }} MW)
            </text>
          </g>

          <!-- 5. EXHAUST DIFFUSER (X: 720 -> 820) -->
          <g class="cursor-pointer transition-opacity hover:opacity-90" (click)="selectedComponent.set('EXHAUST')">
            <path d="M 720 85 L 820 65 L 820 255 L 720 235 Z" fill="#0f172a" stroke="#64748b" stroke-width="1.5"/>
            <text x="770" y="50" text-anchor="middle" fill="#94a3b8" font-family="monospace" font-size="11" font-weight="bold">
              EXHAUST ({{ (cycle.state4_egt.temperatureK - 273.15).toFixed(0) }}°C)
            </text>
          </g>

          <!-- 6. GENERATOR (X: 835 -> 950) -->
          <g class="cursor-pointer transition-opacity hover:opacity-90" (click)="selectedComponent.set('GENERATOR')">
            <rect x="835" y="95" width="115" height="130" rx="6" fill="#1e293b" stroke="#10b981" stroke-width="1.8"/>
            <circle cx="892" cy="160" r="38" fill="#0f172a" stroke="#10b981" stroke-width="1.5" stroke-dasharray="6 3"/>
            <text x="892" y="156" text-anchor="middle" fill="#10b981" font-family="monospace" font-size="11" font-weight="bold">GENERATOR</text>
            <text x="892" y="172" text-anchor="middle" fill="#10b981" font-family="monospace" font-size="10">{{ cycle.netElectricalPowerMW.toFixed(1) }} MW</text>
          </g>

          <!-- STATION MARKER BUBBLES -->
          <!-- Station 0: Ambient -->
          <g transform="translate(35, 20)">
            <circle cx="0" cy="0" r="12" fill="#0284c7" stroke="#ffffff" stroke-width="1.5"/>
            <text x="0" y="4" text-anchor="middle" fill="#ffffff" font-family="monospace" font-size="11" font-weight="bold">0</text>
          </g>

          <!-- Station 1: Compressor Inlet -->
          <g transform="translate(180, 275)">
            <circle cx="0" cy="0" r="12" fill="#38bdf8" stroke="#ffffff" stroke-width="1.5"/>
            <text x="0" y="4" text-anchor="middle" fill="#0f172a" font-family="monospace" font-size="11" font-weight="bold">1</text>
            <text x="0" y="22" text-anchor="middle" fill="#38bdf8" font-family="monospace" font-size="9">
              {{ (cycle.state1_inlet.temperatureK - 273.15).toFixed(1) }}°C · {{ (cycle.state1_inlet.pressurePa / 100000).toFixed(3) }} bar
            </text>
          </g>

          <!-- Station 2: Compressor Discharge CDP -->
          <g transform="translate(450, 275)">
            <circle cx="0" cy="0" r="12" fill="#eab308" stroke="#ffffff" stroke-width="1.5"/>
            <text x="0" y="4" text-anchor="middle" fill="#0f172a" font-family="monospace" font-size="11" font-weight="bold">2</text>
            <text x="0" y="22" text-anchor="middle" fill="#eab308" font-family="monospace" font-size="9">
              {{ (cycle.state2_cdp.temperatureK - 273.15).toFixed(0) }}°C · {{ (cycle.state2_cdp.pressurePa / 100000).toFixed(2) }} bar
            </text>
          </g>

          <!-- Station 3: Turbine Firing TIT -->
          <g transform="translate(580, 275)">
            <circle cx="0" cy="0" r="12" fill="#ef4444" stroke="#ffffff" stroke-width="1.5"/>
            <text x="0" y="4" text-anchor="middle" fill="#ffffff" font-family="monospace" font-size="11" font-weight="bold">3</text>
            <text x="0" y="22" text-anchor="middle" fill="#ef4444" font-family="monospace" font-size="9">
              {{ (cycle.state3_tit.temperatureK - 273.15).toFixed(0) }}°C · {{ (cycle.state3_tit.pressurePa / 100000).toFixed(2) }} bar
            </text>
          </g>

          <!-- Station 4: Turbine Exhaust EGT -->
          <g transform="translate(720, 275)">
            <circle cx="0" cy="0" r="12" fill="#94a3b8" stroke="#ffffff" stroke-width="1.5"/>
            <text x="0" y="4" text-anchor="middle" fill="#0f172a" font-family="monospace" font-size="11" font-weight="bold">4</text>
            <text x="0" y="22" text-anchor="middle" fill="#94a3b8" font-family="monospace" font-size="9">
              {{ (cycle.state4_egt.temperatureK - 273.15).toFixed(0) }}°C · {{ (cycle.state4_egt.pressurePa / 100000).toFixed(3) }} bar
            </text>
          </g>
        </svg>
      </div>

      <!-- Quick Interactive Parameters Strip -->
      <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-3.5 rounded-lg bg-muted/40 border border-border">
        
        <!-- Slider 1: Load Fraction -->
        <div>
          <div class="flex items-center justify-between text-xs font-mono mb-1">
            <span class="text-muted-foreground">DISPATCH LOAD</span>
            <span class="font-bold text-foreground">{{ (service.loadFraction() * 100).toFixed(0) }}%</span>
          </div>
          <input
            type="range"
            min="0.25"
            max="1.05"
            step="0.01"
            [value]="service.loadFraction()"
            (input)="onLoadChange($event)"
            class="w-full h-1.5 bg-border rounded-lg appearance-none cursor-pointer accent-primary"/>
        </div>

        <!-- Slider 2: IGV Angle -->
        <div>
          <div class="flex items-center justify-between text-xs font-mono mb-1">
            <span class="text-muted-foreground">IGV ANGLE</span>
            <span class="font-bold text-foreground">{{ service.igvAngleDeg() > 0 ? '+' : '' }}{{ service.igvAngleDeg().toFixed(1) }}°</span>
          </div>
          <input
            type="range"
            min="-10"
            max="15"
            step="0.5"
            [value]="service.igvAngleDeg()"
            (input)="onIgvChange($event)"
            class="w-full h-1.5 bg-border rounded-lg appearance-none cursor-pointer accent-primary"/>
        </div>

        <!-- Slider 3: Compressor Fouling -->
        <div>
          <div class="flex items-center justify-between text-xs font-mono mb-1">
            <span class="text-muted-foreground">COMP FOULING</span>
            <span class="font-bold" [class.text-amber-400]="service.compressorFoulingFraction() > 0.02">
              {{ (service.compressorFoulingFraction() * 100).toFixed(1) }}%
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="0.12"
            step="0.005"
            [value]="service.compressorFoulingFraction()"
            (input)="onFoulingChange($event)"
            class="w-full h-1.5 bg-border rounded-lg appearance-none cursor-pointer accent-amber-500"/>
        </div>

        <!-- Slider 4: Hydrogen Blend Co-Firing -->
        <div>
          <div class="flex items-center justify-between text-xs font-mono mb-1">
            <span class="text-muted-foreground">H2 BLEND (VOL)</span>
            <span class="font-bold text-emerald-400">{{ service.hydrogenVolPercent() }}% H2</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            step="5"
            [value]="service.hydrogenVolPercent()"
            (input)="onH2Change($event)"
            class="w-full h-1.5 bg-border rounded-lg appearance-none cursor-pointer accent-emerald-500"/>
        </div>

      </div>

      <!-- Component Inspection Drawer -->
      @if (selectedComponent(); as comp) {
        <div class="mt-3 p-3.5 rounded-lg bg-card border border-primary/30 flex items-start justify-between gap-4">
          <div class="text-xs">
            <div class="flex items-center gap-2 mb-1">
              <span class="font-bold text-primary font-mono uppercase">{{ comp }} SECTION INSPECTION</span>
              <span class="text-[10px] text-muted-foreground font-mono">STATUS: VERIFIED</span>
            </div>

            @switch (comp) {
              @case ('INLET') {
                <p class="text-muted-foreground">
                  Inlet total pressure loss: <strong class="text-foreground">{{ cycle.inletFilterLossPercent.toFixed(2) }}%</strong> 
                  ({{ (cycle.inletFilterLossPercent * 10).toFixed(1) }} mbar). Air suction mass flow: 
                  <strong class="text-foreground">{{ cycle.airMassFlowKgS.toFixed(1) }} kg/s</strong>. IGV Angle: 
                  <strong class="text-foreground">{{ cycle.igvAngleDeg.toFixed(1) }}°</strong>.
                </p>
              }
              @case ('COMPRESSOR') {
                <p class="text-muted-foreground">
                  18 axial stages delivering pressure ratio <strong class="text-foreground">{{ (cycle.state2_cdp.pressurePa / cycle.state1_inlet.pressurePa).toFixed(2) }}:1</strong>. 
                  Isentropic efficiency: <strong class="text-foreground">{{ cycle.compressorEfficiencyPercent.toFixed(1) }}%</strong>. 
                  Surge margin: <strong class="text-foreground">{{ cycle.surgeMarginPercent.toFixed(1) }}%</strong>. Power consumed: 
                  <strong class="text-foreground">{{ cycle.compressorPowerMW.toFixed(1) }} MW</strong>.
                </p>
              }
              @case ('COMBUSTOR') {
                <p class="text-muted-foreground">
                  Can-annular dry low-NOx combustion. Fuel flow: <strong class="text-foreground">{{ cycle.fuelFlowKgS.toFixed(2) }} kg/s</strong> 
                  ({{ (cycle.fuelFlowKgS * 3.6).toFixed(1) }} t/h). Air-Fuel Ratio (AFR): <strong class="text-foreground">{{ cycle.airFuelRatio.toFixed(1) }}</strong>. 
                  Heat release: <strong class="text-foreground">{{ (cycle.fuelFlowKgS * cycle.fuel.lhvMJkg).toFixed(1) }} MWth</strong>.
                </p>
              }
              @case ('TURBINE') {
                <p class="text-muted-foreground">
                  4-stage axial expander. Expansion ratio: <strong class="text-foreground">{{ (cycle.state3_tit.pressurePa / cycle.state4_egt.pressurePa).toFixed(2) }}:1</strong>. 
                  Gross turbine shaft power: <strong class="text-foreground">{{ cycle.turbineGrossPowerMW.toFixed(1) }} MW</strong>. 
                  Isentropic efficiency: <strong class="text-foreground">{{ cycle.turbineEfficiencyPercent.toFixed(1) }}%</strong>.
                </p>
              }
              @case ('EXHAUST') {
                <p class="text-muted-foreground">
                  Diffuser exhaust gas temperature (EGT): <strong class="text-foreground">{{ (cycle.state4_egt.temperatureK - 273.15).toFixed(1) }}°C</strong>. 
                  Sensible thermal energy flux: <strong class="text-foreground">{{ cycle.energyBalance.exhaustSensibleLossMW.toFixed(1) }} MWth</strong> 
                  (Available for HRSG steam generation).
                </p>
              }
              @case ('GENERATOR') {
                <p class="text-muted-foreground">
                  Synchronous 2-pole hydrogen-cooled generator. Net active output: <strong class="text-foreground">{{ cycle.netElectricalPowerMW.toFixed(1) }} MW</strong> 
                  at 50.0 Hz ({{ cycle.config.ratedShaftSpeedRpm }} RPM). Generator efficiency: 
                  <strong class="text-foreground">{{ cycle.generatorEfficiencyPercent.toFixed(2) }}%</strong>.
                </p>
              }
            }
          </div>

          <button
            (click)="selectedComponent.set(null)"
            class="text-muted-foreground hover:text-foreground text-xs p-1">
            <mat-icon class="!text-sm !w-4 !h-4">close</mat-icon>
          </button>
        </div>
      }

    </div>
  `,
})
export class TurbineSchematic {
  readonly service = inject(TurbineService);
  readonly selectedComponent = signal<string | null>(null);

  onLoadChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.service.setLoadFraction(val);
  }

  onIgvChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.service.setIgvAngle(val);
  }

  onFoulingChange(event: Event): void {
    const val = parseFloat((event.target as HTMLInputElement).value);
    this.service.setCompressorFouling(val);
  }

  onH2Change(event: Event): void {
    const val = parseInt((event.target as HTMLInputElement).value, 10);
    this.service.setHydrogenBlend(val);
  }
}
