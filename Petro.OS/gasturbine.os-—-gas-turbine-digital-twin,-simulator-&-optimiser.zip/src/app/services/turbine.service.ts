/**
 * GASTURBINE.OS — Central State & Simulation Service
 * Zoneless reactive signals architecture for coupled physics simulation,
 * telemetry streaming, calibration, diagnostics, and multi-objective optimisation.
 */

import { computed, Injectable, signal } from '@angular/core';
import { AmbientModel, AmbientState } from '../engine/thermodynamics/ambient-model';
import { createNaturalGasComposition, FluidComposition } from '../engine/thermodynamics/thermo-state';
import { CycleSimulationResult, CycleSolver, TurbineConfig } from '../engine/cycle/cycle-solver';
import { ExergyAnalysisResult, ExergyEngine } from '../engine/cycle/exergy-engine';
import { HistorianTimePoint, SyntheticPlantEngine, SyntheticSensor, TURBINE_PRESETS } from '../engine/digital-twin/synthetic-plant';
import { CalibrationParameters, StateEstimator } from '../engine/digital-twin/state-estimator';
import { ComponentHealthBreakdown, DiagnosticFinding, DiagnosticsEngine, PerformanceGap } from '../engine/digital-twin/diagnostics-engine';
import { EconomicParams, GoldenOperatingPointComparison, OperatingEnvelopeCell, OptimiserEngine, ParetoPoint } from '../engine/optimisation/optimiser-engine';
import { TransientEngine, TransientTimeStep } from '../engine/scenarios/transient-engine';
import { SIGNATURE_DEMOS, SignatureDemo } from '../engine/scenarios/signature-demos';

export type OperatingMode =
  | 'OVERVIEW'
  | 'CYCLE'
  | 'DIGITAL_TWIN'
  | 'DIAGNOSTICS'
  | 'OPTIMISATION'
  | 'SCENARIOS'
  | 'TRANSIENT'
  | 'EXERGY'
  | 'DOCS';

@Injectable({
  providedIn: 'root',
})
export class TurbineService {
  // Navigation & Mode
  readonly currentMode = signal<OperatingMode>('OVERVIEW');
  readonly selectedDemo = signal<SignatureDemo>(SIGNATURE_DEMOS[0]);
  readonly isStreamingTelemetry = signal<boolean>(true);

  // Machine Configuration
  readonly activePresetKey = signal<string>('GT-500-DEMO');
  readonly turbineConfig = signal<TurbineConfig>(TURBINE_PRESETS['GT-500-DEMO']);

  // Ambient Conditions
  readonly ambientPresetKey = signal<'ISO_DAY' | 'HOT_DAY' | 'COLD_DAY' | 'HIGH_ALTITUDE' | 'CUSTOM'>('ISO_DAY');
  readonly customAmbientTempC = signal<number>(15);
  readonly customAmbientPressureBar = signal<number>(1.01325);
  readonly customHumidityPercent = signal<number>(60);
  readonly ambientState = computed<AmbientState>(() => {
    const preset = this.ambientPresetKey();
    if (preset === 'CUSTOM') {
      return AmbientModel.createAmbientState(
        'CUSTOM',
        this.customAmbientTempC(),
        this.customAmbientPressureBar(),
        this.customHumidityPercent()
      );
    }
    const presets = AmbientModel.getPresets();
    return presets[preset] || presets['ISO_DAY'];
  });

  // Fuel System & Hydrogen Blend
  readonly fuelName = signal<string>('Natural Gas');
  readonly hydrogenVolPercent = signal<number>(0);
  readonly fuelComposition = computed<FluidComposition>(() => {
    const h2Frac = this.hydrogenVolPercent() / 100;
    const base = createNaturalGasComposition();
    const remaining = 1.0 - h2Frac;
    return {
      N2: base.N2 * remaining,
      O2: 0,
      CO2: base.CO2 * remaining,
      H2O: 0,
      Ar: 0,
      CH4: base.CH4 * remaining,
      H2: h2Frac,
      CO: 0,
      C2H6: base.C2H6 * remaining,
    };
  });

  // Operation Controls & Physical Parameters
  readonly loadFraction = signal<number>(1.0); // 0.2 to 1.05
  readonly igvAngleDeg = signal<number>(0.0);   // -10° to +15°
  readonly compressorFoulingFraction = signal<number>(0.0); // 0 to 0.15
  readonly turbineDegradationFraction = signal<number>(0.0); // 0 to 0.10
  readonly filterLossFactor = signal<number>(1.0); // 1.0 to 2.5
  readonly enableCombinedCycle = signal<boolean>(false);

  // Injected Telemetry Faults
  readonly injectedSensorDriftTag = signal<string | undefined>(undefined);
  readonly injectedSensorStuckTag = signal<string | undefined>(undefined);

  // Calibration Parameters
  readonly calibrationParams = signal<CalibrationParameters>(StateEstimator.getDefaultCalibration());

  // Economics
  readonly economicParams = signal<EconomicParams>({
    naturalGasPriceGBPPerMWh: 28.5,
    electricityPriceGBPPerMWh: 88.0,
    carbonPriceGBPPerTonneCO2: 65.0,
    variableOAndMGBPPerMWh: 3.5,
  });

  // Transient Simulation State
  readonly isTransientRunning = signal<boolean>(false);
  readonly transientSteps = signal<TransientTimeStep[]>([]);
  readonly currentTransientStepIndex = signal<number>(0);

  // 20-Year Operational Historian
  readonly historianPoints = signal<HistorianTimePoint[]>(SyntheticPlantEngine.generateHistorianHistory());
  readonly selectedHistorianIndex = signal<number>(180); // Default to around year 2021

  // 1. Core Thermodynamic Cycle Calculation (Computed Purely from Invariants)
  readonly currentCycle = computed<CycleSimulationResult>(() => {
    return CycleSolver.solve(
      this.turbineConfig(),
      this.ambientState(),
      this.fuelComposition(),
      this.loadFraction(),
      this.igvAngleDeg(),
      this.compressorFoulingFraction(),
      this.turbineDegradationFraction(),
      this.filterLossFactor(),
      this.enableCombinedCycle()
    );
  });

  // 2. Second-Law Exergy Analysis
  readonly currentExergy = computed<ExergyAnalysisResult>(() => {
    return ExergyEngine.analyze(this.currentCycle());
  });

  // 3. Synthetic Telemetry Sensors
  readonly currentSensors = computed<SyntheticSensor[]>(() => {
    const cycle = this.currentCycle();
    return SyntheticPlantEngine.generateSensorReadings(
      {
        powerMW: cycle.netElectricalPowerMW,
        fuelFlowKgS: cycle.fuelFlowKgS,
        cdpBar: cycle.state2_cdp.pressurePa / 100000,
        cdtC: cycle.state2_cdp.temperatureK - 273.15,
        titC: cycle.state3_tit.temperatureK - 273.15,
        egtC: cycle.state4_egt.temperatureK - 273.15,
        rpm: cycle.config.ratedShaftSpeedRpm,
        ambientTempC: cycle.ambient.temperatureC,
        ambientBar: cycle.ambient.pressureBar,
        airFlowKgS: cycle.airMassFlowKgS,
        noxPpm: cycle.emissions.noxPpmvd15O2,
        coPpm: cycle.emissions.coPpmvd15O2,
      },
      {
        sensorDriftTag: this.injectedSensorDriftTag(),
        sensorStuckTag: this.injectedSensorStuckTag(),
        biasPercent: 12.0,
      }
    );
  });

  // 4. State Estimation & Model Comparison
  readonly estimatedStateResult = computed(() => {
    return StateEstimator.estimateState(
      this.currentCycle(),
      this.currentSensors(),
      this.calibrationParams()
    );
  });

  // 5. Component Health & Diagnostics
  readonly componentHealth = computed<ComponentHealthBreakdown>(() => {
    return DiagnosticsEngine.evaluateHealth(
      this.currentCycle(),
      this.currentCycle().inletFilterLossPercent,
      this.currentCycle().compressorFoulingPercent,
      this.currentCycle().turbineDegradationPercent
    );
  });

  readonly performanceGap = computed<PerformanceGap>(() => {
    return DiagnosticsEngine.computePerformanceGap(
      this.currentCycle(),
      this.turbineConfig().ratedPowerMW
    );
  });

  readonly diagnosticFindings = computed<DiagnosticFinding[]>(() => {
    return DiagnosticsEngine.runDiagnostics(
      this.currentCycle(),
      this.performanceGap(),
      this.currentSensors()
    );
  });

  // 6. Multi-Objective Pareto Frontier
  readonly paretoFrontier = computed<ParetoPoint[]>(() => {
    return OptimiserEngine.generateParetoFrontier(
      this.turbineConfig(),
      this.ambientState(),
      this.fuelComposition(),
      this.economicParams()
    );
  });

  // 7. Golden Operating Point Comparison
  readonly goldenPointComparison = computed<GoldenOperatingPointComparison>(() => {
    return OptimiserEngine.findGoldenOperatingPoint(
      this.turbineConfig(),
      this.ambientState(),
      this.fuelComposition(),
      this.loadFraction(),
      this.igvAngleDeg(),
      'MAX_EFFICIENCY',
      this.economicParams()
    );
  });

  // 8. 2D Operating Envelope Map
  readonly operatingEnvelope = computed<OperatingEnvelopeCell[]>(() => {
    return OptimiserEngine.generateOperatingEnvelope(
      this.turbineConfig(),
      this.fuelComposition()
    );
  });

  constructor() {
    // Initialize transient startup steps on load
    this.transientSteps.set(TransientEngine.simulateStartupSequence());
  }

  // Action methods
  setMode(mode: OperatingMode): void {
    this.currentMode.set(mode);
  }

  setTurbinePreset(key: string): void {
    const preset = TURBINE_PRESETS[key];
    if (preset) {
      this.activePresetKey.set(key);
      this.turbineConfig.set(preset);
    }
  }

  setAmbientPreset(preset: 'ISO_DAY' | 'HOT_DAY' | 'COLD_DAY' | 'HIGH_ALTITUDE' | 'CUSTOM'): void {
    this.ambientPresetKey.set(preset);
  }

  setHydrogenBlend(volPercent: number): void {
    this.hydrogenVolPercent.set(Math.min(100, Math.max(0, volPercent)));
  }

  setLoadFraction(fraction: number): void {
    this.loadFraction.set(Math.min(1.05, Math.max(0.20, fraction)));
  }

  setIgvAngle(deg: number): void {
    this.igvAngleDeg.set(Math.min(15, Math.max(-10, deg)));
  }

  setCompressorFouling(fraction: number): void {
    this.compressorFoulingFraction.set(Math.min(0.15, Math.max(0, fraction)));
  }

  setTurbineDegradation(fraction: number): void {
    this.turbineDegradationFraction.set(Math.min(0.10, Math.max(0, fraction)));
  }

  simulateCompressorWash(): void {
    this.compressorFoulingFraction.set(0.005); // Restores ~96%
    this.filterLossFactor.set(1.0);
  }

  applyGoldenOperatingPoint(): void {
    const golden = this.goldenPointComparison();
    this.igvAngleDeg.set(golden.optimal.igvAngleDeg);
    this.loadFraction.set(golden.optimal.loadFraction);
  }

  injectSensorFault(tag: string, type: 'DRIFT' | 'STUCK'): void {
    if (type === 'DRIFT') {
      this.injectedSensorDriftTag.set(tag);
      this.injectedSensorStuckTag.set(undefined);
    } else {
      this.injectedSensorStuckTag.set(tag);
      this.injectedSensorDriftTag.set(undefined);
    }
  }

  clearFaults(): void {
    this.injectedSensorDriftTag.set(undefined);
    this.injectedSensorStuckTag.set(undefined);
    this.compressorFoulingFraction.set(0);
    this.turbineDegradationFraction.set(0);
    this.filterLossFactor.set(1.0);
  }

  launchDemo(demo: SignatureDemo): void {
    this.selectedDemo.set(demo);
    this.clearFaults();

    switch (demo.id) {
      case 'demo_1_cycle':
        this.currentMode.set('CYCLE');
        this.loadFraction.set(1.0);
        this.igvAngleDeg.set(0);
        this.enableCombinedCycle.set(false);
        break;
      case 'demo_2_fouling':
        this.currentMode.set('DIGITAL_TWIN');
        this.compressorFoulingFraction.set(0.065); // 6.5% fouling
        this.filterLossFactor.set(1.4);
        break;
      case 'demo_3_golden_point':
        this.currentMode.set('OPTIMISATION');
        this.loadFraction.set(0.80);
        this.igvAngleDeg.set(-4.0);
        break;
      case 'demo_4_hydrogen':
        this.currentMode.set('SCENARIOS');
        this.hydrogenVolPercent.set(30);
        break;
      case 'demo_5_digital_twin':
        this.currentMode.set('DIGITAL_TWIN');
        this.injectSensorFault('PT-201', 'DRIFT');
        break;
      case 'demo_6_time_machine':
        this.currentMode.set('SCENARIOS');
        this.selectedHistorianIndex.set(120);
        break;
      case 'demo_7_pareto':
        this.currentMode.set('OPTIMISATION');
        break;
      case 'demo_8_combined_cycle':
        this.currentMode.set('CYCLE');
        this.enableCombinedCycle.set(true);
        break;
    }
  }

  startStartupSimulation(): void {
    this.isTransientRunning.set(true);
    this.transientSteps.set(TransientEngine.simulateStartupSequence(this.turbineConfig().ratedShaftSpeedRpm, this.turbineConfig().ratedPowerMW));
    this.currentTransientStepIndex.set(0);
    this.currentMode.set('TRANSIENT');
  }

  startTripSimulation(cause: 'OVERSPEED' | 'EGT_OVERTEMP' | 'GRID_LOSS' | 'SURGE'): void {
    this.isTransientRunning.set(true);
    this.transientSteps.set(TransientEngine.simulateTripSequence(cause, this.turbineConfig().ratedShaftSpeedRpm, this.currentCycle().netElectricalPowerMW));
    this.currentTransientStepIndex.set(0);
    this.currentMode.set('TRANSIENT');
  }

  setTransientStep(idx: number): void {
    const steps = this.transientSteps();
    if (idx >= 0 && idx < steps.length) {
      this.currentTransientStepIndex.set(idx);
    }
  }
}
