import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderBar } from './components/header-bar/header-bar';
import { KpiBar } from './components/kpi-bar/kpi-bar';
import { OverviewView } from './components/overview-view/overview-view';
import { CycleView } from './components/cycle-view/cycle-view';
import { ExergyView } from './components/exergy-view/exergy-view';
import { DigitalTwinView } from './components/digital-twin-view/digital-twin-view';
import { DiagnosticsView } from './components/diagnostics-view/diagnostics-view';
import { OptimisationView } from './components/optimisation-view/optimisation-view';
import { ScenariosView } from './components/scenarios-view/scenarios-view';
import { TransientView } from './components/transient-view/transient-view';
import { DocsView } from './components/docs-view/docs-view';
import { GeminiConsultant } from './components/gemini-consultant/gemini-consultant';
import { TurbineService } from './services/turbine.service';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderBar,
    KpiBar,
    OverviewView,
    CycleView,
    ExergyView,
    DigitalTwinView,
    DiagnosticsView,
    OptimisationView,
    ScenariosView,
    TransientView,
    DocsView,
    GeminiConsultant,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly service = inject(TurbineService);
}
