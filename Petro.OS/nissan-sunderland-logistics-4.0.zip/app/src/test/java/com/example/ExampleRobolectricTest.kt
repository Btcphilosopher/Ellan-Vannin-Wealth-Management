package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.SimulationParams
import com.example.data.repository.SunderlandRepository
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Sunderland Logistics 4.0", appName)
    }

    @Test
    fun `repository returns initial plant status`() {
        val repo = SunderlandRepository.getInstance()
        val status = repo.plantStatus.value
        assertTrue(status.productionRunning)
        assertEquals(58, status.taktTimeSeconds)
        assertEquals(472, status.agvFleetActive)
    }

    @Test
    fun `simulation engine calculates risk correctly`() {
        val repo = SunderlandRepository.getInstance()
        val result = repo.runSimulation(SimulationParams(line2ProductionDeltaPercent = 15))
        assertNotNull(result)
        assertTrue(result.agvDemandDeltaPercent > 0)
    }
}
