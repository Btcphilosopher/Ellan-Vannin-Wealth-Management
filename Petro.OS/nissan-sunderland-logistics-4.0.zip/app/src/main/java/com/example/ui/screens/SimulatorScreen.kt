package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SimulationParams
import com.example.ui.components.EngineeringSectionHeader
import com.example.ui.components.IndustrialCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

@Composable
fun SimulatorScreen(
    viewModel: SunderlandViewModel,
    modifier: Modifier = Modifier
) {
    val simParams by viewModel.simParams.collectAsState()
    val simResult by viewModel.simResult.collectAsState()

    val presets = listOf(
        "Line 2 Speed +12%" to SimulationParams(line2ProductionDeltaPercent = 12),
        "Supplier Delay 3 Hrs" to SimulationParams(supplierDelayHours = 3),
        "Battery Demand +25%" to SimulationParams(batteryDemandDeltaPercent = 25),
        "Zone B Congestion 50%" to SimulationParams(zoneBCongestionFactor = 50)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("simulator_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Simulator Header
        item {
            IndustrialCard(
                borderColor = NissanRed
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Science,
                                contentDescription = "Simulation",
                                tint = NissanRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "DIGITAL TWIN WHAT-IF SIMULATOR",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Text(
                            text = "Simulate plant traffic, line rate shifts & bottleneck predictions",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                    Button(
                        onClick = { viewModel.updateSimParams(SimulationParams()) },
                        colors = ButtonDefaults.buttonColors(containerColor = IndustrialCardElevated),
                        border = BorderStroke(1.dp, IndustrialBorder),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Reset", tint = TextPrimary, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("RESET", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp))
                    }
                }
            }
        }

        // Preset Quick Buttons
        item {
            Text(
                text = "PRESET SCENARIOS:",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                presets.take(2).forEach { (label, params) ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(2.dp))
                            .background(IndustrialCard)
                            .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                            .clickable { viewModel.updateSimParams(params) }
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }
        }

        // Interactive Sliders Controls
        item {
            EngineeringSectionHeader(title = "Simulation Parameters", code = "PARAMS-5")

            IndustrialCard {
                // Parameter 1: Line 2 Production Rate Delta
                Text(
                    text = "Line 2 Production Rate Delta: ${simParams.line2ProductionDeltaPercent}%",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace)
                )
                Slider(
                    value = simParams.line2ProductionDeltaPercent.toFloat(),
                    onValueChange = { viewModel.updateSimParams(simParams.copy(line2ProductionDeltaPercent = it.toInt())) },
                    valueRange = -20f..50f,
                    colors = SliderDefaults.colors(thumbColor = NissanRed, activeTrackColor = NissanRed)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Parameter 2: Supplier Delay Hours
                Text(
                    text = "Supplier Delivery Delay: ${simParams.supplierDelayHours} Hours",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace)
                )
                Slider(
                    value = simParams.supplierDelayHours.toFloat(),
                    onValueChange = { viewModel.updateSimParams(simParams.copy(supplierDelayHours = it.toInt())) },
                    valueRange = 0f..12f,
                    colors = SliderDefaults.colors(thumbColor = NissanAmber, activeTrackColor = NissanAmber)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Parameter 3: Battery Demand Delta
                Text(
                    text = "EV Battery Pack Demand Delta: ${simParams.batteryDemandDeltaPercent}%",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace)
                )
                Slider(
                    value = simParams.batteryDemandDeltaPercent.toFloat(),
                    onValueChange = { viewModel.updateSimParams(simParams.copy(batteryDemandDeltaPercent = it.toInt())) },
                    valueRange = -30f..50f,
                    colors = SliderDefaults.colors(thumbColor = NissanGreen, activeTrackColor = NissanGreen)
                )
            }
        }

        // Live Simulation Results Output
        if (simResult != null) {
            val res = simResult!!
            item {
                EngineeringSectionHeader(title = "Simulation Results Output", code = "PREDICTED-IMPACT")

                val riskColor = when (res.riskLevel) {
                    "CRITICAL" -> NissanRed
                    "MODERATE" -> NissanAmber
                    else -> NissanGreen
                }

                IndustrialCard(
                    borderColor = riskColor,
                    backgroundColor = IndustrialCardElevated
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PREDICTED RISK LEVEL: ${res.riskLevel}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = riskColor
                            )
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(riskColor.copy(alpha = 0.2f))
                                .border(1.dp, riskColor, RoundedCornerShape(2.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "BOTTLENECK: ${res.predictedBottleneckZone.uppercase()}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = riskColor,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = IndustrialBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Impact Delta Breakdown
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("AGV DEMAND", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                            Text("+${res.agvDemandDeltaPercent}%", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, color = NissanBlue, fontSize = 14.sp))
                        }
                        Column {
                            Text("LINE REPLENISHMENT", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                            Text("+${res.lineSideReplenishmentDeltaPercent}%", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp))
                        }
                        Column {
                            Text("WAREHOUSE UTIL", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                            Text("+${res.warehouseUtilisationDeltaPercent}%", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp))
                        }
                        Column {
                            Text("DOCK DEMAND", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                            Text("+${res.dockDemandDeltaTrucksPerHour} trucks/hr", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Recommendations
                    Text(
                        text = "RECOMMENDED COUNTERMEASURES:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    res.recommendations.forEach { rec ->
                        Text(
                            text = "• $rec",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextPrimary,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
