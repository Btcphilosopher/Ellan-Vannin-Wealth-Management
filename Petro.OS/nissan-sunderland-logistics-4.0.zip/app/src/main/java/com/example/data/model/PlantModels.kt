package com.example.data.model

enum class ZoneStatus {
    NORMAL,       // White / Graphite
    ATTENTION,    // Amber
    INTERVENTION, // Red
    HEALTHY       // Green
}

enum class ZoneType {
    PRESS_SHOP,
    BODY_SHOP,
    PAINT_SHOP,
    TRIM_CHASSIS_1,
    TRIM_CHASSIS_2,
    BATTERY_PLANT,
    WAREHOUSE_RAW,
    WAREHOUSE_BATTERY,
    WAREHOUSE_FINISHED,
    SUPPLIER_DOCK
}

data class PlantZone(
    val id: String,
    val name: String,
    val code: String,
    val type: ZoneType,
    val status: ZoneStatus,
    val utilizationPercent: Int,
    val activeAgvCount: Int,
    val activePartsCount: Int,
    val bottleneckWarning: String? = null,
    val mapBoundsX: Float,
    val mapBoundsY: Float,
    val mapWidth: Float,
    val mapHeight: Float
)

data class PlantStatus(
    val productionRunning: Boolean,
    val vehiclesInProductionToday: Int,
    val targetDailyVehicles: Int,
    val currentVehicleModels: List<String>,
    val taktTimeSeconds: Int,
    val lineSpeedPercent: Float,
    val inventoryHealthScore: Int,
    val criticalShortagesCount: Int,
    val agvFleetActive: Int,
    val agvFleetTotal: Int,
    val warehouseUtilizationPercent: Int,
    val inboundTrucksActive: Int,
    val outboundLogisticsStatus: String,
    val plantPowerKw: Double,
    val solarContributionPercent: Int,
    val batteryStorageKwh: Int,
    val shiftName: String
)
