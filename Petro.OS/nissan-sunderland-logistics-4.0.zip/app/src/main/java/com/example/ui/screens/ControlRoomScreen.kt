package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.components.IndustrialCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

data class ControlRoomMetric(
    val id: String,
    val label: String,
    val value: String,
    val unit: String = "",
    val statusText: String,
    val isOk: Boolean,
    val detailText: String
)

@Composable
fun ControlRoomScreen(
    viewModel: SunderlandViewModel,
    modifier: Modifier = Modifier
) {
    val plantStatus by viewModel.plantStatus.collectAsState()
    val activeModalTitle by viewModel.controlRoomModalTitle.collectAsState()

    val metrics = remember(plantStatus) {
        listOf(
            ControlRoomMetric(
                id = "PROD",
                label = "PRODUCTION RATE",
                value = "${plantStatus.lineSpeedPercent}%",
                statusText = "LINE SPEED NOMINAL",
                isOk = true,
                detailText = "Trim & Chassis Line 1 & 2 operating at 98.7% nominal throughput. 1,482 vehicles completed on early shift."
            ),
            ControlRoomMetric(
                id = "LOGISTICS",
                label = "LOGISTICS HEALTH",
                value = "99.2%",
                statusText = "REPLENISHMENT OPTIMAL",
                isOk = true,
                detailText = "Line-side delivery efficiency 99.2%. Mean AGV transit latency 2.4 minutes."
            ),
            ControlRoomMetric(
                id = "AGV",
                label = "AGV FLEET AVAILABILITY",
                value = "${plantStatus.agvFleetActive}",
                unit = "/ ${plantStatus.agvFleetTotal}",
                statusText = "472/475 VEHICLES ONLINE",
                isOk = true,
                detailText = "3 AGVs in scheduled inductive charging dock. 0 active physical collision alerts."
            ),
            ControlRoomMetric(
                id = "INBOUND",
                label = "INBOUND LOGISTICS",
                value = "${plantStatus.inboundTrucksActive}",
                unit = "ACTIVE",
                statusText = "DOCKS 01-12 OPERATIONAL",
                isOk = true,
                detailText = "18 inbound supplier trucks scheduled. 4 currently at unloading bays."
            ),
            ControlRoomMetric(
                id = "CRITICAL",
                label = "CRITICAL SHORTAGES",
                value = "${plantStatus.criticalShortagesCount}",
                statusText = "0 PRODUCTION STOPPERS",
                isOk = true,
                detailText = "Zero line-stop risks identified in current 8-hour shift."
            ),
            ControlRoomMetric(
                id = "INCIDENTS",
                label = "INCIDENTS LOGGED",
                value = "2",
                statusText = "MINOR TEMPORARY HALTS",
                isOk = false,
                detailText = "1 temporary AGV route blockage cleared in Zone B2. 1 customs paperwork delay on Dock 06."
            ),
            ControlRoomMetric(
                id = "ENERGY",
                label = "ENERGY POWER TWIN",
                value = "${plantStatus.plantPowerKw.toInt()}",
                unit = "kW",
                statusText = "${plantStatus.solarContributionPercent}% SOLAR CONTRIBUTION",
                isOk = true,
                detailText = "Site electrical load 14,250 kW. Solar array generating 3,990 kW. Battery storage 12,500 kWh."
            ),
            ControlRoomMetric(
                id = "TAKT",
                label = "TAKT TIME",
                value = "${plantStatus.taktTimeSeconds}",
                unit = "sec",
                statusText = "TARGET: 58 SEC/VEHICLE",
                isOk = true,
                detailText = "Pacing strictly synchronized with Japanese Intelligent Factory manufacturing spec."
            ),
            ControlRoomMetric(
                id = "SHIFT",
                label = "SHIFT COMPLETED",
                value = "${plantStatus.vehiclesInProductionToday}",
                unit = "units",
                statusText = "TARGET: ${plantStatus.targetDailyVehicles}",
                isOk = true,
                detailText = "On schedule to exceed daily target by +1.2%."
            )
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("control_room_screen")
    ) {
        // Command Room Widescreen Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(IndustrialDarkBg)
                .border(1.dp, NissanRed, RoundedCornerShape(4.dp))
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SUNDERLAND PLANT LOGISTICS COMMAND ROOM",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = "FULL PLANT OVERVIEW MODE • CLICK ANY METRIC FOR OPERATIONAL DRILLDOWN",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = NissanBlue,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(2.dp))
                        .background(NissanRed)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "COMMAND DISPLAY LIVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 9-Metric Widescreen Grid Layout
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(metrics.size) { index ->
                val m = metrics[index]
                val borderCol = if (m.isOk) IndustrialBorder else NissanAmber

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(IndustrialCard)
                        .border(1.dp, borderCol, RoundedCornerShape(4.dp))
                        .clickable { viewModel.setControlRoomModal(m.label) }
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = m.label,
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = m.value,
                                style = MaterialTheme.typography.displayMedium.copy(
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            if (m.unit.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = m.unit,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = m.statusText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (m.isOk) NissanGreen else NissanAmber,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }
    }

    // Modal Drilldown Dialog
    if (activeModalTitle != null) {
        val activeMetric = metrics.find { it.label == activeModalTitle }
        if (activeMetric != null) {
            Dialog(onDismissRequest = { viewModel.setControlRoomModal(null) }) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        .clip(RoundedCornerShape(6.dp))
                        .border(1.dp, NissanRed, RoundedCornerShape(6.dp)),
                    color = IndustrialSurface
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = activeMetric.label,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            IconButton(
                                onClick = { viewModel.setControlRoomModal(null) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextSecondary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "VALUE: ${activeMetric.value} ${activeMetric.unit}",
                            style = MaterialTheme.typography.displayMedium.copy(fontSize = 22.sp, color = NissanBlue)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = IndustrialBorder)
                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "OPERATIONAL DRILLDOWN DATA:",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontFamily = FontFamily.Monospace)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = activeMetric.detailText,
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary)
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.setControlRoomModal(null) },
                            colors = ButtonDefaults.buttonColors(containerColor = NissanRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("CLOSE DRILLDOWN", style = MaterialTheme.typography.labelMedium.copy(fontFamily = FontFamily.Monospace))
                        }
                    }
                }
            }
        }
    }
}
