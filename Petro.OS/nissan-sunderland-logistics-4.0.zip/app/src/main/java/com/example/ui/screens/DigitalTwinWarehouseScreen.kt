package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InventoryItem
import com.example.data.model.QualityStatus
import com.example.data.model.ReplenishmentStatus
import com.example.ui.components.EngineeringSectionHeader
import com.example.ui.components.IndustrialCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalTwinWarehouseScreen(
    viewModel: SunderlandViewModel,
    modifier: Modifier = Modifier
) {
    val inventoryItems by viewModel.inventoryItems.collectAsState()
    val selectedItem by viewModel.selectedInventoryItem.collectAsState()

    var activeLevel by remember { mutableStateOf("ALL") } // SITE, BUILDING, ZONE, AISLE, RACK, LOCATION, PALLET, PART
    var searchQuery by remember { mutableStateOf("") }

    val levels = listOf("ALL", "BUILDING", "ZONE", "AISLE", "RACK", "LOCATION", "PALLET", "PART")

    val filteredItems = inventoryItems.filter { item ->
        if (searchQuery.isEmpty()) true
        else item.partNumber.contains(searchQuery, ignoreCase = true) ||
                item.description.contains(searchQuery, ignoreCase = true) ||
                item.vehicleModel.contains(searchQuery, ignoreCase = true) ||
                item.supplierName.contains(searchQuery, ignoreCase = true) ||
                item.location.locationId.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("digital_twin_warehouse_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header & Scanner Trigger Button
        item {
            IndustrialCard(
                borderColor = NissanRed
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "2D/3D HYBRID DIGITAL SPATIAL TWIN",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Real-time location, quantity, batch & quality traceability",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                    Button(
                        onClick = { viewModel.openScanner() },
                        colors = ButtonDefaults.buttonColors(containerColor = NissanRed),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.testTag("open_scanner_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.QrCodeScanner,
                            contentDescription = "Scan RFID",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SCAN RFID/QR",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Zoom Hierarchy Navigation Bar: SITE -> BUILDING -> ZONE -> AISLE -> RACK -> LOCATION -> PALLET -> PART
        item {
            Text(
                text = "SPATIAL ZOOM HIERARCHY:",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(levels) { lvl ->
                    val isSelected = activeLevel == lvl
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (isSelected) NissanRed else IndustrialCard)
                            .border(1.dp, if (isSelected) NissanRed else IndustrialBorder, RoundedCornerShape(2.dp))
                            .clickable { activeLevel = lvl }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = lvl,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (isSelected) TextPrimary else TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search Part #, Description, Supplier or Location ID", style = TextStyle(color = TextSecondary, fontSize = 12.sp)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search", tint = TextSecondary) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("warehouse_search_field"),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NissanRed,
                    unfocusedBorderColor = IndustrialBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = IndustrialCard,
                    unfocusedContainerColor = IndustrialCard
                )
            )
        }

        // Detailed Selected Item Inspection Card (if any item is selected)
        if (selectedItem != null) {
            item {
                val item = selectedItem!!
                IndustrialCard(
                    borderColor = NissanBlue,
                    backgroundColor = IndustrialCardElevated
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "PART RECORD: ${item.partNumber}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(NissanGreen.copy(alpha = 0.2f))
                                .border(1.dp, NissanGreen, RoundedCornerShape(2.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = item.qualityStatus.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = NissanGreen,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = IndustrialBorder)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("LOCATION ID", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                            Text(item.location.locationId, style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace))
                        }
                        Column {
                            Text("STOCK QUANTITY", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                            Text("${item.quantity} ${item.unitOfMeasure}", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace))
                        }
                        Column {
                            Text("SAFETY BUFFER", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                            Text("${item.safetyStock} Min", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace))
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Supplier: ${item.supplierName} • Batch: ${item.batchNumber} • Target Station: ${item.destinationStation}",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                    )
                }
            }
        }

        // Inventory Items List
        item {
            EngineeringSectionHeader(
                title = "Live Inventory Locations",
                code = "ITEMS-${filteredItems.size}"
            )
        }

        items(filteredItems) { item ->
            val isSelected = selectedItem?.id == item.id
            IndustrialCard(
                borderColor = if (isSelected) NissanRed else IndustrialBorder,
                onClick = { viewModel.selectInventoryItem(item) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.partNumber,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        )
                        Text(
                            text = item.description,
                            style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontSize = 12.sp)
                        )
                        Text(
                            text = "Loc: ${item.location.locationId} • Dest: ${item.destinationStation} • Qty: ${item.quantity}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        val replColor = when (item.replenishmentStatus) {
                            ReplenishmentStatus.OPTIMAL -> NissanGreen
                            ReplenishmentStatus.LOW_STOCK_WARNING -> NissanAmber
                            ReplenishmentStatus.CRITICAL_SHORTAGE -> NissanRed
                            ReplenishmentStatus.REPLENISHMENT_DISPATCHED -> NissanBlue
                        }
                        Text(
                            text = item.replenishmentStatus.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = replColor,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.supplierName,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
