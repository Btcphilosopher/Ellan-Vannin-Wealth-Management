package com.example.data.model

data class SimulationParams(
    val line2ProductionDeltaPercent: Int = 0,    // -20% to +50%
    val supplierDelayHours: Int = 0,               // 0 to 12 hrs
    val batteryDemandDeltaPercent: Int = 0,       // -30% to +50%
    val shiftChangeOverlapMinutes: Int = 0,       // 0 to 45 min
    val zoneBCongestionFactor: Int = 0             // 0 to 100%
)

data class SimulationResult(
    val agvDemandDeltaPercent: Int,
    val lineSideReplenishmentDeltaPercent: Int,
    val warehouseUtilisationDeltaPercent: Int,
    val dockDemandDeltaTrucksPerHour: Int,
    val predictedBottleneckZone: String,
    val riskLevel: String, // "NORMAL", "MODERATE", "CRITICAL"
    val recommendations: List<String>
)

data class EquipmentItem(
    val id: String,
    val name: String,               // e.g. WH-03 ASRS Stacker Crane 2
    val type: String,               // e.g. ASRS Crane / AGV Charging Dock / Robot Arm / Scanner Gate
    val locationZone: String,
    val healthScorePercent: Float,  // e.g. 97.4%
    val vibrationMmS: Float,
    val operatingTempCelsius: Float,
    val predictedFailureHours: Int,
    val status: String,             // "OPERATIONAL", "MAINTENANCE_DUE", "CRITICAL_INSPECTION"
    val lastServiceDate: String
)

data class AuditLogEntry(
    val id: String,
    val timestamp: String,
    val operatorId: String,
    val operatorRole: String,
    val actionType: String,       // e.g. "AGV_QUARANTINE", "MISSION_OVERRIDE", "EMERGENCY_HALT"
    val targetResource: String,
    val verificationStatus: String // "VERIFIED_HMAC_SHA256", "SSO_AUTHENTICATED"
)

data class IntegrationSystem(
    val systemCode: String,        // e.g. MES, ERP, WMS, SCADA, OPC-UA, MQTT
    val systemName: String,
    val protocol: String,          // e.g. REST / WebSockets / OPC-UA / MQTT / Kafka
    val status: String,            // "CONNECTED_LIVE", "DEGRADED", "SYNCING"
    val throughputEventsPerSec: Int,
    val latencyMs: Int
)
