package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BarcodeScannerDialog
import com.example.ui.navigation.NavDestination
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SunderlandLogisticsTheme {
                MainAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: SunderlandViewModel = viewModel()
) {
    val currentDestination by viewModel.currentDestination.collectAsState()
    val isScannerOpen by viewModel.isScannerOpen.collectAsState()
    val scannedItem by viewModel.scannedResultItem.collectAsState()
    val scanError by viewModel.scanError.collectAsState()

    // Handle Back Button to return to Command Centre if on another screen
    BackHandler(enabled = currentDestination != NavDestination.COMMAND_CENTRE) {
        viewModel.navigateTo(NavDestination.COMMAND_CENTRE)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_app_scaffold"),
        containerColor = IndustrialDarkBg,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(IndustrialSurface)
                    .statusBarsPadding()
                    .border(1.dp, IndustrialBorder)
            ) {
                // Primary Industrial Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(width = 4.dp, height = 22.dp)
                                .background(NissanRed)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "NISSAN SUNDERLAND",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    letterSpacing = 1.sp,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "LOGISTICS 4.0 DIGITAL OPERATING SYSTEM",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = NissanRed,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    letterSpacing = 0.5.sp
                                )
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Scanner Action Button
                        IconButton(
                            onClick = { viewModel.openScanner() },
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(IndustrialCardElevated)
                                .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                                .testTag("header_scanner_icon")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.QrCodeScanner,
                                contentDescription = "Scanner",
                                tint = NissanRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        // Widescreen Command Mode Button
                        IconButton(
                            onClick = { viewModel.navigateTo(NavDestination.CONTROL_ROOM) },
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (currentDestination == NavDestination.CONTROL_ROOM) NissanRed else IndustrialCardElevated)
                                .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                                .testTag("header_control_room_icon")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Fullscreen,
                                contentDescription = "Control Room",
                                tint = TextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Scrollable Navigation Destination Tabs Bar
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(NavDestination.entries.toTypedArray()) { dest ->
                        val isSelected = currentDestination == dest
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (isSelected) NissanRed else IndustrialCard)
                                .border(1.dp, if (isSelected) NissanRed else IndustrialBorder, RoundedCornerShape(2.dp))
                                .clickable { viewModel.navigateTo(dest) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("nav_tab_${dest.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = dest.icon,
                                    contentDescription = dest.title,
                                    tint = if (isSelected) TextPrimary else TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = dest.title.uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isSelected) TextPrimary else TextSecondary,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
        ) {
            when (currentDestination) {
                NavDestination.COMMAND_CENTRE -> CommandCentreScreen(viewModel = viewModel)
                NavDestination.DIGITAL_TWIN_WAREHOUSE -> DigitalTwinWarehouseScreen(viewModel = viewModel)
                NavDestination.LINESIDE_LOGISTICS -> LineSideLogisticsScreen(viewModel = viewModel)
                NavDestination.AGV_CONTROL -> AgvControlScreen(viewModel = viewModel)
                NavDestination.INVENTORY_INTELLIGENCE -> InventoryIntelligenceScreen(viewModel = viewModel)
                NavDestination.SUPPLIER_GATE -> SupplierGateScreen(viewModel = viewModel)
                NavDestination.BATTERY_LOGISTICS -> BatteryLogisticsScreen(viewModel = viewModel)
                NavDestination.DIGITAL_TWIN_SIMULATOR -> SimulatorScreen(viewModel = viewModel)
                NavDestination.PREDICTIVE_MAINTENANCE -> PredictiveMaintenanceScreen(viewModel = viewModel)
                NavDestination.CONTROL_ROOM -> ControlRoomScreen(viewModel = viewModel)
                NavDestination.SYSTEM_ARCHITECTURE -> SystemArchitectureScreen(viewModel = viewModel)
            }

            // Scanner Overlay Dialog
            BarcodeScannerDialog(
                isOpen = isScannerOpen,
                scannedItem = scannedItem,
                errorMessage = scanError,
                onClose = { viewModel.closeScanner() },
                onScan = { code -> viewModel.performScan(code) }
            )
        }
    }
}
