package com.example.data.model

enum class CustomsStatus {
    CLEARED,
    PENDING_DECLARATION,
    UNDER_INSPECTION
}

enum class QualityGateStatus {
    PASSED,
    SAMPLING_REQUIRED,
    REJECTED
}

enum class GateStatus {
    SCHEDULED,
    APPROACHING,
    AT_DOCK,
    UNLOADING,
    COMPLETED
}

data class InboundDelivery(
    val bookingId: String,
    val supplierName: String,
    val vehiclePlate: String,
    val driverName: String,
    val scheduledEta: String,
    val actualEta: String,
    val cargoSummary: String,
    val palletCount: Int,
    val assignedDock: String,       // e.g. Dock 04
    val customsStatus: CustomsStatus,
    val qualityStatus: QualityGateStatus,
    val unloadingProgressPercent: Int,
    val gateStatus: GateStatus
)

data class DockDoor(
    val dockId: String,          // Dock 01 - Dock 12
    val zone: String,            // Inbound Gate A
    val isOccupied: Boolean,
    val currentTruckPlate: String?,
    val assignedSupplier: String?
)
