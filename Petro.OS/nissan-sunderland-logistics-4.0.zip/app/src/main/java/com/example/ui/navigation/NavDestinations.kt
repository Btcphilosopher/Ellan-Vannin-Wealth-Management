package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

enum class NavDestination(
    val title: String,
    val subtitle: String,
    val icon: ImageVector
) {
    COMMAND_CENTRE("Command Centre", "Site Digital Twin & Plant Status", Icons.Filled.Dashboard),
    DIGITAL_TWIN_WAREHOUSE("Digital Twin Warehouse", "2D/3D Hybrid Spatial Inventory", Icons.Filled.Warehouse),
    LINESIDE_LOGISTICS("Line-Side Logistics", "Predictive Production Replenishment", Icons.Filled.PrecisionManufacturing),
    AGV_CONTROL("AGV Fleet Control", "Autonomous Logistics Management", Icons.Filled.DirectionsCar),
    INVENTORY_INTELLIGENCE("Inventory Intelligence", "Predictive Analytics & 8-Hr Forecast", Icons.Filled.Analytics),
    SUPPLIER_GATE("Supplier Gate", "Inbound Dock Portal & Gate Management", Icons.Filled.LocalShipping),
    BATTERY_LOGISTICS("EV Battery Logistics", "Cell to Vehicle Genealogy & Traceability", Icons.Filled.BatteryChargingFull),
    DIGITAL_TWIN_SIMULATOR("Scenario Simulator", "Plant Capacity & Shortage Simulation", Icons.Filled.Science),
    PREDICTIVE_MAINTENANCE("Predictive Maintenance", "Equipment Reliability & Telemetry", Icons.Filled.Build),
    CONTROL_ROOM("Control Room Mode", "Widescreen Command Center View", Icons.Filled.Fullscreen),
    SYSTEM_ARCHITECTURE("API & Security", "Industrial Protocols & Zero-Trust Audit", Icons.Filled.Security)
}
