package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlantZone
import com.example.ui.components.*
import com.example.ui.navigation.NavDestination
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

@Composable
fun CommandCentreScreen(
    viewModel: SunderlandViewModel,
    modifier: Modifier = Modifier
) {
    val plantStatus by viewModel.plantStatus.collectAsState()
    val zones by viewModel.plantZones.collectAsState()
    val agvs by viewModel.agvVehicles.collectAsState()
    val selectedZone by viewModel.selectedZone.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("command_centre_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Plant Overview Header Card
        item {
            IndustrialCard(
                borderColor = NissanRed,
                backgroundColor = IndustrialSurface
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (plantStatus.productionRunning) NissanGreen else NissanRed)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "NISSAN SUNDERLAND • ${plantStatus.shiftName}",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Models in assembly: ${plantStatus.currentVehicleModels.joinToString(" • ")}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(IndustrialCardElevated)
                            .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "TAKT: ${plantStatus.taktTimeSeconds}s",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Key KPI Gauge Cards Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricGaugeCard(
                    title = "Line Speed",
                    value = "${plantStatus.lineSpeedPercent}%",
                    unit = "Nominal",
                    statusText = "Vehicles: ${plantStatus.vehiclesInProductionToday}/${plantStatus.targetDailyVehicles}",
                    statusColor = NissanGreen,
                    icon = Icons.Filled.Speed,
                    modifier = Modifier.weight(1f),
                    testTag = "kpi_line_speed"
                )
                MetricGaugeCard(
                    title = "Inventory Health",
                    value = "${plantStatus.inventoryHealthScore}%",
                    unit = "Optimal",
                    statusText = "Critical Shortages: ${plantStatus.criticalShortagesCount}",
                    statusColor = if (plantStatus.criticalShortagesCount == 0) NissanGreen else NissanRed,
                    icon = Icons.Filled.Warehouse,
                    modifier = Modifier.weight(1f),
                    testTag = "kpi_inventory_health"
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricGaugeCard(
                    title = "AGV Fleet",
                    value = "${plantStatus.agvFleetActive}",
                    unit = "/ ${plantStatus.agvFleetTotal}",
                    statusText = "Active Autonomous Fleet",
                    statusColor = NissanBlue,
                    icon = Icons.Filled.DirectionsCar,
                    modifier = Modifier.weight(1f),
                    testTag = "kpi_agv_fleet"
                )
                MetricGaugeCard(
                    title = "Inbound Trucks",
                    value = "${plantStatus.inboundTrucksActive}",
                    unit = "Active",
                    statusText = plantStatus.outboundLogisticsStatus,
                    statusColor = TextSecondary,
                    icon = Icons.Filled.LocalShipping,
                    modifier = Modifier.weight(1f),
                    testTag = "kpi_inbound_trucks"
                )
            }
        }

        // Live Interactive Plant Map
        item {
            EngineeringSectionHeader(
                title = "Live Site Digital Twin Map",
                code = "MAP-SUNDERLAND-4.0",
                actionText = "Open Control Room",
                onActionClick = { viewModel.navigateTo(NavDestination.CONTROL_ROOM) }
            )
            PlantMapCanvas(
                zones = zones,
                agvs = agvs,
                selectedZone = selectedZone,
                onZoneClick = { zone -> viewModel.selectZone(zone) }
            )
        }

        // Zone Drilldown Detail Card if a zone is clicked
        if (selectedZone != null) {
            item {
                val zone = selectedZone!!
                IndustrialCard(
                    borderColor = NissanRed,
                    backgroundColor = IndustrialCardElevated
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ZONE INSPECTION: ${zone.name.uppercase()}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Code: ${zone.code} • Type: ${zone.type} • Utilization: ${zone.utilizationPercent}%",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }
                        StatusBadge(text = zone.status.name, status = zone.status)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Active AGVs: ${zone.activeAgvCount} • Component Count: ${zone.activePartsCount}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                    if (zone.bottleneckWarning != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "⚠ BOTTLENECK WARNING: ${zone.bottleneckWarning}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanAmber,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Plant Energy & Sustainability Panel
        item {
            EngineeringSectionHeader(title = "Energy & Power Twin", code = "PWR-SUNDERLAND")
            IndustrialCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SITE POWER CONSUMPTION",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                        Text(
                            text = "${plantStatus.plantPowerKw} kW",
                            style = MaterialTheme.typography.displayMedium.copy(fontSize = 20.sp)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "SOLAR & WIND: ${plantStatus.solarContributionPercent}%",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "BATTERY STORAGE: ${plantStatus.batteryStorageKwh} kWh",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }
            }
        }

        // Live Zone Status List
        item {
            EngineeringSectionHeader(title = "Manufacturing & Warehouse Zones", code = "ZONES-8")
        }

        items(zones) { zone ->
            IndustrialCard(
                onClick = { viewModel.selectZone(zone) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = zone.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp)
                        )
                        Text(
                            text = "Utilisation: ${zone.utilizationPercent}% • AGVs: ${zone.activeAgvCount} • Parts: ${zone.activePartsCount}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                        )
                    }
                    StatusBadge(text = zone.status.name, status = zone.status)
                }
            }
        }
    }
}
