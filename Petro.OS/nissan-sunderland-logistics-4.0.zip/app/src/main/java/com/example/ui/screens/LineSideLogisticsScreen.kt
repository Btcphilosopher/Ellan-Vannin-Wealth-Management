package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EngineeringSectionHeader
import com.example.ui.components.IndustrialCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

data class StationReplenishmentDemand(
    val partNumber: String,
    val description: String,
    val vehicleModel: String,
    val currentStock: Int,
    val lineDemandPerHour: Int,
    val predictedShortageMin: Int,
    val assignedAgvId: String,
    val route: String,
    val eta: String,
    val targetStation: String
)

@Composable
fun LineSideLogisticsScreen(
    viewModel: SunderlandViewModel,
    modifier: Modifier = Modifier
) {
    val agvList by viewModel.agvVehicles.collectAsState()

    val stationDemands = remember {
        listOf(
            StationReplenishmentDemand(
                partNumber = "55820-EX01A",
                description = "Qashqai EV Front Assembly Subframe",
                vehicleModel = "Qashqai EV",
                currentStock = 184,
                lineDemandPerHour = 31,
                predictedShortageMin = 42,
                assignedAgvId = "AGV-042",
                route = "WH-03 → T&C-14",
                eta = "06:42",
                targetStation = "T&C-14"
            ),
            StationReplenishmentDemand(
                partNumber = "292C0-5XX0A",
                description = "LEAF 62kWh Battery Module Pack",
                vehicleModel = "LEAF EV",
                currentStock = 92,
                lineDemandPerHour = 18,
                predictedShortageMin = 85,
                assignedAgvId = "AGV-108",
                route = "AESC GIGA → BATT-LINE-02",
                eta = "06:45",
                targetStation = "BATT-LINE-02"
            ),
            StationReplenishmentDemand(
                partNumber = "62022-3XX0B",
                description = "JUKE Front Bumper Pearl Painted",
                vehicleModel = "JUKE Hybrid",
                currentStock = 64,
                lineDemandPerHour = 28,
                predictedShortageMin = 18, // Critical Shortage
                assignedAgvId = "AGV-215",
                route = "WH-03 → T&C-08",
                eta = "06:38",
                targetStation = "T&C-08"
            ),
            StationReplenishmentDemand(
                partNumber = "98100-CH01A",
                description = "Chill-Out EV Wiring Harness Kit",
                vehicleModel = "Chill-Out EV",
                currentStock = 210,
                lineDemandPerHour = 14,
                predictedShortageMin = 240,
                assignedAgvId = "AGV-042",
                route = "WH-01 → T&C-22",
                eta = "07:12",
                targetStation = "T&C-22"
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("lineside_logistics_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Line-Side Logistics Pipeline Header
        item {
            IndustrialCard(
                borderColor = NissanRed
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.PrecisionManufacturing,
                                contentDescription = "Manufacturing",
                                tint = NissanRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AUTOMATED LINE-SIDE REPLENISHMENT",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "PRODUCTION DEMAND → INVENTORY ANALYSIS → ROUTE OPTIMISATION → AGV DISPATCH",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanBlue,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp
                            )
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(NissanGreen.copy(alpha = 0.15f))
                            .border(1.dp, NissanGreen, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "AUTO-DISPATCH LIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        item {
            EngineeringSectionHeader(
                title = "Live Line Replenishment Queue",
                code = "DEMAND-PREDICTOR-4.0"
            )
        }

        items(stationDemands) { demand ->
            val isUrgent = demand.predictedShortageMin < 30
            IndustrialCard(
                borderColor = if (isUrgent) NissanRed else IndustrialBorder,
                backgroundColor = if (isUrgent) NissanRed.copy(alpha = 0.08f) else IndustrialCard
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PART ${demand.partNumber}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        )
                        Text(
                            text = "${demand.description} (${demand.vehicleModel})",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (isUrgent) NissanRed else NissanAmber)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isUrgent) "SHORTAGE: ${demand.predictedShortageMin} MIN" else "SHORTAGE: ${demand.predictedShortageMin} MIN",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Divider(color = IndustrialBorder)
                Spacer(modifier = Modifier.height(10.dp))

                // Logistics Metrics Breakdown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("LINE-SIDE STOCK", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text("${demand.currentStock} Units", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp))
                    }
                    Column {
                        Text("LINE DEMAND", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text("${demand.lineDemandPerHour} / hr", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, fontSize = 13.sp))
                    }
                    Column {
                        Text("ASSIGNED AGV", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text(demand.assignedAgvId, style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, color = NissanBlue, fontSize = 13.sp))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Route & Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Route: ${demand.route} • ETA: ${demand.eta}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    )
                    Button(
                        onClick = {
                            viewModel.dispatchAgvMission(demand.assignedAgvId, demand.targetStation, demand.partNumber)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IndustrialCardElevated),
                        border = BorderStroke(1.dp, NissanBlue),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Autorenew,
                            contentDescription = "Priority Dispatch",
                            tint = NissanBlue,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "FORCE DISPATCH",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanBlue,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
