package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AGVVehicle
import com.example.data.model.PlantZone
import com.example.data.model.ZoneStatus
import com.example.ui.theme.*

@OptIn(ExperimentalTextApi::class)
@Composable
fun PlantMapCanvas(
    zones: List<PlantZone>,
    agvs: List<AGVVehicle>,
    selectedZone: PlantZone?,
    onZoneClick: (PlantZone) -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .testTag("plant_map_canvas")
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(IndustrialDarkBg)
            .border(1.dp, IndustrialBorder, RoundedCornerShape(4.dp))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(zones) {
                    detectTapGestures { tapOffset ->
                        val width = size.width
                        val height = size.height
                        val clickedZone = zones.find { zone ->
                            val left = zone.mapBoundsX * width
                            val top = zone.mapBoundsY * height
                            val right = left + zone.mapWidth * width
                            val bottom = top + zone.mapHeight * height
                            tapOffset.x in left..right && tapOffset.y in top..bottom
                        }
                        if (clickedZone != null) {
                            onZoneClick(clickedZone)
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height

            // 1. Blueprint Grid Lines
            val gridStep = 40.dp.toPx()
            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)

            var x = 0f
            while (x < width) {
                drawLine(
                    color = IndustrialBorder.copy(alpha = 0.25f),
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 1f,
                    pathEffect = dashEffect
                )
                x += gridStep
            }

            var y = 0f
            while (y < height) {
                drawLine(
                    color = IndustrialBorder.copy(alpha = 0.25f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f,
                    pathEffect = dashEffect
                )
                y += gridStep
            }

            // 2. Connecting AGV Transit Tracks
            val trackPath = Path().apply {
                moveTo(width * 0.15f, height * 0.20f)
                lineTo(width * 0.45f, height * 0.20f)
                lineTo(width * 0.45f, height * 0.45f)
                lineTo(width * 0.75f, height * 0.45f)
                lineTo(width * 0.75f, height * 0.75f)
                lineTo(width * 0.25f, height * 0.75f)
                close()
            }
            drawPath(
                path = trackPath,
                color = NissanBlue.copy(alpha = 0.35f),
                style = Stroke(width = 2f, pathEffect = dashEffect)
            )

            // 3. Draw Plant Zones
            zones.forEach { zone ->
                val zX = zone.mapBoundsX * width
                val zY = zone.mapBoundsY * height
                val zW = zone.mapWidth * width
                val zH = zone.mapHeight * height

                val isSelected = selectedZone?.id == zone.id

                val (statusColor, strokeColor) = when (zone.status) {
                    ZoneStatus.HEALTHY -> Pair(NissanGreen.copy(alpha = 0.15f), NissanGreen)
                    ZoneStatus.ATTENTION -> Pair(NissanAmber.copy(alpha = 0.20f), NissanAmber)
                    ZoneStatus.INTERVENTION -> Pair(NissanRed.copy(alpha = 0.25f), NissanRed)
                    ZoneStatus.NORMAL -> Pair(IndustrialCard.copy(alpha = 0.8f), IndustrialAluminium)
                }

                // Fill rect
                drawRect(
                    color = if (isSelected) statusColor.copy(alpha = 0.4f) else statusColor,
                    topLeft = Offset(zX, zY),
                    size = Size(zW, zH)
                )

                // Outline
                drawRect(
                    color = if (isSelected) NissanRed else strokeColor,
                    topLeft = Offset(zX, zY),
                    size = Size(zW, zH),
                    style = Stroke(width = if (isSelected) 3f else 1.5f)
                )

                // Zone Code Label
                val labelResult = textMeasurer.measure(
                    AnnotatedString("${zone.code} (${zone.utilizationPercent}%)"),
                    style = TextStyle(
                        color = TextPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                )
                drawText(
                    textLayoutResult = labelResult,
                    topLeft = Offset(zX + 6f, zY + 6f)
                )
            }

            // 4. Draw AGV Fleet Dots
            agvs.forEach { agv ->
                val agvX = agv.posX * width
                val agvY = agv.posY * height

                val agvColor = when (agv.state) {
                    com.example.data.model.AGVState.IN_TRANSIT -> NissanBlue
                    com.example.data.model.AGVState.BLOCKED -> NissanRed
                    com.example.data.model.AGVState.CHARGING -> NissanAmber
                    com.example.data.model.AGVState.QUARANTINED -> NissanRed
                    else -> IndustrialAluminium
                }

                drawCircle(
                    color = agvColor.copy(alpha = 0.3f),
                    radius = 10f,
                    center = Offset(agvX, agvY)
                )
                drawCircle(
                    color = agvColor,
                    radius = 5f,
                    center = Offset(agvX, agvY)
                )
            }
        }

        // Overlay Legend Header
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(IndustrialDarkBg.copy(alpha = 0.85f))
                .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "NISSAN SUNDERLAND DIGITAL TWIN MAP",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "54°58'N 1°28'W • 472 ACTIVE AGVs",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = NissanBlue,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
            )
        }
    }
}
