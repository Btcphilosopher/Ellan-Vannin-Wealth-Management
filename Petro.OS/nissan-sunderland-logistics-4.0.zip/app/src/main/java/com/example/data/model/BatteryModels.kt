package com.example.data.model

data class TemperatureSample(
    val timeLabel: String,
    val tempCelsius: Float
)

data class BatteryCell(
    val cellId: String,
    val cellBatch: String,
    val supplier: String,
    val nominalVoltage: Float,
    val capacityAh: Float
)

data class BatteryModule(
    val moduleId: String,
    val cellCount: Int,
    val cells: List<BatteryCell>,
    val testVoltage: Float,
    val internalResistanceMilliOhm: Float
)

data class BatteryPack(
    val packId: String,               // e.g. BATT-EV-88402
    val vehicleModel: String,         // e.g. Qashqai e-POWER / Leaf 62kWh / Chill-Out EV
    val cellBatch: String,            // e.g. AESC-GB-2026-0811
    val productionDate: String,       // e.g. 2026-09-28
    val supplier: String,             // e.g. AESC Envision Gigafactory Sunderland
    val temperatureHistory: List<TemperatureSample>,
    val electricalTestPassed: Boolean,
    val thermalTestPassed: Boolean,
    val assignedVin: String?,         // e.g. SJNFAAJ16U1098412
    val installationTimestamp: String?,
    val modules: List<BatteryModule>
)
