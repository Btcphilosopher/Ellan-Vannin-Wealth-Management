package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.InventoryItem
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarcodeScannerDialog(
    isOpen: Boolean,
    scannedItem: InventoryItem?,
    errorMessage: String?,
    onClose: () -> Unit,
    onScan: (String) -> Unit
) {
    if (!isOpen) return

    var searchInput by remember { mutableStateOf("") }
    val quickPresetCodes = listOf(
        "RFID-55820-EX01A-9041" to "Qashqai Subframe",
        "RFID-292C0-5XX0A-811" to "LEAF Battery",
        "RFID-62022-3XX0B-412" to "JUKE Bumper",
        "RFID-98100-CH01A-901" to "Wiring Harness"
    )

    Dialog(onDismissRequest = onClose) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .clip(RoundedCornerShape(6.dp))
                .border(1.dp, IndustrialBorder, RoundedCornerShape(6.dp))
                .testTag("barcode_scanner_dialog"),
            color = IndustrialSurface
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.QrCodeScanner,
                            contentDescription = "Scanner",
                            tint = NissanRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "INDUSTRIAL RFID / BARCODE SCANNER",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        )
                    }
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("scanner_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Close Scanner",
                            tint = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Simulated Optical Camera Viewport
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(IndustrialDarkBg)
                        .border(1.dp, NissanRed.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.QrCodeScanner,
                            contentDescription = "Scanning Reticle",
                            tint = NissanRed,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "OPTICAL CAMERA RETICLE ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanRedLight,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        )
                        Text(
                            text = "Point device at physical QR, RFID tag or Component Barcode",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Input Field for Manual Tag or Scanner Handheld
                OutlinedTextField(
                    value = searchInput,
                    onValueChange = { searchInput = it },
                    label = {
                        Text(
                            "Enter Part #, RFID Tag or Barcode",
                            style = TextStyle(color = TextSecondary, fontSize = 12.sp)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("scanner_input_field"),
                    singleLine = true,
                    trailingIcon = {
                        IconButton(
                            onClick = { if (searchInput.isNotEmpty()) onScan(searchInput) },
                            modifier = Modifier.testTag("scanner_search_button")
                        ) {
                            Icon(Icons.Filled.Search, contentDescription = "Search", tint = NissanBlue)
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NissanRed,
                        unfocusedBorderColor = IndustrialBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = IndustrialCard,
                        unfocusedContainerColor = IndustrialCard
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Quick Preset Test Tags
                Text(
                    text = "QUICK SCAN PRESETS:",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    quickPresetCodes.take(2).forEach { (code, label) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(2.dp))
                                .background(IndustrialCardElevated)
                                .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                                .clickable {
                                    searchInput = code
                                    onScan(code)
                                }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                        }
                    }
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = NissanRed,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    )
                }

                if (scannedItem != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    IndustrialCard(
                        borderColor = NissanGreen,
                        backgroundColor = NissanGreen.copy(alpha = 0.1f)
                    ) {
                        Text(
                            text = "FOUND DIGITAL RECORD:",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${scannedItem.partNumber} - ${scannedItem.description}",
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Stock: ${scannedItem.quantity} ${scannedItem.unitOfMeasure} • Location: ${scannedItem.location.locationId}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                        )
                        Text(
                            text = "Supplier: ${scannedItem.supplierName} • Station Destination: ${scannedItem.destinationStation}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
