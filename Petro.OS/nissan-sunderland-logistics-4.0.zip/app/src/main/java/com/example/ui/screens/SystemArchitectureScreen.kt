package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EngineeringSectionHeader
import com.example.ui.components.IndustrialCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

@Composable
fun SystemArchitectureScreen(
    viewModel: SunderlandViewModel,
    modifier: Modifier = Modifier
) {
    val systems by viewModel.integrationSystems.collectAsState()
    val auditLogs by viewModel.auditLogs.collectAsState()

    var emergencyOverrideConfirmed by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("system_architecture_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Architecture Header
        item {
            IndustrialCard(
                borderColor = NissanRed
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = "Security",
                                tint = NissanRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "INDUSTRIAL API & ZERO-TRUST SECURITY",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Text(
                            text = "OPC-UA, MQTT, REST, Kafka, SCADA & Immutable Audit Trail",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(NissanGreen.copy(alpha = 0.2f))
                            .border(1.dp, NissanGreen, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "ZERO-TRUST ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Industrial Systems Integration Gateways
        item {
            EngineeringSectionHeader(
                title = "Industrial Integration Gateways",
                code = "API-CONNECTORS"
            )
        }

        items(systems) { sys ->
            IndustrialCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${sys.systemCode} • ${sys.systemName}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        )
                        Text(
                            text = "Protocol: ${sys.protocol}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(NissanGreen.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = sys.status,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Throughput: ${sys.throughputEventsPerSec} events/sec",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 10.sp)
                    )
                    Text(
                        text = "Latency: ${sys.latencyMs} ms",
                        style = MaterialTheme.typography.labelSmall.copy(color = NissanBlue, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    )
                }
            }
        }

        // Emergency Safeguard Override Procedure
        item {
            EngineeringSectionHeader(
                title = "Safety & Emergency Override Safeguards",
                code = "SAFETY-INTERLOCK"
            )

            IndustrialCard(
                borderColor = NissanRed,
                backgroundColor = NissanRed.copy(alpha = 0.08f)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Warning, contentDescription = "Override Safeguard", tint = NissanRed, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "HUMAN OPERATOR INTERVENTION REQUIREMENT",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NissanRed
                        )
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "AI systems are prohibited from making autonomous safety-critical physical interventions. Manual physical override required for emergency plant halt or route overrides.",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontSize = 11.sp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        emergencyOverrideConfirmed = true
                        viewModel.triggerEmergencyOverride("SITE_WIDE_SAFETY_INTERLOCK")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NissanRed),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("emergency_override_button")
                ) {
                    Text(
                        text = if (emergencyOverrideConfirmed) "EMERGENCY INTERLOCK LOGGED" else "TRIGGER SAFETY OVERRIDE INTERLOCK",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        // Zero-Trust Immutable Audit Log
        item {
            EngineeringSectionHeader(
                title = "Immutable Security Audit Trail",
                code = "AUDIT-HMAC-SHA256"
            )
        }

        items(auditLogs) { log ->
            IndustrialCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${log.timestamp} • ${log.actionType}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = NissanBlue
                            )
                        )
                        Text(
                            text = "Target: ${log.targetResource}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontSize = 11.sp)
                        )
                    }
                    Text(
                        text = log.operatorId,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Sig: ${log.verificationStatus}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = NissanGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                )
            }
        }
    }
}
