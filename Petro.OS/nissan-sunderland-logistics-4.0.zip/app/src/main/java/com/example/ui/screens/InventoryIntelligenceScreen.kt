package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EngineeringSectionHeader
import com.example.ui.components.IndustrialCard
import com.example.ui.components.MetricGaugeCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

@Composable
fun InventoryIntelligenceScreen(
    viewModel: SunderlandViewModel,
    modifier: Modifier = Modifier
) {
    val plantStatus by viewModel.plantStatus.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("inventory_intelligence_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Intelligence Header
        item {
            IndustrialCard(
                borderColor = NissanRed
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Analytics,
                                contentDescription = "Analytics",
                                tint = NissanRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "PREDICTIVE INVENTORY INTELLIGENCE",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Text(
                            text = "Real-time consumption rate, safety stock buffers & ML Lead-time forecasting",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(IndustrialCardElevated)
                            .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "PREDICTION MODEL: V4.2",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // 8-Hour Shift Forecast Card (06:00 - 14:00)
        item {
            EngineeringSectionHeader(
                title = "Next 8 Hours Logistics Forecast",
                code = "SHIFT 06:00-14:00"
            )

            IndustrialCard(
                borderColor = NissanGreen,
                backgroundColor = IndustrialCardElevated
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Schedule, contentDescription = "Shift", tint = NissanGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "EARLY SHIFT PREDICTIVE SUMMARY",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        )
                    }
                    Text(
                        text = "RELIABILITY SCORE: 99.8%",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = NissanGreen,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = IndustrialBorder)
                Spacer(modifier = Modifier.height(12.dp))

                // Forecast Numbers Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("PREDICTED MOVEMENTS", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text("1,842", style = MaterialTheme.typography.displayMedium.copy(fontSize = 18.sp))
                    }
                    Column {
                        Text("AGV MISSIONS", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text("312", style = MaterialTheme.typography.displayMedium.copy(fontSize = 18.sp, color = NissanBlue))
                    }
                    Column {
                        Text("SUPPLIER DELIVERIES", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text("17", style = MaterialTheme.typography.displayMedium.copy(fontSize = 18.sp))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("POTENTIAL SHORTAGES", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text("4 (Low Risk)", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, color = NissanAmber))
                    }
                    Column {
                        Text("CRITICAL SHORTAGES", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text("0", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, color = NissanGreen))
                    }
                }
            }
        }

        // Supplier Reliability & Lead Time Intelligence
        item {
            EngineeringSectionHeader(title = "Supplier Reliability Matrix", code = "SUPPLIER-SCORE")

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricGaugeCard(
                    title = "Calsonic Kansei",
                    value = "99.4%",
                    statusText = "Lead Time: 1.2 hrs • On-Time",
                    statusColor = NissanGreen,
                    modifier = Modifier.weight(1f)
                )
                MetricGaugeCard(
                    title = "AESC Gigafactory",
                    value = "99.9%",
                    statusText = "Lead Time: 0.4 hrs • On-Time",
                    statusColor = NissanGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricGaugeCard(
                    title = "Unipres UK",
                    value = "97.8%",
                    statusText = "Lead Time: 2.1 hrs • Nominal",
                    statusColor = NissanGreen,
                    modifier = Modifier.weight(1f)
                )
                MetricGaugeCard(
                    title = "Kasai UK",
                    value = "94.2%",
                    statusText = "Lead Time: 3.5 hrs • Customs Sampling",
                    statusColor = NissanAmber,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
