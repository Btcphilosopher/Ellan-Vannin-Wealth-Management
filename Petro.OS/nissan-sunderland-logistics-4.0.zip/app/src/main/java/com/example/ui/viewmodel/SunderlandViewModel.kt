package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.SunderlandRepository
import com.example.ui.navigation.NavDestination
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SunderlandViewModel : ViewModel() {

    private val repository = SunderlandRepository.getInstance()

    // Navigation
    private val _currentDestination = MutableStateFlow(NavDestination.COMMAND_CENTRE)
    val currentDestination: StateFlow<NavDestination> = _currentDestination.asStateFlow()

    // Data from Repository
    val plantStatus: StateFlow<PlantStatus> = repository.plantStatus
    val plantZones: StateFlow<List<PlantZone>> = repository.plantZones
    val inventoryItems: StateFlow<List<InventoryItem>> = repository.inventoryItems
    val agvVehicles: StateFlow<List<AGVVehicle>> = repository.agvVehicles
    val inboundDeliveries: StateFlow<List<InboundDelivery>> = repository.inboundDeliveries
    val batteryPacks: StateFlow<List<BatteryPack>> = repository.batteryPacks
    val equipmentItems: StateFlow<List<EquipmentItem>> = repository.equipmentItems
    val integrationSystems: StateFlow<List<IntegrationSystem>> = repository.integrationSystems
    val auditLogs: StateFlow<List<AuditLogEntry>> = repository.auditLogs

    // UI Selections
    private val _selectedZone = MutableStateFlow<PlantZone?>(null)
    val selectedZone: StateFlow<PlantZone?> = _selectedZone.asStateFlow()

    private val _selectedAgv = MutableStateFlow<AGVVehicle?>(null)
    val selectedAgv: StateFlow<AGVVehicle?> = _selectedAgv.asStateFlow()

    private val _selectedInventoryItem = MutableStateFlow<InventoryItem?>(null)
    val selectedInventoryItem: StateFlow<InventoryItem?> = _selectedInventoryItem.asStateFlow()

    // Scanner
    private val _isScannerOpen = MutableStateFlow(false)
    val isScannerOpen: StateFlow<Boolean> = _isScannerOpen.asStateFlow()

    private val _scannedResultItem = MutableStateFlow<InventoryItem?>(null)
    val scannedResultItem: StateFlow<InventoryItem?> = _scannedResultItem.asStateFlow()

    private val _scanError = MutableStateFlow<String?>(null)
    val scanError: StateFlow<String?> = _scanError.asStateFlow()

    // Simulation
    private val _simParams = MutableStateFlow(SimulationParams())
    val simParams: StateFlow<SimulationParams> = _simParams.asStateFlow()

    private val _simResult = MutableStateFlow<SimulationResult?>(null)
    val simResult: StateFlow<SimulationResult?> = _simResult.asStateFlow()

    // Control Room Metric Modal
    private val _controlRoomModalTitle = MutableStateFlow<String?>(null)
    val controlRoomModalTitle: StateFlow<String?> = _controlRoomModalTitle.asStateFlow()

    init {
        // Run initial simulation calculation
        calculateSimulation()
    }

    fun navigateTo(destination: NavDestination) {
        _currentDestination.value = destination
    }

    fun selectZone(zone: PlantZone?) {
        _selectedZone.value = zone
    }

    fun selectAgv(agv: AGVVehicle?) {
        _selectedAgv.value = agv
    }

    fun selectInventoryItem(item: InventoryItem?) {
        _selectedInventoryItem.value = item
    }

    fun openScanner() {
        _isScannerOpen.value = true
        _scanError.value = null
        _scannedResultItem.value = null
    }

    fun closeScanner() {
        _isScannerOpen.value = false
    }

    fun performScan(code: String) {
        viewModelScope.launch {
            val item = repository.findItemByScan(code)
            if (item != null) {
                _scannedResultItem.value = item
                _selectedInventoryItem.value = item
                _scanError.value = null
            } else {
                _scanError.value = "Identifier '$code' not found in Sunderland Digital Twin Registry"
                _scannedResultItem.value = null
            }
        }
    }

    fun dispatchAgvMission(agvId: String, destination: String, partNumber: String) {
        repository.dispatchAgvMission(agvId, destination, partNumber)
        // Refresh selection
        _selectedAgv.value = repository.agvVehicles.value.find { it.id == agvId }
    }

    fun updateAgvState(agvId: String, newState: AGVState, quarantine: Boolean = false) {
        repository.setAgvState(agvId, newState, quarantine)
        _selectedAgv.value = repository.agvVehicles.value.find { it.id == agvId }
    }

    fun updateSimParams(params: SimulationParams) {
        _simParams.value = params
        calculateSimulation()
    }

    fun calculateSimulation() {
        _simResult.value = repository.runSimulation(_simParams.value)
    }

    fun setControlRoomModal(title: String?) {
        _controlRoomModalTitle.value = title
    }

    fun triggerEmergencyOverride(resource: String) {
        repository.addAuditLog("EMERGENCY_OVERRIDE_TRIGGERED", resource)
    }
}
