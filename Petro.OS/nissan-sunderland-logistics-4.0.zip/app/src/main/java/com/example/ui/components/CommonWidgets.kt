package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ZoneStatus
import com.example.ui.theme.*

@Composable
fun IndustrialCard(
    modifier: Modifier = Modifier,
    borderColor: Color = IndustrialBorder,
    backgroundColor: Color = IndustrialCard,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(4.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(backgroundColor)
            .border(1.dp, borderColor, shape)
            .then(
                if (onClick != null) Modifier.clickable { onClick() } else Modifier
            )
            .padding(12.dp)
    ) {
        content()
    }
}

@Composable
fun StatusBadge(
    text: String,
    status: ZoneStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, borderColor) = when (status) {
        ZoneStatus.HEALTHY -> Triple(NissanGreen.copy(alpha = 0.15f), NissanGreen, NissanGreen.copy(alpha = 0.4f))
        ZoneStatus.ATTENTION -> Triple(NissanAmber.copy(alpha = 0.15f), NissanAmber, NissanAmber.copy(alpha = 0.4f))
        ZoneStatus.INTERVENTION -> Triple(NissanRed.copy(alpha = 0.15f), NissanRed, NissanRed.copy(alpha = 0.4f))
        ZoneStatus.NORMAL -> Triple(IndustrialCardElevated, TextSecondary, IndustrialBorder)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(2.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(2.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(
                color = textColor,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        )
    }
}

@Composable
fun MetricGaugeCard(
    title: String,
    value: String,
    unit: String = "",
    statusText: String? = null,
    statusColor: Color = TextSecondary,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
    testTag: String = "metric_gauge_card",
    onClick: (() -> Unit)? = null
) {
    IndustrialCard(
        modifier = modifier.testTag(testTag),
        onClick = onClick
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelMedium.copy(
                    color = TextSecondary,
                    fontSize = 11.sp,
                    letterSpacing = 0.5.sp
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.displayMedium.copy(
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            )
            if (unit.isNotEmpty()) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = unit,
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = TextSecondary,
                        fontSize = 12.sp
                    ),
                    modifier = Modifier.padding(bottom = 2.dp)
                )
            }
        }
        if (statusText != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = statusText,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = statusColor,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            )
        }
    }
}

@Composable
fun EngineeringSectionHeader(
    title: String,
    code: String? = null,
    actionText: String? = null,
    onActionClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(width = 3.dp, height = 16.dp)
                    .background(NissanRed)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
            if (code != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "[$code]",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                )
            }
        }
        if (actionText != null && onActionClick != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                    .clickable { onActionClick() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = actionText.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = NissanBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                )
            }
        }
    }
}
