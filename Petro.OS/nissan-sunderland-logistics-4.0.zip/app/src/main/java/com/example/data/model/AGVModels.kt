package com.example.data.model

enum class AGVState {
    IN_TRANSIT,
    CHARGING,
    IDLE,
    BLOCKED,
    QUARANTINED,
    MAINTENANCE_REQUIRED
}

data class TelemetryData(
    val speedMps: Float,
    val motorTempCelsius: Float,
    val wheelSlipPercent: Float,
    val lidarHealthPercent: Int,
    val wifiRssiDbm: Int,
    val vibrationMmS: Float
)

data class AGVMission(
    val missionId: String,
    val partNumber: String,
    val partDescription: String,
    val origin: String,       // e.g. WH-03
    val destination: String,  // e.g. T&C-14
    val priority: Int,        // 1 (Critical) to 5 (Low)
    val dispatchedTime: String,
    val eta: String
)

data class AGVVehicle(
    val id: String,              // e.g. AGV-042
    val name: String,            // Autonomous Tug 42
    val posX: Float,             // Normalized 0..1 map coordinate
    val posY: Float,
    val batteryPercent: Int,
    val payloadDescription: String,
    val payloadWeightKg: Int,
    val state: AGVState,
    val activeMission: AGVMission?,
    val routeNodes: List<String>,
    val telemetry: TelemetryData,
    val activeFault: String? = null,
    val isQuarantined: Boolean = false
)
