package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class SunderlandRepository private constructor() {

    private val scope = CoroutineScope(Dispatchers.Default)

    // State Flows
    private val _plantStatus = MutableStateFlow(createInitialPlantStatus())
    val plantStatus: StateFlow<PlantStatus> = _plantStatus.asStateFlow()

    private val _plantZones = MutableStateFlow(createInitialZones())
    val plantZones: StateFlow<List<PlantZone>> = _plantZones.asStateFlow()

    private val _inventoryItems = MutableStateFlow(createInitialInventory())
    val inventoryItems: StateFlow<List<InventoryItem>> = _inventoryItems.asStateFlow()

    private val _agvVehicles = MutableStateFlow(createInitialAgvs())
    val agvVehicles: StateFlow<List<AGVVehicle>> = _agvVehicles.asStateFlow()

    private val _inboundDeliveries = MutableStateFlow(createInitialInbound())
    val inboundDeliveries: StateFlow<List<InboundDelivery>> = _inboundDeliveries.asStateFlow()

    private val _batteryPacks = MutableStateFlow(createInitialBatteryPacks())
    val batteryPacks: StateFlow<List<BatteryPack>> = _batteryPacks.asStateFlow()

    private val _equipmentItems = MutableStateFlow(createInitialEquipment())
    val equipmentItems: StateFlow<List<EquipmentItem>> = _equipmentItems.asStateFlow()

    private val _integrationSystems = MutableStateFlow(createInitialSystems())
    val integrationSystems: StateFlow<List<IntegrationSystem>> = _integrationSystems.asStateFlow()

    private val _auditLogs = MutableStateFlow(createInitialAuditLogs())
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

    init {
        // Start background telemetry and AGV movement simulation
        scope.launch {
            while (true) {
                delay(3000)
                tickAgvTelemetryAndPositions()
            }
        }
    }

    private fun tickAgvTelemetryAndPositions() {
        val currentAgvs = _agvVehicles.value
        val updatedAgvs = currentAgvs.map { agv ->
            if (agv.state == AGVState.IN_TRANSIT) {
                val dx = (Random.nextFloat() - 0.5f) * 0.02f
                val dy = (Random.nextFloat() - 0.5f) * 0.02f
                val newX = (agv.posX + dx).coerceIn(0.05f, 0.95f)
                val newY = (agv.posY + dy).coerceIn(0.05f, 0.95f)
                val newBattery = if (agv.batteryPercent > 10) agv.batteryPercent - (if (Random.nextBoolean()) 1 else 0) else 95
                val newTelemetry = agv.telemetry.copy(
                    speedMps = (1.2f + Random.nextFloat() * 0.6f),
                    motorTempCelsius = (38f + Random.nextFloat() * 4f)
                )
                agv.copy(posX = newX, posY = newY, batteryPercent = newBattery, telemetry = newTelemetry)
            } else {
                agv
            }
        }
        _agvVehicles.value = updatedAgvs
    }

    // --- Actions ---

    fun dispatchAgvMission(agvId: String, destination: String, partNumber: String) {
        val agvs = _agvVehicles.value.toMutableList()
        val index = agvs.indexOfFirst { it.id == agvId }
        if (index != -1) {
            val agv = agvs[index]
            val mission = AGVMission(
                missionId = "MSN-${Random.nextInt(1000, 9999)}",
                partNumber = partNumber,
                partDescription = "Urgent Station Replenishment",
                origin = "WH-03",
                destination = destination,
                priority = 1,
                dispatchedTime = getCurrentTimeString(),
                eta = "04:12"
            )
            agvs[index] = agv.copy(
                state = AGVState.IN_TRANSIT,
                activeMission = mission,
                payloadDescription = "Part $partNumber"
            )
            _agvVehicles.value = agvs
            addAuditLog("DISPATCH_MISSION", "AGV $agvId -> $destination ($partNumber)")
        }
    }

    fun setAgvState(agvId: String, newState: AGVState, quarantine: Boolean = false) {
        val agvs = _agvVehicles.value.toMutableList()
        val index = agvs.indexOfFirst { it.id == agvId }
        if (index != -1) {
            val agv = agvs[index]
            agvs[index] = agv.copy(
                state = newState,
                isQuarantined = quarantine,
                activeFault = if (quarantine) "OPERATOR_QUARANTINE_OVERRIDE" else null
            )
            _agvVehicles.value = agvs
            addAuditLog("AGV_STATE_CHANGE", "AGV $agvId set to $newState (Quarantine=$quarantine)")
        }
    }

    fun findItemByScan(code: String): InventoryItem? {
        val cleanCode = code.trim().uppercase()
        return _inventoryItems.value.find {
            it.qrRfidCode.uppercase() == cleanCode ||
                    it.partNumber.uppercase() == cleanCode ||
                    it.id.uppercase() == cleanCode ||
                    it.batchNumber.uppercase() == cleanCode
        }
    }

    fun runSimulation(params: SimulationParams): SimulationResult {
        val agvDelta = (params.line2ProductionDeltaPercent * 1.5f + params.zoneBCongestionFactor * 0.3f).toInt()
        val lineSideDelta = (params.line2ProductionDeltaPercent * 1.2f + params.batteryDemandDeltaPercent * 0.4f).toInt()
        val whDelta = (params.line2ProductionDeltaPercent * 0.6f + params.supplierDelayHours * 2.0f).toInt()
        val dockDelta = (params.line2ProductionDeltaPercent * 0.3f + params.supplierDelayHours * 0.8f).toInt()

        val bottleneck = when {
            params.zoneBCongestionFactor > 40 -> "Zone B2 Body Shop Transit"
            params.batteryDemandDeltaPercent > 20 -> "Battery Plant AESC Feeder Dock"
            params.line2ProductionDeltaPercent > 15 -> "Trim & Chassis Line 2 Station 14"
            params.supplierDelayHours > 3 -> "Inbound Gate 3 Customs Dock"
            else -> "WH-03 High-Bay ASRS"
        }

        val risk = when {
            agvDelta > 25 || params.supplierDelayHours > 5 -> "CRITICAL"
            agvDelta > 10 || params.line2ProductionDeltaPercent > 10 -> "MODERATE"
            else -> "NORMAL"
        }

        val recommendations = mutableListOf<String>()
        if (agvDelta > 15) recommendations.add("Reallocate 12 reserve AGVs from WH-01 to Trim & Chassis Line 2")
        if (params.supplierDelayHours > 2) recommendations.add("Activate Dock 09 buffer queue to prevent yard gridlock")
        if (params.batteryDemandDeltaPercent > 15) recommendations.add("Pre-stage 24 LEAF/Qashqai battery packs in WH-02 buffer")
        if (recommendations.isEmpty()) recommendations.add("Current plant resource allocation is sufficient")

        addAuditLog("SIMULATION_EXECUTED", "Line2Delta=${params.line2ProductionDeltaPercent}%, Risk=$risk")

        return SimulationResult(
            agvDemandDeltaPercent = agvDelta,
            lineSideReplenishmentDeltaPercent = lineSideDelta,
            warehouseUtilisationDeltaPercent = whDelta,
            dockDemandDeltaTrucksPerHour = dockDelta,
            predictedBottleneckZone = bottleneck,
            riskLevel = risk,
            recommendations = recommendations
        )
    }

    fun addAuditLog(action: String, resource: String) {
        val newEntry = AuditLogEntry(
            id = "LOG-${Random.nextInt(10000, 99999)}",
            timestamp = getCurrentTimeString(),
            operatorId = "OP-9042 (J. HENDERSON)",
            operatorRole = "PLANT_LOGISTICS_LEAD",
            actionType = action,
            targetResource = resource,
            verificationStatus = "VERIFIED_HMAC_SHA256"
        )
        _auditLogs.value = listOf(newEntry) + _auditLogs.value.take(25)
    }

    private fun getCurrentTimeString(): String {
        return SimpleDateFormat("HH:mm:ss", Locale.UK).format(Date())
    }

    // --- Mock Data Generators ---

    private fun createInitialPlantStatus() = PlantStatus(
        productionRunning = true,
        vehiclesInProductionToday = 1482,
        targetDailyVehicles = 1500,
        currentVehicleModels = listOf("Qashqai e-POWER", "JUKE Hybrid", "LEAF EV", "Chill-Out EV Concept"),
        taktTimeSeconds = 58,
        lineSpeedPercent = 98.7f,
        inventoryHealthScore = 99,
        criticalShortagesCount = 0,
        agvFleetActive = 472,
        agvFleetTotal = 475,
        warehouseUtilizationPercent = 84,
        inboundTrucksActive = 18,
        outboundLogisticsStatus = "PORT OF TYNE SHUTTLE ON SCHEDULE",
        plantPowerKw = 14250.0,
        solarContributionPercent = 28,
        batteryStorageKwh = 12500,
        shiftName = "EARLY SHIFT (06:00 - 14:00)"
    )

    private fun createInitialZones() = listOf(
        PlantZone("Z-PRESS", "Press Shop", "PRESS", ZoneType.PRESS_SHOP, ZoneStatus.HEALTHY, 78, 24, 1840, null, 0.08f, 0.12f, 0.22f, 0.18f),
        PlantZone("Z-BODY", "Body Shop", "BODY", ZoneType.BODY_SHOP, ZoneStatus.ATTENTION, 92, 68, 4200, "Zone B2 Welding Line High Traffic", 0.32f, 0.12f, 0.30f, 0.22f),
        PlantZone("Z-PAINT", "Paint Shop", "PAINT", ZoneType.PAINT_SHOP, ZoneStatus.NORMAL, 81, 18, 920, null, 0.64f, 0.12f, 0.28f, 0.20f),
        PlantZone("Z-TC1", "Trim & Chassis 1", "T&C-1", ZoneType.TRIM_CHASSIS_1, ZoneStatus.NORMAL, 88, 110, 6400, null, 0.08f, 0.36f, 0.40f, 0.25f),
        PlantZone("Z-TC2", "Trim & Chassis 2", "T&C-2", ZoneType.TRIM_CHASSIS_2, ZoneStatus.HEALTHY, 86, 122, 6800, null, 0.50f, 0.36f, 0.42f, 0.25f),
        PlantZone("Z-BATT", "AESC Envision Battery Plant", "BATT-GIGA", ZoneType.BATTERY_PLANT, ZoneStatus.HEALTHY, 79, 45, 1250, null, 0.08f, 0.64f, 0.35f, 0.28f),
        PlantZone("Z-WH01", "Warehouse 01 Raw Steel & Stamping", "WH-01", ZoneType.WAREHOUSE_RAW, ZoneStatus.NORMAL, 82, 28, 14200, null, 0.45f, 0.64f, 0.22f, 0.28f),
        PlantZone("Z-WH03", "Warehouse 03 High-Bay Logistics Hub", "WH-03", ZoneType.WAREHOUSE_FINISHED, ZoneStatus.HEALTHY, 89, 57, 28900, null, 0.69f, 0.64f, 0.23f, 0.28f)
    )

    private fun createInitialInventory() = listOf(
        InventoryItem(
            id = "INV-55820",
            partNumber = "55820-EX01A",
            description = "Qashqai EV Front Subframe Assembly",
            vehicleModel = "Qashqai EV",
            quantity = 184,
            safetyStock = 45,
            unitOfMeasure = "Units",
            batchNumber = "BATCH-2026-9041",
            supplierName = "Calsonic Kansei UK",
            location = WarehouseLocation("WH03-B2-A08-R04-L02", "WH-03", "Zone B2", "Aisle 08", "Rack 04", "Level 02"),
            destinationStation = "T&C-14",
            lastScanTimestamp = "06:12:04",
            expiryDate = null,
            qualityStatus = QualityStatus.APPROVED,
            replenishmentStatus = ReplenishmentStatus.OPTIMAL,
            qrRfidCode = "RFID-55820-EX01A-9041"
        ),
        InventoryItem(
            id = "INV-292C0",
            partNumber = "292C0-5XX0A",
            description = "LEAF 62kWh Battery Module Pack",
            vehicleModel = "LEAF EV",
            quantity = 92,
            safetyStock = 30,
            unitOfMeasure = "Packs",
            batchNumber = "AESC-GB-2026-0811",
            supplierName = "AESC Envision Gigafactory",
            location = WarehouseLocation("WH02-BAT-A02-R01-L01", "WH-02 Battery Hub", "Battery Buffer", "Aisle 02", "Rack 01", "Level 01"),
            destinationStation = "BATT-LINE-02",
            lastScanTimestamp = "06:28:11",
            expiryDate = "2028-09-01",
            qualityStatus = QualityStatus.APPROVED,
            replenishmentStatus = ReplenishmentStatus.OPTIMAL,
            qrRfidCode = "RFID-292C0-5XX0A-811"
        ),
        InventoryItem(
            id = "INV-62022",
            partNumber = "62022-3XX0B",
            description = "JUKE Front Bumper Fascia Painted Pearl",
            vehicleModel = "JUKE Hybrid",
            quantity = 64,
            safetyStock = 50,
            unitOfMeasure = "Units",
            batchNumber = "KASAI-JUKE-412",
            supplierName = "Kasai UK Manufacturing",
            location = WarehouseLocation("WH03-C1-A12-R02-L03", "WH-03", "Zone C1", "Aisle 12", "Rack 02", "Level 03"),
            destinationStation = "T&C-08",
            lastScanTimestamp = "05:50:22",
            expiryDate = null,
            qualityStatus = QualityStatus.APPROVED,
            replenishmentStatus = ReplenishmentStatus.LOW_STOCK_WARNING,
            qrRfidCode = "RFID-62022-3XX0B-412"
        ),
        InventoryItem(
            id = "INV-98100",
            partNumber = "98100-CH01A",
            description = "Chill-Out EV High Voltage Wiring Harness",
            vehicleModel = "Chill-Out EV Concept",
            quantity = 210,
            safetyStock = 40,
            unitOfMeasure = "Kits",
            batchNumber = "UNIPRES-WIRE-901",
            supplierName = "Unipres UK",
            location = WarehouseLocation("WH01-E4-A04-R05-L01", "WH-01", "Zone E4", "Aisle 04", "Rack 05", "Level 01"),
            destinationStation = "T&C-22",
            lastScanTimestamp = "06:05:50",
            expiryDate = null,
            qualityStatus = QualityStatus.APPROVED,
            replenishmentStatus = ReplenishmentStatus.OPTIMAL,
            qrRfidCode = "RFID-98100-CH01A-901"
        )
    )

    private fun createInitialAgvs() = listOf(
        AGVVehicle(
            id = "AGV-042",
            name = "Nissan AMR Autonomous Tug 042",
            posX = 0.45f,
            posY = 0.38f,
            batteryPercent = 94,
            payloadDescription = "Qashqai Subframe Assembly x 4",
            payloadWeightKg = 680,
            state = AGVState.IN_TRANSIT,
            activeMission = AGVMission("MSN-8812", "55820-EX01A", "Front Subframe", "WH-03", "T&C-14", 1, "06:35", "06:42"),
            routeNodes = listOf("WH-03-GATE", "AISLE-C", "JUNCTION-04", "T&C-14"),
            telemetry = TelemetryData(1.4f, 41.2f, 0.4f, 99, -58, 0.8f)
        ),
        AGVVehicle(
            id = "AGV-108",
            name = "Heavy Duty Battery Transporter 108",
            posX = 0.18f,
            posY = 0.72f,
            batteryPercent = 88,
            payloadDescription = "AESC 62kWh Battery Pack",
            payloadWeightKg = 420,
            state = AGVState.IN_TRANSIT,
            activeMission = AGVMission("MSN-8815", "292C0-5XX0A", "Battery Module Pack", "AESC GIGA", "BATT-LINE-02", 1, "06:38", "06:45"),
            routeNodes = listOf("GIGA-DOCK-1", "TUNNEL-SOUTH", "BATT-LINE-02"),
            telemetry = TelemetryData(1.2f, 39.8f, 0.2f, 100, -52, 0.5f)
        ),
        AGVVehicle(
            id = "AGV-215",
            name = "Line-Side Stacker AGV 215",
            posX = 0.68f,
            posY = 0.42f,
            batteryPercent = 18,
            payloadDescription = "Empty Pallet Return",
            payloadWeightKg = 80,
            state = AGVState.CHARGING,
            activeMission = null,
            routeNodes = listOf("CHARGER-DOCK-04"),
            telemetry = TelemetryData(0.0f, 32.0f, 0.0f, 100, -48, 0.1f)
        ),
        AGVVehicle(
            id = "AGV-302",
            name = "Body Stamping Transport AGV 302",
            posX = 0.35f,
            posY = 0.18f,
            batteryPercent = 76,
            payloadDescription = "Side Body Panel Stamping",
            payloadWeightKg = 850,
            state = AGVState.BLOCKED,
            activeMission = AGVMission("MSN-8790", "78100-3XX", "Side Stamping", "PRESS", "BODY-LINE-1", 2, "06:20", "06:30"),
            routeNodes = listOf("PRESS-EXIT", "JUNCTION-02"),
            telemetry = TelemetryData(0.0f, 44.5f, 0.0f, 92, -64, 1.2f),
            activeFault = "Obstacle Detected: Forklift Operator Temporary Halt"
        )
    )

    private fun createInitialInbound() = listOf(
        InboundDelivery("DEL-901", "Calsonic Kansei UK", "NK73 XPL", "David Miller", "06:45", "06:42", "Subframes & HVAC Assemblies", 24, "Dock 04", CustomsStatus.CLEARED, QualityGateStatus.PASSED, 65, GateStatus.UNLOADING),
        InboundDelivery("DEL-902", "AESC Envision Gigafactory", "GB26 GIGA", "Sarah Jenkins", "07:00", "06:58", "Li-ion Cells & Battery Modules", 12, "Dock 01 (Hazardous EV)", CustomsStatus.CLEARED, QualityGateStatus.PASSED, 20, GateStatus.UNLOADING),
        InboundDelivery("DEL-903", "Unipres UK Manufacturing", "DU68 NSN", "Robert Taylor", "07:15", "07:10", "High Tensile Pressed Steel", 30, "Dock 08", CustomsStatus.CLEARED, QualityGateStatus.SAMPLING_REQUIRED, 0, GateStatus.AT_DOCK),
        InboundDelivery("DEL-904", "Kasai UK Ltd", "NL74 KAS", "Mark Thompson", "07:30", "07:30", "Interior Trim & Door Casing", 18, "Dock 06", CustomsStatus.PENDING_DECLARATION, QualityGateStatus.PASSED, 0, GateStatus.APPROACHING)
    )

    private fun createInitialBatteryPacks() = listOf(
        BatteryPack(
            packId = "BATT-EV-88402",
            vehicleModel = "Qashqai e-POWER 62kWh",
            cellBatch = "AESC-GB-2026-0811",
            productionDate = "2026-09-28",
            supplier = "AESC Envision Gigafactory Sunderland",
            temperatureHistory = listOf(
                TemperatureSample("04:00", 21.2f),
                TemperatureSample("05:00", 22.8f),
                TemperatureSample("06:00", 23.1f)
            ),
            electricalTestPassed = true,
            thermalTestPassed = true,
            assignedVin = "SJNFAAJ16U1098412",
            installationTimestamp = "06:14:22",
            modules = emptyList()
        ),
        BatteryPack(
            packId = "BATT-EV-88405",
            vehicleModel = "LEAF EV 40kWh",
            cellBatch = "AESC-GB-2026-0812",
            productionDate = "2026-09-29",
            supplier = "AESC Envision Gigafactory Sunderland",
            temperatureHistory = listOf(
                TemperatureSample("04:00", 20.8f),
                TemperatureSample("05:00", 21.5f),
                TemperatureSample("06:00", 22.0f)
            ),
            electricalTestPassed = true,
            thermalTestPassed = true,
            assignedVin = "SJNFAAJ16U1098418",
            installationTimestamp = "06:32:10",
            modules = emptyList()
        )
    )

    private fun createInitialEquipment() = listOf(
        EquipmentItem("EQ-ASRS-01", "WH-03 ASRS High-Bay Stacker Crane 1", "ASRS Crane", "WH-03", 98.4f, 0.4f, 36.2f, 1420, "OPERATIONAL", "2026-09-15"),
        EquipmentItem("EQ-CONV-14", "T&C Line 1 Main Chassis Conveyor", "Conveyor Motor", "Trim & Chassis 1", 94.1f, 1.8f, 52.1f, 180, "MAINTENANCE_DUE", "2026-08-20"),
        EquipmentItem("EQ-ROB-082", "Body Shop Fanuc Spot Welding Robot 82", "Robotic Arm", "Body Shop", 99.1f, 0.2f, 41.0f, 2100, "OPERATIONAL", "2026-09-22"),
        EquipmentItem("EQ-CHG-004", "Fast AGV Inductive Charging Dock 4", "Charging Infrastructure", "WH-01 Central", 96.8f, 0.1f, 38.5f, 980, "OPERATIONAL", "2026-09-10")
    )

    private fun createInitialSystems() = listOf(
        IntegrationSystem("MES", "Manufacturing Execution System", "REST / WebSockets", "CONNECTED_LIVE", 480, 4),
        IntegrationSystem("ERP", "SAP S/4HANA Enterprise Resource Planning", "REST API", "CONNECTED_LIVE", 120, 18),
        IntegrationSystem("WMS", "Sunderland Digital Warehouse Management", "REST / MQTT", "CONNECTED_LIVE", 850, 2),
        IntegrationSystem("OPC-UA", "Industrial PLC & SCADA Telemetry Gate", "OPC-UA Binary", "CONNECTED_LIVE", 2400, 1),
        IntegrationSystem("AGV-FLEET", "Autonomous Fleet Dispatcher", "MQTT / WebSockets", "CONNECTED_LIVE", 1800, 3)
    )

    private fun createInitialAuditLogs() = listOf(
        AuditLogEntry("LOG-90112", "06:32:11", "OP-9042 (J. HENDERSON)", "PLANT_LOGISTICS_LEAD", "SYSTEM_STARTUP", "Sunderland Logistics 4.0 Core Kernel", "VERIFIED_HMAC_SHA256"),
        AuditLogEntry("LOG-90110", "06:28:04", "SYS-DISPATCHER", "AUTOMATED_ENGINE", "ROUTE_OPTIMISATION", "AGV-042 Dispatch WH-03 -> T&C-14", "VERIFIED_HMAC_SHA256"),
        AuditLogEntry("LOG-90108", "06:14:00", "GATE-OPERATOR-1", "DOCK_CONTROLLER", "DOCK_ASSIGNMENT", "Delivery DEL-902 -> Dock 01", "VERIFIED_HMAC_SHA256")
    )

    companion object {
        @Volatile
        private var INSTANCE: SunderlandRepository? = null

        fun getInstance(): SunderlandRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SunderlandRepository().also { INSTANCE = it }
            }
        }
    }
}
