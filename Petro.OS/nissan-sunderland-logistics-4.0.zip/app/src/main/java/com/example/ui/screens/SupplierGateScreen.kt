package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CustomsStatus
import com.example.data.model.GateStatus
import com.example.ui.components.EngineeringSectionHeader
import com.example.ui.components.IndustrialCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

@Composable
fun SupplierGateScreen(
    viewModel: SunderlandViewModel,
    modifier: Modifier = Modifier
) {
    val deliveries by viewModel.inboundDeliveries.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("supplier_gate_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Portal Header
        item {
            IndustrialCard(
                borderColor = NissanBlue
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.LocalShipping,
                                contentDescription = "Inbound Trucks",
                                tint = NissanBlue,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SUPPLIER INBOUND LOGISTICS PORTAL",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Text(
                            text = "Automatic Dock Allocation & Customs Gate Control",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(IndustrialCardElevated)
                            .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "12 DOCKS ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        item {
            EngineeringSectionHeader(
                title = "Inbound Truck Schedule & Dock Status",
                code = "GATE-FEED"
            )
        }

        items(deliveries) { del ->
            IndustrialCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = del.supplierName,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        )
                        Text(
                            text = "Plate: ${del.vehiclePlate} • Driver: ${del.driverName}",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontSize = 12.sp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(NissanBlue.copy(alpha = 0.2f))
                            .border(1.dp, NissanBlue, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = del.assignedDock.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = IndustrialBorder)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("CARGO SUMMARY", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text(del.cargoSummary, style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontSize = 11.sp))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("ETA SCHEDULED", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                        Text("${del.scheduledEta} (Actual ${del.actualEta})", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Progress & Status Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Customs: ",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.sp)
                        )
                        Text(
                            text = del.customsStatus.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (del.customsStatus == CustomsStatus.CLEARED) NissanGreen else NissanAmber,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    }

                    if (del.gateStatus == GateStatus.UNLOADING) {
                        Text(
                            text = "Unloading: ${del.unloadingProgressPercent}%",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    } else {
                        Text(
                            text = "Gate Status: ${del.gateStatus.name}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        )
                    }
                }

                if (del.gateStatus == GateStatus.UNLOADING) {
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { del.unloadingProgressPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = NissanGreen,
                        trackColor = IndustrialCardElevated,
                    )
                }
            }
        }
    }
}
