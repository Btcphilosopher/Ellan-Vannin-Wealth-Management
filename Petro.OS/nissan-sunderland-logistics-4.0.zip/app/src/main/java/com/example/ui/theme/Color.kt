package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nissan Sunderland Industrial Color Palette
val IndustrialDarkBg = Color(0xFF0F131A)
val IndustrialSurface = Color(0xFF161C26)
val IndustrialCard = Color(0xFF1E2533)
val IndustrialCardElevated = Color(0xFF283244)
val IndustrialBorder = Color(0xFF3B485E)
val IndustrialAluminium = Color(0xFF90A1B8)

val NissanRed = Color(0xFFD32F2F)
val NissanRedLight = Color(0xFFEF5350)
val NissanAmber = Color(0xFFE67E22)
val NissanGreen = Color(0xFF10B981)
val NissanBlue = Color(0xFF0284C7)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val StatusNormal = Color(0xFF94A3B8)
val StatusAttention = Color(0xFFF39C12)
val StatusIntervention = Color(0xFFE74C3C)
val StatusHealthy = Color(0xFF2ECC71)
