package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AGVState
import com.example.data.model.AGVVehicle
import com.example.ui.components.EngineeringSectionHeader
import com.example.ui.components.IndustrialCard
import com.example.ui.components.PlantMapCanvas
import com.example.ui.theme.*
import com.example.ui.viewmodel.SunderlandViewModel

@Composable
fun AgvControlScreen(
    viewModel: SunderlandViewModel,
    modifier: Modifier = Modifier
) {
    val agvs by viewModel.agvVehicles.collectAsState()
    val zones by viewModel.plantZones.collectAsState()
    val selectedAgv by viewModel.selectedAgv.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("agv_control_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Fleet Header Card
        item {
            IndustrialCard(
                borderColor = NissanBlue
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.DirectionsCar,
                                contentDescription = "AGV Fleet",
                                tint = NissanBlue,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ENTERPRISE AGV FLEET CONTROL",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                        Text(
                            text = "472 Active Autonomous Vehicles • LiDAR & Ultra-Wideband Positioning",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(IndustrialCardElevated)
                            .border(1.dp, IndustrialBorder, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "AUTO-DISPATCH: ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanGreen,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Live Fleet Spatial Map
        item {
            EngineeringSectionHeader(title = "Autonomous Vehicle Map View", code = "AGV-MAP-LIVE")
            PlantMapCanvas(
                zones = zones,
                agvs = agvs,
                selectedZone = null,
                onZoneClick = {}
            )
        }

        // Selected AGV Operator Control Panel
        if (selectedAgv != null) {
            val agv = selectedAgv!!
            item {
                IndustrialCard(
                    borderColor = NissanRed,
                    backgroundColor = IndustrialCardElevated
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "FLEET INSPECTOR: ${agv.id}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = agv.name,
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (agv.isQuarantined) NissanRed else NissanBlue)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (agv.isQuarantined) "QUARANTINED" else agv.state.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = IndustrialBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Telemetry & Battery
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("BATTERY", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                            Text("${agv.batteryPercent}%", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, color = if (agv.batteryPercent > 20) NissanGreen else NissanRed))
                        }
                        Column {
                            Text("SPEED", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                            Text("${agv.telemetry.speedMps} m/s", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace))
                        }
                        Column {
                            Text("MOTOR TEMP", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                            Text("${agv.telemetry.motorTempCelsius}°C", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace))
                        }
                        Column {
                            Text("LiDAR HEALTH", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 9.sp))
                            Text("${agv.telemetry.lidarHealthPercent}%", style = MaterialTheme.typography.labelLarge.copy(fontFamily = FontFamily.Monospace, color = NissanGreen))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Payload: ${agv.payloadDescription} (${agv.payloadWeightKg} kg) • Route: ${agv.routeNodes.joinToString(" → ")}",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                    )

                    if (agv.activeFault != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "⚠ FAULT: ${agv.activeFault}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = NissanAmber,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Operator Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.updateAgvState(agv.id, AGVState.IN_TRANSIT, quarantine = false) },
                            colors = ButtonDefaults.buttonColors(containerColor = NissanGreen),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f).height(32.dp)
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Resume", modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("RESUME", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp))
                        }

                        Button(
                            onClick = { viewModel.updateAgvState(agv.id, AGVState.QUARANTINED, quarantine = true) },
                            colors = ButtonDefaults.buttonColors(containerColor = NissanRed),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f).height(32.dp)
                        ) {
                            Icon(Icons.Filled.Warning, contentDescription = "Quarantine", modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("QUARANTINE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp))
                        }

                        Button(
                            onClick = { viewModel.dispatchAgvMission(agv.id, "T&C-14", "55820-EX01A") },
                            colors = ButtonDefaults.buttonColors(containerColor = IndustrialCard),
                            border = BorderStroke(1.dp, NissanBlue),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f).height(32.dp)
                        ) {
                            Icon(Icons.Filled.Build, contentDescription = "Reassign", tint = NissanBlue, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("REASSIGN", style = MaterialTheme.typography.labelSmall.copy(color = NissanBlue, fontSize = 10.sp))
                        }
                    }
                }
            }
        }

        // AGV Vehicle List
        item {
            EngineeringSectionHeader(title = "Fleet Vehicles Registry", code = "COUNT-${agvs.size}")
        }

        items(agvs) { agv ->
            val isSelected = selectedAgv?.id == agv.id
            IndustrialCard(
                borderColor = if (isSelected) NissanRed else IndustrialBorder,
                onClick = { viewModel.selectAgv(agv) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = agv.id,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        )
                        Text(
                            text = agv.name,
                            style = MaterialTheme.typography.bodySmall.copy(color = TextPrimary, fontSize = 12.sp)
                        )
                        Text(
                            text = "Battery: ${agv.batteryPercent}% • Payload: ${agv.payloadDescription}",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 10.sp)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        val stateColor = when (agv.state) {
                            AGVState.IN_TRANSIT -> NissanBlue
                            AGVState.CHARGING -> NissanAmber
                            AGVState.BLOCKED -> NissanRed
                            AGVState.QUARANTINED -> NissanRed
                            else -> TextSecondary
                        }
                        Text(
                            text = if (agv.isQuarantined) "QUARANTINED" else agv.state.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = stateColor,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
