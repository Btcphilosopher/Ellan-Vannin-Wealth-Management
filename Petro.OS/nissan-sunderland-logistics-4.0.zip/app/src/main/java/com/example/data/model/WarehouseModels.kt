package com.example.data.model

enum class QualityStatus {
    APPROVED,
    PENDING_INSPECTION,
    QUARANTINED,
    TESTING_IN_PROGRESS
}

enum class ReplenishmentStatus {
    OPTIMAL,
    REPLENISHMENT_DISPATCHED,
    LOW_STOCK_WARNING,
    CRITICAL_SHORTAGE
}

data class WarehouseLocation(
    val locationId: String, // e.g. WH03-B2-A08-R04-L02
    val building: String,  // e.g. WH-03 Finished Component Hub
    val zone: String,      // e.g. Zone B2 Body Parts
    val aisle: String,     // Aisle 08
    val rack: String,      // Rack 04
    val shelfLevel: String // Level 02
)

data class InventoryItem(
    val id: String,
    val partNumber: String,          // e.g. 55820-EX01A
    val description: String,         // e.g. Qashqai EV Front Subframe Assembly
    val vehicleModel: String,        // e.g. Qashqai EV
    val quantity: Int,
    val safetyStock: Int,
    val unitOfMeasure: String,
    val batchNumber: String,
    val supplierName: String,
    val location: WarehouseLocation,
    val destinationStation: String, // e.g. T&C-14
    val lastScanTimestamp: String,
    val expiryDate: String?,
    val qualityStatus: QualityStatus,
    val replenishmentStatus: ReplenishmentStatus,
    val qrRfidCode: String
)
