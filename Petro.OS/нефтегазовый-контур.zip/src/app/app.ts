import { ChangeDetectionStrategy, Component, OnInit, OnDestroy, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { translations, TranslationSet } from './i18n.js';

// STRICT STRUCTURAL INTERFACES (REPLACING 'ANY')
export interface Region {
  id: string;
  name: string;
  dailyProduction: number;
}

export interface Field {
  id: string;
  name: string;
  production: number;
  status: string;
}

export interface Well {
  id: string;
  name: string;
  status: 'ACTIVE' | 'MAINTENANCE' | 'OFFLINE';
  choke: number;
  pumpSpeed: number;
  pumpVibration: number;
  pressureBottomhole: number;
  pressureReservoir: number;
  waterCut: number;
  productionOil: number;
  productionGas: number;
  failureProbability: number;
  healthScore: number;
  liftType: string;
  vibrationAnomaly: boolean;
  recommendedAction: string;
  trajectory: string;
}

export interface Unit {
  name: string;
  nameRu: string;
  throughput: number;
  capacity: number;
  status: 'ONLINE' | 'OFFLINE';
  temperature: number;
  pressure: number;
}

export interface Refinery {
  id: string;
  name: string;
  status: string;
  utilisation: number;
  feedrate: number;
  dieselInventory: number;
  gasolineInventory: number;
  units: Unit[];
}

export interface Pipeline {
  id: string;
  name: string;
  flow: number;
  pressure: number;
  status: string;
}

export interface Tank {
  id: string;
  name: string;
  level: number;
  capacity: number;
  product: string;
  currentLevel: number;
}

export interface Supplier {
  id: string;
  name: string;
  category: string;
  qualityScore: number;
  reliability: number;
  risk: string;
}

export interface SalesOrder {
  id: string;
  customer: string;
  volume: number;
  status: string;
}

export interface Project {
  id: string;
  name: string;
  category: 'DIGITAL' | 'DRILLING' | 'INFRASTRUCTURE';
  capex: number;
  npv: number;
  irr: number;
  roic: number;
  status: 'IN_PROGRESS' | 'COMPLETED' | 'SUSPENDED';
}

export interface GasStation {
  id: string;
  name: string;
  location: string;
  dieselLevel: number;
  gas95Level: number;
  gas92Level: number;
  dieselPrice: number;
  gas95Price: number;
  gas92Price: number;
  trafficRate: 'LOW' | 'MEDIUM' | 'HIGH';
  queueSize: number;
  terminalStatus: 'ONLINE' | 'OFFLINE';
  healthScore: number;
}

export interface Alert {
  id: string;
  title: string;
  severity: string;
  message: string;
  timestamp: string;
  assetId?: string;
}

export interface Incident {
  id: string;
  asset: string;
  impact: string;
  rootCause: string;
  status: string;
}

export interface WorkOrder {
  id: string;
  wellId: string;
  asset: string;
  task: string;
  status: 'PENDING' | 'ACCEPTED' | 'ON_SITE' | 'DIAGNOSIS' | 'REPAIR' | 'TEST' | 'COMPLETED';
  safetyRequirements: string[];
}

export interface AuditLogItem {
  id: string;
  user: string;
  timestamp: string;
  entity: string;
  oldValue: string;
  newValue: string;
  reason: string;
}

export interface SimState {
  isPlaying: boolean;
  time: string;
  scenario: string;
  revenue: number;
  opex: number;
  capexTotal: number;
  ebitda: number;
  fcf: number;
  oilPriceRub: number;
  gasPriceRub: number;
  regions: Region[];
  fields: Field[];
  wells: Well[];
  refineries: Refinery[];
  pipelines: Pipeline[];
  tanks: Tank[];
  suppliers: Supplier[];
  salesOrders: SalesOrder[];
  gasStations: GasStation[];
  projects: Project[];
  alerts: Alert[];
  incidents: Incident[];
  workOrders: WorkOrder[];
  auditLog: AuditLogItem[];
}

export interface BlendResult {
  totalVolume: number;
  finalOctane: number;
  finalSulfur: number;
  profit: number;
}

export interface PipeResult {
  pressureDrop: number;
  powerRequired: number;
}

export interface PriceResult {
  finalPrice: string;
  margin: string;
}

export interface ChatMsg {
  id: string;
  sender: 'USER' | 'AI';
  text: string;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  lang: 'RU' | 'EN' = 'RU';
  activeTab = 'home';
  geoLayer = 'reservoir';
  projectFilter = 'ALL';
  
  // Dynamic Sim State
  state!: SimState;
  selectedWell!: Well;
  
  // Form Controls
  roleCtrl = new FormControl('ОПЕРАТОР');
  searchCtrl = new FormControl('');
  scenarioCtrl = new FormControl('BASE');
  
  // Gasoline Blender Form Controls
  targetOctaneCtrl = new FormControl(95);
  targetSulfurCtrl = new FormControl(10);
  blendResult: BlendResult | null = null;

  // Pipeline Flow Form Controls
  pipeDiaCtrl = new FormControl(500);
  pipeFlowCtrl = new FormControl(3500);
  pipeResult: PipeResult | null = null;

  // Pricing Form Controls
  pricingBaseCtrl = new FormControl(45000);
  pricingDiscCtrl = new FormControl(5);
  priceResult: PriceResult | null = null;

  // AI Assistant Chat Logs
  chatLog: ChatMsg[] = [
    {
      id: 'welcome',
      sender: 'AI',
      text: `### 🤖 РОСНЕФТЬ AI АССИСТЕНТ
Приветствую! Я подключен к реальному телеметрическому контуру симуляции. 

Вы можете спросить меня:
* Какие скважины имеют наибольший риск отказа?
* Почему снизилась EBITDA предприятия?
* Какие проекты имеют лучший ROIC?`
    }
  ];
  aiInputCtrl = new FormControl('');
  aiLoading = false;

  private pollInterval: ReturnType<typeof setInterval> | null = null;
  private cdr = inject(ChangeDetectorRef);

  constructor() {
    // Hardcoded initial preview state to prevent any empty UI flashes
    this.state = this.getFallbackState();
    this.selectedWell = this.state.wells[3]; // Default to W-104
  }

  ngOnInit() {
    this.fetchState();
    
    // Poll the simulation state every 2.5 seconds to capture real-time parameters
    this.pollInterval = setInterval(() => {
      this.fetchState();
    }, 2500);

    // Watch for scenario adjustments
    this.scenarioCtrl.valueChanges.subscribe(val => {
      if (val) {
        void this.postControl('SCENARIO', val);
      }
    });
  }

  ngOnDestroy() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
    }
  }

  t(): TranslationSet {
    return translations[this.lang];
  }

  setLang(l: 'RU' | 'EN') {
    this.lang = l;
    this.cdr.markForCheck();
  }

  setTab(t: string) {
    this.activeTab = t;
    this.cdr.markForCheck();
  }

  setProjectFilter(f: string) {
    this.projectFilter = f;
    this.cdr.markForCheck();
  }

  selectWell(w: Well) {
    this.selectedWell = w;
    this.cdr.markForCheck();
  }

  async fetchState() {
    try {
      const res = await fetch('/api/v1/simulation/state');
      if (res.ok) {
        const data = await res.json() as SimState;
        this.state = data;
        
        // Keep active selection in sync with fresh server values
        const updatedSelected = this.state.wells.find(w => w.id === this.selectedWell.id);
        if (updatedSelected) {
          this.selectedWell = updatedSelected;
        }
        
        // Sync macro scenario selector value silently
        if (this.scenarioCtrl.value !== this.state.scenario) {
          this.scenarioCtrl.setValue(this.state.scenario, { emitEvent: false });
        }
        
        this.cdr.markForCheck();
      }
    } catch (e) {
      console.error('Failed to poll simulation state:', e);
    }
  }

  async control(action: string, value?: unknown) {
    await this.postControl(action, value);
  }

  async postControl(action: string, value?: unknown) {
    try {
      const res = await fetch('/api/v1/simulation/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, value })
      });
      if (res.ok) {
        const data = await res.json() as SimState;
        this.state = data;
        
        const updatedSelected = this.state.wells.find(w => w.id === this.selectedWell.id);
        if (updatedSelected) {
          this.selectedWell = updatedSelected;
        }

        this.cdr.markForCheck();
      }
    } catch (e) {
      console.error('Error posting simulation control action:', e);
    }
  }

  triggerScenario(type: 'WELL_FAILURE' | 'REFINERY_SHUTDOWN') {
    if (type === 'WELL_FAILURE') {
      void this.postControl('TRIGGER_WELL_FAILURE');
    } else {
      void this.postControl('TRIGGER_REFINERY_SHUTDOWN');
    }
  }

  // Adjust well choke or ESP speed
  async adjustWell(wellId: string, event: Event, param: 'choke' | 'pumpSpeed') {
    const input = event.target as HTMLInputElement;
    const value = Number(input.value);
    
    try {
      const res = await fetch('/api/v1/simulation/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'UPDATE_WELL',
          wellId,
          [param]: value
        })
      });
      if (res.ok) {
        const data = await res.json() as SimState;
        this.state = data;
        
        const updatedSelected = this.state.wells.find(w => w.id === this.selectedWell.id);
        if (updatedSelected) {
          this.selectedWell = updatedSelected;
        }
        this.cdr.markForCheck();
      }
    } catch (e) {
      console.error('Error adjusting well parameters:', e);
    }
  }

  // Progress offline simulated work order on Kotlin Android interface
  async progressWorkOrder(nextStatus: string) {
    const wo = this.state.workOrders[0];
    try {
      const res = await fetch('/api/v1/work-orders/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workOrderId: wo.id,
          status: nextStatus
        })
      });
      if (res.ok) {
        const data = await res.json() as SimState;
        this.state = data;
        this.cdr.markForCheck();
      }
    } catch (e) {
      console.error('Error progressing work order:', e);
    }
  }

  // GASOLINE BLENDING SOLVER
  async solveBlend() {
    try {
      const res = await fetch('/api/v1/optimisation/blend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetOctane: Number(this.targetOctaneCtrl.value),
          targetSulfur: Number(this.targetSulfurCtrl.value),
          components: [
            { name: 'Изомеризат', octane: 88, sulfur: 2, cost: 24000, volume: 2200 },
            { name: 'Риформат', octane: 98, sulfur: 5, cost: 28000, volume: 4500 },
            { name: 'Бензин ГО', octane: 74, sulfur: 12, cost: 21000, volume: 1200 }
          ]
        })
      });
      if (res.ok) {
        this.blendResult = await res.json() as BlendResult;
        this.cdr.markForCheck();
      }
    } catch (e) {
      console.error('Error solving blending:', e);
    }
  }

  // PIPELINE HYDRAULIC SOLVER
  async solvePipeline() {
    try {
      const res = await fetch('/api/v1/optimisation/pipeline', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          diameterMm: Number(this.pipeDiaCtrl.value),
          flowRate: Number(this.pipeFlowCtrl.value),
          lengthKm: 120,
          roughness: 0.05
        })
      });
      if (res.ok) {
        this.pipeResult = await res.json() as PipeResult;
        this.cdr.markForCheck();
      }
    } catch (e) {
      console.error('Error solving pipeline:', e);
    }
  }

  // SALES PRICING DECIMALS CALCULATOR
  calculatePrice() {
    const base = Number(this.pricingBaseCtrl.value) || 0;
    const discount = Number(this.pricingDiscCtrl.value) || 0;
    
    // Decimal precision formulation
    const finalPrice = base * (1 - discount / 100);
    const costOfProduction = 38000;
    const margin = ((finalPrice - costOfProduction) / finalPrice) * 100;

    this.priceResult = {
      finalPrice: finalPrice.toFixed(2),
      margin: margin.toFixed(1)
    };
    this.cdr.markForCheck();
  }

  // RUSSIAN CYRILLIC TECHNICAL AI CHAT INTERACTION
  async askAi(query: string) {
    this.chatLog.push({ id: `q-${Date.now()}`, sender: 'USER', text: query });
    this.aiLoading = true;
    this.cdr.markForCheck();

    // Check for magical triggers to switch tab context and filter dynamically for the dispatcher!
    const qLower = query.toLowerCase();
    if (qLower.includes('скважин') && qLower.includes('отказ')) {
      setTimeout(() => {
        this.setTab('wells');
        this.searchCtrl.setValue('vibration');
      }, 800);
    }

    try {
      const res = await fetch('/api/v1/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      });
      if (res.ok) {
        const data = await res.json() as { text: string };
        this.chatLog.push({ id: `a-${Date.now()}`, sender: 'AI', text: data.text });
      }
    } catch (e: unknown) {
      const err = e as Error | null;
      this.chatLog.push({ id: `err-${Date.now()}`, sender: 'AI', text: `Ошибка связи: ${err?.message || 'сбой'}` });
    } finally {
      this.aiLoading = false;
      this.cdr.markForCheck();
    }
  }

  askAiFromInput() {
    const val = this.aiInputCtrl.value;
    if (val) {
      void this.askAi(val);
      this.aiInputCtrl.setValue('');
    }
  }

  // COMPACT SEARCH FILTERS FOR WELLS
  filteredWells(): Well[] {
    const search = (this.searchCtrl.value || '').toLowerCase();
    if (!search) return this.state.wells;

    // Advanced technical tags parsing
    if (search === 'vibration' || search === 'вибрация') {
      return this.state.wells.filter(w => w.vibrationAnomaly || w.pumpVibration > 4.2);
    }
    if (search === 'active' || search === 'активные') {
      return this.state.wells.filter(w => w.status === 'ACTIVE');
    }
    if (search === 'maintenance' || search === 'ремонт') {
      return this.state.wells.filter(w => w.status === 'MAINTENANCE' || w.status === 'OFFLINE');
    }

    return this.state.wells.filter(w => 
      w.name.toLowerCase().includes(search) || 
      w.liftType.toLowerCase().includes(search) ||
      w.recommendedAction.toLowerCase().includes(search)
    );
  }

  // STRATEGIC CAPEX PORTFOLIO FILTERS
  filteredProjects(): Project[] {
    if (this.projectFilter === 'ALL') return this.state.projects;
    if (this.projectFilter === 'DIGITAL') {
      return this.state.projects.filter(p => p.category === 'DIGITAL');
    }
    return this.state.projects.filter(p => p.category === 'DRILLING');
  }

  // FALLBACK INITIAL GRAPH STATE (PREVENTS DYNAMIC BLINKING STATE DELAYS)
  getFallbackState(): SimState {
    return {
      isPlaying: false,
      time: new Date().toISOString(),
      scenario: 'BASE',
      revenue: 42500,
      opex: 18400,
      capexTotal: 12500,
      ebitda: 24100,
      fcf: 11600,
      oilPriceRub: 45000,
      gasPriceRub: 5200,
      regions: [{ id: 'REG-01', name: 'Самотлорский сектор', dailyProduction: 145000 }],
      fields: [],
      refineries: [
        {
          id: 'REF-01',
          name: 'НПЗ Рязань',
          status: 'ONLINE',
          utilisation: 88,
          feedrate: 12000,
          dieselInventory: 45000,
          gasolineInventory: 22000,
          units: []
        },
        {
          id: 'REF-02',
          name: 'НПЗ Ярославль',
          status: 'ONLINE',
          utilisation: 92,
          feedrate: 15000,
          dieselInventory: 65000,
          gasolineInventory: 34000,
          units: [
            { name: 'AVT-6', nameRu: 'АВТ-6 (Первичная перегонка)', throughput: 6000, capacity: 6000, status: 'ONLINE', temperature: 360, pressure: 0.3 },
            { name: 'Hydrocracking', nameRu: 'Комплекс гидрокрекинга', throughput: 4500, capacity: 5000, status: 'ONLINE', temperature: 410, pressure: 14.5 }
          ]
        }
      ],
      wells: [
        { id: 'W-101', name: 'Скважина W-101', status: 'ACTIVE', choke: 10, pumpSpeed: 3400, pumpVibration: 2.1, pressureBottomhole: 98, pressureReservoir: 240, waterCut: 12, productionOil: 84, productionGas: 15, failureProbability: 1.1, healthScore: 99, liftType: 'ЭЦН', vibrationAnomaly: false, recommendedAction: 'Режим оптимален.', trajectory: 'Наклонно-направленная' },
        { id: 'W-102', name: 'Скважина W-102', status: 'ACTIVE', choke: 12, pumpSpeed: 3600, pumpVibration: 3.4, pressureBottomhole: 84, pressureReservoir: 240, waterCut: 24, productionOil: 92, productionGas: 22, failureProbability: 4.5, healthScore: 92, liftType: 'ЭЦН', vibrationAnomaly: false, recommendedAction: 'Режим оптимален.', trajectory: 'Горизонтальная' },
        { id: 'W-103', name: 'Скважина W-103', status: 'ACTIVE', choke: 8, pumpSpeed: 3200, pumpVibration: 1.8, pressureBottomhole: 112, pressureReservoir: 240, waterCut: 8, productionOil: 76, productionGas: 12, failureProbability: 0.8, healthScore: 99, liftType: 'ЭЦН', vibrationAnomaly: false, recommendedAction: 'Режим оптимален.', trajectory: 'Наклонно-направленная' },
        { id: 'W-104', name: 'Скважина W-104', status: 'ACTIVE', choke: 12, pumpSpeed: 3800, pumpVibration: 2.4, pressureBottomhole: 78, pressureReservoir: 240, waterCut: 42, productionOil: 105, productionGas: 34, failureProbability: 2.7, healthScore: 95, liftType: 'ЭЦН', vibrationAnomaly: false, recommendedAction: 'Режим оптимален.', trajectory: 'Горизонтальный ствол' }
      ],
      pipelines: [],
      tanks: [],
      suppliers: [],
      salesOrders: [],
      gasStations: [
        { id: 'GS-01', name: 'АЗС №120 «Москва-Центр»', location: 'Москва, ул. Тверская', dieselLevel: 78, gas95Level: 82, gas92Level: 64, dieselPrice: 62.5, gas95Price: 58.4, gas92Price: 51.2, trafficRate: 'HIGH', queueSize: 4, terminalStatus: 'ONLINE', healthScore: 98 },
        { id: 'GS-02', name: 'АЗС №305 «Трасса М4»', location: 'М4, 150 км', dieselLevel: 91, gas95Level: 45, gas92Level: 32, dieselPrice: 61.9, gas95Price: 57.9, gas92Price: 50.8, trafficRate: 'MEDIUM', queueSize: 2, terminalStatus: 'ONLINE', healthScore: 95 }
      ],
      projects: [
        { id: 'PRJ-01', name: 'Зарезка боковых стволов Самотлор', category: 'DRILLING', capex: 1200, npv: 3400, irr: 42, roic: 28, status: 'IN_PROGRESS' },
        { id: 'PRJ-02', name: 'Внедрение APC Рязанский НПЗ', category: 'DIGITAL', capex: 450, npv: 1200, irr: 68, roic: 45, status: 'IN_PROGRESS' }
      ],
      alerts: [],
      incidents: [],
      workOrders: [
        {
          id: 'WO-104',
          wellId: 'W-104',
          asset: 'Скважина W-104',
          task: 'Внеплановая вибродиагностика и юстировка ЭЦН из-за повышенной вибрации привода на Самотлоре',
          status: 'PENDING',
          safetyRequirements: ['Защитная каска', 'Маслостойкие перчатки', 'Газоанализатор', 'Калибратор вибрации']
        }
      ],
      auditLog: []
    };
  }
}
