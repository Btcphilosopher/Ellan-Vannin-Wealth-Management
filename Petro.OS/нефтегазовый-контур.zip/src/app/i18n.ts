// НЕФТЕГАЗОВЫЙ КОНТУР — LOCALIZATION DICTIONARIES
// ru.json and en.json conceptual mapping represented as a unified object

export interface TranslationSet {
  title: string;
  subtitle: string;
  navHome: string;
  navExploration: string;
  navGeology: string;
  navFields: string;
  navWells: string;
  navProduction: string;
  navEquipment: string;
  navDigitalField: string;
  navRefinery: string;
  navPetrochemicals: string;
  navLogistics: string;
  navSupply: string;
  navSales: string;
  navRetail: string;
  navFinance: string;
  navInvestments: string;
  navAnalytics: string;
  navOptimization: string;
  navAI: string;
  navFieldApp: string;
  navAdmin: string;
  
  kpiOil: string;
  kpiGas: string;
  kpiRefining: string;
  kpiSales: string;
  kpiReserves: string;
  kpiRevenue: string;
  kpiEbitda: string;
  kpiFcf: string;
  kpiCapex: string;
  kpiOpex: string;
  kpiEfficiency: string;
  kpiRisks: string;
  
  btnPlay: string;
  btnPause: string;
  btnStep: string;
  btnReset: string;
  lblSimulation: string;
  lblRole: string;
  lblLanguage: string;
  
  resType: string;
  prodChain: string;
  activeAlerts: string;
  incidentsTitle: string;
}

export const translations: Record<'RU' | 'EN', TranslationSet> = {
  RU: {
    title: 'РОСНЕФТЬ DIGITAL OIL & GAS OS',
    subtitle: 'Единая среда управления ресурсами, производством, переработкой, логистикой и капиталом.',
    navHome: 'Главная',
    navExploration: 'Разведка',
    navGeology: 'Геологическая модель',
    navFields: 'Месторождения',
    navWells: 'Скважины',
    navProduction: 'Добыча',
    navEquipment: 'Оборудование',
    navDigitalField: 'Цифровое месторождение',
    navRefinery: 'Переработка',
    navPetrochemicals: 'Нефтехимия',
    navLogistics: 'Логистика',
    navSupply: 'Снабжение',
    navSales: 'Сбыт',
    navRetail: 'АЗС',
    navFinance: 'Финансы',
    navInvestments: 'Инвестиции',
    navAnalytics: 'Аналитика',
    navOptimization: 'Оптимизация',
    navAI: 'ИИ Помощник',
    navFieldApp: 'Полевой обходчик (Kotlin)',
    navAdmin: 'Администрирование',
    
    kpiOil: 'Добыча нефти',
    kpiGas: 'Добыча газа',
    kpiRefining: 'Переработка НПЗ',
    kpiSales: 'Продажи',
    kpiReserves: 'Запасы',
    kpiRevenue: 'Выручка',
    kpiEbitda: 'EBITDA',
    kpiFcf: 'Свободный поток (FCF)',
    kpiCapex: 'Капитальные затраты (CAPEX)',
    kpiOpex: 'Операционные затраты (OPEX)',
    kpiEfficiency: 'Производственная эфф.',
    kpiRisks: 'Риски и инциденты',
    
    btnPlay: 'ЗАПУСК',
    btnPause: 'ПАУЗА',
    btnStep: 'ШАГ ЧАС',
    btnReset: 'СБРОСИТЬ',
    lblSimulation: 'СИМУЛЯЦИЯ',
    lblRole: 'РОЛЬ',
    lblLanguage: 'ЯЗЫК',
    
    resType: 'РЕСУРС. ПРОИЗВОДСТВО. ДАННЫЕ. КОНТРОЛЬ. ЭФФЕКТИВНОСТЬ.',
    prodChain: 'КОМПЬЮТЕРНЫЙ ГРАФ ЦЕПОЧКИ СТОИМОСТИ',
    activeAlerts: 'АКТИВНЫЕ ПРЕДУПРЕЖДЕНИЯ',
    incidentsTitle: 'ЖУРНАЛ КРИТИЧЕСКИХ ИНЦИДЕНТОВ'
  },
  EN: {
    title: 'ROSNEFT DIGITAL OIL & GAS OS',
    subtitle: 'Unified operational environment for resources, production, refining, logistics, and capital.',
    navHome: 'Overview',
    navExploration: 'Exploration',
    navGeology: 'Geological Model',
    navFields: 'Oil Fields',
    navWells: 'Wells',
    navProduction: 'Production',
    navEquipment: 'Equipment',
    navDigitalField: 'Digital Field',
    navRefinery: 'Refining',
    navPetrochemicals: 'Petrochemicals',
    navLogistics: 'Logistics',
    navSupply: 'Supply Chain',
    navSales: 'Sales & Pricing',
    navRetail: 'Filling Stations',
    navFinance: 'Finance',
    navInvestments: 'Investments',
    navAnalytics: 'Analytics',
    navOptimization: 'Optimization',
    navAI: 'AI Assistant',
    navFieldApp: 'Field Operator (Kotlin)',
    navAdmin: 'Administration',
    
    kpiOil: 'Oil Production',
    kpiGas: 'Gas Production',
    kpiRefining: 'Refinery Input',
    kpiSales: 'Product Sales',
    kpiReserves: 'Reserves',
    kpiRevenue: 'Revenue',
    kpiEbitda: 'EBITDA',
    kpiFcf: 'Free Cash Flow (FCF)',
    kpiCapex: 'Capital Expenditure (CAPEX)',
    kpiOpex: 'Operating Expenses (OPEX)',
    kpiEfficiency: 'Operational Eff.',
    kpiRisks: 'Risks & Incidents',
    
    btnPlay: 'PLAY',
    btnPause: 'PAUSE',
    btnStep: 'STEP HOUR',
    btnReset: 'RESET',
    lblSimulation: 'SIMULATION',
    lblRole: 'ROLE',
    lblLanguage: 'LANG',
    
    resType: 'RESOURCE. PRODUCTION. DATA. CONTROL. EFFICIENCY.',
    prodChain: 'VALUE CHAIN COMPUTATIONAL GRAPH',
    activeAlerts: 'ACTIVE INDUSTRIAL ALERTS',
    incidentsTitle: 'CRITICAL INCIDENTS LOG'
  }
};
