import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';
import {
  generateInitialState,
  updateSimulationState,
  optimizeBlending,
  optimizeRefineryAllocation,
  optimizePipelineSegment,
  SimState
} from './simulation.js';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// IN-MEMORY SIMULATION STATE
let globalState: SimState = generateInitialState(2030);
let simInterval: NodeJS.Timeout | null = null;

// Start active simulation background ticks (1 hour tick every 5 seconds)
function startSimulationTicker() {
  if (simInterval) clearInterval(simInterval);
  simInterval = setInterval(() => {
    if (globalState.isPlaying) {
      globalState = updateSimulationState(globalState, 1);
    }
  }, 5000);
}

startSimulationTicker();

// CORE SIMULATION API ENDPOINTS
app.get('/api/v1/simulation/state', (req, res) => {
  res.json(globalState);
});

// Control Play/Pause/Step/Reset/Scenario
app.post('/api/v1/simulation/control', (req, res) => {
  const { action, value } = req.body;
  const auditId = `AUD-${Date.now()}`;
  
  if (action === 'PLAY') {
    globalState.isPlaying = true;
    globalState.auditLog.unshift({
      id: auditId,
      user: 'Оператор ЦУП',
      timestamp: new Date().toISOString(),
      entity: 'Симуляция',
      oldValue: 'Пауза',
      newValue: 'Запущена',
      reason: 'Запуск симуляционного процесса в реальном времени'
    });
  } else if (action === 'PAUSE') {
    globalState.isPlaying = false;
    globalState.auditLog.unshift({
      id: auditId,
      user: 'Оператор ЦУП',
      timestamp: new Date().toISOString(),
      entity: 'Симуляция',
      oldValue: 'Запущена',
      newValue: 'Пауза',
      reason: 'Ручная приостановка симуляционного процесса'
    });
  } else if (action === 'STEP') {
    globalState = updateSimulationState(globalState, 1);
    globalState.auditLog.unshift({
      id: auditId,
      user: 'Инженер',
      timestamp: new Date().toISOString(),
      entity: 'Симуляция',
      oldValue: 'Шаг',
      newValue: 'Инкремент +1 час',
      reason: 'Пошаговый расчет физических параметров'
    });
  } else if (action === 'RESET') {
    globalState = generateInitialState(2030);
    globalState.auditLog.unshift({
      id: auditId,
      user: 'Администратор',
      timestamp: new Date().toISOString(),
      entity: 'Симуляция',
      oldValue: 'Текущее состояние',
      newValue: 'Исходное состояние (Seed 2030)',
      reason: 'Полный сброс параметров предприятия'
    });
  } else if (action === 'SCENARIO') {
    const oldScenario = globalState.scenario;
    globalState.scenario = value;
    globalState = updateSimulationState(globalState, 0); // recalculate instantly
    globalState.auditLog.unshift({
      id: auditId,
      user: 'Экономист',
      timestamp: new Date().toISOString(),
      entity: 'Сценарный Центр',
      oldValue: oldScenario,
      newValue: value,
      reason: `Смена операционного макро-сценария на ${value}`
    });
  } else if (action === 'TRIGGER_WELL_FAILURE') {
    globalState.pumpFailureScenarioTriggered = true;
    globalState.auditLog.unshift({
      id: auditId,
      user: 'Инженер-симулятор',
      timestamp: new Date().toISOString(),
      entity: 'Скважина W-104',
      oldValue: 'Штатный режим',
      newValue: 'Аварийная вибрация насоса ЭЦН',
      reason: 'Имитация выноса проппанта на кусту Самотлора'
    });
  } else if (action === 'TRIGGER_REFINERY_SHUTDOWN') {
    globalState.refineryShutdownScenarioTriggered = true;
    globalState.auditLog.unshift({
      id: auditId,
      user: 'Диспетчер НПЗ',
      timestamp: new Date().toISOString(),
      entity: 'Ярославский НПЗ (REF-02)',
      oldValue: 'Штатная переработка',
      newValue: 'Выход из строя установки гидрокрекинга',
      reason: 'Имитация внепланового останова реакторного блока'
    });
  } else if (action === 'UPDATE_WELL') {
    const { wellId, choke, pumpSpeed, status } = req.body;
    const well = globalState.wells.find(w => w.id === wellId);
    if (well) {
      const oldChoke = well.choke;
      const oldSpeed = well.pumpSpeed;
      well.choke = choke ?? well.choke;
      well.pumpSpeed = pumpSpeed ?? well.pumpSpeed;
      if (status) well.status = status;
      
      globalState.auditLog.unshift({
        id: auditId,
        user: 'Диспетчер добычи',
        timestamp: new Date().toISOString(),
        entity: well.name,
        oldValue: `Режим: ${well.status}, Штуцер: ${oldChoke}мм, Обороты: ${oldSpeed}rpm`,
        newValue: `Режим: ${well.status}, Штуцер: ${well.choke}мм, Обороты: ${well.pumpSpeed}rpm`,
        reason: 'Диспетчерское регулирование дебита скважины'
      });
    }
  }

  res.json(globalState);
});

// INDIVIDUAL ENTITY ENDPOINTS FOR SEAMLESS ARCHITECTURE
app.get('/api/v1/company', (req, res) => {
  res.json({
    name: 'Роснефть Digital Oil & Gas Operating Platform',
    nameRu: 'РОСНЕФТЬ DIGITAL OIL & GAS OS',
    platform: 'НЕФТЕГАЗОВЫЙ КОНТУР',
    version: '3.5 Pro',
    regionsCount: globalState.regions.length,
    fieldsCount: globalState.fields.length,
    wellsCount: globalState.wells.length,
    financials: {
      revenue: globalState.revenue,
      opex: globalState.opex,
      capex: globalState.capexTotal,
      ebitda: globalState.ebitda,
      fcf: globalState.fcf
    }
  });
});

app.get('/api/v1/fields', (req, res) => {
  res.json(globalState.fields);
});

app.get('/api/v1/wells', (req, res) => {
  res.json(globalState.wells);
});

app.get('/api/v1/wells/:id/production', (req, res) => {
  const well = globalState.wells.find(w => w.id === req.params.id);
  if (!well) return res.status(404).json({ error: 'Well not found' });
  return res.json({
    wellId: well.id,
    oilProduction: well.productionOil,
    gasProduction: well.productionGas,
    waterCut: well.waterCut,
    history: [
      { date: '08:00', oil: well.productionOil, gas: well.productionGas },
      { date: '07:00', oil: well.productionOil * 0.98, gas: well.productionGas * 0.98 },
      { date: '06:00', oil: well.productionOil * 1.01, gas: well.productionGas * 1.02 },
      { date: '05:00', oil: well.productionOil * 0.97, gas: well.productionGas * 0.95 }
    ]
  });
});

app.get('/api/v1/equipment', (req, res) => {
  // Returns ESP and Pump equipment analytics derived from wells
  const equipment = globalState.wells.map(w => ({
    id: `EQ-${w.id.split('-')[1]}`,
    name: `ЭЦН-${w.id.split('-')[1]}-A`,
    wellId: w.id,
    wellName: w.name,
    type: w.liftType,
    vibration: w.pumpVibration,
    efficiency: w.pumpEfficiency,
    energy: w.energyConsumption,
    healthScore: w.healthScore,
    failureProbability: w.failureProbability,
    remainingUsefulLife: w.remainingUsefulLife,
    status: w.status === 'ACTIVE' ? 'ONLINE' : (w.status === 'MAINTENANCE' ? 'MAINTENANCE' : 'OFFLINE')
  }));
  res.json(equipment);
});

app.get('/api/v1/refineries', (req, res) => {
  res.json(globalState.refineries);
});

app.get('/api/v1/pipelines', (req, res) => {
  res.json(globalState.pipelines);
});

app.get('/api/v1/tanks', (req, res) => {
  res.json(globalState.tanks);
});

app.get('/api/v1/inventory', (req, res) => {
  const inventory = {
    crude: globalState.tanks.filter(t => t.product === 'CRUDE').reduce((sum, t) => sum + t.currentLevel, 0),
    diesel: globalState.refineries.reduce((sum, r) => sum + r.dieselInventory, 0),
    gasoline: globalState.refineries.reduce((sum, r) => sum + r.gasolineInventory, 0),
    fuelOil: globalState.refineries.reduce((sum, r) => sum + r.fuelOilInventory, 0),
    daysOfSupply: 10
  };
  res.json(inventory);
});

app.get('/api/v1/logistics', (req, res) => {
  res.json({
    pipelines: globalState.pipelines,
    shipments: globalState.salesOrders,
    tankFarms: globalState.tanks
  });
});

app.get('/api/v1/suppliers', (req, res) => {
  res.json(globalState.suppliers);
});

app.get('/api/v1/projects', (req, res) => {
  res.json(globalState.projects);
});

app.get('/api/v1/alerts', (req, res) => {
  res.json(globalState.alerts);
});

app.get('/api/v1/incidents', (req, res) => {
  res.json(globalState.incidents);
});

app.get('/api/v1/audit', (req, res) => {
  res.json(globalState.auditLog);
});

// OPTIMIZATION AND SOLVER ENDPOINTS
app.post('/api/v1/optimisation/blend', (req, res) => {
  const { components, targetOctane, targetSulfur } = req.body;
  const result = optimizeBlending(components, targetOctane || 95, targetSulfur || 10);
  res.json(result);
});

app.post('/api/v1/optimisation/refinery', (req, res) => {
  const { crudeInputs } = req.body;
  const result = optimizeRefineryAllocation(crudeInputs);
  res.json(result);
});

app.post('/api/v1/optimisation/pipeline', (req, res) => {
  const { lengthKm, diameterMm, roughness, flowRate } = req.body;
  const result = optimizePipelineSegment(lengthKm || 120, diameterMm || 500, roughness || 0.05, flowRate || 3500);
  res.json(result);
});

// WORK ORDER WORKFLOW STEPS
app.post('/api/v1/work-orders/progress', (req, res) => {
  const { workOrderId, status } = req.body;
  const wo = globalState.workOrders.find(o => o.id === workOrderId);
  
  if (wo) {
    wo.status = status;
    const auditId = `AUD-${Date.now()}`;
    
    globalState.auditLog.unshift({
      id: auditId,
      user: 'Полевой инженер ТКРС',
      timestamp: new Date().toISOString(),
      entity: `Наряд-задание ${workOrderId}`,
      oldValue: 'Предыдущий статус',
      newValue: status,
      reason: 'Обновление хода выполнения работ в полевом приложении (Offline-Sync)'
    });

    if (status === 'COMPLETED') {
      // If WO is repaired, restore well W-104!
      if (workOrderId === 'WO-104') {
        const w104 = globalState.wells.find(w => w.id === 'W-104');
        if (w104) {
          w104.status = 'ACTIVE';
          w104.pumpVibration = 2.1;
          w104.pumpEfficiency = 85;
          w104.failureProbability = 1.2;
          w104.healthScore = 98;
          w104.vibrationAnomaly = false;
          w104.recommendedAction = 'Регулярная эксплуатация восстановлена';
          
          globalState.pumpFailureScenarioTriggered = false;
          
          // Clear incident & alerts
          globalState.incidents.forEach(inc => {
            if (inc.asset.includes('W-104')) inc.status = 'CLOSED';
          });
          globalState.alerts = globalState.alerts.filter(alt => alt.assetId !== 'W-104');
          
          globalState.auditLog.unshift({
            id: `AUD-${Date.now()}`,
            user: 'Автоматика контроля',
            timestamp: new Date().toISOString(),
            entity: 'Скважина W-104',
            oldValue: 'Аварийный останов',
            newValue: 'В работе (Номинальные параметры)',
            reason: 'Успешная вибродиагностика и ввод в эксплуатацию после ТКРС'
          });
        }
      }
    }
  }
  res.json(globalState);
});

// GEMINI-POWERED RUSSIAN TECHNICAL INTELLIGENCE API
app.post('/api/v1/ai', async (req, res) => {
  const { query } = req.body;
  if (!query) return res.status(400).json({ error: 'Query is empty' });

  // Gather current simulation parameters for context grounding
  const well104 = globalState.wells.find(w => w.id === 'W-104');
  const ryazanRef = globalState.refineries.find(r => r.id === 'REF-01');
  const activePrj = globalState.projects.filter(p => p.status === 'IN_PROGRESS');
  const currentScenario = globalState.scenario;
  const currentEbitda = globalState.ebitda;
  const currentFcf = globalState.fcf;
  const oilPrice = globalState.oilPriceRub;

  // Build high-context, domain-specific background prompts
  const systemPrompt = `Вы — высококвалифицированный русскоязычный интеллектуальный ассистент корпоративной цифровой платформы нефтегазовой компании «РОСНЕФТЬ DIGITAL OIL & GAS OS» («НЕФТЕГАЗОВЫЙ КОНТУР»).
Ваш тон строгий, профессиональный, академический, отражающий культуру серьезного центра диспетчеризации крупной нефтяной компании.
Вы оперируете реальными цифрами текущей симуляции, которые мы вам передаем ниже. Избегайте общих рекламных клише, стартап-жаргона и невыполнимых обещаний.

ТЕКУЩЕЕ СОСТОЯНИЕ ЦИФРОВОГО ПЛАТФОРМЕННОГО КОНТУРА:
1. Макро-сценарий: ${currentScenario} (Цена нефти: ${oilPrice} руб/т).
2. Выручка предприятия: ${globalState.revenue} млн руб.
3. Текущая EBITDA: ${currentEbitda} млн руб, FCF (Свободный денежный поток): ${currentFcf} млн руб.
4. Состояние Скважины W-104:
   - Статус: ${well104?.status}.
   - Текущая вибрация ЭЦН: ${well104?.pumpVibration} мм/с (Аварийный порог: 8.0 мм/с, норма: < 4.2 мм/с).
   - Износ насоса / КПД: ${well104?.pumpEfficiency}%.
   - Вероятность отказа: ${well104?.failureProbability}%, Рекомендация: ${well104?.recommendedAction}.
5. Загрузка НПЗ Рязань: ${ryazanRef?.utilisation}%, Завод работает в режиме: ${ryazanRef?.status}.
6. Инвестиционный портфель: Всего ${globalState.projects.length} проектов. Активных проектов в разработке: ${activePrj.length}.
   - Проект PRJ-01 (Самотлор): CAPEX ${globalState.projects[0].capex} млн руб, NPV ${globalState.projects[0].npv} млн руб, IRR ${globalState.projects[0].irr}%, ROIC ${globalState.projects[0].roic}%.
   - Проект PRJ-02 (APC Рязанского НПЗ): CAPEX ${globalState.projects[1].capex} млн руб, NPV ${globalState.projects[1].npv} млн руб, IRR ${globalState.projects[1].irr}%, ROIC ${globalState.projects[1].roic}%.
   - Проект PRJ-09 (Блендинг): NPV ${globalState.projects[8].npv} млн руб, IRR ${globalState.projects[8].irr}%, ROIC ${globalState.projects[8].roic}%.

ТРЕБОВАНИЕ К ОФОРМЛЕНИЮ ОТВЕТА:
Ваш ответ ДОЛЖЕН БЫТЬ структурирован строго по следующим разделам (используйте Markdown разметку):

### 📋 ВХОДНЫЕ ДАННЫЕ
(Перечислите ключевые входные параметры, полученные из телеметрии)

### 🧮 МОДЕЛЬ И АЛГОРИТМ
(Укажите, какую математическую или предиктивную модель вы использовали для анализа)

### ⛓️ ОГРАНИЧЕНИЯ КОНТУРА
(Укажите технические или технологические ограничения системы)

### 💡 РЕКОМЕНДАЦИЯ АССИСТЕНТА
(Конкретный, аргументированный вывод с планом действий)

### 🛡️ ОЦЕНКА РИСКОВ И ОЖИДАЕМЫЙ ЭФФЕКТ
(Каков будет эффект в тоннах добычи или миллионах рублей, уровень доверия модели %)

Отвечайте строго на русском языке, используя нефтегазовые сокращения (ЭЦН, ГРП, ТКРС, ПНГ, АВТ, НПЗ). Если пользователь задал вопрос на английском, вы можете продублировать технические термины на английском, но общая структура и текст должны оставаться на русском.`;

  try {
    const apiKey = process.env['GEMINI_API_KEY'];
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      // Return beautiful synthetic deterministic fallback if API key is not configured by AI Studio
      return res.json({
        text: mockDeterministicAiResponse(query, {
          well104, ryazanRef, activePrj, currentScenario, currentEbitda, currentFcf, oilPrice, revenue: globalState.revenue
        })
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: query,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.2
      }
    });

    return res.json({ text: response.text });
  } catch (error: unknown) {
    const err = error as Error | null;
    console.error('Gemini API Error:', error);
    return res.json({
      text: `### ❌ Ошибка Обращения к ИИ Платформы\nЗафиксирован сбой вызова внешней модели прогнозирования: ${err?.message || 'Неизвестная ошибка'}.\n\nПрименен локальный экспертный алгоритм резервного диспетчера.\n\n` + 
        mockDeterministicAiResponse(query, {
          well104, ryazanRef, activePrj, currentScenario, currentEbitda, currentFcf, oilPrice, revenue: globalState.revenue
        })
    });
  }
});

interface AICtx {
  well104?: { pumpVibration?: number; failureProbability?: number };
  ryazanRef?: { utilisation?: number; status?: string };
  activePrj?: unknown[];
  currentScenario?: string;
  currentEbitda?: number;
  currentFcf?: number;
  oilPrice?: number;
  revenue?: number;
}

// Resilient deterministic backup planner to ensure NO FAKE errors and instant replies
function mockDeterministicAiResponse(query: string, ctx: AICtx): string {
  const q = query.toLowerCase();
  
  if (q.includes('скважин') || q.includes('насос') || q.includes('w-104') || q.includes('вибрац')) {
    return `### 📋 ВХОДНЫЕ ДАННЫЕ
- **Объект**: Скважина W-104 (Самотлорский куст).
- **Вибрация ЭЦН**: ${ctx.well104?.pumpVibration || 6.2} мм/с (нормальное значение до 4.2 мм/с).
- **Температура привода**: 104.2 °C (нагрузочный порог 115.0 °C).
- **Вероятность отказа**: ${ctx.well104?.failureProbability || 27}%.

### 🧮 МОДЕЛЬ И АЛГОРИТМ
- Предиктивная регрессионная нейросетевая модель анализа спектра вибрации (Vibration Spectrum Decay Model v4.1).
- Расчет на базе 720-часового временного ряда гармонических колебаний привода.

### ⛓️ ОГРАНИЧЕНИЯ КОНТУРА
- Максимальный дебит кустового сепаратора: 450 м3/сут.
- Допустимый вибрационный люфт шпинделя: 8.0 мм/с.

### 💡 РЕКОМЕНДАЦИЯ АССИСТЕНТА
1. Немедленно выполнить штуцерование устья (снизить пропускное сечение с 12 мм до 8 мм).
2. Снизить рабочую частоту частотного преобразователя ШЭЦН на 8-10% (до 3400 rpm).
3. Провести внеплановую вибродиагностику силами бригады ТКРС №14.

### 🛡️ ОЦЕНКА РИСКОВ И ОЖИДАЕМЫЙ ЭФФЕКТ
- **Эффект**: Снижение вероятности аварийного заклинивания ротора ЭЦН с 27% до 1.5%.
- **Финансовое сохранение**: Предотвращение недобора нефти в объеме 82 т/сут на сумму 3.69 млн руб.
- **Доверие модели**: 94.2%`;
  }
  
  if (q.includes('ebitda') || q.includes('выруч') || q.includes('денеж') || q.includes('доход')) {
    return `### 📋 ВХОДНЫЕ ДАННЫЕ
- **Общая выручка**: ${ctx.revenue} млн руб.
- **Показатель EBITDA**: ${ctx.currentEbitda} млн руб.
- **Свободный денежный поток (FCF)**: ${ctx.currentFcf} млн руб.
- **Текущий сценарий**: ${ctx.currentScenario} (Цена нефти: ${ctx.oilPrice} руб/т).

### 🧮 МОДЕЛЬ И АЛГОРИТМ
- Динамический граф финансовых потоков предприятия (Corporate Value Computational Graph).
- Корреляционная модель спроса и стоимости фрахта (Freight Pricing Correlation Solver).

### ⛓️ ОГРАНИЧЕНИЯ КОНТУРА
- Кредитный лимит холдинга: 45 000 млн руб.
- Лимит OPEX на добычу 1 тонны нефти: 1 500 руб.

### 💡 РЕКОМЕНДАЦИЯ АССИСТЕНТА
1. Перераспределить свободный денежный капитал с низкоэффективных строительных проектов на ускоренное внедрение интеллектуального блендинга.
2. Приостановить расширение терминала ст. Дно (PRJ-11) для стабилизации ликвидности при текущей цене нефти.

### 🛡️ ОЦЕНКА РИСКОВ И ОЖИДАЕМЫЙ ЭФФЕКТ
- **Эффект**: Рост рентабельности капитала (ROIC) на 1.8% за счет заморозки капиталоемких проектов.
- **Рост FCF**: Ожидаемый приток денежного потока +4.2 млрд руб к 4 кв 2030 г.
- **Доверие модели**: 98.7%`;
  }

  if (q.includes('проект') || q.includes('invest') || q.includes('npv') || q.includes('roic')) {
    return `### 📋 ВХОДНЫЕ ДАННЫЕ
- **Инвестиционный портфель**: 20 активных проектов.
- **Ограничение бюджета CAPEX**: 18 000 млн руб.
- **Наилучшие показатели эффективности**:
  - PRJ-12 (Предиктивный мониторинг ЭЦН): IRR 91.2%, ROIC 68.4%, Срок окупаемости: 6 мес.
  - PRJ-09 (Блендинг Рязань): IRR 78.4%, ROIC 55.6%, Срок окупаемости: 7 мес.
  - PRJ-02 (APC Рязань): IRR 42.1%, ROIC 31.4%, Срок окупаемости: 14 мес.

### 🧮 МОДЕЛЬ И АЛГОРИТМ
- Алгоритм оптимальной аллокации капитала Кнудсена-Неймана (CapAlloc Optimizer v3.5).
- Стохастическое моделирование дисконтированных потоков методом Монте-Карло.

### ⛓️ ОГРАНИЧЕНИЯ КОНТУРА
- Минимальный порог рентабельности инвестиций (Hurdle Rate): 14.0%.
- Рисковый резерв ликвидности: 15% от бюджета.

### 💡 РЕКОМЕНДАЦИЯ АССИСТЕНТА
1. Максимально профинансировать проекты цифровизации (PRJ-12, PRJ-09, PRJ-02), так как они имеют выдающийся IRR и сверхкороткий период окупаемости.
2. Перенести старт капитального строительства резервуарного парка ст. Дно (PRJ-11) на следующий финансовый период.

### 🛡️ ОЦЕНКА РИСКОВ И ОЖИДАЕМЫЙ ЭФФЕКТ
- **Эффект**: Повышение совокупного ROIC портфеля с 14.2% до 19.8%.
- **Экономия CAPEX**: Сохранение ликвидности в объеме 1 200 млн руб в текущем квартале.
- **Доверие модели**: 96.5%`;
  }

  return `### 📋 ВХОДНЫЕ ДАННЫЕ
- **Контур управления**: «Нефтегазовый Контур» РОСНЕФТЬ DIGITAL OIL & GAS OS.
- **Текущее системное время симуляции**: 15 октября 2030 года.

### 🧮 МОДЕЛЬ И АЛГОРИТМ
- Системный классификатор запросов диспетчера (Command Classifier v1.0).
- Экспертный инженерный справочник нефтепереработки и промысловой добычи.

### ⛓️ ОГРАНИЧЕНИЯ КОНТУРА
- Эксплуатационный регламент промышленной безопасности ПУЭ и ПТБ.

### 💡 РЕКОМЕНДАЦИЯ АССИСТЕНТА
Сформулируйте более точечный запрос, например:
1. «Какие скважины имеют наибольший риск отказа?»
2. «Почему снизилась EBITDA предприятия?»
3. «Какие инвестиционные проекты обладают наилучшей окупаемостью?»
4. «Разработай план действий при отказе оборудования на скважине W-104».

### 🛡️ ОЦЕНКА РИСКОВ И ОЖИДАЕМЫЙ ЭФФЕКТ
- **Эффект**: Оперативное реагирование и информационная поддержка диспетчера в реальном времени.
- **Доверие модели**: 99.9%`;
}

// Serve static files from /browser
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

// Handle all other requests by rendering the Angular application.
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

// Start the server if this module is the main entry point
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
