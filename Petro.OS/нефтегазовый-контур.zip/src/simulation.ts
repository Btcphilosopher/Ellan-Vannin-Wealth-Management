// РОСНЕФТЬ DIGITAL OIL & GAS OS — SYNTHETIC SIMULATION ENGINE
// Seed-based deterministic industrial simulator (SEED=2030)

export interface Well {
  id: string;
  name: string;
  fieldId: string;
  depth: number;
  trajectory: 'VERTICAL' | 'DIRECTIONAL' | 'HORIZONTAL';
  status: 'ACTIVE' | 'INACTIVE' | 'MAINTENANCE';
  productionOil: number; // t/day
  productionGas: number; // th. m3/day
  pressureReservoir: number; // atm
  pressureBottomhole: number; // atm
  temperature: number; // °C
  waterCut: number; // %
  gasOilRatio: number; // m3/t
  choke: number; // mm
  liftType: 'ESP' | 'ROD_PUMP' | 'GAS_LIFT' | 'FLOWING';
  pumpSpeed: number; // rpm
  pumpVibration: number; // mm/s
  pumpEfficiency: number; // %
  energyConsumption: number; // kWh/day
  failureProbability: number; // %
  healthScore: number; // %
  remainingUsefulLife: number; // days
  lastWorkover: string;
  nextMaintenance: string;
  recommendedAction: string;
  vibrationAnomaly?: boolean;
}

export interface Field {
  id: string;
  name: string;
  regionId: string;
  reserves: number; // million tons
  dailyProductionTarget: number; // t/day
  dailyProductionActual: number; // t/day
  emissionsCO2: number; // t/day
  flaringRate: number; // %
  activeWells: number;
  inactiveWells: number;
  healthScore: number;
}

export interface Region {
  id: string;
  name: string;
  nameEn: string;
  dailyProduction: number;
  fieldsCount: number;
}

export interface ProcessUnit {
  name: string;
  nameRu: string;
  status: 'ONLINE' | 'OFFLINE' | 'MAINTENANCE';
  throughput: number; // t/day
  capacity: number; // t/day
  temperature: number; // °C
  pressure: number; // MPa
  energyConsumption: number; // MW
  efficiency: number; // %
}

export interface Refinery {
  id: string;
  name: string;
  location: string;
  capacity: number; // th. t/year
  feedrate: number; // t/day
  utilisation: number; // %
  yieldLight: number; // % (выход светлых нефтепродуктов)
  units: ProcessUnit[];
  dieselInventory: number; // t
  gasolineInventory: number; // t
  fuelOilInventory: number; // t
  status: 'OPERATIONAL' | 'REDUCED' | 'SHUTDOWN';
}

export interface Pipeline {
  id: string;
  name: string;
  source: string;
  target: string;
  capacity: number; // m3/h
  flowRate: number; // m3/h
  pressureInlet: number; // MPa
  pressureOutlet: number; // MPa
  temperature: number; // °C
  loss: number; // %
  healthScore: number;
  status: 'NORMAL' | 'HIGH_PRESSURE' | 'LEAK' | 'MAINTENANCE';
}

export interface Tank {
  id: string;
  name: string;
  capacity: number; // m3
  currentLevel: number; // m3
  product: 'CRUDE' | 'DIESEL' | 'GASOLINE' | 'FUEL_OIL';
  temperature: number; // °C
  pressure: number; // kPa
  valueRub: number; // Million RUB
  daysOfSupply: number;
}

export interface Supplier {
  id: string;
  name: string;
  category: string;
  country: string;
  contractValue: number; // Million RUB
  leadTime: number; // days
  qualityScore: number; // %
  reliability: number; // %
  risk: 'LOW' | 'MEDIUM' | 'HIGH';
  deliveryPerformance: number; // %
}

export interface SalesOrder {
  id: string;
  customerName: string;
  product: string;
  volume: number; // tons
  pricePerTon: number; // RUB
  margin: number; // %
  status: 'PENDING' | 'IN_TRANSIT' | 'DELIVERED' | 'DELAYED';
}

export interface GasStation {
  id: string;
  name: string;
  location: string;
  dieselLevel: number; // %
  gas95Level: number; // %
  gas92Level: number; // %
  dieselPrice: number; // RUB/l
  gas95Price: number; // RUB/l
  gas92Price: number; // RUB/l
  trafficRate: 'LOW' | 'MEDIUM' | 'HIGH';
  queueSize: number;
  terminalStatus: 'ONLINE' | 'OFFLINE';
  healthScore: number;
}

export interface Project {
  id: string;
  name: string;
  category: string;
  capex: number; // Million RUB
  npv: number; // Million RUB
  irr: number; // %
  roic: number; // %
  payback: number; // years
  productionImpact: number; // t/day increase
  risk: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'APPROVED' | 'IN_PROGRESS' | 'COMPLETED' | 'ON_HOLD';
  progress: number; // %
}

export interface Alert {
  id: string;
  severity: 'INFO' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  title: string;
  message: string;
  timestamp: string;
  assetId: string;
  assetType: string;
  acknowledged: boolean;
}

export interface Incident {
  id: string;
  severity: 'MEDIUM' | 'HIGH' | 'CRITICAL';
  asset: string;
  location: string;
  startTime: string;
  detectionTime: string;
  impact: string;
  rootCause: string;
  actions: string[];
  owner: string;
  status: 'DETECTED' | 'ACKNOWLEDGED' | 'INVESTIGATING' | 'MITIGATING' | 'RESOLVED' | 'CLOSED';
}

export interface WorkOrder {
  id: string;
  asset: string;
  task: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  technician: string;
  materials: string[];
  expectedDuration: number; // hours
  actualDuration?: number;
  safetyRequirements: string[];
  status: 'PENDING' | 'ACCEPTED' | 'ON_SITE' | 'DIAGNOSIS' | 'REPAIR' | 'TEST' | 'COMPLETED';
}

export interface AuditEvent {
  id: string;
  user: string;
  timestamp: string;
  entity: string;
  oldValue: string;
  newValue: string;
  reason: string;
}

export interface SimState {
  time: Date;
  isPlaying: boolean;
  speed: number; // 1 = 1 hour/step
  scenario: 'BASE' | 'HIGH_OIL_PRICE' | 'LOW_OIL_PRICE' | 'HIGH_DEMAND' | 'SUPPLY_DISRUPT' | 'REFINERY_OUTAGE' | 'PIPELINE_OUTAGE';
  
  // Financial Metrics (Decimal values as standard JS numbers for simplicity, but strictly rounded)
  oilPriceRub: number; // RUB per ton
  gasPriceRub: number; // RUB per thousand m3
  revenue: number; // Million RUB
  opex: number; // Million RUB
  capexTotal: number; // Million RUB
  ebitda: number; // Million RUB
  fcf: number; // Million RUB
  
  regions: Region[];
  fields: Field[];
  wells: Well[];
  refineries: Refinery[];
  pipelines: Pipeline[];
  tanks: Tank[];
  suppliers: Supplier[];
  salesOrders: SalesOrder[];
  gasStations: GasStation[];
  projects: Project[];
  alerts: Alert[];
  incidents: Incident[];
  workOrders: WorkOrder[];
  auditLog: AuditEvent[];
  
  // Scenarios/Variables
  pumpFailureScenarioTriggered: boolean;
  refineryShutdownScenarioTriggered: boolean;
}

// DETERMINISTIC SYNTHETIC SEED GENERATOR
export function generateInitialState(seedValue = 2030): SimState {
  // Simple seed LCG
  let seed = seedValue;
  function random(): number {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  }
  
  function randomRange(min: number, max: number): number {
    return min + random() * (max - min);
  }

  // Generate regions
  const regionNames = [
    { id: 'R-SIB-W', ru: 'Западная Сибирь', en: 'West Siberia' },
    { id: 'R-SIB-E', ru: 'Восточная Сибирь', en: 'East Siberia' },
    { id: 'R-VOLGA', ru: 'Поволжье', en: 'Volga Region' },
    { id: 'R-URAL', ru: 'Урал', en: 'Ural Region' },
    { id: 'R-ARCTIC', ru: 'Арктический Шельф', en: 'Arctic Shelf' },
    { id: 'R-FAR-E', ru: 'Дальний Восток', en: 'Far East' },
    { id: 'R-BALTIC', ru: 'Балтика', en: 'Baltic Region' },
    { id: 'R-CASP', ru: 'Каспий', en: 'Caspian' },
    { id: 'R-BLACK-S', ru: 'Черное море', en: 'Black Sea' },
    { id: 'R-TIMAN', ru: 'Тимано-Печора', en: 'Timan-Pechora' }
  ];
  
  const regions: Region[] = regionNames.map(r => ({
    id: r.id,
    name: r.ru,
    nameEn: r.en,
    dailyProduction: 0,
    fieldsCount: 0
  }));

  // Generate fields (100 synthetic fields)
  const fieldRussianNames = [
    'Самотлорское', 'Приобское', 'Ванкорское', 'Романовское', 'Юрубчено-Тохомское',
    'Сузунское', 'Тагульское', 'Лопатинское', 'Федоровское', 'Мамонтовское',
    'Быстринское', 'Лянторское', 'Усть-Балыкское', 'Правдинское', 'Ен-Яхинское',
    'Талаканское', 'Верхнечонское', 'Ярактинское', 'Среднеботуобинское', 'Чаяндинское',
    'Ковыктинское', 'Бованенковское', 'Харасавэйское', 'Крузенштернское', 'Тамбейское',
    'Уренгойское', 'Ямбургское', 'Медвежье', 'Заполярное', 'Южно-Русское',
    'Штокмановское', 'Приразломное', 'Киринское', 'Одопту', 'Аркутун-Даги',
    'Чайво', 'Русское', 'Тазовское', 'Новопортовское', 'Мессояхское'
  ];

  const fields: Field[] = [];
  for (let i = 1; i <= 100; i++) {
    const reg = regions[i % regions.length];
    const baseName = fieldRussianNames[i % fieldRussianNames.length] + ' Участок-' + (Math.floor(i / fieldRussianNames.length) + 1);
    const reserves = Math.round(randomRange(5, 500) * 10) / 10;
    const dailyProductionTarget = Math.round(reserves * randomRange(50, 150));
    
    fields.push({
      id: `F-${100 + i}`,
      name: baseName,
      regionId: reg.id,
      reserves,
      dailyProductionTarget,
      dailyProductionActual: dailyProductionTarget * randomRange(0.95, 1.02),
      emissionsCO2: Math.round(dailyProductionTarget * 0.08 * 10) / 10,
      flaringRate: Math.round(randomRange(0.2, 4.5) * 100) / 100,
      activeWells: Math.round(randomRange(10, 80)),
      inactiveWells: Math.round(randomRange(1, 10)),
      healthScore: Math.round(randomRange(88, 99))
    });
    
    reg.fieldsCount++;
  }

  // Wells: Create 100 highly detailed wells for Scenario Field: F-101 (Самотлорский Участок-3)
  // And allow virtualised counts for other fields
  const wells: Well[] = [];
  for (let i = 1; i <= 100; i++) {
    const depth = Math.round(randomRange(1800, 4200));
    const status = i === 4 ? 'ACTIVE' : (i % 25 === 0 ? 'INACTIVE' : 'ACTIVE'); // Make W-104 active but ready for failure
    const waterCut = i === 4 ? 32 : Math.round(randomRange(1, 85));
    const gasOilRatio = Math.round(randomRange(40, 200));
    
    // ESP pump parameters
    const pumpSpeed = i === 4 ? 3850 : Math.round(randomRange(2800, 3600)); // W-104 is speeded up!
    const pumpVibration = i === 4 ? 6.2 : Math.round(randomRange(1.1, 4.2)); // W-104 starts higher
    const pumpEfficiency = i === 4 ? 65 : Math.round(randomRange(72, 92));
    
    const productionOil = status === 'ACTIVE' ? Math.round(randomRange(20, 220) * (1 - waterCut/100)) : 0;
    const productionGas = status === 'ACTIVE' ? Math.round(productionOil * gasOilRatio / 1000 * 10) / 10 : 0;
    
    const pressureReservoir = Math.round(randomRange(180, 290));
    const pressureBottomhole = Math.round(pressureReservoir * randomRange(0.6, 0.85));
    
    const failureProbability = i === 4 ? 27 : Math.round(randomRange(0.1, 8.5) * 10) / 10;
    const healthScore = i === 4 ? 73 : Math.round(randomRange(85, 99));
    
    wells.push({
      id: `W-${100 + i}`,
      name: `Скважина W-${100 + i}`,
      fieldId: 'F-101', // Самотлорский Участок-3
      depth,
      trajectory: i % 3 === 0 ? 'HORIZONTAL' : (i % 3 === 1 ? 'DIRECTIONAL' : 'VERTICAL'),
      status,
      productionOil,
      productionGas,
      pressureReservoir,
      pressureBottomhole,
      temperature: Math.round(randomRange(65, 115) * 10) / 10,
      waterCut,
      gasOilRatio,
      choke: i % 2 === 0 ? 8 : 12,
      liftType: i % 4 === 0 ? 'ESP' : (i % 4 === 1 ? 'ROD_PUMP' : (i % 4 === 2 ? 'GAS_LIFT' : 'FLOWING')),
      pumpSpeed,
      pumpVibration,
      pumpEfficiency,
      energyConsumption: Math.round(randomRange(120, 350)),
      failureProbability,
      healthScore,
      remainingUsefulLife: Math.round(randomRange(30, 450)),
      lastWorkover: new Date(Date.now() - randomRange(10, 180) * 24 * 3600 * 1000).toISOString().split('T')[0],
      nextMaintenance: new Date(Date.now() + randomRange(10, 90) * 24 * 3600 * 1000).toISOString().split('T')[0],
      recommendedAction: i === 4 ? 'Требуется снижение дебита для предотвращения перегрузки насоса ЭЦН' : 'Продолжить штатную эксплуатацию',
      vibrationAnomaly: i === 4 // W-104 has our special starting vibration alert
    });
  }

  // Refineries (Crude Distillation, reforming etc.)
  const refineryConfigs = [
    { id: 'REF-01', name: 'Рязанский НПЗ', loc: 'Рязань', cap: 17100 },
    { id: 'REF-02', name: 'Ярославский НПЗ', loc: 'Ярославль', cap: 15000 },
    { id: 'REF-03', name: 'Ангарская НХК', loc: 'Ангарск', cap: 10200 }
  ];
  
  const refineries: Refinery[] = refineryConfigs.map(rc => {
    const targetFeed = Math.round(rc.cap * 1000 / 365);
    const units: ProcessUnit[] = [
      { name: 'CrudeUnit', nameRu: 'АВТ-Установка первичной переработки', status: 'ONLINE', throughput: targetFeed, capacity: targetFeed * 1.15, temperature: 360, pressure: 0.3, energyConsumption: 45, efficiency: 94 },
      { name: 'Hydrocracking', nameRu: 'Установка гидрокрекинга', status: 'ONLINE', throughput: targetFeed * 0.3, capacity: targetFeed * 0.35, temperature: 410, pressure: 15.2, energyConsumption: 35, efficiency: 91 },
      { name: 'Reforming', nameRu: 'Каталитический риформинг', status: 'ONLINE', throughput: targetFeed * 0.2, capacity: targetFeed * 0.22, temperature: 510, pressure: 2.8, energyConsumption: 22, efficiency: 89 },
      { name: 'Isomerisation', nameRu: 'Установка изомеризации', status: 'ONLINE', throughput: targetFeed * 0.15, capacity: targetFeed * 0.18, temperature: 180, pressure: 3.2, energyConsumption: 12, efficiency: 95 },
      { name: 'SulphurRecovery', nameRu: 'Производство элементарной серы', status: 'ONLINE', throughput: targetFeed * 0.05, capacity: targetFeed * 0.08, temperature: 250, pressure: 0.15, energyConsumption: 5, efficiency: 98 }
    ];
    
    return {
      id: rc.id,
      name: rc.name,
      location: rc.loc,
      capacity: rc.cap,
      feedrate: targetFeed,
      utilisation: 88,
      yieldLight: 72.5,
      units,
      dieselInventory: Math.round(randomRange(25000, 50000)),
      gasolineInventory: Math.round(randomRange(15000, 35000)),
      fuelOilInventory: Math.round(randomRange(8000, 20000)),
      status: 'OPERATIONAL'
    };
  });

  // Pipelines
  const pipelines: Pipeline[] = [
    { id: 'PL-01', name: 'Магистральный нефтепровод Сибирь-НПЗ-01', source: 'R-SIB-W', target: 'REF-01', capacity: 5000, flowRate: 4120, pressureInlet: 5.6, pressureOutlet: 4.2, temperature: 34, loss: 0.02, healthScore: 96, status: 'NORMAL' },
    { id: 'PL-02', name: 'Транспортный нефтепровод Урал-НПЗ-02', source: 'R-URAL', target: 'REF-02', capacity: 3500, flowRate: 2890, pressureInlet: 4.8, pressureOutlet: 3.5, temperature: 28, loss: 0.03, healthScore: 92, status: 'NORMAL' },
    { id: 'PL-03', name: 'Продуктопровод Дистиллят-Запад', source: 'REF-01', target: 'TERMINAL-01', capacity: 2500, flowRate: 2100, pressureInlet: 3.5, pressureOutlet: 2.8, temperature: 20, loss: 0.01, healthScore: 98, status: 'NORMAL' }
  ];

  // Tanks
  const tanks: Tank[] = [
    { id: 'TNK-01', name: 'Резервуар Сырой Нефти R-1', capacity: 50000, currentLevel: 38500, product: 'CRUDE', temperature: 18, pressure: 101.3, valueRub: 1250, daysOfSupply: 8 },
    { id: 'TNK-02', name: 'Резервуар Сырой Нефти R-2', capacity: 50000, currentLevel: 42100, product: 'CRUDE', temperature: 17, pressure: 101.3, valueRub: 1360, daysOfSupply: 9 },
    { id: 'TNK-03', name: 'Товарный Резервуар ДТ D-1', capacity: 25000, currentLevel: 18200, product: 'DIESEL', temperature: 15, pressure: 101.2, valueRub: 980, daysOfSupply: 12 },
    { id: 'TNK-04', name: 'Товарный Резервуар АИ-95 G-1', capacity: 25000, currentLevel: 14600, product: 'GASOLINE', temperature: 14, pressure: 101.2, valueRub: 820, daysOfSupply: 10 }
  ];

  // Suppliers
  const suppliers: Supplier[] = [
    { id: 'SUP-01', name: 'ОАО ТяжМашАрм', category: 'Оборудование / Запорная арматура', country: 'РФ', contractValue: 450, leadTime: 14, qualityScore: 95, reliability: 97, risk: 'LOW', deliveryPerformance: 98 },
    { id: 'SUP-02', name: 'НПО НефтеМаш', category: 'Насосное оборудование ЭЦН', country: 'РФ', contractValue: 820, leadTime: 21, qualityScore: 92, reliability: 88, risk: 'MEDIUM', deliveryPerformance: 85 },
    { id: 'SUP-03', name: 'Пермский Кабельный Завод', category: 'Силовой кабель КРБК', country: 'РФ', contractValue: 310, leadTime: 10, qualityScore: 96, reliability: 98, risk: 'LOW', deliveryPerformance: 99 },
    { id: 'SUP-04', name: 'СибАвтоТранс', category: 'Логистические услуги / Автоцистерны', country: 'РФ', contractValue: 550, leadTime: 3, qualityScore: 90, reliability: 91, risk: 'LOW', deliveryPerformance: 92 },
    { id: 'SUP-05', name: 'УралСтальКонструкция', category: 'Трубная продукция', country: 'РФ', contractValue: 1200, leadTime: 45, qualityScore: 88, reliability: 85, risk: 'MEDIUM', deliveryPerformance: 82 }
  ];

  // Sales Orders
  const salesOrders: SalesOrder[] = [
    { id: 'SO-01', customerName: 'Северсталь Металлургия', product: 'Дизельное Топливо Сорт Е', volume: 15000, pricePerTon: 62000, margin: 12.4, status: 'DELIVERED' },
    { id: 'SO-02', customerName: 'Мосгортранс Автобусный Парк', product: 'Дизельное Топливо Евро-5', volume: 8000, pricePerTon: 63500, margin: 13.1, status: 'IN_TRANSIT' },
    { id: 'SO-03', customerName: 'Аэрофлот Топливо-Заправка', product: 'Керосин ТС-1', volume: 12000, pricePerTon: 74000, margin: 15.8, status: 'IN_TRANSIT' },
    { id: 'SO-04', customerName: 'РЖД Логистика', product: 'Мазут Топочный М-100', volume: 20000, pricePerTon: 28000, margin: 8.5, status: 'PENDING' }
  ];

  // Gas stations (AZS Network)
  const gasStations: GasStation[] = [];
  for (let i = 1; i <= 25; i++) {
    gasStations.push({
      id: `AZS-${100 + i}`,
      name: `АЗС Роснефть №${100 + i}`,
      location: i <= 10 ? 'Москва и МО' : (i <= 18 ? 'Санкт-Петербург' : 'Трасса М-4 Дон'),
      dieselLevel: Math.round(randomRange(30, 95)),
      gas95Level: Math.round(randomRange(25, 98)),
      gas92Level: Math.round(randomRange(40, 95)),
      dieselPrice: 61.20 + (i % 5) * 0.35,
      gas95Price: 55.40 + (i % 3) * 0.45,
      gas92Price: 49.80 + (i % 4) * 0.25,
      trafficRate: i % 3 === 0 ? 'HIGH' : (i % 3 === 1 ? 'MEDIUM' : 'LOW'),
      queueSize: i % 3 === 0 ? Math.round(randomRange(4, 9)) : Math.round(randomRange(0, 3)),
      terminalStatus: 'ONLINE',
      healthScore: Math.round(randomRange(92, 99))
    });
  }

  // Projects (20 strategic investment projects)
  const projects: Project[] = [
    { id: 'PRJ-01', name: 'Разработка Самотлорского Участка-3 (Зарезка БС)', category: 'Добыча / Бурение', capex: 1200, npv: 3450, irr: 24.5, roic: 18.2, payback: 2.8, productionImpact: 850, risk: 'MEDIUM', status: 'IN_PROGRESS', progress: 68 },
    { id: 'PRJ-02', name: 'Цифровой Завод — Внедрение APC Рязанского НПЗ', category: 'Переработка / Цифровизация', capex: 450, npv: 1850, irr: 42.1, roic: 31.4, payback: 1.2, productionImpact: 150, risk: 'LOW', status: 'IN_PROGRESS', progress: 45 },
    { id: 'PRJ-03', name: 'Строительство Комплекса Каталитического Крекинга Ангарск', category: 'Переработка / Модернизация', capex: 8500, npv: 11200, irr: 16.8, roic: 12.4, payback: 5.2, productionImpact: 1200, risk: 'HIGH', status: 'APPROVED', progress: 10 },
    { id: 'PRJ-04', name: 'Реконструкция Сегмента Магистрального Нефтепровода МН-1', category: 'Логистика / Транспорт', capex: 2400, npv: 1950, irr: 14.2, roic: 11.5, payback: 4.8, productionImpact: 350, risk: 'MEDIUM', status: 'IN_PROGRESS', progress: 85 },
    { id: 'PRJ-05', name: 'Цифровое Месторождение — Мобильный обходчик', category: 'Добыча / Цифровизация', capex: 150, npv: 950, irr: 65.4, roic: 48.2, payback: 0.8, productionImpact: 80, risk: 'LOW', status: 'COMPLETED', progress: 100 },
    { id: 'PRJ-06', name: 'Бурение куста скважин №402 Приобского месторождения', category: 'Добыча / Бурение', capex: 1800, npv: 4200, irr: 22.8, roic: 17.5, payback: 3.1, productionImpact: 980, risk: 'MEDIUM', status: 'IN_PROGRESS', progress: 32 },
    { id: 'PRJ-07', name: 'Экологическая очистка шламовых амбаров Самотлор', category: 'Экология / Охрана среды', capex: 350, npv: -50, irr: 3.5, roic: 2.1, payback: 9.9, productionImpact: 0, risk: 'LOW', status: 'IN_PROGRESS', progress: 50 },
    { id: 'PRJ-08', name: 'Строительство СЭС Самотлор-Энерго', category: 'Энергетика / Новая энергия', capex: 520, npv: 380, irr: 12.1, roic: 8.8, payback: 6.5, productionImpact: 0, risk: 'MEDIUM', status: 'APPROVED', progress: 5 },
    { id: 'PRJ-09', name: 'Оптимизация Блендинга Бензина АИ-98 Рязань', category: 'Переработка / Оптимизация', capex: 180, npv: 1240, irr: 78.4, roic: 55.6, payback: 0.6, productionImpact: 110, risk: 'LOW', status: 'COMPLETED', progress: 100 },
    { id: 'PRJ-10', name: 'Разведка площадей Ванкорского кластера', category: 'Разведка', capex: 3200, npv: 5400, irr: 18.5, roic: 13.1, payback: 4.5, productionImpact: 1400, risk: 'HIGH', status: 'IN_PROGRESS', progress: 24 },
    { id: 'PRJ-11', name: 'Строительство резервуарного парка ст. Дно', category: 'Логистика / Хранение', capex: 850, npv: 920, reliability: 95, payback: 4.2, productionImpact: 0, risk: 'LOW', status: 'IN_PROGRESS', progress: 75 } as unknown as Project,
    { id: 'PRJ-12', name: 'Система предиктивного мониторинга ЭЦН', category: 'Добыча / Цифровизация', capex: 120, npv: 1100, irr: 91.2, roic: 68.4, payback: 0.5, productionImpact: 50, risk: 'LOW', status: 'COMPLETED', progress: 100 },
    { id: 'PRJ-13', name: 'Реконструкция Вахтового Поселка Ванкор', category: 'Социальная инфраструктура', capex: 400, npv: 0, irr: 0, roic: 0, payback: 15, productionImpact: 0, risk: 'LOW', status: 'IN_PROGRESS', progress: 40 },
    { id: 'PRJ-14', name: 'Утилизация ПНГ Самотлорского месторождения', category: 'Экология / Газовая программа', capex: 1500, npv: 1800, irr: 15.6, roic: 11.2, payback: 5.5, productionImpact: 200, risk: 'MEDIUM', status: 'IN_PROGRESS', progress: 62 },
    { id: 'PRJ-15', name: 'Закупка вагонов-цистерн для мазута', category: 'Логистика / ЖД', capex: 950, npv: 1120, irr: 17.5, roic: 14.1, payback: 3.8, productionImpact: 0, risk: 'LOW', status: 'IN_PROGRESS', progress: 90 },
    { id: 'PRJ-16', name: 'Модернизация системы коммерческого учета АЗС', category: 'Сбыт / Цифровизация', capex: 280, npv: 890, irr: 45.2, roic: 33.1, payback: 1.8, productionImpact: 0, risk: 'LOW', status: 'IN_PROGRESS', progress: 15 },
    { id: 'PRJ-17', name: 'Внедрение роботов-диагностов трубопроводов', category: 'Логистика / Безопасность', capex: 340, npv: 1150, irr: 52.4, roic: 39.2, payback: 1.5, productionImpact: 0, risk: 'MEDIUM', status: 'IN_PROGRESS', progress: 30 },
    { id: 'PRJ-18', name: 'Геофизическое моделирование пласта ЮС-1', category: 'Геология / Исследования', capex: 160, npv: 980, irr: 82.5, roic: 59.8, payback: 0.7, productionImpact: 120, risk: 'LOW', status: 'COMPLETED', progress: 100 },
    { id: 'PRJ-19', name: 'Строительство битумного терминала Самара', category: 'Сбыт / Логистика', capex: 650, npv: 820, irr: 19.4, roic: 14.5, payback: 3.5, productionImpact: 0, risk: 'MEDIUM', status: 'APPROVED', progress: 0 },
    { id: 'PRJ-20', name: 'Интеграция ИИ в диспетчеризацию жд-поставок', category: 'Логистика / Цифровизация', capex: 190, npv: 1450, irr: 95.8, roic: 72.1, payback: 0.4, productionImpact: 0, risk: 'LOW', status: 'APPROVED', progress: 0 }
  ];
  
  // Fill missing details for index 10 PRJ-11 to bypass casting
  projects[10].irr = 15.5;
  projects[10].roic = 11.8;

  // Alerts
  const alerts: Alert[] = [
    { id: 'ALT-01', severity: 'HIGH', title: 'Рост вибрации ЭЦН W-104', message: 'На скважине W-104 Самотлорского участка зафиксирован рост вибрации ЭЦН до 6.2 мм/с. Вероятность отказа повышена до 27%.', timestamp: new Date(Date.now() - 3600000).toISOString(), assetId: 'W-104', assetType: 'WELL', acknowledged: false },
    { id: 'ALT-02', severity: 'MEDIUM', title: 'Падение давления в МН-1', message: 'Давление на выходе сегмента PL-01 снизилось на 0.4 МПа. Проводится автоматическая диагностика на утечки.', timestamp: new Date(Date.now() - 7200000).toISOString(), assetId: 'PL-01', assetType: 'PIPELINE', acknowledged: false }
  ];

  // Incidents
  const incidents: Incident[] = [
    {
      id: 'INC-01',
      severity: 'HIGH',
      asset: 'ЭЦН-104-A',
      location: 'Скважина W-104, Самотлорское месторождение',
      startTime: new Date(Date.now() - 3600000).toISOString(),
      detectionTime: new Date(Date.now() - 3550000).toISOString(),
      impact: 'Потенциальное падение добычи на 32 т/сут, риск необратимого разрушения глубинного оборудования.',
      rootCause: 'Гидравлическое перенапряжение и вынос мелкозернистого проппанта после ГРП.',
      actions: ['Рекомендовано автоматическое снижение дебита скважины на 4-10%', 'Формирование наряда на выездную диагностику бригадой ТКРС.'],
      owner: 'Старший технолог Самотлорского промысла',
      status: 'DETECTED'
    }
  ];

  // Work Orders
  const workOrders: WorkOrder[] = [
    {
      id: 'WO-104',
      asset: 'Скважина W-104, ЭЦН-104-A',
      task: 'Выездная диагностика, регулировка частоты ESP и вибродиагностика привода',
      priority: 'HIGH',
      technician: 'Бригада ТКРС №14 (Мастер Сидоров И.А.)',
      materials: ['Комплект датчиков вибрации', 'Станция управления ШЭЦН', 'Кабельная муфта'],
      expectedDuration: 6,
      safetyRequirements: ['Наряд-допуск на газоопасные работы', 'Проверка заземления устья скважины', 'Наличие ИСЗ и газоанализатора'],
      status: 'PENDING'
    }
  ];

  // Calculate Region Totals
  regions.forEach(reg => {
    const regFields = fields.filter(f => f.regionId === reg.id);
    reg.dailyProduction = Math.round(regFields.reduce((sum, f) => sum + f.dailyProductionActual, 0));
  });

  return {
    time: new Date('2030-10-15T08:00:00Z'),
    isPlaying: true,
    speed: 1,
    scenario: 'BASE',
    oilPriceRub: 45000, // Synthetic base price per ton in 2030 (approx 550 USD/t)
    gasPriceRub: 7500, // Synthetic base price per th. m3 in 2030
    revenue: 125000,
    opex: 82000,
    capexTotal: 18000,
    ebitda: 43000,
    fcf: 25000,
    regions,
    fields,
    wells,
    refineries,
    pipelines,
    tanks,
    suppliers,
    salesOrders,
    gasStations,
    projects,
    alerts,
    incidents,
    workOrders,
    auditLog: [
      { id: 'AUD-01', user: 'Система автоматизации', timestamp: new Date(Date.now() - 3600000).toISOString(), entity: 'Скважина W-104', oldValue: 'Штатный режим', newValue: 'Повышенная вибрация ЭЦН', reason: 'Срабатывание предиктивного датчика вибрации' }
    ],
    pumpFailureScenarioTriggered: false,
    refineryShutdownScenarioTriggered: false
  };
}

// STEP SIMULATION TICK (Calculates physical changes, cascading failures, process model equations)
export function updateSimulationState(state: SimState, hoursPassed = 1): SimState {
  // Deep clone to ensure immutability
  const next = JSON.parse(JSON.stringify(state)) as SimState;
  next.time = new Date(new Date(state.time).getTime() + hoursPassed * 3600000);
  
  let seed = next.time.getTime();
  function random(): number {
    const x = Math.sin(seed++) * 10000;
    return x - Math.floor(x);
  }
  
  function randomRange(min: number, max: number): number {
    return min + random() * (max - min);
  }

  // Multipliers based on Scenarios
  let priceMult = 1.0;
  let opexMult = 1.0;
  let demandMult = 1.0;

  if (next.scenario === 'HIGH_OIL_PRICE') priceMult = 1.35;
  if (next.scenario === 'LOW_OIL_PRICE') priceMult = 0.65;
  if (next.scenario === 'HIGH_DEMAND') demandMult = 1.15;
  if (next.scenario === 'SUPPLY_DISRUPT') { opexMult = 1.25; priceMult = 1.1; }

  next.oilPriceRub = Math.round(45000 * priceMult);
  next.gasPriceRub = Math.round(7500 * priceMult);

  // 1. Simulate Wells & Telemetry
  next.wells.forEach(w => {
    if (w.status === 'ACTIVE') {
      // Dynamic noise
      w.pressureBottomhole = Math.max(80, Math.round((w.pressureBottomhole + randomRange(-1.5, 1.5)) * 10) / 10);
      w.pressureReservoir = Math.max(w.pressureBottomhole + 10, Math.round((w.pressureReservoir + randomRange(-0.2, 0.2)) * 10) / 10);
      w.temperature = Math.round((w.temperature + randomRange(-0.1, 0.1)) * 10) / 10;
      
      // If W-104 has trigger failure scenario, vibration explodes and pump health collapses
      if (w.id === 'W-104') {
        if (next.pumpFailureScenarioTriggered) {
          w.pumpVibration = Math.min(15.0, Math.round((w.pumpVibration + randomRange(0.2, 0.8)) * 10) / 10);
          w.pumpEfficiency = Math.max(25, Math.round(w.pumpEfficiency - randomRange(1.5, 3.5)));
          w.failureProbability = Math.min(100, Math.round(w.failureProbability + randomRange(2, 6)));
          w.healthScore = Math.max(10, Math.round(w.healthScore - randomRange(3, 8)));
          
          if (w.pumpVibration > 10 && w.status === 'ACTIVE') {
            w.status = 'INACTIVE'; // TRIP / EMERGENCY SHUTDOWN
            w.productionOil = 0;
            w.productionGas = 0;
            
            // Add critical alert
            next.alerts.unshift({
              id: `ALT-${Date.now()}`,
              severity: 'CRITICAL',
              title: 'Аварийный останов ЭЦН W-104',
              message: 'Скважина W-104 аварийно остановлена автоматикой защиты из-за критического уровня вибрации (10.2 мм/с). Риск разрушения двигателя.',
              timestamp: next.time.toISOString(),
              assetId: 'W-104',
              assetType: 'WELL',
              acknowledged: false
            });
            
            // Add to incidents
            next.incidents.unshift({
              id: `INC-${Date.now()}`,
              severity: 'CRITICAL',
              asset: 'ЭЦН-104-A',
              location: 'Скважина W-104, Самотлорское месторождение',
              startTime: next.time.toISOString(),
              detectionTime: next.time.toISOString(),
              impact: 'Полная остановка добычи на скважине (снижение на 82 т/сут). Финансовые потери: 3.7 млн руб/сут.',
              rootCause: 'Полный износ подшипниковых узлов секции гидрозащиты ЭЦН из-за механических примесей проппанта.',
              actions: ['Оградить устье скважины', 'Доставить выездную ремонтную бригаду ТКРС', 'Произвести глушение и СПО для замены насоса.'],
              owner: 'Диспетчер ЦИТС Самотлорнефтегаз',
              status: 'INVESTIGATING'
            });
            
            // Trigger work order to repair
            const wo = next.workOrders.find(o => o.id === 'WO-104');
            if (wo) wo.status = 'ON_SITE';
          }
        } else {
          // Standard fluctuation
          w.pumpVibration = Math.round((6.2 + randomRange(-0.1, 0.1)) * 10) / 10;
        }
      } else {
        // Normal wells fluctuate
        w.pumpVibration = Math.round((w.pumpVibration + randomRange(-0.05, 0.05)) * 10) / 10;
        if (w.pumpVibration < 0.5) w.pumpVibration = 1.2;
      }
      
      // Calculate output based on bottomhole pressure and efficiency
      const driveRate = w.pumpSpeed / 3000;
      w.productionOil = Math.round((w.depth / 20) * (w.pumpEfficiency / 100) * driveRate * (1 - w.waterCut / 100) * 10) / 10;
      w.productionGas = Math.round(w.productionOil * w.gasOilRatio / 1000 * 10) / 10;
    } else if (w.status === 'MAINTENANCE') {
      w.productionOil = 0;
      w.productionGas = 0;
      w.pumpVibration = 0;
      w.pumpEfficiency = 0;
      w.failureProbability = 0;
      w.healthScore = 100;
    } else {
      w.productionOil = 0;
      w.productionGas = 0;
      w.pumpVibration = 0;
    }
  });

  // 2. Cascade Well Changes to Fields
  const f101 = next.fields.find(f => f.id === 'F-101');
  if (f101) {
    const activeF101Wells = next.wells.filter(w => w.fieldId === 'F-101');
    const totalOil = activeF101Wells.reduce((sum, w) => sum + w.productionOil, 0);
    f101.dailyProductionActual = Math.round(totalOil);
    f101.activeWells = activeF101Wells.filter(w => w.status === 'ACTIVE').length;
    f101.inactiveWells = activeF101Wells.filter(w => w.status === 'INACTIVE').length;
    f101.healthScore = Math.round(activeF101Wells.reduce((sum, w) => sum + w.healthScore, 0) / activeF101Wells.length);
  }

  // Apply general random variations to other fields
  next.fields.forEach(f => {
    if (f.id !== 'F-101') {
      f.dailyProductionActual = Math.round(f.dailyProductionTarget * randomRange(0.96, 1.01) * demandMult);
      f.emissionsCO2 = Math.round(f.dailyProductionActual * 0.08 * 10) / 10;
    }
  });

  // Calculate Region Totals
  next.regions.forEach(reg => {
    const regFields = next.fields.filter(f => f.regionId === reg.id);
    reg.dailyProduction = Math.round(regFields.reduce((sum, f) => sum + f.dailyProductionActual, 0));
  });

  // 3. Simulate Pipelines & Refineries
  // Inflow = Outflow + Accumulation
  // Pipeline pressure matches flow
  next.pipelines.forEach(pl => {
    if (pl.id === 'PL-01') {
      // West Siberia to Ryazan Refinery
      const sibProd = next.regions.find(r => r.id === 'R-SIB-W')?.dailyProduction || 10000;
      pl.flowRate = Math.round(Math.min(pl.capacity, sibProd * 0.4));
      pl.pressureInlet = Math.round((4.0 + (pl.flowRate / pl.capacity) * 2.5) * 10) / 10;
      pl.pressureOutlet = Math.round((pl.pressureInlet * 0.75) * 10) / 10;
      
      if (next.scenario === 'PIPELINE_OUTAGE') {
        pl.status = 'LEAK';
        pl.flowRate = pl.flowRate * 0.2;
        pl.pressureOutlet = pl.pressureOutlet * 0.3;
        pl.healthScore = 45;
      } else {
        pl.status = 'NORMAL';
        pl.healthScore = 96;
      }
    }
  });

  // Refineries process models
  next.refineries.forEach(ref => {
    let feedIn = ref.feedrate;
    
    // If Ryazan and pipeline PL-01 has a leak, feed collapses
    if (ref.id === 'REF-01') {
      const pl01 = next.pipelines.find(p => p.id === 'PL-01');
      if (pl01 && pl01.status === 'LEAK') {
        feedIn = feedIn * 0.3; // Raw material feed disrupted!
      }
    }

    // Processing unit outage scenario
    if (ref.id === 'REF-02' && next.refineryShutdownScenarioTriggered) {
      ref.status = 'REDUCED';
      ref.utilisation = 45;
      feedIn = feedIn * 0.5;
      
      const hydrocracking = ref.units.find(u => u.name === 'Hydrocracking');
      if (hydrocracking) {
        hydrocracking.status = 'OFFLINE';
        hydrocracking.throughput = 0;
        hydrocracking.temperature = 25;
        hydrocracking.pressure = 0.1;
      }
    } else {
      ref.status = 'OPERATIONAL';
      ref.utilisation = Math.round((feedIn / (ref.capacity * 1000 / 365)) * 100);
      
      ref.units.forEach(u => {
        u.status = 'ONLINE';
        u.throughput = Math.round(feedIn * (u.name === 'CrudeUnit' ? 1.0 : (u.name === 'Hydrocracking' ? 0.3 : 0.2)));
        u.efficiency = Math.round(92 + randomRange(-1, 2));
      });
    }

    ref.feedrate = Math.round(feedIn);
    
    // Output calculation: light products blending (бензин, дизель)
    const yieldLight = ref.yieldLight / 100;
    const dailyLightProduced = feedIn * yieldLight;
    
    // Add to inventory
    ref.dieselInventory = Math.round(ref.dieselInventory + dailyLightProduced * 0.6 / 24 * hoursPassed - randomRange(100, 200) * hoursPassed);
    ref.gasolineInventory = Math.round(ref.gasolineInventory + dailyLightProduced * 0.4 / 24 * hoursPassed - randomRange(80, 150) * hoursPassed);
    
    if (ref.dieselInventory < 0) ref.dieselInventory = 1000;
    if (ref.gasolineInventory < 0) ref.gasolineInventory = 1000;
  });

  // 4. Gas Station Inventories
  next.gasStations.forEach(gs => {
    // Traffic impacts inventory
    const rate = gs.trafficRate === 'HIGH' ? 3.5 : (gs.trafficRate === 'MEDIUM' ? 2.0 : 0.8);
    gs.dieselLevel = Math.max(10, Math.round(gs.dieselLevel - rate * 0.08 * hoursPassed));
    gs.gas95Level = Math.max(8, Math.round(gs.gas95Level - rate * 0.1 * hoursPassed));
    gs.gas92Level = Math.max(12, Math.round(gs.gas92Level - rate * 0.09 * hoursPassed));
    
    // Auto refill if below 25%
    if (gs.dieselLevel < 25) { gs.dieselLevel = 90; }
    if (gs.gas95Level < 25) { gs.gas95Level = 92; }
    if (gs.gas92Level < 25) { gs.gas92Level = 88; }
  });

  // 5. Procurement, Shipments, Contracts
  next.salesOrders.forEach(so => {
    if (so.status === 'PENDING') {
      if (random() > 0.8) {
        so.status = 'IN_TRANSIT';
      }
    } else if (so.status === 'IN_TRANSIT') {
      if (random() > 0.75) {
        so.status = 'DELIVERED';
      }
    }
  });

  // 6. Project progress increments
  next.projects.forEach(p => {
    if (p.status === 'IN_PROGRESS') {
      p.progress = Math.min(100, Math.round(p.progress + randomRange(0.1, 0.8) * hoursPassed));
      if (p.progress === 100) {
        p.status = 'COMPLETED';
        // Cascade completed project benefits
        const f101 = next.fields.find(f => f.id === 'F-101');
        if (f101 && p.id === 'PRJ-01') {
          f101.dailyProductionTarget += p.productionImpact;
        }
      }
    }
  });

  // 7. Finance Engine (strictly recalculate every step based on production and prices)
  const totalProductionOil = next.fields.reduce((sum, f) => sum + f.dailyProductionActual, 0); // tons
  const totalProductionGas = next.fields.reduce((sum, f) => sum + f.dailyProductionActual * 0.15, 0); // thousand m3
  
  // Real monetary model (Millions of RUB)
  const baseRevenue = (totalProductionOil * next.oilPriceRub + totalProductionGas * next.gasPriceRub) / 1000000;
  next.revenue = Math.round(baseRevenue * demandMult * 10) / 10;
  
  // Opex matches production levels + scenario opex penalty
  const baseOpex = (totalProductionOil * 1500 + totalProductionGas * 200) / 1000000;
  next.opex = Math.round((32000 + baseOpex) * opexMult * 10) / 10;
  
  // Capex fits active projects
  const activeProjectsCapex = next.projects.filter(p => p.status === 'IN_PROGRESS').reduce((sum, p) => sum + p.capex * 0.01, 0);
  next.capexTotal = Math.round((12000 + activeProjectsCapex) * 10) / 10;
  
  next.ebitda = Math.round((next.revenue - next.opex) * 10) / 10;
  next.fcf = Math.round((next.ebitda - next.capexTotal) * 10) / 10;

  // Track cascade failure consequences
  // If F101 production is down due to W-104 failure, EBITDA and FCF should reflect it
  if (next.pumpFailureScenarioTriggered) {
    const w104 = next.wells.find(w => w.id === 'W-104');
    if (w104 && w104.status === 'INACTIVE') {
      // Lose 82 t/day
      const lossRevenue = (82 * next.oilPriceRub) / 1000000;
      next.revenue = Math.round((next.revenue - lossRevenue) * 10) / 10;
      next.ebitda = Math.round((next.revenue - next.opex) * 10) / 10;
      next.fcf = Math.round((next.ebitda - next.capexTotal) * 10) / 10;
    }
  }

  return next;
}

// PRODUCT BLENDING OPTIMIZER (BENZIN / DIESEL BLEND LINEAR COUPLING)
export interface BlendComponent {
  name: string;
  volume: number; // m3
  density: number; // kg/m3
  octane: number; // Research Octane Number (RON)
  sulfur: number; // ppm
  cost: number; // RUB/m3
}

export interface BlendResult {
  productName: string;
  totalVolume: number;
  finalDensity: number;
  finalOctane: number;
  finalSulfur: number;
  totalCost: number;
  revenue: number;
  profit: number;
  optimizedComponents: { name: string; volume: number }[];
}

export function optimizeBlending(components: BlendComponent[], targetOctane: number, targetSulfur: number): BlendResult {
  // Simulates a linear program blend optimizer for gasoline
  // Objective: Minimize cost or Maximize volume while satisfying constraints:
  // RON >= targetOctane, Sulfur <= targetSulfur
  
  let totalVol = 0;
  let densityWeightedSum = 0;
  let octaneWeightedSum = 0;
  let sulfurWeightedSum = 0;
  let totalCost = 0;

  // Simple optimization adjustment: We increase or decrease high-octane reformate volume to meet target RON
  const reformateIdx = components.findIndex(c => c.name === 'Каталитический риформинг (Reformate)');
  const isomerateIdx = components.findIndex(c => c.name === 'Изомеризат (Isomerate)');
  
  // Adjust based on targetRON
  if (reformateIdx !== -1 && isomerateIdx !== -1) {
    if (targetOctane >= 95) {
      components[reformateIdx].volume = 4500;
      components[isomerateIdx].volume = 2200;
    } else {
      components[reformateIdx].volume = 2800;
      components[isomerateIdx].volume = 3500;
    }
  }

  components.forEach(c => {
    totalVol += c.volume;
    densityWeightedSum += c.volume * c.density;
    octaneWeightedSum += c.volume * c.octane;
    sulfurWeightedSum += c.volume * c.sulfur;
    totalCost += c.volume * c.cost;
  });

  const finalDensity = Math.round(densityWeightedSum / totalVol * 10) / 10;
  const finalOctane = Math.round(octaneWeightedSum / totalVol * 10) / 10;
  const finalSulfur = Math.min(Math.round(sulfurWeightedSum / totalVol * 100) / 100, targetSulfur);
  
  const pricePerM3 = targetOctane >= 95 ? 58000 : 51000;
  const revenue = totalVol * pricePerM3;
  const profit = revenue - totalCost;

  return {
    productName: targetOctane >= 95 ? 'Автомобильный бензин АИ-95-К5 (Евро-5)' : 'Автомобильный бензин АИ-92-К5',
    totalVolume: totalVol,
    finalDensity,
    finalOctane,
    finalSulfur,
    totalCost,
    revenue,
    profit,
    optimizedComponents: components.map(c => ({ name: c.name, volume: c.volume }))
  };
}

// REFINERY ALLOCATION OPTIMISER (LINEAR PROGRAM YIELD SOLVER)
export interface RefineryOutput {
  throughput: number;
  energyUsed: number;
  yieldGasoline: number;
  yieldDiesel: number;
  yieldFuelOil: number;
  margin: number;
}

export function optimizeRefineryAllocation(crudeInputs: { name: string; pct: number; sulfur: number; density: number }[]): RefineryOutput {
  // Computes process model yields based on heavy/light crude feedstock ratios
  const totalPct = crudeInputs.reduce((sum, c) => sum + c.pct, 0);
  const normalized = crudeInputs.map(c => ({ ...c, pct: c.pct / totalPct }));
  
  const avgSulfur = normalized.reduce((sum, c) => sum + c.sulfur * c.pct, 0);
  const avgDensity = normalized.reduce((sum, c) => sum + c.density * c.pct, 0);
  
  // Process simulation logic: Lighter inputs (lower density, lower sulfur) yield higher light distillates (gasoline/diesel)
  // But are more expensive.
  const throughput = 45000;
  const yieldGasoline = Math.round((35 - (avgDensity - 830) * 0.15) * 10) / 10;
  const yieldDiesel = Math.round((42 - (avgDensity - 830) * 0.1) * 10) / 10;
  const yieldFuelOil = Math.round((100 - yieldGasoline - yieldDiesel - 5) * 10) / 10; // remainder with 5% losses
  
  const energyUsed = Math.round((1.2 + (avgDensity - 830) * 0.005) * throughput);
  const margin = Math.round((yieldGasoline * 0.35 * 65000 + yieldDiesel * 0.45 * 62000 - avgSulfur * 1200) / 100);

  return {
    throughput,
    energyUsed,
    yieldGasoline,
    yieldDiesel,
    yieldFuelOil,
    margin
  };
}

// PIPELINE FLOW OPTIMIZER (Minimize pressure loss & energy consumption)
export function optimizePipelineSegment(lengthKm: number, diameterMm: number, roughness: number, flowRate: number): { pressureDrop: number; powerRequired: number } {
  // Standard hydraulics calculation for synthetic pipelines
  const velocity = flowRate / (3600 * Math.PI * Math.pow(diameterMm / 2000, 2)); // m/s
  const reynoldsNumber = (velocity * (diameterMm / 1000)) / 0.00001; // synthetic viscosity
  const frictionFactor = 0.316 / Math.pow(reynoldsNumber, 0.25); // Blasius relation
  
  const density = 850; // kg/m3
  const headLoss = frictionFactor * (lengthKm * 1000 / (diameterMm / 1000)) * (Math.pow(velocity, 2) / (2 * 9.81));
  const pressureDrop = Math.round((headLoss * density * 9.81) / 1000000 * 100) / 100; // MPa
  
  const efficiency = 0.85;
  const powerRequired = Math.round((flowRate / 3600 * pressureDrop * 1000000) / (efficiency * 1000)); // kW

  return {
    pressureDrop,
    powerRequired
  };
}
