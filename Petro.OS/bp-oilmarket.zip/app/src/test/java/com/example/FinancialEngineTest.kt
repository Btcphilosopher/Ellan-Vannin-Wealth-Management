package com.example

import com.example.data.TerminalRepository
import com.example.engine.FinancialEngine
import com.example.model.*
import org.junit.Assert.*
import org.junit.Test

class FinancialEngineTest {

    @Test
    fun testCarryTradeCalculation() {
        val setup = CarryTradeSetup(
            id = "TEST-CARRY",
            name = "Test Contango",
            spotPrice = 80.0,
            forwardPrice = 84.0,
            forwardDays = 90,
            volumeBbls = 100000,
            financingRatePct = 5.0,
            storageMonthlyBbl = 0.40,
            insuranceMonthlyBbl = 0.05,
            handlingBbl = 0.10,
            hedgingCostBbl = 0.05
        )

        val result = FinancialEngine.calculateCarry(setup)

        // Gross carry = 84.0 - 80.0 = 4.0
        assertEquals(4.0, result.grossCarryPerBbl, 0.001)

        // Financing = 80.0 * 0.05 * (90/365) = ~0.9863
        assertEquals(0.986, result.financingCostPerBbl, 0.01)

        // Storage = 0.40 * 3 months = 1.20
        assertEquals(1.20, result.storageCostPerBbl, 0.001)

        // Net carry should be positive and total calculated accurately
        assertTrue("Net carry should be positive", result.netCarryPerBbl > 0)
        assertTrue("Annualised yield should be positive", result.annualisedYieldPct > 0)
        assertEquals(8000000.0, result.capitalRequiredUSD, 0.01)
    }

    @Test
    fun testBlack76OptionGreeks() {
        // At-the-money call option
        val callGreeks = FinancialEngine.calculateBlack76(
            isCall = true,
            forwardPrice = 80.0,
            strike = 80.0,
            riskFreeRatePct = 5.0,
            volatilityPct = 30.0,
            daysToExpiry = 90
        )

        assertTrue("Call price must be positive", callGreeks.price > 0.0)
        assertTrue("Call delta must be around 0.5", callGreeks.delta in 0.4..0.6)
        assertTrue("Gamma must be positive", callGreeks.gamma > 0.0)
        assertTrue("Vega must be positive", callGreeks.vega > 0.0)

        // Put option
        val putGreeks = FinancialEngine.calculateBlack76(
            isCall = false,
            forwardPrice = 80.0,
            strike = 80.0,
            riskFreeRatePct = 5.0,
            volatilityPct = 30.0,
            daysToExpiry = 90
        )

        assertTrue("Put price must be positive", putGreeks.price > 0.0)
        assertTrue("Put delta must be negative", putGreeks.delta < 0.0)
    }

    @Test
    fun testAccruedInterestDayCounts() {
        val principal = 1000000.0
        val rate = 5.0
        val days = 30

        val act360 = FinancialEngine.calculateAccruedInterest(principal, rate, days, DayCountConvention.ACT_360)
        val act365 = FinancialEngine.calculateAccruedInterest(principal, rate, days, DayCountConvention.ACT_365)

        // 1,000,000 * 0.05 * (30/360) = 4,166.67
        assertEquals(4166.67, act360, 0.01)
        // 1,000,000 * 0.05 * (30/365) = 4,109.59
        assertEquals(4109.59, act365, 0.01)
        assertTrue("ACT/360 interest should exceed ACT/365", act360 > act365)
    }

    @Test
    fun testCDOWaterfallAllocation() {
        val waterfall = FinancialEngine.calculateCDOWaterfall(
            totalCollateralUSD = 100000000.0,
            simulatedDefaultRatePct = 1.0,
            recoveryRatePct = 50.0,
            seniorPrincipalUSD = 75000000.0,
            seniorCouponSpreadBps = 100.0,
            mezzPrincipalUSD = 15000000.0,
            mezzCouponSpreadBps = 250.0,
            equityPrincipalUSD = 10000000.0,
            targetReserveUSD = 2000000.0,
            benchmarkRatePct = 5.0
        )

        // Senior tranche must have 100% coverage under 1% default
        assertEquals(100.0, waterfall.seniorCoverageRatioPct, 0.01)
        assertEquals(100.0, waterfall.mezzCoverageRatioPct, 0.01)
        assertTrue("Total collected should exceed 99M", waterfall.totalCollectedUSD >= 99000000.0)
    }

    @Test
    fun testRepositoryLifecycleAndDualApproval() {
        val repo = TerminalRepository()
        assertFalse(repo.quotes.value.isEmpty())
        assertFalse(repo.facilities.value.isEmpty())

        // Submit order
        val order = repo.submitOrder(
            symbol = "BRENT_DATED",
            side = OrderSide.BUY,
            type = OrderType.LIMIT,
            price = 84.0,
            quantityBbls = 50000,
            counterparty = "Test Trading",
            laycan = "Nov 1-5",
            location = "Rotterdam"
        )
        assertNotNull(order)
        assertEquals(OrderStatus.ACTIVE, order.status)

        // Test dual officer escrow approval
        val pendingEscrow = repo.escrowRecords.value.first { it.stage != EscrowStage.SETTLED_DVP }
        val id = pendingEscrow.escrowId

        repo.approveEscrowOfficer(id, isTreasury = true, isRisk = false)
        val updated1 = repo.escrowRecords.value.first { it.escrowId == id }
        assertTrue(updated1.treasuryDualApproved)

        repo.approveEscrowOfficer(id, isTreasury = false, isRisk = true)
        val updated2 = repo.escrowRecords.value.first { it.escrowId == id }
        assertTrue(updated2.riskDualApproved)
    }
}
