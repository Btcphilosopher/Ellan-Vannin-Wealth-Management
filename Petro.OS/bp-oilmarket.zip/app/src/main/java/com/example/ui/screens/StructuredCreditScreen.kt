package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.FinancialEngine
import com.example.model.StructuredCreditPool
import com.example.model.TokenisedAsset
import com.example.ui.theme.*

@Composable
fun StructuredCreditScreen(
    cdoPool: StructuredCreditPool?,
    tokenisedAssets: List<TokenisedAsset>,
    modifier: Modifier = Modifier
) {
    var defaultRateSimPct by remember { mutableStateOf(2.5f) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // CDO SPV Header Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.AccountTree, contentDescription = null, tint = BPGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "STRUCTURED CREDIT & CDO WATERFALL",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Asset-Backed Securitization of Physical Oil & Trade Receivables",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(BPGreen.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = "SPV ACTIVE", color = BPGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Waterfall Simulation Interactive Slider
        if (cdoPool != null) {
            val waterfall = FinancialEngine.calculateCDOWaterfall(
                totalCollateralUSD = cdoPool.totalCollateralUSD,
                simulatedDefaultRatePct = defaultRateSimPct.toDouble(),
                recoveryRatePct = 40.0,
                seniorPrincipalUSD = cdoPool.seniorTranche.principalUSD,
                seniorCouponSpreadBps = cdoPool.seniorTranche.couponSpreadBps,
                mezzPrincipalUSD = cdoPool.mezzTranche.principalUSD,
                mezzCouponSpreadBps = cdoPool.mezzTranche.couponSpreadBps,
                equityPrincipalUSD = cdoPool.equityTranche.principalUSD,
                targetReserveUSD = cdoPool.reserveAccountUSD
            )

            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = cdoPool.spvName,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Pool: $${"%,.0f".format(cdoPool.totalCollateralUSD / 1000000.0)}M",
                                color = BPGreen,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Simulated Pool Default Rate: ${"%.1f".format(defaultRateSimPct)}% (40% Recovery)",
                            color = WarningAmber,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold
                        )

                        Slider(
                            value = defaultRateSimPct,
                            onValueChange = { defaultRateSimPct = it },
                            valueRange = 0f..15f,
                            steps = 14,
                            colors = SliderDefaults.colors(
                                thumbColor = WarningAmber,
                                activeTrackColor = WarningAmber,
                                inactiveTrackColor = TerminalBackground
                            )
                        )

                        // Tranche Waterfall Allocation Cards
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            TrancheRow(
                                name = "SENIOR TRANCHE A (AAA)",
                                slice = "75% ($187.5M)",
                                coupon = "SOFR + 115 bps",
                                coverage = "${"%.1f".format(waterfall.seniorCoverageRatioPct)}%",
                                payout = "$${"%,.0f".format(waterfall.seniorPayoutUSD)}",
                                statusColor = if (waterfall.seniorCoverageRatioPct >= 99.9) PriceUpGreen else PriceDownRed
                            )
                            TrancheRow(
                                name = "MEZZANINE TRANCHE B (BBB)",
                                slice = "15% ($37.5M)",
                                coupon = "SOFR + 285 bps",
                                coverage = "${"%.1f".format(waterfall.mezzCoverageRatioPct)}%",
                                payout = "$${"%,.0f".format(waterfall.mezzPayoutUSD)}",
                                statusColor = if (waterfall.mezzCoverageRatioPct >= 99.9) PriceUpGreen else WarningAmber
                            )
                            TrancheRow(
                                name = "RESERVE ACCOUNT REPLENISH",
                                slice = "Target: $5.0M",
                                coupon = "Cash Buffer",
                                coverage = "Protected",
                                payout = "$${"%,.0f".format(waterfall.reserveReplenishedUSD)}",
                                statusColor = InfoCyan
                            )
                            TrancheRow(
                                name = "EQUITY / FIRST-LOSS SLICE",
                                slice = "10% ($25.0M)",
                                coupon = "Residual Yield",
                                coverage = "Yield: ${"%.1f".format(waterfall.equityYieldPct)}%",
                                payout = "$${"%,.0f".format(waterfall.equityResidualUSD)}",
                                statusColor = if (waterfall.equityResidualUSD > 0) BPGreen else PriceDownRed
                            )
                        }
                    }
                }
            }
        }

        // Section Title: Tokenised Oil Asset Exchange
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TOKENISED ASSET EXCHANGE (PERMISSIONED REGISTRY)",
                    color = BPGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(text = "ERC-3643 Institutional Standard", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }

        items(tokenisedAssets) { token ->
            TokenCard(token = token)
        }
    }
}

@Composable
private fun TrancheRow(
    name: String,
    slice: String,
    coupon: String,
    coverage: String,
    payout: String,
    statusColor: Color
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalBackground)
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = "$slice | $coupon", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(text = payout, color = statusColor, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text(text = coverage, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun TokenCard(token: TokenisedAsset) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(BPGreenDark)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = token.symbol, color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = token.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    text = "$${"%.2f".format(token.marketPriceUSD)}",
                    color = PriceUpGreen,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Custody: ${token.custodyLocation} | Cert: ${token.inspectionCertNo}",
                color = TextSecondary,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Supply: ${"%,d".format(token.circulatingSupply)} / ${"%,d".format(token.totalSupply)}",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = null, tint = BPGreen, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "TRANSFER RESTRICTED (KYC/AML)", color = BPGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
