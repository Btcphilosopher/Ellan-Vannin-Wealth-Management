package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TerminalBackground
import com.example.viewmodel.TerminalTab
import com.example.viewmodel.TerminalViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                TerminalApp()
            }
        }
    }
}

@Composable
fun TerminalApp(
    viewModel: TerminalViewModel = viewModel()
) {
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val isLiveStreaming by viewModel.isLiveStreaming.collectAsStateWithLifecycle()
    val latencyMs by viewModel.latencyMs.collectAsStateWithLifecycle()
    val commandQuery by viewModel.commandQuery.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    val quotes by viewModel.repository.quotes.collectAsStateWithLifecycle()
    val orderBooks by viewModel.repository.orderBooks.collectAsStateWithLifecycle()
    val cargos by viewModel.repository.cargos.collectAsStateWithLifecycle()
    val facilities by viewModel.repository.facilities.collectAsStateWithLifecycle()
    val moneyMarketQuotes by viewModel.repository.moneyMarketQuotes.collectAsStateWithLifecycle()
    val yieldCurve by viewModel.repository.yieldCurve.collectAsStateWithLifecycle()
    val derivatives by viewModel.repository.derivatives.collectAsStateWithLifecycle()
    val carrySetups by viewModel.repository.carrySetups.collectAsStateWithLifecycle()
    val cdoPool by viewModel.repository.cdoPool.collectAsStateWithLifecycle()
    val tokenisedAssets by viewModel.repository.tokenisedAssets.collectAsStateWithLifecycle()
    val escrows by viewModel.repository.escrowRecords.collectAsStateWithLifecycle()
    val orders by viewModel.repository.orders.collectAsStateWithLifecycle()
    val auditLogs by viewModel.repository.auditLogs.collectAsStateWithLifecycle()
    val riskSummary by viewModel.repository.riskSummary.collectAsStateWithLifecycle()

    val selectedQuoteForTrade by viewModel.selectedQuoteForTrade.collectAsStateWithLifecycle()
    val selectedFacility by viewModel.selectedFacility.collectAsStateWithLifecycle()
    val showStressModal by viewModel.showStressModal.collectAsStateWithLifecycle()

    BackHandler(enabled = activeTab != TerminalTab.OVERVIEW) {
        viewModel.setTab(TerminalTab.OVERVIEW)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            Column {
                TerminalHeader(
                    isLiveStreaming = isLiveStreaming,
                    latencyMs = latencyMs,
                    commandQuery = commandQuery,
                    statusMessage = statusMessage,
                    onQueryChange = { viewModel.setCommandQuery(it) },
                    onExecuteCommand = { viewModel.executeTerminalCommand(it) },
                    onToggleLive = { viewModel.toggleLiveStreaming() },
                    onStepTick = { viewModel.stepTick() },
                    onClearStatus = { viewModel.clearStatusMessage() }
                )
                TerminalNavigation(
                    activeTab = activeTab,
                    onTabSelected = { viewModel.setTab(it) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(TerminalBackground)
                .padding(innerPadding)
        ) {
            when (activeTab) {
                TerminalTab.OVERVIEW -> OverviewScreen(
                    quotes = quotes,
                    cargos = cargos,
                    facilities = facilities,
                    riskSummary = riskSummary,
                    onSelectQuote = { viewModel.selectQuoteForTrade(it) },
                    onOpenStressModal = { viewModel.setShowStressModal(true) }
                )
                TerminalTab.PHYSICAL_DESK -> PhysicalDeskScreen(
                    quotes = quotes,
                    orderBooks = orderBooks,
                    commodityGrades = viewModel.repository.commodityGrades,
                    orders = orders,
                    cargos = cargos,
                    onSelectQuoteForTrade = { viewModel.selectQuoteForTrade(it) }
                )
                TerminalTab.TREASURY -> TreasuryScreen(
                    facilities = facilities,
                    onSelectFacility = { viewModel.selectFacility(it) }
                )
                TerminalTab.MONEY_MARKET -> MoneyMarketScreen(
                    quotes = moneyMarketQuotes,
                    yieldCurve = yieldCurve
                )
                TerminalTab.DERIVATIVES -> DerivativesScreen(
                    derivatives = derivatives
                )
                TerminalTab.CARRY_ARBITRAGE -> CarryArbitrageScreen(
                    carrySetups = carrySetups
                )
                TerminalTab.STRUCTURED_CREDIT -> StructuredCreditScreen(
                    cdoPool = cdoPool,
                    tokenisedAssets = tokenisedAssets
                )
                TerminalTab.ESCROW_SETTLEMENT -> EscrowSettlementScreen(
                    escrows = escrows,
                    onApproveDualSignOff = { id, isTreasury, isRisk ->
                        viewModel.approveEscrow(id, isTreasury, isRisk)
                    }
                )
                TerminalTab.RISK_ENGINE -> RiskScreen(
                    riskSummary = riskSummary,
                    onTriggerScenario = { viewModel.triggerStressScenario(it) }
                )
                TerminalTab.AUDIT_LEDGER -> AuditLedgerScreen(
                    logs = auditLogs
                )
            }

            // Trade Order Dialog
            if (selectedQuoteForTrade != null) {
                OrderDialog(
                    quote = selectedQuoteForTrade!!,
                    onDismiss = { viewModel.selectQuoteForTrade(null) },
                    onSubmit = { symbol, side, type, price, qty, cparty, laycan, loc ->
                        viewModel.submitOrder(symbol, side, type, price, qty, cparty, laycan, loc)
                    }
                )
            }

            // Facility Adjustment Dialog
            if (selectedFacility != null) {
                FacilityDialog(
                    facility = selectedFacility!!,
                    onDismiss = { viewModel.selectFacility(null) },
                    onSubmit = { facilityId, amount, isDrawdown ->
                        viewModel.adjustFacility(facilityId, amount, isDrawdown)
                    }
                )
            }

            // Stress Scenario Modal
            if (showStressModal) {
                StressScenarioModal(
                    onDismiss = { viewModel.setShowStressModal(false) },
                    onSelectScenario = { viewModel.triggerStressScenario(it) }
                )
            }
        }
    }
}
