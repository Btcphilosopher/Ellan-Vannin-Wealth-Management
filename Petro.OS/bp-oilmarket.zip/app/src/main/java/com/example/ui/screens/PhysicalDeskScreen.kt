package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun PhysicalDeskScreen(
    quotes: List<MarketQuote>,
    orderBooks: Map<String, OrderBook>,
    commodityGrades: List<CommodityGrade>,
    orders: List<Order>,
    cargos: List<PhysicalCargo>,
    onSelectQuoteForTrade: (MarketQuote) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSymbol by remember { mutableStateOf("BRENT_DATED") }
    val currentQuote = quotes.find { it.symbol == selectedSymbol } ?: quotes.firstOrNull()
    val currentBook = orderBooks[selectedSymbol]

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Instrument Selector Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quotes.forEach { q ->
                    val isSelected = q.symbol == selectedSymbol
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) BPGreenDark else TerminalSurface)
                            .border(1.dp, if (isSelected) BPGreen else TerminalBorder, RoundedCornerShape(4.dp))
                            .clickable { selectedSymbol = q.symbol }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Column {
                            Text(
                                text = q.symbol,
                                color = if (isSelected) Color.White else TextSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$${q.last}",
                                color = if (isSelected) BPGreenLight else Color.White,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Selected Instrument Live Header & Fast Execution Bar
        if (currentQuote != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = currentQuote.name.uppercase(),
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Category: ${currentQuote.category} | High: $${currentQuote.high} Low: $${currentQuote.low}",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "$${currentQuote.last}",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${if (currentQuote.change >= 0) "+" else ""}${"%.2f".format(currentQuote.change)} (${"%.2f".format(currentQuote.changePct)}%)",
                                    color = if (currentQuote.change >= 0) PriceUpGreen else PriceDownRed,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Transmit Order Action Button
                        Button(
                            onClick = { onSelectQuoteForTrade(currentQuote) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("open_trade_ticket"),
                            shape = RoundedCornerShape(4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BPGreen)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "TRANSMIT ORDER / RFQ FOR ${currentQuote.symbol}",
                                color = Color.White,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Institutional Market Depth & Order Book
        if (currentBook != null) {
            item {
                Text(
                    text = "LEVEL 2 ORDER BOOK // MARKET DEPTH",
                    color = BPGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalSurface)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        // Header row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "BIDS (BUY)", color = BPGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(text = "VOLUME", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text(text = "ASKS (SELL)", color = PriceDownRed, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(text = "VOLUME", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        }

                        for (i in 0 until 5) {
                            val bid = currentBook.bids.getOrNull(i)
                            val ask = currentBook.asks.getOrNull(i)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Bid Price
                                Text(
                                    text = if (bid != null) "$${"%.2f".format(bid.price)}" else "-",
                                    color = PriceUpGreen,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                // Bid Qty
                                Text(
                                    text = if (bid != null) "${"%,d".format(bid.quantityBbls / 1000)}k" else "-",
                                    color = TextSecondary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                                // Ask Price
                                Text(
                                    text = if (ask != null) "$${"%.2f".format(ask.price)}" else "-",
                                    color = PriceDownRed,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                // Ask Qty
                                Text(
                                    text = if (ask != null) "${"%,d".format(ask.quantityBbls / 1000)}k" else "-",
                                    color = TextSecondary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Commodity Grade Matrix (Differentials, API, Sulfur)
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "APPROVED CRUDE GRADES & REGIONAL DIFFERENTIALS",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(commodityGrades) { grade ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = grade.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "vs ${grade.benchmark}", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                        Text(
                            text = "${grade.deliveryRegion} | API: ${grade.apiGravity}° | S: ${grade.sulfurPct}%",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        val diff = grade.differentialBbl
                        val diffText = if (diff >= 0) "+$${"%.2f".format(diff)}" else "-$${"%.2f".format(kotlin.math.abs(diff))}"
                        Text(
                            text = diffText,
                            color = if (diff >= 0) PriceUpGreen else PriceDownRed,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = "Std: ${"%,d".format(grade.standardCargoBbl / 1000)}k bbl", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // Active Orders Blotter
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "TRADER ORDER BLOTTER",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(orders) { order ->
            OrderBlotterRow(order = order)
        }

        // Vessel Cargo Nominations & SGS Inspections
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "PHYSICAL CARGO NOMINATIONS & SGS INSPECTIONS",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(cargos) { cargo ->
            CargoDetailedCard(cargo = cargo)
        }
    }
}

@Composable
private fun OrderBlotterRow(order: Order) {
    val isBuy = order.side == OrderSide.BUY

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isBuy) BPGreenDark else PriceDownRed.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = order.side.name,
                            color = if (isBuy) Color.White else PriceDownRed,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = order.orderId, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "(${order.symbol})", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(TerminalSurfaceVariant)
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = order.status.name,
                        color = if (order.status == OrderStatus.FILLED) PriceUpGreen else WarningAmber,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${"%,d".format(order.quantityBbls)} bbls @ $${"%.2f".format(order.price)} | ${order.counterparty}",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Filled: ${"%,d".format(order.filledBbls)}",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun CargoDetailedCard(cargo: PhysicalCargo) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${cargo.vesselName} [${cargo.cargoId}]",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (cargo.sgsInspectionVerified) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "SGS Verified", tint = PriceUpGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "SGS VERIFIED", color = PriceUpGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    } else {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = "SGS Pending", tint = WarningAmber, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "INSPECTION PENDING", color = WarningAmber, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "${cargo.portOfOrigin} → ${cargo.destinationPort} | Grade: ${cargo.gradeCode} | Vol: ${"%,d".format(cargo.quantityBbls)} bbls",
                color = TextSecondary,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Freight: $${"%,.0f".format(cargo.freightCostUSD)} | Storage: $${"%,.0f".format(cargo.storageCostUSD)}",
                    color = TextMuted,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Buyer: ${cargo.buyer}",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
