package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.FinancingFacility
import com.example.ui.theme.*

@Composable
fun FacilityDialog(
    facility: FinancingFacility,
    onDismiss: () -> Unit,
    onSubmit: (facilityId: String, amountUSD: Double, isDrawdown: Boolean) -> Unit
) {
    var isDrawdown by remember { mutableStateOf(true) }
    var amountInput by remember { mutableStateOf("50000000") }

    val amount = amountInput.toDoubleOrNull() ?: 50000000.0

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("facility_dialog"),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "TREASURY FACILITY ADJUSTMENT",
                    color = BPGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = facility.title,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${facility.benchmark} + ${facility.spreadBps} bps | All-in: ${"%.2f".format(facility.allInRatePct)}%",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Stats row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalBackground)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Drawn", color = TextMuted, fontSize = 10.sp)
                        Text("$${"%,.0f".format(facility.drawnUSD)}", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("Available Capacity", color = TextMuted, fontSize = 10.sp)
                        Text("$${"%,.0f".format(facility.availableUSD)}", color = BPGreen, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("Accrued Interest", color = TextMuted, fontSize = 10.sp)
                        Text("$${"%,.0f".format(facility.accruedInterestUSD)}", color = WarningAmber, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Drawdown vs Repayment toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isDrawdown) BPGreenDark else TerminalBackground)
                            .border(1.dp, if (isDrawdown) BPGreen else TerminalBorder, RoundedCornerShape(4.dp))
                            .clickable { isDrawdown = true }
                            .padding(vertical = 8.dp)
                            .testTag("action_drawdown"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("DRAWDOWN (+CASH)", color = if (isDrawdown) Color.White else TextMuted, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (!isDrawdown) NeutralBlue.copy(alpha = 0.3f) else TerminalBackground)
                            .border(1.dp, if (!isDrawdown) NeutralBlue else TerminalBorder, RoundedCornerShape(4.dp))
                            .clickable { isDrawdown = false }
                            .padding(vertical = 8.dp)
                            .testTag("action_repay"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("REPAY (-DEBT)", color = if (!isDrawdown) Color.White else TextMuted, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Amount (USD)", color = TextMuted, fontSize = 11.sp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("facility_amount_input"),
                    textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.Monospace),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("25M" to 25000000.0, "50M" to 50000000.0, "100M" to 100000000.0, "250M" to 250000000.0).forEach { (lbl, valUSD) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(3.dp))
                                .background(TerminalBackground)
                                .border(1.dp, TerminalBorder, RoundedCornerShape(3.dp))
                                .clickable { amountInput = "%.0f".format(valUSD) }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = lbl, color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("CANCEL", color = TextSecondary, fontFamily = FontFamily.Monospace)
                    }

                    Button(
                        onClick = { onSubmit(facility.facilityId, amount, isDrawdown) },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("submit_facility_confirm"),
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (isDrawdown) BPGreen else NeutralBlue)
                    ) {
                        Text(
                            text = if (isDrawdown) "EXECUTE DRAW" else "EXECUTE REPAY",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
