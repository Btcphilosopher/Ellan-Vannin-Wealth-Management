package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EscrowRecord
import com.example.model.EscrowStage
import com.example.ui.theme.*

@Composable
fun EscrowSettlementScreen(
    escrows: List<EscrowRecord>,
    onApproveDualSignOff: (escrowId: String, isTreasury: Boolean, isRisk: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalEscrowUSD = escrows.sumOf { it.totalNotionalUSD }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Escrow Engine Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "48-HOUR (T+2) ESCROW & DvP SETTLEMENT ENGINE",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Conditional Title Transfer | SGS Quality Verification | Dual Sign-Off",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "TOTAL RESTRICTED", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        Text(
                            text = "$${"%,.1f".format(totalEscrowUSD / 1000000.0)}M",
                            color = WarningAmber,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Section Title
        item {
            Text(
                text = "ACTIVE SETTLEMENT OBLIGATIONS & DUAL APPROVAL CONTROLS",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(escrows) { escrow ->
            EscrowDetailedCard(escrow = escrow, onApprove = onApproveDualSignOff)
        }
    }
}

@Composable
private fun EscrowDetailedCard(
    escrow: EscrowRecord,
    onApprove: (escrowId: String, isTreasury: Boolean, isRisk: Boolean) -> Unit
) {
    val stageColor = when (escrow.stage) {
        EscrowStage.T0_RECORDED -> TextSecondary
        EscrowStage.T1_FUNDS_RESERVED -> InfoCyan
        EscrowStage.T2_INSPECTION_CONFIRMED -> WarningAmber
        EscrowStage.SETTLED_DVP -> PriceUpGreen
        EscrowStage.EXCEPTION_HOLD -> PriceDownRed
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = escrow.escrowId, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "Trade: ${escrow.tradeRef}", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Text(
                        text = "${escrow.commodity} | ${"%,d".format(escrow.volumeBbls)} bbls",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$${"%,.0f".format(escrow.totalNotionalUSD)}",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(stageColor.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = escrow.stage.name.replace("_", " "),
                            color = stageColor,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Parties
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Buyer: ${escrow.buyer}", color = TextMuted, fontSize = 10.sp)
                Text(text = "Seller: ${escrow.seller}", color = TextMuted, fontSize = 10.sp)
            }

            // Exception notes if any
            val note = escrow.exceptionNote
            if (note != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(PriceDownRed.copy(alpha = 0.15f))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = PriceDownRed, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = note, color = Color.White, fontSize = 10.sp, lineHeight = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dual Officer Authorization Panel
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TerminalBackground)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Treasury Officer status
                OfficerStatusPill(
                    role = "TREASURY OFFICER",
                    approved = escrow.treasuryDualApproved,
                    onSign = { onApprove(escrow.escrowId, true, false) },
                    enabled = !escrow.treasuryDualApproved && escrow.stage != EscrowStage.SETTLED_DVP
                )

                // Risk Officer status
                OfficerStatusPill(
                    role = "RISK OFFICER",
                    approved = escrow.riskDualApproved,
                    onSign = { onApprove(escrow.escrowId, false, true) },
                    enabled = !escrow.riskDualApproved && escrow.stage != EscrowStage.SETTLED_DVP
                )
            }
        }
    }
}

@Composable
private fun OfficerStatusPill(
    role: String,
    approved: Boolean,
    onSign: () -> Unit,
    enabled: Boolean
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (approved) {
            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = PriceUpGreen, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text(text = role, color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text(text = "SIGNED / OK", color = PriceUpGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        } else {
            Icon(imageVector = Icons.Default.HourglassTop, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text(text = role, color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                if (enabled) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(WarningAmber.copy(alpha = 0.2f))
                            .clickable { onSign() }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                            .testTag("sign_${role.lowercase().replace(" ", "_")}")
                    ) {
                        Text(text = "SIGN OFF", color = WarningAmber, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text(text = "PENDING", color = WarningAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
