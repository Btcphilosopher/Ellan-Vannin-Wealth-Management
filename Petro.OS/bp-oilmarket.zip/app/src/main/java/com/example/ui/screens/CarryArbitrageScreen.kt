package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.FinancialEngine
import com.example.model.CarryTradeSetup
import com.example.ui.theme.*

@Composable
fun CarryArbitrageScreen(
    carrySetups: List<CarryTradeSetup>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Formula banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.SyncAlt, contentDescription = null, tint = BPGreen, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CARRY TRADE & FUNDING ARBITRAGE ENGINE",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(BPGreen.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "CONTANGO/CARRY ACTIVE", color = BPGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Net Carry = Forward Price − Spot Cost − Financing − Storage − Insurance − Transport − Handling − Hedging",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Section Title: Strategy Blotter
        item {
            Text(
                text = "COMMODITY CASH-AND-CARRY STRATEGIES",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(carrySetups) { setup ->
            val result = FinancialEngine.calculateCarry(setup)
            CarryTradeDetailedCard(setup = setup, result = result)
        }
    }
}

@Composable
private fun CarryTradeDetailedCard(
    setup: CarryTradeSetup,
    result: FinancialEngine.CarryResult
) {
    val isPositiveYield = result.annualisedYieldPct >= 0

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = setup.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Volume: ${"%,d".format(setup.volumeBbls)} bbls | Holding Period: ${setup.forwardDays} Days",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Annualised Net Yield", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "${"%.2f".format(result.annualisedYieldPct)}%",
                        color = if (isPositiveYield) PriceUpGreen else PriceDownRed,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Cost Decomposition Grid
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TerminalBackground)
                    .padding(8.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Spot Purchase Price:", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "$${"%.2f".format(setup.spotPrice)}/bbl", color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Forward Sale Price:", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "$${"%.2f".format(setup.forwardPrice)}/bbl (Gross: +$${"%.2f".format(result.grossCarryPerBbl)})", color = BPGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Financing Cost (${setup.financingRatePct}% SOFR):", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "-$${"%.2f".format(result.financingCostPerBbl)}/bbl", color = WarningAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Storage & Tank Rental:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "-$${"%.2f".format(result.storageCostPerBbl)}/bbl", color = WarningAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Insurance, Handling & Freight:", color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(text = "-$${"%.2f".format(result.insuranceCostPerBbl + result.otherCostsPerBbl)}/bbl", color = WarningAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    HorizontalDivider(color = TerminalBorder, thickness = 1.dp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Net Carry Profit:", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Text(
                            text = "$${"%.2f".format(result.netCarryPerBbl)}/bbl ($${"%,.0f".format(result.totalNetCarryUSD)} total)",
                            color = if (result.netCarryPerBbl >= 0) PriceUpGreen else PriceDownRed,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Break-even and Capital Required
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Break-Even Exit: $${"%.2f".format(result.breakEvenPrice)}/bbl",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Capital: $${"%,.1f".format(result.capitalRequiredUSD / 1000000.0)}M",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Stress (+100bps): -$${"%,.0f".format(result.stressLoss100BpsUSD)}",
                    color = PriceDownRed,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
