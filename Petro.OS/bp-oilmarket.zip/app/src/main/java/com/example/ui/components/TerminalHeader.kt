package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TerminalHeader(
    isLiveStreaming: Boolean,
    latencyMs: Int,
    commandQuery: String,
    statusMessage: String?,
    onQueryChange: (String) -> Unit,
    onExecuteCommand: (String) -> Unit,
    onToggleLive: () -> Unit,
    onStepTick: () -> Unit,
    onClearStatus: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(width = 1.dp, color = TerminalBorder)
            .padding(top = 8.dp, bottom = 8.dp)
    ) {
        // Top Ticker / Platform Identity Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isLiveStreaming) BPGreen else WarningAmber)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "BP OILMARKET",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 1.sp
                )
                Text(
                    text = " // TERMINAL v3.8",
                    color = BPGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Latency and desk indicators
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${latencyMs}ms",
                    color = BPGreen,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "| LDN•HOU•SGP",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(8.dp))

                // Step Tick Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalSurfaceVariant)
                        .clickable { onStepTick() }
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                        .testTag("step_tick_button")
                ) {
                    Text(
                        text = "STEP",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Live Feed Toggle
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isLiveStreaming) BPGreenDark else TerminalSurfaceVariant)
                        .clickable { onToggleLive() }
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                        .testTag("toggle_live_button")
                ) {
                    Text(
                        text = if (isLiveStreaming) "FEED: ON" else "PAUSED",
                        color = if (isLiveStreaming) BPGreenLight else WarningAmber,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Benchmark Rates Tape
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TerminalBackground)
                .padding(horizontal = 12.dp, vertical = 3.dp)
                .horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TickerPill("SOFR", "5.31%", PriceUpGreen)
            TickerPill("SONIA", "5.18%", PriceUpGreen)
            TickerPill("€STR", "3.89%", PriceUpGreen)
            TickerPill("BRENT", "$84.28", PriceUpGreen)
            TickerPill("WTI", "$79.82", PriceDownRed)
            TickerPill("DUBAI", "$82.42", PriceUpGreen)
            TickerPill("ULSD", "$112.55", PriceUpGreen)
            TickerPill("CRACK 3:2:1", "$26.80", PriceUpGreen)
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Command Palette & Search Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .background(TerminalBackground)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "CMD>",
                        color = BPGreen,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    BasicTextField(
                        value = commandQuery,
                        onValueChange = onQueryChange,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("command_input"),
                        textStyle = LocalTextStyle.current.copy(
                            color = Color.White,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = {
                            if (commandQuery.isNotBlank()) onExecuteCommand(commandQuery)
                        }),
                        decorationBox = { innerTextField ->
                            if (commandQuery.isEmpty()) {
                                Text(
                                    text = "Type command or symbol (e.g. PHYS, TREAS, BRENT, CDO)...",
                                    color = TextMuted,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            innerTextField()
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = { if (commandQuery.isNotBlank()) onExecuteCommand(commandQuery) },
                modifier = Modifier
                    .size(32.dp)
                    .background(TerminalSurfaceVariant, RoundedCornerShape(4.dp))
                    .testTag("command_submit_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Execute Command",
                    tint = BPGreen,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Quick Command Shortcuts
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("PHYS", "TREAS", "MM", "DERIV", "CARRY", "CDO", "ESCROW", "RISK", "AUDIT").forEach { cmd ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(TerminalBackground)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(3.dp))
                        .clickable { onExecuteCommand(cmd) }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = cmd,
                        color = TextSecondary,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Notification Banner
        if (statusMessage != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BPGreenDark.copy(alpha = 0.85f))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = statusMessage,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Dismiss",
                    tint = Color.White,
                    modifier = Modifier
                        .size(14.dp)
                        .clickable { onClearStatus() }
                )
            }
        }
    }
}

@Composable
private fun TickerPill(symbol: String, value: String, color: Color) {
    Row(
        modifier = Modifier.padding(end = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$symbol:",
            color = TextSecondary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = value,
            color = color,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}
