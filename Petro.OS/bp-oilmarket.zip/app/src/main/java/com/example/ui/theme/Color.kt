package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// BP Institutional Terminal Palette
val TerminalBackground = Color(0xFF090D14)
val TerminalSurface = Color(0xFF0E1523)
val TerminalSurfaceVariant = Color(0xFF151F32)
val TerminalBorder = Color(0xFF1E2D47)
val TerminalCard = Color(0xFF121B2B)

// Accents
val BPGreen = Color(0xFF00A859)
val BPGreenLight = Color(0xFF10B981)
val BPGreenDark = Color(0xFF007A3D)
val BPGold = Color(0xFFE5A912)

// Market Indicators
val PriceUpGreen = Color(0xFF00C853)
val PriceDownRed = Color(0xFFFF334B)
val WarningAmber = Color(0xFFF59E0B)
val InfoCyan = Color(0xFF00B4D8)
val NeutralBlue = Color(0xFF3B82F6)

// Typography Colors
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextOnAccent = Color(0xFF041A0E)
