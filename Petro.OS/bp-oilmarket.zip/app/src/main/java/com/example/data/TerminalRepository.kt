package com.example.data

import com.example.engine.FinancialEngine
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class TerminalRepository {

    private val _quotes = MutableStateFlow<List<MarketQuote>>(emptyList())
    val quotes: StateFlow<List<MarketQuote>> = _quotes.asStateFlow()

    private val _orderBooks = MutableStateFlow<Map<String, OrderBook>>(emptyMap())
    val orderBooks: StateFlow<Map<String, OrderBook>> = _orderBooks.asStateFlow()

    private val _cargos = MutableStateFlow<List<PhysicalCargo>>(emptyList())
    val cargos: StateFlow<List<PhysicalCargo>> = _cargos.asStateFlow()

    private val _facilities = MutableStateFlow<List<FinancingFacility>>(emptyList())
    val facilities: StateFlow<List<FinancingFacility>> = _facilities.asStateFlow()

    private val _moneyMarketQuotes = MutableStateFlow<List<MoneyMarketQuote>>(emptyList())
    val moneyMarketQuotes: StateFlow<List<MoneyMarketQuote>> = _moneyMarketQuotes.asStateFlow()

    private val _yieldCurve = MutableStateFlow<List<YieldCurvePoint>>(emptyList())
    val yieldCurve: StateFlow<List<YieldCurvePoint>> = _yieldCurve.asStateFlow()

    private val _derivatives = MutableStateFlow<List<DerivativeContract>>(emptyList())
    val derivatives: StateFlow<List<DerivativeContract>> = _derivatives.asStateFlow()

    private val _carrySetups = MutableStateFlow<List<CarryTradeSetup>>(emptyList())
    val carrySetups: StateFlow<List<CarryTradeSetup>> = _carrySetups.asStateFlow()

    private val _cdoPool = MutableStateFlow<StructuredCreditPool?>(null)
    val cdoPool: StateFlow<StructuredCreditPool?> = _cdoPool.asStateFlow()

    private val _tokenisedAssets = MutableStateFlow<List<TokenisedAsset>>(emptyList())
    val tokenisedAssets: StateFlow<List<TokenisedAsset>> = _tokenisedAssets.asStateFlow()

    private val _escrowRecords = MutableStateFlow<List<EscrowRecord>>(emptyList())
    val escrowRecords: StateFlow<List<EscrowRecord>> = _escrowRecords.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AccountingLog>>(emptyList())
    val auditLogs: StateFlow<List<AccountingLog>> = _auditLogs.asStateFlow()

    private val _riskSummary = MutableStateFlow<RiskSummary>(
        RiskSummary(
            totalNetExposureUSD = 184500000.0,
            var95DailyUSD = 3420000.0,
            expectedShortfallUSD = 4280000.0,
            liquidityReserveUSD = 485000000.0,
            stressedLossUSD = 12900000.0,
            marginUtilizationPct = 42.6,
            limitBreached = false
        )
    )
    val riskSummary: StateFlow<RiskSummary> = _riskSummary.asStateFlow()

    val commodityGrades = listOf(
        CommodityGrade("BRENT", "Brent Dated", "ICE Brent", 38.3, 0.40, "North Sea (Sullom Voe)", 0.0, 600000),
        CommodityGrade("FORTIES", "Forties Blend", "Dated Brent", 40.3, 0.60, "Hound Point UK", 0.45, 600000),
        CommodityGrade("EKOFISK", "Ekofisk Crude", "Dated Brent", 37.5, 0.22, "Teesside UK", 0.95, 600000),
        CommodityGrade("WTI", "WTI Cushing", "NYMEX WTI", 40.8, 0.20, "Cushing OK", -4.45, 100000),
        CommodityGrade("DUBAI", "Dubai Crude", "Platts Dubai", 31.0, 2.00, "Fateh Terminal", -1.85, 500000),
        CommodityGrade("ULSD", "Ultra-Low Sulfur Diesel", "ICE Gasoil", 35.0, 0.001, "ARA Hub", 28.25, 200000, "$/MT"),
        CommodityGrade("JET_A1", "Aviation Jet Fuel A-1", "Platts Jet", 42.0, 0.015, "Rotterdam", 33.95, 200000, "$/MT")
    )

    init {
        seedInitialFixtures()
    }

    private fun seedInitialFixtures() {
        val now = System.currentTimeMillis()

        _quotes.value = listOf(
            MarketQuote("BRENT_DATED", "Brent Dated Platts", "CRUDE", 84.25, 84.30, 84.28, 0.85, 1.02, 1420000, 84.90, 83.40, now),
            MarketQuote("WTI_CUSH", "WTI Light Sweet", "CRUDE", 79.80, 79.85, 79.82, -0.42, -0.52, 1850000, 80.60, 79.20, now),
            MarketQuote("DUBAI_MKT", "Dubai/Oman Fateh", "CRUDE", 82.40, 82.46, 82.42, 0.35, 0.43, 890000, 82.95, 81.80, now),
            MarketQuote("ULSD_10PPM", "ULSD Diesel 10ppm", "REFINED", 112.50, 112.65, 112.55, 1.40, 1.26, 620000, 113.10, 110.80, now),
            MarketQuote("JET_A1", "Aviation Jet A-1", "REFINED", 118.20, 118.40, 118.30, 0.95, 0.81, 410000, 119.00, 117.10, now),
            MarketQuote("RBOB_GAS", "RBOB Gasoline NYMEX", "REFINED", 104.10, 104.22, 104.15, -0.65, -0.62, 940000, 105.30, 103.80, now),
            MarketQuote("VLSFO_05", "Marine Fuel 0.5% S", "REFINED", 89.60, 89.75, 89.68, 0.20, 0.22, 510000, 90.20, 89.10, now)
        )

        regenerateOrderBooks()

        _cargos.value = listOf(
            PhysicalCargo("CRG-BP-881", "BRENT", "M/T British Explorer", 1000000, "10-15 Nov", "Sullom Voe", "Rotterdam", true, CargoStatus.IN_TRANSIT, 1450000.0, 180000.0, "BP Trading", "Equinor"),
            PhysicalCargo("CRG-BP-904", "WTI", "M/T Eagle Valence", 600000, "18-22 Nov", "Houston Terminal", "Antwerp", true, CargoStatus.LOADING, 920000.0, 110000.0, "TotalEnergies", "BP Trading"),
            PhysicalCargo("CRG-BP-922", "DUBAI", "M/T Olympic Loyalty", 2000000, "25-30 Nov", "Fujairah SPM", "Singapore Jurong", false, CargoStatus.NOMINATED, 2750000.0, 320000.0, "BP Singapore", "ADNOC"),
            PhysicalCargo("CRG-BP-935", "ULSD", "M/T Stena Premium", 300000, "02-05 Dec", "Rotterdam Botlek", "Hamburg", true, CargoStatus.SETTLED, 380000.0, 45000.0, "Shell Global", "BP Trading")
        )

        _facilities.value = listOf(
            FinancingFacility("FAC-RCF-01", "Syndicated Revolving Credit Facility", "RCF", 5000000000.0, 1850000000.0, "SOFR", 65.0, null, DayCountConvention.ACT_360, "2028-10-15", 8120000.0, 2.50, 1.62),
            FinancingFacility("FAC-USCP-02", "Tier-1 US Commercial Paper Program", "COMMERCIAL_PAPER", 2500000000.0, 1200000000.0, "SOFR", 45.0, 5.38, DayCountConvention.ACT_360, "2027-04-30", 4950000.0, 2.50, 1.62),
            FinancingFacility("FAC-INV-03", "Inventory Borrowing Base (Cushing/ARA)", "INVENTORY_BORROWING_BASE", 1500000000.0, 640000000.0, "SOFR", 95.0, null, DayCountConvention.ACT_360, "2026-12-31", 2850000.0, 2.75, 1.70),
            FinancingFacility("FAC-TERM-04", "Bilateral Green Transition Term Loan", "TERM_LOAN", 1000000000.0, 1000000000.0, "SONIA", 80.0, 5.25, DayCountConvention.ACT_365, "2031-06-30", 3910000.0, 2.50, 1.62)
        )

        _moneyMarketQuotes.value = listOf(
            MoneyMarketQuote("O/N", "SOFR", 5.31, 5.33, 450000000.0, 2.0),
            MoneyMarketQuote("T/N", "SOFR", 5.32, 5.34, 380000000.0, 2.5),
            MoneyMarketQuote("S/N", "SOFR", 5.32, 5.35, 300000000.0, 3.0),
            MoneyMarketQuote("1W", "SOFR", 5.30, 5.33, 250000000.0, 4.0),
            MoneyMarketQuote("1M", "SOFR", 5.26, 5.30, 200000000.0, 6.0),
            MoneyMarketQuote("3M", "SOFR", 5.18, 5.22, 180000000.0, 8.0),
            MoneyMarketQuote("6M", "SOFR", 5.05, 5.10, 120000000.0, 10.0),
            MoneyMarketQuote("O/N", "SONIA", 5.18, 5.20, 250000000.0, 2.0),
            MoneyMarketQuote("1M", "SONIA", 5.14, 5.17, 150000000.0, 5.0)
        )

        _yieldCurve.value = listOf(
            YieldCurvePoint(1, "1M", 5.32, 5.32, 0.9956, 420.0),
            YieldCurvePoint(3, "3M", 5.24, 5.25, 0.9870, 1250.0),
            YieldCurvePoint(6, "6M", 5.10, 5.12, 0.9748, 2450.0),
            YieldCurvePoint(12, "1Y", 4.88, 4.90, 0.9523, 4800.0),
            YieldCurvePoint(24, "2Y", 4.52, 4.55, 0.9135, 9200.0),
            YieldCurvePoint(60, "5Y", 4.18, 4.22, 0.8114, 21500.0),
            YieldCurvePoint(120, "10Y", 4.12, 4.15, 0.6623, 38900.0)
        )

        _derivatives.value = listOf(
            DerivativeContract("DRV-BRENT-SWAP-01", "BRENT_SWAP", "BRENT_DATED", 83.50, 84.28, 500000, "Q1-2027", 75, 26.5, 390000.0, 0.98, 0.012, 4800.0, -1200.0),
            DerivativeContract("DRV-BRENT-CAL-02", "CALENDAR_SPREAD", "BRENT_M1_M3", 1.25, 1.45, 1000000, "M1/M3", 60, 22.0, 200000.0, 0.85, 0.008, 3100.0, -850.0),
            DerivativeContract("DRV-CRACK-321-03", "CRACK_SPREAD", "3:2:1 REFINERY", 24.50, 26.80, 300000, "Dec-2026", 45, 34.0, 690000.0, 0.92, 0.015, 2900.0, -920.0),
            DerivativeContract("DRV-BRENT-CALL-04", "CALL_OPTION", "BRENT_DATED", 85.00, 84.28, 250000, "Dec-2026", 45, 27.5, 312500.0, 0.48, 0.042, 6200.0, -2100.0),
            DerivativeContract("DRV-WTI-PUT-05", "PUT_OPTION", "WTI_CUSH", 78.00, 79.82, 250000, "Dec-2026", 45, 31.0, 245000.0, -0.38, 0.038, 5900.0, -1850.0)
        )

        _carrySetups.value = listOf(
            CarryTradeSetup("CARRY-CUSHING-01", "Cushing Tank Contango Arbitrage (M1/M4)", 79.82, 82.60, 90, 500000, 5.35, 0.42, 0.08, 0.15, 0.10),
            CarryTradeSetup("CARRY-ROTTERDAM-02", "Rotterdam Botlek ULSD Storage Carry", 112.55, 116.20, 60, 200000, 5.25, 0.55, 0.12, 0.20, 0.15),
            CarryTradeSetup("CARRY-FUJAIRAH-03", "Fujairah VLSFO Bunkering Reverse Carry", 89.68, 88.40, 45, 350000, 5.40, 0.48, 0.09, 0.18, 0.12)
        )

        _cdoPool.value = StructuredCreditPool(
            poolId = "BP-SPV-ENERGY-2026-I",
            spvName = "BP Energy Structured Credit SPV I LLC (Delaware)",
            totalCollateralUSD = 250000000.0,
            underlyingAssetCount = 42,
            seniorTranche = CDOTranche("Tranche A Senior", "AAA", 187500000.0, 115.0, 75.0),
            mezzTranche = CDOTranche("Tranche B Mezzanine", "BBB", 37500000.0, 285.0, 15.0),
            equityTranche = CDOTranche("Tranche C Equity / First-Loss", "UNRATED", 25000000.0, 850.0, 10.0),
            reserveAccountUSD = 5000000.0,
            simulatedDefaultRatePct = 2.5
        )

        _tokenisedAssets.value = listOf(
            TokenisedAsset("TOK-BPOIL-ROTTERDAM", "BPOIL-ROT", "BP Rotterdam Certified Physical Oil Barrel", "PHYSICAL_INVENTORY", 1000000, "BP Europoort Tank 402, Netherlands", "SGS-NL-99410", 84.28, 1000000, 850000, true),
            TokenisedAsset("TOK-BPOIL-CUSHING", "BPOIL-CSH", "BP Cushing Terminal WTI Storage Receipt", "PHYSICAL_INVENTORY", 750000, "Enterprise Products Deeprock Cushing", "SGS-US-88129", 79.82, 750000, 620000, true),
            TokenisedAsset("TOK-BPOIL-RECV-Q4", "BPOIL-REC", "BP Enforceable Refinery Trade Receivable Note", "TRADE_RECEIVABLE", 500000, "Citigroup Custody Escrow", "PWC-REC-77301", 98.45, 500000, 500000, true),
            TokenisedAsset("TOK-BPOIL-CDO-AAA", "BPOIL-SNA", "BP Energy SPV-I Senior Tranche A Token", "CDO_TRANCHE", 1875000, "Wilmington Trust SPV Custody", "MOODYS-AAA-829", 100.25, 1875000, 1875000, true)
        )

        _escrowRecords.value = listOf(
            EscrowRecord("ESC-2026-0091", "TRD-88201", "TotalEnergies Trading", "BP Oil International", "Brent Dated", 500000, 42140000.0, EscrowStage.T1_FUNDS_RESERVED, now - 18 * 3600000L, now + 30 * 3600000L, treasuryDualApproved = true, riskDualApproved = false, sgsInspectionOk = true),
            EscrowRecord("ESC-2026-0089", "TRD-88195", "BP Oil International", "ConocoPhillips", "WTI Cushing", 300000, 23946000.0, EscrowStage.T2_INSPECTION_CONFIRMED, now - 36 * 3600000L, now + 12 * 3600000L, treasuryDualApproved = true, riskDualApproved = false, sgsInspectionOk = true),
            EscrowRecord("ESC-2026-0087", "TRD-88140", "Glencore Energy UK", "BP Oil International", "ULSD Diesel 10ppm", 250000, 28137500.0, EscrowStage.SETTLED_DVP, now - 52 * 3600000L, now - 4 * 3600000L, treasuryDualApproved = true, riskDualApproved = true, sgsInspectionOk = true),
            EscrowRecord("ESC-2026-0085", "TRD-88092", "Trafigura Pte Ltd", "BP Singapore", "Dubai Crude", 500000, 41210000.0, EscrowStage.EXCEPTION_HOLD, now - 28 * 3600000L, now + 20 * 3600000L, treasuryDualApproved = false, riskDualApproved = false, sgsInspectionOk = false, exceptionNote = "SGS Certificate #SGS-DXB-401 reports 0.15% API gravity mismatch against contract specifications.")
        )

        _orders.value = listOf(
            Order("ORD-2026-1049", "BRENT_DATED", OrderSide.BUY, OrderType.LIMIT, 84.10, 250000, 250000, "Shell Western Supply", "15-20 Nov", "Sullom Voe", OrderStatus.FILLED, now - 7200000L),
            Order("ORD-2026-1050", "WTI_CUSH", OrderSide.SELL, OrderType.LIMIT, 79.95, 100000, 50000, "Vitol Inc", "20-25 Nov", "Cushing OK", OrderStatus.PARTIALLY_FILLED, now - 3600000L),
            Order("ORD-2026-1051", "ULSD_10PPM", OrderSide.BUY, OrderType.MARKETABLE_LIMIT, 112.50, 150000, 0, "BP Products North America", "01-05 Dec", "Rotterdam", OrderStatus.ACTIVE, now - 1800000L)
        )

        addAuditLog("TRD-INIT-001", "CASH_OPERATING_USD", "INVENTORY_CRUDE_BRENT", 84280000.0, "Physical Crude Cargo Purchase 1,000,000 bbls Sullom Voe")
        addAuditLog("RCF-DRAW-002", "CASH_OPERATING_USD", "CREDIT_FACILITY_RCF", 150000000.0, "RCF Liquidity Drawdown to support T+2 Escrow reservations")
        addAuditLog("ESC-RSV-003", "ESCROW_RESTRICTED_CASH", "CASH_OPERATING_USD", 42140000.0, "T+1 Pre-funding Escrow Reservation for ESC-2026-0091")
    }

    private fun regenerateOrderBooks() {
        val map = mutableMapOf<String, OrderBook>()
        for (q in _quotes.value) {
            val bids = mutableListOf<OrderBookLevel>()
            val asks = mutableListOf<OrderBookLevel>()

            for (i in 0 until 5) {
                val bidPx = q.bid - i * 0.05
                val bidQty = 50000L + (i * 25000L) + (Random.nextInt(10) * 10000L)
                val askPx = q.ask + i * 0.05
                val askQty = 45000L + (i * 20000L) + (Random.nextInt(10) * 10000L)

                bids.add(OrderBookLevel(bidPx, bidQty, 3 + i, 0.4f + i * 0.12f))
                asks.add(OrderBookLevel(askPx, askQty, 2 + i, 0.4f + i * 0.12f))
            }
            map[q.symbol] = OrderBook(q.symbol, bids, asks, System.currentTimeMillis())
        }
        _orderBooks.value = map
    }

    /**
     * Live Market Tick Simulation
     */
    fun tickMarket() {
        val now = System.currentTimeMillis()
        val currentQuotes = _quotes.value.map { q ->
            val delta = (Random.nextDouble() - 0.49) * 0.12
            val newLast = max(10.0, String.format("%.2f", q.last + delta).toDouble())
            val spread = 0.05
            val newBid = String.format("%.2f", newLast - spread / 2.0).toDouble()
            val newAsk = String.format("%.2f", newLast + spread / 2.0).toDouble()
            val newChange = newLast - (q.last - q.change)
            val newChangePct = (newChange / (newLast - newChange)) * 100.0
            val addedVol = Random.nextLong(5000, 35000)

            q.copy(
                bid = newBid,
                ask = newAsk,
                last = newLast,
                change = String.format("%.2f", newChange).toDouble(),
                changePct = String.format("%.2f", newChangePct).toDouble(),
                volume = q.volume + addedVol,
                high = max(q.high, newLast),
                low = min(q.low, newLast),
                timestamp = now
            )
        }
        _quotes.value = currentQuotes
        regenerateOrderBooks()

        // Recalculate derivative present values
        val brentQuote = currentQuotes.find { it.symbol == "BRENT_DATED" }?.last ?: 84.28
        val wtiQuote = currentQuotes.find { it.symbol == "WTI_CUSH" }?.last ?: 79.82
        val updatedDerivatives = _derivatives.value.map { d ->
            val currentUnderlying = if (d.underlying.contains("WTI")) wtiQuote else brentQuote
            val greeks = FinancialEngine.calculateBlack76(
                isCall = d.type.contains("CALL"),
                forwardPrice = currentUnderlying,
                strike = d.strikePrice,
                riskFreeRatePct = 5.30,
                volatilityPct = d.impliedVolPct,
                daysToExpiry = d.expiryDays
            )
            val pv = if (d.type.contains("OPTION")) {
                greeks.price * d.notionalBbls
            } else {
                (currentUnderlying - d.strikePrice) * d.notionalBbls
            }
            d.copy(
                spotPrice = currentUnderlying,
                presentValueUSD = pv,
                delta = greeks.delta,
                gamma = greeks.gamma,
                vega = greeks.vega,
                theta = greeks.thetaPerDay
            )
        }
        _derivatives.value = updatedDerivatives

        // Recalculate Risk VaR
        val netExposure = 184500000.0 + (brentQuote - 84.28) * 1000000.0
        val (var95, cvar) = FinancialEngine.calculateVaR(netExposure, 28.5)
        _riskSummary.value = _riskSummary.value.copy(
            totalNetExposureUSD = netExposure,
            var95DailyUSD = var95,
            expectedShortfallUSD = cvar
        )
    }

    /**
     * Submit an Institutional Order
     */
    fun submitOrder(
        symbol: String,
        side: OrderSide,
        type: OrderType,
        price: Double,
        quantityBbls: Long,
        counterparty: String,
        laycan: String,
        location: String
    ): Order {
        val now = System.currentTimeMillis()
        val orderId = "ORD-${now % 1000000}"
        val newOrder = Order(
            orderId = orderId,
            symbol = symbol,
            side = side,
            type = type,
            price = price,
            quantityBbls = quantityBbls,
            filledBbls = if (type == OrderType.MARKETABLE_LIMIT) quantityBbls else 0,
            counterparty = counterparty,
            laycanWindow = laycan,
            deliveryLocation = location,
            status = if (type == OrderType.MARKETABLE_LIMIT) OrderStatus.FILLED else OrderStatus.ACTIVE,
            timestamp = now
        )

        _orders.value = listOf(newOrder) + _orders.value

        if (type == OrderType.MARKETABLE_LIMIT) {
            val notional = price * quantityBbls
            addAuditLog(
                transactionRef = orderId,
                debitAccount = if (side == OrderSide.BUY) "INVENTORY_PHYSICAL_CRUDE" else "RECEIVABLES_COUNTERPARTY",
                creditAccount = if (side == OrderSide.BUY) "PAYABLES_COUNTERPARTY" else "INVENTORY_PHYSICAL_CRUDE",
                amountUSD = notional,
                memo = "Executed ${side.name} $quantityBbls bbls $symbol @ $$price ($location)"
            )
        }

        return newOrder
    }

    /**
     * Dual Officer Escrow Authorization (Treasury + Risk)
     */
    fun approveEscrowOfficer(escrowId: String, isTreasury: Boolean, isRisk: Boolean) {
        val current = _escrowRecords.value.toMutableList()
        val index = current.indexOfFirst { it.escrowId == escrowId }
        if (index != -1) {
            val record = current[index]
            val newTreasury = record.treasuryDualApproved || isTreasury
            val newRisk = record.riskDualApproved || isRisk
            val bothApproved = newTreasury && newRisk && record.sgsInspectionOk

            val newStage = if (bothApproved && record.stage == EscrowStage.T2_INSPECTION_CONFIRMED) {
                EscrowStage.SETTLED_DVP
            } else if (bothApproved && record.stage == EscrowStage.T0_RECORDED) {
                EscrowStage.T1_FUNDS_RESERVED
            } else {
                record.stage
            }

            current[index] = record.copy(
                treasuryDualApproved = newTreasury,
                riskDualApproved = newRisk,
                stage = newStage
            )
            _escrowRecords.value = current

            if (newStage == EscrowStage.SETTLED_DVP) {
                addAuditLog(
                    transactionRef = escrowId,
                    debitAccount = "CASH_SETTLED_PROCEEDS",
                    creditAccount = "ESCROW_RESTRICTED_CASH",
                    amountUSD = record.totalNotionalUSD,
                    memo = "48-Hour T+2 DvP Final Settlement Released for ${record.tradeRef}"
                )
            }
        }
    }

    /**
     * Treasury Facility Drawdown / Repayment
     */
    fun adjustFacility(facilityId: String, amountUSD: Double, isDrawdown: Boolean) {
        val current = _facilities.value.toMutableList()
        val index = current.indexOfFirst { it.facilityId == facilityId }
        if (index != -1) {
            val f = current[index]
            val newDrawn = if (isDrawdown) {
                min(f.committedUSD, f.drawnUSD + amountUSD)
            } else {
                max(0.0, f.drawnUSD - amountUSD)
            }
            current[index] = f.copy(drawnUSD = newDrawn)
            _facilities.value = current

            addAuditLog(
                transactionRef = facilityId,
                debitAccount = if (isDrawdown) "CASH_OPERATING_USD" else "DEBT_OBLIGATION_FACILITY",
                creditAccount = if (isDrawdown) "DEBT_OBLIGATION_FACILITY" else "CASH_OPERATING_USD",
                amountUSD = amountUSD,
                memo = "${if (isDrawdown) "Drawdown" else "Repayment"} on ${f.title} ($amountUSD USD)"
            )
        }
    }

    /**
     * Run Macro Stress Scenario
     */
    fun runStressScenario(scenarioName: String) {
        when (scenarioName) {
            "SUPPLY_CRUNCH" -> {
                // +25% Crude spike, +150 bps funding widen
                _quotes.value = _quotes.value.map {
                    val newPrice = String.format("%.2f", it.last * 1.25).toDouble()
                    it.copy(last = newPrice, bid = newPrice - 0.10, ask = newPrice + 0.10)
                }
                _riskSummary.value = _riskSummary.value.copy(
                    totalNetExposureUSD = _riskSummary.value.totalNetExposureUSD * 1.25,
                    stressedLossUSD = 34500000.0,
                    marginUtilizationPct = 78.4,
                    limitBreached = true
                )
            }
            "RECESSION_DEMAND" -> {
                // -30% Crude crash
                _quotes.value = _quotes.value.map {
                    val newPrice = String.format("%.2f", it.last * 0.70).toDouble()
                    it.copy(last = newPrice, bid = newPrice - 0.10, ask = newPrice + 0.10)
                }
                _riskSummary.value = _riskSummary.value.copy(
                    totalNetExposureUSD = _riskSummary.value.totalNetExposureUSD * 0.70,
                    stressedLossUSD = 28900000.0,
                    marginUtilizationPct = 64.2,
                    limitBreached = false
                )
            }
            "STORAGE_BOTTLENECK" -> {
                // Super contango: carry becomes extremely profitable for tank operators
                _carrySetups.value = _carrySetups.value.map {
                    it.copy(forwardPrice = it.forwardPrice + 5.50)
                }
            }
        }
        addAuditLog(
            transactionRef = "STRESS-SCN-${System.currentTimeMillis() % 10000}",
            debitAccount = "RISK_CAPITAL_ALLOCATION",
            creditAccount = "STRESS_LOSS_RESERVE",
            amountUSD = _riskSummary.value.stressedLossUSD,
            memo = "Simulated Stress Scenario: $scenarioName"
        )
    }

    private fun addAuditLog(transactionRef: String, debitAccount: String, creditAccount: String, amountUSD: Double, memo: String) {
        val now = System.currentTimeMillis()
        val raw = "$now|$transactionRef|$debitAccount|$creditAccount|$amountUSD|$memo"
        val hash = sha256(raw)
        val log = AccountingLog(
            id = "AUD-${now % 10000000}",
            timestamp = now,
            transactionRef = transactionRef,
            debitAccount = debitAccount,
            creditAccount = creditAccount,
            amountUSD = amountUSD,
            memo = memo,
            cryptographicHash = hash
        )
        _auditLogs.value = listOf(log) + _auditLogs.value
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
