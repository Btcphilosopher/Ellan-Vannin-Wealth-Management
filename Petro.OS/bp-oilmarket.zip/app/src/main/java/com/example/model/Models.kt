package com.example.model

enum class MarketStatus { OPEN, AUCTION, CLOSED, HALTED }

enum class OrderSide { BUY, SELL }

enum class OrderType { LIMIT, MARKETABLE_LIMIT, RFQ }

enum class OrderStatus { PENDING, ACTIVE, PARTIALLY_FILLED, FILLED, CANCELLED, REJECTED }

enum class CargoStatus { NOMINATED, LOADING, IN_TRANSIT, DISCHARGED, SETTLED }

enum class DayCountConvention { ACT_360, ACT_365, THIRTY_360 }

enum class EscrowStage {
    T0_RECORDED,
    T1_FUNDS_RESERVED,
    T2_INSPECTION_CONFIRMED,
    SETTLED_DVP,
    EXCEPTION_HOLD
}

data class CommodityGrade(
    val code: String,
    val name: String,
    val benchmark: String,
    val apiGravity: Double,
    val sulfurPct: Double,
    val deliveryRegion: String,
    val differentialBbl: Double,
    val standardCargoBbl: Long,
    val unit: String = "$/bbl"
)

data class MarketQuote(
    val symbol: String,
    val name: String,
    val category: String, // CRUDE, REFINED, BENCHMARK
    var bid: Double,
    var ask: Double,
    var last: Double,
    var change: Double,
    var changePct: Double,
    var volume: Long,
    var high: Double,
    var low: Double,
    var timestamp: Long,
    val unit: String = "$/bbl",
    val status: MarketStatus = MarketStatus.OPEN
)

data class OrderBookLevel(
    val price: Double,
    val quantityBbls: Long,
    val orderCount: Int,
    val depthPct: Float
)

data class OrderBook(
    val symbol: String,
    val bids: List<OrderBookLevel>,
    val asks: List<OrderBookLevel>,
    val timestamp: Long
)

data class Order(
    val orderId: String,
    val symbol: String,
    val side: OrderSide,
    val type: OrderType,
    val price: Double,
    val quantityBbls: Long,
    val filledBbls: Long,
    val counterparty: String,
    val laycanWindow: String,
    val deliveryLocation: String,
    val status: OrderStatus,
    val timestamp: Long
)

data class PhysicalCargo(
    val cargoId: String,
    val gradeCode: String,
    val vesselName: String,
    val quantityBbls: Long,
    val laycanWindow: String,
    val portOfOrigin: String,
    val destinationPort: String,
    val sgsInspectionVerified: Boolean,
    val status: CargoStatus,
    val freightCostUSD: Double,
    val storageCostUSD: Double,
    val buyer: String,
    val seller: String
)

data class FinancingFacility(
    val facilityId: String,
    val title: String,
    val type: String, // RCF, TERM_LOAN, COMMERCIAL_PAPER, INVENTORY_BORROWING_BASE
    val committedUSD: Double,
    var drawnUSD: Double,
    val benchmark: String, // SOFR, SONIA, ESTR
    val spreadBps: Double,
    val fixedRatePct: Double? = null,
    val dayCount: DayCountConvention = DayCountConvention.ACT_360,
    val maturityDate: String,
    var accruedInterestUSD: Double,
    val maxLeverageCovenant: Double = 2.50,
    val currentLeverage: Double = 1.62
) {
    val availableUSD: Double get() = committedUSD - drawnUSD
    val allInRatePct: Double get() = (fixedRatePct ?: (5.32 + spreadBps / 100.0))
}

data class MoneyMarketQuote(
    val tenor: String, // O/N, T/N, S/N, 1W, 1M, 3M, 6M
    val benchmark: String, // SOFR, SONIA
    var bidRatePct: Double,
    var askRatePct: Double,
    val availableLiquidityUSD: Double,
    val eligibleCollateralHaircutPct: Double
)

data class YieldCurvePoint(
    val tenorMonths: Int,
    val label: String,
    val zeroRatePct: Double,
    val parRatePct: Double,
    val discountFactor: Double,
    val dv01USD: Double
)

data class DerivativeContract(
    val id: String,
    val type: String, // BRENT_SWAP, CALENDAR_SPREAD, CRACK_SPREAD, CALL_OPTION, PUT_OPTION
    val underlying: String,
    val strikePrice: Double,
    val spotPrice: Double,
    val notionalBbls: Long,
    val tenor: String,
    val expiryDays: Int,
    val impliedVolPct: Double,
    var presentValueUSD: Double,
    var delta: Double,
    var gamma: Double,
    var vega: Double,
    var theta: Double
)

data class CarryTradeSetup(
    val id: String,
    val name: String,
    val spotPrice: Double,
    val forwardPrice: Double,
    val forwardDays: Int,
    val volumeBbls: Long,
    val financingRatePct: Double,
    val storageMonthlyBbl: Double,
    val insuranceMonthlyBbl: Double,
    val handlingBbl: Double,
    val hedgingCostBbl: Double
)

data class CDOTranche(
    val trancheName: String,
    val rating: String, // AAA, BBB, FIRST_LOSS
    val principalUSD: Double,
    val couponSpreadBps: Double,
    val subordinationPct: Double,
    val currentLossUSD: Double = 0.0
)

data class StructuredCreditPool(
    val poolId: String,
    val spvName: String,
    val totalCollateralUSD: Double,
    val underlyingAssetCount: Int,
    val seniorTranche: CDOTranche,
    val mezzTranche: CDOTranche,
    val equityTranche: CDOTranche,
    val reserveAccountUSD: Double,
    val simulatedDefaultRatePct: Double = 2.0
)

data class TokenisedAsset(
    val tokenId: String,
    val symbol: String,
    val name: String,
    val assetType: String, // PHYSICAL_INVENTORY, TRADE_RECEIVABLE, CDO_TRANCHE
    val underlyingBbls: Long,
    val custodyLocation: String,
    val inspectionCertNo: String,
    var marketPriceUSD: Double,
    val totalSupply: Long,
    var circulatingSupply: Long,
    val transferRestricted: Boolean = true
)

data class EscrowRecord(
    val escrowId: String,
    val tradeRef: String,
    val buyer: String,
    val seller: String,
    val commodity: String,
    val volumeBbls: Long,
    val totalNotionalUSD: Double,
    var stage: EscrowStage,
    val createdTimestamp: Long,
    val deadlineTimestamp: Long,
    var treasuryDualApproved: Boolean = false,
    var riskDualApproved: Boolean = false,
    var sgsInspectionOk: Boolean = true,
    var exceptionNote: String? = null
)

data class RiskSummary(
    val totalNetExposureUSD: Double,
    val var95DailyUSD: Double,
    val expectedShortfallUSD: Double,
    val liquidityReserveUSD: Double,
    val stressedLossUSD: Double,
    val marginUtilizationPct: Double,
    val limitBreached: Boolean
)

data class AccountingLog(
    val id: String,
    val timestamp: Long,
    val transactionRef: String,
    val debitAccount: String,
    val creditAccount: String,
    val amountUSD: Double,
    val memo: String,
    val cryptographicHash: String
)
