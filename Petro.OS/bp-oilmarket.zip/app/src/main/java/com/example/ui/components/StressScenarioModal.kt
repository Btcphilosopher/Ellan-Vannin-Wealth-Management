package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun StressScenarioModal(
    onDismiss: () -> Unit,
    onSelectScenario: (String) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("stress_scenario_modal"),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "PORTFOLIO MACRO STRESS ENGINE",
                    color = WarningAmber,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Hypothetical & Historical Shocks",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Inject systemic market dislocations to evaluate VaR, capital adequacy, and liquidity buffers.",
                    color = TextMuted,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                StressOptionCard(
                    title = "Geopolitical Supply Shock (+25% Crude)",
                    details = "Crude spikes 25%, SOFR funding spreads widen +150 bps, PFE spikes to $34.5M. Triggers collateral calls.",
                    badge = "EXTREME",
                    badgeColor = PriceDownRed,
                    onClick = { onSelectScenario("SUPPLY_CRUNCH") }
                )

                Spacer(modifier = Modifier.height(8.dp))

                StressOptionCard(
                    title = "Global Demand Recession (-30% Crude)",
                    details = "Crude plunges 30%, deep contango structure develops, inventory markdown, refinery margin contraction.",
                    badge = "SEVERE",
                    badgeColor = WarningAmber,
                    onClick = { onSelectScenario("RECESSION_DEMAND") }
                )

                Spacer(modifier = Modifier.height(8.dp))

                StressOptionCard(
                    title = "Tank Farm Outage & Super-Contango",
                    details = "Cushing & Rotterdam tank storage rates surge +200%, forward curve steepens, carry trade return exceeds 18%.",
                    badge = "OPPORTUNITY",
                    badgeColor = BPGreen,
                    onClick = { onSelectScenario("STORAGE_BOTTLENECK") }
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalSurfaceVariant)
                ) {
                    Text("CLOSE", color = Color.White, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun StressOptionCard(
    title: String,
    details: String,
    badge: String,
    badgeColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalBackground)
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(badgeColor.copy(alpha = 0.2f))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(text = badge, color = badgeColor, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = details, color = TextSecondary, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}
