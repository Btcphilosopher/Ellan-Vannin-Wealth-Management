package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RiskSummary
import com.example.ui.theme.*

@Composable
fun RiskScreen(
    riskSummary: RiskSummary,
    onTriggerScenario: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Master Risk Header Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.WarningAmber, contentDescription = null, tint = if (riskSummary.limitBreached) PriceDownRed else WarningAmber, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = "CENTRALISED PORTFOLIO RISK ENGINE",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Parametric & Historical VaR | Expected Shortfall | PFE Limits",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background((if (riskSummary.limitBreached) PriceDownRed else BPGreen).copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (riskSummary.limitBreached) "LIMIT BREACHED" else "WITHIN MANDATE",
                                color = if (riskSummary.limitBreached) PriceDownRed else BPGreen,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("1D 95% VaR", color = TextMuted, fontSize = 10.sp)
                            Text("$${"%,.2f".format(riskSummary.var95DailyUSD / 1000000.0)}M", color = WarningAmber, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("CVaR (Expected Shortfall)", color = TextMuted, fontSize = 10.sp)
                            Text("$${"%,.2f".format(riskSummary.expectedShortfallUSD / 1000000.0)}M", color = PriceDownRed, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Margin Util.", color = TextMuted, fontSize = 10.sp)
                            Text("${"%.1f".format(riskSummary.marginUtilizationPct)}%", color = if (riskSummary.marginUtilizationPct > 70) PriceDownRed else Color.White, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Stressed Loss", color = TextMuted, fontSize = 10.sp)
                            Text("$${"%,.1f".format(riskSummary.stressedLossUSD / 1000000.0)}M", color = PriceDownRed, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section Title: Interactive Macro Scenarios
        item {
            Text(
                text = "HYPOTHETICAL STRESS SCENARIO SIMULATION",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                StressActionCard(
                    title = "Geopolitical Supply Shock (+25% Crude)",
                    details = "Simulates +25% crude rally, +150 bps funding widen, and $34.5M stressed loss.",
                    buttonText = "TRIGGER +25% SHOCK",
                    buttonColor = PriceDownRed,
                    onClick = { onTriggerScenario("SUPPLY_CRUNCH") }
                )
                StressActionCard(
                    title = "Global Demand Recession (-30% Crude)",
                    details = "Simulates -30% crude drop, inventory markdowns, contango curve expansion.",
                    buttonText = "TRIGGER -30% RECESSION",
                    buttonColor = WarningAmber,
                    onClick = { onTriggerScenario("RECESSION_DEMAND") }
                )
                StressActionCard(
                    title = "Tank Outage & Super-Contango",
                    details = "Storage rental rates surge +200%, physical tank arbitrage return hits +18.5%.",
                    buttonText = "TRIGGER STORAGE CONTANGO",
                    buttonColor = BPGreen,
                    onClick = { onTriggerScenario("STORAGE_BOTTLENECK") }
                )
            }
        }

        // Section Title: Counterparty Credit Exposure (PFE)
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "COUNTERPARTY CREDIT EXPOSURE & LIMITS (PFE)",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    CounterpartyExposureRow(name = "TotalEnergies Trading SA", rating = "A1 / A+", currentExp = "$42.1M", limit = "$75.0M", util = 56)
                    CounterpartyExposureRow(name = "Shell International Trading", rating = "Aa2 / AA-", currentExp = "$38.5M", limit = "$100.0M", util = 38)
                    CounterpartyExposureRow(name = "Glencore Energy UK Ltd", rating = "Baa1 / BBB+", currentExp = "$28.1M", limit = "$50.0M", util = 56)
                    CounterpartyExposureRow(name = "Trafigura Pte Ltd", rating = "Baa2 / BBB", currentExp = "$41.2M", limit = "$45.0M", util = 91)
                }
            }
        }
    }
}

@Composable
private fun StressActionCard(
    title: String,
    details: String,
    buttonText: String,
    buttonColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.5f)) {
                Text(text = title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = details, color = TextSecondary, fontSize = 10.sp, lineHeight = 13.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(buttonColor.copy(alpha = 0.2f))
                    .border(1.dp, buttonColor, RoundedCornerShape(4.dp))
                    .clickable { onClick() }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .testTag("btn_${title.take(10).lowercase().replace(" ", "_")}"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = buttonColor, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = buttonText, color = buttonColor, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun CounterpartyExposureRow(
    name: String,
    rating: String,
    currentExp: String,
    limit: String,
    util: Int
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "$name ($rating)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(text = "$currentExp / $limit ($util%)", color = if (util > 80) PriceDownRed else BPGreen, fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { util / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp)),
            color = if (util > 80) PriceDownRed else BPGreen,
            trackColor = TerminalBackground
        )
    }
}
