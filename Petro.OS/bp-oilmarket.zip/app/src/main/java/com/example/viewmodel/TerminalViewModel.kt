package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.TerminalRepository
import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class TerminalTab(val code: String, val title: String, val category: String) {
    OVERVIEW("1", "Overview", "Global Desk"),
    PHYSICAL_DESK("2", "Physical", "Crude & Cargo"),
    TREASURY("3", "Treasury", "Debt & Liquidity"),
    MONEY_MARKET("4", "Money Mkt", "SOFR & Repo"),
    DERIVATIVES("5", "Derivatives", "Swaps & Options"),
    CARRY_ARBITRAGE("6", "Carry Trade", "Contango Arb"),
    STRUCTURED_CREDIT("7", "Structured", "CDO & Tokens"),
    ESCROW_SETTLEMENT("8", "Escrow T+2", "DvP Settlement"),
    RISK_ENGINE("9", "Risk & VaR", "Stress & PFE"),
    AUDIT_LEDGER("10", "Audit Log", "Dual Control")
}

class TerminalViewModel(
    val repository: TerminalRepository = TerminalRepository()
) : ViewModel() {

    private val _activeTab = MutableStateFlow(TerminalTab.OVERVIEW)
    val activeTab: StateFlow<TerminalTab> = _activeTab.asStateFlow()

    private val _commandQuery = MutableStateFlow("")
    val commandQuery: StateFlow<String> = _commandQuery.asStateFlow()

    private val _isLiveStreaming = MutableStateFlow(true)
    val isLiveStreaming: StateFlow<Boolean> = _isLiveStreaming.asStateFlow()

    private val _latencyMs = MutableStateFlow(12)
    val latencyMs: StateFlow<Int> = _latencyMs.asStateFlow()

    // Dialog States
    private val _selectedQuoteForTrade = MutableStateFlow<MarketQuote?>(null)
    val selectedQuoteForTrade: StateFlow<MarketQuote?> = _selectedQuoteForTrade.asStateFlow()

    private val _selectedFacility = MutableStateFlow<FinancingFacility?>(null)
    val selectedFacility: StateFlow<FinancingFacility?> = _selectedFacility.asStateFlow()

    private val _showStressModal = MutableStateFlow(false)
    val showStressModal: StateFlow<Boolean> = _showStressModal.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        startLiveTicker()
    }

    private fun startLiveTicker() {
        viewModelScope.launch {
            while (isActive) {
                if (_isLiveStreaming.value) {
                    repository.tickMarket()
                    _latencyMs.value = (8..18).random()
                }
                delay(2800)
            }
        }
    }

    fun setTab(tab: TerminalTab) {
        _activeTab.value = tab
    }

    fun setCommandQuery(query: String) {
        _commandQuery.value = query
    }

    fun toggleLiveStreaming() {
        _isLiveStreaming.value = !_isLiveStreaming.value
        showMessage(if (_isLiveStreaming.value) "Live Market Feed: CONNECTED" else "Market Feed: PAUSED")
    }

    fun stepTick() {
        repository.tickMarket()
        showMessage("Manual Tick Dispatched (Deterministic Step)")
    }

    fun selectQuoteForTrade(quote: MarketQuote?) {
        _selectedQuoteForTrade.value = quote
    }

    fun selectFacility(facility: FinancingFacility?) {
        _selectedFacility.value = facility
    }

    fun setShowStressModal(show: Boolean) {
        _showStressModal.value = show
    }

    fun submitOrder(
        symbol: String,
        side: OrderSide,
        type: OrderType,
        price: Double,
        quantityBbls: Long,
        counterparty: String,
        laycan: String,
        location: String
    ) {
        val order = repository.submitOrder(
            symbol = symbol,
            side = side,
            type = type,
            price = price,
            quantityBbls = quantityBbls,
            counterparty = counterparty,
            laycan = laycan,
            location = location
        )
        _selectedQuoteForTrade.value = null
        showMessage("Order ${order.orderId} Confirmed: ${order.side} ${order.quantityBbls} bbls @ $$price")
    }

    fun approveEscrow(escrowId: String, isTreasury: Boolean, isRisk: Boolean) {
        repository.approveEscrowOfficer(escrowId, isTreasury, isRisk)
        val role = if (isTreasury) "Treasury Officer" else "Risk Officer"
        showMessage("$role Dual-Authorization Signature Applied to $escrowId")
    }

    fun adjustFacility(facilityId: String, amountUSD: Double, isDrawdown: Boolean) {
        repository.adjustFacility(facilityId, amountUSD, isDrawdown)
        _selectedFacility.value = null
        showMessage("${if (isDrawdown) "Drawdown" else "Repayment"} of $${"%,.0f".format(amountUSD)} Completed")
    }

    fun triggerStressScenario(scenario: String) {
        repository.runStressScenario(scenario)
        _showStressModal.value = false
        showMessage("Stress Scenario Applied: $scenario")
    }

    fun executeTerminalCommand(cmd: String) {
        val clean = cmd.trim().uppercase()
        when {
            clean.startsWith("PHYS") || clean == "OIL" -> setTab(TerminalTab.PHYSICAL_DESK)
            clean.startsWith("TREAS") || clean == "DEBT" -> setTab(TerminalTab.TREASURY)
            clean.startsWith("MM") || clean.startsWith("SOFR") || clean == "REPO" -> setTab(TerminalTab.MONEY_MARKET)
            clean.startsWith("DERIV") || clean.startsWith("SWAP") || clean == "OPT" -> setTab(TerminalTab.DERIVATIVES)
            clean.startsWith("CARRY") || clean == "ARB" -> setTab(TerminalTab.CARRY_ARBITRAGE)
            clean.startsWith("CDO") || clean.startsWith("STRUCT") || clean == "TOK" -> setTab(TerminalTab.STRUCTURED_CREDIT)
            clean.startsWith("ESC") || clean == "SETTLE" || clean == "DVP" -> setTab(TerminalTab.ESCROW_SETTLEMENT)
            clean.startsWith("RISK") || clean == "VAR" -> setTab(TerminalTab.RISK_ENGINE)
            clean.startsWith("AUDIT") || clean == "LEDGER" -> setTab(TerminalTab.AUDIT_LEDGER)
            clean == "HELP" || clean == "?" -> showMessage("Commands: PHYS, TREAS, MM, DERIV, CARRY, CDO, ESC, RISK, AUDIT")
            else -> {
                // If it matches a symbol
                val q = repository.quotes.value.find { it.symbol.contains(clean) }
                if (q != null) {
                    selectQuoteForTrade(q)
                    setTab(TerminalTab.PHYSICAL_DESK)
                } else {
                    showMessage("Unrecognized command '$cmd'. Press HELP for commands.")
                }
            }
        }
        _commandQuery.value = ""
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    private fun showMessage(msg: String) {
        _statusMessage.value = msg
    }
}
