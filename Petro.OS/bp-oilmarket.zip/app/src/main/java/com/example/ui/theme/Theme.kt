package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TerminalColorScheme = darkColorScheme(
    primary = BPGreen,
    onPrimary = TextOnAccent,
    primaryContainer = BPGreenDark,
    onPrimaryContainer = Color.White,
    secondary = BPGold,
    onSecondary = Color.Black,
    secondaryContainer = TerminalSurfaceVariant,
    onSecondaryContainer = Color.White,
    tertiary = InfoCyan,
    onTertiary = Color.Black,
    background = TerminalBackground,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder,
    error = PriceDownRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
