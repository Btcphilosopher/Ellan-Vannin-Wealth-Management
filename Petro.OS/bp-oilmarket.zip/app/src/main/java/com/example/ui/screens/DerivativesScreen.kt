package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DerivativeContract
import com.example.ui.theme.*

@Composable
fun DerivativesScreen(
    derivatives: List<DerivativeContract>,
    modifier: Modifier = Modifier
) {
    val totalPV = derivatives.sumOf { it.presentValueUSD }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Summary Header Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Functions, contentDescription = null, tint = BPGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "DERIVATIVES & QUANT PRICING DESK",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Black-76 Commodity European Options | Swaps & Crack Spreads",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "TOTAL MTM PV", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        Text(
                            text = "$${"%,.0f".format(totalPV)}",
                            color = if (totalPV >= 0) PriceUpGreen else PriceDownRed,
                            fontSize = 15.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Section Title: Contracts Blotter
        item {
            Text(
                text = "ACTIVE CONTRACTS & ANALYTICAL GREEKS",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(derivatives) { contract ->
            DerivativeDetailedCard(contract = contract)
        }
    }
}

@Composable
private fun DerivativeDetailedCard(contract: DerivativeContract) {
    val isPositivePV = contract.presentValueUSD >= 0

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = contract.type.replace("_", " "), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(TerminalSurfaceVariant)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(text = contract.tenor, color = BPGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(
                        text = "Underlying: ${contract.underlying} | Vol: ${"%,d".format(contract.notionalBbls)} bbls | Exp: ${contract.expiryDays}d",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Mark-to-Market PV", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        text = "$${"%,.0f".format(contract.presentValueUSD)}",
                        color = if (isPositivePV) PriceUpGreen else PriceDownRed,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Pricing & Greeks Grid
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(TerminalBackground)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    GreekCol("STRIKE", "$${"%.2f".format(contract.strikePrice)}")
                    GreekCol("SPOT", "$${"%.2f".format(contract.spotPrice)}")
                    GreekCol("IV", "${"%.1f".format(contract.impliedVolPct)}%")
                    GreekCol("DELTA (Δ)", "%.3f".format(contract.delta))
                    GreekCol("GAMMA (Γ)", "%.4f".format(contract.gamma))
                    GreekCol("VEGA (ν)", "$${"%,.0f".format(contract.vega)}")
                    GreekCol("THETA (θ)", "$${"%,.0f".format(contract.theta)}/d")
                }
            }
        }
    }
}

@Composable
private fun GreekCol(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = TextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}
