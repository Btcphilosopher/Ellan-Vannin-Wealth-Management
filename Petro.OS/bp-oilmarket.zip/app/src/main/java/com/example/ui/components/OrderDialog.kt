package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.MarketQuote
import com.example.model.OrderSide
import com.example.model.OrderType
import com.example.ui.theme.*

@Composable
fun OrderDialog(
    quote: MarketQuote,
    onDismiss: () -> Unit,
    onSubmit: (
        symbol: String,
        side: OrderSide,
        type: OrderType,
        price: Double,
        quantityBbls: Long,
        counterparty: String,
        laycan: String,
        location: String
    ) -> Unit
) {
    var side by remember { mutableStateOf(OrderSide.BUY) }
    var orderType by remember { mutableStateOf(OrderType.LIMIT) }
    var priceInput by remember { mutableStateOf(quote.last.toString()) }
    var quantityBblsInput by remember { mutableStateOf("250000") }
    var counterparty by remember { mutableStateOf("TotalEnergies Trading") }
    var laycan by remember { mutableStateOf("15-20 Nov 2026") }
    var location by remember { mutableStateOf("Rotterdam Botlek") }

    val price = priceInput.toDoubleOrNull() ?: quote.last
    val quantity = quantityBblsInput.toLongOrNull() ?: 250000L
    val notionalUSD = price * quantity

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("order_dialog"),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ORDER EXECUTION TICKET",
                            color = BPGreen,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${quote.symbol} // ${quote.name}",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "$${quote.last} ${quote.unit}",
                        color = PriceUpGreen,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Side Selection (BUY / SELL)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (side == OrderSide.BUY) BPGreenDark else TerminalBackground)
                            .border(1.dp, if (side == OrderSide.BUY) BPGreen else TerminalBorder, RoundedCornerShape(4.dp))
                            .clickable { side = OrderSide.BUY }
                            .padding(vertical = 10.dp)
                            .testTag("order_side_buy"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "BID / BUY",
                            color = if (side == OrderSide.BUY) Color.White else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (side == OrderSide.SELL) PriceDownRed.copy(alpha = 0.3f) else TerminalBackground)
                            .border(1.dp, if (side == OrderSide.SELL) PriceDownRed else TerminalBorder, RoundedCornerShape(4.dp))
                            .clickable { side = OrderSide.SELL }
                            .padding(vertical = 10.dp)
                            .testTag("order_side_sell"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "OFFER / SELL",
                            color = if (side == OrderSide.SELL) Color.White else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Order Type Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OrderType.values().forEach { t ->
                        val isSelected = t == orderType
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) TerminalSurfaceVariant else TerminalBackground)
                                .border(1.dp, if (isSelected) BPGreen else TerminalBorder, RoundedCornerShape(4.dp))
                                .clickable { orderType = t }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = t.name.replace("_", " "),
                                color = if (isSelected) Color.White else TextMuted,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Limit Price & Volume Fields
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = priceInput,
                        onValueChange = { priceInput = it },
                        label = { Text("Price ($/bbl)", color = TextMuted, fontSize = 11.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("order_price_input"),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.Monospace),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = quantityBblsInput,
                        onValueChange = { quantityBblsInput = it },
                        label = { Text("Volume (bbls)", color = TextMuted, fontSize = 11.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("order_volume_input"),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.Monospace),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Volume Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("100K" to 100000L, "250K" to 250000L, "500K" to 500000L, "1M (VLCC)" to 1000000L).forEach { (label, vol) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(3.dp))
                                .background(TerminalBackground)
                                .border(1.dp, TerminalBorder, RoundedCornerShape(3.dp))
                                .clickable { quantityBblsInput = vol.toString() }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = label, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Counterparty and Delivery Location
                OutlinedTextField(
                    value = counterparty,
                    onValueChange = { counterparty = it },
                    label = { Text("Counterparty / Clearing Venue", color = TextMuted, fontSize = 11.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.Monospace),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = laycan,
                        onValueChange = { laycan = it },
                        label = { Text("Laycan Window", color = TextMuted, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.Monospace),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("Delivery Port", color = TextMuted, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.Monospace),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Calculated Notional Summary Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalBackground)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Total Notional USD:", color = TextSecondary, fontSize = 11.sp)
                            Text(
                                text = "$${"%,.2f".format(notionalUSD)}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Settlement Convention:", color = TextMuted, fontSize = 10.sp)
                            Text(text = "T+2 48-Hour DvP Escrow", color = WarningAmber, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("CANCEL", color = TextSecondary, fontFamily = FontFamily.Monospace)
                    }

                    Button(
                        onClick = {
                            onSubmit(quote.symbol, side, orderType, price, quantity, counterparty, laycan, location)
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("submit_order_confirm"),
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (side == OrderSide.BUY) BPGreen else PriceDownRed
                        )
                    ) {
                        Text(
                            text = "TRANSMIT ${side.name}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
