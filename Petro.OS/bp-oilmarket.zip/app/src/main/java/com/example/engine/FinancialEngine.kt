package com.example.engine

import com.example.model.CarryTradeSetup
import com.example.model.DayCountConvention
import kotlin.math.*

object FinancialEngine {

    /**
     * Standard Normal Cumulative Distribution Function (Abramowitz and Stegun 7.1.26 approximation)
     */
    fun normCdf(x: Double): Double {
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429
        val p = 0.2316419
        val c = 0.3989422804014327 // 1.0 / sqrt(2 * PI)

        if (x >= 0.0) {
            val t = 1.0 / (1.0 + p * x)
            return 1.0 - c * exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1)
        } else {
            val t = 1.0 / (1.0 - p * x)
            return c * exp(-x * x / 2.0) * t * (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1)
        }
    }

    /**
     * Standard Normal Probability Density Function
     */
    fun normPdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * Math.PI)) * exp(-0.5 * x * x)
    }

    /**
     * Black-76 Model for European Commodity Futures Options
     */
    data class OptionGreeks(
        val price: Double,
        val delta: Double,
        val gamma: Double,
        val vega: Double,
        val thetaPerDay: Double
    )

    fun calculateBlack76(
        isCall: Boolean,
        forwardPrice: Double,
        strike: Double,
        riskFreeRatePct: Double,
        volatilityPct: Double,
        daysToExpiry: Int
    ): OptionGreeks {
        if (forwardPrice <= 0.0 || strike <= 0.0 || daysToExpiry <= 0) {
            return OptionGreeks(0.0, 0.0, 0.0, 0.0, 0.0)
        }

        val t = max(1.0 / 365.0, daysToExpiry / 365.0)
        val r = riskFreeRatePct / 100.0
        val sigma = max(0.01, volatilityPct / 100.0)
        val df = exp(-r * t)

        val sqrtT = sqrt(t)
        val d1 = (ln(forwardPrice / strike) + 0.5 * sigma * sigma * t) / (sigma * sqrtT)
        val d2 = d1 - sigma * sqrtT

        val price = if (isCall) {
            df * (forwardPrice * normCdf(d1) - strike * normCdf(d2))
        } else {
            df * (strike * normCdf(-d2) - forwardPrice * normCdf(-d1))
        }

        val delta = if (isCall) {
            df * normCdf(d1)
        } else {
            -df * normCdf(-d1)
        }

        val gamma = df * normPdf(d1) / (forwardPrice * sigma * sqrtT)
        // 1% vol change sensitivity
        val vega = (df * forwardPrice * sqrtT * normPdf(d1)) / 100.0

        // Theta per day
        val thetaAnnual = -(df * forwardPrice * normPdf(d1) * sigma) / (2.0 * sqrtT) -
                (if (isCall) -r * df * (forwardPrice * normCdf(d1) - strike * normCdf(d2))
                else -r * df * (strike * normCdf(-d2) - forwardPrice * normCdf(-d1)))
        val thetaPerDay = thetaAnnual / 365.0

        return OptionGreeks(
            price = max(0.0, price),
            delta = delta,
            gamma = gamma,
            vega = vega,
            thetaPerDay = thetaPerDay
        )
    }

    /**
     * Institutional Cash & Carry Calculation
     * Net carry = forward sale value − spot purchase cost − financing − storage − insurance − transport − handling − hedging.
     */
    data class CarryResult(
        val grossCarryPerBbl: Double,
        val financingCostPerBbl: Double,
        val storageCostPerBbl: Double,
        val insuranceCostPerBbl: Double,
        val otherCostsPerBbl: Double,
        val netCarryPerBbl: Double,
        val totalNetCarryUSD: Double,
        val annualisedYieldPct: Double,
        val breakEvenPrice: Double,
        val capitalRequiredUSD: Double,
        val stressLoss100BpsUSD: Double
    )

    fun calculateCarry(setup: CarryTradeSetup): CarryResult {
        val grossCarry = setup.forwardPrice - setup.spotPrice
        val financingPerBbl = setup.spotPrice * (setup.financingRatePct / 100.0) * (setup.forwardDays / 365.0)
        val months = setup.forwardDays / 30.0
        val storagePerBbl = setup.storageMonthlyBbl * months
        val insurancePerBbl = setup.insuranceMonthlyBbl * months
        val otherPerBbl = setup.handlingBbl + setup.hedgingCostBbl

        val netCarryPerBbl = grossCarry - financingPerBbl - storagePerBbl - insurancePerBbl - otherPerBbl
        val totalNetCarry = netCarryPerBbl * setup.volumeBbls
        val capitalRequired = setup.spotPrice * setup.volumeBbls

        val annualisedYieldPct = if (setup.spotPrice > 0.0 && setup.forwardDays > 0) {
            (netCarryPerBbl / setup.spotPrice) * (365.0 / setup.forwardDays) * 100.0
        } else 0.0

        val breakEvenPrice = setup.spotPrice + financingPerBbl + storagePerBbl + insurancePerBbl + otherPerBbl

        // Adverse 100 bps funding rate widening stress test
        val stressedFinancingPerBbl = setup.spotPrice * ((setup.financingRatePct + 1.0) / 100.0) * (setup.forwardDays / 365.0)
        val stressLoss100Bps = (stressedFinancingPerBbl - financingPerBbl) * setup.volumeBbls

        return CarryResult(
            grossCarryPerBbl = grossCarry,
            financingCostPerBbl = financingPerBbl,
            storageCostPerBbl = storagePerBbl,
            insuranceCostPerBbl = insurancePerBbl,
            otherCostsPerBbl = otherPerBbl,
            netCarryPerBbl = netCarryPerBbl,
            totalNetCarryUSD = totalNetCarry,
            annualisedYieldPct = annualisedYieldPct,
            breakEvenPrice = breakEvenPrice,
            capitalRequiredUSD = capitalRequired,
            stressLoss100BpsUSD = stressLoss100Bps
        )
    }

    /**
     * Accrued Interest for Corporate Financing / Treasury loans
     */
    fun calculateAccruedInterest(
        principalUSD: Double,
        ratePct: Double,
        days: Int,
        convention: DayCountConvention
    ): Double {
        val divisor = when (convention) {
            DayCountConvention.ACT_360 -> 360.0
            DayCountConvention.ACT_365 -> 365.0
            DayCountConvention.THIRTY_360 -> 360.0
        }
        return principalUSD * (ratePct / 100.0) * (days / divisor)
    }

    /**
     * Structured Credit CDO Waterfall Simulator
     */
    data class WaterfallResult(
        val totalCollectedUSD: Double,
        val defaultLossUSD: Double,
        val seniorPayoutUSD: Double,
        val seniorCoverageRatioPct: Double,
        val mezzPayoutUSD: Double,
        val mezzCoverageRatioPct: Double,
        val reserveReplenishedUSD: Double,
        val equityResidualUSD: Double,
        val equityYieldPct: Double
    )

    fun calculateCDOWaterfall(
        totalCollateralUSD: Double,
        simulatedDefaultRatePct: Double,
        recoveryRatePct: Double,
        seniorPrincipalUSD: Double,
        seniorCouponSpreadBps: Double,
        mezzPrincipalUSD: Double,
        mezzCouponSpreadBps: Double,
        equityPrincipalUSD: Double,
        targetReserveUSD: Double,
        benchmarkRatePct: Double = 5.30
    ): WaterfallResult {
        val defaultAmount = totalCollateralUSD * (simulatedDefaultRatePct / 100.0)
        val recoveryAmount = defaultAmount * (recoveryRatePct / 100.0)
        val realizedLoss = defaultAmount - recoveryAmount
        val totalCollected = totalCollateralUSD - realizedLoss

        val seniorRate = (benchmarkRatePct + seniorCouponSpreadBps / 100.0) / 100.0
        val seniorDue = seniorPrincipalUSD * (1.0 + seniorRate * 0.25) // Quarterly period

        val seniorPaid = min(totalCollected, seniorDue)
        val remainingAfterSenior = max(0.0, totalCollected - seniorPaid)
        val seniorCoverage = if (seniorDue > 0) (seniorPaid / seniorDue) * 100.0 else 100.0

        val mezzRate = (benchmarkRatePct + mezzCouponSpreadBps / 100.0) / 100.0
        val mezzDue = mezzPrincipalUSD * (1.0 + mezzRate * 0.25)

        val mezzPaid = min(remainingAfterSenior, mezzDue)
        val remainingAfterMezz = max(0.0, remainingAfterSenior - mezzPaid)
        val mezzCoverage = if (mezzDue > 0) (mezzPaid / mezzDue) * 100.0 else 100.0

        val reserveAllocated = min(remainingAfterMezz, targetReserveUSD)
        val equityResidual = max(0.0, remainingAfterMezz - reserveAllocated)

        val equityYield = if (equityPrincipalUSD > 0) {
            ((equityResidual - equityPrincipalUSD) / equityPrincipalUSD) * 4.0 * 100.0
        } else 0.0

        return WaterfallResult(
            totalCollectedUSD = totalCollected,
            defaultLossUSD = realizedLoss,
            seniorPayoutUSD = seniorPaid,
            seniorCoverageRatioPct = seniorCoverage,
            mezzPayoutUSD = mezzPaid,
            mezzCoverageRatioPct = mezzCoverage,
            reserveReplenishedUSD = reserveAllocated,
            equityResidualUSD = equityResidual,
            equityYieldPct = equityYield
        )
    }

    /**
     * Value at Risk (VaR 95%) and Expected Shortfall (CVaR)
     */
    fun calculateVaR(exposureUSD: Double, annualVolPct: Double): Pair<Double, Double> {
        val dailyVol = (annualVolPct / 100.0) / sqrt(252.0)
        // 95% 1-tailed Z = 1.64485
        val var95 = 1.64485 * dailyVol * abs(exposureUSD)
        // Expected Shortfall for normal dist at 95%: ~ 2.0627 * dailyVol * exposure
        val expectedShortfall = 2.0627 * dailyVol * abs(exposureUSD)
        return Pair(var95, expectedShortfall)
    }
}
