package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FinancingFacility
import com.example.ui.theme.*

@Composable
fun TreasuryScreen(
    facilities: List<FinancingFacility>,
    onSelectFacility: (FinancingFacility) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalCommitted = facilities.sumOf { it.committedUSD }
    val totalDrawn = facilities.sumOf { it.drawnUSD }
    val totalAvailable = totalCommitted - totalDrawn
    val totalAccrued = facilities.sumOf { it.accruedInterestUSD }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Treasury Capital Summary
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AccountBalance, contentDescription = null, tint = BPGreen, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CORPORATE TREASURY & FUNDING DESK",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Text(text = "BP PLC GROUP TREASURY", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total Committed", color = TextMuted, fontSize = 10.sp)
                            Text("$${"%,.1f".format(totalCommitted / 1000000000.0)}B", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Total Drawn Debt", color = TextMuted, fontSize = 10.sp)
                            Text("$${"%,.1f".format(totalDrawn / 1000000000.0)}B", color = WarningAmber, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Available Headroom", color = TextMuted, fontSize = 10.sp)
                            Text("$${"%,.1f".format(totalAvailable / 1000000000.0)}B", color = BPGreen, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Accrued Interest", color = TextMuted, fontSize = 10.sp)
                            Text("$${"%,.1f".format(totalAccrued / 1000000.0)}M", color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Debt Covenant Status Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = BPGreen, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(text = "FINANCIAL DEBT COVENANTS: FULLY COMPLIANT", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Net Debt / EBITDA: 1.62x (Covenant Ceiling: 2.50x) | Interest Coverage: 8.4x (Floor: 4.0x)", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(BPGreen.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = "PASSED", color = BPGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Section Title: Facilities
        item {
            Text(
                text = "CREDIT FACILITIES & DEBT ISSUANCE",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(facilities) { facility ->
            FacilityDetailedCard(facility = facility, onAction = { onSelectFacility(facility) })
        }

        // Section: Multi-Currency Cash Pooling Forecast
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "GLOBAL CASH POOLING & INTRADAY LIQUIDITY",
                color = BPGreen,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(TerminalSurface)
                    .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    CashPoolRow(currency = "USD", balance = "$485,200,000", rate = "SOFR: 5.31%", bank = "Citigroup London / NY")
                    CashPoolRow(currency = "EUR", balance = "€142,500,000", rate = "€STR: 3.89%", bank = "BNP Paribas Paris")
                    CashPoolRow(currency = "GBP", balance = "£88,400,000", rate = "SONIA: 5.18%", bank = "Barclays Bank UK")
                    CashPoolRow(currency = "SGD", balance = "S$65,100,000", rate = "SORA: 3.65%", bank = "DBS Bank Singapore")
                }
            }
        }
    }
}

@Composable
private fun FacilityDetailedCard(
    facility: FinancingFacility,
    onAction: () -> Unit
) {
    val utilPct = (facility.drawnUSD / facility.committedUSD).toFloat()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = facility.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "ID: ${facility.facilityId} | Type: ${facility.type} | Maturity: ${facility.maturityDate}",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalBackground)
                        .border(1.dp, BPGreen, RoundedCornerShape(4.dp))
                        .clickable { onAction() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("facility_action_${facility.facilityId.lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "DRAW / REPAY", color = BPGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pricing & terms
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Spread: ${facility.benchmark} + ${facility.spreadBps} bps",
                    color = BPGreen,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "All-In Rate: ${"%.2f".format(facility.allInRatePct)}% (${facility.dayCount.name})",
                    color = Color.White,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
                Text(
                    text = "Accrued: $${"%,.0f".format(facility.accruedInterestUSD)}",
                    color = WarningAmber,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { utilPct },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (utilPct > 0.85f) PriceDownRed else BPGreen,
                trackColor = TerminalBackground
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Drawn: $${"%,.0f".format(facility.drawnUSD)} (${(utilPct * 100).toInt()}%)",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Available: $${"%,.0f".format(facility.availableUSD)}",
                    color = BPGreen,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun CashPoolRow(currency: String, balance: String, rate: String, bank: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(TerminalSurfaceVariant)
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Text(text = currency, color = Color.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(text = balance, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text(text = bank, color = TextMuted, fontSize = 9.sp)
            }
        }
        Text(text = rate, color = BPGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
}
