package com.example.eac.state

import com.example.eac.contracts.ComponentHealth
import com.example.eac.contracts.MessageHeader
import com.example.eac.contracts.VehiclePose2D
import com.example.eac.sensors.SensorFrameBundle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

data class EstimatedVehicleState(
    val header: MessageHeader,
    val pose: VehiclePose2D,
    val vxMps: Double,
    val yawRateRadS: Double,
    val pitchDeg: Double,
    val rollDeg: Double,
    val positionStdM: Double,
    val yawStdDeg: Double,
    val gnssInnovationM: Double,
    val wheelImuDiscrepancyMps: Double,
    val localizationConfidence: Double,
    val authoritative: Boolean,
    val statusDetail: String,
    val health: ComponentHealth,
)

/**
 * Lightweight 2D+attitude Extended Kalman Filter fusing wheel odometry,
 * IMU yaw rate, and GNSS position with innovation-based outlier rejection.
 */
class EkfStateEstimator {
    private var x = 0.0
    private var y = 0.0
    private var yaw = 0.0
    private var pPos = 0.08 // variance (m^2)
    private var pYaw = 0.01 // variance (rad^2)
    private var initialized = false

    fun reset(initialPose: VehiclePose2D = VehiclePose2D(0.0, 0.0, 0.0)) {
        x = initialPose.xM
        y = initialPose.yM
        yaw = initialPose.yawRad
        pPos = 0.05
        pYaw = 0.008
        initialized = true
    }

    fun update(frame: SensorFrameBundle, dtSec: Double): EstimatedVehicleState {
        if (!initialized) {
            reset(frame.truePose)
        }

        // 1. Prediction step using wheel speed & IMU yaw rate
        val vPred = frame.wheelOdometryVxMps / (1.0 + frame.wheelSlipObserved * 0.35)
        val yawRate = frame.imuYawRateRadS
        yaw = normalizeAngle(yaw + yawRate * dtSec)
        x += vPred * cos(yaw) * dtSec
        y += vPred * sin(yaw) * dtSec

        // Process noise scales with wheel slip & velocity
        val qPos = (0.015 + frame.wheelSlipObserved * 0.25) * dtSec
        val qYaw = 0.004 * dtSec
        pPos += qPos
        pYaw += qYaw

        // 2. GNSS measurement update with Mahalanobis / innovation gating
        val dx = frame.gnssX - x
        val dy = frame.gnssY - y
        val innovation = hypot(dx, dy)
        val rGnss = (0.12 * frame.gnssHdop * frame.gnssHdop).coerceAtLeast(0.08)

        val gateThreshold = 1.65
        var gnssAccepted = false
        if (frame.gnssValid && innovation < gateThreshold) {
            val k = pPos / (pPos + rGnss)
            x += k * dx
            y += k * dy
            pPos *= (1.0 - k)
            gnssAccepted = true
        } else if (!frame.gnssValid) {
            pPos += 0.08 * dtSec
        } else {
            // Outlier rejected, uncertainty grows slowly
            pPos += 0.04 * dtSec
        }

        val posStd = sqrt(pPos).coerceAtLeast(0.04)
        val yawStdDeg = Math.toDegrees(sqrt(pYaw)).coerceAtLeast(0.5)
        val wheelImuDiscrepancy = kotlin.math.abs(frame.wheelOdometryVxMps - vPred)

        val conf = (1.0 - (posStd / 2.2) - (if (!gnssAccepted) 0.18 else 0.0) - (frame.wheelSlipObserved * 0.35))
            .coerceIn(0.05, 0.99)
        val authoritative = posStd < 0.95 && conf >= 0.45

        val detail = when {
            !authoritative -> "Localization UNRELIABLE (sigma=${"%.2f".format(posStd)}m, innov=${"%.2f".format(innovation)}m)"
            !gnssAccepted -> "Dead-reckoning IMU+Wheel (GNSS rejected/degraded)"
            else -> "GNSS/IMU/Wheel EKF locked"
        }

        return EstimatedVehicleState(
            header = MessageHeader(frame.seq, frame.timestampNs, "map"),
            pose = VehiclePose2D(x, y, yaw),
            vxMps = vPred,
            yawRateRadS = yawRate,
            pitchDeg = frame.truePitchDeg,
            rollDeg = frame.trueRollDeg,
            positionStdM = posStd,
            yawStdDeg = yawStdDeg,
            gnssInnovationM = innovation,
            wheelImuDiscrepancyMps = wheelImuDiscrepancy,
            localizationConfidence = conf,
            authoritative = authoritative,
            statusDetail = detail,
            health = ComponentHealth(
                moduleName = "state_estimation_ekf",
                healthy = authoritative,
                latencyMs = 1.8,
                deadlineMs = 15.0,
                confidence = conf,
                statusNote = detail,
            ),
        )
    }

    private fun normalizeAngle(a: Double): Double {
        var r = a
        while (r > PI) r -= 2.0 * PI
        while (r < -PI) r += 2.0 * PI
        return r
    }
}
