package com.example.eac.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.eac.contracts.OperatingMode
import com.example.eac.contracts.SafetyState
import com.example.eac.control.ResearchControlInterface
import com.example.eac.perception.LocalTerrainMap
import com.example.eac.perception.TerrainPerceptionEngine
import com.example.eac.planning.HierarchicalPlanner
import com.example.eac.planning.PlanningResult
import com.example.eac.safety.IndependentSafetySupervisor
import com.example.eac.sensors.DeterministicTerrainWorld
import com.example.eac.sensors.EnvironmentConditions
import com.example.eac.sensors.FaultInjectionConfig
import com.example.eac.sensors.SimulatedSensorAdapter
import com.example.eac.sensors.SensorFrameBundle
import com.example.eac.sensors.TerrainScenario
import com.example.eac.state.EkfStateEstimator
import com.example.eac.state.EstimatedVehicleState
import com.example.eac.telemetry.TelemetryRecorder
import com.example.eac.traversability.TraversabilityEngine
import com.example.eac.traversability.TraversabilityMap
import com.example.eac.vehicle.EffectiveVehicleLimits
import com.example.eac.vehicle.VehicleModelRegistry
import com.example.eac.vehicle.VehicleProfile
import com.example.eac.vehicle.VehicleSensitivityInput
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ExpeditionViewModel : ViewModel() {
    private var scenario = TerrainScenario.ROCKY_TRACK_ACCEPTANCE
    private var vehicleProfile = VehicleModelRegistry.grenadierBaseline
    private var sensitivity = VehicleSensitivityInput()
    private var privEnvConditions = EnvironmentConditions()
    private var privFaultConfig = FaultInjectionConfig()
    private var privOperatingMode = OperatingMode.MODE_A_TERRAIN_ASSIST

    private var world = DeterministicTerrainWorld(scenario, scenario.defaultSeed)
    private var sensorAdapter = SimulatedSensorAdapter(scenario.defaultSeed)
    private var ekf = EkfStateEstimator()
    private var terrainEngine = TerrainPerceptionEngine()
    private var travEngine = TraversabilityEngine()
    private var planner = HierarchicalPlanner()
    private var controlInterface = ResearchControlInterface(vehicleProfile)
    private var supervisor = IndependentSafetySupervisor()
    private var telemetryRecorder = TelemetryRecorder()

    private var simSeq = 0L
    private var simTime = 0.0
    private var simPoseX = 0.0
    private var simPoseY = 0.0
    private var simPoseYaw = 0.0
    private var simVx = 0.0

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _simTimeSec = MutableStateFlow(0.0)
    val simTimeSec: StateFlow<Double> = _simTimeSec.asStateFlow()

    private val _currentScenario = MutableStateFlow(scenario)
    val currentScenario: StateFlow<TerrainScenario> = _currentScenario.asStateFlow()

    private val _selectedProfile = MutableStateFlow(vehicleProfile)
    val selectedProfile: StateFlow<VehicleProfile> = _selectedProfile.asStateFlow()

    private val _envConditions = MutableStateFlow(privEnvConditions)
    val envConditions: StateFlow<EnvironmentConditions> = _envConditions.asStateFlow()

    private val _faultConfig = MutableStateFlow(privFaultConfig)
    val faultConfig: StateFlow<FaultInjectionConfig> = _faultConfig.asStateFlow()

    private val _frameBundle = MutableStateFlow<SensorFrameBundle?>(null)
    val frameBundle: StateFlow<SensorFrameBundle?> = _frameBundle.asStateFlow()

    private val _estState = MutableStateFlow<EstimatedVehicleState?>(null)
    val estState: StateFlow<EstimatedVehicleState?> = _estState.asStateFlow()

    private val _terrainMap = MutableStateFlow<LocalTerrainMap?>(null)
    val terrainMap: StateFlow<LocalTerrainMap?> = _terrainMap.asStateFlow()

    private val _travMap = MutableStateFlow<TraversabilityMap?>(null)
    val travMap: StateFlow<TraversabilityMap?> = _travMap.asStateFlow()

    private val _planningResult = MutableStateFlow<PlanningResult?>(null)
    val planningResult: StateFlow<PlanningResult?> = _planningResult.asStateFlow()

    private val _safetyState = MutableStateFlow(SafetyState.INITIALISING)
    val safetyState: StateFlow<SafetyState> = _safetyState.asStateFlow()

    private val _eStopLatched = MutableStateFlow(false)
    val eStopLatched: StateFlow<Boolean> = _eStopLatched.asStateFlow()

    private val _operatingMode = MutableStateFlow(privOperatingMode)
    val operatingMode: StateFlow<OperatingMode> = _operatingMode.asStateFlow()

    private val _actuationLocked = MutableStateFlow(true)
    val actuationLocked: StateFlow<Boolean> = _actuationLocked.asStateFlow()

    private val _limits = MutableStateFlow(VehicleModelRegistry.computeEffectiveLimits(vehicleProfile, sensitivity))
    val limits: StateFlow<EffectiveVehicleLimits> = _limits.asStateFlow()

    private var simJob: Job? = null

    init {
        resetSimulation()
    }

    fun selectScenario(sc: TerrainScenario) {
        scenario = sc
        _currentScenario.value = sc
        resetSimulation()
    }

    fun selectProfile(prof: VehicleProfile) {
        vehicleProfile = prof
        _selectedProfile.value = prof
        controlInterface = ResearchControlInterface(prof)
        recomputeLimits()
    }

    fun updateEnv(env: EnvironmentConditions) {
        privEnvConditions = env
        _envConditions.value = env
    }

    fun updateFaults(faults: FaultInjectionConfig) {
        privFaultConfig = faults
        _faultConfig.value = faults
    }

    fun togglePlay() {
        val playing = !_isPlaying.value
        _isPlaying.value = playing
        if (playing) {
            startLoop()
        } else {
            simJob?.cancel()
        }
    }

    fun stepSimulation() {
        tickSimulation(0.1)
    }

    fun resetSimulation() {
        _isPlaying.value = false
        simJob?.cancel()
        world = DeterministicTerrainWorld(scenario, scenario.defaultSeed)
        sensorAdapter = SimulatedSensorAdapter(scenario.defaultSeed)
        ekf.reset(com.example.eac.contracts.VehiclePose2D(0.0, 0.0, 0.0))
        simSeq = 0L
        simTime = 0.0
        simPoseX = 0.0
        simPoseY = 0.0
        simPoseYaw = 0.0
        simVx = scenario.nominalSpeedMps

        _simTimeSec.value = 0.0
        telemetryRecorder.clear()
        tickSimulation(0.05)
    }

    fun toggleEStop() {
        if (controlInterface.emergencyStopLatch) {
            controlInterface.releaseEmergencyStop()
            _eStopLatched.value = false
        } else {
            controlInterface.triggerEmergencyStop()
            _eStopLatched.value = true
        }
    }

    fun changeMode(mode: OperatingMode) {
        privOperatingMode = mode
        _operatingMode.value = mode
        controlInterface.currentMode = mode
        _actuationLocked.value = controlInterface.physicalActuationLocked
    }

    fun unlockActuation() {
        controlInterface.requestUnlockPhysicalActuation(true)
        _actuationLocked.value = controlInterface.physicalActuationLocked
    }

    private fun startLoop() {
        simJob?.cancel()
        simJob = viewModelScope.launch {
            while (_isPlaying.value) {
                delay(100L)
                tickSimulation(0.1)
                if (simPoseX >= scenario.goalX) {
                    _isPlaying.value = false
                    break
                }
            }
        }
    }

    private fun tickSimulation(dt: Double) {
        simSeq++
        simTime += dt

        val currentPlan = _planningResult.value
        val targetSpeed = if (controlInterface.emergencyStopLatch) 0.0 else (currentPlan?.recommendedSpeedMps ?: scenario.nominalSpeedMps)
        val targetSteer = currentPlan?.recommendedSteeringDeg ?: 0.0
        val steerRad = Math.toRadians(targetSteer)

        simVx += (targetSpeed - simVx) * 0.3 * dt
        val effectiveVx = simVx.coerceIn(0.0, 3.0)
        val wheelbase = vehicleProfile.wheelbaseM.value
        val yawRate = (effectiveVx / wheelbase) * kotlin.math.tan(steerRad)
        simPoseYaw += yawRate * dt
        simPoseX += effectiveVx * kotlin.math.cos(simPoseYaw) * dt
        simPoseY += effectiveVx * kotlin.math.sin(simPoseYaw) * dt

        val truePose = com.example.eac.contracts.VehiclePose2D(simPoseX, simPoseY, simPoseYaw)

        val frame = sensorAdapter.captureFrame(
            seq = simSeq,
            simTimeSec = simTime,
            world = world,
            truePose = truePose,
            trueVxMps = effectiveVx,
            trueYawRateRadS = yawRate,
            steeringAngleDeg = targetSteer,
            env = privEnvConditions,
            faults = privFaultConfig,
        )

        val est = ekf.update(frame, dt)
        val terrain = terrainEngine.reconstruct(frame, est.pose, privEnvConditions)
        val currentLimits = _limits.value
        val trav = travEngine.evaluate(terrain, currentLimits, effectiveVx)

        val plan = planner.plan(
            seq = simSeq,
            timestampNs = frame.timestampNs,
            estimatedPose = est.pose,
            globalWaypoints = frame.globalCorridorWaypoints,
            terrain = terrain,
            traversability = trav,
            profile = vehicleProfile,
            limits = currentLimits,
            currentVxMps = effectiveVx,
        )

        val sensorHealthOk = frame.healthRecords.all { it.status != com.example.eac.contracts.SensorStatus.DROPPED }
        val safetySt = supervisor.evaluate(
            simTimeSec = simTime,
            sensorHealthOk = sensorHealthOk,
            localization = est,
            terrain = terrain,
            traversability = trav,
            planning = plan,
            controlInterface = controlInterface,
        )

        telemetryRecorder.recordFrame(frame, est, plan, safetySt)

        _simTimeSec.value = simTime
        _frameBundle.value = frame
        _estState.value = est
        _terrainMap.value = terrain
        _travMap.value = trav
        _planningResult.value = plan
        _safetyState.value = safetySt
        _eStopLatched.value = controlInterface.emergencyStopLatch
    }

    private fun recomputeLimits() {
        val l = VehicleModelRegistry.computeEffectiveLimits(vehicleProfile, sensitivity)
        _limits.value = l
    }
}
