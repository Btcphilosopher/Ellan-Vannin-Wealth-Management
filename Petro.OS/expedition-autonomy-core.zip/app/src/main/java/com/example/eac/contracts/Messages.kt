package com.example.eac.contracts

/**
 * Versioned inter-module message header for deterministic replay,
 * coordinate-frame traceability, and latency/deadline accounting.
 */
data class MessageHeader(
    val seq: Long,
    val timestampNs: Long,
    val frameId: String,
    val schemaVersion: String = "eac.v1.0",
)

enum class OperatingMode(val code: String, val label: String, val description: String) {
    MODE_A_TERRAIN_ASSIST(
        code = "MODE A",
        label = "TERRAIN ASSIST",
        description = "Perceive terrain, assess risk, recommend lines and speeds to human driver.",
    ),
    MODE_B_SUPERVISED_LOW_SPEED(
        code = "MODE B",
        label = "SUPERVISED LOW-SPEED",
        description = "Execute validated low-speed manoeuvres with safety operator & independent E-Stop.",
    ),
    MODE_C_AUTONOMOUS_RESEARCH(
        code = "MODE C",
        label = "AUTONOMOUS RESEARCH",
        description = "Experimental planning/control in simulation & approved closed facilities only.",
    ),
}

enum class SafetyState(val label: String, val allowsSimulatedControl: Boolean) {
    INITIALISING("INITIALISING", false),
    OBSERVATION_ONLY("OBSERVATION_ONLY", false),
    READY_FOR_TEST("READY_FOR_TEST", false),
    SUPERVISED_AUTONOMY("SUPERVISED_AUTONOMY", true),
    DEGRADED("DEGRADED", false),
    SAFE_STOP("SAFE_STOP", false),
    FAULT_LOCKOUT("FAULT_LOCKOUT", false),
}

enum class SensorType(val displayName: String, val frameId: String, val expectedHz: Double, val criticalForAutonomy: Boolean) {
    FORWARD_CAMERA("Forward Mono Camera", "cam_front", 30.0, false),
    STEREO_CAMERA("Stereo Depth Camera", "cam_stereo", 20.0, false),
    SURROUND_CAMERA("Surround-View Rig", "cam_surround", 15.0, false),
    LIDAR_3D("Roof 3D LiDAR", "lidar_top", 10.0, true),
    RADAR("Front Millimeter Radar", "radar_front", 20.0, false),
    GNSS("Dual-Antenna GNSS", "gnss_roof", 10.0, false),
    IMU("6-Axis Tactical IMU", "imu_center", 100.0, true),
    WHEEL_SPEED("4x Wheel Encoders", "base_link", 50.0, true),
    STEERING_ANGLE("Steering Column Sensor", "steer_shaft", 50.0, true),
    VEHICLE_SPEED("Drivetrain Speed Bus", "base_link", 50.0, true),
    SUSPENSION_TRAVEL("Axle Articulation", "chassis_axles", 25.0, false),
    ENV_SENSORS("Dust / Rain / Lux", "roof_env", 5.0, false),
}

enum class SensorStatus {
    HEALTHY,
    DEGRADED,
    DROPPED,
    OCCLUDED,
    UNMOUNTED,
    UNCALIBRATED,
}

data class ExtrinsicTransform(
    val xM: Double,
    val yM: Double,
    val zM: Double,
    val rollDeg: Double,
    val pitchDeg: Double,
    val yawDeg: Double,
)

data class SensorHealthRecord(
    val type: SensorType,
    val header: MessageHeader,
    val fitted: Boolean,
    val calibrated: Boolean,
    val status: SensorStatus,
    val actualHz: Double,
    val latencyMs: Double,
    val confidence: Double,
    val extrinsic: ExtrinsicTransform,
    val diagnosticNote: String,
)

data class ComponentHealth(
    val moduleName: String,
    val healthy: Boolean,
    val latencyMs: Double,
    val deadlineMs: Double,
    val confidence: Double,
    val statusNote: String,
) {
    val deadlineMissed: Boolean get() = latencyMs > deadlineMs
}

data class VehiclePose2D(
    val xM: Double,
    val yM: Double,
    val yawRad: Double,
)

data class SafetyAuditEvent(
    val timestampMs: Long,
    val simTimeSec: Double,
    val fromState: SafetyState,
    val toState: SafetyState,
    val trigger: String,
    val rationale: String,
)
