package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val EacDarkColorScheme = darkColorScheme(
    primary = MutedGreen,
    onPrimary = OffWhitePrimary,
    primaryContainer = MutedGreenContainer,
    onPrimaryContainer = MutedGreenBright,
    secondary = SlateSecondary,
    onSecondary = GraphiteBackground,
    secondaryContainer = GraphiteSurfaceElevated,
    onSecondaryContainer = OffWhitePrimary,
    tertiary = AmberWarning,
    onTertiary = GraphiteBackground,
    tertiaryContainer = AmberWarningContainer,
    onTertiaryContainer = AmberWarning,
    error = FaultRed,
    onError = OffWhitePrimary,
    errorContainer = FaultRedContainer,
    onErrorContainer = FaultRed,
    background = GraphiteBackground,
    onBackground = OffWhitePrimary,
    surface = GraphiteSurface,
    onSurface = OffWhitePrimary,
    surfaceVariant = GraphiteSurfaceElevated,
    onSurfaceVariant = OffWhiteSecondary,
    outline = SlateBorder,
    outlineVariant = SlateMuted,
)

@Composable
fun ExpeditionAutonomyTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = EacDarkColorScheme,
        typography = EacTypography,
        content = content,
    )
}
