package com.example.eac.perception

import com.example.eac.contracts.ComponentHealth
import com.example.eac.contracts.MessageHeader
import com.example.eac.contracts.VehiclePose2D
import com.example.eac.sensors.EnvironmentConditions
import com.example.eac.sensors.SemanticTerrainClass
import com.example.eac.sensors.SensorFrameBundle
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

data class TerrainCell(
    val gx: Int,
    val gy: Int,
    val localXM: Double,
    val localYM: Double,
    val worldXM: Double,
    val worldYM: Double,
    val elevationM: Double,
    val isUnknown: Boolean,
    val isOccluded: Boolean,
    val normalZ: Double,
    val slopeDeg: Double,
    val crossSlopeDeg: Double,
    val roughnessM: Double,
    val stepHeightM: Double,
    val rutDepthM: Double,
    val obstacleCandidate: Boolean,
    val vegetationDetected: Boolean,
    val waterReflectiveDetected: Boolean,
    val semanticClass: SemanticTerrainClass,
    val semanticConfidence: Double,
    val cellUncertainty: Double,
)

data class LocalTerrainMap(
    val header: MessageHeader,
    val originPose: VehiclePose2D,
    val gridWidth: Int,
    val gridHeight: Int,
    val resolutionM: Double,
    val minLocalXM: Double,
    val minLocalYM: Double,
    val cells: List<TerrainCell>,
    val knownFraction: Double,
    val occludedFraction: Double,
    val meanUncertainty: Double,
    val health: ComponentHealth,
) {
    fun cellAtLocal(lx: Double, ly: Double): TerrainCell? {
        val gx = ((lx - minLocalXM) / resolutionM).toInt()
        val gy = ((ly - minLocalYM) / resolutionM).toInt()
        if (gx !in 0 until gridWidth || gy !in 0 until gridHeight) return null
        return cells[gy * gridWidth + gx]
    }
}

/**
 * Constructs a vehicle-centric 2.5D Bird's-Eye View (BEV) terrain model.
 * Keeps geometric observations strictly separate from semantic classification hints
 * and explicitly preserves unknown/occluded cells.
 */
class TerrainPerceptionEngine(
    private val gridWidth: Int = 30,
    private val gridHeight: Int = 24,
    private val resolutionM: Double = 0.5,
) {
    private val minLocalXM = -1.5
    private val minLocalYM = -(gridHeight * resolutionM) / 2.0

    fun reconstruct(
        frame: SensorFrameBundle,
        estimatedPose: VehiclePose2D,
        env: EnvironmentConditions,
    ): LocalTerrainMap {
        val total = gridWidth * gridHeight
        val sums = DoubleArray(total)
        val sqSums = DoubleArray(total)
        val counts = IntArray(total)
        val minZ = DoubleArray(total) { Double.POSITIVE_INFINITY }
        val maxZ = DoubleArray(total) { Double.NEGATIVE_INFINITY }
        val semCounts = Array(total) { IntArray(SemanticTerrainClass.entries.size) }
        val semConfSum = DoubleArray(total)
        val waterHits = IntArray(total)

        val baseZ = if (frame.lidarPoints.isNotEmpty()) {
            frame.lidarPoints.minOf { it.worldZ - it.localZ }
        } else {
            0.0
        }

        for (pt in frame.lidarPoints) {
            val gx = ((pt.localX - minLocalXM) / resolutionM).toInt()
            val gy = ((pt.localY - minLocalYM) / resolutionM).toInt()
            if (gx !in 0 until gridWidth || gy !in 0 until gridHeight) continue
            val idx = gy * gridWidth + gx
            val relGroundZ = pt.localZ
            sums[idx] += relGroundZ
            sqSums[idx] += relGroundZ * relGroundZ
            counts[idx]++
            if (relGroundZ < minZ[idx]) minZ[idx] = relGroundZ
            if (relGroundZ > maxZ[idx]) maxZ[idx] = relGroundZ
            semCounts[idx][pt.semanticHint.ordinal]++
            semConfSum[idx] += pt.semanticConfidence
            if (pt.semanticHint == SemanticTerrainClass.WATER_REFLECTIVE || pt.intensity < 0.25) {
                waterHits[idx]++
            }
        }

        val means = DoubleArray(total)
        val hasObs = BooleanArray(total)
        for (i in 0 until total) {
            if (counts[i] > 0) {
                means[i] = sums[i] / counts[i]
                hasObs[i] = true
            }
        }

        val cosYaw = cos(estimatedPose.yawRad)
        val sinYaw = sin(estimatedPose.yawRad)
        val cells = ArrayList<TerrainCell>(total)
        var knownCount = 0
        var occludedCount = 0
        var uncSum = 0.0

        for (gy in 0 until gridHeight) {
            for (gx in 0 until gridWidth) {
                val idx = gy * gridWidth + gx
                val lx = minLocalXM + (gx + 0.5) * resolutionM
                val ly = minLocalYM + (gy + 0.5) * resolutionM
                val wx = estimatedPose.xM + lx * cosYaw - ly * sinYaw
                val wy = estimatedPose.yM + lx * sinYaw + ly * cosYaw
                val dist = hypot(lx, ly)

                val observed = hasObs[idx]
                // Cells in forward sector with 0 LiDAR hits are explicitly occluded or unobserved!
                val inForwardSector = lx > 1.2 && abs(atan2(ly, lx)) < 1.05 && dist < 13.0
                val isOccluded = !observed && inForwardSector
                val isUnknown = !observed

                if (!isUnknown) knownCount++
                if (isOccluded) occludedCount++

                var dzdx = 0.0
                var dzdy = 0.0
                var maxNeighborDiff = 0.0
                var depressionDepth = 0.0

                if (observed) {
                    val leftIdx = if (gx > 0 && hasObs[idx - 1]) idx - 1 else idx
                    val rightIdx = if (gx < gridWidth - 1 && hasObs[idx + 1]) idx + 1 else idx
                    val downIdx = if (gy > 0 && hasObs[idx - gridWidth]) idx - gridWidth else idx
                    val upIdx = if (gy < gridHeight - 1 && hasObs[idx + gridWidth]) idx + gridWidth else idx

                    val spanX = if (leftIdx != rightIdx) (if (leftIdx != idx && rightIdx != idx) 2.0 else 1.0) * resolutionM else resolutionM
                    val spanY = if (downIdx != upIdx) (if (downIdx != idx && upIdx != idx) 2.0 else 1.0) * resolutionM else resolutionM
                    dzdx = (means[rightIdx] - means[leftIdx]) / spanX
                    dzdy = (means[upIdx] - means[downIdx]) / spanY

                    val neighborIndices = listOf(leftIdx, rightIdx, downIdx, upIdx)
                    var neighborSum = 0.0
                    var neighborN = 0
                    for (ni in neighborIndices) {
                        if (ni != idx && hasObs[ni]) {
                            maxNeighborDiff = max(maxNeighborDiff, abs(means[ni] - means[idx]))
                            neighborSum += means[ni]
                            neighborN++
                        }
                    }
                    if (neighborN > 0) {
                        val avgNeighbor = neighborSum / neighborN
                        depressionDepth = max(0.0, avgNeighbor - means[idx])
                    }
                }

                val normalMag = sqrt(dzdx * dzdx + dzdy * dzdy + 1.0)
                val nz = if (observed) 1.0 / normalMag else 1.0
                val slopeDeg = if (observed) Math.toDegrees(atan2(abs(dzdx), 1.0)) else 0.0
                val crossSlopeDeg = if (observed) Math.toDegrees(atan2(abs(dzdy), 1.0)) else 0.0

                val variance = if (counts[iCount(idx)] > 1) {
                    val m = means[idx]
                    max(0.0, (sqSums[idx] / counts[idx]) - m * m)
                } else 0.0
                val roughness = if (observed) sqrt(variance) + (maxZ[idx] - minZ[idx]) * 0.25 else 0.0
                val stepHeight = if (observed) max(maxNeighborDiff, (maxZ[idx] - minZ[idx]) * 0.7) else 0.0

                var dominantSem = SemanticTerrainClass.UNKNOWN
                var bestSemCount = 0
                if (observed) {
                    for (s in SemanticTerrainClass.entries) {
                        val c = semCounts[idx][s.ordinal]
                        if (c > bestSemCount) {
                            bestSemCount = c
                            dominantSem = s
                        }
                    }
                }
                val semConf = if (observed && counts[idx] > 0) {
                    (semConfSum[idx] / counts[idx]) * (1.0 - frame.cameraOcclusionFraction * 0.6)
                } else 0.0

                val isVegetation = dominantSem == SemanticTerrainClass.VEGETATION && semConf > 0.35
                val isObstacle = observed && !isVegetation && (stepHeight > 0.28 || means[idx] > 0.35)
                val isWater = observed && waterHits[idx] > 0

                val cellUncertainty = if (isUnknown) {
                    1.0
                } else {
                    (0.08 + (dist / 26.0) * 0.25 + env.opticalDegradation * 0.28 +
                        (if (counts[idx] == 1) 0.18 else 0.0) +
                        frame.cameraOcclusionFraction * 0.22).coerceIn(0.05, 0.98)
                }
                uncSum += cellUncertainty

                cells.add(
                    TerrainCell(
                        gx = gx,
                        gy = gy,
                        localXM = lx,
                        localYM = ly,
                        worldXM = wx,
                        worldYM = wy,
                        elevationM = if (observed) baseZ + means[idx] else Double.NaN,
                        isUnknown = isUnknown,
                        isOccluded = isOccluded,
                        normalZ = nz,
                        slopeDeg = slopeDeg,
                        crossSlopeDeg = crossSlopeDeg,
                        roughnessM = roughness,
                        stepHeightM = stepHeight,
                        rutDepthM = depressionDepth,
                        obstacleCandidate = isObstacle,
                        vegetationDetected = isVegetation,
                        waterReflectiveDetected = isWater,
                        semanticClass = dominantSem,
                        semanticConfidence = semConf,
                        cellUncertainty = cellUncertainty,
                    )
                )
            }
        }

        val knownFraction = knownCount.toDouble() / total
        val occludedFraction = occludedCount.toDouble() / total
        val meanUnc = uncSum / total
        val lidarHealthy = frame.lidarPoints.isNotEmpty()
        val latency = if (lidarHealthy) 11.4 else 2.5

        return LocalTerrainMap(
            header = MessageHeader(frame.seq, frame.timestampNs, "base_link"),
            originPose = estimatedPose,
            gridWidth = gridWidth,
            gridHeight = gridHeight,
            resolutionM = resolutionM,
            minLocalXM = minLocalXM,
            minLocalYM = minLocalYM,
            cells = cells,
            knownFraction = knownFraction,
            occludedFraction = occludedFraction,
            meanUncertainty = meanUnc,
            health = ComponentHealth(
                moduleName = "terrain_perception_bev",
                healthy = lidarHealthy && knownFraction > 0.12,
                latencyMs = latency,
                deadlineMs = 35.0,
                confidence = (knownFraction * 1.4 * (1.0 - env.opticalDegradation * 0.35)).coerceIn(0.0, 0.98),
                statusNote = if (lidarHealthy) "2.5D BEV active (${knownCount}/$total cells)" else "No LiDAR returns — terrain UNKNOWN",
            ),
        )
    }

    private fun iCount(idx: Int) = idx
}
