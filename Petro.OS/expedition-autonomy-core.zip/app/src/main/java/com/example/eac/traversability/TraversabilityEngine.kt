package com.example.eac.traversability

import com.example.eac.contracts.ComponentHealth
import com.example.eac.contracts.MessageHeader
import com.example.eac.perception.LocalTerrainMap
import com.example.eac.perception.TerrainCell
import com.example.eac.sensors.SemanticTerrainClass
import com.example.eac.vehicle.EffectiveVehicleLimits
import kotlin.math.max
import kotlin.math.min

data class TraversabilityCell(
    val gx: Int,
    val gy: Int,
    val geometricFeasible: Boolean,
    val clearanceMarginM: Double,
    val slopeRisk: Double,
    val rolloverRisk: Double,
    val estimatedTraction: Double,
    val expectedSlip: Double,
    val wheelContactUncertainty: Double,
    val cost: Double, // 0..1 when traversable, >=1.0 when impassable/refused
    val suggestedMaxSpeedMps: Double,
    val confidence: Double,
    val refusalReason: String?,
)

data class TraversabilityMap(
    val header: MessageHeader,
    val gridWidth: Int,
    val gridHeight: Int,
    val cells: List<TraversabilityCell>,
    val traversableRatio: Double,
    val inadequateEvidence: Boolean,
    val meanConfidence: Double,
    val health: ComponentHealth,
) {
    fun cellAt(gx: Int, gy: Int): TraversabilityCell? {
        if (gx !in 0 until gridWidth || gy !in 0 until gridHeight) return null
        return cells[gy * gridWidth + gx]
    }
}

/**
 * State-dependent traversability engine conditioned on vehicle geometry,
 * load/CoG sensitivity, and traction uncertainty. Never treats semantic labels
 * as direct friction guarantees; uses conservative lower-bound estimates.
 */
class TraversabilityEngine {

    fun evaluate(
        terrain: LocalTerrainMap,
        limits: EffectiveVehicleLimits,
        currentVxMps: Double,
    ): TraversabilityMap {
        val out = ArrayList<TraversabilityCell>(terrain.cells.size)
        var traversableCount = 0
        var confSum = 0.0

        for (cell in terrain.cells) {
            val evaluated = evaluateCell(cell, limits, currentVxMps)
            out.add(evaluated)
            if (evaluated.refusalReason == null && evaluated.cost < 0.95) {
                traversableCount++
            }
            confSum += evaluated.confidence
        }

        val travRatio = traversableCount.toDouble() / terrain.cells.size.coerceAtLeast(1)
        val meanConf = confSum / terrain.cells.size.coerceAtLeast(1)
        val inadequate = terrain.knownFraction < 0.14 || meanConf < 0.22

        return TraversabilityMap(
            header = MessageHeader(terrain.header.seq, terrain.header.timestampNs, terrain.header.frameId),
            gridWidth = terrain.gridWidth,
            gridHeight = terrain.gridHeight,
            cells = out,
            traversableRatio = travRatio,
            inadequateEvidence = inadequate,
            meanConfidence = meanConf,
            health = ComponentHealth(
                moduleName = "traversability_engine",
                healthy = !inadequate,
                latencyMs = 4.6,
                deadlineMs = 25.0,
                confidence = meanConf,
                statusNote = if (inadequate) "Refusing recommendation: inadequate terrain evidence" else "Traversability field evaluated",
            ),
        )
    }

    private fun evaluateCell(
        cell: TerrainCell,
        limits: EffectiveVehicleLimits,
        currentVxMps: Double,
    ): TraversabilityCell {
        if (cell.isUnknown) {
            return TraversabilityCell(
                gx = cell.gx,
                gy = cell.gy,
                geometricFeasible = false,
                clearanceMarginM = 0.0,
                slopeRisk = 1.0,
                rolloverRisk = 1.0,
                estimatedTraction = 0.0,
                expectedSlip = 1.0,
                wheelContactUncertainty = 1.0,
                cost = 1.0,
                suggestedMaxSpeedMps = 0.0,
                confidence = 0.0,
                refusalReason = if (cell.isOccluded) "Occluded terrain behind obstacle" else "Unobserved terrain",
            )
        }

        // Conservative traction lower bound (semantic hint only reduces or bounds traction, never inflates!)
        val baseTraction = when (cell.semanticClass) {
            SemanticTerrainClass.ROCK -> 0.72
            SemanticTerrainClass.GRAVEL -> 0.56
            SemanticTerrainClass.SAND -> 0.40
            SemanticTerrainClass.MUD -> 0.28
            SemanticTerrainClass.WATER_REFLECTIVE -> 0.24
            SemanticTerrainClass.VEGETATION -> 0.42
            SemanticTerrainClass.UNKNOWN -> 0.30
        } * limits.effectiveTractionMultiplier

        val estTraction = baseTraction.coerceIn(0.15, 0.85)
        val slopeRisk = (cell.slopeDeg / limits.maxOperationalPitchDeg).coerceIn(0.0, 1.5)
        // Speed amplifies rollover dynamic lateral load transfer
        val speedFactor = 1.0 + (currentVxMps / 4.0) * 0.22
        val rolloverRisk = ((cell.crossSlopeDeg * speedFactor) / limits.maxOperationalCrossSlopeDeg).coerceIn(0.0, 1.5)

        val clearanceMargin = limits.maxObstacleStepM - cell.stepHeightM
        val wheelContactUnc = (cell.roughnessM / 0.16 + cell.cellUncertainty * 0.5).coerceIn(0.05, 0.99)
        val expectedSlip = ((1.0 - estTraction) * 0.6 + (cell.slopeDeg / 35.0) * 0.4).coerceIn(0.02, 0.95)

        val reason: String? = when {
            cell.obstacleCandidate -> "Obstacle step ${"%.2f".format(cell.stepHeightM)}m > limit ${"%.2f".format(limits.maxObstacleStepM)}m"
            clearanceMargin < 0.0 -> "Ground clearance violated (${"%.2f".format(cell.stepHeightM)}m step)"
            rolloverRisk >= 1.0 -> "Cross-slope ${"%.1f".format(cell.crossSlopeDeg)}° exceeds rollover limit ${"%.1f".format(limits.maxOperationalCrossSlopeDeg)}°"
            slopeRisk >= 1.0 -> "Pitch slope ${"%.1f".format(cell.slopeDeg)}° exceeds limit ${"%.1f".format(limits.maxOperationalPitchDeg)}°"
            cell.rutDepthM > 0.26 -> "Deep rut ${"%.2f".format(cell.rutDepthM)}m risks grounding"
            cell.waterReflectiveDetected -> "Reflective/water surface: depth & bed unverified"
            else -> null
        }

        val geomFeasible = reason == null
        val cost = if (!geomFeasible) {
            1.0
        } else {
            (0.28 * slopeRisk +
                0.30 * rolloverRisk +
                0.20 * (cell.roughnessM / 0.18).coerceIn(0.0, 1.0) +
                0.12 * expectedSlip +
                0.10 * cell.cellUncertainty).coerceIn(0.02, 0.94)
        }

        val suggestedSpeed = if (!geomFeasible) {
            0.0
        } else {
            (limits.maxCommandSpeedMps * (1.0 - cost * 0.72)).coerceIn(0.35, limits.maxCommandSpeedMps)
        }

        val conf = ((1.0 - cell.cellUncertainty) * 0.7 + (1.0 - wheelContactUnc) * 0.3).coerceIn(0.05, 0.98)

        return TraversabilityCell(
            gx = cell.gx,
            gy = cell.gy,
            geometricFeasible = geomFeasible,
            clearanceMarginM = clearanceMargin,
            slopeRisk = slopeRisk,
            rolloverRisk = rolloverRisk,
            estimatedTraction = estTraction,
            expectedSlip = expectedSlip,
            wheelContactUncertainty = wheelContactUnc,
            cost = cost,
            suggestedMaxSpeedMps = suggestedSpeed,
            confidence = conf,
            refusalReason = reason,
        )
    }
}
