package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Restrained industrial engineering palette: graphite, off-white, muted green, slate, amber
val GraphiteBackground = Color(0xFF111417)
val GraphiteSurface = Color(0xFF181C20)
val GraphiteSurfaceElevated = Color(0xFF20262C)
val GraphiteSurfaceBright = Color(0xFF283038)
val SlateBorder = Color(0xFF313B44)
val SlateMuted = Color(0xFF5D6D7E)
val SlateSecondary = Color(0xFF8C9AA8)

val OffWhitePrimary = Color(0xFFECEFF2)
val OffWhiteSecondary = Color(0xFFB7C0C8)

val MutedGreen = Color(0xFF4B936E)
val MutedGreenContainer = Color(0xFF1D352A)
val MutedGreenBright = Color(0xFF66B38B)

val AmberWarning = Color(0xFFE09F2D)
val AmberWarningContainer = Color(0xFF3A2A11)

val FaultRed = Color(0xFFD14E4E)
val FaultRedContainer = Color(0xFF3C1A1C)

val SensorCyan = Color(0xFF4CC2D9)
val SensorCyanContainer = Color(0xFF16323A)

val UnknownHatch = Color(0xFF2A2E33)
