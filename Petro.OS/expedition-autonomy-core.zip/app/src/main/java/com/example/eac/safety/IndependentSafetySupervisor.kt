package com.example.eac.safety

import com.example.eac.contracts.SafetyAuditEvent
import com.example.eac.contracts.SafetyState
import com.example.eac.control.ResearchControlInterface
import com.example.eac.perception.LocalTerrainMap
import com.example.eac.planning.PlanningResult
import com.example.eac.state.EstimatedVehicleState
import com.example.eac.traversability.TraversabilityMap
import kotlin.math.abs

class IndependentSafetySupervisor {
    var currentState: SafetyState = SafetyState.INITIALISING
        private set

    val auditLog = mutableListOf<SafetyAuditEvent>()

    fun evaluate(
        simTimeSec: Double,
        sensorHealthOk: Boolean,
        localization: EstimatedVehicleState,
        terrain: LocalTerrainMap,
        traversability: TraversabilityMap,
        planning: PlanningResult,
        controlInterface: ResearchControlInterface,
    ): SafetyState {
        val previousState = currentState

        val eStopActive = controlInterface.emergencyStopLatch
        val localizationDegraded = !localization.authoritative || localization.positionStdM > 1.2
        val terrainUncertain = terrain.meanUncertainty > 0.65 || traversability.inadequateEvidence
        val planningFailed = planning.selectedTrajectory == null || planning.health.deadlineMissed
        val excessiveSlope = abs(localization.pitchDeg) > 22.0 || abs(localization.rollDeg) > 20.0

        val nextState = when {
            eStopActive -> SafetyState.SAFE_STOP
            excessiveSlope -> SafetyState.SAFE_STOP
            !sensorHealthOk -> SafetyState.DEGRADED
            localizationDegraded -> SafetyState.DEGRADED
            terrainUncertain -> SafetyState.DEGRADED
            planningFailed -> SafetyState.SAFE_STOP
            currentState == SafetyState.INITIALISING && sensorHealthOk -> SafetyState.OBSERVATION_ONLY
            currentState == SafetyState.OBSERVATION_ONLY && localization.authoritative && !terrainUncertain -> SafetyState.READY_FOR_TEST
            currentState == SafetyState.READY_FOR_TEST && controlInterface.currentMode.name.contains("SUPERVISED") && !controlInterface.physicalActuationLocked -> SafetyState.SUPERVISED_AUTONOMY
            currentState == SafetyState.SUPERVISED_AUTONOMY && (localizationDegraded || terrainUncertain) -> SafetyState.DEGRADED
            else -> if (currentState == SafetyState.INITIALISING) SafetyState.INITIALISING else currentState
        }

        if (nextState != previousState) {
            auditLog.add(
                SafetyAuditEvent(
                    timestampMs = System.currentTimeMillis(),
                    simTimeSec = simTimeSec,
                    fromState = previousState,
                    toState = nextState,
                    trigger = when {
                        eStopActive -> "Emergency Stop Latch Triggered"
                        excessiveSlope -> "Excessive Pitch/Roll Limit Exceeded"
                        !sensorHealthOk -> "Sensor Health Failure"
                        localizationDegraded -> "Localization Uncertainty Drift"
                        planningFailed -> "Planner Feasibility Failure"
                        else -> "State Transition Rule Satisfied"
                    },
                    rationale = "Supervisor monitored health: locStd=${"%.2f".format(localization.positionStdM)}m, travKnown=${"%.2f".format(terrain.knownFraction)}",
                )
            )
        }

        currentState = nextState
        return nextState
    }
}
