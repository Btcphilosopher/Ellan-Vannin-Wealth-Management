package com.example.eac.control

import com.example.eac.contracts.ComponentHealth
import com.example.eac.contracts.MessageHeader
import com.example.eac.contracts.OperatingMode
import com.example.eac.contracts.SafetyState
import com.example.eac.vehicle.VehicleProfile

data class ControlCommand(
    val header: MessageHeader,
    val steeringAngleDeg: Double,
    val propulsionThrottle: Double, // -1.0 to 1.0
    val brakingPressureMpa: Double,
    val emergencyStopLatch: Boolean,
    val mode: OperatingMode,
    val validityPeriodMs: Long,
    val physicalActuationAllowed: Boolean,
)

data class ActuatorFeedback(
    val actualSteeringAngleDeg: Double,
    val actualThrottle: Double,
    val actualBrakingMpa: Double,
    val watchdogAlive: Boolean,
    val actuatorLatencyMs: Double,
    val controlAuthorityGranted: Boolean,
)

class ResearchControlInterface(
    private val profile: VehicleProfile,
) {
    var emergencyStopLatch: Boolean = false
        private set

    var currentMode: OperatingMode = OperatingMode.MODE_A_TERRAIN_ASSIST
        set(value) {
            field = value
            if (value != OperatingMode.MODE_B_SUPERVISED_LOW_SPEED && value != OperatingMode.MODE_C_AUTONOMOUS_RESEARCH) {
                physicalActuationLocked = true
            }
        }

    var physicalActuationLocked: Boolean = true
        private set

    fun requestUnlockPhysicalActuation(operatorPinConfirmed: Boolean): Boolean {
        if (!profile.dbwAuthorizedPlatform) {
            physicalActuationLocked = true
            return false
        }
        if (operatorPinConfirmed && currentMode == OperatingMode.MODE_B_SUPERVISED_LOW_SPEED) {
            physicalActuationLocked = false
            return true
        }
        physicalActuationLocked = true
        return false
    }

    fun triggerEmergencyStop() {
        emergencyStopLatch = true
        physicalActuationLocked = true
    }

    fun releaseEmergencyStop() {
        emergencyStopLatch = false
    }

    fun generateCommand(
        seq: Long,
        timestampNs: Long,
        desiredSteeringDeg: Double,
        desiredSpeedMps: Double,
        safetyState: SafetyState,
    ): Pair<ControlCommand, ActuatorFeedback> {
        val clampedSteer = desiredSteeringDeg.coerceIn(-35.0, 35.0)
        val throttle = if (emergencyStopLatch || safetyState != SafetyState.SUPERVISED_AUTONOMY) {
            0.0
        } else {
            (desiredSpeedMps / 2.5).coerceIn(0.0, 0.8)
        }

        val braking = if (emergencyStopLatch || desiredSpeedMps <= 0.05) 6.0 else 0.0
        val actuationAllowed = !physicalActuationLocked && !emergencyStopLatch &&
            safetyState == SafetyState.SUPERVISED_AUTONOMY && profile.dbwAuthorizedPlatform

        val cmd = ControlCommand(
            header = MessageHeader(seq, timestampNs, "control_interface"),
            steeringAngleDeg = clampedSteer,
            propulsionThrottle = throttle,
            brakingPressureMpa = braking,
            emergencyStopLatch = emergencyStopLatch,
            mode = currentMode,
            validityPeriodMs = 150L,
            physicalActuationAllowed = actuationAllowed,
        )

        val feedback = ActuatorFeedback(
            actualSteeringAngleDeg = if (actuationAllowed) clampedSteer else 0.0,
            actualThrottle = if (actuationAllowed) throttle else 0.0,
            actualBrakingMpa = if (emergencyStopLatch) 6.0 else 0.0,
            watchdogAlive = true,
            actuatorLatencyMs = 12.5,
            controlAuthorityGranted = actuationAllowed,
        )

        return cmd to feedback
    }
}
