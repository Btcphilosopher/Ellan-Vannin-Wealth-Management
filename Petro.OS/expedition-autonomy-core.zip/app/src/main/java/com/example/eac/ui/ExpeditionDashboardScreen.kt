package com.example.eac.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CarCrash
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.eac.contracts.OperatingMode
import com.example.eac.contracts.SafetyState
import com.example.eac.contracts.SensorStatus
import com.example.eac.perception.LocalTerrainMap
import com.example.eac.planning.PlanningResult
import com.example.eac.sensors.EnvironmentConditions
import com.example.eac.sensors.FaultInjectionConfig
import com.example.eac.sensors.SemanticTerrainClass
import com.example.eac.sensors.SensorFrameBundle
import com.example.eac.sensors.TerrainScenario
import com.example.eac.state.EstimatedVehicleState
import com.example.eac.traversability.TraversabilityMap
import com.example.eac.vehicle.EffectiveVehicleLimits
import com.example.eac.vehicle.VehicleProfile
import kotlin.math.abs
import kotlin.math.hypot

enum class DashboardTab(val label: String) {
    BEV_TELEM("BEV & TELEM"),
    TRAVERSABILITY("TRAVERSABILITY"),
    PLANNING("PLANNING"),
    SENSORS("SENSORS"),
    VEHICLE("VEHICLE & LIMITS"),
    SAFETY("SAFETY & FAULTS"),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpeditionDashboardScreen(
    currentScenario: TerrainScenario,
    onSelectScenario: (TerrainScenario) -> Unit,
    selectedProfile: VehicleProfile,
    onSelectProfile: (VehicleProfile) -> Unit,
    env: EnvironmentConditions,
    onUpdateEnv: (EnvironmentConditions) -> Unit,
    faults: FaultInjectionConfig,
    onUpdateFaults: (FaultInjectionConfig) -> Unit,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    onStep: () -> Unit,
    onReset: () -> Unit,
    simTimeSec: Double,
    frameBundle: SensorFrameBundle?,
    estState: EstimatedVehicleState?,
    terrainMap: LocalTerrainMap?,
    travMap: TraversabilityMap?,
    planningResult: PlanningResult?,
    safetyState: SafetyState,
    eStopLatched: Boolean,
    onToggleEStop: () -> Unit,
    operatingMode: OperatingMode,
    onChangeMode: (OperatingMode) -> Unit,
    actuationLocked: Boolean,
    onUnlockActuation: () -> Unit,
    limits: EffectiveVehicleLimits,
) {
    var activeTab by remember { mutableStateOf(DashboardTab.BEV_TELEM) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(
                                    when (safetyState) {
                                        SafetyState.SUPERVISED_AUTONOMY -> Color(0xFF4B936E)
                                        SafetyState.READY_FOR_TEST -> Color(0xFF4CC2D9)
                                        SafetyState.DEGRADED -> Color(0xFFE09F2D)
                                        SafetyState.SAFE_STOP, SafetyState.FAULT_LOCKOUT -> Color(0xFFD14E4E)
                                        else -> Color.Gray
                                    },
                                    shape = RoundedCornerShape(50)
                                )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "EXPEDITION AUTONOMY CORE",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onPrimary,
                            )
                            Text(
                                text = "MODE: ${operatingMode.code} | STATE: ${safetyState.name} | t=${"%.1f".format(simTimeSec)}s",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary,
                            )
                        }
                    }
                },
                actions = {
                    Button(
                        onClick = onToggleEStop,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (eStopLatched) Color(0xFFD14E4E) else Color(0xFF3A2A11),
                            contentColor = if (eStopLatched) Color.White else Color(0xFFE09F2D),
                        ),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("estop_button"),
                    ) {
                        Icon(
                            imageVector = if (eStopLatched) Icons.Default.CarCrash else Icons.Default.Warning,
                            contentDescription = "Emergency stop latch",
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (eStopLatched) "E-STOP LATCHED" else "E-STOP ARM",
                            style = MaterialTheme.typography.labelMedium,
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
            ) {
                DashboardTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        icon = {
                            Icon(
                                imageVector = when (tab) {
                                    DashboardTab.BEV_TELEM -> Icons.Default.Dashboard
                                    DashboardTab.TRAVERSABILITY -> Icons.Default.Explore
                                    DashboardTab.PLANNING -> Icons.Default.Engineering
                                    DashboardTab.SENSORS -> Icons.Default.CompassCalibration
                                    DashboardTab.VEHICLE -> Icons.Default.Settings
                                    DashboardTab.SAFETY -> Icons.Default.Security
                                },
                                contentDescription = tab.label,
                            )
                        },
                        label = {
                            Text(
                                text = tab.name.split("_")[0],
                                style = MaterialTheme.typography.labelSmall,
                            )
                        },
                    )
                }
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = 2.dp,
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onTogglePlay,
                            modifier = Modifier.testTag("play_pause_button"),
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Toggle simulation playback",
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                        IconButton(
                            onClick = onStep,
                            modifier = Modifier.testTag("step_sim_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipNext,
                                contentDescription = "Advance simulation by one tick",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(
                            onClick = onReset,
                            modifier = Modifier.testTag("reset_sim_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reset simulation scenario",
                                tint = MaterialTheme.colorScheme.error,
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        TerrainScenario.entries.forEach { sc ->
                            val selected = sc == currentScenario
                            Surface(
                                modifier = Modifier
                                    .clickable { onSelectScenario(sc) }
                                    .testTag("scenario_${sc.id}"),
                                shape = RoundedCornerShape(16.dp),
                                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                            ) {
                                Text(
                                    text = sc.title.split(" ")[0] + " " + sc.title.split(" ").getOrElse(1) { "" },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                            }
                        }
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.0f)
                    .padding(8.dp),
            ) {
                when (activeTab) {
                    DashboardTab.BEV_TELEM -> BevTelemTab(
                        frameBundle = frameBundle,
                        estState = estState,
                        terrainMap = terrainMap,
                        travMap = travMap,
                        planningResult = planningResult,
                        safetyState = safetyState,
                        limits = limits,
                    )
                    DashboardTab.TRAVERSABILITY -> TraversabilityTab(
                        travMap = travMap,
                        terrainMap = terrainMap,
                    )
                    DashboardTab.PLANNING -> PlanningTab(
                        planningResult = planningResult,
                    )
                    DashboardTab.SENSORS -> SensorsTab(
                        frameBundle = frameBundle,
                    )
                    DashboardTab.VEHICLE -> VehicleTab(
                        selectedProfile = selectedProfile,
                        onSelectProfile = onSelectProfile,
                        limits = limits,
                    )
                    DashboardTab.SAFETY -> SafetyTab(
                        safetyState = safetyState,
                        operatingMode = operatingMode,
                        onChangeMode = onChangeMode,
                        actuationLocked = actuationLocked,
                        onUnlockActuation = onUnlockActuation,
                        faults = faults,
                        onUpdateFaults = onUpdateFaults,
                        env = env,
                        onUpdateEnv = onUpdateEnv,
                    )
                }
            }
        }
    }
}

@Composable
fun BevTelemTab(
    frameBundle: SensorFrameBundle?,
    estState: EstimatedVehicleState?,
    terrainMap: LocalTerrainMap?,
    travMap: TraversabilityMap?,
    planningResult: PlanningResult?,
    safetyState: SafetyState,
    limits: EffectiveVehicleLimits,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TelemMetricCard(
                label = "VELOCITY",
                value = "${"%.2f".format(estState?.vxMps ?: 0.0)} m/s",
                sub = "Slip: ${"%.1f".format((frameBundle?.wheelSlipObserved ?: 0.0) * 100)}%",
                modifier = Modifier.weight(1.0f),
            )
            TelemMetricCard(
                label = "PITCH / ROLL",
                value = "${"%.1f".format(estState?.pitchDeg ?: 0.0)}° / ${"%.1f".format(estState?.rollDeg ?: 0.0)}°",
                sub = "Limits: ±${limits.maxOperationalPitchDeg.toInt()}°",
                modifier = Modifier.weight(1.0f),
            )
            TelemMetricCard(
                label = "LOCALIZATION",
                value = "σ=±${"%.2f".format(estState?.positionStdM ?: 0.0)}m",
                sub = if (estState?.authoritative == true) "EKF Locked" else "Degraded",
                alert = !(estState?.authoritative ?: true),
                modifier = Modifier.weight(1.0f),
            )
            TelemMetricCard(
                label = "PLANNER",
                value = "${"%.1f".format(planningResult?.plannerLatencyMs ?: 0.0)} ms",
                sub = planningResult?.selectedTrajectory?.id ?: "NO PATH",
                alert = planningResult?.selectedTrajectory == null,
                modifier = Modifier.weight(1.0f),
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = "BIRD'S-EYE VIEW (BEV) TERRAIN & TRAJECTORY",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                    Text(
                        text = "Coverage: ${( (terrainMap?.knownFraction ?: 0.0) * 100 ).toInt()}% | Occluded: ${( (terrainMap?.occludedFraction ?: 0.0) * 100 ).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.0f)
                        .background(Color(0xFF0D1013), shape = RoundedCornerShape(8.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawBevContent(terrainMap, travMap, planningResult, frameBundle)
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "ACTIVE PLANNER CANDIDATES & REJECTION LOG",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.tertiary,
                )
                Spacer(modifier = Modifier.height(6.dp))
                if (planningResult?.candidates.isNullOrEmpty()) {
                    Text(text = "Initializing planning lattice...", style = MaterialTheme.typography.bodyMedium)
                } else {
                    planningResult?.candidates?.forEach { cand ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                text = "${cand.id} (κ=${"%.2f".format(cand.curvatureInvM)})",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (cand.accepted) Color(0xFF4B936E) else Color(0xFFD14E4E),
                            )
                            Text(
                                text = if (cand.accepted) "ACCEPTED (Cost: ${"%.2f".format(cand.totalCost)})" else "REJECTED: ${cand.rejectionReason}",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (cand.accepted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TraversabilityTab(
    travMap: TraversabilityMap?,
    terrainMap: LocalTerrainMap?,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "STATE-DEPENDENT TRAVERSABILITY & RISK ANALYSIS",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Traversability is evaluated against vehicle approach angles, slope limits, rollover risk, ground clearance, and traction uncertainty. Semantic labels never override geometry.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(text = "Trav Ratio: ${"%.1f".format((travMap?.traversableRatio ?: 0.0) * 100)}%", style = MaterialTheme.typography.labelMedium)
                    Text(text = "Mean Conf: ${"%.2f".format(travMap?.meanConfidence ?: 0.0)}", style = MaterialTheme.typography.labelMedium)
                    Text(text = "Inadequate Evidence: ${travMap?.inadequateEvidence == true}", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
fun PlanningTab(planningResult: PlanningResult?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "HIERARCHICAL PLANNING & RETREAT CORRIDORS",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Distance to Goal: ${"%.1f".format(planningResult?.globalDistanceRemainingM ?: 0.0)} m", style = MaterialTheme.typography.bodyMedium)
                Text(text = "Retreat Corridor Available: ${planningResult?.retreatCorridorAvailable == true}", style = MaterialTheme.typography.bodyMedium)
                Text(text = "Selected Path: ${planningResult?.selectedTrajectory?.id ?: "NONE (Safe Stop)"}", style = MaterialTheme.typography.bodyMedium)
                Text(text = "Recommended Steering: ${"%.1f".format(planningResult?.recommendedSteeringDeg ?: 0.0)}°", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
fun SensorsTab(frameBundle: SensorFrameBundle?) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        item {
            Text(
                text = "12-SENSOR CAPABILITY REGISTRY & HEALTH MONITORING",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(vertical = 4.dp),
            )
        }
        val records = frameBundle?.healthRecords ?: emptyList()
        items(records) { rec ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(1.0f)) {
                        Text(text = rec.type.displayName, style = MaterialTheme.typography.titleSmall)
                        Text(text = "Frame: ${rec.header.frameId} | Hz: ${rec.actualHz.toInt()}/${rec.type.expectedHz.toInt()} | Latency: ${"%.1f".format(rec.latencyMs)}ms", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = rec.diagnosticNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                    }
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = when (rec.status) {
                            SensorStatus.HEALTHY -> Color(0xFF1D352A)
                            SensorStatus.DEGRADED -> Color(0xFF3A2A11)
                            else -> Color(0xFF3C1A1C)
                        },
                    ) {
                        Text(
                            text = rec.status.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = when (rec.status) {
                                SensorStatus.HEALTHY -> Color(0xFF4B936E)
                                SensorStatus.DEGRADED -> Color(0xFFE09F2D)
                                else -> Color(0xFFD14E4E)
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VehicleTab(
    selectedProfile: VehicleProfile,
    onSelectProfile: (VehicleProfile) -> Unit,
    limits: EffectiveVehicleLimits,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = "CONFIGURABLE 4X4 VEHICLE PLATFORM", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    com.example.eac.vehicle.VehicleModelRegistry.allProfiles.forEach { prof ->
                        val selected = prof.id == selectedProfile.id
                        Button(
                            onClick = { onSelectProfile(prof) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                            ),
                            modifier = Modifier.weight(1.0f),
                        ) {
                            Text(text = prof.displayName.split(" ")[0], style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = "Chassis: ${selectedProfile.chassisClass}", style = MaterialTheme.typography.bodyMedium)
                Text(text = "DBW Note: ${selectedProfile.dbwAuthorizationNote}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Effective Operational Limits (Sensitivity-Derived):", style = MaterialTheme.typography.labelMedium)
                Text(text = "• Total Mass: ${limits.totalMassKg.toInt()} kg", style = MaterialTheme.typography.bodySmall)
                Text(text = "• Effective CoG Height: ${"%.2f".format(limits.effectiveCogHeightM)} m", style = MaterialTheme.typography.bodySmall)
                Text(text = "• Static Stability Factor (SSF): ${"%.2f".format(limits.staticStabilityFactor)}", style = MaterialTheme.typography.bodySmall)
                Text(text = "• Max Operational Roll/Cross-Slope: ±${"%.1f".format(limits.maxOperationalCrossSlopeDeg)}°", style = MaterialTheme.typography.bodySmall)
                Text(text = "• Max Obstacle Step: ${"%.2f".format(limits.maxObstacleStepM)} m", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun SafetyTab(
    safetyState: SafetyState,
    operatingMode: OperatingMode,
    onChangeMode: (OperatingMode) -> Unit,
    actuationLocked: Boolean,
    onUnlockActuation: () -> Unit,
    faults: FaultInjectionConfig,
    onUpdateFaults: (FaultInjectionConfig) -> Unit,
    env: EnvironmentConditions,
    onUpdateEnv: (EnvironmentConditions) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = "OPERATING MODES & SAFETY SUPERVISOR", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(8.dp))
                OperatingMode.entries.forEach { mode ->
                    val selected = mode == operatingMode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onChangeMode(mode) }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Switch(checked = selected, onCheckedChange = { onChangeMode(mode) })
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = "${mode.code} — ${mode.label}", style = MaterialTheme.typography.titleSmall)
                            Text(text = mode.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = "Physical Drive-By-Wire Actuation:", style = MaterialTheme.typography.labelMedium)
                Text(text = "Status: ${if (actuationLocked) "LOCKED (Observation Only)" else "UNLOCKED (Supervised Test Active)"}", style = MaterialTheme.typography.bodyMedium, color = if (actuationLocked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = onUnlockActuation,
                    enabled = actuationLocked && operatingMode == OperatingMode.MODE_B_SUPERVISED_LOW_SPEED,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Text(text = "Request Safety Operator DBW Unlock (PIN Confirmed)")
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(text = "ENVIRONMENT DEGRADATION & FAULT INJECTION", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Drop LiDAR Sensor Pack", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = faults.dropLidar, onCheckedChange = { onUpdateFaults(faults.copy(dropLidar = it)) })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Degrade GNSS / Canopy Multipath", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = faults.degradeGnss, onCheckedChange = { onUpdateFaults(faults.copy(degradeGnss = it)) })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Occlude Forward Camera (Mud Splash)", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = faults.occludeForwardCamera, onCheckedChange = { onUpdateFaults(faults.copy(occludeForwardCamera = it)) })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "Inject Extreme Wheel Slip", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = faults.injectWheelSlip, onCheckedChange = { onUpdateFaults(faults.copy(injectWheelSlip = it)) })
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Dust / Rain Degradation Slider", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = env.dust.toFloat(),
                    onValueChange = { onUpdateEnv(env.copy(dust = it.toDouble(), rain = it.toDouble() * 0.5)) },
                )
            }
        }
    }
}

@Composable
fun TelemMetricCard(
    label: String,
    value: String,
    sub: String,
    alert: Boolean = false,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = if (alert) Color(0xFF3C1A1C) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (alert) Color(0xFFD14E4E) else MaterialTheme.colorScheme.outline),
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = if (alert) Color(0xFFD14E4E) else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
            Text(text = sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
        }
    }
}

fun DrawScope.drawBevContent(
    terrainMap: LocalTerrainMap?,
    travMap: TraversabilityMap?,
    planningResult: PlanningResult?,
    frameBundle: SensorFrameBundle?,
) {
    val w = size.width
    val h = size.height
    val scaleX = w / 15.0
    val scaleY = h / 12.0

    drawCircle(
        color = Color(0xFF222B34),
        radius = (5.0 * scaleX).toFloat(),
        center = Offset(w * 0.15f, h * 0.5f),
        style = Stroke(width = 1.0f),
    )
    drawCircle(
        color = Color(0xFF222B34),
        radius = (10.0 * scaleX).toFloat(),
        center = Offset(w * 0.15f, h * 0.5f),
        style = Stroke(width = 1.0f),
    )

    if (terrainMap != null) {
        for (cell in terrainMap.cells) {
            val px = w * 0.15 + cell.localXM * scaleX
            val py = h * 0.5 - cell.localYM * scaleY
            if (px !in 0.0..w.toDouble() || py !in 0.0..h.toDouble()) continue

            val color = when {
                cell.isUnknown -> Color(0xFF161A1D)
                cell.isOccluded -> Color(0xFF2A2E33)
                cell.obstacleCandidate -> Color(0xFFD14E4E)
                cell.semanticClass == SemanticTerrainClass.ROCK -> Color(0xFF8C9AA8)
                cell.semanticClass == SemanticTerrainClass.MUD -> Color(0xFF6B4F29)
                cell.semanticClass == SemanticTerrainClass.SAND -> Color(0xFFC2A359)
                cell.semanticClass == SemanticTerrainClass.WATER_REFLECTIVE -> Color(0xFF4CC2D9)
                else -> Color(0xFF20352A)
            }
            drawRect(
                color = color,
                topLeft = Offset((px - 2.5).toFloat(), (py - 2.5).toFloat()),
                size = Size(5.0f, 5.0f),
            )
        }
    }

    planningResult?.selectedTrajectory?.let { traj ->
        val path = Path()
        traj.points.forEachIndexed { idx, pt ->
            val px = (w * 0.15 + pt.localXM * scaleX).toFloat()
            val py = (h * 0.5 - pt.localYM * scaleY).toFloat()
            if (idx == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        drawPath(
            path = path,
            color = Color(0xFF4B936E),
            style = Stroke(width = 3.5f),
        )
    }

    val vehPx = (w * 0.15).toFloat()
    val vehPy = (h * 0.5).toFloat()
    drawRect(
        color = Color(0xFFECEFF2),
        topLeft = Offset(vehPx - 14f, vehPy - 9f),
        size = Size(28f, 18f),
    )
}
