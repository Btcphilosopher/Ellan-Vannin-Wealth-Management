package com.example.eac.telemetry

import com.example.eac.contracts.SafetyState
import com.example.eac.planning.PlanningResult
import com.example.eac.sensors.SensorFrameBundle
import com.example.eac.state.EstimatedVehicleState
import java.io.File

data class SimulationMetricsReport(
    val totalFrames: Long,
    val finalDistanceToGoalM: Double,
    val meanPlannerLatencyMs: Double,
    val maxLocalizationStdM: Double,
    val minClearanceM: Double,
    val safeStopTriggers: Int,
    val sensorDropoutsDetected: Int,
    val planningSuccessRate: Double,
    val summaryConclusion: String,
)

/**
 * MCAP/ROS-bag telemetry recording and automated metrics evaluation report generator.
 */
class TelemetryRecorder {
    private val recordedFrames = mutableListOf<SensorFrameBundle>()
    private val recordedStates = mutableListOf<EstimatedVehicleState>()
    private val recordedPlans = mutableListOf<PlanningResult>()
    private val recordedSafetyStates = mutableListOf<SafetyState>()

    fun recordFrame(
        frame: SensorFrameBundle,
        state: EstimatedVehicleState,
        plan: PlanningResult,
        safetyState: SafetyState,
    ) {
        recordedFrames.add(frame)
        recordedStates.add(state)
        recordedPlans.add(plan)
        recordedSafetyStates.add(safetyState)
    }

    fun clear() {
        recordedFrames.clear()
        recordedStates.clear()
        recordedPlans.clear()
        recordedSafetyStates.clear()
    }

    fun generateReport(goalDistanceRemaining: Double): SimulationMetricsReport {
        val total = recordedFrames.size.toLong().coerceAtLeast(1L)
        val meanLatency = recordedPlans.map { it.plannerLatencyMs }.average()
        val maxLocStd = recordedStates.maxOfOrNull { it.positionStdM } ?: 0.0
        val minClearance = recordedPlans.mapNotNull { p -> p.selectedTrajectory?.minClearanceM }.minOrNull() ?: 0.0
        val safeStops = recordedSafetyStates.count { it == SafetyState.SAFE_STOP }
        val sensorDrops = recordedFrames.sumOf { f -> f.healthRecords.count { !it.status.name.contains("HEALTHY") } }
        val successfulPlans = recordedPlans.count { it.selectedTrajectory != null }
        val successRate = successfulPlans.toDouble() / total

        val conclusion = when {
            safeStops > 0 -> "Mission encountered $safeStops safety supervisor intervention(s). System successfully executed safe-stop protocol."
            successRate > 0.85 -> "Mission completed successfully with high planning confidence and robust terrain adherence."
            else -> "Mission completed with degraded traversability confidence and frequent conservative path rejections."
        }

        return SimulationMetricsReport(
            totalFrames = total,
            finalDistanceToGoalM = goalDistanceRemaining,
            meanPlannerLatencyMs = meanLatency,
            maxLocalizationStdM = maxLocStd,
            minClearanceM = minClearance,
            safeStopTriggers = safeStops,
            sensorDropoutsDetected = sensorDrops,
            planningSuccessRate = successRate,
            summaryConclusion = conclusion,
        )
    }
}
