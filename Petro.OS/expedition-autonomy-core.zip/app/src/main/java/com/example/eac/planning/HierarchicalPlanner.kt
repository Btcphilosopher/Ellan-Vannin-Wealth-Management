package com.example.eac.planning

import com.example.eac.contracts.ComponentHealth
import com.example.eac.contracts.MessageHeader
import com.example.eac.contracts.VehiclePose2D
import com.example.eac.perception.LocalTerrainMap
import com.example.eac.traversability.TraversabilityMap
import com.example.eac.vehicle.EffectiveVehicleLimits
import com.example.eac.vehicle.VehicleProfile
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

data class TrajectoryPoint(
    val localXM: Double,
    val localYM: Double,
    val localYawRad: Double,
    val targetSpeedMps: Double,
)

data class CandidateTrajectory(
    val id: String,
    val curvatureInvM: Double,
    val points: List<TrajectoryPoint>,
    val accepted: Boolean,
    val totalCost: Double,
    val minClearanceM: Double,
    val maxCrossSlopeDeg: Double,
    val maxUncertainty: Double,
    val targetSpeedMps: Double,
    val rejectionReason: String?,
)

data class PlanningResult(
    val header: MessageHeader,
    val globalPathWorld: List<Pair<Double, Double>>,
    val globalDistanceRemainingM: Double,
    val retreatCorridorAvailable: Boolean,
    val candidates: List<CandidateTrajectory>,
    val selectedTrajectory: CandidateTrajectory?,
    val recommendedSteeringDeg: Double,
    val recommendedSpeedMps: Double,
    val plannerLatencyMs: Double,
    val health: ComponentHealth,
)

/**
 * Hierarchical Planner:
 * - Global planner evaluates waypoint corridor, distance, retreat corridor & map confidence.
 * - Local constrained lattice planner rolls out kinematic bicycle arcs within turning radius,
 *   evaluating full vehicle width footprint against terrain geometry, clearance, slope,
 *   unknown/occluded zones, and stopping distance.
 */
class HierarchicalPlanner {

    fun plan(
        seq: Long,
        timestampNs: Long,
        estimatedPose: VehiclePose2D,
        globalWaypoints: List<Pair<Double, Double>>,
        terrain: LocalTerrainMap,
        traversability: TraversabilityMap,
        profile: VehicleProfile,
        limits: EffectiveVehicleLimits,
        currentVxMps: Double,
    ): PlanningResult {
        val startNs = System.nanoTime()

        // Find active global target ahead of vehicle
        val goal = globalWaypoints.lastOrNull() ?: (25.0 to 0.0)
        val distToGoal = hypot(goal.first - estimatedPose.xM, goal.second - estimatedPose.yM)
        val lookaheadTargetWorld = selectLookaheadWaypoint(estimatedPose, globalWaypoints, lookaheadM = 7.0)

        // Transform lookahead target into local vehicle frame
        val dxW = lookaheadTargetWorld.first - estimatedPose.xM
        val dyW = lookaheadTargetWorld.second - estimatedPose.yM
        val cosY = cos(-estimatedPose.yawRad)
        val sinY = sin(-estimatedPose.yawRad)
        val targetLocalX = dxW * cosY - dyW * sinY
        val targetLocalY = dxW * sinY + dyW * cosY

        val maxCurvature = 1.0 / profile.minTurningRadiusM.value
        val curvatureSteps = listOf(-1.0, -0.78, -0.55, -0.35, -0.18, 0.0, 0.18, 0.35, 0.55, 0.78, 1.0)
            .map { it * maxCurvature }

        val horizonM = 7.5
        val stepM = 0.5
        val halfWidth = profile.vehicleWidthM.value * 0.5
        val stoppingDistanceM = (currentVxMps * currentVxMps) / (2.0 * limits.maxBrakingDecelMps2) + limits.minStoppingMarginM

        val candidates = ArrayList<CandidateTrajectory>(curvatureSteps.size)

        for ((idx, kappa) in curvatureSteps.withIndex()) {
            val pts = mutableListOf<TrajectoryPoint>()
            var lx = 0.0
            var ly = 0.0
            var lyaw = 0.0
            var minClearance = limits.maxObstacleStepM
            var maxCrossSlope = 0.0
            var maxUnc = 0.0
            var costAccum = 0.0
            var minSuggestedSpeed = limits.maxCommandSpeedMps
            var unknownCellsHit = 0
            var rejectReason: String? = null

            val steps = (horizonM / stepM).toInt()
            for (s in 1..steps) {
                lx += stepM * cos(lyaw)
                ly += stepM * sin(lyaw)
                lyaw += kappa * stepM

                // Check vehicle lateral footprint (left wheel track, center, right wheel track)
                val lateralOffsets = listOf(-halfWidth * 0.85, 0.0, halfWidth * 0.85)
                var stepMaxCost = 0.0

                for (lat in lateralOffsets) {
                    val sampleX = lx - lat * sin(lyaw)
                    val sampleY = ly + lat * cos(lyaw)
                    val tCell = terrain.cellAtLocal(sampleX, sampleY)
                    if (tCell == null || tCell.isUnknown) {
                        unknownCellsHit++
                        maxUnc = max(maxUnc, 1.0)
                        if (s * stepM <= stoppingDistanceM + 1.0 && rejectReason == null) {
                            rejectReason = if (tCell?.isOccluded == true) {
                                "Enters occluded shadow within stopping distance"
                            } else {
                                "Insufficient terrain coverage within stopping horizon"
                            }
                        }
                        continue
                    }

                    val trav = traversability.cellAt(tCell.gx, tCell.gy)
                    if (trav != null) {
                        minClearance = min(minClearance, trav.clearanceMarginM)
                        maxCrossSlope = max(maxCrossSlope, tCell.crossSlopeDeg)
                        maxUnc = max(maxUnc, tCell.cellUncertainty)
                        minSuggestedSpeed = min(minSuggestedSpeed, trav.suggestedMaxSpeedMps)
                        stepMaxCost = max(stepMaxCost, trav.cost)

                        if (trav.refusalReason != null && rejectReason == null) {
                            rejectReason = "@${"%.1f".format(s * stepM)}m: ${trav.refusalReason}"
                        }
                    }
                }
                costAccum += stepMaxCost

                pts.add(
                    TrajectoryPoint(
                        localXM = lx,
                        localYM = ly,
                        localYawRad = lyaw,
                        targetSpeedMps = minSuggestedSpeed,
                    )
                )
            }

            if (traversability.inadequateEvidence && rejectReason == null) {
                rejectReason = "Global evidence inadequate (refusing to recommend path)"
            }
            if (unknownCellsHit > 12 && rejectReason == null) {
                rejectReason = "Excessive unverified cells ($unknownCellsHit samples)"
            }

            // Progress alignment towards global corridor target
            val endPt = pts.last()
            val goalAlignDist = hypot(endPt.localXM - targetLocalX, endPt.localYM - targetLocalY)
            val totalCost = (costAccum / steps) * 2.5 + goalAlignDist * 0.22 + abs(kappa) * 0.45

            candidates.add(
                CandidateTrajectory(
                    id = "ARC-${idx + 1}",
                    curvatureInvM = kappa,
                    points = pts,
                    accepted = rejectReason == null,
                    totalCost = totalCost,
                    minClearanceM = minClearance,
                    maxCrossSlopeDeg = maxCrossSlope,
                    maxUncertainty = maxUnc,
                    targetSpeedMps = if (rejectReason == null) minSuggestedSpeed else 0.0,
                    rejectionReason = rejectReason,
                )
            )
        }

        val selected = candidates.filter { it.accepted }.minByOrNull { it.totalCost }
        val steerRad = if (selected != null) {
            atan2(profile.wheelbaseM.value * selected.curvatureInvM, 1.0)
        } else 0.0
        val steerDeg = Math.toDegrees(steerRad)
        val recSpeed = selected?.targetSpeedMps ?: 0.0
        val retreatOk = terrain.cells.count { !it.isUnknown && it.localXM < 0.5 && !it.obstacleCandidate } >= 4

        val latencyMs = ((System.nanoTime() - startNs) / 1_000_000.0).coerceAtLeast(1.4)

        return PlanningResult(
            header = MessageHeader(seq, timestampNs, "base_link"),
            globalPathWorld = globalWaypoints,
            globalDistanceRemainingM = distToGoal,
            retreatCorridorAvailable = retreatOk,
            candidates = candidates,
            selectedTrajectory = selected,
            recommendedSteeringDeg = steerDeg,
            recommendedSpeedMps = recSpeed,
            plannerLatencyMs = latencyMs,
            health = ComponentHealth(
                moduleName = "hierarchical_planner",
                healthy = selected != null,
                latencyMs = latencyMs,
                deadlineMs = 40.0,
                confidence = if (selected != null) (1.0 - selected.maxUncertainty * 0.6).coerceIn(0.2, 0.96) else 0.0,
                statusNote = if (selected != null) {
                    "Selected ${selected.id} (${candidates.count { !it.accepted }}/${candidates.size} rejected)"
                } else {
                    "NO FEASIBLE TRAJECTORY — all ${candidates.size} candidates violated constraints"
                },
            ),
        )
    }

    private fun selectLookaheadWaypoint(
        pose: VehiclePose2D,
        waypoints: List<Pair<Double, Double>>,
        lookaheadM: Double,
    ): Pair<Double, Double> {
        if (waypoints.isEmpty()) return (pose.xM + lookaheadM) to pose.yM
        for (wp in waypoints) {
            val dx = wp.first - pose.xM
            val dy = wp.second - pose.yM
            val forwardProj = dx * cos(pose.yawRad) + dy * sin(pose.yawRad)
            if (forwardProj > 2.2 && hypot(dx, dy) >= 2.5) {
                return wp
            }
        }
        return waypoints.last()
    }
}
