package com.example.eac

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.eac.ui.ExpeditionDashboardScreen
import com.example.ui.theme.ExpeditionAutonomyTheme
import com.example.eac.viewmodel.ExpeditionViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: ExpeditionViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ExpeditionAutonomyTheme {
                val currentScenario by viewModel.currentScenario.collectAsState()
                val selectedProfile by viewModel.selectedProfile.collectAsState()
                val envConditions by viewModel.envConditions.collectAsState()
                val faultConfig by viewModel.faultConfig.collectAsState()
                val isPlaying by viewModel.isPlaying.collectAsState()
                val simTimeSec by viewModel.simTimeSec.collectAsState()
                val frameBundle by viewModel.frameBundle.collectAsState()
                val estState by viewModel.estState.collectAsState()
                val terrainMap by viewModel.terrainMap.collectAsState()
                val travMap by viewModel.travMap.collectAsState()
                val planningResult by viewModel.planningResult.collectAsState()
                val safetyState by viewModel.safetyState.collectAsState()
                val eStopLatched by viewModel.eStopLatched.collectAsState()
                val operatingMode by viewModel.operatingMode.collectAsState()
                val actuationLocked by viewModel.actuationLocked.collectAsState()
                val limits by viewModel.limits.collectAsState()

                ExpeditionDashboardScreen(
                    currentScenario = currentScenario,
                    onSelectScenario = { viewModel.selectScenario(it) },
                    selectedProfile = selectedProfile,
                    onSelectProfile = { viewModel.selectProfile(it) },
                    env = envConditions,
                    onUpdateEnv = { viewModel.updateEnv(it) },
                    faults = faultConfig,
                    onUpdateFaults = { viewModel.updateFaults(it) },
                    isPlaying = isPlaying,
                    onTogglePlay = { viewModel.togglePlay() },
                    onStep = { viewModel.stepSimulation() },
                    onReset = { viewModel.resetSimulation() },
                    simTimeSec = simTimeSec,
                    frameBundle = frameBundle,
                    estState = estState,
                    terrainMap = terrainMap,
                    travMap = travMap,
                    planningResult = planningResult,
                    safetyState = safetyState,
                    eStopLatched = eStopLatched,
                    onToggleEStop = { viewModel.toggleEStop() },
                    operatingMode = operatingMode,
                    onChangeMode = { viewModel.changeMode(it) },
                    actuationLocked = actuationLocked,
                    onUnlockActuation = { viewModel.unlockActuation() },
                    limits = limits,
                )
            }
        }
    }
}
