package com.example.eac.vehicle

import kotlin.math.atan
import kotlin.math.max
import kotlin.math.min

enum class ParamProvenance(val badge: String) {
    VERIFIED_OEM("OEM"),
    MEASURED("MEAS"),
    ESTIMATED("EST"),
    PLACEHOLDER("TBD"),
}

data class TrackedParam(
    val value: Double,
    val unit: String,
    val provenance: ParamProvenance,
    val note: String,
)

enum class DrivetrainLayout(val label: String) {
    PERMANENT_4WD_LOCKING_DIFFS("Permanent 4WD + Center/Axle Diff Locks"),
    FULL_TIME_4WD_OPEN("Full-Time 4WD + Electronic Traction"),
}

data class VehicleProfile(
    val id: String,
    val displayName: String,
    val chassisClass: String,
    val dbwAuthorizedPlatform: Boolean,
    val dbwAuthorizationNote: String,
    val wheelbaseM: TrackedParam,
    val trackWidthM: TrackedParam,
    val vehicleWidthM: TrackedParam,
    val vehicleLengthM: TrackedParam,
    val vehicleHeightM: TrackedParam,
    val curbMassKg: TrackedParam,
    val groundClearanceM: TrackedParam,
    val approachAngleDeg: TrackedParam,
    val breakoverAngleDeg: TrackedParam,
    val departureAngleDeg: TrackedParam,
    val minTurningRadiusM: TrackedParam,
    val maxSteeringAngleDeg: TrackedParam,
    val cogHeightBaseM: TrackedParam,
    val tyreRadiusM: TrackedParam,
    val suspensionTravelM: TrackedParam,
    val advisoryWadingDepthM: TrackedParam,
    val drivetrain: DrivetrainLayout,
)

data class VehicleSensitivityInput(
    val payloadKg: Double = 280.0,
    val roofLoadKg: Double = 45.0,
    val tyrePressureBar: Double = 2.0,
    val surfaceMoistureFactor: Double = 0.25,
)

data class EffectiveVehicleLimits(
    val totalMassKg: Double,
    val effectiveCogHeightM: Double,
    val cogUncertaintyM: Double,
    val staticStabilityFactor: Double,
    val maxOperationalPitchDeg: Double,
    val maxOperationalCrossSlopeDeg: Double,
    val maxObstacleStepM: Double,
    val effectiveTractionMultiplier: Double,
    val maxBrakingDecelMps2: Double,
    val minStoppingMarginM: Double,
    val maxCommandSpeedMps: Double,
)

object VehicleModelRegistry {

    val grenadierBaseline = VehicleProfile(
        id = "ineos_grenadier_sw",
        displayName = "INEOS Grenadier Station Wagon",
        chassisClass = "Ladder-frame solid-axle 4x4 (Observation Baseline)",
        dbwAuthorizedPlatform = false,
        dbwAuthorizationNote = "Production Grenadier exposes read-only diagnostics only; physical actuation locked out.",
        wheelbaseM = TrackedParam(2.922, "m", ParamProvenance.VERIFIED_OEM, "Published OEM wheelbase"),
        trackWidthM = TrackedParam(1.645, "m", ParamProvenance.VERIFIED_OEM, "Published front/rear track"),
        vehicleWidthM = TrackedParam(1.930, "m", ParamProvenance.VERIFIED_OEM, "Body width excluding mirrors"),
        vehicleLengthM = TrackedParam(4.896, "m", ParamProvenance.VERIFIED_OEM, "Overall length incl. spare"),
        vehicleHeightM = TrackedParam(2.036, "m", ParamProvenance.VERIFIED_OEM, "Unladen roof height"),
        curbMassKg = TrackedParam(2669.0, "kg", ParamProvenance.VERIFIED_OEM, "Unladen DIN kerb mass"),
        groundClearanceM = TrackedParam(0.264, "m", ParamProvenance.VERIFIED_OEM, "Under-axle static clearance"),
        approachAngleDeg = TrackedParam(35.5, "deg", ParamProvenance.VERIFIED_OEM, "Static OEM approach geometry"),
        breakoverAngleDeg = TrackedParam(28.2, "deg", ParamProvenance.VERIFIED_OEM, "Static OEM ramp breakover"),
        departureAngleDeg = TrackedParam(36.1, "deg", ParamProvenance.VERIFIED_OEM, "Static OEM departure angle"),
        minTurningRadiusM = TrackedParam(6.75, "m", ParamProvenance.VERIFIED_OEM, "Kerb-to-kerb 13.5m turning circle"),
        maxSteeringAngleDeg = TrackedParam(34.0, "deg", ParamProvenance.ESTIMATED, "Equivalent front wheel steer angle"),
        cogHeightBaseM = TrackedParam(0.86, "m", ParamProvenance.ESTIMATED, "Unladen CoG height; requires tilt-table calibration"),
        tyreRadiusM = TrackedParam(0.402, "m", ParamProvenance.MEASURED, "BFGoodrich KO2 265/70R17 nominal radius"),
        suspensionTravelM = TrackedParam(0.220, "m", ParamProvenance.ESTIMATED, "Effective live-axle articulation range"),
        advisoryWadingDepthM = TrackedParam(0.800, "m", ParamProvenance.VERIFIED_OEM, "OEM static limit; NOT an autonomy guarantee"),
        drivetrain = DrivetrainLayout.PERMANENT_4WD_LOCKING_DIFFS,
    )

    val lwbExpeditionUtility = VehicleProfile(
        id = "lwb_expedition_4x4",
        displayName = "LWB Expedition Utility 4x4",
        chassisClass = "Long-wheelbase heavy expedition carrier",
        dbwAuthorizedPlatform = false,
        dbwAuthorizationNote = "No authorized DBW gateway configured.",
        wheelbaseM = TrackedParam(3.220, "m", ParamProvenance.VERIFIED_OEM, "Extended chassis wheelbase"),
        trackWidthM = TrackedParam(1.660, "m", ParamProvenance.VERIFIED_OEM, "Wide-track heavy axle"),
        vehicleWidthM = TrackedParam(1.980, "m", ParamProvenance.VERIFIED_OEM, "Body width"),
        vehicleLengthM = TrackedParam(5.340, "m", ParamProvenance.VERIFIED_OEM, "Overall length"),
        vehicleHeightM = TrackedParam(2.140, "m", ParamProvenance.MEASURED, "With expedition rack"),
        curbMassKg = TrackedParam(2890.0, "kg", ParamProvenance.MEASURED, "Weighed research trim"),
        groundClearanceM = TrackedParam(0.258, "m", ParamProvenance.MEASURED, "Under rear differential"),
        approachAngleDeg = TrackedParam(34.0, "deg", ParamProvenance.MEASURED, "With steel winch bumper"),
        breakoverAngleDeg = TrackedParam(24.5, "deg", ParamProvenance.ESTIMATED, "Reduced by longer wheelbase"),
        departureAngleDeg = TrackedParam(29.0, "deg", ParamProvenance.ESTIMATED, "Overhang departure"),
        minTurningRadiusM = TrackedParam(7.45, "m", ParamProvenance.MEASURED, "Measured lock-to-lock circle"),
        maxSteeringAngleDeg = TrackedParam(32.0, "deg", ParamProvenance.ESTIMATED, "Front axle lock"),
        cogHeightBaseM = TrackedParam(0.92, "m", ParamProvenance.ESTIMATED, "Higher cab/utility body"),
        tyreRadiusM = TrackedParam(0.415, "m", ParamProvenance.MEASURED, "285/70R17 A/T"),
        suspensionTravelM = TrackedParam(0.210, "m", ParamProvenance.ESTIMATED, "Heavy spring pack"),
        advisoryWadingDepthM = TrackedParam(0.750, "m", ParamProvenance.PLACEHOLDER, "Pending breather verification"),
        drivetrain = DrivetrainLayout.PERMANENT_4WD_LOCKING_DIFFS,
    )

    val trialMuleResearch = VehicleProfile(
        id = "eac_trial_mule_dbw",
        displayName = "EAC Trial Mule (DBW Research)",
        chassisClass = "Short-wheelbase closed-course DBW testbed",
        dbwAuthorizedPlatform = true,
        dbwAuthorizationNote = "Authorized for closed-course Mode B/C simulation & validated low-speed DBW trials with hardware E-Stop.",
        wheelbaseM = TrackedParam(2.540, "m", ParamProvenance.MEASURED, "Laser-measured axle centres"),
        trackWidthM = TrackedParam(1.620, "m", ParamProvenance.MEASURED, "Hub-to-hub track"),
        vehicleWidthM = TrackedParam(1.880, "m", ParamProvenance.MEASURED, "Including side LiDAR pods"),
        vehicleLengthM = TrackedParam(4.280, "m", ParamProvenance.MEASURED, "Bumper-to-bumper"),
        vehicleHeightM = TrackedParam(2.120, "m", ParamProvenance.MEASURED, "Including roof sensor mast"),
        curbMassKg = TrackedParam(2180.0, "kg", ParamProvenance.MEASURED, "Corner-weighted on scales"),
        groundClearanceM = TrackedParam(0.305, "m", ParamProvenance.MEASURED, "Portal/lifted research setup"),
        approachAngleDeg = TrackedParam(41.0, "deg", ParamProvenance.MEASURED, "Stubby test bumper"),
        breakoverAngleDeg = TrackedParam(33.5, "deg", ParamProvenance.MEASURED, "Short wheelbase clearance"),
        departureAngleDeg = TrackedParam(39.0, "deg", ParamProvenance.MEASURED, "Rear skid clearance"),
        minTurningRadiusM = TrackedParam(5.90, "m", ParamProvenance.MEASURED, "Calibrated kinematic circle"),
        maxSteeringAngleDeg = TrackedParam(36.0, "deg", ParamProvenance.MEASURED, "Encoder-calibrated steering rack"),
        cogHeightBaseM = TrackedParam(0.79, "m", ParamProvenance.MEASURED, "Measured via tilt-rig"),
        tyreRadiusM = TrackedParam(0.410, "m", ParamProvenance.MEASURED, "33-inch M/T research tyre"),
        suspensionTravelM = TrackedParam(0.250, "m", ParamProvenance.MEASURED, "Linear pot instrumented"),
        advisoryWadingDepthM = TrackedParam(0.850, "m", ParamProvenance.ESTIMATED, "Sealed test harness"),
        drivetrain = DrivetrainLayout.PERMANENT_4WD_LOCKING_DIFFS,
    )

    val allProfiles = listOf(grenadierBaseline, lwbExpeditionUtility, trialMuleResearch)

    fun computeEffectiveLimits(
        profile: VehicleProfile,
        sensitivity: VehicleSensitivityInput,
    ): EffectiveVehicleLimits {
        val totalMass = profile.curbMassKg.value + sensitivity.payloadKg + sensitivity.roofLoadKg
        // Roof load raises CoG significantly; cabin payload raises slightly
        val cogDelta = (sensitivity.roofLoadKg * 1.15 + sensitivity.payloadKg * 0.15) / totalMass
        val effectiveCog = profile.cogHeightBaseM.value + cogDelta
        val cogUncertainty = 0.06 + (sensitivity.payloadKg + sensitivity.roofLoadKg) * 0.00012

        // Static Stability Factor = Track / (2 * CoG_height)
        val conservativeCog = effectiveCog + cogUncertainty
        val ssf = profile.trackWidthM.value / (2.0 * conservativeCog)
        val staticRolloverDeg = Math.toDegrees(atan(ssf))
        // Apply 0.55 conservative safety derating for dynamic suspension compression & lateral bumps
        val maxCrossSlopeDeg = min(22.0, staticRolloverDeg * 0.52)

        // Pitch limit constrained by approach/breakover/departure & traction
        val geomPitchLimit = min(profile.approachAngleDeg.value, profile.breakoverAngleDeg.value) * 0.72
        val maxPitchDeg = min(24.0, geomPitchLimit * (1.0 - sensitivity.surfaceMoistureFactor * 0.22))

        // Effective obstacle step clearance (derated from static under-axle clearance)
        val maxStepM = max(0.12, profile.groundClearanceM.value * 0.78 - cogUncertainty * 0.15)

        // Tyre pressure airing-down improves soft-soil footprint up to ~1.8 bar, penalizes stability slightly
        val pressureBonus = when {
            sensitivity.tyrePressureBar < 1.5 -> 1.12
            sensitivity.tyrePressureBar < 2.1 -> 1.05
            else -> 0.94
        }
        val tractionMult = (1.0 - sensitivity.surfaceMoistureFactor * 0.42) * pressureBonus
        val maxDecel = (6.2 * tractionMult).coerceIn(1.8, 6.5)

        return EffectiveVehicleLimits(
            totalMassKg = totalMass,
            effectiveCogHeightM = effectiveCog,
            cogUncertaintyM = cogUncertainty,
            staticStabilityFactor = ssf,
            maxOperationalPitchDeg = maxPitchDeg,
            maxOperationalCrossSlopeDeg = maxCrossSlopeDeg,
            maxObstacleStepM = maxStepM,
            effectiveTractionMultiplier = tractionMult,
            maxBrakingDecelMps2 = maxDecel,
            minStoppingMarginM = 1.15,
            maxCommandSpeedMps = if (profile.dbwAuthorizedPlatform) 2.5 else 2.2,
        )
    }
}
