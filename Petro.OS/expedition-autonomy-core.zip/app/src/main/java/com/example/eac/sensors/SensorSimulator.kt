package com.example.eac.sensors

import com.example.eac.contracts.ExtrinsicTransform
import com.example.eac.contracts.MessageHeader
import com.example.eac.contracts.SensorHealthRecord
import com.example.eac.contracts.SensorStatus
import com.example.eac.contracts.SensorType
import com.example.eac.contracts.VehiclePose2D
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

enum class TerrainScenario(
    val id: String,
    val title: String,
    val subtitle: String,
    val defaultSeed: Long,
    val nominalSpeedMps: Double,
    val goalX: Double,
    val goalY: Double,
) {
    ROCKY_TRACK_ACCEPTANCE(
        id = "rocky_track_acceptance",
        title = "Rocky Track Acceptance",
        subtitle = "Unfamiliar granite ledges, boulder pinch & occluded drop-off",
        defaultSeed = 4201L,
        nominalSpeedMps = 1.4,
        goalX = 28.0,
        goalY = 0.0,
    ),
    MUD_RUT_CORRIDOR(
        id = "mud_rut_corridor",
        title = "Muddy Rut & Clay Track",
        subtitle = "Deep wheel ruts, high-slip clay basin & standing water glare",
        defaultSeed = 5107L,
        nominalSpeedMps = 1.1,
        goalX = 28.0,
        goalY = 1.5,
    ),
    STEEP_SHALE_SWITCHBACK(
        id = "steep_shale_switchback",
        title = "Steep Shale Cross-Slope",
        subtitle = "21 deg off-camber shelf, loose scree & narrow ridge",
        defaultSeed = 6319L,
        nominalSpeedMps = 1.0,
        goalX = 26.0,
        goalY = -2.0,
    ),
    FOREST_LOW_VISIBILITY(
        id = "forest_low_visibility",
        title = "Forest Canopy & Fog",
        subtitle = "Dense trunks, GNSS multipath & low-contrast camera",
        defaultSeed = 7823L,
        nominalSpeedMps = 1.1,
        goalX = 26.0,
        goalY = 0.5,
    ),
    SAND_DUNE_CREST(
        id = "sand_dune_crest",
        title = "Sand & Loose Gravel Wash",
        subtitle = "Soft dune crest occlusion, high rolling resistance & washout",
        defaultSeed = 8941L,
        nominalSpeedMps = 1.5,
        goalX = 28.0,
        goalY = -0.5,
    ),
}

enum class SemanticTerrainClass(val label: String) {
    ROCK("Compact Rock"),
    GRAVEL("Loose Gravel"),
    MUD("Wet Mud / Clay"),
    SAND("Deep Sand"),
    VEGETATION("Brush / Canopy"),
    WATER_REFLECTIVE("Reflective / Water"),
    UNKNOWN("Unclassified"),
}

data class EnvironmentConditions(
    val darkness: Double = 0.15,
    val rain: Double = 0.10,
    val dust: Double = 0.15,
    val mudSplash: Double = 0.05,
    val gnssCanopyDegradation: Double = 0.10,
) {
    val opticalDegradation: Double
        get() = (darkness * 0.45 + rain * 0.35 + dust * 0.45 + mudSplash * 0.65).coerceIn(0.0, 0.95)
}

data class FaultInjectionConfig(
    val dropLidar: Boolean = false,
    val degradeGnss: Boolean = false,
    val occludeForwardCamera: Boolean = false,
    val injectWheelSlip: Boolean = false,
    val injectComputeDeadlineMiss: Boolean = false,
    val commsTimeout: Boolean = false,
    val actuatorDelayMs: Int = 45,
)

data class LidarReturnPoint(
    val localX: Double,
    val localY: Double,
    val localZ: Double,
    val worldX: Double,
    val worldY: Double,
    val worldZ: Double,
    val intensity: Double,
    val semanticHint: SemanticTerrainClass,
    val semanticConfidence: Double,
)

data class SensorFrameBundle(
    val seq: Long,
    val simTimeSec: Double,
    val timestampNs: Long,
    val truePose: VehiclePose2D,
    val trueVxMps: Double,
    val trueYawRateRadS: Double,
    val truePitchDeg: Double,
    val trueRollDeg: Double,
    val lidarPoints: List<LidarReturnPoint>,
    val gnssValid: Boolean,
    val gnssX: Double,
    val gnssY: Double,
    val gnssHdop: Double,
    val imuAxMps2: Double,
    val imuAyMps2: Double,
    val imuYawRateRadS: Double,
    val wheelOdometryVxMps: Double,
    val wheelSlipObserved: Double,
    val steeringAngleDeg: Double,
    val suspensionCompressionM: Double,
    val cameraOcclusionFraction: Double,
    val cameraSemanticConfidence: Double,
    val oodScore: Double,
    val healthRecords: List<SensorHealthRecord>,
    val globalCorridorWaypoints: List<Pair<Double, Double>>,
)

data class WorldHazardFeature(
    val x: Double,
    val y: Double,
    val radius: Double,
    val heightDeltaM: Double,
    val semantic: SemanticTerrainClass,
)

class DeterministicTerrainWorld(
    val scenario: TerrainScenario,
    val seed: Long,
) {
    private val rng = Random(seed)
    val features: List<WorldHazardFeature> = generateFeatures()
    val waypoints: List<Pair<Double, Double>> = generateWaypoints()

    private fun generateFeatures(): List<WorldHazardFeature> {
        val list = mutableListOf<WorldHazardFeature>()
        when (scenario) {
            TerrainScenario.ROCKY_TRACK_ACCEPTANCE -> {
                // Large boulder pinch on left & right around x=9..16, leaving a cautious right-of-center corridor
                list.add(WorldHazardFeature(7.5, 1.8, 1.35, 0.72, SemanticTerrainClass.ROCK))
                list.add(WorldHazardFeature(10.8, -2.3, 1.50, 0.85, SemanticTerrainClass.ROCK))
                list.add(WorldHazardFeature(12.2, 0.8, 1.15, 0.48, SemanticTerrainClass.ROCK))
                // Steep drop-off / shelf edge on far left
                list.add(WorldHazardFeature(15.5, 3.6, 2.2, -0.95, SemanticTerrainClass.ROCK))
                // Scatter smaller granite rocks
                repeat(16) { i ->
                    val fx = 4.0 + i * 1.65 + rng.nextDouble(-0.4, 0.4)
                    val fy = rng.nextDouble(-5.5, 5.5)
                    if (hypot(fx - 12.2, fy + 1.2) > 2.2) {
                        val h = if (rng.nextDouble() > 0.4) rng.nextDouble(0.22, 0.52) else rng.nextDouble(0.10, 0.22)
                        list.add(WorldHazardFeature(fx, fy, rng.nextDouble(0.55, 1.05), h, SemanticTerrainClass.ROCK))
                    }
                }
                // Sparse scrub vegetation along track margins
                repeat(8) {
                    val fx = rng.nextDouble(5.0, 27.0)
                    val fy = if (rng.nextBoolean()) rng.nextDouble(3.4, 6.0) else rng.nextDouble(-6.0, -3.4)
                    list.add(WorldHazardFeature(fx, fy, 0.9, 0.85, SemanticTerrainClass.VEGETATION))
                }
            }

            TerrainScenario.MUD_RUT_CORRIDOR -> {
                // Deep parallel ruts + standing water puddle
                list.add(WorldHazardFeature(9.0, 0.4, 2.1, -0.34, SemanticTerrainClass.MUD))
                list.add(WorldHazardFeature(14.0, -0.5, 2.4, -0.28, SemanticTerrainClass.WATER_REFLECTIVE))
                list.add(WorldHazardFeature(18.5, 1.6, 1.6, 0.45, SemanticTerrainClass.MUD))
                repeat(12) { i ->
                    val fx = 5.0 + i * 1.9
                    val fy = if (i % 2 == 0) -2.4 else 2.6
                    list.add(WorldHazardFeature(fx, fy, 1.1, -0.24, SemanticTerrainClass.MUD))
                }
            }

            TerrainScenario.STEEP_SHALE_SWITCHBACK -> {
                list.add(WorldHazardFeature(8.5, -1.8, 1.5, 0.65, SemanticTerrainClass.ROCK))
                list.add(WorldHazardFeature(14.0, 2.2, 1.8, -0.80, SemanticTerrainClass.GRAVEL))
                list.add(WorldHazardFeature(20.0, -1.2, 1.4, 0.55, SemanticTerrainClass.ROCK))
            }

            TerrainScenario.FOREST_LOW_VISIBILITY -> {
                repeat(22) { i ->
                    val fx = 4.5 + i * 1.1
                    val fy = rng.nextDouble(-5.5, 5.5)
                    if (abs(fy) > 1.35) {
                        list.add(WorldHazardFeature(fx, fy, 0.55, 1.9, SemanticTerrainClass.VEGETATION))
                    }
                }
                list.add(WorldHazardFeature(11.0, 0.2, 0.9, 0.42, SemanticTerrainClass.ROCK))
            }

            TerrainScenario.SAND_DUNE_CREST -> {
                list.add(WorldHazardFeature(10.5, 0.0, 3.2, 1.15, SemanticTerrainClass.SAND))
                list.add(WorldHazardFeature(16.5, -2.1, 2.4, -0.65, SemanticTerrainClass.SAND))
                list.add(WorldHazardFeature(21.0, 1.9, 1.7, 0.58, SemanticTerrainClass.GRAVEL))
            }
        }
        return list
    }

    private fun generateWaypoints(): List<Pair<Double, Double>> {
        return when (scenario) {
            TerrainScenario.ROCKY_TRACK_ACCEPTANCE -> listOf(
                0.0 to 0.0,
                6.0 to -0.4,
                12.5 to -1.2,
                19.0 to -0.2,
                28.0 to 0.0,
            )
            TerrainScenario.MUD_RUT_CORRIDOR -> listOf(
                0.0 to 0.0,
                7.0 to -1.2,
                14.0 to 1.4,
                21.0 to 1.2,
                28.0 to 1.5,
            )
            TerrainScenario.STEEP_SHALE_SWITCHBACK -> listOf(
                0.0 to 0.0,
                8.0 to 0.8,
                15.0 to -0.8,
                26.0 to -2.0,
            )
            TerrainScenario.FOREST_LOW_VISIBILITY -> listOf(
                0.0 to 0.0,
                9.0 to -0.5,
                18.0 to 0.4,
                26.0 to 0.5,
            )
            TerrainScenario.SAND_DUNE_CREST -> listOf(
                0.0 to 0.0,
                9.5 to 1.2,
                18.0 to 0.4,
                28.0 to -0.5,
            )
        }
    }

    fun groundHeightAt(wx: Double, wy: Double): Double {
        var z = when (scenario) {
            TerrainScenario.ROCKY_TRACK_ACCEPTANCE ->
                0.05 * wx + 0.14 * sin(wx * 0.45) * cos(wy * 0.55) + 0.04 * wy
            TerrainScenario.MUD_RUT_CORRIDOR ->
                0.02 * wx - 0.14 * exp(-((wy - 0.65) * (wy - 0.65)) / 0.18) -
                    0.14 * exp(-((wy + 0.65) * (wy + 0.65)) / 0.18)
            TerrainScenario.STEEP_SHALE_SWITCHBACK ->
                0.18 * wx + 0.31 * wy + 0.10 * sin(wx * 0.5)
            TerrainScenario.FOREST_LOW_VISIBILITY ->
                0.04 * wx + 0.09 * sin(wx * 0.35 + wy * 0.4)
            TerrainScenario.SAND_DUNE_CREST ->
                0.65 * exp(-((wx - 11.0) * (wx - 11.0)) / 18.0) + 0.08 * sin(wy * 0.5)
        }

        for (f in features) {
            val d2 = (wx - f.x) * (wx - f.x) + (wy - f.y) * (wy - f.y)
            val r2 = f.radius * f.radius
            if (d2 < r2 * 2.2) {
                z += f.heightDeltaM * exp(-d2 / (0.55 * r2))
            }
        }
        return z
    }

    fun semanticAt(wx: Double, wy: Double): SemanticTerrainClass {
        for (f in features) {
            if (hypot(wx - f.x, wy - f.y) <= f.radius * 1.05) {
                return f.semantic
            }
        }
        return when (scenario) {
            TerrainScenario.ROCKY_TRACK_ACCEPTANCE -> SemanticTerrainClass.GRAVEL
            TerrainScenario.MUD_RUT_CORRIDOR -> SemanticTerrainClass.MUD
            TerrainScenario.STEEP_SHALE_SWITCHBACK -> SemanticTerrainClass.GRAVEL
            TerrainScenario.FOREST_LOW_VISIBILITY -> SemanticTerrainClass.VEGETATION
            TerrainScenario.SAND_DUNE_CREST -> SemanticTerrainClass.SAND
        }
    }

    fun truePitchRollDeg(pose: VehiclePose2D): Pair<Double, Double> {
        val dx = 1.4 * cos(pose.yawRad)
        val dy = 1.4 * sin(pose.yawRad)
        val zFront = groundHeightAt(pose.xM + dx, pose.yM + dy)
        val zRear = groundHeightAt(pose.xM - dx, pose.yM - dy)
        val pitchRad = kotlin.math.atan2(zFront - zRear, 2.8)

        val lx = -0.82 * sin(pose.yawRad)
        val ly = 0.82 * cos(pose.yawRad)
        val zLeft = groundHeightAt(pose.xM + lx, pose.yM + ly)
        val zRight = groundHeightAt(pose.xM - lx, pose.yM - ly)
        val rollRad = kotlin.math.atan2(zLeft - zRight, 1.64)

        return Math.toDegrees(pitchRad) to Math.toDegrees(rollRad)
    }
}

class SimulatedSensorAdapter(
    private val seed: Long,
) {
    private val rng = Random(seed)

    private val extrinsics: Map<SensorType, ExtrinsicTransform> = mapOf(
        SensorType.FORWARD_CAMERA to ExtrinsicTransform(1.75, 0.0, 1.55, 0.0, 8.0, 0.0),
        SensorType.STEREO_CAMERA to ExtrinsicTransform(1.78, 0.0, 1.58, 0.0, 7.5, 0.0),
        SensorType.SURROUND_CAMERA to ExtrinsicTransform(0.0, 0.0, 1.25, 0.0, 22.0, 0.0),
        SensorType.LIDAR_3D to ExtrinsicTransform(0.45, 0.0, 2.18, 0.0, 4.0, 0.0),
        SensorType.RADAR to ExtrinsicTransform(2.35, 0.0, 0.58, 0.0, 0.0, 0.0),
        SensorType.GNSS to ExtrinsicTransform(-0.35, 0.0, 2.12, 0.0, 0.0, 0.0),
        SensorType.IMU to ExtrinsicTransform(0.0, 0.0, 0.52, 0.0, 0.0, 0.0),
        SensorType.WHEEL_SPEED to ExtrinsicTransform(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        SensorType.STEERING_ANGLE to ExtrinsicTransform(1.45, 0.0, 0.45, 0.0, 0.0, 0.0),
        SensorType.VEHICLE_SPEED to ExtrinsicTransform(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
        SensorType.SUSPENSION_TRAVEL to ExtrinsicTransform(0.0, 0.0, 0.35, 0.0, 0.0, 0.0),
        SensorType.ENV_SENSORS to ExtrinsicTransform(0.40, 0.0, 2.22, 0.0, 0.0, 0.0),
    )

    fun captureFrame(
        seq: Long,
        simTimeSec: Double,
        world: DeterministicTerrainWorld,
        truePose: VehiclePose2D,
        trueVxMps: Double,
        trueYawRateRadS: Double,
        steeringAngleDeg: Double,
        env: EnvironmentConditions,
        faults: FaultInjectionConfig,
    ): SensorFrameBundle {
        val tsNs = 1_700_000_000_000_000_000L + (simTimeSec * 1_000_000_000.0).toLong()
        val (pitchDeg, rollDeg) = world.truePitchRollDeg(truePose)
        val sensorHeightZ = world.groundHeightAt(truePose.xM, truePose.yM) + 2.18

        // Raycast LiDAR forward-hemisphere with occlusion behind tall obstacles/crests
        val lidarPoints = mutableListOf<LidarReturnPoint>()
        if (!faults.dropLidar) {
            val azCount = 48
            val rangeSteps = 22
            val maxRange = 13.5 * (1.0 - env.dust * 0.25 - env.rain * 0.15)
            val cosYaw = cos(truePose.yawRad)
            val sinYaw = sin(truePose.yawRad)

            for (ai in 0 until azCount) {
                val az = -PI * 0.58 + (PI * 1.16) * ai / (azCount - 1)
                var maxElevationAngleSeen = -PI / 2.0
                for (ri in 1..rangeSteps) {
                    val r = 1.6 + (maxRange - 1.6) * ri / rangeSteps
                    val lx = r * cos(az)
                    val ly = r * sin(az)
                    val wx = truePose.xM + lx * cosYaw - ly * sinYaw
                    val wy = truePose.yM + lx * sinYaw + ly * cosYaw
                    val trueZ = world.groundHeightAt(wx, wy)
                    val relZ = trueZ - sensorHeightZ
                    val elevAngle = kotlin.math.atan2(relZ, r)

                    // Realistic geometric occlusion: points shadowed behind a crest or boulder are not visible!
                    if (elevAngle + 0.015 < maxElevationAngleSeen) {
                        continue
                    }
                    if (elevAngle > maxElevationAngleSeen) {
                        maxElevationAngleSeen = elevAngle
                    }

                    val noiseSigma = 0.015 + env.dust * 0.03 + env.rain * 0.02
                    val noisyZ = trueZ + rng.nextDouble(-noiseSigma, noiseSigma)
                    val semantic = world.semanticAt(wx, wy)
                    val semConf = (0.88 - env.opticalDegradation * 0.55 - (r / 25.0)).coerceIn(0.20, 0.95)
                    val intensity = when (semantic) {
                        SemanticTerrainClass.WATER_REFLECTIVE -> 0.18
                        SemanticTerrainClass.ROCK -> 0.82
                        SemanticTerrainClass.VEGETATION -> 0.55
                        else -> 0.65
                    }
                    lidarPoints.add(
                        LidarReturnPoint(
                            localX = lx,
                            localY = ly,
                            localZ = noisyZ - world.groundHeightAt(truePose.xM, truePose.yM),
                            worldX = wx,
                            worldY = wy,
                            worldZ = noisyZ,
                            intensity = intensity,
                            semanticHint = semantic,
                            semanticConfidence = semConf,
                        )
                    )
                }
            }
        }

        val gnssDegraded = faults.degradeGnss || env.gnssCanopyDegradation > 0.65
        val gnssJump = if (faults.degradeGnss) 3.8 else env.gnssCanopyDegradation * 1.4
        val gnssX = truePose.xM + rng.nextDouble(-0.08 - gnssJump, 0.08 + gnssJump)
        val gnssY = truePose.yM + rng.nextDouble(-0.08 - gnssJump, 0.08 + gnssJump)
        val gnssHdop = if (faults.degradeGnss) 7.4 else 1.1 + env.gnssCanopyDegradation * 3.2

        val slip = if (faults.injectWheelSlip) {
            0.48
        } else {
            val sem = world.semanticAt(truePose.xM, truePose.yM)
            when (sem) {
                SemanticTerrainClass.MUD -> 0.24
                SemanticTerrainClass.SAND -> 0.19
                SemanticTerrainClass.GRAVEL -> 0.08
                else -> 0.04
            } + env.rain * 0.08
        }

        val wheelOdomVx = trueVxMps * (1.0 + slip * 0.45) + rng.nextDouble(-0.03, 0.03)
        val imuYawRate = trueYawRateRadS + rng.nextDouble(-0.008, 0.008)
        val camOcclusion = if (faults.occludeForwardCamera) 0.85 else env.mudSplash.coerceIn(0.0, 0.75)
        val camConf = (1.0 - env.opticalDegradation).coerceIn(0.10, 0.96)
        val oodScore = (env.opticalDegradation * 0.55 +
            (if (faults.dropLidar) 0.25 else 0.0) +
            (if (faults.injectWheelSlip) 0.22 else 0.0)).coerceIn(0.02, 0.99)

        val healthRecords = SensorType.entries.map { type ->
            val ext = extrinsics[type] ?: ExtrinsicTransform(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            val (status, actualHz, latMs, conf, note) = when (type) {
                SensorType.LIDAR_3D -> when {
                    faults.dropLidar -> SensorHealthTuple(SensorStatus.DROPPED, 0.0, 250.0, 0.0, "Packet timeout >100ms")
                    env.dust > 0.6 -> SensorHealthTuple(SensorStatus.DEGRADED, 9.4, 24.0, 0.62, "Dust backscatter attenuation")
                    else -> SensorHealthTuple(SensorStatus.HEALTHY, 10.0, 14.2, 0.96, "3D scan locked")
                }
                SensorType.FORWARD_CAMERA, SensorType.STEREO_CAMERA -> when {
                    faults.occludeForwardCamera -> SensorHealthTuple(SensorStatus.OCCLUDED, 30.0, 18.0, 0.12, "Lens mud/splash occlusion")
                    env.opticalDegradation > 0.55 -> SensorHealthTuple(SensorStatus.DEGRADED, 28.5, 22.0, camConf, "Low-visibility contrast loss")
                    else -> SensorHealthTuple(SensorStatus.HEALTHY, type.expectedHz, 12.5, camConf, "Exposure & calibration nominal")
                }
                SensorType.SURROUND_CAMERA -> SensorHealthTuple(
                    if (env.mudSplash > 0.5) SensorStatus.DEGRADED else SensorStatus.HEALTHY,
                    15.0,
                    19.0,
                    (0.90 - env.mudSplash * 0.45).coerceIn(0.2, 0.95),
                    "4-ch stitched rig",
                )
                SensorType.RADAR -> SensorHealthTuple(SensorStatus.HEALTHY, 20.0, 9.8, 0.91, "All-weather Doppler active")
                SensorType.GNSS -> if (gnssDegraded) {
                    SensorHealthTuple(SensorStatus.DEGRADED, 8.0, 42.0, 0.28, "High HDOP / multipath drift")
                } else {
                    SensorHealthTuple(SensorStatus.HEALTHY, 10.0, 18.0, 0.92, "RTK-float lock")
                }
                SensorType.IMU -> SensorHealthTuple(SensorStatus.HEALTHY, 100.0, 2.4, 0.98, "Bias compensated")
                SensorType.WHEEL_SPEED -> if (faults.injectWheelSlip) {
                    SensorHealthTuple(SensorStatus.DEGRADED, 50.0, 4.1, 0.48, "Excessive slip delta vs IMU")
                } else {
                    SensorHealthTuple(SensorStatus.HEALTHY, 50.0, 3.8, 0.95, "4-wheel ABS hall pulses")
                }
                SensorType.STEERING_ANGLE -> SensorHealthTuple(SensorStatus.HEALTHY, 50.0, 3.2, 0.97, "Column encoder nominal")
                SensorType.VEHICLE_SPEED -> SensorHealthTuple(SensorStatus.HEALTHY, 50.0, 3.5, 0.96, "Transfer-case speed ref")
                SensorType.SUSPENSION_TRAVEL -> SensorHealthTuple(SensorStatus.HEALTHY, 25.0, 7.5, 0.90, "Axle articulation nominal")
                SensorType.ENV_SENSORS -> SensorHealthTuple(SensorStatus.HEALTHY, 5.0, 11.0, 0.93, "Optical/rain telemetry active")
            }

            SensorHealthRecord(
                type = type,
                header = MessageHeader(seq = seq, timestampNs = tsNs, frameId = type.frameId),
                fitted = true,
                calibrated = true,
                status = status,
                actualHz = actualHz,
                latencyMs = latMs,
                confidence = conf,
                extrinsic = ext,
                diagnosticNote = note,
            )
        }

        return SensorFrameBundle(
            seq = seq,
            simTimeSec = simTimeSec,
            timestampNs = tsNs,
            truePose = truePose,
            trueVxMps = trueVxMps,
            trueYawRateRadS = trueYawRateRadS,
            truePitchDeg = pitchDeg,
            trueRollDeg = rollDeg,
            lidarPoints = lidarPoints,
            gnssValid = !faults.degradeGnss,
            gnssX = gnssX,
            gnssY = gnssY,
            gnssHdop = gnssHdop,
            imuAxMps2 = 0.05,
            imuAyMps2 = trueVxMps * trueYawRateRadS,
            imuYawRateRadS = imuYawRate,
            wheelOdometryVxMps = wheelOdomVx,
            wheelSlipObserved = slip,
            steeringAngleDeg = steeringAngleDeg,
            suspensionCompressionM = (abs(rollDeg) * 0.004).coerceIn(0.0, 0.14),
            cameraOcclusionFraction = camOcclusion,
            cameraSemanticConfidence = camConf,
            oodScore = oodScore,
            healthRecords = healthRecords,
            globalCorridorWaypoints = world.waypoints,
        )
    }

    private data class SensorHealthTuple(
        val status: SensorStatus,
        val actualHz: Double,
        val latencyMs: Double,
        val confidence: Double,
        val note: String,
    )
}
