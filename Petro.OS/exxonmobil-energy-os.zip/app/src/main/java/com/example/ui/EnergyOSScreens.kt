package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EnergyOSMainScreen(viewModel: EnergyOSViewModel) {
    val activeRole by viewModel.activeRole.collectAsState()
    val activeTab by viewModel.activeTab.collectAsState()
    val timeMachine by viewModel.timeMachine.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    var showRoleMenu by remember { mutableStateOf(false) }
    var showScenarioMenu by remember { mutableStateOf(false) }
    val currentScenarioName by viewModel.currentScenarioName.collectAsState()

    // Base UTC clock (simulated date/time)
    val clockString = remember {
        val sdf = SimpleDateFormat("EEEE HH:mm:ss 'UTC'", Locale.US)
        sdf.format(Date())
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "EXXONMOBIL",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = ExxonRed,
                            fontSize = 20.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ENERGY OS",
                            fontWeight = FontWeight.Light,
                            letterSpacing = 2.sp,
                            color = TextWhite,
                            fontSize = 20.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = GridLineGray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = "GLOBAL COMMAND CENTRE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentTeal,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                actions = {
                    // Time Machine Trigger
                    Text(
                        text = "REPLAY STATE:",
                        fontSize = 11.sp,
                        color = TextMuted,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    var showTimeMenu by remember { mutableStateOf(false) }
                    Box {
                        TextButton(onClick = { showTimeMenu = true }) {
                            Text(timeMachine, color = AccentTeal, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Time Machine", tint = AccentTeal)
                        }
                        DropdownMenu(
                            expanded = showTimeMenu,
                            onDismissRequest = { showTimeMenu = false },
                            modifier = Modifier.background(SurfaceDark)
                        ) {
                            listOf("NOW", "1H_AGO", "1D_AGO", "1W_AGO", "1M_AGO").forEach { time ->
                                DropdownMenuItem(
                                    text = { Text(time, color = TextWhite) },
                                    onClick = {
                                        viewModel.setTimeMachine(time)
                                        showTimeMenu = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Active Scenario Trigger
                    Box {
                        Button(
                            onClick = { showScenarioMenu = true },
                            colors = ButtonDefaults.buttonColors(containerColor = GridLineGray),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("scenario_menu_button")
                        ) {
                            Icon(Icons.Default.SettingsInputComponent, contentDescription = "Scenario", tint = AlertOrange, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(currentScenarioName, fontSize = 11.sp, color = TextWhite)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Scenario Dropdown", tint = TextWhite)
                        }
                        DropdownMenu(
                            expanded = showScenarioMenu,
                            onDismissRequest = { showScenarioMenu = false },
                            modifier = Modifier.background(SurfaceDark)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Baseline Operations (Nominal)", color = TextWhite) },
                                onClick = { viewModel.resetScenario(); showScenarioMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Scenario 1: Oil Price Collapse (-30%)", color = TextWhite) },
                                onClick = { viewModel.runScenario("Oil Price Collapse"); showScenarioMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Scenario 2: Henry Hub Gas Spike (+50%)", color = TextWhite) },
                                onClick = { viewModel.runScenario("Henry Hub Gas Spike"); showScenarioMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Scenario 3: Offshore Platform Hurricane", color = TextWhite) },
                                onClick = { viewModel.runScenario("Offshore Platform Hurricane"); showScenarioMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Scenario 4: Refinery Critical Outage", color = TextWhite) },
                                onClick = { viewModel.runScenario("Refinery Outage"); showScenarioMenu = false }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Role Switcher
                    Box {
                        Button(
                            onClick = { showRoleMenu = true },
                            colors = ButtonDefaults.buttonColors(containerColor = ExxonBlue),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.testTag("role_switcher_button")
                        ) {
                            Icon(Icons.Default.AccountCircle, contentDescription = "Role Selector", tint = AccentTeal)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(activeRole.displayName, color = TextWhite, fontSize = 12.sp)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = TextWhite)
                        }
                        DropdownMenu(
                            expanded = showRoleMenu,
                            onDismissRequest = { showRoleMenu = false },
                            modifier = Modifier.background(SurfaceDark)
                        ) {
                            UserRole.values().forEach { role ->
                                DropdownMenuItem(
                                    text = { Text(role.displayName, color = TextWhite, fontSize = 13.sp) },
                                    onClick = {
                                        viewModel.setRole(role)
                                        showRoleMenu = false
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ControlBackground,
                    titleContentColor = TextWhite
                )
            )
        },
        containerColor = ControlBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            // Live Status Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceDark)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageName(activeTab),
                        contentDescription = "Active Icon",
                        tint = AccentTeal,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "MODE: ${activeTab.uppercase()} | $clockString",
                        fontSize = 11.sp,
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "ROLE: ${activeRole.name} COMMAND ACTIVE",
                        fontSize = 10.sp,
                        color = AccentTeal,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(SignalGreen, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SYS ONLINE",
                        fontSize = 10.sp,
                        color = SignalGreen,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Universal Search & Command Palette Bar
            UniversalSearchBar(viewModel)

            // Primary Responsive split: Sidebar + Main Workspace
            Row(modifier = Modifier.fillMaxSize()) {
                // Adaptive Navigation bar (Vertical Rail for wider layout)
                SidebarNavigation(viewModel, activeTab)

                // Master Workspace Content Area
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .background(ControlBackground)
                        .padding(16.dp)
                ) {
                    when (activeTab) {
                        "HOME" -> HomeScreen(viewModel)
                        "OPERATIONS" -> OperationsScreen(viewModel)
                        "ASSETS" -> AssetsScreen(viewModel)
                        "ENERGY" -> EnergyScreen(viewModel)
                        "MARKETS" -> MarketsScreen(viewModel)
                        "REFINING" -> RefiningScreen(viewModel)
                        "CHEMICALS" -> ChemicalsScreen(viewModel)
                        "MOBILITY" -> MobilityScreen(viewModel)
                        "LOW CARBON" -> LowCarbonScreen(viewModel)
                        "PROJECTS" -> ProjectsScreen(viewModel)
                        "DATA & AI" -> DataScreen(viewModel)
                        else -> HomeScreen(viewModel)
                    }
                }
            }
        }
    }
}

// Universal Search & Command Palette
@Composable
fun UniversalSearchBar(viewModel: EnergyOSViewModel) {
    val query by viewModel.searchQuery.collectAsState()
    var searchFocused by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(SurfaceDark.copy(alpha = 0.6f))
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Default.Search,
            contentDescription = "Search",
            tint = TextMuted,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Box(modifier = Modifier.weight(1f)) {
            if (query.isEmpty() && !searchFocused) {
                Text(
                    text = "Universal Command Palette (e.g. Search wells, refineries, launch scenarios, ask AI...) Press Ctrl+K",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }
            BasicTextField(
                value = query,
                onValueChange = {
                    viewModel.updateSearchQuery(it)
                    searchFocused = true
                },
                textStyle = TextStyle(color = TextWhite, fontSize = 12.sp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("universal_search_input")
            )
        }
        if (query.isNotEmpty()) {
            IconButton(
                onClick = { viewModel.updateSearchQuery("") },
                modifier = Modifier.size(20.dp)
            ) {
                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextWhite, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun SidebarNavigation(viewModel: EnergyOSViewModel, activeTab: String) {
    val navigationItems = listOf(
        "HOME", "OPERATIONS", "ASSETS", "ENERGY", "MARKETS", "REFINING", "CHEMICALS", "MOBILITY", "LOW CARBON", "PROJECTS", "DATA & AI"
    )

    Column(
        modifier = Modifier
            .width(180.dp)
            .fillMaxHeight()
            .background(SurfaceDark)
            .verticalScroll(rememberScrollState())
            .border(width = 1.dp, color = GridLineGray)
            .padding(vertical = 8.dp)
    ) {
        navigationItems.forEach { item ->
            val isActive = activeTab == item
            val itemBg = if (isActive) ExxonBlue else Color.Transparent
            val textCol = if (isActive) TextWhite else TextMuted
            val iconTint = if (isActive) AccentTeal else TextMuted

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.setTab(item) }
                    .background(itemBg)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .testTag("nav_tab_${item.lowercase().replace(" & ", "_")}"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = imageName(item),
                    contentDescription = item,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = item,
                    fontSize = 11.sp,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    color = textCol,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

fun imageName(tabName: String): androidx.compose.ui.graphics.vector.ImageVector {
    return when (tabName) {
        "HOME" -> Icons.Default.Home
        "OPERATIONS" -> Icons.Default.Warning
        "ASSETS" -> Icons.Default.Layers
        "ENERGY" -> Icons.Default.TrendingUp
        "MARKETS" -> Icons.Default.ShowChart
        "REFINING" -> Icons.Default.LocalGasStation
        "CHEMICALS" -> Icons.Default.Science
        "MOBILITY" -> Icons.Default.DirectionsCar
        "LOW CARBON" -> Icons.Default.CloudQueue
        "PROJECTS" -> Icons.Default.AccountBalance
        "DATA & AI" -> Icons.Default.Psychology
        else -> Icons.Default.Settings
    }
}

// ----------------------------------------------------
// 1. HOME — GLOBAL EXECUTIVE COMMAND CENTRE
// ----------------------------------------------------
@Composable
fun HomeScreen(viewModel: EnergyOSViewModel) {
    val assets by viewModel.assets.collectAsState()
    val markets by viewModel.markets.collectAsState()
    val selectedAsset by viewModel.selectedAsset.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "GLOBAL PERFORMANCE OVERVIEW",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = AccentTeal,
                letterSpacing = 1.sp
            )
            Text(
                text = "CONFIDENCE COEFFICIENT: 96.8% (AUDITED)",
                fontSize = 10.sp,
                color = SignalGreen,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // High Density Metrics Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val brent = markets.find { it.ticker == "BRENT" }?.price ?: 78.4
            val gas = markets.find { it.ticker == "NAT_GAS" }?.price ?: 2.6

            MetricCard(
                metric = ExecutiveMetric("GLOBAL PRODUCTION", "2.42M", "bbl/day", "09:42 UTC", "Field Flow Meters", 0.98, "Current 24H", "+1.2% vs Q2")
            )
            MetricCard(
                metric = ExecutiveMetric("REFINING THROUGHPUT", "1,850K", "kbpd", "09:42 UTC", "CDU Metrology", 0.96, "Current 24H", "-0.4% vs Avg")
            )
            MetricCard(
                metric = ExecutiveMetric("CHEMICAL OUTPUT", "1,620K", "tonnes/yr", "09:42 UTC", "Site Logistics Ledger", 0.95, "Current Day", "+2.8% vs Mon")
            )
            MetricCard(
                metric = ExecutiveMetric("BRENT SPOT PRICE", "$$brent", "USD/bbl", "Live Ticking", "Intercontinental Exchange", 0.99, "Real-Time", "+0.6% Spot")
            )
            MetricCard(
                metric = ExecutiveMetric("NATURAL GAS SPOT", "$$gas", "USD/mmbtu", "Live Ticking", "Henry Hub Index", 0.99, "Real-Time", "-1.4% Spot")
            )
            MetricCard(
                metric = ExecutiveMetric("CO2 SEQUESTRATION", "14.8M", "mtpa", "09:42 UTC", "CCS Point Audit", 0.97, "Current Year", "+8.2% vs Target")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Map and side statistics panel
        Row(modifier = Modifier.weight(1f)) {
            // Left: Custom Drawing Global Map
            Box(
                modifier = Modifier
                    .weight(1.8f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
            ) {
                GlobalInteractiveMapCanvas(assets) { asset ->
                    viewModel.selectAsset(asset)
                }

                // Overlay Map Instructions
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = ControlBackground.copy(alpha = 0.8f),
                    modifier = Modifier
                        .padding(8.dp)
                        .align(Alignment.BottomStart)
                ) {
                    Text(
                        text = "Interactive Asset Grid Map. Click markers for Real-Time Telemetry.",
                        fontSize = 10.sp,
                        color = TextMuted,
                        modifier = Modifier.padding(6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Side panel: Asset Inspection Drawer
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                if (selectedAsset != null) {
                    AssetInspectionPanel(selectedAsset!!, onClose = { viewModel.selectAsset(null) })
                } else {
                    EmptySelectionPanel("No Active Asset Selected", "Click on any blinking marker on the global energy grid map to capture real-time telemetry, historical trends, and provenance metrics.")
                }
            }
        }
    }
}

@Composable
fun MetricCard(metric: ExecutiveMetric) {
    Card(
        modifier = Modifier
            .width(180.dp)
            .border(width = 1.dp, color = GridLineGray, shape = RoundedCornerShape(4.dp)),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(4.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(metric.name, fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(metric.value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Spacer(modifier = Modifier.width(2.dp))
                Text(metric.unit, fontSize = 10.sp, color = AccentTeal)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(metric.comparison, fontSize = 10.sp, color = if (metric.comparison.startsWith("+")) SignalGreen else AlertOrange)
                Text("Conf: ${(metric.confidence * 100).toInt()}%", fontSize = 9.sp, color = TextMuted)
            }
            Divider(color = GridLineGray, modifier = Modifier.padding(vertical = 4.dp))
            Text("Source: ${metric.source}", fontSize = 8.sp, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun GlobalInteractiveMapCanvas(assets: List<Asset>, onAssetSelected: (Asset) -> Unit) {
    var hoveredAsset by remember { mutableStateOf<Asset?>(null) }
    val infiniteTransition = rememberInfiniteTransition()

    // Blinking effect for warning/maintenance
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(assets) {
                detectTapGestures { offset ->
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val clicked = assets.find { asset ->
                        val coords = projectCoordinates(asset.latitude, asset.longitude, w, h)
                        val dx = offset.x - coords.first
                        val dy = offset.y - coords.second
                        (dx * dx + dy * dy) <= 225f
                    }
                    if (clicked != null) {
                        onAssetSelected(clicked)
                    }
                }
            }
    ) {
        val w = size.width
        val h = size.height

        // Draw basic global grid lines
        for (i in 1..8) {
            val y = (h / 9) * i
            drawLine(GridLineGray.copy(alpha = 0.3f), Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }
        for (i in 1..12) {
            val x = (w / 13) * i
            drawLine(GridLineGray.copy(alpha = 0.3f), Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
        }

        // Draw rough continent boundaries to give sense of a world control map
        val americasPath = Path().apply {
            moveTo(w * 0.15f, h * 0.1f)
            lineTo(w * 0.3f, h * 0.15f)
            lineTo(w * 0.35f, h * 0.35f)
            lineTo(w * 0.22f, h * 0.45f)
            lineTo(w * 0.28f, h * 0.6f)
            lineTo(w * 0.32f, h * 0.85f)
            lineTo(w * 0.28f, h * 0.95f)
            lineTo(w * 0.24f, h * 0.65f)
            lineTo(w * 0.15f, h * 0.45f)
            lineTo(w * 0.08f, h * 0.25f)
            close()
        }
        drawPath(americasPath, ExxonBlue.copy(alpha = 0.3f))

        val eurasiaPath = Path().apply {
            moveTo(w * 0.45f, h * 0.15f)
            lineTo(w * 0.65f, h * 0.12f)
            lineTo(w * 0.85f, h * 0.2f)
            lineTo(w * 0.9f, h * 0.45f)
            lineTo(w * 0.75f, h * 0.55f)
            lineTo(w * 0.65f, h * 0.45f)
            lineTo(w * 0.52f, h * 0.35f)
            close()
        }
        drawPath(eurasiaPath, ExxonBlue.copy(alpha = 0.3f))

        val africaPath = Path().apply {
            moveTo(w * 0.48f, h * 0.45f)
            lineTo(w * 0.58f, h * 0.48f)
            lineTo(w * 0.62f, h * 0.65f)
            lineTo(w * 0.55f, h * 0.82f)
            lineTo(w * 0.5f, h * 0.8f)
            lineTo(w * 0.46f, h * 0.6f)
            close()
        }
        drawPath(africaPath, ExxonBlue.copy(alpha = 0.25f))

        val australiaPath = Path().apply {
            moveTo(w * 0.82f, h * 0.68f)
            lineTo(w * 0.92f, h * 0.7f)
            lineTo(w * 0.9f, h * 0.85f)
            lineTo(w * 0.8f, h * 0.82f)
            close()
        }
        drawPath(australiaPath, ExxonBlue.copy(alpha = 0.3f))

        // Draw Interactive Asset Markers
        assets.forEach { asset ->
            val (x, y) = projectCoordinates(asset.latitude, asset.longitude, w, h)
            val markerCol = when (asset.status) {
                AssetStatus.OPERATIONAL -> SignalGreen
                AssetStatus.WARNING -> AlertOrange
                AssetStatus.MAINTENANCE -> HighContrastBlue
                AssetStatus.OFFLINE -> ExxonRed
            }

            // Outer pulse
            if (asset.status != AssetStatus.OPERATIONAL) {
                drawCircle(
                    color = markerCol,
                    radius = 12f * pulseAlpha + 6f,
                    center = Offset(x, y),
                    alpha = 1.0f - pulseAlpha
                )
            } else {
                drawCircle(
                    color = markerCol,
                    radius = 8f,
                    center = Offset(x, y),
                    alpha = 0.4f
                )
            }

            // Core dot
            drawCircle(
                color = markerCol,
                radius = 5f,
                center = Offset(x, y)
            )

            // Minimal text indicator
            val textPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.WHITE
                textSize = 22f
                isAntiAlias = true
            }
            drawContext.canvas.nativeCanvas.drawText(
                asset.name.take(12),
                x + 8f,
                y + 6f,
                textPaint
            )
        }
    }
}

// Projection function mapping lat/lng to canvas space
fun projectCoordinates(lat: Double, lng: Double, w: Float, h: Float): Pair<Float, Float> {
    val latF = lat.toFloat()
    val lngF = lng.toFloat()
    val x = ((lngF + 180f) / 360f) * w
    val y = ((90f - latF) / 180f) * h
    return Pair(x.coerceIn(0f, w), y.coerceIn(0f, h))
}

@Composable
fun AssetInspectionPanel(asset: Asset, onClose: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ASSET METROLOGY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
            IconButton(onClick = onClose, modifier = Modifier.size(24.dp).testTag("close_asset_btn")) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = TextWhite, modifier = Modifier.size(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(asset.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextWhite)
        Text("TYPE: ${asset.type.name} | REGION: ${asset.region.name}", fontSize = 10.sp, color = AccentTeal)

        Spacer(modifier = Modifier.height(16.dp))

        // Status Card
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(GridLineGray, RoundedCornerShape(4.dp))
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("INTEGRITY HEALTH INDEX", fontSize = 9.sp, color = TextMuted)
                Text("${asset.healthScore}%", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = if (asset.healthScore >= 90) SignalGreen else AlertOrange)
            }
            Surface(
                color = when (asset.status) {
                    AssetStatus.OPERATIONAL -> SignalGreen.copy(alpha = 0.2f)
                    AssetStatus.WARNING -> AlertOrange.copy(alpha = 0.2f)
                    AssetStatus.OFFLINE -> ExxonRed.copy(alpha = 0.2f)
                    AssetStatus.MAINTENANCE -> HighContrastBlue.copy(alpha = 0.2f)
                },
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    asset.status.name,
                    color = when (asset.status) {
                        AssetStatus.OPERATIONAL -> SignalGreen
                        AssetStatus.WARNING -> AlertOrange
                        AssetStatus.OFFLINE -> ExxonRed
                        AssetStatus.MAINTENANCE -> HighContrastBlue
                    },
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("LIVE SENSOR TELEMETRY", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextMuted)
        Spacer(modifier = Modifier.height(8.dp))

        if (asset.telemetry.isNotEmpty()) {
            asset.telemetry.forEach { (key, value) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(key.replace("_", " "), fontSize = 12.sp, color = TextWhite)
                    Text(String.format("%.2f", value), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
                }
                Divider(color = GridLineGray.copy(alpha = 0.5f))
            }
        } else {
            Text("No telemetry channels registered.", fontSize = 11.sp, color = TextMuted)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Provenance & Cybersecurity
        Card(
            colors = CardDefaults.cardColors(containerColor = ControlBackground),
            modifier = Modifier.fillMaxWidth().border(width = 0.5.dp, color = GridLineGray)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text("DATA PROVENANCE SECURED", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SignalGreen)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Ingested via Honeywell Edge-Crypt Gateways. SHA-256 Verified Ledger block matching.", fontSize = 10.sp, color = TextMuted)
            }
        }
    }
}

@Composable
fun EmptySelectionPanel(title: String, desc: String) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.Info, contentDescription = "No select", tint = TextMuted, modifier = Modifier.size(48.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(8.dp))
        Text(desc, fontSize = 11.sp, color = TextMuted, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp))
    }
}

// ----------------------------------------------------
// 2. OPERATIONS — INCIDENT CONTROL ROOM & SAFETY
// ----------------------------------------------------
@Composable
fun OperationsScreen(viewModel: EnergyOSViewModel) {
    val incidents by viewModel.incidents.collectAsState()
    val permits by viewModel.permits.collectAsState()

    var showPermitDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text("INCIDENT COMMAND CONTROL ROOM", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = ExxonRed)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Incidents Tracker
            Column(
                modifier = Modifier
                    .weight(1.5f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Text("ACTIVE OPERATIONAL INCIDENTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(12.dp))

                incidents.forEach { incident ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ControlBackground),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .border(width = 1.dp, color = if (incident.severity == "CRITICAL") ExxonRed else AlertOrange)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(incident.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                Surface(
                                    color = if (incident.severity == "CRITICAL") ExxonRed.copy(alpha = 0.2f) else AlertOrange.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(2.dp)
                                ) {
                                    Text(
                                        incident.severity,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (incident.severity == "CRITICAL") ExxonRed else AlertOrange,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(incident.description, fontSize = 11.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Timeline History:", fontSize = 10.sp, color = AccentTeal, fontWeight = FontWeight.Bold)
                            incident.timeline.forEach { log ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("• ${log.status}: ${log.description}", fontSize = 9.sp, color = TextMuted)
                                    Text(log.timestamp, fontSize = 9.sp, color = TextMuted)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Column: Permits to Work PTW Ledger
            Column(
                modifier = Modifier
                    .weight(1.5f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ACTIVE PERMITS TO WORK (PTW)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    Button(
                        onClick = { showPermitDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = HighContrastBlue),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("create_permit_btn")
                    ) {
                        Text("Add Permit", fontSize = 10.sp, color = TextWhite)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                permits.forEach { permit ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ControlBackground),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .border(width = 0.5.dp, color = GridLineGray)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(permit.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                Surface(
                                    color = when (permit.status) {
                                        "APPROVED" -> SignalGreen.copy(alpha = 0.2f)
                                        "REVIEW" -> AlertOrange.copy(alpha = 0.2f)
                                        else -> TextMuted.copy(alpha = 0.2f)
                                    },
                                    shape = RoundedCornerShape(2.dp)
                                ) {
                                    Text(
                                        permit.status,
                                        fontSize = 8.sp,
                                        color = when (permit.status) {
                                            "APPROVED" -> SignalGreen
                                            "REVIEW" -> AlertOrange
                                            else -> TextMuted
                                        },
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Site: ${permit.site} | Type: ${permit.type}", fontSize = 10.sp, color = AccentTeal)
                            Text("Author: ${permit.author} | Reviewer: ${permit.approvedBy}", fontSize = 9.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Required Precautions:", fontSize = 9.sp, color = TextWhite, fontWeight = FontWeight.Bold)
                            permit.safetyMeasures.forEach { measure ->
                                Text("✔ $measure", fontSize = 9.sp, color = SignalGreen)
                            }
                            if (permit.status == "REVIEW") {
                                Button(
                                    onClick = {
                                        viewModel.submitWorkPermit(permit.copy(status = "APPROVED", approvedBy = "HSE Supervisor"))
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SignalGreen),
                                    shape = RoundedCornerShape(2.dp),
                                    modifier = Modifier.padding(top = 8.dp).testTag("approve_ptw_${permit.id}")
                                ) {
                                    Text("Approve Permit to Work", fontSize = 8.sp, color = TextWhite)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // New Permit Dialog Simulation
    if (showPermitDialog) {
        AlertDialog(
            onDismissRequest = { showPermitDialog = false },
            title = { Text("Draft New Permit to Work", color = TextWhite) },
            text = {
                Column {
                    Text("Select permit parameters to inject securely into operations grid", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = {
                        viewModel.addWorkPermit(
                            WorkPermit(
                                id = "p-${UUID.randomUUID().toString().take(4)}",
                                name = "Hot Work: Flare Stack Purge",
                                site = "Antwerp Refinery",
                                type = "Hot Work",
                                status = "REVIEW",
                                author = "Refinery Engineer S. Jenkins",
                                approvedBy = "Pending HSE Sign-off",
                                description = "Purge flare lines prior to standard mechanical inspection.",
                                safetyMeasures = listOf("Lock Out Tag Out (LOTO) completed", "Nitrogen purge sweep logged", "Fire watch officer on station")
                            )
                        )
                        showPermitDialog = false
                    }, colors = ButtonDefaults.buttonColors(containerColor = HighContrastBlue)) {
                        Text("Draft Hot Work Permit (Antwerp)")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPermitDialog = false }) {
                    Text("Cancel", color = ExxonRed)
                }
            },
            containerColor = SurfaceDark
        )
    }
}

// ----------------------------------------------------
// 3. ASSETS — DRILLING, SUB-SURFACE, RESERVOIRS
// ----------------------------------------------------
@Composable
fun AssetsScreen(viewModel: EnergyOSViewModel) {
    val wells by viewModel.wells.collectAsState()
    val selectedWell by viewModel.selectedWell.collectAsState()
    var selectedScenarioRes by remember { mutableStateOf("Scenario A (Baseline)") }

    Column(modifier = Modifier.fillMaxSize()) {
        Text("UPSTREAM GEOSCIENCE & DRILLING WORKBENCH", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Wells list
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(12.dp)
            ) {
                Text("ACTIVE DRILLING WELLS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(12.dp))

                Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Column {
                        wells.forEach { well ->
                            val isSelected = selectedWell?.id == well.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectWell(well) }
                                    .background(if (isSelected) ExxonBlue else Color.Transparent)
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(well.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                    Text("Depth: ${well.depth} m | ${well.trajectory}", fontSize = 10.sp, color = TextMuted)
                                }
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(
                                            when (well.status) {
                                                AssetStatus.OPERATIONAL -> SignalGreen
                                                AssetStatus.WARNING -> AlertOrange
                                                AssetStatus.MAINTENANCE -> HighContrastBlue
                                                AssetStatus.OFFLINE -> ExxonRed
                                            }, CircleShape
                                        )
                                )
                            }
                            Divider(color = GridLineGray.copy(alpha = 0.4f))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Column: Reservoir & Trajectory Visualizer
            Column(
                modifier = Modifier
                    .weight(1.8f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                if (selectedWell != null) {
                    Text("WELL DIAGNOSTICS: ${selectedWell!!.name}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Text("Geological Block: ${selectedWell!!.parentFieldId}", fontSize = 10.sp, color = AccentTeal)

                    Spacer(modifier = Modifier.height(12.dp))

                    // Simulated 2D Well Bore Trajectory
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .background(ControlBackground)
                            .border(width = 1.dp, color = GridLineGray)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw geological strata lines
                            drawLine(Color(0xFF8D5B4C), Offset(0f, h * 0.2f), Offset(w, h * 0.25f), strokeWidth = 2f) // Shale
                            drawLine(Color(0xFF6E5D57), Offset(0f, h * 0.5f), Offset(w, h * 0.48f), strokeWidth = 2f) // Silt
                            drawLine(Color(0xFF2C3E50), Offset(0f, h * 0.8f), Offset(w, h * 0.82f), strokeWidth = 2f) // Hydrocarbon Reservoirs

                            // Labels
                            val textPaint = android.graphics.Paint().apply {
                                color = android.graphics.Color.GRAY
                                textSize = 22f
                            }
                            drawContext.canvas.nativeCanvas.drawText("Shale Layer (Unconventional)", 20f, h * 0.15f, textPaint)
                            drawContext.canvas.nativeCanvas.drawText("Siltstone Cap Rock", 20f, h * 0.42f, textPaint)
                            drawContext.canvas.nativeCanvas.drawText("Delaware Sandstone Reservoir", 20f, h * 0.75f, textPaint)

                            // Draw trajectory line
                            val points = selectedWell!!.trajectories
                            if (points.isNotEmpty()) {
                                val drawPath = Path()
                                drawPath.moveTo(w * 0.5f, 0f)
                                points.forEachIndexed { idx, pt ->
                                    val screenX = (w * 0.5f) + pt.x
                                    val screenY = (h * 0.8f) * (idx / 5f)
                                    drawPath.lineTo(screenX, screenY)
                                }
                                drawPath(drawPath, color = HighContrastBlue, style = Stroke(width = 6f))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Drilling metrics and simulation scenarios comparison
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("PRESSURE", fontSize = 10.sp, color = TextMuted)
                            Text("${selectedWell!!.pressure} psi", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("WATER CUT", fontSize = 10.sp, color = TextMuted)
                            Text("${selectedWell!!.waterCut}%", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AlertOrange)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("FLOW RATE", fontSize = 10.sp, color = TextMuted)
                            Text("${selectedWell!!.oilRate} bpd", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SignalGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("RESERVOIR SIMULATOR SCHEME", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Scenario comparison dropdown selector
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Active Scheme:", fontSize = 11.sp, color = TextWhite)
                        Spacer(modifier = Modifier.width(8.dp))
                        listOf("Scenario A (Baseline)", "Scenario B (Waterflood)", "Scenario C (Gas Inject)").forEach { scheme ->
                            val isSelected = selectedScenarioRes == scheme
                            Button(
                                onClick = { selectedScenarioRes = scheme },
                                colors = ButtonDefaults.buttonColors(containerColor = if (isSelected) ExxonBlue else GridLineGray),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.padding(horizontal = 4.dp).height(28.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Text(scheme, fontSize = 9.sp, color = TextWhite)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = ControlBackground),
                        modifier = Modifier.fillMaxWidth().border(width = 0.5.dp, color = GridLineGray)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            val values = when (selectedScenarioRes) {
                                "Scenario A (Baseline)" -> Triple("22.5M bbls", "85% NPV Target", "Recovery: 32%")
                                "Scenario B (Waterflood)" -> Triple("28.2M bbls", "102% NPV Target", "Recovery: 40%")
                                else -> Triple("31.0M bbls", "112% NPV Target", "Recovery: 44% (Optimal)")
                            }
                            Text("RESERVOIR SIMULATION METRICS:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
                            Text("• Total recoverable reserve: ${values.first}", fontSize = 11.sp, color = TextWhite)
                            Text("• Financial NPV Model alignment: ${values.second}", fontSize = 11.sp, color = TextWhite)
                            Text("• Ultimate Recovery Factor: ${values.third}", fontSize = 11.sp, color = SignalGreen)
                        }
                    }
                } else {
                    EmptySelectionPanel("No Active Well Selected", "Choose an active drilling trajectory from the left ledger list to open reservoir stratification charts, 2D casing diagrams, and performance forecast models.")
                }
            }
        }
    }
}

// ----------------------------------------------------
// 4. ENERGY — SANKEY ENERGY BALANCE & EMISSIONS
// ----------------------------------------------------
@Composable
fun EnergyScreen(viewModel: EnergyOSViewModel) {
    var steamLossFactor by remember { mutableStateOf(15f) }
    var gridEfficiencySlider by remember { mutableStateOf(85f) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text("EXXONMOBIL SYNTHETIC ENERGY BALANCE SYSTEM", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left: Custom Drawing Sankey-like Energy Balance flow
            Column(
                modifier = Modifier
                    .weight(1.8f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Text("PROCESS ENERGY BALANCE FLOWSHEET", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(ControlBackground)
                        .border(width = 1.dp, color = GridLineGray)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // Sliders impact the width of paths
                        val inputThickness = 25f
                        val refineryFlow = 15f * (gridEfficiencySlider / 100f)
                        val lossFlow = 10f * (steamLossFactor / 15f)

                        // 1. Draw inputs (left nodes)
                        drawRoundRect(color = AccentTeal, topLeft = Offset(20f, h * 0.15f), size = Size(150f, 60f), cornerRadius = CornerRadius(4f, 4f))
                        drawRoundRect(color = HighContrastBlue, topLeft = Offset(20f, h * 0.45f), size = Size(150f, 60f), cornerRadius = CornerRadius(4f, 4f))

                        // 2. Draw processors (middle node)
                        drawRoundRect(color = ExxonBlue, topLeft = Offset(w * 0.45f - 75f, h * 0.35f), size = Size(150f, 80f), cornerRadius = CornerRadius(4f, 4f))

                        // 3. Draw outputs (right nodes)
                        drawRoundRect(color = SignalGreen, topLeft = Offset(w - 170f, h * 0.15f), size = Size(150f, 60f), cornerRadius = CornerRadius(4f, 4f))
                        drawRoundRect(color = ExxonRed, topLeft = Offset(w - 170f, h * 0.55f), size = Size(150f, 60f), cornerRadius = CornerRadius(4f, 4f))

                        // Flows (Flow lines mapping)
                        // Input to Middle
                        drawLine(AccentTeal.copy(alpha = 0.5f), Offset(170f, h * 0.22f), Offset(w * 0.45f - 75f, h * 0.38f), strokeWidth = inputThickness)
                        drawLine(HighContrastBlue.copy(alpha = 0.5f), Offset(170f, h * 0.52f), Offset(w * 0.45f - 75f, h * 0.42f), strokeWidth = inputThickness)

                        // Middle to Products
                        drawLine(SignalGreen.copy(alpha = 0.5f), Offset(w * 0.45f + 75f, h * 0.38f), Offset(w - 170f, h * 0.22f), strokeWidth = refineryFlow)
                        drawLine(ExxonRed.copy(alpha = 0.5f), Offset(w * 0.45f + 75f, h * 0.42f), Offset(w - 170f, h * 0.62f), strokeWidth = lossFlow)

                        // Text tags
                        val paint = android.graphics.Paint().apply {
                            color = android.graphics.Color.WHITE
                            textSize = 22f
                        }
                        drawContext.canvas.nativeCanvas.drawText("CRUDE OIL", 35f, h * 0.20f, paint)
                        drawContext.canvas.nativeCanvas.drawText("NATURAL GAS", 35f, h * 0.50f, paint)
                        drawContext.canvas.nativeCanvas.drawText("BAYTOWN CORE", w * 0.45f - 60f, h * 0.40f, paint)
                        drawContext.canvas.nativeCanvas.drawText("FUELS/PRODUCTS", w - 160f, h * 0.20f, paint)
                        drawContext.canvas.nativeCanvas.drawText("STEAM LOSSES", w - 160f, h * 0.60f, paint)
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right: Emissions & Adjustments Sliders
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Text("EFFICIENCY CONTROLS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(12.dp))

                Text("Steam Recovery Valve Loss: ${steamLossFactor.toInt()}%", fontSize = 11.sp, color = TextWhite)
                Slider(
                    value = steamLossFactor,
                    onValueChange = { steamLossFactor = it },
                    valueRange = 5f..35f,
                    colors = SliderDefaults.colors(thumbColor = AlertOrange, activeTrackColor = AlertOrange),
                    modifier = Modifier.testTag("steam_loss_slider")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Grid Power Efficiency: ${gridEfficiencySlider.toInt()}%", fontSize = 11.sp, color = TextWhite)
                Slider(
                    value = gridEfficiencySlider,
                    onValueChange = { gridEfficiencySlider = it },
                    valueRange = 60f..100f,
                    colors = SliderDefaults.colors(thumbColor = AccentTeal, activeTrackColor = AccentTeal),
                    modifier = Modifier.testTag("grid_efficiency_slider")
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("SUSTAINABILITY EMISSIONS AUDIT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = ControlBackground),
                    modifier = Modifier.fillMaxWidth().border(width = 0.5.dp, color = GridLineGray)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("SCOPE 1 DIRECT EMISSIONS", fontSize = 9.sp, color = TextMuted)
                        Text("3.42M CO2e tonnes (MODELLED)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("SCOPE 2 INDIRECT", fontSize = 9.sp, color = TextMuted)
                        Text("1.25M CO2e tonnes (AUDITED)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("METHANE DENSITY", fontSize = 9.sp, color = TextMuted)
                        Text("0.02% (Aerial Satellites Ingested)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SignalGreen)
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 5. MARKETS — TRADING OS, COMMODITY PRICES, FORECASTS
// ----------------------------------------------------
@Composable
fun MarketsScreen(viewModel: EnergyOSViewModel) {
    val markets by viewModel.markets.collectAsState()
    val trades by viewModel.trades.collectAsState()
    var selectedTickerForTrade by remember { mutableStateOf("BRENT") }
    var orderSizeStr by remember { mutableStateOf("500") }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("GLOBAL COMMODITY MARKETS (SIMULATED REAL-TIME)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
            Surface(
                color = ExxonRed.copy(alpha = 0.15f),
                shape = RoundedCornerShape(2.dp)
            ) {
                Text(
                    text = "SIMULATED MARKET DATA FEED",
                    fontSize = 9.sp,
                    color = ExxonRed,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Price ledger
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(12.dp)
            ) {
                Text("MARKET LEDGER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                markets.forEach { item ->
                    val isSelected = selectedTickerForTrade == item.ticker
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedTickerForTrade = item.ticker }
                            .background(if (isSelected) ExxonBlue else Color.Transparent)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(item.ticker, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text(item.name.take(15), fontSize = 9.sp, color = TextMuted)
                        }
                        val diff = item.price - item.prevClose
                        val col = if (diff >= 0) SignalGreen else ExxonRed
                        Text(
                            text = String.format("$%.2f", item.price),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = col
                        )
                    }
                    Divider(color = GridLineGray.copy(alpha = 0.4f))
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Column: Chart & Execution Book
            Column(
                modifier = Modifier
                    .weight(1.8f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                val activeInstrument = markets.find { it.ticker == selectedTickerForTrade }
                if (activeInstrument != null) {
                    Text("INSTRUMENT DETAILS: ${activeInstrument.name} (${activeInstrument.ticker})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Draw basic history plot + forward curve points on Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .background(ControlBackground)
                            .border(width = 1.dp, color = GridLineGray)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            val points = activeInstrument.history1D
                            if (points.size >= 2) {
                                val minVal = points.minOrNull() ?: 1.0
                                val maxVal = points.maxOrNull() ?: 10.0
                                val range = (maxVal - minVal).coerceAtLeast(0.1)

                                val path = Path()
                                points.forEachIndexed { i, price ->
                                    val x = (i / (points.size - 1f)) * w
                                    val y = h - ((price - minVal) / range) * h
                                    if (i == 0) path.moveTo(x, y.toFloat()) else path.lineTo(x, y.toFloat())
                                }
                                drawPath(path, color = AccentTeal, style = Stroke(width = 4f))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Forward curve inspector
                    Text("COMMODITY FORWARD CURVE: " + activeInstrument.forwardCurve.joinToString(", ") { "$$it" }, fontSize = 10.sp, color = TextMuted)

                    Spacer(modifier = Modifier.height(12.dp))

                    // Trading order form
                    Text("SIMULATED TRADE ORDER ENTRY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = orderSizeStr,
                            onValueChange = { orderSizeStr = it },
                            label = { Text("Quantity (bbl/mmbtu)", color = TextMuted) },
                            textStyle = TextStyle(color = TextWhite),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AccentTeal, unfocusedBorderColor = GridLineGray),
                            modifier = Modifier.width(150.dp).height(50.dp).testTag("trade_quantity_input")
                        )
                        Spacer(modifier = Modifier.width(12.dp))

                        Button(
                            onClick = {
                                val qty = orderSizeStr.toIntOrNull() ?: 500
                                viewModel.executeTrade(selectedTickerForTrade, "BUY", qty, activeInstrument.price)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SignalGreen),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.height(45.dp).testTag("trade_buy_btn")
                        ) {
                            Text("BUY / LONG", fontSize = 11.sp, color = TextWhite)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                val qty = orderSizeStr.toIntOrNull() ?: 500
                                viewModel.executeTrade(selectedTickerForTrade, "SELL", qty, activeInstrument.price)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ExxonRed),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.height(45.dp).testTag("trade_sell_btn")
                        ) {
                            Text("SELL / SHORT", fontSize = 11.sp, color = TextWhite)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Live Trades book ledger
                    Text("TRADING BOOK TRANSACTION HISTORY (LIVE)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        Column {
                            trades.forEach { t ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Trade: ${t.type} ${t.quantity} ${t.ticker}", fontSize = 10.sp, color = TextWhite)
                                    Text("at $${t.price} | ${t.timestamp}", fontSize = 10.sp, color = TextMuted)
                                }
                                Divider(color = GridLineGray.copy(alpha = 0.2f))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 6. REFINING — CONTROL ROOM & TWINS
// ----------------------------------------------------
@Composable
fun RefiningScreen(viewModel: EnergyOSViewModel) {
    val refineries by viewModel.refineries.collectAsState()
    val selectedRefinery by viewModel.selectedRefinery.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text("REFINERY COMPLEX COMMAND CENTRE", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Refineries List
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(12.dp)
            ) {
                Text("REFINERY DIGITAL TWINS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                refineries.forEach { r ->
                    val isSelected = selectedRefinery?.id == r.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectRefinery(r) }
                            .background(if (isSelected) ExxonBlue else Color.Transparent)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(r.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Cap: ${r.baseCapacity} kbpd | feed: ${r.crudeFeedstock}", fontSize = 9.sp, color = TextMuted)
                        }
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(
                                    when (r.status) {
                                        AssetStatus.OPERATIONAL -> SignalGreen
                                        AssetStatus.WARNING -> AlertOrange
                                        AssetStatus.MAINTENANCE -> HighContrastBlue
                                        AssetStatus.OFFLINE -> ExxonRed
                                    }, CircleShape
                                )
                        )
                    }
                    Divider(color = GridLineGray.copy(alpha = 0.4f))
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Column: Refining Process flow and Optimizer
            Column(
                modifier = Modifier
                    .weight(1.8f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                if (selectedRefinery != null) {
                    Text("REFINERY INTEGRATION FLOW: ${selectedRefinery!!.name}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Process flowsheet canvas drawing
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(ControlBackground)
                            .border(width = 1.dp, color = GridLineGray)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // CRUDE (10%) -> DISTILLATION (30%) -> TREATMENT (60%) -> BLENDING/PRODUCT (90%)
                            drawRoundRect(color = ExxonBlue, topLeft = Offset(20f, h * 0.35f), size = Size(110f, 50f), cornerRadius = CornerRadius(4f, 4f))
                            drawRoundRect(color = AccentTeal, topLeft = Offset(w * 0.3f - 40f, h * 0.15f), size = Size(120f, 100f), cornerRadius = CornerRadius(4f, 4f))
                            drawRoundRect(color = SurfaceMedium, topLeft = Offset(w * 0.65f - 40f, h * 0.3f), size = Size(120f, 60f), cornerRadius = CornerRadius(4f, 4f))
                            drawRoundRect(color = SignalGreen, topLeft = Offset(w - 140f, h * 0.35f), size = Size(120f, 50f), cornerRadius = CornerRadius(4f, 4f))

                            // Connecting Pipes
                            drawLine(TextWhite.copy(alpha = 0.4f), Offset(130f, h * 0.5f), Offset(w * 0.3f - 40f, h * 0.5f), strokeWidth = 4f)
                            drawLine(TextWhite.copy(alpha = 0.4f), Offset(w * 0.3f + 80f, h * 0.5f), Offset(w * 0.65f - 40f, h * 0.5f), strokeWidth = 4f)
                            drawLine(TextWhite.copy(alpha = 0.4f), Offset(w * 0.65f + 80f, h * 0.5f), Offset(w - 140f, h * 0.5f), strokeWidth = 4f)

                            val paint = android.graphics.Paint().apply {
                                color = android.graphics.Color.WHITE
                                textSize = 20f
                            }
                            drawContext.canvas.nativeCanvas.drawText("CRUDE IN", 25f, h * 0.45f, paint)
                            drawContext.canvas.nativeCanvas.drawText("CDU COLUMN", w * 0.3f - 35f, h * 0.45f, paint)
                            drawContext.canvas.nativeCanvas.drawText("TREATER", w * 0.65f - 30f, h * 0.45f, paint)
                            drawContext.canvas.nativeCanvas.drawText("PRODUCT OUT", w - 135f, h * 0.45f, paint)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("LIVE UNIT METROLOGY DETECTED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))

                    Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        Column {
                            selectedRefinery!!.units.forEach { unit ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(unit.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                        Text("Temp: ${unit.temperature} F | Press: ${unit.pressure} psi", fontSize = 9.sp, color = TextMuted)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Flow: ${unit.throughput} kbpd", fontSize = 11.sp, color = AccentTeal)
                                        Text("Energy: ${unit.energyIntensity} MBtu/bbl", fontSize = 9.sp, color = TextMuted)
                                    }
                                }
                                Divider(color = GridLineGray.copy(alpha = 0.2f))
                            }
                        }
                    }
                } else {
                    EmptySelectionPanel("No Active Refinery Selected", "Choose a regional refinery asset to monitor real-time distillation column parameters, cracker operations, catalyst health scores, and optimizer targets.")
                }
            }
        }
    }
}

// ----------------------------------------------------
// 7. CHEMICALS — CHEMICALS PLANT, MATERIALS & LUBRICANTS
// ----------------------------------------------------
@Composable
fun ChemicalsScreen(viewModel: EnergyOSViewModel) {
    val chemicalPlants by viewModel.chemicalPlants.collectAsState()
    val selectedPlant by viewModel.selectedChemicalPlant.collectAsState()
    val lubricants by viewModel.lubricants.collectAsState()
    val diagnostics by viewModel.lubricantDiagnostics.collectAsState()

    var materialSearchQuery by remember { mutableStateOf("") }
    var viscoSampleInput by remember { mutableStateOf("LA-1102") }

    Column(modifier = Modifier.fillMaxSize()) {
        Text("CHEMICALS, ADVANCED POLYMERS & LUBRICANTS OS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Olefins Plant lists
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(12.dp)
            ) {
                Text("CHEMICAL PLANTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                chemicalPlants.forEach { plant ->
                    val isSelected = selectedPlant?.id == plant.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectChemicalPlant(plant) }
                            .background(if (isSelected) ExxonBlue else Color.Transparent)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(plant.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Feed: ${plant.feedstockFeedRate} tons/hr", fontSize = 9.sp, color = TextMuted)
                        }
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(if (plant.status == AssetStatus.OPERATIONAL) SignalGreen else AlertOrange, CircleShape)
                        )
                    }
                    Divider(color = GridLineGray.copy(alpha = 0.3f))
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("POLYMERS GRADE SEARCH", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = materialSearchQuery,
                    onValueChange = { materialSearchQuery = it },
                    placeholder = { Text("automotive, medical, construction...", fontSize = 10.sp, color = TextMuted) },
                    textStyle = TextStyle(color = TextWhite, fontSize = 11.sp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AccentTeal, unfocusedBorderColor = GridLineGray),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("polymer_search_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // High quality polymer results mock
                Card(colors = CardDefaults.cardColors(containerColor = ControlBackground)) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Mobil PP-7032 Exxon Poly", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        Text("High performance polypropylene for lightweight automotive components & impact resistance.", fontSize = 9.sp, color = TextMuted)
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Column: Active diagnostics and diagnostics detail
            Column(
                modifier = Modifier
                    .weight(2f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                if (selectedPlant != null) {
                    Text("CHEMICAL PLANT TWIN: ${selectedPlant!!.name}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Card(colors = CardDefaults.cardColors(containerColor = ControlBackground), modifier = Modifier.weight(1f)) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("ETHYLENE OUTPUT", fontSize = 8.sp, color = TextMuted)
                                Text("${selectedPlant!!.outputEthylene} kt/yr", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = ControlBackground), modifier = Modifier.weight(1f)) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("POLYMERS OUTPUT", fontSize = 8.sp, color = TextMuted)
                                Text("${selectedPlant!!.outputPolyethylene} kt/yr", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                Text("LUBRICANTS VISCOSITY DIAGNOSTICS LAB", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = viscoSampleInput,
                        onValueChange = { viscoSampleInput = it },
                        label = { Text("Sample ID Code", color = TextMuted) },
                        textStyle = TextStyle(color = TextWhite),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AccentTeal, unfocusedBorderColor = GridLineGray),
                        modifier = Modifier.width(160.dp).height(50.dp).testTag("lubricant_sample_input")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val matchedDiag = diagnostics.find { it.sampleId == viscoSampleInput }
                if (matchedDiag != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ControlBackground),
                        modifier = Modifier.fillMaxWidth().border(width = 1.dp, color = if (matchedDiag.status == "CRITICAL") ExxonRed else SignalGreen)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("SAMPLE SUMMARY: ${matchedDiag.sampleId}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
                            Text("Target Machinery: ${matchedDiag.vehicleId}", fontSize = 11.sp, color = TextWhite)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text("Viscosity: ${matchedDiag.viscosityCSt} cSt", fontSize = 10.sp, color = TextWhite)
                                Text("Wear metals: ${matchedDiag.wearMetalsPpm} ppm", fontSize = 10.sp, color = TextWhite)
                                Text("Contamination: ${matchedDiag.contaminationPct}%", fontSize = 10.sp, color = TextWhite)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Status: ${matchedDiag.status}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (matchedDiag.status == "CRITICAL") ExxonRed else SignalGreen)
                            Text("Action recommended: ${matchedDiag.recommendation}", fontSize = 10.sp, color = TextMuted)
                        }
                    }
                } else {
                    Text("Provide a valid sample ID (LA-1102, LA-4029, LA-9821) to pull lab diagnostics.", fontSize = 11.sp, color = TextMuted)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("MOBIL 1 PRODUCTS REGISTRY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Column {
                        lubricants.forEach { lube ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(lube.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                Text(lube.category, fontSize = 9.sp, color = AccentTeal)
                            }
                            Text("Viscosity Index: ${lube.viscosityIdx} | Service limit: ${lube.recommendedInterval}", fontSize = 9.sp, color = TextMuted)
                            Divider(color = GridLineGray.copy(alpha = 0.2f))
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 8. MOBILITY — MOTORIST STATION FINDER & PAY AT PUMP
// ----------------------------------------------------
@Composable
fun MobilityScreen(viewModel: EnergyOSViewModel) {
    val stations by viewModel.stations.collectAsState()
    val logs by viewModel.fuelLogs.collectAsState()
    val vehicles by viewModel.vehicles.collectAsState()

    val step by viewModel.pumpStep.collectAsState()
    val selectedStation by viewModel.selectedStationForPump.collectAsState()
    val progress by viewModel.fuelingVolumeProgress.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text("MOBILITY & MOTORIST DIGITAL PLATFORM", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Station list & logs
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(12.dp)
            ) {
                Text("SYNERGY FUEL STATIONS FINDER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                stations.forEach { station ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectedStationForPump.value = station
                                viewModel.pumpStep.value = 2 // Move to select pump
                            }
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(station.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text(station.address, fontSize = 9.sp, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text("$${station.regularPrice}/G", fontSize = 11.sp, color = SignalGreen)
                    }
                    Divider(color = GridLineGray.copy(alpha = 0.3f))
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("VEHICLE GARAGE RECORD", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                vehicles.forEach { v ->
                    Card(colors = CardDefaults.cardColors(containerColor = ControlBackground), modifier = Modifier.padding(vertical = 4.dp).fillMaxWidth()) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("${v.make} ${v.model} (${v.year})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Mileage: ${v.mileage} miles | Oil health: ${v.oilHealth}%", fontSize = 9.sp, color = TextMuted)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Column: Automated Pay at Pump Flow
            Column(
                modifier = Modifier
                    .weight(1.8f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Text("PAY AT PUMP INTEGRATED WIZARD (SIMULATED)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(12.dp))

                when (step) {
                    1 -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.LocationOn, contentDescription = "Select station", tint = AlertOrange, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Step 1: Select Station", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Select an Exxon/Mobil Synergy station on the left ledger menu to begin the Pay-At-Pump sequence.", fontSize = 11.sp, color = TextMuted, textAlign = TextAlign.Center)
                        }
                    }
                    2 -> {
                        Column {
                            Text("Station selected: ${selectedStation!!.name}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Step 2: Select Pump", fontSize = 12.sp, color = TextMuted)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                selectedStation!!.pumpStates.forEachIndexed { idx, state ->
                                    val id = idx + 1
                                    Button(
                                        onClick = {
                                            viewModel.selectedPumpId.value = id
                                            viewModel.pumpStep.value = 3
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (state == "FREE") SignalGreen else ExxonRed),
                                        modifier = Modifier.weight(1f).testTag("pump_select_btn_$id"),
                                        enabled = state == "FREE"
                                    ) {
                                        Text("Pump $id", fontSize = 10.sp, color = TextWhite)
                                    }
                                }
                            }
                        }
                    }
                    3 -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Text("Pump Selected: Pump #${viewModel.selectedPumpId.value}", fontSize = 12.sp, color = TextWhite)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Step 3: Authorizing Payment", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Connecting via secure Synthetic Payment Provider. Never uses actual bank card details.", fontSize = 10.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(12.dp))
                            CircularProgressIndicator(color = AccentTeal)
                            Button(
                                onClick = { viewModel.pumpStep.value = 4 },
                                colors = ButtonDefaults.buttonColors(containerColor = HighContrastBlue),
                                modifier = Modifier.padding(top = 12.dp).testTag("authorise_payment_btn")
                            ) {
                                Text("Authorise Pump and Select Gas octane")
                            }
                        }
                    }
                    4 -> {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Text("FUELING IN PROGRESS (Pump #${viewModel.selectedPumpId.value})", fontSize = 12.sp, color = AlertOrange, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(12.dp))
                            LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth(), color = SignalGreen)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(String.format("Volume Injected: %.2f Liters", progress * 45.2), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Dynamic simulation flowing... please wait.", fontSize = 10.sp, color = TextMuted)
                        }
                    }
                    5 -> {
                        Column {
                            Text("TRANSACTION COMPLETED", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SignalGreen)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Receipt Code: EM-9420-0012", fontSize = 10.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Station: ${selectedStation?.name}", fontSize = 11.sp, color = TextWhite)
                            Text("Pump: #${viewModel.selectedPumpId.value}", fontSize = 11.sp, color = TextWhite)
                            Text("Octane chosen: ${viewModel.chosenFuelType.value}", fontSize = 11.sp, color = TextWhite)
                            Text("Volume: 45.2 Liters", fontSize = 11.sp, color = TextWhite)
                            Text("Total Charge: $${String.format("%.2f", 45.2 * (selectedStation?.regularPrice ?: 2.95))} (Synthetic)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhite)

                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.pumpStep.value = 1 },
                                colors = ButtonDefaults.buttonColors(containerColor = ExxonBlue),
                                modifier = Modifier.testTag("reset_pump_btn")
                            ) {
                                Text("Refuel Another Vehicle")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text("FUEL TRANSACTION HISTORY LOGS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Box(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Column {
                        logs.forEach { log ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${log.vehicleName} - ${log.stationName}", fontSize = 10.sp, color = TextWhite)
                                Text("${log.volume}L @ $${log.pricePerLiter}/L", fontSize = 10.sp, color = TextMuted)
                            }
                            Divider(color = GridLineGray.copy(alpha = 0.2f))
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 9. LOW CARBON — CARBON CAPTURE, HYDROGEN & LITHIUM
// ----------------------------------------------------
@Composable
fun LowCarbonScreen(viewModel: EnergyOSViewModel) {
    val ccsProjects by viewModel.ccsProjects.collectAsState()
    val hydrogenProjects by viewModel.hydrogenProjects.collectAsState()
    val lithiumProjects by viewModel.lithiumProjects.collectAsState()

    val h2PowerCost by viewModel.greenH2PowerSlider.collectAsState()
    val h2WaterCost by viewModel.greenH2WaterSlider.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text("LOW CARBON Solutions & DECARBONISATION COMMAND", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: CCS Point capture facilities
            Column(
                modifier = Modifier
                    .weight(1.5f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Text("CARBON CAPTURE & STORAGE (CCS)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                ccsProjects.forEach { p ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ControlBackground),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(p.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                                Text("${p.co2Captured} mtpa", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
                            }
                            Text("Region: ${p.region.name} | Monitoring sensors active: ${p.activeMonitoringSensors}", fontSize = 9.sp, color = TextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(progress = (p.co2Captured / p.storageCapacity).toFloat(), modifier = Modifier.fillMaxWidth(), color = AccentTeal)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("LITHIUM BRINE EXTRACTION PROJECTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(6.dp))

                lithiumProjects.forEach { li ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ControlBackground),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(li.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Method: ${li.resourceType} | Target Output: ${li.extractionRateTpa} tpa LCE", fontSize = 9.sp, color = TextMuted)
                            Text("Brine Concentrate: ${li.concentrationMgL} mg/L | Yield: ${li.recoveryEfficiencyPct}%", fontSize = 9.sp, color = TextMuted)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Column: Green Hydrogen & Green Economics Optimizer
            Column(
                modifier = Modifier
                    .weight(1.5f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Text("GREEN HYDROGEN PROJECTS & ECONOMICS OPTIMIZER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(12.dp))

                hydrogenProjects.forEach { h2 ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ControlBackground),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(h2.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Type: ${h2.type} | Production load: ${h2.currentProductionKgDay}/${h2.capacityKgDay} kg/day", fontSize = 9.sp, color = TextMuted)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("HYDROGEN SENSITIVITY SOLVER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                // Economics slider adjustments
                Text("Renewable Electricity Cost: $${h2PowerCost.toInt()}/MWh", fontSize = 11.sp, color = TextWhite)
                Slider(
                    value = h2PowerCost.toFloat(),
                    onValueChange = { viewModel.greenH2PowerSlider.value = it.toDouble() },
                    valueRange = 20f..100f,
                    colors = SliderDefaults.colors(thumbColor = AccentTeal, activeTrackColor = AccentTeal),
                    modifier = Modifier.testTag("h2_power_slider")
                )

                Text("Demineralised Water Cost: $${String.format("%.2f", h2WaterCost)}/m3", fontSize = 11.sp, color = TextWhite)
                Slider(
                    value = h2WaterCost.toFloat(),
                    onValueChange = { viewModel.greenH2WaterSlider.value = it.toDouble() },
                    valueRange = 0.5f..5.0f,
                    colors = SliderDefaults.colors(thumbColor = AccentTeal, activeTrackColor = AccentTeal),
                    modifier = Modifier.testTag("h2_water_slider")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Calculated hydrogen output
                val calculatedH2Cost = (h2PowerCost * 0.045) + (h2WaterCost * 0.09) + 0.8
                Card(
                    colors = CardDefaults.cardColors(containerColor = ControlBackground),
                    modifier = Modifier.fillMaxWidth().border(width = 0.5.dp, color = GridLineGray)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("ESTIMATED LEVELISED COST OF H2 (LCOH)", fontSize = 8.sp, color = TextMuted)
                        Text(String.format("$%.2f per kg", calculatedH2Cost), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SignalGreen)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Assuming 45 kWh electrolyser stack efficiency & SMR baseline capital amortisation curves.", fontSize = 9.sp, color = TextMuted)
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 10. PROJECTS & CAPITAL — ALLOCATION OS, SUPPLIERS
// ----------------------------------------------------
@Composable
fun ProjectsScreen(viewModel: EnergyOSViewModel) {
    val suppliers by viewModel.suppliers.collectAsState()
    val shipments by viewModel.shipments.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text("CAPITAL PROJECTS ALLOCATION & PROCUREMENT OS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Planned projects IRR list
            Column(
                modifier = Modifier
                    .weight(1.5f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Text("CAPITAL INITIATIVES METRIC REGISTER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(12.dp))

                val mockProjects = listOf(
                    Triple("Smackover Brine Lithium extraction", "$250M CAPEX", "IRR: 32.4% | NPV: $450M"),
                    Triple("Olefins Reactor polymer expansions", "$180M CAPEX", "IRR: 24.5% | NPV: $310M"),
                    Triple("Gulf Point Carbon Transport pipelines", "$140M CAPEX", "IRR: 18.2% | NPV: $190M"),
                    Triple("Fawley refinery distillation upgrading", "$95M CAPEX", "IRR: 15.6% | NPV: $110M")
                )

                mockProjects.forEach { p ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ControlBackground),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).border(width = 0.5.dp, color = GridLineGray)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(p.first, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(p.second, fontSize = 10.sp, color = TextMuted)
                                Text(p.third, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SignalGreen)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Column: Procurement & Shipping
            Column(
                modifier = Modifier
                    .weight(1.5f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Text("SUPPLIERS PERFORMANCE DIRECTORY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                suppliers.forEach { sup ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(sup.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Category: ${sup.category} | Lead time: ${sup.leadTimeDays} days", fontSize = 9.sp, color = TextMuted)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Rating: ${sup.rating}/5.0", fontSize = 10.sp, color = AccentTeal)
                            Text("Risk: ${sup.riskScore}%", fontSize = 9.sp, color = if (sup.riskScore > 10) ExxonRed else SignalGreen)
                        }
                    }
                    Divider(color = GridLineGray.copy(alpha = 0.2f))
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("SHIPMENTS CONTROL TOWER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(6.dp))

                shipments.forEach { s ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(s.vesselName, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("From ${s.origin} to ${s.destination}", fontSize = 9.sp, color = TextMuted)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(s.status, fontSize = 9.sp, color = SignalGreen)
                            Text("${s.quantityBbls.toInt()} bbls", fontSize = 9.sp, color = TextMuted)
                        }
                    }
                    Divider(color = GridLineGray.copy(alpha = 0.2f))
                }
            }
        }
    }
}

// ----------------------------------------------------
// 11. DATA & AI — AI ASSISTANT, DOCS & LINEAGE
// ----------------------------------------------------
@Composable
fun DataScreen(viewModel: EnergyOSViewModel) {
    val aiMessages by viewModel.aiMessages.collectAsState()
    var userInput by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    var activeAiMode by remember { mutableStateOf("ANALYSE") }

    Column(modifier = Modifier.fillMaxSize()) {
        Text("EXXON ENERGY INTELLIGENCE (COGNITIVE REASONING ENGINE)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Semantic Chat Interface
            Column(
                modifier = Modifier
                    .weight(1.8f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                // AI modes selectors
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("EXPLAIN", "ANALYSE", "COMPARE", "FORECAST", "OPTIMISE").forEach { mode ->
                        val isSelected = activeAiMode == mode
                        Button(
                            onClick = { activeAiMode = mode },
                            colors = ButtonDefaults.buttonColors(containerColor = if (isSelected) ExxonBlue else GridLineGray),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f).height(28.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp)
                        ) {
                            Text(mode, fontSize = 8.sp, color = TextWhite)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Messages area
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(ControlBackground)
                        .border(width = 1.dp, color = GridLineGray)
                        .padding(10.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(scrollState)
                    ) {
                        aiMessages.forEach { msg ->
                            val isUser = msg.sender == "USER"
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                            ) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = if (isUser) ExxonBlue else SurfaceDark),
                                    modifier = Modifier
                                        .widthIn(max = 420.dp)
                                        .border(width = 0.5.dp, color = GridLineGray)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = if (isUser) "COMMAND INGESTION" else "REASONING OUTPUT",
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isUser) AccentTeal else SignalGreen
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(msg.text, fontSize = 12.sp, color = TextWhite)

                                        if (msg.confidence != null) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Divider(color = GridLineGray)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text("AI METRICS SUMMARY (EXPLAINABLE):", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AccentTeal)
                                            Text("• COGNITIVE CONFIDENCE: ${(msg.confidence * 100).toInt()}%", fontSize = 10.sp, color = SignalGreen)
                                            Text("• SOLVER MODEL: ${msg.model ?: "Intelligence v3.5"}", fontSize = 10.sp, color = TextWhite)

                                            if (msg.drivers != null) {
                                                Text("• CORE DRIVERS: ${msg.drivers.joinToString(", ")}", fontSize = 10.sp, color = TextMuted)
                                            }
                                            if (msg.evidence != null) {
                                                Text("• DATA EVIDENCE CITED: ${msg.evidence.joinToString(", ")}", fontSize = 10.sp, color = TextMuted)
                                            }
                                            if (msg.assumptions != null) {
                                                Text("• UNDERLYING ASSUMPTIONS: ${msg.assumptions.joinToString(", ")}", fontSize = 10.sp, color = TextMuted)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Input bar
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = userInput,
                        onValueChange = { userInput = it },
                        placeholder = { Text("Ask Exxon Intelligence about refineries, deteriorated assets, highest IRR...", fontSize = 11.sp, color = TextMuted) },
                        textStyle = TextStyle(color = TextWhite),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AccentTeal, unfocusedBorderColor = GridLineGray),
                        modifier = Modifier.weight(1f).height(50.dp).testTag("ai_chat_input"),
                        keyboardOptions = KeyboardOptions.Default.copy(imeAction = androidx.compose.ui.text.input.ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            if (userInput.isNotEmpty()) {
                                viewModel.askAI(userInput)
                                userInput = ""
                            }
                        })
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (userInput.isNotEmpty()) {
                                viewModel.askAI(userInput)
                                userInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HighContrastBlue),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.height(45.dp).testTag("ai_send_btn")
                    ) {
                        Text("Query")
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Right Column: Data Pipeline Quality & Lineage Graph
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(SurfaceDark)
                    .border(width = 1.dp, color = GridLineGray)
                    .padding(16.dp)
            ) {
                Text("DATA INGESTION PROVENANCE & QUALITY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(12.dp))

                Card(colors = CardDefaults.cardColors(containerColor = ControlBackground)) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("DATA LAKE FEATURES QUALITY INDEX", fontSize = 9.sp, color = TextMuted)
                        Text("99.4% VALIDATED", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = SignalGreen)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("0 missing values across 1,420 registered sensor streams. Ingested over MQTT and Kafka nodes.", fontSize = 10.sp, color = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("REASONING DATA LINEAGE PIPELINE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(8.dp))

                val lineageNodes = listOf(
                    "SENSOR telemetry stream Ingestion",
                    "KAFKA encrypted gateway distribution",
                    "SPARK real-time sliding aggregation",
                    "DATA LAKE curated features catalog",
                    "COGNITIVE LLM context inject",
                    "EXPLAINABLE AUDIT DECISION"
                )

                lineageNodes.forEachIndexed { idx, node ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .background(HighContrastBlue, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text((idx + 1).toString(), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(node, fontSize = 10.sp, color = TextWhite)
                    }
                    if (idx < lineageNodes.size - 1) {
                        Box(
                            modifier = Modifier
                                .padding(start = 7.dp)
                                .width(2.dp)
                                .height(12.dp)
                                .background(GridLineGray)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Document semantic analyzer search
                Text("PROPRIETARY CONTRACTS & MANUALS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                Spacer(modifier = Modifier.height(6.dp))

                val docs by viewModel.documents.collectAsState()
                docs.forEach { d ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = ControlBackground),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(d.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                            Text("Summary: ${d.summary}", fontSize = 9.sp, color = TextMuted)
                        }
                    }
                }
            }
        }
    }
}
