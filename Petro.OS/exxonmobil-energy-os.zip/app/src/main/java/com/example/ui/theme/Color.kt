package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ExxonMobil Brand and Control Room Palette
val ControlBackground = Color(0xFF080F1E) // Deepest dark blue-grey
val SurfaceDark = Color(0xFF111C30)     // Deep navy card surfaces
val SurfaceMedium = Color(0xFF1E2D4A)   // Medium steel grey-blue
val ExxonBlue = Color(0xFF0C2340)       // Official deep Exxon blue
val HighContrastBlue = Color(0xFF007ACC) // Brilliant indicator blue
val ExxonRed = Color(0xFFD62D20)        // Restrained alert red
val AlertOrange = Color(0xFFE65100)     // Warning orange
val AccentTeal = Color(0xFF00B4D8)      // Hydrogen green-blue teal
val SignalGreen = Color(0xFF2EC4B6)     // Safe operating green
val TextWhite = Color(0xFFFFFFFF)       // Crisp display text
val TextMuted = Color(0xFF8E9AA8)       // Steel muted reading text
val GridLineGray = Color(0xFF2A3B50)    // Control grid lines

val PrimaryLight = Color(0xFF0A2342)
val SecondaryLight = Color(0xFF4A5568)
val BackgroundLight = Color(0xFFF7FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
