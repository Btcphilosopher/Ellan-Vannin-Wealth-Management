package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = HighContrastBlue,
    onPrimary = TextWhite,
    secondary = AccentTeal,
    onSecondary = TextWhite,
    tertiary = ExxonRed,
    background = ControlBackground,
    onBackground = TextWhite,
    surface = SurfaceDark,
    onSurface = TextWhite,
    surfaceVariant = SurfaceMedium,
    onSurfaceVariant = TextMuted,
    error = ExxonRed
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryLight,
    onPrimary = Color.White,
    secondary = SecondaryLight,
    onSecondary = Color.White,
    background = BackgroundLight,
    onBackground = PrimaryLight,
    surface = SurfaceLight,
    onSurface = PrimaryLight,
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = SecondaryLight,
    error = Color(0xFFC53030)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark theme by default for control room look
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
