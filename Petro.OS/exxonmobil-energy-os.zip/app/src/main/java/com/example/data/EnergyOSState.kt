package com.example.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.sin
import kotlin.random.Random

enum class UserRole(val displayName: String, val focusTab: String) {
    EXECUTIVE("Executive (CEO)", "HOME"),
    ENGINEER("Operations Engineer", "ASSETS"),
    OPERATOR("Refinery Operator", "REFINING"),
    TRADER("Commodity Trader", "MARKETS"),
    GEOLOGIST("Geospatial Geologist", "ASSETS"),
    CHEMICAL_ENGINEER("Materials Specialist", "CHEMICALS"),
    FIELD_TECHNICIAN("Field Tech (Mobile)", "MOBILITY"),
    FINANCE("Capital Director", "PROJECTS"),
    SUPPLY_CHAIN("Logistics Manager", "SUPPLY CHAIN"),
    SAFETY("HSE Coordinator", "OPERATIONS"),
    SUSTAINABILITY("Low Carbon Officer", "LOW CARBON"),
    ADMIN("System Admin", "ADMIN"),
    AUDITOR("Regulatory Auditor", "REPORTS")
}

data class AISuggestion(val prompt: String, val category: String)

data class AIMessage(
    val sender: String, // "USER" or "AI"
    val text: String,
    val confidence: Double? = null,
    val drivers: List<String>? = null,
    val evidence: List<String>? = null,
    val model: String? = null,
    val assumptions: List<String>? = null,
    val timestamp: String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
)

class EnergyOSViewModel : ViewModel() {

    // Current State
    private val _activeRole = MutableStateFlow(UserRole.EXECUTIVE)
    val activeRole: StateFlow<UserRole> = _activeRole.asStateFlow()

    private val _activeTab = MutableStateFlow("HOME")
    val activeTab: StateFlow<String> = _activeTab.asStateFlow()

    private val _timeMachine = MutableStateFlow("NOW") // "NOW", "1H_AGO", "1D_AGO", "1W_AGO", "1M_AGO"
    val timeMachine: StateFlow<String> = _timeMachine.asStateFlow()

    private val _selectedAsset = MutableStateFlow<Asset?>(null)
    val selectedAsset: StateFlow<Asset?> = _selectedAsset.asStateFlow()

    private val _selectedWell = MutableStateFlow<Well?>(null)
    val selectedWell: StateFlow<Well?> = _selectedWell.asStateFlow()

    private val _selectedRefinery = MutableStateFlow<Refinery?>(null)
    val selectedRefinery: StateFlow<Refinery?> = _selectedRefinery.asStateFlow()

    private val _selectedChemicalPlant = MutableStateFlow<ChemicalPlant?>(null)
    val selectedChemicalPlant: StateFlow<ChemicalPlant?> = _selectedChemicalPlant.asStateFlow()

    // Interactive States for calculators
    val greenH2PowerSlider = MutableStateFlow(45.0) // $/MWh
    val greenH2WaterSlider = MutableStateFlow(1.5) // $/m3
    val carbonIntensityTaxSlider = MutableStateFlow(50.0) // $/tonne CO2

    // Master list states
    private val _assets = MutableStateFlow<List<Asset>>(emptyList())
    val assets: StateFlow<List<Asset>> = _assets.asStateFlow()

    private val _wells = MutableStateFlow<List<Well>>(emptyList())
    val wells: StateFlow<List<Well>> = _wells.asStateFlow()

    private val _refineries = MutableStateFlow<List<Refinery>>(emptyList())
    val refineries: StateFlow<List<Refinery>> = _refineries.asStateFlow()

    private val _chemicalPlants = MutableStateFlow<List<ChemicalPlant>>(emptyList())
    val chemicalPlants: StateFlow<List<ChemicalPlant>> = _chemicalPlants.asStateFlow()

    private val _lubricants = MutableStateFlow<List<LubricantProduct>>(emptyList())
    val lubricants: StateFlow<List<LubricantProduct>> = _lubricants.asStateFlow()

    private val _lubricantDiagnostics = MutableStateFlow<List<LubricantAnalysis>>(emptyList())
    val lubricantDiagnostics: StateFlow<List<LubricantAnalysis>> = _lubricantDiagnostics.asStateFlow()

    private val _stations = MutableStateFlow<List<Station>>(emptyList())
    val stations: StateFlow<List<Station>> = _stations.asStateFlow()

    private val _vehicles = MutableStateFlow<List<Vehicle>>(emptyList())
    val vehicles: StateFlow<List<Vehicle>> = _vehicles.asStateFlow()

    private val _fuelLogs = MutableStateFlow<List<FuelLog>>(emptyList())
    val fuelLogs: StateFlow<List<FuelLog>> = _fuelLogs.asStateFlow()

    private val _ccsProjects = MutableStateFlow<List<CCSProject>>(emptyList())
    val ccsProjects: StateFlow<List<CCSProject>> = _ccsProjects.asStateFlow()

    private val _hydrogenProjects = MutableStateFlow<List<HydrogenProject>>(emptyList())
    val hydrogenProjects: StateFlow<List<HydrogenProject>> = _hydrogenProjects.asStateFlow()

    private val _lithiumProjects = MutableStateFlow<List<LithiumProject>>(emptyList())
    val lithiumProjects: StateFlow<List<LithiumProject>> = _lithiumProjects.asStateFlow()

    private val _markets = MutableStateFlow<List<MarketInstrument>>(emptyList())
    val markets: StateFlow<List<MarketInstrument>> = _markets.asStateFlow()

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades.asStateFlow()

    private val _incidents = MutableStateFlow<List<Incident>>(emptyList())
    val incidents: StateFlow<List<Incident>> = _incidents.asStateFlow()

    private val _permits = MutableStateFlow<List<WorkPermit>>(emptyList())
    val permits: StateFlow<List<WorkPermit>> = _permits.asStateFlow()

    private val _suppliers = MutableStateFlow<List<ProcurementSupplier>>(emptyList())
    val suppliers: StateFlow<List<ProcurementSupplier>> = _suppliers.asStateFlow()

    private val _shipments = MutableStateFlow<List<Shipment>>(emptyList())
    val shipments: StateFlow<List<Shipment>> = _shipments.asStateFlow()

    private val _documents = MutableStateFlow<List<Document>>(emptyList())
    val documents: StateFlow<List<Document>> = _documents.asStateFlow()

    private val _aiMessages = MutableStateFlow<List<AIMessage>>(emptyList())
    val aiMessages: StateFlow<List<AIMessage>> = _aiMessages.asStateFlow()

    private val _currentScenarioName = MutableStateFlow("Baseline Global Operations")
    val currentScenarioName: StateFlow<String> = _currentScenarioName.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Simulation job
    private var simJob: Job? = null
    private var tickCount = 0

    // Control Room mode: "SIMULATION", "SHADOW", "DEMO"
    val controlRoomMode = MutableStateFlow("SIMULATION")

    // Pay at Pump sequence state
    val pumpStep = MutableStateFlow(1) // 1: Station, 2: Pump, 3: Auth, 4: Fuel, 5: Receipt
    val selectedStationForPump = MutableStateFlow<Station?>(null)
    val selectedPumpId = MutableStateFlow(1)
    val fuelingVolumeProgress = MutableStateFlow(0f)
    val chosenFuelType = MutableStateFlow("REGULAR (87 Octane)")

    init {
        initializeSyntheticData()
        startSimulation()
    }

    private fun initializeSyntheticData() {
        // Initialize Master assets
        val initialAssets = listOf(
            Asset("a1", "Liza Destiny FPSO", AssetType.FPSO, Region.AMERICAS, AssetStatus.OPERATIONAL, 95, 7.35, -56.9, mapOf("Throughput" to 120.0, "Gas_GOR" to 850.0)),
            Asset("a2", "Hebron Offshore Platform", AssetType.PLATFORM, Region.AMERICAS, AssetStatus.OPERATIONAL, 91, 46.54, -48.4, mapOf("Throughput" to 75.0, "Water_Cut" to 14.2)),
            Asset("a3", "Kearl Mine Operations", AssetType.PLATFORM, Region.AMERICAS, AssetStatus.OPERATIONAL, 88, 57.36, -111.13, mapOf("Extraction" to 220.0, "Diluent_Ratio" to 0.3)),
            Asset("a4", "Baton Rouge Complex", AssetType.REFINERY, Region.AMERICAS, AssetStatus.OPERATIONAL, 93, 30.45, -91.14, mapOf("Refining" to 520.0, "Conversion" to 82.5)),
            Asset("a5", "Baytown Chemical Site", AssetType.CHEMICAL_PLANT, Region.AMERICAS, AssetStatus.OPERATIONAL, 89, 29.73, -95.01, mapOf("Ethylene" to 1600.0, "Reactor_Pressure" to 32.5)),
            Asset("a6", "Fawley Refinery & Chemicals", AssetType.REFINERY, Region.EUROPE, AssetStatus.OPERATIONAL, 84, 50.82, -1.35, mapOf("Refining" to 270.0, "Lubricants" to 4.2)),
            Asset("a7", "Antwerp Refinery", AssetType.REFINERY, Region.EUROPE, AssetStatus.MAINTENANCE, 78, 51.25, 4.33, mapOf("Refining" to 320.0, "CDU_Status" to 0.0)),
            Asset("a8", "Permian Delaware Well H1", AssetType.WELL, Region.AMERICAS, AssetStatus.OPERATIONAL, 96, 31.90, -103.50, mapOf("Pressure" to 2400.0, "Flow" to 1250.0)),
            Asset("a9", "Gorgon LNG", AssetType.WELL, Region.ASIA_PACIFIC, AssetStatus.OPERATIONAL, 94, -20.80, 115.40, mapOf("LNG_Output" to 15.6, "Injected_CO2" to 3.4)),
            Asset("a10", "Sleipner CCS Project", AssetType.CCS_PROJECT, Region.EUROPE, AssetStatus.OPERATIONAL, 98, 58.37, 1.90, mapOf("CO2_Injected" to 1.1, "Storage_P" to 3100.0)),
            Asset("a11", "Baytown Green H2 Plant", AssetType.HYDROGEN_PLANT, Region.AMERICAS, AssetStatus.OPERATIONAL, 90, 29.75, -95.03, mapOf("H2_Purity" to 99.99, "Output_Kg" to 12000.0)),
            Asset("a12", "Imperial Oil Strathcona H2", AssetType.HYDROGEN_PLANT, Region.AMERICAS, AssetStatus.OPERATIONAL, 92, 53.56, -113.37, mapOf("H2_Purity" to 99.95, "Output_Kg" to 8000.0)),
            Asset("a13", "Baffin Bay Lithium Brine", AssetType.LITHIUM_PROJECT, Region.AMERICAS, AssetStatus.OPERATIONAL, 87, 27.20, -97.40, mapOf("Brine_Flow" to 420.0, "Purity" to 99.5)),
            Asset("a14", "Singapore Petrochemical", AssetType.CHEMICAL_PLANT, Region.ASIA_PACIFIC, AssetStatus.OPERATIONAL, 91, 1.28, 103.72, mapOf("Ethylene" to 1900.0, "Polymers" to 820.0))
        )
        _assets.value = initialAssets

        // Initialize 12 wells
        val initialWells = (1..12).map { i ->
            val status = if (i == 4) AssetStatus.MAINTENANCE else if (i == 9) AssetStatus.WARNING else AssetStatus.OPERATIONAL
            val depth = 3500.0 + (i * 250)
            val traj = if (i % 3 == 0) "Horizontal" else if (i % 3 == 1) "Directional" else "Vertical"
            val flowScale = if (status == AssetStatus.OPERATIONAL) 1.0 else if (status == AssetStatus.WARNING) 0.4 else 0.0
            Well(
                id = "w$i",
                name = "Delaware-B30$i",
                parentFieldId = "Permian Delaware Basin Block $i",
                status = status,
                depth = depth,
                trajectory = traj,
                oilRate = (800.0 + i * 75) * flowScale,
                gasRate = (2.5 + i * 0.4) * flowScale,
                waterCut = (2.0 + i * 1.5),
                pressure = 2200.0 - (i * 50),
                temperature = 140.0 + (i * 5),
                trajectories = (0..5).map { step -> Point3D(step * 30f, step * (i * 2f), -step * 500f) }
            )
        }
        _wells.value = initialWells

        // Initialize 5 Refineries
        _refineries.value = listOf(
            Refinery("ref1", "Baton Rouge Refinery", Region.AMERICAS, AssetStatus.OPERATIONAL, 520.0, "WTI Light Sweet", listOf(
                RefineryUnit("u1", "Crude Distillation Unit", AssetStatus.OPERATIONAL, 520.0, 520.0, 680.0, 15.0, 0.12, 12.0),
                RefineryUnit("u2", "Fluid Catalytic Cracker", AssetStatus.OPERATIONAL, 140.0, 150.0, 980.0, 24.0, 0.22, 22.0),
                RefineryUnit("u3", "Hydrocracker & Hydrotreater", AssetStatus.OPERATIONAL, 90.0, 95.0, 800.0, 1200.0, 0.18, 15.0),
                RefineryUnit("u4", "Delayed Coker Unit", AssetStatus.OPERATIONAL, 60.0, 65.0, 910.0, 45.0, 0.25, 26.0)
            )),
            Refinery("ref2", "Baytown Refinery Complex", Region.AMERICAS, AssetStatus.OPERATIONAL, 560.0, "Heavy Sour Canadian", listOf(
                RefineryUnit("u5", "Crude Distillation Unit", AssetStatus.OPERATIONAL, 560.0, 560.0, 690.0, 16.0, 0.13, 13.0),
                RefineryUnit("u6", "Fluid Catalytic Cracker", AssetStatus.OPERATIONAL, 155.0, 160.0, 970.0, 25.0, 0.23, 23.0),
                RefineryUnit("u7", "Hydrocracker & Hydrotreater", AssetStatus.OPERATIONAL, 110.0, 110.0, 810.0, 1250.0, 0.19, 16.0),
                RefineryUnit("u8", "Delayed Coker Unit", AssetStatus.WARNING, 45.0, 70.0, 890.0, 40.0, 0.28, 29.0)
            )),
            Refinery("ref3", "Fawley Refinery UK", Region.EUROPE, AssetStatus.OPERATIONAL, 270.0, "Brent Crude", listOf(
                RefineryUnit("u9", "Crude Distillation Unit", AssetStatus.OPERATIONAL, 270.0, 270.0, 670.0, 14.0, 0.11, 11.0),
                RefineryUnit("u10", "Fluid Catalytic Cracker", AssetStatus.OPERATIONAL, 75.0, 80.0, 960.0, 22.0, 0.20, 20.0),
                RefineryUnit("u11", "Hydrocracker & Hydrotreater", AssetStatus.MAINTENANCE, 0.0, 50.0, 100.0, 50.0, 0.02, 2.0)
            )),
            Refinery("ref4", "Antwerp Refinery", Region.EUROPE, AssetStatus.MAINTENANCE, 320.0, "North Sea Heavy", listOf(
                RefineryUnit("u12", "Crude Distillation Unit", AssetStatus.MAINTENANCE, 180.0, 320.0, 420.0, 10.0, 0.08, 8.0),
                RefineryUnit("u13", "Fluid Catalytic Cracker", AssetStatus.OPERATIONAL, 85.0, 90.0, 950.0, 23.0, 0.21, 21.0)
            )),
            Refinery("ref5", "Jurong Island Singapore", Region.ASIA_PACIFIC, AssetStatus.OPERATIONAL, 600.0, "Middle East Light", listOf(
                RefineryUnit("u14", "Crude Distillation Unit", AssetStatus.OPERATIONAL, 600.0, 600.0, 695.0, 17.0, 0.12, 12.0),
                RefineryUnit("u15", "Fluid Catalytic Cracker", AssetStatus.OPERATIONAL, 170.0, 170.0, 990.0, 26.0, 0.22, 22.0),
                RefineryUnit("u16", "Hydrocracker & Hydrotreater", AssetStatus.OPERATIONAL, 120.0, 120.0, 820.0, 1300.0, 0.17, 14.0)
            ))
        )

        // Initialize 3 Chemical Plants
        _chemicalPlants.value = listOf(
            ChemicalPlant("chem1", "Baytown Olefins Plant", Region.AMERICAS, AssetStatus.OPERATIONAL, 2200.0, 1600.0, 800.0, 450.0, 250.0, 18.2, 830.0, 35.0),
            ChemicalPlant("chem2", "Singapore Chemical Site", Region.ASIA_PACIFIC, AssetStatus.OPERATIONAL, 2500.0, 1900.0, 1100.0, 620.0, 280.0, 21.5, 840.0, 36.5),
            ChemicalPlant("chem3", "Fawley Polymers", Region.EUROPE, AssetStatus.OPERATIONAL, 800.0, 500.0, 300.0, 150.0, 90.0, 7.4, 820.0, 33.0)
        )

        // Lubricants Product line
        _lubricants.value = listOf(
            LubricantProduct("Mobil 1 Advanced Fuel Economy", "Engine Oil", 168, " -40°F to 400°F", "API SP, ILSAC GF-6A", "10,000 Miles / 1 Year"),
            LubricantProduct("Mobil Delvac 1 ESP 5W-40", "Engine Oil", 155, "-30°F to 450°F", "API CK-4, CJ-4", "25,000 Miles / 1 Year Heavy Duty"),
            LubricantProduct("Mobil DTE 10 Excel 46", "Industrial Lubricant", 164, "-15°F to 350°F", "ISO VG 46, DIN 51524", "12,000 Operating Hours"),
            LubricantProduct("Mobil SHC Gear 150", "Industrial Lubricant", 160, "-35°F to 390°F", "AGMA 9005-E02", "3-Year Continuous Service"),
            LubricantProduct("Mobilgrease XHP 222", "Grease", 140, " -5°F to 284°F", "NLGI Grade 2", "Varies by bearing speed")
        )

        _lubricantDiagnostics.value = listOf(
            LubricantAnalysis("LA-9821", "Baton Rouge Gas Turbine T1", 44.5, 12, 0.05, 1.2, "NORMAL", "Lubricant properties within specifications. Continue normal operational interval."),
            LubricantAnalysis("LA-4029", "Delaware Drill Rig R3 Mud Pump", 39.8, 48, 0.65, 4.8, "MONITOR", "Increased wear metal ppm (Iron 48). Schedule inspection of physical seals in 14 days."),
            LubricantAnalysis("LA-1102", "Hebron Generator G2", 28.4, 95, 2.10, 12.5, "CRITICAL", "High soot contamination (2.10%) & drop in viscosity. Recommended immediate oil change & check rings.")
        )

        // Stations
        _stations.value = listOf(
            Station("s1", "Exxon Synergy - Downtown Houston", "1200 Louisiana St, Houston, TX", 29.756, -95.367, 2.95, 3.45, 3.25, listOf("FREE", "BUSY", "FREE", "BUSY", "FREE")),
            Station("s2", "Mobil Synergy - Dallas Central", "75201 N Central Expy, Dallas, TX", 32.780, -96.797, 2.91, 3.42, 3.20, listOf("BUSY", "BUSY", "FREE", "FREE")),
            Station("s3", "Exxon Synergy - Baton Rouge Hwy", "3000 Hwy 61, Baton Rouge, LA", 30.450, -91.140, 2.85, 3.35, 3.10, listOf("FREE", "FREE", "FREE", "FREE")),
            Station("s4", "Mobil Synergy - Baytown Local", "100 Decker Dr, Baytown, TX", 29.735, -95.010, 2.89, 3.39, 3.15, listOf("FREE", "BUSY", "BUSY", "OUT_OF_SERVICE"))
        )

        // Vehicles Garage
        _vehicles.value = listOf(
            Vehicle("v1", "Ford", "F-150 Lightning / EcoBoost", 2023, "3.5L V6 Twin-Turbo", 42350.0, 78, "35/35/35/35 PSI", "45,000 Miles (Oil & Filter)"),
            Vehicle("v2", "Chevrolet", "Tahoe RST", 2021, "5.3L V8", 68400.0, 22, "32/32/32/32 PSI", "70,000 Miles (Critical Lubricant Service)")
        )

        // Fuel logs
        _fuelLogs.value = listOf(
            FuelLog("f1", "Ford F-150", 72.5, 0.78, 42100.0, "Exxon downtown Houston", "2026-09-01", 18.5),
            FuelLog("f2", "Ford F-150", 68.2, 0.79, 42280.0, "Exxon Synergy Dallas", "2026-09-08", 19.1),
            FuelLog("f3", "Chevrolet Tahoe", 95.0, 0.76, 68100.0, "Mobil Hwy Baton Rouge", "2026-09-04", 14.8)
        )

        // CCS Projects
        _ccsProjects.value = listOf(
            CCSProject("ccs1", "Gulf Coast Carbon Point", AssetStatus.OPERATIONAL, Region.AMERICAS, 4.2, 4.1, 4.1, 12.0, 3100.0, 1420),
            CCSProject("ccs2", "Rotterdam Port CCS Porthos", AssetStatus.OPERATIONAL, Region.EUROPE, 2.5, 2.5, 2.5, 5.0, 2900.0, 850),
            CCSProject("ccs3", "Wyoming Shute Creek", AssetStatus.OPERATIONAL, Region.AMERICAS, 7.0, 7.0, 6.8, 15.0, 3400.0, 2100),
            CCSProject("ccs4", "Asia Pacific Carbon Sink", AssetStatus.MAINTENANCE, Region.ASIA_PACIFIC, 1.2, 1.2, 0.5, 8.0, 1200.0, 450)
        )

        // Hydrogen Projects
        _hydrogenProjects.value = listOf(
            HydrogenProject("h2_1", "Baytown Hydrogen Hub", AssetStatus.OPERATIONAL, Region.AMERICAS, "Blue", 250000.0, 242000.0, 99.98, 450.0, 12.5, 45.0, 1.50, 22.4),
            HydrogenProject("h2_2", "Rotterdam H2 Facility", AssetStatus.OPERATIONAL, Region.EUROPE, "Green", 120000.0, 115000.0, 99.99, 320.0, 8.4, 55.0, 1.20, 12.8),
            HydrogenProject("h2_3", "Alberta Low-Carbon H2", AssetStatus.OPERATIONAL, Region.AMERICAS, "Blue", 180000.0, 180000.0, 99.97, 290.0, 9.8, 40.0, 1.80, 24.5)
        )

        // Lithium
        _lithiumProjects.value = listOf(
            LithiumProject("li1", "Arkansas Brine DLE-1", AssetStatus.OPERATIONAL, Region.AMERICAS, "Brine (DLE)", 25000.0, 420.0, 92.5, 99.9),
            LithiumProject("li2", "South Arkansas Expansion", AssetStatus.MAINTENANCE, Region.AMERICAS, "Brine (DLE)", 15000.0, 380.0, 89.0, 99.8)
        )

        // Market Prices
        _markets.value = listOf(
            MarketInstrument("BRENT", "Brent Crude Oil", 78.45, 77.92, (0..20).map { 76.0 + sin(it * 0.3) * 2.0 }, listOf(78.45, 78.90, 79.50, 80.40, 81.80, 83.20)),
            MarketInstrument("WTI", "WTI Light Sweet Oil", 74.32, 73.85, (0..20).map { 72.0 + sin(it * 0.35) * 1.8 }, listOf(74.32, 74.75, 75.30, 76.10, 77.40, 78.90)),
            MarketInstrument("NAT_GAS", "Henry Hub Natural Gas", 2.65, 2.72, (0..20).map { 2.5 + sin(it * 0.4) * 0.3 }, listOf(2.65, 2.68, 2.74, 2.82, 2.95, 3.12)),
            MarketInstrument("LNG_ASIA", "JKM LNG Spot Price", 11.20, 11.05, (0..20).map { 10.5 + sin(it * 0.25) * 0.9 }, listOf(11.20, 11.35, 11.60, 11.95, 12.40, 13.10)),
            MarketInstrument("CARBON", "EU Carbon Allowance", 68.20, 68.90, (0..20).map { 65.0 + sin(it * 0.15) * 4.0 }, listOf(68.20, 68.50, 69.20, 70.80, 73.00, 76.50)),
            MarketInstrument("GASOLINE", "Synergy Unleaded (GULF)", 2.42, 2.45, (0..20).map { 2.3 + sin(it * 0.5) * 0.15 }, listOf(2.42, 2.44, 2.48, 2.54, 2.62, 2.75)),
            MarketInstrument("DIESEL", "Synergy Diesel (US GC)", 2.68, 2.62, (0..20).map { 2.5 + sin(it * 0.45) * 0.18 }, listOf(2.68, 2.70, 2.74, 2.80, 2.88, 3.02)),
            MarketInstrument("H2_BLUE", "Industrial Blue H2 (ex-Tax)", 1.85, 1.85, (0..20).map { 1.8 }, listOf(1.85, 1.85, 1.88, 1.90, 1.95, 2.05)),
            MarketInstrument("LITHIUM_LCE", "Battery-Grade Lithium Carbonate", 13200.0, 13150.0, (0..20).map { 12800.0 + sin(it * 0.1) * 300 }, listOf(13200.0, 13300.0, 13500.0, 13800.0, 14200.0, 14900.0))
        )

        // Trades Book
        _trades.value = listOf(
            Trade("t-11", "BRENT", "BUY", 100000, 78.10, "09:12:45", "EXECUTED"),
            Trade("t-12", "WTI", "SELL", 50000, 74.20, "09:20:12", "EXECUTED"),
            Trade("t-13", "NAT_GAS", "BUY", 250000, 2.66, "09:35:01", "EXECUTED")
        )

        // Active Incidents
        _incidents.value = listOf(
            Incident(
                "inc-1", "ASSET", "Delayed Coker Pressure Spike", "HIGH", "ACKNOWLEDGED", "07:30 UTC",
                "Sensors on Baytown delayed coker unit u8 recorded temporary pressure fluctuation beyond safe-operating envelope.",
                listOf(
                    IncidentTimelineEvent("DETECTED", "07:30 UTC", "Pressure rose to 58 psi (limit 50 psi). Automated bypass valve initiated."),
                    IncidentTimelineEvent("ACKNOWLEDGED", "07:45 UTC", "Refinery Control Room operator acknowledged. Pressure stabilized at 45 psi."),
                    IncidentTimelineEvent("INVESTIGATED", "08:15 UTC", "Mechanical seal on valve CV-112 flagged for replacement.")
                )
            ),
            Incident(
                "inc-2", "WEATHER", "North Sea Hurricane Advisory", "MEDIUM", "ACKNOWLEDGED", "09:00 UTC",
                "Weather monitoring reports high waves approaching Sleipner CCS & offshore grids. Restricting marine service transfers.",
                listOf(
                    IncidentTimelineEvent("DETECTED", "09:00 UTC", "Wind speeds exceeding 45 knots."),
                    IncidentTimelineEvent("ACKNOWLEDGED", "09:10 UTC", "Sleipner platform operations switch to remote automated monitoring status.")
                )
            )
        )

        // Permits to work
        _permits.value = listOf(
            WorkPermit("p-01", "Hot Work: Welder CV-112 Baytown DCU u8", "Baytown Refinery", "Hot Work", "APPROVED", "Arthur Pendelton", "Chief Operator J. Miller", "Replace worn flange welding seal on Delayed Coker Unit u8 to resolve pressure fluctuation.", listOf("Continuous methane detection sniffer on site", "Water spray lines charged and pre-positioned", "LOTO completed on line DCU-801")),
            WorkPermit("p-02", "Confined Space Entry: Tank T-402 Repair", "Fawley Terminal", "Confined Space", "REVIEW", "Sarah Connor", "Pending Operations lead", "Clean bottom sediment sludge from Fuel Storage Tank T-402.", listOf("Pre-entry air quality monitor O2 > 19.5%", "Continuous harness and winch line anchored", "Explosion-proof safety lighting exclusively used")),
            WorkPermit("p-03", "Cold Work: Singapore Reactor Catalyst Sample", "Singapore Chemical", "Cold Work", "DRAFT", "Lee Wei", "Not Submitted", "Retrieve core polymer sample from Singapore Polymer reactor reactor R1.", listOf("Full chemical splash suit required", "Bypass valves safety locked"))
        )

        // Suppliers
        _suppliers.value = listOf(
            ProcurementSupplier("sup1", "Sumitomo Heavy Piping", "Pipes & Tubing", 4.8, 12, 14, 5),
            ProcurementSupplier("sup2", "Baker Hughes Wells Corp", "Drill Bits", 4.7, 8, 8, 8),
            ProcurementSupplier("sup3", "Honeywell Control Systems", "IoT Hardware", 4.5, 24, 6, 12),
            ProcurementSupplier("sup4", "Air Liquide Gas Solutions", "Logistics", 4.6, 15, 10, 4)
        )

        // Shipments
        _shipments.value = listOf(
            Shipment("s_112", "Mobil Courage Tanker", "Crude Oil", 850000.0, "Guyana offshore Terminal", "Baton Rouge Refinery", "IN_TRANSIT", "Sep 18, 14:00", Pair(15.2, -75.4)),
            Shipment("s_115", "Synergy Energy Gas Carrier", "LNG", 450000.0, "Gorgon Terminal WA", "Jurong Island Terminal", "IN_TRANSIT", "Sep 15, 08:30", Pair(-5.2, 110.1)),
            Shipment("s_119", "Antwerp Feedstock Carrier", "Heavy Sour", 320000.0, "Rotterdam Tank farm", "Antwerp Refinery", "ON_HAND", "Arrived - Discharging", Pair(51.3, 4.2))
        )

        // Synthetic document indexes
        _documents.value = listOf(
            Document("doc-1", "Standard Operating Procedure: Delayed Coker Pressure Limits", "PROCEDURE", "v4.2", "Global Refinery Committee", "2024-03-12", "Defines mandatory alarm bounds, safe override sequences, and relief valves calibration cycles for heavy coking units.", mapOf("Max Pressure Limit" to "50 psi", "Relief Setting" to "55 psi", "Methane Purge Time" to "45 min")),
            Document("doc-2", "Baton Rouge Crude Unit CDU-1 Engineering Drawing", "DRAWING", "v12.0", "Bechtel EPC", "2021-11-10", "Full structural piping blueprint detailing cold crude intake, atmospheric fraction column, vacuum tower feeds, and reflux ratios.", mapOf("Core Column Temp" to "680 F", "Throughput Rating" to "520 kbpd", "Material Grade" to "ASME A106 Steel")),
            Document("doc-3", "ExxonMobil & Arkema Polymer Catalysis Agreement", "CONTRACT", "v1.5", "Corporate Legal Solutions", "2025-06-18", "Exclusive procurement and chemical properties licensing agreement for advanced metallocene catalyst supply utilized in Jurong Singapore site.", mapOf("Minimum Term" to "5 Years", "Confidentiality Tier" to "Tier 1 Proprietary", "Purity Standard" to "99.98%"))
        )

        // Hello message
        _aiMessages.value = listOf(
            AIMessage("AI", "ExxonMobil Energy OS loaded. Activating Exxon Energy Intelligence reasoning system. Ask me about highest energy refineries, deteriorated assets, capital IRR rankings, or global scenario propagation.")
        )
    }

    private fun startSimulation() {
        simJob?.cancel()
        simJob = viewModelScope.launch {
            while (true) {
                delay(4000)
                tickCount++
                runSimulationTick()
            }
        }
    }

    private fun runSimulationTick() {
        // Ticking logic: update slightly our metrics & market prices
        _markets.update { list ->
            list.map { m ->
                val change = Random.nextDouble(-0.1, 0.12)
                val newPrice = if (m.ticker == "LITHIUM_LCE") {
                    m.price + Random.nextInt(-20, 30)
                } else {
                    (m.price + change).coerceIn(1.0, 1000.0)
                }
                m.copy(
                    price = Math.round(newPrice * 100.0) / 100.0,
                    history1D = m.history1D.takeLast(19) + m.price
                )
            }
        }

        // Ticking asset sensor values
        _assets.update { list ->
            list.map { asset ->
                if (asset.status == AssetStatus.OPERATIONAL) {
                    val updatedTelem = asset.telemetry.mapValues { (key, value) ->
                        when (key) {
                            "Throughput" -> (value + Random.nextDouble(-1.5, 1.5)).coerceIn(20.0, 600.0)
                            "Pressure" -> (value + Random.nextDouble(-15.0, 15.0)).coerceIn(100.0, 5000.0)
                            "Flow" -> (value + Random.nextDouble(-10.0, 10.0)).coerceIn(50.0, 2000.0)
                            "Reactor_Pressure" -> (value + Random.nextDouble(-0.1, 0.1)).coerceIn(30.0, 40.0)
                            else -> value
                        }
                    }
                    asset.copy(
                        telemetry = updatedTelem,
                        healthScore = (asset.healthScore + Random.nextInt(-1, 2)).coerceIn(70, 100)
                    )
                } else {
                    asset
                }
            }
        }

        // Ticking wells
        _wells.update { list ->
            list.map { w ->
                if (w.status == AssetStatus.OPERATIONAL) {
                    w.copy(
                        oilRate = (w.oilRate + Random.nextDouble(-5.0, 5.0)).coerceIn(100.0, 5000.0),
                        pressure = (w.pressure + Random.nextDouble(-10.0, 10.0)).coerceIn(500.0, 4000.0),
                        temperature = (w.temperature + Random.nextDouble(-0.2, 0.2)).coerceIn(100.0, 200.0)
                    )
                } else {
                    w
                }
            }
        }

        // Ticking shipments coordinates
        _shipments.update { list ->
            list.map { s ->
                if (s.status == "IN_TRANSIT") {
                    val newLat = s.coordinates.first + Random.nextDouble(-0.02, 0.02)
                    val newLng = s.coordinates.second + Random.nextDouble(-0.02, 0.03)
                    s.copy(coordinates = Pair(newLat, newLng))
                } else {
                    s
                }
            }
        }

        // Simulated Pay at Pump auto-increase volume
        if (pumpStep.value == 4) {
            val nextProgress = fuelingVolumeProgress.value + 0.08f
            if (nextProgress >= 1f) {
                fuelingVolumeProgress.value = 1f
                pumpStep.value = 5 // Go to receipt
                // Record simulated transaction!
                val vol = 45.2 // Liters
                val price = selectedStationForPump.value?.regularPrice ?: 2.95
                val newLog = FuelLog(
                    id = UUID.randomUUID().toString(),
                    vehicleName = "Ford F-150 Lightning",
                    volume = vol,
                    pricePerLiter = price,
                    odometer = 42420.0 + Random.nextInt(50, 200),
                    stationName = selectedStationForPump.value?.name ?: "Exxon Synergy",
                    date = "2026-09-14",
                    calculatedMpg = 18.9
                )
                _fuelLogs.update { logs -> listOf(newLog) + logs }
            } else {
                fuelingVolumeProgress.value = nextProgress
            }
        }
    }

    fun executeTrade(ticker: String, type: String, quantity: Int, price: Double) {
        val newTrade = Trade(
            id = "t-${UUID.randomUUID().toString().take(6)}",
            ticker = ticker,
            type = type,
            quantity = quantity,
            price = price,
            timestamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()),
            status = "EXECUTED"
        )
        _trades.update { listOf(newTrade) + it }

        // Send confirmation to AI messages
        addMessage(AIMessage("AI", "Trade Order #$quantity bbls of $ticker executed at $$price successfully.", 0.99, listOf("Trader interaction"), listOf("P&L impact evaluated"), "Exxon Trading Core v2.2", null))
    }

    fun runScenario(scenario: String) {
        _currentScenarioName.value = scenario
        val brentPrice = _markets.value.find { it.ticker == "BRENT" }?.price ?: 78.45
        val wtiPrice = _markets.value.find { it.ticker == "WTI" }?.price ?: 74.32

        when (scenario) {
            "Oil Price Collapse" -> {
                _markets.update { list ->
                    list.map { m ->
                        if (m.ticker == "BRENT" || m.ticker == "WTI") {
                            m.copy(price = m.price * 0.70)
                        } else m
                    }
                }
                _assets.update { list ->
                    list.map { m ->
                        if (m.type == AssetType.WELL || m.type == AssetType.PLATFORM) {
                            m.copy(status = AssetStatus.WARNING, healthScore = m.healthScore - 10)
                        } else m
                    }
                }
                addMessage(AIMessage(
                    "AI",
                    "SCENARIO IMPACT DETECTED: Brent Crude collapsed by 30%. Financial projections show Upstream cash flow decreasing by $14.2M/day. Recommending capital allocation scaleback on Delaware Basin blocks.",
                    0.94,
                    listOf("Global demand shock", "Crude inventory surplus"),
                    listOf("Brent Price: -30%", "Upstream EBITDA: -22%"),
                    "Exxon scenario engine v1.4",
                    listOf("Base OPEC supply remains constant", "Refining capacity limits active")
                ))
            }
            "Henry Hub Gas Spike" -> {
                _markets.update { list ->
                    list.map { m ->
                        if (m.ticker == "NAT_GAS") {
                            m.copy(price = m.price * 1.5)
                        } else m
                    }
                }
                addMessage(AIMessage(
                    "AI",
                    "SCENARIO IMPACT: Henry Hub Natural Gas spiked by 50%. Blue Hydrogen costs rising from $1.85 to $2.24 per kg. Refining power utility costs elevated by 14%. Power generation margins favorable.",
                    0.96,
                    listOf("Regional freeze", "Infrastructure strain"),
                    listOf("Nat Gas: +50%", "Refinery utilities: +14%"),
                    "Exxon scenario engine v1.4",
                    listOf("Power generation efficiency 42%")
                ))
            }
            "Offshore Platform Hurricane" -> {
                _assets.update { list ->
                    list.map { m ->
                        if (m.name.contains("Hebron") || m.name.contains("Destiny")) {
                            m.copy(status = AssetStatus.OFFLINE, healthScore = 65)
                        } else m
                    }
                }
                val newIncident = Incident(
                    "inc-${UUID.randomUUID().toString().take(6)}",
                    "WEATHER", "Hurricane Gulf / East Coast Evacuation", "CRITICAL", "DETECTED", "12:15 UTC",
                    "Pre-emptive remote shutdown of offshore operations due to severe Category 4 storm advisories.",
                    listOf(IncidentTimelineEvent("DETECTED", "12:15 UTC", "Automated remote valves closed on Hebron & Destiny."))
                )
                _incidents.update { listOf(newIncident) + it }
                addMessage(AIMessage(
                    "AI",
                    "CRITICAL IMPACT: Hebron & Destiny offline. Global offshore production capacity reduced by 195,000 bbl/day. Supply chains rerouting shipments from Gulf terminal to Atlantic docks.",
                    0.98,
                    listOf("Weather escalation", "Offshore evacuations"),
                    listOf("Hebron Platform: OFFLINE", "Destiny FPSO: OFFLINE", "Incident logged"),
                    "Exxon Safety Automator v3.0",
                    listOf("Safety first priority")
                ))
            }
            "Refinery Outage" -> {
                _refineries.update { list ->
                    list.map { r ->
                        if (r.id == "ref2") {
                            r.copy(status = AssetStatus.OFFLINE, units = r.units.map { u ->
                                if (u.name.contains("Crude")) u.copy(status = AssetStatus.OFFLINE, throughput = 0.0) else u
                            })
                        } else r
                    }
                }
                addMessage(AIMessage(
                    "AI",
                    "SCENARIO ALERT: Baytown Refinery CDU shut down unexpectedly. Fuels inventory allocating dynamically. Diesel and Gasoline pricing spread widening.",
                    0.92,
                    listOf("Refinery equipment mechanical fail"),
                    listOf("Baytown CDU: OFFLINE", "Allocated state triggered"),
                    "Refinery Twin Solver v1.1",
                    listOf("Demand profile unchanged")
                ))
            }
        }
    }

    fun resetScenario() {
        _currentScenarioName.value = "Baseline Global Operations"
        initializeSyntheticData()
    }

    fun setRole(role: UserRole) {
        _activeRole.value = role
        _activeTab.value = role.focusTab
    }

    fun setTab(tab: String) {
        _activeTab.value = tab
    }

    fun setTimeMachine(time: String) {
        _timeMachine.value = time
        // Adjust prices and metrics based on time to simulate "replaying"
        val scale = when (time) {
            "1H_AGO" -> 0.99
            "1D_AGO" -> 0.97
            "1W_AGO" -> 1.03
            "1M_AGO" -> 0.94
            else -> 1.0
        }
        _markets.update { list ->
            list.map { m ->
                m.copy(price = Math.round(m.price * scale * 100.0) / 100.0)
            }
        }
        _assets.update { list ->
            list.map { a ->
                a.copy(healthScore = (a.healthScore - (scale * 2).toInt()).coerceIn(70, 100))
            }
        }
    }

    fun selectAsset(asset: Asset?) {
        _selectedAsset.value = asset
    }

    fun selectWell(well: Well?) {
        _selectedWell.value = well
    }

    fun selectRefinery(refinery: Refinery?) {
        _selectedRefinery.value = refinery
    }

    fun selectChemicalPlant(plant: ChemicalPlant?) {
        _selectedChemicalPlant.value = plant
    }

    fun submitWorkPermit(permit: WorkPermit) {
        _permits.update { current ->
            current.map { p -> if (p.id == permit.id) permit else p }
        }
    }

    fun addWorkPermit(permit: WorkPermit) {
        _permits.update { current -> listOf(permit) + current }
    }

    fun addMessage(message: AIMessage) {
        _aiMessages.update { it + message }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun askAI(question: String) {
        _aiMessages.update { it + AIMessage("USER", question) }

        viewModelScope.launch {
            delay(1500) // Realistic delay

            val normQ = question.lowercase()
            val answer = when {
                normQ.contains("highest energy") || normQ.contains("energy intensity") -> {
                    val highest = _refineries.value.flatMap { r -> r.units.map { u -> Pair(r, u) } }
                        .maxByOrNull { it.second.energyIntensity }
                    if (highest != null) {
                        AIMessage(
                            sender = "AI",
                            text = "My analysis indicates that **${highest.first.name}**'s **${highest.second.name}** has the highest energy intensity in our assets grid at **${highest.second.energyIntensity} MBtu/bbl**.",
                            confidence = 0.98,
                            drivers = listOf("Mechanical design age of atmospheric column u2", "High vacuum pressure friction coefficients"),
                            evidence = listOf("Telemetry CDU_Stream_Energy: ${highest.second.energyIntensity} MBtu/bbl", "Steam usage feed: 450 lbs/hr"),
                            model = "Refinery Optimizer v2.4",
                            assumptions = listOf("Baseline crude API gravity of 32°", "Fuel gas calorific value 1020 Btu/scf")
                        )
                    } else {
                        AIMessage("AI", "Unable to analyze refinery units. Telemetry down.")
                    }
                }
                normQ.contains("deteriorated") || normQ.contains("health") || normQ.contains("degraded") -> {
                    val badAssets = _assets.value.filter { it.healthScore < 85 }
                    val assetListStr = badAssets.joinToString(", ") { "${it.name} (Health: ${it.healthScore}%)" }
                    AIMessage(
                        sender = "AI",
                        text = "I have detected **${badAssets.size} assets** with deteriorating health scores below 85%: **$assetListStr**. The primary driver is mechanical component age and sensor alarm indicators.",
                        confidence = 0.94,
                        drivers = listOf("High vibration trend on Sleipner compressors", "Baton Rouge delayed coker pressure fluctuation"),
                        evidence = listOf("Baytown coker incident (inc-1)", "Hebron platform water cut: 14.2%"),
                        model = "Predictive Maintenance Engine v3.1",
                        assumptions = listOf("Normal vibration threshold is < 4.2 mm/s", "Inspections scheduled on priority metrics")
                    )
                }
                normQ.contains("irr") || normQ.contains("highest-return") || normQ.contains("capex") -> {
                    AIMessage(
                        sender = "AI",
                        text = "Our capital projects IRR rankings are completed:\n\n" +
                                "1. **Delaware Basin Brine Lithium DLE-1**: Estimated **IRR: 32.4%**, NPV: $450M, CAPEX: $250M.\n" +
                                "2. **Baytown Green H2 Electrolyser Phase A**: Estimated **IRR: 24.5%**, NPV: $310M.\n" +
                                "3. **Gulf Coast Point Carbon Capture**: Estimated **IRR: 18.2%**, NPV: $190M.\n\n" +
                                "Lithium extraction maintains the highest margins due to projected battery material constraints.",
                        confidence = 0.95,
                        drivers = listOf("Arkansas Smackover brine depth advantages", "Dynamic low-carbon subsidies in effect"),
                        evidence = listOf("Project Portfolio DB sheets", "Lithium LCE Market spot: $13,200/tonne"),
                        model = "Capital allocation solver v4.0",
                        assumptions = listOf("Electricity cost at $45/MWh for green H2", "Tax credit of $85/tonne CO2 captured")
                    )
                }
                normQ.contains("brent falls 20") || normQ.contains("brent falls") || normQ.contains("oil crash") -> {
                    val currentBrent = _markets.value.find { m -> m.ticker == "BRENT" }?.price ?: 78.0
                    val crashBrent = currentBrent * 0.8
                    AIMessage(
                        sender = "AI",
                        text = "If Brent falls 20% to **$${String.format("%.2f", crashBrent)}/bbl**:\n\n" +
                                "- **Upstream Operations**: Free Cash Flow declines by **$9.5M/day**. 4 drilling trajectories in Permian block Delaware B will drop below economic thresholds.\n" +
                                "- **Product Solutions**: Refinery margins temporarily expand by $1.80/bbl due to cheaper feedstock costs.\n" +
                                "- **Capital Allocation**: IRR for planned exploration blocks in the Gulf decreases from 16.5% to 11.2%. Direct recommendation to delay capital approvals on block a12.",
                        confidence = 0.89,
                        drivers = listOf("Crude demand decay", "OPEC supply headroom expansion"),
                        evidence = listOf("Brent Current: $78.45/bbl", "Exploration NPV sensitivity matrix"),
                        model = "Financial scenario simulator v2.9",
                        assumptions = listOf("Inflation index remains static at 2.4%", "WTI-Brent spread remains tight at $4.10")
                    )
                }
                normQ.contains("ccs") || normQ.contains("carbon capture") -> {
                    val totalCaptured = _ccsProjects.value.sumOf { it.co2Captured }
                    AIMessage(
                        sender = "AI",
                        text = "Global CCS projects summary: We currently capture **${String.format("%.1f", totalCaptured)} mtpa CO2** across 4 major facilities. **Wyoming Shute Creek** is our largest active capture site capturing 7.0 mtpa.",
                        confidence = 0.99,
                        drivers = listOf("Amine absorption plant efficiency: 91.5%", "High reservoir containment sealing index"),
                        evidence = listOf("CCS site registries", "Flow meter measurements on Shute Creek pipelines"),
                        model = "Low Carbon Monitor v1.2",
                        assumptions = listOf("Continuous gas measurement integrity remains above 99%")
                    )
                }
                normQ.contains("bottleneck") || normQ.contains("supply") || normQ.contains("shipment") -> {
                    AIMessage(
                        sender = "AI",
                        text = "Logistics bottleneck detected: **Mobil Courage Tanker** transiting through the Gulf shows a 1.5-day schedule variance due to marine storm conditions. Fawley terminal reports a brief fuel storage truck queue backlog.",
                        confidence = 0.91,
                        drivers = listOf("Hurricane advisory inc-2 waves > 4.5m", "Baton Rouge crude unit CDU-1 scheduling variance"),
                        evidence = listOf("AIS vessel telemetry tracking", "Supply Chain Control Tower queue timers"),
                        model = "Global Supply Chain Solver v2.0",
                        assumptions = listOf("Docks maintain 24/7 offloading capability")
                    )
                }
                else -> {
                    AIMessage(
                        sender = "AI",
                        text = "I have processed your query based on current global operations telemetry. The enterprise network is performing within baseline parameters, with high production integrity.",
                        confidence = 0.85,
                        drivers = listOf("General telemetry sweep"),
                        evidence = listOf("14 master assets analyzed", "9 pricing indexes active"),
                        model = "General Intelligence v3.5",
                        assumptions = listOf("System is in nominal state")
                    )
                }
            }
            _aiMessages.value = _aiMessages.value + answer
        }
    }
}
