package com.example.data

import java.util.UUID

enum class AssetType {
    PLATFORM, FPSO, REFINERY, CHEMICAL_PLANT, CCS_PROJECT, HYDROGEN_PLANT, LITHIUM_PROJECT, STATION, WELL, OIL_FIELD, GAS_FIELD, DISTRIBUTION_CENTER, STORAGE_FACILITY
}

enum class Region {
    AMERICAS, EUROPE, MIDDLE_EAST, AFRICA, ASIA_PACIFIC
}

enum class AssetStatus {
    OPERATIONAL, MAINTENANCE, WARNING, OFFLINE
}

data class Point3D(val x: Float, val y: Float, val z: Float)

data class Asset(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: AssetType,
    val region: Region,
    val status: AssetStatus,
    val healthScore: Int,
    val latitude: Double,
    val longitude: Double,
    val telemetry: Map<String, Double> = emptyMap()
)

data class Well(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val parentFieldId: String,
    val status: AssetStatus,
    val depth: Double, // in meters
    val trajectory: String, // "Vertical", "Directional", "Horizontal"
    val oilRate: Double, // bbl/day
    val gasRate: Double, // mmscf/day
    val waterCut: Double, // percentage
    val pressure: Double, // psi
    val temperature: Double, // Fahrenheit
    val trajectories: List<Point3D> = emptyList()
)

data class RefineryUnit(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val status: AssetStatus,
    val throughput: Double, // kbpd (thousand barrels per day)
    val capacity: Double,
    val temperature: Double, // F
    val pressure: Double, // psi
    val energyIntensity: Double, // MBtu/bbl
    val carbonIntensity: Double // kg CO2/bbl
)

data class Refinery(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val region: Region,
    val status: AssetStatus,
    val baseCapacity: Double, // kbpd
    val crudeFeedstock: String, // "Brent Crude", "WTI Crude", "Heavy Sour"
    val units: List<RefineryUnit>
)

data class ChemicalPlant(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val region: Region,
    val status: AssetStatus,
    val baseCapacity: Double, // thousand tonnes/yr
    val outputEthylene: Double,
    val outputPolyethylene: Double,
    val outputPolypropylene: Double,
    val feedstockFeedRate: Double, // tons/hr
    val energyUsage: Double, // MWh/hr
    val reactorTemp: Double, // C
    val reactorPressure: Double // bar
)

data class LubricantProduct(
    val name: String,
    val category: String, // "Engine Oil", "Industrial Lubricant", "Grease", etc.
    val viscosityIdx: Int,
    val tempRange: String,
    val performanceLevel: String,
    val recommendedInterval: String
)

data class LubricantAnalysis(
    val sampleId: String,
    val vehicleId: String,
    val viscosityCSt: Double,
    val wearMetalsPpm: Int, // iron/copper parts per million
    val contaminationPct: Double,
    val oxidationPct: Double,
    val status: String, // "NORMAL", "MONITOR", "CRITICAL"
    val recommendation: String
)

data class Station(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val regularPrice: Double,
    val supremePrice: Double,
    val dieselPrice: Double,
    val pumpStates: List<String> // "FREE", "BUSY", "OUT_OF_SERVICE"
)

data class FuelLog(
    val id: String = UUID.randomUUID().toString(),
    val vehicleName: String,
    val volume: Double, // liters
    val pricePerLiter: Double,
    val odometer: Double, // km
    val stationName: String,
    val date: String,
    val calculatedMpg: Double
)

data class Vehicle(
    val id: String = UUID.randomUUID().toString(),
    val make: String,
    val model: String,
    val year: Int,
    val engine: String,
    val mileage: Double,
    val oilHealth: Int, // %
    val tirePressure: String, // "32/32/32/32 PSI"
    val nextService: String
)

data class CCSProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val status: AssetStatus,
    val region: Region,
    val co2Captured: Double, // mtpa (million tonnes per annum)
    val co2Transported: Double,
    val co2Injected: Double,
    val storageCapacity: Double, // mtpa
    val injectionPressure: Double, // psi
    val activeMonitoringSensors: Int
)

data class HydrogenProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val status: AssetStatus,
    val region: Region,
    val type: String, // "Green" (electrolysis), "Blue" (SMR + CCS), "Gray" (SMR)
    val capacityKgDay: Double,
    val currentProductionKgDay: Double,
    val electrolyserPurity: Double, // %
    val capexM: Double,
    val opexM: Double,
    val powerCostMwh: Double,
    val waterCostM3: Double,
    val marginPercent: Double
)

data class LithiumProject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val status: AssetStatus,
    val region: Region,
    val resourceType: String, // "Brine (DLE)", "Hard Rock"
    val extractionRateTpa: Double, // tonnes per annum LCE
    val concentrationMgL: Double,
    val recoveryEfficiencyPct: Double,
    val productPurityPct: Double
)

data class MarketInstrument(
    val ticker: String,
    val name: String,
    val price: Double,
    val prevClose: Double,
    val history1D: List<Double>,
    val forwardCurve: List<Double> // spot, 1M, 3M, 6M, 12M, 24M
)

data class Trade(
    val id: String = UUID.randomUUID().toString(),
    val ticker: String,
    val type: String, // "BUY", "SELL"
    val quantity: Int, // bbl or mmbtu
    val price: Double,
    val timestamp: String,
    val status: String // "EXECUTED"
)

data class Incident(
    val id: String = UUID.randomUUID().toString(),
    val type: String, // "SAFETY", "ASSET", "PRODUCTION", "ENVIRONMENT", "CYBER", "SUPPLY_CHAIN", "WEATHER", "MARKET"
    val name: String,
    val severity: String, // "CRITICAL", "HIGH", "MEDIUM", "LOW"
    val status: String, // "DETECTED", "ACKNOWLEDGED", "INVESTIGATED", "CONTAINED", "RESOLVED"
    val timestamp: String,
    val description: String,
    val timeline: List<IncidentTimelineEvent> = emptyList()
)

data class IncidentTimelineEvent(
    val status: String,
    val timestamp: String,
    val description: String
)

data class WorkPermit(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val site: String,
    val type: String, // "Hot Work", "Confined Space", "Cold Work", "Electrical Isolation"
    val status: String, // "DRAFT", "SUBMITTED", "REVIEW", "APPROVED", "ACTIVE", "SUSPENDED", "CLOSED"
    val author: String,
    val approvedBy: String,
    val description: String,
    val safetyMeasures: List<String>
)

data class ProcurementSupplier(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String, // "Pipes & Tubing", "Drill Bits", "Catalysts", "Logistics", "IoT Hardware"
    val rating: Double, // 1.0 - 5.0
    val activeOrders: Int,
    val leadTimeDays: Int,
    val riskScore: Int // %
)

data class Shipment(
    val id: String = UUID.randomUUID().toString(),
    val vesselName: String,
    val cargoType: String, // "Crude Oil", "LNG", "Ethylene", "Diesel"
    val quantityBbls: Double,
    val origin: String,
    val destination: String,
    val status: String, // "ON_HAND", "IN_TRANSIT", "ALLOCATED", "RESERVED", "AVAILABLE", "QUARANTINED"
    val eta: String,
    val coordinates: Pair<Double, Double>
)

data class Document(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val type: String, // "MANUAL", "DRAWING", "CONTRACT", "REPORT", "PROCEDURE"
    val version: String,
    val author: String,
    val date: String,
    val summary: String,
    val extracts: Map<String, String> // e.g. "Pressure Rating" -> "3000 psi"
)

data class ExecutiveMetric(
    val name: String,
    val value: String,
    val unit: String,
    val timestamp: String,
    val source: String,
    val confidence: Double,
    val period: String,
    val comparison: String // e.g. "+2.4% vs Q2"
)
