package com.example

import com.example.data.local.DefaultDemonstrationData
import com.example.data.model.PowertrainType
import com.example.data.model.VehicleCapability
import org.junit.Assert.*
import org.junit.Test

class VehicleCapabilityTest {

    @Test
    fun testSilveradoCombustionCapabilities() {
        val vehicles = DefaultDemonstrationData.getInitialVehicles()
        val silverado = vehicles.first { it.id == DefaultDemonstrationData.ID_SILVERADO }

        assertEquals(PowertrainType.ICE_PETROL, silverado.powertrainType)
        val caps = silverado.getCapabilities()

        assertTrue("Silverado must support Remote Lock", caps.contains(VehicleCapability.REMOTE_LOCK))
        assertTrue("Silverado must support Remote Start", caps.contains(VehicleCapability.REMOTE_START))
        assertTrue("Silverado must support Fuel Monitoring", caps.contains(VehicleCapability.FUEL_MONITOR))
        assertFalse("Silverado must NOT support EV Charging Management", caps.contains(VehicleCapability.CHARGING_MANAGEMENT))
        assertFalse("Silverado must NOT support EV Charging Schedule", caps.contains(VehicleCapability.CHARGING_SCHEDULE))
    }

    @Test
    fun testBlazerEvCapabilities() {
        val vehicles = DefaultDemonstrationData.getInitialVehicles()
        val blazerEv = vehicles.first { it.id == DefaultDemonstrationData.ID_BLAZER_EV }

        assertEquals(PowertrainType.EV, blazerEv.powertrainType)
        val caps = blazerEv.getCapabilities()

        assertTrue("Blazer EV must support Charging Management", caps.contains(VehicleCapability.CHARGING_MANAGEMENT))
        assertTrue("Blazer EV must support Battery SoC Monitoring", caps.contains(VehicleCapability.BATTERY_SOC_MONITOR))
        assertTrue("Blazer EV must support Remote Lock", caps.contains(VehicleCapability.REMOTE_LOCK))
        assertFalse("Blazer EV must NOT support Fuel Tank Monitor", caps.contains(VehicleCapability.FUEL_MONITOR))
    }

    @Test
    fun testVinMasking() {
        val vehicles = DefaultDemonstrationData.getInitialVehicles()
        val silverado = vehicles.first { it.id == DefaultDemonstrationData.ID_SILVERADO }

        val masked = silverado.getMaskedVin()
        assertTrue("Masked VIN must start with first 3 characters", masked.startsWith("1GC"))
        assertTrue("Masked VIN must end with last 4 characters", masked.endsWith("2841"))
        assertTrue("Masked VIN must hide middle characters", masked.contains("••••••••••"))
    }
}
