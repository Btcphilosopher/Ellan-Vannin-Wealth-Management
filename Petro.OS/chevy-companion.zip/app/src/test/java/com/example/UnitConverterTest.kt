package com.example

import com.example.data.model.*
import com.example.domain.UnitConverter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UnitConverterTest {

    @Test
    fun testDistanceConversion() {
        val miles = 100.0
        val miString = UnitConverter.formatDistance(miles, DistanceUnit.MILES)
        val kmString = UnitConverter.formatDistance(miles, DistanceUnit.KILOMETERS)

        assertEquals("100.0 mi", miString)
        assertEquals("160.9 km", kmString)
    }

    @Test
    fun testTemperatureConversion() {
        val fahrenheit = 68
        val fString = UnitConverter.formatTemperature(fahrenheit, TemperatureUnit.FAHRENHEIT)
        val cString = UnitConverter.formatTemperature(fahrenheit, TemperatureUnit.CELSIUS)

        assertEquals("68°F", fString)
        assertEquals("20°C", cString)
    }

    @Test
    fun testPressureConversion() {
        val psi = 35.0
        val psiString = UnitConverter.formatPressure(psi, PressureUnit.PSI)
        val barString = UnitConverter.formatPressure(psi, PressureUnit.BAR)
        val kpaString = UnitConverter.formatPressure(psi, PressureUnit.KPA)

        assertEquals("35.0 psi", psiString)
        assertEquals("2.41 bar", barString)
        assertEquals("241 kPa", kpaString)
    }

    @Test
    fun testCurrencyFormatting() {
        val amount = 42.50
        val usd = UnitConverter.formatCurrency(amount, CurrencyUnit.USD)
        val gbp = UnitConverter.formatCurrency(amount, CurrencyUnit.GBP)

        assertEquals("$42.50", usd)
        assertEquals("£42.50", gbp)
    }

    @Test
    fun testFuelEconomyFormatting() {
        val mpg = 20.0
        val us = UnitConverter.formatFuelEconomy(mpg, FuelEconomyUnit.MPG_US)
        val l100km = UnitConverter.formatFuelEconomy(mpg, FuelEconomyUnit.L_100KM)

        assertEquals("20.0 mpg (US)", us)
        assertTrue(l100km.contains("11.8 L/100km"))
    }
}
