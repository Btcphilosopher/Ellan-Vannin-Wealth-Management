package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ChevyCompanionDatabase
import com.example.data.local.DefaultDemonstrationData
import com.example.data.model.CommandState
import com.example.data.model.CommandType
import com.example.network.VehicleSimulator
import com.example.security.KeystoreSecurityManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var database: ChevyCompanionDatabase
    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, ChevyCompanionDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun testAppNameString() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Chevy Companion", appName)
    }

    @Test
    fun testDemonstrationDataPopulationAndQuery() = runBlocking {
        val simulator = VehicleSimulator(database)
        simulator.initializeDefaultDataIfEmpty()

        val vehicles = database.vehicleDao().getAllVehicles().first()
        assertEquals(3, vehicles.size)

        val silverado = database.vehicleDao().getVehicleDirect(DefaultDemonstrationData.ID_SILVERADO)
        assertNotNull(silverado)
        assertEquals("Silverado 1500", silverado?.model)

        val telemetry = database.telemetryDao().getTelemetryDirect(DefaultDemonstrationData.ID_SILVERADO)
        assertNotNull(telemetry)
        assertTrue(telemetry!!.isLocked)
    }

    @Test
    fun testKeystoreSecurityPinVerification() {
        val secManager = KeystoreSecurityManager(context)
        assertTrue("Founding year PIN 1911 must verify", secManager.verifyAuthorizationPin("1911"))
        assertFalse("Arbitrary PIN must fail", secManager.verifyAuthorizationPin("0000"))
    }
}
