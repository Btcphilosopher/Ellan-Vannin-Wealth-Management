package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "service_records")
data class ServiceRecord(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val dateMs: Long,
    val odometerMiles: Double,
    val serviceCategory: String, // Scheduled, Oil & Filter, Tyres, Brakes, Battery/EV, Warranty
    val description: String,
    val serviceCenter: String,
    val costUsd: Double,
    val receiptNote: String = "",
    val isDemonstration: Boolean = true
)

@Entity(tableName = "maintenance_reminders")
data class MaintenanceReminder(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val title: String,
    val dueDateMs: Long,
    val dueMileage: Double,
    val isCompleted: Boolean = false,
    val urgencyLevel: String, // Normal, Due Soon, Overdue
    val description: String
)

data class DealerWorkshop(
    val id: String,
    val name: String,
    val address: String,
    val phone: String,
    val distanceMiles: Double,
    val isCertifiedChevy: Boolean = true,
    val offersEvService: Boolean = true
)
