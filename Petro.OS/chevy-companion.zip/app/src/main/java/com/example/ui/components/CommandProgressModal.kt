package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.CommandState
import com.example.data.model.RemoteCommand
import com.example.ui.theme.*

@Composable
fun CommandProgressModal(
    command: RemoteCommand,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("command_progress_modal"),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.outline),
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Text(
                    text = "COMMAND IN PROGRESS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    ),
                    color = ChevyGoldBright
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = command.getDisplayName(),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Status Animation or Result Icon
                when (command.state) {
                    CommandState.PENDING, CommandState.ACCEPTED -> {
                        val infiniteTransition = rememberInfiniteTransition(label = "spinner")
                        val rotation by infiniteTransition.animateFloat(
                            initialValue = 0f,
                            targetValue = 360f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1200, easing = LinearEasing)
                            ),
                            label = "rotation"
                        )
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(ChevyGoldContainerDark, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier
                                    .size(54.dp)
                                    .rotate(rotation),
                                color = ChevyGoldBright,
                                strokeWidth = 3.dp
                            )
                        }
                    }
                    CommandState.CONFIRMED -> {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(StatusGreenContainer.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Confirmed",
                                tint = StatusGreen,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }
                    CommandState.FAILED, CommandState.EXPIRED -> {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .background(StatusRedContainer.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = "Failed",
                                tint = StatusRed,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Progress Step Indicators
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StepItem(
                        label = "1. Dispatch",
                        isCompleted = command.state != CommandState.PENDING,
                        isActive = command.state == CommandState.PENDING
                    )
                    Divider(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        color = MaterialTheme.colorScheme.outline
                    )
                    StepItem(
                        label = "2. Handshake",
                        isCompleted = command.state == CommandState.CONFIRMED || command.state == CommandState.FAILED,
                        isActive = command.state == CommandState.ACCEPTED
                    )
                    Divider(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp),
                        color = MaterialTheme.colorScheme.outline
                    )
                    StepItem(
                        label = "3. Confirm",
                        isCompleted = command.state == CommandState.CONFIRMED,
                        isFailed = command.state == CommandState.FAILED || command.state == CommandState.EXPIRED,
                        isActive = false
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Description text
                val statusMessage = when (command.state) {
                    CommandState.PENDING -> "Encrypting command and transmitting to Chevrolet OnStar Gateway..."
                    CommandState.ACCEPTED -> "Vehicle modem acknowledged packet. Executing vehicle precondition check..."
                    CommandState.CONFIRMED -> "Vehicle actuator confirmed success. Telemetry snapshot updated."
                    CommandState.FAILED -> command.failureReason ?: "Command failed. Precondition not met."
                    CommandState.EXPIRED -> "Request timed out waiting for vehicle response."
                }

                Text(
                    text = statusMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (command.state == CommandState.FAILED) StatusRed else MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Token & ID info for auditability
                Text(
                    text = "ID: ${command.commandId.take(12)}... • Token: ${command.clientToken.take(8)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("dismiss_modal_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (command.state == CommandState.CONFIRMED) ChevyGoldBright else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (command.state == CommandState.CONFIRMED) ChevyOnyx else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Text(
                        text = if (command.state == CommandState.PENDING || command.state == CommandState.ACCEPTED) "Run in Background" else "Close",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun StepItem(
    label: String,
    isCompleted: Boolean,
    isActive: Boolean = false,
    isFailed: Boolean = false
) {
    val tint = when {
        isFailed -> StatusRed
        isCompleted -> StatusGreen
        isActive -> ChevyGoldBright
        else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .background(tint, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (isCompleted && !isFailed) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(10.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = tint,
            fontWeight = if (isActive || isCompleted) FontWeight.Bold else FontWeight.Normal
        )
    }
}
