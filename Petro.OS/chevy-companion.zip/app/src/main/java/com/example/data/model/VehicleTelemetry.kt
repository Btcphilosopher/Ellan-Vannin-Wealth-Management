package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AlertSeverity {
    INFO,
    WARNING,
    CRITICAL
}

data class VehicleAlert(
    val id: String,
    val title: String,
    val plainEnglishExplanation: String,
    val severity: AlertSeverity,
    val timestampMs: Long,
    val isDemonstration: Boolean = true
)

@Entity(tableName = "vehicle_telemetry")
data class VehicleTelemetry(
    @PrimaryKey val vehicleId: String,
    val lastUpdatedEpochMs: Long,
    val connectionState: ConnectionState = ConnectionState.SIMULATED,
    val isStale: Boolean = false,
    
    // Fuel & Range
    val fuelLevelPercent: Float = 68f, // 0..100
    val batterySocPercent: Float = 82f, // 0..100
    val estimatedRangeMiles: Double = 345.0,
    
    // Doors, Windows & Security
    val isLocked: Boolean = true,
    val areDoorsClosed: Boolean = true,
    val areWindowsClosed: Boolean = true,
    val isRemoteStarted: Boolean = false,
    
    // Climate & Preconditioning
    val cabinTempF: Int = 70,
    val targetTempF: Int = 72,
    val isPreconditioning: Boolean = false,
    
    // EV Charging
    val isCharging: Boolean = false,
    val isPluggedIn: Boolean = false,
    val chargingPowerKw: Double = 0.0,
    val chargingTargetPercent: Int = 80,
    val departureScheduleTime: String = "07:30 AM",
    val departureScheduleEnabled: Boolean = false,
    
    // Tyres
    val tyrePressureFrontLeftPsi: Double = 35.0,
    val tyrePressureFrontRightPsi: Double = 35.0,
    val tyrePressureRearLeftPsi: Double = 35.0,
    val tyrePressureRearRightPsi: Double = 35.0,
    val hasLowTyreAlert: Boolean = false,
    
    // Parking & Location
    val lastParkedLatitude: Double = 42.3314, // Detroit GM Renaissance Center area
    val lastParkedLongitude: Double = -83.0458,
    val lastParkedAddress: String = "GM Plaza, Detroit, MI 48243",
    val lastParkedTimestampMs: Long = System.currentTimeMillis() - 3600000L,
    val parkingNotes: String = "Level 3, Space 42B near north elevators",
    val parkingPhotoUri: String? = null,
    
    // Service
    val nextServiceDateMs: Long = System.currentTimeMillis() + 86400000L * 45, // 45 days
    val nextServiceMiles: Double = 30000.0,
    val activeAlertsJson: String = "" // Serialized list of alerts
)
