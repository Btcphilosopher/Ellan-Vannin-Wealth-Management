package com.example.data.repository

import com.example.data.local.*
import com.example.data.model.*
import com.example.network.VehicleSimulator
import com.example.security.KeystoreSecurityManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class VehicleRepository(
    private val database: ChevyCompanionDatabase,
    private val preferencesRepository: PreferencesRepository,
    val simulator: VehicleSimulator,
    val securityManager: KeystoreSecurityManager
) {
    val allVehicles: Flow<List<Vehicle>> = database.vehicleDao().getAllVehicles()

    val selectedVehicleId: Flow<String?> = preferencesRepository.selectedVehicleId

    val userPreferences: Flow<UserPreferences> = preferencesRepository.userPreferences

    fun getVehicle(id: String): Flow<Vehicle?> = database.vehicleDao().getVehicleById(id)

    fun getTelemetry(vehicleId: String): Flow<VehicleTelemetry?> =
        database.telemetryDao().getTelemetryForVehicle(vehicleId)

    fun getCommands(vehicleId: String): Flow<List<RemoteCommand>> =
        database.commandDao().getCommandsForVehicle(vehicleId)

    fun getTrips(vehicleId: String): Flow<List<JourneyTrip>> =
        database.tripDao().getTripsForVehicle(vehicleId)

    fun getFavoriteDestinations(): Flow<List<FavoriteDestination>> =
        database.tripDao().getFavoriteDestinations()

    fun getRefuelLogs(vehicleId: String): Flow<List<RefuelLog>> =
        database.energyDao().getRefuelLogs(vehicleId)

    fun getChargingSessions(vehicleId: String): Flow<List<ChargingSession>> =
        database.energyDao().getChargingSessions(vehicleId)

    fun getServiceRecords(vehicleId: String): Flow<List<ServiceRecord>> =
        database.careDao().getServiceRecords(vehicleId)

    fun getMaintenanceReminders(vehicleId: String): Flow<List<MaintenanceReminder>> =
        database.careDao().getMaintenanceReminders(vehicleId)

    fun getDocuments(vehicleId: String): Flow<List<VehicleDocument>> =
        database.ownershipDao().getDocuments(vehicleId)

    fun getHouseholdMembers(vehicleId: String): Flow<List<HouseholdMember>> =
        database.ownershipDao().getHouseholdMembers(vehicleId)

    suspend fun selectVehicle(vehicleId: String) {
        preferencesRepository.setSelectedVehicleId(vehicleId)
    }

    suspend fun sendRemoteCommand(
        vehicleId: String,
        commandType: CommandType,
        targetParameter: String? = null
    ): RemoteCommand {
        return simulator.executeCommand(vehicleId, commandType, targetParameter)
    }

    suspend fun addTrip(trip: JourneyTrip) {
        database.tripDao().insertTrip(trip)
    }

    suspend fun addRefuelLog(log: RefuelLog) {
        database.energyDao().insertRefuelLog(log)
    }

    suspend fun addServiceRecord(record: ServiceRecord) {
        database.careDao().insertServiceRecord(record)
    }

    suspend fun completeReminder(reminder: MaintenanceReminder) {
        database.careDao().updateMaintenanceReminder(reminder.copy(isCompleted = true))
    }

    suspend fun addVehicleDocument(doc: VehicleDocument) {
        database.ownershipDao().insertDocument(doc)
    }

    suspend fun addHouseholdMember(member: HouseholdMember) {
        database.ownershipDao().insertHouseholdMember(member)
    }

    suspend fun saveParkingLocation(
        vehicleId: String,
        latitude: Double,
        longitude: Double,
        address: String,
        notes: String
    ) {
        val telemetry = database.telemetryDao().getTelemetryDirect(vehicleId) ?: return
        database.telemetryDao().updateTelemetry(
            telemetry.copy(
                lastParkedLatitude = latitude,
                lastParkedLongitude = longitude,
                lastParkedAddress = address,
                lastParkedTimestampMs = System.currentTimeMillis(),
                parkingNotes = notes
            )
        )
    }

    suspend fun updatePreferences(preferences: UserPreferences) {
        preferencesRepository.updatePreferences(preferences)
    }

    suspend fun toggleMaskVin(masked: Boolean) {
        preferencesRepository.toggleMaskVin(masked)
    }

    suspend fun toggleDrivingMode(enabled: Boolean) {
        preferencesRepository.toggleDrivingMode(enabled)
    }

    suspend fun resetAllToDefaults() {
        database.clearAllTables()
        simulator.initializeDefaultDataIfEmpty()
    }
}
