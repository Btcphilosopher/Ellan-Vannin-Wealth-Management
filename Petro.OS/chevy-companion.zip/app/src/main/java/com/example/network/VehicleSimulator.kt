package com.example.network

import com.example.data.local.*
import com.example.data.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class VehicleSimulator(
    private val database: ChevyCompanionDatabase,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
) {
    // Simulator toggles for testing and demonstrations
    var forceCommandFailure: Boolean = false
    var simulateOffline: Boolean = false

    suspend fun initializeDefaultDataIfEmpty() {
        withContext(Dispatchers.IO) {
            val existing = database.vehicleDao().getVehicleDirect(DefaultDemonstrationData.ID_SILVERADO)
            if (existing == null) {
                database.vehicleDao().insertVehicles(DefaultDemonstrationData.getInitialVehicles())
                DefaultDemonstrationData.getInitialTelemetry().forEach {
                    database.telemetryDao().insertTelemetry(it)
                }
                database.tripDao().insertTrips(DefaultDemonstrationData.getInitialTrips())
                database.tripDao().insertFavoriteDestinations(DefaultDemonstrationData.getInitialFavoritePlaces())
                database.energyDao().insertRefuelLogs(DefaultDemonstrationData.getInitialRefuels())
                database.energyDao().insertChargingSessions(DefaultDemonstrationData.getInitialChargingSessions())
                database.careDao().insertServiceRecords(DefaultDemonstrationData.getInitialServiceRecords())
                database.careDao().insertMaintenanceReminders(DefaultDemonstrationData.getInitialReminders())
                database.ownershipDao().insertDocuments(DefaultDemonstrationData.getInitialDocuments())
                database.ownershipDao().insertHouseholdMembers(DefaultDemonstrationData.getInitialHouseholdMembers())
            }
        }
    }

    suspend fun executeCommand(
        vehicleId: String,
        commandType: CommandType,
        targetParameter: String? = null
    ): RemoteCommand {
        val command = RemoteCommand(
            commandId = UUID.randomUUID().toString(),
            vehicleId = vehicleId,
            commandType = commandType,
            state = CommandState.PENDING,
            targetParameter = targetParameter,
            initiatedTimestampMs = System.currentTimeMillis()
        )
        database.commandDao().insertCommand(command)

        // Launch simulated asynchronous vehicle telemetry processing
        scope.launch {
            processSimulatedCommand(command)
        }

        return command
    }

    private suspend fun processSimulatedCommand(command: RemoteCommand) {
        // Step 1: Network transit delay
        delay(1000)

        // Check if offline
        val currentTelemetry = database.telemetryDao().getTelemetryDirect(command.vehicleId)
        val isOffline = simulateOffline || (currentTelemetry?.connectionState == ConnectionState.OFFLINE)

        if (isOffline) {
            val failedCmd = command.copy(
                state = CommandState.FAILED,
                completedTimestampMs = System.currentTimeMillis(),
                failureReason = "Vehicle is offline. Unable to reach OnStar vehicle communications gateway."
            )
            database.commandDao().updateCommand(failedCmd)
            return
        }

        // Step 2: Vehicle Accepted command
        val acceptedCmd = command.copy(state = CommandState.ACCEPTED)
        database.commandDao().updateCommand(acceptedCmd)

        // Step 3: Vehicle execution delay
        delay(1500)

        // Check if simulated failure forced
        if (forceCommandFailure) {
            val failedCmd = command.copy(
                state = CommandState.FAILED,
                completedTimestampMs = System.currentTimeMillis(),
                failureReason = "Vehicle precondition check failed: Ignition/hood open or powertrain safety interlock active."
            )
            database.commandDao().updateCommand(failedCmd)
            return
        }

        // Step 4: Apply command effect to vehicle telemetry
        if (currentTelemetry != null) {
            val updatedTelemetry = when (command.commandType) {
                CommandType.LOCK -> currentTelemetry.copy(
                    isLocked = true,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                CommandType.UNLOCK -> currentTelemetry.copy(
                    isLocked = false,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                CommandType.REMOTE_START -> currentTelemetry.copy(
                    isRemoteStarted = true,
                    isPreconditioning = true,
                    cabinTempF = currentTelemetry.targetTempF,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                CommandType.REMOTE_STOP -> currentTelemetry.copy(
                    isRemoteStarted = false,
                    isPreconditioning = false,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                CommandType.HORN_LIGHTS -> currentTelemetry.copy(
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                CommandType.PRECONDITION_START -> currentTelemetry.copy(
                    isPreconditioning = true,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                CommandType.PRECONDITION_STOP -> currentTelemetry.copy(
                    isPreconditioning = false,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                CommandType.CHARGING_START -> currentTelemetry.copy(
                    isCharging = true,
                    isPluggedIn = true,
                    chargingPowerKw = 11.5,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                CommandType.CHARGING_STOP -> currentTelemetry.copy(
                    isCharging = false,
                    chargingPowerKw = 0.0,
                    lastUpdatedEpochMs = System.currentTimeMillis()
                )
                CommandType.SET_CHARGE_TARGET -> {
                    val target = command.targetParameter?.toIntOrNull() ?: currentTelemetry.chargingTargetPercent
                    currentTelemetry.copy(
                        chargingTargetPercent = target,
                        lastUpdatedEpochMs = System.currentTimeMillis()
                    )
                }
            }
            database.telemetryDao().updateTelemetry(updatedTelemetry)
        }

        // Step 5: Confirmed
        val confirmedCmd = command.copy(
            state = CommandState.CONFIRMED,
            completedTimestampMs = System.currentTimeMillis()
        )
        database.commandDao().updateCommand(confirmedCmd)
    }

    // Interactive simulation controls from UI
    suspend fun toggleOffline(vehicleId: String, offline: Boolean) {
        val current = database.telemetryDao().getTelemetryDirect(vehicleId) ?: return
        val updated = current.copy(
            connectionState = if (offline) ConnectionState.OFFLINE else ConnectionState.SIMULATED,
            lastUpdatedEpochMs = System.currentTimeMillis()
        )
        database.telemetryDao().updateTelemetry(updated)
    }

    suspend fun toggleStaleTelemetry(vehicleId: String, stale: Boolean) {
        val current = database.telemetryDao().getTelemetryDirect(vehicleId) ?: return
        val updated = current.copy(
            isStale = stale,
            connectionState = if (stale) ConnectionState.CACHED else ConnectionState.SIMULATED,
            lastUpdatedEpochMs = if (stale) System.currentTimeMillis() - 3600000L * 6 else System.currentTimeMillis()
        )
        database.telemetryDao().updateTelemetry(updated)
    }

    suspend fun toggleTyreAlert(vehicleId: String, lowPressure: Boolean) {
        val current = database.telemetryDao().getTelemetryDirect(vehicleId) ?: return
        val updated = current.copy(
            hasLowTyreAlert = lowPressure,
            tyrePressureFrontLeftPsi = if (lowPressure) 26.5 else 35.0,
            lastUpdatedEpochMs = System.currentTimeMillis()
        )
        database.telemetryDao().updateTelemetry(updated)
    }

    suspend fun simulateChargingTick(vehicleId: String, deltaSoc: Float) {
        val current = database.telemetryDao().getTelemetryDirect(vehicleId) ?: return
        val newSoc = (current.batterySocPercent + deltaSoc).coerceIn(0f, 100f)
        val updated = current.copy(
            batterySocPercent = newSoc,
            estimatedRangeMiles = (newSoc * 3.2).toDouble(),
            lastUpdatedEpochMs = System.currentTimeMillis()
        )
        database.telemetryDao().updateTelemetry(updated)
    }

    suspend fun refreshTelemetry(vehicleId: String) {
        val current = database.telemetryDao().getTelemetryDirect(vehicleId) ?: return
        val updated = current.copy(
            isStale = false,
            connectionState = ConnectionState.SIMULATED,
            lastUpdatedEpochMs = System.currentTimeMillis()
        )
        database.telemetryDao().updateTelemetry(updated)
    }
}
