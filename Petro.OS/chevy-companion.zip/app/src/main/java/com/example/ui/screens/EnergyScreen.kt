package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.domain.UnitConverter
import com.example.ui.ChevyViewModel
import com.example.ui.components.DemonstrationPill
import com.example.ui.components.GloveFriendlyButton
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun EnergyScreen(
    viewModel: ChevyViewModel,
    modifier: Modifier = Modifier
) {
    val currentVehicle by viewModel.currentVehicle.collectAsState()
    val telemetry by viewModel.currentTelemetry.collectAsState()
    val refuelLogs by viewModel.refuelLogs.collectAsState()
    val chargingSessions by viewModel.chargingSessions.collectAsState()
    val prefs by viewModel.userPreferences.collectAsState()

    var showAddRefuelDialog by remember { mutableStateOf(false) }

    val isEv = currentVehicle?.powertrainType == PowertrainType.EV

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("energy_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isEv) "ULTIUM ELECTRIC ENERGY & CHARGING" else "FUEL ECONOMY & REFUELLING",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = ChevyGoldBright
                    )
                    Text(
                        text = "${currentVehicle?.nickname} (${currentVehicle?.model})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                DemonstrationPill()
            }
        }

        if (isEv) {
            // EV ADAPTIVE VIEW
            item {
                EvChargingStatusCard(
                    telemetry = telemetry,
                    preferences = prefs,
                    onToggleCharging = {
                        val charging = telemetry?.isCharging == true
                        if (charging) viewModel.requestCommand(CommandType.CHARGING_STOP)
                        else viewModel.requestCommand(CommandType.CHARGING_START)
                    }
                )
            }

            item {
                EvChargeTargetCard(
                    currentTarget = telemetry?.chargingTargetPercent ?: 80,
                    departureTime = telemetry?.departureScheduleTime ?: "07:30 AM",
                    onSetTarget = { target ->
                        viewModel.requestCommand(CommandType.SET_CHARGE_TARGET, target.toString())
                    }
                )
            }

            item {
                EvTariffCard(preferences = prefs)
            }

            item {
                Text(
                    text = "CHARGING SESSIONS HISTORY",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    ),
                    color = ChevyGoldBright
                )
            }

            items(chargingSessions) { session ->
                ChargingSessionItem(session = session, preferences = prefs)
            }

            item {
                EvChargerFinderCard()
            }

        } else {
            // COMBUSTION (ICE) ADAPTIVE VIEW
            item {
                CombustionFuelCard(
                    vehicle = currentVehicle,
                    telemetry = telemetry,
                    preferences = prefs
                )
            }

            item {
                FuelEconomyTrendsCard(
                    refuelLogs = refuelLogs,
                    preferences = prefs
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "REFUELLING LOGS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = ChevyGoldBright
                    )
                    Button(
                        onClick = { showAddRefuelDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Log Fill-Up", fontWeight = FontWeight.Bold)
                    }
                }
            }

            items(refuelLogs) { log ->
                RefuelLogItem(log = log, preferences = prefs)
            }

            item {
                GasStationFinderCard()
            }
        }
    }

    if (showAddRefuelDialog) {
        AddRefuelDialog(
            onDismiss = { showAddRefuelDialog = false },
            onAdd = { gal, price, station, notes ->
                viewModel.addRefuelLog(gal, price, station, notes)
                showAddRefuelDialog = false
            }
        )
    }
}

// ---------------- EV COMPONENTS ----------------

@Composable
private fun EvChargingStatusCard(
    telemetry: VehicleTelemetry?,
    preferences: UserPreferences,
    onToggleCharging: () -> Unit
) {
    val tel = telemetry ?: return
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (tel.isCharging) Icons.Default.Bolt else Icons.Default.Power,
                        contentDescription = null,
                        tint = if (tel.isCharging) StatusBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (tel.isCharging) "CHARGING IN PROGRESS" else if (tel.isPluggedIn) "PLUGGED IN (IDLE)" else "UNPLUGGED",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (tel.isCharging) StatusBlue else MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = "${tel.batterySocPercent.toInt()}%",
                    style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold),
                    color = ChevyGoldBright
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress bar to target
            LinearProgressIndicator(
                progress = { tel.batterySocPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp)),
                color = if (tel.isCharging) StatusBlue else StatusGreen,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("CHARGING POWER", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(if (tel.isCharging) "${tel.chargingPowerKw} kW" else "0.0 kW", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("EST. RANGE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(UnitConverter.formatRange(tel.estimatedRangeMiles, preferences.distanceUnit), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("TARGET LIMIT", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${tel.chargingTargetPercent}%", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = ChevyGoldBright))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            GloveFriendlyButton(
                text = if (tel.isCharging) "Stop Charging Session" else "Initiate EV Charging",
                icon = Icons.Default.Bolt,
                onClick = onToggleCharging,
                isActive = tel.isCharging,
                accentColor = StatusBlue,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun EvChargeTargetCard(
    currentTarget: Int,
    departureTime: String,
    onSetTarget: (Int) -> Unit
) {
    var targetSlider by remember(currentTarget) { mutableStateOf(currentTarget.toFloat()) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DAILY CHARGE TARGET",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp),
                        color = ChevyGoldBright
                    )
                    Text(
                        text = "80% recommended for daily battery longevity",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "${targetSlider.toInt()}%",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = ChevyGoldBright
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Slider(
                value = targetSlider,
                onValueChange = { targetSlider = it },
                onValueChangeFinished = { onSetTarget(targetSlider.toInt()) },
                valueRange = 50f..100f,
                steps = 9,
                colors = SliderDefaults.colors(
                    thumbColor = ChevyGoldBright,
                    activeTrackColor = ChevyGoldBright
                )
            )

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("DEPARTURE PRECONDITION SCHEDULE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Weekdays at $departureTime (Cabin at 72°F)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                }
                Icon(Icons.Default.Alarm, contentDescription = null, tint = ChevyGoldBright)
            }
        }
    }
}

@Composable
private fun EvTariffCard(preferences: UserPreferences) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.AttachMoney, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Tariff Cost Estimate Assumptions", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Text("Residential Off-Peak: $0.15/kWh • Ultium Fast DC: $0.42/kWh. Full charge ~${UnitConverter.formatCurrency(12.75, preferences.currencyUnit)} at home.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ChargingSessionItem(session: ChargingSession, preferences: UserPreferences) {
    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(session.chargerNetwork, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                Text(UnitConverter.formatCurrency(session.totalCost, preferences.currencyUnit), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = ChevyGoldBright))
            }
            Text(dateFormat.format(Date(session.startTimeMs)) + " • " + session.chargerLocation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))
            Text("${session.startSocPercent}% → ${session.endSocPercent}% • ${session.energyDeliveredKWh} kWh delivered (Peak ${session.peakPowerKW} kW)", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun EvChargerFinderCard() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("NEARBY COMPATIBLE CHARGERS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = ChevyGoldBright)
            Spacer(modifier = Modifier.height(10.dp))
            ChargerRow("EVgo Ultium Fast Charger", "350 kW DC Fast • CCS & NACS", "1.4 mi", "$0.42/kWh")
            Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ChargerRow("Electrify America - Meijer", "150 kW DC Fast • CCS", "3.2 mi", "$0.48/kWh")
            Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ChargerRow("GM Dealer Level 2 Destination", "19.2 kW L2 • J1772", "4.8 mi", "Complimentary")
        }
    }
}

@Composable
private fun ChargerRow(name: String, specs: String, distance: String, price: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
            Text(specs, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(distance, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = ChevyGoldBright))
            Text(price, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------------- COMBUSTION (ICE) COMPONENTS ----------------

@Composable
private fun CombustionFuelCard(
    vehicle: Vehicle?,
    telemetry: VehicleTelemetry?,
    preferences: UserPreferences
) {
    val tel = telemetry ?: return
    val veh = vehicle ?: return

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("FUEL TANK LEVEL", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = ChevyGoldBright)
                    Text("Approx. ${String.format(Locale.US, "%.1f", veh.fuelTankCapacityGal * tel.fuelLevelPercent / 100)} / ${veh.fuelTankCapacityGal} gal", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Text(
                    text = "${tel.fuelLevelPercent.toInt()}%",
                    style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (tel.fuelLevelPercent < 20f) StatusAmber else ChevyGoldBright
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            LinearProgressIndicator(
                progress = { tel.fuelLevelPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp)),
                color = if (tel.fuelLevelPercent < 20f) StatusAmber else ChevyGoldBright,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("EST. RANGE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(UnitConverter.formatRange(tel.estimatedRangeMiles, preferences.distanceUnit), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("RECOMMENDED FUEL", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("87 Octane Top Tier", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("FILL-UP REMINDER", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(if (tel.fuelLevelPercent < 25f) "Refuel Soon" else "Normal", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = if (tel.fuelLevelPercent < 25f) StatusAmber else StatusGreen))
                }
            }
        }
    }
}

@Composable
private fun FuelEconomyTrendsCard(
    refuelLogs: List<RefuelLog>,
    preferences: UserPreferences
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("FUEL ECONOMY & COST ANALYSIS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = ChevyGoldBright)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("AVERAGE ECONOMY", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(UnitConverter.formatFuelEconomy(19.2, preferences.fuelEconomyUnit), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("COST PER MILE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(UnitConverter.formatCurrency(0.18, preferences.currencyUnit) + "/mi", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("LAST 30 DAYS", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(UnitConverter.formatCurrency(153.91, preferences.currencyUnit), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = ChevyGoldBright))
                }
            }
        }
    }
}

@Composable
private fun RefuelLogItem(log: RefuelLog, preferences: UserPreferences) {
    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(log.stationName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                Text(UnitConverter.formatCurrency(log.totalCost, preferences.currencyUnit), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = ChevyGoldBright))
            }
            Text(dateFormat.format(Date(log.timestampMs)) + " • " + log.fuelGrade, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text("${log.gallons} gal at ${UnitConverter.formatCurrency(log.pricePerGallon, preferences.currencyUnit)}/gal • Odometer: ${UnitConverter.formatOdometer(log.odometerMiles, preferences.distanceUnit)}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun GasStationFinderCard() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("NEARBY TOP TIER FUEL STATIONS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = ChevyGoldBright)
            Spacer(modifier = Modifier.height(10.dp))
            ChargerRow("Shell - Woodward Ave", "Regular 87 • V-Power 93", "0.8 mi", "$3.59/gal")
            Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ChargerRow("BP - Maple Rd", "Regular 87 • Invigorate Diesel", "2.1 mi", "$3.62/gal")
            Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ChargerRow("Mobil - Telegraph Rd", "Synergy Regular 87", "3.5 mi", "$3.55/gal")
        }
    }
}

@Composable
private fun AddRefuelDialog(
    onDismiss: () -> Unit,
    onAdd: (gallons: Double, pricePerGal: Double, station: String, notes: String) -> Unit
) {
    var gallonsText by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var station by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Fuel Fill-Up") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = gallonsText,
                    onValueChange = { gallonsText = it },
                    label = { Text("Gallons Pumped") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Price per Gallon ($)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = station,
                    onValueChange = { station = it },
                    label = { Text("Station Brand & Location") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (e.g. Full tank)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val g = gallonsText.toDoubleOrNull() ?: 18.0
                    val p = priceText.toDoubleOrNull() ?: 3.59
                    onAdd(g, p, if (station.isNotBlank()) station else "Local Station", notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
            ) {
                Text("Save Fill-Up", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
