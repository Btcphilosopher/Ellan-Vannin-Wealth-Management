package com.example.network

import com.example.data.model.CommandType
import com.example.data.model.ConnectionState
import com.example.data.model.VehicleTelemetry
import kotlinx.coroutines.flow.Flow

data class RemoteCommandResult(
    val commandId: String,
    val success: Boolean,
    val initialStatus: String, // "PENDING", "ACCEPTED"
    val message: String
)

interface VehicleServiceApi {
    suspend fun getTelemetry(vehicleId: String): VehicleTelemetry
    suspend fun executeCommand(vehicleId: String, commandType: CommandType, parameter: String?): RemoteCommandResult
    suspend fun checkCommandStatus(commandId: String): String // "PENDING", "ACCEPTED", "CONFIRMED", "FAILED", "EXPIRED"
    suspend fun getAvailableChargers(lat: Double, lng: Double): List<ChargerStationDto>
    suspend fun getAvailableFuelStations(lat: Double, lng: Double): List<FuelStationDto>
}

data class ChargerStationDto(
    val id: String,
    val name: String,
    val address: String,
    val distanceMiles: Double,
    val plugType: String,
    val powerKw: Int,
    val pricePerKWh: String,
    val isAvailable: Boolean
)

data class FuelStationDto(
    val id: String,
    val name: String,
    val address: String,
    val distanceMiles: Double,
    val regularPrice: String,
    val dieselPrice: String
)
