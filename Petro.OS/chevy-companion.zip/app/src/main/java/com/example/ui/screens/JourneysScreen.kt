package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.domain.UnitConverter
import com.example.ui.ChevyViewModel
import com.example.ui.components.DemonstrationPill
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun JourneysScreen(
    viewModel: ChevyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentVehicle by viewModel.currentVehicle.collectAsState()
    val telemetry by viewModel.currentTelemetry.collectAsState()
    val trips by viewModel.trips.collectAsState()
    val favorites by viewModel.favoriteDestinations.collectAsState()
    val prefs by viewModel.userPreferences.collectAsState()

    var showAddTripDialog by remember { mutableStateOf(false) }
    var showSaveParkingDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("journeys_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Mode Banner: Parked vs Driving
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = if (prefs.simplifiedDrivingModeEnabled) StatusGreenContainer.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, if (prefs.simplifiedDrivingModeEnabled) StatusGreen else MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (prefs.simplifiedDrivingModeEnabled) "DRIVING MODE ACTIVE" else "VEHICLE PARKED & STATIONARY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = if (prefs.simplifiedDrivingModeEnabled) StatusGreen else ChevyGoldBright
                        )
                        Text(
                            text = if (prefs.simplifiedDrivingModeEnabled)
                                "Glanceable high-contrast display. Complex tasks deferred until stationary."
                            else
                                "Trip logs, parking notes, and telemetry estimates ready.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Switch(
                        checked = prefs.simplifiedDrivingModeEnabled,
                        onCheckedChange = { viewModel.toggleDrivingMode() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = StatusGreen,
                            checkedTrackColor = StatusGreenContainer
                        )
                    )
                }
            }
        }

        // Saved Parking Location Card
        item {
            telemetry?.let { tel ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    tonalElevation = 4.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SAVED PARKING SPOT & NOTES",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.2.sp
                                ),
                                color = ChevyGoldBright
                            )
                            IconButton(
                                onClick = { showSaveParkingDialog = true },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Notes", tint = ChevyGoldBright, modifier = Modifier.size(18.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.LocalParking, contentDescription = null, tint = StatusBlue, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = tel.lastParkedAddress,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (tel.parkingNotes.isNotBlank()) tel.parkingNotes else "No parking notes recorded yet.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val gmmIntentUri = Uri.parse("geo:${tel.lastParkedLatitude},${tel.lastParkedLongitude}?q=${Uri.encode(tel.lastParkedAddress)}")
                                    val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                                    context.startActivity(Intent.createChooser(mapIntent, "Open Navigation"))
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp), tint = ChevyGoldBright)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Map Handoff")
                            }

                            Button(
                                onClick = { showSaveParkingDialog = true },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = MaterialTheme.colorScheme.onSurface
                                )
                            ) {
                                Icon(Icons.Default.AddLocation, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Update Spot")
                            }
                        }
                    }
                }
            }
        }

        // Favourite Destinations with fast navigation handoff
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                tonalElevation = 4.dp
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "FAVOURITE DESTINATIONS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = ChevyGoldBright
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    favorites.forEach { fav ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(fav.address)}"))
                                    context.startActivity(Intent.createChooser(intent, "Navigate to ${fav.name}"))
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                val favIcon = when (fav.category) {
                                    "Home" -> Icons.Default.Home
                                    "Work" -> Icons.Default.Work
                                    "Charger" -> Icons.Default.Bolt
                                    else -> Icons.Default.Place
                                }
                                Icon(favIcon, contentDescription = null, tint = ChevyGoldBright, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(fav.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                    Text(fav.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    }
                }
            }
        }

        // Trip History Header + Add Manual Trip Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "JOURNEY LOGS & TELEMETRY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = ChevyGoldBright
                    )
                    Text(
                        text = "Audited phone vs vehicle data sources",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { showAddTripDialog = true },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ChevyGoldBright,
                        contentColor = ChevyOnyx
                    )
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log Trip", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Trip Cards List
        if (trips.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = "No trips logged yet for this vehicle.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            }
        } else {
            items(trips) { trip ->
                TripCardItem(trip = trip, preferences = prefs, isEv = currentVehicle?.powertrainType == PowertrainType.EV)
            }
        }
    }

    if (showAddTripDialog) {
        AddTripDialog(
            isEv = currentVehicle?.powertrainType == PowertrainType.EV,
            onDismiss = { showAddTripDialog = false },
            onAdd = { title, dist, dur, consumed, cost, notes ->
                viewModel.addManualTrip(title, dist, dur, consumed, cost, notes)
                showAddTripDialog = false
            }
        )
    }

    if (showSaveParkingDialog) {
        SaveParkingDialog(
            currentNotes = telemetry?.parkingNotes ?: "",
            onDismiss = { showSaveParkingDialog = false },
            onSave = { notes ->
                viewModel.saveParkingLocation(notes)
                showSaveParkingDialog = false
            }
        )
    }
}

@Composable
private fun TripCardItem(trip: JourneyTrip, preferences: UserPreferences, isEv: Boolean) {
    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy • hh:mm a", Locale.getDefault()) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 3.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = trip.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Visible Data Source Badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (trip.dataSource == TripDataSource.VEHICLE_TELEMETRY) ChevyGoldContainerDark else MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, if (trip.dataSource == TripDataSource.VEHICLE_TELEMETRY) ChevyGoldBright else MaterialTheme.colorScheme.outline)
                ) {
                    Text(
                        text = if (trip.dataSource == TripDataSource.VEHICLE_TELEMETRY) "VEHICLE TELEMETRY" else "PHONE ESTIMATE",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                        color = if (trip.dataSource == TripDataSource.VEHICLE_TELEMETRY) ChevyGoldBright else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = dateFormat.format(Date(trip.startTimeMs)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Route
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.TripOrigin, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(trip.startAddress, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Icon(Icons.Default.Place, contentDescription = null, tint = StatusRed, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(trip.endAddress, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(12.dp))

            // Metrics: Distance, Duration, Consumption, Estimated Cost
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("DISTANCE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(UnitConverter.formatDistance(trip.distanceMiles, preferences.distanceUnit), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text("DURATION", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${trip.durationMinutes} min", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                Column {
                    Text(if (isEv) "ENERGY" else "FUEL", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        if (isEv) "${trip.electricityConsumedKWh} kWh" else "${trip.fuelConsumedGal} gal",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Column {
                    Text("EST. COST", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(UnitConverter.formatCurrency(trip.estimatedCostUsd, preferences.currencyUnit), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = ChevyGoldBright))
                }
            }

            if (trip.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Note: ${trip.notes}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AddTripDialog(
    isEv: Boolean,
    onDismiss: () -> Unit,
    onAdd: (title: String, dist: Double, dur: Int, consumed: Double, cost: Double, notes: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var distanceText by remember { mutableStateOf("") }
    var durationText by remember { mutableStateOf("") }
    var consumedText by remember { mutableStateOf("") }
    var costText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log New Journey") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Trip Title (e.g. Commute to Office)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = distanceText,
                    onValueChange = { distanceText = it },
                    label = { Text("Distance (miles)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = durationText,
                    onValueChange = { durationText = it },
                    label = { Text("Duration (minutes)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = consumedText,
                    onValueChange = { consumedText = it },
                    label = { Text(if (isEv) "Electricity Used (kWh)" else "Fuel Used (gal)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = costText,
                    onValueChange = { costText = it },
                    label = { Text("Estimated Cost ($)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Driving Notes / Route") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val d = distanceText.toDoubleOrNull() ?: 15.0
                    val dur = durationText.toIntOrNull() ?: 25
                    val c = consumedText.toDoubleOrNull() ?: if (isEv) 4.5 else 0.8
                    val cost = costText.toDoubleOrNull() ?: 3.00
                    onAdd(if (title.isNotBlank()) title else "Personal Drive", d, dur, c, cost, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
            ) {
                Text("Save Trip", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun SaveParkingDialog(
    currentNotes: String,
    onDismiss: () -> Unit,
    onSave: (notes: String) -> Unit
) {
    var notes by remember { mutableStateOf(currentNotes) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Update Parking Details") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Record floor level, pillar number, or parking deck bay to easily find your Chevrolet later.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Parking Notes / Spot Number") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(notes) },
                colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
            ) {
                Text("Save Note", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
