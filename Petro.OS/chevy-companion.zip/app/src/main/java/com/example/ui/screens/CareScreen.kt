package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MaintenanceReminder
import com.example.data.model.ServiceRecord
import com.example.domain.UnitConverter
import com.example.ui.ChevyViewModel
import com.example.ui.components.DemonstrationPill
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CareScreen(
    viewModel: ChevyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentVehicle by viewModel.currentVehicle.collectAsState()
    val serviceRecords by viewModel.serviceRecords.collectAsState()
    val reminders by viewModel.maintenanceReminders.collectAsState()
    val prefs by viewModel.userPreferences.collectAsState()

    var showAddServiceDialog by remember { mutableStateOf(false) }
    var selectedAlertExplainer by remember { mutableStateOf<String?>(null) }
    var showBookAppointmentDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("care_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Roadside Assistance & Emergency Header Bar
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = ChevyGoldContainerDark,
                border = BorderStroke(1.5.dp, ChevyGoldBright)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "CHEVROLET 24/7 ROADSIDE ASSISTANCE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = ChevyGoldBright
                        )
                        Text(
                            text = "Towing, flat tyre assistance, lockout, battery jump",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:18002438872"))
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ChevyGoldBright,
                            contentColor = ChevyOnyx
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Call Assistance", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Maintenance Reminders by Time & Mileage
        item {
            Text(
                text = "UPCOMING MAINTENANCE REMINDERS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                ),
                color = ChevyGoldBright
            )
        }

        items(reminders) { reminder ->
            ReminderCardItem(
                reminder = reminder,
                onComplete = { viewModel.completeReminder(reminder) },
                onBook = { showBookAppointmentDialog = true }
            )
        }

        // Service History Timeline + Add Service Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CERTIFIED SERVICE TIMELINE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = ChevyGoldBright
                    )
                    Text(
                        text = "Owner records, dealer stamps, and receipt notes",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = { showAddServiceDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Record", fontWeight = FontWeight.Bold)
                }
            }
        }

        items(serviceRecords) { record ->
            ServiceRecordCard(record = record, preferences = prefs)
        }

        // Plain English Alert Explanations
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DOCUMENTED ALERT GUIDE & MEANINGS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = ChevyGoldBright
                    )
                    Text(
                        text = "Plain-language documented meanings. Never presents inferred diagnoses as confirmed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    AlertGuideRow(
                        title = "TPMS (Tyre Pressure Monitoring)",
                        explanation = "Indicates one or more tyres have dropped below recommended cold PSI. Inspect tyre tread, fill to 35 PSI, and drive for 2 minutes to recalibrate."
                    )
                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    AlertGuideRow(
                        title = "Oil Life Monitor (dexos1)",
                        explanation = "Calculates engine oil breakdown based on engine revolutions, operating temperatures, and cold starts rather than simple mileage."
                    )
                    Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    AlertGuideRow(
                        title = "StabiliTrak / Electronic Stability Control",
                        explanation = "Active traction management system. Flashes when slippery conditions cause wheel slip; steady light indicates service inspection required."
                    )
                }
            }
        }

        // Recall Lookup & Official Documentation Links
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SAFETY RECALL LOOKUP (NHTSA)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = ChevyGoldBright
                        )
                        DemonstrationPill()
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Official safety recall checks query the National Highway Traffic Safety Administration (NHTSA) database. Fictional demonstration VINs have no safety recall campaigns open.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.nhtsa.gov/recalls"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp), tint = ChevyGoldBright)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("NHTSA Lookup")
                        }

                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.chevrolet.com/ownercenter"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface)
                        ) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Owner's Manual")
                        }
                    }
                }
            }
        }
    }

    if (showAddServiceDialog) {
        AddServiceRecordDialog(
            onDismiss = { showAddServiceDialog = false },
            onAdd = { category, desc, center, cost, note ->
                viewModel.addServiceRecord(category, desc, center, cost, note)
                showAddServiceDialog = false
            }
        )
    }

    if (showBookAppointmentDialog) {
        BookAppointmentDialog(onDismiss = { showBookAppointmentDialog = false })
    }
}

@Composable
private fun ReminderCardItem(
    reminder: MaintenanceReminder,
    onComplete: () -> Unit,
    onBook: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }
    val isDueSoon = reminder.urgencyLevel == "Due Soon"

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = if (isDueSoon) StatusAmberContainer.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, if (isDueSoon) StatusAmber else MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = reminder.title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = reminder.urgencyLevel,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (isDueSoon) StatusAmber else ChevyGoldBright
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Due by ${dateFormat.format(Date(reminder.dueDateMs))} (Target: ${reminder.dueMileage.toInt()} mi)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(reminder.description, style = MaterialTheme.typography.bodySmall)

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onComplete,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = StatusGreen)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Mark Completed")
                }

                Button(
                    onClick = onBook,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
                ) {
                    Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Book Service", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ServiceRecordCard(record: ServiceRecord, preferences: com.example.data.model.UserPreferences) {
    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 3.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(record.serviceCategory, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Text(UnitConverter.formatCurrency(record.costUsd, preferences.currencyUnit), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = ChevyGoldBright))
            }
            Text("${dateFormat.format(Date(record.dateMs))} • ${UnitConverter.formatOdometer(record.odometerMiles, preferences.distanceUnit)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))
            Text(record.description, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Storefront, contentDescription = null, tint = ChevyGoldBright, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(record.serviceCenter, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (record.receiptNote.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Note: ${record.receiptNote}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AlertGuideRow(title: String, explanation: String) {
    Column {
        Text(title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSurface)
        Spacer(modifier = Modifier.height(2.dp))
        Text(explanation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AddServiceRecordDialog(
    onDismiss: () -> Unit,
    onAdd: (category: String, desc: String, center: String, cost: Double, note: String) -> Unit
) {
    var category by remember { mutableStateOf("Scheduled Maintenance") }
    var desc by remember { mutableStateOf("") }
    var center by remember { mutableStateOf("") }
    var costText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Service Record") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category (e.g. Oil & Filter, Tyres)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Service Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = center,
                    onValueChange = { center = it },
                    label = { Text("Service Center / Dealer") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = costText,
                    onValueChange = { costText = it },
                    label = { Text("Cost ($)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Receipt Attachment / Notes") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val c = costText.toDoubleOrNull() ?: 75.0
                    onAdd(category, if (desc.isNotBlank()) desc else "Routine service inspection", if (center.isNotBlank()) center else "Chevrolet Certified Service", c, note)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
            ) {
                Text("Save Record", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun BookAppointmentDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Appointment Requested") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Your maintenance request has been submitted to Buff Whelan Chevrolet Certified Service.")
                Text("Preferred timing: Next Tuesday, 08:30 AM with courtesy shuttle service.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("(Demonstration flow: no live dealer dispatch)", style = MaterialTheme.typography.labelSmall, color = ChevyGoldBright)
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
            ) {
                Text("Done")
            }
        }
    )
}
