package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "remote_commands")
data class RemoteCommand(
    @PrimaryKey val commandId: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val commandType: CommandType,
    val state: CommandState = CommandState.PENDING,
    val targetParameter: String? = null,
    val initiatedTimestampMs: Long = System.currentTimeMillis(),
    val completedTimestampMs: Long? = null,
    val failureReason: String? = null,
    val clientToken: String = UUID.randomUUID().toString()
) {
    fun isConsequential(): Boolean {
        return when (commandType) {
            CommandType.UNLOCK,
            CommandType.REMOTE_START -> true
            else -> false
        }
    }

    fun getDisplayName(): String {
        return when (commandType) {
            CommandType.LOCK -> "Lock Doors"
            CommandType.UNLOCK -> "Unlock Doors"
            CommandType.REMOTE_START -> "Remote Engine/Climate Start"
            CommandType.REMOTE_STOP -> "Cancel Remote Start"
            CommandType.HORN_LIGHTS -> "Flash Lights & Sound Horn"
            CommandType.PRECONDITION_START -> "Precondition Cabin"
            CommandType.PRECONDITION_STOP -> "Stop Preconditioning"
            CommandType.CHARGING_START -> "Start EV Charging"
            CommandType.CHARGING_STOP -> "Stop EV Charging"
            CommandType.SET_CHARGE_TARGET -> "Set Charging Target"
        }
    }
}
