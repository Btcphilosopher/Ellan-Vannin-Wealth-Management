package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "refuel_logs")
data class RefuelLog(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val timestampMs: Long,
    val gallons: Double,
    val pricePerGallon: Double,
    val totalCost: Double,
    val odometerMiles: Double,
    val isFullTank: Boolean,
    val fuelGrade: String, // Regular 87, Premium 93, Diesel
    val stationName: String,
    val notes: String = ""
)

@Entity(tableName = "charging_sessions")
data class ChargingSession(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val energyDeliveredKWh: Double,
    val peakPowerKW: Double,
    val totalCost: Double,
    val chargerNetwork: String, // Home L2, EVgo, Electrify America, Supercharger (NACS)
    val chargerLocation: String,
    val startSocPercent: Int,
    val endSocPercent: Int
)

data class EnergyStation(
    val id: String,
    val name: String,
    val address: String,
    val distanceMiles: Double,
    val type: String, // "EV DC Fast (350kW)", "EV Level 2 (11kW)", "Top Tier Gasoline", "Ultra-Low Diesel"
    val priceDisplay: String,
    val isDemonstration: Boolean = true,
    val latitude: Double,
    val longitude: Double
)
