package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionState
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ConnectionStatusBadge(
    connectionState: ConnectionState,
    isStale: Boolean,
    lastUpdatedMs: Long,
    modifier: Modifier = Modifier
) {
    val (statusText, dotColor, badgeBg, badgeBorder) = when {
        connectionState == ConnectionState.OFFLINE -> {
            Quad("OFFLINE", StatusRed, StatusRedContainer.copy(alpha = 0.3f), StatusRed)
        }
        isStale || connectionState == ConnectionState.CACHED -> {
            val agoMinutes = ((System.currentTimeMillis() - lastUpdatedMs) / 60000).coerceAtLeast(1)
            val agoText = if (agoMinutes >= 60) "${agoMinutes / 60}h ago" else "${agoMinutes}m ago"
            Quad("CACHED ($agoText)", StatusAmber, StatusAmberContainer.copy(alpha = 0.25f), StatusAmber)
        }
        connectionState == ConnectionState.SIMULATED -> {
            Quad("SIMULATED TELEMETRY", ChevyGoldBright, ChevyGoldContainerDark, ChevyGold)
        }
        else -> {
            Quad("LIVE CONNECTED", StatusGreen, StatusGreenContainer.copy(alpha = 0.3f), StatusGreen)
        }
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = badgeBg,
        border = BorderStroke(1.dp, badgeBorder.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(dotColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = statusText,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 0.5.sp
                ),
                color = dotColor
            )
        }
    }
}

@Composable
fun DemonstrationPill(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Text(
            text = "DEMO DATA",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 9.sp,
                letterSpacing = 0.8.sp
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
