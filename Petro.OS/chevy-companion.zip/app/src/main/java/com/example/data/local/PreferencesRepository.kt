package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "chevy_companion_prefs")

class PreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val SELECTED_VEHICLE_ID = stringPreferencesKey("selected_vehicle_id")
        val DISTANCE_UNIT = stringPreferencesKey("distance_unit")
        val TEMP_UNIT = stringPreferencesKey("temp_unit")
        val PRESSURE_UNIT = stringPreferencesKey("pressure_unit")
        val CURRENCY_UNIT = stringPreferencesKey("currency_unit")
        val FUEL_ECONOMY_UNIT = stringPreferencesKey("fuel_economy_unit")
        val MASK_VIN = booleanPreferencesKey("mask_vin")
        val PARKING_REMINDERS = booleanPreferencesKey("parking_reminders")
        val HAPTIC_FEEDBACK = booleanPreferencesKey("haptic_feedback")
        val SIMPLIFIED_DRIVING_MODE = booleanPreferencesKey("simplified_driving_mode")
        val DEMO_FORCE_FAILURE = booleanPreferencesKey("demo_force_failure")
        val DEMO_SIMULATE_OFFLINE = booleanPreferencesKey("demo_simulate_offline")
    }

    val selectedVehicleId: Flow<String?> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { preferences ->
            preferences[PreferencesKeys.SELECTED_VEHICLE_ID]
        }

    val userPreferences: Flow<UserPreferences> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { prefs ->
            UserPreferences(
                distanceUnit = DistanceUnit.valueOf(prefs[PreferencesKeys.DISTANCE_UNIT] ?: DistanceUnit.MILES.name),
                temperatureUnit = TemperatureUnit.valueOf(prefs[PreferencesKeys.TEMP_UNIT] ?: TemperatureUnit.FAHRENHEIT.name),
                pressureUnit = PressureUnit.valueOf(prefs[PreferencesKeys.PRESSURE_UNIT] ?: PressureUnit.PSI.name),
                currencyUnit = CurrencyUnit.valueOf(prefs[PreferencesKeys.CURRENCY_UNIT] ?: CurrencyUnit.USD.name),
                fuelEconomyUnit = FuelEconomyUnit.valueOf(prefs[PreferencesKeys.FUEL_ECONOMY_UNIT] ?: FuelEconomyUnit.MPG_US.name),
                maskVinInUi = prefs[PreferencesKeys.MASK_VIN] ?: true,
                parkingRemindersEnabled = prefs[PreferencesKeys.PARKING_REMINDERS] ?: true,
                hapticFeedbackEnabled = prefs[PreferencesKeys.HAPTIC_FEEDBACK] ?: true,
                simplifiedDrivingModeEnabled = prefs[PreferencesKeys.SIMPLIFIED_DRIVING_MODE] ?: false
            )
        }

    suspend fun setSelectedVehicleId(vehicleId: String) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.SELECTED_VEHICLE_ID] = vehicleId
        }
    }

    suspend fun updatePreferences(preferences: UserPreferences) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.DISTANCE_UNIT] = preferences.distanceUnit.name
            prefs[PreferencesKeys.TEMP_UNIT] = preferences.temperatureUnit.name
            prefs[PreferencesKeys.PRESSURE_UNIT] = preferences.pressureUnit.name
            prefs[PreferencesKeys.CURRENCY_UNIT] = preferences.currencyUnit.name
            prefs[PreferencesKeys.FUEL_ECONOMY_UNIT] = preferences.fuelEconomyUnit.name
            prefs[PreferencesKeys.MASK_VIN] = preferences.maskVinInUi
            prefs[PreferencesKeys.PARKING_REMINDERS] = preferences.parkingRemindersEnabled
            prefs[PreferencesKeys.HAPTIC_FEEDBACK] = preferences.hapticFeedbackEnabled
            prefs[PreferencesKeys.SIMPLIFIED_DRIVING_MODE] = preferences.simplifiedDrivingModeEnabled
        }
    }

    suspend fun toggleMaskVin(masked: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.MASK_VIN] = masked
        }
    }

    suspend fun toggleDrivingMode(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.SIMPLIFIED_DRIVING_MODE] = enabled
        }
    }
}
