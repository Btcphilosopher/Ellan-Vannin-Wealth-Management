package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.*

@Database(
    entities = [
        Vehicle::class,
        VehicleTelemetry::class,
        RemoteCommand::class,
        JourneyTrip::class,
        FavoriteDestination::class,
        RefuelLog::class,
        ChargingSession::class,
        ServiceRecord::class,
        MaintenanceReminder::class,
        VehicleDocument::class,
        HouseholdMember::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(ChevyConverters::class)
abstract class ChevyCompanionDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
    abstract fun telemetryDao(): TelemetryDao
    abstract fun commandDao(): CommandDao
    abstract fun tripDao(): TripDao
    abstract fun energyDao(): EnergyDao
    abstract fun careDao(): CareDao
    abstract fun ownershipDao(): OwnershipDao

    companion object {
        @Volatile
        private var INSTANCE: ChevyCompanionDatabase? = null

        fun getDatabase(context: Context): ChevyCompanionDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ChevyCompanionDatabase::class.java,
                    "chevy_companion.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
