package com.example.data.local

import com.example.data.model.*

object DefaultDemonstrationData {

    const val ID_SILVERADO = "demo_silverado_1500"
    const val ID_TAHOE = "demo_tahoe_premier"
    const val ID_BLAZER_EV = "demo_blazer_ev"

    fun getInitialVehicles(): List<Vehicle> = listOf(
        Vehicle(
            id = ID_SILVERADO,
            nickname = "High Country Beast",
            model = "Silverado 1500",
            modelYear = 2024,
            trim = "High Country Crew Cab 4WD",
            exteriorColorName = "Dark Ash Metallic",
            powertrainType = PowertrainType.ICE_PETROL,
            vin = "1GCUDDED8RZ192841",
            registrationPlate = "CHVY-911",
            odometerMiles = 18450.0,
            fuelTankCapacityGal = 24.0,
            batteryCapacityKWh = 0.0,
            heroDrawableName = "img_vehicle_silverado",
            warrantySummary = "Bumper-to-Bumper: 3 Yr / 36,000 Mi • Powertrain: 5 Yr / 60,000 Mi",
            isDemo = true
        ),
        Vehicle(
            id = ID_TAHOE,
            nickname = "Family Cruiser",
            model = "Tahoe",
            modelYear = 2023,
            trim = "Premier 4WD 5.3L V8",
            exteriorColorName = "Black",
            powertrainType = PowertrainType.ICE_PETROL,
            vin = "1GNSKBKC4PR248102",
            registrationPlate = "MICH-842",
            odometerMiles = 29410.0,
            fuelTankCapacityGal = 28.0,
            batteryCapacityKWh = 0.0,
            heroDrawableName = "img_vehicle_tahoe",
            warrantySummary = "Bumper-to-Bumper: Expired • Powertrain: 5 Yr / 60,000 Mi (Active)",
            isDemo = true
        ),
        Vehicle(
            id = ID_BLAZER_EV,
            nickname = "Lightning Bowtie",
            model = "Blazer EV",
            modelYear = 2025,
            trim = "RS AWD Ultium 85kWh",
            exteriorColorName = "Radiant Red Tintcoat",
            powertrainType = PowertrainType.EV,
            vin = "3GNAXKEV2SS901248",
            registrationPlate = "EV-BOWTIE",
            odometerMiles = 8240.0,
            fuelTankCapacityGal = 0.0,
            batteryCapacityKWh = 85.0,
            heroDrawableName = "img_vehicle_blazer_ev",
            warrantySummary = "EV Component / Ultium Battery: 8 Yr / 100,000 Mi • Bumper-to-Bumper: 3 Yr / 36,000 Mi",
            isDemo = true
        )
    )

    fun getInitialTelemetry(): List<VehicleTelemetry> {
        val now = System.currentTimeMillis()
        return listOf(
            VehicleTelemetry(
                vehicleId = ID_SILVERADO,
                lastUpdatedEpochMs = now - 180000L, // 3 minutes ago
                connectionState = ConnectionState.SIMULATED,
                isStale = false,
                fuelLevelPercent = 72f,
                batterySocPercent = 0f,
                estimatedRangeMiles = 365.0,
                isLocked = true,
                areDoorsClosed = true,
                areWindowsClosed = true,
                isRemoteStarted = false,
                cabinTempF = 68,
                targetTempF = 71,
                isPreconditioning = false,
                tyrePressureFrontLeftPsi = 35.0,
                tyrePressureFrontRightPsi = 35.5,
                tyrePressureRearLeftPsi = 36.0,
                tyrePressureRearRightPsi = 36.2,
                hasLowTyreAlert = false,
                lastParkedLatitude = 42.3314,
                lastParkedLongitude = -83.0458,
                lastParkedAddress = "GM Renaissance Center, Detroit, MI",
                lastParkedTimestampMs = now - 7200000L,
                parkingNotes = "Surface Lot P4, Bay 18",
                nextServiceDateMs = now + 86400000L * 45,
                nextServiceMiles = 22500.0
            ),
            VehicleTelemetry(
                vehicleId = ID_TAHOE,
                lastUpdatedEpochMs = now - 3600000L * 4, // 4 hours ago (cached)
                connectionState = ConnectionState.CACHED,
                isStale = true,
                fuelLevelPercent = 38f,
                batterySocPercent = 0f,
                estimatedRangeMiles = 185.0,
                isLocked = true,
                areDoorsClosed = true,
                areWindowsClosed = true,
                isRemoteStarted = false,
                cabinTempF = 72,
                targetTempF = 70,
                isPreconditioning = false,
                tyrePressureFrontLeftPsi = 28.5, // Low tyre example
                tyrePressureFrontRightPsi = 35.0,
                tyrePressureRearLeftPsi = 35.0,
                tyrePressureRearRightPsi = 34.8,
                hasLowTyreAlert = true,
                lastParkedLatitude = 42.2808,
                lastParkedLongitude = -83.7430,
                lastParkedAddress = "Main St Parking Structure, Ann Arbor, MI",
                lastParkedTimestampMs = now - 3600000L * 5,
                parkingNotes = "4th Floor near North Stairwell",
                nextServiceDateMs = now + 86400000L * 10,
                nextServiceMiles = 30000.0
            ),
            VehicleTelemetry(
                vehicleId = ID_BLAZER_EV,
                lastUpdatedEpochMs = now - 60000L, // 1 minute ago
                connectionState = ConnectionState.SIMULATED,
                isStale = false,
                fuelLevelPercent = 0f,
                batterySocPercent = 78f,
                estimatedRangeMiles = 248.0,
                isLocked = true,
                areDoorsClosed = true,
                areWindowsClosed = true,
                isRemoteStarted = false,
                cabinTempF = 69,
                targetTempF = 72,
                isPreconditioning = false,
                isCharging = true,
                isPluggedIn = true,
                chargingPowerKw = 11.5,
                chargingTargetPercent = 85,
                departureScheduleTime = "07:30 AM",
                departureScheduleEnabled = true,
                tyrePressureFrontLeftPsi = 38.0,
                tyrePressureFrontRightPsi = 38.2,
                tyrePressureRearLeftPsi = 38.0,
                tyrePressureRearRightPsi = 37.9,
                hasLowTyreAlert = false,
                lastParkedLatitude = 42.3486,
                lastParkedLongitude = -83.0567,
                lastParkedAddress = "Home Driveway - Ultium Level 2 Wall Box",
                lastParkedTimestampMs = now - 1800000L,
                parkingNotes = "Plugged in overnight to Level 2 48A charger",
                nextServiceDateMs = now + 86400000L * 120,
                nextServiceMiles = 15000.0
            )
        )
    }

    fun getInitialTrips(): List<JourneyTrip> {
        val now = System.currentTimeMillis()
        return listOf(
            JourneyTrip(
                vehicleId = ID_SILVERADO,
                title = "Commute to Tech Center",
                startTimeMs = now - 86400000L - 3600000L,
                endTimeMs = now - 86400000L,
                startAddress = "Rochester Hills, MI",
                endAddress = "GM Global Technical Center, Warren, MI",
                distanceMiles = 18.4,
                durationMinutes = 26,
                fuelConsumedGal = 0.95,
                estimatedCostUsd = 3.42,
                dataSource = TripDataSource.VEHICLE_TELEMETRY,
                isFavorite = true,
                notes = "Smooth highway driving via M-53 South"
            ),
            JourneyTrip(
                vehicleId = ID_SILVERADO,
                title = "Weekend Haul to Lake Huron",
                startTimeMs = now - 86400000L * 3,
                endTimeMs = now - 86400000L * 3 + 7200000L,
                startAddress = "Warren, MI",
                endAddress = "Port Huron Marina, MI",
                distanceMiles = 64.2,
                durationMinutes = 68,
                fuelConsumedGal = 3.40,
                estimatedCostUsd = 12.24,
                dataSource = TripDataSource.VEHICLE_TELEMETRY,
                isFavorite = false,
                notes = "Towed boat trailer with Tow/Haul mode engaged"
            ),
            JourneyTrip(
                vehicleId = ID_BLAZER_EV,
                title = "Downtown Detroit Commute",
                startTimeMs = now - 3600000L * 8,
                endTimeMs = now - 3600000L * 7,
                startAddress = "Birmingham, MI",
                endAddress = "Woodward Ave, Detroit, MI",
                distanceMiles = 19.8,
                durationMinutes = 32,
                fuelConsumedGal = 0.0,
                electricityConsumedKWh = 5.8,
                estimatedCostUsd = 0.87,
                dataSource = TripDataSource.VEHICLE_TELEMETRY,
                isFavorite = true,
                notes = "Regen-on-demand used extensively on Woodward"
            ),
            JourneyTrip(
                vehicleId = ID_TAHOE,
                title = "Youth Hockey Tournament",
                startTimeMs = now - 86400000L * 2,
                endTimeMs = now - 86400000L * 2 + 5400000L,
                startAddress = "Ann Arbor, MI",
                endAddress = "Novi Ice Arena, MI",
                distanceMiles = 31.5,
                durationMinutes = 42,
                fuelConsumedGal = 1.95,
                estimatedCostUsd = 7.02,
                dataSource = TripDataSource.PHONE_DERIVED_ESTIMATE,
                isFavorite = false,
                notes = "Full cabin with 6 passengers and sports gear"
            )
        )
    }

    fun getInitialRefuels(): List<RefuelLog> {
        val now = System.currentTimeMillis()
        return listOf(
            RefuelLog(
                vehicleId = ID_SILVERADO,
                timestampMs = now - 86400000L * 5,
                gallons = 20.4,
                pricePerGallon = 3.59,
                totalCost = 73.24,
                odometerMiles = 18120.0,
                isFullTank = true,
                fuelGrade = "Regular 87 Octane",
                stationName = "Shell - Woodward Ave",
                notes = "Top Tier gasoline fill-up"
            ),
            RefuelLog(
                vehicleId = ID_TAHOE,
                timestampMs = now - 86400000L * 8,
                gallons = 22.1,
                pricePerGallon = 3.65,
                totalCost = 80.67,
                odometerMiles = 29050.0,
                isFullTank = true,
                fuelGrade = "Regular 87 Octane",
                stationName = "Mobil - Ann Arbor Rd",
                notes = "Full tank prior to weekend tournament"
            )
        )
    }

    fun getInitialChargingSessions(): List<ChargingSession> {
        val now = System.currentTimeMillis()
        return listOf(
            ChargingSession(
                vehicleId = ID_BLAZER_EV,
                startTimeMs = now - 86400000L * 2 - 3600000L,
                endTimeMs = now - 86400000L * 2,
                energyDeliveredKWh = 42.5,
                peakPowerKW = 150.0,
                totalCost = 17.85,
                chargerNetwork = "EVgo Fast Charger (Ultium Network)",
                chargerLocation = "Troy Marketplace, MI",
                startSocPercent = 22,
                endSocPercent = 80
            ),
            ChargingSession(
                vehicleId = ID_BLAZER_EV,
                startTimeMs = now - 86400000L * 4 - 28800000L,
                endTimeMs = now - 86400000L * 4,
                energyDeliveredKWh = 31.0,
                peakPowerKW = 11.5,
                totalCost = 4.65,
                chargerNetwork = "Home Ultium Level 2 Wallbox",
                chargerLocation = "Residential Off-Peak Tariff",
                startSocPercent = 45,
                endSocPercent = 85
            )
        )
    }

    fun getInitialServiceRecords(): List<ServiceRecord> {
        val now = System.currentTimeMillis()
        return listOf(
            ServiceRecord(
                vehicleId = ID_SILVERADO,
                dateMs = now - 86400000L * 90,
                odometerMiles = 15000.0,
                serviceCategory = "Scheduled Maintenance",
                description = "Mobil 1 Full Synthetic dexos1 oil change, ACDelco oil filter, multi-point vehicle inspection, tyre rotation & balance.",
                serviceCenter = "Buff Whelan Chevrolet Service Center, Sterling Heights, MI",
                costUsd = 98.50,
                receiptNote = "Warranty intact; complementary multipoint inspection passed.",
                isDemonstration = true
            ),
            ServiceRecord(
                vehicleId = ID_TAHOE,
                dateMs = now - 86400000L * 150,
                odometerMiles = 25000.0,
                serviceCategory = "Brakes & Tyres",
                description = "Front ceramic brake pads inspection, rear pads replacement, cabin air filter replacement, TPMS recalibration.",
                serviceCenter = "Gordon Chevrolet Certified Service, Garden City, MI",
                costUsd = 345.00,
                receiptNote = "Replaced rear pads with OEM GM Genuine parts.",
                isDemonstration = true
            ),
            ServiceRecord(
                vehicleId = ID_BLAZER_EV,
                dateMs = now - 86400000L * 60,
                odometerMiles = 7500.0,
                serviceCategory = "EV Health & Inspection",
                description = "Ultium high-voltage battery diagnostic check, battery thermal cooling fluid level inspection, tyre rotation and torque verification.",
                serviceCenter = "Suburban Chevrolet EV Specialist Center, Ann Arbor, MI",
                costUsd = 45.00,
                receiptNote = "Ultium diagnostic report: 100% cell pack balance health.",
                isDemonstration = true
            )
        )
    }

    fun getInitialReminders(): List<MaintenanceReminder> {
        val now = System.currentTimeMillis()
        return listOf(
            MaintenanceReminder(
                vehicleId = ID_SILVERADO,
                title = "22,500 Mi Scheduled Service & Oil Life",
                dueDateMs = now + 86400000L * 45,
                dueMileage = 22500.0,
                isCompleted = false,
                urgencyLevel = "Normal",
                description = "Recommended GM Certified engine oil & filter service, air cleaner inspection, and chassis lube."
            ),
            MaintenanceReminder(
                vehicleId = ID_TAHOE,
                title = "30,000 Mi Major Inspection & Front Tyres",
                dueDateMs = now + 86400000L * 10,
                dueMileage = 30000.0,
                isCompleted = false,
                urgencyLevel = "Due Soon",
                description = "Inspection of transmission fluid, brake lines, fuel system, and addressing low left front tyre pressure."
            ),
            MaintenanceReminder(
                vehicleId = ID_BLAZER_EV,
                title = "15,000 Mi EV Cabin Filter & Inspection",
                dueDateMs = now + 86400000L * 120,
                dueMileage = 15000.0,
                isCompleted = false,
                urgencyLevel = "Normal",
                description = "Passenger compartment air filter replacement, wiper blades check, and Ultium cooling loop inspection."
            )
        )
    }

    fun getInitialDocuments(): List<VehicleDocument> {
        val now = System.currentTimeMillis()
        return listOf(
            VehicleDocument(
                vehicleId = ID_SILVERADO,
                title = "State Auto Insurance Card",
                documentType = "Auto Insurance",
                policyOrDocNumber = "AUTO-MI-98214-CH",
                issuerName = "State Farm Mutual",
                expirationDateMs = now + 86400000L * 180,
                notes = "Comprehensive & Collision with $500 deductible"
            ),
            VehicleDocument(
                vehicleId = ID_SILVERADO,
                title = "Michigan Certificate of Registration",
                documentType = "Registration",
                policyOrDocNumber = "REG-2024-88410",
                issuerName = "Michigan Secretary of State",
                expirationDateMs = now + 86400000L * 240,
                notes = "Plate: CHVY-911, tab valid through birthday"
            ),
            VehicleDocument(
                vehicleId = ID_BLAZER_EV,
                title = "Ultium EV Manufacturer Warranty",
                documentType = "Warranty Certificate",
                policyOrDocNumber = "GM-ULTIUM-EV-0912",
                issuerName = "General Motors LLC",
                expirationDateMs = now + 86400000L * 365 * 7,
                notes = "Covers high-voltage battery degradation below 75% for 8 yrs / 100,000 mi"
            )
        )
    }

    fun getInitialHouseholdMembers(): List<HouseholdMember> {
        return listOf(
            HouseholdMember(
                vehicleId = ID_SILVERADO,
                fullName = "Sarah Anderson",
                relationship = "Spouse",
                accessScope = "Full Remote Commands",
                isLocationSharingGranted = true
            ),
            HouseholdMember(
                vehicleId = ID_SILVERADO,
                fullName = "James Anderson",
                relationship = "Son",
                accessScope = "Dashboard Telemetry Only",
                isLocationSharingGranted = false
            )
        )
    }

    fun getInitialFavoritePlaces(): List<FavoriteDestination> {
        return listOf(
            FavoriteDestination(
                name = "Home",
                address = "1420 Woodward Ave, Birmingham, MI",
                category = "Home",
                latitude = 42.5467,
                longitude = -83.2155
            ),
            FavoriteDestination(
                name = "GM Global Tech Center",
                address = "30001 Van Dyke Ave, Warren, MI",
                category = "Work",
                latitude = 42.5085,
                longitude = -83.0366
            ),
            FavoriteDestination(
                name = "EVgo Ultium Fast Charger",
                address = "2800 W Big Beaver Rd, Troy, MI",
                category = "Charger",
                latitude = 42.5606,
                longitude = -83.1784
            ),
            FavoriteDestination(
                name = "Buff Whelan Chevrolet Dealer",
                address = "40445 Van Dyke Ave, Sterling Heights, MI",
                category = "Dealer",
                latitude = 42.5936,
                longitude = -83.0322
            )
        )
    }
}
