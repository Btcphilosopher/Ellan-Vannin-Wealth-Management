package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ChevyGoldBright,
    onPrimary = ChevyOnyx,
    primaryContainer = ChevyGoldContainerDark,
    onPrimaryContainer = ChevyGoldBright,
    secondary = ChevyMetalHighlight,
    onSecondary = ChevyOnyx,
    secondaryContainer = ChevySurfaceRaisedDark,
    onSecondaryContainer = TextPrimaryDark,
    tertiary = StatusBlue,
    onTertiary = Color.White,
    background = ChevyOnyx,
    onBackground = TextPrimaryDark,
    surface = ChevyGraphiteDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = ChevySurfaceCardDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = ChevyMetalBorderDark,
    outlineVariant = ChevyMetalMuted,
    error = StatusRed,
    onError = Color.White,
    errorContainer = StatusRedContainer,
    onErrorContainer = Color(0xFFFFDAD6)
)

private val ChevySecondaryLightText = Color(0xFF3B414C)

private val LightColorScheme = lightColorScheme(
    primary = ChevyGoldDark,
    onPrimary = Color.White,
    primaryContainer = ChevyGoldContainerLight,
    onPrimaryContainer = ChevyOnyx,
    secondary = ChevySecondaryLightText,
    onSecondary = Color.White,
    secondaryContainer = ChevyLightSurfaceRaised,
    onSecondaryContainer = TextPrimaryLight,
    tertiary = StatusBlue,
    onTertiary = Color.White,
    background = ChevyLightBg,
    onBackground = TextPrimaryLight,
    surface = ChevyLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = ChevyLightSurfaceRaised,
    onSurfaceVariant = TextSecondaryLight,
    outline = ChevyLightBorder,
    outlineVariant = ChevyMetalMuted,
    error = StatusRed,
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = StatusRedContainer
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Preserve custom Chevrolet automotive identity by default
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
