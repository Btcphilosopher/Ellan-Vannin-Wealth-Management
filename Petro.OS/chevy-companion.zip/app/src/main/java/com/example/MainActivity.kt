package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.PowertrainType
import com.example.ui.ChevyViewModel
import com.example.ui.components.CommandProgressModal
import com.example.ui.components.ConsequentialConfirmDialog
import com.example.ui.components.SimulationControlSheet
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class ChevyDestination(
    val label: String,
    val icon: ImageVector,
    val testTag: String
) {
    GARAGE("Garage", Icons.Default.DirectionsCar, "nav_garage"),
    JOURNEYS("Journeys", Icons.Default.Route, "nav_journeys"),
    ENERGY("Energy", Icons.Default.LocalGasStation, "nav_energy"),
    CARE("Care", Icons.Default.Build, "nav_care"),
    ACCOUNT("Account", Icons.Default.Person, "nav_account")
}

class MainActivity : ComponentActivity() {

    private val viewModel: ChevyViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val currentVehicle by viewModel.currentVehicle.collectAsState()
                val telemetry by viewModel.currentTelemetry.collectAsState()
                val prefs by viewModel.userPreferences.collectAsState()
                val activeCmdState by viewModel.activeCommandState.collectAsState()
                val confirmState by viewModel.confirmationState.collectAsState()
                val isSimulatorOpen by viewModel.isSimulatorSheetOpen.collectAsState()

                var currentDestination by remember { mutableStateOf(ChevyDestination.GARAGE) }

                // System back button returns to Garage if on other tab
                BackHandler(enabled = currentDestination != ChevyDestination.GARAGE) {
                    currentDestination = ChevyDestination.GARAGE
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(start = 4.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.img_chevy_bowtie),
                                        contentDescription = "Chevrolet Bowtie",
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "CHEVROLET",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Black,
                                                letterSpacing = 2.sp,
                                                fontSize = 15.sp
                                            ),
                                            color = ChevyGoldBright
                                        )
                                        currentVehicle?.let { veh ->
                                            Text(
                                                text = "${veh.nickname} • ${veh.model}",
                                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            },
                            actions = {
                                // Driving mode toggle
                                IconButton(
                                    onClick = { viewModel.toggleDrivingMode() },
                                    modifier = Modifier.testTag("topbar_driving_mode_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DirectionsCarFilled,
                                        contentDescription = "Toggle Driving Mode",
                                        tint = if (prefs.simplifiedDrivingModeEnabled) StatusGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                // Simulator Control Lab Button
                                IconButton(
                                    onClick = { viewModel.toggleSimulatorSheet(true) },
                                    modifier = Modifier.testTag("topbar_simulator_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Tune,
                                        contentDescription = "Open Simulator Lab",
                                        tint = ChevyGoldBright
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface,
                                titleContentColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.testTag("bottom_nav_bar"),
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp
                        ) {
                            ChevyDestination.values().forEach { destination ->
                                val selected = currentDestination == destination

                                // Adapt Energy icon if EV is selected
                                val destIcon = if (destination == ChevyDestination.ENERGY && currentVehicle?.powertrainType == PowertrainType.EV) {
                                    Icons.Default.Bolt
                                } else {
                                    destination.icon
                                }

                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { currentDestination = destination },
                                    icon = {
                                        Icon(
                                            imageVector = destIcon,
                                            contentDescription = destination.label,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = destination.label,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                                fontSize = 11.sp
                                            )
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = ChevyOnyx,
                                        selectedTextColor = ChevyGoldBright,
                                        indicatorColor = ChevyGoldBright,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    modifier = Modifier.testTag(destination.testTag)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        Crossfade(targetState = currentDestination, label = "screen_crossfade") { dest ->
                            when (dest) {
                                ChevyDestination.GARAGE -> GarageScreen(viewModel = viewModel)
                                ChevyDestination.JOURNEYS -> JourneysScreen(viewModel = viewModel)
                                ChevyDestination.ENERGY -> EnergyScreen(viewModel = viewModel)
                                ChevyDestination.CARE -> CareScreen(viewModel = viewModel)
                                ChevyDestination.ACCOUNT -> AccountScreen(viewModel = viewModel)
                            }
                        }
                    }
                }

                // In-Progress Remote Command Modal
                activeCmdState?.let { activeState ->
                    if (activeState.showModal) {
                        CommandProgressModal(
                            command = activeState.command,
                            onDismiss = { viewModel.dismissCommandModal() }
                        )
                    }
                }

                // Consequential Action Confirmation Dialog (Remote Start, Unlock)
                confirmState?.let { confState ->
                    ConsequentialConfirmDialog(
                        state = confState,
                        onConfirm = { pin -> viewModel.confirmConsequentialAction(pin) },
                        onDismiss = { viewModel.dismissConfirmation() }
                    )
                }

                // Interactive Simulator Lab Bottom Sheet
                if (isSimulatorOpen) {
                    SimulationControlSheet(
                        viewModel = viewModel,
                        vehicle = currentVehicle,
                        telemetry = telemetry,
                        onDismiss = { viewModel.toggleSimulatorSheet(false) }
                    )
                }
            }
        }
    }
}
