package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionState
import com.example.data.model.PowertrainType
import com.example.data.model.Vehicle
import com.example.data.model.VehicleTelemetry
import com.example.ui.ChevyViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimulationControlSheet(
    viewModel: ChevyViewModel,
    vehicle: Vehicle?,
    telemetry: VehicleTelemetry?,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = { BottomSheetDefaults.DragHandle(color = ChevyGoldBright) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
                .testTag("simulation_control_sheet")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "SIMULATOR LAB & TEST HARNESS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = ChevyGoldBright
                    )
                    Text(
                        text = "Vehicle State Injection",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                DemonstrationPill()
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Simulate real-world conditions like loss of cellular signal, low tyre pressure, stale telemetry, command failures, and charging progress.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Switch: Force Command Failure
            SimulationToggleItem(
                title = "Force Command Failure",
                subtitle = "Causes next remote command to fail with precondition/interlock error",
                isChecked = viewModel.forceCommandFailure,
                onCheckedChange = { viewModel.forceCommandFailure = it }
            )

            Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

            // Switch: Simulate Offline Vehicle
            val isOffline = telemetry?.connectionState == ConnectionState.OFFLINE
            SimulationToggleItem(
                title = "Simulate Vehicle Offline",
                subtitle = "Cuts OnStar cellular telemetry uplink",
                isChecked = isOffline,
                onCheckedChange = { viewModel.simulateToggleOffline(it) }
            )

            Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

            // Switch: Stale Telemetry
            val isStale = telemetry?.isStale == true
            SimulationToggleItem(
                title = "Stale Telemetry (>6 hours)",
                subtitle = "Simulates vehicle parked underground without telemetry updates",
                isChecked = isStale,
                onCheckedChange = { viewModel.simulateToggleStale(it) }
            )

            Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

            // Switch: Low Tyre Pressure Alert
            val hasLowTyre = telemetry?.hasLowTyreAlert == true
            SimulationToggleItem(
                title = "Low Tyre Pressure Alert",
                subtitle = "Drops Left Front pressure to 26.5 PSI and triggers warning",
                isChecked = hasLowTyre,
                onCheckedChange = { viewModel.simulateToggleTyreAlert(it) }
            )

            // EV specific simulation
            if (vehicle?.powertrainType == PowertrainType.EV) {
                Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "EV Charging Progress",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Fast-forward Ultium battery charge state by +10%",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { viewModel.simulateChargingDelta(10f) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = StatusBlue,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+10% SoC")
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Quick Refresh Button
            OutlinedButton(
                onClick = {
                    viewModel.refreshTelemetry()
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, ChevyGoldBright)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = ChevyGoldBright)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Force Fresh Telemetry Sync", color = ChevyGoldBright)
            }
        }
    }
}

@Composable
private fun SimulationToggleItem(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ChevyGoldBright,
                checkedTrackColor = ChevyGoldContainerDark,
                uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        )
    }
}
