package com.example.domain

import com.example.data.model.*
import java.util.Locale

object UnitConverter {

    fun formatDistance(miles: Double, unit: DistanceUnit): String {
        return when (unit) {
            DistanceUnit.MILES -> String.format(Locale.US, "%.1f mi", miles)
            DistanceUnit.KILOMETERS -> String.format(Locale.US, "%.1f km", miles * 1.60934)
        }
    }

    fun formatOdometer(miles: Double, unit: DistanceUnit): String {
        return when (unit) {
            DistanceUnit.MILES -> String.format(Locale.US, "%,.0f mi", miles)
            DistanceUnit.KILOMETERS -> String.format(Locale.US, "%,.0f km", miles * 1.60934)
        }
    }

    fun formatRange(miles: Double, unit: DistanceUnit): String {
        return when (unit) {
            DistanceUnit.MILES -> String.format(Locale.US, "%.0f mi", miles)
            DistanceUnit.KILOMETERS -> String.format(Locale.US, "%.0f km", miles * 1.60934)
        }
    }

    fun formatTemperature(tempF: Int, unit: TemperatureUnit): String {
        return when (unit) {
            TemperatureUnit.FAHRENHEIT -> "$tempF°F"
            TemperatureUnit.CELSIUS -> {
                val c = Math.round((tempF - 32) * 5.0 / 9.0).toInt()
                "$c°C"
            }
        }
    }

    fun formatPressure(psi: Double, unit: PressureUnit): String {
        return when (unit) {
            PressureUnit.PSI -> String.format(Locale.US, "%.1f psi", psi)
            PressureUnit.BAR -> String.format(Locale.US, "%.2f bar", psi * 0.0689476)
            PressureUnit.KPA -> String.format(Locale.US, "%.0f kPa", psi * 6.89476)
        }
    }

    fun formatCurrency(amount: Double, currency: CurrencyUnit): String {
        return String.format(Locale.US, "%s%.2f", currency.symbol, amount)
    }

    fun formatFuelEconomy(mpg: Double, unit: FuelEconomyUnit): String {
        return when (unit) {
            FuelEconomyUnit.MPG_US -> String.format(Locale.US, "%.1f mpg (US)", mpg)
            FuelEconomyUnit.MPG_UK -> String.format(Locale.US, "%.1f mpg (UK)", mpg * 1.20095)
            FuelEconomyUnit.L_100KM -> {
                if (mpg <= 0) "N/A" else String.format(Locale.US, "%.1f L/100km", 235.215 / mpg)
            }
            FuelEconomyUnit.KM_L -> String.format(Locale.US, "%.1f km/L", mpg * 0.425144)
        }
    }

    fun formatVolume(gallons: Double, unit: DistanceUnit): String {
        return when (unit) {
            DistanceUnit.MILES -> String.format(Locale.US, "%.1f gal", gallons)
            DistanceUnit.KILOMETERS -> String.format(Locale.US, "%.1f L", gallons * 3.78541)
        }
    }
}
