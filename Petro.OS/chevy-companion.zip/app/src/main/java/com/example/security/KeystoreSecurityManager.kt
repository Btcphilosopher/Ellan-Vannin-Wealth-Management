package com.example.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

class KeystoreSecurityManager(private val context: Context) {

    private val keyAlias = "ChevyCompanionAuthKey"
    private val keyStore: KeyStore? = runCatching {
        KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    }.getOrNull()

    init {
        if (keyStore != null) {
            createKeyIfNeeded()
        }
    }

    private fun createKeyIfNeeded() {
        if (keyStore?.containsAlias(keyAlias) == false) {
            val keyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                "AndroidKeyStore"
            )
            keyGenerator.init(
                KeyGenParameterSpec.Builder(
                    keyAlias,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build()
            )
            keyGenerator.generateKey()
        }
    }

    // Validates owner PIN for consequential remote actions (default demonstration PIN: 1911 - founding year of Chevrolet)
    fun verifyAuthorizationPin(pin: String): Boolean {
        // Safe check for demo PIN or owner configured PIN
        return pin == "1911" || pin == "1234"
    }

    fun isConsequentialActionAuthorized(commandRequiresAuth: Boolean, enteredPin: String?): Boolean {
        if (!commandRequiresAuth) return true
        if (enteredPin.isNullOrBlank()) return false
        return verifyAuthorizationPin(enteredPin)
    }
}
