package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.ChevyViewModel
import com.example.ui.components.DemonstrationPill
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AccountScreen(
    viewModel: ChevyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentVehicle by viewModel.currentVehicle.collectAsState()
    val documents by viewModel.vehicleDocuments.collectAsState()
    val householdMembers by viewModel.householdMembers.collectAsState()
    val prefs by viewModel.userPreferences.collectAsState()

    var showUnitSettingsDialog by remember { mutableStateOf(false) }
    var showExportConfirmDialog by remember { mutableStateOf(false) }
    var showAddDocDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("account_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Owner Profile Card
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                tonalElevation = 4.dp
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .background(ChevyGoldContainerDark, CircleShape)
                                .border(1.5.dp, ChevyGoldBright, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("TA", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = ChevyGoldBright)
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text("Thomas Anderson", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                            Text("tom@ahyx.org • (313) 555-0144", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("MYCHEVROLET REWARDS", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("18,450 Points", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = ChevyGoldBright))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ONSTAR SUBSCRIPTION", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Connected Access", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Simulator Lab Shortcut Button
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.toggleSimulatorSheet(true) },
                shape = RoundedCornerShape(16.dp),
                color = ChevyGoldContainerDark,
                border = BorderStroke(1.5.dp, ChevyGoldBright)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, contentDescription = null, tint = ChevyGoldBright, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("SIMULATOR CONTROL LAB", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = ChevyGoldBright)
                            Text("Inject tyre alerts, offline state, or fast-forward charging", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = ChevyGoldBright, modifier = Modifier.size(16.dp))
                }
            }
        }

        // Unit & Regional Preferences
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("REGIONAL UNITS & DISPLAY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = ChevyGoldBright)
                            Text("Configure US, UK, or Metric preferences", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        TextButton(onClick = { showUnitSettingsDialog = true }) {
                            Text("Edit Units", color = ChevyGoldBright, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Distance: ${prefs.distanceUnit.name.lowercase().capitalize()} • Temperature: ${prefs.temperatureUnit.name.lowercase().capitalize()} • Pressure: ${prefs.pressureUnit.name}", style = MaterialTheme.typography.bodyMedium)
                    Text("Currency: ${prefs.currencyUnit.name} (${prefs.currencyUnit.symbol}) • Economy: ${prefs.fuelEconomyUnit.name}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        // Vehicle Documents & Insurance Cards
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("VEHICLE DOCUMENTS & INSURANCE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = ChevyGoldBright)
                        TextButton(onClick = { showAddDocDialog = true }) {
                            Text("Add Doc", color = ChevyGoldBright)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy", Locale.getDefault()) }
                    documents.forEach { doc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(doc.title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Text("${doc.issuerName} • #${doc.policyOrDocNumber}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("Expires ${dateFormat.format(Date(doc.expirationDateMs))}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    }
                }
            }
        }

        // Household Vehicle Sharing
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("HOUSEHOLD VEHICLE SHARING", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = ChevyGoldBright)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Sharing app information is distinct from granting actual vehicle access. Real digital-key sharing requires an authorized manufacturer mobile wallet key integration.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    householdMembers.forEach { member ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(member.fullName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                                Text("${member.relationship} • ${member.accessScope}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(
                                if (member.isLocationSharingGranted) "Location Shared" else "No Location",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (member.isLocationSharingGranted) StatusGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Privacy & Security Disclosure
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PRIVACY & DATA RESIDENCY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "All vehicle profiles, trip histories, and service receipts reside in your device's encrypted Room database. Consequential remote commands are guarded with Android Keystore. Real vehicle connections are disabled in this demonstration build.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Data Export & Reset Controls
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        Toast.makeText(context, "Exported 4 trips, 3 service records, and 2 refuel logs to Downloads.", Toast.LENGTH_LONG).show()
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp), tint = ChevyGoldBright)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Export Data")
                }

                Button(
                    onClick = { showExportConfirmDialog = true },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = StatusRed)
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Reset Demo Data")
                }
            }
        }
    }

    if (showUnitSettingsDialog) {
        UnitSettingsDialog(
            currentPrefs = prefs,
            onDismiss = { showUnitSettingsDialog = false },
            onSave = { updated ->
                viewModel.updatePreferences(updated)
                showUnitSettingsDialog = false
            }
        )
    }

    if (showExportConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showExportConfirmDialog = false },
            title = { Text("Reset Demonstration Data?") },
            text = { Text("This will restore default vehicle profiles for Silverado 1500, Tahoe, and Blazer EV, along with initial demonstration logs.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.repository.simulator.forceCommandFailure = false
                        viewModel.refreshTelemetry()
                        showExportConfirmDialog = false
                        Toast.makeText(context, "Demonstration data reset to initial factory specs.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRed, contentColor = MaterialTheme.colorScheme.onError)
                ) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportConfirmDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showAddDocDialog) {
        AlertDialog(
            onDismissRequest = { showAddDocDialog = false },
            title = { Text("Document Recorded") },
            text = { Text("Document record saved to encrypted local SQLite repository.") },
            confirmButton = {
                Button(
                    onClick = { showAddDocDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
                ) { Text("OK") }
            }
        )
    }
}

@Composable
private fun UnitSettingsDialog(
    currentPrefs: UserPreferences,
    onDismiss: () -> Unit,
    onSave: (UserPreferences) -> Unit
) {
    var distUnit by remember { mutableStateOf(currentPrefs.distanceUnit) }
    var tempUnit by remember { mutableStateOf(currentPrefs.temperatureUnit) }
    var pressUnit by remember { mutableStateOf(currentPrefs.pressureUnit) }
    var currUnit by remember { mutableStateOf(currentPrefs.currencyUnit) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Unit & Measurement Preferences") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Distance System", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = distUnit == DistanceUnit.MILES, onClick = { distUnit = DistanceUnit.MILES }, label = { Text("Miles (US/UK)") })
                    FilterChip(selected = distUnit == DistanceUnit.KILOMETERS, onClick = { distUnit = DistanceUnit.KILOMETERS }, label = { Text("Kilometers (Metric)") })
                }

                Text("Temperature", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tempUnit == TemperatureUnit.FAHRENHEIT, onClick = { tempUnit = TemperatureUnit.FAHRENHEIT }, label = { Text("Fahrenheit (°F)") })
                    FilterChip(selected = tempUnit == TemperatureUnit.CELSIUS, onClick = { tempUnit = TemperatureUnit.CELSIUS }, label = { Text("Celsius (°C)") })
                }

                Text("Tyre Pressure", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = pressUnit == PressureUnit.PSI, onClick = { pressUnit = PressureUnit.PSI }, label = { Text("PSI") })
                    FilterChip(selected = pressUnit == PressureUnit.BAR, onClick = { pressUnit = PressureUnit.BAR }, label = { Text("Bar") })
                    FilterChip(selected = pressUnit == PressureUnit.KPA, onClick = { pressUnit = PressureUnit.KPA }, label = { Text("kPa") })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(currentPrefs.copy(distanceUnit = distUnit, temperatureUnit = tempUnit, pressureUnit = pressUnit, currencyUnit = currUnit))
                },
                colors = ButtonDefaults.buttonColors(containerColor = ChevyGoldBright, contentColor = ChevyOnyx)
            ) {
                Text("Apply Preferences", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
