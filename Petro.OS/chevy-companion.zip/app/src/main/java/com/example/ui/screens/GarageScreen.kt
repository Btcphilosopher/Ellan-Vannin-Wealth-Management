package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.domain.UnitConverter
import com.example.ui.ChevyViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun GarageScreen(
    viewModel: ChevyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allVehicles by viewModel.allVehicles.collectAsState()
    val currentVehicle by viewModel.currentVehicle.collectAsState()
    val telemetry by viewModel.currentTelemetry.collectAsState()
    val prefs by viewModel.userPreferences.collectAsState()
    val recentCommands by viewModel.recentCommands.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("garage_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Vehicle Switcher Pills
        item {
            Text(
                text = "YOUR CHEVROLET FLEET",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                ),
                color = ChevyGoldBright
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(allVehicles) { veh ->
                    val isSelected = veh.id == currentVehicle?.id
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectVehicle(veh.id) },
                        label = {
                            Text(
                                text = "${veh.model} (${veh.nickname})",
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = if (veh.powertrainType == PowertrainType.EV) Icons.Default.Bolt else Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = if (isSelected) ChevyGoldBright else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ChevyGoldContainerDark,
                            selectedLabelColor = ChevyGoldBright,
                            selectedLeadingIconColor = ChevyGoldBright
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) ChevyGoldBright else MaterialTheme.colorScheme.outline
                        )
                    )
                }
            }
        }

        // 2. Hero Vehicle Card with Connection Status
        item {
            val vehicle = currentVehicle
            if (vehicle != null && telemetry != null) {
                HeroVehicleCard(
                    vehicle = vehicle,
                    telemetry = telemetry!!,
                    preferences = prefs,
                    onRefresh = { viewModel.refreshTelemetry() }
                )
            }
        }

        // 3. Active Alert Banner if any
        item {
            telemetry?.let { tel ->
                if (tel.hasLowTyreAlert) {
                    AlertBannerCard(
                        title = "Low Tyre Pressure Detected",
                        message = "Left Front tyre pressure is 26.5 PSI (Recommended: 35.0 PSI). Refill tyre before extended highway driving.",
                        severity = AlertSeverity.WARNING,
                        onAction = { viewModel.simulateToggleTyreAlert(false) },
                        actionLabel = "Simulate Refill"
                    )
                }
            }
        }

        // 4. Glove-Friendly Remote Vehicle Controls
        item {
            val vehicle = currentVehicle
            val tel = telemetry
            if (vehicle != null && tel != null) {
                VehicleControlsCard(
                    vehicle = vehicle,
                    telemetry = tel,
                    onCommand = { cmdType, param -> viewModel.requestCommand(cmdType, param) }
                )
            }
        }

        // 5. Tyre Pressure Monitor Card
        item {
            telemetry?.let { tel ->
                TyrePressureCard(
                    telemetry = tel,
                    preferences = prefs,
                    onQuickRefill = { viewModel.simulateToggleTyreAlert(false) }
                )
            }
        }

        // 6. Last Parked Location Card
        item {
            telemetry?.let { tel ->
                LastParkedCard(
                    telemetry = tel,
                    onNavigate = {
                        val gmmIntentUri = Uri.parse("geo:${tel.lastParkedLatitude},${tel.lastParkedLongitude}?q=${Uri.encode(tel.lastParkedAddress)}")
                        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                        if (mapIntent.resolveActivity(context.packageManager) != null) {
                            context.startActivity(mapIntent)
                        } else {
                            // Fallback to web maps
                            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=${tel.lastParkedLatitude},${tel.lastParkedLongitude}"))
                            context.startActivity(webIntent)
                        }
                    }
                )
            }
        }

        // 7. Vehicle Specifications & VIN Privacy Card
        item {
            currentVehicle?.let { vehicle ->
                VehicleSpecsCard(
                    vehicle = vehicle,
                    maskVin = prefs.maskVinInUi,
                    onToggleMaskVin = { viewModel.toggleMaskVin() }
                )
            }
        }

        // 8. Recent Commands Audit History
        item {
            CommandHistoryCard(commands = recentCommands.take(4))
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun HeroVehicleCard(
    vehicle: Vehicle,
    telemetry: VehicleTelemetry,
    preferences: UserPreferences,
    onRefresh: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_vehicle_card"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header with Nickname and Connection Badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = vehicle.nickname,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${vehicle.modelYear} ${vehicle.model} • ${vehicle.trim}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    ConnectionStatusBadge(
                        connectionState = telemetry.connectionState,
                        isStale = telemetry.isStale,
                        lastUpdatedMs = telemetry.lastUpdatedEpochMs
                    )
                    IconButton(onClick = onRefresh, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Telemetry",
                            tint = ChevyGoldBright,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Hero Artwork
            val drawableId = when (vehicle.heroDrawableName) {
                "img_vehicle_silverado" -> R.drawable.img_vehicle_silverado
                "img_vehicle_tahoe" -> R.drawable.img_vehicle_tahoe
                "img_vehicle_blazer_ev" -> R.drawable.img_vehicle_blazer_ev
                else -> R.drawable.img_vehicle_silverado
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(Color(0xFF0C0E11))
            ) {
                Image(
                    painter = painterResource(id = drawableId),
                    contentDescription = "${vehicle.model} Hero Photo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )

                // Restrained Gold Chevy Bowtie Watermark in top left corner
                Image(
                    painter = painterResource(id = R.drawable.img_chevy_bowtie),
                    contentDescription = null,
                    modifier = Modifier
                        .padding(12.dp)
                        .size(32.dp)
                        .align(Alignment.TopStart)
                        .clip(CircleShape)
                )

                // Demonstrative data badge
                DemonstrationPill(
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.BottomEnd)
                )
            }

            // Primary Telemetry Gauges Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Metric 1: Fuel or Battery
                if (vehicle.powertrainType == PowertrainType.EV) {
                    TelemetryMetric(
                        label = "ULTIUM BATTERY",
                        value = "${telemetry.batterySocPercent.toInt()}%",
                        subtext = if (telemetry.isCharging) "Charging (${telemetry.chargingPowerKw}kW)" else "Ready",
                        highlightColor = if (telemetry.isCharging) StatusBlue else StatusGreen,
                        icon = Icons.Default.ElectricBolt
                    )
                } else {
                    TelemetryMetric(
                        label = "FUEL LEVEL",
                        value = "${telemetry.fuelLevelPercent.toInt()}%",
                        subtext = "Tank approx. ${String.format(Locale.US, "%.1f", vehicle.fuelTankCapacityGal * telemetry.fuelLevelPercent / 100)} gal",
                        highlightColor = if (telemetry.fuelLevelPercent < 20f) StatusAmber else ChevyGoldBright,
                        icon = Icons.Default.LocalGasStation
                    )
                }

                Divider(
                    modifier = Modifier
                        .height(44.dp)
                        .width(1.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                )

                // Metric 2: Estimated Range
                TelemetryMetric(
                    label = "EST. RANGE",
                    value = UnitConverter.formatRange(telemetry.estimatedRangeMiles, preferences.distanceUnit),
                    subtext = "Based on recent driving",
                    highlightColor = MaterialTheme.colorScheme.onSurface,
                    icon = Icons.Default.Timeline
                )

                Divider(
                    modifier = Modifier
                        .height(44.dp)
                        .width(1.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                )

                // Metric 3: Security & Climate
                TelemetryMetric(
                    label = "VEHICLE STATUS",
                    value = if (telemetry.isLocked) "Locked" else "Unlocked",
                    subtext = if (telemetry.isRemoteStarted) "Engine/Climate On" else "All Doors Closed",
                    highlightColor = if (telemetry.isLocked) StatusGreen else StatusAmber,
                    icon = if (telemetry.isLocked) Icons.Default.Lock else Icons.Default.LockOpen
                )
            }
        }
    }
}

@Composable
private fun TelemetryMetric(
    label: String,
    value: String,
    subtext: String,
    highlightColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Column(horizontalAlignment = Alignment.Start) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = highlightColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, letterSpacing = 0.5.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = highlightColor
        )
        Text(
            text = subtext,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun VehicleControlsCard(
    vehicle: Vehicle,
    telemetry: VehicleTelemetry,
    onCommand: (CommandType, String?) -> Unit
) {
    val caps = vehicle.getCapabilities()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("vehicle_controls_card"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "REMOTE VEHICLE CONTROLS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    ),
                    color = ChevyGoldBright
                )
                Text(
                    text = "Glove-Friendly Touch Area",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Primary Row 1: Lock / Unlock & Remote Start
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (caps.contains(VehicleCapability.REMOTE_LOCK)) {
                    val isLocked = telemetry.isLocked
                    GloveFriendlyButton(
                        text = if (isLocked) "Unlock Doors" else "Lock Doors",
                        icon = if (isLocked) Icons.Default.LockOpen else Icons.Default.Lock,
                        onClick = {
                            if (isLocked) onCommand(CommandType.UNLOCK, null)
                            else onCommand(CommandType.LOCK, null)
                        },
                        isActive = isLocked,
                        accentColor = if (isLocked) StatusGreen else StatusAmber,
                        modifier = Modifier.weight(1f),
                        testTag = "lock_unlock_button"
                    )
                }

                if (caps.contains(VehicleCapability.REMOTE_START)) {
                    val isRunning = telemetry.isRemoteStarted
                    GloveFriendlyButton(
                        text = if (isRunning) "Stop Engine" else "Remote Start",
                        icon = if (isRunning) Icons.Default.StopCircle else Icons.Default.PlayCircle,
                        onClick = {
                            if (isRunning) onCommand(CommandType.REMOTE_STOP, null)
                            else onCommand(CommandType.REMOTE_START, null)
                        },
                        isActive = isRunning,
                        accentColor = if (isRunning) StatusRed else ChevyGoldBright,
                        modifier = Modifier.weight(1f),
                        testTag = "remote_start_button"
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Primary Row 2: Precondition Cabin & Horn/Lights
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (caps.contains(VehicleCapability.CABIN_PRECONDITION)) {
                    val isPrecon = telemetry.isPreconditioning
                    GloveFriendlyButton(
                        text = if (isPrecon) "Stop Climate" else "Precondition",
                        icon = Icons.Default.AcUnit,
                        onClick = {
                            if (isPrecon) onCommand(CommandType.PRECONDITION_STOP, null)
                            else onCommand(CommandType.PRECONDITION_START, null)
                        },
                        isActive = isPrecon,
                        accentColor = StatusBlue,
                        modifier = Modifier.weight(1f),
                        testTag = "precondition_button"
                    )
                }

                if (caps.contains(VehicleCapability.HORN_LIGHTS)) {
                    GloveFriendlyButton(
                        text = "Horn & Lights",
                        icon = Icons.Default.NotificationsActive,
                        onClick = { onCommand(CommandType.HORN_LIGHTS, null) },
                        modifier = Modifier.weight(1f),
                        testTag = "horn_lights_button"
                    )
                }
            }

            // EV Specific Charging Controls
            if (caps.contains(VehicleCapability.CHARGING_MANAGEMENT)) {
                Spacer(modifier = Modifier.height(10.dp))
                val isCharging = telemetry.isCharging
                GloveFriendlyButton(
                    text = if (isCharging) "Stop Charging" else "Start EV Charging",
                    icon = Icons.Default.Bolt,
                    onClick = {
                        if (isCharging) onCommand(CommandType.CHARGING_STOP, null)
                        else onCommand(CommandType.CHARGING_START, null)
                    },
                    isActive = isCharging,
                    accentColor = StatusBlue,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "charging_control_button"
                )
            }
        }
    }
}

@Composable
private fun TyrePressureCard(
    telemetry: VehicleTelemetry,
    preferences: UserPreferences,
    onQuickRefill: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tyre_pressure_card"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TYRE PRESSURE MONITORING (TPMS)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp
                        ),
                        color = ChevyGoldBright
                    )
                    Text(
                        text = "Target Cold: ${UnitConverter.formatPressure(35.0, preferences.pressureUnit)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (telemetry.hasLowTyreAlert) {
                    TextButton(onClick = onQuickRefill) {
                        Text("Reset Alert", color = ChevyGoldBright, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4-corner grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                TyreItem(
                    position = "FRONT LEFT",
                    psi = telemetry.tyrePressureFrontLeftPsi,
                    isLow = telemetry.hasLowTyreAlert,
                    unit = preferences.pressureUnit
                )
                TyreItem(
                    position = "FRONT RIGHT",
                    psi = telemetry.tyrePressureFrontRightPsi,
                    isLow = false,
                    unit = preferences.pressureUnit
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                TyreItem(
                    position = "REAR LEFT",
                    psi = telemetry.tyrePressureRearLeftPsi,
                    isLow = false,
                    unit = preferences.pressureUnit
                )
                TyreItem(
                    position = "REAR RIGHT",
                    psi = telemetry.tyrePressureRearRightPsi,
                    isLow = false,
                    unit = preferences.pressureUnit
                )
            }
        }
    }
}

@Composable
private fun TyreItem(
    position: String,
    psi: Double,
    isLow: Boolean,
    unit: PressureUnit
) {
    Surface(
        modifier = Modifier.width(140.dp),
        shape = RoundedCornerShape(12.dp),
        color = if (isLow) StatusRedContainer.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, if (isLow) StatusRed else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = position,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                color = if (isLow) StatusRed else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = UnitConverter.formatPressure(psi, unit),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = if (isLow) StatusRed else MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = if (isLow) "LOW PRESSURE" else "NORMAL",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                color = if (isLow) StatusRed else StatusGreen
            )
        }
    }
}

@Composable
private fun LastParkedCard(
    telemetry: VehicleTelemetry,
    onNavigate: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("last_parked_card"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "LAST PARKED LOCATION",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    ),
                    color = ChevyGoldBright
                )
                Text(
                    text = "GPS Telemetry",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.Top) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = StatusRed,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = telemetry.lastParkedAddress,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (telemetry.parkingNotes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Note: ${telemetry.parkingNotes}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onNavigate,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("navigate_to_car_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Icon(Icons.Default.Navigation, contentDescription = null, modifier = Modifier.size(16.dp), tint = ChevyGoldBright)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Open Navigation to Vehicle", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun VehicleSpecsCard(
    vehicle: Vehicle,
    maskVin: Boolean,
    onToggleMaskVin: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("vehicle_specs_card"),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "VEHICLE SPECIFICATIONS & IDENTITY",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                ),
                color = ChevyGoldBright
            )

            Spacer(modifier = Modifier.height(12.dp))

            SpecRow("Model & Year", "${vehicle.modelYear} Chevrolet ${vehicle.model}")
            SpecRow("Trim & Configuration", vehicle.trim)
            SpecRow("Exterior Color", vehicle.exteriorColorName)
            SpecRow("Powertrain", when (vehicle.powertrainType) {
                PowertrainType.EV -> "Ultium Electric Platform (${vehicle.batteryCapacityKWh} kWh)"
                PowertrainType.ICE_PETROL -> "Gasoline V8 EcoTec3 (${vehicle.fuelTankCapacityGal} gal)"
                PowertrainType.ICE_DIESEL -> "Duramax Turbo-Diesel"
            })
            SpecRow("Registration Plate", vehicle.registrationPlate)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "VIN",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (maskVin) vehicle.getMaskedVin() else vehicle.vin,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onToggleMaskVin, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (maskVin) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle VIN Visibility",
                            tint = ChevyGoldBright,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "WARRANTY COVERAGE",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = vehicle.warrantySummary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun AlertBannerCard(
    title: String,
    message: String,
    severity: AlertSeverity,
    onAction: () -> Unit,
    actionLabel: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = StatusAmberContainer.copy(alpha = 0.2f),
        border = BorderStroke(1.dp, StatusAmber)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = StatusAmber, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = StatusAmber)
                Text(text = message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
            }
            TextButton(onClick = onAction) {
                Text(actionLabel, color = ChevyGoldBright, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun CommandHistoryCard(commands: List<RemoteCommand>) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "RECENT REMOTE COMMAND AUDIT",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                ),
                color = ChevyGoldBright
            )
            Spacer(modifier = Modifier.height(10.dp))

            if (commands.isEmpty()) {
                Text(
                    text = "No remote commands issued in current session.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                val dateFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
                commands.forEach { cmd ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = cmd.getDisplayName(),
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${dateFormat.format(Date(cmd.initiatedTimestampMs))} • Token: ${cmd.clientToken.take(6)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        val (statusText, statusColor) = when (cmd.state) {
                            CommandState.CONFIRMED -> "CONFIRMED" to StatusGreen
                            CommandState.FAILED -> "FAILED" to StatusRed
                            CommandState.PENDING -> "PENDING" to ChevyGoldBright
                            CommandState.ACCEPTED -> "ACCEPTED" to StatusBlue
                            CommandState.EXPIRED -> "EXPIRED" to MaterialTheme.colorScheme.onSurfaceVariant
                        }

                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = statusColor
                        )
                    }
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                }
            }
        }
    }
}
