package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Chevrolet Signature Colors
val ChevyGold = Color(0xFFD4AF37)
val ChevyGoldBright = Color(0xFFE5B239)
val ChevyGoldDark = Color(0xFFA17D16)
val ChevyGoldContainerDark = Color(0xFF332709)
val ChevyGoldContainerLight = Color(0xFFFBEBC5)

// Graphite & Dark Surfaces
val ChevyOnyx = Color(0xFF0E1013)
val ChevyGraphiteDark = Color(0xFF16181D)
val ChevySurfaceCardDark = Color(0xFF1E222A)
val ChevySurfaceRaisedDark = Color(0xFF282D38)

// Brushed Metal & Border Accents
val ChevyMetalBorderDark = Color(0xFF353C49)
val ChevyMetalHighlight = Color(0xFF8E95A5)
val ChevyMetalMuted = Color(0xFF5E6573)

// Light Theme Surfaces
val ChevyLightBg = Color(0xFFF4F5F7)
val ChevyLightSurface = Color(0xFFFFFFFF)
val ChevyLightSurfaceRaised = Color(0xFFE9ECF1)
val ChevyLightBorder = Color(0xFFD3D8E2)

// Automotive Status Indicators
val StatusGreen = Color(0xFF22C55E)
val StatusGreenContainer = Color(0xFF14532D)
val StatusAmber = Color(0xFFF59E0B)
val StatusAmberContainer = Color(0xFF78350F)
val StatusRed = Color(0xFFEF4444)
val StatusRedContainer = Color(0xFF7F1D1D)
val StatusBlue = Color(0xFF3B82F6)
val StatusBlueContainer = Color(0xFF1E3A8A)

// Typography Warm Whites and Inks
val TextPrimaryDark = Color(0xFFF5F6F8)
val TextSecondaryDark = Color(0xFFA2A8B4)
val TextMutedDark = Color(0xFF6F7684)

val TextPrimaryLight = Color(0xFF111317)
val TextSecondaryLight = Color(0xFF4B5565)
val TextMutedLight = Color(0xFF8590A2)
