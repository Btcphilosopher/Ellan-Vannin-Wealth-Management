package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class TripDataSource {
    VEHICLE_TELEMETRY,
    PHONE_DERIVED_ESTIMATE
}

@Entity(tableName = "journey_trips")
data class JourneyTrip(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val title: String,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val startAddress: String,
    val endAddress: String,
    val distanceMiles: Double,
    val durationMinutes: Int,
    val fuelConsumedGal: Double = 0.0,
    val electricityConsumedKWh: Double = 0.0,
    val estimatedCostUsd: Double,
    val dataSource: TripDataSource,
    val isFavorite: Boolean = false,
    val notes: String = ""
)

@Entity(tableName = "favorite_destinations")
data class FavoriteDestination(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val address: String,
    val category: String, // Home, Work, Charger, Fuel, Dealer
    val latitude: Double,
    val longitude: Double
)
