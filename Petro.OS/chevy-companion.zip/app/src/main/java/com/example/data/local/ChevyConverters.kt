package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.*

class ChevyConverters {
    @TypeConverter
    fun fromPowertrainType(value: PowertrainType?): String? = value?.name

    @TypeConverter
    fun toPowertrainType(value: String?): PowertrainType? =
        value?.let { runCatching { PowertrainType.valueOf(it) }.getOrDefault(PowertrainType.ICE_PETROL) }

    @TypeConverter
    fun fromConnectionState(value: ConnectionState?): String? = value?.name

    @TypeConverter
    fun toConnectionState(value: String?): ConnectionState? =
        value?.let { runCatching { ConnectionState.valueOf(it) }.getOrDefault(ConnectionState.SIMULATED) }

    @TypeConverter
    fun fromCommandState(value: CommandState?): String? = value?.name

    @TypeConverter
    fun toCommandState(value: String?): CommandState? =
        value?.let { runCatching { CommandState.valueOf(it) }.getOrDefault(CommandState.PENDING) }

    @TypeConverter
    fun fromCommandType(value: CommandType?): String? = value?.name

    @TypeConverter
    fun toCommandType(value: String?): CommandType? =
        value?.let { runCatching { CommandType.valueOf(it) }.getOrDefault(CommandType.LOCK) }

    @TypeConverter
    fun fromTripDataSource(value: TripDataSource?): String? = value?.name

    @TypeConverter
    fun toTripDataSource(value: String?): TripDataSource? =
        value?.let { runCatching { TripDataSource.valueOf(it) }.getOrDefault(TripDataSource.VEHICLE_TELEMETRY) }
}
