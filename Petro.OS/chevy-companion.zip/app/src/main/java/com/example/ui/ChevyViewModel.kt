package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ChevyCompanionDatabase
import com.example.data.local.DefaultDemonstrationData
import com.example.data.local.PreferencesRepository
import com.example.data.model.*
import com.example.data.repository.VehicleRepository
import com.example.network.VehicleSimulator
import com.example.security.KeystoreSecurityManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ActiveCommandUiState(
    val command: RemoteCommand,
    val showModal: Boolean = true
)

data class ConsequentialConfirmationState(
    val commandType: CommandType,
    val targetParameter: String? = null,
    val title: String,
    val warningMessage: String,
    val requiresPin: Boolean = true
)

class ChevyViewModel(application: Application) : AndroidViewModel(application) {

    private val database = ChevyCompanionDatabase.getDatabase(application)
    private val preferencesRepository = PreferencesRepository(application)
    private val simulator = VehicleSimulator(database, viewModelScope)
    private val securityManager = KeystoreSecurityManager(application)

    val repository = VehicleRepository(
        database = database,
        preferencesRepository = preferencesRepository,
        simulator = simulator,
        securityManager = securityManager
    )

    val allVehicles: StateFlow<List<Vehicle>> = repository.allVehicles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedVehicleId: StateFlow<String?> = repository.selectedVehicleId
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val userPreferences: StateFlow<UserPreferences> = repository.userPreferences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    // Active vehicle
    val currentVehicle: StateFlow<Vehicle?> = combine(allVehicles, selectedVehicleId) { vehicles, selectedId ->
        if (vehicles.isEmpty()) null
        else vehicles.find { it.id == selectedId } ?: vehicles.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Current telemetry
    val currentTelemetry: StateFlow<VehicleTelemetry?> = currentVehicle.flatMapLatest { vehicle ->
        if (vehicle != null) repository.getTelemetry(vehicle.id) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Recent remote commands
    val recentCommands: StateFlow<List<RemoteCommand>> = currentVehicle.flatMapLatest { vehicle ->
        if (vehicle != null) repository.getCommands(vehicle.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Trips
    val trips: StateFlow<List<JourneyTrip>> = currentVehicle.flatMapLatest { vehicle ->
        if (vehicle != null) repository.getTrips(vehicle.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Energy
    val refuelLogs: StateFlow<List<RefuelLog>> = currentVehicle.flatMapLatest { vehicle ->
        if (vehicle != null) repository.getRefuelLogs(vehicle.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chargingSessions: StateFlow<List<ChargingSession>> = currentVehicle.flatMapLatest { vehicle ->
        if (vehicle != null) repository.getChargingSessions(vehicle.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Care
    val serviceRecords: StateFlow<List<ServiceRecord>> = currentVehicle.flatMapLatest { vehicle ->
        if (vehicle != null) repository.getServiceRecords(vehicle.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val maintenanceReminders: StateFlow<List<MaintenanceReminder>> = currentVehicle.flatMapLatest { vehicle ->
        if (vehicle != null) repository.getMaintenanceReminders(vehicle.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Ownership
    val vehicleDocuments: StateFlow<List<VehicleDocument>> = currentVehicle.flatMapLatest { vehicle ->
        if (vehicle != null) repository.getDocuments(vehicle.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val householdMembers: StateFlow<List<HouseholdMember>> = currentVehicle.flatMapLatest { vehicle ->
        if (vehicle != null) repository.getHouseholdMembers(vehicle.id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteDestinations: StateFlow<List<FavoriteDestination>> = repository.getFavoriteDestinations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active in-progress command modal
    private val _activeCommandState = MutableStateFlow<ActiveCommandUiState?>(null)
    val activeCommandState: StateFlow<ActiveCommandUiState?> = _activeCommandState.asStateFlow()

    // Confirmation dialog for consequential actions
    private val _confirmationState = MutableStateFlow<ConsequentialConfirmationState?>(null)
    val confirmationState: StateFlow<ConsequentialConfirmationState?> = _confirmationState.asStateFlow()

    // Simulation tool sheet visibility
    private val _isSimulatorSheetOpen = MutableStateFlow(false)
    val isSimulatorSheetOpen: StateFlow<Boolean> = _isSimulatorSheetOpen.asStateFlow()

    // Simulator toggles
    var forceCommandFailure: Boolean
        get() = simulator.forceCommandFailure
        set(value) { simulator.forceCommandFailure = value }

    init {
        viewModelScope.launch {
            simulator.initializeDefaultDataIfEmpty()
            // Set default selected vehicle if none
            val currentId = preferencesRepository.selectedVehicleId.firstOrNull()
            if (currentId == null) {
                preferencesRepository.setSelectedVehicleId(DefaultDemonstrationData.ID_SILVERADO)
            }
        }
    }

    fun selectVehicle(vehicleId: String) {
        viewModelScope.launch {
            repository.selectVehicle(vehicleId)
        }
    }

    fun requestCommand(commandType: CommandType, targetParameter: String? = null) {
        val vehicle = currentVehicle.value ?: return

        // Verify capability
        val caps = vehicle.getCapabilities()
        val isSupported = when (commandType) {
            CommandType.LOCK, CommandType.UNLOCK -> caps.contains(VehicleCapability.REMOTE_LOCK)
            CommandType.REMOTE_START, CommandType.REMOTE_STOP -> caps.contains(VehicleCapability.REMOTE_START)
            CommandType.HORN_LIGHTS -> caps.contains(VehicleCapability.HORN_LIGHTS)
            CommandType.PRECONDITION_START, CommandType.PRECONDITION_STOP -> caps.contains(VehicleCapability.CABIN_PRECONDITION)
            CommandType.CHARGING_START, CommandType.CHARGING_STOP, CommandType.SET_CHARGE_TARGET -> caps.contains(VehicleCapability.CHARGING_MANAGEMENT)
        }

        if (!isSupported) {
            return
        }

        // Consequential action confirmation check
        when (commandType) {
            CommandType.UNLOCK -> {
                _confirmationState.value = ConsequentialConfirmationState(
                    commandType = commandType,
                    targetParameter = targetParameter,
                    title = "Confirm Vehicle Unlock",
                    warningMessage = "Unlocking doors will grant physical access to your Chevrolet. Enter owner PIN to authorize.",
                    requiresPin = true
                )
            }
            CommandType.REMOTE_START -> {
                _confirmationState.value = ConsequentialConfirmationState(
                    commandType = commandType,
                    targetParameter = targetParameter,
                    title = "Confirm Remote Start",
                    warningMessage = "Ensure vehicle is outdoors or in a well-ventilated space with all doors and hood securely closed.",
                    requiresPin = true
                )
            }
            else -> {
                executeCommandInternal(commandType, targetParameter)
            }
        }
    }

    fun confirmConsequentialAction(pin: String) {
        val pending = _confirmationState.value ?: return
        if (pending.requiresPin) {
            if (!securityManager.verifyAuthorizationPin(pin)) {
                // Invalid PIN
                return
            }
        }
        val type = pending.commandType
        val param = pending.targetParameter
        _confirmationState.value = null
        executeCommandInternal(type, param)
    }

    fun dismissConfirmation() {
        _confirmationState.value = null
    }

    private fun executeCommandInternal(commandType: CommandType, targetParameter: String?) {
        val vehicle = currentVehicle.value ?: return
        viewModelScope.launch {
            val cmd = repository.sendRemoteCommand(vehicle.id, commandType, targetParameter)
            _activeCommandState.value = ActiveCommandUiState(command = cmd, showModal = true)

            // Listen to updates for this specific command to update modal
            launch {
                repository.getCommands(vehicle.id).collect { list ->
                    val updated = list.find { it.commandId == cmd.commandId }
                    if (updated != null) {
                        _activeCommandState.value = ActiveCommandUiState(command = updated, showModal = true)
                    }
                }
            }
        }
    }

    fun dismissCommandModal() {
        _activeCommandState.value = null
    }

    fun toggleSimulatorSheet(open: Boolean) {
        _isSimulatorSheetOpen.value = open
    }

    // Simulator action delegates
    fun simulateToggleOffline(offline: Boolean) {
        val vehicle = currentVehicle.value ?: return
        viewModelScope.launch {
            simulator.toggleOffline(vehicle.id, offline)
        }
    }

    fun simulateToggleStale(stale: Boolean) {
        val vehicle = currentVehicle.value ?: return
        viewModelScope.launch {
            simulator.toggleStaleTelemetry(vehicle.id, stale)
        }
    }

    fun simulateToggleTyreAlert(low: Boolean) {
        val vehicle = currentVehicle.value ?: return
        viewModelScope.launch {
            simulator.toggleTyreAlert(vehicle.id, low)
        }
    }

    fun simulateChargingDelta(delta: Float) {
        val vehicle = currentVehicle.value ?: return
        viewModelScope.launch {
            simulator.simulateChargingTick(vehicle.id, delta)
        }
    }

    fun refreshTelemetry() {
        val vehicle = currentVehicle.value ?: return
        viewModelScope.launch {
            simulator.refreshTelemetry(vehicle.id)
        }
    }

    fun updatePreferences(preferences: UserPreferences) {
        viewModelScope.launch {
            repository.updatePreferences(preferences)
        }
    }

    fun toggleMaskVin() {
        val current = userPreferences.value.maskVinInUi
        viewModelScope.launch {
            repository.toggleMaskVin(!current)
        }
    }

    fun toggleDrivingMode() {
        val current = userPreferences.value.simplifiedDrivingModeEnabled
        viewModelScope.launch {
            repository.toggleDrivingMode(!current)
        }
    }

    fun saveParkingLocation(notes: String) {
        val vehicle = currentVehicle.value ?: return
        val telemetry = currentTelemetry.value ?: return
        viewModelScope.launch {
            repository.saveParkingLocation(
                vehicleId = vehicle.id,
                latitude = telemetry.lastParkedLatitude,
                longitude = telemetry.lastParkedLongitude,
                address = telemetry.lastParkedAddress,
                notes = notes
            )
        }
    }

    fun addManualTrip(
        title: String,
        distanceMiles: Double,
        durationMinutes: Int,
        consumed: Double,
        cost: Double,
        notes: String
    ) {
        val vehicle = currentVehicle.value ?: return
        val isEv = vehicle.powertrainType == PowertrainType.EV
        val now = System.currentTimeMillis()
        val trip = JourneyTrip(
            vehicleId = vehicle.id,
            title = title,
            startTimeMs = now - durationMinutes * 60000L,
            endTimeMs = now,
            startAddress = "Manual Entry",
            endAddress = title,
            distanceMiles = distanceMiles,
            durationMinutes = durationMinutes,
            fuelConsumedGal = if (isEv) 0.0 else consumed,
            electricityConsumedKWh = if (isEv) consumed else 0.0,
            estimatedCostUsd = cost,
            dataSource = TripDataSource.PHONE_DERIVED_ESTIMATE,
            notes = notes
        )
        viewModelScope.launch {
            repository.addTrip(trip)
        }
    }

    fun addRefuelLog(gallons: Double, pricePerGal: Double, station: String, notes: String) {
        val vehicle = currentVehicle.value ?: return
        val currentOdo = currentVehicle.value?.odometerMiles ?: 20000.0
        val log = RefuelLog(
            vehicleId = vehicle.id,
            timestampMs = System.currentTimeMillis(),
            gallons = gallons,
            pricePerGallon = pricePerGal,
            totalCost = gallons * pricePerGal,
            odometerMiles = currentOdo,
            isFullTank = true,
            fuelGrade = "Regular 87",
            stationName = station,
            notes = notes
        )
        viewModelScope.launch {
            repository.addRefuelLog(log)
        }
    }

    fun addServiceRecord(category: String, desc: String, center: String, cost: Double, note: String) {
        val vehicle = currentVehicle.value ?: return
        val currentOdo = currentVehicle.value?.odometerMiles ?: 20000.0
        val record = ServiceRecord(
            vehicleId = vehicle.id,
            dateMs = System.currentTimeMillis(),
            odometerMiles = currentOdo,
            serviceCategory = category,
            description = desc,
            serviceCenter = center,
            costUsd = cost,
            receiptNote = note,
            isDemonstration = false
        )
        viewModelScope.launch {
            repository.addServiceRecord(record)
        }
    }

    fun completeReminder(reminder: MaintenanceReminder) {
        viewModelScope.launch {
            repository.completeReminder(reminder)
        }
    }
}
