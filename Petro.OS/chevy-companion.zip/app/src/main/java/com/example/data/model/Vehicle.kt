package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class PowertrainType {
    ICE_PETROL,
    ICE_DIESEL,
    EV
}

enum class ConnectionState {
    CONNECTED,
    CACHED,
    SIMULATED,
    OFFLINE
}

enum class CommandState {
    PENDING,
    ACCEPTED,
    CONFIRMED,
    FAILED,
    EXPIRED
}

enum class CommandType {
    LOCK,
    UNLOCK,
    REMOTE_START,
    REMOTE_STOP,
    HORN_LIGHTS,
    PRECONDITION_START,
    PRECONDITION_STOP,
    CHARGING_START,
    CHARGING_STOP,
    SET_CHARGE_TARGET
}

enum class VehicleCapability {
    REMOTE_LOCK,
    REMOTE_START,
    CABIN_PRECONDITION,
    HORN_LIGHTS,
    CHARGING_MANAGEMENT,
    CHARGING_SCHEDULE,
    TYRE_PRESSURE_MONITOR,
    SAVED_PARKING_LOCATION,
    ODOMETER_TRACKING,
    FUEL_MONITOR,
    BATTERY_SOC_MONITOR
}

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey val id: String,
    val nickname: String,
    val model: String,
    val modelYear: Int,
    val trim: String,
    val exteriorColorName: String,
    val powertrainType: PowertrainType,
    val vin: String,
    val registrationPlate: String,
    val odometerMiles: Double,
    val fuelTankCapacityGal: Double, // 0 for EV
    val batteryCapacityKWh: Double,  // 0 for ICE
    val heroDrawableName: String,
    val warrantySummary: String,
    val isDemo: Boolean = true
) {
    fun getMaskedVin(): String {
        return if (vin.length >= 8) {
            vin.take(3) + "••••••••••" + vin.takeLast(4)
        } else {
            "•••••••••••••••••"
        }
    }

    fun getCapabilities(): Set<VehicleCapability> {
        return when (powertrainType) {
            PowertrainType.EV -> setOf(
                VehicleCapability.REMOTE_LOCK,
                VehicleCapability.REMOTE_START,
                VehicleCapability.CABIN_PRECONDITION,
                VehicleCapability.HORN_LIGHTS,
                VehicleCapability.CHARGING_MANAGEMENT,
                VehicleCapability.CHARGING_SCHEDULE,
                VehicleCapability.TYRE_PRESSURE_MONITOR,
                VehicleCapability.SAVED_PARKING_LOCATION,
                VehicleCapability.ODOMETER_TRACKING,
                VehicleCapability.BATTERY_SOC_MONITOR
            )
            PowertrainType.ICE_PETROL, PowertrainType.ICE_DIESEL -> setOf(
                VehicleCapability.REMOTE_LOCK,
                VehicleCapability.REMOTE_START,
                VehicleCapability.CABIN_PRECONDITION,
                VehicleCapability.HORN_LIGHTS,
                VehicleCapability.TYRE_PRESSURE_MONITOR,
                VehicleCapability.SAVED_PARKING_LOCATION,
                VehicleCapability.ODOMETER_TRACKING,
                VehicleCapability.FUEL_MONITOR
            )
        }
    }
}
