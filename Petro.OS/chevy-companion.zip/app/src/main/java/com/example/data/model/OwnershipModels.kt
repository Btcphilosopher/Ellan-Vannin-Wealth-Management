package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "vehicle_documents")
data class VehicleDocument(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val title: String,
    val documentType: String, // Insurance Card, Vehicle Title, Registration, Emission Cert
    val policyOrDocNumber: String,
    val issuerName: String,
    val expirationDateMs: Long,
    val notes: String = ""
)

@Entity(tableName = "household_members")
data class HouseholdMember(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val vehicleId: String,
    val fullName: String,
    val relationship: String, // Spouse, Child, Fleet Driver
    val accessScope: String, // "Dashboard Telemetry Only", "Full Remote Commands", "Guest"
    val isLocationSharingGranted: Boolean = false,
    val dateAddedMs: Long = System.currentTimeMillis()
)

data class OwnerProfile(
    val name: String = "Thomas Anderson",
    val email: String = "tom@ahyx.org",
    val phone: String = "+1 (313) 555-0144",
    val myChevroletRewardsPoints: Int = 18450,
    val onStarSubscriptionTier: String = "Connected Access (Demonstration Mode)"
)

enum class DistanceUnit { MILES, KILOMETERS }
enum class TemperatureUnit { FAHRENHEIT, CELSIUS }
enum class PressureUnit { PSI, BAR, KPA }
enum class CurrencyUnit(val symbol: String) { USD("$"), GBP("£"), EUR("€"), CAD("CA$") }
enum class FuelEconomyUnit { MPG_US, MPG_UK, L_100KM, KM_L }

data class UserPreferences(
    val distanceUnit: DistanceUnit = DistanceUnit.MILES,
    val temperatureUnit: TemperatureUnit = TemperatureUnit.FAHRENHEIT,
    val pressureUnit: PressureUnit = PressureUnit.PSI,
    val currencyUnit: CurrencyUnit = CurrencyUnit.USD,
    val fuelEconomyUnit: FuelEconomyUnit = FuelEconomyUnit.MPG_US,
    val maskVinInUi: Boolean = true,
    val parkingRemindersEnabled: Boolean = true,
    val hapticFeedbackEnabled: Boolean = true,
    val simplifiedDrivingModeEnabled: Boolean = false
)
