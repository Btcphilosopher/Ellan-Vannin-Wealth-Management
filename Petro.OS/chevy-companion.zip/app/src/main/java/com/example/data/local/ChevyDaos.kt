package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles")
    fun getAllVehicles(): Flow<List<Vehicle>>

    @Query("SELECT * FROM vehicles WHERE id = :id")
    fun getVehicleById(id: String): Flow<Vehicle?>

    @Query("SELECT * FROM vehicles WHERE id = :id")
    suspend fun getVehicleDirect(id: String): Vehicle?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicles(vehicles: List<Vehicle>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicle(vehicle: Vehicle)

    @Update
    suspend fun updateVehicle(vehicle: Vehicle)

    @Delete
    suspend fun deleteVehicle(vehicle: Vehicle)
}

@Dao
interface TelemetryDao {
    @Query("SELECT * FROM vehicle_telemetry WHERE vehicleId = :vehicleId")
    fun getTelemetryForVehicle(vehicleId: String): Flow<VehicleTelemetry?>

    @Query("SELECT * FROM vehicle_telemetry WHERE vehicleId = :vehicleId")
    suspend fun getTelemetryDirect(vehicleId: String): VehicleTelemetry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTelemetry(telemetry: VehicleTelemetry)

    @Update
    suspend fun updateTelemetry(telemetry: VehicleTelemetry)
}

@Dao
interface CommandDao {
    @Query("SELECT * FROM remote_commands WHERE vehicleId = :vehicleId ORDER BY initiatedTimestampMs DESC")
    fun getCommandsForVehicle(vehicleId: String): Flow<List<RemoteCommand>>

    @Query("SELECT * FROM remote_commands WHERE commandId = :id")
    suspend fun getCommandById(id: String): RemoteCommand?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommand(command: RemoteCommand)

    @Update
    suspend fun updateCommand(command: RemoteCommand)
}

@Dao
interface TripDao {
    @Query("SELECT * FROM journey_trips WHERE vehicleId = :vehicleId ORDER BY startTimeMs DESC")
    fun getTripsForVehicle(vehicleId: String): Flow<List<JourneyTrip>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrip(trip: JourneyTrip)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrips(trips: List<JourneyTrip>)

    @Query("SELECT * FROM favorite_destinations")
    fun getFavoriteDestinations(): Flow<List<FavoriteDestination>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoriteDestination(destination: FavoriteDestination)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavoriteDestinations(destinations: List<FavoriteDestination>)
}

@Dao
interface EnergyDao {
    @Query("SELECT * FROM refuel_logs WHERE vehicleId = :vehicleId ORDER BY timestampMs DESC")
    fun getRefuelLogs(vehicleId: String): Flow<List<RefuelLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRefuelLog(log: RefuelLog)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRefuelLogs(logs: List<RefuelLog>)

    @Query("SELECT * FROM charging_sessions WHERE vehicleId = :vehicleId ORDER BY startTimeMs DESC")
    fun getChargingSessions(vehicleId: String): Flow<List<ChargingSession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChargingSession(session: ChargingSession)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChargingSessions(sessions: List<ChargingSession>)
}

@Dao
interface CareDao {
    @Query("SELECT * FROM service_records WHERE vehicleId = :vehicleId ORDER BY dateMs DESC")
    fun getServiceRecords(vehicleId: String): Flow<List<ServiceRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServiceRecord(record: ServiceRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServiceRecords(records: List<ServiceRecord>)

    @Query("SELECT * FROM maintenance_reminders WHERE vehicleId = :vehicleId ORDER BY dueDateMs ASC")
    fun getMaintenanceReminders(vehicleId: String): Flow<List<MaintenanceReminder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenanceReminders(reminders: List<MaintenanceReminder>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaintenanceReminder(reminder: MaintenanceReminder)

    @Update
    suspend fun updateMaintenanceReminder(reminder: MaintenanceReminder)
}

@Dao
interface OwnershipDao {
    @Query("SELECT * FROM vehicle_documents WHERE vehicleId = :vehicleId ORDER BY expirationDateMs ASC")
    fun getDocuments(vehicleId: String): Flow<List<VehicleDocument>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: VehicleDocument)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocuments(docs: List<VehicleDocument>)

    @Query("SELECT * FROM household_members WHERE vehicleId = :vehicleId ORDER BY dateAddedMs ASC")
    fun getHouseholdMembers(vehicleId: String): Flow<List<HouseholdMember>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHouseholdMember(member: HouseholdMember)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHouseholdMembers(members: List<HouseholdMember>)
}
