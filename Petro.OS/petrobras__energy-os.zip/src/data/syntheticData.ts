import { AssetSummary, WellData, ReservoirData, FpsoSubsystem, SubseaComponent, RefineryUnit, LowCarbonProject, MaintenanceWorkOrder, EventLogItem, ScenarioResult } from '../types';

export const SYNTHETIC_ASSETS: AssetSummary[] = [
  {
    id: 'asset-01',
    name: 'FPSO Atlântico-01 (Búzios)',
    code: 'FPSO-ATL-01',
    type: 'FPSO',
    basin: 'Bacia de Santos (Pré-Sal)',
    location: { lat: -24.812, lng: -42.518, depthMeters: 2150 },
    status: 'OPERATIONAL',
    productionOilBpd: 154200,
    productionGasMmscfd: 7.2,
    waterCutPercent: 12.4,
    efficiencyPercent: 96.8,
    co2IntensityKgBoe: 9.4,
    activeWells: 14,
    criticalAlarms: 0
  },
  {
    id: 'asset-02',
    name: 'FPSO Carioca-02 (Sépia)',
    code: 'FPSO-CAR-02',
    type: 'FPSO',
    basin: 'Bacia de Santos (Pré-Sal)',
    location: { lat: -25.012, lng: -42.822, depthMeters: 2200 },
    status: 'OPERATIONAL',
    productionOilBpd: 142100,
    productionGasMmscfd: 6.8,
    waterCutPercent: 14.1,
    efficiencyPercent: 95.2,
    co2IntensityKgBoe: 10.1,
    activeWells: 12,
    criticalAlarms: 1
  },
  {
    id: 'asset-03',
    name: 'FPSO Guanabara (Mero-1)',
    code: 'FPSO-GNB-01',
    type: 'FPSO',
    basin: 'Bacia de Santos (Pré-Sal)',
    location: { lat: -24.950, lng: -42.310, depthMeters: 2100 },
    status: 'OPERATIONAL',
    productionOilBpd: 178500,
    productionGasMmscfd: 8.4,
    waterCutPercent: 8.9,
    efficiencyPercent: 98.1,
    co2IntensityKgBoe: 8.7,
    activeWells: 16,
    criticalAlarms: 0
  },
  {
    id: 'asset-04',
    name: 'FPSO P-70 (Atapu)',
    code: 'FPSO-P70',
    type: 'FPSO',
    basin: 'Bacia de Santos (Pré-Sal)',
    location: { lat: -25.210, lng: -42.650, depthMeters: 2300 },
    status: 'WARNING',
    productionOilBpd: 128400,
    productionGasMmscfd: 5.9,
    waterCutPercent: 22.8,
    efficiencyPercent: 89.4,
    co2IntensityKgBoe: 12.3,
    activeWells: 11,
    criticalAlarms: 2
  },
  {
    id: 'asset-05',
    name: 'Refinaria Duque de Caxias (REDUC)',
    code: 'REF-REDUC',
    type: 'Refinery',
    basin: 'Rio de Janeiro',
    location: { lat: -22.716, lng: -43.272, depthMeters: 0 },
    status: 'OPERATIONAL',
    productionOilBpd: 239000,
    productionGasMmscfd: 12.5,
    waterCutPercent: 0,
    efficiencyPercent: 94.6,
    co2IntensityKgBoe: 18.2,
    activeWells: 0,
    criticalAlarms: 0
  },
  {
    id: 'asset-06',
    name: 'Refinaria de Paulínia (REPLAN)',
    code: 'REF-REPLAN',
    type: 'Refinery',
    basin: 'São Paulo',
    location: { lat: -22.723, lng: -47.128, depthMeters: 0 },
    status: 'OPERATIONAL',
    productionOilBpd: 434000,
    productionGasMmscfd: 22.0,
    waterCutPercent: 0,
    efficiencyPercent: 97.2,
    co2IntensityKgBoe: 16.5,
    activeWells: 0,
    criticalAlarms: 0
  },
  {
    id: 'asset-07',
    name: 'Refinaria Alberto Pasqualini (REFAP)',
    code: 'REF-REFAP',
    type: 'Refinery',
    basin: 'Rio Grande do Sul',
    location: { lat: -29.851, lng: -51.182, depthMeters: 0 },
    status: 'OPERATIONAL',
    productionOilBpd: 201000,
    productionGasMmscfd: 9.8,
    waterCutPercent: 0,
    efficiencyPercent: 93.8,
    co2IntensityKgBoe: 17.9,
    activeWells: 0,
    criticalAlarms: 1
  },
  {
    id: 'asset-08',
    name: 'Plataforma P-51 (Marlim Sul)',
    code: 'PLT-P51',
    type: 'Platform',
    basin: 'Bacia de Campos',
    location: { lat: -22.450, lng: -40.120, depthMeters: 1250 },
    status: 'MAINTENANCE',
    productionOilBpd: 48200,
    productionGasMmscfd: 1.8,
    waterCutPercent: 45.2,
    efficiencyPercent: 82.0,
    co2IntensityKgBoe: 15.6,
    activeWells: 8,
    criticalAlarms: 1
  }
];

export const SYNTHETIC_WELLS: WellData[] = [
  {
    id: 'well-7-BUZ-10',
    name: '7-BUZ-10D-RJS',
    assetId: 'asset-01',
    type: 'Producer',
    status: 'PRODUCING',
    mdMeters: 5840,
    tvdMeters: 2180,
    inclinationDeg: 34.2,
    azimuthDeg: 128.5,
    oilRateBpd: 24500,
    gasRateMmscfd: 1.15,
    waterCutPercent: 8.2,
    wellheadPressurePsi: 3850,
    bottomholePressurePsi: 7420,
    temperatureC: 78.4,
    chokePercent: 68.0,
    gasLiftRateMscfd: 0,
    ropMhr: 0,
    mudWeightPpg: 12.2,
    torqueKftlbs: 0,
    dragKlbs: 0,
    bitWearPercent: 12
  },
  {
    id: 'well-7-BUZ-12',
    name: '7-BUZ-12HP-RJS',
    assetId: 'asset-01',
    type: 'Producer',
    status: 'PRODUCING',
    mdMeters: 6210,
    tvdMeters: 2210,
    inclinationDeg: 88.5,
    azimuthDeg: 210.0,
    oilRateBpd: 28100,
    gasRateMmscfd: 1.32,
    waterCutPercent: 5.4,
    wellheadPressurePsi: 4120,
    bottomholePressurePsi: 7650,
    temperatureC: 81.2,
    chokePercent: 72.5,
    gasLiftRateMscfd: 0,
    ropMhr: 0,
    mudWeightPpg: 12.4,
    torqueKftlbs: 0,
    dragKlbs: 0,
    bitWearPercent: 8
  },
  {
    id: 'well-3-SEP-04',
    name: '3-SEP-04D-RJS',
    assetId: 'asset-02',
    type: 'Producer',
    status: 'PRODUCING',
    mdMeters: 5920,
    tvdMeters: 2240,
    inclinationDeg: 42.0,
    azimuthDeg: 95.2,
    oilRateBpd: 19800,
    gasRateMmscfd: 0.92,
    waterCutPercent: 18.6,
    wellheadPressurePsi: 3410,
    bottomholePressurePsi: 7100,
    temperatureC: 76.8,
    chokePercent: 55.0,
    gasLiftRateMscfd: 450,
    ropMhr: 0,
    mudWeightPpg: 12.1,
    torqueKftlbs: 0,
    dragKlbs: 0,
    bitWearPercent: 25
  },
  {
    id: 'well-1-MER-08',
    name: '1-MER-08-RJS (Perfuração)',
    assetId: 'asset-03',
    type: 'Exploratory',
    status: 'DRILLING',
    mdMeters: 4620,
    tvdMeters: 2080,
    inclinationDeg: 12.1,
    azimuthDeg: 45.0,
    oilRateBpd: 0,
    gasRateMmscfd: 0,
    waterCutPercent: 0,
    wellheadPressurePsi: 2100,
    bottomholePressurePsi: 6890,
    temperatureC: 69.5,
    chokePercent: 0,
    gasLiftRateMscfd: 0,
    ropMhr: 18.5,
    mudWeightPpg: 13.8,
    torqueKftlbs: 22.4,
    dragKlbs: 48.2,
    bitWearPercent: 64
  }
];

export const SYNTHETIC_RESERVOIR: ReservoirData = {
  id: 'res-A01',
  name: 'PRE-SALT-A01 (Formação Barra Velha)',
  basin: 'Bacia de Santos',
  formation: 'Carbonatos Microbialíticos do Pré-Sal',
  initialPressurePsi: 8250,
  currentPressurePsi: 7380,
  temperatureC: 84.5,
  porosityPercent: 18.5,
  permeabilityMd: 420,
  waterSaturationPercent: 14.2,
  oilSaturationPercent: 78.8,
  gasSaturationPercent: 7.0,
  apiGravity: 29.4,
  gorScfBbl: 820,
  originalOilInPlaceMMbbl: 12800,
  cumulativeProductionMMbbl: 1420,
  recoveryFactorPercent: 11.09
};

export const FPSO_SUBSYSTEMS: FpsoSubsystem[] = [
  {
    id: 'sub-01',
    namePt: 'Togos / Trem de Separação Trifásica A',
    nameEn: 'Three-Phase Separation Train A',
    status: 'OPERATIONAL',
    pressurePsi: 840,
    temperatureC: 68.2,
    flowRateBpd: 85000,
    vibrationMmSec: 1.8,
    efficiencyPercent: 98.4,
    valveState: 'OPEN',
    maintenanceOverdue: false,
    activeAlarms: []
  },
  {
    id: 'sub-02',
    namePt: 'Módulo de Compressão de Gás Alta Pressão',
    nameEn: 'High Pressure Gas Compression Module',
    status: 'WARNING',
    pressurePsi: 2450,
    temperatureC: 112.5,
    flowRateBpd: 42000,
    vibrationMmSec: 4.8,
    efficiencyPercent: 91.2,
    valveState: 'THROTTLED',
    maintenanceOverdue: true,
    activeAlarms: ['Vibração Elevada em Mancal C2', 'Temperatura de Descarga +4.2°C']
  },
  {
    id: 'sub-03',
    namePt: 'Unidade de Tratamento de Água de Injeção',
    nameEn: 'Water Injection Treatment Unit',
    status: 'OPERATIONAL',
    pressurePsi: 1200,
    temperatureC: 28.0,
    flowRateBpd: 92000,
    vibrationMmSec: 1.2,
    efficiencyPercent: 96.5,
    valveState: 'OPEN',
    maintenanceOverdue: false,
    activeAlarms: []
  },
  {
    id: 'sub-04',
    namePt: 'Sistema de Geração Principal (Turbinas a Gás)',
    nameEn: 'Main Power Generation System (Gas Turbines)',
    status: 'OPERATIONAL',
    pressurePsi: 450,
    temperatureC: 480.0,
    flowRateBpd: 0,
    vibrationMmSec: 2.1,
    efficiencyPercent: 94.0,
    valveState: 'OPEN',
    maintenanceOverdue: false,
    activeAlarms: []
  }
];

export const SUBSEA_COMPONENTS: SubseaComponent[] = [
  {
    id: 'sea-01',
    name: 'Árvore de Natal Molhada (ANM-01)',
    type: 'Tree',
    status: 'OPERATIONAL',
    depthMeters: 2150,
    pressurePsi: 3850,
    temperatureC: 78.4,
    corrosionRateMpy: 0.12,
    hydrateRiskPercent: 4.2,
    valveState: 'OPEN'
  },
  {
    id: 'sea-02',
    name: 'Manifold Submarino de Produção MSP-A',
    type: 'Manifold',
    status: 'OPERATIONAL',
    depthMeters: 2160,
    pressurePsi: 3720,
    temperatureC: 72.1,
    corrosionRateMpy: 0.18,
    hydrateRiskPercent: 6.8,
    valveState: 'OPEN'
  },
  {
    id: 'sea-03',
    name: 'Riser Flexível de Produção RSR-03',
    type: 'Riser',
    status: 'WARNING',
    depthMeters: 1050,
    pressurePsi: 3450,
    temperatureC: 62.4,
    corrosionRateMpy: 0.85,
    hydrateRiskPercent: 18.4,
    valveState: 'OPEN'
  }
];

export const REFINERY_UNITS: RefineryUnit[] = [
  {
    id: 'ref-cdu',
    name: 'Unidade de Destilação Atmosférica (U-100)',
    type: 'CDU',
    capacityBpd: 240000,
    currentThroughputBpd: 228000,
    temperatureC: 362.0,
    pressureBar: 1.8,
    efficiencyPercent: 96.2,
    energyConsumptMwt: 42.5,
    yields: {
      dieselPercent: 44.5,
      gasolinePercent: 28.0,
      lpgPercent: 8.2,
      fuelOilPercent: 14.3,
      cokeSulphurPercent: 5.0
    }
  },
  {
    id: 'ref-fcc',
    name: 'Unidade de Craqueamento Catalítico Fluido (U-200)',
    type: 'FCC',
    capacityBpd: 85000,
    currentThroughputBpd: 81200,
    temperatureC: 535.0,
    pressureBar: 2.4,
    efficiencyPercent: 94.8,
    energyConsumptMwt: 28.1,
    yields: {
      dieselPercent: 22.0,
      gasolinePercent: 54.0,
      lpgPercent: 18.5,
      fuelOilPercent: 2.5,
      cokeSulphurPercent: 3.0
    }
  }
];

export const LOW_CARBON_PROJECTS: LowCarbonProject[] = [
  {
    id: 'lc-01',
    name: 'Complexo de Biodiesel e HVO Paulínia',
    category: 'Biofuels',
    capacityMwOrTpa: '500,000 t/ano',
    capexMillionUsd: 420,
    opexMillionUsdYr: 32,
    npvMillionUsd: 185,
    irrPercent: 16.8,
    trlLevel: 8,
    carbonAbatedTco2eYr: 1250000,
    status: 'FEED'
  },
  {
    id: 'lc-02',
    name: 'Parque Eólico Offshore Bacia de Campos (Projeto Piloto)',
    category: 'Wind',
    capacityMwOrTpa: '100 MW',
    capexMillionUsd: 280,
    opexMillionUsdYr: 12,
    npvMillionUsd: 64,
    irrPercent: 11.2,
    trlLevel: 6,
    carbonAbatedTco2eYr: 310000,
    status: 'CONCEPT'
  },
  {
    id: 'lc-03',
    name: 'Hub de Captura e Armazenamento de Carbono (CCUS Búzios)',
    category: 'CCUS',
    capacityMwOrTpa: '10.5 MMt/ano CO₂',
    capexMillionUsd: 650,
    opexMillionUsdYr: 45,
    npvMillionUsd: 310,
    irrPercent: 14.5,
    trlLevel: 9,
    carbonAbatedTco2eYr: 10500000,
    status: 'OPERATIONAL'
  }
];

export const MAINTENANCE_WORK_ORDERS: MaintenanceWorkOrder[] = [
  {
    id: 'WO-88219',
    assetName: 'FPSO Atlântico-01',
    equipment: 'Compressor C2 - Módulo de Compressão',
    type: 'PREDICTIVE',
    priority: 'HIGH',
    status: 'IN_PROGRESS',
    dueDate: '2026-10-08',
    assignedTeam: 'Equipe de Confiabilidade Subsea/Topsides',
    descriptionPt: 'Substituição preventiva do mancal axial e recalibração dos sensores de vibração FFT.',
    descriptionEn: 'Preventive replacement of thrust bearing and recalibration of FFT vibration sensors.'
  },
  {
    id: 'WO-88240',
    assetName: 'Refinaria REDUC',
    equipment: 'Bomba P-102B - Alimentação CDU',
    type: 'PREVENTIVE',
    priority: 'MEDIUM',
    status: 'PENDING',
    dueDate: '2026-10-12',
    assignedTeam: 'Manutenção Mecânica REDUC',
    descriptionPt: 'Inspeção por ultrassom de espessura de carcaça e alinhamento a laser de selo mecânico.',
    descriptionEn: 'Ultrasonic casing thickness inspection and laser alignment of mechanical seal.'
  }
];

export const EVENT_HISTORY: EventLogItem[] = [
  {
    id: 'evt-01',
    timestamp: '00:52:10',
    eventType: 'AlarmRaised',
    source: 'FPSO-P70 / COMP-02',
    severity: 'WARNING',
    messagePt: 'Alerta de vibração anormal (4.8 mm/s) no mancal do compressor de gás.',
    messageEn: 'Abnormal vibration alert (4.8 mm/s) on gas compressor bearing.'
  },
  {
    id: 'evt-02',
    timestamp: '00:45:00',
    eventType: 'ProductionUpdated',
    source: 'Búzios Field Control',
    severity: 'INFO',
    messagePt: 'Vazão total do campo Búzios estabilizada em 154,200 bpd.',
    messageEn: 'Total flow rate at Búzios field stabilized at 154,200 bpd.'
  },
  {
    id: 'evt-03',
    timestamp: '00:30:15',
    eventType: 'EmissionCalculated',
    source: 'REDUC Environmental Engine',
    severity: 'INFO',
    messagePt: 'Emissões líquidas da unidade ajustadas para 18.2 kgCO₂e/boe (-1.2% vs ontem).',
    messageEn: 'Unit net emissions adjusted to 18.2 kgCO₂e/boe (-1.2% vs yesterday).'
  }
];

export const SCENARIO_PRESETS: ScenarioResult[] = [
  {
    id: 'base-case',
    namePt: 'Cenário Base (Plano Estratégico 2026-2030)',
    nameEn: 'Base Case Case (Strategic Plan 2026-2030)',
    brentPriceUsd: 78.0,
    oilProductionMMboeD: 2.41,
    gasProductionMMboeD: 0.50,
    capexMillionUsd: 18500,
    opexMillionUsd: 9200,
    npvBillionUsd: 42.8,
    co2IntensityKgBoe: 9.8,
    irrPercent: 22.4
  },
  {
    id: 'high-oil',
    namePt: 'Cenário Alta Preço Brent ($95/bbl) & Expansão Pré-Sal',
    nameEn: 'High Brent Price ($95/bbl) & Pre-Salt Expansion',
    brentPriceUsd: 95.0,
    oilProductionMMboeD: 2.68,
    gasProductionMMboeD: 0.58,
    capexMillionUsd: 22000,
    opexMillionUsd: 10100,
    npvBillionUsd: 61.5,
    co2IntensityKgBoe: 9.2,
    irrPercent: 28.1
  },
  {
    id: 'low-carbon-focus',
    namePt: 'Descarbonização Acelerada & Taxa de Carbono $80/t',
    nameEn: 'Accelerated Decarbonisation & $80/t Carbon Tax',
    brentPriceUsd: 70.0,
    oilProductionMMboeD: 2.35,
    gasProductionMMboeD: 0.52,
    capexMillionUsd: 19800,
    opexMillionUsd: 8900,
    npvBillionUsd: 38.2,
    co2IntensityKgBoe: 7.1,
    irrPercent: 19.5
  }
];
