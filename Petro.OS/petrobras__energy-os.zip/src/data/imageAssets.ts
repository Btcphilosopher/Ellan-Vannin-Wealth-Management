import fpsoImg from '../assets/images/fpso_deepwater_rig_1791100528407.jpg';
import refineryImg from '../assets/images/refinery_industrial_plant_1791100540019.jpg';
import seismicImg from '../assets/images/geological_seismic_basin_1791100550389.jpg';

export const IMAGE_ASSETS = {
  fpsoHero: fpsoImg,
  refineryHero: refineryImg,
  seismicHero: seismicImg,
};
