import React from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import {
  LayoutDashboard, Compass, Database, Drill, Ship, Anchor, Zap, Factory,
  Cpu, Truck, Network, Flame, Leaf, LineChart, ShieldCheck, Wrench, AlertTriangle,
  Package, DollarSign, Trash2, Sliders, Bot, Shield, Globe2
} from 'lucide-react';

interface SidebarProps {
  activeModule: string;
  onSelectModule: (moduleId: string) => void;
  language: Language;
}

interface NavItem {
  id: string;
  icon: React.ReactNode;
  category: 'OPERATIONS' | 'ENGINEERING' | 'GEOSCIENCE' | 'STRATEGY' | 'GOVERNANCE';
  titleKey: string;
}

const NAV_ITEMS: NavItem[] = [
  // OPERATIONS
  { id: 'executive', icon: <LayoutDashboard className="w-4 h-4" />, category: 'OPERATIONS', titleKey: 'nav.executive' },
  { id: 'fpso', icon: <Ship className="w-4 h-4" />, category: 'OPERATIONS', titleKey: 'nav.fpso' },
  { id: 'subsea', icon: <Anchor className="w-4 h-4" />, category: 'OPERATIONS', titleKey: 'nav.subsea' },
  { id: 'wells', icon: <Drill className="w-4 h-4" />, category: 'OPERATIONS', titleKey: 'nav.wells' },
  { id: 'refinery', icon: <Factory className="w-4 h-4" />, category: 'OPERATIONS', titleKey: 'nav.refinery' },
  { id: 'logistics', icon: <Truck className="w-4 h-4" />, category: 'OPERATIONS', titleKey: 'nav.logistics' },
  { id: 'gas_network', icon: <Network className="w-4 h-4" />, category: 'OPERATIONS', titleKey: 'nav.gas_network' },
  { id: 'supply_chain', icon: <Package className="w-4 h-4" />, category: 'OPERATIONS', titleKey: 'nav.supply_chain' },

  // GEOSCIENCE & RESERVOIR
  { id: 'geoscience', icon: <Compass className="w-4 h-4" />, category: 'GEOSCIENCE', titleKey: 'nav.geoscience' },
  { id: 'reservoir', icon: <Database className="w-4 h-4" />, category: 'GEOSCIENCE', titleKey: 'nav.reservoir' },

  // ENGINEERING & OPTIMISATION
  { id: 'production_opt', icon: <Zap className="w-4 h-4" />, category: 'ENGINEERING', titleKey: 'nav.production_opt' },
  { id: 'process_eng', icon: <Cpu className="w-4 h-4" />, category: 'ENGINEERING', titleKey: 'nav.process_eng' },
  { id: 'power_energy', icon: <Flame className="w-4 h-4" />, category: 'ENGINEERING', titleKey: 'nav.power_energy' },
  { id: 'asset_integrity', icon: <ShieldCheck className="w-4 h-4" />, category: 'ENGINEERING', titleKey: 'nav.asset_integrity' },
  { id: 'predictive_maint', icon: <Wrench className="w-4 h-4" />, category: 'ENGINEERING', titleKey: 'nav.predictive_maint' },
  { id: 'safety_risk', icon: <AlertTriangle className="w-4 h-4" />, category: 'ENGINEERING', titleKey: 'nav.safety_risk' },
  { id: 'simulation_lab', icon: <Sliders className="w-4 h-4" />, category: 'ENGINEERING', titleKey: 'nav.simulation_lab' },

  // STRATEGY & ECONOMICS
  { id: 'low_carbon', icon: <Leaf className="w-4 h-4" />, category: 'STRATEGY', titleKey: 'nav.low_carbon' },
  { id: 'carbon_emissions', icon: <LineChart className="w-4 h-4" />, category: 'STRATEGY', titleKey: 'nav.carbon_emissions' },
  { id: 'economics', icon: <DollarSign className="w-4 h-4" />, category: 'STRATEGY', titleKey: 'nav.economics' },
  { id: 'scenario_lab', icon: <Globe2 className="w-4 h-4" />, category: 'STRATEGY', titleKey: 'nav.scenario_lab' },
  { id: 'decommissioning', icon: <Trash2 className="w-4 h-4" />, category: 'STRATEGY', titleKey: 'nav.decommissioning' },

  // AI & GOVERNANCE
  { id: 'petro_ai', icon: <Bot className="w-4 h-4 text-cyan-400" />, category: 'GOVERNANCE', titleKey: 'nav.petro_ai' },
  { id: 'governance', icon: <Shield className="w-4 h-4" />, category: 'GOVERNANCE', titleKey: 'nav.governance' },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeModule,
  onSelectModule,
  language
}) => {
  const t = (key: string) => translations[language][key] || key;

  const categories = [
    { id: 'OPERATIONS', labelPt: 'OPERACIONAL', labelEn: 'OPERATIONS' },
    { id: 'GEOSCIENCE', labelPt: 'GEOCIÊNCIAS & RESERVATÓRIO', labelEn: 'GEOSCIENCE' },
    { id: 'ENGINEERING', labelPt: 'ENGENHARIA DE PROCESSOS', labelEn: 'ENGINEERING' },
    { id: 'STRATEGY', labelPt: 'ESTRATÉGIA & CARBONO', labelEn: 'STRATEGY & CARBON' },
    { id: 'GOVERNANCE', labelPt: 'IA & GOVERNAÇA', labelEn: 'AI & GOVERNANCE' },
  ];

  return (
    <aside className="w-64 bg-[#0A1128] border-r border-slate-800 flex flex-col shrink-0 h-[calc(100vh-53px)] overflow-y-auto">
      <div className="p-3 space-y-5">
        {categories.map(cat => {
          const items = NAV_ITEMS.filter(item => item.category === cat.id);
          if (items.length === 0) return null;

          return (
            <div key={cat.id} className="space-y-1">
              <div className="px-3 text-[10px] font-mono tracking-wider text-slate-400 uppercase font-semibold">
                {language === 'pt-BR' ? cat.labelPt : cat.labelEn}
              </div>
              <div className="space-y-0.5 mt-1">
                {items.map(item => {
                  const isActive = activeModule === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onSelectModule(item.id)}
                      className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded transition-all text-left ${
                        isActive
                          ? 'bg-[#0077C8] text-white font-semibold shadow-sm border border-cyan-400/20'
                          : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                      }`}
                    >
                      <span className={isActive ? 'text-white' : 'text-slate-400'}>
                        {item.icon}
                      </span>
                      <span className="truncate">{t(item.titleKey)}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </aside>
  );
};
