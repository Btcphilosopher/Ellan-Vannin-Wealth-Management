import React from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { Activity, Terminal, FileText, Globe, Play, Cpu, ShieldAlert } from 'lucide-react';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenCli: () => void;
  onOpenReport: () => void;
  onOpenApi: () => void;
  onStartWorkflow: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  onOpenCli,
  onOpenReport,
  onOpenApi,
  onStartWorkflow
}) => {
  const t = (key: string) => translations[language][key] || key;

  return (
    <header className="sticky top-0 z-40 bg-[#0A1128]/95 backdrop-blur-md border-b border-slate-800 px-4 py-2.5">
      <div className="flex items-center justify-between gap-4">
        {/* Zone 1: Single Element Brand Title */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-[#0077C8] flex items-center justify-center text-white font-bold tracking-wider text-sm shadow-sm border border-cyan-400/30">
              P//
            </div>
            <div>
              <a href="#" className="text-lg font-bold tracking-tight text-white font-display hover:text-[#0077C8] transition-colors">
                {t('app.title')}
              </a>
              <div className="text-[10px] text-slate-400 font-mono tracking-wider flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00A859] animate-pulse"></span>
                <span>{t('app.status')}</span>
                <span className="text-slate-600">·</span>
                <span>{t('app.version')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center: Synthetic Banner Disclaimer */}
        <div className="hidden xl:flex items-center gap-2 bg-slate-900/90 border border-amber-500/30 rounded px-3 py-1 text-xs text-amber-300/90 font-mono">
          <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="truncate max-w-xl">{t('app.simulated_banner')}</span>
        </div>

        {/* Zone 3: Actions & Controls */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Workflow Demo Button */}
          <button
            onClick={onStartWorkflow}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-[#00A859] text-white rounded hover:bg-[#008f4b] transition-colors shadow-sm whitespace-nowrap"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{t('btn.guided_workflow')}</span>
          </button>

          {/* CLI Terminal */}
          <button
            onClick={onOpenCli}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono bg-slate-800/80 text-slate-200 border border-slate-700 rounded hover:bg-slate-700 hover:text-white transition-colors whitespace-nowrap"
            title="Open Petrobras OS CLI Terminal"
          >
            <Terminal className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">CLI</span>
          </button>

          {/* API Docs */}
          <button
            onClick={onOpenApi}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono bg-slate-800/80 text-slate-200 border border-slate-700 rounded hover:bg-slate-700 hover:text-white transition-colors whitespace-nowrap"
            title="View OpenAPI Specifications"
          >
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline">API</span>
          </button>

          {/* Export Report */}
          <button
            onClick={onOpenReport}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium bg-slate-800/80 text-slate-200 border border-slate-700 rounded hover:bg-slate-700 hover:text-white transition-colors whitespace-nowrap"
            title="Export Engineering Report"
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">{t('btn.export_report')}</span>
          </button>

          {/* Language Selector */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded p-0.5 ml-1">
            <button
              onClick={() => onLanguageChange('pt-BR')}
              className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                language === 'pt-BR'
                  ? 'bg-[#0077C8] text-white shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              PT-BR
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                language === 'en'
                  ? 'bg-[#0077C8] text-white shadow-sm font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              EN
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
