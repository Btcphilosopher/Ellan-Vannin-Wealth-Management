import React from 'react';
import { Language } from '../../types';
import { Network, Activity, ShieldCheck } from 'lucide-react';

export const GasNetworkModule: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Network className="w-5 h-5 text-cyan-400" />
          <span>REDE DE GÁS NATURAL // NATIONAL NATURAL GAS NETWORK</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Malha integrada de gasodutos offshore (Rota 1, Rota 2, Rota 3), UPGNs (Cabiúnas, Comperj) e atendimento ao mercado térmico e industrial.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Gasoduto Rota 3 (Pré-Sal → Comperj)</span>
          <div className="text-xl font-bold text-emerald-400">Escoamento: 18.0 MMm³/dia</div>
          <span className="text-slate-500">Pressão Operacional: 1,420 psi</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">UPGN Cabiúnas (Processamento)</span>
          <div className="text-xl font-bold text-white">Vazão Processada: 25.2 MMm³/dia</div>
          <span className="text-slate-500">Recuperação de GLP/C5+: 98.6%</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Atendimento a Termelétricas</span>
          <div className="text-xl font-bold text-cyan-300">Despacho: 12.4 MMm³/dia</div>
          <span className="text-emerald-400">Reserva de Rede: 100% Nominal</span>
        </div>
      </div>
    </div>
  );
};
