import React from 'react';
import { Language } from '../../types';
import { MAINTENANCE_WORK_ORDERS } from '../../data/syntheticData';
import { Wrench, Activity, AlertTriangle } from 'lucide-react';

export const PredictiveMaintenance: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Wrench className="w-5 h-5 text-amber-400" />
          <span>MANUTENÇÃO PREDITIVA // PREDICTIVE MAINTENANCE & FFT ANALYTICS</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Análise de espectro de vibração FFT, desvio de temperatura de mancais em compressores de gás e detecção explicável de anomalias.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3">
        <h3 className="font-bold text-white text-sm border-b border-slate-800 pb-2">
          ORDENS DE SERVIÇO PREDITIVAS EM EXECUÇÃO
        </h3>
        <div className="space-y-2">
          {MAINTENANCE_WORK_ORDERS.map(wo => (
            <div key={wo.id} className="bg-slate-950 p-3 rounded border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-white text-sm">{wo.id} - {wo.equipment}</div>
                <div className="text-slate-400 text-[11px]">{wo.assetName} | {language === 'pt-BR' ? wo.descriptionPt : wo.descriptionEn}</div>
              </div>
              <div className="text-right">
                <span className="px-2 py-0.5 bg-amber-950 text-amber-400 border border-amber-800 text-[10px] font-bold rounded">
                  {wo.priority}
                </span>
                <div className="text-slate-500 text-[10px] mt-1">Vencimento: {wo.dueDate}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
