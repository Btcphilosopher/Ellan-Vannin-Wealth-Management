import React from 'react';
import { Language } from '../../types';
import { LineChart, Leaf, Zap, Activity } from 'lucide-react';

export const EmissionsModule: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <LineChart className="w-5 h-5 text-emerald-400" />
          <span>CARBONO E EMISSÕES // EMISSIONS ACCOUNTING & DECARBONISATION</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Contabilidade rigorosa Scope 1 (diretas), Scope 2 (eletricidade) e Scope 3 selecionados. Intensidade de carbono e taxa de queima em flare.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Intensidade Média de Carbono</span>
          <div className="text-2xl font-bold text-emerald-400">9.8 <span className="text-xs font-normal text-slate-400">kgCO₂e/boe</span></div>
          <span className="text-slate-500">Meta 2030: &lt;8.5 kgCO₂e/boe</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Emissões Escopo 1 (Operacionais)</span>
          <div className="text-2xl font-bold text-white">18.4 <span className="text-xs font-normal text-slate-400">MtCO₂e/ano</span></div>
          <span className="text-slate-500">Turbinas + Flare + Queima</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Emissões Escopo 2 (Eletricidade)</span>
          <div className="text-2xl font-bold text-cyan-300">1.2 <span className="text-xs font-normal text-slate-400">MtCO₂e/ano</span></div>
          <span className="text-slate-500">Rede Elétrica Nacional</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Taxa de Queima em Flare (Rotina)</span>
          <div className="text-2xl font-bold text-emerald-400">0.08 <span className="text-xs font-normal text-slate-400">%</span></div>
          <span className="text-emerald-400">Meta de Flare Zero Atingida</span>
        </div>
      </div>
    </div>
  );
};
