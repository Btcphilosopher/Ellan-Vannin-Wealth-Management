import React from 'react';
import { Language, AssetSummary } from '../../types';
import { translations } from '../../i18n/translations';
import { SYNTHETIC_ASSETS } from '../../data/syntheticData';
import { IMAGE_ASSETS } from '../../data/imageAssets';
import { TrendingUp, AlertTriangle, ShieldCheck, Activity, ArrowUpRight, Flame, Droplets, Zap, ShieldAlert } from 'lucide-react';

interface ExecutiveCommandCentreProps {
  language: Language;
  onSelectAsset: (asset: AssetSummary) => void;
  onNavigateToModule: (moduleId: string) => void;
}

export const ExecutiveCommandCentre: React.FC<ExecutiveCommandCentreProps> = ({
  language,
  onSelectAsset,
  onNavigateToModule
}) => {
  const t = (key: string) => translations[language][key] || key;

  return (
    <div className="p-6 space-y-6">
      {/* Top Banner Hero */}
      <div className="relative rounded-lg overflow-hidden border border-slate-800 bg-slate-900 shadow-xl">
        <img
          src={IMAGE_ASSETS.fpsoHero}
          alt="FPSO Deepwater Rig"
          className="w-full h-48 object-cover opacity-35"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A1128] via-[#0A1128]/80 to-transparent p-6 flex flex-col justify-between">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded bg-[#0077C8]/30 border border-cyan-400/30 text-cyan-300 text-xs font-mono font-semibold">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t('app.subtitle')}</span>
            </div>
            <h2 className="text-2xl font-black text-white font-display tracking-tight">
              CENTRO DE COMANDO EXECUTIVO // EXECUTIVE COMMAND CENTRE
            </h2>
            <p className="text-xs text-slate-300 max-w-2xl font-sans">
              Plataforma integrada de visão holística da cadeia de valor da energia: Exploração, Reservatório, Poços, Submarino, FPSO, Refino, Logística e Carbono.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono text-slate-300 pt-2 border-t border-slate-800/80">
            <div>
              <span className="text-slate-500">PRODUÇÃO BOE: </span>
              <span className="font-bold text-white">2.41 MMboe/d</span>
            </div>
            <span>·</span>
            <div>
              <span className="text-slate-500">PETRÓLEO: </span>
              <span className="font-bold text-emerald-400">1.91 MMbbl/d</span>
            </div>
            <span>·</span>
            <div>
              <span className="text-slate-500">GÁS NATURAL: </span>
              <span className="font-bold text-cyan-400">0.50 MMboe/d</span>
            </div>
            <span>·</span>
            <div>
              <span className="text-slate-500">EFICIÊNCIA OPERACIONAL: </span>
              <span className="font-bold text-emerald-400">95.8%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Corporate KPIs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>{t('kpi.oil_prod')}</span>
            <Droplets className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">1,910,000 <span className="text-xs text-slate-400 font-normal">bpd</span></div>
          <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
            <TrendingUp className="w-3 h-3" />
            <span>+1.8% vs mês anterior</span>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>{t('kpi.gas_prod')}</span>
            <Flame className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">0.50 <span className="text-xs text-slate-400 font-normal">MMboe/d</span></div>
          <div className="flex items-center gap-1 text-[11px] text-slate-400 font-mono">
            <span>100% gás associado reinjetado / exportado</span>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>{t('kpi.co2_intensity')}</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-300">9.8 <span className="text-xs text-slate-400 font-normal">kgCO₂e/boe</span></div>
          <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
            <span>-42% vs média da indústria global</span>
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>{t('kpi.brent')} / MARGEM REFINO</span>
            <Activity className="w-4 h-4 text-[#0077C8]" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">$78.00 <span className="text-xs text-slate-400 font-normal">/bbl</span></div>
          <div className="text-[11px] text-slate-300 font-mono">Margem Refino: $14.20/bbl</div>
        </div>
      </div>

      {/* Asset Grid Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold font-mono text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>ATIVOS PRINCIPAIS EM OPERAÇÃO (SANTOS, CAMPOS & REFINO)</span>
          </h3>
          <span className="text-xs text-slate-500 font-mono">Clique em um ativo para detalhar no Gêmeo Digital</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {SYNTHETIC_ASSETS.map(asset => (
            <div
              key={asset.id}
              onClick={() => {
                onSelectAsset(asset);
                onNavigateToModule(asset.type === 'Refinery' ? 'refinery' : 'fpso');
              }}
              className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-cyan-500/50 rounded-lg p-4 cursor-pointer transition-all space-y-3 group"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs font-mono text-cyan-400 font-bold">{asset.code}</div>
                  <div className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors font-display truncate max-w-[180px]">
                    {asset.name}
                  </div>
                </div>
                <span className={`px-2 py-0.5 text-[10px] font-mono font-bold rounded ${asset.status === 'OPERATIONAL' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-400 border border-amber-800'}`}>
                  {asset.status}
                </span>
              </div>

              <div className="space-y-1 text-xs font-mono text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-500">Bacia / Região:</span>
                  <span className="text-slate-200">{asset.basin}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Produção:</span>
                  <span className="font-bold text-emerald-400">{asset.productionOilBpd.toLocaleString()} bpd</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Eficiência:</span>
                  <span>{asset.efficiencyPercent}%</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span>Poços: {asset.activeWells}</span>
                <span className="flex items-center gap-1 text-cyan-400 group-hover:translate-x-0.5 transition-transform">
                  <span>Abrir Gêmeo</span>
                  <ArrowUpRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
