import React from 'react';
import { Language } from '../../types';
import { Cpu, Activity, ShieldCheck, Zap } from 'lucide-react';

export const ProcessEngineering: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Cpu className="w-5 h-5 text-cyan-400" />
          <span>ENGENHARIA DE PROCESSOS // PROCESS ENGINEERING & P&ID</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Análise de fluxogramas P&ID, redes de permutadores de calor, curvas de bombas centrífugas e termodinâmica de fluidos.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Permutador E-101 (Pré-Aquecimento)</span>
          <div className="text-xl font-bold text-emerald-400">Eficiência Térmica: 92.4%</div>
          <span className="text-slate-500">Q = 14.8 MW | T_in = 45°C / T_out = 118°C</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Bomba P-201A (Alimentação Main Line)</span>
          <div className="text-xl font-bold text-white">Pressão de Descarga: 3,850 psi</div>
          <span className="text-slate-500">Vazão: 85,000 bpd | NPSH_disp = 8.2m</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Válvula de Alívio PSV-102</span>
          <div className="text-xl font-bold text-cyan-300">Set-Point: 4,500 psi</div>
          <span className="text-emerald-400">Status: ÍNTEGRA (Selo Intacto)</span>
        </div>
      </div>
    </div>
  );
};
