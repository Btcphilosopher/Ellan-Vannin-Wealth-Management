import React from 'react';
import { Language } from '../../types';
import { ShieldCheck, AlertTriangle, Activity } from 'lucide-react';

export const AssetIntegrityModule: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-cyan-400" />
          <span>INTEGRIDADE DE ATIVOS // ASSET INTEGRITY MANAGEMENT (RBI)</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Matriz de Risco 5x5 (Probabilidade x Consequência), plano de inspeção baseada em risco (RBI) e vida útil remanescente (RUL).
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Vaso de Pressão V-101 (Separador)</span>
          <div className="text-xl font-bold text-emerald-400">Score de Integridade: 98/100</div>
          <span className="text-slate-500">Espessura Atual: 24.2 mm (Mín: 18.0 mm)</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Riser Flexível RSR-03 (Búzios)</span>
          <div className="text-xl font-bold text-amber-300">Score de Integridade: 82/100</div>
          <span className="text-amber-400">Acompanhamento de Tensão de Anular Ativo</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Tubulação Oleoduto Submarino M-01</span>
          <div className="text-xl font-bold text-white">Taxa de Corrosão: 0.12 mpy</div>
          <span className="text-slate-500">Vida Útil Remanescente: 28 anos</span>
        </div>
      </div>
    </div>
  );
};
