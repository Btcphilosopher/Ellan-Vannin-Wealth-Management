import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { SUBSEA_COMPONENTS } from '../../data/syntheticData';
import { calculateHydrateRisk } from '../../services/simulationEngine';
import { Anchor, Activity, AlertTriangle, ShieldCheck, Play, ArrowRight, Zap } from 'lucide-react';

interface SubseaSystemsProps {
  language: Language;
}

export const SubseaSystems: React.FC<SubseaSystemsProps> = ({ language }) => {
  const t = (key: string) => translations[language][key] || key;

  const [selectedComp, setSelectedComp] = useState(SUBSEA_COMPONENTS[0]);
  const [faultScenarioTriggered, setFaultScenarioTriggered] = useState(false);

  const hydrateInfo = calculateHydrateRisk(selectedComp.pressurePsi, selectedComp.temperatureC, 5.0);

  return (
    <div className="p-6 space-y-6">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <Anchor className="w-5 h-5 text-[#0077C8]" />
            <span>SISTEMAS SUBMARINOS // SUBSEA ENGINEERING & RISERS</span>
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Manifolds de produção em águas ultraprofundas (2,150m), árvores de natal molhadas (ANM), risers flexíveis e injeção de glicol (MEG).
          </p>
        </div>

        {/* Fault Propagation Demo Trigger */}
        <button
          onClick={() => setFaultScenarioTriggered(!faultScenarioTriggered)}
          className={`px-3 py-1.5 text-xs font-mono font-bold rounded flex items-center gap-2 transition-colors ${
            faultScenarioTriggered
              ? 'bg-rose-600 text-white animate-pulse'
              : 'bg-amber-500 hover:bg-amber-600 text-slate-950'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>
            {faultScenarioTriggered
              ? 'SIMULAÇÃO DE ANOMALIA DE PRESSÃO NO RISER (ATIVA)'
              : 'INJETAR FALA: ANOMALIA DE PRESSÃO NO RISER'}
          </span>
        </button>
      </div>

      {/* Fault Propagation Banner */}
      {faultScenarioTriggered && (
        <div className="bg-rose-950/80 border border-rose-500 rounded-lg p-4 space-y-2 font-mono text-xs text-rose-200">
          <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
            <AlertTriangle className="w-4 h-4" />
            <span>PROPAGAÇÃO DE CONSEQUÊNCIA EM TEMPO REAL (GÊMEO DIGITAL SUBMARINO)</span>
          </div>
          <div>1. Anomalia detectada: Queda abrupta de pressão no Riser Flexível RSR-03 (-450 psi).</div>
          <div>2. Propagação Submarina: Risco de formação de hidrato elevado para 18.4% devido ao resfriamento da linha.</div>
          <div>3. Ação do Gêmeo Digital: Injeção automática de MEG aumentada para +12 L/min e sinalização para o topside fechar parcialmente a válvula SDV-03.</div>
        </div>
      )}

      {/* Subsea Components Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
        {SUBSEA_COMPONENTS.map(c => (
          <div
            key={c.id}
            onClick={() => setSelectedComp(c)}
            className={`p-4 rounded-lg border cursor-pointer transition-all space-y-3 ${
              selectedComp.id === c.id
                ? 'bg-slate-800 border-cyan-400 shadow-lg'
                : 'bg-slate-900 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-sm">{c.name}</span>
              <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${c.status === 'OPERATIONAL' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-400 border border-amber-800'}`}>
                {c.status}
              </span>
            </div>

            <div className="space-y-1.5 text-slate-300">
              <div className="flex justify-between"><span>Profundidade (Lâmina d'Água):</span> <span className="text-white font-bold">{c.depthMeters} m</span></div>
              <div className="flex justify-between"><span>Pressão Interna:</span> <span className="text-cyan-300 font-bold">{c.pressurePsi} psi</span></div>
              <div className="flex justify-between"><span>Taxa de Corrosão:</span> <span>{c.corrosionRateMpy} mpy</span></div>
              <div className="flex justify-between"><span>Risco de Hidrato:</span> <span className={c.hydrateRiskPercent > 10 ? 'text-amber-400 font-bold' : 'text-emerald-400'}>{c.hydrateRiskPercent}%</span></div>
            </div>
          </div>
        ))}
      </div>

      {/* Detailed Component Inspector & Hydrate Risk Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-mono text-xs">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>AVALIAÇÃO DE RISCO DE FORMALIZAÇÃO DE HIDRATO</span>
          </h3>

          <div className="space-y-2 text-slate-300">
            <div className="flex justify-between"><span>Temperatura Limite de Hidrato:</span> <span className="text-amber-400 font-bold">{hydrateInfo.hydrateEquilibriumTempC.toFixed(1)}°C</span></div>
            <div className="flex justify-between"><span>Temperatura Atual da Linha:</span> <span className="text-white font-bold">{selectedComp.temperatureC}°C</span></div>
            <div className="flex justify-between"><span>Margem Térmica de Segurança:</span> <span className="text-emerald-400 font-bold">{hydrateInfo.temperatureMarginC.toFixed(1)}°C</span></div>
            <div className="flex justify-between"><span>Score de Risco de Hidrato:</span> <span className="text-cyan-300 font-bold">{hydrateInfo.riskScorePercent}%</span></div>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">
            INTEGRIDADE DE UMBLICAIS E FIBRA ÓPTICA SUBMARINA
          </h3>
          <div className="space-y-2 text-slate-300">
            <div className="flex justify-between"><span>Comunicação Eletro-Hidráulica:</span> <span className="text-emerald-400 font-bold">100% OPERACIONAL</span></div>
            <div className="flex justify-between"><span>Pressão de Injeção de MEG:</span> <span className="text-white font-bold">4,200 psi</span></div>
            <div className="flex justify-between"><span>Monitoramento por Fibra Óptica (DAS):</span> <span className="text-cyan-400 font-bold">ATIVO (0 Ruídos Anômalos)</span></div>
          </div>
        </div>
      </div>
    </div>
  );
};
