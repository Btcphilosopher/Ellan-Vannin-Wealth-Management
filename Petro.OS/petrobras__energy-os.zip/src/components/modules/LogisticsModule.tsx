import React from 'react';
import { Language } from '../../types';
import { Truck, Ship, Navigation, Clock } from 'lucide-react';

export const LogisticsModule: React.FC<{ language: Language }> = ({ language }) => {
  const tankers = [
    { name: 'Suezmax ' + 'Petrobras ' + 'Brasil', cargo: '1,000,000 bbl', route: 'FPSO Búzios -> REDUC', eta: '12h 40m', status: 'IN_TRANSIT' },
    { name: 'Aframax ' + 'Campos ' + 'Bay', cargo: '650,000 bbl', route: 'FPSO Mero -> REFAP', eta: '24h 15m', status: 'LOADING' },
  ];

  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Truck className="w-5 h-5 text-amber-400" />
          <span>LOGÍSTICA DE PETRÓLEO & GÁS // OIL & GAS LOGISTICS</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Otimização de frota de navios petroleiros (Offloading/Suezmax), oleodutos e terminais marítimos (Angra, São Sebastião, Cabiúnas).
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {tankers.map((t, idx) => (
          <div key={idx} className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
            <div className="flex items-center justify-between text-white font-bold text-sm">
              <span>{t.name}</span>
              <span className="px-2 py-0.5 bg-[#0077C8] text-white text-[10px] rounded">{t.status}</span>
            </div>
            <div className="text-slate-300">Carga: {t.cargo}</div>
            <div className="text-slate-400">Rota: {t.route}</div>
            <div className="text-emerald-400 font-bold">ETA: {t.eta}</div>
          </div>
        ))}
      </div>
    </div>
  );
};
