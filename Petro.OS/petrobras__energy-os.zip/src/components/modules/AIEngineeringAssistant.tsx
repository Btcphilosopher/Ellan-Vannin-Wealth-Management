import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { askPetroAi } from '../../services/geminiAi';
import { Bot, Send, Sparkles, CheckCircle2, ShieldAlert, Cpu } from 'lucide-react';

export const AIEngineeringAssistant: React.FC<{ language: Language }> = ({ language }) => {
  const t = (key: string) => translations[language][key] || key;

  const [promptInput, setPromptInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string; citations?: string[] }>>([
    {
      role: 'assistant',
      text: t('ai.greeting'),
      citations: ['Gêmeo Digital Pré-Sal v3.6', 'Telemetria do FPSO Atlântico-01']
    }
  ]);

  const presetQuestionsPt = [
    'Quais ativos apresentam maior risco de integridade?',
    'Quais poços estão limitando a produção no pré-sal?',
    'Por que a vazão do FPSO P-70 caiu?',
    'Quais são os principais consumidores de energia offshore?'
  ];

  const presetQuestionsEn = [
    'Which assets present the highest integrity risk?',
    'Which wells are limiting production in the pre-salt?',
    'Why did production on FPSO P-70 drop?',
    'What are the primary energy consumers offshore?'
  ];

  const presets = language === 'pt-BR' ? presetQuestionsPt : presetQuestionsEn;

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || promptInput;
    if (!textToSend.trim()) return;

    setMessages(prev => [...prev, { role: 'user', text: textToSend }]);
    if (!queryText) setPromptInput('');
    setLoading(true);

    const res = await askPetroAi(textToSend, language);

    setMessages(prev => [
      ...prev,
      { role: 'assistant', text: res.text, citations: res.citations }
    ]);
    setLoading(false);
  };

  return (
    <div className="p-6 space-y-6 font-mono text-xs flex flex-col h-[calc(100vh-100px)]">
      {/* Title */}
      <div className="border-b border-slate-800 pb-4 shrink-0">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Bot className="w-6 h-6 text-cyan-400" />
          <span>ASSISTENTE DE ENGENHARIA PETRO.AI // GEMINI 3.6 ASSISTANT</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Agente inteligente conectado aos modelos do Gêmeo Digital: Termodinâmica, Reservatório, Telemetria e Matriz de Riscos.
        </p>
      </div>

      {/* Preset Prompts */}
      <div className="flex items-center gap-2 overflow-x-auto shrink-0 pb-1">
        <span className="text-slate-500 text-[11px] whitespace-nowrap">Exemplos:</span>
        {presets.map((p, i) => (
          <button
            key={i}
            onClick={() => handleSend(p)}
            className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-800 rounded text-[11px] whitespace-nowrap transition-colors"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Messages Scroll View */}
      <div className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-4 overflow-y-auto space-y-4">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`p-4 rounded-lg border max-w-3xl space-y-2 ${
              m.role === 'user'
                ? 'bg-[#0077C8]/20 border-cyan-500/40 text-white ml-auto'
                : 'bg-slate-900 border-slate-800 text-slate-200'
            }`}
          >
            <div className="flex items-center gap-2 text-[11px] font-bold text-cyan-400 border-b border-slate-800/80 pb-1">
              {m.role === 'user' ? (
                <span>ENGENHEIRO / OPERADOR</span>
              ) : (
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <Bot className="w-4 h-4 text-cyan-400" />
                  <span>PETRO.AI ENGINE (GEMINI 3.6)</span>
                </div>
              )}
            </div>

            <div className="text-xs leading-relaxed whitespace-pre-wrap font-sans">
              {m.text}
            </div>

            {m.citations && m.citations.length > 0 && (
              <div className="pt-2 border-t border-slate-800/80 text-[10px] text-slate-400 space-y-1">
                <div className="font-bold text-slate-300">{t('ai.citation_title')}</div>
                <div className="flex flex-wrap gap-1">
                  {m.citations.map((c, ci) => (
                    <span key={ci} className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-cyan-300">
                      • {c}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg text-cyan-400 flex items-center gap-2 animate-pulse">
            <Sparkles className="w-4 h-4" />
            <span>PETRO.AI consultando telemetria e calculando modelos físicos...</span>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form
        onSubmit={e => {
          e.preventDefault();
          handleSend();
        }}
        className="flex items-center gap-2 shrink-0 pt-2"
      >
        <input
          type="text"
          value={promptInput}
          onChange={e => setPromptInput(e.target.value)}
          placeholder={t('ai.placeholder')}
          className="flex-1 bg-slate-900 border border-slate-800 rounded p-3 text-white text-xs placeholder:text-slate-600 outline-none focus:border-cyan-500"
        />
        <button
          type="submit"
          disabled={loading}
          className="px-5 py-3 bg-[#0077C8] hover:bg-[#0060a3] text-white font-bold text-xs rounded transition-colors flex items-center gap-2 shadow-sm"
        >
          <span>ENVIAR</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
