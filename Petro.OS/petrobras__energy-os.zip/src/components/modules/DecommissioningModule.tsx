import React from 'react';
import { Language } from '../../types';
import { Trash2, Shield, RefreshCw } from 'lucide-react';

export const DecommissioningModule: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Trash2 className="w-5 h-5 text-amber-400" />
          <span>DESCOMISSIONAMENTO // ASSET END-OF-LIFE & CIRCULAR ECONOMY</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Planejamento de fim de vida útil de plataformas maduras (Bacia de Campos), tamponamento e abandono de poços (P&A) e taxa de reciclagem de aço.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Plataforma P-15 (Marlim - Fase Abandono)</span>
          <div className="text-xl font-bold text-amber-300">Custo Estimado P&A: $140M</div>
          <span className="text-slate-500">Remoção de Jaqueta e Topsides</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Índice de Reciclagem de Materiais</span>
          <div className="text-xl font-bold text-emerald-400">96.8% do Aço Reaproveitado</div>
          <span className="text-slate-500">Economia Circular em Estaleiros Nacionais</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Tamponamento Hermético de Poços (P&A)</span>
          <div className="text-xl font-bold text-white">12 Poços Concluídos</div>
          <span className="text-emerald-400">Barreira de Cimento Verificada</span>
        </div>
      </div>
    </div>
  );
};
