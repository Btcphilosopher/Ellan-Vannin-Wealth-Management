import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { FPSO_SUBSYSTEMS } from '../../data/syntheticData';
import { IMAGE_ASSETS } from '../../data/imageAssets';
import { Ship, Activity, Flame, ShieldAlert, Sliders, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';

interface FPSODigitalTwinProps {
  language: Language;
}

export const FPSODigitalTwin: React.FC<FPSODigitalTwinProps> = ({ language }) => {
  const t = (key: string) => translations[language][key] || key;

  const [selectedSubsystem, setSelectedSubsystem] = useState(FPSO_SUBSYSTEMS[0]);
  const [gasLiftInjectionMscfd, setGasLiftInjectionMscfd] = useState(450);
  const [flareRecoveryStatus, setFlareRecoveryStatus] = useState(true);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <Ship className="w-5 h-5 text-cyan-400" />
            <span>GÊMEO DIGITAL DE FPSO // FPSO DIGITAL TWIN (ATLÂNTICO-01)</span>
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Planta de processo offshore de 150,000 bpd: Separação trifásica, compressão de gás, injeção de água, geração elétrica e flare de alta segurança.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs bg-slate-900 border border-slate-800 p-1 rounded">
          <span className="text-slate-400 px-2">Flare Recovery:</span>
          <button
            onClick={() => setFlareRecoveryStatus(!flareRecoveryStatus)}
            className={`px-3 py-1 rounded font-semibold transition-colors ${flareRecoveryStatus ? 'bg-[#00A859] text-white' : 'bg-rose-600 text-white'}`}
          >
            {flareRecoveryStatus ? 'RECUPERAÇÃO ATIVA (99.2%)' : 'DESATIVADO (QUEIMA DIRETA)'}
          </button>
        </div>
      </div>

      {/* FPSO Topside Interactive Subsystems Diagram */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between font-mono text-xs border-b border-slate-800 pb-2">
          <span className="text-cyan-400 font-bold">ESQUEMA DE MÓDULOS DE TOPSIDE & CASCO</span>
          <span className="text-slate-400">Capacidade de Estocagem no Casco: 1,600,000 barris</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          {FPSO_SUBSYSTEMS.map(sub => (
            <div
              key={sub.id}
              onClick={() => setSelectedSubsystem(sub)}
              className={`p-4 rounded-lg border cursor-pointer transition-all space-y-2 ${
                selectedSubsystem.id === sub.id
                  ? 'bg-slate-800 border-cyan-400 shadow-md ring-1 ring-cyan-400/40'
                  : 'bg-slate-950 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-white truncate max-w-[150px]">
                  {language === 'pt-BR' ? sub.namePt : sub.nameEn}
                </span>
                <span className={`px-1.5 py-0.5 text-[10px] rounded font-bold ${sub.status === 'OPERATIONAL' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-400 border border-amber-800'}`}>
                  {sub.status}
                </span>
              </div>

              <div className="space-y-1 text-slate-300 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Pressão:</span>
                  <span className="text-white font-bold">{sub.pressurePsi} psi</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Temperatura:</span>
                  <span>{sub.temperatureC}°C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Vibração:</span>
                  <span className={sub.vibrationMmSec > 4.0 ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                    {sub.vibrationMmSec} mm/s
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Selected Subsystem Detailed Inspection */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span>INSPEÇÃO TÉCNICA DE SUB-SISTEMA</span>
          </h3>

          <div className="space-y-3 text-slate-300">
            <div>
              <span className="text-slate-500 block">Módulo Selecionado:</span>
              <span className="text-sm font-bold text-cyan-300">
                {language === 'pt-BR' ? selectedSubsystem.namePt : selectedSubsystem.nameEn}
              </span>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1.5">
              <div className="flex justify-between"><span>Eficiência do Módulo:</span> <span className="text-emerald-400 font-bold">{selectedSubsystem.efficiencyPercent}%</span></div>
              <div className="flex justify-between"><span>Estado da Válvula SDV:</span> <span className="text-white font-bold">{selectedSubsystem.valveState}</span></div>
              <div className="flex justify-between"><span>Status Manutenção:</span> <span className={selectedSubsystem.maintenanceOverdue ? 'text-amber-400 font-bold' : 'text-emerald-400'}>{selectedSubsystem.maintenanceOverdue ? 'PENDENTE' : 'EM DIA'}</span></div>
            </div>

            {selectedSubsystem.activeAlarms.length > 0 && (
              <div className="bg-amber-950/40 border border-amber-800/80 p-3 rounded space-y-1">
                <div className="text-amber-400 font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>ALARMES ATIVOS EM TELEMETRIA:</span>
                </div>
                {selectedSubsystem.activeAlarms.map((a, i) => (
                  <div key={i} className="text-slate-300 text-[11px]">• {a}</div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Offshore Process Flow Diagram Summary */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">
            BALANÇO DE PROCESSO DA PLATAFORMA (FPSO ATLÂNTICO-01)
          </h3>

          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[11px]">POÇOS PRODUTORES</span>
              <span className="text-base font-bold text-white">154,200 bpd</span>
              <span className="text-[10px] text-slate-500">14 poços abertos</span>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[11px]">SEPARAÇÃO & ESTABILIZAÇÃO</span>
              <span className="text-base font-bold text-emerald-400">151,800 bpd</span>
              <span className="text-[10px] text-slate-500">BSW final 0.1%</span>
            </div>
            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
              <span className="text-slate-400 block text-[11px]">EXPORTAÇÃO / OFFLOADING</span>
              <span className="text-base font-bold text-cyan-400">150,000 bpd</span>
              <span className="text-[10px] text-slate-500">Alívio p/ Petroleiro</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
