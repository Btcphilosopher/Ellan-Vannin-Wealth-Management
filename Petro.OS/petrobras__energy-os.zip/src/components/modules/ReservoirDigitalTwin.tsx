import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { SYNTHETIC_RESERVOIR } from '../../data/syntheticData';
import { calculateReservoirMaterialBalance } from '../../services/simulationEngine';
import { Database, Activity, Sliders, ArrowUpRight, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface ReservoirDigitalTwinProps {
  language: Language;
}

export const ReservoirDigitalTwin: React.FC<ReservoirDigitalTwinProps> = ({ language }) => {
  const t = (key: string) => translations[language][key] || key;

  const [annualProdMMbbl, setAnnualProdMMbbl] = useState(85);
  const [waterInjectMMbbl, setWaterInjectMMbbl] = useState(72);
  const [selectedScenario, setSelectedScenario] = useState<'BASE' | 'INFILL' | 'HIGH_RECOVERY'>('BASE');

  const simResult = calculateReservoirMaterialBalance(SYNTHETIC_RESERVOIR, annualProdMMbbl, waterInjectMMbbl);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <Database className="w-5 h-5 text-cyan-400" />
            <span>GÊMEO DIGITAL DO RESERVATÓRIO // RESERVOIR DIGITAL TWIN</span>
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Modelo físico de balanço de materiais, lei de Darcy e avanço de aquífero para o reservatório {SYNTHETIC_RESERVOIR.name}.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs bg-slate-900 border border-slate-800 p-1 rounded">
          <span className="text-slate-400 px-2">Cenários:</span>
          <button
            onClick={() => setSelectedScenario('BASE')}
            className={`px-3 py-1 rounded font-semibold ${selectedScenario === 'BASE' ? 'bg-[#0077C8] text-white' : 'text-slate-400'}`}
          >
            BASE CASE
          </button>
          <button
            onClick={() => {
              setSelectedScenario('INFILL');
              setAnnualProdMMbbl(110);
            }}
            className={`px-3 py-1 rounded font-semibold ${selectedScenario === 'INFILL' ? 'bg-[#0077C8] text-white' : 'text-slate-400'}`}
          >
            INFILL DRILLING (+2 Poços)
          </button>
          <button
            onClick={() => {
              setSelectedScenario('HIGH_RECOVERY');
              setWaterInjectMMbbl(95);
            }}
            className={`px-3 py-1 rounded font-semibold ${selectedScenario === 'HIGH_RECOVERY' ? 'bg-[#0077C8] text-white' : 'text-slate-400'}`}
          >
            ENHANCED WATER INJECTION
          </button>
        </div>
      </div>

      {/* Primary Parameters Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono space-y-1">
          <span className="text-xs text-slate-400 block">Pressão Atual do Reservatório</span>
          <div className="text-2xl font-bold text-cyan-300">{simResult.newPressurePsi.toFixed(0)} <span className="text-xs font-normal text-slate-400">psi</span></div>
          <span className="text-[11px] text-amber-400">Queda: -{simResult.pressureDropPsi.toFixed(1)} psi/ano</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono space-y-1">
          <span className="text-xs text-slate-400 block">BSW Previsto (Water Breakthrough)</span>
          <div className="text-2xl font-bold text-white">{simResult.estimatedWaterCutPercent.toFixed(1)} <span className="text-xs font-normal text-slate-400">%</span></div>
          <span className="text-[11px] text-slate-400">Avanço do contato água-óleo</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono space-y-1">
          <span className="text-xs text-slate-400 block">Fator de Recuperação Atual (FR)</span>
          <div className="text-2xl font-bold text-emerald-400">{simResult.newRecoveryFactor.toFixed(2)} <span className="text-xs font-normal text-slate-400">%</span></div>
          <span className="text-[11px] text-emerald-400">VOIP: 12.8 Bilhões de barris</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono space-y-1">
          <span className="text-xs text-slate-400 block">Suporte de Injeção de Água</span>
          <div className="text-2xl font-bold text-cyan-400">{waterInjectMMbbl} <span className="text-xs font-normal text-slate-400">MMbbl/ano</span></div>
          <span className="text-[11px] text-cyan-300">Eficiência de Varredura: 85%</span>
        </div>
      </div>

      {/* Simulator Inputs & Physics Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-5">
          <h3 className="text-sm font-bold font-mono text-white border-b border-slate-800 pb-2 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#0077C8]" />
            <span>CONTROLES DE BALANÇO DE MASSAS</span>
          </h3>

          <div className="space-y-4 font-mono text-xs">
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Produção Anual de Óleo (MMbbl):</span>
                <span className="text-cyan-400 font-bold">{annualProdMMbbl} MMbbl</span>
              </div>
              <input
                type="range"
                min={40}
                max={150}
                value={annualProdMMbbl}
                onChange={e => setAnnualProdMMbbl(Number(e.target.value))}
                className="w-full accent-[#0077C8]"
              />
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Injeção Anual de Água (MMbbl):</span>
                <span className="text-emerald-400 font-bold">{waterInjectMMbbl} MMbbl</span>
              </div>
              <input
                type="range"
                min={20}
                max={130}
                value={waterInjectMMbbl}
                onChange={e => setWaterInjectMMbbl(Number(e.target.value))}
                className="w-full accent-[#00A859]"
              />
            </div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 text-xs font-mono space-y-2 text-slate-300">
            <div className="text-cyan-400 font-bold">Equações e Simplificações Físicas:</div>
            <div>• Balanço de Material: dP = (Np - Wi·E) / (N·Ct)</div>
            <div>• Inflow Darcy Approximation: Q_oil = (2π·k·h·dP) / (μ·ln(re/rw))</div>
            <div className="text-[10px] text-amber-300 pt-1">
              *Modelo simplificado com interfaces para conexão de simuladores industriais (Eclipse/tNavigator).
            </div>
          </div>
        </div>

        {/* Detailed Reservoir Properties */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">
            PROPRIEDADES TERMODINÂMICAS E DE FLUIDO (BARRA VELHA)
          </h3>

          <div className="grid grid-cols-2 gap-4 text-slate-300">
            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <div className="text-cyan-400 font-bold border-b border-slate-800 pb-1">PETRÓLEO & GÁS</div>
              <div className="flex justify-between"><span>Grau API:</span> <span className="text-white font-bold">{SYNTHETIC_RESERVOIR.apiGravity}°</span></div>
              <div className="flex justify-between"><span>Razão Gás-Óleo (RGO):</span> <span className="text-white font-bold">{SYNTHETIC_RESERVOIR.gorScfBbl} scf/bbl</span></div>
              <div className="flex justify-between"><span>Temperatura Fundo Poço:</span> <span className="text-white font-bold">{SYNTHETIC_RESERVOIR.temperatureC}°C</span></div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <div className="text-emerald-400 font-bold border-b border-slate-800 pb-1">PETROFÍSICA DE ROCHA</div>
              <div className="flex justify-between"><span>Porosidade Efetiva (Φ):</span> <span className="text-white font-bold">{SYNTHETIC_RESERVOIR.porosityPercent}%</span></div>
              <div className="flex justify-between"><span>Permeabilidade (k):</span> <span className="text-white font-bold">{SYNTHETIC_RESERVOIR.permeabilityMd} mD</span></div>
              <div className="flex justify-between"><span>Saturação Irredutível de Água:</span> <span className="text-white font-bold">{SYNTHETIC_RESERVOIR.waterSaturationPercent}%</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
