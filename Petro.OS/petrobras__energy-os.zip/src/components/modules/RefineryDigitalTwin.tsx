import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { REFINERY_UNITS } from '../../data/syntheticData';
import { IMAGE_ASSETS } from '../../data/imageAssets';
import { Factory, Activity, Sliders, CheckCircle2, TrendingUp, Flame, Zap } from 'lucide-react';

interface RefineryDigitalTwinProps {
  language: Language;
}

export const RefineryDigitalTwin: React.FC<RefineryDigitalTwinProps> = ({ language }) => {
  const t = (key: string) => translations[language][key] || key;

  const [crudeBlend, setCrudeBlend] = useState<'BASE' | 'LIGHT_PRESALT' | 'HEAVY_CAMPOS'>('LIGHT_PRESALT');

  const blendSlates = {
    BASE: { throughputBpd: 239000, dieselPct: 44.5, gasolPct: 28.0, lpgPct: 8.2, fuelOilPct: 14.3, marginUsdBbl: 14.2 },
    LIGHT_PRESALT: { throughputBpd: 252000, dieselPct: 49.2, gasolPct: 31.5, lpgPct: 9.8, fuelOilPct: 6.5, marginUsdBbl: 18.5 },
    HEAVY_CAMPOS: { throughputBpd: 220000, dieselPct: 38.0, gasolPct: 24.0, lpgPct: 6.5, fuelOilPct: 25.5, marginUsdBbl: 11.4 }
  };

  const currentSlate = blendSlates[crudeBlend];

  return (
    <div className="p-6 space-y-6">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <Factory className="w-5 h-5 text-amber-400" />
            <span>GÊMEO DIGITAL DE REFINARIA // REFINERY DIGITAL TWIN (REDUC / REPLAN)</span>
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Simulação de destilação atmosférica (CDU), vácuo (VDU), craqueamento catalítico (FCC) e hidrotratamento de diesel (HDT).
          </p>
        </div>

        {/* Crude Blend Switcher */}
        <div className="flex items-center gap-2 font-mono text-xs bg-slate-900 border border-slate-800 p-1 rounded">
          <span className="text-slate-400 px-2">Carga de Petróleo (Blend):</span>
          <button
            onClick={() => setCrudeBlend('LIGHT_PRESALT')}
            className={`px-3 py-1 rounded font-semibold ${crudeBlend === 'LIGHT_PRESALT' ? 'bg-[#0077C8] text-white' : 'text-slate-400'}`}
          >
            LEVE PRÉ-SAL (29.4° API)
          </button>
          <button
            onClick={() => setCrudeBlend('HEAVY_CAMPOS')}
            className={`px-3 py-1 rounded font-semibold ${crudeBlend === 'HEAVY_CAMPOS' ? 'bg-[#0077C8] text-white' : 'text-slate-400'}`}
          >
            PESADO CAMPOS (18.2° API)
          </button>
        </div>
      </div>

      {/* Hero Asset Picture */}
      <div className="relative rounded-lg overflow-hidden border border-slate-800 h-40">
        <img
          src={IMAGE_ASSETS.refineryHero}
          alt="Petrobras Refinery Plant"
          className="w-full h-full object-cover opacity-40"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A1128] via-[#0A1128]/80 to-transparent p-5 flex flex-col justify-center">
          <div className="text-xs font-mono text-cyan-400 font-bold">REFINARIA DUQUE DE CAXIAS (REDUC)</div>
          <div className="text-xl font-bold text-white font-display">
            SIMULADOR DE RENDIMENTO DE DERIVADOS DE PETRÓLEO
          </div>
          <div className="text-xs text-slate-300 font-mono mt-1">
            Margem de Refino Estimada: <strong className="text-emerald-400">${currentSlate.marginUsdBbl}/bbl</strong> | Processamento: <strong className="text-white">{currentSlate.throughputBpd.toLocaleString()} bpd</strong>
          </div>
        </div>
      </div>

      {/* Yield Breakdown Slate */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Rendimento em Diesel S-10</span>
          <div className="text-2xl font-bold text-emerald-400">{currentSlate.dieselPct}%</div>
          <span className="text-slate-500">Alta Demanda Rodoviária</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Rendimento em Gasolina C</span>
          <div className="text-2xl font-bold text-cyan-300">{currentSlate.gasolPct}%</div>
          <span className="text-slate-500">Unidade FCC ativa</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">GLP (Gás de Cozinha)</span>
          <div className="text-2xl font-bold text-white">{currentSlate.lpgPct}%</div>
          <span className="text-slate-500">Mercado Residencial</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Óleo Combustível / Bunker</span>
          <div className="text-2xl font-bold text-amber-300">{currentSlate.fuelOilPct}%</div>
          <span className="text-slate-500">Resíduo Atmosférico</span>
        </div>
      </div>

      {/* Refinery Units Performance Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-3 font-mono text-xs">
        <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">
          DESEMPENHO DAS UNIDADES DE PROCESSO DE REFINO
        </h3>
        <div className="space-y-2">
          {REFINERY_UNITS.map(unit => (
            <div key={unit.id} className="bg-slate-950 p-3 rounded border border-slate-800 flex items-center justify-between text-slate-300">
              <div>
                <div className="font-bold text-white text-sm">{unit.name}</div>
                <div className="text-slate-500 text-[11px]">Tipo: {unit.type} | Temp Operação: {unit.temperatureC}°C</div>
              </div>
              <div className="text-right">
                <div className="text-emerald-400 font-bold text-sm">{unit.currentThroughputBpd.toLocaleString()} bpd</div>
                <div className="text-slate-400 text-[11px]">Eficiência: {unit.efficiencyPercent}%</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
