import React, { useState, useRef, useEffect } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { IMAGE_ASSETS } from '../../data/imageAssets';
import { Compass, Layers, Eye, EyeOff, Ruler, Mountain, Activity, ChevronRight } from 'lucide-react';

interface ExplorationGeoscienceProps {
  language: Language;
}

export const ExplorationGeoscience: React.FC<ExplorationGeoscienceProps> = ({ language }) => {
  const t = (key: string) => translations[language][key] || key;
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [selectedSubmodule, setSelectedSubmodule] = useState<'Seismic' | 'Petrophysics' | 'Prospects'>('Seismic');
  const [showSeismic, setShowSeismic] = useState(true);
  const [showFaults, setShowFaults] = useState(true);
  const [showWells, setShowWells] = useState(true);
  const [depthMeter, setDepthMeter] = useState(2150);

  // Draw 2D Seismic / Geological Layer Cross Section Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // 1. Water Layer (0 - 80px)
    ctx.fillStyle = '#002B49';
    ctx.fillRect(0, 0, width, 70);
    ctx.fillStyle = '#0077C8';
    ctx.font = '10px IBM Plex Mono';
    ctx.fillText('LÂMINA D\'ÁGUA // WATER LAYER (2,150m)', 15, 35);

    // Seabed line
    ctx.strokeStyle = '#00A859';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 70);
    ctx.lineTo(width, 70);
    ctx.stroke();

    // 2. Post-Salt Layer (70 - 160px)
    ctx.fillStyle = '#1E293B';
    ctx.fillRect(0, 70, width, 90);
    ctx.fillStyle = '#94A3B8';
    ctx.fillText('PÓS-SAL (FOLHELOS E ARENITOS)', 15, 110);

    // 3. Salt Layer Dome (160 - 270px) - Halite & Anhydrite
    ctx.fillStyle = '#0F172A';
    ctx.beginPath();
    ctx.moveTo(0, 160);
    ctx.bezierCurveTo(width * 0.3, 140, width * 0.6, 210, width, 160);
    ctx.lineTo(width, 260);
    ctx.lineTo(0, 260);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#38BDF8';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = '#38BDF8';
    ctx.fillText('CAMADA DE SAL (EVAPORITOS - 2,000m ESPESSURA)', 15, 200);

    // 4. Pre-Salt Reservoir Rock Trap (260 - 360px)
    ctx.fillStyle = '#1D283A';
    ctx.fillRect(0, 260, width, 100);

    // Oil Trap Reservoir Reservoir Dome (Pre-salt Microbialite)
    ctx.fillStyle = '#0077C8';
    ctx.beginPath();
    ctx.ellipse(width * 0.45, 310, 180, 40, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#00A859';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 11px IBM Plex Mono';
    ctx.fillText('RESERVATÓRIO PRÉ-SAL // PRE-SALT RESERVOIR (BARRA VELHA)', width * 0.3, 312);

    // Fault Lines
    if (showFaults) {
      ctx.strokeStyle = '#EF4444';
      ctx.setLineDash([5, 5]);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(width * 0.25, 80);
      ctx.lineTo(width * 0.35, 380);
      ctx.moveTo(width * 0.70, 90);
      ctx.lineTo(width * 0.80, 380);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = '#EF4444';
      ctx.font = '10px IBM Plex Mono';
      ctx.fillText('FALHA GEOLÓGICA REGIONAL F-01', width * 0.36, 370);
    }

    // Well Trajectories
    if (showWells) {
      // Well 7-BUZ-10D
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(width * 0.45, 10);
      ctx.lineTo(width * 0.45, 160);
      ctx.lineTo(width * 0.48, 310);
      ctx.stroke();

      ctx.fillStyle = '#F59E0B';
      ctx.beginPath();
      ctx.arc(width * 0.48, 310, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '10px IBM Plex Mono';
      ctx.fillText('POÇO 7-BUZ-10D', width * 0.45 - 40, 25);
    }

    // Depth Cursor Line
    const cursorY = 70 + ((depthMeter - 2150) / 4000) * 300;
    ctx.strokeStyle = '#00A859';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, cursorY);
    ctx.lineTo(width, cursorY);
    ctx.stroke();
  }, [showSeismic, showFaults, showWells, depthMeter]);

  const prospects = [
    { name: 'PROSPECT OLYMPUS-ALPHA', basin: 'Santos', depthM: 5850, oipMMbbl: 3200, porosityPct: 19.2, status: 'HIGH PRIORITY' },
    { name: 'PROSPECT ATAPU-WEST', basin: 'Santos', depthM: 6120, oipMMbbl: 1850, porosityPct: 17.5, status: 'EVALUATION' },
    { name: 'PROSPECT MARLIM-DEEP', basin: 'Campos', depthM: 4920, oipMMbbl: 940, porosityPct: 16.1, status: 'EXPLORATORY' },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Module Title */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <Compass className="w-5 h-5 text-[#0077C8]" />
            <span>EXPLORAÇÃO E GEOCIÊNCIAS // EXPLORATION & GEOSCIENCE</span>
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Workbench sísmico, interpretação de horizontes, modelo geológico 3D e caracterização petrofísica.
          </p>
        </div>

        <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded">
          <button
            onClick={() => setSelectedSubmodule('Seismic')}
            className={`px-3 py-1 text-xs font-mono font-semibold rounded ${selectedSubmodule === 'Seismic' ? 'bg-[#0077C8] text-white' : 'text-slate-400'}`}
          >
            SÍSMICA 2D/3D
          </button>
          <button
            onClick={() => setSelectedSubmodule('Petrophysics')}
            className={`px-3 py-1 text-xs font-mono font-semibold rounded ${selectedSubmodule === 'Petrophysics' ? 'bg-[#0077C8] text-white' : 'text-slate-400'}`}
          >
            PETROFÍSICA
          </button>
          <button
            onClick={() => setSelectedSubmodule('Prospects')}
            className={`px-3 py-1 text-xs font-mono font-semibold rounded ${selectedSubmodule === 'Prospects' ? 'bg-[#0077C8] text-white' : 'text-slate-400'}`}
          >
            PROSPECT RANKING
          </button>
        </div>
      </div>

      {/* Main Canvas & Inspection Workstation */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-cyan-400 font-bold flex items-center gap-1.5">
                <Layers className="w-4 h-4" />
                SEÇÃO GEOLÓGICA LONGITUDINAL (BACIA DE SANTOS)
              </span>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-1.5 cursor-pointer text-slate-300">
                  <input type="checkbox" checked={showFaults} onChange={e => setShowFaults(e.target.checked)} className="rounded bg-slate-800 border-slate-700" />
                  <span>Falhas</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer text-slate-300">
                  <input type="checkbox" checked={showWells} onChange={e => setShowWells(e.target.checked)} className="rounded bg-slate-800 border-slate-700" />
                  <span>Poços</span>
                </label>
              </div>
            </div>

            {/* Interactive Canvas */}
            <div className="bg-[#050A18] rounded border border-slate-800 overflow-hidden flex justify-center p-2">
              <canvas ref={canvasRef} width={800} height={400} className="w-full h-[400px] object-contain" />
            </div>

            {/* Depth Slider */}
            <div className="flex items-center gap-4 bg-slate-950 p-3 rounded border border-slate-800 text-xs font-mono">
              <span className="text-slate-400 whitespace-nowrap">Medição de Profundidade TVD:</span>
              <input
                type="range"
                min={2150}
                max={6500}
                value={depthMeter}
                onChange={e => setDepthMeter(Number(e.target.value))}
                className="w-full accent-[#0077C8]"
              />
              <span className="text-cyan-400 font-bold text-sm w-24 text-right">{depthMeter.toLocaleString()} m</span>
            </div>
          </div>
        </div>

        {/* Side Panel: Petrophysics & Prospect Ranking */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3 font-mono text-xs">
            <h3 className="font-bold text-white text-sm border-b border-slate-800 pb-2">
              PROPRIEDADES DA ROCHA RESERVATÓRIO
            </h3>
            <div className="space-y-2 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-500">Lito-Fácies:</span>
                <span className="text-white font-semibold">Microbialito Pré-Sal</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Porosidade Média (Φ):</span>
                <span className="text-emerald-400 font-bold">18.5%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Permeabilidade (k):</span>
                <span className="text-white font-bold">420 mD</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Saturação de Óleo (So):</span>
                <span className="text-cyan-400 font-bold">78.8%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Grau API:</span>
                <span className="text-amber-400 font-bold">29.4° API</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
            <h3 className="font-bold text-white text-xs font-mono uppercase tracking-wider border-b border-slate-800 pb-2">
              RANKING DE PROSPECTS EXPLORATÓRIOS
            </h3>
            <div className="space-y-2">
              {prospects.map((p, idx) => (
                <div key={idx} className="bg-slate-950 p-2.5 rounded border border-slate-800 space-y-1 font-mono text-xs">
                  <div className="text-cyan-300 font-bold">{p.name}</div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>VOIP Estimado:</span>
                    <span className="text-emerald-400 font-bold">{p.oipMMbbl} MMbbl</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Profundidade:</span>
                    <span>{p.depthM} m</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
