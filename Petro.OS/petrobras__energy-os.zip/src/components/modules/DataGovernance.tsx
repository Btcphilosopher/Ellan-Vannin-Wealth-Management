import React from 'react';
import { Language } from '../../types';
import { Shield, CheckCircle2, FileText } from 'lucide-react';

export const DataGovernance: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Shield className="w-5 h-5 text-emerald-400" />
          <span>GOVERNAÇA DE DADOS E MODELOS // MODEL REGISTRY & DATA SCHEMAS</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Rastreabilidade de versões de modelos, validação de esquemas Pydantic/Zod e logs de auditoria imutáveis.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Modelo Balanço Reservatório (MBAL-01)</span>
          <div className="text-xl font-bold text-emerald-400">Versão: v3.6.0-APPROVED</div>
          <span className="text-slate-500">Hash SHA-256 Validado</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Esquema de Telemetria (10k Sensores)</span>
          <div className="text-xl font-bold text-white">100% Invariantes Passaram</div>
          <span className="text-emerald-400">Zero Inconsistências Detectadas</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Trilha de Auditoria Criptográfica</span>
          <div className="text-xl font-bold text-cyan-300">RBAC: 8 Perfis Ativos</div>
          <span className="text-slate-500">Logs Imutáveis em Registro Interno</span>
        </div>
      </div>
    </div>
  );
};
