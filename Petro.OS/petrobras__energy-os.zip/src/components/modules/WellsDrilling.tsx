import React, { useState } from 'react';
import { Language, WellData } from '../../types';
import { translations } from '../../i18n/translations';
import { SYNTHETIC_WELLS } from '../../data/syntheticData';
import { calculateDrillingDynamics } from '../../services/simulationEngine';
import { Drill, Activity, AlertTriangle, Compass, Sliders, ShieldCheck } from 'lucide-react';

interface WellsDrillingProps {
  language: Language;
}

export const WellsDrilling: React.FC<WellsDrillingProps> = ({ language }) => {
  const t = (key: string) => translations[language][key] || key;

  const [selectedWell, setSelectedWell] = useState<WellData>(SYNTHETIC_WELLS[0]);
  const [mudWeightPpg, setMudWeightPpg] = useState(12.4);
  const [rpm, setRpm] = useState(120);
  const [wobKlbs, setWobKlbs] = useState(35);

  const dynamics = calculateDrillingDynamics(mudWeightPpg, selectedWell.tvdMeters, rpm, wobKlbs);

  return (
    <div className="p-6 space-y-6">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <Drill className="w-5 h-5 text-amber-400" />
            <span>POÇOS E PERFURAÇÃO // WELLS & DRILLING ENGINEERING</span>
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Monitoramento em tempo real de trajetória direcional, fluido de perfuração, ROP, torque, drag e integridade de poço.
          </p>
        </div>

        {/* Well Selector */}
        <div className="flex items-center gap-2 font-mono text-xs bg-slate-900 border border-slate-800 p-1 rounded">
          <span className="text-slate-400 px-2">Poço Selecionado:</span>
          {SYNTHETIC_WELLS.map(w => (
            <button
              key={w.id}
              onClick={() => setSelectedWell(w)}
              className={`px-2.5 py-1 rounded font-semibold ${selectedWell.id === w.id ? 'bg-[#0077C8] text-white' : 'text-slate-400 hover:text-white'}`}
            >
              {w.name}
            </button>
          ))}
        </div>
      </div>

      {/* Trajectory & Drilling Telemetry Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Profundidade Medida (MD)</span>
          <div className="text-2xl font-bold text-white">{selectedWell.mdMeters.toLocaleString()} <span className="text-xs font-normal text-slate-400">m</span></div>
          <span className="text-slate-500">TVD: {selectedWell.tvdMeters.toLocaleString()} m</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Taxa de Penetração (ROP Estimada)</span>
          <div className="text-2xl font-bold text-emerald-400">{dynamics.estimatedRopMhr.toFixed(1)} <span className="text-xs font-normal text-slate-400">m/h</span></div>
          <span className="text-slate-500">Broca PDC 8-1/2" (Desgaste {selectedWell.bitWearPercent}%)</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Torque de Perfuração</span>
          <div className="text-2xl font-bold text-amber-300">{dynamics.torqueKftlbs.toFixed(1)} <span className="text-xs font-normal text-slate-400">kft·lbs</span></div>
          <span className="text-slate-500">Arraste Drag: {dynamics.dragKlbs.toFixed(1)} klbs</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-1">
          <span className="text-slate-400 block">Janela de Pressão Hidrostática</span>
          <div className="text-2xl font-bold text-cyan-300">{dynamics.hydrostaticPressurePsi.toFixed(0)} <span className="text-xs font-normal text-slate-400">psi</span></div>
          <span className={dynamics.isKickRisk ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
            {dynamics.isKickRisk ? 'ALERTA: Risco de Kick' : 'Estabilidade Nominal'}
          </span>
        </div>
      </div>

      {/* Drilling Simulation Controls & Directional Trajectory */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>SIMULADOR DE PARÂMETROS DE PERFURAÇÃO</span>
          </h3>

          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Peso do Fluido (Mud Weight):</span>
                <span className="text-cyan-400 font-bold">{mudWeightPpg} ppg</span>
              </div>
              <input
                type="range"
                min={9.0}
                max={16.0}
                step={0.1}
                value={mudWeightPpg}
                onChange={e => setMudWeightPpg(Number(e.target.value))}
                className="w-full accent-cyan-500"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Rotação na Broca (RPM):</span>
                <span className="text-amber-400 font-bold">{rpm} RPM</span>
              </div>
              <input
                type="range"
                min={40}
                max={220}
                value={rpm}
                onChange={e => setRpm(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Peso sobre a Broca (WOB):</span>
                <span className="text-emerald-400 font-bold">{wobKlbs} klbs</span>
              </div>
              <input
                type="range"
                min={10}
                max={60}
                value={wobKlbs}
                onChange={e => setWobKlbs(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Well Design & Geometry Details */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">
            ARQUITETURA DE REVESTIMENTO E GEOMETRIA DO POÇO
          </h3>

          <div className="grid grid-cols-2 gap-4 text-slate-300">
            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <div className="text-cyan-400 font-bold border-b border-slate-800 pb-1">TRAJETÓRIA DIRECIONAL</div>
              <div className="flex justify-between"><span>Inclinação:</span> <span className="text-white font-bold">{selectedWell.inclinationDeg}°</span></div>
              <div className="flex justify-between"><span>Azimute:</span> <span className="text-white font-bold">{selectedWell.azimuthDeg}°</span></div>
              <div className="flex justify-between"><span>Pressão de Cabeça:</span> <span className="text-white font-bold">{selectedWell.wellheadPressurePsi} psi</span></div>
            </div>

            <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
              <div className="text-emerald-400 font-bold border-b border-slate-800 pb-1">PRODUÇÃO E CHOKE</div>
              <div className="flex justify-between"><span>Vazão de Óleo:</span> <span className="text-emerald-400 font-bold">{selectedWell.oilRateBpd.toLocaleString()} bpd</span></div>
              <div className="flex justify-between"><span>Abertura Choke:</span> <span className="text-white font-bold">{selectedWell.chokePercent}%</span></div>
              <div className="flex justify-between"><span>BSW (Water Cut):</span> <span className="text-amber-400 font-bold">{selectedWell.waterCutPercent}%</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
