import React from 'react';
import { Language } from '../../types';
import { Package, Ship, Clock } from 'lucide-react';

export const SupplyChainModule: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Package className="w-5 h-5 text-cyan-400" />
          <span>CADEIA DE SUPRIMENTOS // OFFSHORE SUPPLY CHAIN & PSV FLEET</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Programação de embarcações de apoio offshore (PSVs), gestão de sobressalentes críticos e almoxarifados de base de apoio.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">PSV 'Niterói' (Carga de Fluido e Química)</span>
          <div className="text-xl font-bold text-white">Partida: Base Macaé → Búzios</div>
          <span className="text-emerald-400">ETA: 08h 15m (Dentro do Prazo)</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Estoque de Peças Sobressalentes Críticas</span>
          <div className="text-xl font-bold text-emerald-400">Nível do Almoxarifado: 94.2%</div>
          <span className="text-slate-500">Mancais de Compressor C2 em Trânsito</span>
        </div>
      </div>
    </div>
  );
};
