import React from 'react';
import { Language } from '../../types';
import { Flame, Zap, ShieldCheck } from 'lucide-react';

export const PowerEnergyModule: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Flame className="w-5 h-5 text-amber-400" />
          <span>ENERGIA E ELETRICIDADE // POWER & ENERGY DISPATCH</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Geração de energia offshore por turbinas a gás, integração com renováveis (eólica offshore) e despacho elétrico de refinarias.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Geração Turbogás Offshore Total</span>
          <div className="text-xl font-bold text-amber-300">Demanda: 185.0 MW</div>
          <span className="text-slate-500">Eficiência Térmica: 41.2%</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Geração de Vapor Cogeração (Refinarias)</span>
          <div className="text-xl font-bold text-white">420 t/h Vapor Alta Pressão</div>
          <span className="text-slate-500">Potência Elétrica: 120 MW</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Integração Piloto Eólica Offshore</span>
          <div className="text-xl font-bold text-emerald-400">Geração Atual: 18.4 MW</div>
          <span className="text-emerald-400">Disponibilidade: 98.2%</span>
        </div>
      </div>
    </div>
  );
};
