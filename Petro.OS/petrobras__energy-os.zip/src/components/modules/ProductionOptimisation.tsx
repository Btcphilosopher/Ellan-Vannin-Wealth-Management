import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { SYNTHETIC_WELLS } from '../../data/syntheticData';
import { runProductionOptimization } from '../../services/simulationEngine';
import { Zap, Activity, Sliders, CheckCircle2, TrendingUp, DollarSign, Leaf } from 'lucide-react';

interface ProductionOptimisationProps {
  language: Language;
}

export const ProductionOptimisation: React.FC<ProductionOptimisationProps> = ({ language }) => {
  const t = (key: string) => translations[language][key] || key;

  const [maxGasCapMmscfd, setMaxGasCapMmscfd] = useState(10.0);
  const [maxWaterCut, setMaxWaterCut] = useState(15.0);
  const [objective, setObjective] = useState<'MAX_PROD' | 'MIN_EMISSIONS' | 'MAX_VALUE'>('MAX_VALUE');

  const opt = runProductionOptimization(SYNTHETIC_WELLS, maxGasCapMmscfd, maxWaterCut);

  return (
    <div className="p-6 space-y-6">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <Zap className="w-5 h-5 text-emerald-400" />
            <span>OTIMIZAÇÃO DE PRODUÇÃO // PRODUCTION OPTIMISATION ENGINE</span>
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            Otimização restrita multi-variável: Abertura de chokes de poço, elevação artificial (gas lift), pressão de separador e capacidade de compressão topside.
          </p>
        </div>

        {/* Objective Function Switcher */}
        <div className="flex items-center gap-2 font-mono text-xs bg-slate-900 border border-slate-800 p-1 rounded">
          <span className="text-slate-400 px-2">Objetivo:</span>
          <button
            onClick={() => setObjective('MAX_VALUE')}
            className={`px-3 py-1 rounded font-semibold ${objective === 'MAX_VALUE' ? 'bg-[#0077C8] text-white' : 'text-slate-400'}`}
          >
            MAXIMIZAR VALOR ($)
          </button>
          <button
            onClick={() => setObjective('MIN_EMISSIONS')}
            className={`px-3 py-1 rounded font-semibold ${objective === 'MIN_EMISSIONS' ? 'bg-[#00A859] text-white' : 'text-slate-400'}`}
          >
            MINIMIZAR EMISSÕES (CO₂)
          </button>
        </div>
      </div>

      {/* Delta Comparison Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-slate-900 border border-[#00A859]/50 rounded-lg p-4 space-y-2">
          <span className="text-slate-400 block">PRODUÇÃO DE PETRÓLEO</span>
          <div className="text-2xl font-bold text-emerald-400">
            +{opt.deltaProductionPercent}% <span className="text-xs text-slate-300 font-normal">DELTA</span>
          </div>
          <div className="text-[11px] text-slate-300">
            {opt.currentProductionBpd.toLocaleString()} → <strong className="text-white">{opt.optimisedProductionBpd.toLocaleString()} bpd</strong>
          </div>
        </div>

        <div className="bg-slate-900 border border-cyan-500/50 rounded-lg p-4 space-y-2">
          <span className="text-slate-400 block">CONSUMO DE ENERGIA</span>
          <div className="text-2xl font-bold text-cyan-300">
            {opt.deltaEnergyPercent}% <span className="text-xs text-slate-300 font-normal">DELTA</span>
          </div>
          <div className="text-[11px] text-slate-300">
            {opt.currentEnergyMw} MW → <strong className="text-white">{opt.optimisedEnergyMw.toFixed(1)} MW</strong>
          </div>
        </div>

        <div className="bg-slate-900 border border-amber-500/50 rounded-lg p-4 space-y-2">
          <span className="text-slate-400 block">EMISSÕES DE CO₂</span>
          <div className="text-2xl font-bold text-amber-300">
            {opt.deltaEmissionsPercent}% <span className="text-xs text-slate-300 font-normal">DELTA</span>
          </div>
          <div className="text-[11px] text-slate-300">
            {opt.currentEmissionsTCo2d} t/d → <strong className="text-white">{opt.optimisedEmissionsTCo2d.toFixed(1)} t/dia</strong>
          </div>
        </div>

        <div className="bg-slate-900 border border-emerald-500/50 rounded-lg p-4 space-y-2">
          <span className="text-slate-400 block">GANHO ECONÔMICO LÍQUIDO</span>
          <div className="text-2xl font-bold text-emerald-400">
            +${opt.economicGainUsdDay.toLocaleString()} <span className="text-xs text-slate-300 font-normal">/dia</span>
          </div>
          <div className="text-[11px] text-emerald-300 font-bold">
            +${((opt.economicGainUsdDay * 365) / 1e6).toFixed(1)} Milhões / ano
          </div>
        </div>
      </div>

      {/* Constraints Controls & Recommended Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#0077C8]" />
            <span>RESTRIÇÕES OPERACIONAIS DO SISTEMA</span>
          </h3>

          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Capacidade Máxima Gás Topside:</span>
                <span className="text-cyan-400 font-bold">{maxGasCapMmscfd} MMscfd</span>
              </div>
              <input
                type="range"
                min={5.0}
                max={15.0}
                step={0.5}
                value={maxGasCapMmscfd}
                onChange={e => setMaxGasCapMmscfd(Number(e.target.value))}
                className="w-full accent-[#0077C8]"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Limite Tolervável de BSW:</span>
                <span className="text-amber-400 font-bold">{maxWaterCut}%</span>
              </div>
              <input
                type="range"
                min={5.0}
                max={30.0}
                value={maxWaterCut}
                onChange={e => setMaxWaterCut(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#00A859]" />
            <span>RECOMENDAÇÕES EXECUTÁVEIS DE OTIMIZAÇÃO DE CHOKE</span>
          </h3>

          <div className="space-y-2">
            {(language === 'pt-BR' ? opt.recommendationsPt : opt.recommendationsEn).map((rec, i) => (
              <div key={i} className="bg-slate-950 p-3 rounded border border-slate-800 text-slate-200 flex items-start gap-2">
                <span className="text-emerald-400 font-bold shrink-0">[{i + 1}]</span>
                <span>{rec}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
