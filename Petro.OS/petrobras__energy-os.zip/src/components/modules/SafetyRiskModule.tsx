import React from 'react';
import { Language } from '../../types';
import { AlertTriangle, Shield, CheckCircle2 } from 'lucide-react';

export const SafetyRiskModule: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-rose-400" />
          <span>SEGURANÇA E RISCO OPERACIONAL // SAFETY & HAZOP RISK BARRIERS</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Gestão de barreiras de segurança de processo (Bowtie), níveis SIL (Safety Integrity Level) e gestão de alarmes industriais.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Barreira de Sobrepressão (SIL-2)</span>
          <div className="text-xl font-bold text-emerald-400">Status: 100% OPERACIONAL</div>
          <span className="text-slate-500">Válvulas SDV-101 e SDV-102 Testadas</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Detecção de Gás Fogo & Fumaça (F&G)</span>
          <div className="text-xl font-bold text-white">420 Sensores Online</div>
          <span className="text-slate-500">Zero Detecções Anômalas</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-2">
          <span className="text-slate-400">Permissões de Trabalho Críticas (PT)</span>
          <div className="text-xl font-bold text-cyan-300">18 PTs Ativas em FPSOs</div>
          <span className="text-slate-500">100% com Análise Preliminar de Risco (APR)</span>
        </div>
      </div>
    </div>
  );
};
