import React, { useState } from 'react';
import { Language } from '../../types';
import { runMonteCarloEconomicSimulation } from '../../services/simulationEngine';
import { DollarSign, LineChart, Sliders, Play, TrendingUp } from 'lucide-react';

export const EconomicsPlanning: React.FC<{ language: Language }> = ({ language }) => {
  const [brentUsd, setBrentUsd] = useState(78);
  const [capexMillions, setCapexMillions] = useState(18500);
  const [mcResults, setMcResults] = useState<{ meanNpvMillionUsd: number; p10NpvMillionUsd: number; p50NpvMillionUsd: number; p90NpvMillionUsd: number } | null>(null);

  const handleRunMonteCarlo = () => {
    const res = runMonteCarloEconomicSimulation(brentUsd, capexMillions, 1000);
    setMcResults(res);
  };

  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <span>ECONOMIA E PLANEJAMENTO // VALUATION & MONTE CARLO LAB</span>
          </h2>
          <p className="text-slate-400 mt-0.5">
            Modelagem de fluxo de caixa descontado (VPL / TIR), sensibilidade a commodities e simulação stocástica de Monte Carlo.
          </p>
        </div>

        <button
          onClick={handleRunMonteCarlo}
          className="px-4 py-2 bg-[#00A859] hover:bg-[#008f4b] text-white font-bold rounded flex items-center gap-2 transition-colors shadow-sm"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>EXECUTAR SIMULAÇÃO DE MONTE CARLO (1,000 ITERAÇÕES)</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-white text-sm border-b border-slate-800 pb-2 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#0077C8]" />
            <span>PARÂMETROS MACROECONÔMICOS</span>
          </h3>

          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex justify-between"><span>Preço do Brent (USD/bbl):</span> <span className="text-emerald-400 font-bold">${brentUsd}</span></div>
              <input type="range" min={40} max={120} value={brentUsd} onChange={e => setBrentUsd(Number(e.target.value))} className="w-full accent-emerald-500" />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between"><span>CAPEX Anual ($M USD):</span> <span className="text-cyan-400 font-bold">${capexMillions}M</span></div>
              <input type="range" min={10000} max={30000} step={500} value={capexMillions} onChange={e => setCapexMillions(Number(e.target.value))} className="w-full accent-[#0077C8]" />
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-white text-sm border-b border-slate-800 pb-2">
            DISTRIBUIÇÃO DE PROBABILIDADE DE VPL (PROBABILISTIC MONTE CARLO)
          </h3>

          {mcResults ? (
            <div className="grid grid-cols-4 gap-4 text-center">
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">VPL MÉDIO</span>
                <span className="text-xl font-bold text-emerald-400">${mcResults.meanNpvMillionUsd}M</span>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">P10 (CONSERVADOR)</span>
                <span className="text-xl font-bold text-white">${mcResults.p10NpvMillionUsd}M</span>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">P50 (MEDIANA)</span>
                <span className="text-xl font-bold text-cyan-300">${mcResults.p50NpvMillionUsd}M</span>
              </div>
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-slate-400 block text-[11px]">P90 (OTIMISTA)</span>
                <span className="text-xl font-bold text-emerald-400">${mcResults.p90NpvMillionUsd}M</span>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950 p-8 rounded border border-slate-800 text-center text-slate-400">
              Clique no botão verde acima para rodar 1,000 iterações estocásticas de Monte Carlo e visualizar a distribuição de VPL.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
