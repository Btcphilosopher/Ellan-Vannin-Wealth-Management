import React, { useState } from 'react';
import { Language } from '../../types';
import { SCENARIO_PRESETS } from '../../data/syntheticData';
import { Globe2, Play, CheckCircle2, TrendingUp } from 'lucide-react';

export const ScenarioLaboratory: React.FC<{ language: Language }> = ({ language }) => {
  const [selectedScenario, setSelectedScenario] = useState(SCENARIO_PRESETS[0]);

  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Globe2 className="w-5 h-5 text-cyan-400" />
          <span>LABORATÓRIO DE CENÁRIOS MACRO // MACRO SCENARIO LABORATORY</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Simulação de choque de preço de commodity, alteração de tributação de carbono e expansão acelerada de capacidade.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {SCENARIO_PRESETS.map(s => (
          <div
            key={s.id}
            onClick={() => setSelectedScenario(s)}
            className={`p-4 rounded-lg border cursor-pointer transition-all space-y-3 ${
              selectedScenario.id === s.id
                ? 'bg-slate-800 border-cyan-400 shadow-lg'
                : 'bg-slate-900 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="font-bold text-white text-sm">
              {language === 'pt-BR' ? s.namePt : s.nameEn}
            </div>

            <div className="space-y-1 text-slate-300">
              <div className="flex justify-between"><span>Preço Brent:</span> <span className="text-emerald-400 font-bold">${s.brentPriceUsd}/bbl</span></div>
              <div className="flex justify-between"><span>Produção Óleo:</span> <span className="text-white font-bold">{s.oilProductionMMboeD} MMboe/d</span></div>
              <div className="flex justify-between"><span>VPL / TIR:</span> <span className="text-cyan-300 font-bold">${s.npvBillionUsd}B / {s.irrPercent}%</span></div>
              <div className="flex justify-between"><span>Intensidade CO₂:</span> <span className="text-amber-300 font-bold">{s.co2IntensityKgBoe} kg/boe</span></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
