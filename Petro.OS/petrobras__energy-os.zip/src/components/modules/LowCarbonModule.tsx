import React from 'react';
import { Language } from '../../types';
import { LOW_CARBON_PROJECTS } from '../../data/syntheticData';
import { Leaf, DollarSign, TrendingUp } from 'lucide-react';

export const LowCarbonModule: React.FC<{ language: Language }> = ({ language }) => {
  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
          <Leaf className="w-5 h-5 text-emerald-400" />
          <span>ENERGIA DE BAIXA EMISSÃO // LOW-CARBON ENERGY PORTFOLIO</span>
        </h2>
        <p className="text-slate-400 mt-0.5">
          Projetos de investimentos transicionais: Biorrefino (Biodiesel, HVO, SAF), CCUS em águas profundas e Eólica Offshore.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {LOW_CARBON_PROJECTS.map(proj => (
          <div key={proj.id} className="bg-slate-900 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-sm">{proj.name}</span>
              <span className="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] rounded font-bold">{proj.status}</span>
            </div>
            <div className="space-y-1 text-slate-300">
              <div className="flex justify-between"><span>Categoria:</span> <span className="text-white font-bold">{proj.category}</span></div>
              <div className="flex justify-between"><span>Capacidade:</span> <span className="text-cyan-300 font-bold">{proj.capacityMwOrTpa}</span></div>
              <div className="flex justify-between"><span>CAPEX Investimento:</span> <span className="text-amber-400 font-bold">${proj.capexMillionUsd}M</span></div>
              <div className="flex justify-between"><span>VPL / TIR:</span> <span className="text-emerald-400 font-bold">${proj.npvMillionUsd}M / {proj.irrPercent}%</span></div>
              <div className="flex justify-between"><span>Nível TRL:</span> <span className="text-white font-bold">TRL {proj.trlLevel}/9</span></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
