import React, { useState } from 'react';
import { Language } from '../../types';
import { Sliders, Play, CheckCircle2 } from 'lucide-react';

export const EngineeringSimulationLab: React.FC<{ language: Language }> = ({ language }) => {
  const [seedVal, setSeedVal] = useState('0x7E3F91A');
  const [newWellsCount, setNewWellsCount] = useState(4);
  const [gasReinjectPct, setGasReinjectPct] = useState(15);
  const [running, setRunning] = useState(false);
  const [simRunCompleted, setSimRunCompleted] = useState(false);

  const handleRunMultiPhysics = () => {
    setRunning(true);
    setSimRunCompleted(false);
    setTimeout(() => {
      setRunning(false);
      setSimRunCompleted(true);
    }, 1200);
  };

  return (
    <div className="p-6 space-y-6 font-mono text-xs">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <span>LABORATÓRIO DE SIMULAÇÃO INTEGRADA // MULTI-PHYSICS SIMULATION LAB</span>
          </h2>
          <p className="text-slate-400 mt-0.5">
            Ambiente central de simulação determinística acoplada: Reservatório → Poço → Submarino → FPSO → Refino → Mercado.
          </p>
        </div>

        <button
          onClick={handleRunMultiPhysics}
          disabled={running}
          className="px-4 py-2 bg-[#0077C8] hover:bg-[#0060a3] disabled:opacity-50 text-white font-bold rounded flex items-center gap-2 transition-colors shadow-sm"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>{running ? 'EXECUTANDO SIMULAÇÃO...' : 'RODAR EXPANSÃO PRÉ-SAL (DETERMINÍSTICO)'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-white text-sm border-b border-slate-800 pb-2">VARIÁVEIS DE SIMULAÇÃO</h3>
          <div className="space-y-3">
            <div>
              <span className="text-slate-400 block">Semente Determinística (Seed):</span>
              <input type="text" value={seedVal} onChange={e => setSeedVal(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded p-1.5 text-cyan-300 font-bold" />
            </div>
            <div>
              <div className="flex justify-between"><span>Novos Poços Produtores:</span> <span className="text-emerald-400 font-bold">+{newWellsCount}</span></div>
              <input type="range" min={1} max={10} value={newWellsCount} onChange={e => setNewWellsCount(Number(e.target.value))} className="w-full accent-[#0077C8]" />
            </div>
            <div>
              <div className="flex justify-between"><span>Injeção de Gás (% Reinjeção):</span> <span className="text-cyan-300 font-bold">{gasReinjectPct}%</span></div>
              <input type="range" min={0} max={40} value={gasReinjectPct} onChange={e => setGasReinjectPct(Number(e.target.value))} className="w-full accent-cyan-500" />
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-white text-sm border-b border-slate-800 pb-2">RESULTADOS DA SIMULAÇÃO MULTI-FÍSICA</h3>
          {simRunCompleted ? (
            <div className="space-y-3 bg-slate-950 p-4 rounded border border-slate-800 text-slate-200">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <CheckCircle2 className="w-4 h-4" />
                <span>Simulação Executada com Sucesso (Semente {seedVal})</span>
              </div>
              <div className="grid grid-cols-3 gap-3 pt-2">
                <div><span className="text-slate-500 block">Produção Adicional:</span> <span className="text-emerald-400 font-bold text-sm">+{newWellsCount * 6100} bpd</span></div>
                <div><span className="text-slate-500 block">Pressão Média Reservatório:</span> <span className="text-cyan-300 font-bold text-sm">7,320 psi</span></div>
                <div><span className="text-slate-500 block">VPL do Projeto Expansão:</span> <span className="text-emerald-400 font-bold text-sm">+$840M USD</span></div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950 p-8 rounded border border-slate-800 text-center text-slate-400">
              Ajuste as variáveis e execute a simulação para visualizar o perfil completo de produção e emissões.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
