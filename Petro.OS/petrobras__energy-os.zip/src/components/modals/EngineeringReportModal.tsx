import React from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { SYNTHETIC_ASSETS, SYNTHETIC_WELLS, SYNTHETIC_RESERVOIR } from '../../data/syntheticData';
import { FileText, Download, Printer, X, ShieldAlert, CheckCircle } from 'lucide-react';

interface EngineeringReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const EngineeringReportModal: React.FC<EngineeringReportModalProps> = ({
  isOpen,
  onClose,
  language
}) => {
  const t = (key: string) => translations[language][key] || key;

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadCsv = () => {
    const headers = 'AssetID,Name,Type,Status,OilProduction_bpd,GasProduction_Mmscfd,WaterCut_pct,CO2Intensity_kgBoe\n';
    const rows = SYNTHETIC_ASSETS.map(a => `${a.id},"${a.name}",${a.type},${a.status},${a.productionOilBpd},${a.productionGasMmscfd},${a.waterCutPercent},${a.co2IntensityKgBoe}`).join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PETROBRAS_ENERGY_OS_AUDIT_REPORT_${Date.now()}.csv`;
    a.click();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0A1128] border border-slate-700 rounded-lg max-w-4xl w-full h-[640px] flex flex-col shadow-2xl overflow-hidden text-slate-100">
        {/* Modal Top Bar */}
        <div className="bg-slate-900 px-5 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold font-display">
              {language === 'pt-BR' ? 'Relatório de Decisão de Engenharia & Auditoria Operacional' : 'Engineering Decision & Operational Audit Report'}
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadCsv}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0077C8] hover:bg-[#0060a3] text-white text-xs font-semibold rounded transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Imprimir / PDF</span>
            </button>
            <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors ml-2">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Report Document Content */}
        <div className="flex-1 p-8 bg-white text-slate-900 overflow-y-auto space-y-6 font-sans">
          {/* Document Header */}
          <div className="border-b-2 border-slate-900 pb-4 flex items-center justify-between">
            <div>
              <div className="text-2xl font-black font-display tracking-tight text-[#002B49]">
                PETROBRAS // ENERGY OS
              </div>
              <div className="text-xs text-slate-600 font-mono mt-0.5">
                RELATÓRIO TÉCNICO DE AUDITORIA OPERACIONAL E OTIMIZAÇÃO DE ENGENHARIA
              </div>
            </div>
            <div className="text-right text-xs font-mono text-slate-500 space-y-1">
              <div>DATA: {new Date().toLocaleDateString('pt-BR')}</div>
              <div>EMISSÃO: SISTEMA DIGITAL TWIN v3.6</div>
              <div>CÓDIGO: PETRO-AUDIT-2026-X9</div>
            </div>
          </div>

          {/* Mandatory Synthetic Data Disclaimer */}
          <div className="bg-amber-50 border border-amber-300 rounded p-3 text-xs text-amber-900 flex items-center gap-2 font-mono">
            <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0" />
            <div>
              <strong>AVISO DE DADOS SINTÉTICOS:</strong> Este documento foi gerado por simulação computacional utilizando dados não confidenciais e modelos físicos de balanço de massa/energia. Não conectado a SCADA real.
            </div>
          </div>

          {/* Executive Summary */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-[#002B49] uppercase tracking-wider font-mono border-b border-slate-200 pb-1">
              1. RESUMO EXECUTIVO OPERACIONAL
            </h4>
            <div className="grid grid-cols-4 gap-4 text-xs bg-slate-50 p-4 rounded border border-slate-200">
              <div>
                <span className="text-slate-500 block">Produção Total (BOE):</span>
                <span className="font-bold text-slate-900 text-sm">2.41 MMboe/d</span>
              </div>
              <div>
                <span className="text-slate-500 block">Eficiência do Parque:</span>
                <span className="font-bold text-emerald-700 text-sm">95.8%</span>
              </div>
              <div>
                <span className="text-slate-500 block">Intensidade CO₂:</span>
                <span className="font-bold text-slate-900 text-sm">9.8 kgCO₂e/boe</span>
              </div>
              <div>
                <span className="text-slate-500 block">Ganhos de Otimização:</span>
                <span className="font-bold text-emerald-700 text-sm">+3.2% Vazão</span>
              </div>
            </div>
          </div>

          {/* Asset Telemetry Table */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-[#002B49] uppercase tracking-wider font-mono border-b border-slate-200 pb-1">
              2. DESEMPENHO DOS ATIVOS DE E&P E REFINO
            </h4>
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-300 text-slate-700 font-mono">
                  <th className="p-2">CÓDIGO</th>
                  <th className="p-2">ATIVO</th>
                  <th className="p-2">STATUS</th>
                  <th className="p-2 text-right">PETRÓLEO (bpd)</th>
                  <th className="p-2 text-right">BSW (%)</th>
                  <th className="p-2 text-right">CO₂ (kg/boe)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono">
                {SYNTHETIC_ASSETS.map(a => (
                  <tr key={a.id}>
                    <td className="p-2 font-bold">{a.code}</td>
                    <td className="p-2 font-sans font-medium">{a.name}</td>
                    <td className="p-2">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${a.status === 'OPERATIONAL' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                        {a.status}
                      </span>
                    </td>
                    <td className="p-2 text-right">{a.productionOilBpd.toLocaleString()}</td>
                    <td className="p-2 text-right">{a.waterCutPercent}%</td>
                    <td className="p-2 text-right">{a.co2IntensityKgBoe}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Signatures */}
          <div className="pt-8 border-t border-slate-300 flex items-center justify-between text-xs font-mono text-slate-600">
            <div>
              <div className="font-bold text-slate-900">ENGENHARIA DE OPERAÇÕES DE RESERVATÓRIO</div>
              <div>ASSINATURA DIGITAL: 0x892F...C01</div>
            </div>
            <div>
              <div className="font-bold text-slate-900">GERÊNCIA EXECUTIVE DE RECURSOS HÍDRICOS E CARBONO</div>
              <div>VALIDADO POR PETRO.AI</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
