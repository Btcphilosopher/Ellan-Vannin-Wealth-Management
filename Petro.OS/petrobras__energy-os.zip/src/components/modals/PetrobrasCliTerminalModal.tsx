import React, { useState } from 'react';
import { Language } from '../../types';
import { executePetrobrasCliCommand } from '../../services/cliEngine';
import { Terminal, X, Send, CornerDownLeft } from 'lucide-react';

interface PetrobrasCliTerminalModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const PetrobrasCliTerminalModal: React.FC<PetrobrasCliTerminalModalProps> = ({
  isOpen,
  onClose,
  language
}) => {
  const [inputVal, setInputVal] = useState('petrobras-os --help');
  const [history, setHistory] = useState<Array<{ cmd: string; output: string[]; status: 'success' | 'error' }>>([
    {
      cmd: 'petrobras-os init',
      output: [
        '[PETROBRAS//ENERGY OS] CLI Terminal Session Initialized',
        'Type "petrobras-os --help" or "petrobras-os simulate" to run commands.'
      ],
      status: 'success'
    }
  ]);

  if (!isOpen) return null;

  const handleRun = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;

    const res = executePetrobrasCliCommand(inputVal, language);
    setHistory(prev => [...prev, { cmd: inputVal, output: res.output, status: res.status }]);
    setInputVal('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0A1128] border border-cyan-500/30 rounded-lg max-w-3xl w-full h-[540px] flex flex-col shadow-2xl overflow-hidden font-mono text-xs">
        {/* Terminal Header */}
        <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between text-slate-300">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-white">petrobras-os // CLI Workstation</span>
            <span className="text-[10px] text-slate-500 font-normal">v3.6.0-SIMULATED</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Terminal Scroll Area */}
        <div className="flex-1 p-4 bg-[#050A18] overflow-y-auto space-y-4">
          {history.map((h, i) => (
            <div key={i} className="space-y-1">
              <div className="flex items-center gap-2 text-cyan-400 font-semibold">
                <span>$</span>
                <span>{h.cmd}</span>
              </div>
              <div className="pl-4 space-y-0.5 text-slate-300 leading-relaxed font-mono">
                {h.output.map((line, j) => (
                  <div key={j} className={line.startsWith('[ERROR]') ? 'text-rose-400' : line.startsWith('[OK]') || line.startsWith('[PASS]') ? 'text-emerald-400' : ''}>
                    {line}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Terminal Input Line */}
        <form onSubmit={handleRun} className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
          <span className="text-cyan-400 font-bold">$</span>
          <input
            type="text"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            placeholder="e.g. petrobras-os scenario run pre-salt-expansion"
            className="flex-1 bg-transparent border-none outline-none text-white font-mono text-xs placeholder:text-slate-600"
            autoFocus
          />
          <button type="submit" className="px-3 py-1 bg-[#0077C8] hover:bg-[#0060a3] text-white rounded font-sans text-xs font-semibold flex items-center gap-1">
            <span>RUN</span>
            <CornerDownLeft className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
