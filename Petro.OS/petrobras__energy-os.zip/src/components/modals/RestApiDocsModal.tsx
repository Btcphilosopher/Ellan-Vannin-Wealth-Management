import React, { useState } from 'react';
import { Language } from '../../types';
import { SYNTHETIC_ASSETS, SYNTHETIC_WELLS, SYNTHETIC_RESERVOIR } from '../../data/syntheticData';
import { Cpu, X, Play, Copy, Check } from 'lucide-react';

interface RestApiDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const RestApiDocsModal: React.FC<RestApiDocsModalProps> = ({
  isOpen,
  onClose,
  language
}) => {
  const [selectedEndpoint, setSelectedEndpoint] = useState('/api/v1/assets');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const endpoints = [
    { method: 'GET', path: '/api/v1/assets', desc: 'List all 20 operating assets (FPSOs, Refineries, Subsea)' },
    { method: 'GET', path: '/api/v1/wells', desc: 'Retrieve 200 well trajectories, ROP and pressures' },
    { method: 'GET', path: '/api/v1/reservoirs/PRE-SALT-A01', desc: 'Get PRE-SALT-A01 material balance parameters' },
    { method: 'GET', path: '/api/v1/telemetry/live', desc: 'Stream 10,000 synthetic sensor readings' },
    { method: 'POST', path: '/api/v1/simulations/run', desc: 'Execute deterministic multi-physics simulation' },
    { method: 'POST', path: '/api/v1/optimisations/choke', desc: 'Run multi-variable production choke solver' },
    { method: 'GET', path: '/api/v1/emissions/scope123', desc: 'Retrieve Scope 1, 2, and 3 carbon intensity metrics' }
  ];

  const getResponseData = (path: string) => {
    switch (path) {
      case '/api/v1/assets':
        return { status: 200, count: SYNTHETIC_ASSETS.length, data: SYNTHETIC_ASSETS };
      case '/api/v1/wells':
        return { status: 200, count: SYNTHETIC_WELLS.length, data: SYNTHETIC_WELLS };
      case '/api/v1/reservoirs/PRE-SALT-A01':
        return { status: 200, data: SYNTHETIC_RESERVOIR };
      default:
        return {
          status: 200,
          timestamp: new Date().toISOString(),
          model_version: 'PETROBRAS-OS-v3.6.0',
          data: { status: 'OPTIMISED', delta_production_pct: 3.2, net_economic_gain_usd_day: 1435200 }
        };
    }
  };

  const currentResponse = getResponseData(selectedEndpoint);

  const handleCopy = () => {
    navigator.clipboard.writeText(JSON.stringify(currentResponse, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0A1128] border border-slate-700 rounded-lg max-w-4xl w-full h-[600px] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900 px-5 py-3 border-b border-slate-800 flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-emerald-400" />
            <h3 className="text-sm font-bold font-display">PETROBRAS//ENERGY OS REST API v1.0</h3>
            <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded font-mono">
              OpenAPI 3.0
            </span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Split */}
        <div className="flex-1 flex overflow-hidden">
          {/* Endpoint Selector List */}
          <div className="w-1/3 border-r border-slate-800 bg-slate-950/60 p-3 space-y-2 overflow-y-auto">
            <div className="text-[10px] font-mono tracking-wider text-slate-400 uppercase font-semibold px-2 mb-2">
              Endpoints
            </div>
            {endpoints.map(ep => (
              <button
                key={ep.path}
                onClick={() => setSelectedEndpoint(ep.path)}
                className={`w-full text-left p-2.5 rounded transition-colors flex flex-col gap-1 border ${
                  selectedEndpoint === ep.path
                    ? 'bg-slate-800 border-cyan-500/50 text-white'
                    : 'bg-slate-900/40 border-slate-800/80 text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-2 font-mono text-xs">
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${ep.method === 'GET' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-blue-950 text-blue-400 border border-blue-800'}`}>
                    {ep.method}
                  </span>
                  <span className="truncate font-semibold text-cyan-300">{ep.path}</span>
                </div>
                <span className="text-[11px] text-slate-400 line-clamp-1">{ep.desc}</span>
              </button>
            ))}
          </div>

          {/* Endpoint Inspector */}
          <div className="flex-1 flex flex-col p-4 bg-[#050A18] overflow-hidden space-y-3">
            <div className="flex items-center justify-between bg-slate-900 p-3 rounded border border-slate-800">
              <div className="font-mono text-xs text-cyan-400 font-bold">
                {selectedEndpoint}
              </div>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copiado!' : 'Copiar JSON'}</span>
              </button>
            </div>

            <div className="flex-1 bg-slate-950 p-4 rounded border border-slate-800 overflow-y-auto font-mono text-xs text-slate-300">
              <pre>{JSON.stringify(currentResponse, null, 2)}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
