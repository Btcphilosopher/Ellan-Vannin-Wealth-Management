import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../i18n/translations';
import { Play, CheckCircle2, ChevronRight, X, ArrowRight, ShieldCheck } from 'lucide-react';

interface GuidedWorkflowModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  onNavigateToModule: (moduleId: string) => void;
}

export const GuidedWorkflowModal: React.FC<GuidedWorkflowModalProps> = ({
  isOpen,
  onClose,
  language,
  onNavigateToModule
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const t = (key: string) => translations[language][key] || key;

  if (!isOpen) return null;

  const steps = [
    {
      step: 1,
      titlePt: '1. Declínio de Produção Anômalo Detectado',
      titleEn: '1. Production Decline Anomaly Detected',
      module: 'executive',
      descPt: 'O Centro de Comando Executivo sinalizou uma redução de -3.4% na vazão do ativo FPSO P-70 (Atapu), caindo de 133,000 bpd para 128,400 bpd.',
      descEn: 'Executive Command Centre flagged a -3.4% flow drop on asset FPSO P-70 (Atapu), falling from 133,000 bpd to 128,400 bpd.',
      actionTextPt: 'Abrir Painel de Produção & Alertas',
      actionTextEn: 'Open Production & Alarms Panel'
    },
    {
      step: 2,
      titlePt: '2. Identificação de Poços com Restrição',
      titleEn: '2. Identification of Restricting Wells',
      module: 'wells',
      descPt: 'A análise detalhada de telemetria de fundo de poço aponta aumento do BSW para 22.8% no poço 3-SEP-04D e queda de pressão de cabeça (3,410 psi).',
      descEn: 'Detailed downhole telemetry analysis points to BSW rise to 22.8% on well 3-SEP-04D and wellhead pressure drop (3,410 psi).',
      actionTextPt: 'Examinar Trajetória & Pressão dos Poços',
      actionTextEn: 'Inspect Well Trajectories & Pressures'
    },
    {
      step: 3,
      titlePt: '3. Diagnóstico de Depleção no Gêmeo do Reservatório',
      titleEn: '3. Reservoir Digital Twin Depletion Diagnosis',
      module: 'reservoir',
      descPt: 'O modelo de balanço de materiais PRE-SALT-A01 confirma queda localizada de pressão (-18.2 psi) e avanço do contato água-óleo (água de aquífero).',
      descEn: 'PRE-SALT-A01 material balance model confirms localized pressure drop (-18.2 psi) and water-oil contact advance (aquifer water).',
      actionTextPt: 'Abrir Gêmeo Digital do Reservatório',
      actionTextEn: 'Open Reservoir Digital Twin'
    },
    {
      step: 4,
      titlePt: '4. Execução do Algoritmo de Otimização Multi-Variável',
      titleEn: '4. Multi-Variable Optimisation Engine Execution',
      module: 'production_opt',
      descPt: 'O otimizador calcula o rearranjo de aberturas de choke e injeção de gás, propondo estrangular o poço aquoso e abrir o poço 7-BUZ-12HP.',
      descEn: 'The optimiser calculates choke opening rearrangements and gas lift rates, proposing to throttle the water cut well and open 7-BUZ-12HP.',
      actionTextPt: 'Simular Cenários de Otimização',
      actionTextEn: 'Simulate Optimisation Scenarios'
    },
    {
      step: 5,
      titlePt: '5. Validação Econômica e de Intensidade de Carbono',
      titleEn: '5. Economic & Carbon Intensity Validation',
      module: 'economics',
      descPt: 'Resultado do Cenário Otimizado: +18,400 bpd (+3.2%), redução de -2.8% na energia, -1.9% nas emissões de CO₂ e ganho líquido de +$1.4M/dia.',
      descEn: 'Optimised Scenario Outcome: +18,400 bpd (+3.2%), -2.8% energy reduction, -1.9% CO₂ emissions and net gain of +$1.4M/day.',
      actionTextPt: 'Avaliar VPL, TIR e Pegada de Carbono',
      actionTextEn: 'Evaluate NPV, IRR & Carbon Footprint'
    },
    {
      step: 6,
      titlePt: '6. Emissão de Relatório de Decisão de Engenharia',
      titleEn: '6. Engineering Decision Report Generation',
      module: 'governance',
      descPt: 'Sistema emite a Ordem de Operação WO-88219 com assinatura criptográfica e rastreabilidade total de modelo.',
      descEn: 'System generates Operations Order WO-88219 with cryptographic signature and complete model traceability.',
      actionTextPt: 'Aprovar e Emitir Relatório Técnico',
      actionTextEn: 'Approve & Issue Technical Report'
    }
  ];

  const activeStepObj = steps[currentStep];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0A1128] border border-slate-700 rounded-lg max-w-2xl w-full shadow-2xl overflow-hidden text-slate-100">
        {/* Header */}
        <div className="bg-slate-900 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-[#00A859] animate-pulse"></div>
            <h3 className="text-sm font-bold tracking-tight text-white font-display">
              {t('workflow.title')}
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6">
          {/* Progress Tracker Bar */}
          <div className="flex items-center justify-between gap-1">
            {steps.map((s, idx) => (
              <div
                key={s.step}
                onClick={() => setCurrentStep(idx)}
                className={`flex-1 h-2 rounded cursor-pointer transition-all ${
                  idx === currentStep
                    ? 'bg-[#0077C8] ring-2 ring-cyan-400/50'
                    : idx < currentStep
                    ? 'bg-[#00A859]'
                    : 'bg-slate-800'
                }`}
                title={`Etapa ${s.step}`}
              />
            ))}
          </div>

          {/* Active Step Content */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-5 space-y-4">
            <div className="flex items-start justify-between">
              <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/50 px-2 py-0.5 rounded">
                PASSO / STEP {currentStep + 1} DE {steps.length}
              </span>
              <span className="text-xs font-mono text-slate-400">
                MÓDULO: {activeStepObj.module.toUpperCase()}
              </span>
            </div>

            <h4 className="text-lg font-bold text-white font-display">
              {language === 'pt-BR' ? activeStepObj.titlePt : activeStepObj.titleEn}
            </h4>

            <p className="text-sm text-slate-300 leading-relaxed font-sans">
              {language === 'pt-BR' ? activeStepObj.descPt : activeStepObj.descEn}
            </p>

            <div className="pt-2 flex items-center justify-between">
              <button
                onClick={() => {
                  onNavigateToModule(activeStepObj.module);
                  if (currentStep < steps.length - 1) {
                    setCurrentStep(prev => prev + 1);
                  } else {
                    onClose();
                  }
                }}
                className="flex items-center gap-2 px-4 py-2 bg-[#0077C8] hover:bg-[#0060a3] text-white text-xs font-semibold rounded transition-colors shadow-sm"
              >
                <span>{language === 'pt-BR' ? activeStepObj.actionTextPt : activeStepObj.actionTextEn}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2">
                {currentStep > 0 && (
                  <button
                    onClick={() => setCurrentStep(prev => prev - 1)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded transition-colors"
                  >
                    Anterior
                  </button>
                )}
                {currentStep < steps.length - 1 ? (
                  <button
                    onClick={() => setCurrentStep(prev => prev + 1)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs rounded transition-colors"
                  >
                    Próximo Passo
                  </button>
                ) : (
                  <button
                    onClick={onClose}
                    className="px-3 py-1.5 bg-[#00A859] hover:bg-[#008f4b] text-white text-xs font-semibold rounded transition-colors"
                  >
                    Concluir Workflow
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
