export type Language = 'pt-BR' | 'en';

export type SystemStatus = 'OPERATIONAL' | 'WARNING' | 'CRITICAL' | 'MAINTENANCE';

export interface AssetSummary {
  id: string;
  name: string;
  code: string;
  type: 'FPSO' | 'Refinery' | 'Subsea' | 'Platform' | 'GasPlant' | 'PowerPlant';
  basin: string;
  location: { lat: number; lng: number; depthMeters: number };
  status: SystemStatus;
  productionOilBpd: number;
  productionGasMmscfd: number;
  waterCutPercent: number;
  efficiencyPercent: number;
  co2IntensityKgBoe: number;
  activeWells: number;
  criticalAlarms: number;
}

export interface WellData {
  id: string;
  name: string;
  assetId: string;
  type: 'Producer' | 'Injector' | 'Exploratory';
  status: 'PRODUCING' | 'SHUT_IN' | 'INJECTING' | 'DRILLING';
  mdMeters: number; // Measured Depth
  tvdMeters: number; // True Vertical Depth
  inclinationDeg: number;
  azimuthDeg: number;
  oilRateBpd: number;
  gasRateMmscfd: number;
  waterCutPercent: number;
  wellheadPressurePsi: number;
  bottomholePressurePsi: number;
  temperatureC: number;
  chokePercent: number;
  gasLiftRateMscfd: number;
  ropMhr: number; // Rate of Penetration
  mudWeightPpg: number;
  torqueKftlbs: number;
  dragKlbs: number;
  bitWearPercent: number;
}

export interface ReservoirData {
  id: string;
  name: string;
  basin: string;
  formation: string;
  initialPressurePsi: number;
  currentPressurePsi: number;
  temperatureC: number;
  porosityPercent: number;
  permeabilityMd: number;
  waterSaturationPercent: number;
  oilSaturationPercent: number;
  gasSaturationPercent: number;
  apiGravity: number;
  gorScfBbl: number; // Gas-Oil Ratio
  originalOilInPlaceMMbbl: number;
  cumulativeProductionMMbbl: number;
  recoveryFactorPercent: number;
}

export interface FpsoSubsystem {
  id: string;
  namePt: string;
  nameEn: string;
  status: SystemStatus;
  pressurePsi: number;
  temperatureC: number;
  flowRateBpd: number;
  vibrationMmSec: number;
  efficiencyPercent: number;
  valveState: 'OPEN' | 'CLOSED' | 'THROTTLED';
  maintenanceOverdue: boolean;
  activeAlarms: string[];
}

export interface SubseaComponent {
  id: string;
  name: string;
  type: 'Tree' | 'Manifold' | 'Riser' | 'Flowline' | 'Umbilical';
  status: SystemStatus;
  depthMeters: number;
  pressurePsi: number;
  temperatureC: number;
  corrosionRateMpy: number; // mils per year
  hydrateRiskPercent: number;
  valveState: 'OPEN' | 'CLOSED';
}

export interface RefineryUnit {
  id: string;
  name: string;
  type: 'CDU' | 'VDU' | 'HDT' | 'FCC' | 'Sulphur' | 'Hydrogen';
  capacityBpd: number;
  currentThroughputBpd: number;
  temperatureC: number;
  pressureBar: number;
  efficiencyPercent: number;
  energyConsumptMwt: number;
  yields: {
    dieselPercent: number;
    gasolinePercent: number;
    lpgPercent: number;
    fuelOilPercent: number;
    cokeSulphurPercent: number;
  };
}

export interface LowCarbonProject {
  id: string;
  name: string;
  category: 'Biofuels' | 'Solar' | 'Wind' | 'CCUS' | 'Hydrogen';
  capacityMwOrTpa: string;
  capexMillionUsd: number;
  opexMillionUsdYr: number;
  npvMillionUsd: number;
  irrPercent: number;
  trlLevel: number; // Technology Readiness Level 1-9
  carbonAbatedTco2eYr: number;
  status: 'CONCEPT' | 'FEED' | 'EXECUTION' | 'OPERATIONAL';
}

export interface MaintenanceWorkOrder {
  id: string;
  assetName: string;
  equipment: string;
  type: 'PREDICTIVE' | 'PREVENTIVE' | 'CORRECTIVE';
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED';
  dueDate: string;
  assignedTeam: string;
  descriptionPt: string;
  descriptionEn: string;
}

export interface EventLogItem {
  id: string;
  timestamp: string;
  eventType: string;
  source: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  messagePt: string;
  messageEn: string;
}

export interface OptimizationResult {
  currentProductionBpd: number;
  optimisedProductionBpd: number;
  deltaProductionPercent: number;
  currentEnergyMw: number;
  optimisedEnergyMw: number;
  deltaEnergyPercent: number;
  currentEmissionsTCo2d: number;
  optimisedEmissionsTCo2d: number;
  deltaEmissionsPercent: number;
  economicGainUsdDay: number;
  recommendationsPt: string[];
  recommendationsEn: string[];
}

export interface ScenarioResult {
  id: string;
  namePt: string;
  nameEn: string;
  brentPriceUsd: number;
  oilProductionMMboeD: number;
  gasProductionMMboeD: number;
  capexMillionUsd: number;
  opexMillionUsd: number;
  npvBillionUsd: number;
  co2IntensityKgBoe: number;
  irrPercent: number;
}

export interface ModuleDefinition {
  id: string;
  titlePt: string;
  titleEn: string;
  category: 'OPERATIONS' | 'ENGINEERING' | 'GEOSCIENCE' | 'STRATEGY' | 'GOVERNANCE';
  iconName: string;
}
