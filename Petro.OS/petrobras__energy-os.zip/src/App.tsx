import React, { useState, useEffect } from 'react';
import { Language, AssetSummary } from './types';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { GuidedWorkflowModal } from './components/modals/GuidedWorkflowModal';
import { PetrobrasCliTerminalModal } from './components/modals/PetrobrasCliTerminalModal';
import { RestApiDocsModal } from './components/modals/RestApiDocsModal';
import { EngineeringReportModal } from './components/modals/EngineeringReportModal';

// Modules
import { ExecutiveCommandCentre } from './components/modules/ExecutiveCommandCentre';
import { ExplorationGeoscience } from './components/modules/ExplorationGeoscience';
import { ReservoirDigitalTwin } from './components/modules/ReservoirDigitalTwin';
import { WellsDrilling } from './components/modules/WellsDrilling';
import { FPSODigitalTwin } from './components/modules/FPSODigitalTwin';
import { SubseaSystems } from './components/modules/SubseaSystems';
import { ProductionOptimisation } from './components/modules/ProductionOptimisation';
import { RefineryDigitalTwin } from './components/modules/RefineryDigitalTwin';
import { ProcessEngineering } from './components/modules/ProcessEngineering';
import { LogisticsModule } from './components/modules/LogisticsModule';
import { GasNetworkModule } from './components/modules/GasNetworkModule';
import { PowerEnergyModule } from './components/modules/PowerEnergyModule';
import { LowCarbonModule } from './components/modules/LowCarbonModule';
import { EmissionsModule } from './components/modules/EmissionsModule';
import { AssetIntegrityModule } from './components/modules/AssetIntegrityModule';
import { PredictiveMaintenance } from './components/modules/PredictiveMaintenance';
import { SafetyRiskModule } from './components/modules/SafetyRiskModule';
import { SupplyChainModule } from './components/modules/SupplyChainModule';
import { EconomicsPlanning } from './components/modules/EconomicsPlanning';
import { DecommissioningModule } from './components/modules/DecommissioningModule';
import { EngineeringSimulationLab } from './components/modules/EngineeringSimulationLab';
import { AIEngineeringAssistant } from './components/modules/AIEngineeringAssistant';
import { DataGovernance } from './components/modules/DataGovernance';
import { ScenarioLaboratory } from './components/modules/ScenarioLaboratory';

export function App() {
  const [language, setLanguage] = useState<Language>('pt-BR');
  const [activeModule, setActiveModule] = useState<string>('executive');

  // Modals state
  const [isWorkflowOpen, setIsWorkflowOpen] = useState(false);
  const [isCliOpen, setIsCliOpen] = useState(false);
  const [isApiOpen, setIsApiOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);

  // Selected asset state
  const [selectedAsset, setSelectedAsset] = useState<AssetSummary | null>(null);

  // Persist language selection
  useEffect(() => {
    const saved = localStorage.getItem('petrobras_os_lang');
    if (saved === 'pt-BR' || saved === 'en') {
      setLanguage(saved);
    }
  }, []);

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('petrobras_os_lang', lang);
  };

  const renderActiveModule = () => {
    switch (activeModule) {
      case 'executive':
        return (
          <ExecutiveCommandCentre
            language={language}
            onSelectAsset={asset => setSelectedAsset(asset)}
            onNavigateToModule={modId => setActiveModule(modId)}
          />
        );
      case 'geoscience':
        return <ExplorationGeoscience language={language} />;
      case 'reservoir':
        return <ReservoirDigitalTwin language={language} />;
      case 'wells':
        return <WellsDrilling language={language} />;
      case 'fpso':
        return <FPSODigitalTwin language={language} />;
      case 'subsea':
        return <SubseaSystems language={language} />;
      case 'production_opt':
        return <ProductionOptimisation language={language} />;
      case 'refinery':
        return <RefineryDigitalTwin language={language} />;
      case 'process_eng':
        return <ProcessEngineering language={language} />;
      case 'logistics':
        return <LogisticsModule language={language} />;
      case 'gas_network':
        return <GasNetworkModule language={language} />;
      case 'power_energy':
        return <PowerEnergyModule language={language} />;
      case 'low_carbon':
        return <LowCarbonModule language={language} />;
      case 'carbon_emissions':
        return <EmissionsModule language={language} />;
      case 'asset_integrity':
        return <AssetIntegrityModule language={language} />;
      case 'predictive_maint':
        return <PredictiveMaintenance language={language} />;
      case 'safety_risk':
        return <SafetyRiskModule language={language} />;
      case 'supply_chain':
        return <SupplyChainModule language={language} />;
      case 'economics':
        return <EconomicsPlanning language={language} />;
      case 'decommissioning':
        return <DecommissioningModule language={language} />;
      case 'simulation_lab':
        return <EngineeringSimulationLab language={language} />;
      case 'petro_ai':
        return <AIEngineeringAssistant language={language} />;
      case 'governance':
        return <DataGovernance language={language} />;
      case 'scenario_lab':
        return <ScenarioLaboratory language={language} />;
      default:
        return (
          <ExecutiveCommandCentre
            language={language}
            onSelectAsset={asset => setSelectedAsset(asset)}
            onNavigateToModule={modId => setActiveModule(modId)}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#0A1128] text-slate-100 flex flex-col font-sans selection:bg-[#0077C8] selection:text-white">
      {/* Top Header */}
      <Header
        language={language}
        onLanguageChange={handleLanguageChange}
        onOpenCli={() => setIsCliOpen(true)}
        onOpenReport={() => setIsReportOpen(true)}
        onOpenApi={() => setIsApiOpen(true)}
        onStartWorkflow={() => setIsWorkflowOpen(true)}
      />

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          activeModule={activeModule}
          onSelectModule={modId => setActiveModule(modId)}
          language={language}
        />

        <main className="flex-1 overflow-y-auto bg-[#0A1128]">
          {renderActiveModule()}
        </main>
      </div>

      {/* Modals */}
      <GuidedWorkflowModal
        isOpen={isWorkflowOpen}
        onClose={() => setIsWorkflowOpen(false)}
        language={language}
        onNavigateToModule={modId => setActiveModule(modId)}
      />

      <PetrobrasCliTerminalModal
        isOpen={isCliOpen}
        onClose={() => setIsCliOpen(false)}
        language={language}
      />

      <RestApiDocsModal
        isOpen={isApiOpen}
        onClose={() => setIsApiOpen(false)}
        language={language}
      />

      <EngineeringReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        language={language}
      />
    </div>
  );
}

export default App;
