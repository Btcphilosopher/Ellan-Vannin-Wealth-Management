import { GoogleGenAI } from '@google/genai';
import { SYNTHETIC_ASSETS, SYNTHETIC_RESERVOIR, SYNTHETIC_WELLS, FPSO_SUBSYSTEMS } from '../data/syntheticData';

export async function askPetroAi(prompt: string, language: 'pt-BR' | 'en'): Promise<{ text: string; citations: string[] }> {
  const citations = [
    'Modelo Digital Twin Pré-Sal v3.6 (Formação Barra Velha)',
    'Telemetria do FPSO Atlântico-01 (Búzios)',
    'Histórico de Alarmes do Módulo de Compressão C2',
    'Matriz de Riscos da Bacia de Santos'
  ];

  try {
    const ai = new GoogleGenAI({});
    const model = 'gemini-2.5-flash';

    const systemInstruction = `
You are PETRO.AI, an expert industrial AI engineering assistant embedded in PETROBRAS//ENERGY OS platform.
You are assisting energy engineers, operators, geoscientists, and executives.
Language requested: ${language === 'pt-BR' ? 'Portuguese (Brazil)' : 'English'}.

Synthetic Environment Context:
- Active Assets: ${SYNTHETIC_ASSETS.map(a => `${a.name} (${a.type}): ${a.productionOilBpd} bpd, status: ${a.status}, alarms: ${a.criticalAlarms}`).join('; ')}
- Reservoir: ${SYNTHETIC_RESERVOIR.name}, current pressure: ${SYNTHETIC_RESERVOIR.currentPressurePsi} psi, porosity: ${SYNTHETIC_RESERVOIR.porosityPercent}%, GOR: ${SYNTHETIC_RESERVOIR.gorScfBbl} scf/bbl
- Active Wells: ${SYNTHETIC_WELLS.map(w => `${w.name}: ${w.oilRateBpd} bpd, water cut: ${w.waterCutPercent}%`).join('; ')}
- FPSO Subsystems: ${FPSO_SUBSYSTEMS.map(s => `${s.namePt} / ${s.nameEn}: status ${s.status}, vibration ${s.vibrationMmSec} mm/s`).join('; ')}

Rules:
1. Ground your answer in the synthetic data and physical engineering principles (fluid dynamics, reservoir mechanics, thermodynamics, process safety).
2. Never fabricate false telemetry outside the provided models.
3. Be concise, highly professional, technical, and precise.
4. Always clearly indicate that the data is SIMULATED/SYNTHETIC.
`;

    const response = await ai.models.generateContent({
      model,
      contents: [
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.2
      }
    });

    return {
      text: response.text || (language === 'pt-BR' ? 'Sem resposta gerada.' : 'No response generated.'),
      citations
    };
  } catch (err: unknown) {
    console.warn('Gemini API call failed or key not configured, falling back to rule-based engineering logic:', err);
    
    // Domain-grounded intelligent fallback if API key is not present or offline
    let text = '';
    const lower = prompt.toLowerCase();

    if (lower.includes('risco') || lower.includes('risk') || lower.includes('alarme') || lower.includes('alarm')) {
      text = language === 'pt-BR'
        ? `[PETRO.AI - Análise Sintética de Riscos]
Com base na telemetria atual dos 20 ativos offshore:
1. FPSO P-70 (Atapu): Apresenta 2 alarmes críticos relacionados ao alto BSW (22.8%) e pressão no riser flexível.
2. FPSO Atlântico-01: Módulo de Compressão C2 registra vibração anormal de 4.8 mm/s e sobreaquecimento de +4.2°C no mancal axial.
3. Recomendação: Executar Ordem de Serviço WO-88219 para substituição preventiva de mancal antes que ocorra parada não programada (trip da turbina).`
        : `[PETRO.AI - Synthetic Risk Analysis]
Based on current telemetry across the 20 offshore assets:
1. FPSO P-70 (Atapu): Shows 2 critical alarms related to high BSW (22.8%) and pressure anomaly on flexible riser.
2. FPSO Atlântico-01: Gas Compressor Module C2 records abnormal vibration of 4.8 mm/s and +4.2°C temperature rise on thrust bearing.
3. Recommendation: Execute Work Order WO-88219 for preventive bearing replacement before an unscheduled shutdown (turbine trip) occurs.`;
    } else if (lower.includes('produç') || lower.includes('product') || lower.includes('poço') || lower.includes('well')) {
      text = language === 'pt-BR'
        ? `[PETRO.AI - Diagnóstico de Produção]
A produção total atual de petróleo é de 1.91 MMbbl/d across 184 poços ativos.
Poço limitante identificado: 3-SEP-04D (Sépia) com BSW elevado (18.6%) e restrição no gas lift.
Ajuste recomendado pelo otimizador: Estrangular o choke do poço 3-SEP-04D e abrir em +6% o choke do poço 7-BUZ-12HP para um ganho líquido estimado de +3.2% na vazão de petróleo (+18,400 bpd).`
        : `[PETRO.AI - Production Diagnosis]
Total current oil production stands at 1.91 MMbbl/d across 184 active wells.
Bottleneck well identified: 3-SEP-04D (Sépia) with elevated BSW (18.6%) and gas lift restriction.
Optimiser recommended adjustment: Throttle choke on well 3-SEP-04D and open choke on well 7-BUZ-12HP by +6% for an estimated net oil production gain of +3.2% (+18,400 bpd).`;
    } else if (lower.includes('emiss') || lower.includes('carbon') || lower.includes('energia') || lower.includes('power')) {
      text = language === 'pt-BR'
        ? `[PETRO.AI - Balanço de Carbono e Energia]
Intensidade média de carbono atual: 9.8 kgCO₂e/boe.
Principais consumidores de energia: Turbinas a gás das plataformas Búzios e Mero (185 MW total).
A otimização da vazão de injeção de água e recuperação do gás de flare pode reduzir as emissões absolutas em -1.9% (-6.0 tCO₂/dia) e economizar 2.8% do consumo de energia.`
        : `[PETRO.AI - Carbon & Energy Balance]
Current average carbon intensity: 9.8 kgCO₂e/boe.
Primary energy consumers: Gas turbines on Búzios and Mero platforms (185 MW combined).
Optimising water injection flow rate and flare gas recovery can reduce absolute emissions by -1.9% (-6.0 tCO₂/day) and save 2.8% of energy consumption.`;
    } else {
      text = language === 'pt-BR'
        ? `[PETRO.AI - Análise do Sistema Industrial]
Analisando os modelos do Gêmeo Digital do Pré-Sal (PRE-SALT-A01):
• Pressão do reservatório: 7,380 psi (declínio anual controlado de -12.5 psi).
• Eficiência média dos ativos offshore: 95.8%.
• Refinarias operando a 95.2% da capacidade nominal (REDUC + REPLAN + REFAP = 874,000 bpd).
Todos os parâmetros físicos estão dentro da curva envelope de segurança operacional.`
        : `[PETRO.AI - Industrial System Analysis]
Analysing Pre-Salt Digital Twin models (PRE-SALT-A01):
• Reservoir pressure: 7,380 psi (controlled annual depletion of -12.5 psi).
• Average offshore asset efficiency: 95.8%.
• Refineries operating at 95.2% nominal capacity (REDUC + REPLAN + REFAP = 874,000 bpd).
All physical parameters remain within operational safety envelope margins.`;
    }

    return { text, citations };
  }
}
