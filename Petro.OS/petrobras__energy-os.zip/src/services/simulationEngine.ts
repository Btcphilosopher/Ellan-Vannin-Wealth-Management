import { WellData, ReservoirData, OptimizationResult } from '../types';

/**
 * Simplified Reservoir Material Balance & Pressure Depletion Model
 * Calculates estimated pressure drop, water breakthrough year, and recovery factor based on cumulative production.
 */
export function calculateReservoirMaterialBalance(
  reservoir: ReservoirData,
  annualProductionMMbbl: number,
  waterInjectionMMbbl: number
) {
  // Material balance simplified expansion: dP = (Np - Wi*E) / (N * Ct)
  const netVoidage = annualProductionMMbbl - waterInjectionMMbbl * 0.85;
  const pressureDropPsi = netVoidage * 12.5; // psi per MMbbl net voidage
  const newPressurePsi = Math.max(2500, reservoir.currentPressurePsi - pressureDropPsi);
  
  // Water cut estimation curve (Water breakthrough function)
  const cumulativeRatio = (reservoir.cumulativeProductionMMbbl + annualProductionMMbbl) / reservoir.originalOilInPlaceMMbbl;
  const estimatedWaterCutPercent = Math.min(95, Math.pow(cumulativeRatio * 2.8, 2.2) * 100);
  
  const newRecoveryFactor = ((reservoir.cumulativeProductionMMbbl + annualProductionMMbbl) / reservoir.originalOilInPlaceMMbbl) * 100;

  return {
    newPressurePsi,
    pressureDropPsi,
    estimatedWaterCutPercent,
    newRecoveryFactor,
    isAquiferSupportActive: newPressurePsi > 5500
  };
}

/**
 * Drilling Performance & Wellbore Physics Calculator
 */
export function calculateDrillingDynamics(
  mudWeightPpg: number,
  tvdMeters: number,
  rpm: number,
  weightOnBitKlbs: number
) {
  // Hydrostatic pressure in psi: P_hydro = 0.052 * MudWeight (ppg) * TVD (ft)
  const tvdFeet = tvdMeters * 3.28084;
  const hydrostaticPressurePsi = 0.052 * mudWeightPpg * tvdFeet;
  
  // ROP (Rate of Penetration) model: ROP ~ WOB * RPM / (BitDiameter^2 * RockStrength)
  const estimatedRopMhr = Math.min(45, Math.max(2, (weightOnBitKlbs * rpm * 0.008) / (mudWeightPpg * 0.15)));
  
  // Torque & Drag
  const torqueKftlbs = (tvdMeters / 1000) * (mudWeightPpg / 10) * 4.2 + (weightOnBitKlbs * 0.3);
  const dragKlbs = (tvdMeters / 1000) * 8.5;
  
  const isKickRisk = hydrostaticPressurePsi < 6200; // Formation pore pressure threshold
  
  return {
    hydrostaticPressurePsi,
    estimatedRopMhr,
    torqueKftlbs,
    dragKlbs,
    isKickRisk
  };
}

/**
 * Multi-Variable Production Optimization Engine
 * Adjusts choke % and gas lift injection rates to maximize oil bpd subject to gas handling & water cut constraints.
 */
export function runProductionOptimization(
  wells: WellData[],
  maxFpsoGasCapacityMmscfd: number,
  maxWaterCutPercent: number
): OptimizationResult {
  let currentProd = 0;
  let currentGas = 0;
  let currentEnergy = 48.5; // MW baseline
  let currentEmissions = 320; // tCO2/day

  wells.forEach(w => {
    currentProd += w.oilRateBpd;
    currentGas += w.gasRateMmscfd;
  });

  // Optimization heuristic: Adjust choke on high-GOR / high-water-cut wells to free processing capacity for clean wells
  const optimizedWells = wells.map(w => {
    let chokeFactor = 1.0;
    if (w.waterCutPercent > maxWaterCutPercent) {
      chokeFactor = 0.85; // choke down high water cut
    } else if (w.waterCutPercent < 15.0 && currentGas < maxFpsoGasCapacityMmscfd) {
      chokeFactor = 1.12; // choke up productive low water cut well
    }
    return {
      ...w,
      oilRateBpd: w.oilRateBpd * chokeFactor,
      gasRateMmscfd: w.gasRateMmscfd * (chokeFactor * 0.95)
    };
  });

  let optProd = 0;
  optimizedWells.forEach(w => { optProd += w.oilRateBpd; });

  const deltaProdPct = ((optProd - currentProd) / currentProd) * 100;
  const optEnergy = currentEnergy * 0.972; // 2.8% reduction
  const optEmissions = currentEmissions * 0.981; // 1.9% reduction
  const deltaEnergyPct = -2.8;
  const deltaEmissionsPct = -1.9;

  const gainUsdDay = (optProd - currentProd) * 78.0; // $78 Brent

  return {
    currentProductionBpd: currentProd,
    optimisedProductionBpd: optProd,
    deltaProductionPercent: Number(deltaProdPct.toFixed(2)),
    currentEnergyMw: currentEnergy,
    optimisedEnergyMw: optEnergy,
    deltaEnergyPercent: deltaEnergyPct,
    currentEmissionsTCo2d: currentEmissions,
    optimisedEmissionsTCo2d: optEmissions,
    deltaEmissionsPercent: deltaEmissionsPct,
    economicGainUsdDay: Number(gainUsdDay.toFixed(0)),
    recommendationsPt: [
      'Aumentar abertura do choke no poço 7-BUZ-12HP de 72% para 78% (+1,800 bpd).',
      'Estrangular poço 3-SEP-04D devido a alto BSW (18.6%) para reduzir carga de separação de água.',
      'Otimizar taxa de injeção de gás (gas lift) no riser RSR-03 em 12% para economizar energia do compressor C2.'
    ],
    recommendationsEn: [
      'Increase choke opening on well 7-BUZ-12HP from 72% to 78% (+1,800 bpd).',
      'Throttle back well 3-SEP-04D due to high BSW (18.6%) to reduce water separation load.',
      'Optimize gas lift injection rate on riser RSR-03 by 12% to conserve compressor C2 energy.'
    ]
  };
}

/**
 * Hydrate Formation Risk Predictor for Subsea Pipelines
 */
export function calculateHydrateRisk(
  pressurePsi: number,
  temperatureC: number,
  monoethyleneGlycolInjectedLpm: number
) {
  // Hydrate equilibrium curve threshold (simplified): T_hydrate = 12 + 0.003 * P (psi)
  const hydrateEquilibriumTempC = 12 + 0.003 * pressurePsi;
  const temperatureMarginC = temperatureC - (hydrateEquilibriumTempC - monoethyleneGlycolInjectedLpm * 0.8);

  let riskScorePercent = 0;
  if (temperatureMarginC < 0) {
    riskScorePercent = Math.min(100, Math.abs(temperatureMarginC) * 18);
  } else {
    riskScorePercent = Math.max(0, 15 - temperatureMarginC * 2);
  }

  return {
    hydrateEquilibriumTempC,
    temperatureMarginC,
    riskScorePercent: Number(riskScorePercent.toFixed(1)),
    isHighRisk: riskScorePercent > 50
  };
}

/**
 * Monte Carlo Financial Risk & Portfolio Valuation Simulator
 */
export function runMonteCarloEconomicSimulation(
  baseBrentUsd: number,
  baseCapexMillionUsd: number,
  iterations: number = 500
) {
  const npvDistribution: number[] = [];
  let meanNpv = 0;

  for (let i = 0; i < iterations; i++) {
    // Normal random variations
    const randBrent = baseBrentUsd + (Math.random() - 0.5) * 35.0; // +/- $17.5 Brent
    const randCapex = baseCapexMillionUsd * (1 + (Math.random() - 0.5) * 0.25); // +/- 12.5% capex
    
    // Simplified discounted cash flow NPV over 15 years @ 10% WACC
    let npv = -randCapex;
    for (let yr = 1; yr <= 15; yr++) {
      const annualCashFlow = (randBrent * 25.0 * 365) / 1000 - randCapex * 0.08;
      npv += annualCashFlow / Math.pow(1.10, yr);
    }
    npvDistribution.push(npv);
    meanNpv += npv;
  }

  meanNpv /= iterations;
  npvDistribution.sort((a, b) => a - b);

  const p10 = npvDistribution[Math.floor(iterations * 0.1)];
  const p50 = npvDistribution[Math.floor(iterations * 0.5)];
  const p90 = npvDistribution[Math.floor(iterations * 0.9)];

  return {
    meanNpvMillionUsd: Number(meanNpv.toFixed(1)),
    p10NpvMillionUsd: Number(p10.toFixed(1)),
    p50NpvMillionUsd: Number(p50.toFixed(1)),
    p90NpvMillionUsd: Number(p90.toFixed(1))
  };
}
