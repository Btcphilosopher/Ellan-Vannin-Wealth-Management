import { EventLogItem } from '../types';
import { EVENT_HISTORY } from '../data/syntheticData';

type EventListener = (event: EventLogItem) => void;

class IndustrialEventBus {
  private listeners: Map<string, EventListener[]> = new Map();
  private eventHistory: EventLogItem[] = [...EVENT_HISTORY];

  public subscribe(eventType: string, callback: EventListener): () => void {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, []);
    }
    this.listeners.get(eventType)!.push(callback);

    return () => {
      const list = this.listeners.get(eventType);
      if (list) {
        this.listeners.set(eventType, list.filter(cb => cb !== callback));
      }
    };
  }

  public emit(eventType: string, payload: Omit<EventLogItem, 'id' | 'timestamp'>): EventLogItem {
    const timestamp = new Date().toLocaleTimeString('pt-BR', { hour12: false });
    const fullEvent: EventLogItem = {
      id: `evt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp,
      ...payload
    };

    this.eventHistory.unshift(fullEvent);
    if (this.eventHistory.length > 50) {
      this.eventHistory.pop();
    }

    const callbacks = this.listeners.get(eventType) || [];
    callbacks.forEach(cb => cb(fullEvent));

    const wildcardCallbacks = this.listeners.get('*') || [];
    wildcardCallbacks.forEach(cb => cb(fullEvent));

    return fullEvent;
  }

  public getHistory(): EventLogItem[] {
    return [...this.eventHistory];
  }
}

export const eventBus = new IndustrialEventBus();
