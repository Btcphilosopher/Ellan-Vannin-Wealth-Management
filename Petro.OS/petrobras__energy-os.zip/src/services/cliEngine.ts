import { SYNTHETIC_ASSETS, SYNTHETIC_WELLS, SYNTHETIC_RESERVOIR } from '../data/syntheticData';
import { runProductionOptimization } from './simulationEngine';

export interface CliCommandResult {
  output: string[];
  status: 'success' | 'error';
}

export function executePetrobrasCliCommand(commandLine: string, language: 'pt-BR' | 'en'): CliCommandResult {
  const parts = commandLine.trim().split(' ');
  const base = parts[0]?.toLowerCase();
  const subCommand = parts[1]?.toLowerCase();
  const arg = parts[2]?.toLowerCase();

  if (base !== 'petrobras-os') {
    return {
      output: [
        `Command not recognized: '${commandLine}'.`,
        `Try: 'petrobras-os --help' or 'petrobras-os init'`
      ],
      status: 'error'
    };
  }

  if (!subCommand || subCommand === '--help' || subCommand === '-h') {
    return {
      output: [
        'PETROBRAS//ENERGY OS Industrial CLI Interface (v3.6.0)',
        '====================================================',
        'Available Commands:',
        '  petrobras-os init                    Initialize digital twin environment',
        '  petrobras-os seed                    Reset synthetic telemetry & seeds',
        '  petrobras-os assets                  List active operating units and FPSOs',
        '  petrobras-os telemetry               Dump live sensor stream sample',
        '  petrobras-os simulate                Run reservoir & facility physical balance',
        '  petrobras-os optimise                Execute choke & gas lift optimization',
        '  petrobras-os scenario run <name>     Execute macro scenario (e.g., pre-salt-expansion)',
        '  petrobras-os report                  Generate PDF/CSV audit report schema',
        '  petrobras-os validate                Run physical mass balance verification'
      ],
      status: 'success'
    };
  }

  switch (subCommand) {
    case 'init':
      return {
        output: [
          '[PETROBRAS//ENERGY OS] Initializing synthetic digital twin nodes...',
          '[OK] Connected 20 offshore assets (Santos & Campos basins)',
          '[OK] Registered 200 wells, 5 reservoirs, 8 subsea manifolds',
          '[OK] Synced 3 refineries (REDUC, REPLAN, REFAP) and national gas grid',
          '[OK] Real-time telemetry engine active (10,000 synthetic sensors online)',
          'System Status: OPERATIONAL / OPERAÇÃO NORMAL'
        ],
        status: 'success'
      };

    case 'seed':
      return {
        output: [
          '[SEED] Re-seeding deterministic pseudorandom telemetry generator.',
          'Random seed set to: 0x7E3F91A',
          '[OK] Reset noise, drift, and fault injection matrices.'
        ],
        status: 'success'
      };

    case 'assets':
      return {
        output: [
          'ACTIVE OPERATING ASSETS (PETROBRAS DIGITAL TWIN):',
          '------------------------------------------------',
          ...SYNTHETIC_ASSETS.map(a => 
            `• [${a.code}] ${a.name} | Status: ${a.status} | Prod: ${a.productionOilBpd.toLocaleString()} bpd | CO2: ${a.co2IntensityKgBoe} kg/boe`
          )
        ],
        status: 'success'
      };

    case 'telemetry':
      return {
        output: [
          'LIVE SENSOR TELEMETRY SAMPLE STREAM (100ms interval):',
          `[${new Date().toISOString()}] FPSO-ATL-01.PT-101.PRESSURE: 3,850.4 psi [NOMINAL]`,
          `[${new Date().toISOString()}] FPSO-ATL-01.TT-104.TEMP: 78.42 °C [NOMINAL]`,
          `[${new Date().toISOString()}] FPSO-CAR-02.VT-201.VIB: 4.82 mm/s [WARNING - BEARING C2]`,
          `[${new Date().toISOString()}] REF-REDUC.FT-302.FLOW: 228,400 bpd [NOMINAL]`,
          `[${new Date().toISOString()}] SUBSEA-ANM01.CT-01.CORROSION: 0.12 mpy [NOMINAL]`
        ],
        status: 'success'
      };

    case 'simulate':
      return {
        output: [
          '[SIMULATION] Running coupled reservoir-well-facility material balance...',
          `Reservoir: ${SYNTHETIC_RESERVOIR.name}`,
          `Current Pressure: ${SYNTHETIC_RESERVOIR.currentPressurePsi} psi | Depletion Delta: -12.5 psi/yr`,
          `Estimated Water Cut: ${SYNTHETIC_RESERVOIR.waterSaturationPercent}% | Recovery Factor: ${SYNTHETIC_RESERVOIR.recoveryFactorPercent}%`,
          '[MASS BALANCE] Hydrocarbon mass conservation verified (Error: 0.002%)',
          '[ENERGY BALANCE] Gas turbine efficiency verified (94.0%)',
          'Simulation completed successfully.'
        ],
        status: 'success'
      };

    case 'optimise': {
      const opt = runProductionOptimization(SYNTHETIC_WELLS, 10.0, 15.0);
      return {
        output: [
          '[OPTIMISER] Executing constrained multi-variable optimization...',
          `Current Oil Production: ${opt.currentProductionBpd.toLocaleString()} bpd`,
          `Optimised Oil Production: ${opt.optimisedProductionBpd.toLocaleString()} bpd (${opt.deltaProductionPercent > 0 ? '+' : ''}${opt.deltaProductionPercent}%)`,
          `Energy Reduction: ${opt.deltaEnergyPercent}% | Emissions Reduction: ${opt.deltaEmissionsPercent}%`,
          `Estimated Net Value Gain: +$${opt.economicGainUsdDay.toLocaleString()}/day`,
          'Recommendations:',
          ...opt.recommendationsPt.map(r => `  -> ${r}`)
        ],
        status: 'success'
      };
    }

    case 'scenario':
      if (arg === 'pre-salt-expansion' || !arg) {
        return {
          output: [
            '[SCENARIO RUNNER] Scenario: "pre-salt-expansion"',
            'Inputs: +4 new horizontal wells, FPSO topside expansion +20k bpd, gas reinjection +15%',
            'Simulating 5-year production profile...',
            'Year 1: +18,400 bpd | Year 2: +24,200 bpd | Year 3: +22,100 bpd',
            'Financial Metrics: CAPEX: $1.2B | NPV: +$840M | IRR: 24.2%',
            'Carbon Intensity Impact: 8.9 kgCO2e/boe (-0.5 kg vs base)',
            'Scenario run finished with seed 0x7E3F91A. Reproducibility verified.'
          ],
          status: 'success'
        };
      }
      return {
        output: [`Unknown scenario '${arg}'. Available: 'pre-salt-expansion', 'low-carbon-transition'`],
        status: 'error'
      };

    case 'report':
      return {
        output: [
          '[REPORT ENGINE] Generating Engineering Audit Report package...',
          'Format: PDF / CSV / JSON',
          'Timestamp: ' + new Date().toISOString(),
          'Model Version: PETROBRAS-OS-v3.6.0',
          'Checksum: sha256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
          'Disclaimer: SYNTHETIC DATASET FOR DEMONSTRATION & SIMULATION ONLY.'
        ],
        status: 'success'
      };

    case 'validate':
      return {
        output: [
          '[VALIDATOR] Running automated physical invariant checks...',
          '[PASS] Mass Conservation: Sum(Inputs) - Sum(Outputs) = Accumulation',
          '[PASS] Pressure Continuity: Reservoir -> Wellhead -> Separator -> Export',
          '[PASS] Thermodynamics: Phase envelope stability within 0.01% tolerance',
          '[PASS] Schema Invariants: All 20 assets pass pydantic/zod schema validation',
          'All 14 numerical invariants verified.'
        ],
        status: 'success'
      };

    default:
      return {
        output: [`Unknown sub-command '${subCommand}'. Type 'petrobras-os --help' for usage.`],
        status: 'error'
      };
  }
}
