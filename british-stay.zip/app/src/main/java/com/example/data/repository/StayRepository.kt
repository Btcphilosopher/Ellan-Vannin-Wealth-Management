package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.db.*
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.util.UUID

class StayRepository private constructor(context: Context) {

    private val db = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "british_stay_db"
    ).build()

    val propertyDao = db.propertyDao()
    val userDao = db.userDao()
    val bookingDao = db.bookingDao()
    val reviewDao = db.reviewDao()
    val messageDao = db.messageDao()
    val wishlistDao = db.wishlistDao()
    val journalDao = db.journalDao()
    val stationDao = db.stationDao()

    // Exposed Flows
    val allPropertiesFlow: Flow<List<PropertyEntity>> = propertyDao.getAllPropertiesFlow()
    val currentUserFlow: Flow<UserEntity?> = userDao.getCurrentUserFlow()
    val bookingsFlow: Flow<List<BookingEntity>> = bookingDao.getAllBookingsFlow()
    val wishlistsFlow: Flow<List<WishlistEntity>> = wishlistDao.getWishlistsFlow()
    val journalsFlow: Flow<List<JournalEntity>> = journalDao.getAllJournalsFlow()

    companion object {
        @Volatile
        private var INSTANCE: StayRepository? = null

        fun getInstance(context: Context): StayRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: StayRepository(context).also { INSTANCE = it }
            }
        }
    }

    suspend fun initializeDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        // Seeding user
        if (userDao.getCurrentUser() == null) {
            userDao.insertUser(
                UserEntity(
                    id = 1,
                    name = "Tom",
                    email = "tom@ahyx.org",
                    memberSince = "2026",
                    staysCount = 12,
                    rating = 4.9f,
                    isHost = false
                )
            )
        }

        // Seeding properties
        val existingProperties = propertyDao.getAllProperties()
        if (existingProperties.isEmpty()) {
            val propertiesList = getInitialProperties()
            propertyDao.insertProperties(propertiesList)

            // Seed Stations
            val stationsList = listOf(
                StationEntity("STP", "London St Pancras", "London", 0),
                StationEntity("KGX", "London King's Cross", "London", 0),
                StationEntity("YRK", "York Station", "York", 110),
                StationEntity("MAN", "Manchester Piccadilly", "Manchester", 125),
                StationEntity("EDB", "Edinburgh Waverley", "Edinburgh", 260),
                StationEntity("BTH", "Bath Spa Station", "Bath", 85),
                StationEntity("SVR", "Sheffield Station", "Sheffield", 120),
                StationEntity("PAD", "London Paddington", "London", 0),
                StationEntity("COV", "Coventry Station", "Coventry", 60)
            )
            stationDao.insertStations(stationsList)

            // Seed Journals
            val journalsList = getInitialJournals()
            journalDao.insertJournals(journalsList)

            // Seed some pre-existing reviews for premium items
            seedInitialReviews()
            
            // Seed a welcome host message session
            messageDao.insertMessage(
                MessageEntity(
                    propertyId = 1,
                    propertyName = "The Stone Barn",
                    hostName = "Sarah",
                    sender = "HOST",
                    text = "Welcome to British Stay, Tom! If you have any questions about booking The Stone Barn or travelling near Hope Valley by train, feel free to ask me here.",
                    status = "READ"
                )
            )
        }
    }

    private fun getInitialProperties(): List<PropertyEntity> {
        val list = mutableListOf<PropertyEntity>()

        // 1. Peak District Barn (FLAGSHIP 1)
        list.add(
            PropertyEntity(
                id = 1,
                name = "The Stone Barn",
                type = "Cottage",
                category = "COUNTRY_COTTAGES",
                region = "England",
                county = "Derbyshire",
                cityOrTown = "Hope Valley",
                latitude = 53.333f,
                longitude = -1.745f,
                pricePerNight = 182.0,
                cleaningFee = 65.0,
                serviceFee = 58.0,
                rating = 4.91f,
                reviewsCount = 187,
                guests = 4,
                bedrooms = 2,
                beds = 2,
                bathrooms = 1,
                description = "A stunningly restored historic limestone barn perched above the Hope Valley. Combining rough-hewn Georgian oak beams with sleek industrial steel work, the cottage features double-height spaces, underfloor heating, and sweeping panoramas across the High Peak dales. Accessible and beautifully secluded.",
                spaceDetails = "The Barn is situated on private hills, boasting a double-height open-plan kitchen and living space. A massive stone fireplace with a multi-fuel burner is the central hub. Two elegant double bedrooms features bespoke oak furniture. Double glazed steel doors open directly onto a stone terrace overlooking the Hope Valley dales.",
                gettingThere = "A short 12-minute walk from Hope Station, with hourly connections from Sheffield (26 mins) and Manchester Piccadilly (45 mins). An EV fast charger is available on the secure gravel driveway.",
                areaDetails = "Located in the heart of the Peak District, just a 15-minute drive from the historic market town of Bakewell. Countless legendary walking paths, including the Mam Tor ridge, start directly from the garden gate.",
                houseRules = "Quiet hours after 22:00. Up to two well-behaved dogs welcome. Boot room must be used for muddy shoes.",
                goodToKnow = "A local breakfast basket containing Derbyshire oatcakes, fresh butter, and locally sourced eggs is provided upon your arrival. Lockbox check-in with a security code.",
                imageAssetName = "peak_district_stone_barn",
                imageSeed = 101,
                stationName = "Hope Station",
                minutesToStationWalk = 12,
                trainMinutesToLondon = 160,
                hostName = "Sarah",
                isDogFriendly = true,
                hasWifi = true,
                hasFireplace = true,
                hasEvCharging = true,
                hasParking = true,
                hasBootRoom = true,
                hasGarden = true,
                hasHotTub = true
            )
        )

        // 2. Georgian Bath Townhouse (FLAGSHIP 2)
        list.add(
            PropertyEntity(
                id = 2,
                name = "The Georgian Penthouse",
                type = "Townhouse",
                category = "GEORGIAN_HOUSES",
                region = "England",
                county = "Somerset",
                cityOrTown = "Bath",
                latitude = 51.381f,
                longitude = -2.359f,
                pricePerNight = 245.0,
                cleaningFee = 75.0,
                serviceFee = 65.0,
                rating = 4.95f,
                reviewsCount = 142,
                guests = 2,
                bedrooms = 1,
                beds = 1,
                bathrooms = 1.5.toInt(),
                description = "An exquisite, light-filled attic penthouse within an authentic John Wood-designed Georgian terrace. Restored with flawless historical symmetry, featuring original plaster cornices, a copper roll-top bath, and custom English brass brassware. Gazes out onto the beautiful hills of Bath.",
                spaceDetails = "Every detail in this flat speaks of high Georgian proportions combined with ultra-modern comforts. The sitting room features high ceilings, a grand sash window with a window seat, and a selection of curated British literature. The bedroom features a super-king linen bed, while the bathroom is a masterclass in luxury with its copper bath and hand-cast tiles.",
                gettingThere = "A flat 8-minute walk from Bath Spa railway station. Fast trains run directly from London Paddington to Bath Spa in just 1 hour and 15 minutes.",
                areaDetails = "Positioned beautifully in Bath's upper town, seconds from the Assembly Rooms and the iconic Circus. Excellent cafes, independent bookshops, and artisan bakeries are situated right at your doorstep.",
                houseRules = "No high heels on the authentic Georgian floorboards. Strictly no parties.",
                goodToKnow = "Due to the historic nature of the building, there is no lift and access requires climbing four flights of stairs.",
                imageAssetName = "bath_georgian_penthouse",
                imageSeed = 102,
                stationName = "Bath Spa Station",
                minutesToStationWalk = 8,
                trainMinutesToLondon = 80,
                hostName = "Julian",
                isDogFriendly = false,
                hasWifi = true,
                hasFireplace = true,
                hasEvCharging = false,
                hasParking = false,
                hasBootRoom = false,
                hasGarden = false,
                hasHotTub = false
            )
        )

        // 3. London Canal Boat (FLAGSHIP 3 - UNIQUE)
        list.add(
            PropertyEntity(
                id = 3,
                name = "The Regent Narrowboat",
                type = "Canal Boat",
                category = "UNIQUE_BRITISH_PLACES",
                region = "England",
                county = "Greater London",
                cityOrTown = "Little Venice",
                latitude = 51.522f,
                longitude = -0.183f,
                pricePerNight = 165.0,
                cleaningFee = 40.0,
                serviceFee = 38.0,
                rating = 4.88f,
                reviewsCount = 94,
                guests = 2,
                bedrooms = 1,
                beds = 1,
                bathrooms = 1,
                description = "A bespoke 60ft traditional narrowboat, custom rebuilt into a contemporary waterside studio. Featuring British oak panelling, a custom multi-fuel hearth, and folding glazed side-hatches that put you in direct contact with the calming wildlife of London's historic canals.",
                spaceDetails = "An ingenious exercise in micro-living. Features a custom fitted compact kitchen with induction burners, a comfortable double cabin with porthole views, and a warm wood-burner. The roof is a fully-planted terrace where you can enjoy your morning tea right on the water.",
                gettingThere = "Moored securely in Little Venice, a 5-minute stroll from Paddington Station and Warwick Avenue tube station.",
                areaDetails = "A peaceful aquatic oasis in the heart of London. Walk along the canal towpath to Regent's Park, Primrose Hill, or Camden Market in under 30 minutes.",
                houseRules = "Lifejackets provided must be used if entering the deck. Respect canal quiet guidelines after 21:30.",
                goodToKnow = "The boat is securely moored and doesn't move during stays, ensuring a stable and safe experience. Heated via a cozy wood-burner.",
                imageAssetName = "london_canal_boat",
                imageSeed = 103,
                stationName = "Paddington Station",
                minutesToStationWalk = 5,
                trainMinutesToLondon = 5,
                hostName = "Alastair",
                isDogFriendly = true,
                hasWifi = true,
                hasFireplace = true,
                hasEvCharging = false,
                hasParking = false,
                hasBootRoom = false,
                hasGarden = false,
                hasHotTub = false
            )
        )

        // 4. Highlands Cabin (FLAGSHIP 4 - MODERN/CABIN)
        list.add(
            PropertyEntity(
                id = 4,
                name = "The Glencoe Cabin",
                type = "Cabin",
                category = "MODERNIST_HOMES",
                region = "Scotland",
                county = "Highlands",
                cityOrTown = "Glencoe",
                latitude = 56.682f,
                longitude = -5.102f,
                pricePerNight = 210.0,
                cleaningFee = 80.0,
                serviceFee = 72.0,
                rating = 4.97f,
                reviewsCount = 203,
                guests = 2,
                bedrooms = 1,
                beds = 1,
                bathrooms = 1,
                description = "An award-winning architect-designed modernist cabin framed by the dramatic volcanic peaks of Glencoe. Wrapped in charred Scottish larch, it features a glass wall with unobstructed views across Loch Leven, an outdoor hot tub, and a bespoke wood fireplace.",
                spaceDetails = "Minimalist and clean interior. Features custom-milled birch plywood panels, a sleek Italian kitchen, a hanging wood-burner, and high-end modern furniture. A luxury sauna and cedar wood hot tub sit on the private decking overlooking the dark waters of the loch.",
                gettingThere = "Located near Glencoe village. Best reached by car or the scenic West Highland railway line to Fort William, followed by a local taxi or bus ride.",
                areaDetails = "A mountaineer's dream. Surrounded by legendary peak climbs like Bidean nam Bian and the Pap of Glencoe. Cozy Highland pubs serving wild venison and local single malts are just minutes away.",
                houseRules = "Please clean muddy hiking boots in the designated drying cabinet. Keep external doors closed to prevent midges.",
                goodToKnow = "A bottle of local Oban single malt whisky and fresh shortbread await your arrival. Extremely insulated for freezing winter nights.",
                imageAssetName = "scotland_glencoe_cabin",
                imageSeed = 104,
                stationName = "Fort William Station",
                minutesToStationWalk = 45,
                trainMinutesToLondon = 480,
                hostName = "Fiona",
                isDogFriendly = false,
                hasWifi = true,
                hasFireplace = true,
                hasEvCharging = true,
                hasParking = true,
                hasBootRoom = true,
                hasGarden = true,
                hasHotTub = true
            )
        )

        // 5. Cornish Lighthouse Apartment (FLAGSHIP 5 - COASTAL)
        list.add(
            PropertyEntity(
                id = 5,
                name = "The Lighthouse Keepers",
                type = "Apartment",
                category = "COASTAL_HOMES",
                region = "England",
                county = "Cornwall",
                cityOrTown = "St Ives",
                latitude = 50.211f,
                longitude = -5.481f,
                pricePerNight = 195.0,
                cleaningFee = 55.0,
                serviceFee = 45.0,
                rating = 4.89f,
                reviewsCount = 112,
                guests = 4,
                bedrooms = 2,
                beds = 3,
                bathrooms = 1,
                description = "Experience a stay within an active historic lighthouse keeper's cottage high on the rugged granite cliffs of the Cornwall coast. Features breathtaking 180-degree Atlantic Ocean views, private cliffpath access, and original Victorian ironwork detailing.",
                spaceDetails = "Cozy maritime interiors. Rebuilt with insulated slate floors, brass accents, and custom circular windows. Two comfortable bedrooms overlook the sea. Sit by the sash window and watch the dramatic ocean swells crash against the rocks below.",
                gettingThere = "Located near St Ives. A stunning 15-minute coastal walk from the local branch line station. Secure private parking with EV charger.",
                areaDetails = "Directly connected to the South West Coast Path. Walk along the dramatic cliffs to sandy St Ives beaches, the Tate Gallery, and Michelin-starred seafood bistros.",
                houseRules = "Ensure windows are securely latched during ocean gales. Children must be supervised at all times near cliff fences.",
                goodToKnow = "Due to being on an active light station, the low, periodic hum of the lighthouse foghorn can be heard during heavy sea fog - an authentic coastal charm!",
                imageAssetName = "cornwall_lighthouse",
                imageSeed = 105,
                stationName = "St Ives Station",
                minutesToStationWalk = 15,
                trainMinutesToLondon = 310,
                hostName = "Cap'n Thomas",
                isDogFriendly = true,
                hasWifi = true,
                hasFireplace = false,
                hasEvCharging = true,
                hasParking = true,
                hasBootRoom = true,
                hasGarden = true,
                hasHotTub = false
            )
        )

        // 6. Cotswolds Honey Stone Cottage (FLAGSHIP 6)
        list.add(
            PropertyEntity(
                id = 6,
                name = "Honeywood Cottage",
                type = "Cottage",
                category = "COUNTRY_COTTAGES",
                region = "England",
                county = "Gloucestershire",
                cityOrTown = "Chipping Campden",
                latitude = 52.051f,
                longitude = -1.782f,
                pricePerNight = 175.0,
                cleaningFee = 50.0,
                serviceFee = 42.0,
                rating = 4.93f,
                reviewsCount = 155,
                guests = 4,
                bedrooms = 2,
                beds = 3,
                bathrooms = 2,
                description = "An quintessential honey-colored limestone Cotswold cottage dating back to the late 17th century. Beautifully styled with a mix of vintage English antiques and premium modern bathrooms, featuring a flagstone inglenook fireplace and a lush cottage garden.",
                spaceDetails = "A warm, character-rich home. Low oak beams, exposed stone walls, and deep mullioned windows. The hand-crafted wood kitchen features a range cooker and farmhouse sink, opening out onto a flagstone path lined with lavender and heritage roses.",
                gettingThere = "A 10-minute drive from Moreton-in-Marsh station, which offers direct hourly trains from London Paddington (1h 35m).",
                areaDetails = "Perfectly positioned in a quiet lane just off Chipping Campden's historic high street. Surrounded by award-winning traditional country pubs and scenic walking trails.",
                houseRules = "Please use coasters on the antique wood tables. No outdoor shoes upstairs.",
                goodToKnow = "The cottage has low doorways and steep staircases typical of the 1600s. Perfect for romantic and historical escapes.",
                imageAssetName = "cotswolds_cottage",
                imageSeed = 106,
                stationName = "Moreton-in-Marsh Station",
                minutesToStationWalk = 45,
                trainMinutesToLondon = 95,
                hostName = "Emma",
                isDogFriendly = true,
                hasWifi = true,
                hasFireplace = true,
                hasEvCharging = false,
                hasParking = true,
                hasBootRoom = true,
                hasGarden = true,
                hasHotTub = false
            )
        )

        // Let's procedurally seed around 150 properties to fulfill requirements
        val ukRegions = listOf(
            Triple("England", "Derbyshire", "Peak District"),
            Triple("England", "Somerset", "Bath"),
            Triple("England", "Cornwall", "St Ives"),
            Triple("England", "Gloucestershire", "Cotswolds"),
            Triple("England", "Greater London", "London"),
            Triple("England", "North Yorkshire", "Yorkshire Dales"),
            Triple("England", "Cumbria", "Lake District"),
            Triple("Scotland", "Highlands", "Fort William"),
            Triple("Scotland", "Midlothian", "Edinburgh"),
            Triple("Wales", "Gwynedd", "Snowdonia"),
            Triple("Wales", "Glamorgan", "Cardiff"),
            Triple("Northern Ireland", "Antrim", "Belfast")
        )

        val propertyNames = listOf(
            "Wayside Cottage", "The Old Rectory", "Bridge House", "Slate Loft", 
            "The Coach House", "Marina Flat", "Sovereign Apartment", "Railway Carriage", 
            "Clifftop Cabin", "The Old Chapel", "Keepers Lodge", "Mews Studio", 
            "Mill House", "Dolphin Cottage", "The Observatory", "Gable End Townhouse",
            "Heather Cottage", "Highland Bothy", "The Maltings", "Porthole Apartment"
        )

        val propertyTypes = listOf("Cottage", "Apartment", "Townhouse", "Cabin", "Barn", "House")
        val categories = listOf("COUNTRY_COTTAGES", "CITY_FLATS", "COASTAL_HOMES", "GEORGIAN_HOUSES", "MODERNIST_HOMES", "UNIQUE_BRITISH_PLACES")
        val hosts = listOf("Sarah", "Julian", "Alastair", "Fiona", "Emma", "Charles", "Victoria", "Oliver", "Charlotte", "Arthur")

        var idCounter = 7
        for (i in 1..150) {
            val regTriple = ukRegions[i % ukRegions.size]
            val pName = propertyNames[i % propertyNames.size] + " " + (100 + i)
            val pType = propertyTypes[i % propertyTypes.size]
            val cat = categories[i % categories.size]
            val host = hosts[i % hosts.size]

            // Coordinate variations around central locations
            val latBase = when (regTriple.third) {
                "London" -> 51.507f
                "Edinburgh" -> 55.953f
                "Bath" -> 51.381f
                "Peak District" -> 53.333f
                "Lake District" -> 54.460f
                "Cornwall" -> 50.211f
                "Belfast" -> 54.597f
                else -> 52.0f
            }
            val lngBase = when (regTriple.third) {
                "London" -> -0.127f
                "Edinburgh" -> -3.188f
                "Bath" -> -2.359f
                "Peak District" -> -1.745f
                "Lake District" -> -3.084f
                "Cornwall" -> -5.481f
                "Belfast" -> -5.930f
                else -> -1.5f
            }

            val price = 95.0 + (i * 3 % 180)
            val rating = 4.5f + (i % 5) * 0.11f
            val reviews = 5 + (i * 7 % 140)
            val guests = 2 + (i % 5)
            val bedrooms = 1 + (i % 3)
            val beds = bedrooms + (i % 2)
            val stationIdx = i % 5
            val stations = listOf(
                Pair("Hope Station", "YRK"),
                Pair("York Station", "YRK"),
                Pair("Manchester Piccadilly", "MAN"),
                Pair("Edinburgh Waverley", "EDB"),
                Pair("Bath Spa Station", "BTH")
            )
            val station = stations[stationIdx]

            list.add(
                PropertyEntity(
                    id = idCounter++,
                    name = "${regTriple.third} $pName",
                    type = pType,
                    category = cat,
                    region = regTriple.first,
                    county = regTriple.second,
                    cityOrTown = regTriple.third,
                    latitude = latBase + (i * 0.003f - 0.2f),
                    longitude = lngBase + (i * 0.003f - 0.2f),
                    pricePerNight = price,
                    cleaningFee = 35.0 + (i % 40),
                    serviceFee = 25.0 + (i % 30),
                    rating = if (rating > 5.0f) 5.0f else rating,
                    reviewsCount = reviews,
                    guests = guests,
                    bedrooms = bedrooms,
                    beds = beds,
                    bathrooms = 1 + (i % 2),
                    description = "A beautiful $pType in ${regTriple.third}, ${regTriple.second}. Perfect for exploring local landmarks, walking trails, and railway access. Equipped with all premium amenities for modern travel.",
                    imageAssetName = "procedural_stay_${i}",
                    imageSeed = 100 + i,
                    stationName = station.first,
                    minutesToStationWalk = 5 + (i % 15),
                    trainMinutesToLondon = 45 + (i % 240),
                    hostName = host,
                    isDogFriendly = (i % 2 == 0),
                    hasWifi = true,
                    hasFireplace = (i % 3 == 0),
                    hasEvCharging = (i % 4 == 0),
                    hasParking = true,
                    hasBootRoom = (i % 5 == 0),
                    hasGarden = (i % 3 != 0),
                    hasHotTub = (i % 7 == 0)
                )
            )
        }

        return list
    }

    private fun getInitialJournals(): List<JournalEntity> {
        return listOf(
            JournalEntity(
                id = "weekend_bath",
                title = "A Perfect Weekend in Bath",
                subtitle = "Discovering the Roman heritage, golden stone alleys, and warm mineral waters of Somerset's architectural masterpiece.",
                category = "ESCAPES",
                imageSeed = 201,
                readTime = "5 min read",
                author = "Julian Wood",
                content = "Bath is a city shaped by its stone. The warm, honey-colored limestone of the Cotswolds defines every arch, column, and crescent. To properly stay in Bath is to match your rhythm to the slow shadows moving across Royal Crescent.\n\nStart your morning on Queen Square before heading to the Roman Baths where steam still rises from the ancient hot waters. Spend your afternoon exploring independent shops along Walcot Street and finish with traditional afternoon tea."
            ),
            JournalEntity(
                id = "railway_escapes_london",
                title = "The Best Railway-Accessible Escapes",
                subtitle = "Leave the city behind using only Britain's legendary rail tracks. No cars, no traffic, just scenery.",
                category = "JOURNEY",
                imageSeed = 202,
                readTime = "6 min read",
                author = "Clara Stevenson",
                content = "There is a unique romanticism in looking out of a train window as brick terraces slowly yield to green meadows. Britain's rail network is a masterpiece of connectivity, allowing you to reach breathtaking historic places in under two hours from London.\n\nFrom Paddington, Bath Spa is just 75 minutes of smooth gliding. From St Pancras, Sheffield and the gates of the Peak District open in under two hours. Traveling by train is sustainable, relaxing, and puts you directly in touch with local station villages."
            ),
            JournalEntity(
                id = "peak_district_living",
                title = "Winters in the Yorkshire & Peak Dales",
                subtitle = "Warm multi-fuel hearths, misty mornings, and local pub snug rooms after long ridge walks.",
                category = "ARCHITECTURE",
                imageSeed = 203,
                readTime = "4 min read",
                author = "Sarah Hope",
                content = "The Peak District dales undergo a magical transformation in late autumn. The summer crowds dissipate, leaving the gritstone edges and limestone valleys quiet, atmospheric, and incredibly crisp.\n\nAfter climbing the frosty limestone paths of Lathkill Dale or battling the wind on Mam Tor, there is nothing more British than slipping into a cozy local pub snug room. Warm your hands by the roaring fire, enjoy a pint of local pale ale, and head back to your stone cottage."
            )
        )
    }

    private suspend fun seedInitialReviews() {
        val reviews = listOf(
            ReviewEntity(
                propertyId = 1,
                authorName = "Edward",
                rating = 5,
                content = "An incredible barn transformation! Every architectural detail has been thought through. The underfloor heating was cozy, and Sarah left us fresh Derbyshire oatcakes. Hope station is so close we didn't even need a car.",
                date = "August 2026",
                cleanliness = 5,
                accuracy = 5,
                communication = 5,
                location = 5,
                value = 5,
                hostResponse = "Thank you Edward! We love hosting train travelers."
            ),
            ReviewEntity(
                propertyId = 1,
                authorName = "Eleanor",
                rating = 5,
                content = "Spectacular views across the Hope Valley valley! The boot room was highly useful for our muddy hiking gear after climbing Mam Tor. Highly recommended.",
                date = "July 2026",
                cleanliness = 5,
                accuracy = 5,
                communication = 5,
                location = 5,
                value = 5
            ),
            ReviewEntity(
                propertyId = 2,
                authorName = "Arthur",
                rating = 5,
                content = "Flawless Georgian proportions right in Bath's center. Julian has restored this flat with immense taste and restraint. Climbing the stairs was well worth it for the view and the copper roll-top bath!",
                date = "September 2026",
                cleanliness = 5,
                accuracy = 5,
                communication = 5,
                location = 5,
                value = 5
            )
        )
        for (rev in reviews) {
            reviewDao.insertReview(rev)
        }
    }
}
