package com.example.data.db

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PropertyDao {
    @Query("SELECT * FROM properties")
    fun getAllPropertiesFlow(): Flow<List<PropertyEntity>>

    @Query("SELECT * FROM properties")
    suspend fun getAllProperties(): List<PropertyEntity>

    @Query("SELECT * FROM properties WHERE id = :id")
    suspend fun getPropertyById(id: Int): PropertyEntity?

    @Query("SELECT * FROM properties WHERE id = :id")
    fun getPropertyByIdFlow(id: Int): Flow<PropertyEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProperties(properties: List<PropertyEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProperty(property: PropertyEntity): Long

    @Update
    suspend fun updateProperty(property: PropertyEntity)

    @Query("DELETE FROM properties WHERE id = :id")
    suspend fun deletePropertyById(id: Int)
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users LIMIT 1")
    suspend fun getCurrentUser(): UserEntity?

    @Query("SELECT * FROM users LIMIT 1")
    fun getCurrentUserFlow(): Flow<UserEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY startDate DESC")
    fun getAllBookingsFlow(): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE propertyId = :propertyId")
    suspend fun getBookingsForProperty(propertyId: Int): List<BookingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: BookingEntity): Long

    @Update
    suspend fun updateBooking(booking: BookingEntity)

    @Query("DELETE FROM bookings WHERE id = :id")
    suspend fun deleteBookingById(id: Int)
}

@Dao
interface ReviewDao {
    @Query("SELECT * FROM reviews WHERE propertyId = :propertyId ORDER BY id DESC")
    fun getReviewsForPropertyFlow(propertyId: Int): Flow<List<ReviewEntity>>

    @Query("SELECT * FROM reviews WHERE propertyId = :propertyId ORDER BY id DESC")
    suspend fun getReviewsForProperty(propertyId: Int): List<ReviewEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: ReviewEntity): Long
}

@Dao
interface MessageDao {
    @Query("SELECT DISTINCT propertyId, propertyName, hostName FROM messages ORDER BY timestamp DESC")
    fun getChatSessionsFlow(): Flow<List<ChatSession>>

    @Query("SELECT * FROM messages WHERE propertyId = :propertyId ORDER BY timestamp ASC")
    fun getMessagesForPropertyFlow(propertyId: Int): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long
}

// Helper tuple for chat sessions list
data class ChatSession(
    val propertyId: Int,
    val propertyName: String,
    val hostName: String
)

@Dao
interface WishlistDao {
    @Query("SELECT * FROM wishlists ORDER BY id DESC")
    fun getWishlistsFlow(): Flow<List<WishlistEntity>>

    @Query("SELECT * FROM wishlists WHERE id = :wishlistId")
    suspend fun getWishlistById(wishlistId: Int): WishlistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWishlist(wishlist: WishlistEntity): Long

    @Query("DELETE FROM wishlists WHERE id = :id")
    suspend fun deleteWishlist(id: Int)

    // Wishlist items mapping
    @Query("SELECT p.* FROM properties p INNER JOIN wishlist_items wi ON p.id = wi.propertyId WHERE wi.wishlistId = :wishlistId")
    fun getPropertiesInWishlistFlow(wishlistId: Int): Flow<List<PropertyEntity>>

    @Query("SELECT p.* FROM properties p INNER JOIN wishlist_items wi ON p.id = wi.propertyId WHERE wi.wishlistId = :wishlistId")
    suspend fun getPropertiesInWishlist(wishlistId: Int): List<PropertyEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWishlistItem(item: WishlistItemEntity): Long

    @Query("DELETE FROM wishlist_items WHERE wishlistId = :wishlistId AND propertyId = :propertyId")
    suspend fun removeWishlistItem(wishlistId: Int, propertyId: Int)

    @Query("SELECT EXISTS(SELECT 1 FROM wishlist_items WHERE wishlistId = :wishlistId AND propertyId = :propertyId)")
    suspend fun isPropertyInWishlist(wishlistId: Int, propertyId: Int): Boolean
}

@Dao
interface JournalDao {
    @Query("SELECT * FROM journals")
    fun getAllJournalsFlow(): Flow<List<JournalEntity>>

    @Query("SELECT * FROM journals WHERE id = :id")
    suspend fun getJournalById(id: String): JournalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournals(journals: List<JournalEntity>)
}

@Dao
interface StationDao {
    @Query("SELECT * FROM stations")
    suspend fun getAllStations(): List<StationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<StationEntity>)
}

@Database(
    entities = [
        PropertyEntity::class,
        UserEntity::class,
        BookingEntity::class,
        ReviewEntity::class,
        MessageEntity::class,
        WishlistEntity::class,
        WishlistItemEntity::class,
        JournalEntity::class,
        StationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun propertyDao(): PropertyDao
    abstract fun userDao(): UserDao
    abstract fun bookingDao(): BookingDao
    abstract fun reviewDao(): ReviewDao
    abstract fun messageDao(): MessageDao
    abstract fun wishlistDao(): WishlistDao
    abstract fun journalDao(): JournalDao
    abstract fun stationDao(): StationDao
}
