package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    suspend fun getStayFinderResponse(prompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY" || apiKey.contains("placeholder", ignoreCase = true)) {
            Log.d(TAG, "Gemini API Key missing/placeholder. Using local heuristic engine.")
            return@withContext getLocalHeuristicResponse(prompt)
        }

        val systemInstruction = """
            You are the British Stay Assistant. Help tourists find places to stay in the United Kingdom.
            Guide them on UK geography, travel times, stations, and property taxonomy (cottages, flats, barns, townhouses).
            Be understated, intelligent, elegant, and distinctly British.
            Reply concisely in 2-3 short, beautiful paragraphs.
        """.trimIndent()

        val jsonRequest = """
            {
              "contents": [
                {
                  "parts": [
                    {
                      "text": ${escapeJsonString(prompt)}
                    }
                  ]
                }
              ],
              "systemInstruction": {
                "parts": [
                  {
                    "text": ${escapeJsonString(systemInstruction)}
                  }
                ]
              },
              "generationConfig": {
                "temperature": 0.7,
                "maxOutputTokens": 400
              }
            }
        """.trimIndent()

        try {
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = jsonRequest.toRequestBody(mediaType)
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Gemini API failed with response code ${response.code}. Falling back.")
                    return@withContext getLocalHeuristicResponse(prompt)
                }
                val bodyString = response.body?.string() ?: ""
                val textResponse = parseTextFromResponse(bodyString)
                if (textResponse != null) {
                    return@withContext textResponse
                } else {
                    return@withContext getLocalHeuristicResponse(prompt)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in Gemini API call: ${e.message}. Falling back.")
            return@withContext getLocalHeuristicResponse(prompt)
        }
    }

    suspend fun getHostAssistantResponse(propertyDetails: String, query: String): String = withContext(Dispatchers.IO) {
        val prompt = "Property Details:\n$propertyDetails\n\nGuest Query: $query"
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getLocalHostHeuristicResponse(propertyDetails, query)
        }

        val systemInstruction = """
            You are British Stay AI, an assistant for UK holiday hosts.
            Help them write descriptions, summarize reviews, draft messages, or optimize rates.
            Ground all facts strictly in the supplied Property Details. Do not invent details.
            Keep your advice professional, structured, and elegant.
        """.trimIndent()

        val jsonRequest = """
            {
              "contents": [
                {
                  "parts": [
                    {
                      "text": ${escapeJsonString(prompt)}
                    }
                  ]
                }
              ],
              "systemInstruction": {
                "parts": [
                  {
                    "text": ${escapeJsonString(systemInstruction)}
                  }
                ]
              },
              "generationConfig": {
                "temperature": 0.5,
                "maxOutputTokens": 500
              }
            }
        """.trimIndent()

        try {
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = jsonRequest.toRequestBody(mediaType)
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext getLocalHostHeuristicResponse(propertyDetails, query)
                val bodyString = response.body?.string() ?: ""
                parseTextFromResponse(bodyString) ?: getLocalHostHeuristicResponse(propertyDetails, query)
            }
        } catch (e: Exception) {
            return@withContext getLocalHostHeuristicResponse(propertyDetails, query)
        }
    }

    private fun escapeJsonString(s: String): String {
        val sb = StringBuilder()
        sb.append("\"")
        for (i in s.indices) {
            val c = s[i]
            when (c) {
                '\"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> {
                    if (c.code < 32) {
                        sb.append(String.format("\\u%04x", c.code))
                    } else {
                        sb.append(c)
                    }
                }
            }
        }
        sb.append("\"")
        return sb.toString()
    }

    private fun parseTextFromResponse(responseJson: String): String? {
        try {
            // Quick and lightweight manual search to avoid complicated deserialization crashes.
            // Search for "text": "..." values
            val partsToken = "\"text\":"
            var index = responseJson.indexOf(partsToken)
            if (index != -1) {
                index += partsToken.length
                // skip whitespace
                while (index < responseJson.length && (responseJson[index] == ' ' || responseJson[index] == '\n' || responseJson[index] == '\r')) {
                    index++
                }
                if (responseJson[index] == '\"') {
                    index++
                    val start = index
                    val textBuilder = java.lang.StringBuilder()
                    var escaped = false
                    while (index < responseJson.length) {
                        val c = responseJson[index]
                        if (escaped) {
                            when (c) {
                                'n' -> textBuilder.append('\n')
                                't' -> textBuilder.append('\t')
                                'r' -> textBuilder.append('\r')
                                '\"' -> textBuilder.append('\"')
                                '\\' -> textBuilder.append('\\')
                                else -> textBuilder.append(c)
                            }
                            escaped = false
                        } else if (c == '\\') {
                            escaped = true
                        } else if (c == '\"') {
                            break
                        } else {
                            textBuilder.append(c)
                        }
                        index++
                    }
                    val result = textBuilder.toString().trim()
                    if (result.isNotEmpty()) {
                        return result
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extraction text manual parsing: ${e.message}")
        }
        return null
    }

    private fun getLocalHeuristicResponse(prompt: String): String {
        val q = prompt.lowercase()
        return when {
            q.contains("cottage") || q.contains("peak district") || q.contains("lakes") || q.contains("lake district") -> {
                """
                    I have scanned our verified database for country cottages. In the Peak District, **The Stone Barn** is a fantastic match. It's a restored 18th-century limestone structure in Hope Valley with dual-height spaces, a stone fireplace, and a muddy-dog friendly boot room. 
                    
                    Crucially, it is highly accessible by rail: a short 12-minute walk from Hope Station, which connects directly to Manchester Piccadilly in 45 minutes or Sheffield in 26 minutes, making it a perfect car-free escape.
                    
                    For the Lake District, our collection includes cottages near Windermere and Keswick, offering cozy fireplaces, expansive gardens, and direct fell walk access.
                """.trimIndent()
            }
            q.contains("bath") || q.contains("georgian") || q.contains("townhouse") -> {
                """
                    To experience Britain’s Georgian elegance, Bath is peerless. **The Georgian Penthouse** is a restored light-filled attic penthouse within an authentic John Wood-designed terrace in Bath Spa.
                    
                    It features original cornices, classical proportions, and a luxurious copper roll-top bath overlooking the Bath hills. Positioned seconds from the Circus and the Assembly Rooms, it is just an 8-minute flat walk to Bath Spa Station, allowing you to travel from London Paddington in under 80 minutes.
                """.trimIndent()
            }
            q.contains("london") || q.contains("canal") || q.contains("boat") || q.contains("paddington") -> {
                """
                    For a truly unique London stay, **The Regent Narrowboat** is a magnificent choice. Moored securely in the tranquil waters of Little Venice (5 mins from Paddington Station), this bespoke 60ft traditional canal boat has been custom rebuilt into a contemporary studio with warm oak panelling, a custom hearth, and folding glazed hatches.
                    
                    Alternatively, we have gorgeous loft apartments near King's Cross and classic Victorian terraced homes in Kensington.
                """.trimIndent()
            }
            q.contains("train") || q.contains("railway") || q.contains("station") || q.contains("reachable") -> {
                """
                    Britain is best explored by rail! Our signature **Railway Escapes** category helps you discover gorgeous properties within walking distance of local stations.
                    
                    - **The Regent Narrowboat** (5 mins walk to Paddington Station, London)
                    - **The Georgian Penthouse** (8 mins walk to Bath Spa Station)
                    - **The Stone Barn** (12 mins walk to Hope Station in Peak District)
                    - **The Lighthouse Keepers** (15 mins walk to St Ives Station, Cornwall)
                    
                    We show walking times and travel hours to major hubs, helping you plan a car-free holiday.
                """.trimIndent()
            }
            q.contains("cornwall") || q.contains("coastal") || q.contains("sea") || q.contains("lighthouse") -> {
                """
                    For a spectacular sea view, **The Lighthouse Keepers** in St Ives, Cornwall is unparalleled. It is located inside an active historic light station on the granite cliffs, offering direct South West Coast Path access.
                    
                    It features circular maritime windows and is just 15 minutes on foot from St Ives Station. Enjoy coastal walks, art galleries, and the fresh Cornish salt air.
                """.trimIndent()
            }
            else -> {
                """
                    Stay somewhere distinctly British. Whether you are looking for a stone cottage in the Peak District, a Georgian attic penthouse in Bath, a bespoke canal boat in London, or a larch-wrapped modern cabin in the Scottish Highlands, British Stay provides transport-aware recommendations.
                    
                    Tell me: do you prefer a peaceful countryside escape, a historic city break, or a coastal retreat reachable easily by rail? I will help you find the perfect stay.
                """.trimIndent()
            }
        }
    }

    private fun getLocalHostHeuristicResponse(propertyDetails: String, query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("description") || q.contains("write") -> {
                """
                    ### Suggested Editorial Description Upgrade:
                    
                    **"A Masterpiece of British Character"**
                    *Nestled in the historical setting of this beautiful property, this residence is a perfect dialogue between heritage and late-2020s modern luxury.*
                    
                    **The Space:**
                    Warm and understated interiors featuring original textures, high-quality timber detailing, and curated British decor. Features a beautifully fitted kitchen, a luxury double suite, and a peaceful garden view.
                    
                    **Transport & Arrival:**
                    Perfectly suited for train travelers, with rapid walking access to the local railway station. Includes self check-in via secure lockbox, private parking, and a premium drying room for outdoor apparel.
                """.trimIndent()
            }
            q.contains("price") || q.contains("rate") || q.contains("suggest") -> {
                """
                    ### Dynamic Pricing Suggestion:
                    
                    Based on local demand patterns, seasonality, and your property's 4.9+ rating:
                    - **Base Rate:** £175/night (Standard midweek)
                    - **Weekend Peak (Fri-Sun):** £210/night (+20% demand)
                    - **Autumn/Winter Modifier:** £155/night (-11% low season)
                    - **Bank Holidays / Peak Summer:** £245/night (+40% demand)
                    
                    *Tip: Setting a 2-night minimum stay for weekends will optimize your cleaning schedule and boost gross profits by an estimated 14%.*
                """.trimIndent()
            }
            else -> {
                """
                    ### British Stay Host Intelligence:
                    
                    I have reviewed your query regarding your property. 
                    - **Review Summary:** Guests consistently praise your prompt communication, clean interiors, and close proximity to the railway station.
                    - **Actionable Insight:** Adding a small "muddy boots" welcome mat or a dry rack in the boot room would address the feedback regarding walks during damp autumn days.
                    
                    *Draft Guest Reply:*
                    "Dear guest, thank you for booking. The keys are in the lockbox beside the blue door. The entry code will become active at 15:00 on Friday. We hope you enjoy a wonderful stay!"
                """.trimIndent()
            }
        }
    }
}
