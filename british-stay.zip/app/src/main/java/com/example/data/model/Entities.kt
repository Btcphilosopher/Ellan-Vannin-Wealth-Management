package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "properties")
data class PropertyEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val type: String, // e.g. "Cottage", "Flat", "Apartment", "Townhouse", "Cabin"
    val category: String, // e.g. "COUNTRY_COTTAGES", "CITY_FLATS", "COASTAL_HOMES", "GEORGIAN_HOUSES", "RAILWAY_STAYS", "UNIQUE_BRITISH_PLACES"
    val region: String, // "England", "Scotland", "Wales", "Northern Ireland"
    val county: String, // "Derbyshire", "Cornwall", "Highlands", "Somerset", "Greater London"
    val cityOrTown: String, // "Hope Valley", "Bath", "London", "Edinburgh"
    val latitude: Float,
    val longitude: Float,
    val pricePerNight: Double,
    val cleaningFee: Double = 45.0,
    val serviceFee: Double = 35.0,
    val rating: Float,
    val reviewsCount: Int,
    val guests: Int,
    val bedrooms: Int,
    val beds: Int,
    val bathrooms: Int,
    val description: String,
    val spaceDetails: String = "",
    val gettingThere: String = "",
    val areaDetails: String = "",
    val houseRules: String = "No smoking inside. Respect neighbors.",
    val goodToKnow: String = "Traditional keys, self check-in via lockbox.",
    val imageAssetName: String, // placeholder or loaded dynamically
    val imageSeed: Int = 1,
    val stationName: String = "",
    val minutesToStationWalk: Int = 10,
    val trainMinutesToLondon: Int = 0, // 0 means not directly linked or too far
    val hostName: String,
    val hostRating: Float = 4.9f,
    val hostExperienceYears: Int = 3,
    val isVerified: Boolean = true,
    val isDogFriendly: Boolean = false,
    val hasWifi: Boolean = true,
    val hasFireplace: Boolean = false,
    val hasEvCharging: Boolean = false,
    val hasParking: Boolean = true,
    val hasBootRoom: Boolean = false,
    val hasGarden: Boolean = false,
    val hasHotTub: Boolean = false,
    // Host calendar status (e.g. customized base rate override, block checkouts)
    val customizedBasePrice: Double? = null,
    val isBlocked: Boolean = false
)

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val email: String,
    val memberSince: String,
    val staysCount: Int = 0,
    val rating: Float = 5.0f,
    val isHost: Boolean = false
)

@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val propertyId: Int,
    val propertyName: String,
    val propertyType: String,
    val propertyRegion: String,
    val propertyCounty: String,
    val imageSeed: Int,
    val startDate: String, // "YYYY-MM-DD"
    val endDate: String,   // "YYYY-MM-DD"
    val guests: Int,
    val status: String, // "PENDING", "CONFIRMED", "COMPLETED", "CANCELLED"
    val nightlyRate: Double,
    val cleaningFee: Double,
    val serviceFee: Double,
    val totalPaid: Double,
    val checkInCode: String = "1066", // lockbox code
    val checkInTime: String = "15:00",
    val checkOutTime: String = "10:00",
    val checkInInstructions: String = "The keys are in the secure lockbox on the right side of the main door."
)

@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val propertyId: Int,
    val authorName: String,
    val rating: Int,
    val content: String,
    val date: String, // e.g. "September 2026"
    val cleanliness: Int = 5,
    val accuracy: Int = 5,
    val communication: Int = 5,
    val location: Int = 5,
    val value: Int = 5,
    val hostResponse: String = ""
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val propertyId: Int,
    val propertyName: String,
    val hostName: String,
    val sender: String, // "GUEST", "HOST"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "READ" // "SENT", "DELIVERED", "READ"
)

@Entity(tableName = "wishlists")
data class WishlistEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val notes: String = "",
    val voteCount: Int = 0
)

@Entity(tableName = "wishlist_items")
data class WishlistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val wishlistId: Int,
    val propertyId: Int
)

@Entity(tableName = "journals")
data class JournalEntity(
    @PrimaryKey val id: String, // e.g. "weekend_bath"
    val title: String,
    val subtitle: String,
    val category: String, // e.g. "ESCAPES", "ARCHITECTURE", "JOURNEY"
    val imageSeed: Int,
    val readTime: String,
    val author: String,
    val content: String // Markdown or formatted text block
)

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val code: String, // e.g. "YRK"
    val name: String,
    val city: String,
    val trainMinutesToLondon: Int
)
