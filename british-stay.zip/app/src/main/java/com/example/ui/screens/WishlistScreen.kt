package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CompareArrows
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PropertyEntity
import com.example.data.model.WishlistEntity
import com.example.ui.components.PropertyIllustration
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel

@Composable
fun WishlistScreen(
    viewModel: StayViewModel,
    wishlists: List<WishlistEntity>,
    modifier: Modifier = Modifier
) {
    // Back handling
    BackHandler {
        viewModel.navigateTo(AppScreen.EXPLORE)
        true
    }

    var showCreateDialog by remember { mutableStateOf(false) }
    var newWishName by remember { mutableStateOf("") }
    var newWishNotes by remember { mutableStateOf("") }

    val activeWishlist by viewModel.selectedWishlist.collectAsState()
    val wishlistProps by viewModel.wishlistProperties.collectAsState()

    var showComparisonMode by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A3C25))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (activeWishlist != null) {
                    IconButton(onClick = { viewModel.selectedWishlist.value = null }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFFF5F2EA))
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }
                Text(
                    text = activeWishlist?.name?.uppercase() ?: "WISHLISTS",
                    color = Color(0xFFF5F2EA),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.Serif
                )
            }

            if (activeWishlist == null) {
                IconButton(
                    onClick = { showCreateDialog = true },
                    modifier = Modifier.testTag("create_wishlist_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Create", tint = Color(0xFFF5F2EA))
                }
            } else if (wishlistProps.size >= 2) {
                IconButton(
                    onClick = { showComparisonMode = !showComparisonMode },
                    modifier = Modifier.testTag("compare_wishlist_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.CompareArrows,
                        contentDescription = "Compare",
                        tint = if (showComparisonMode) Color(0xFFB5945B) else Color(0xFFF5F2EA)
                    )
                }
            }
        }

        if (activeWishlist == null) {
            // --- WISHLIST DIRECTORY VIEW ---
            if (wishlists.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FavoriteBorder, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color(0xFFB5945B))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No wishlists yet", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                        Text("Tap + above to start a collaborative collection.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(wishlists) { wish ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.loadWishlistProperties(wish.id) }
                                .testTag("wishlist_directory_item_${wish.id}"),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Folder, contentDescription = null, tint = Color(0xFF0A3C25), modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(wish.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, fontFamily = FontFamily.Serif)
                                    if (wish.notes.isNotEmpty()) {
                                        Text(wish.notes, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    }
                                }
                                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            }
                        }
                    }
                }
            }
        } else if (showComparisonMode) {
            // --- COMPARISON MODE TAB (UP TO 4 PROPERTIES SIDE-BY-SIDE) ---
            val comparisonProps = wishlistProps.take(4)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .background(MaterialTheme.colorScheme.background)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SIDE-BY-SIDE STAYS COMPARISON",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = Color(0xFF0A3C25)
                    )
                    Text(
                        text = "Exit Compare",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        modifier = Modifier.clickable { showComparisonMode = false }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Scrollable Table Row structure
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    comparisonProps.forEach { p ->
                        Card(
                            modifier = Modifier.width(180.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                PropertyIllustration(
                                    type = p.type,
                                    seed = p.imageSeed,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    p.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Serif,
                                    maxLines = 1
                                )
                                Text(
                                    "${p.cityOrTown}, ${p.county}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Divider()
                                Spacer(modifier = Modifier.height(8.dp))

                                // Attributes
                                CompareItem("PRICE", "£${p.pricePerNight.toInt()}/night")
                                CompareItem("RATING", "★ ${String.format("%.2f", p.rating)}")
                                CompareItem("GUESTS", "${p.guests} Guests")
                                CompareItem("BEDROOMS", "${p.bedrooms} Beds")
                                CompareItem("STATION WALK", "${p.minutesToStationWalk} mins")
                                CompareItem("DOGS OK?", if (p.isDogFriendly) "Yes" else "No")
                                CompareItem("FIREPLACE?", if (p.hasFireplace) "Yes" else "No")

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = { viewModel.selectPropertyForBooking(p) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A3C25)),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(2.dp)
                                ) {
                                    Text("Select Stay", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // --- WISHLIST DETAILED PROPERTIES VIEW ---
            if (wishlistProps.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FavoriteBorder, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color(0xFFB5945B))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No properties saved yet", fontWeight = FontWeight.Bold)
                        Text("Browse stays and tap the heart icon to save them.", fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(wishlistProps) { p ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectPropertyForBooking(p) },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                PropertyIllustration(
                                    type = p.type,
                                    seed = p.imageSeed,
                                    modifier = Modifier
                                        .size(80.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "${p.region} · ${p.county}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFB5945B)
                                    )
                                    Text(p.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, maxLines = 1)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("£${p.pricePerNight.toInt()} / night", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0A3C25))
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(12.dp))
                                        Text(" ${String.format("%.2f", p.rating)}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        activeWishlist?.let {
                                            viewModel.togglePropertyInWishlist(it.id, p.id)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.Red.copy(alpha = 0.7f))
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- Create Wishlist Dialog ---
        if (showCreateDialog) {
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                title = { Text("Create New Wishlist", fontFamily = FontFamily.Serif) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = newWishName,
                            onValueChange = { newWishName = it },
                            label = { Text("Wishlist Name") },
                            placeholder = { Text("e.g. Cornwall 2027") },
                            singleLine = true,
                            modifier = Modifier.testTag("create_wishlist_name_input")
                        )

                        OutlinedTextField(
                            value = newWishNotes,
                            onValueChange = { newWishNotes = it },
                            label = { Text("Notes (Collaborative description)") },
                            placeholder = { Text("e.g. Escapes reachable by train for the family.") }
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newWishName.isNotEmpty()) {
                                viewModel.createWishlist(newWishName, newWishNotes)
                                newWishName = ""
                                newWishNotes = ""
                                showCreateDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A3C25)),
                        modifier = Modifier.testTag("confirm_create_wishlist_button")
                    ) {
                        Text("Create")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
private fun CompareItem(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
