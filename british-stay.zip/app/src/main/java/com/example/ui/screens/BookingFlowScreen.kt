package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PropertyEntity
import com.example.ui.components.PropertyIllustration
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingFlowScreen(
    viewModel: StayViewModel,
    property: PropertyEntity,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    // Custom back handler
    BackHandler {
        viewModel.navigateBack()
    }

    val scrollState = rememberScrollState()

    var startDate by remember { mutableStateOf("2026-10-14") }
    var endDate by remember { mutableStateOf("2026-10-17") }
    var guests by remember { mutableStateOf(viewModel.searchGuests.value) }

    var cardNumber by remember { mutableStateOf("") }
    var cardHolder by remember { mutableStateOf("") }
    var paymentMode by remember { mutableStateOf("Visa") }

    var isProcessing by remember { mutableStateOf(false) }
    var isConfirmed by remember { mutableStateOf(false) }

    val totalDays = 3
    val baseTotal = property.pricePerNight * totalDays
    val finalTotal = baseTotal + property.cleaningFee + property.serviceFee

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A3C25))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFFF5F2EA))
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "CONFIRM & PAY",
                color = Color(0xFFF5F2EA),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Serif
            )
        }

        if (isConfirmed) {
            // --- CONFIRMATION SCREEN ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF0A3C25),
                    modifier = Modifier.size(72.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Booking Confirmed!",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Your stay at ${property.name} has been secured.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Trip Card Preview
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1C12), contentColor = Color(0xFFF5F2EA))
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "OFFLINE ARRIVAL CARD",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB5945B),
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = property.name.uppercase(),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Serif
                        )
                        Text(
                            text = "${property.cityOrTown}, ${property.county}",
                            fontSize = 12.sp,
                            color = Color(0xFFF5F2EA).copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("CHECK-IN", fontSize = 10.sp, color = Color(0xFFF5F2EA).copy(alpha = 0.6f))
                                Text("14 Oct · 15:00", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("CHECK-OUT", fontSize = 10.sp, color = Color(0xFFF5F2EA).copy(alpha = 0.6f))
                                Text("17 Oct · 10:00", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Divider(color = Color(0xFFF5F2EA).copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("KEY ENTRY CODE", fontSize = 10.sp, color = Color(0xFFF5F2EA).copy(alpha = 0.6f))
                                Text("★ 1066", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFB5945B))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("GUESTS", fontSize = 10.sp, color = Color(0xFFF5F2EA).copy(alpha = 0.6f))
                                Text("$guests Guests", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = {
                        viewModel.clearBackstackAndGoTo(AppScreen.TRIPS)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A3C25))
                ) {
                    Text("Go to My Trips", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            // --- CONFIRMATION & PAYMENT DETAILS ---
            Column(modifier = Modifier.padding(16.dp)) {
                // Property overview summary row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PropertyIllustration(
                        type = property.type,
                        seed = property.imageSeed,
                        modifier = Modifier
                            .size(70.dp)
                            .clip(RoundedCornerShape(6.dp))
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(property.name, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                        Text("${property.cityOrTown}, ${property.county}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Text("★ ${String.format("%.2f", property.rating)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB5945B))
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- Dates and Guests Editor ---
                Text("YOUR HOLIDAY DETAILS", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Dates", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("14 Oct 2026 – 17 Oct 2026 (3 nights)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                            TextButton(onClick = { }) {
                                Text("Edit", color = Color(0xFF0A3C25), fontWeight = FontWeight.Bold)
                            }
                        }
                        Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Guests", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("$guests Guests", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                            TextButton(onClick = { }) {
                                Text("Edit", color = Color(0xFF0A3C25), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- Simulated Payment Details ---
                Text("PREMIUM UK PAYMENTS", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Visa, Mastercard, Apple Pay selector
                            listOf("Visa", "Mastercard", "Apple Pay").forEach { mode ->
                                val active = paymentMode == mode
                                Button(
                                    onClick = { paymentMode = mode },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (active) Color(0xFF0A3C25) else MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = if (active) Color(0xFFF5F2EA) else MaterialTheme.colorScheme.onSurfaceVariant
                                    ),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(mode, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (paymentMode != "Apple Pay") {
                            OutlinedTextField(
                                value = cardNumber,
                                onValueChange = { cardNumber = it },
                                label = { Text("Card Number") },
                                placeholder = { Text("4532 •••• •••• ••••") },
                                leadingIcon = { Icon(Icons.Default.CreditCard, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("payment_card_number_input"),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = cardHolder,
                                onValueChange = { cardHolder = it },
                                label = { Text("Cardholder Name") },
                                placeholder = { Text("Tom") },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("payment_card_holder_input"),
                                singleLine = true
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Double-press lock button to pay securely.", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- Total transparent breakdown again ---
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Stay Price", fontSize = 13.sp)
                            Text("£${finalTotal.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Service Fee", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text("Included", fontSize = 11.sp, color = Color(0xFF0A3C25), fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // --- Confirm Button ---
                Button(
                    onClick = {
                        isProcessing = true
                        coroutineScope.launch {
                            kotlinx.coroutines.delay(1500) // simulated processing delay
                            isProcessing = false
                            isConfirmed = true
                            // Save reservation inside Room database state
                            viewModel.paymentCardNumber.value = cardNumber
                            viewModel.paymentCardHolder.value = cardHolder
                            viewModel.paymentMethod.value = paymentMode
                            viewModel.executeBookingPayment()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("confirm_booking_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A3C25)),
                    shape = RoundedCornerShape(8.dp),
                    enabled = !isProcessing
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    } else {
                        Text("Confirm and Pay · £${finalTotal.toInt()}", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF0A3C25), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Fully encrypted UK banking gateway connections.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                }
            }
        }
    }
}
