package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BookingEntity
import com.example.ui.components.PropertyIllustration
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel

@Composable
fun TripsScreen(
    viewModel: StayViewModel,
    bookings: List<BookingEntity>,
    modifier: Modifier = Modifier
) {
    // Custom back pressed support
    BackHandler {
        viewModel.navigateTo(AppScreen.EXPLORE)
        true
    }

    var selectedBookingForArrivalCard by remember { mutableStateOf<BookingEntity?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A3C25))
                .padding(horizontal = 16.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MY TRIPS",
                color = Color(0xFFF5F2EA),
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Serif
            )
        }

        if (bookings.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CardTravel, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color(0xFFB5945B))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("No trips booked yet", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Your confirmed reservations will appear here.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { viewModel.navigateTo(AppScreen.EXPLORE) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A3C25))
                    ) {
                        Text("Explore stays")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        text = "UPCOMING ESCAPES",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                items(bookings) { booking ->
                    val isOpened = selectedBookingForArrivalCard?.id == booking.id

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("booking_card_${booking.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                    ) {
                        Column {
                            // Property illustration top header
                            PropertyIllustration(
                                type = booking.propertyType,
                                seed = booking.imageSeed,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                            )

                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "${booking.propertyRegion} · ${booking.propertyCounty}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB5945B)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = booking.propertyName,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontFamily = FontFamily.Serif
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Dates: ${booking.startDate} to ${booking.endDate}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Guests: ${booking.guests} guests · Paid £${booking.totalPaid.toInt()}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )

                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Button(
                                        onClick = {
                                            selectedBookingForArrivalCard = if (isOpened) null else booking
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isOpened) Color(0xFFB5945B) else Color(0xFF0A3C25)
                                        ),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1.2f)
                                    ) {
                                        Icon(
                                            imageVector = if (isOpened) Icons.Default.ExpandLess else Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isOpened) "Close Arrival Card" else "Arrival & Entry Card", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    OutlinedButton(
                                        onClick = {
                                            viewModel.selectedChatPropertyId.value = booking.propertyId
                                            viewModel.navigateTo(AppScreen.INBOX)
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(0.8f)
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Chat", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Expandable Offline Check-In Arrival Card
                                if (isOpened) {
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(
                                            containerColor = Color(0xFF0D1C12),
                                            contentColor = Color(0xFFF5F2EA)
                                        ),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.VpnKey, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "DIGITAL TRIP PASS (OFFLINE)",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    letterSpacing = 1.5.sp,
                                                    color = Color(0xFFB5945B)
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(12.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Column {
                                                    Text("CHECK-IN TIME", fontSize = 9.sp, color = Color(0xFFF5F2EA).copy(alpha = 0.6f))
                                                    Text("From ${booking.checkInTime} on arrival", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                }
                                                Column(horizontalAlignment = Alignment.End) {
                                                    Text("CHECK-OUT TIME", fontSize = 9.sp, color = Color(0xFFF5F2EA).copy(alpha = 0.6f))
                                                    Text("Before ${booking.checkOutTime} on departure", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(12.dp))
                                            Divider(color = Color(0xFFF5F2EA).copy(alpha = 0.15f))
                                            Spacer(modifier = Modifier.height(12.dp))

                                            Text("ENTRY LOCKBOX SECURITY CODE", fontSize = 9.sp, color = Color(0xFFF5F2EA).copy(alpha = 0.6f))
                                            Text(
                                                text = "CODE: ★ ${booking.checkInCode}",
                                                fontSize = 20.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = Color(0xFFB5945B),
                                                fontFamily = FontFamily.Monospace
                                            )

                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text("ARRIVALS INSTRUCTIONS:", fontSize = 9.sp, color = Color(0xFFF5F2EA).copy(alpha = 0.6f))
                                            Text(
                                                text = booking.checkInInstructions,
                                                fontSize = 11.sp,
                                                lineHeight = 16.sp,
                                                color = Color(0xFFF5F2EA).copy(alpha = 0.8f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
