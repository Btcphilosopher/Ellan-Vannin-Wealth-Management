package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiClient
import com.example.data.db.ChatSession
import com.example.data.model.*
import com.example.data.repository.StayRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class AppScreen {
    EXPLORE,
    SEARCH_RESULTS,
    PROPERTY_DETAIL,
    BOOKING_FLOW,
    TRIPS,
    WISHLISTS,
    INBOX,
    HOST_MODE,
    JOURNAL_VIEW
}

class StayViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = StayRepository.getInstance(application)
    val wishlistDao = repository.wishlistDao

    // Navigation State
    private val _currentScreen = MutableStateFlow(AppScreen.EXPLORE)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val backstack = Stack<AppScreen>()

    // Core Data Flows from Room
    val allProperties = repository.allPropertiesFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val currentUser = repository.currentUserFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val bookings = repository.bookingsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val wishlists = repository.wishlistsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val journals = repository.journalsFlow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search Parameters
    var searchDestination = MutableStateFlow("")
    var searchDates = MutableStateFlow("Add dates")
    var searchGuests = MutableStateFlow(2)
    var searchCategory = MutableStateFlow("ANY")
    var selectedProperty = MutableStateFlow<PropertyEntity?>(null)

    // Dynamic Filter State
    private val _filteredProperties = MutableStateFlow<List<PropertyEntity>>(emptyList())
    val filteredProperties: StateFlow<List<PropertyEntity>> = _filteredProperties.asStateFlow()

    // Booking Details
    var bookingStartDate = MutableStateFlow("2026-10-14")
    var bookingEndDate = MutableStateFlow("2026-10-17")
    var bookingGuestsCount = MutableStateFlow(2)
    var paymentCardNumber = MutableStateFlow("")
    var paymentCardHolder = MutableStateFlow("")
    var paymentMethod = MutableStateFlow("Visa")
    var lastCreatedBooking = MutableStateFlow<BookingEntity?>(null)

    // Selected Details for detail sub-views
    var selectedWishlist = MutableStateFlow<WishlistEntity?>(null)
    val wishlistProperties = MutableStateFlow<List<PropertyEntity>>(emptyList())
    
    // Messaging Details
    val chatSessions = repository.messageDao.getChatSessionsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    var selectedChatPropertyId = MutableStateFlow<Int?>(null)
    val chatMessages = selectedChatPropertyId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList())
        else repository.messageDao.getMessagesForPropertyFlow(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Journal Details
    var selectedJournal = MutableStateFlow<JournalEntity?>(null)

    // Stay Finder AI State
    var stayFinderQuery = MutableStateFlow("")
    var stayFinderResponse = MutableStateFlow("")
    var stayFinderLoading = MutableStateFlow(false)

    // Host Mode Assistant State
    var hostAssistantQuery = MutableStateFlow("")
    var hostAssistantResponse = MutableStateFlow("")
    var hostAssistantLoading = MutableStateFlow(false)

    // Host Mode Management
    var hostSelectedProperty = MutableStateFlow<PropertyEntity?>(null)
    var hostSelectedDate = MutableStateFlow("2026-10-01")
    var hostCustomPriceInput = MutableStateFlow("")
    var hostIsBlockedInput = MutableStateFlow(false)

    // Co-host Management State
    var coHostsList = MutableStateFlow<List<String>>(listOf("Sarah (Primary Host)", "Arthur (Co-Host)", "Victoria (Cleaner)"))
    var coHostPermissions = MutableStateFlow<Map<String, Boolean>>(mapOf(
        "Arthur (Co-Host)" to true,
        "Victoria (Cleaner)" to false
    ))

    init {
        viewModelScope.launch {
            repository.initializeDatabaseIfEmpty()
            // Pull initial properties for filtered properties list
            allProperties.collectLatest {
                if (it.isNotEmpty() && _filteredProperties.value.isEmpty()) {
                    _filteredProperties.value = it
                }
            }
        }
    }

    // --- Navigation Core ---
    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            backstack.push(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (!backstack.isEmpty()) {
            _currentScreen.value = backstack.pop()
            return true
        }
        return false
    }

    fun clearBackstackAndGoTo(screen: AppScreen) {
        backstack.clear()
        _currentScreen.value = screen
    }

    // --- Search & Recommendations ---
    fun selectCategory(cat: String) {
        searchCategory.value = cat
        performSearch()
    }

    fun performSearch() {
        viewModelScope.launch(Dispatchers.IO) {
            val dest = searchDestination.value.lowercase().trim()
            val guests = searchGuests.value
            val cat = searchCategory.value
            val all = allProperties.value

            val filtered = all.filter { p ->
                // Category match
                val catMatch = cat == "ANY" || p.category == cat
                
                // Guests match
                val guestsMatch = p.guests >= guests

                // Term match (City, Region, County, Station, Postcode)
                val destMatch = if (dest.isEmpty()) {
                    true
                } else {
                    p.cityOrTown.lowercase().contains(dest) ||
                    p.region.lowercase().contains(dest) ||
                    p.county.lowercase().contains(dest) ||
                    p.stationName.lowercase().contains(dest) ||
                    p.name.lowercase().contains(dest) ||
                    p.description.lowercase().contains(dest) ||
                    (dest.contains("station") && p.stationName.isNotEmpty()) ||
                    (dest.contains("dog") && p.isDogFriendly) ||
                    (dest.contains("ev") && p.hasEvCharging)
                }

                catMatch && guestsMatch && destMatch
            }

            _filteredProperties.value = filtered
            navigateTo(AppScreen.SEARCH_RESULTS)
        }
    }

    fun performStayFinderAISearch() {
        val query = stayFinderQuery.value.trim()
        if (query.isEmpty()) return

        stayFinderLoading.value = true
        stayFinderResponse.value = ""

        viewModelScope.launch {
            val response = GeminiClient.getStayFinderResponse(query)
            stayFinderResponse.value = response
            stayFinderLoading.value = false

            // Automatically filter properties based on keywords from query
            val all = allProperties.value
            val lowerQuery = query.lowercase()
            val matched = all.filter { p ->
                lowerQuery.contains(p.cityOrTown.lowercase()) ||
                lowerQuery.contains(p.county.lowercase()) ||
                lowerQuery.contains(p.region.lowercase()) ||
                lowerQuery.contains(p.type.lowercase()) ||
                (lowerQuery.contains("dog") && p.isDogFriendly) ||
                (lowerQuery.contains("train") && p.minutesToStationWalk <= 15) ||
                (lowerQuery.contains("station") && p.stationName.isNotEmpty()) ||
                (lowerQuery.contains("fireplace") && p.hasFireplace) ||
                (lowerQuery.contains("hot tub") && p.hasHotTub)
            }
            if (matched.isNotEmpty()) {
                _filteredProperties.value = matched
            }
        }
    }

    // --- Booking Logic ---
    fun selectPropertyForBooking(property: PropertyEntity) {
        selectedProperty.value = property
        bookingGuestsCount.value = searchGuests.value
        navigateTo(AppScreen.PROPERTY_DETAIL)
    }

    fun executeBookingPayment() {
        val prop = selectedProperty.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val nights = calculateNights(bookingStartDate.value, bookingEndDate.value)
            val basePrice = prop.customizedBasePrice ?: prop.pricePerNight
            val rawTotal = basePrice * nights
            val cleanFee = prop.cleaningFee
            val servFee = prop.serviceFee
            val finalTotal = rawTotal + cleanFee + servFee

            val newBooking = BookingEntity(
                propertyId = prop.id,
                propertyName = prop.name,
                propertyType = prop.type,
                propertyRegion = prop.region,
                propertyCounty = prop.county,
                imageSeed = prop.imageSeed,
                startDate = bookingStartDate.value,
                endDate = bookingEndDate.value,
                guests = bookingGuestsCount.value,
                status = "CONFIRMED",
                nightlyRate = basePrice,
                cleaningFee = cleanFee,
                serviceFee = servFee,
                totalPaid = finalTotal,
                checkInCode = (1000 + Random().nextInt(9000)).toString(),
                checkInInstructions = "The keys are located in the secure metal lockbox directly to the right of the ${prop.type.lowercase()}'s front entrance. Code is active starting 15:00 on arrival day."
            )

            val bookingId = repository.bookingDao.insertBooking(newBooking)
            val persistedBooking = newBooking.copy(id = bookingId.toInt())
            lastCreatedBooking.value = persistedBooking

            // Trigger notification
            insertNotificationMessage(prop, "Your booking for ${prop.name} has been successfully processed and confirmed. Payment of £${String.format("%.2f", finalTotal)} authorized.")

            // Clear selected fields
            paymentCardNumber.value = ""
            paymentCardHolder.value = ""

            // Pull updated properties to reflect occupancy if any analytics are affected
            navigateTo(AppScreen.TRIPS)
        }
    }

    private fun insertNotificationMessage(prop: PropertyEntity, customText: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.messageDao.insertMessage(
                MessageEntity(
                    propertyId = prop.id,
                    propertyName = prop.name,
                    hostName = prop.hostName,
                    sender = "HOST",
                    text = customText,
                    status = "UNREAD"
                )
            )
        }
    }

    private fun calculateNights(start: String, end: String): Int {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val startDate = sdf.parse(start)
            val endDate = sdf.parse(end)
            if (startDate != null && endDate != null) {
                val diff = endDate.time - startDate.time
                val days = diff / (1000 * 60 * 60 * 24)
                if (days > 0) days.toInt() else 1
            } else 1
        } catch (e: Exception) {
            3
        }
    }

    // --- Reviews ---
    fun submitPropertyReview(propertyId: Int, author: String, rating: Int, content: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val review = ReviewEntity(
                propertyId = propertyId,
                authorName = author,
                rating = rating,
                content = content,
                date = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())
            )
            repository.reviewDao.insertReview(review)
        }
    }

    fun getReviewsForProperty(propertyId: Int): Flow<List<ReviewEntity>> {
        return repository.reviewDao.getReviewsForPropertyFlow(propertyId)
    }

    // --- Messaging ---
    fun selectChatSession(propertyId: Int) {
        selectedChatPropertyId.value = propertyId
        navigateTo(AppScreen.INBOX)
    }

    fun sendGuestChatMessage(propertyId: Int, text: String) {
        if (text.trim().isEmpty()) return
        val prop = allProperties.value.firstOrNull { it.id == propertyId } ?: return

        viewModelScope.launch(Dispatchers.IO) {
            val guestMsg = MessageEntity(
                propertyId = propertyId,
                propertyName = prop.name,
                hostName = prop.hostName,
                sender = "GUEST",
                text = text,
                status = "SENT"
            )
            repository.messageDao.insertMessage(guestMsg)

            // Dynamic agent responder
            delay(1000)
            val hostReplyText = getDynamicHostResponder(prop, text)
            val hostMsg = MessageEntity(
                propertyId = propertyId,
                propertyName = prop.name,
                hostName = prop.hostName,
                sender = "HOST",
                text = hostReplyText,
                status = "READ"
            )
            repository.messageDao.insertMessage(hostMsg)
        }
    }

    private fun getDynamicHostResponder(prop: PropertyEntity, text: String): String {
        val t = text.lowercase()
        return when {
            t.contains("key") || t.contains("lockbox") || t.contains("code") || t.contains("check in") -> {
                "Hi Tom! The check-in code is active on your arrival date from 15:00. The lockbox is beside the entrance door. Let me know if you need any directions from the local station!"
            }
            t.contains("wifi") || t.contains("internet") -> {
                "Yes, the high-speed broadband details are in your digital trip card! Network is 'BritishStay_${prop.name.replace(" ", "")}' and password is '${prop.hostName.lowercase()}2026'."
            }
            t.contains("dog") || t.contains("pet") -> {
                if (prop.isDogFriendly) {
                    "Absolutely! We are completely muddy-dog friendly. We even have a dedicated wash tub in the boot room and local organic dog biscuits waiting for you."
                } else {
                    "Unfortunately, due to historical textures and delicate fabrics inside the property, we cannot accommodate pets. Let me know if you'd like recommendations for local boardings!"
                }
            }
            t.contains("station") || t.contains("train") || t.contains("walk") -> {
                if (prop.stationName.isNotEmpty()) {
                    "It is a beautiful ${prop.minutesToStationWalk}-minute walk to ${prop.stationName}. The pathway is fully paved and passes by some beautiful cottages and local sights!"
                } else {
                    "The nearest major railway station is about a 20-minute taxi ride away. We recommend pre-booking a taxi from our local guide page!"
                }
            }
            else -> {
                "Thank you for reaching out, Tom! That is perfectly fine. I am always happy to help with anything to make your stay at ${prop.name} absolutely marvelous. Let me know if you have any other questions!"
            }
        }
    }

    // --- Wishlist Management ---
    fun createWishlist(name: String, notes: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.wishlistDao.insertWishlist(WishlistEntity(name = name, notes = notes))
        }
    }

    fun togglePropertyInWishlist(wishlistId: Int, propertyId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            if (repository.wishlistDao.isPropertyInWishlist(wishlistId, propertyId)) {
                repository.wishlistDao.removeWishlistItem(wishlistId, propertyId)
            } else {
                repository.wishlistDao.insertWishlistItem(WishlistItemEntity(wishlistId = wishlistId, propertyId = propertyId))
            }
            loadWishlistProperties(wishlistId)
        }
    }

    fun loadWishlistProperties(wishlistId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = repository.wishlistDao.getPropertiesInWishlist(wishlistId)
            val currentWish = repository.wishlistDao.getWishlistById(wishlistId)
            selectedWishlist.value = currentWish
            wishlistProperties.value = list
        }
    }

    // --- Host Mode Management ---
    fun selectHostProperty(property: PropertyEntity) {
        hostSelectedProperty.value = property
        hostCustomPriceInput.value = (property.customizedBasePrice ?: property.pricePerNight).toString()
        hostIsBlockedInput.value = property.isBlocked
    }

    fun saveHostCalendarSettings() {
        val prop = hostSelectedProperty.value ?: return
        val price = hostCustomPriceInput.value.toDoubleOrNull() ?: prop.pricePerNight
        val blocked = hostIsBlockedInput.value

        viewModelScope.launch(Dispatchers.IO) {
            val updated = prop.copy(
                customizedBasePrice = price,
                isBlocked = blocked
            )
            repository.propertyDao.updateProperty(updated)
            // Update selected holder
            hostSelectedProperty.value = updated
            // Update full list to update UI
            performSearch()
        }
    }

    fun submitHostAssistantQuery() {
        val prop = hostSelectedProperty.value ?: return
        val query = hostAssistantQuery.value.trim()
        if (query.isEmpty()) return

        hostAssistantLoading.value = true
        hostAssistantResponse.value = ""

        viewModelScope.launch {
            val propDetails = """
                Name: ${prop.name}
                Type: ${prop.type}
                Price: £${prop.pricePerNight}/night
                Location: ${prop.cityOrTown}, ${prop.county}
                Rating: ${prop.rating}
                Description: ${prop.description}
                Amenities: Wifi=${prop.hasWifi}, Fireplace=${prop.hasFireplace}, EVCharger=${prop.hasEvCharging}, DogFriendly=${prop.isDogFriendly}
            """.trimIndent()

            val response = GeminiClient.getHostAssistantResponse(propDetails, query)
            hostAssistantResponse.value = response
            hostAssistantLoading.value = false
        }
    }

    // Co-hosts permissions toggle
    fun toggleCoHostPermission(name: String) {
        val current = coHostPermissions.value.toMutableMap()
        if (current.containsKey(name)) {
            current[name] = !(current[name] ?: false)
            coHostPermissions.value = current
        }
    }

    // --- Dynamic Pricing Simulation Model (Deterministic) ---
    fun getSimulatedDynamicPrice(baseRate: Double, season: String, isWeekend: Boolean, demand: String): Double {
        var multiplier = 1.0
        // Season
        when (season.uppercase()) {
            "SUMMER_PEAK" -> multiplier += 0.25
            "WINTER_LOW" -> multiplier -= 0.15
            "AUTUMN_MIST" -> multiplier -= 0.05
            "SPRING_BLOOM" -> multiplier += 0.05
        }
        // Weekend
        if (isWeekend) multiplier += 0.15
        // Demand
        when (demand.uppercase()) {
            "HIGH" -> multiplier += 0.10
            "CRITICAL" -> multiplier += 0.20
            "LOW" -> multiplier -= 0.10
        }
        return baseRate * multiplier
    }
}
