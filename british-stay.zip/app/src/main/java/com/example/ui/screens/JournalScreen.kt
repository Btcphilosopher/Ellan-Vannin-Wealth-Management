package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.JournalEntity
import com.example.ui.components.PropertyIllustration
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel

@Composable
fun JournalScreen(
    viewModel: StayViewModel,
    article: JournalEntity,
    modifier: Modifier = Modifier
) {
    // Back pressed action
    BackHandler {
        viewModel.navigateBack()
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A3C25)) // Racing Green
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFFF5F2EA))
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "BRITISH STAY JOURNAL",
                color = Color(0xFFF5F2EA),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Serif
            )
        }

        // Article Top Banner Graphic Illustration
        PropertyIllustration(
            type = "contemporary", // stylized
            seed = article.imageSeed,
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        )

        // Article Content Body in Serif Style
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = article.category,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFB5945B),
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = article.title,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Serif,
                lineHeight = 30.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = article.subtitle,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "By ${article.author}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0A3C25)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = article.readTime,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(16.dp))

            // Main text blocks
            article.content.split("\n\n").forEach { paragraph ->
                Text(
                    text = paragraph,
                    fontSize = 15.sp,
                    lineHeight = 24.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                    fontFamily = FontFamily.Serif,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF8F5)),
                border = BorderStroke(1.dp, Color(0xFFEFECE5))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "EXPLORE SCENIC ESCAPES",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB5945B)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "All properties matching this article are available on the home explore portal with direct train connection markers.",
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.navigateTo(AppScreen.EXPLORE) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A3C25)),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(36.dp).testTag("journal_explore_cta_button")
                    ) {
                        Text("Explore stays now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
