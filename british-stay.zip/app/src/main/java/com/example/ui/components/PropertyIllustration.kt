package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun PropertyIllustration(
    type: String,
    seed: Int,
    modifier: Modifier = Modifier
) {
    // Elegant, curated Anglo-Futurist atmospheric palettes
    val palette = when (seed % 6) {
        0 -> Triple(Color(0xFF0F1E36), Color(0xFFF5F2EA), Color(0xFFB5945B)) // Navy, Ivory, Gold Brass
        1 -> Triple(Color(0xFF0A3C25), Color(0xFFFAF8F5), Color(0xFFD4AF37)) // Racing Green, Parchment, Brass
        2 -> Triple(Color(0xFF2E1C1C), Color(0xFFFAF5EF), Color(0xFFC5A059)) // Burgundy, Soft Rose, Gold
        3 -> Triple(Color(0xFF1E242C), Color(0xFFEFECE5), Color(0xFF8A6D3B)) // Charcoal, Muted Stone, Warm Bronze
        4 -> Triple(Color(0xFF0A2C3C), Color(0xFFF0F4F8), Color(0xFFC0A268)) // Ocean Teal, Soft Blue, Soft Gold
        else -> Triple(Color(0xFF222831), Color(0xFFECEFF1), Color(0xFFB09B72)) // Dark Slate, Cool White, Pewter
    }

    val primaryBg = palette.first
    val secondaryStone = palette.second
    val accentBrass = palette.third

    Box(modifier = modifier.background(primaryBg)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            when (type.lowercase()) {
                "cottage", "barn" -> {
                    // Draw traditional stone cottage / barn landscape
                    // 1. Hills in background
                    val hill1 = Path().apply {
                        moveTo(0f, height * 0.8f)
                        quadraticTo(width * 0.4f, height * 0.55f, width, height * 0.75f)
                        lineTo(width, height)
                        lineTo(0f, height)
                        close()
                    }
                    val hill2 = Path().apply {
                        moveTo(0f, height * 0.9f)
                        quadraticTo(width * 0.6f, height * 0.65f, width, height * 0.6f)
                        lineTo(width, height)
                        lineTo(0f, height)
                        close()
                    }
                    drawPath(hill1, secondaryStone.copy(alpha = 0.2f))
                    drawPath(hill2, secondaryStone.copy(alpha = 0.15f))

                    // 2. Stone house base (Georgian/Victorian proportioned cottage)
                    val houseW = width * 0.5f
                    val houseH = height * 0.4f
                    val houseX = (width - houseW) / 2f
                    val houseY = height * 0.5f

                    // Draw stone wall
                    drawRect(
                        color = secondaryStone,
                        topLeft = Offset(houseX, houseY),
                        size = Size(houseW, houseH)
                    )

                    // 3. Gabled Roof (Classic slate roof)
                    val roof = Path().apply {
                        moveTo(houseX - 10f, houseY)
                        lineTo(houseX + houseW / 2f, houseY - height * 0.22f)
                        lineTo(houseX + houseW + 10f, houseY)
                        close()
                    }
                    drawPath(roof, primaryBg.copy(alpha = 0.85f))
                    drawPath(roof, accentBrass, style = Stroke(width = 1.5.dp.toPx()))

                    // Chimney
                    drawRect(
                        color = primaryBg.copy(alpha = 0.9f),
                        topLeft = Offset(houseX + houseW * 0.75f, houseY - height * 0.18f),
                        size = Size(20f, 40f)
                    )

                    // 4. Sash Windows & Door
                    val winW = houseW * 0.16f
                    val winH = houseH * 0.28f

                    // First floor sash windows
                    drawRect(
                        color = primaryBg,
                        topLeft = Offset(houseX + houseW * 0.18f, houseY + houseH * 0.15f),
                        size = Size(winW, winH)
                    )
                    drawRect(
                        color = primaryBg,
                        topLeft = Offset(houseX + houseW * 0.66f, houseY + houseH * 0.15f),
                        size = Size(winW, winH)
                    )

                    // Door (British Racing Green or Burgundy)
                    val doorW = houseW * 0.18f
                    val doorH = houseH * 0.42f
                    drawRect(
                        color = accentBrass,
                        topLeft = Offset(houseX + (houseW - doorW) / 2f, houseY + houseH * 0.58f),
                        size = Size(doorW, doorH)
                    )
                    // Brass doorknob
                    drawCircle(
                        color = secondaryStone,
                        radius = 2.dp.toPx(),
                        center = Offset(houseX + houseW / 2f + doorW * 0.3f, houseY + houseH * 0.8f)
                    )
                }

                "townhouse", "penthouse" -> {
                    // Draw Georgian multi-story classical townhouse front
                    val buildingW = width * 0.45f
                    val buildingH = height * 0.85f
                    val bx = (width - buildingW) / 2f
                    val by = height * 0.15f

                    // Building façade
                    drawRect(color = secondaryStone, topLeft = Offset(bx, by), size = Size(buildingW, buildingH))

                    // Draw columns / Georgian lines
                    drawLine(
                        color = primaryBg.copy(alpha = 0.15f),
                        start = Offset(bx, by),
                        end = Offset(bx, by + buildingH),
                        strokeWidth = 3f
                    )
                    drawLine(
                        color = primaryBg.copy(alpha = 0.15f),
                        start = Offset(bx + buildingW, by),
                        end = Offset(bx + buildingW, by + buildingH),
                        strokeWidth = 3f
                    )

                    // 3 Rows of proportional sash windows
                    val winW = buildingW * 0.22f
                    val winH = buildingH * 0.16f
                    val gapY = buildingH * 0.06f

                    for (row in 0..2) {
                        val wy = by + row * (winH + gapY) + gapY
                        // Left Window
                        drawRect(
                            color = primaryBg,
                            topLeft = Offset(bx + buildingW * 0.18f, wy),
                            size = Size(winW, winH)
                        )
                        // Window panes lines
                        drawLine(
                            color = secondaryStone.copy(alpha = 0.3f),
                            start = Offset(bx + buildingW * 0.18f + winW / 2f, wy),
                            end = Offset(bx + buildingW * 0.18f + winW / 2f, wy + winH),
                            strokeWidth = 1f
                        )
                        drawLine(
                            color = secondaryStone.copy(alpha = 0.3f),
                            start = Offset(bx + buildingW * 0.18f, wy + winH / 2f),
                            end = Offset(bx + buildingW * 0.18f + winW, wy + winH / 2f),
                            strokeWidth = 1f
                        )

                        // Right Window
                        drawRect(
                            color = primaryBg,
                            topLeft = Offset(bx + buildingW * 0.6f, wy),
                            size = Size(winW, winH)
                        )
                        drawLine(
                            color = secondaryStone.copy(alpha = 0.3f),
                            start = Offset(bx + buildingW * 0.6f + winW / 2f, wy),
                            end = Offset(bx + buildingW * 0.6f + winW / 2f, wy + winH),
                            strokeWidth = 1f
                        )
                    }

                    // Classical Pediment Triangle on Top
                    val pediment = Path().apply {
                        moveTo(bx - 5f, by)
                        lineTo(bx + buildingW / 2f, by - height * 0.08f)
                        lineTo(bx + buildingW + 5f, by)
                        close()
                    }
                    drawPath(pediment, accentBrass)
                }

                "canal boat", "narrowboat" -> {
                    // Draw cozy London narrowboat on water
                    // Water lines
                    for (i in 0..3) {
                        val wy = height * 0.75f + i * 20f
                        drawLine(
                            color = secondaryStone.copy(alpha = 0.2f),
                            start = Offset(0f, wy),
                            end = Offset(width, wy),
                            strokeWidth = 2f
                        )
                    }

                    // Boat hull
                    val boatW = width * 0.75f
                    val boatH = height * 0.22f
                    val bx = (width - boatW) / 2f
                    val by = height * 0.52f

                    val hull = Path().apply {
                        moveTo(bx, by)
                        lineTo(bx + boatW * 0.85f, by)
                        quadraticTo(bx + boatW, by, bx + boatW, by + boatH * 0.5f)
                        lineTo(bx + boatW * 0.92f, by + boatH)
                        lineTo(bx + boatW * 0.08f, by + boatH)
                        lineTo(bx, by + boatH * 0.4f)
                        close()
                    }
                    drawPath(hull, accentBrass)

                    // Cabin roof top
                    drawRect(
                        color = secondaryStone,
                        topLeft = Offset(bx + boatW * 0.15f, by - boatH * 0.4f),
                        size = Size(boatW * 0.68f, boatH * 0.4f)
                    )

                    // Portholes windows
                    val pr = 10f
                    val gapX = boatW * 0.15f
                    for (i in 0..3) {
                        drawCircle(
                            color = primaryBg,
                            radius = pr,
                            center = Offset(bx + boatW * 0.25f + i * gapX, by - boatH * 0.2f)
                        )
                    }

                    // Smoke stack with smoke puff
                    drawLine(
                        color = secondaryStone,
                        start = Offset(bx + boatW * 0.2f, by - boatH * 0.4f),
                        end = Offset(bx + boatW * 0.2f, by - boatH * 0.8f),
                        strokeWidth = 4f
                    )
                }

                else -> {
                    // Minimalist contemporary/cabin design
                    // Background mountain / geometric accent
                    val peak = Path().apply {
                        moveTo(width * 0.1f, height)
                        lineTo(width * 0.5f, height * 0.25f)
                        lineTo(width * 0.9f, height)
                        close()
                    }
                    drawPath(peak, secondaryStone.copy(alpha = 0.1f))

                    // A-Frame or Larch-wrapped Box
                    val cabinW = width * 0.45f
                    val cabinH = height * 0.45f
                    val cx = (width - cabinW) / 2f
                    val cy = height * 0.45f

                    // Charred larch box
                    drawRoundRect(
                        color = primaryBg.copy(alpha = 0.5f),
                        topLeft = Offset(cx, cy),
                        size = Size(cabinW, cabinH),
                        cornerRadius = CornerRadius(8f, 8f),
                        style = Stroke(width = 2.dp.toPx())
                    )
                    drawRoundRect(
                        color = secondaryStone,
                        topLeft = Offset(cx, cy),
                        size = Size(cabinW, cabinH),
                        cornerRadius = CornerRadius(8f, 8f)
                    )

                    // Golden huge glass window
                    drawRect(
                        color = primaryBg,
                        topLeft = Offset(cx + cabinW * 0.15f, cy + cabinH * 0.15f),
                        size = Size(cabinW * 0.7f, cabinH * 0.7f)
                    )

                    // Hanging fireplace glow line
                    drawLine(
                        color = accentBrass,
                        start = Offset(cx + cabinW * 0.5f, cy + cabinH * 0.15f),
                        end = Offset(cx + cabinW * 0.5f, cy + cabinH * 0.6f),
                        strokeWidth = 3f
                    )
                    drawCircle(
                        color = accentBrass,
                        radius = 8f,
                        center = Offset(cx + cabinW * 0.5f, cy + cabinH * 0.6f)
                    )
                }
            }
        }
    }
}
