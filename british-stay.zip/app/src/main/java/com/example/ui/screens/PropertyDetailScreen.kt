package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PropertyEntity
import com.example.ui.components.PropertyIllustration
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PropertyDetailScreen(
    viewModel: StayViewModel,
    property: PropertyEntity,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    // Custom back pressed handling
    BackHandler {
        viewModel.navigateBack()
    }

    val wishlists by viewModel.wishlists.collectAsState()
    var isSavedInWishlist by remember { mutableStateOf(false) }

    // Check if saved in any wishlist on launch
    LaunchedEffect(wishlists, property) {
        if (wishlists.isNotEmpty()) {
            isSavedInWishlist = viewModel.wishlistDao.isPropertyInWishlist(wishlists.first().id, property.id)
        }
    }

    val scrollState = rememberScrollState()

    // Amenities List mapping
    val amenities = mutableListOf<Pair<String, Boolean>>().apply {
        add("High-Speed Wi-Fi" to property.hasWifi)
        add("Cozy Log Fireplace" to property.hasFireplace)
        add("EV Fast Charging" to property.hasEvCharging)
        add("Muddy-Dog Friendly" to property.isDogFriendly)
        add("Secure Cycle Storage" to true)
        add("Boot Room" to property.hasBootRoom)
        add("Expansive Garden" to property.hasGarden)
        add("Outdoor Cedar Hot Tub" to property.hasHotTub)
        add("Complimentary Tea & Coffee" to true)
        add("Drying Room" to property.hasBootRoom)
    }

    Scaffold(
        bottomBar = {
            // STICKY BOTTOM RESERVATION BAR
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "£${property.pricePerNight.toInt()}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF0A3C25)
                            )
                            Text(
                                text = " / night",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        Text(
                            text = "£${(property.pricePerNight * 3).toInt()} total (3 nights)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.bookingStartDate.value = "2026-10-14"
                            viewModel.bookingEndDate.value = "2026-10-17"
                            viewModel.bookingGuestsCount.value = viewModel.searchGuests.value
                            viewModel.navigateTo(AppScreen.BOOKING_FLOW)
                        },
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("instant_book_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A3C25)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Instant Book", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // --- 1. HERO GRAPHIC ILLUSTRATION ---
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
            ) {
                PropertyIllustration(
                    type = property.type,
                    seed = property.imageSeed,
                    modifier = Modifier.fillMaxSize()
                )

                // Back & Wishlist Floating buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Wishlist button
                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    if (wishlists.isEmpty()) {
                                        viewModel.createWishlist("My Stays", "Curated British escapes.")
                                        kotlinx.coroutines.delay(500)
                                    }
                                    val activeWish = viewModel.wishlists.value.firstOrNull()
                                    if (activeWish != null) {
                                        viewModel.togglePropertyInWishlist(activeWish.id, property.id)
                                        isSavedInWishlist = !isSavedInWishlist
                                    }
                                }
                            },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.4f), CircleShape)
                                .size(36.dp)
                                .testTag("save_wishlist_button")
                        ) {
                            Icon(
                                imageVector = if (isSavedInWishlist) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Wishlist",
                                tint = if (isSavedInWishlist) Color.Red else Color.White
                            )
                        }
                    }
                }
            }

            // --- 2. TITLE & LOCATION ---
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "${property.cityOrTown}, ${property.county}, ${property.region}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFB5945B),
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = property.name,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Serif
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(16.dp))
                    Text(
                        text = String.format(" %.2f · ", property.rating),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${property.reviewsCount} reviews",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline
                    )
                    if (property.isVerified) {
                        Spacer(modifier = Modifier.width(12.dp))
                        Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF0A3C25), modifier = Modifier.size(16.dp))
                        Text(
                            text = " Verified Stay",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0A3C25)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Entire ${property.type.lowercase()} · ${property.guests} guests · ${property.bedrooms} bedrooms · ${property.beds} beds · ${property.bathrooms} bath",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(16.dp))

                // --- 3. RECOMMENDATION ENGINE ("WHY THIS PROPERTY") ---
                Text(
                    text = "WHY THIS STAY FITS PERFECTLY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFBF9F4)),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFEFECE5))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (property.stationName.isNotEmpty()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF0A3C25), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Reachable by rail: just ${property.minutesToStationWalk} mins walk from ${property.stationName}.", fontSize = 12.sp)
                            }
                        }
                        if (property.isDogFriendly) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF0A3C25), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Completely dog-friendly with scenic walking paths.", fontSize = 12.sp)
                            }
                        }
                        if (property.hasFireplace) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF0A3C25), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Cozy wood fireplace makes it perfect for frosty evenings.", fontSize = 12.sp)
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF0A3C25), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Exceptional rating of ${String.format("%.2f", property.rating)} with verified reviews.", fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- 4. THE SPACE (EDITORIAL DESCRIPTION) ---
                Text(
                    text = "THE SPACE",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = property.description,
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                )
                if (property.spaceDetails.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = property.spaceDetails,
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- 5. GETTING THERE (TRANSPORT LINK VISUALIZATION) ---
                Text(
                    text = "GETTING THERE",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (property.stationName.isNotEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF001E36).copy(alpha = 0.05f))
                            .padding(14.dp)
                    ) {
                        Text(
                            text = "Sceneries & Connection details:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF001E36)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        // Visual pathway representation
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Home, contentDescription = null, tint = Color(0xFF0A3C25))
                                Text("This Stay", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Divider(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(2.dp),
                                color = Color(0xFFB5945B)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    "${property.minutesToStationWalk} min walk",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB5945B)
                                )
                                Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Divider(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(2.dp),
                                color = Color(0xFF001E36)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Train, contentDescription = null, tint = Color(0xFF001E36))
                                Text(property.stationName, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (property.gettingThere.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = property.gettingThere,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                lineHeight = 18.sp
                            )
                        }
                    }
                } else {
                    Text("Best reached via taxi or private car. EV parking space available on premises.", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(24.dp))

                // --- 6. DETAILED AMENITY SYSTEM ---
                Text(
                    text = "AMENITIES",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    amenities.forEach { (name, present) ->
                        if (present) {
                            SuggestionChip(
                                onClick = { },
                                label = { Text(name, fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                                shape = RoundedCornerShape(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // --- 7. TRANSPARENT PRICE BREAKDOWN ---
                Text(
                    text = "TRANSPARENT BREAKDOWN",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("£${property.pricePerNight.toInt()} × 3 nights", fontSize = 13.sp)
                            Text("£${(property.pricePerNight * 3).toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Cleaning Fee", fontSize = 13.sp)
                            Text("£${property.cleaningFee.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Service Charge", fontSize = 13.sp)
                            Text("£${property.serviceFee.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("TOTAL (GBP)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("£${(property.pricePerNight * 3 + property.cleaningFee + property.serviceFee).toInt()}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0A3C25))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // --- 8. THE AREA LOCAL GUIDE ---
                Text(
                    text = "THE AREA & LOCAL GUIDE",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(8.dp))

                val guideSpots = listOf(
                    Triple("The Castle Snug Pub", "Historic traditional tavern with fireplace", "5 min walk"),
                    Triple("Peak Bakery & Café", "Local organic sourdough and fresh tea", "10 min walk"),
                    Triple("Mam Tor Ridge Trail", "Breathtaking national park ridge walk", "15 min drive"),
                    Triple("Hope Station Link", "Train linkages directly to Manchester/Sheffield", "12 min walk")
                )

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    guideSpots.forEach { (spot, desc, dist) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(spot, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                            Text(dist, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0A3C25))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // --- 9. HOST PROFILE & ACTION MESSAGING ---
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1C12), contentColor = Color(0xFFF5F2EA))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFB5945B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = property.hostName.take(1),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                    color = Color(0xFF0D1C12)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text("Hosted by ${property.hostName}", fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                                Text("Verified Host · 3 years experience · ★ 4.95", fontSize = 12.sp, color = Color(0xFFF5F2EA).copy(alpha = 0.7f))
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Sarah and family love welcoming visitors to the Derbyshire hills. They can help recommend local station hikes, traditional gastropubs, and secure storage for cycling gear.",
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            color = Color(0xFFF5F2EA).copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.selectedChatPropertyId.value = property.id
                                viewModel.navigateTo(AppScreen.INBOX)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB5945B)),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("contact_host_button")
                        ) {
                            Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Contact Host", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}
