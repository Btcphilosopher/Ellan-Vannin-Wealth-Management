package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MessageEntity
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel

@Composable
fun InboxScreen(
    viewModel: StayViewModel,
    chatSessions: List<com.example.data.db.ChatSession>,
    messages: List<MessageEntity>,
    modifier: Modifier = Modifier
) {
    // Custom backpressed handler
    BackHandler {
        if (viewModel.selectedChatPropertyId.value != null) {
            viewModel.selectedChatPropertyId.value = null
        } else {
            viewModel.navigateTo(AppScreen.EXPLORE)
        }
    }

    val selectedPropertyId by viewModel.selectedChatPropertyId.collectAsState()
    var messageText by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A3C25))
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectedPropertyId != null) {
                IconButton(onClick = { viewModel.selectedChatPropertyId.value = null }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFFF5F2EA))
                }
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = if (selectedPropertyId != null) "CHAT WITH HOST" else "INBOX MESSAGES",
                color = Color(0xFFF5F2EA),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Serif
            )
        }

        if (selectedPropertyId == null) {
            // --- CONVERSATIONS INDEX ---
            if (chatSessions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color(0xFFB5945B))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("No messages yet", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                        Text("Connect with verified hosts on the stays pages.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(chatSessions) { session ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectedChatPropertyId.value = session.propertyId }
                                .testTag("chat_session_item_${session.propertyId}"),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF0A3C25)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        session.hostName.take(1),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        session.hostName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        fontFamily = FontFamily.Serif
                                    )
                                    Text(
                                        "Regarding: ${session.propertyName}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                                Icon(
                                    Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // --- DETAILED CHAT VIEW CONVERSATION ---
            Column(modifier = Modifier.fillMaxSize()) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { msg ->
                        val isGuest = msg.sender == "GUEST"
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = if (isGuest) Alignment.CenterEnd else Alignment.CenterStart
                        ) {
                            Column(
                                horizontalAlignment = if (isGuest) Alignment.End else Alignment.Start
                            ) {
                                Card(
                                    shape = RoundedCornerShape(
                                        topStart = 12.dp,
                                        topEnd = 12.dp,
                                        bottomStart = if (isGuest) 12.dp else 0.dp,
                                        bottomEnd = if (isGuest) 0.dp else 12.dp
                                    ),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isGuest) Color(0xFF0A3C25) else MaterialTheme.colorScheme.surfaceVariant,
                                        contentColor = if (isGuest) Color(0xFFF5F2EA) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                ) {
                                    Text(
                                        text = msg.text,
                                        modifier = Modifier.padding(12.dp),
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (isGuest) "You" else msg.hostName,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (isGuest) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = if (msg.status == "READ") Icons.Default.DoneAll else Icons.Default.Done,
                                            contentDescription = null,
                                            tint = Color(0xFF0A3C25),
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Input Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = messageText,
                            onValueChange = { messageText = it },
                            placeholder = { Text("Ask about check-in, wifi, station direction...") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_message_input"),
                            shape = RoundedCornerShape(20.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF0A3C25)
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (messageText.trim().isNotEmpty()) {
                                    selectedPropertyId?.let { id ->
                                        viewModel.sendGuestChatMessage(id, messageText)
                                        messageText = ""
                                    }
                                }
                            },
                            modifier = Modifier
                                .background(Color(0xFF0A3C25), CircleShape)
                                .size(40.dp)
                                .testTag("send_chat_message_button")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}
