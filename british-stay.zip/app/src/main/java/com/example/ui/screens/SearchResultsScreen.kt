package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.ViewList
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PropertyEntity
import com.example.ui.components.PropertyIllustration
import com.example.ui.components.UKMap
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel

@Composable
fun SearchResultsScreen(
    viewModel: StayViewModel,
    properties: List<PropertyEntity>,
    modifier: Modifier = Modifier
) {
    // Custom Back Handler support
    BackHandler {
        viewModel.navigateBack()
    }

    var showMapMode by remember { mutableStateOf(false) }
    var selectedMapProperty by remember { mutableStateOf<PropertyEntity?>(null) }

    val destQuery by viewModel.searchDestination.collectAsState()
    val guestsQuery by viewModel.searchGuests.collectAsState()

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showMapMode = !showMapMode },
                containerColor = Color(0xFF0A3C25),
                contentColor = Color(0xFFF5F2EA),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.testTag("map_toggle_fab")
            ) {
                Icon(
                    imageVector = if (showMapMode) Icons.Outlined.ViewList else Icons.Outlined.Map,
                    contentDescription = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = if (showMapMode) "View List" else "View Map", fontWeight = FontWeight.Bold)
            }
        },
        floatingActionButtonPosition = FabPosition.Center
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // --- TOP HEADER SEARCH SUMMARY ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0A3C25))
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFFF5F2EA))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = if (destQuery.isEmpty()) "Anywhere in Britain" else destQuery,
                        color = Color(0xFFF5F2EA),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                    Text(
                        text = "14–17 October · $guestsQuery guests · ${properties.size} stays available",
                        color = Color(0xFFF5F2EA).copy(alpha = 0.7f),
                        fontSize = 11.sp
                    )
                }
            }

            if (showMapMode) {
                // --- MAP VIEW ---
                Box(modifier = Modifier.fillMaxSize()) {
                    UKMap(
                        properties = properties,
                        selectedProperty = selectedMapProperty,
                        onPropertySelect = { selectedMapProperty = it },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay card for selected map marker
                    if (selectedMapProperty != null) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 80.dp, start = 16.dp, end = 16.dp)
                        ) {
                            selectedMapProperty?.let { p ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.selectPropertyForBooking(p) },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(12.dp),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        PropertyIllustration(
                                            type = p.type,
                                            seed = p.imageSeed,
                                            modifier = Modifier
                                                .size(80.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        )
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${p.type} · ${p.cityOrTown}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFB5945B)
                                            )
                                            Text(
                                                text = p.name,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                fontFamily = FontFamily.Serif
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "£${p.pricePerNight.toInt()} night",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF0A3C25)
                                                )
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(12.dp))
                                                Text(String.format(" %.2f", p.rating), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // --- LISTINGS VIEW ---
                if (properties.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SearchOff, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color(0xFFB5945B))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("No properties found", fontWeight = FontWeight.Bold)
                            Text("Try adjusting your keyword, destination or filters.", fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        items(properties) { p ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.selectPropertyForBooking(p) }
                                    .testTag("property_card_${p.id}"),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                )
                            ) {
                                Column {
                                    // 1. Vector Illustration Hero Banner
                                    PropertyIllustration(
                                        type = p.type,
                                        seed = p.imageSeed,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(180.dp)
                                    )

                                    // 2. Listing Information
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${p.region} · ${p.county}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                            )
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(2.dp))
                                                Text(String.format("%.2f", p.rating), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                Text(" (${p.reviewsCount})", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Text(
                                            text = p.name,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontFamily = FontFamily.Serif
                                        )

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Text(
                                            text = "Entire ${p.type.lowercase()} · ${p.guests} guests · ${p.bedrooms} bedrooms · ${p.bathrooms} bath",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                        )

                                        // 3. Transport Aware Intelligence (SCENIC RAILWAYS)
                                        if (p.stationName.isNotEmpty()) {
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(Color(0xFF0A3C25).copy(alpha = 0.08f))
                                                    .padding(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.Train, contentDescription = null, tint = Color(0xFF0A3C25), modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "${p.minutesToStationWalk} min walk to ${p.stationName} station",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF0A3C25)
                                                )
                                                if (p.trainMinutesToLondon > 0) {
                                                    Spacer(modifier = Modifier.weight(1f))
                                                    Text(
                                                        text = "↓ ${p.trainMinutesToLondon} min to London",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFFB5945B)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(14.dp))

                                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = "£${p.pricePerNight.toInt()} / night",
                                                    fontSize = 16.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = Color(0xFF0A3C25)
                                                )
                                                Text(
                                                    text = "£${(p.pricePerNight * 3).toInt()} total (3 nights)",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                                )
                                            }

                                            Button(
                                                onClick = { viewModel.selectPropertyForBooking(p) },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A3C25)),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text("View Details", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
