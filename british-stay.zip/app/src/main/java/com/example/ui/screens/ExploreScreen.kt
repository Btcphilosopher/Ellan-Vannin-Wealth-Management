package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PropertyEntity
import com.example.ui.components.PropertyIllustration
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(
    viewModel: StayViewModel,
    properties: List<PropertyEntity>,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    // Local inputs state
    var destInput by remember { mutableStateOf("") }
    var guestsCount by remember { mutableStateOf(2) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- 1. HERO HEADER BANNER ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(Color(0xFF0A3C25)) // British Racing Green
        ) {
            // Draw stylized map background overlay or elegant texture
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "BRITISH STAY",
                    color = Color(0xFFB5945B), // Golden Brass
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 4.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "STAY SOMEWHERE\nBRITISH.",
                    color = Color(0xFFF5F2EA), // Parchment
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = 38.sp,
                    fontFamily = FontFamily.Serif
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Britain, properly stayed.",
                    color = Color(0xFFF5F2EA).copy(alpha = 0.7f),
                    fontSize = 15.sp,
                    fontFamily = FontFamily.SansSerif
                )
            }
        }

        // --- 2. INTEGRATED SEARCH INTERFACE (ANGLO-FUTURIST CONTROLS) ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .offset(y = (-30).dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Where Input
                OutlinedTextField(
                    value = destInput,
                    onValueChange = { destInput = it },
                    label = { Text("Where are you going?") },
                    placeholder = { Text("London, Cornwall, York Station...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_destination_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF0A3C25),
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Dates Picker Indicator
                    OutlinedButton(
                        onClick = { /* Simulated dates */ },
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.onSurface
                        )
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = null, tint = Color(0xFFB5945B))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Dates: 14–17 Oct", fontSize = 12.sp, maxLines = 1)
                    }

                    // Who Selector
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = { if (guestsCount > 1) guestsCount-- },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                        }
                        Text("$guestsCount Guests", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        IconButton(
                            onClick = { if (guestsCount < 10) guestsCount++ },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.searchDestination.value = destInput
                            viewModel.searchGuests.value = guestsCount
                            viewModel.performSearch()
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp)
                            .testTag("submit_search_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF0A3C25), // British Racing Green
                            contentColor = Color(0xFFF5F2EA)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Search stays", fontWeight = FontWeight.Bold)
                    }

                    // Stay Finder AI Button
                    Button(
                        onClick = {
                            viewModel.stayFinderQuery.value = if (destInput.isNotEmpty()) destInput else "Find me a quiet cottage in the Peak District reachable by train."
                            viewModel.performStayFinderAISearch()
                            viewModel.navigateTo(AppScreen.EXPLORE) // Or keep inside the AI chat tab
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("ai_finder_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF001E36), // Deep Navy
                            contentColor = Color(0xFFB5945B) // Warm Gold
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Stay Finder", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // --- 3. DYNAMIC CATEGORY TAXONOMY SLIDER ---
        Text(
            text = "EXPLORE BRITAIN BY CHARACTER",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(start = 16.dp, bottom = 12.dp),
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )

        val categoriesList = listOf(
            Pair("ANY", "All Character"),
            Pair("COUNTRY_COTTAGES", "Cottages"),
            Pair("CITY_FLATS", "City Flats"),
            Pair("COASTAL_HOMES", "Coastal"),
            Pair("GEORGIAN_HOUSES", "Georgian"),
            Pair("MODERNIST_HOMES", "Modernist"),
            Pair("UNIQUE_BRITISH_PLACES", "Unique Stays")
        )

        val selectedCat by viewModel.searchCategory.collectAsState()

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categoriesList.forEach { (key, label) ->
                val active = selectedCat == key
                FilterChip(
                    selected = active,
                    onClick = { viewModel.selectCategory(key) },
                    label = { Text(label, fontWeight = FontWeight.Medium) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF0A3C25),
                        selectedLabelColor = Color(0xFFF5F2EA)
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
            }
        }

        // --- 4. SIGNATURE RAILWAY ESCAPES BANNER ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 24.dp)
                .clickable {
                    viewModel.searchDestination.value = "Station"
                    viewModel.performSearch()
                },
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF0D1C12), // Very deep Racing green
                contentColor = Color(0xFFF5F2EA)
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Train, contentDescription = null, tint = Color(0xFFB5945B))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "RAILWAY ESCAPES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB5945B),
                            letterSpacing = 1.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Leave the Car Behind",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Serif
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Stays situated under 15 mins walk of scenic railway hubs with rapid journey times to core cities.",
                        fontSize = 12.sp,
                        color = Color(0xFFF5F2EA).copy(alpha = 0.7f)
                    )
                }
                Icon(
                    Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = Color(0xFFB5945B),
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // --- 5. FEATURED BRITISH PLACES LIST ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "FEATURED STAYS",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
            )
            Text(
                text = "See All (${properties.size})",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0A3C25),
                modifier = Modifier.clickable {
                    viewModel.searchDestination.value = ""
                    viewModel.performSearch()
                }
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, bottom = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Take first 5 flagship/popular properties to show on homepage
            properties.take(6).forEach { p ->
                Card(
                    modifier = Modifier
                        .width(220.dp)
                        .clickable { viewModel.selectPropertyForBooking(p) },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    )
                ) {
                    Column {
                        // Drawing dynamic vector graphics inside card
                        PropertyIllustration(
                            type = p.type,
                            seed = p.imageSeed,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                        )

                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "${p.cityOrTown}, ${p.county}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = p.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                fontFamily = FontFamily.Serif
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "£${p.pricePerNight.toInt()} / night",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0A3C25)
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = null,
                                        tint = Color(0xFFB5945B),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = String.format("%.2f", p.rating),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- 6. THE BRITISH STAY JOURNAL (TRAVEL EDITOR) ---
        Text(
            text = "THE BRITISH STAY JOURNAL",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(start = 16.dp, bottom = 12.dp),
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
        )

        val journalsList by viewModel.journals.collectAsState()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            journalsList.forEach { article ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        .clickable {
                            viewModel.selectedJournal.value = article
                            viewModel.navigateTo(AppScreen.JOURNAL_VIEW)
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF0A3C25).copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Book, contentDescription = null, tint = Color(0xFFB5945B))
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = article.category,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB5945B),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = article.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = article.subtitle,
                            fontSize = 11.sp,
                            maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                    Icon(
                        Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                    )
                }
            }
        }
    }
}
