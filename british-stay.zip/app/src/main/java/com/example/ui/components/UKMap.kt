package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.data.model.PropertyEntity
import kotlin.math.max
import kotlin.math.min

@Composable
fun UKMap(
    properties: List<PropertyEntity>,
    selectedProperty: PropertyEntity?,
    onPropertySelect: (PropertyEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    
    // Theme Colors
    val mapBackground = if (isDark) Color(0xFF161A1F) else Color(0xFFFAF8F5)
    val landColor = if (isDark) Color(0xFF1E242C) else Color(0xFFEFECE5)
    val coastOutlineColor = if (isDark) Color(0xFF2E3844) else Color(0xFFDCD8CF)
    val railColor = if (isDark) Color(0xFFB5945B).copy(alpha = 0.4f) else Color(0xFF8A6D3B).copy(alpha = 0.3f)
    val cityMarkerColor = if (isDark) Color(0xFFFFFFFF).copy(alpha = 0.3f) else Color(0xFF000000).copy(alpha = 0.2f)
    val normalPinColor = Color(0xFF0A3C25) // British Racing Green
    val selectedPinColor = Color(0xFFB5945B) // Brass Gold

    // Animation for pulse on selected property pin
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 8f,
        targetValue = 20f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )

    // Zoom & Pan state
    var scale by remember { mutableStateOf(1.0f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    Box(
        modifier = modifier
            .background(mapBackground)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                }
            }
            .pointerInput(properties, selectedProperty) {
                detectTapGestures { tapOffset ->
                    // Reverse calculate the tapped point in 0..100 coordinate space
                    val w = size.width
                    val h = size.height

                    var closestProp: PropertyEntity? = null
                    var minDistance = 50f // Tap tolerance in pixels

                    properties.forEach { p ->
                        // Map coordinates
                        val px = mapLongitudeToX(p.longitude, w.toFloat(), offsetX, scale)
                        val py = mapLatitudeToY(p.latitude, h.toFloat(), offsetY, scale)

                        val dx = tapOffset.x - px
                        val dy = tapOffset.y - py
                        val dist = kotlin.math.sqrt(dx * dx + dy * dy)
                        if (dist < minDistance) {
                            minDistance = dist
                            closestProp = p
                        }
                    }

                    closestProp?.let { onPropertySelect(it) }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // 1. Draw Great Britain Mainland stylized silhouette path
            val landPath = Path().apply {
                // Approximate coordinate points mapping (scaled to width, height)
                moveTo(scaleX(50f, width, offsetX, scale), scaleY(5f, height, offsetY, scale)) // John o' Groats
                lineTo(scaleX(35f, width, offsetX, scale), scaleY(10f, height, offsetY, scale)) // Highlands West
                lineTo(scaleX(25f, width, offsetX, scale), scaleY(22f, height, offsetY, scale)) // Skye/Mull
                lineTo(scaleX(32f, width, offsetX, scale), scaleY(36f, height, offsetY, scale)) // Galloway
                lineTo(scaleX(28f, width, offsetX, scale), scaleY(58f, height, offsetY, scale)) // Anglesey
                lineTo(scaleX(23f, width, offsetX, scale), scaleY(68f, height, offsetY, scale)) // Pembrokeshire
                lineTo(scaleX(10f, width, offsetX, scale), scaleY(88f, height, offsetY, scale)) // Lands End Cornwall
                lineTo(scaleX(18f, width, offsetX, scale), scaleY(92f, height, offsetY, scale)) // Lizard Point
                lineTo(scaleX(48f, width, offsetX, scale), scaleY(90f, height, offsetY, scale)) // Isle of Wight
                lineTo(scaleX(80f, width, offsetX, scale), scaleY(85f, height, offsetY, scale)) // Dover/Kent
                lineTo(scaleX(85f, width, offsetX, scale), scaleY(68f, height, offsetY, scale)) // East Anglia
                lineTo(scaleX(72f, width, offsetX, scale), scaleY(54f, height, offsetY, scale)) // Humber
                lineTo(scaleX(62f, width, offsetX, scale), scaleY(40f, height, offsetY, scale)) // Newcastle
                lineTo(scaleX(60f, width, offsetX, scale), scaleY(22f, height, offsetY, scale)) // Aberdeen
                lineTo(scaleX(54f, width, offsetX, scale), scaleY(10f, height, offsetY, scale)) // Inverness
                close()
            }

            // 2. Draw Northern Ireland stylized silhouette path
            val niPath = Path().apply {
                moveTo(scaleX(16f, width, offsetX, scale), scaleY(38f, height, offsetY, scale))
                lineTo(scaleX(11f, width, offsetX, scale), scaleY(42f, height, offsetY, scale))
                lineTo(scaleX(14f, width, offsetX, scale), scaleY(48f, height, offsetY, scale))
                lineTo(scaleX(22f, width, offsetX, scale), scaleY(46f, height, offsetY, scale))
                lineTo(scaleX(20f, width, offsetX, scale), scaleY(39f, height, offsetY, scale))
                close()
            }

            // Draw land shapes
            drawPath(landPath, landColor)
            drawPath(niPath, landColor)

            drawPath(landPath, coastOutlineColor, style = Stroke(width = 2.dp.toPx()))
            drawPath(niPath, coastOutlineColor, style = Stroke(width = 2.dp.toPx()))

            // 3. Draw Stylized Main Rail Lines
            // London St Pancras (70, 78) -> Birmingham (52, 70) -> Manchester (54, 58) -> Carlisle (50, 42) -> Glasgow (42, 28)
            val wcml = Path().apply {
                moveTo(scaleX(70f, width, offsetX, scale), scaleY(78f, height, offsetY, scale))
                quadraticTo(
                    scaleX(52f, width, offsetX, scale), scaleY(70f, height, offsetY, scale),
                    scaleX(54f, width, offsetX, scale), scaleY(58f, height, offsetY, scale)
                )
                lineTo(scaleX(50f, width, offsetX, scale), scaleY(42f, height, offsetY, scale))
                lineTo(scaleX(42f, width, offsetX, scale), scaleY(28f, height, offsetY, scale))
            }

            // East Coast Main Line: London (70, 78) -> York (64, 52) -> Newcastle (62, 40) -> Edinburgh (48, 27)
            val ecml = Path().apply {
                moveTo(scaleX(70f, width, offsetX, scale), scaleY(78f, height, offsetY, scale))
                lineTo(scaleX(64f, width, offsetX, scale), scaleY(52f, height, offsetY, scale))
                lineTo(scaleX(62f, width, offsetX, scale), scaleY(40f, height, offsetY, scale))
                lineTo(scaleX(48f, width, offsetX, scale), scaleY(27f, height, offsetY, scale))
            }

            // Great Western Line: London (70, 78) -> Bath (45, 81) -> Cardiff (36, 81)
            val gwml = Path().apply {
                moveTo(scaleX(70f, width, offsetX, scale), scaleY(78f, height, offsetY, scale))
                lineTo(scaleX(45f, width, offsetX, scale), scaleY(81f, height, offsetY, scale))
                lineTo(scaleX(36f, width, offsetX, scale), scaleY(81f, height, offsetY, scale))
            }

            drawPath(wcml, railColor, style = Stroke(width = 1.5.dp.toPx()))
            drawPath(ecml, railColor, style = Stroke(width = 1.5.dp.toPx()))
            drawPath(gwml, railColor, style = Stroke(width = 1.5.dp.toPx()))

            // 4. Draw Core City Markers
            val cities = listOf(
                Pair("London", Offset(scaleX(70f, width, offsetX, scale), scaleY(78f, height, offsetY, scale))),
                Pair("Edinburgh", Offset(scaleX(48f, width, offsetX, scale), scaleY(27f, height, offsetY, scale))),
                Pair("Manchester", Offset(scaleX(54f, width, offsetX, scale), scaleY(58f, height, offsetY, scale))),
                Pair("Bath", Offset(scaleX(45f, width, offsetX, scale), scaleY(81f, height, offsetY, scale))),
                Pair("Belfast", Offset(scaleX(17f, width, offsetX, scale), scaleY(42f, height, offsetY, scale)))
            )

            cities.forEach { city ->
                drawCircle(cityMarkerColor, radius = 6.dp.toPx(), center = city.second)
                drawCircle(Color.White, radius = 2.dp.toPx(), center = city.second)
            }

            // 5. Draw Property Pins
            properties.forEach { p ->
                val px = mapLongitudeToX(p.longitude, width, offsetX, scale)
                val py = mapLatitudeToY(p.latitude, height, offsetY, scale)
                val isSelected = selectedProperty?.id == p.id

                val finalPinColor = if (isSelected) selectedPinColor else normalPinColor

                if (isSelected) {
                    // Draw outer pulse glow
                    drawCircle(
                        color = selectedPinColor.copy(alpha = 0.3f),
                        radius = pulseRadius.dp.toPx(),
                        center = Offset(px, py)
                    )
                }

                // Draw solid pointer head pin
                drawCircle(
                    color = finalPinColor,
                    radius = if (isSelected) 8.dp.toPx() else 6.dp.toPx(),
                    center = Offset(px, py)
                )
                // Inward white core dot
                drawCircle(
                    color = Color.White,
                    radius = if (isSelected) 3.dp.toPx() else 2.dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }
    }
}

// Coordinate Scaling Helpers to transform 0..100 grid to screen dimensions with pan and zoom.
private fun scaleX(gridX: Float, width: Float, offsetX: Float, scale: Float): Float {
    return (gridX / 100f) * width * scale + offsetX
}

private fun scaleY(gridY: Float, height: Float, offsetY: Float, scale: Float): Float {
    return (gridY / 100f) * height * scale + offsetY
}

// Convert real world latitude and longitude to approximated map grid.
// Latitude UK boundaries: ~49.9 N to ~59 N
// Longitude UK boundaries: ~-8.5 W to ~1.8 E
private fun mapLatitudeToY(lat: Float, height: Float, offsetY: Float, scale: Float): Float {
    val norm = (59.0f - lat) / (59.0f - 49.9f) // 0 (North) to 1 (South)
    // Approximate placing on our 0..100 grid (North is at ~5% height, South is at ~92% height)
    val gridY = 5f + norm * (92f - 5f)
    return scaleY(gridY, height, offsetY, scale)
}

private fun mapLongitudeToX(lng: Float, width: Float, offsetX: Float, scale: Float): Float {
    val norm = (lng - (-8.5f)) / (1.8f - (-8.5f)) // 0 (West) to 1 (East)
    // Place on our grid (West is at ~10% width, East is at ~88% width)
    val gridX = 10f + norm * (88f - 10f)
    return scaleX(gridX, width, offsetX, scale)
}
