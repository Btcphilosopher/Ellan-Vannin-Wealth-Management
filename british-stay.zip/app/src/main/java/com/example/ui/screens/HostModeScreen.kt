package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PropertyEntity
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HostModeScreen(
    viewModel: StayViewModel,
    properties: List<PropertyEntity>,
    modifier: Modifier = Modifier
) {
    // Back pressed action
    BackHandler {
        viewModel.navigateTo(AppScreen.EXPLORE)
        true
    }

    val allProps = properties.filter { it.id <= 6 } // Let's list flagship ones as owned properties for demo
    val hostSelectedProp by viewModel.hostSelectedProperty.collectAsState()

    var activeTab by remember { mutableStateOf("OVERVIEW") }

    // Set initial owned host property if none is selected
    LaunchedEffect(allProps) {
        if (hostSelectedProp == null && allProps.isNotEmpty()) {
            viewModel.selectHostProperty(allProps.first())
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- 1. HEADER (HOST IDENTIFICATION) ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F1E36)) // Navy
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.navigateTo(AppScreen.EXPLORE) }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFFF5F2EA))
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "HOST DASHBOARD",
                        color = Color(0xFFB5945B),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "The Stone Barn Portfolio",
                        color = Color(0xFFF5F2EA),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                }
            }

            // Stays Selection dropdown indicator
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White.copy(alpha = 0.12f))
                    .clickable {
                        // Switch to next property for demo rotation
                        val currentIdx = allProps.indexOfFirst { it.id == hostSelectedProp?.id }
                        if (currentIdx != -1 && allProps.isNotEmpty()) {
                            val nextIdx = (currentIdx + 1) % allProps.size
                            viewModel.selectHostProperty(allProps[nextIdx])
                        }
                    }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Home, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = hostSelectedProp?.name ?: "No Stay Selected",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.White)
            }
        }

        // --- 2. HOST PROFILE SUB NAVIGATION TABS ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F1E36).copy(alpha = 0.95f))
                .horizontalScroll(rememberScrollState())
                .padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tabs = listOf(
                "OVERVIEW" to "Overview",
                "CALENDAR" to "Rates & Blocks",
                "OPERATIONS" to "Operations",
                "AI_ASSISTANT" to "Host AI Assistant"
            )

            tabs.forEach { (key, label) ->
                val active = activeTab == key
                Button(
                    onClick = { activeTab = key },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (active) Color(0xFFB5945B) else Color.White.copy(alpha = 0.08f),
                        contentColor = if (active) Color(0xFF0F1E36) else Color(0xFFF5F2EA)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp).testTag("host_tab_$key")
                ) {
                    Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // --- 3. ACTIVE TAB VIEWER CONTAINER ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (activeTab) {
                "OVERVIEW" -> {
                    // --- OVERVIEW TAB ---
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text(
                            text = "GOOD MORNING, SARAH.",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )

                        // 3 Column Stat Box Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            StatBox("OCCUPANCY", "78%", "High Demand", Modifier.weight(1f))
                            StatBox("THIS MONTH", "£4,820", "+14% vs Aug", Modifier.weight(1.2f))
                            StatBox("PENDING", "£1,240", "2 upcoming", Modifier.weight(1f))
                        }

                        // Detailed Gross Payout Card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("GROSS REVENUE TRACKER", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB5945B))
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Gross Earnings", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text("£6,420.00", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Service Fees", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                        Text("- £512.00", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Red.copy(alpha = 0.7f))
                                    }
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Divider()
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("NET PAYOUT SENT", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text("£5,908.00", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0A3C25))
                                }
                            }
                        }

                        // Algorithmic pricing card suggestions
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF8F5)),
                            border = BorderStroke(1.dp, Color(0xFFEFECE5))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.TrendingUp, contentDescription = null, tint = Color(0xFF0A3C25))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("DYNAMIC PRICING INTELLIGENCE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0A3C25))
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    "Your current base rate is £${hostSelectedProp?.pricePerNight?.toInt() ?: 180}.\n" +
                                            "Our system suggests adjusting your rate to £${(hostSelectedProp?.pricePerNight?.plus(24))?.toInt() ?: 204} for the upcoming Peak Autumn foliage season due to critical searches for '${hostSelectedProp?.cityOrTown}'.",
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }

                "CALENDAR" -> {
                    // --- CALENDAR & BASE RATE ADJUSTER TAB ---
                    hostSelectedProp?.let { prop ->
                        val customPrice by viewModel.hostCustomPriceInput.collectAsState()
                        val isBlocked by viewModel.hostIsBlockedInput.collectAsState()

                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text(
                                text = "CALENDAR RATE OVERRIDES",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.5.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )

                            // Quick Simulated calendar layout (3 Rows of dates)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("October 2026", fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
                                    FlowRow(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        for (day in 1..28) {
                                            val isSelected = viewModel.hostSelectedDate.value == "2026-10-$day"
                                            val isWeekend = day % 7 == 5 || day % 7 == 6

                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(
                                                        if (isSelected) Color(0xFFB5945B)
                                                        else if (prop.isBlocked && day % 4 == 0) Color.Red.copy(alpha = 0.1f)
                                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                                    )
                                                    .clickable {
                                                        viewModel.hostSelectedDate.value = "2026-10-$day"
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Text(
                                                        "$day",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Text(
                                                        text = if (isWeekend) "£${(prop.pricePerNight * 1.15).toInt()}" else "£${prop.pricePerNight.toInt()}",
                                                        fontSize = 8.sp,
                                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Selected day config edit controls
                            Text(
                                "SETTINGS FOR: ${viewModel.hostSelectedDate.value}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFB5945B)
                            )

                            OutlinedTextField(
                                value = customPrice,
                                onValueChange = { viewModel.hostCustomPriceInput.value = it },
                                label = { Text("Custom Nightly Rate Override (GBP)") },
                                leadingIcon = { Icon(Icons.Default.Payments, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("host_price_override_input"),
                                singleLine = true
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Block Checkouts / Bookings", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Locks dates for cleaning or personal use.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                }
                                Switch(
                                    checked = isBlocked,
                                    onCheckedChange = { viewModel.hostIsBlockedInput.value = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF0A3C25)),
                                    modifier = Modifier.testTag("host_block_dates_switch")
                                )
                            }

                            Button(
                                onClick = { viewModel.saveHostCalendarSettings() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("save_host_calendar_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F1E36))
                            ) {
                                Text("Save Rate Overrides", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                "OPERATIONS" -> {
                    // --- OPERATIONS & CO-HOST TAB ---
                    val coHosts by viewModel.coHostsList.collectAsState()
                    val coPermissions by viewModel.coHostPermissions.collectAsState()

                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text(
                            text = "PROPERTY TURNOVER CHECKS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )

                        // Clean checklist boxes
                        listOf(
                            "Next Checkout scheduled at 10:00" to true,
                            "Turnover cleaning set for 10:30 (Victoria)" to true,
                            "Replenish Yorkshire tea bags, towels & firewood" to false,
                            "Safe lockbox code refresh check" to false
                        ).forEach { (task, checked) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (checked) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (checked) Color(0xFF0A3C25) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(task, fontSize = 13.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "CO-HOSTS & CLEANERS PERMISSIONS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB5945B)
                        )

                        coHosts.forEach { name ->
                            val hasPermission = coPermissions[name] ?: false
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(
                                        text = if (hasPermission) "Full write access to rates & calendars" else "ReadOnly operations and tasks",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                    )
                                }
                                if (name.contains("Host")) {
                                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF0A3C25))
                                } else {
                                    Switch(
                                        checked = hasPermission,
                                        onCheckedChange = { viewModel.toggleCoHostPermission(name) },
                                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFB5945B))
                                    )
                                }
                            }
                        }
                    }
                }

                "AI_ASSISTANT" -> {
                    // --- AI HOST ASSISTANT TAB (GEMINI POWERED) ---
                    val response by viewModel.hostAssistantResponse.collectAsState()
                    val query by viewModel.hostAssistantQuery.collectAsState()
                    val isLoading by viewModel.hostAssistantLoading.collectAsState()

                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text(
                            text = "BRITISH STAY HOST AI",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                        )

                        OutlinedTextField(
                            value = query,
                            onValueChange = { viewModel.hostAssistantQuery.value = it },
                            label = { Text("Ask Host AI") },
                            placeholder = { Text("e.g. Write a description upgrade or explain pricing.") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("host_ai_query_input"),
                            singleLine = true,
                            trailingIcon = {
                                IconButton(
                                    onClick = { viewModel.submitHostAssistantQuery() },
                                    modifier = Modifier.testTag("host_ai_submit_button")
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = null, tint = Color(0xFF0F1E36))
                                }
                            }
                        )

                        if (isLoading) {
                            Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = Color(0xFFB5945B))
                            }
                        }

                        if (response.isNotEmpty()) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFBF9F4)),
                                border = BorderStroke(1.dp, Color(0xFFEFECE5))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "AI RESPONSE",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFB5945B)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = response,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        } else if (!isLoading) {
                            // Predefined rapid queries cards
                            Text("SUGGESTED ACTIONS:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                            listOf(
                                "Write description upgrade for marketing",
                                "Suggest seasonal rates adjustments",
                                "Identify missing amenities vs local matches"
                            ).forEach { prompt ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.hostAssistantQuery.value = prompt
                                            viewModel.submitHostAssistantQuery()
                                        },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                ) {
                                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(prompt, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatBox(label: String, valStr: String, trend: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(4.dp))
            Text(valStr, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Serif)
            Spacer(modifier = Modifier.height(2.dp))
            Text(trend, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0A3C25))
        }
    }
}
