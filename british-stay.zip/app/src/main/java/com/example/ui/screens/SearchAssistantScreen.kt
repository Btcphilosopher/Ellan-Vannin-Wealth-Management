package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel

@Composable
fun SearchAssistantScreen(
    viewModel: StayViewModel,
    modifier: Modifier = Modifier
) {
    // Back action
    BackHandler {
        viewModel.navigateTo(AppScreen.EXPLORE)
        true
    }

    val query by viewModel.stayFinderQuery.collectAsState()
    val response by viewModel.stayFinderResponse.collectAsState()
    val isLoading by viewModel.stayFinderLoading.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF001E36)) // Deep Navy
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateTo(AppScreen.EXPLORE) }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color(0xFFF5F2EA))
            }
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text(
                    text = "BRITISH STAY AI",
                    color = Color(0xFFB5945B),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Stay Finder Assistant",
                    color = Color(0xFFF5F2EA),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Explaining card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF8F5)),
                border = BorderStroke(1.dp, Color(0xFFEFECE5))
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFB5945B))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Search by natural language. Let the AI map coordinates, find stations, select property characters, or find countryside trails for you.",
                        fontSize = 12.sp,
                        lineHeight = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )
                }
            }

            // Assistant chat history area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (response.isNotEmpty() || isLoading) {
                    // Prompt bubble
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF001E36), contentColor = Color(0xFFF5F2EA)),
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Text(text = query, modifier = Modifier.padding(12.dp), fontSize = 13.sp)
                        }
                    }

                    // Response bubble
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            modifier = Modifier.widthIn(max = 300.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                if (isLoading) {
                                    CircularProgressIndicator(color = Color(0xFFB5945B), modifier = Modifier.size(24.dp))
                                } else {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFB5945B), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Stay Finder AI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB5945B))
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = response,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = { viewModel.navigateTo(AppScreen.SEARCH_RESULTS) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A3C25)),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.height(32.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("View Matched Stays", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Predefined queries recommendations
                    Text("SUGGESTED QUERIES:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                    listOf(
                        "Peak District cottage near a train station with a wood fireplace",
                        "Georgian townhouse in Bath with a private garden",
                        "Cozy seaside cottage in Cornwall that is dog friendly",
                        "Modern cabins in Scotland reachable from Fort William"
                    ).forEach { prompt ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.stayFinderQuery.value = prompt
                                    viewModel.performStayFinderAISearch()
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF0A3C25), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(prompt, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Input Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { viewModel.stayFinderQuery.value = it },
                        placeholder = { Text("Search Cornwall, dog friendly, train times...") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_assistant_query_input"),
                        shape = RoundedCornerShape(20.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF001E36)
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { viewModel.performStayFinderAISearch() },
                        modifier = Modifier
                            .background(Color(0xFF001E36), CircleShape)
                            .size(40.dp)
                            .testTag("send_ai_query_button")
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
