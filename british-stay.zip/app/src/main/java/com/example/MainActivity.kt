package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StayViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: StayViewModel = viewModel()
            val currentScreen by viewModel.currentScreen.collectAsState()
            val properties by viewModel.allProperties.collectAsState()
            val bookings by viewModel.bookings.collectAsState()
            val wishlists by viewModel.wishlists.collectAsState()
            val chatSessions by viewModel.chatSessions.collectAsState()
            val messages by viewModel.chatMessages.collectAsState()

            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        // Bottom Navigation bar is active for the main primary tabs
                        if (currentScreen in listOf(AppScreen.EXPLORE, AppScreen.WISHLISTS, AppScreen.TRIPS, AppScreen.INBOX, AppScreen.HOST_MODE)) {
                            NavigationBar(
                                containerColor = Color(0xFF0F1E36), // Premium Navy Blue
                                contentColor = Color(0xFFF5F2EA)
                            ) {
                                NavigationBarItem(
                                    selected = currentScreen == AppScreen.EXPLORE,
                                    onClick = { 
                                        viewModel.stayFinderResponse.value = "" // clear search assistant if clicking explore
                                        viewModel.navigateTo(AppScreen.EXPLORE) 
                                    },
                                    icon = { Icon(if (currentScreen == AppScreen.EXPLORE) Icons.Filled.Explore else Icons.Outlined.Explore, contentDescription = "Explore") },
                                    label = { Text("Explore", fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFFB5945B),
                                        selectedTextColor = Color(0xFFB5945B),
                                        indicatorColor = Color.White.copy(alpha = 0.12f),
                                        unselectedIconColor = Color(0xFFF5F2EA).copy(alpha = 0.6f),
                                        unselectedTextColor = Color(0xFFF5F2EA).copy(alpha = 0.6f)
                                    )
                                )

                                NavigationBarItem(
                                    selected = currentScreen == AppScreen.WISHLISTS,
                                    onClick = { 
                                        viewModel.selectedWishlist.value = null // reset selection when clicking primary tab
                                        viewModel.navigateTo(AppScreen.WISHLISTS) 
                                    },
                                    icon = { Icon(if (currentScreen == AppScreen.WISHLISTS) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, contentDescription = "Wishlists") },
                                    label = { Text("Wishlists", fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFFB5945B),
                                        selectedTextColor = Color(0xFFB5945B),
                                        indicatorColor = Color.White.copy(alpha = 0.12f),
                                        unselectedIconColor = Color(0xFFF5F2EA).copy(alpha = 0.6f),
                                        unselectedTextColor = Color(0xFFF5F2EA).copy(alpha = 0.6f)
                                    )
                                )

                                NavigationBarItem(
                                    selected = currentScreen == AppScreen.TRIPS,
                                    onClick = { viewModel.navigateTo(AppScreen.TRIPS) },
                                    icon = { Icon(if (currentScreen == AppScreen.TRIPS) Icons.Filled.CardTravel else Icons.Outlined.CardTravel, contentDescription = "Trips") },
                                    label = { Text("Trips", fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFFB5945B),
                                        selectedTextColor = Color(0xFFB5945B),
                                        indicatorColor = Color.White.copy(alpha = 0.12f),
                                        unselectedIconColor = Color(0xFFF5F2EA).copy(alpha = 0.6f),
                                        unselectedTextColor = Color(0xFFF5F2EA).copy(alpha = 0.6f)
                                    )
                                )

                                NavigationBarItem(
                                    selected = currentScreen == AppScreen.INBOX,
                                    onClick = { 
                                        viewModel.selectedChatPropertyId.value = null
                                        viewModel.navigateTo(AppScreen.INBOX) 
                                    },
                                    icon = { Icon(if (currentScreen == AppScreen.INBOX) Icons.Filled.Chat else Icons.Outlined.ChatBubbleOutline, contentDescription = "Inbox") },
                                    label = { Text("Inbox", fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFFB5945B),
                                        selectedTextColor = Color(0xFFB5945B),
                                        indicatorColor = Color.White.copy(alpha = 0.12f),
                                        unselectedIconColor = Color(0xFFF5F2EA).copy(alpha = 0.6f),
                                        unselectedTextColor = Color(0xFFF5F2EA).copy(alpha = 0.6f)
                                    )
                                )

                                NavigationBarItem(
                                    selected = currentScreen == AppScreen.HOST_MODE,
                                    onClick = { viewModel.navigateTo(AppScreen.HOST_MODE) },
                                    icon = { Icon(if (currentScreen == AppScreen.HOST_MODE) Icons.Filled.Dashboard else Icons.Outlined.Dashboard, contentDescription = "Host") },
                                    label = { Text("Host", fontSize = 10.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color(0xFFB5945B),
                                        selectedTextColor = Color(0xFFB5945B),
                                        indicatorColor = Color.White.copy(alpha = 0.12f),
                                        unselectedIconColor = Color(0xFFF5F2EA).copy(alpha = 0.6f),
                                        unselectedTextColor = Color(0xFFF5F2EA).copy(alpha = 0.6f)
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            AppScreen.EXPLORE -> {
                                val stayFinderResponse by viewModel.stayFinderResponse.collectAsState()
                                val isStayFinderLoading by viewModel.stayFinderLoading.collectAsState()
                                
                                if (stayFinderResponse.isNotEmpty() || isStayFinderLoading) {
                                    SearchAssistantScreen(viewModel = viewModel)
                                } else {
                                    ExploreScreen(viewModel = viewModel, properties = properties)
                                }
                            }
                            AppScreen.SEARCH_RESULTS -> {
                                val filtered by viewModel.filteredProperties.collectAsState()
                                SearchResultsScreen(viewModel = viewModel, properties = filtered)
                            }
                            AppScreen.PROPERTY_DETAIL -> {
                                val prop by viewModel.selectedProperty.collectAsState()
                                prop?.let {
                                    PropertyDetailScreen(viewModel = viewModel, property = it)
                                }
                            }
                            AppScreen.BOOKING_FLOW -> {
                                val prop by viewModel.selectedProperty.collectAsState()
                                prop?.let {
                                    BookingFlowScreen(viewModel = viewModel, property = it)
                                }
                            }
                            AppScreen.TRIPS -> TripsScreen(viewModel = viewModel, bookings = bookings)
                            AppScreen.WISHLISTS -> WishlistScreen(viewModel = viewModel, wishlists = wishlists)
                            AppScreen.INBOX -> InboxScreen(viewModel = viewModel, chatSessions = chatSessions, messages = messages)
                            AppScreen.HOST_MODE -> HostModeScreen(viewModel = viewModel, properties = properties)
                            AppScreen.JOURNAL_VIEW -> {
                                val journal by viewModel.selectedJournal.collectAsState()
                                journal?.let {
                                    JournalScreen(viewModel = viewModel, article = it)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
