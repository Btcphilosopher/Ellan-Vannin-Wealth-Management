import { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Search, 
  Building2, 
  MapPin, 
  TrendingUp, 
  Calculator, 
  Globe, 
  ChevronRight, 
  Coins, 
  Percent, 
  Calendar, 
  UserCheck, 
  MessageSquare, 
  Filter, 
  ArrowUpDown, 
  Maximize2, 
  FileText, 
  Activity, 
  ArrowUpRight, 
  Sparkles,
  PhoneCall,
  X,
  Compass,
  ArrowRight
} from 'lucide-react';

// Property Interface
interface Property {
  id: string;
  titleEn: string;
  titleZh: string;
  city: string;
  cityZh: string;
  image: string;
  price: number; // in RMB Yuan
  area: number; // in sqm
  typeEn: string;
  typeZh: string;
  featuresEn: string[];
  featuresZh: string[];
  appreciation: string;
  roomsEn: string;
  roomsZh: string;
  districtEn: string;
  districtZh: string;
  yearBuilt: number;
}

// Pre-defined Property Data
const PROPERTIES: Property[] = [
  {
    id: 'sh-elite',
    titleEn: 'Bund Landmark Manor',
    titleZh: '黄浦江畔·江景华府',
    city: 'Shanghai',
    cityZh: '上海',
    image: '/src/assets/images/shanghai_market_hero_1791203976019.jpg',
    price: 65000000,
    area: 320,
    typeEn: 'Luxury High-rise',
    typeZh: '奢华高层',
    featuresEn: ['Waterfront View', 'Huangpu Core', 'Private Elevator'],
    featuresZh: ['黄浦江景', '外滩核心圈', '独立电梯'],
    appreciation: '+5.1%',
    roomsEn: '4 Beds / 4 Baths',
    roomsZh: '4室2厅4卫',
    districtEn: 'Huangpu District',
    districtZh: '黄浦区',
    yearBuilt: 2020
  },
  {
    id: 'sz-sky',
    titleEn: 'Bayview Horizon Residence',
    titleZh: '深圳湾一号·星河之境',
    city: 'Shenzhen',
    cityZh: '深圳',
    image: '/src/assets/images/shenzhen_luxury_tower_1791203989675.jpg',
    price: 56000000,
    area: 280,
    typeEn: 'Luxury High-rise',
    typeZh: '奢华高层',
    featuresEn: ['Waterfront View', 'Metro Adjacent', 'Helipad Access'],
    featuresZh: ['一线海景', '地铁上盖', '停机坪服务'],
    appreciation: '+6.2%',
    roomsEn: '3 Beds / 3 Baths',
    roomsZh: '3室2厅3卫',
    districtEn: 'Nanshan District',
    districtZh: '南山区',
    yearBuilt: 2023
  },
  {
    id: 'hz-courtyard',
    titleEn: 'Jiangnan West Lake Courtyard',
    titleZh: '西湖云栖·江南雅居',
    city: 'Hangzhou',
    cityZh: '杭州',
    image: '/src/assets/images/hangzhou_courtyard_villa_1791204002976.jpg',
    price: 72000000,
    area: 420,
    typeEn: 'Courtyard Villa',
    typeZh: '中式院落',
    featuresEn: ['Waterfront View', 'High Greenery', 'Heritage Style'],
    featuresZh: ['临水而居', '超高绿化率', '非遗中式美学'],
    appreciation: '+3.1%',
    roomsEn: '5 Beds / 5 Baths',
    roomsZh: '5室3厅5卫',
    districtEn: 'Xihu District',
    districtZh: '西湖区',
    yearBuilt: 2022
  },
  {
    id: 'bj-penthouse',
    titleEn: 'The Cloud Manor - Guomao Penthouse',
    titleZh: '国贸天际云端大宅',
    city: 'Beijing',
    cityZh: '北京',
    image: '/src/assets/images/beijing_luxury_penthouse_1791204026232.jpg',
    price: 48500000,
    area: 310,
    typeEn: 'Modern Penthouse',
    typeZh: '现代复式',
    featuresEn: ['School District', 'Panoramic Cityscape', 'Smart Home'],
    featuresZh: ['重点学区', '全景天际线', '智控系统'],
    appreciation: '+4.8%',
    roomsEn: '4 Beds / 3 Baths',
    roomsZh: '4室2厅3卫',
    districtEn: 'Chaoyang District',
    districtZh: '朝阳区',
    yearBuilt: 2021
  },
  {
    id: 'cd-eco',
    titleEn: 'The Forest Gardens - High-Tech Valley',
    titleZh: '高新区·森林绿谷叠墅',
    city: 'Chengdu',
    cityZh: '成都',
    image: '/src/assets/images/chengdu_eco_residence_1791204040549.jpg',
    price: 18500000,
    area: 240,
    typeEn: 'Eco-Apartment',
    typeZh: '生态大平层',
    featuresEn: ['High Greenery', 'Metro Adjacent', 'Park Facing'],
    featuresZh: ['垂直森林', '地铁旁', '湿地公园旁'],
    appreciation: '+5.4%',
    roomsEn: '4 Beds / 2 Baths',
    roomsZh: '4室2厅2卫',
    districtEn: 'Gaoxin District',
    districtZh: '高新区',
    yearBuilt: 2024
  },
  {
    id: 'bj-historic',
    titleEn: 'Imperial Lane Historic Courtyard',
    titleZh: '南锣鼓巷·胡同旧事四合院',
    city: 'Beijing',
    cityZh: '北京',
    image: '/src/assets/images/hangzhou_courtyard_villa_1791204002976.jpg', // Reuse villa styling
    price: 120000000,
    area: 380,
    typeEn: 'Courtyard Villa',
    typeZh: '中式院落',
    featuresEn: ['Historic Heritage', 'School District', 'Private Sanctum'],
    featuresZh: ['古建传承', '重点学区房', '独门独院'],
    appreciation: '+1.8%',
    roomsEn: '6 Beds / 4 Baths',
    roomsZh: '6室2厅4卫',
    districtEn: 'Dongcheng District',
    districtZh: '东城区',
    yearBuilt: 1950
  },
  {
    id: 'sh-sky-penthouse',
    titleEn: 'LuJiaZui Panoramic Skyline Duplex',
    titleZh: '陆家嘴双子星·云顶复式',
    city: 'Shanghai',
    cityZh: '上海',
    image: '/src/assets/images/beijing_luxury_penthouse_1791204026232.jpg', // Reuse penthouse interior
    price: 82000000,
    area: 350,
    typeEn: 'Modern Penthouse',
    typeZh: '现代复式',
    featuresEn: ['Panoramic Cityscape', 'Waterfront View', 'Private Elevator'],
    featuresZh: ['金茂天际视野', '一线江景', '专梯入户'],
    appreciation: '+4.9%',
    roomsEn: '4 Beds / 4 Baths',
    roomsZh: '4室2厅4卫',
    districtEn: 'Pudong New Area',
    districtZh: '浦东新区',
    yearBuilt: 2018
  },
  {
    id: 'sz-shekou',
    titleEn: 'Shekou Coastal Eco Residence',
    titleZh: '蛇口半山·观海生态洋房',
    city: 'Shenzhen',
    cityZh: '深圳',
    image: '/src/assets/images/chengdu_eco_residence_1791204040549.jpg', // Reuse eco styling
    price: 32000000,
    area: 220,
    typeEn: 'Eco-Apartment',
    typeZh: '生态大平层',
    featuresEn: ['Waterfront View', 'High Greenery', 'School District'],
    featuresZh: ['山海景观', '森林氧吧', '双语国际学校'],
    appreciation: '+5.8%',
    roomsEn: '3 Beds / 2 Baths',
    roomsZh: '3室2厅2卫',
    districtEn: 'Nanshan District',
    districtZh: '南山区',
    yearBuilt: 2022
  }
];

// Historical Prices over the last 6 months (May 2026 - Oct 2026) for each city in CNY/sqm
const CITY_TRENDS: Record<string, { label: string; values: number[]; dates: string[] }> = {
  Beijing: {
    label: 'Beijing 北京',
    values: [67900, 68000, 68200, 68300, 68450, 68500],
    dates: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct']
  },
  Shanghai: {
    label: 'Shanghai 上海',
    values: [69800, 70100, 70400, 70900, 71100, 71200],
    dates: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct']
  },
  Shenzhen: {
    label: 'Shenzhen 深圳',
    values: [73200, 73600, 74000, 74400, 74600, 74800],
    dates: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct']
  },
  Guangzhou: {
    label: 'Guangzhou 广州',
    values: [45800, 45900, 46100, 46200, 46400, 46500],
    dates: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct']
  },
  Hangzhou: {
    label: 'Hangzhou 杭州',
    values: [37800, 38000, 38100, 38300, 38400, 38500],
    dates: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct']
  },
  Chengdu: {
    label: 'Chengdu 成都',
    values: [19800, 20100, 20300, 20600, 20800, 21000],
    dates: ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct']
  }
};

const STATS_DATA: Record<string, { price: number; yoy: string; volume: string; inventory: string; restrictionEn: string; restrictionZh: string }> = {
  All: { price: 54100, yoy: '+4.2%', volume: '142.6M', inventory: '2.8M', restrictionEn: 'LPR benchmark cut to 3.35%; down payment drops to 15%.', restrictionZh: '5年期LPR调降至3.35%，首套首付降至15%' },
  Beijing: { price: 68500, yoy: '+1.8%', volume: '18.4M', inventory: '420K', restrictionEn: 'Strict purchase limits inside 5th Ring; special school zone locks.', restrictionZh: '限购限贷政策维持，部分城区因学区锁定' },
  Shanghai: { price: 71200, yoy: '+5.1%', volume: '22.1M', inventory: '380K', restrictionEn: 'Single non-locals can buy outside Outer Ring after 3-year tax history.', restrictionZh: '外环外非沪籍单身限购社保年限由5年降至3年' },
  Shenzhen: { price: 74800, yoy: '+6.2%', volume: '24.3M', inventory: '320K', restrictionEn: 'Local household down-payment reduced; key tax exemptions.', restrictionZh: '首套首付下调，增值税征免年限5改2' },
  Guangzhou: { price: 46500, yoy: '+1.1%', volume: '19.8M', inventory: '580K', restrictionEn: 'Comprehensive easing of purchase restrictions across non-core zones.', restrictionZh: '全面取消非核心区域限购，二套首付减免' },
  Hangzhou: { price: 38500, yoy: '+3.1%', volume: '15.2M', inventory: '290K', restrictionEn: 'No buying limits in full Xihu area; active talent subsidies.', restrictionZh: '放开非核心区限购，高层次人才购房享受补贴' },
  Chengdu: { price: 21000, yoy: '+5.4%', volume: '42.8M', inventory: '810K', restrictionEn: 'Active support for family-upgrades; high eco-balcony incentives.', restrictionZh: '鼓励改善性住房，生态绿化建筑享受政策红利' }
};

// Language Dictionary
const DICTIONARY = {
  en: {
    title: 'HuaXun Housing',
    subtitle: 'Institutional Housing Market Directory & Analytics',
    navOverview: 'Market Overview',
    navDirectory: 'Property Directory',
    navTrends: 'Market Trends',
    navMortgage: 'Mortgage Calculator',
    navAdvisor: 'Investment Analyst',
    contactBroker: 'Request Institutional Report',
    searchPlaceholder: 'Search luxury estates by name, district, keyword...',
    searchBtn: 'Query',
    allCities: 'All Cities',
    appreciationTitle: 'YoY appreciation',
    areaLabel: 'Area',
    priceLabel: 'Total Price',
    priceUnit: '¥',
    priceUnitSuffix: 'M',
    pricePerSqm: 'Price / ㎡',
    bedsLabel: 'Rooms',
    districtLabel: 'Location',
    yearLabel: 'Built',
    calculatorTitle: 'Interactive Mortgage Calculator',
    calcSub: 'Bilingual PBOC regulatory compliant amortization formulas',
    propertyPrice: 'Target Property Price',
    downPaymentRate: 'Down Payment Ratio',
    loanTerm: 'Loan Term',
    annualRate: 'Interest Rate (LPR + Margin)',
    paymentMethod: 'Payment Structure',
    method1: 'Equal Principal & Interest (等额本息)',
    method2: 'Equal Principal (等额本金)',
    totalLoan: 'Total Loan Amount',
    downPaymentAmount: 'Down Payment Required',
    monthlyPayment: 'Monthly Amortization',
    monthlyDecrease: 'Monthly Decrement',
    totalInterest: 'Total Interest Payable',
    totalRepayment: 'Total Cost of Ownership',
    viewSchedule: 'Show Amortization Table',
    yearCol: 'Year',
    paymentCol: 'Yearly Payments',
    remainingCol: 'Remaining Balance',
    chartTitle: 'Average Property Value Trend (6-Month)',
    chartUnit: 'Yuan/㎡',
    advisorTitle: 'HuaXun Smart Market Analyst',
    advisorSub: 'Bespoke investment guidance grounded in real-time Chinese policy models',
    askAdvisorPlaceholder: 'Ask about local purchase restrictions, school districts, or investment risk...',
    sendQuestion: 'Analyze',
    analyzingState: 'Synthesizing market reports...',
    featuresTitle: 'Signature Qualifiers',
    detailsTitle: 'Property Profile Details',
    scheduleTour: 'Register Acquisition Intent',
    closeBtn: 'Close',
    cityLabel: 'City',
    noProperties: 'No properties found matching your selection criteria.',
    comparisonTitle: 'City Market Comparison Matrix',
    comparisonSub: 'Benchmark local indicators side-by-side',
    statAveragePrice: 'Average Price',
    statYoY: 'YoY Change',
    statVolume: 'Monthly Sales Area',
    statInventory: 'Available Inventory',
    policyOutlook: 'Policy Framework',
    suggestedQuestions: 'Suggested Enquiries',
    cityAllLabel: 'All Metro Areas'
  },
  zh: {
    title: '华讯置业',
    subtitle: '中国房地产市场机构级目录与分析套件',
    navOverview: '市场概览',
    navDirectory: '精选房源目录',
    navTrends: '价格趋势分析',
    navMortgage: '精准房贷计算器',
    navAdvisor: '机构投资分析顾问',
    contactBroker: '索取机构分析报告',
    searchPlaceholder: '输入案名、行政区、特色关键词进行查询...',
    searchBtn: '检索',
    allCities: '全部城市',
    appreciationTitle: '年同比涨幅',
    areaLabel: '建筑面积',
    priceLabel: '物业总价',
    priceUnit: '¥',
    priceUnitSuffix: '万',
    pricePerSqm: '单价',
    bedsLabel: '户型',
    districtLabel: '区域位置',
    yearLabel: '竣工年份',
    calculatorTitle: '专业房贷测算器',
    calcSub: '基于央行最新LPR基准利率及还款法算法',
    propertyPrice: '物业意向总价',
    downPaymentRate: '首付比例',
    loanTerm: '按揭年限',
    annualRate: '贷款利率 (LPR + 基点)',
    paymentMethod: '还款方式选择',
    method1: '等额本息 (每月还款额固定)',
    method2: '等额本金 (每月本金固定，递减)',
    totalLoan: '按揭贷款总额',
    downPaymentAmount: '首期款额度',
    monthlyPayment: '首月/每月月供',
    monthlyDecrease: '每月递减额',
    totalInterest: '利息支出总计',
    totalRepayment: '累计还款本息和',
    viewSchedule: '查看还款详情年表',
    yearCol: '年份',
    paymentCol: '年度已还款项',
    remainingCol: '贷款余额',
    chartTitle: '住宅销售均价走势 (近六个月)',
    chartUnit: '元/平方米',
    advisorTitle: '华讯AI市场研究员',
    advisorSub: '依托中国房地产宏观政策和宏观金融模型的专属顾问服务',
    askAdvisorPlaceholder: '可向我提问关于限购限售、重点学区、宏观金融降息等政策影响...',
    sendQuestion: '智能分析',
    analyzingState: '正在深度研判市场走势...',
    featuresTitle: '物业核心特征',
    detailsTitle: '房源尊享详情',
    scheduleTour: '提交认购意向',
    closeBtn: '关闭',
    cityLabel: '城市',
    noProperties: '未检索到符合当前筛选条件的特色物业房源。',
    comparisonTitle: '多城市宏观指标对比矩阵',
    comparisonSub: '横向多维评测各区域住宅基本面',
    statAveragePrice: '住宅均价',
    statYoY: '年同比增长',
    statVolume: '月成交面积',
    statInventory: '待售总库存',
    policyOutlook: '政策监管导向',
    suggestedQuestions: '热门政策咨询',
    cityAllLabel: '全国主要一二线城市'
  }
};

export default function App() {
  // Locale State
  const [lang, setLang] = useState<'en' | 'zh'>('zh');
  const t = useMemo(() => DICTIONARY[lang], [lang]);

  // City and filtering state
  const [selectedCity, setSelectedCity] = useState<string>('All');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [priceRange, setPriceRange] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Interactive Mortgage Calculator State
  const [calcPrice, setCalcPrice] = useState<number>(50000000); // 50M Default
  const [downPaymentPct, setDownPaymentPct] = useState<number>(20); // 20% PBOC compliant standard
  const [termYears, setTermYears] = useState<number>(30); // 30 Years
  const [interestRate, setInterestRate] = useState<number>(3.35); // LPR Oct 2026 standard
  const [calcMethod, setCalcMethod] = useState<'equalInterest' | 'equalPrincipal'>('equalInterest');
  const [showAmortization, setShowAmortization] = useState<boolean>(false);

  // Active Selected Property for Amortization Loader & Modal
  const [activeProperty, setActiveProperty] = useState<Property | null>(null);

  // Gemini AI AI Intelligence Suite State
  const [advisorInput, setAdvisorInput] = useState<string>('');
  const [advisorHistory, setAdvisorHistory] = useState<Array<{ sender: 'user' | 'analyst'; text: string }>>([
    {
      sender: 'analyst',
      text: lang === 'zh' 
        ? '您好，我是华讯研究院的首席住宅分析师。我专注于全国一二线城市限购政策、LPR利率调整、以及高端住宅资产增值的量化评测。请问您需要了解哪个城市的宏观动向或具体项目的投资前景？' 
        : 'Welcome to HuaXun Real Estate. I am the Director of Housing Research. I specialize in regulatory framework evaluation, LPR rate analysis, and premium residential asset valuations across China. How can I assist your portfolio strategies today?'
    }
  ]);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  // Comparison Module State (Select two cities side-by-side)
  const [compCityA, setCompCityA] = useState<string>('Shanghai');
  const [compCityB, setCompCityB] = useState<string>('Shenzhen');

  // Interactive booking/inquiry modal state
  const [inquiryModalOpen, setInquiryModalOpen] = useState<boolean>(false);
  const [inquirySuccess, setInquirySuccess] = useState<boolean>(false);
  const [clientName, setClientName] = useState<string>('');
  const [clientContact, setClientContact] = useState<string>('');

  // Sync Mortgage Calculator Target Price if a user clicks on a property card's finance tool
  const loadInCalculator = (price: number) => {
    setCalcPrice(price);
    const element = document.getElementById('mortgage-calculator');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Switch App language effect for AI advisor historical starter messages
  useEffect(() => {
    setAdvisorHistory([
      {
        sender: 'analyst',
        text: lang === 'zh' 
          ? '您好，我是华讯研究院的首席住宅分析师。我专注于全国一二线城市限购政策、LPR利率调整、以及高端住宅资产增值的量化评测。请问您需要了解哪个城市的宏观动向或具体项目的投资前景？' 
          : 'Welcome to HuaXun Real Estate. I am the Director of Housing Research. I specialize in regulatory framework evaluation, LPR rate analysis, and premium residential asset valuations across China. How can I assist your portfolio strategies today?'
      }
    ]);
  }, [lang]);

  // Property Filters
  const filteredProperties = useMemo(() => {
    return PROPERTIES.filter((p) => {
      // Search
      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = searchQuery === '' || 
        p.titleEn.toLowerCase().includes(searchLower) ||
        p.titleZh.includes(searchQuery) ||
        p.districtEn.toLowerCase().includes(searchLower) ||
        p.districtZh.includes(searchQuery) ||
        p.typeEn.toLowerCase().includes(searchLower) ||
        p.typeZh.includes(searchQuery);

      // City
      const matchesCity = selectedCity === 'All' || p.city === selectedCity;

      // Property Type
      const matchesType = selectedType === 'All' || p.typeEn === selectedType;

      // Price Range (in millions)
      const matchesPrice = () => {
        if (priceRange === 'All') return true;
        const priceM = p.price / 1000000;
        if (priceRange === 'under15') return priceM < 15;
        if (priceRange === '15to50') return priceM >= 15 && priceM <= 50;
        if (priceRange === '50to80') return priceM >= 50 && priceM <= 80;
        if (priceRange === 'over80') return priceM > 80;
        return true;
      };

      return matchesSearch && matchesCity && matchesType && matchesPrice();
    });
  }, [selectedCity, selectedType, priceRange, searchQuery]);

  // Unique Types from Properties for Filters
  const propertyTypes = useMemo(() => {
    return ['All', 'Luxury High-rise', 'Courtyard Villa', 'Modern Penthouse', 'Eco-Apartment'];
  }, []);

  // Price Ranges definition
  const priceRanges = [
    { value: 'All', labelEn: 'All Prices', labelZh: '全部价格' },
    { value: 'under15', labelEn: '< ¥15M', labelZh: '1500万以下' },
    { value: '15to50', labelEn: '¥15M - ¥50M', labelZh: '1500万-5000万' },
    { value: '50to80', labelEn: '¥50M - ¥80M', labelZh: '5000万-8000万' },
    { value: 'over80', labelEn: '> ¥80M', labelZh: '8000万以上' }
  ];

  // Calculated Mortgage Variables
  const mortgageMetrics = useMemo(() => {
    const totalLoan = Math.max(0, calcPrice * (1 - downPaymentPct / 100));
    const downPaymentAmount = Math.max(0, calcPrice * (downPaymentPct / 100));
    const r = interestRate / 12 / 100; // Monthly rate
    const n = termYears * 12; // Total months

    if (totalLoan <= 0 || r <= 0 || n <= 0) {
      return {
        totalLoan: 0,
        downPaymentAmount: calcPrice,
        monthlyPayment: 0,
        monthlyDecrease: 0,
        totalInterest: 0,
        totalRepayment: calcPrice,
        schedule: []
      };
    }

    if (calcMethod === 'equalInterest') {
      // Equal Principal & Interest Formula
      const monthlyPayment = (totalLoan * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      const totalRepayment = monthlyPayment * n;
      const totalInterest = totalRepayment - totalLoan;

      // Amortization Schedule (Yearly summary for space saving & clean styling)
      const schedule = [];
      let balance = totalLoan;
      for (let yr = 1; yr <= termYears; yr++) {
        let yearlyInterestPaid = 0;
        let yearlyPrincipalPaid = 0;
        for (let m = 0; m < 12; m++) {
          const interestForMonth = balance * r;
          const principalForMonth = monthlyPayment - interestForMonth;
          yearlyInterestPaid += interestForMonth;
          yearlyPrincipalPaid += principalForMonth;
          balance = Math.max(0, balance - principalForMonth);
        }
        schedule.push({
          year: yr,
          payment: monthlyPayment * 12,
          remaining: balance
        });
      }

      return {
        totalLoan,
        downPaymentAmount,
        monthlyPayment,
        monthlyDecrease: 0,
        totalInterest,
        totalRepayment: totalRepayment + downPaymentAmount,
        schedule
      };
    } else {
      // Equal Principal Formula
      const monthlyPrincipal = totalLoan / n;
      let totalInterest = 0;
      let firstMonthPayment = monthlyPrincipal + totalLoan * r;
      let lastMonthPayment = monthlyPrincipal + monthlyPrincipal * r;
      const monthlyDecrease = monthlyPrincipal * r;

      const schedule = [];
      let balance = totalLoan;
      for (let yr = 1; yr <= termYears; yr++) {
        let yearlyPaid = 0;
        for (let m = 0; m < 12; m++) {
          const interestForMonth = balance * r;
          const totalMonthlyPay = monthlyPrincipal + interestForMonth;
          totalInterest += interestForMonth;
          yearlyPaid += totalMonthlyPay;
          balance = Math.max(0, balance - monthlyPrincipal);
        }
        schedule.push({
          year: yr,
          payment: yearlyPaid,
          remaining: balance
        });
      }

      return {
        totalLoan,
        downPaymentAmount,
        monthlyPayment: firstMonthPayment, // Displays first month as benchmark
        monthlyDecrease,
        totalInterest,
        totalRepayment: totalLoan + totalInterest + downPaymentAmount,
        schedule
      };
    }
  }, [calcPrice, downPaymentPct, termYears, interestRate, calcMethod]);

  // Call Gemini API server route `/api/gemini/generate` securely
  const askAdvisor = async (customPrompt?: string) => {
    const textToSend = customPrompt || advisorInput;
    if (!textToSend.trim()) return;

    // Append user message immediately
    setAdvisorHistory((prev) => [...prev, { sender: 'user', text: textToSend }]);
    setAdvisorInput('');
    setIsAnalyzing(true);

    try {
      const promptToModel = `
You are a highly analytical and experienced Chief Real Estate Investment Analyst at HuaXun Housing, a premium institutional residential advisory firm in China. 
The user is asking: "${textToSend}"
Provide a high-character, elite, and quantitative assessment. Speak strictly in ${lang === 'zh' ? 'Chinese' : 'English'}.
Structure your thoughts to cover:
1. Current Policy alignment (e.g., PBOC LPR 3.35% cuts, down payment ratios down to 15%, local purchase limits/restrictions (限购限贷)).
2. Asset performance metrics (discuss typical capitalization rates (租金收益率), YoY growth, and long-term liquidity profiles).
3. Real investment recommendation (Neutral/Cautious, Buy, Outperform, Sell).

Keep the tone highly professional, objective, academic, and tailored to high-net-worth institutional real estate investors. Do not use generic AI chatter, emojis, or exclamation points. Output in clean Markdown formatting without code comment prefixes.
`;

      const systemInstruction = "You are the Director of Housing Research at HuaXun Housing. You write comprehensive, concise institutional real estate reports with quantitative data.";

      const response = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: promptToModel, systemInstruction })
      });

      const data = await response.json();
      if (data.text) {
        setAdvisorHistory((prev) => [...prev, { sender: 'analyst', text: data.text }]);
      } else {
        throw new Error(data.error || 'Empty response');
      }
    } catch (err) {
      console.error('Failed to communicate with advisor backend:', err);
      // Fallback Response (Zero-Broken-Experience policy)
      const fallbackMsg = lang === 'zh'
        ? `【华讯分析提示：API调试模式】
当前一二线市场核心政策导向：
1. 上海、深圳首套首付降至15%，五年来最低。
2. 5年期LPR调降至3.35%，存量房贷普遍减免。
3. 精选标的（如外滩、深圳湾等稀缺江海景观资源）具备较强的资产避险属性，建议高净值投资者配置。
如需更详细的量化多模分析，请确认您的环境变量中已配有有效的 GEMINI_API_KEY。`
        : `[HuaXun Advisory: API Fallback Alert]
Current Macro Real Estate Framework:
1. PBOC has lowered the national down-payment floor to 15% for first-time buyers, hitting historical lows.
2. The 5-year LPR index stands at 3.35%, optimizing holding costs for leveraged portfolios.
3. Core locations (Shanghai Bund, Shenzhen Bay) with waterfront assets maintain scarcity premiums and act as reliable capital preserves. Recommended asset weight: Outperform.`;
      
      setAdvisorHistory((prev) => [...prev, { sender: 'analyst', text: fallbackMsg }]);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Preset Advisory Questions
  const PRESET_QUESTIONS = lang === 'zh' ? [
    '5年期LPR降至3.35%，购房成本降低多少？',
    '上海与深圳核心豪宅区目前首付及限购政策对比？',
    '杭州与成都等强二线城市，哪一个租金收益率更稳健？'
  ] : [
    'How does the 3.35% LPR cut impact standard mortgage costs?',
    'Compare current purchase limits between Shanghai & Shenzhen prime areas.',
    'Which city offers better premium rental yields: Hangzhou or Chengdu?'
  ];

  // Custom SVG Chart Mathematical Calculations based on Selected City prices
  const chartData = useMemo(() => {
    const cityKey = selectedCity === 'All' ? 'Shanghai' : selectedCity;
    const trend = CITY_TRENDS[cityKey] || CITY_TRENDS['Shanghai'];
    const minVal = Math.min(...trend.values) * 0.98;
    const maxVal = Math.max(...trend.values) * 1.02;
    const range = maxVal - minVal;

    // Convert values to SVG coordinate percentages
    const width = 600;
    const height = 180;
    const paddingLeft = 60;
    const paddingRight = 20;
    const paddingTop = 20;
    const paddingBottom = 30;

    const chartWidth = width - paddingLeft - paddingRight;
    const chartHeight = height - paddingTop - paddingBottom;

    const points = trend.values.map((val, idx) => {
      const x = paddingLeft + (idx / (trend.values.length - 1)) * chartWidth;
      const y = height - paddingBottom - ((val - minVal) / range) * chartHeight;
      return { x, y, value: val, date: trend.dates[idx] };
    });

    const pathD = points.reduce((acc, p, idx) => {
      return idx === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`;
    }, '');

    const areaD = `${pathD} L ${points[points.length - 1].x} ${height - paddingBottom} L ${points[0].x} ${height - paddingBottom} Z`;

    return { points, pathD, areaD, minVal, maxVal, width, height, paddingLeft, paddingBottom, trend };
  }, [selectedCity]);

  // Handle inquiry submissions
  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim() || !clientContact.trim()) return;
    setIsAnalyzing(true);
    setTimeout(() => {
      setInquirySuccess(true);
      setIsAnalyzing(false);
    }, 1200);
  };

  // Close inquiry and clear form
  const resetInquiry = () => {
    setInquiryModalOpen(false);
    setInquirySuccess(false);
    setClientName('');
    setClientContact('');
  };

  return (
    <div className="min-h-screen bg-[#070B13] text-slate-100 font-sans selection:bg-emerald-500/30 selection:text-emerald-300">
      
      {/* SECTION 2: Top Bar Contract (Exactly 3 zones: Brand title, 5 nav links, 2 primary actions) */}
      <header className="sticky top-0 z-50 bg-[#070B13]/90 backdrop-blur-md border-b border-emerald-950/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          {/* Zone 1: Single text element Brand Zone */}
          <div className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-emerald-400" />
            <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-200 bg-clip-text text-transparent">
              {t.title}
            </span>
          </div>

          {/* Zone 2: 5 clean navigation links with subtle single-line hover states */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-400">
            <a href="#market-overview" className="hover:text-emerald-400 transition-colors whitespace-nowrap">{t.navOverview}</a>
            <a href="#property-directory" className="hover:text-emerald-400 transition-colors whitespace-nowrap">{t.navDirectory}</a>
            <a href="#market-trends" className="hover:text-emerald-400 transition-colors whitespace-nowrap">{t.navTrends}</a>
            <a href="#mortgage-calculator" className="hover:text-emerald-400 transition-colors whitespace-nowrap">{t.navMortgage}</a>
            <a href="#investment-advisor" className="hover:text-emerald-400 transition-colors whitespace-nowrap">{t.navAdvisor}</a>
          </nav>

          {/* Zone 3: 1-2 functional, single-line actions */}
          <div className="flex items-center gap-3">
            {/* Language switcher */}
            <button 
              onClick={() => setLang(lang === 'en' ? 'zh' : 'en')}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-slate-800 text-xs text-slate-300 hover:border-emerald-500/50 hover:text-emerald-400 transition-all font-mono"
              aria-label="Toggle language"
            >
              <Globe className="h-3 w-3" />
              <span className="whitespace-nowrap font-medium">{lang === 'en' ? '中文' : 'EN'}</span>
            </button>

            {/* Direct inquiry CTA */}
            <button 
              onClick={() => setInquiryModalOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white rounded-md text-xs font-semibold tracking-wide shadow-lg shadow-emerald-950/20 active:translate-y-px transition-all whitespace-nowrap"
            >
              <PhoneCall className="h-3.5 w-3.5" />
              <span>{t.contactBroker}</span>
            </button>
          </div>

        </div>
      </header>

      {/* Hero Banner Section with Custom Background image & Search */}
      <section className="relative overflow-hidden border-b border-emerald-950/30">
        {/* Scrim and Overlay */}
        <div className="absolute inset-0 z-0 bg-gradient-to-b from-[#070B13]/20 via-[#070B13]/70 to-[#070B13]"></div>
        
        {/* Background Image generated with proper aspect ratio */}
        <img 
          src="/src/assets/images/shanghai_market_hero_1791203976019.jpg" 
          alt="Shanghai Skyline Real Estate" 
          className="absolute inset-0 w-full h-full object-cover object-center scale-105 select-none blur-[1px] opacity-40 filter brightness-90"
          referrerPolicy="no-referrer"
        />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32 flex flex-col items-center text-center">
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/40 border border-emerald-500/20 text-xs text-emerald-400 mb-6 backdrop-blur-sm">
            <Sparkles className="h-3.5 w-3.5 animate-pulse" />
            <span className="font-mono uppercase tracking-wider">{lang === 'zh' ? '机构级数据汇编' : 'INSTITUTIONAL GRADE COMPILATION'}</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white mb-6 max-w-4xl text-wrap-balance leading-tight">
            {lang === 'zh' ? '探寻中国超大都市住宅资产真实价值' : 'Unveiling Sovereign Values of Chinese Metropolitan Estates'}
          </h1>
          
          <p className="text-lg text-slate-300 max-w-2xl mb-10 text-wrap-balance leading-relaxed">
            {t.subtitle}
          </p>

          {/* Bilingual Search Overlay Bar */}
          <div className="w-full max-w-2xl bg-[#0d1527]/90 backdrop-blur-md p-2 rounded-lg border border-slate-800 flex items-center shadow-2xl shadow-black/80 gap-2">
            <div className="flex items-center pl-3 text-slate-400 w-full">
              <Search className="h-5 w-5 text-emerald-500 mr-2.5 shrink-0" />
              <input 
                type="text"
                placeholder={t.searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent text-slate-200 placeholder-slate-500 text-sm focus:outline-none w-full"
              />
            </div>
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="p-1 rounded-md text-slate-400 hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            )}
            <button className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-md transition-all whitespace-nowrap tracking-wider">
              {t.searchBtn}
            </button>
          </div>

        </div>
      </section>

      {/* SECTION 4D: Micro Stats Grid with Monospace Tabular Figures */}
      <section id="market-overview" className="bg-[#090E18] py-8 border-b border-emerald-950/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* City Interactive Filter Row (TABS / Segmented button style - allowed!) */}
          <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-sm font-semibold tracking-wider text-slate-400 uppercase font-mono mb-1">
                {lang === 'zh' ? '重点城市联动监测' : 'METROPOLITAN MARKET LINK'}
              </h2>
              <p className="text-xl font-bold text-white">
                {selectedCity === 'All' ? t.cityAllLabel : `${selectedCity} ${PROPERTIES.find(p => p.city === selectedCity)?.cityZh || ''}`}
              </p>
            </div>

            {/* Clean Segmented Tab Controls for Cities */}
            <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-900 self-start">
              <button 
                onClick={() => setSelectedCity('All')}
                className={`px-3.5 py-2 text-xs font-medium rounded-md transition-all ${selectedCity === 'All' ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/20 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
              >
                {t.allCities}
              </button>
              {['Beijing', 'Shanghai', 'Shenzhen', 'Guangzhou', 'Hangzhou', 'Chengdu'].map((city) => {
                const cityZh = city === 'Beijing' ? '北京' : city === 'Shanghai' ? '上海' : city === 'Shenzhen' ? '深圳' : city === 'Guangzhou' ? '广州' : city === 'Hangzhou' ? '杭州' : '成都';
                return (
                  <button 
                    key={city}
                    onClick={() => setSelectedCity(city)}
                    className={`px-3.5 py-2 text-xs font-medium rounded-md transition-all ${selectedCity === city ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/20 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
                  >
                    <span className="font-mono">{city}</span> <span className="text-[10px] opacity-75">{cityZh}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Actual stats numbers - enforcing tab-nums strictly for alignments */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            
            <div className="bg-[#0b1424]/40 p-5 rounded-lg border border-slate-900">
              <span className="text-xs text-slate-400 block mb-1 font-mono uppercase">{lang === 'zh' ? '本月均价 (元/㎡)' : 'AVG SALE PRICE (/㎡)'}</span>
              <div className="flex items-baseline gap-2">
                <span className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-mono tabular-nums">
                  ¥{STATS_DATA[selectedCity]?.price.toLocaleString()}
                </span>
                <span className="text-xs font-bold text-emerald-400 font-mono">
                  {STATS_DATA[selectedCity]?.yoy}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-2">
                {lang === 'zh' ? '成交量加权真实计算' : 'Volume-weighted actual valuation'}
              </p>
            </div>

            <div className="bg-[#0b1424]/40 p-5 rounded-lg border border-slate-900">
              <span className="text-xs text-slate-400 block mb-1 font-mono uppercase">{lang === 'zh' ? '住宅销量（成交面积）' : 'MONTHLY VOLUME SOLD'}</span>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-mono tabular-nums">
                  {STATS_DATA[selectedCity]?.volume}
                </span>
                <span className="text-sm font-medium text-slate-400 font-sans">
                  ㎡
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-2">
                {lang === 'zh' ? '近三十日累计成交量' : 'Cumulative volume past 30 days'}
              </p>
            </div>

            <div className="bg-[#0b1424]/40 p-5 rounded-lg border border-slate-900">
              <span className="text-xs text-slate-400 block mb-1 font-mono uppercase">{lang === 'zh' ? '待售可售总套数' : 'ACTIVE INVENTORY UNITS'}</span>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white font-mono tabular-nums">
                  {STATS_DATA[selectedCity]?.inventory}
                </span>
                <span className="text-xs text-amber-500 font-mono ml-1.5 font-bold uppercase">
                  {lang === 'zh' ? '高存销比' : 'High SCR'}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-2">
                {lang === 'zh' ? '核心区与郊区合并待售量' : 'Aggregated listing volumes'}
              </p>
            </div>

            <div className="bg-[#0b1424]/40 p-5 rounded-lg border border-emerald-950/20 bg-gradient-to-br from-[#0c162b] to-[#0a1b24]">
              <span className="text-xs text-emerald-400 block mb-1 font-mono uppercase">{lang === 'zh' ? '央行及本市信贷限制' : 'PBOC REGULATORY BENCHMARK'}</span>
              <p className="text-xs font-semibold text-slate-200 line-clamp-2 leading-relaxed">
                {lang === 'zh' ? STATS_DATA[selectedCity]?.restrictionZh : STATS_DATA[selectedCity]?.restrictionEn}
              </p>
              <div className="mt-2.5 flex items-center gap-1.5 text-[10px] font-mono text-emerald-500">
                <Activity className="h-3 w-3 animate-pulse" />
                <span>{lang === 'zh' ? '2026最新降按基准' : '2026 PBOC eased baseline'}</span>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* Primary Workspace: Listing Grid & Filter System */}
      <section id="property-directory" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Header Section */}
        <div className="border-l-4 border-emerald-500 pl-4 mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            {t.navDirectory}
          </h2>
          <p className="text-slate-400 text-sm mt-1">
            {lang === 'zh' ? '精选全国超高净值地标住宅与生态建筑目录' : 'Curated register of ultra-high-net-worth trophy residential estates'}
          </p>
        </div>

        {/* Dynamic Filtering Row - Segmented Controls */}
        <div className="bg-[#0c1322]/60 p-5 rounded-lg border border-slate-900 mb-8 flex flex-col gap-6">
          
          {/* Filter Group 1: Property Type */}
          <div>
            <span className="text-xs font-semibold font-mono text-slate-400 block mb-2.5 uppercase tracking-wider">
              {lang === 'zh' ? '物业形态类型' : 'Property Asset Type'}
            </span>
            <div className="flex flex-wrap gap-1.5">
              {propertyTypes.map((type) => {
                const isSelected = selectedType === type;
                const labelZh = type === 'All' ? '全部形态' : type === 'Luxury High-rise' ? '奢华高层' : type === 'Courtyard Villa' ? '中式院落' : type === 'Modern Penthouse' ? '现代复式' : '生态大平层';
                return (
                  <button
                    key={type}
                    onClick={() => setSelectedType(type)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${isSelected ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-900'}`}
                  >
                    {lang === 'zh' ? labelZh : type}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Filter Group 2: Price Bracket */}
          <div>
            <span className="text-xs font-semibold font-mono text-slate-400 block mb-2.5 uppercase tracking-wider">
              {lang === 'zh' ? '总价交易区间' : 'Total Price Bracket'}
            </span>
            <div className="flex flex-wrap gap-1.5">
              {priceRanges.map((range) => {
                const isSelected = priceRange === range.value;
                return (
                  <button
                    key={range.value}
                    onClick={() => setPriceRange(range.value)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-all ${isSelected ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-900'}`}
                  >
                    {lang === 'zh' ? range.labelZh : range.labelEn}
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* Properties Grid */}
        {filteredProperties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProperties.map((p) => {
              const priceMillions = (p.price / 1000000).toFixed(1);
              const pricePerSqmFormatted = Math.round(p.price / p.area).toLocaleString();

              return (
                <div 
                  key={p.id}
                  className="bg-[#0b1222] rounded-lg border border-slate-900 overflow-hidden hover:border-emerald-500/40 transition-all group flex flex-col"
                >
                  {/* Photo Slot */}
                  <div className="relative h-64 overflow-hidden bg-slate-950">
                    <img 
                      src={p.image} 
                      alt={lang === 'zh' ? p.titleZh : p.titleEn} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                    
                    {/* Floating top left City Marker */}
                    <span className="absolute top-3 left-3 px-2.5 py-1 rounded bg-[#070b13]/80 border border-slate-800 text-[10px] font-mono tracking-wider text-emerald-400">
                      {p.city.toUpperCase()} · {p.cityZh}
                    </span>

                    {/* YoY change marker bottom left */}
                    <span className="absolute bottom-3 left-3 text-xs text-white font-mono flex items-center gap-1 bg-emerald-950/90 border border-emerald-500/30 px-2 py-0.5 rounded">
                      <TrendingUp className="h-3 w-3 text-emerald-400" />
                      {p.appreciation} YoY
                    </span>
                  </div>

                  {/* Body Info */}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-lg font-bold text-white group-hover:text-emerald-400 transition-colors line-clamp-1">
                        {lang === 'zh' ? p.titleZh : p.titleEn}
                      </h3>
                      
                      {/* Zero-Pill Metadata. Styled as clean unboxed inline text with separators */}
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-400 mt-2 font-mono">
                        <span>{lang === 'zh' ? p.typeZh : p.typeEn}</span>
                        <span className="text-slate-600">·</span>
                        <span>{p.area} sqm</span>
                        <span className="text-slate-600">·</span>
                        <span>{lang === 'zh' ? p.roomsZh : p.roomsEn}</span>
                      </div>

                      {/* Geographic detail */}
                      <div className="flex items-center gap-1 text-xs text-slate-500 mt-2.5">
                        <MapPin className="h-3.5 w-3.5 text-slate-600 shrink-0" />
                        <span className="truncate">{lang === 'zh' ? `${p.cityZh} · ${p.districtZh}` : `${p.city}, ${p.districtEn}`}</span>
                      </div>

                      {/* Property qualifiers */}
                      <div className="flex flex-wrap gap-x-2 gap-y-1 mt-4 text-[11px] text-slate-400 font-sans border-t border-slate-900/60 pt-3">
                        {lang === 'zh' ? p.featuresZh.map((f, i) => (
                          <span key={i} className="text-[#bf9f62] font-semibold">#{f}</span>
                        )) : p.featuresEn.map((f, i) => (
                          <span key={i} className="text-[#bf9f62] font-semibold">#{f}</span>
                        ))}
                      </div>
                    </div>

                    <div className="mt-6 pt-4 border-t border-slate-950 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-500 block uppercase tracking-wider font-mono">{t.priceLabel}</span>
                        <span className="text-xl font-black text-white font-mono tabular-nums">
                          ¥{priceMillions}{t.priceUnitSuffix}
                        </span>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block uppercase tracking-wider font-mono">{t.pricePerSqm}</span>
                        <span className="text-xs font-mono text-slate-300 tabular-nums">
                          ¥{pricePerSqmFormatted}/㎡
                        </span>
                      </div>
                    </div>

                    {/* Interactive CTAs inside card */}
                    <div className="grid grid-cols-2 gap-2 mt-5">
                      <button 
                        onClick={() => {
                          setActiveProperty(p);
                        }}
                        className="px-3 py-2 border border-slate-800 hover:border-emerald-500/30 text-slate-300 hover:text-emerald-400 text-xs font-semibold rounded transition-all text-center"
                      >
                        {lang === 'zh' ? '档案详情' : 'Asset Profile'}
                      </button>

                      <button 
                        onClick={() => loadInCalculator(p.price)}
                        className="px-3 py-2 bg-slate-950 border border-slate-900 hover:border-emerald-500/30 text-emerald-400 text-xs font-semibold rounded flex items-center justify-center gap-1 transition-all"
                      >
                        <Calculator className="h-3 w-3 shrink-0" />
                        <span>{lang === 'zh' ? '测算房贷' : 'Mortgage'}</span>
                      </button>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16 bg-[#0c1322]/30 rounded-lg border border-slate-900">
            <Building2 className="h-10 w-10 text-slate-600 mx-auto mb-3" />
            <p className="text-slate-400 text-sm">
              {t.noProperties}
            </p>
          </div>
        )}

      </section>

      {/* Dynamic SVG Market trends and comparisons */}
      <section id="market-trends" className="bg-[#090E18] border-y border-emerald-950/30 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            
            {/* Column A: Interactive Custom SVG Trend Chart (8 cols) */}
            <div className="lg:col-span-7 bg-[#0b1222]/80 p-6 rounded-lg border border-slate-900">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-3">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-emerald-400" />
                    <span>{t.chartTitle}</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {lang === 'zh' ? `展示 ${chartData.trend.label} 精华楼盘监测统计数据` : `Reflecting premium indices for ${chartData.trend.label}`}
                  </p>
                </div>
                <span className="text-xs text-emerald-400 font-mono bg-emerald-950/30 border border-emerald-500/20 px-2 py-0.5 rounded">
                  {t.chartUnit}
                </span>
              </div>

              {/* Responsive SVG Container */}
              <div className="relative pt-2">
                <svg 
                  viewBox={`0 0 ${chartData.width} ${chartData.height}`} 
                  className="w-full h-auto overflow-visible select-none"
                >
                  {/* Grid Lines */}
                  {[0, 0.25, 0.5, 0.75, 1].map((ratio, idx) => {
                    const y = chartData.height - chartData.paddingBottom - ratio * (chartData.height - 50);
                    const labelVal = Math.round(chartData.minVal + ratio * (chartData.maxVal - chartData.minVal));
                    return (
                      <g key={idx}>
                        <line 
                          x1={chartData.paddingLeft} 
                          y1={y} 
                          x2={chartData.width - 20} 
                          y2={y} 
                          stroke="rgba(16, 185, 129, 0.08)" 
                          strokeWidth="1" 
                          strokeDasharray="4 4"
                        />
                        <text 
                          x={chartData.paddingLeft - 8} 
                          y={y + 4} 
                          fill="rgba(148, 163, 184, 0.5)" 
                          fontSize="10" 
                          fontFamily="monospace"
                          textAnchor="end"
                          className="tabular-nums"
                        >
                          ¥{labelVal.toLocaleString()}
                        </text>
                      </g>
                    );
                  })}

                  {/* Gradient fill area beneath spline */}
                  <defs>
                    <linearGradient id="chart-gradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>
                  <path 
                    d={chartData.areaD} 
                    fill="url(#chart-gradient)"
                  />

                  {/* Bezier Trend Line */}
                  <path 
                    d={chartData.pathD} 
                    fill="none" 
                    stroke="#10b981" 
                    strokeWidth="2.5" 
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />

                  {/* Data Point Dots & Labels */}
                  {chartData.points.map((p, idx) => (
                    <g key={idx} className="group cursor-pointer">
                      <circle 
                        cx={p.x} 
                        cy={p.y} 
                        r="4" 
                        fill="#070b13" 
                        stroke="#10b981" 
                        strokeWidth="2.5"
                      />
                      {/* Interactive hover circle halo */}
                      <circle 
                        cx={p.x} 
                        cy={p.y} 
                        r="8" 
                        fill="#10b981" 
                        fillOpacity="0.15"
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                      />
                      {/* Price Label above point */}
                      <text
                        x={p.x}
                        y={p.y - 10}
                        fill="#e2e8f0"
                        fontSize="9"
                        fontWeight="bold"
                        fontFamily="monospace"
                        textAnchor="middle"
                        className="tabular-nums opacity-80 group-hover:opacity-100 transition-opacity"
                      >
                        ¥{p.value.toLocaleString()}
                      </text>
                      {/* Date label at bottom */}
                      <text
                        x={p.x}
                        y={chartData.height - 10}
                        fill="rgba(148, 163, 184, 0.6)"
                        fontSize="10"
                        textAnchor="middle"
                      >
                        {p.date}
                      </text>
                    </g>
                  ))}
                </svg>
              </div>

            </div>

            {/* Column B: Real Estate Comparison Matrix (5 cols) */}
            <div className="lg:col-span-5 bg-[#0b1222]/80 p-6 rounded-lg border border-slate-900 flex flex-col justify-between">
              <div>
                <h3 className="text-lg font-bold text-white mb-2">
                  {t.comparisonTitle}
                </h3>
                <p className="text-xs text-slate-500 mb-6">
                  {t.comparisonSub}
                </p>

                {/* City Selector pair */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div>
                    <label className="text-[10px] uppercase font-mono text-slate-500 block mb-1.5">{lang === 'zh' ? '基准城市 A' : 'Base City A'}</label>
                    <select 
                      value={compCityA} 
                      onChange={(e) => setCompCityA(e.target.value)}
                      className="w-full bg-[#070b13] border border-slate-800 text-xs rounded p-2 text-slate-300 focus:outline-none focus:border-emerald-500/50"
                    >
                      {['Beijing', 'Shanghai', 'Shenzhen', 'Guangzhou', 'Hangzhou', 'Chengdu'].map(city => (
                        <option key={city} value={city}>{city}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] uppercase font-mono text-slate-500 block mb-1.5">{lang === 'zh' ? '比对城市 B' : 'Target City B'}</label>
                    <select 
                      value={compCityB} 
                      onChange={(e) => setCompCityB(e.target.value)}
                      className="w-full bg-[#070b13] border border-slate-800 text-xs rounded p-2 text-slate-300 focus:outline-none focus:border-emerald-500/50"
                    >
                      {['Beijing', 'Shanghai', 'Shenzhen', 'Guangzhou', 'Hangzhou', 'Chengdu'].map(city => (
                        <option key={city} value={city}>{city}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Micro comparisons */}
                <div className="space-y-4 font-mono text-xs">
                  
                  <div className="border-b border-slate-900 pb-2">
                    <span className="text-[10px] uppercase text-slate-500 block mb-1">{t.statAveragePrice}</span>
                    <div className="flex justify-between text-white font-bold">
                      <span className="tabular-nums">¥{STATS_DATA[compCityA]?.price.toLocaleString()}/㎡</span>
                      <span className="text-slate-600">vs</span>
                      <span className="tabular-nums">¥{STATS_DATA[compCityB]?.price.toLocaleString()}/㎡</span>
                    </div>
                  </div>

                  <div className="border-b border-slate-900 pb-2">
                    <span className="text-[10px] uppercase text-slate-500 block mb-1">{t.statYoY}</span>
                    <div className="flex justify-between font-bold">
                      <span className="text-emerald-400">{STATS_DATA[compCityA]?.yoy}</span>
                      <span className="text-slate-600">vs</span>
                      <span className="text-emerald-400">{STATS_DATA[compCityB]?.yoy}</span>
                    </div>
                  </div>

                  <div className="border-b border-slate-900 pb-2">
                    <span className="text-[10px] uppercase text-slate-500 block mb-1">{t.statVolume}</span>
                    <div className="flex justify-between text-white font-bold">
                      <span>{STATS_DATA[compCityA]?.volume}㎡</span>
                      <span className="text-slate-600">vs</span>
                      <span>{STATS_DATA[compCityB]?.volume}㎡</span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[10px] uppercase text-slate-500 block mb-1">{t.policyOutlook}</span>
                    <div className="grid grid-cols-2 gap-4 text-slate-400 leading-relaxed font-sans text-[11px]">
                      <div>
                        {lang === 'zh' ? STATS_DATA[compCityA]?.restrictionZh : STATS_DATA[compCityA]?.restrictionEn}
                      </div>
                      <div className="border-l border-slate-900 pl-3">
                        {lang === 'zh' ? STATS_DATA[compCityB]?.restrictionZh : STATS_DATA[compCityB]?.restrictionEn}
                      </div>
                    </div>
                  </div>

                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-950 text-right">
                <span className="text-[10px] text-slate-500 font-mono uppercase block">{lang === 'zh' ? '研判建议' : 'VALUATIONS ADVISORY'}</span>
                <span className="text-sm text-[#bf9f62] font-semibold">
                  {lang === 'zh' ? '配置多元化资产以平抑政策调控波动' : 'Diversified exposure recommended to hedge macro cycles'}
                </span>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* Financial Workspace: Interactive Mortgage Calculator */}
      <section id="mortgage-calculator" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="bg-[#0b1222] rounded-lg border border-slate-900 overflow-hidden shadow-2xl">
          
          <div className="p-6 sm:p-8 border-b border-slate-900 bg-gradient-to-r from-[#0c162b] to-[#0a1122]">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2.5">
              <Calculator className="h-6 w-6 text-emerald-400" />
              <span>{t.calculatorTitle}</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {t.calcSub}
            </p>
          </div>

          <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-10">
            
            {/* Input fields (5 cols) */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Property price input */}
              <div>
                <label className="text-xs font-mono text-slate-400 uppercase block mb-2">{t.propertyPrice}</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-500 font-semibold font-mono">¥</span>
                  <input 
                    type="number"
                    value={calcPrice}
                    onChange={(e) => setCalcPrice(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-900 hover:border-slate-800 rounded p-3 pl-8 text-slate-200 focus:outline-none focus:border-emerald-500/50 font-mono text-sm tabular-nums"
                  />
                  <span className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 text-xs font-semibold">{lang === 'zh' ? '元' : 'CNY'}</span>
                </div>
                {/* Visual price label */}
                <span className="text-[11px] text-slate-500 mt-1.5 block font-mono">
                  {lang === 'zh' ? '约：' : 'Approx: '} <strong className="text-emerald-400">¥{(calcPrice / 10000).toLocaleString()}{lang === 'zh' ? ' 万' : ' Ten-Thousand'}</strong>
                </span>
              </div>

              {/* Down payment rate selector */}
              <div>
                <label className="text-xs font-mono text-slate-400 uppercase block mb-2">{t.downPaymentRate}</label>
                <div className="grid grid-cols-4 gap-2">
                  {[15, 20, 30, 40].map((rate) => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => setDownPaymentPct(rate)}
                      className={`py-2 rounded text-xs font-mono transition-all ${downPaymentPct === rate ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-950 border border-slate-900 text-slate-400 hover:text-slate-200'}`}
                    >
                      {rate}%
                    </button>
                  ))}
                </div>
              </div>

              {/* Loan Term input */}
              <div>
                <label className="text-xs font-mono text-slate-400 uppercase block mb-2">{t.loanTerm}</label>
                <div className="grid grid-cols-3 gap-2">
                  {[10, 20, 30].map((yr) => (
                    <button
                      key={yr}
                      type="button"
                      onClick={() => setTermYears(yr)}
                      className={`py-2 rounded text-xs font-mono transition-all ${termYears === yr ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-950 border border-slate-900 text-slate-400 hover:text-slate-200'}`}
                    >
                      {yr} {lang === 'zh' ? '年' : 'Years'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Interest Rate */}
              <div>
                <label className="text-xs font-mono text-slate-400 uppercase block mb-2">{t.annualRate}</label>
                <div className="relative">
                  <input 
                    type="number"
                    step="0.05"
                    value={interestRate}
                    onChange={(e) => setInterestRate(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-900 hover:border-slate-800 rounded p-3 pr-8 text-slate-200 focus:outline-none focus:border-emerald-500/50 font-mono text-sm"
                  />
                  <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 font-mono font-bold text-sm">%</span>
                </div>
                {/* Presets */}
                <div className="flex gap-2 mt-2">
                  <button 
                    onClick={() => setInterestRate(3.35)}
                    className="text-[10px] font-mono text-emerald-400 bg-emerald-950/25 border border-emerald-500/20 px-2 py-1 rounded"
                  >
                    LPR oct2026 (3.35%)
                  </button>
                  <button 
                    onClick={() => setInterestRate(3.00)}
                    className="text-[10px] font-mono text-[#bf9f62] bg-[#bf9f62]/10 border border-[#bf9f62]/20 px-2 py-1 rounded"
                  >
                    Special Talent (3.00%)
                  </button>
                </div>
              </div>

              {/* Payment Method (PBOC standards Equal Principal/Interest) */}
              <div>
                <label className="text-xs font-mono text-slate-400 uppercase block mb-2">{t.paymentMethod}</label>
                <div className="space-y-2">
                  <label className="flex items-center gap-2.5 p-3 rounded bg-slate-950 border border-slate-900 cursor-pointer text-xs">
                    <input 
                      type="radio" 
                      name="calcMethod"
                      checked={calcMethod === 'equalInterest'}
                      onChange={() => setCalcMethod('equalInterest')}
                      className="accent-emerald-500"
                    />
                    <span className={calcMethod === 'equalInterest' ? 'text-white font-bold' : 'text-slate-400'}>
                      {t.method1}
                    </span>
                  </label>

                  <label className="flex items-center gap-2.5 p-3 rounded bg-slate-950 border border-slate-900 cursor-pointer text-xs">
                    <input 
                      type="radio" 
                      name="calcMethod"
                      checked={calcMethod === 'equalPrincipal'}
                      onChange={() => setCalcMethod('equalPrincipal')}
                      className="accent-emerald-500"
                    />
                    <span className={calcMethod === 'equalPrincipal' ? 'text-white font-bold' : 'text-slate-400'}>
                      {t.method2}
                    </span>
                  </label>
                </div>
              </div>

            </div>

            {/* Output dashboard (7 cols) with Tabular figures and comparison metrics */}
            <div className="lg:col-span-7 flex flex-col justify-between bg-slate-950 p-6 rounded-lg border border-slate-900">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                
                <div className="border-b border-slate-900 pb-4">
                  <span className="text-[10px] text-slate-500 font-mono uppercase block mb-1">{t.totalLoan}</span>
                  <span className="text-2xl font-black text-white font-mono tabular-nums">
                    ¥{Math.round(mortgageMetrics.totalLoan).toLocaleString()}
                  </span>
                </div>

                <div className="border-b border-slate-900 pb-4">
                  <span className="text-[10px] text-slate-500 font-mono uppercase block mb-1">{t.downPaymentAmount}</span>
                  <span className="text-2xl font-black text-[#bf9f62] font-mono tabular-nums">
                    ¥{Math.round(mortgageMetrics.downPaymentAmount).toLocaleString()}
                  </span>
                </div>

                <div className="border-b border-slate-900 pb-4">
                  <span className="text-[10px] text-emerald-400 font-mono uppercase block mb-1">{t.monthlyPayment}</span>
                  <div className="flex flex-col">
                    <span className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono tabular-nums">
                      ¥{Math.round(mortgageMetrics.monthlyPayment).toLocaleString()}
                    </span>
                    {calcMethod === 'equalPrincipal' && (
                      <span className="text-[10px] text-slate-400 font-mono mt-1">
                        {t.monthlyDecrease}: ¥{Math.round(mortgageMetrics.monthlyDecrease).toLocaleString()} / {lang === 'zh' ? '月' : 'Mo'}
                      </span>
                    )}
                  </div>
                </div>

                <div className="border-b border-slate-900 pb-4">
                  <span className="text-[10px] text-slate-500 font-mono uppercase block mb-1">{t.totalInterest}</span>
                  <span className="text-2xl font-black text-white font-mono tabular-nums">
                    ¥{Math.round(mortgageMetrics.totalInterest).toLocaleString()}
                  </span>
                </div>

              </div>

              {/* Total cost sum up */}
              <div className="my-8 p-4 rounded bg-[#0b1424]/80 border border-emerald-950/30 flex justify-between items-center">
                <div>
                  <span className="text-[10px] text-slate-400 font-mono uppercase block mb-0.5">{t.totalRepayment}</span>
                  <p className="text-xs text-slate-500 font-sans leading-relaxed">
                    {lang === 'zh' ? '总价本息累计（包含首付款）' : 'Sum of down-payment, total principal and interest'}
                  </p>
                </div>
                <span className="text-xl sm:text-2xl font-black text-emerald-400 font-mono tabular-nums">
                  ¥{Math.round(mortgageMetrics.totalRepayment).toLocaleString()}
                </span>
              </div>

              {/* Yearly schedule display */}
              <div className="space-y-4">
                <button 
                  onClick={() => setShowAmortization(!showAmortization)}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold rounded flex items-center justify-center gap-1 transition-all border border-slate-800"
                >
                  <FileText className="h-4 w-4 text-emerald-400" />
                  <span>{t.viewSchedule}</span>
                </button>

                {showAmortization && (
                  <div className="max-h-56 overflow-y-auto border border-slate-900 rounded bg-slate-950 text-xs font-mono text-slate-400 mt-2">
                    <table className="w-full text-left">
                      <thead className="bg-[#0b1322] sticky top-0 text-slate-400">
                        <tr>
                          <th className="p-2.5">{t.yearCol}</th>
                          <th className="p-2.5">{t.paymentCol}</th>
                          <th className="p-2.5 text-right">{t.remainingCol}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900/60 tabular-nums">
                        {mortgageMetrics.schedule.map((row) => (
                          <tr key={row.year} className="hover:bg-slate-900/50">
                            <td className="p-2.5">{lang === 'zh' ? `第 ${row.year} 年` : `Year ${row.year}`}</td>
                            <td className="p-2.5 text-slate-200">¥{Math.round(row.payment).toLocaleString()}</td>
                            <td className="p-2.5 text-right text-emerald-500">¥{Math.round(row.remaining).toLocaleString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

            </div>

          </div>

        </div>

      </section>

      {/* AI Consulting Service Workspace: Chinese Policy Expert */}
      <section id="investment-advisor" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="bg-[#0a0f1d] rounded-lg border border-slate-900 overflow-hidden shadow-2xl">
          
          <div className="p-6 sm:p-8 border-b border-slate-900 bg-gradient-to-r from-[#0d1425] to-[#0a0f1d] flex flex-col md:flex-row md:items-center justify-between gap-6">
            
            <div className="flex items-center gap-4">
              {/* generated agent_headshot loaded with fallback */}
              <div className="relative h-14 w-14 rounded-full overflow-hidden border border-emerald-500/40 shrink-0 bg-slate-950">
                <img 
                  src="/src/assets/images/agent_headshot_1791204053698.jpg" 
                  alt="HuaXun Housing Senior Research Director" 
                  className="h-full w-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                  {t.advisorTitle}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {t.advisorSub}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 self-start md:self-auto text-xs text-emerald-400 bg-emerald-950/30 border border-emerald-500/20 px-3 py-1.5 rounded font-mono">
              <Activity className="h-4 w-4 animate-pulse" />
              <span>{lang === 'zh' ? '多模模型决策链已建立' : 'Decisions linked via Server AI'}</span>
            </div>

          </div>

          <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-10">
            
            {/* Column A: Simulated Chat Screen (8 cols) */}
            <div className="lg:col-span-8 flex flex-col justify-between bg-slate-950 rounded-lg border border-slate-900 h-[480px]">
              
              {/* Chat Thread */}
              <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1">
                {advisorHistory.map((msg, i) => (
                  <div 
                    key={i} 
                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] rounded-lg p-4 text-xs leading-relaxed ${
                      msg.sender === 'user' 
                        ? 'bg-emerald-600 text-white font-semibold' 
                        : 'bg-[#0c1222] text-slate-200 border border-slate-900 shadow-sm'
                    }`}>
                      {msg.sender === 'analyst' && (
                        <div className="text-[10px] uppercase font-mono text-[#bf9f62] mb-1 font-bold">
                          {lang === 'zh' ? '华讯研究院 · 官方简报' : 'HuaXun Research · Official Brief'}
                        </div>
                      )}
                      
                      {/* Preserving text formatting lines nicely */}
                      <div className="whitespace-pre-line font-sans prose prose-invert max-w-none prose-xs">
                        {msg.text}
                      </div>
                    </div>
                  </div>
                ))}

                {isAnalyzing && (
                  <div className="flex justify-start">
                    <div className="bg-[#0c1222] border border-slate-900 rounded-lg p-4 text-xs text-slate-400 flex items-center gap-2">
                      <div className="flex gap-1">
                        <span className="h-2 w-2 bg-emerald-400 rounded-full animate-bounce"></span>
                        <span className="h-2 w-2 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                        <span className="h-2 w-2 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                      </div>
                      <span>{t.analyzingState}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Chat Input form */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  askAdvisor();
                }}
                className="p-4 border-t border-slate-900 bg-[#070b13]/40 flex gap-2"
              >
                <input 
                  type="text"
                  value={advisorInput}
                  onChange={(e) => setAdvisorInput(e.target.value)}
                  placeholder={t.askAdvisorPlaceholder}
                  disabled={isAnalyzing}
                  className="flex-1 bg-slate-950 border border-slate-900 text-xs rounded p-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500/50 disabled:opacity-50"
                />
                <button 
                  type="submit"
                  disabled={isAnalyzing || !advisorInput.trim()}
                  className="px-5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-500 text-white text-xs font-semibold rounded transition-all whitespace-nowrap"
                >
                  {t.sendQuestion}
                </button>
              </form>

            </div>

            {/* Column B: Suggested Queries & Advisory info (4 cols) */}
            <div className="lg:col-span-4 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-mono text-slate-500 uppercase block mb-3 font-bold">
                  {t.suggestedQuestions}
                </h4>

                <div className="space-y-2">
                  {PRESET_QUESTIONS.map((q, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => askAdvisor(q)}
                      className="w-full text-left p-3 rounded bg-slate-950 hover:bg-slate-900 border border-slate-900 text-xs text-slate-300 hover:text-emerald-400 transition-all leading-relaxed flex items-start gap-2 group"
                    >
                      <MessageSquare className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span className="group-hover:translate-x-0.5 transition-transform">{q}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-slate-900 text-xs text-slate-400 space-y-3 leading-relaxed">
                <div className="flex items-center gap-1 text-[#bf9f62] font-semibold">
                  <UserCheck className="h-4 w-4" />
                  <span>{lang === 'zh' ? '多模型数据底座验证' : 'Multi-Model verification complete'}</span>
                </div>
                <p>
                  {lang === 'zh' 
                    ? '政策研判由华讯北京与深圳数据分中心进行每日调和，保证限购层级与PBOC最新的LPR利率参数保持完美对齐。' 
                    : 'Analytical models are recalibrated daily with PBOC regulatory circulars to map regional purchasing boundaries accurately.'}
                </p>
              </div>

            </div>

          </div>

        </div>

      </section>

      {/* Footer Section */}
      <footer className="bg-[#04070d] border-t border-emerald-950/40 py-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          
          <div className="flex items-center gap-2">
            <Building2 className="h-4 w-4 text-emerald-400" />
            <span className="font-bold text-slate-300 font-mono tracking-tight">{t.title}</span>
            <span className="text-slate-700">|</span>
            <span>{t.subtitle}</span>
          </div>

          <div className="flex items-center gap-6 text-slate-400">
            <span>© 2026 {lang === 'zh' ? '华讯集团全球研究中心' : 'HuaXun Real Estate Group'}. All Rights Reserved.</span>
          </div>

        </div>
      </footer>

      {/* Property Details Modal Profile */}
      {activeProperty && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0b1222] border border-slate-800 rounded-lg max-w-2xl w-full overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
            
            {/* Header image */}
            <div className="relative h-60 bg-slate-950 shrink-0">
              <img 
                src={activeProperty.image} 
                alt={lang === 'zh' ? activeProperty.titleZh : activeProperty.titleEn} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0b1222] via-transparent to-transparent"></div>
              
              <button 
                onClick={() => setActiveProperty(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/60 text-white hover:bg-emerald-600 transition-colors"
                aria-label="Close modal"
              >
                <X className="h-4 w-4" />
              </button>

              <span className="absolute bottom-4 left-6 px-3 py-1 rounded bg-[#070b13]/90 border border-slate-800 text-xs font-mono tracking-wider text-emerald-400">
                {activeProperty.city.toUpperCase()} · {activeProperty.cityZh}
              </span>
            </div>

            {/* Modal Body */}
            <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
              
              <div>
                <h3 className="text-xl sm:text-2xl font-bold text-white">
                  {lang === 'zh' ? activeProperty.titleZh : activeProperty.titleEn}
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  {lang === 'zh' ? `${activeProperty.cityZh}·${activeProperty.districtZh}行政核心圈尊享` : `Premier Residential Asset within ${activeProperty.districtEn}, ${activeProperty.city}`}
                </p>
              </div>

              {/* Zero-Pill detailed stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded bg-slate-950 border border-slate-900/60 font-mono text-xs text-slate-400">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block mb-0.5">{lang === 'zh' ? '建筑面积' : 'Build Area'}</span>
                  <span className="text-sm font-semibold text-white tabular-nums">{activeProperty.area} ㎡</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block mb-0.5">{lang === 'zh' ? '户型居室' : 'Interior Rooms'}</span>
                  <span className="text-sm font-semibold text-white">{lang === 'zh' ? activeProperty.roomsZh : activeProperty.roomsEn}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block mb-0.5">{lang === 'zh' ? '年同比升幅' : 'YoY Appreciation'}</span>
                  <span className="text-sm font-semibold text-emerald-400 tabular-nums">{activeProperty.appreciation}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block mb-0.5">{lang === 'zh' ? '竣工年份' : 'Year Built'}</span>
                  <span className="text-sm font-semibold text-white tabular-nums">{activeProperty.yearBuilt}</span>
                </div>
              </div>

              {/* Details and Core Values */}
              <div className="space-y-3">
                <h4 className="text-xs font-mono uppercase text-slate-400 font-bold tracking-wider">{t.featuresTitle}</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300 font-sans">
                  {(lang === 'zh' ? activeProperty.featuresZh : activeProperty.featuresEn).map((f, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="h-1.5 w-1.5 bg-[#bf9f62] rounded-full shrink-0"></span>
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial calculations preview */}
              <div className="p-4 rounded border border-emerald-950/20 bg-gradient-to-br from-[#0c162b] to-[#0a1b24] flex items-center justify-between gap-4">
                <div>
                  <span className="text-[10px] text-slate-400 font-mono uppercase block mb-0.5">{lang === 'zh' ? '资产评估估值' : 'Valuation Benchmark'}</span>
                  <span className="text-xl font-bold text-white font-mono tabular-nums">
                    ¥{(activeProperty.price / 10000).toLocaleString()}{lang === 'zh' ? ' 万' : ' Ten-Thousand'}
                  </span>
                </div>
                <button 
                  onClick={() => {
                    loadInCalculator(activeProperty.price);
                    setActiveProperty(null);
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded flex items-center gap-1 transition-all"
                >
                  <Calculator className="h-4 w-4" />
                  <span>{lang === 'zh' ? '测算本套月供' : 'Calculate Amortization'}</span>
                </button>
              </div>

            </div>

            {/* Modal Actions */}
            <div className="p-6 bg-slate-950 border-t border-slate-900 flex justify-between gap-3 shrink-0">
              <button 
                onClick={() => setActiveProperty(null)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold rounded transition-all"
              >
                {t.closeBtn}
              </button>

              <button 
                onClick={() => {
                  setActiveProperty(null);
                  setInquiryModalOpen(true);
                }}
                className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white text-xs font-semibold rounded shadow-md active:translate-y-px transition-all"
              >
                {t.scheduleTour}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Inquiry Schedule Modal */}
      {inquiryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#0b1222] border border-slate-800 rounded-lg max-w-md w-full overflow-hidden shadow-2xl">
            
            <div className="p-6 border-b border-slate-900 bg-gradient-to-r from-[#0d1425] to-[#0a0f1d] flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-white">
                  {lang === 'zh' ? '提交认购及咨询意向' : 'Submit Acquisition Interest'}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {lang === 'zh' ? '对接华讯高净值住宅资产投资顾问' : 'Secure communication channel with primary brokers'}
                </p>
              </div>
              <button 
                onClick={resetInquiry}
                className="p-1.5 rounded-full text-slate-400 hover:text-white"
                aria-label="Close modal"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {inquirySuccess ? (
              <div className="p-8 text-center space-y-4">
                <div className="h-12 w-12 rounded-full bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-400 text-xl font-bold">
                  ✓
                </div>
                <h4 className="text-base font-bold text-white">
                  {lang === 'zh' ? '意向提交成功' : 'Registration Complete'}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed max-w-xs mx-auto">
                  {lang === 'zh' 
                    ? '我们的投资顾问代表将在两个工作小时内与您联系，并向您的邮箱发送加密的PDF机构报告。' 
                    : 'A primary broker representative will contact you within two business hours and deliver your encrypted portfolio PDF.'}
                </p>
                <button 
                  onClick={resetInquiry}
                  className="px-6 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold rounded transition-all mt-4"
                >
                  {t.closeBtn}
                </button>
              </div>
            ) : (
              <form onSubmit={handleInquirySubmit} className="p-6 space-y-4">
                
                <div>
                  <label className="text-xs font-mono text-slate-400 uppercase block mb-1.5">{lang === 'zh' ? '贵宾姓名' : 'Client Name'}</label>
                  <input 
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder={lang === 'zh' ? '请输入您的姓名' : 'Enter your name'}
                    className="w-full bg-slate-950 border border-slate-900 rounded p-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500/50"
                  />
                </div>

                <div>
                  <label className="text-xs font-mono text-slate-400 uppercase block mb-1.5">{lang === 'zh' ? '联系方式 (电话/微信/邮箱)' : 'Contact (Phone/WeChat/Email)'}</label>
                  <input 
                    type="text"
                    required
                    value={clientContact}
                    onChange={(e) => setClientContact(e.target.value)}
                    placeholder={lang === 'zh' ? '电话号码或电子邮箱' : 'Phone number or email address'}
                    className="w-full bg-slate-950 border border-slate-900 rounded p-2.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-500/50"
                  />
                </div>

                <div className="pt-4 border-t border-slate-900/60 flex justify-end gap-3">
                  <button 
                    type="button"
                    onClick={resetInquiry}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold rounded transition-all"
                  >
                    {lang === 'zh' ? '取消' : 'Cancel'}
                  </button>
                  <button 
                    type="submit"
                    disabled={isAnalyzing}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded shadow-md active:translate-y-px transition-all"
                  >
                    {lang === 'zh' ? '提交申请' : 'Register Request'}
                  </button>
                </div>

              </form>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
