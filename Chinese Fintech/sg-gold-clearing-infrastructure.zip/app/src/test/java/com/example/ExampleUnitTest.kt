package com.example

import com.example.engine.CryptoLedgerUtils
import com.example.engine.DvpSettlementEngine
import com.example.engine.GoldLedgerEngine
import com.example.engine.MarginAndRiskEngine
import com.example.engine.NovationAndNettingEngine
import com.example.model.BarAllocationStatus
import com.example.model.BarWeightClass
import com.example.model.DeliveryType
import com.example.model.GoldBar
import com.example.model.LedgerType
import com.example.model.SettlementObligation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testGoldLedgerInvariant() {
        val ledgerEngine = GoldLedgerEngine()

        val bar1 = GoldBar(
            barId = "BAR-001",
            serialNumber = "SGC-400-001",
            refiner = "Valcambi SA",
            brand = "Valcambi",
            fineness = 999.9,
            weightClass = BarWeightClass.BAR_400_OZ,
            grossWeightKg = 12.4414,
            fineGoldWeightKg = 12.44,
            manufactureDate = "2026-01-01",
            assayReference = "ASSAY-001",
            origin = "Switzerland",
            currentVaultId = "VLT-SG-CENTRAL",
            vaultName = "Singapore Central Vault",
            ownerMemberId = "SGBB",
            allocationStatus = BarAllocationStatus.ALLOCATED
        )

        val bar2 = GoldBar(
            barId = "BAR-002",
            serialNumber = "SGC-400-002",
            refiner = "Metalor SA",
            brand = "Metalor",
            fineness = 999.9,
            weightClass = BarWeightClass.BAR_1_KG,
            grossWeightKg = 1.0,
            fineGoldWeightKg = 1.0,
            manufactureDate = "2026-01-01",
            assayReference = "ASSAY-002",
            origin = "Switzerland",
            currentVaultId = "VLT-SG-CENTRAL",
            vaultName = "Singapore Central Vault",
            ownerMemberId = "MAC",
            allocationStatus = BarAllocationStatus.UNALLOCATED
        )

        val bars = listOf(bar1, bar2)
        val invariantHolds = ledgerEngine.checkGoldLedgerInvariant(bars)
        assertTrue("Gold ledger invariant must hold: Total = Allocated + Unallocated", invariantHolds)
    }

    @Test
    fun testNovationEngineCreatesCcpLegs() {
        val novationEngine = NovationAndNettingEngine()
        val trades = novationEngine.novateBilateralTrade(
            originalTradeId = "TRD-100",
            buyerMemberId = "MAC",
            sellerMemberId = "SGBB",
            instrument = "XAU/SGD",
            quantityKg = 50.0,
            price = 110470.0,
            currency = "SGD",
            deliveryType = DeliveryType.DVP_PHYSICAL_VAULT,
            goldPriceSgdPerKg = 110470.0
        )

        assertEquals(2, trades.size)
        assertEquals("MAC", trades[0].buyerMemberId)
        assertEquals("SG-GOLD-CLEAR-CCP", trades[0].sellerMemberId)
        assertEquals("SG-GOLD-CLEAR-CCP", trades[1].buyerMemberId)
        assertEquals("SGBB", trades[1].sellerMemberId)
    }

    @Test
    fun testMarginHaircuts() {
        val marginEngine = MarginAndRiskEngine()
        val eligible = marginEngine.calculateEligibleCollateral(cashSgd = 100_000_000.0, goldCollateralValueSgd = 50_000_000.0)
        // 100M * 0.98 + 50M * 0.92 = 98M + 46M = 144M
        assertEquals(144_000_000.0, eligible, 0.001)
    }

    @Test
    fun testCryptoSha256LedgerHashing() {
        val hash = CryptoLedgerUtils.calculateHash("E1", "EVT1", "2026-10-05", "CASH", "ACC1", 100.0, "SGD", "PREV_HASH")
        assertNotNull(hash)
        assertEquals(64, hash.length)
    }
}
