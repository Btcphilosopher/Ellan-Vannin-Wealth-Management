package com.example.model

import com.example.engine.DvpSettlementEngine
import com.example.engine.GoldLedgerEngine
import com.example.engine.MarginAndRiskEngine
import com.example.engine.MarketPriceEngine
import com.example.engine.NovationAndNettingEngine
import com.example.engine.ReconciliationEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClearingRepository {

    val marketEngine = MarketPriceEngine()
    val ledgerEngine = GoldLedgerEngine()
    val novationEngine = NovationAndNettingEngine()
    val marginEngine = MarginAndRiskEngine()
    val dvpEngine = DvpSettlementEngine()
    val reconciliationEngine = ReconciliationEngine()

    private val _members = MutableStateFlow<List<ClearingMember>>(emptyList())
    val members: StateFlow<List<ClearingMember>> = _members.asStateFlow()

    private val _vaults = MutableStateFlow<List<VaultFacility>>(emptyList())
    val vaults: StateFlow<List<VaultFacility>> = _vaults.asStateFlow()

    private val _bars = MutableStateFlow<List<GoldBar>>(emptyList())
    val bars: StateFlow<List<GoldBar>> = _bars.asStateFlow()

    private val _clearedTrades = MutableStateFlow<List<ClearedTrade>>(emptyList())
    val clearedTrades: StateFlow<List<ClearedTrade>> = _clearedTrades.asStateFlow()

    private val _netPositions = MutableStateFlow<Map<String, NetPosition>>(emptyMap())
    val netPositions: StateFlow<Map<String, NetPosition>> = _netPositions.asStateFlow()

    private val _marginCalls = MutableStateFlow<List<MarginCall>>(emptyList())
    val marginCalls: StateFlow<List<MarginCall>> = _marginCalls.asStateFlow()

    private val _settlements = MutableStateFlow<List<SettlementObligation>>(emptyList())
    val settlements: StateFlow<List<SettlementObligation>> = _settlements.asStateFlow()

    private val _exceptions = MutableStateFlow<List<ReconciliationException>>(emptyList())
    val exceptions: StateFlow<List<ReconciliationException>> = _exceptions.asStateFlow()

    private val _defaultWaterfall = MutableStateFlow(DefaultWaterfallState())
    val defaultWaterfall: StateFlow<DefaultWaterfallState> = _defaultWaterfall.asStateFlow()

    private val _scenarios = MutableStateFlow<List<StressScenario>>(emptyList())
    val scenarios: StateFlow<List<StressScenario>> = _scenarios.asStateFlow()

    private val _demoStepIndex = MutableStateFlow(0)
    val demoStepIndex: StateFlow<Int> = _demoStepIndex.asStateFlow()

    private val _demoLogs = MutableStateFlow<List<String>>(emptyList())
    val demoLogs: StateFlow<List<String>> = _demoLogs.asStateFlow()

    init {
        seedSyntheticData()
    }

    fun seedSyntheticData(seed: Long = 42L) {
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

        // 1. Vault Facilities in Singapore
        val v1 = VaultFacility(
            vaultId = "VLT-SG-CENTRAL",
            name = "Singapore Central Bullion Vault",
            location = "Changi South Logistics Park, Singapore",
            maxCapacityTonnes = 150.0,
            occupiedTonnes = 84.5,
            barCount = 6780,
            securityLevel = "TIER-1 ARMORED VAULT",
            inspectionStatus = "AUDITED - MAS COMPLIANT",
            physicalGoldTonnes = 84.5,
            digitalGoldTonnes = 84.5,
            encumberedGoldTonnes = 12.0
        )
        val v2 = VaultFacility(
            vaultId = "VLT-CHANGI-FREEPORT",
            name = "Changi Freeport Security Vault",
            location = "Singapore Freeport, Changi Airport Zone",
            maxCapacityTonnes = 200.0,
            occupiedTonnes = 112.3,
            barCount = 9025,
            securityLevel = "CUSTOMS BONDED TIER-1",
            inspectionStatus = "AUDITED CLEAN",
            physicalGoldTonnes = 112.3,
            digitalGoldTonnes = 112.3,
            encumberedGoldTonnes = 18.5
        )
        val v3 = VaultFacility(
            vaultId = "VLT-JURONG-METALS",
            name = "Jurong Metals & Logistics Vault",
            location = "Jurong Industrial Hub, Singapore",
            maxCapacityTonnes = 100.0,
            occupiedTonnes = 42.1,
            barCount = 3380,
            securityLevel = "TIER-2 HIGH SECURITY",
            inspectionStatus = "AUDITED CLEAN",
            physicalGoldTonnes = 42.1,
            digitalGoldTonnes = 42.1,
            encumberedGoldTonnes = 5.2
        )
        val v4 = VaultFacility(
            vaultId = "VLT-MARINA-INST",
            name = "Marina Bay Institutional Vault",
            location = "Marina Bay Financial Centre Sub-level",
            maxCapacityTonnes = 80.0,
            occupiedTonnes = 32.8,
            barCount = 2640,
            securityLevel = "BANK GRADE TIER-1",
            inspectionStatus = "AUDITED CLEAN",
            physicalGoldTonnes = 32.8,
            digitalGoldTonnes = 32.8,
            encumberedGoldTonnes = 4.0
        )
        val v5 = VaultFacility(
            vaultId = "VLT-TUAS-FREEPORT",
            name = "Tuas Freeport Mega Vault",
            location = "Tuas Port Precinct, Singapore",
            maxCapacityTonnes = 120.0,
            occupiedTonnes = 15.7,
            barCount = 1260,
            securityLevel = "TIER-1 HIGH SECURITY",
            inspectionStatus = "AUDITED CLEAN",
            physicalGoldTonnes = 15.7,
            digitalGoldTonnes = 15.7,
            encumberedGoldTonnes = 1.0
        )
        _vaults.value = listOf(v1, v2, v3, v4, v5)

        // 2. Synthetic Clearing Members
        val m1 = ClearingMember(
            memberId = "SGBB",
            legalName = "Singapore Bullion Bank Pte Ltd",
            jurisdiction = "Singapore (MAS Regulated)",
            status = MemberStatus.ACTIVE,
            grossLongKg = 812.4,
            grossShortKg = 593.7,
            netPositionKg = 218.7,
            allocatedGoldKg = 176.2,
            unallocatedGoldKg = 42.5,
            cashCollateralSgd = 82_400_000.0,
            goldCollateralSgd = 20_000_000.0,
            initialMarginRequiredSgd = 61_700_000.0,
            variationMarginSgd = 0.0,
            vaultAccessList = listOf("VLT-SG-CENTRAL", "VLT-CHANGI-FREEPORT")
        )
        val m2 = ClearingMember(
            memberId = "LMB",
            legalName = "Lion Metals Bank Corp",
            jurisdiction = "Singapore / Hong Kong",
            status = MemberStatus.ACTIVE,
            grossLongKg = 640.0,
            grossShortKg = 720.0,
            netPositionKg = -80.0,
            allocatedGoldKg = 90.0,
            unallocatedGoldKg = 30.0,
            cashCollateralSgd = 55_000_000.0,
            goldCollateralSgd = 15_000_000.0,
            initialMarginRequiredSgd = 42_000_000.0,
            variationMarginSgd = 2_100_000.0,
            vaultAccessList = listOf("VLT-CHANGI-FREEPORT", "VLT-MARINA-INST")
        )
        val m3 = ClearingMember(
            memberId = "MAC",
            legalName = "Meridian Asia Commodities Ltd",
            jurisdiction = "Singapore / UK",
            status = MemberStatus.ACTIVE,
            grossLongKg = 1200.0,
            grossShortKg = 450.0,
            netPositionKg = 750.0,
            allocatedGoldKg = 600.0,
            unallocatedGoldKg = 150.0,
            cashCollateralSgd = 140_000_000.0,
            goldCollateralSgd = 30_000_000.0,
            initialMarginRequiredSgd = 110_000_000.0,
            variationMarginSgd = 0.0,
            vaultAccessList = listOf("VLT-SG-CENTRAL", "VLT-TUAS-FREEPORT")
        )
        val m4 = ClearingMember(
            memberId = "SPM",
            legalName = "Straits Precious Metals Pte Ltd",
            jurisdiction = "Singapore",
            status = MemberStatus.ACTIVE,
            grossLongKg = 300.0,
            grossShortKg = 300.0,
            netPositionKg = 0.0,
            allocatedGoldKg = 150.0,
            unallocatedGoldKg = 20.0,
            cashCollateralSgd = 35_000_000.0,
            goldCollateralSgd = 5_000_000.0,
            initialMarginRequiredSgd = 18_000_000.0,
            variationMarginSgd = 0.0,
            vaultAccessList = listOf("VLT-JURONG-METALS")
        )
        val m5 = ClearingMember(
            memberId = "PGT",
            legalName = "Pacific Gold Trading AG",
            jurisdiction = "Switzerland / Singapore Branch",
            status = MemberStatus.ACTIVE,
            grossLongKg = 410.0,
            grossShortKg = 680.0,
            netPositionKg = -270.0,
            allocatedGoldKg = 80.0,
            unallocatedGoldKg = 10.0,
            cashCollateralSgd = 68_000_000.0,
            goldCollateralSgd = 10_000_000.0,
            initialMarginRequiredSgd = 54_000_000.0,
            variationMarginSgd = 4_800_000.0,
            vaultAccessList = listOf("VLT-CHANGI-FREEPORT")
        )
        val m6 = ClearingMember(
            memberId = "NUB",
            legalName = "Nusantara Bullion Corp",
            jurisdiction = "Indonesia / Singapore",
            status = MemberStatus.MARGIN_CALL,
            grossLongKg = 150.0,
            grossShortKg = 520.0,
            netPositionKg = -370.0,
            allocatedGoldKg = 20.0,
            unallocatedGoldKg = 5.0,
            cashCollateralSgd = 28_000_000.0,
            goldCollateralSgd = 5_000_000.0,
            initialMarginRequiredSgd = 45_000_000.0,
            variationMarginSgd = 6_200_000.0,
            vaultAccessList = listOf("VLT-SG-CENTRAL")
        )
        val m7 = ClearingMember(
            memberId = "EAM",
            legalName = "East Asia Metals Corp",
            jurisdiction = "Japan / Singapore",
            status = MemberStatus.ACTIVE,
            grossLongKg = 500.0,
            grossShortKg = 200.0,
            netPositionKg = 300.0,
            allocatedGoldKg = 250.0,
            unallocatedGoldKg = 50.0,
            cashCollateralSgd = 60_000_000.0,
            goldCollateralSgd = 12_000_000.0,
            initialMarginRequiredSgd = 41_000_000.0,
            vaultAccessList = listOf("VLT-MARINA-INST")
        )
        val m8 = ClearingMember(
            memberId = "MFO",
            legalName = "Meridian Family Office Bullion Ltd",
            jurisdiction = "Singapore / UAE",
            status = MemberStatus.ACTIVE,
            grossLongKg = 220.0,
            grossShortKg = 50.0,
            netPositionKg = 170.0,
            allocatedGoldKg = 160.0,
            unallocatedGoldKg = 10.0,
            cashCollateralSgd = 32_000_000.0,
            goldCollateralSgd = 18_000_000.0,
            initialMarginRequiredSgd = 22_000_000.0,
            vaultAccessList = listOf("VLT-CHANGI-FREEPORT")
        )
        _members.value = listOf(m1, m2, m3, m4, m5, m6, m7, m8)

        // 3. Generate 30 Detailed Physical Bars for Demonstration
        val refiners = listOf("Valcambi SA - Switzerland", "Metalor SA - Switzerland", "PAMP SA - Switzerland", "Heraeus Precious Metals - Germany", "Tanaka Kikinzoku - Japan", "Perth Mint - Australia", "Rand Refinery - South Africa")
        val barList = mutableListOf<GoldBar>()

        for (i in 1..30) {
            val weightClass = when (i % 4) {
                0 -> BarWeightClass.BAR_400_OZ
                1 -> BarWeightClass.BAR_1_KG
                2 -> BarWeightClass.BAR_100_OZ
                else -> BarWeightClass.BAR_1_KG
            }
            val refiner = refiners[(i - 1) % refiners.size]
            val vault = _vaults.value[(i - 1) % _vaults.value.size]
            val owner = _members.value[(i - 1) % _members.value.size]

            val isAllocated = (i % 2 == 0)
            val allocStatus = if (isAllocated) BarAllocationStatus.ALLOCATED else BarAllocationStatus.UNALLOCATED

            val custodyHistory = listOf(
                CustodyEvent(
                    timestamp = "2026-01-15T09:00:00Z",
                    fromLocation = "$refiner Refinery Works",
                    toLocation = "In Transit - Armored Flight SQ802",
                    actor = "Brinks Global Logistics",
                    assayRef = "ASSAY-$refiner-${1000 + i}",
                    txHash = "0x892a4e7f81bc923a4d91_${i}"
                ),
                CustodyEvent(
                    timestamp = "2026-01-17T14:30:00Z",
                    fromLocation = "In Transit - Changi Customs Zone",
                    toLocation = vault.name,
                    actor = "Singapore Freeport Logistics",
                    assayRef = "ASSAY-SG-SEC-${2000 + i}",
                    txHash = "0x3f1e9c2b48a1d7e50124_${i}"
                )
            )

            val bar = GoldBar(
                barId = "BAR-SG-${10000 + i}",
                serialNumber = "SGC-${weightClass.label.take(3)}-${880000 + i}",
                refiner = refiner,
                brand = refiner.split(" ").first(),
                fineness = 999.9,
                weightClass = weightClass,
                grossWeightKg = weightClass.weightKg,
                fineGoldWeightKg = weightClass.weightKg * 0.9999,
                manufactureDate = "2025-11-${10 + (i % 15)}",
                assayReference = "ASSAY-SG-SEC-${2000 + i}",
                origin = refiner,
                currentVaultId = vault.vaultId,
                vaultName = vault.name,
                ownerMemberId = owner.memberId,
                status = "IN_VAULT",
                allocationStatus = allocStatus,
                isEncumbered = (i == 13), // 1 bar encumbered for demo assay exception
                inspectionStatus = if (i == 13) BarInspectionStatus.DISCREPANCY else BarInspectionStatus.VERIFIED,
                chainOfCustody = custodyHistory
            )
            barList.add(bar)
        }
        _bars.value = barList

        // 4. Initial Cleared Trades
        val spotSgd = marketEngine.getQuote("XAU/SGD").spot
        val t1 = novationEngine.novateBilateralTrade("TRD-8801", "SGBB", "LMB", "XAU/SGD", 100.0, spotSgd, "SGD", DeliveryType.DVP_PHYSICAL_VAULT, spotSgd)
        val t2 = novationEngine.novateBilateralTrade("TRD-8802", "MAC", "PGT", "XAU/SGD", 250.0, spotSgd, "SGD", DeliveryType.DVP_PHYSICAL_VAULT, spotSgd)
        val t3 = novationEngine.novateBilateralTrade("TRD-8803", "EAM", "NUB", "XAU/SGD", 150.0, spotSgd, "SGD", DeliveryType.DVP_PHYSICAL_VAULT, spotSgd)

        val allTrades = t1 + t2 + t3
        _clearedTrades.value = allTrades

        // 5. Net positions
        _netPositions.value = novationEngine.calculateNetPositions(allTrades, spotSgd)

        // 6. Initial Margin Calls
        val mc = marginEngine.evaluateMarginCall(m6, spotSgd)
        if (mc != null) {
            _marginCalls.value = listOf(mc)
        }

        // 7. Initial Stress Scenarios
        _scenarios.value = listOf(
            StressScenario(
                scenarioId = "SCN-GOLD-SPIKE",
                name = "Gold Spot Spike +25%",
                description = "Rapid surge in physical gold demand driven by geopolitical volatility in Asia-Pacific.",
                goldPriceChangePct = +25.0,
                fxUsdSgdChangePct = -2.0,
                projectedDeficitMembersCount = 3,
                projectedTotalMarginIncreaseSgd = 145_000_000.0,
                ccpDefaultFundDrawnSgd = 0.0
            ),
            StressScenario(
                scenarioId = "SCN-MEMBER-DEFAULT",
                name = "Major Member Default & Liquidation",
                description = "Simulate sudden insolvency of Nusantara Bullion Corp (NUB) following physical delivery failure.",
                goldPriceChangePct = +5.0,
                fxUsdSgdChangePct = +1.5,
                defaultingMemberId = "NUB",
                projectedDeficitMembersCount = 1,
                projectedTotalMarginIncreaseSgd = 42_000_000.0,
                ccpDefaultFundDrawnSgd = 0.0
            ),
            StressScenario(
                scenarioId = "SCN-VAULT-OUTAGE",
                name = "Changi Freeport Vault Logistics Lockout",
                description = "Temporary physical security lockdown at Changi Freeport facility restricting outbound gold releases.",
                goldPriceChangePct = +2.0,
                fxUsdSgdChangePct = 0.0,
                vaultOutageId = "VLT-CHANGI-FREEPORT",
                projectedDeficitMembersCount = 2,
                projectedTotalMarginIncreaseSgd = 30_000_000.0,
                ccpDefaultFundDrawnSgd = 0.0
            )
        )

        // 8. Run Initial 3-way Reconciliation
        _exceptions.value = reconciliationEngine.runThreeWayReconciliation(_clearedTrades.value, _bars.value, _vaults.value, _members.value)

        // Record Initial Ledger Event
        ledgerEngine.recordEntry(
            eventId = "EVT-SYSTEM-INIT",
            ledgerType = LedgerType.CCP_OBLIGATION,
            accountId = "SG-GOLD-CLEAR-SYSTEM",
            quantity = 287.4,
            unit = "TONNES",
            valuationSgd = 2_410_000_000.0,
            reference = "SYSTEM_BOOTSTRAP",
            actor = "SG-GOLD-CLEAR-CORE",
            reason = "INITIAL_SYNTHETIC_MARKET_STATE_SEEDED"
        )
    }

    fun submitNewBilateralTrade(
        buyerId: String,
        sellerId: String,
        instrument: String,
        quantityKg: Double,
        price: Double
    ): String {
        val origId = "TRD-${(10000..99999).random()}"
        val spotSgd = marketEngine.getQuote(instrument).spot
        val novated = novationEngine.novateBilateralTrade(
            origId, buyerId, sellerId, instrument, quantityKg, price, "SGD", DeliveryType.DVP_PHYSICAL_VAULT, spotSgd
        )

        _clearedTrades.value = _clearedTrades.value + novated
        _netPositions.value = novationEngine.calculateNetPositions(_clearedTrades.value, spotSgd)

        // Check if seller or buyer gets margin call
        val updatedMembers = _members.value.map { member ->
            if (member.memberId == buyerId) {
                member.copy(grossLongKg = member.grossLongKg + quantityKg, netPositionKg = member.netPositionKg + quantityKg)
            } else if (member.memberId == sellerId) {
                member.copy(grossShortKg = member.grossShortKg + quantityKg, netPositionKg = member.netPositionKg - quantityKg)
            } else {
                member
            }
        }
        _members.value = updatedMembers

        ledgerEngine.recordEntry(
            eventId = "EVT-TRADE-NOVATED-$origId",
            ledgerType = LedgerType.CCP_OBLIGATION,
            accountId = "CCP-NOVATION-BOOK",
            quantity = quantityKg,
            unit = "KG",
            valuationSgd = quantityKg * spotSgd,
            reference = origId,
            actor = "NOVATION-ENGINE",
            reason = "BILATERAL_TRADE_NOVATED_TO_CCP"
        )

        return origId
    }

    fun executeDvpSettlementForTrade(tradeId: String): Boolean {
        val trade = _clearedTrades.value.find { it.tradeId == tradeId || it.originalTradeId == tradeId } ?: return false

        val spotSgd = marketEngine.getQuote(trade.instrument).spot
        val obligation = SettlementObligation(
            settlementId = "SETTL-${trade.tradeId}",
            buyerMemberId = trade.buyerMemberId,
            sellerMemberId = trade.sellerMemberId,
            goldQuantityKg = trade.quantityKg,
            cashAmountSgd = trade.quantityKg * spotSgd,
            currency = "SGD",
            deliveryType = DeliveryType.DVP_PHYSICAL_VAULT,
            vaultId = "VLT-SG-CENTRAL",
            settlementDate = trade.settlementDate,
            timestampCreated = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date())
        )

        val (completedObligation, updatedBars) = dvpEngine.executeDvpSettlement(obligation, _bars.value, ledgerEngine)
        _bars.value = updatedBars

        _settlements.value = _settlements.value + completedObligation

        val updatedTrades = _clearedTrades.value.map {
            if (it.tradeId == trade.tradeId) it.copy(status = com.example.model.TradeStatus.SETTLED) else it
        }
        _clearedTrades.value = updatedTrades

        // Re-run 3-way reconciliation
        _exceptions.value = reconciliationEngine.runThreeWayReconciliation(_clearedTrades.value, _bars.value, _vaults.value, _members.value)

        return completedObligation.overallStatus == "SETTLED"
    }

    fun triggerMemberDefaultSimulation(memberId: String) {
        val member = _members.value.find { it.memberId == memberId } ?: return
        val updatedMembers = _members.value.map {
            if (it.memberId == memberId) it.copy(status = MemberStatus.DEFAULTED) else it
        }
        _members.value = updatedMembers

        // Execute Default Waterfall
        val waterfallResult = marginEngine.executeDefaultWaterfall(member, 92_000_000.0)
        _defaultWaterfall.value = waterfallResult

        ledgerEngine.recordEntry(
            eventId = "EVT-MEMBER-DEFAULT-$memberId",
            ledgerType = LedgerType.CCP_OBLIGATION,
            accountId = "DEFAULT-WATERFALL-BOOK",
            quantity = member.netPositionKg,
            unit = "KG",
            valuationSgd = 92_000_000.0,
            reference = memberId,
            actor = "RISK-CONTROL-ENGINE",
            reason = "MEMBER_DEFAULT_TRIGGERED_WATERFALL_EXECUTED"
        )
    }

    fun fundMarginCall(callId: String) {
        val calls = _marginCalls.value.map { call ->
            if (call.callId == callId) {
                call.copy(status = com.example.model.MarginCallStatus.FUNDED)
            } else call
        }
        _marginCalls.value = calls

        // Update member status
        val call = _marginCalls.value.find { it.callId == callId } ?: return
        _members.value = _members.value.map { m ->
            if (m.memberId == call.memberId) {
                m.copy(status = MemberStatus.ACTIVE, cashCollateralSgd = m.cashCollateralSgd + call.deficitSgd)
            } else m
        }
    }

    fun runThreeWayReconciliationNow() {
        _exceptions.value = reconciliationEngine.runThreeWayReconciliation(_clearedTrades.value, _bars.value, _vaults.value, _members.value)
    }

    // Interactive Demo Walkthrough
    fun setDemoStep(step: Int) {
        _demoStepIndex.value = step.coerceIn(0, 18)
    }

    fun appendDemoLog(log: String) {
        _demoLogs.value = _demoLogs.value + log
    }

    fun clearDemoLogs() {
        _demoLogs.value = emptyList()
    }
}
