package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.components.InstitutionalTopHeader
import com.example.ui.components.TerminalTabSelector
import com.example.ui.screens.ApiConsoleScreen
import com.example.ui.screens.ControlCentreScreen
import com.example.ui.screens.DemoWalkthroughScreen
import com.example.ui.screens.MemberTerminalScreen
import com.example.ui.screens.RiskScenarioScreen
import com.example.ui.screens.VaultTerminalScreen
import com.example.ui.theme.DarkBg
import com.example.ui.theme.SGGoldClearTheme
import com.example.viewmodel.ClearingViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ClearingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SGGoldClearTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DarkBg,
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    MainScreenContent(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun MainScreenContent(
    viewModel: ClearingViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTerminalTab.collectAsState()
    val quotes by viewModel.marketQuotes.collectAsState()
    val isTickerRunning by viewModel.isLiveTickerRunning.collectAsState()

    val clearedTrades by viewModel.clearedTrades.collectAsState()
    val members by viewModel.members.collectAsState()
    val netPositions by viewModel.netPositions.collectAsState()
    val marginCalls by viewModel.marginCalls.collectAsState()
    val exceptions by viewModel.exceptions.collectAsState()
    val selectedMemberId by viewModel.selectedMemberId.collectAsState()

    val vaults by viewModel.vaults.collectAsState()
    val bars by viewModel.bars.collectAsState()
    val selectedVaultId by viewModel.selectedVaultId.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedBarDetail by viewModel.selectedBarDetail.collectAsState()

    val scenarios by viewModel.scenarios.collectAsState()
    val defaultWaterfall by viewModel.defaultWaterfall.collectAsState()

    val cliOutput by viewModel.cliOutput.collectAsState()
    val apiResponseJson by viewModel.apiResponseJson.collectAsState()

    val demoStepIndex by viewModel.demoStepIndex.collectAsState()
    val demoLogs by viewModel.demoLogs.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        // Top Ticker & Header
        InstitutionalTopHeader(
            quotes = quotes,
            isTickerRunning = isTickerRunning,
            onToggleTicker = { viewModel.toggleLiveTicker() }
        )

        // Terminal Mode Tab Selector
        TerminalTabSelector(
            selectedTab = currentTab,
            onTabSelected = { viewModel.setTerminalTab(it) }
        )

        // Selected Terminal Screen
        when (currentTab) {
            0 -> ControlCentreScreen(
                clearedTrades = clearedTrades,
                members = members,
                netPositions = netPositions,
                marginCalls = marginCalls,
                exceptions = exceptions,
                onSettleTrade = { viewModel.settleTrade(it) },
                onFundMarginCall = { viewModel.fundMarginCall(it) },
                onRunReconciliation = { viewModel.runReconciliation() }
            )

            1 -> MemberTerminalScreen(
                members = members,
                selectedMemberId = selectedMemberId,
                clearedTrades = clearedTrades,
                onSelectMember = { viewModel.setSelectedMember(it) },
                onSubmitTrade = { buyer, seller, inst, qty, px ->
                    viewModel.submitTrade(buyer, seller, inst, qty, px)
                }
            )

            2 -> VaultTerminalScreen(
                vaults = vaults,
                bars = bars,
                selectedVaultId = selectedVaultId,
                searchQuery = searchQuery,
                selectedBarDetail = selectedBarDetail,
                onSelectVault = { viewModel.setSelectedVault(it) },
                onSearchQueryChange = { viewModel.setSearchQuery(it) },
                onSelectBarDetail = { viewModel.setSelectedBarDetail(it) }
            )

            3 -> RiskScenarioScreen(
                scenarios = scenarios,
                defaultWaterfall = defaultWaterfall,
                members = members,
                onTriggerDefault = { viewModel.triggerDefault(it) }
            )

            4 -> ApiConsoleScreen(
                cliOutput = cliOutput,
                apiResponseJson = apiResponseJson,
                onExecuteCli = { viewModel.executeCliCommand(it) },
                onCallApiEndpoint = { viewModel.callApiEndpoint(it) }
            )

            5 -> DemoWalkthroughScreen(
                currentStepIndex = demoStepIndex,
                demoLogs = demoLogs,
                onAdvanceStep = { viewModel.advanceDemoStep() },
                onResetWalkthrough = { viewModel.resetDemoWalkthrough() }
            )
        }
    }
}
