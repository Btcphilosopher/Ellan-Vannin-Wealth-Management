package com.example.engine

import com.example.model.ClearingMember
import com.example.model.DefaultWaterfallState
import com.example.model.MarginCall
import com.example.model.MarginCallStatus
import com.example.model.MemberStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MarginAndRiskEngine {

    /**
     * SPAN-style Margin Calculation with Concentration & Liquidity Add-ons.
     */
    fun calculateMemberMarginRequirement(
        grossLongKg: Double,
        grossShortKg: Double,
        netPositionKg: Double,
        spotPriceSgdPerKg: Double,
        marketVolatilityPct: Double = 0.12 // 12% annualised volatility
    ): Pair<Double, Double> { // Pair(InitialMargin, VariationMargin)
        val notionalValueSgd = netPositionKg * spotPriceSgdPerKg

        // SPAN base scan range (e.g. 5% price scan range)
        val baseScanRange = 0.05
        val baseInitialMargin = kotlin.math.abs(notionalValueSgd) * baseScanRange

        // Concentration add-on for large gross positions (> 500 kg)
        val totalGrossKg = grossLongKg + grossShortKg
        val concentrationMultiplier = if (totalGrossKg > 500.0) 1.25 else 1.0

        // Volatility adjustment
        val volAdjustment = (marketVolatilityPct / 0.10)

        val initialMargin = baseInitialMargin * concentrationMultiplier * volAdjustment

        // Variation Margin (M2M shock simulation)
        val variationMargin = if (netPositionKg < 0) {
            // Short position loses when gold price rises
            kotlin.math.abs(netPositionKg) * (spotPriceSgdPerKg * 0.015)
        } else {
            0.0
        }

        return Pair(initialMargin, variationMargin)
    }

    /**
     * Haircut Calculation for Collateral:
     * Gold: 8% Haircut
     * SGD Cash: 2% Haircut
     * USD Cash: 5% Haircut
     */
    fun calculateEligibleCollateral(cashSgd: Double, goldCollateralValueSgd: Double): Double {
        val eligibleCash = cashSgd * 0.98
        val eligibleGold = goldCollateralValueSgd * 0.92
        return eligibleCash + eligibleGold
    }

    /**
     * Evaluates Margin Health for a member & generates MarginCall if deficit exists.
     */
    fun evaluateMarginCall(member: ClearingMember, spotPriceSgdPerKg: Double): MarginCall? {
        val (im, vm) = calculateMemberMarginRequirement(
            member.grossLongKg, member.grossShortKg, member.netPositionKg, spotPriceSgdPerKg
        )
        val requiredTotal = im + vm
        val eligibleCollateral = calculateEligibleCollateral(member.cashCollateralSgd, member.goldCollateralSgd)

        val deficit = requiredTotal - eligibleCollateral

        if (deficit > 0) {
            val callId = "MC-${member.memberId}-${System.currentTimeMillis()}"
            val issuedTs = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date())
            val deadlineTs = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date(System.currentTimeMillis() + 14400000L)) // 4 hour deadline

            return MarginCall(
                callId = callId,
                memberId = member.memberId,
                requiredMarginSgd = requiredTotal,
                currentCollateralSgd = eligibleCollateral,
                deficitSgd = deficit,
                issuedTimestamp = issuedTs,
                deadlineTimestamp = deadlineTs,
                status = MarginCallStatus.ISSUED
            )
        }
        return null
    }

    /**
     * Default Waterfall Execution Engine.
     */
    fun executeDefaultWaterfall(
        defaulter: ClearingMember,
        lossAmountSgd: Double
    ): DefaultWaterfallState {
        var remainingLoss = lossAmountSgd

        // Stage 1: Defaulter Margin
        val defaulterMarginConsumed = remainingLoss.coerceAtMost(defaulter.initialMarginRequiredSgd)
        remainingLoss -= defaulterMarginConsumed

        // Stage 2: Defaulter Collateral
        val defaulterCollateralConsumed = remainingLoss.coerceAtMost(defaulter.totalCollateralSgd - defaulterMarginConsumed)
        remainingLoss -= defaulterCollateralConsumed

        // Stage 3: SG-GOLD CLEAR Capital (Skin-in-the-game) - Max SGD 50,000,000
        val ccpCapitalAvailable = 50_000_000.0
        val ccpCapitalUsed = remainingLoss.coerceAtMost(ccpCapitalAvailable)
        remainingLoss -= ccpCapitalUsed

        // Stage 4: Default Fund Mutualised Pool (SGD 500,000,000)
        val defaultFundAvailable = 500_000_000.0
        val defaultFundDrawn = remainingLoss.coerceAtMost(defaultFundAvailable)
        remainingLoss -= defaultFundDrawn

        // Stage 5: Mutualised Loss
        val mutualisedLoss = remainingLoss.coerceAtLeast(0.0)

        val statusText = if (remainingLoss <= 0) {
            "DEFICIT_FULL_COVERED"
        } else {
            "MUTUALISED_RECOVERY_TRIGGERED"
        }

        return DefaultWaterfallState(
            defaulterMemberId = defaulter.memberId,
            defaulterMarginConsumedSgd = defaulterMarginConsumed,
            defaulterCollateralConsumedSgd = defaulterCollateralConsumed,
            ccpCapitalUsedSgd = ccpCapitalUsed,
            defaultFundDrawnSgd = defaultFundDrawn,
            mutualisedLossSgd = mutualisedLoss,
            recoveryStatus = statusText
        )
    }
}
