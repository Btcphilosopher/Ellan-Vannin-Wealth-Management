package com.example.engine

import com.example.model.ClearedTrade
import com.example.model.ClearingMember
import com.example.model.ExceptionSeverity
import com.example.model.ExceptionStatus
import com.example.model.GoldBar
import com.example.model.ReconciliationException
import com.example.model.VaultFacility
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReconciliationEngine {

    /**
     * Executes three-way reconciliation across Market Trades, Ledger, and Physical Vault Facilities.
     */
    fun runThreeWayReconciliation(
        clearedTrades: List<ClearedTrade>,
        bars: List<GoldBar>,
        vaults: List<VaultFacility>,
        members: List<ClearingMember>
    ): List<ReconciliationException> {
        val exceptions = mutableListOf<ReconciliationException>()
        val ts = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date())

        // Check 1: Vault Physical Bar Weight vs Recorded Facility Tonnes
        for (vault in vaults) {
            val barsInVault = bars.filter { it.currentVaultId == vault.vaultId }
            val actualPhysicalKg = barsInVault.sumOf { it.fineGoldWeightKg }
            val recordedKg = vault.occupiedTonnes * 1000.0

            val diffKg = kotlin.math.abs(actualPhysicalKg - recordedKg)
            if (diffKg > 0.001) {
                exceptions.add(
                    ReconciliationException(
                        exceptionId = "EXC-VAULT-WEIGHT-${vault.vaultId}-${(1000..9999).random()}",
                        timestamp = ts,
                        type = "WEIGHT_MISMATCH",
                        severity = ExceptionSeverity.HIGH,
                        facilityOrMemberId = vault.vaultId,
                        description = "Vault ${vault.name}: Physical bar sum (${"%.3f".format(actualPhysicalKg)} kg) differs from facility balance (${"%.3f".format(recordedKg)} kg). Discrepancy: ${"%.3f".format(diffKg)} kg.",
                        status = ExceptionStatus.OPEN
                    )
                )
            }
        }

        // Check 2: Member Allocated Bars vs Member Ledger Balance
        for (member in members) {
            val allocatedBars = bars.filter { it.ownerMemberId == member.memberId && it.allocationStatus == com.example.model.BarAllocationStatus.ALLOCATED }
            val totalAllocatedKg = allocatedBars.sumOf { it.fineGoldWeightKg }

            if (kotlin.math.abs(totalAllocatedKg - member.allocatedGoldKg) > 0.001) {
                exceptions.add(
                    ReconciliationException(
                        exceptionId = "EXC-MEMBER-BAL-${member.memberId}-${(1000..9999).random()}",
                        timestamp = ts,
                        type = "UNEXPLAINED_BALANCE",
                        severity = ExceptionSeverity.MEDIUM,
                        facilityOrMemberId = member.memberId,
                        description = "Member ${member.legalName}: Allocated bar count fine weight (${"%.3f".format(totalAllocatedKg)} kg) does not match member recorded allocated balance (${"%.3f".format(member.allocatedGoldKg)} kg).",
                        status = ExceptionStatus.OPEN
                    )
                )
            }
        }

        // Check 3: Uninspected / Discrepancy Bars
        val discrepancyBars = bars.filter { it.inspectionStatus == com.example.model.BarInspectionStatus.DISCREPANCY }
        for (bar in discrepancyBars) {
            exceptions.add(
                ReconciliationException(
                    exceptionId = "EXC-BAR-ASSAY-${bar.barId}",
                    timestamp = ts,
                    type = "DISCREPANCY_ASSAY",
                    severity = ExceptionSeverity.CRITICAL,
                    facilityOrMemberId = bar.currentVaultId,
                    description = "Bar ${bar.serialNumber} (${bar.refiner}) failed secondary assay check at ${bar.vaultName}. Encumbered for investigation.",
                    status = ExceptionStatus.OPEN
                )
            )
        }

        return exceptions
    }
}
