package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SG-GOLD CLEAR Institutional Palette
val DarkBg = Color(0xFF0F141A)          // Warm Graphite / Deep Charcoal
val SurfaceDark = Color(0xFF161C24)     // Card Surface
val SurfaceElevated = Color(0xFF1E2631) // Elevated Card / Modal
val BorderDark = Color(0xFF2B3644)      // Divider & Card Borders

// Primary Accent - Singapore Gold
val GoldPrimary = Color(0xFFD4AF37)     // Brushed Gold
val GoldVariant = Color(0xFFF3E5AB)     // Pale Gold Highlight
val GoldDark = Color(0xFFAA820A)        // Muted Bronze

// Institutional Accents
val SingaporeRed = Color(0xFFD62828)    // Singapore National Red (used sparingly)
val NavyDeep = Color(0xFF0D1B2A)        // Institutional Navy
val SteelGrey = Color(0xFF8D99AE)       // Subtitle / Label Grey
val TextPrimary = Color(0xFFF1F5F9)     // Pure Cool White
val TextSecondary = Color(0xFF94A3B8)   // Muted Text

// Status Indicators
val StatusGreen = Color(0xFF2EC4B6)     // Active / Settled / Clean
val StatusAmber = Color(0xFFFF9F1C)     // Pending / Margin Call
val StatusRed = Color(0xFFE71D36)       // Deficit / Exception / Default
val StatusBlue = Color(0xFF3A86FF)      // Novated / In Vault

val GlassCardBg = Color(0xCC1A232E)     // Glassmorphic Panel Overlay
