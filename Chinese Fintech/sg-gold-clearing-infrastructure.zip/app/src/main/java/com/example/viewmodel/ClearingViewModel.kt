package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.BarAllocationStatus
import com.example.model.ClearingMember
import com.example.model.ClearingRepository
import com.example.model.GoldBar
import com.example.model.LedgerEntry
import com.example.model.MarginCall
import com.example.model.NetPosition
import com.example.model.ReconciliationException
import com.example.model.SettlementObligation
import com.example.model.StressScenario
import com.example.model.VaultFacility
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ClearingViewModel(
    val repository: ClearingRepository = ClearingRepository()
) : ViewModel() {

    private val _currentTerminalTab = MutableStateFlow(0) // 0: CCP Control, 1: Member Terminal, 2: Vault Terminal, 3: Risk Lab, 4: API & CLI, 5: Demo Step
    val currentTerminalTab: StateFlow<Int> = _currentTerminalTab.asStateFlow()

    private val _selectedMemberId = MutableStateFlow("SGBB")
    val selectedMemberId: StateFlow<String> = _selectedMemberId.asStateFlow()

    private val _selectedVaultId = MutableStateFlow("VLT-SG-CENTRAL")
    val selectedVaultId: StateFlow<String> = _selectedVaultId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedBarDetail = MutableStateFlow<GoldBar?>(null)
    val selectedBarDetail: StateFlow<GoldBar?> = _selectedBarDetail.asStateFlow()

    private val _cliOutput = MutableStateFlow<List<String>>(
        listOf(
            "SG-GOLD CLEAR CLI v3.5.0 [Singapore Precious Metals Clearing Platform]",
            "Type 'goldclear help' or press buttons below to execute terminal commands.",
            "Connected to Local Real-Time Simulation Engine."
        )
    )
    val cliOutput: StateFlow<List<String>> = _cliOutput.asStateFlow()

    private val _apiResponseJson = MutableStateFlow<String>("{ \"status\": \"READY\", \"engine\": \"SG-GOLD CLEAR CCP\" }")
    val apiResponseJson: StateFlow<String> = _apiResponseJson.asStateFlow()

    private val _isLiveTickerRunning = MutableStateFlow(true)
    val isLiveTickerRunning: StateFlow<Boolean> = _isLiveTickerRunning.asStateFlow()

    val members = repository.members
    val vaults = repository.vaults
    val bars = repository.bars
    val clearedTrades = repository.clearedTrades
    val netPositions = repository.netPositions
    val marginCalls = repository.marginCalls
    val settlements = repository.settlements
    val exceptions = repository.exceptions
    val defaultWaterfall = repository.defaultWaterfall
    val scenarios = repository.scenarios
    val demoStepIndex = repository.demoStepIndex
    val demoLogs = repository.demoLogs

    val marketQuotes = MutableStateFlow(repository.marketEngine.getAllQuotes())

    init {
        // Live Price Tick Coroutine
        viewModelScope.launch {
            while (true) {
                delay(3000)
                if (_isLiveTickerRunning.value) {
                    repository.marketEngine.tickSimulatedPrices()
                    marketQuotes.value = repository.marketEngine.getAllQuotes()
                }
            }
        }
    }

    fun setTerminalTab(tab: Int) {
        _currentTerminalTab.value = tab
    }

    fun setSelectedMember(memberId: String) {
        _selectedMemberId.value = memberId
    }

    fun setSelectedVault(vaultId: String) {
        _selectedVaultId.value = vaultId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedBarDetail(bar: GoldBar?) {
        _selectedBarDetail.value = bar
    }

    fun toggleLiveTicker() {
        _isLiveTickerRunning.value = !_isLiveTickerRunning.value
    }

    // Submit New Trade
    fun submitTrade(buyerId: String, sellerId: String, instrument: String, qtyKg: Double, price: Double) {
        val origId = repository.submitNewBilateralTrade(buyerId, sellerId, instrument, qtyKg, price)
        appendCliLine("> Executed: POST /api/v1/trades -> Novated Trade ID $origId")
    }

    // Execute Settlement
    fun settleTrade(tradeId: String) {
        val success = repository.executeDvpSettlementForTrade(tradeId)
        if (success) {
            appendCliLine("> Executed: POST /api/v1/settlements -> Trade $tradeId DVP SETTLED FINAL")
        } else {
            appendCliLine("> Executed: POST /api/v1/settlements -> Trade $tradeId DVP FAILED / SHORTAGE")
        }
    }

    // Trigger Default Simulation
    fun triggerDefault(memberId: String) {
        repository.triggerMemberDefaultSimulation(memberId)
        appendCliLine("> WARNING: Member $memberId Default Triggered. Waterfall executed.")
    }

    // Fund Margin Call
    fun fundMarginCall(callId: String) {
        repository.fundMarginCall(callId)
        appendCliLine("> Action: Margin Call $callId Funded & Acknowledged.")
    }

    // Run 3-Way Reconciliation
    fun runReconciliation() {
        repository.runThreeWayReconciliationNow()
        appendCliLine("> Executed: POST /api/v1/reconciliation/run -> 3-Way Audit Complete.")
    }

    // CLI Command Parser
    fun executeCliCommand(cmdInput: String) {
        val cmd = cmdInput.trim()
        appendCliLine("$ $cmd")

        val parts = cmd.split(" ").filter { it.isNotBlank() }
        if (parts.isEmpty()) return

        if (parts[0].lowercase() == "goldclear" || parts[0].lowercase() == "clear") {
            val sub = parts.getOrNull(1)?.lowercase() ?: "help"
            when (sub) {
                "members" -> {
                    appendCliLine("--- CLEARING MEMBERS (ACTIVE) ---")
                    members.value.forEach { m ->
                        appendCliLine("[${m.memberId}] ${m.legalName} | Net: ${"%.1f".format(m.netPositionKg)} kg | Margin: SGD ${"%.1f".format(m.initialMarginRequiredSgd / 1e6)}M | Status: ${m.status}")
                    }
                }
                "trades" -> {
                    appendCliLine("--- CLEARED TRADES (CCP NOVATED) ---")
                    clearedTrades.value.take(6).forEach { t ->
                        appendCliLine("[${t.tradeId}] ${t.buyerMemberId} <- ${t.sellerMemberId} | ${t.quantityKg} kg @ ${t.price} | ${t.status}")
                    }
                }
                "margin" -> {
                    appendCliLine("--- MARGIN & COLLATERAL STATUS ---")
                    marginCalls.value.forEach { mc ->
                        appendCliLine("[${mc.callId}] Member: ${mc.memberId} | Deficit: SGD ${"%.2f".format(mc.deficitSgd / 1e6)}M | Status: ${mc.status}")
                    }
                    if (marginCalls.value.isEmpty()) {
                        appendCliLine("All clearing members fully margin collateralised. Zero margin deficits.")
                    }
                }
                "vaults" -> {
                    appendCliLine("--- SINGAPORE BULLION VAULTS ---")
                    vaults.value.forEach { v ->
                        appendCliLine("[${v.vaultId}] ${v.name} | Occupied: ${v.occupiedTonnes} t / ${v.maxCapacityTonnes} t | Bars: ${v.barCount}")
                    }
                }
                "reconcile" -> {
                    runReconciliation()
                    appendCliLine("Three-way reconciliation executed. Open Exceptions: ${exceptions.value.size}")
                }
                "audit" -> {
                    appendCliLine("--- DOUBLE-ENTRY LEDGER TRAIL ---")
                    repository.ledgerEngine.entries.takeLast(5).forEach { e ->
                        appendCliLine("[${e.entryId.take(16)}] ${e.ledgerType} | ${e.accountId} | ${e.quantity} ${e.unit} | Hash: ${e.eventHash.take(12)}...")
                    }
                }
                "help" -> {
                    appendCliLine("Available commands:")
                    appendCliLine("  goldclear members      - List active clearing members & positions")
                    appendCliLine("  goldclear trades       - View CCP novated trade obligations")
                    appendCliLine("  goldclear margin       - View margin calls & collateral requirements")
                    appendCliLine("  goldclear vaults       - View Singapore bullion vault status")
                    appendCliLine("  goldclear reconcile    - Run 3-way Market-Ledger-Vault reconciliation")
                    appendCliLine("  goldclear audit        - View cryptographic SHA-256 ledger event trail")
                }
                else -> {
                    appendCliLine("Unknown command '$cmd'. Type 'goldclear help' for assistance.")
                }
            }
        } else {
            appendCliLine("Command not recognized. Type 'goldclear help'.")
        }
    }

    // REST API Endpoint Tester
    fun callApiEndpoint(endpoint: String, method: String = "GET") {
        val json = when (endpoint) {
            "/api/v1/markets" -> {
                val qList = marketQuotes.value.map {
                    "\"${it.pair}\": { \"spot\": ${it.spot}, \"all_in_kg_sgd\": ${it.allInPhysicalPricePerKg} }"
                }.joinToString(",")
                "{ \"timestamp\": \"${System.currentTimeMillis()}\", \"markets\": { $qList } }"
            }
            "/api/v1/members" -> {
                val mList = members.value.map {
                    "{ \"id\": \"${it.memberId}\", \"name\": \"${it.legalName}\", \"net_kg\": ${it.netPositionKg}, \"status\": \"${it.status}\" }"
                }.joinToString(",")
                "{ \"count\": ${members.value.size}, \"members\": [ $mList ] }"
            }
            "/api/v1/vaults" -> {
                val vList = vaults.value.map {
                    "{ \"id\": \"${it.vaultId}\", \"name\": \"${it.name}\", \"occupied_t\": ${it.occupiedTonnes} }"
                }.joinToString(",")
                "{ \"count\": ${vaults.value.size}, \"vaults\": [ $vList ] }"
            }
            "/api/v1/bars" -> {
                val bList = bars.value.take(5).map {
                    "{ \"id\": \"${it.barId}\", \"serial\": \"${it.serialNumber}\", \"refiner\": \"${it.refiner}\", \"vault\": \"${it.vaultName}\" }"
                }.joinToString(",")
                "{ \"total_bars\": ${bars.value.size}, \"sample\": [ $bList ] }"
            }
            "/api/v1/reconciliation/run" -> {
                runReconciliation()
                "{ \"status\": \"SUCCESS\", \"reconciliation\": \"PASSED\", \"exceptions_found\": ${exceptions.value.size} }"
            }
            else -> {
                "{ \"endpoint\": \"$endpoint\", \"status\": \"200 OK\", \"idempotency_key\": \"IDEM-SG-${System.currentTimeMillis()}\" }"
            }
        }
        _apiResponseJson.value = json
    }

    // Step-by-Step Interactive Demo Walkthrough (18 Steps)
    fun advanceDemoStep() {
        val current = demoStepIndex.value
        val next = (current + 1).coerceAtMost(18)
        repository.setDemoStep(next)

        when (next) {
            1 -> repository.appendDemoLog("Step 1: Bilateral trade initiated between Singapore Bullion Bank (SGBB) [Seller] and Meridian Asia Commodities (MAC) [Buyer] for 100.0 kg XAU/SGD.")
            2 -> repository.appendDemoLog("Step 2: Trade Captured at Clearing Engine Gateway. Idempotency Key validated.")
            3 -> repository.appendDemoLog("Step 3: Validation Engine verified member risk limits & trading eligibility.")
            4 -> {
                val spot = repository.marketEngine.getQuote("XAU/SGD").spot
                repository.submitNewBilateralTrade("MAC", "SGBB", "XAU/SGD", 100.0, spot)
                repository.appendDemoLog("Step 4: NOVATION EXECUTED! Bilateral trade transformed into 2 CCP ClearedTrade obligations (MAC <-> CCP, CCP <-> SGBB).")
            }
            5 -> repository.appendDemoLog("Step 5: Initial Margin calculated using SPAN-style portfolio margin with 12% volatility & concentration add-ons.")
            6 -> repository.appendDemoLog("Step 6: Member Collateral posted & verified (SGD 82.4M Cash + SGD 20M Gold Collateral). Haircuts applied (8% Gold, 2% Cash).")
            7 -> repository.appendDemoLog("Step 7: Multilateral Position Netting Engine executed. SGBB Net Position updated to +118.7 kg. MAC Net Position updated to +850.0 kg.")
            8 -> repository.appendDemoLog("Step 8: Delivery Obligation created: DVP_PHYSICAL_VAULT for 100.0 kg Fine Gold at Singapore Central Vault.")
            9 -> repository.appendDemoLog("Step 9: Physical Inventory Selection Engine selected 8 individual Good Delivery gold bars matching 100.0 kg fine weight.")
            10 -> repository.appendDemoLog("Step 10: Vault Facility Manager (VLT-SG-CENTRAL) confirmed bar serial numbers & secondary assay clearance.")
            11 -> repository.appendDemoLog("Step 11: Cash Leg escrow verified (SGD 11.04M deposited in SG-GOLD CLEAR Central Settlement Account).")
            12 -> {
                val trade = repository.clearedTrades.value.lastOrNull()
                if (trade != null) {
                    repository.executeDvpSettlementForTrade(trade.tradeId)
                }
                repository.appendDemoLog("Step 12: DVP ATOMIC SETTLEMENT EXECUTED! Physical Bar ownership transferred to Buyer (MAC). Cash transferred to Seller (SGBB).")
            }
            13 -> repository.appendDemoLog("Step 13: Gold Bar allocation status updated to ALLOCATED in Singapore Central Vault Digital Twin.")
            14 -> repository.appendDemoLog("Step 14: Double-entry Precious Metals Ledger recorded 4 immutable debit/credit entries with SHA-256 hash chaining.")
            15 -> {
                repository.runThreeWayReconciliationNow()
                repository.appendDemoLog("Step 15: Three-Way Reconciliation Engine executed (Market Records vs Clearing Ledger vs Physical Vault).")
            }
            16 -> repository.appendDemoLog("Step 16: Property-based Invariant Check PASSED: Total Gold Owned == Allocated + Unallocated + Encumbered.")
            17 -> repository.appendDemoLog("Step 17: Audit Trail Hash generated: 0x9f8b2c4e1a0d7f3e581429b6c43100e7.")
            18 -> repository.appendDemoLog("Step 18: END-TO-END CLEARING, SETTLEMENT & RECONCILIATION LIFECYCLE COMPLETE!")
        }
    }

    fun resetDemoWalkthrough() {
        repository.setDemoStep(0)
        repository.clearDemoLogs()
    }

    private fun appendCliLine(line: String) {
        _cliOutput.value = _cliOutput.value + line
    }
}
