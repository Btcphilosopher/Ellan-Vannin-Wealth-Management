package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ClearingMember
import com.example.model.DefaultWaterfallState
import com.example.model.StressScenario
import com.example.ui.components.MetricCard
import com.example.ui.components.StatusChip
import com.example.ui.theme.BorderDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SingaporeRed
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusBlue
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.SteelGrey
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RiskScenarioScreen(
    scenarios: List<StressScenario>,
    defaultWaterfall: DefaultWaterfallState,
    members: List<ClearingMember>,
    onTriggerDefault: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "RISK ENGINE & STRESS SCENARIO LAB",
                color = GoldPrimary,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Quantitative Clearing House Stress Testing & Default Waterfall Simulation",
                color = SteelGrey,
                fontSize = 11.sp
            )
        }

        // CCP Default Waterfall Visualizer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .border(1.dp, GoldPrimary, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CCP DEFAULT WATERFALL STATE",
                        color = GoldPrimary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    StatusChip(statusText = defaultWaterfall.recoveryStatus, color = StatusGreen)
                }

                Spacer(modifier = Modifier.height(12.dp))

                WaterfallStepRow(
                    stepNumber = "1",
                    title = "Defaulter Initial Margin",
                    amountText = "SGD ${"%.2f".format(defaultWaterfall.defaulterMarginConsumedSgd / 1e6)}M Consumed",
                    statusColor = StatusBlue
                )
                WaterfallStepRow(
                    stepNumber = "2",
                    title = "Defaulter Posted Collateral",
                    amountText = "SGD ${"%.2f".format(defaultWaterfall.defaulterCollateralConsumedSgd / 1e6)}M Consumed",
                    statusColor = StatusBlue
                )
                WaterfallStepRow(
                    stepNumber = "3",
                    title = "SG-GOLD CLEAR Equity (Skin-in-the-game)",
                    amountText = "SGD ${"%.2f".format(defaultWaterfall.ccpCapitalUsedSgd / 1e6)}M Drawn",
                    statusColor = StatusAmber
                )
                WaterfallStepRow(
                    stepNumber = "4",
                    title = "CCP Default Fund Pool (SGD 500M)",
                    amountText = "SGD ${"%.2f".format(defaultWaterfall.defaultFundDrawnSgd / 1e6)}M Drawn",
                    statusColor = StatusGreen
                )
                WaterfallStepRow(
                    stepNumber = "5",
                    title = "Mutualised Member Loss Recovery",
                    amountText = "SGD ${"%.2f".format(defaultWaterfall.mutualisedLossSgd / 1e6)}M Uncovered",
                    statusColor = if (defaultWaterfall.mutualisedLossSgd > 0) StatusRed else StatusGreen
                )
            }
        }

        // Trigger Default Action Box
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .border(1.dp, SingaporeRed, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "SIMULATE CLEARING MEMBER DEFAULT",
                    color = SingaporeRed,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Select a clearing member to trigger simulated insolvency & execute default waterfall close-out.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onTriggerDefault("NUB") },
                        colors = ButtonDefaults.buttonColors(containerColor = SingaporeRed),
                        modifier = Modifier.weight(1f).testTag("trigger_default_nub")
                    ) {
                        Text("Default NUB Corp", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Button(
                        onClick = { onTriggerDefault("LMB") },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusAmber),
                        modifier = Modifier.weight(1f).testTag("trigger_default_lmb")
                    ) {
                        Text("Default Lion Metals", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        // Stress Testing Scenarios List
        item {
            Text(
                text = "CONFIGURED STRESS TEST SCENARIOS",
                color = GoldPrimary,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        items(scenarios) { scn ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = scn.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        StatusChip(statusText = "TEST READY", color = StatusBlue)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = scn.description, color = SteelGrey, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Projected Deficit Members: ${scn.projectedDeficitMembersCount}",
                            color = StatusAmber,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Margin Increase: +SGD ${"%.1f".format(scn.projectedTotalMarginIncreaseSgd / 1e6)}M",
                            color = StatusGreen,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WaterfallStepRow(stepNumber: String, title: String, amountText: String, statusColor: androidx.compose.ui.graphics.Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1.5f)) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(SurfaceElevated)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(text = "#$stepNumber", color = GoldPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = title, color = TextPrimary, fontSize = 11.sp)
        }
        Text(text = amountText, color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
    Divider(color = BorderDark, thickness = 0.5.dp)
}
