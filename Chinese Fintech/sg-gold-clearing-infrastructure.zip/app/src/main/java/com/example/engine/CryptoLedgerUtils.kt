package com.example.engine

import java.security.MessageDigest

object CryptoLedgerUtils {
    fun calculateHash(
        entryId: String,
        eventId: String,
        timestamp: String,
        ledgerType: String,
        accountId: String,
        quantity: Double,
        unit: String,
        previousHash: String
    ): String {
        val input = "$entryId|$eventId|$timestamp|$ledgerType|$accountId|$quantity|$unit|$previousHash"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
