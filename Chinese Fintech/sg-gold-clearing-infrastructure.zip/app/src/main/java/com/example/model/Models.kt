package com.example.model

import java.math.BigDecimal

enum class MemberStatus { ACTIVE, MARGIN_CALL, WARNING, DEFAULTED, SUSPENDED }

enum class BarWeightClass(val label: String, val weightKg: Double) {
    BAR_400_OZ("400 oz Good Delivery", 12.4414),
    BAR_100_OZ("100 oz Bar", 3.11035),
    BAR_1_KG("1 kg Bar", 1.0),
    BAR_500_G("500 g Bar", 0.5),
    BAR_250_G("250 g Bar", 0.25),
    BAR_100_G("100 g Bar", 0.1)
}

enum class BarAllocationStatus { ALLOCATED, UNALLOCATED, PLEDGED, ENCUMBERED, IN_TRANSIT }
enum class BarInspectionStatus { VERIFIED, PENDING_ASSAY, AUDITED_CLEAN, DISCREPANCY }

enum class TradeStatus { NOVATED, NETTED, SETTLING, SETTLED, FAILED, CANCELLED }

enum class DeliveryType { ALLOCATED_PHYSICAL, UNALLOCATED_ACCOUNT, DVP_PHYSICAL_VAULT }

enum class MarginCallStatus { ISSUED, ACKNOWLEDGED, PARTIALLY_FUNDED, FUNDED, OVERDUE, DEFAULTED }

enum class LedgerType { CASH, GOLD, COLLATERAL, PHYSICAL_INVENTORY, CLIENT_OWNERSHIP, CCP_OBLIGATION }

enum class ExceptionSeverity { CRITICAL, HIGH, MEDIUM, LOW }
enum class ExceptionStatus { OPEN, INVESTIGATING, RESOLVED }

data class CustodyEvent(
    val timestamp: String,
    val fromLocation: String,
    val toLocation: String,
    val actor: String,
    val assayRef: String,
    val txHash: String
)

data class GoldBar(
    val barId: String,
    val serialNumber: String,
    val refiner: String,
    val brand: String,
    val fineness: Double = 999.9, // e.g. 999.9
    val weightClass: BarWeightClass,
    val grossWeightKg: Double,
    val fineGoldWeightKg: Double,
    val manufactureDate: String,
    val assayReference: String,
    val origin: String, // e.g. "Valcambi SA - Switzerland"
    val currentVaultId: String,
    val vaultName: String,
    val ownerMemberId: String,
    val status: String = "IN_VAULT",
    val allocationStatus: BarAllocationStatus = BarAllocationStatus.UNALLOCATED,
    val isEncumbered: Boolean = false,
    val inspectionStatus: BarInspectionStatus = BarInspectionStatus.VERIFIED,
    val chainOfCustody: List<CustodyEvent> = emptyList()
)

data class VaultFacility(
    val vaultId: String,
    val name: String,
    val location: String,
    val maxCapacityTonnes: Double,
    val occupiedTonnes: Double,
    val barCount: Int,
    val securityLevel: String = "TIER-1 HIGH SECURITY",
    val inspectionStatus: String = "AUDITED - FULL COMPLIANCE",
    val inboundTransfersCount: Int = 0,
    val outboundTransfersCount: Int = 0,
    val physicalGoldTonnes: Double,
    val digitalGoldTonnes: Double,
    val encumberedGoldTonnes: Double
) {
    val availableTonnes: Double get() = (maxCapacityTonnes - occupiedTonnes).coerceAtLeast(0.0)
}

data class ClearingMember(
    val memberId: String,
    val legalName: String,
    val jurisdiction: String,
    val status: MemberStatus = MemberStatus.ACTIVE,
    val grossLongKg: Double = 0.0,
    val grossShortKg: Double = 0.0,
    val netPositionKg: Double = 0.0,
    val allocatedGoldKg: Double = 0.0,
    val unallocatedGoldKg: Double = 0.0,
    val cashCollateralSgd: Double = 0.0,
    val goldCollateralSgd: Double = 0.0,
    val initialMarginRequiredSgd: Double = 0.0,
    val variationMarginSgd: Double = 0.0,
    val vaultAccessList: List<String> = emptyList(),
    val riskLimitSgd: Double = 500_000_000.0
) {
    val totalCollateralSgd: Double get() = cashCollateralSgd + goldCollateralSgd
    val availableCollateralSgd: Double get() = totalCollateralSgd - initialMarginRequiredSgd - variationMarginSgd.coerceAtLeast(0.0)
}

data class ClearedTrade(
    val tradeId: String,
    val originalTradeId: String,
    val buyerMemberId: String,
    val sellerMemberId: String,
    val instrument: String, // e.g. "XAU/SGD", "XAU/USD"
    val quantityKg: Double,
    val price: Double,
    val currency: String, // e.g. "SGD"
    val tradeTimestamp: String,
    val clearingTimestamp: String,
    val settlementDate: String,
    val deliveryType: DeliveryType,
    val marginRequirementSgd: Double,
    val status: TradeStatus = TradeStatus.NOVATED
)

data class NetPosition(
    val memberId: String,
    val instrument: String,
    val settlementDate: String,
    val grossLongKg: Double,
    val grossShortKg: Double,
    val netObligationKg: Double, // Positive = Receive Gold, Negative = Deliver Gold
    val netCashObligationSgd: Double,
    val vaultIdPreference: String = "VLT-SG-CENTRAL"
)

data class MarginCall(
    val callId: String,
    val memberId: String,
    val requiredMarginSgd: Double,
    val currentCollateralSgd: Double,
    val deficitSgd: Double,
    val deadlineTimestamp: String,
    val status: MarginCallStatus = MarginCallStatus.ISSUED,
    val issuedTimestamp: String
)

data class SettlementLeg(
    val legId: String,
    val type: String, // "GOLD" or "CASH"
    val payerId: String,
    val receiverId: String,
    val quantityOrAmount: Double,
    val unit: String,
    val status: String
)

data class SettlementObligation(
    val settlementId: String,
    val buyerMemberId: String,
    val sellerMemberId: String,
    val goldQuantityKg: Double,
    val cashAmountSgd: Double,
    val currency: String = "SGD",
    val deliveryType: DeliveryType,
    val vaultId: String,
    val settlementDate: String,
    val allocatedBarIds: List<String> = emptyList(),
    val goldLegStatus: String = "PENDING",
    val cashLegStatus: String = "PENDING",
    val overallStatus: String = "PENDING",
    val timestampCreated: String
)

data class LedgerEntry(
    val entryId: String,
    val eventId: String,
    val timestamp: String,
    val ledgerType: LedgerType,
    val accountId: String,
    val quantity: Double,
    val unit: String, // "KG" or "SGD" or "USD"
    val valuationSgd: Double,
    val reference: String,
    val previousEventHash: String,
    val eventHash: String,
    val actor: String,
    val reason: String
)

data class ReconciliationException(
    val exceptionId: String,
    val timestamp: String,
    val type: String, // e.g., "MISSING_BAR", "WEIGHT_MISMATCH", "UNEXPLAINED_BALANCE"
    val severity: ExceptionSeverity,
    val facilityOrMemberId: String,
    val description: String,
    val status: ExceptionStatus = ExceptionStatus.OPEN
)

data class StressScenario(
    val scenarioId: String,
    val name: String,
    val description: String,
    val goldPriceChangePct: Double,
    val fxUsdSgdChangePct: Double,
    val vaultOutageId: String? = null,
    val defaultingMemberId: String? = null,
    val projectedDeficitMembersCount: Int = 0,
    val projectedTotalMarginIncreaseSgd: Double = 0.0,
    val ccpDefaultFundDrawnSgd: Double = 0.0
)

data class DefaultWaterfallState(
    val defaulterMemberId: String = "MEMBER_DEFAULTED",
    val defaulterMarginConsumedSgd: Double = 45_000_000.0,
    val defaulterCollateralConsumedSgd: Double = 35_000_000.0,
    val ccpCapitalUsedSgd: Double = 12_000_000.0, // SG-GOLD CLEAR skin in the game
    val defaultFundDrawnSgd: Double = 0.0,
    val mutualisedLossSgd: Double = 0.0,
    val recoveryStatus: String = "DEFICIT_COVERED_BY_CCP_CAPITAL"
)
