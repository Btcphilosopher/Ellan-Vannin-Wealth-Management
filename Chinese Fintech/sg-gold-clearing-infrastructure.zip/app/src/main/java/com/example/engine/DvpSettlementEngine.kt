package com.example.engine

import com.example.model.BarAllocationStatus
import com.example.model.GoldBar
import com.example.model.LedgerType
import com.example.model.SettlementObligation

class DvpSettlementEngine {

    /**
     * Executes atomic DVP Settlement between Buyer, Seller, and Physical Vault.
     */
    fun executeDvpSettlement(
        obligation: SettlementObligation,
        vaultBars: List<GoldBar>,
        ledgerEngine: GoldLedgerEngine
    ): Pair<SettlementObligation, List<GoldBar>> {
        val requiredKg = obligation.goldQuantityKg

        // Select available bars in specified vault
        val candidateBars = vaultBars.filter {
            it.currentVaultId == obligation.vaultId &&
                    (it.allocationStatus == BarAllocationStatus.UNALLOCATED || it.ownerMemberId == obligation.sellerMemberId)
        }

        val selectedBars = mutableListOf<GoldBar>()
        var accumulatedKg = 0.0

        for (bar in candidateBars) {
            if (accumulatedKg < requiredKg) {
                selectedBars.add(bar)
                accumulatedKg += bar.fineGoldWeightKg
            } else {
                break
            }
        }

        if (accumulatedKg < requiredKg) {
            // Cannot settle due to insufficient unallocated physical gold in vault
            val failedObligation = obligation.copy(
                goldLegStatus = "INSUFFICIENT_VAULT_INVENTORY",
                cashLegStatus = "ESCROWED",
                overallStatus = "FAILED_PHYSICAL_SHORTAGE"
            )
            return Pair(failedObligation, vaultBars)
        }

        val allocatedBarIds = selectedBars.map { it.barId }

        // Update bar ownership and allocation status
        val updatedBars = vaultBars.map { bar ->
            if (bar.barId in allocatedBarIds) {
                bar.copy(
                    ownerMemberId = obligation.buyerMemberId,
                    allocationStatus = BarAllocationStatus.ALLOCATED,
                    status = "SETTLED_IN_VAULT"
                )
            } else {
                bar
            }
        }

        // Record Double-Entry Ledger Events
        val eventId = "EVT-DVP-${obligation.settlementId}"

        // Gold Debit from Seller
        ledgerEngine.recordEntry(
            eventId = eventId,
            ledgerType = LedgerType.GOLD,
            accountId = "GOLD-ACC-${obligation.sellerMemberId}",
            quantity = -requiredKg,
            unit = "KG",
            valuationSgd = obligation.cashAmountSgd,
            reference = obligation.settlementId,
            actor = "DVP-SETTLEMENT-ENGINE",
            reason = "PHYSICAL_GOLD_DELIVERY_OUT"
        )

        // Gold Credit to Buyer
        ledgerEngine.recordEntry(
            eventId = eventId,
            ledgerType = LedgerType.GOLD,
            accountId = "GOLD-ACC-${obligation.buyerMemberId}",
            quantity = requiredKg,
            unit = "KG",
            valuationSgd = obligation.cashAmountSgd,
            reference = obligation.settlementId,
            actor = "DVP-SETTLEMENT-ENGINE",
            reason = "PHYSICAL_GOLD_DELIVERY_IN"
        )

        // Cash Debit from Buyer
        ledgerEngine.recordEntry(
            eventId = eventId,
            ledgerType = LedgerType.CASH,
            accountId = "CASH-ACC-${obligation.buyerMemberId}",
            quantity = -obligation.cashAmountSgd,
            unit = "SGD",
            valuationSgd = obligation.cashAmountSgd,
            reference = obligation.settlementId,
            actor = "DVP-SETTLEMENT-ENGINE",
            reason = "CASH_SETTLEMENT_PAYMENT"
        )

        // Cash Credit to Seller
        ledgerEngine.recordEntry(
            eventId = eventId,
            ledgerType = LedgerType.CASH,
            accountId = "CASH-ACC-${obligation.sellerMemberId}",
            quantity = obligation.cashAmountSgd,
            unit = "SGD",
            valuationSgd = obligation.cashAmountSgd,
            reference = obligation.settlementId,
            actor = "DVP-SETTLEMENT-ENGINE",
            reason = "CASH_SETTLEMENT_RECEIPT"
        )

        val completedObligation = obligation.copy(
            allocatedBarIds = allocatedBarIds,
            goldLegStatus = "DELIVERED_AND_ALLOCATED",
            cashLegStatus = "SETTLED_FINAL",
            overallStatus = "SETTLED"
        )

        return Pair(completedObligation, updatedBars)
    }
}
