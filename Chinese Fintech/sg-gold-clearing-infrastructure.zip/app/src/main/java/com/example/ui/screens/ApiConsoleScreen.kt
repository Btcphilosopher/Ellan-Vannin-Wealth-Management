package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SteelGrey
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary

@Composable
fun ApiConsoleScreen(
    cliOutput: List<String>,
    apiResponseJson: String,
    onExecuteCli: (String) -> Unit,
    onCallApiEndpoint: (String) -> Unit
) {
    var cmdInputText by remember { mutableStateOf("goldclear members") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SG-GOLD CLEAR // API PLATFORM & CLI CONSOLE",
                color = GoldPrimary,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "REST / OpenAPI Endpoints & Interactive Command-Line Simulation Console",
                color = SteelGrey,
                fontSize = 11.sp
            )
        }

        // REST API Quick Tester
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "REST ENDPOINT TESTER",
                    color = GoldPrimary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                val endpoints = listOf(
                    "/api/v1/markets",
                    "/api/v1/members",
                    "/api/v1/vaults",
                    "/api/v1/bars",
                    "/api/v1/reconciliation/run"
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(endpoints) { ep ->
                        Button(
                            onClick = { onCallApiEndpoint(ep) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated),
                            modifier = Modifier.testTag("api_endpoint_${ep.replace("/", "_")}")
                        ) {
                            Text(text = "GET $ep", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(SurfaceElevated)
                        .padding(8.dp)
                ) {
                    Text(
                        text = apiResponseJson,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Interactive CLI Terminal
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .border(1.dp, GoldPrimary, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "INTERACTIVE 'goldclear' CLI TERMINAL",
                    color = GoldPrimary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                // CLI Quick Action Shortcut Buttons
                val shortcuts = listOf(
                    "goldclear members",
                    "goldclear trades",
                    "goldclear margin",
                    "goldclear vaults",
                    "goldclear reconcile",
                    "goldclear audit"
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(shortcuts) { sc ->
                        Button(
                            onClick = {
                                cmdInputText = sc
                                onExecuteCli(sc)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated),
                            modifier = Modifier.testTag("cli_shortcut_${sc.replace(" ", "_")}")
                        ) {
                            Text(sc, color = GoldPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Terminal Output Screen
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(SurfaceElevated)
                        .padding(10.dp)
                ) {
                    LazyColumn {
                        items(cliOutput) { line ->
                            Text(
                                text = line,
                                color = if (line.startsWith("$")) GoldPrimary else TextPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = cmdInputText,
                        onValueChange = { cmdInputText = it },
                        modifier = Modifier.weight(1f).testTag("cli_input_field"),
                        placeholder = { Text("Type goldclear command...") },
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onExecuteCli(cmdInputText) },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.testTag("cli_run_button")
                    ) {
                        Text("RUN", color = SurfaceDark, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
