package com.example.engine

data class MarketQuote(
    val pair: String, // e.g. "XAU/SGD"
    val bid: Double,
    val ask: Double,
    val spot: Double,
    val change24hPct: Double,
    val regionalPremiumUsdPerOz: Double = 3.50,
    val sgVaultPremiumUsdPerOz: Double = 1.20,
    val currency: String = "SGD"
) {
    val allInPhysicalPricePerKg: Double
        get() {
            val ozToKg = 32.1507
            val ozBasePrice = spot / ozToKg
            val ozAllIn = ozBasePrice + (regionalPremiumUsdPerOz + sgVaultPremiumUsdPerOz) / ozToKg
            return ozAllIn * ozToKg
        }
}

class MarketPriceEngine {
    private val quotes = mutableMapOf<String, MarketQuote>(
        "XAU/SGD" to MarketQuote("XAU/SGD", bid = 110450.0, ask = 110490.0, spot = 110470.0, change24hPct = +0.82, currency = "SGD"),
        "XAU/USD" to MarketQuote("XAU/USD", bid = 2740.50, ask = 2741.50, spot = 2741.00, change24hPct = +0.65, currency = "USD"),
        "XAU/CNH" to MarketQuote("XAU/CNH", bid = 19480.0, ask = 19495.0, spot = 19487.5, change24hPct = +0.45, currency = "CNH"),
        "XAU/JPY" to MarketQuote("XAU/JPY", bid = 412000.0, ask = 412300.0, spot = 412150.0, change24hPct = +1.10, currency = "JPY"),
        "XAU/EUR" to MarketQuote("XAU/EUR", bid = 2510.0, ask = 2512.0, spot = 2511.0, change24hPct = +0.30, currency = "EUR"),
        "XAU/GBP" to MarketQuote("XAU/GBP", bid = 2085.0, ask = 2087.0, spot = 2086.0, change24hPct = +0.25, currency = "GBP"),
        "XAU/CHF" to MarketQuote("XAU/CHF", bid = 2360.0, ask = 2362.0, spot = 2361.0, change24hPct = +0.40, currency = "CHF"),
        "XAU/AUD" to MarketQuote("XAU/AUD", bid = 4050.0, ask = 4055.0, spot = 4052.5, change24hPct = +0.70, currency = "AUD"),
        "XAU/INR" to MarketQuote("XAU/INR", bid = 229500.0, ask = 229800.0, spot = 229650.0, change24hPct = +0.55, currency = "INR")
    )

    fun getQuote(pair: String): MarketQuote {
        return quotes[pair] ?: quotes["XAU/SGD"]!!
    }

    fun getAllQuotes(): List<MarketQuote> = quotes.values.toList()

    fun tickSimulatedPrices(): Map<String, MarketQuote> {
        for ((key, q) in quotes) {
            val deltaPct = ((1..10).random() - 5.5) * 0.0008
            val newSpot = (q.spot * (1.0 + deltaPct)).coerceAtLeast(10.0)
            val spread = newSpot * 0.0003
            val newBid = newSpot - spread / 2
            val newAsk = newSpot + spread / 2
            val newChange = q.change24hPct + deltaPct * 100

            quotes[key] = q.copy(
                bid = newBid,
                ask = newAsk,
                spot = newSpot,
                change24hPct = newChange
            )
        }
        return quotes.toMap()
    }
}
