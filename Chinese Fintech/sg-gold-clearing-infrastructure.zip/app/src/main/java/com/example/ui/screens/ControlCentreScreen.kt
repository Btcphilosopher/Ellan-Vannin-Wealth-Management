package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ClearedTrade
import com.example.model.ClearingMember
import com.example.model.MarginCall
import com.example.model.NetPosition
import com.example.model.ReconciliationException
import com.example.model.TradeStatus
import com.example.ui.components.MetricCard
import com.example.ui.components.StatusChip
import com.example.ui.theme.BorderDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SingaporeRed
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusBlue
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.SteelGrey
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ControlCentreScreen(
    clearedTrades: List<ClearedTrade>,
    members: List<ClearingMember>,
    netPositions: Map<String, NetPosition>,
    marginCalls: List<MarginCall>,
    exceptions: List<ReconciliationException>,
    onSettleTrade: (String) -> Unit,
    onFundMarginCall: (String) -> Unit,
    onRunReconciliation: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Metrics Grid
        item {
            Text(
                text = "CLEARING HOUSE OVERVIEW // SG-GOLD CLEAR CCP",
                color = GoldPrimary,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCard(
                        label = "GOLD CLEARED TODAY",
                        value = "18,492.5 kg",
                        subtitle = "SGD 2.04 Billion",
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        label = "OPEN GOLD INTEREST",
                        value = "142.8 Tonnes",
                        subtitle = "Net Cleared Obligations",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricCard(
                        label = "MARGIN HELD",
                        value = "SGD 614.2M",
                        subtitle = "Collateralized @ 100%",
                        statusColor = StatusGreen,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        label = "GOLD IN SG VAULTS",
                        value = "287.4 Tonnes",
                        subtitle = "5 Facilities Audited",
                        statusColor = StatusBlue,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Active Margin Calls Section
        if (marginCalls.isNotEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceDark)
                        .border(1.dp, StatusAmber, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ACTIVE MARGIN CALLS (${marginCalls.size})",
                            color = StatusAmber,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        StatusChip(statusText = "DEFICIT DETECTED", color = StatusAmber)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    marginCalls.forEach { call ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Member: ${call.memberId} | Deficit: SGD ${"%.2f".format(call.deficitSgd / 1e6)}M",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Deadline: ${call.deadlineTimestamp}",
                                    color = SteelGrey,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Button(
                                onClick = { onFundMarginCall(call.callId) },
                                colors = ButtonDefaults.buttonColors(containerColor = StatusAmber),
                                modifier = Modifier.testTag("fund_margin_call_button")
                            ) {
                                Text("Acknowledge & Fund", color = SurfaceDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // System Exposure Netting Matrix
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "MEMBER NETTING & EXPOSURE MATRIX",
                    color = GoldPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                members.forEach { m ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(text = m.legalName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(text = m.jurisdiction, color = SteelGrey, fontSize = 10.sp)
                        }

                        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                            val isLong = m.netPositionKg >= 0
                            val dirText = if (isLong) "+${"%.1f".format(m.netPositionKg)} kg" else "${"%.1f".format(m.netPositionKg)} kg"
                            val dirColor = if (isLong) StatusGreen else StatusRed
                            Text(text = dirText, color = dirColor, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Text(text = "Gross: ${"%.1f".format(m.grossLongKg + m.grossShortKg)} kg", color = SteelGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.width(8.dp))
                        StatusChip(
                            statusText = m.status.name,
                            color = if (m.status == com.example.model.MemberStatus.ACTIVE) StatusGreen else StatusAmber
                        )
                    }
                    Divider(color = BorderDark, thickness = 0.5.dp)
                }
            }
        }

        // Live Cleared Trades Stream
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CCP CLEARED OBLIGATIONS STREAM",
                    color = GoldPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                OutlinedButton(
                    onClick = onRunReconciliation,
                    modifier = Modifier.testTag("run_reconciliation_button")
                ) {
                    Text("Run 3-Way Reconcile", fontSize = 11.sp, color = GoldPrimary)
                }
            }
        }

        items(clearedTrades) { trade ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = trade.tradeId,
                                color = GoldPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val stColor = when (trade.status) {
                                TradeStatus.NOVATED -> StatusBlue
                                TradeStatus.SETTLED -> StatusGreen
                                TradeStatus.FAILED -> StatusRed
                                else -> StatusAmber
                            }
                            StatusChip(statusText = trade.status.name, color = stColor)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Buyer: ${trade.buyerMemberId} <- CCP <- Seller: ${trade.sellerMemberId}",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Settle Date: ${trade.settlementDate} | Delivery: ${trade.deliveryType.name}",
                            color = SteelGrey,
                            fontSize = 10.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${trade.quantityKg} kg",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "@ SGD ${trade.price}/kg",
                            color = SteelGrey,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        if (trade.status == TradeStatus.NOVATED) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Button(
                                onClick = { onSettleTrade(trade.tradeId) },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                modifier = Modifier.testTag("settle_trade_${trade.tradeId}")
                            ) {
                                Text("Settle DVP", color = SurfaceDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
