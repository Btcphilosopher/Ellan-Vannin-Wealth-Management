package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldVariant
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.SteelGrey
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary

@Composable
fun DemoWalkthroughScreen(
    currentStepIndex: Int,
    demoLogs: List<String>,
    onAdvanceStep: () -> Unit,
    onResetWalkthrough: () -> Unit
) {
    val stepTitles = listOf(
        "0: Pipeline Standby",
        "1: Trade Initiated (SGBB Sells 100kg to MAC)",
        "2: Trade Captured at Gateway",
        "3: Validation & Risk Limit Check",
        "4: Novation to Central Counterparty (CCP)",
        "5: SPAN Margin Requirement Calculation",
        "6: Member Collateral Posted & Haircut Verified",
        "7: Multilateral Position Netting Executed",
        "8: Delivery Obligation Generated (DVP_PHYSICAL)",
        "9: Physical Inventory Selected (8 Good Delivery Bars)",
        "10: Vault Facility Assay Confirmed",
        "11: Cash Leg Escrow Verified in SGD Account",
        "12: DVP ATOMIC SETTLEMENT EXECUTED",
        "13: Physical Bar Ownership Transferred in Vault",
        "14: Double-Entry Precious Metals Ledger Recorded",
        "15: Three-Way Reconciliation Executed",
        "16: Property-Based Invariant Check Passed",
        "17: Cryptographic Audit Hash Generated",
        "18: END-TO-END CLEARING LIFECYCLE COMPLETE"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "END-TO-END DEMONSTRATION PIPELINE (18-STEP)",
                color = GoldPrimary,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "TRADE -> CLEAR -> MARGIN -> NET -> ALLOCATE -> SETTLE -> DELIVER -> RECONCILE",
                color = SteelGrey,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        // Stepper Progress Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .border(1.dp, GoldPrimary, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "CURRENT STAGE [STEP $currentStepIndex / 18]",
                    color = GoldVariant,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stepTitles.getOrElse(currentStepIndex) { "Stage $currentStepIndex" },
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))
                val progress = (currentStepIndex.toFloat() / 18f).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = StatusGreen,
                    trackColor = SurfaceElevated
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onAdvanceStep,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.weight(1f).testTag("advance_demo_step_button")
                    ) {
                        Text(
                            text = if (currentStepIndex >= 18) "LIFECYCLE COMPLETE (REPLAY)" else "ADVANCE NEXT STEP ->",
                            color = SurfaceDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    OutlinedButton(
                        onClick = onResetWalkthrough,
                        modifier = Modifier.testTag("reset_demo_button")
                    ) {
                        Text("Reset", color = GoldPrimary, fontSize = 12.sp)
                    }
                }
            }
        }

        // Live Pipeline Execution Audit Logs
        item {
            Text(
                text = "REAL-TIME PIPELINE EXECUTION AUDIT LOGS",
                color = GoldPrimary,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .padding(12.dp)
            ) {
                LazyColumn {
                    items(demoLogs) { log ->
                        Text(
                            text = log,
                            color = if (log.contains("EXECUTED") || log.contains("PASSED") || log.contains("COMPLETE")) StatusGreen else TextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                    if (demoLogs.isEmpty()) {
                        item {
                            Text(
                                text = "Press 'ADVANCE NEXT STEP' button above to execute Step 1 of the 18-step clearing lifecycle...",
                                color = SteelGrey,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
