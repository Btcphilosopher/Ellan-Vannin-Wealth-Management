package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BarAllocationStatus
import com.example.model.GoldBar
import com.example.model.VaultFacility
import com.example.ui.components.BarListItemCard
import com.example.ui.components.MetricCard
import com.example.ui.components.StatusChip
import com.example.ui.theme.BorderDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldVariant
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusBlue
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.SteelGrey
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun VaultTerminalScreen(
    vaults: List<VaultFacility>,
    bars: List<GoldBar>,
    selectedVaultId: String,
    searchQuery: String,
    selectedBarDetail: GoldBar?,
    onSelectVault: (String) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSelectBarDetail: (GoldBar?) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SINGAPORE BULLION VAULT DIGITAL TWIN",
                color = GoldPrimary,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Vault Facilities Row
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vaults) { vault ->
                    val isSelected = vault.vaultId == selectedVaultId
                    Box(
                        modifier = Modifier
                            .width(220.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(SurfaceDark)
                            .border(1.dp, if (isSelected) GoldPrimary else BorderDark, RoundedCornerShape(8.dp))
                            .clickable { onSelectVault(vault.vaultId) }
                            .padding(12.dp)
                            .testTag("select_vault_${vault.vaultId}")
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = vault.vaultId,
                                    color = GoldPrimary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                StatusChip(statusText = vault.securityLevel.take(6), color = StatusBlue)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = vault.name,
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Occupied: ${vault.occupiedTonnes} t / ${vault.maxCapacityTonnes} t",
                                color = SteelGrey,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val pct = (vault.occupiedTonnes / vault.maxCapacityTonnes).toFloat().coerceIn(0f, 1f)
                            LinearProgressIndicator(
                                progress = { pct },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = GoldPrimary,
                                trackColor = SurfaceElevated
                            )
                        }
                    }
                }
            }
        }

        // Search Field & Filter
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier.fillMaxWidth().testTag("bar_search_input"),
                placeholder = { Text("Search by serial number (e.g. SGC-400), refiner, or owner...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = GoldPrimary) },
                singleLine = true
            )
        }

        // Bar Inspector Dialog Modal (If bar selected)
        if (selectedBarDetail != null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceElevated)
                        .border(2.dp, GoldPrimary, RoundedCornerShape(10.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "BAR INSPECTOR // ${selectedBarDetail.serialNumber}",
                                    color = GoldPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                StatusChip(statusText = selectedBarDetail.allocationStatus.name, color = StatusGreen)
                            }
                            IconButton(
                                onClick = { onSelectBarDetail(null) },
                                modifier = Modifier.testTag("close_bar_inspector")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = GoldPrimary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Attributes Grid
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricCard(label = "REFINER / BRAND", value = selectedBarDetail.refiner.take(16), modifier = Modifier.weight(1f))
                            MetricCard(label = "FINENESS", value = "${selectedBarDetail.fineness}", modifier = Modifier.weight(1f))
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricCard(label = "FINE GOLD WEIGHT", value = "${"%.3f".format(selectedBarDetail.fineGoldWeightKg)} kg", modifier = Modifier.weight(1f))
                            MetricCard(label = "ASSAY REF", value = selectedBarDetail.assayReference, modifier = Modifier.weight(1f))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "CHAIN OF CUSTODY TIMELINE",
                            color = GoldVariant,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        selectedBarDetail.chainOfCustody.forEach { evt ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${evt.timestamp} | ${evt.actor}",
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "${evt.fromLocation} -> ${evt.toLocation}",
                                    color = SteelGrey,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = "Tx Hash: ${evt.txHash}",
                                    color = StatusBlue,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Divider(color = BorderDark)
                        }
                    }
                }
            }
        }

        // Inventory Bars List
        item {
            Text(
                text = "PHYSICAL GOLD INVENTORY (FILTERED BY VAULT $selectedVaultId)",
                color = GoldPrimary,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        val filteredBars = bars.filter { bar ->
            val matchVault = bar.currentVaultId == selectedVaultId
            val matchQuery = searchQuery.isBlank() ||
                    bar.serialNumber.contains(searchQuery, ignoreCase = true) ||
                    bar.refiner.contains(searchQuery, ignoreCase = true) ||
                    bar.ownerMemberId.contains(searchQuery, ignoreCase = true)
            matchVault && matchQuery
        }

        items(filteredBars) { bar ->
            BarListItemCard(bar = bar, onInspectClick = { onSelectBarDetail(bar) })
        }
    }
}
