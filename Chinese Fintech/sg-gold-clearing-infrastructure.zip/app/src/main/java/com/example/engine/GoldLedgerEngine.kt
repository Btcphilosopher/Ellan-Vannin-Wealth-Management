package com.example.engine

import com.example.model.GoldBar
import com.example.model.LedgerEntry
import com.example.model.LedgerType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GoldLedgerEngine {
    private val _entries = mutableListOf<LedgerEntry>()
    val entries: List<LedgerEntry> get() = _entries.toList()

    private var lastHash = "0000000000000000000000000000000000000000000000000000000000000000"

    fun recordEntry(
        eventId: String,
        ledgerType: LedgerType,
        accountId: String,
        quantity: Double,
        unit: String,
        valuationSgd: Double,
        reference: String,
        actor: String,
        reason: String
    ): LedgerEntry {
        val entryId = "LEDGER-${System.currentTimeMillis()}-${(1000..9999).random()}"
        val timestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date())
        val currentHash = CryptoLedgerUtils.calculateHash(
            entryId = entryId,
            eventId = eventId,
            timestamp = timestamp,
            ledgerType = ledgerType.name,
            accountId = accountId,
            quantity = quantity,
            unit = unit,
            previousHash = lastHash
        )

        val entry = LedgerEntry(
            entryId = entryId,
            eventId = eventId,
            timestamp = timestamp,
            ledgerType = ledgerType,
            accountId = accountId,
            quantity = quantity,
            unit = unit,
            valuationSgd = valuationSgd,
            reference = reference,
            previousEventHash = lastHash,
            eventHash = currentHash,
            actor = actor,
            reason = reason
        )

        lastHash = currentHash
        _entries.add(entry)
        return entry
    }

    /**
     * Property-based Invariant Check:
     * TOTAL GOLD OWNED == TOTAL GOLD ALLOCATED + TOTAL GOLD UNALLOCATED + OTHER EXPLICIT STATES
     */
    fun checkGoldLedgerInvariant(bars: List<GoldBar>): Boolean {
        val totalFineGoldKg = bars.sumOf { it.fineGoldWeightKg }
        val allocatedKg = bars.filter { it.allocationStatus == com.example.model.BarAllocationStatus.ALLOCATED }.sumOf { it.fineGoldWeightKg }
        val unallocatedKg = bars.filter { it.allocationStatus == com.example.model.BarAllocationStatus.UNALLOCATED }.sumOf { it.fineGoldWeightKg }
        val pledgedKg = bars.filter { it.allocationStatus == com.example.model.BarAllocationStatus.PLEDGED || it.allocationStatus == com.example.model.BarAllocationStatus.ENCUMBERED }.sumOf { it.fineGoldWeightKg }
        val inTransitKg = bars.filter { it.allocationStatus == com.example.model.BarAllocationStatus.IN_TRANSIT }.sumOf { it.fineGoldWeightKg }

        val sumExplicit = allocatedKg + unallocatedKg + pledgedKg + inTransitKg
        return kotlin.math.abs(totalFineGoldKg - sumExplicit) < 0.000001
    }
}
