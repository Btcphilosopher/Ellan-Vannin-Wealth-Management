package com.example.engine

import com.example.model.ClearedTrade
import com.example.model.DeliveryType
import com.example.model.NetPosition
import com.example.model.TradeStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NovationAndNettingEngine {

    /**
     * Novates a bilateral transaction into two CCP cleared trades.
     */
    fun novateBilateralTrade(
        originalTradeId: String,
        buyerMemberId: String,
        sellerMemberId: String,
        instrument: String,
        quantityKg: Double,
        price: Double,
        currency: String,
        deliveryType: DeliveryType,
        goldPriceSgdPerKg: Double
    ): List<ClearedTrade> {
        val timestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date())
        val settlementDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(System.currentTimeMillis() + 86400000L * 2)) // T+2

        val notionalSgd = quantityKg * goldPriceSgdPerKg
        val marginReqSgd = notionalSgd * 0.05 // 5% base initial margin requirement

        val trade1 = ClearedTrade(
            tradeId = "NOV-BUY-$originalTradeId",
            originalTradeId = originalTradeId,
            buyerMemberId = buyerMemberId,
            sellerMemberId = "SG-GOLD-CLEAR-CCP",
            instrument = instrument,
            quantityKg = quantityKg,
            price = price,
            currency = currency,
            tradeTimestamp = timestamp,
            clearingTimestamp = timestamp,
            settlementDate = settlementDate,
            deliveryType = deliveryType,
            marginRequirementSgd = marginReqSgd,
            status = TradeStatus.NOVATED
        )

        val trade2 = ClearedTrade(
            tradeId = "NOV-SELL-$originalTradeId",
            originalTradeId = originalTradeId,
            buyerMemberId = "SG-GOLD-CLEAR-CCP",
            sellerMemberId = sellerMemberId,
            instrument = instrument,
            quantityKg = quantityKg,
            price = price,
            currency = currency,
            tradeTimestamp = timestamp,
            clearingTimestamp = timestamp,
            settlementDate = settlementDate,
            deliveryType = deliveryType,
            marginRequirementSgd = marginReqSgd,
            status = TradeStatus.NOVATED
        )

        return listOf(trade1, trade2)
    }

    /**
     * Multilateral Position Netting calculation across active trades.
     */
    fun calculateNetPositions(clearedTrades: List<ClearedTrade>, goldPriceSgdPerKg: Double): Map<String, NetPosition> {
        val memberLongs = mutableMapOf<String, Double>()
        val memberShorts = mutableMapOf<String, Double>()
        val memberCashLegs = mutableMapOf<String, Double>()

        for (trade in clearedTrades) {
            if (trade.status == TradeStatus.SETTLED || trade.status == TradeStatus.CANCELLED) continue

            val valueSgd = trade.quantityKg * goldPriceSgdPerKg

            // Buyer leg
            if (trade.buyerMemberId != "SG-GOLD-CLEAR-CCP") {
                memberLongs[trade.buyerMemberId] = (memberLongs[trade.buyerMemberId] ?: 0.0) + trade.quantityKg
                memberCashLegs[trade.buyerMemberId] = (memberCashLegs[trade.buyerMemberId] ?: 0.0) - valueSgd
            }

            // Seller leg
            if (trade.sellerMemberId != "SG-GOLD-CLEAR-CCP") {
                memberShorts[trade.sellerMemberId] = (memberShorts[trade.sellerMemberId] ?: 0.0) + trade.quantityKg
                memberCashLegs[trade.sellerMemberId] = (memberCashLegs[trade.sellerMemberId] ?: 0.0) + valueSgd
            }
        }

        val allMembers = (memberLongs.keys + memberShorts.keys).toSet()
        val result = mutableMapOf<String, NetPosition>()

        for (memberId in allMembers) {
            val longKg = memberLongs[memberId] ?: 0.0
            val shortKg = memberShorts[memberId] ?: 0.0
            val netKg = longKg - shortKg
            val netCash = memberCashLegs[memberId] ?: 0.0

            result[memberId] = NetPosition(
                memberId = memberId,
                instrument = "XAU/SGD",
                settlementDate = "T+2 FINAL",
                grossLongKg = longKg,
                grossShortKg = shortKg,
                netObligationKg = netKg,
                netCashObligationSgd = netCash
            )
        }

        return result
    }
}
