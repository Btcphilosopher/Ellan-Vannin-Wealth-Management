package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ClearedTrade
import com.example.model.ClearingMember
import com.example.ui.components.MetricCard
import com.example.ui.components.StatusChip
import com.example.ui.theme.BorderDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.SteelGrey
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MemberTerminalScreen(
    members: List<ClearingMember>,
    selectedMemberId: String,
    clearedTrades: List<ClearedTrade>,
    onSelectMember: (String) -> Unit,
    onSubmitTrade: (buyerId: String, sellerId: String, instrument: String, qtyKg: Double, price: Double) -> Unit
) {
    val currentMember = members.find { it.memberId == selectedMemberId } ?: members.firstOrNull()

    var counterpartyId by remember { mutableStateOf("MAC") }
    var tradeQtyText by remember { mutableStateOf("50.0") }
    var tradePriceText by remember { mutableStateOf("110470.0") }
    var tradeDirection by remember { mutableStateOf("BUY") } // BUY or SELL

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Member Selector Pills
        item {
            Text(
                text = "CLEARING MEMBER TERMINAL // ACCOUNT PORTAL",
                color = GoldPrimary,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(members) { member ->
                    val isSelected = member.memberId == selectedMemberId
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) GoldPrimary else SurfaceDark)
                            .border(1.dp, if (isSelected) GoldPrimary else BorderDark, RoundedCornerShape(6.dp))
                            .clickable { onSelectMember(member.memberId) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("select_member_${member.memberId}")
                    ) {
                        Text(
                            text = "${member.memberId} (${member.legalName.take(15)}...)",
                            color = if (isSelected) SurfaceDark else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        if (currentMember != null) {
            // Detailed Gold Position Screen
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceDark)
                        .border(1.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = currentMember.legalName,
                                color = GoldPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Jurisdiction: ${currentMember.jurisdiction}",
                                color = SteelGrey,
                                fontSize = 11.sp
                            )
                        }
                        StatusChip(
                            statusText = currentMember.status.name,
                            color = if (currentMember.status == com.example.model.MemberStatus.ACTIVE) StatusGreen else StatusAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Position Metrics Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricCard(
                            label = "GROSS LONG",
                            value = "${"%.1f".format(currentMember.grossLongKg)} kg",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            label = "GROSS SHORT",
                            value = "${"%.1f".format(currentMember.grossShortKg)} kg",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            label = "NET POSITION",
                            value = "${if (currentMember.netPositionKg >= 0) "+" else ""}${"%.1f".format(currentMember.netPositionKg)} kg",
                            statusColor = if (currentMember.netPositionKg >= 0) StatusGreen else StatusRed,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricCard(
                            label = "ALLOCATED GOLD",
                            value = "${"%.1f".format(currentMember.allocatedGoldKg)} kg",
                            subtitle = "In Vault",
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            label = "UNALLOCATED BAL",
                            value = "${"%.1f".format(currentMember.unallocatedGoldKg)} kg",
                            subtitle = "Clearing Account",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Collateral & Margin Breakdown Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(SurfaceElevated)
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = "COLLATERAL & MARGIN REQUIREMENT",
                                color = SteelGrey,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Cash Collateral (SGD): $${"%.2f".format(currentMember.cashCollateralSgd / 1e6)}M",
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Gold Collateral: $${"%.2f".format(currentMember.goldCollateralSgd / 1e6)}M",
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Initial Margin Req: $${"%.2f".format(currentMember.initialMarginRequiredSgd / 1e6)}M",
                                    color = StatusAmber,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "Available Excess: $${"%.2f".format(currentMember.availableCollateralSgd / 1e6)}M",
                                    color = StatusGreen,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // New Trade Order Entry Form
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceDark)
                        .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = "SUBMIT BILATERAL TRADE FOR CCP NOVATION",
                        color = GoldPrimary,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { tradeDirection = "BUY" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tradeDirection == "BUY") StatusGreen else SurfaceElevated
                            ),
                            modifier = Modifier.weight(1f).testTag("trade_direction_buy")
                        ) {
                            Text("BUY GOLD", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { tradeDirection = "SELL" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tradeDirection == "SELL") StatusRed else SurfaceElevated
                            ),
                            modifier = Modifier.weight(1f).testTag("trade_direction_sell")
                        ) {
                            Text("SELL GOLD", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = counterpartyId,
                            onValueChange = { counterpartyId = it },
                            label = { Text("Counterparty Member") },
                            modifier = Modifier.weight(1f).testTag("counterparty_input")
                        )
                        OutlinedTextField(
                            value = tradeQtyText,
                            onValueChange = { tradeQtyText = it },
                            label = { Text("Quantity (kg)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("trade_qty_input")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = tradePriceText,
                        onValueChange = { tradePriceText = it },
                        label = { Text("Spot Price (SGD / kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().testTag("trade_price_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val qty = tradeQtyText.toDoubleOrNull() ?: 10.0
                            val px = tradePriceText.toDoubleOrNull() ?: 110470.0
                            if (tradeDirection == "BUY") {
                                onSubmitTrade(currentMember.memberId, counterpartyId, "XAU/SGD", qty, px)
                            } else {
                                onSubmitTrade(counterpartyId, currentMember.memberId, "XAU/SGD", qty, px)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        modifier = Modifier.fillMaxWidth().testTag("submit_trade_button")
                    ) {
                        Text(
                            text = "SUBMIT TRADE TO CCP NOVATION GATEWAY",
                            color = SurfaceDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Member Trades History
            item {
                Text(
                    text = "MEMBER OBLIGATIONS HISTORY",
                    color = GoldPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            val memberTrades = clearedTrades.filter {
                it.buyerMemberId == currentMember.memberId || it.sellerMemberId == currentMember.memberId
            }

            items(memberTrades) { trade ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceDark)
                        .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = trade.tradeId, color = GoldPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                text = "Role: ${if (trade.buyerMemberId == currentMember.memberId) "BUYER" else "SELLER"} | Settle: ${trade.settlementDate}",
                                color = TextPrimary,
                                fontSize = 11.sp
                            )
                        }
                        Text(
                            text = "${trade.quantityKg} kg @ SGD ${trade.price}",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
