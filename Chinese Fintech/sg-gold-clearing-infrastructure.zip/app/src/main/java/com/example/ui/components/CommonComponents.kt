package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Badge
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MarketQuote
import com.example.model.BarAllocationStatus
import com.example.model.BarInspectionStatus
import com.example.model.GoldBar
import com.example.model.MemberStatus
import com.example.model.TradeStatus
import com.example.ui.theme.BorderDark
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldVariant
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.SingaporeRed
import com.example.ui.theme.StatusAmber
import com.example.ui.theme.StatusBlue
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.SteelGrey
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun InstitutionalTopHeader(
    quotes: List<MarketQuote>,
    isTickerRunning: Boolean,
    onToggleTicker: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(NavyDeep)
            .border(1.dp, BorderDark)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(GoldDark)
                        .border(1.dp, GoldPrimary, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "SG Gold Crest",
                        tint = GoldVariant,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "SG-GOLD CLEAR",
                            style = MaterialTheme.typography.titleLarge,
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(SingaporeRed.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "SINGAPORE CCP",
                                color = SingaporeRed,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "Singapore Institutional Precious Metals Clearing & Vault Infrastructure",
                        style = MaterialTheme.typography.labelSmall,
                        color = SteelGrey
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(SurfaceDark)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isTickerRunning) StatusGreen else StatusAmber)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isTickerRunning) "LIVE TICKER" else "PAUSED",
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                IconButton(onClick = onToggleTicker, modifier = Modifier.testTag("toggle_ticker_button")) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Toggle Ticker",
                        tint = GoldPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Live Market Ticker Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(SurfaceDark)
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val sgdQuote = quotes.find { it.pair == "XAU/SGD" }
            val usdQuote = quotes.find { it.pair == "XAU/USD" }
            val cnhQuote = quotes.find { it.pair == "XAU/CNH" }

            TickerItem(pair = "XAU/SGD (Spot)", value = "SGD ${"%.2f".format(sgdQuote?.spot ?: 110470.0)}/kg", change = sgdQuote?.change24hPct ?: 0.8)
            TickerItem(pair = "XAU/USD", value = "$${"%.2f".format(usdQuote?.spot ?: 2741.0)}/oz", change = usdQuote?.change24hPct ?: 0.6)
            TickerItem(pair = "XAU/CNH", value = "¥${"%.1f".format(cnhQuote?.spot ?: 19487.5)}/oz", change = cnhQuote?.change24hPct ?: 0.45)
            TickerItem(pair = "SG Vault Premium", value = "+$1.20/oz", change = 0.0)
        }
    }
}

@Composable
fun TickerItem(pair: String, value: String, change: Double) {
    Column {
        Text(text = pair, color = SteelGrey, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = value, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.width(4.dp))
            val color = if (change >= 0) StatusGreen else StatusRed
            val prefix = if (change >= 0) "+" else ""
            Text(text = "$prefix${"%.2f".format(change)}%", color = color, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun TerminalTabSelector(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit
) {
    val tabs = listOf(
        Pair("CCP Control", Icons.Default.Security),
        Pair("Member Terminal", Icons.Default.AccountBalance),
        Pair("Vault Digital Twin", Icons.Default.ViewInAr),
        Pair("Risk & Scenario Lab", Icons.Default.Analytics),
        Pair("API & CLI Console", Icons.Default.Code),
        Pair("18-Step Walkthrough", Icons.Default.SwapHoriz)
    )

    ScrollableTabRow(
        selectedTabIndex = selectedTab,
        containerColor = SurfaceDark,
        contentColor = GoldPrimary,
        edgePadding = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        tabs.forEachIndexed { index, pair ->
            Tab(
                selected = selectedTab == index,
                onClick = { onTabSelected(index) },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = pair.second,
                            contentDescription = pair.first,
                            modifier = Modifier.size(16.dp),
                            tint = if (selectedTab == index) GoldPrimary else SteelGrey
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = pair.first,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) GoldPrimary else SteelGrey
                        )
                    }
                },
                modifier = Modifier.testTag("terminal_tab_$index")
            )
        }
    }
}

@Composable
fun MetricCard(
    label: String,
    value: String,
    subtitle: String? = null,
    statusColor: Color = GoldPrimary,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceDark)
            .border(1.dp, BorderDark, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(text = label, color = SteelGrey, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            if (subtitle != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = subtitle, color = statusColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun StatusChip(statusText: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = statusText,
            color = color,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun BarListItemCard(
    bar: GoldBar,
    onInspectClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceDark)
            .border(1.dp, if (bar.allocationStatus == BarAllocationStatus.ALLOCATED) GoldPrimary.copy(alpha = 0.4f) else BorderDark, RoundedCornerShape(8.dp))
            .clickable { onInspectClick() }
            .padding(12.dp)
            .testTag("bar_card_${bar.barId}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = bar.serialNumber,
                        color = GoldPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val allocColor = when (bar.allocationStatus) {
                        BarAllocationStatus.ALLOCATED -> StatusGreen
                        BarAllocationStatus.UNALLOCATED -> StatusBlue
                        BarAllocationStatus.PLEDGED, BarAllocationStatus.ENCUMBERED -> StatusAmber
                        else -> SteelGrey
                    }
                    StatusChip(statusText = bar.allocationStatus.name, color = allocColor)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${bar.weightClass.label} • ${bar.refiner} • Fineness: ${bar.fineness}",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Text(
                    text = "Vault: ${bar.vaultName} | Owner: ${bar.ownerMemberId}",
                    color = SteelGrey,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${"%.3f".format(bar.fineGoldWeightKg)} kg",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Fine Gold",
                    color = SteelGrey,
                    fontSize = 10.sp
                )
            }
        }
    }
}
