package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HktdColorScheme = darkColorScheme(
    primary = HktdCyan,
    onPrimary = HktdBackground,
    primaryContainer = HktdSurfaceVariant,
    onPrimaryContainer = HktdCyan,
    secondary = HktdBlue,
    onSecondary = HktdTextPrimary,
    background = HktdBackground,
    onBackground = HktdTextPrimary,
    surface = HktdSurface,
    onSurface = HktdTextPrimary,
    surfaceVariant = HktdSurfaceVariant,
    onSurfaceVariant = HktdTextSecondary,
    outline = HktdBorder,
    error = HktdRed,
    onError = HktdBackground
)

@Composable
fun HktdTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HktdColorScheme,
        typography = Typography,
        content = content
    )
}
