package com.example.data.local

import androidx.room.*

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val accountId: String,
    val institutionName: String,
    val instrumentId: String,
    val side: String,
    val orderType: String,
    val price: Double,
    val quantity: Long,
    val filledQuantity: Long,
    val avgExecutionPrice: Double,
    val status: String,
    val timeInForce: String,
    val timestamp: Long,
    val rejectReason: String?,
    val latencyNs: Long
)

@Entity(tableName = "positions")
data class PositionEntity(
    @PrimaryKey val key: String, // accountId_instrumentId
    val accountId: String,
    val instrumentId: String,
    val quantity: Long,
    val avgPrice: Double,
    val currency: String,
    val realizedPnlHkd: Double
)

@Entity(tableName = "executions")
data class ExecutionEntity(
    @PrimaryKey val executionId: String,
    val orderId: String,
    val accountId: String,
    val instrumentId: String,
    val side: String,
    val price: Double,
    val quantity: Long,
    val fee: Double,
    val currency: String,
    val timestamp: Long,
    val execType: String
)

@Entity(tableName = "ledger")
data class LedgerEntity(
    @PrimaryKey val id: String,
    val account: String,
    val debitAccount: String,
    val creditAccount: String,
    val amount: Double,
    val currency: String,
    val description: String,
    val timestamp: Long
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String,
    val details: String,
    val category: String,
    val timestamp: Long
)
