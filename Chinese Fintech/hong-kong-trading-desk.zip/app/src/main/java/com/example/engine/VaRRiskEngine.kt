package com.example.engine

import com.example.data.model.Position
import com.example.data.model.StressScenario
import com.example.data.model.VaRMetrics
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.sqrt

class VaRRiskEngine {

    private val _varMetrics = MutableStateFlow(VaRMetrics())
    val varMetrics: StateFlow<VaRMetrics> = _varMetrics.asStateFlow()

    private val _stressScenarios = MutableStateFlow<List<StressScenario>>(emptyList())
    val stressScenarios: StateFlow<List<StressScenario>> = _stressScenarios.asStateFlow()

    init {
        loadScenarios()
    }

    private fun loadScenarios() {
        _stressScenarios.value = listOf(
            StressScenario(
                id = "SCEN-01",
                nameCn = "港幣聯繫匯率壓測 (HKD Peg Dislocation)",
                nameEn = "HKD Peg Shock",
                shockDescription = "USD/HKD 匯率大幅波動突破 7.85 強方保證，港元流動性驟緊",
                simulatedLossHkd = 28_500_000.0,
                varImpactPct = +125.0
            ),
            StressScenario(
                id = "SCEN-02",
                nameCn = "離岸人民幣突發貶值 (CNH Rapid Depreciation)",
                nameEn = "CNH Depreciation",
                shockDescription = "USD/CNH 向上突破 7.35，中資股與跨境人幣資產估值回撤",
                simulatedLossHkd = 42_200_000.0,
                varImpactPct = +180.0
            ),
            StressScenario(
                id = "SCEN-03",
                nameCn = "恆指及科技股深度下挫 (China Equity Sell-Off)",
                nameEn = "China Equity Sell-Off",
                shockDescription = "恆生科技指數單日暴跌 8.5%，流動性偏緊引發程序化平倉",
                simulatedLossHkd = 65_800_000.0,
                varImpactPct = +210.0
            ),
            StressScenario(
                id = "SCEN-04",
                nameCn = "香港地產與商業信貸衝擊 (HK Property Shock)",
                nameEn = "HK Property Shock",
                shockDescription = "商業地產重估降價 15%，地產板塊龍頭股賣壓加大",
                simulatedLossHkd = 19_400_000.0,
                varImpactPct = +85.0
            ),
            StressScenario(
                id = "SCEN-05",
                nameCn = "美聯儲利率鷹派衝擊 (US Rate Shock)",
                nameEn = "US Rate Shock",
                shockDescription = "美聯儲無預期加息 50bps，10年期美債收益率急升引發全球資本回流",
                simulatedLossHkd = 31_000_000.0,
                varImpactPct = +110.0
            )
        )
    }

    fun recalculateRisk(positions: List<Position>) {
        val grossExposure = positions.sumOf { Math.abs(it.marketValueHkd) }
        val netExposure = positions.sumOf { it.marketValueHkd }

        val portfolioVol = 0.018 // 1.8% daily vol assumption
        val z99 = 2.326 // 99% confidence z-score

        val var1d = grossExposure * portfolioVol * z99
        val var5d = var1d * sqrt(5.0)
        val var10d = var1d * sqrt(10.0)
        val expectedShortfall = var1d * 1.35
        val stressLoss = grossExposure * 0.08

        _varMetrics.value = VaRMetrics(
            var1d99PctHkd = if (var1d > 0) var1d else 12_450_000.0,
            var5d99PctHkd = if (var5d > 0) var5d else 27_800_000.0,
            var10d99PctHkd = if (var10d > 0) var10d else 39_200_000.0,
            expectedShortfallHkd = if (expectedShortfall > 0) expectedShortfall else 16_800_000.0,
            stressLossHkd = if (stressLoss > 0) stressLoss else 45_000_000.0,
            grossExposureHkd = grossExposure,
            netExposureHkd = netExposure,
            currentLeverage = if (grossExposure > 0) (grossExposure / 250_000_000.0) else 1.0,
            portfolioBeta = 1.08,
            sharpeRatio = 1.92
        )
    }
}
