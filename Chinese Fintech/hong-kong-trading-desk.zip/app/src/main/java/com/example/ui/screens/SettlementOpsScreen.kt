package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Formatters
import com.example.ui.components.CardContainer
import com.example.ui.theme.*
import com.example.ui.viewmodel.HKTDViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SettlementOpsScreen(viewModel: HKTDViewModel) {
    val ledgerRecords = viewModel.portfolioEngine.ledgerRecords.collectAsState().value
    val cashBalances = viewModel.portfolioEngine.cashBalances.collectAsState().value
    val reconciliationStatus = viewModel.reconciliationStatus.collectAsState().value

    val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HktdBackground)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Multi-Currency Cash Ledger
        item {
            CardContainer(
                titleCn = "多幣種資金頭寸 (Multi-Currency Cash Balances)",
                titleEn = "Base Currency: HKD"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    cashBalances.entries.forEach { entry ->
                        val ccy = entry.key
                        val amt = entry.value
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(HktdSurfaceVariant)
                                .padding(8.dp)
                        ) {
                            Text("$ccy 現金頭寸", color = HktdTextSecondary, fontSize = 9.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(Formatters.formatMoney(amt), color = HktdCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Daily Reconciliation Trigger
        item {
            CardContainer(
                titleCn = "日終自動對賬與核算 (Automated Daily Reconciliation)",
                titleEn = "Broker vs OMS vs Ledger"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = reconciliationStatus,
                        color = HktdGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Button(
                        onClick = { viewModel.triggerReconciliation() },
                        colors = ButtonDefaults.buttonColors(containerColor = HktdBlue),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().height(34.dp).testTag("trigger_reconciliation_button")
                    ) {
                        Text("啟動 T+0 系統自動對賬核驗 / Run System Reconciliation", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Double-Entry General Ledger
        item {
            CardContainer(
                titleCn = "複式簿記總賬 (Double-Entry General Ledger)",
                titleEn = "Balanced Accounting Log"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ledgerRecords.take(10).forEach { record ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(HktdSurfaceVariant)
                                .border(width = 0.5.dp, color = HktdBorder)
                                .padding(6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.2f)) {
                                Text(record.id, color = HktdGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(record.description, color = HktdTextPrimary, fontSize = 10.sp)
                                Text(sdf.format(Date(record.timestamp)), color = HktdTextMuted, fontSize = 8.sp)
                            }

                            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                Text("${record.currency} ${Formatters.formatMoney(record.amount)}", color = HktdCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("借: ${record.debitAccount} | 貸: ${record.creditAccount}", color = HktdTextSecondary, fontSize = 8.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
