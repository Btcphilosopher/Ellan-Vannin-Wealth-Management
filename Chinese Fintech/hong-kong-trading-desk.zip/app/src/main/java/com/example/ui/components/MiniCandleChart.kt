package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.model.Instrument
import com.example.ui.theme.HktdGreen
import com.example.ui.theme.HktdRed
import kotlin.random.Random

@Composable
fun MiniCandleChart(instrument: Instrument?, modifier: Modifier = Modifier.height(140.dp).fillMaxWidth()) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val candleCount = 24
        val barWidth = (width / candleCount) * 0.7f
        val gap = (width / candleCount) * 0.3f

        val basePx = instrument?.lastPrice ?: 100.0
        val candles = (0 until candleCount).map { i ->
            val factor = (Math.sin(i * 0.3) * 0.015) + (Random.nextDouble() * 0.01 - 0.005)
            val open = basePx * (1.0 + factor)
            val close = open * (1.0 + (Random.nextDouble() * 0.012 - 0.006))
            val high = maxOf(open, close) * (1.0 + Random.nextDouble() * 0.004)
            val low = minOf(open, close) * (1.0 - Random.nextDouble() * 0.004)
            val vol = Random.nextInt(500, 5000).toFloat()
            CandleData(open, close, high, low, vol)
        }

        val minPx = candles.minOf { it.low }
        val maxPx = candles.maxOf { it.high }
        val pxRange = if (maxPx - minPx > 0) (maxPx - minPx) else 1.0

        candles.forEachIndexed { i, c ->
            val x = i * (barWidth + gap) + gap / 2
            val isGreen = c.close >= c.open
            val color = if (isGreen) HktdGreen else HktdRed

            // High/Low line
            val yHigh = height * (1f - ((c.high - minPx) / pxRange).toFloat())
            val yLow = height * (1f - ((c.low - minPx) / pxRange).toFloat())
            drawLine(
                color = color,
                start = Offset(x + barWidth / 2, yHigh),
                end = Offset(x + barWidth / 2, yLow),
                strokeWidth = 2f
            )

            // Body
            val yOpen = height * (1f - ((c.open - minPx) / pxRange).toFloat())
            val yClose = height * (1f - ((c.close - minPx) / pxRange).toFloat())
            val bodyTop = minOf(yOpen, yClose)
            val bodyHeight = maxOf(Math.abs(yOpen - yClose), 4f)

            drawRect(
                color = color,
                topLeft = Offset(x, bodyTop),
                size = Size(barWidth, bodyHeight)
            )
        }
    }
}

private data class CandleData(
    val open: Double,
    val close: Double,
    val high: Double,
    val low: Double,
    val volume: Float
)
