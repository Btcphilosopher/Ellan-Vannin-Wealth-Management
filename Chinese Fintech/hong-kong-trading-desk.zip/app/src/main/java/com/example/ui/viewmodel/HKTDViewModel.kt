package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.HktdDatabase
import com.example.data.model.*
import com.example.engine.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class HktdTab(val titleCn: String, val titleEn: String) {
    MARKET_OVERVIEW("市場總覽", "Market Overview"),
    TRADING_DESK("交易台", "Trading Desk"),
    OMS_EMS("OMS / EMS 訂單", "OMS / EMS"),
    RISK_VAR("風控與 VaR", "Risk & VaR"),
    QUANT_LAB("量化研究", "Quant Lab"),
    LATENCY_LAB("時延與微結構", "Latency & Microstructure"),
    API_FIX("API & FIX 終端", "API & FIX Terminal"),
    SETTLEMENT_OPS("結算與對賬", "Settlement & Ops")
}

class HKTDViewModel(application: Application) : AndroidViewModel(application) {

    private val db = HktdDatabase.getDatabase(application)
    
    // Engines
    val marketDataEngine = MarketDataEngine(viewModelScope)
    val portfolioEngine = PortfolioEngine()
    val riskGate = PreTradeRiskGate()
    val latencyTracker = LatencyTracker()
    val matchingEngine = OrderMatchingEngine(viewModelScope, marketDataEngine, portfolioEngine, riskGate, latencyTracker)
    val varRiskEngine = VaRRiskEngine()
    val backtestEngine = BacktestEngine()

    // Navigation & UI State
    private val _activeTab = MutableStateFlow(HktdTab.MARKET_OVERVIEW)
    val activeTab: StateFlow<HktdTab> = _activeTab.asStateFlow()

    private val _selectedInstrumentId = MutableStateFlow("00005.HK")
    val selectedInstrumentId: StateFlow<String> = _selectedInstrumentId.asStateFlow()

    private val _riskConfig = MutableStateFlow(PreTradeRiskConfig())
    val riskConfig: StateFlow<PreTradeRiskConfig> = _riskConfig.asStateFlow()

    private val _latestBacktest = MutableStateFlow<QuantBacktestResult?>(null)
    val latestBacktest: StateFlow<QuantBacktestResult?> = _latestBacktest.asStateFlow()

    private val _reconciliationStatus = MutableStateFlow("系統已完成 T+0 自動對賬，所有成交筆數及資金完全匹配 (0 差異)")
    val reconciliationStatus: StateFlow<String> = _reconciliationStatus.asStateFlow()

    init {
        // Observe positions and update VaR Risk Engine
        viewModelScope.launch {
            portfolioEngine.positions.collect { positions ->
                varRiskEngine.recalculateRisk(positions)
            }
        }

        // Observe market ticks and update portfolio market values
        viewModelScope.launch {
            marketDataEngine.instruments.collect { insts ->
                portfolioEngine.updatePrices(insts)
            }
        }
    }

    fun setActiveTab(tab: HktdTab) {
        _activeTab.value = tab
    }

    fun selectInstrument(id: String) {
        _selectedInstrumentId.value = id
    }

    fun submitOrder(
        side: OrderSide,
        orderType: OrderType,
        price: Double,
        quantity: Long,
        accountId: String = "HK-DESK-01",
        institutionName: String = "Victoria Securities (維多利亞證券)"
    ) {
        matchingEngine.submitOrder(
            accountId = accountId,
            institutionName = institutionName,
            instrumentId = _selectedInstrumentId.value,
            side = side,
            orderType = orderType,
            price = price,
            quantity = quantity,
            riskConfig = _riskConfig.value
        )
    }

    fun cancelOrder(orderId: String) {
        matchingEngine.cancelOrder(orderId)
    }

    fun toggleGlobalKillSwitch() {
        val current = _riskConfig.value
        val updated = current.copy(globalKillSwitch = !current.globalKillSwitch)
        _riskConfig.value = updated
        if (updated.globalKillSwitch) {
            matchingEngine.cancelAllOrders()
        }
    }

    fun updateRiskLimits(maxNotional: Double, maxQty: Long, priceCollar: Double) {
        _riskConfig.value = _riskConfig.value.copy(
            maxOrderNotionalHkd = maxNotional,
            maxOrderQuantity = maxQty,
            priceCollarPct = priceCollar
        )
    }

    fun runQuantBacktest(strategyName: String) {
        val res = backtestEngine.runBacktest(strategyName, _selectedInstrumentId.value)
        _latestBacktest.value = res
    }

    fun triggerReconciliation() {
        _reconciliationStatus.value = "對賬程序已啟動：核對 OMS(${matchingEngine.orders.value.size}筆) vs 交易所執行表(${matchingEngine.executions.value.size}筆) vs 總賬... 差異：0筆"
    }
}
