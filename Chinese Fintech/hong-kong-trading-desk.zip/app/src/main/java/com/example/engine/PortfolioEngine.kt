package com.example.engine

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

class PortfolioEngine {

    private val _positions = MutableStateFlow<List<Position>>(emptyList())
    val positions: StateFlow<List<Position>> = _positions.asStateFlow()

    private val _ledgerRecords = MutableStateFlow<List<LedgerRecord>>(emptyList())
    val ledgerRecords: StateFlow<List<LedgerRecord>> = _ledgerRecords.asStateFlow()

    private val _cashBalances = MutableStateFlow<Map<String, Double>>(
        mapOf("HKD" to 250_000_000.0, "USD" to 15_000_000.0, "CNH" to 50_000_000.0)
    )
    val cashBalances: StateFlow<Map<String, Double>> = _cashBalances.asStateFlow()

    init {
        seedInitialPortfolio()
    }

    private fun seedInitialPortfolio() {
        val initialPositions = listOf(
            Position("HK-DESK-01", "00005.HK", 120_000L, 345.50, 350.20, "HKD", 120000 * 350.20, (350.20 - 345.50) * 120000, 48000.0),
            Position("HK-DESK-01", "00700.HK", 45_000L, 382.00, 385.60, "HKD", 45000 * 385.60, (385.60 - 382.00) * 45000, 125000.0),
            Position("HK-DESK-01", "09988.HK", 80_000L, 81.00, 82.40, "HKD", 80000 * 82.40, (82.40 - 81.00) * 80000, 32000.0),
            Position("HK-DESK-01", "USD/CNH", 2_000_000L, 7.1180, 7.1230, "CNH", 2000000 * 7.1230 * 1.10, (7.1230 - 7.1180) * 2000000 * 1.10, 15000.0)
        )
        _positions.value = initialPositions

        // Seed initial double-entry ledger entries
        _ledgerRecords.value = listOf(
            LedgerRecord("L-1001", "HK-DESK-01", "CASH_HKD", "CAPITAL_EQUITY", 250_000_000.0, "HKD", "Institutional Capital Allocation / 機構注資", System.currentTimeMillis() - 86400000L * 5),
            LedgerRecord("L-1002", "HK-DESK-01", "SECURITIES_00005", "CASH_HKD", 41_460_000.0, "HKD", "Bought 120,000 00005.HK @ 345.50", System.currentTimeMillis() - 86400000L * 2),
            LedgerRecord("L-1003", "HK-DESK-01", "FEE_EXPENSE", "CASH_HKD", 20_730.0, "HKD", "HKEX Stamp Duty & Trading Fee 0.05%", System.currentTimeMillis() - 86400000L * 2)
        )
    }

    fun onTradeExecuted(execution: Execution, instrument: Instrument?) {
        val px = execution.price
        val qty = execution.quantity
        val notional = px * qty
        val instId = execution.instrumentId
        val side = execution.side
        val ccy = execution.currency

        val currentList = _positions.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.instrumentId == instId && it.accountId == execution.accountId }

        if (existingIndex >= 0) {
            val p = currentList[existingIndex]
            val newQty = if (side == OrderSide.BUY) p.quantity + qty else p.quantity - qty
            val newAvgPx = if (side == OrderSide.BUY && newQty > 0) {
                ((p.quantity * p.avgPrice) + (qty * px)) / newQty
            } else p.avgPrice

            val realizedChange = if (side == OrderSide.SELL) {
                (px - p.avgPrice) * qty
            } else 0.0

            val updatedPos = p.copy(
                quantity = newQty,
                avgPrice = newAvgPx,
                currentPrice = px,
                marketValueHkd = newQty * px * (if (ccy == "USD") 7.82 else 1.0),
                unrealizedPnlHkd = (px - newAvgPx) * newQty * (if (ccy == "USD") 7.82 else 1.0),
                realizedPnlHkd = p.realizedPnlHkd + realizedChange
            )
            if (newQty == 0L) {
                currentList.removeAt(existingIndex)
            } else {
                currentList[existingIndex] = updatedPos
            }
        } else if (side == OrderSide.BUY) {
            val newPos = Position(
                accountId = execution.accountId,
                instrumentId = instId,
                quantity = qty,
                avgPrice = px,
                currentPrice = px,
                currency = ccy,
                marketValueHkd = notional * (if (ccy == "USD") 7.82 else 1.0),
                unrealizedPnlHkd = 0.0,
                realizedPnlHkd = 0.0
            )
            currentList.add(newPos)
        }
        _positions.value = currentList

        // Deduct/Add Cash Balance
        val currentCash = _cashBalances.value.toMutableMap()
        val ccyCash = currentCash[ccy] ?: 0.0
        val cashDelta = if (side == OrderSide.BUY) -notional - execution.fee else notional - execution.fee
        currentCash[ccy] = ccyCash + cashDelta
        _cashBalances.value = currentCash

        // Record Double Entry Ledger
        val ledgerList = _ledgerRecords.value.toMutableList()
        val ledgerId = "L-${System.currentTimeMillis().toString().takeLast(6)}"
        val debitAcc = if (side == OrderSide.BUY) "SECURITIES_$instId" else "CASH_$ccy"
        val creditAcc = if (side == OrderSide.BUY) "CASH_$ccy" else "SECURITIES_$instId"

        val record = LedgerRecord(
            id = ledgerId,
            account = execution.accountId,
            debitAccount = debitAcc,
            creditAccount = creditAcc,
            amount = notional,
            currency = ccy,
            description = "${side.name} $qty $instId @ $px ($ccy)",
            timestamp = System.currentTimeMillis()
        )
        ledgerList.add(0, record)
        _ledgerRecords.value = ledgerList
    }

    fun updatePrices(instruments: List<Instrument>) {
        val currentPos = _positions.value.map { pos ->
            val inst = instruments.find { it.id == pos.instrumentId }
            if (inst != null) {
                val curPx = inst.lastPrice
                val mktVal = pos.quantity * curPx * (if (pos.currency == "USD") 7.82 else 1.0)
                val unPnl = (curPx - pos.avgPrice) * pos.quantity * (if (pos.currency == "USD") 7.82 else 1.0)
                pos.copy(currentPrice = curPx, marketValueHkd = mktVal, unrealizedPnlHkd = unPnl)
            } else pos
        }
        _positions.value = currentPos
    }
}
