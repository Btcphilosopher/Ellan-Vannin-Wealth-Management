package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CardContainer
import com.example.ui.theme.*
import com.example.ui.viewmodel.HKTDViewModel

@Composable
fun ApiFixScreen(viewModel: HKTDViewModel) {
    val fixMessages = viewModel.matchingEngine.fixMessages.collectAsState().value
    var selectedEndpoint by remember { mutableStateOf("POST /api/v1/orders") }
    var apiResponseJson by remember { mutableStateOf<String?>(null) }

    val endpoints = listOf(
        "POST /api/v1/orders",
        "GET /api/v1/orders/{order_id}",
        "GET /api/v1/positions",
        "GET /api/v1/orderbook",
        "GET /api/v1/risk",
        "GET /api/v1/pnl"
    )

    val sampleRequestJson = """
{
  "account_id": "HK-DESK-01",
  "instrument": "${viewModel.selectedInstrumentId.collectAsState().value}",
  "side": "BUY",
  "quantity": 10000,
  "order_type": "LIMIT",
  "price": 350.20,
  "time_in_force": "DAY"
}
    """.trimIndent()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HktdBackground)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // OpenAPI / REST Explorer Panel
        item {
            CardContainer(
                titleCn = "OpenAPI / REST 結構化接口 (Institutional REST API)",
                titleEn = "v1 / JSON Specification"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("可調用 API 端點 (Select API Endpoint):", color = HktdTextSecondary, fontSize = 10.sp)

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(endpoints) { ep ->
                            val isSel = ep == selectedEndpoint
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) HktdCyan else HktdSurfaceVariant)
                                    .border(width = 0.5.dp, color = HktdBorder, shape = RoundedCornerShape(6.dp))
                                    .clickable {
                                        selectedEndpoint = ep
                                        apiResponseJson = null
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                    .testTag("api_endpoint_$ep")
                            ) {
                                Text(ep, color = if (isSel) HktdBackground else HktdTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Request Payload
                        Column(modifier = Modifier.weight(1f)) {
                            Text("請求 Body (Request JSON):", color = HktdTextSecondary, fontSize = 10.sp)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(HktdHeaderBg)
                                    .border(width = 0.5.dp, color = HktdBorder)
                                    .padding(6.dp)
                            ) {
                                Text(sampleRequestJson, color = HktdCyan, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                            }
                        }

                        // Response Payload
                        Column(modifier = Modifier.weight(1f)) {
                            Text("響應 Response (200 OK):", color = HktdTextSecondary, fontSize = 10.sp)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(HktdHeaderBg)
                                    .border(width = 0.5.dp, color = HktdBorder)
                                    .padding(6.dp)
                            ) {
                                Text(
                                    text = apiResponseJson ?: "點擊下方按鈕測試 API 請求...",
                                    color = if (apiResponseJson != null) HktdGreen else HktdTextMuted,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            apiResponseJson = """
{
  "status": "SUCCESS",
  "code": 200,
  "order_id": "ORD-82910392",
  "timestamp": "${System.currentTimeMillis()}",
  "instrument": "00005.HK",
  "executed_qty": 10000,
  "avg_price": 350.20,
  "latency_us": 182.4
}
                            """.trimIndent()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HktdBlue),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().height(32.dp).testTag("test_api_request_button")
                    ) {
                        Text("測試發送 REST 請求 / Send API Test Request", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Real-Time FIX Protocol Stream & Drop Copy
        item {
            CardContainer(
                titleCn = "FIX Protocol / Drop-Copy 實時報文流 (FIX Stream)",
                titleEn = "Protocol Adapter • Tag Breakdown"
            ) {
                if (fixMessages.isEmpty()) {
                    Text("尚未產生 FIX 報文。請前往【交易台】提交訂單...", color = HktdTextSecondary, fontSize = 11.sp, modifier = Modifier.padding(vertical = 12.dp))
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        fixMessages.take(8).forEach { fix ->
                            val isInbound = fix.direction == "INBOUND"
                            val dirColor = if (isInbound) HktdGreen else HktdCyan

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(HktdSurfaceVariant)
                                    .border(width = 0.5.dp, color = HktdBorder)
                                    .padding(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("[${fix.direction}] MsgType: ${fix.msgType}", color = dirColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text("Seq #${fix.sequence}", color = HktdTextMuted, fontSize = 9.sp)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = fix.rawFix,
                                    color = HktdTextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
