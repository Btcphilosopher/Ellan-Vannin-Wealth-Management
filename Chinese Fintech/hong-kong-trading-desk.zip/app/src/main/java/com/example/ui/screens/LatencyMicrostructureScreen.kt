package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CardContainer
import com.example.ui.theme.*
import com.example.ui.viewmodel.HKTDViewModel

@Composable
fun LatencyMicrostructureScreen(viewModel: HKTDViewModel) {
    val latencyMetrics = viewModel.latencyTracker.latencyMetrics.collectAsState().value
    val recentBreakdowns = viewModel.latencyTracker.recentBreakdowns.collectAsState().value

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HktdBackground)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Stage-by-Stage Latency Distribution Matrix
        item {
            CardContainer(
                titleCn = "交易管線分階段時延分佈 (Stage-by-Stage Latency Telemetry)",
                titleEn = "Unit: Microseconds (μs)",
                trailingText = "Target: < 500 μs"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(HktdSurfaceVariant)
                            .padding(vertical = 4.dp, horizontal = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("處理階段 / Stage", color = HktdTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                        Text("P50", color = HktdCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("P95", color = HktdCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("P99", color = HktdGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("P99.9", color = HktdRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    }

                    latencyMetrics.forEach { metric ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(metric.stage, color = HktdTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1.5f))
                            Text("${metric.p50Micros} μs", color = HktdTextPrimary, fontSize = 10.sp, modifier = Modifier.weight(1f))
                            Text("${metric.p95Micros} μs", color = HktdTextPrimary, fontSize = 10.sp, modifier = Modifier.weight(1f))
                            Text("${metric.p99Micros} μs", color = HktdGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("${metric.p999Micros} μs", color = HktdRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // Live Real-Time Latency Execution Audit
        item {
            CardContainer(
                titleCn = "實時訂單處理時延追蹤 (Real-Time Order Processing Breakdown)",
                titleEn = "Nanosecond Audit Log"
            ) {
                if (recentBreakdowns.isEmpty()) {
                    Text("請前往【交易台】提交訂單以記錄實時時延數據...", color = HktdTextSecondary, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp))
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        recentBreakdowns.take(6).forEachIndexed { index, bd ->
                            val totalMicros = bd.totalNs / 1000.0
                            val (color, label) = when {
                                totalMicros < 400.0 -> HktdGreen to "超低時延 ULTRA-LOW"
                                totalMicros < 800.0 -> HktdCyan to "正常 NORMAL"
                                else -> HktdAmber to "高偏置 HIGH"
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(HktdSurfaceVariant)
                                    .padding(6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("#${index + 1} 訂單穿透總時延:", color = HktdTextSecondary, fontSize = 10.sp)
                                Text("${String.format("%.1f", totalMicros)} μs (${bd.totalNs} ns)", color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(color.copy(alpha = 0.2f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Market Microstructure Lab Metrics
        item {
            CardContainer(
                titleCn = "市場微觀結構與執行品質 (Market Microstructure Metrics)",
                titleEn = "Order Flow Telemetry"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MicroBox(title = "買賣價差 Spread", value = "0.05 HKD", detail = "Average 1.2 ticks")
                    MicroBox(title = "市場衝擊 Market Impact", value = "1.2 bps", detail = "Square-root model")
                    MicroBox(title = "成交流動性 Fill Prob", value = "98.4%", detail = "Limit queue pos: #3")
                }
            }
        }
    }
}

@Composable
private fun RowScope.MicroBox(title: String, value: String, detail: String) {
    Column(
        modifier = Modifier
            .weight(1f)
            .padding(2.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(HktdSurfaceVariant)
            .padding(8.dp)
    ) {
        Text(title, color = HktdTextSecondary, fontSize = 9.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = HktdCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(detail, color = HktdTextMuted, fontSize = 9.sp)
    }
}
