package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val HktdBackground = Color(0xFF080E18)
val HktdSurface = Color(0xFF0F1826)
val HktdSurfaceVariant = Color(0xFF162235)
val HktdBorder = Color(0xFF23354E)

val HktdCyan = Color(0xFF00E5FF)
val HktdBlue = Color(0xFF2979FF)
val HktdGold = Color(0xFFFFD700)

val HktdGreen = Color(0xFF00E676)
val HktdRed = Color(0xFFFF5252)
val HktdAmber = Color(0xFFFFB300)

val HktdTextPrimary = Color(0xFFE2E8F0)
val HktdTextSecondary = Color(0xFF94A3B8)
val HktdTextMuted = Color(0xFF64748B)

val HktdHeaderBg = Color(0xFF0B1320)
