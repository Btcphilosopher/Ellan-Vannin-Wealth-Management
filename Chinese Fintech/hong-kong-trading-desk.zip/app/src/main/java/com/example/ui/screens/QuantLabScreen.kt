package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Formatters
import com.example.ui.components.CardContainer
import com.example.ui.theme.*
import com.example.ui.viewmodel.HKTDViewModel

@Composable
fun QuantLabScreen(viewModel: HKTDViewModel) {
    val backtestResult = viewModel.latestBacktest.collectAsState().value
    var selectedStrategy by remember { mutableStateOf("VWAP") }
    var codeLanguage by remember { mutableStateOf("Python") }

    val pythonCode = """
import hktd
import pandas as pd
import numpy as np

# Load HKEX 1-min Tick Data
ticks = hktd.market("00005.HK").history(days=30)
signals = np.where(ticks['close'] > ticks['vwap'], 1, -1)

# Backtest Order Routing
portfolio = hktd.backtest(ticks, signals, slippage_bps=1.5)
print(f"Sharpe Ratio: {portfolio.sharpe():.2f}")
    """.trimIndent()

    val rCode = """
library(hktd)
library(data.table)

ticks <- get_market_data("00700.HK", timeframe="1m")
ticks[, spread := ask - bid]
model <- lm(returns ~ spread + order_imbalance, data=ticks)
summary(model)
    """.trimIndent()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HktdBackground)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Strategy Backtesting Selector & Trigger
        item {
            CardContainer(
                titleCn = "香港量化策略回測引擎 (HK Quant Backtester)",
                titleEn = "Historical Event Replay"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("選擇量化策略 (Select Strategy):", color = HktdTextSecondary, fontSize = 10.sp)

                    val strats = listOf("VWAP", "TWAP", "POV (20%)", "Statistical Arbitrage (統計套利)", "Mean Reversion (均值回歸)", "Cross-Asset Momentum (跨資產動量)", "FX Carry & Basis Trading (外匯套息)")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(strats) { s ->
                            val isSel = s == selectedStrategy
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) HktdCyan else HktdSurfaceVariant)
                                    .border(width = 0.5.dp, color = HktdBorder, shape = RoundedCornerShape(6.dp))
                                    .clickable { selectedStrategy = s }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                    .testTag("quant_strategy_$s")
                            ) {
                                Text(s, color = if (isSel) HktdBackground else HktdTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Button(
                        onClick = { viewModel.runQuantBacktest(selectedStrategy) },
                        colors = ButtonDefaults.buttonColors(containerColor = HktdCyan),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().height(36.dp).testTag("run_backtest_button")
                    ) {
                        Text("運行策略歷史回測 / Run Backtest", color = HktdBackground, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        // Backtest Performance Metrics Display
        item {
            CardContainer(
                titleCn = "回測績效與滑點報告 (Backtest Performance & Slippage)",
                titleEn = "Analytics Summary"
            ) {
                if (backtestResult == null) {
                    Text(
                        text = "點擊上方按鈕運行量化策略回測...",
                        color = HktdTextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MetricBox(label = "策略名稱 Strategy", value = backtestResult.strategyName, color = HktdCyan)
                            MetricBox(label = "累計收益 Total Return", value = "+${String.format("%.2f", backtestResult.totalReturnPct)}%", color = HktdGreen)
                            MetricBox(label = "年化收益 Annualized", value = "+${String.format("%.2f", backtestResult.annualizedReturnPct)}%", color = HktdGreen)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MetricBox(label = "夏普比率 Sharpe Ratio", value = String.format("%.2f", backtestResult.sharpeRatio), color = HktdGold)
                            MetricBox(label = "最大回撤 Max Drawdown", value = "-${String.format("%.2f", backtestResult.maxDrawdownPct)}%", color = HktdRed)
                            MetricBox(label = "勝率 Win Rate", value = "${String.format("%.1f", backtestResult.winRatePct)}%", color = HktdCyan)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("總交易筆數: ${backtestResult.totalTrades} 筆", color = HktdTextSecondary, fontSize = 10.sp)
                            Text("平均滑點: ${String.format("%.2f", backtestResult.avgSlippageBps)} bps", color = HktdAmber, fontSize = 10.sp)
                            Text("總手續費支出: HK$ ${Formatters.formatMoney(backtestResult.totalCommissionHkd)}", color = HktdTextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // Python / R Script Execution Environment
        item {
            CardContainer(
                titleCn = "HK Quant Lab 腳本研發環境 (Python & R Lab)",
                titleEn = "Scripting Environment"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Python", "R Language").forEach { lang ->
                                val isSel = lang.startsWith(codeLanguage)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSel) HktdBlue else HktdSurfaceVariant)
                                        .clickable { codeLanguage = lang.take(6) }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(lang, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text("Environment: Python 3.12 • Pandas • SciPy • R 4.3", color = HktdTextMuted, fontSize = 9.sp)
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(HktdHeaderBg)
                            .border(width = 0.5.dp, color = HktdBorder)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = if (codeLanguage == "Python") pythonCode else rCode,
                            color = HktdGreen,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.MetricBox(label: String, value: String, color: Color) {
    Column(
        modifier = Modifier
            .weight(1f)
            .padding(2.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(HktdSurfaceVariant)
            .padding(6.dp)
    ) {
        Text(label, color = HktdTextSecondary, fontSize = 9.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
