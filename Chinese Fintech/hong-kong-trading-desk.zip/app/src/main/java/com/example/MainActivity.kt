package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.components.HeaderView
import com.example.ui.components.TickerStripView
import com.example.ui.screens.*
import com.example.ui.theme.HktdBackground
import com.example.ui.theme.HktdTheme
import com.example.ui.viewmodel.HKTDViewModel
import com.example.ui.viewmodel.HktdTab

class MainActivity : ComponentActivity() {

    private val viewModel: HKTDViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            HktdTheme {
                HKTDAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun HKTDAppContent(viewModel: HKTDViewModel) {
    val activeTab by viewModel.activeTab.collectAsState()
    val riskConfig by viewModel.riskConfig.collectAsState()
    val instruments by viewModel.marketDataEngine.instruments.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = HktdBackground,
        topBar = {
            Column {
                HeaderView(
                    activeTab = activeTab,
                    onTabSelected = { viewModel.setActiveTab(it) },
                    globalKillSwitch = riskConfig.globalKillSwitch,
                    onToggleKillSwitch = { viewModel.toggleGlobalKillSwitch() }
                )
                TickerStripView(instruments = instruments)
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(HktdBackground)
        ) {
            when (activeTab) {
                HktdTab.MARKET_OVERVIEW -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToDesk = { instrumentId ->
                        viewModel.selectInstrument(instrumentId)
                        viewModel.setActiveTab(HktdTab.TRADING_DESK)
                    }
                )
                HktdTab.TRADING_DESK -> TradingDeskScreen(viewModel = viewModel)
                HktdTab.OMS_EMS -> OmsEmsScreen(viewModel = viewModel)
                HktdTab.RISK_VAR -> RiskVaRScreen(viewModel = viewModel)
                HktdTab.QUANT_LAB -> QuantLabScreen(viewModel = viewModel)
                HktdTab.LATENCY_LAB -> LatencyMicrostructureScreen(viewModel = viewModel)
                HktdTab.API_FIX -> ApiFixScreen(viewModel = viewModel)
                HktdTab.SETTLEMENT_OPS -> SettlementOpsScreen(viewModel = viewModel)
            }
        }
    }
}
