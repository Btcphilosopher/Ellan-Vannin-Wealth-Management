package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Formatters
import com.example.data.model.OrderSide
import com.example.data.model.OrderStatus
import com.example.ui.components.CardContainer
import com.example.ui.theme.*
import com.example.ui.viewmodel.HKTDViewModel

@Composable
fun OmsEmsScreen(viewModel: HKTDViewModel) {
    val orders = viewModel.matchingEngine.orders.collectAsState().value
    val executions = viewModel.matchingEngine.executions.collectAsState().value

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HktdBackground)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Active OMS Orders Table
        item {
            CardContainer(
                titleCn = "OMS 訂單生命週期 (Order Management System)",
                titleEn = "Live Order Lifecycle",
                trailingText = "總訂單: ${orders.size} 筆"
            ) {
                if (orders.isEmpty()) {
                    Text(
                        text = "當前無活躍訂單。請前往【交易台】提交新單。",
                        color = HktdTextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        orders.forEach { order ->
                            val isBuy = order.side == OrderSide.BUY
                            val sideColor = if (isBuy) HktdGreen else HktdRed

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(HktdSurfaceVariant)
                                    .border(width = 0.5.dp, color = HktdBorder)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(order.orderId, color = HktdCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        StatusBadge(status = order.status)
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("${order.institutionName} • ${order.accountId}", color = HktdTextSecondary, fontSize = 9.sp)
                                    if (order.rejectReason != null) {
                                        Text("拒絕原因: ${order.rejectReason}", color = HktdRed, fontSize = 9.sp)
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text("${order.side.name} ${order.instrumentId}", color = sideColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("單價: HK$ ${order.price} | 數量: ${order.quantity}", color = HktdTextPrimary, fontSize = 10.sp)
                                    Text("已成交: ${order.filledQuantity} @ HK$ ${order.avgExecutionPrice}", color = HktdTextMuted, fontSize = 9.sp)
                                }

                                if (order.status != OrderStatus.FILLED && order.status != OrderStatus.CANCELLED && order.status != OrderStatus.REJECTED) {
                                    Button(
                                        onClick = { viewModel.cancelOrder(order.orderId) },
                                        colors = ButtonDefaults.buttonColors(containerColor = HktdRed),
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                        modifier = Modifier.height(26.dp).testTag("cancel_order_${order.orderId}")
                                    ) {
                                        Text("撤單 / Cancel", fontSize = 9.sp, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // EMS Execution Reports Table
        item {
            CardContainer(
                titleCn = "EMS 成交執行報告 (Execution Management System)",
                titleEn = "Execution Audit Trail",
                trailingText = "總成交: ${executions.size} 筆"
            ) {
                if (executions.isEmpty()) {
                    Text(
                        text = "尚未產生成交報告。",
                        color = HktdTextSecondary,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        executions.take(10).forEach { exec ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(exec.executionId, color = HktdGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(exec.instrumentId, color = HktdCyan, fontSize = 10.sp)
                                Text("${exec.side.name} ${Formatters.formatInt(exec.quantity)} 股", color = if (exec.side == OrderSide.BUY) HktdGreen else HktdRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("HK$ ${Formatters.formatMoney(exec.price)}", color = HktdTextPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text("手續費: HK$ ${Formatters.formatMoney(exec.fee)}", color = HktdTextMuted, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: OrderStatus) {
    val (bgColor, textColor) = when (status) {
        OrderStatus.FILLED -> HktdGreen to Color.Black
        OrderStatus.REJECTED, OrderStatus.CANCELLED -> HktdRed to Color.White
        OrderStatus.PARTIALLY_FILLED -> HktdAmber to Color.Black
        else -> HktdCyan to Color.Black
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(status.labelCn, color = textColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}
