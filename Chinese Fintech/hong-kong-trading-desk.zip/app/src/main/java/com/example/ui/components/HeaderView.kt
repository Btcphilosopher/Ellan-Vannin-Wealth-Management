package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.HktdTab
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HeaderView(
    activeTab: HktdTab,
    onTabSelected: (HktdTab) -> Unit,
    globalKillSwitch: Boolean,
    onToggleKillSwitch: () -> Unit
) {
    var timeString by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("HH:mm:ss 'HKT'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("Asia/Hong_Kong")
        while (true) {
            timeString = sdf.format(Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(HktdHeaderBg)
            .border(width = 0.5.dp, color = HktdBorder)
    ) {
        // Top Branding & Control Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(HktdCyan)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "HKTD",
                        color = HktdBackground,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "香港交易台 API",
                            color = HktdTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "HONG KONG TRADING DESK",
                            color = HktdCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Text(
                        text = "Institutional Market Infrastructure • Central Desk",
                        color = HktdTextSecondary,
                        fontSize = 10.sp
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = timeString,
                    color = HktdGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(12.dp))

                // Kill Switch Button
                Button(
                    onClick = onToggleKillSwitch,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (globalKillSwitch) HktdRed else HktdSurfaceVariant
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("global_kill_switch_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "Kill Switch",
                        tint = if (globalKillSwitch) Color.White else HktdRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (globalKillSwitch) "KILL SWITCH ACTIVE" else "KILL SWITCH",
                        color = if (globalKillSwitch) Color.White else HktdRed,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Tab Navigation Scrollable Row
        ScrollableTabRow(
            selectedTabIndex = activeTab.ordinal,
            containerColor = HktdHeaderBg,
            contentColor = HktdCyan,
            edgePadding = 8.dp,
            divider = {}
        ) {
            HktdTab.values().forEach { tab ->
                val selected = tab == activeTab
                Tab(
                    selected = selected,
                    onClick = { onTabSelected(tab) },
                    modifier = Modifier
                        .testTag("nav_tab_${tab.name}")
                        .padding(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${tab.titleCn} | ${tab.titleEn}",
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        color = if (selected) HktdCyan else HktdTextSecondary,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
            }
        }
    }
}
