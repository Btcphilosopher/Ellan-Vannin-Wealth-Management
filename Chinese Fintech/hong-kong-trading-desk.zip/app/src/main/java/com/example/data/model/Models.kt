package com.example.data.model

import java.text.DecimalFormat

enum class AssetClass(val displayNameCn: String, val displayNameEn: String) {
    EQUITY("港股股票", "Hong Kong Equities"),
    ETF("交易所基金", "Hong Kong ETFs"),
    INDEX("指數", "Indices"),
    FX("外匯 / 人民幣", "FX / CNH"),
    BOND("固定收益 / 債券", "Bonds / Fixed Income"),
    DERIVATIVE("衍生品 / 期貨", "Derivatives / Futures"),
    COMMODITY("大宗商品", "Commodities")
}

enum class OrderSide(val labelCn: String, val labelEn: String) {
    BUY("買入", "BUY"),
    SELL("賣出", "SELL")
}

enum class OrderType(val labelCn: String, val labelEn: String) {
    LIMIT("限價單 (LIMIT)", "LIMIT"),
    MARKET("市價單 (MARKET)", "MARKET"),
    STOP_LIMIT("止損限價 (STOP_LIMIT)", "STOP_LIMIT"),
    TWAP("時間加權算法 (TWAP)", "TWAP"),
    VWAP("成交量加權算法 (VWAP)", "VWAP"),
    POV("參與率算法 (POV)", "POV"),
    ICEBERG("冰山訂單 (ICEBERG)", "ICEBERG")
}

enum class OrderStatus(val labelCn: String, val labelEn: String) {
    NEW("新建", "NEW"),
    VALIDATING("合規驗證", "VALIDATING"),
    RISK_CHECK("風控檢查", "RISK_CHECK"),
    ROUTING("路由中", "ROUTING"),
    SENT("已發送", "SENT"),
    ACKNOWLEDGED("交易所確認", "ACKNOWLEDGED"),
    PARTIALLY_FILLED("部分成交", "PARTIALLY_FILLED"),
    FILLED("完全成交", "FILLED"),
    REJECTED("已拒絕", "REJECTED"),
    CANCELLED("已撤銷", "CANCELLED"),
    EXPIRED("已過期", "EXPIRED")
}

data class Instrument(
    val id: String,              // e.g. "00005.HK"
    val symbol: String,          // "00005"
    val nameCn: String,          // "匯豐控股"
    val nameEn: String,          // "HSBC Holdings plc"
    val assetClass: AssetClass,
    val exchange: String = "HKEX",
    val currency: String = "HKD",
    val lotSize: Int = 400,
    val tickSize: Double = 0.05,
    val lastPrice: Double,
    val prevClose: Double,
    val changePx: Double = lastPrice - prevClose,
    val changePct: Double = if (prevClose > 0) ((lastPrice - prevClose) / prevClose) * 100.0 else 0.0,
    val high: Double = lastPrice * 1.012,
    val low: Double = lastPrice * 0.988,
    val volume: Long = 12500000L,
    val turnoverHkd: Double = volume * lastPrice,
    val isChinaConnect: Boolean = false
)

data class OrderBookLevel(
    val price: Double,
    val volume: Long,
    val ordersCount: Int
)

data class OrderBook(
    val instrumentId: String,
    val bids: List<OrderBookLevel>,
    val asks: List<OrderBookLevel>,
    val lastPrice: Double,
    val lastSize: Long,
    val timestamp: Long,
    val sequenceNumber: Long,
    val microprice: Double,
    val spread: Double,
    val imbalance: Double // (bidVol - askVol) / (bidVol + askVol)
)

data class TradeTick(
    val sequence: Long,
    val instrumentId: String,
    val price: Double,
    val quantity: Long,
    val side: OrderSide,
    val timestamp: Long,
    val venue: String = "HKEX-SIM"
)

data class Order(
    val orderId: String,
    val accountId: String,
    val institutionName: String,
    val instrumentId: String,
    val side: OrderSide,
    val orderType: OrderType,
    val price: Double,
    val quantity: Long,
    val filledQuantity: Long = 0,
    val avgExecutionPrice: Double = 0.0,
    val status: OrderStatus = OrderStatus.NEW,
    val timeInForce: String = "DAY",
    val timestamp: Long = System.currentTimeMillis(),
    val rejectReason: String? = null,
    val latencyNs: Long = 0L
)

data class Execution(
    val executionId: String,
    val orderId: String,
    val accountId: String,
    val instrumentId: String,
    val side: OrderSide,
    val price: Double,
    val quantity: Long,
    val fee: Double,
    val currency: String,
    val timestamp: Long,
    val execType: String = "FILL"
)

data class Position(
    val accountId: String,
    val instrumentId: String,
    val quantity: Long,
    val avgPrice: Double,
    val currentPrice: Double,
    val currency: String,
    val marketValueHkd: Double,
    val unrealizedPnlHkd: Double,
    val realizedPnlHkd: Double
)

data class PreTradeRiskConfig(
    val maxOrderNotionalHkd: Double = 50_000_000.0,
    val maxOrderQuantity: Long = 100_000L,
    val priceCollarPct: Double = 5.0,
    val maxPositionNotionalHkd: Double = 200_000_000.0,
    val maxDailyLossHkd: Double = 10_000_000.0,
    val globalKillSwitch: Boolean = false,
    val selfTradePreventionEnabled: Boolean = true,
    val maxLeverage: Double = 5.0
)

data class VaRMetrics(
    val var1d99PctHkd: Double = 12_450_000.0,
    val var5d99PctHkd: Double = 27_800_000.0,
    val var10d99PctHkd: Double = 39_200_000.0,
    val expectedShortfallHkd: Double = 16_800_000.0,
    val stressLossHkd: Double = 45_000_000.0,
    val grossExposureHkd: Double = 1_240_000_000.0,
    val netExposureHkd: Double = 180_000_000.0,
    val currentLeverage: Double = 2.15,
    val portfolioBeta: Double = 1.08,
    val sharpeRatio: Double = 1.92
)

data class StressScenario(
    val id: String,
    val nameCn: String,
    val nameEn: String,
    val shockDescription: String,
    val simulatedLossHkd: Double,
    val varImpactPct: Double
)

data class LatencyMetric(
    val stage: String,
    val p50Micros: Double,
    val p95Micros: Double,
    val p99Micros: Double,
    val p999Micros: Double
)

data class LatencyBreakdown(
    val feedIngestionNs: Long,
    val parserNs: Long,
    val normalizerNs: Long,
    val strategyNs: Long,
    val riskCheckNs: Long,
    val serializationNs: Long,
    val networkNs: Long,
    val exchangeNs: Long,
    val totalNs: Long
)

data class FIXMessage(
    val sequence: Long,
    val msgType: String, // 35=D, 35=8, 35=0, 35=W
    val direction: String, // INBOUND / OUTBOUND
    val rawFix: String,
    val timestamp: Long
)

data class LedgerRecord(
    val id: String,
    val account: String,
    val debitAccount: String,
    val creditAccount: String,
    val amount: Double,
    val currency: String,
    val description: String,
    val timestamp: Long
)

data class SettlementInstruction(
    val settlementId: String,
    val tradeId: String,
    val buyerAccount: String,
    val sellerAccount: String,
    val instrumentId: String,
    val quantity: Long,
    val cashAmount: Double,
    val currency: String,
    val settlementDate: String,
    val status: String
)

data class QuantBacktestResult(
    val strategyName: String,
    val totalReturnPct: Double,
    val annualizedReturnPct: Double,
    val maxDrawdownPct: Double,
    val winRatePct: Double,
    val sharpeRatio: Double,
    val totalTrades: Int,
    val avgSlippageBps: Double,
    val totalCommissionHkd: Double
)

object Formatters {
    private val currencyFmt = DecimalFormat("#,##0.00")
    private val intFmt = DecimalFormat("#,##0")
    private val percentFmt = DecimalFormat("+0.00%;-0.00%")

    fun formatMoney(amount: Double): String = currencyFmt.format(amount)
    fun formatInt(qty: Long): String = intFmt.format(qty)
    fun formatPct(pct: Double): String = String.format("%+.2f%%", pct)
}
