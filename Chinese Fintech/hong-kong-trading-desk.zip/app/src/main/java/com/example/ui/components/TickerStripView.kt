package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Formatters
import com.example.data.model.Instrument
import com.example.ui.theme.*

@Composable
fun TickerStripView(instruments: List<Instrument>) {
    val featuredIds = listOf("HK.HSI", "HK.HSTECH", "00005.HK", "00700.HK", "09988.HK", "USD/HKD", "USD/CNH")
    val featuredList = instruments.filter { it.id in featuredIds }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(HktdSurface)
            .border(width = 0.5.dp, color = HktdBorder)
            .padding(vertical = 4.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "LIVE TICK:",
            color = HktdCyan,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(end = 8.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(featuredList) { inst ->
                val isUp = inst.changePx >= 0
                val color = if (isUp) HktdGreen else HktdRed
                val sign = if (isUp) "+" else ""

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${inst.symbol}: ",
                        color = HktdTextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = if (inst.lastPrice > 1000) Formatters.formatMoney(inst.lastPrice) else String.format("%.4f", inst.lastPrice),
                        color = HktdTextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "$sign${String.format("%.2f", inst.changePct)}%",
                        color = color,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
