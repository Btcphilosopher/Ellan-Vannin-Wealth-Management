package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Formatters
import com.example.ui.components.CardContainer
import com.example.ui.theme.*
import com.example.ui.viewmodel.HKTDViewModel

@Composable
fun RiskVaRScreen(viewModel: HKTDViewModel) {
    val varMetrics = viewModel.varRiskEngine.varMetrics.collectAsState().value
    val scenarios = viewModel.varRiskEngine.stressScenarios.collectAsState().value
    val riskConfig = viewModel.riskConfig.collectAsState().value

    var notionalInput by remember { mutableStateOf(riskConfig.maxOrderNotionalHkd.toString()) }
    var quantityInput by remember { mutableStateOf(riskConfig.maxOrderQuantity.toString()) }
    var collarInput by remember { mutableStateOf(riskConfig.priceCollarPct.toString()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HktdBackground)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Global Kill Switch Banner
        item {
            CardContainer(
                titleCn = "全盤緊急風控殺車 (Global & Desk Kill Switch)",
                titleEn = "Emergency Controls"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (riskConfig.globalKillSwitch) "STATUS: 全盤殺車已觸發 (ALL NEW ORDERS BLOCKED)" else "STATUS: 風控正常運行 (Risk Controls Normal)",
                            color = if (riskConfig.globalKillSwitch) HktdRed else HktdGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "觸發後將立即拒絕所有新單提交，並自動撤銷盤口所有未成交掛單",
                            color = HktdTextSecondary,
                            fontSize = 10.sp
                        )
                    }

                    Button(
                        onClick = { viewModel.toggleGlobalKillSwitch() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (riskConfig.globalKillSwitch) HktdGreen else HktdRed
                        ),
                        modifier = Modifier.testTag("risk_tab_kill_switch")
                    ) {
                        Text(
                            text = if (riskConfig.globalKillSwitch) "解除殺車 (Deactivate)" else "全盤殺車 (ACTIVATE)",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Value at Risk (VaR) Gauges & Exposure
        item {
            CardContainer(
                titleCn = "機構級風險價值模型 (Value at Risk & Capital)",
                titleEn = "99% Confidence Level"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        RiskBox(label = "1D 99% VaR", value = "HK$ ${Formatters.formatMoney(varMetrics.var1d99PctHkd)}", color = HktdCyan)
                        RiskBox(label = "5D 99% VaR", value = "HK$ ${Formatters.formatMoney(varMetrics.var5d99PctHkd)}", color = HktdBlue)
                        RiskBox(label = "10D 99% VaR", value = "HK$ ${Formatters.formatMoney(varMetrics.var10d99PctHkd)}", color = HktdGold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        RiskBox(label = "預期尾部損失 (Expected Shortfall)", value = "HK$ ${Formatters.formatMoney(varMetrics.expectedShortfallHkd)}", color = HktdAmber)
                        RiskBox(label = "總敞口 (Gross Exposure)", value = "HK$ ${Formatters.formatMoney(varMetrics.grossExposureHkd)}", color = HktdTextPrimary)
                        RiskBox(label = "淨敞口 (Net Exposure)", value = "HK$ ${Formatters.formatMoney(varMetrics.netExposureHkd)}", color = HktdTextPrimary)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("槓桿率 Leverage: ${String.format("%.2f", varMetrics.currentLeverage)}x", color = HktdTextSecondary, fontSize = 11.sp)
                        Text("組合 Beta: ${varMetrics.portfolioBeta}", color = HktdTextSecondary, fontSize = 11.sp)
                        Text("夏普比率 Sharpe: ${varMetrics.sharpeRatio}", color = HktdGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Pre-Trade Risk Limit Configurator
        item {
            CardContainer(
                titleCn = "前置風控限制配置 (Pre-Trade Risk Limits)",
                titleEn = "Order Validation Rules"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("單筆最大名義金額 (HKD)", color = HktdTextSecondary, fontSize = 10.sp)
                            OutlinedTextField(
                                value = notionalInput,
                                onValueChange = { notionalInput = it },
                                singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(color = HktdTextPrimary, fontSize = 11.sp),
                                modifier = Modifier.fillMaxWidth().height(46.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("單筆最大股數/數量", color = HktdTextSecondary, fontSize = 10.sp)
                            OutlinedTextField(
                                value = quantityInput,
                                onValueChange = { quantityInput = it },
                                singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(color = HktdTextPrimary, fontSize = 11.sp),
                                modifier = Modifier.fillMaxWidth().height(46.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("限價偏離上限 (Price Collar %)", color = HktdTextSecondary, fontSize = 10.sp)
                            OutlinedTextField(
                                value = collarInput,
                                onValueChange = { collarInput = it },
                                singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(color = HktdTextPrimary, fontSize = 11.sp),
                                modifier = Modifier.fillMaxWidth().height(46.dp)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            val notional = notionalInput.toDoubleOrNull() ?: 50000000.0
                            val qty = quantityInput.toLongOrNull() ?: 100000L
                            val collar = collarInput.toDoubleOrNull() ?: 5.0
                            viewModel.updateRiskLimits(notional, qty, collar)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HktdBlue),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.align(Alignment.End).height(32.dp).testTag("save_risk_limits_button")
                    ) {
                        Text("更新風控規則 / Save Risk Rules", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Stress Testing Scenarios Matrix
        item {
            CardContainer(
                titleCn = "香港市場特定情境壓力測試 (Hong Kong Stress Scenarios)",
                titleEn = "Macro Stress Matrix"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    scenarios.forEach { scenario ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(HktdSurfaceVariant)
                                .border(width = 0.5.dp, color = HktdBorder)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.5f)) {
                                Text(scenario.nameCn, color = HktdTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(scenario.shockDescription, color = HktdTextSecondary, fontSize = 9.sp)
                            }

                            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                Text("-HK$ ${Formatters.formatMoney(scenario.simulatedLossHkd)}", color = HktdRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("VaR 影響: ${scenario.varImpactPct}%", color = HktdAmber, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.RiskBox(label: String, value: String, color: Color) {
    Column(
        modifier = Modifier
            .weight(1f)
            .padding(2.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(HktdSurfaceVariant)
            .padding(6.dp)
    ) {
        Text(label, color = HktdTextSecondary, fontSize = 9.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
