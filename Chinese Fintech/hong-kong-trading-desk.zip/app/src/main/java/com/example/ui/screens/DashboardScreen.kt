package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Formatters
import com.example.data.model.Instrument
import com.example.ui.components.CardContainer
import com.example.ui.theme.*
import com.example.ui.viewmodel.HKTDViewModel

@Composable
fun DashboardScreen(viewModel: HKTDViewModel, onNavigateToDesk: (String) -> Unit) {
    val instruments = viewModel.marketDataEngine.instruments.value
    val positions = viewModel.portfolioEngine.positions.value
    val orders = viewModel.matchingEngine.orders.value
    val varMetrics = viewModel.varRiskEngine.varMetrics.value

    val hsi = instruments.find { it.id == "HK.HSI" }
    val hstech = instruments.find { it.id == "HK.HSTECH" }

    val totalMarketVal = positions.sumOf { it.marketValueHkd }
    val totalUnrealizedPnl = positions.sumOf { it.unrealizedPnlHkd }
    val totalRealizedPnl = positions.sumOf { it.realizedPnlHkd }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HktdBackground)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Market Overview Metric Cards Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // HSI Card
                MetricCard(
                    title = "恆生指數 HSI",
                    value = hsi?.lastPrice?.let { Formatters.formatMoney(it) } ?: "18,420.50",
                    changePct = hsi?.changePct ?: +0.88,
                    subtitle = "大市成交: HK$ 128.4 B",
                    modifier = Modifier.weight(1f)
                )
                // HSTECH Card
                MetricCard(
                    title = "恆生科技 HSTECH",
                    value = hstech?.lastPrice?.let { Formatters.formatMoney(it) } ?: "4,120.30",
                    changePct = hstech?.changePct ?: +1.48,
                    subtitle = "科指成份股: 30 隻",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Trading Desk Summary Banner
        item {
            CardContainer(
                titleCn = "交易台當前概覽 (Trading Desk Summary)",
                titleEn = "DESK METRICS"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("總持倉市值 (Market Value)", color = HktdTextSecondary, fontSize = 10.sp)
                        Text("HK$ ${Formatters.formatMoney(totalMarketVal)}", color = HktdCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("未實現盈虧 (Unrealised P&L)", color = HktdTextSecondary, fontSize = 10.sp)
                        val color = if (totalUnrealizedPnl >= 0) HktdGreen else HktdRed
                        Text("HK$ ${Formatters.formatMoney(totalUnrealizedPnl)}", color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("1D 99% 風險價值 (VaR)", color = HktdTextSecondary, fontSize = 10.sp)
                        Text("HK$ ${Formatters.formatMoney(varMetrics.var1d99PctHkd)}", color = HktdAmber, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("活躍訂單數 (Active Orders)", color = HktdTextSecondary, fontSize = 10.sp)
                        Text("${orders.size} 筆", color = HktdTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // China Stock Connect & FX Status
        item {
            CardContainer(
                titleCn = "滬深港通與離岸人民幣 (China Connect & CNH Telemetry)",
                titleEn = "Greater China Infrastructure"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("北向滬股通/深股通 (Northbound)", color = HktdTextSecondary, fontSize = 10.sp)
                        Text("淨買入 +RMB 4.28 B", color = HktdGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("額度剩餘: 82.4%", color = HktdTextMuted, fontSize = 9.sp)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("南向港股通 (Southbound)", color = HktdTextSecondary, fontSize = 10.sp)
                        Text("淨買入 +HK$ 6.12 B", color = HktdGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("額度剩餘: 74.8%", color = HktdTextMuted, fontSize = 9.sp)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("離岸人民幣 (USD/CNH)", color = HktdTextSecondary, fontSize = 10.sp)
                        Text("7.1230  (-0.08%)", color = HktdCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("HKD/CNH: 0.9103", color = HktdTextMuted, fontSize = 9.sp)
                    }
                }
            }
        }

        // Featured Market Securities List
        item {
            CardContainer(
                titleCn = "熱門標的行情 (Featured Tickers)",
                titleEn = "Click to Trade"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    instruments.take(8).forEach { inst ->
                        val isUp = inst.changePx >= 0
                        val color = if (isUp) HktdGreen else HktdRed

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(HktdSurfaceVariant)
                                .clickable { onNavigateToDesk(inst.id) }
                                .padding(8.dp)
                                .testTag("ticker_item_${inst.symbol}"),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(HktdHeaderBg)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(inst.symbol, color = HktdCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(inst.nameCn, color = HktdTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(inst.nameEn, color = HktdTextSecondary, fontSize = 9.sp)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("HK$ ${Formatters.formatMoney(inst.lastPrice)}", color = HktdTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text("${if (isUp) "+" else ""}${String.format("%.2f", inst.changePct)}%", color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { onNavigateToDesk(inst.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = HktdBlue),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("交易 / Trade", fontSize = 10.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    changePct: Double,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    val isUp = changePct >= 0
    val color = if (isUp) HktdGreen else HktdRed

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(HktdSurface)
            .border(width = 0.5.dp, color = HktdBorder, shape = RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(title, color = HktdTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(value, color = HktdTextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("${if (isUp) "+" else ""}${String.format("%.2f", changePct)}%", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(subtitle, color = HktdTextMuted, fontSize = 9.sp)
    }
}
