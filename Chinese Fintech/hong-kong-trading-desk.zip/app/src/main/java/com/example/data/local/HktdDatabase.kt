package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        OrderEntity::class,
        PositionEntity::class,
        ExecutionEntity::class,
        LedgerEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class HktdDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao
    abstract fun positionDao(): PositionDao
    abstract fun executionDao(): ExecutionDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun auditLogDao(): AuditLogDao

    companion object {
        @Volatile
        private var INSTANCE: HktdDatabase? = null

        fun getDatabase(context: Context): HktdDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    HktdDatabase::class.java,
                    "hktd_trading_desk_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
