package com.example.engine

import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

class OrderMatchingEngine(
    private val scope: CoroutineScope,
    private val marketDataEngine: MarketDataEngine,
    private val portfolioEngine: PortfolioEngine,
    private val riskGate: PreTradeRiskGate,
    private val latencyTracker: LatencyTracker
) {

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _executions = MutableStateFlow<List<Execution>>(emptyList())
    val executions: StateFlow<List<Execution>> = _executions.asStateFlow()

    private val _fixMessages = MutableStateFlow<List<FIXMessage>>(emptyList())
    val fixMessages: StateFlow<List<FIXMessage>> = _fixMessages.asStateFlow()

    private var fixSeqNumber = 101L

    fun submitOrder(
        accountId: String,
        institutionName: String,
        instrumentId: String,
        side: OrderSide,
        orderType: OrderType,
        price: Double,
        quantity: Long,
        riskConfig: PreTradeRiskConfig
    ) {
        val instrument = marketDataEngine.getInstrument(instrumentId)
        val orderId = "ORD-${System.currentTimeMillis().toString().takeLast(8)}"

        val initialOrder = Order(
            orderId = orderId,
            accountId = accountId,
            institutionName = institutionName,
            instrumentId = instrumentId,
            side = side,
            orderType = orderType,
            price = price,
            quantity = quantity,
            status = OrderStatus.NEW,
            timestamp = System.currentTimeMillis()
        )

        val currentList = _orders.value.toMutableList()
        currentList.add(0, initialOrder)
        _orders.value = currentList

        emitFix("35=D", "OUTBOUND", "8=FIX.4.4|35=D|34=${fixSeqNumber++}|49=HKTD_OMS|56=HKEX|11=$orderId|55=$instrumentId|54=${if (side==OrderSide.BUY) "1" else "2"}|38=$quantity|44=$price|10=128|")

        // Async execution pipeline
        scope.launch(Dispatchers.Default) {
            // Stage 1: Pre-Trade Risk Validation
            delay(15)
            val riskResult = riskGate.validateOrder(initialOrder, instrument, riskConfig, _orders.value)
            
            if (riskResult is RiskCheckResult.Rejected) {
                updateOrderStatus(orderId, OrderStatus.REJECTED, rejectReason = riskResult.reasonCn)
                emitFix("35=8", "INBOUND", "8=FIX.4.4|35=8|34=${fixSeqNumber++}|49=HKEX|56=HKTD_OMS|11=$orderId|39=8|58=${riskResult.reasonEn}|10=092|")
                return@launch
            }

            // Stage 2: Risk Approved & Routing
            updateOrderStatus(orderId, OrderStatus.RISK_CHECK)
            delay(20)
            updateOrderStatus(orderId, OrderStatus.ROUTING)
            delay(15)
            updateOrderStatus(orderId, OrderStatus.SENT)
            delay(10)
            updateOrderStatus(orderId, OrderStatus.ACKNOWLEDGED)
            emitFix("35=8", "INBOUND", "8=FIX.4.4|35=8|34=${fixSeqNumber++}|49=HKEX|56=HKTD_OMS|11=$orderId|39=0|150=0|10=210|")

            // Stage 3: Simulated Execution Matching
            delay(80)
            val mktPx = instrument?.lastPrice ?: price
            val execPrice = if (orderType == OrderType.LIMIT && price > 0) price else mktPx
            val fee = execPrice * quantity * 0.0005

            val breakdown = latencyTracker.recordOrderProcessing()

            val execId = "EXEC-${System.currentTimeMillis().toString().takeLast(8)}"
            val execution = Execution(
                executionId = execId,
                orderId = orderId,
                accountId = accountId,
                instrumentId = instrumentId,
                side = side,
                price = execPrice,
                quantity = quantity,
                fee = fee,
                currency = instrument?.currency ?: "HKD",
                timestamp = System.currentTimeMillis()
            )

            val currentExecs = _executions.value.toMutableList()
            currentExecs.add(0, execution)
            _executions.value = currentExecs

            // Update order status to FILLED
            updateOrderStatus(
                orderId = orderId,
                status = OrderStatus.FILLED,
                filledQty = quantity,
                avgPrice = execPrice,
                latencyNs = breakdown.totalNs
            )

            portfolioEngine.onTradeExecuted(execution, instrument)

            emitFix("35=8", "INBOUND", "8=FIX.4.4|35=8|34=${fixSeqNumber++}|49=HKEX|56=HKTD_OMS|11=$orderId|17=$execId|39=2|150=2|31=$execPrice|32=$quantity|10=184|")
        }
    }

    fun cancelOrder(orderId: String) {
        val order = _orders.value.find { it.orderId == orderId } ?: return
        if (order.status == OrderStatus.FILLED || order.status == OrderStatus.CANCELLED) return

        updateOrderStatus(orderId, OrderStatus.CANCELLED)
        emitFix("35=F", "OUTBOUND", "8=FIX.4.4|35=F|34=${fixSeqNumber++}|49=HKTD_OMS|56=HKEX|11=$orderId|41=$orderId|10=045|")
        emitFix("35=8", "INBOUND", "8=FIX.4.4|35=8|34=${fixSeqNumber++}|49=HKEX|56=HKTD_OMS|11=$orderId|39=4|150=4|10=190|")
    }

    fun cancelAllOrders() {
        val active = _orders.value.filter { it.status != OrderStatus.FILLED && it.status != OrderStatus.CANCELLED && it.status != OrderStatus.REJECTED }
        active.forEach { cancelOrder(it.orderId) }
    }

    private fun updateOrderStatus(
        orderId: String,
        status: OrderStatus,
        filledQty: Long = 0,
        avgPrice: Double = 0.0,
        rejectReason: String? = null,
        latencyNs: Long = 0L
    ) {
        val currentList = _orders.value.toMutableList()
        val index = currentList.indexOfFirst { it.orderId == orderId }
        if (index >= 0) {
            val old = currentList[index]
            val updated = old.copy(
                status = status,
                filledQuantity = if (filledQty > 0) filledQty else old.filledQuantity,
                avgExecutionPrice = if (avgPrice > 0) avgPrice else old.avgExecutionPrice,
                rejectReason = rejectReason ?: old.rejectReason,
                latencyNs = if (latencyNs > 0) latencyNs else old.latencyNs
            )
            currentList[index] = updated
            _orders.value = currentList
        }
    }

    private fun emitFix(msgType: String, direction: String, rawFix: String) {
        val fixMsg = FIXMessage(
            sequence = fixSeqNumber,
            msgType = msgType,
            direction = direction,
            rawFix = rawFix,
            timestamp = System.currentTimeMillis()
        )
        val list = _fixMessages.value.toMutableList()
        list.add(0, fixMsg)
        if (list.size > 100) list.removeAt(list.size - 1)
        _fixMessages.value = list
    }
}
