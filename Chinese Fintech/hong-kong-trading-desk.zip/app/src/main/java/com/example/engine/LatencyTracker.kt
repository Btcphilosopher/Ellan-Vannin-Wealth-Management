package com.example.engine

import com.example.data.model.LatencyBreakdown
import com.example.data.model.LatencyMetric
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

class LatencyTracker {

    private val _latencyMetrics = MutableStateFlow<List<LatencyMetric>>(emptyList())
    val latencyMetrics: StateFlow<List<LatencyMetric>> = _latencyMetrics.asStateFlow()

    private val _recentBreakdowns = MutableStateFlow<List<LatencyBreakdown>>(emptyList())
    val recentBreakdowns: StateFlow<List<LatencyBreakdown>> = _recentBreakdowns.asStateFlow()

    init {
        generateDefaultStats()
    }

    private fun generateDefaultStats() {
        _latencyMetrics.value = listOf(
            LatencyMetric("行情接收 (Feed Ingestion)", 12.4, 28.1, 45.0, 112.0),
            LatencyMetric("二進制解析 (Binary Parsing)", 4.2, 8.5, 14.1, 35.0),
            LatencyMetric("數據規範化 (Normalisation)", 6.1, 11.2, 19.8, 48.0),
            LatencyMetric("量化策略計算 (Strategy Engine)", 25.0, 52.0, 98.0, 240.0),
            LatencyMetric("前置風控檢查 (Pre-Trade Risk)", 18.5, 34.0, 62.0, 180.0),
            LatencyMetric("網關序列化 (FIX/Binary Enc)", 8.3, 16.0, 28.5, 72.0),
            LatencyMetric("交易所撮合 (Exchange Matching)", 140.0, 290.0, 480.0, 1200.0)
        )
    }

    fun recordOrderProcessing(): LatencyBreakdown {
        val feed = (10..30).random().toLong() * 1000L
        val parse = (3..12).random().toLong() * 1000L
        val norm = (5..15).random().toLong() * 1000L
        val strat = (20..80).random().toLong() * 1000L
        val risk = (15..40).random().toLong() * 1000L
        val serial = (6..20).random().toLong() * 1000L
        val net = (80..200).random().toLong() * 1000L
        val exch = (100..400).random().toLong() * 1000L

        val total = feed + parse + norm + strat + risk + serial + net + exch

        val breakdown = LatencyBreakdown(
            feedIngestionNs = feed,
            parserNs = parse,
            normalizerNs = norm,
            strategyNs = strat,
            riskCheckNs = risk,
            serializationNs = serial,
            networkNs = net,
            exchangeNs = exch,
            totalNs = total
        )

        val currentList = _recentBreakdowns.value.toMutableList()
        currentList.add(0, breakdown)
        if (currentList.size > 30) currentList.removeAt(currentList.size - 1)
        _recentBreakdowns.value = currentList

        return breakdown
    }
}
