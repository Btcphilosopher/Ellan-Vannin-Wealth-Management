package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Formatters
import com.example.data.model.OrderBook
import com.example.ui.theme.*

@Composable
fun DepthOfBookView(orderBook: OrderBook?) {
    CardContainer(titleCn = "市場深度 Order Book (L2)", titleEn = "Market By Price") {
        if (orderBook == null) {
            Text("等待行情數據加載...", color = HktdTextSecondary, fontSize = 11.sp)
            return@CardContainer
        }

        val maxVol = maxOf(
            orderBook.asks.maxOfOrNull { it.volume } ?: 1L,
            orderBook.bids.maxOfOrNull { it.volume } ?: 1L
        ).toDouble()

        Column(modifier = Modifier.fillMaxWidth()) {
            // Table Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HktdSurfaceVariant)
                    .padding(vertical = 4.dp, horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("賣盤 / Ask", color = HktdRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("價格", color = HktdTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("數量 / Volume", color = HktdTextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            }

            // Asks (Sells) in reverse order (highest ask at top)
            orderBook.asks.reversed().forEach { level ->
                val barFraction = (level.volume / maxVol).toFloat().coerceIn(0.05f, 1.0f)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(20.dp)
                ) {
                    // Red background depth bar
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(barFraction)
                            .background(HktdRed.copy(alpha = 0.2f))
                            .align(Alignment.CenterEnd)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("ASK", color = HktdRed, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(String.format("%.2f", level.price), color = HktdRed, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(Formatters.formatInt(level.volume), color = HktdTextPrimary, fontSize = 10.sp, modifier = Modifier.weight(1f))
                    }
                }
            }

            // Mid Price & Microprice Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HktdHeaderBg)
                    .border(width = 0.5.dp, color = HktdCyan)
                    .padding(vertical = 4.dp, horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "最新: HK$${String.format("%.2f", orderBook.lastPrice)}",
                    color = HktdCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "微價: HK$${String.format("%.2f", orderBook.microprice)}",
                    color = HktdGold,
                    fontSize = 10.sp
                )
                Text(
                    text = "點差: ${String.format("%.2f", orderBook.spread)}",
                    color = HktdTextSecondary,
                    fontSize = 10.sp
                )
            }

            // Bids (Buys)
            orderBook.bids.forEach { level ->
                val barFraction = (level.volume / maxVol).toFloat().coerceIn(0.05f, 1.0f)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(20.dp)
                ) {
                    // Green background depth bar
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(barFraction)
                            .background(HktdGreen.copy(alpha = 0.2f))
                            .align(Alignment.CenterStart)
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("BID", color = HktdGreen, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(String.format("%.2f", level.price), color = HktdGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(Formatters.formatInt(level.volume), color = HktdTextPrimary, fontSize = 10.sp, modifier = Modifier.weight(1f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "訂單失衡度 (Imbalance): ${String.format("%+.2f", orderBook.imbalance)}",
                    color = if (orderBook.imbalance >= 0) HktdGreen else HktdRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "Seq #${orderBook.sequenceNumber}",
                    color = HktdTextMuted,
                    fontSize = 9.sp
                )
            }
        }
    }
}
