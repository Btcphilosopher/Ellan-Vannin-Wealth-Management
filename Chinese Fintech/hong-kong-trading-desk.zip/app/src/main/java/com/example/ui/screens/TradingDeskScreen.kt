package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.CardContainer
import com.example.ui.components.DepthOfBookView
import com.example.ui.components.MiniCandleChart
import com.example.ui.theme.*
import com.example.ui.viewmodel.HKTDViewModel

@Composable
fun TradingDeskScreen(viewModel: HKTDViewModel) {
    val selectedId = viewModel.selectedInstrumentId.collectAsState().value
    val instruments = viewModel.marketDataEngine.instruments.collectAsState().value
    val orderBooks = viewModel.marketDataEngine.orderBooks.collectAsState().value
    val recentTrades = viewModel.marketDataEngine.recentTrades.collectAsState().value

    val inst = instruments.find { it.id == selectedId } ?: instruments.firstOrNull()
    val book = orderBooks[selectedId]

    var side by remember { mutableStateOf(OrderSide.BUY) }
    var orderType by remember { mutableStateOf(OrderType.LIMIT) }
    var priceInput by remember(selectedId, inst?.lastPrice) { mutableStateOf(inst?.lastPrice?.toString() ?: "350.20") }
    var quantityInput by remember(inst?.lotSize) { mutableStateOf((inst?.lotSize ?: 400).toString()) }

    var alertMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(HktdBackground)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Ticker Selection Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(instruments) { i ->
                    val isSelected = i.id == selectedId
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) HktdCyan else HktdSurfaceVariant)
                            .border(width = 0.5.dp, color = HktdBorder, shape = RoundedCornerShape(6.dp))
                            .clickable { viewModel.selectInstrument(i.id) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("select_instrument_${i.symbol}")
                    ) {
                        Text(
                            text = "${i.symbol} ${i.nameCn}",
                            color = if (isSelected) HktdBackground else HktdTextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Selected Instrument Header
        item {
            inst?.let {
                CardContainer(
                    titleCn = "${it.symbol} ${it.nameCn} (${it.nameEn})",
                    titleEn = "HKEX • ${it.currency} • Lot Size: ${it.lotSize}"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "HK$ ${Formatters.formatMoney(it.lastPrice)}",
                                color = HktdCyan,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            val isUp = it.changePx >= 0
                            val color = if (isUp) HktdGreen else HktdRed
                            Text(
                                text = "${if (isUp) "+" else ""}${Formatters.formatMoney(it.changePx)} (${if (isUp) "+" else ""}${String.format("%.2f", it.changePct)}%)",
                                color = color,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("最高 High", color = HktdTextSecondary, fontSize = 9.sp)
                                Text(Formatters.formatMoney(it.high), color = HktdTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("最低 Low", color = HktdTextSecondary, fontSize = 9.sp)
                                Text(Formatters.formatMoney(it.low), color = HktdTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("成交量 Volume", color = HktdTextSecondary, fontSize = 9.sp)
                                Text(Formatters.formatInt(it.volume), color = HktdTextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    MiniCandleChart(instrument = it)
                }
            }
        }

        // L2 Depth & Order Entry Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // L2 Orderbook Depth
                Box(modifier = Modifier.weight(1.2f)) {
                    DepthOfBookView(orderBook = book)
                }

                // Order Entry Form
                Box(modifier = Modifier.weight(1f)) {
                    CardContainer(titleCn = "下單交易台 (Order Entry)", titleEn = "FIX / OMS Gateway") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            // BUY / SELL Toggle
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Button(
                                    onClick = { side = OrderSide.BUY },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (side == OrderSide.BUY) HktdGreen else HktdSurfaceVariant
                                    ),
                                    shape = RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp),
                                    modifier = Modifier.weight(1f).height(32.dp).testTag("order_side_buy")
                                ) {
                                    Text("買入 BUY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                                Button(
                                    onClick = { side = OrderSide.SELL },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (side == OrderSide.SELL) HktdRed else HktdSurfaceVariant
                                    ),
                                    shape = RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp),
                                    modifier = Modifier.weight(1f).height(32.dp).testTag("order_side_sell")
                                ) {
                                    Text("賣出 SELL", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }

                            // Order Type Selector
                            Text("訂單類型 / Type:", color = HktdTextSecondary, fontSize = 10.sp)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                listOf(OrderType.LIMIT, OrderType.MARKET, OrderType.TWAP, OrderType.VWAP).forEach { t ->
                                    val isSel = t == orderType
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (isSel) HktdCyan else HktdSurfaceVariant)
                                            .clickable { orderType = t }
                                            .padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = t.name,
                                            color = if (isSel) HktdBackground else HktdTextPrimary,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Price Input
                            Text("價格 (Price HKD):", color = HktdTextSecondary, fontSize = 10.sp)
                            OutlinedTextField(
                                value = priceInput,
                                onValueChange = { priceInput = it },
                                singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(color = HktdTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold),
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("order_price_input")
                            )

                            // Quantity Input
                            Text("數量 (Quantity Shares):", color = HktdTextSecondary, fontSize = 10.sp)
                            OutlinedTextField(
                                value = quantityInput,
                                onValueChange = { quantityInput = it },
                                singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(color = HktdTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold),
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("order_quantity_input")
                            )

                            // Quick Lot size buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                val lot = inst?.lotSize ?: 400
                                listOf(1, 2, 5, 10).forEach { mul ->
                                    val q = lot * mul
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(HktdSurfaceVariant)
                                            .border(width = 0.5.dp, color = HktdBorder)
                                            .clickable { quantityInput = q.toString() }
                                            .padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("${q}股", color = HktdTextSecondary, fontSize = 9.sp)
                                    }
                                }
                            }

                            val estPrice = priceInput.toDoubleOrNull() ?: (inst?.lastPrice ?: 0.0)
                            val estQty = quantityInput.toLongOrNull() ?: 0L
                            val estNotional = estPrice * estQty

                            Text(
                                text = "估計金額: HK$ ${Formatters.formatMoney(estNotional)}",
                                color = HktdGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )

                            // Submit Order Button
                            Button(
                                onClick = {
                                    val px = priceInput.toDoubleOrNull() ?: 0.0
                                    val qty = quantityInput.toLongOrNull() ?: 0L
                                    if (qty > 0) {
                                        viewModel.submitOrder(
                                            side = side,
                                            orderType = orderType,
                                            price = px,
                                            quantity = qty
                                        )
                                        alertMessage = "訂單已提交前置風控與 FIX 網關路由！"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (side == OrderSide.BUY) HktdGreen else HktdRed
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth().height(38.dp).testTag("submit_order_button")
                            ) {
                                Text(
                                    text = "發送 ${side.labelCn} 訂單 (${orderType.name})",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Time & Sales Recent Trades
        item {
            CardContainer(
                titleCn = "逐筆成交 (Time & Sales)",
                titleEn = "Market Trade Ticks"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    recentTrades.take(6).forEach { trade ->
                        val isBuy = trade.side == OrderSide.BUY
                        val color = if (isBuy) HktdGreen else HktdRed

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(trade.instrumentId, color = HktdCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("HK$ ${String.format("%.2f", trade.price)}", color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${trade.quantity} 股", color = HktdTextPrimary, fontSize = 10.sp)
                            Text(trade.venue, color = HktdTextMuted, fontSize = 9.sp)
                        }
                    }
                }
            }
        }
    }
}
