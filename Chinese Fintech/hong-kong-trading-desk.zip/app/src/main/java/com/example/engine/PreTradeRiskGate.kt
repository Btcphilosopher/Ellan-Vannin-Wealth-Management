package com.example.engine

import com.example.data.model.*

sealed class RiskCheckResult {
    data class Approved(val order: Order) : RiskCheckResult()
    data class Rejected(val reasonCn: String, val reasonEn: String) : RiskCheckResult()
}

class PreTradeRiskGate {

    fun validateOrder(
        order: Order,
        instrument: Instrument?,
        config: PreTradeRiskConfig,
        existingOrders: List<Order>
    ): RiskCheckResult {
        // 1. Global Kill Switch Check
        if (config.globalKillSwitch) {
            return RiskCheckResult.Rejected(
                reasonCn = "全盤緊急殺車 (Global Kill Switch) 已觸發：禁止新單提交",
                reasonEn = "Global Kill Switch active: New order submissions blocked"
            )
        }

        if (instrument == null) {
            return RiskCheckResult.Rejected(
                reasonCn = "未找到標的合約信息：${order.instrumentId}",
                reasonEn = "Unknown instrument identifier: ${order.instrumentId}"
            )
        }

        // 2. Quantity Limit Check
        if (order.quantity > config.maxOrderQuantity) {
            return RiskCheckResult.Rejected(
                reasonCn = "單筆下單數量 (${Formatters.formatInt(order.quantity)}) 超過最大限制 (${Formatters.formatInt(config.maxOrderQuantity)})",
                reasonEn = "Order size (${order.quantity}) exceeds maximum limit (${config.maxOrderQuantity})"
            )
        }

        // 3. Notional Limit Check
        val estPrice = if (order.price > 0) order.price else instrument.lastPrice
        val notionalHkd = estPrice * order.quantity * (if (instrument.currency == "USD") 7.82 else if (instrument.currency == "CNH") 1.10 else 1.0)
        
        if (notionalHkd > config.maxOrderNotionalHkd) {
            return RiskCheckResult.Rejected(
                reasonCn = "單筆下單金額 (HK$${Formatters.formatMoney(notionalHkd)}) 超過風控上限 (HK$${Formatters.formatMoney(config.maxOrderNotionalHkd)})",
                reasonEn = "Order notional exceeds pre-trade risk limit of HK$${Formatters.formatMoney(config.maxOrderNotionalHkd)}"
            )
        }

        // 4. Price Collar Check (Limit Order price vs Market price)
        if (order.orderType == OrderType.LIMIT && order.price > 0) {
            val marketPx = instrument.lastPrice
            val diffPct = Math.abs(order.price - marketPx) / marketPx * 100.0
            if (diffPct > config.priceCollarPct) {
                return RiskCheckResult.Rejected(
                    reasonCn = "下單價格 HK$${order.price} 偏離現價 (HK$${marketPx}) ${String.format("%.2f", diffPct)}%，超過價格偏離偏置上限 (${config.priceCollarPct}%)",
                    reasonEn = "Limit price deviates ${String.format("%.2f", diffPct)}% from last market price, exceeding collar threshold (${config.priceCollarPct}%)"
                )
            }
        }

        // 5. Self-Trade Prevention (Wash trade prevention)
        if (config.selfTradePreventionEnabled) {
            val oppositeSide = if (order.side == OrderSide.BUY) OrderSide.SELL else OrderSide.BUY
            val potentialSelfMatch = existingOrders.any {
                it.instrumentId == order.instrumentId &&
                it.accountId == order.accountId &&
                it.side == oppositeSide &&
                it.status == OrderStatus.SENT &&
                Math.abs(it.price - order.price) < 0.001
            }
            if (potentialSelfMatch) {
                return RiskCheckResult.Rejected(
                    reasonCn = "觸發自對沖洗售防護 (Self-Trade Prevention)：同賬戶對向等價掛單已存在",
                    reasonEn = "Self-Trade Prevention triggered: Matching opposite order exists for same account"
                )
            }
        }

        return RiskCheckResult.Approved(order)
    }
}
