package com.example.engine

import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

class MarketDataEngine(private val scope: CoroutineScope) {

    private val _instruments = MutableStateFlow<List<Instrument>>(emptyList())
    val instruments: StateFlow<List<Instrument>> = _instruments.asStateFlow()

    private val _orderBooks = MutableStateFlow<Map<String, OrderBook>>(emptyMap())
    val orderBooks: StateFlow<Map<String, OrderBook>> = _orderBooks.asStateFlow()

    private val _recentTrades = MutableStateFlow<List<TradeTick>>(emptyList())
    val recentTrades: StateFlow<List<TradeTick>> = _recentTrades.asStateFlow()

    private var seqCounter = 100000L

    init {
        initializeUniverse()
        startLiveMarketFeed()
    }

    private fun initializeUniverse() {
        val initialList = listOf(
            Instrument("00005.HK", "00005", "匯豐控股", "HSBC Holdings plc", AssetClass.EQUITY, "HKEX", "HKD", 400, 0.05, 350.20, 348.50, volume = 15400000L),
            Instrument("00700.HK", "00700", "騰訊控股", "Tencent Holdings", AssetClass.EQUITY, "HKEX", "HKD", 100, 0.20, 385.60, 380.00, volume = 22100000L, isChinaConnect = true),
            Instrument("09988.HK", "09988", "阿里巴巴", "Alibaba Group", AssetClass.EQUITY, "HKEX", "HKD", 100, 0.10, 82.40, 81.20, volume = 18900000L, isChinaConnect = true),
            Instrument("00941.HK", "00941", "中國移動", "China Mobile", AssetClass.EQUITY, "HKEX", "HKD", 500, 0.05, 74.80, 74.20, volume = 9800000L, isChinaConnect = true),
            Instrument("09999.HK", "09999", "網易", "NetEase Inc", AssetClass.EQUITY, "HKEX", "HKD", 100, 0.10, 142.30, 140.50, volume = 4500000L, isChinaConnect = true),
            Instrument("01810.HK", "01810", "小米集團", "Xiaomi Corp", AssetClass.EQUITY, "HKEX", "HKD", 200, 0.02, 21.50, 20.80, volume = 35000000L, isChinaConnect = true),
            Instrument("02318.HK", "02318", "中國平安", "Ping An Insurance", AssetClass.EQUITY, "HKEX", "HKD", 500, 0.05, 48.20, 47.60, volume = 11200000L, isChinaConnect = true),
            
            // ETFs
            Instrument("02800.HK", "02800", "盈富基金", "Tracker Fund of HK", AssetClass.ETF, "HKEX", "HKD", 500, 0.02, 18.95, 18.80, volume = 42000000L),
            Instrument("03033.HK", "03033", "南方恆生科技", "CSOP HS TECH ETF", AssetClass.ETF, "HKEX", "HKD", 200, 0.01, 3.88, 3.82, volume = 68000000L),

            // Indices
            Instrument("HK.HSI", "HSI", "恆生指數", "Hang Seng Index", AssetClass.INDEX, "HKEX", "HKD", 1, 1.0, 18420.50, 18260.00, volume = 0L),
            Instrument("HK.HSTECH", "HSTECH", "恆生科技指數", "Hang Seng Tech Index", AssetClass.INDEX, "HKEX", "HKD", 1, 1.0, 4120.30, 4060.00, volume = 0L),

            // FX
            Instrument("USD/HKD", "USDHKD", "美元/港幣", "USD/HKD Spot", AssetClass.FX, "OTC-FX", "HKD", 100000, 0.0001, 7.8245, 7.8250, volume = 500000000L),
            Instrument("USD/CNH", "USDCNH", "美元/離岸人民幣", "USD/CNH Spot", AssetClass.FX, "OTC-FX", "CNH", 100000, 0.0001, 7.1230, 7.1180, volume = 800000000L),
            Instrument("HKD/CNH", "HKDCNH", "港幣/離岸人民幣", "HKD/CNH Cross", AssetClass.FX, "OTC-FX", "CNH", 100000, 0.0001, 0.9103, 0.9095, volume = 200000000L),

            // Bonds
            Instrument("HK_BOND_10Y", "HKGB10Y", "香港政府10年期債券", "HK Gov 10Y Bond", AssetClass.BOND, "HKMA", "HKD", 10000, 0.01, 98.45, 98.50, volume = 50000000L),
            Instrument("CGB_CNH_5Y", "CGB5Y", "中國國債離岸人民幣5年", "China Gov Bond 5Y CNH", AssetClass.BOND, "HKEX-CONNECT", "CNH", 10000, 0.01, 101.20, 101.10, volume = 30000000L),

            // Derivatives
            Instrument("HSI_FUT_OCT", "HSIF2610", "恆指期貨10月", "HSI Index Futures Oct", AssetClass.DERIVATIVE, "HKEX", "HKD", 1, 1.0, 18435.00, 18275.00, volume = 85000L)
        )

        _instruments.value = initialList
        initialList.forEach { inst ->
            updateOrderBookFor(inst)
        }
    }

    private fun startLiveMarketFeed() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(800)
                simulateMarketTick()
            }
        }
    }

    private fun simulateMarketTick() {
        val currentList = _instruments.value.toMutableList()
        if (currentList.isEmpty()) return

        // Pick 2 random instruments to tick
        val instCount = currentList.size
        val idx1 = Random.nextInt(instCount)
        val inst = currentList[idx1]

        val pctChange = (Random.nextDouble() - 0.49) * 0.004 // slightly positive bias
        val oldPx = inst.lastPrice
        val newPx = (oldPx * (1.0 + pctChange)).let { px ->
            // Round to tick size
            val ticks = Math.round(px / inst.tickSize)
            ticks * inst.tickSize
        }

        if (newPx <= 0) return

        val changePx = newPx - inst.prevClose
        val changePct = (changePx / inst.prevClose) * 100.0
        val high = maxOf(inst.high, newPx)
        val low = minOf(inst.low, newPx)
        val tradeQty = (Random.nextInt(1, 20) * inst.lotSize).toLong()
        val newVol = inst.volume + tradeQty
        val newTurnover = inst.turnoverHkd + (tradeQty * newPx)

        val updatedInst = inst.copy(
            lastPrice = newPx,
            changePx = changePx,
            changePct = changePct,
            high = high,
            low = low,
            volume = newVol,
            turnoverHkd = newTurnover
        )

        currentList[idx1] = updatedInst
        _instruments.value = currentList

        updateOrderBookFor(updatedInst)

        // Generate trade tick record
        seqCounter++
        val tick = TradeTick(
            sequence = seqCounter,
            instrumentId = updatedInst.id,
            price = newPx,
            quantity = tradeQty,
            side = if (newPx >= oldPx) OrderSide.BUY else OrderSide.SELL,
            timestamp = System.currentTimeMillis()
        )
        val trades = _recentTrades.value.toMutableList()
        trades.add(0, tick)
        if (trades.size > 50) trades.removeAt(trades.size - 1)
        _recentTrades.value = trades
    }

    private fun updateOrderBookFor(inst: Instrument) {
        val px = inst.lastPrice
        val tick = inst.tickSize
        val lot = inst.lotSize.toLong()

        val bids = (1..5).map { level ->
            val levelPx = (px - (level * tick)).let { Math.round(it / tick) * tick }
            val vol = (Random.nextInt(2, 25) * lot)
            val count = Random.nextInt(1, 8)
            OrderBookLevel(levelPx, vol, count)
        }

        val asks = (1..5).map { level ->
            val levelPx = (px + (level * tick)).let { Math.round(it / tick) * tick }
            val vol = (Random.nextInt(2, 25) * lot)
            val count = Random.nextInt(1, 8)
            OrderBookLevel(levelPx, vol, count)
        }

        val bestBid = bids.first().price
        val bestAsk = asks.first().price
        val spread = bestAsk - bestBid

        val bidVol = bids.sumOf { it.volume }.toDouble()
        val askVol = asks.sumOf { it.volume }.toDouble()
        val imbalance = if (bidVol + askVol > 0) (bidVol - askVol) / (bidVol + askVol) else 0.0
        val microprice = if (bidVol + askVol > 0) (bestBid * askVol + bestAsk * bidVol) / (bidVol + askVol) else px

        seqCounter++
        val book = OrderBook(
            instrumentId = inst.id,
            bids = bids,
            asks = asks,
            lastPrice = px,
            lastSize = lot,
            timestamp = System.currentTimeMillis(),
            sequenceNumber = seqCounter,
            microprice = microprice,
            spread = spread,
            imbalance = imbalance
        )

        val currentMap = _orderBooks.value.toMutableMap()
        currentMap[inst.id] = book
        _orderBooks.value = currentMap
    }

    fun getInstrument(id: String): Instrument? {
        return _instruments.value.find { it.id == id }
    }
}
