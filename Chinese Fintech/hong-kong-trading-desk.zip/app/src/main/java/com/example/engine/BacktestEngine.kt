package com.example.engine

import com.example.data.model.QuantBacktestResult
import kotlin.random.Random

class BacktestEngine {

    fun runBacktest(strategyName: String, instrumentId: String): QuantBacktestResult {
        val totalReturn = when (strategyName) {
            "VWAP" -> 14.8
            "TWAP" -> 11.2
            "POV (20%)" -> 16.5
            "Statistical Arbitrage (統計套利)" -> 22.4
            "Mean Reversion (均值回歸)" -> 18.2
            "Cross-Asset Momentum (跨資產動量)" -> 26.1
            "FX Carry & Basis Trading (外匯套息)" -> 8.9
            else -> 15.0
        } + (Random.nextDouble() * 2.0 - 1.0)

        val sharpe = 1.6 + (Random.nextDouble() * 0.8)
        val drawdown = 5.2 + (Random.nextDouble() * 3.0)
        val winRate = 58.5 + (Random.nextDouble() * 8.0)

        return QuantBacktestResult(
            strategyName = strategyName,
            totalReturnPct = totalReturn,
            annualizedReturnPct = totalReturn * 1.25,
            maxDrawdownPct = drawdown,
            winRatePct = winRate,
            sharpeRatio = sharpe,
            totalTrades = Random.nextInt(450, 1200),
            avgSlippageBps = 1.8 + Random.nextDouble() * 1.2,
            totalCommissionHkd = 42_500.0
        )
    }
}
