// RHINOQUANT CHINA MBS - High Performance Rust Engine
// Parallel Monte Carlo & Pool Cashflow Matrix Calculations

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PoolParams {
    pub initial_balance: f64,
    pub wac: f64,
    pub wam: u32,
    pub cpr: f64,
    pub annual_pd: f64,
    pub lgd: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonthlyResult {
    pub month: u32,
    pub beginning_balance: f64,
    pub scheduled_principal: f64,
    pub scheduled_interest: f64,
    pub prepayment: f64,
    pub default_amount: f64,
    pub recovery_amount: f64,
    pub loss_amount: f64,
    pub ending_balance: f64,
}

pub fn simulate_pool(params: &PoolParams) -> Vec<MonthlyResult> {
    let mut results = Vec::with_capacity(params.wam as usize);
    let mut balance = params.initial_balance;

    let smm = 1.0 - (1.0 - params.cpr).powf(1.0 / 12.0);
    let monthly_pd = 1.0 - (1.0 - params.annual_pd).powf(1.0 / 12.0);
    let monthly_rate = params.wac / 12.0;

    for m in 1..=params.wam {
        if balance <= 0.01 {
            break;
        }

        let rem_months = (params.wam - m + 1) as f64;
        let factor = (1.0 + monthly_rate).powf(rem_months);
        let scheduled_pmt = (balance * monthly_rate * factor) / (factor - 1.0);

        let sched_int = balance * monthly_rate;
        let sched_prin = (scheduled_pmt - sched_int).max(0.0).min(balance);

        let bal_after_sched = (balance - sched_prin).max(0.0);
        let prepay = bal_after_sched * smm;

        let bal_after_prepay = (bal_after_sched - prepay).max(0.0);
        let default_amt = bal_after_prepay * monthly_pd;

        let recovery = default_amt * (1.0 - params.lgd);
        let loss = default_amt * params.lgd;

        let ending_bal = (bal_after_prepay - default_amt).max(0.0);

        results.push(MonthlyResult {
            month: m,
            beginning_balance: balance,
            scheduled_principal: sched_prin,
            scheduled_interest: sched_int,
            prepayment: prepay,
            default_amount: default_amt,
            recovery_amount: recovery,
            loss_amount: loss,
            ending_balance: ending_bal,
        });

        balance = ending_bal;
    }

    results
}
