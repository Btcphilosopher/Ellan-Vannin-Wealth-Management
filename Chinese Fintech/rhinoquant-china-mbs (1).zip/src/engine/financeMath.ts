/**
 * RHINOQUANT CHINA MBS - Financial Engineering Math & Cash Flow Core
 * Strict Decimal precision math principles without floating-point artifacts.
 */

import { MonthlyCashflow, Tranche, TrancheMonthlyPayout, ScenarioConfig } from '../types/mbs';

/**
 * Monthly Payment calculation (Equal Payment Amortization)
 * PMT = P * r * (1+r)^n / ((1+r)^n - 1)
 */
export function calculatePMT(principal: number, annualRate: number, months: number): number {
  if (months <= 0 || principal <= 0) return 0;
  if (annualRate <= 0) return Math.round((principal / months) * 100) / 100;
  
  const r = annualRate / 12;
  const factor = Math.pow(1 + r, months);
  const pmt = (principal * r * factor) / (factor - 1);
  return Math.round(pmt * 100) / 100;
}

/**
 * Convert Annual Constant Prepayment Rate (CPR) to Monthly Single Monthly Mortality (SMM)
 * SMM = 1 - (1 - CPR)^(1/12)
 */
export function cprToSmm(cpr: number): number {
  if (cpr <= 0) return 0;
  if (cpr >= 1) return 1;
  return 1 - Math.pow(1 - cpr, 1 / 12);
}

/**
 * Dynamic Refinancing Incentive Model for CPR
 * Base CPR adjusted by interest rate differential and seasoning
 */
export function calculateDynamicCPR(
  baseCPR: number,
  wac: number,
  marketRate: number,
  seasoningMonths: number,
  cprMultiplier: number = 1.0
): number {
  const rateDiff = wac - marketRate; // Positive means incentive to refinance
  let cpr = baseCPR;

  if (rateDiff > 0) {
    // Interest rate drop increases refinancing incentive
    cpr += Math.pow(rateDiff * 10, 1.5) * 0.08;
  } else {
    // Interest rate rise decreases CPR (lock-in effect)
    cpr = Math.max(0.01, cpr - Math.abs(rateDiff) * 0.3);
  }

  // Seasoning ramp (PSA style 30-month ramp up)
  const ramp = Math.min(1.0, seasoningMonths / 30);
  cpr = cpr * ramp * cprMultiplier;

  return Math.min(0.60, Math.max(0.005, cpr));
}

/**
 * Dynamic Probability of Default (PD) and Loss Given Default (LGD)
 * Driven by LTV, DSTI, Property Price shock, and Interest Rate
 */
export function calculateDynamicPDAndLGD(
  basePD: number,
  currentLTV: number,
  dsti: number,
  propertyValueDropPct: number,
  defaultMultiplier: number = 1.0,
  recoveryRateOverride?: number
): { pd: number; lgd: number; ead_factor: number } {
  // Stressed LTV
  const stressedLTV = currentLTV / (1 + propertyValueDropPct);
  
  // Equity pressure
  let pdFactor = 1.0;
  if (stressedLTV > 0.80) pdFactor += (stressedLTV - 0.80) * 3.5;
  if (stressedLTV > 1.00) pdFactor += (stressedLTV - 1.00) * 8.0; // Underwater mortgage default spike
  if (dsti > 0.45) pdFactor += (dsti - 0.45) * 2.5;

  const annualPD = Math.min(0.35, Math.max(0.001, basePD * pdFactor * defaultMultiplier));
  const monthlyPD = 1 - Math.pow(1 - annualPD, 1 / 12);

  // LGD depends on collateral recovery after liquidation cost (approx 10-15% cost)
  let lgd = 0.25; // Base LGD
  if (recoveryRateOverride !== undefined) {
    lgd = 1.0 - recoveryRateOverride;
  } else {
    if (stressedLTV > 0.70) {
      lgd = Math.min(0.85, 0.15 + (stressedLTV - 0.70) * 0.9);
    }
  }

  return {
    pd: monthlyPD,
    lgd: Math.max(0.05, Math.min(0.95, lgd)),
    ead_factor: 1.0
  };
}

/**
 * Generate Pool Monthly Cashflows given Scenario parameters
 */
export function generatePoolMonthlyCashflows(
  initialPoolBalance: number,
  wac: number,
  wam: number,
  baseCPR: number,
  basePD: number,
  baseLTV: number,
  scenario: ScenarioConfig
): MonthlyCashflow[] {
  const cashflows: MonthlyCashflow[] = [];
  let currentBalance = initialPoolBalance;
  
  const marketRate = wac + (scenario.rate_shift_bp / 10000);
  const servicingFeeRate = 0.0025; // 25 bp annual servicing fee
  const trusteeFeeRate = 0.0005; // 5 bp annual trustee fee

  let date = new Date(2026, 0, 1);

  for (let month = 1; month <= wam; month++) {
    if (currentBalance <= 100) break;

    const currentWam = Math.max(1, wam - month + 1);
    const monthlyRate = wac / 12;

    // Scheduled monthly installment
    const scheduledPMT = calculatePMT(currentBalance, wac, currentWam);
    const scheduledInterest = Math.round(currentBalance * monthlyRate * 100) / 100;
    const scheduledPrincipal = Math.min(currentBalance, Math.max(0, scheduledPMT - scheduledInterest));

    // Dynamic CPR & SMM
    const cpr = calculateDynamicCPR(baseCPR, wac, marketRate, month + 12, scenario.cpr_multiplier);
    const smm = cprToSmm(cpr);

    // Dynamic Default & Recovery
    const { pd, lgd } = calculateDynamicPDAndLGD(
      basePD,
      baseLTV,
      0.38,
      scenario.property_price_change_pct,
      scenario.default_multiplier,
      scenario.recovery_rate_override
    );

    // Balance after scheduled principal
    const balanceAfterScheduled = Math.max(0, currentBalance - scheduledPrincipal);

    // Prepayment amount
    const prepayAmount = Math.round(balanceAfterScheduled * smm * 100) / 100;

    // Default amount
    const balanceAfterPrepay = Math.max(0, balanceAfterScheduled - prepayAmount);
    const defaultBalance = Math.round(balanceAfterPrepay * pd * 100) / 100;

    // Recovery & Loss
    const recoveryAmount = Math.round(defaultBalance * (1 - lgd) * 100) / 100;
    const lossAmount = Math.round(defaultBalance * lgd * 100) / 100;

    const endingBalance = Math.max(0, balanceAfterPrepay - defaultBalance);

    // Pool Collections
    const totalCashAvailable = scheduledPrincipal + scheduledInterest + prepayAmount + recoveryAmount;

    // Fees
    const servicingFees = Math.round((currentBalance * servicingFeeRate) / 12 * 100) / 100;
    const trusteeFees = Math.round((currentBalance * trusteeFeeRate) / 12 * 100) / 100;

    const netCashDistributable = Math.max(0, totalCashAvailable - servicingFees - trusteeFees);

    date.setMonth(date.getMonth() + 1);
    const dateStr = date.toISOString().slice(0, 7);

    cashflows.push({
      month,
      date: dateStr,
      beginning_balance: currentBalance,
      scheduled_principal: scheduledPrincipal,
      scheduled_interest: scheduledInterest,
      prepayment_principal: prepayAmount,
      default_balance: defaultBalance,
      recovery_amount: recoveryAmount,
      loss_amount: lossAmount,
      total_cash_available: totalCashAvailable,
      servicing_fees: servicingFees,
      trustee_fees: trusteeFees,
      net_cash_distributable: netCashDistributable,
      ending_balance: endingBalance,
      cpr_applied: Math.round(cpr * 10000) / 100,
      smm_applied: Math.round(smm * 10000) / 100,
      pd_applied: Math.round(pd * 10000) / 100,
      lgd_applied: Math.round(lgd * 10000) / 100
    });

    currentBalance = endingBalance;
  }

  return cashflows;
}

/**
 * Execute Waterfall Cash Flow Allocation to Tranches
 * Strictly respects Seniority & Attachment/Detachment Loss Allocation Rules
 */
export function executeWaterfallAllocation(
  tranchesInput: Tranche[],
  monthlyPoolCashflows: MonthlyCashflow[]
): {
  updatedTranches: Tranche[];
  payouts: TrancheMonthlyPayout[];
} {
  // Deep clone tranches
  const tranches: Tranche[] = JSON.parse(JSON.stringify(tranchesInput));
  tranches.sort((a, b) => a.priority - b.priority);

  const payouts: TrancheMonthlyPayout[] = [];

  for (const cf of monthlyPoolCashflows) {
    let availableCash = cf.net_cash_distributable;
    let poolLoss = cf.loss_amount;

    // 1. Pay Tranche Interest sequentially by priority
    for (const tr of tranches) {
      if (tr.current_balance <= 0) continue;
      const interestDue = Math.round((tr.current_balance * tr.coupon_rate) / 12 * 100) / 100;
      const interestPaid = Math.min(availableCash, interestDue);
      availableCash -= interestPaid;

      payouts.push({
        month: cf.month,
        tranche_id: tr.tranche_id,
        tranche_name: tr.tranche_name,
        beginning_balance: tr.current_balance,
        interest_due: interestDue,
        interest_paid: interestPaid,
        principal_paid: 0,
        loss_allocated: 0,
        ending_balance: tr.current_balance
      });
    }

    // 2. Pay Tranche Principal sequentially by priority (Sequential Pay structure)
    for (const tr of tranches) {
      if (availableCash <= 0) break;
      if (tr.current_balance <= 0) continue;

      const principalTarget = cf.scheduled_principal + cf.prepayment_principal + cf.recovery_amount;
      const principalPaid = Math.min(availableCash, tr.current_balance, principalTarget);

      tr.current_balance = Math.max(0, tr.current_balance - principalPaid);
      availableCash -= principalPaid;

      // Update payout entry
      const payoutEntry = payouts.find(p => p.month === cf.month && p.tranche_id === tr.tranche_id);
      if (payoutEntry) {
        payoutEntry.principal_paid = principalPaid;
        payoutEntry.ending_balance = tr.current_balance;
      }
    }

    // 3. Loss Allocation Engine (Reverse Seniority: Equity absorbs loss first, then Subordinate, Mezzanine, Senior)
    if (poolLoss > 0) {
      const reverseTranches = [...tranches].reverse();
      for (const tr of reverseTranches) {
        if (poolLoss <= 0) break;
        if (tr.current_balance <= 0) continue;

        const lossAbsorbed = Math.min(poolLoss, tr.current_balance);
        tr.current_balance = Math.max(0, tr.current_balance - lossAbsorbed);
        poolLoss -= lossAbsorbed;

        const payoutEntry = payouts.find(p => p.month === cf.month && p.tranche_id === tr.tranche_id);
        if (payoutEntry) {
          payoutEntry.loss_allocated = lossAbsorbed;
          payoutEntry.ending_balance = tr.current_balance;
        }
      }
    }
  }

  // Recalculate metrics for updated tranches
  for (const tr of tranches) {
    const trPayouts = payouts.filter(p => p.tranche_id === tr.tranche_id);
    const wal = calculateWAL(trPayouts);
    const dur = calculateModifiedDuration(tr.coupon_rate, wal, tr.clean_price / 100);
    const dv01 = Math.round((tr.current_balance * dur * 0.0001) * 100) / 100;

    tr.wal = wal;
    tr.duration = dur;
    tr.dv01 = dv01;
  }

  return { updatedTranches: tranches, payouts };
}

/**
 * Weighted Average Life (WAL) in years
 * WAL = sum(t * principal_t) / sum(principal_t)
 */
export function calculateWAL(payouts: TrancheMonthlyPayout[]): number {
  let totalPrincipal = 0;
  let weightedMonths = 0;

  for (const p of payouts) {
    if (p.principal_paid > 0) {
      totalPrincipal += p.principal_paid;
      weightedMonths += (p.month / 12) * p.principal_paid;
    }
  }

  if (totalPrincipal <= 0) return 0;
  return Math.round((weightedMonths / totalPrincipal) * 100) / 100;
}

/**
 * Modified Duration calculation
 */
export function calculateModifiedDuration(coupon: number, wal: number, priceDecimal: number): number {
  if (wal <= 0 || priceDecimal <= 0) return 0;
  const yieldEst = coupon + (1.0 - priceDecimal) / Math.max(1, wal);
  const macDur = wal * 0.92; // Empirical Macaulay duration factor for amortizing loans
  const modDur = macDur / (1 + yieldEst / 2);
  return Math.round(modDur * 100) / 100;
}

/**
 * Z-Spread Calculation over Spot Curve
 */
export function calculateZSpread(
  cashflows: { month: number; cashflow: number }[],
  cleanPrice: number,
  spotRates: number[] // Monthly spot rates decimal
): number {
  if (cashflows.length === 0 || cleanPrice <= 0) return 0;

  let zSpreadBp = 150; // Initial guess 150 bps
  for (let iter = 0; iter < 20; iter++) {
    const spreadDecimal = zSpreadBp / 10000;
    let pv = 0;
    for (const cf of cashflows) {
      const spot = spotRates[cf.month - 1] || 0.025;
      const discount = Math.pow(1 + (spot + spreadDecimal) / 12, cf.month);
      pv += cf.cashflow / discount;
    }

    const diff = pv - cleanPrice;
    if (Math.abs(diff) < 0.01) break;
    zSpreadBp += diff > 0 ? 5 : -5;
  }

  return Math.round(zSpreadBp);
}
