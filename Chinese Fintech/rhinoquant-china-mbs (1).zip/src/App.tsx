import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { MarketTerminal } from './components/MarketTerminal';
import { SecurityResearch } from './components/SecurityResearch';
import { LoanPoolDigitalTwin } from './components/LoanPoolDigitalTwin';
import { CashflowWaterfallView } from './components/CashflowWaterfallView';
import { TradingTerminal } from './components/TradingTerminal';
import { PortfolioView } from './components/PortfolioView';
import { ScenarioLab } from './components/ScenarioLab';
import { ServicingDisclosureView } from './components/ServicingDisclosureView';
import { AiIntelligenceView } from './components/AiIntelligenceView';
import { CodeEngineBrowser } from './components/CodeEngineBrowser';

import { LoanPool, Security, PortfolioSummary, AccountingEntry, InvariantCheckResult } from './types/mbs';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('market');
  const [pools, setPools] = useState<LoanPool[]>([]);
  const [securities, setSecurities] = useState<Security[]>([]);
  const [fund, setFund] = useState<PortfolioSummary | null>(null);
  const [accountingEntries, setAccountingEntries] = useState<AccountingEntry[]>([]);
  const [selectedSecId, setSelectedSecId] = useState<string>('');
  const [invariantStatus, setInvariantStatus] = useState<{ total: number; passed: number } | null>(null);

  const fetchData = async () => {
    try {
      const [poolsRes, secRes, fundRes, accRes, invRes] = await Promise.all([
        fetch('/api/pools'),
        fetch('/api/securities'),
        fetch('/api/portfolio'),
        fetch('/api/accounting'),
        fetch('/api/invariants')
      ]);

      const poolsData = await poolsRes.json();
      const secData = await secRes.json();
      const fundData = await fundRes.json();
      const accData = await accRes.json();
      const invData: InvariantCheckResult[] = await invRes.json();

      setPools(poolsData);
      setSecurities(secData);
      setFund(fundData);
      setAccountingEntries(accData);
      if (secData.length > 0 && !selectedSecId) {
        setSelectedSecId(secData[0].security_id);
      }

      if (Array.isArray(invData)) {
        const passed = invData.filter((i) => i.status === 'PASSED').length;
        setInvariantStatus({ total: invData.length, passed });
      }
    } catch (err) {
      console.error('Failed to fetch platform data:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSelectSecurity = (secId: string) => {
    setSelectedSecId(secId);
    setActiveTab('research');
  };

  const handleSimulateWaterfall = (secId: string) => {
    setSelectedSecId(secId);
    setActiveTab('cashflow');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-mono selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Header & Navigation */}
      <Header
        fund={fund}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        invariantStatus={invariantStatus}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto">
        {activeTab === 'market' && (
          <MarketTerminal
            securities={securities}
            pools={pools}
            onSelectSecurity={handleSelectSecurity}
          />
        )}

        {activeTab === 'research' && (
          <SecurityResearch
            securities={securities}
            pools={pools}
            selectedSecId={selectedSecId}
            onSelectSecurity={setSelectedSecId}
            onSimulateWaterfall={handleSimulateWaterfall}
          />
        )}

        {activeTab === 'pool_twin' && <LoanPoolDigitalTwin pools={pools} />}

        {activeTab === 'cashflow' && (
          <CashflowWaterfallView
            poolId={
              securities.find((s) => s.security_id === selectedSecId)?.underlying_pool_id ||
              pools[0]?.pool_id ||
              'RHX-POOL-001'
            }
          />
        )}

        {activeTab === 'trading' && (
          <TradingTerminal
            securities={securities}
            accountingEntries={accountingEntries}
            onTradeSubmitted={fetchData}
          />
        )}

        {activeTab === 'portfolio' && <PortfolioView fund={fund} />}

        {activeTab === 'scenarios' && <ScenarioLab />}

        {activeTab === 'disclosure' && (
          <ServicingDisclosureView pools={pools} securities={securities} />
        )}

        {activeTab === 'ai_intelligence' && <AiIntelligenceView />}

        {activeTab === 'code_browser' && <CodeEngineBrowser />}
      </main>

      {/* Bottom Status Bar */}
      <footer className="bg-slate-950 border-t border-slate-800 px-4 py-1.5 text-[11px] text-slate-500 flex flex-wrap items-center justify-between font-mono">
        <div className="flex items-center space-x-4">
          <span>RHINOQUANT CHINA MBS v3.5-PROD</span>
          <span>•</span>
          <span>架构: Express + React 18 + Recharts + Python/Rust Engine</span>
          <span>•</span>
          <span className="text-emerald-400">100,000+ 模拟房贷逐笔关联中</span>
        </div>

        <div className="flex items-center space-x-3 text-slate-400">
          <span>环境: Sandbox Cloud Run (Port 3000)</span>
          <span>•</span>
          <span>模式: 机构专业级多分层定价与风险引擎</span>
        </div>
      </footer>
    </div>
  );
}
export default App;
