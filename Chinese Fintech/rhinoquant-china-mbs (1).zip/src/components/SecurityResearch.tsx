import React, { useState } from 'react';
import { Security, LoanPool } from '../types/mbs';
import { Layers, Shield, DollarSign, Calendar, TrendingUp, Cpu, PieChart } from 'lucide-react';

interface SecurityResearchProps {
  securities: Security[];
  pools: LoanPool[];
  selectedSecId: string;
  onSelectSecurity: (id: string) => void;
  onSimulateWaterfall: (secId: string) => void;
}

export const SecurityResearch: React.FC<SecurityResearchProps> = ({
  securities,
  pools,
  selectedSecId,
  onSelectSecurity,
  onSimulateWaterfall
}) => {
  const currentSec = securities.find((s) => s.security_id === selectedSecId) || securities[0];
  const underlyingPool = pools.find((p) => p.pool_id === currentSec.underlying_pool_id);

  return (
    <div className="space-y-4 p-4 font-mono text-slate-200">
      {/* Top Security Selector */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <span className="text-slate-400">当前选择证券:</span>
          <select
            value={currentSec.security_id}
            onChange={(e) => onSelectSecurity(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-cyan-400 font-bold px-3 py-1.5 rounded focus:outline-none focus:border-cyan-500"
          >
            {securities.map((s) => (
              <option key={s.security_id} value={s.security_id}>
                {s.ticker} - {s.name} (规模: ¥{(s.total_issue_amount / 1e8).toFixed(1)}亿)
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={() => onSimulateWaterfall(currentSec.security_id)}
          className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-bold transition-colors flex items-center space-x-1"
        >
          <Cpu className="w-4 h-4" />
          <span>运行瀑布现金流推演</span>
        </button>
      </div>

      {/* Security Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400">发行总额</div>
          <div className="text-lg font-bold text-slate-100 mt-1">
            ¥{(currentSec.total_issue_amount / 1e8).toFixed(2)} 亿元
          </div>
          <div className="text-slate-500 text-[11px] mt-1">发行日: {currentSec.issue_date}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400">当前剩余本金</div>
          <div className="text-lg font-bold text-cyan-400 mt-1">
            ¥{(currentSec.current_total_balance / 1e8).toFixed(2)} 亿元
          </div>
          <div className="text-slate-500 text-[11px] mt-1">法定到期日: {currentSec.maturity_date}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400">关联底层资产池</div>
          <div className="text-lg font-bold text-emerald-400 mt-1">{underlyingPool?.pool_id}</div>
          <div className="text-slate-500 text-[11px] mt-1">
            WAC: {((underlyingPool?.weighted_average_coupon || 0) * 100).toFixed(2)}% | WAM:{' '}
            {underlyingPool?.weighted_average_maturity}月
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400">分层数量 & 增信保护</div>
          <div className="text-lg font-bold text-amber-300 mt-1">
            {currentSec.tranches.length} 档 | 15% 厚度
          </div>
          <div className="text-slate-500 text-[11px] mt-1">次级与权益层超额抵押缓冲</div>
        </div>
      </div>

      {/* Tranche Seniority & Credit Enhancement Hierarchy Table */}
      <div className="bg-slate-900 border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>MBS 证券分层结构与信用增级 (Tranche Seniority & Attachment Points)</span>
          </div>
          <span className="text-xs text-slate-400">次级安全垫分配模型</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <th className="p-3 font-medium">优先级</th>
                <th className="p-3 font-medium">分层名称</th>
                <th className="p-3 font-medium">清偿级别</th>
                <th className="p-3 font-medium">评级</th>
                <th className="p-3 font-medium text-right">票面利率</th>
                <th className="p-3 font-medium text-right">当前本金 (亿元)</th>
                <th className="p-3 font-medium text-right">损益吸收区间</th>
                <th className="p-3 font-medium text-right">WAL (年)</th>
                <th className="p-3 font-medium text-right">OAS (bp)</th>
                <th className="p-3 font-medium text-right">DV01 (万元/bp)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {currentSec.tranches.map((t) => (
                <tr key={t.tranche_id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-slate-400">P{t.priority}</td>
                  <td className="p-3 font-bold text-cyan-300">{t.tranche_name}</td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        t.seniority === 'SENIOR'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : t.seniority === 'MEZZANINE'
                          ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                          : t.seniority === 'SUBORDINATE'
                          ? 'bg-amber-950 text-amber-400 border border-amber-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {t.seniority}
                    </span>
                  </td>
                  <td className="p-3 font-bold text-slate-200">{t.rating_agency_rating}</td>
                  <td className="p-3 text-right text-emerald-400 font-bold">
                    {(t.coupon_rate * 100).toFixed(2)}%
                  </td>
                  <td className="p-3 text-right font-bold text-slate-100 font-mono">
                    {(t.current_balance / 1e8).toFixed(2)}
                  </td>
                  <td className="p-3 text-right text-slate-300 font-mono">
                    [(t.attachment_point * 100).toFixed(0)% - {(t.detachment_point * 100).toFixed(0)}%]
                  </td>
                  <td className="p-3 text-right text-slate-300">{t.wal}</td>
                  <td className="p-3 text-right text-cyan-300 font-bold font-mono">{t.oas} bp</td>
                  <td className="p-3 text-right text-amber-300 font-bold font-mono">
                    {(t.dv01 / 10000).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* OAS Valuation & Pricing Model Parameters Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded">
          <div className="flex items-center space-x-2 text-cyan-400 font-bold mb-3 border-b border-slate-800 pb-2">
            <Cpu className="w-4 h-4" />
            <span>OAS 期权调整利差与提前偿还定价假设</span>
          </div>
          <div className="space-y-2 text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-400">定价基准收益率:</span>
              <span className="font-bold text-slate-100">中国国债即期零息曲线 (2.15%)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">利率波动率模型 (Hull-White):</span>
              <span className="font-bold text-slate-100">σ = 0.85% / a = 0.03</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">提前偿还基准 (CPR 3M):</span>
              <span className="font-bold text-emerald-400">
                {((underlyingPool?.cpr_3m || 0) * 100).toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">年化违约率 (PD):</span>
              <span className="font-bold text-amber-400">
                {((underlyingPool?.default_rate_annual || 0) * 100).toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">违约损失率 (LGD):</span>
              <span className="font-bold text-slate-100">25.0% (处置回收率 75.0%)</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded">
          <div className="flex items-center space-x-2 text-cyan-400 font-bold mb-3 border-b border-slate-800 pb-2">
            <Shield className="w-4 h-4" />
            <span>优先级与次级保护垫分配图 (Protection Buffer)</span>
          </div>
          <div className="space-y-3">
            {currentSec.tranches.map((t) => {
              const widthPct = Math.max(5, (t.current_balance / currentSec.current_total_balance) * 100);
              return (
                <div key={t.tranche_id} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="font-bold text-slate-200">{t.tranche_name}</span>
                    <span className="text-slate-400">
                      ¥{(t.current_balance / 1e8).toFixed(2)}亿 ({widthPct.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
                    <div
                      className={`h-full ${
                        t.seniority === 'SENIOR'
                          ? 'bg-emerald-500'
                          : t.seniority === 'MEZZANINE'
                          ? 'bg-cyan-500'
                          : t.seniority === 'SUBORDINATE'
                          ? 'bg-amber-500'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${widthPct}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
