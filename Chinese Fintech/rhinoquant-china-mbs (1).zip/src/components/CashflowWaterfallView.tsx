import React, { useState, useEffect } from 'react';
import { MonthlyCashflow, Tranche, ScenarioConfig } from '../types/mbs';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid, LineChart, Line } from 'recharts';
import { Play, RotateCcw, Sliders, Layers, Droplet } from 'lucide-react';

interface CashflowWaterfallViewProps {
  poolId: string;
}

export const CashflowWaterfallView: React.FC<CashflowWaterfallViewProps> = ({ poolId }) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [cashflows, setCashflows] = useState<MonthlyCashflow[]>([]);
  const [waterfallTranches, setWaterfallTranches] = useState<Tranche[]>([]);
  const [rateShift, setRateShift] = useState<number>(0); // bp
  const [priceDrop, setPriceDrop] = useState<number>(0); // %
  const [cprMult, setCprMult] = useState<number>(1.0);
  const [defaultMult, setDefaultMult] = useState<number>(1.0);

  const runSimulation = async () => {
    setLoading(true);
    try {
      const scenario: ScenarioConfig = {
        scenario_id: 'CUSTOM',
        name: '自定义演练情景',
        rate_shift_bp: rateShift,
        property_price_change_pct: priceDrop / 100,
        cpr_multiplier: cprMult,
        default_multiplier: defaultMult
      };

      const res = await fetch('/api/cashflows/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pool_id: poolId, scenario })
      });

      const data = await res.json();
      setCashflows(data.monthlyPoolCashflows || []);
      setWaterfallTranches(data.waterfallTranches || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runSimulation();
  }, [poolId]);

  // Format data for Recharts (Show first 36 months for clear visualization)
  const chartData = cashflows.slice(0, 36).map((cf) => ({
    month: `M${cf.month}`,
    scheduledPrincipal: Math.round(cf.scheduled_principal / 10000),
    prepayment: Math.round(cf.prepayment_principal / 10000),
    interest: Math.round(cf.scheduled_interest / 10000),
    loss: Math.round(cf.loss_amount / 10000),
    recovery: Math.round(cf.recovery_amount / 10000),
    cprApplied: cf.cpr_applied,
    pdApplied: cf.pd_applied
  }));

  return (
    <div className="space-y-4 p-4 font-mono text-slate-200">
      {/* Simulation Scenario Control Box */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-3 text-xs">
          <div className="flex items-center space-x-2 font-bold text-cyan-400">
            <Sliders className="w-4 h-4" />
            <span>MBS 现金流瀑布与损益模拟引擎 (Waterfall Simulator)</span>
          </div>
          <button
            onClick={runSimulation}
            disabled={loading}
            className="px-4 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-bold transition-colors flex items-center space-x-1.5"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{loading ? '引擎计算中...' : '重新运行模拟'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <div className="flex justify-between text-slate-400 mb-1">
              <span>基准利率变动 (Rate Shift):</span>
              <span className="font-bold text-cyan-400">{rateShift > 0 ? `+${rateShift}` : rateShift} bp</span>
            </div>
            <input
              type="range"
              min="-200"
              max="300"
              step="25"
              value={rateShift}
              onChange={(e) => setRateShift(Number(e.target.value))}
              className="w-full accent-cyan-500 bg-slate-950"
            />
          </div>

          <div>
            <div className="flex justify-between text-slate-400 mb-1">
              <span>房价冲击 (House Price):</span>
              <span className="font-bold text-amber-400">{priceDrop}%</span>
            </div>
            <input
              type="range"
              min="-40"
              max="10"
              step="5"
              value={priceDrop}
              onChange={(e) => setPriceDrop(Number(e.target.value))}
              className="w-full accent-amber-500 bg-slate-950"
            />
          </div>

          <div>
            <div className="flex justify-between text-slate-400 mb-1">
              <span>提前偿还乘数 (CPR):</span>
              <span className="font-bold text-emerald-400">{cprMult.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.2"
              max="3.0"
              step="0.1"
              value={cprMult}
              onChange={(e) => setCprMult(Number(e.target.value))}
              className="w-full accent-emerald-500 bg-slate-950"
            />
          </div>

          <div>
            <div className="flex justify-between text-slate-400 mb-1">
              <span>违约率乘数 (PD):</span>
              <span className="font-bold text-rose-400">{defaultMult.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="5.0"
              step="0.5"
              value={defaultMult}
              onChange={(e) => setDefaultMult(Number(e.target.value))}
              className="w-full accent-rose-500 bg-slate-950"
            />
          </div>
        </div>
      </div>

      {/* Cashflow Chart (Recharts Stacked Bar) */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3 text-xs">
          <div className="flex items-center space-x-2 font-bold text-slate-200">
            <Droplet className="w-4 h-4 text-cyan-400" />
            <span>月度资产池现金流分配堆叠图 (前36个月，单位: 万元)</span>
          </div>
          <span className="text-slate-400">本金偿还 • 提前偿还 • 利息收入 • 违约损失</span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="month" stroke="#94a3b8" tick={{ fontSize: 10 }} />
              <YAxis stroke="#94a3b8" tick={{ fontSize: 10 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: 11 }}
              />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="scheduledPrincipal" name="常规本金" stackId="a" fill="#3b82f6" />
              <Bar dataKey="prepayment" name="提前偿还本金" stackId="a" fill="#06b6d4" />
              <Bar dataKey="interest" name="利息收入" stackId="a" fill="#10b981" />
              <Bar dataKey="loss" name="违约损失" stackId="a" fill="#f43f5e" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Waterfall Payout Output Tranche Table */}
      <div className="bg-slate-900 border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
            <Layers className="w-4 h-4 text-cyan-400" />
            <span>瀑布分配后证券分层计算指标 (Simulated Tranche Metrics)</span>
          </div>
          <span className="text-xs text-slate-400">顺序清偿 (Sequential Pay) 规则生效中</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <th className="p-3 font-medium">分层名称</th>
                <th className="p-3 font-medium">清偿级别</th>
                <th className="p-3 font-medium text-right">初始本金 (亿元)</th>
                <th className="p-3 font-medium text-right">演练后剩余本金 (亿元)</th>
                <th className="p-3 font-medium text-right">加权寿命 WAL (年)</th>
                <th className="p-3 font-medium text-right">修正久期 (年)</th>
                <th className="p-3 font-medium text-right">DV01 (万元/bp)</th>
                <th className="p-3 font-medium text-center">状态</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {waterfallTranches.map((t) => (
                <tr key={t.tranche_id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-cyan-300">{t.tranche_name}</td>
                  <td className="p-3 font-bold text-slate-300">{t.seniority}</td>
                  <td className="p-3 text-right text-slate-300">{(t.initial_balance / 1e8).toFixed(2)}</td>
                  <td className="p-3 text-right font-bold text-slate-100 font-mono">
                    {(t.current_balance / 1e8).toFixed(2)}
                  </td>
                  <td className="p-3 text-right text-emerald-400 font-bold">{t.wal}</td>
                  <td className="p-3 text-right text-cyan-300">{t.duration}</td>
                  <td className="p-3 text-right text-amber-300 font-bold">{(t.dv01 / 10000).toFixed(2)}</td>
                  <td className="p-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                      清偿正常
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
