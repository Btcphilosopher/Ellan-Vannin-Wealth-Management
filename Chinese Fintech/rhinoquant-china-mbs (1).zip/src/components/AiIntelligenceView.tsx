import React, { useState } from 'react';
import { Bot, Send, Sparkles, Shield, Cpu, RefreshCw, CheckCircle2 } from 'lucide-react';
import Markdown from 'react-markdown';

export const AiIntelligenceView: React.FC = () => {
  const [question, setQuestion] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [messages, setMessages] = useState<
    Array<{
      sender: 'USER' | 'AI';
      text: string;
      version?: string;
      lineage?: string;
    }>
  >([
    {
      sender: 'AI',
      text: '您好！我是 RhinoQuant China MBS 平台的 AI 量化分析师。我连接了系统底层 Decimal 级现金流引擎与 100,000+ 笔合成房贷数据池。请问有什么关于利率敏感度、提前偿还模型或结构化瀑布的问题需要分析？',
      version: 'v3.5-PROD-GEMINI',
      lineage: 'Fund -> Security -> Tranche -> Pool -> Loan -> Property'
    }
  ]);

  const presetPrompts = [
    '若基准利率突然下调 50bp，加权平均寿命 (WAL) 与提前偿还 (CPR) 将如何演变？',
    '一线城市房价下挫 20% 时，优先 A1 级与次级 tranche 的 Expected Loss 传导路径是什么？',
    '解释顺序清偿 (Sequential Pay) 瀑布机制如何保护优先 A 级证券的本金安全？',
    '分析 RhinoQuant China Fund 100亿 AUM 的 DV01 风险敞口与利率对冲策略建议。'
  ];

  const handleSend = async (queryText?: string) => {
    const q = queryText || question;
    if (!q.trim() || loading) return;

    const userMsg = { sender: 'USER' as const, text: q };
    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setQuestion('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: q })
      });

      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        {
          sender: 'AI',
          text: data.answer || '分析完成',
          version: data.model_version,
          lineage: data.source_lineage
        }
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'AI',
          text: 'AI 引擎响应超时或服务暂时不可用，已自动切换至本地量化估算结果。',
          version: 'v3.5-LOCAL-FALLBACK'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 p-4 font-mono text-slate-200">
      {/* Top Header Card */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded flex items-center justify-between text-xs">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-cyan-950 rounded border border-cyan-800">
            <Bot className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <div className="font-bold text-slate-100 text-sm">RHINOQUANT AI 机构量化智库助手</div>
            <div className="text-slate-400">
              与底层 Decimal 级金融引擎和 100,000+ 笔合成房贷数据强连通 • 归因与数据血缘透明
            </div>
          </div>
        </div>

        <div className="hidden sm:flex items-center space-x-2 bg-slate-950 px-3 py-1.5 rounded border border-slate-800 text-[11px]">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-slate-300">模型版本: v3.5-PROD-GEMINI</span>
        </div>
      </div>

      {/* Preset Prompt Chips */}
      <div className="flex flex-wrap gap-2 text-xs">
        {presetPrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(p)}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-cyan-700 text-slate-300 rounded text-[11px] transition-colors flex items-center space-x-1"
          >
            <Sparkles className="w-3 h-3 text-cyan-400 shrink-0" />
            <span>{p}</span>
          </button>
        ))}
      </div>

      {/* Chat Messages Box */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4 h-[420px] overflow-y-auto space-y-4 text-xs">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex ${m.sender === 'USER' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded p-3 space-y-2 ${
                m.sender === 'USER'
                  ? 'bg-cyan-950 border border-cyan-800 text-cyan-100 font-semibold'
                  : 'bg-slate-950 border border-slate-800 text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between text-[10px] text-slate-400 border-b border-slate-800/80 pb-1 mb-1">
                <span className="font-bold">{m.sender === 'USER' ? '机构量化研究员' : 'RHINOQUANT AI'}</span>
                {m.version && <span className="text-cyan-400 font-mono">{m.version}</span>}
              </div>

              <div className="markdown-body leading-relaxed text-xs">
                <Markdown>{m.text}</Markdown>
              </div>

              {m.lineage && (
                <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-800/60 flex items-center space-x-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                  <span>数据与计算血缘: {m.lineage}</span>
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-slate-950 border border-slate-800 p-3 rounded text-slate-400 text-xs flex items-center space-x-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
              <span>AI 引擎正在检索资产池现金流矩阵并计算回答...</span>
            </div>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend();
        }}
        className="flex items-center space-x-2 text-xs"
      >
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="请输入金融工程、MBS分层、久期敏感度或提前偿还模型分析提问..."
          className="flex-1 bg-slate-900 border border-slate-700 rounded p-2.5 text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
        />
        <button
          type="submit"
          disabled={loading}
          className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded transition-colors flex items-center space-x-1"
        >
          <Send className="w-4 h-4" />
          <span>提问</span>
        </button>
      </form>
    </div>
  );
};
