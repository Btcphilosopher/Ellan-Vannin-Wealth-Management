import React, { useState } from 'react';
import { Security, LoanPool } from '../types/mbs';
import { Search, Filter, ArrowUpRight, ArrowDownRight, TrendingUp, BarChart3, Info } from 'lucide-react';

interface MarketTerminalProps {
  securities: Security[];
  pools: LoanPool[];
  onSelectSecurity: (secId: string) => void;
}

export const MarketTerminal: React.FC<MarketTerminalProps> = ({
  securities,
  pools,
  onSelectSecurity
}) => {
  const [filterRating, setFilterRating] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Collect all tranches with security metadata
  const allTranches = securities.flatMap((sec) =>
    sec.tranches.map((t) => ({
      ...t,
      secTicker: sec.ticker,
      secName: sec.name,
      poolId: sec.underlying_pool_id
    }))
  );

  const filteredTranches = allTranches.filter((t) => {
    const matchesRating = filterRating === 'ALL' || t.rating_agency_rating === filterRating;
    const matchesSearch =
      t.tranche_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.secTicker.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesRating && matchesSearch;
  });

  return (
    <div className="space-y-4 p-4 font-mono text-slate-200">
      {/* Warning Disclaimer Box */}
      <div className="bg-amber-950/40 border border-amber-800/80 rounded p-3 text-xs text-amber-200/90 flex items-start space-x-2">
        <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-amber-300">系统声明 [RhinoQuant Synthetics]: </span>
          本系统所有 MBS 证券代码、交易价格、贷款池与持仓数据均为合成/模拟数据 [SYNTHETIC DATA]，不属于中国任何真实银行或证券机构，不接入真实交易系统。数据与定价由内部量化引擎实时计算得出。
        </div>
      </div>

      {/* Market Overview Top Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400 mb-1">中债国债3年期收益率 (基准)</div>
          <div className="text-xl font-bold text-slate-100 flex items-baseline justify-between">
            <span>2.15%</span>
            <span className="text-emerald-400 text-xs flex items-center">
              <ArrowDownRight className="w-3 h-3 mr-0.5" /> -1.5 bp
            </span>
          </div>
          <div className="text-slate-500 text-[11px] mt-1">人民币即期零息收益率曲线</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400 mb-1">MBS 优先A1级利差 (AAA)</div>
          <div className="text-xl font-bold text-cyan-400 flex items-baseline justify-between">
            <span>45 bp</span>
            <span className="text-slate-400 text-xs">Z-Spread: 45bp</span>
          </div>
          <div className="text-slate-500 text-[11px] mt-1">加权平均寿命 WAL: 2.4 年</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400 mb-1">MBS 优先A2级利差 (AAA)</div>
          <div className="text-xl font-bold text-cyan-300 flex items-baseline justify-between">
            <span>75 bp</span>
            <span className="text-slate-400 text-xs">OAS: 65bp</span>
          </div>
          <div className="text-slate-500 text-[11px] mt-1">加权平均寿命 WAL: 4.8 年</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400 mb-1">全市场合成 MBS 发行总额</div>
          <div className="text-xl font-bold text-emerald-400 flex items-baseline justify-between">
            <span>¥{(securities.reduce((s, sec) => s + sec.total_issue_amount, 0) / 1e8).toFixed(1)} 亿</span>
            <span className="text-xs text-slate-400">{securities.length} 期 MBS / 50 档分层</span>
          </div>
          <div className="text-slate-500 text-[11px] mt-1">包含 100,000+ 笔底层住房贷款</div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-3 rounded text-xs">
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-slate-400">评级筛选:</span>
          {['ALL', 'AAA', 'AA', 'A+', 'NR'].map((r) => (
            <button
              key={r}
              onClick={() => setFilterRating(r)}
              className={`px-2.5 py-1 rounded transition-colors ${
                filterRating === r
                  ? 'bg-cyan-600 text-white font-bold'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {r === 'ALL' ? '全部评级' : r}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-2.5 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="搜索证券代码 / 分层名称..."
            className="w-full bg-slate-950 border border-slate-700 rounded pl-8 pr-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Market Quotes Table */}
      <div className="bg-slate-900 border border-slate-800 rounded overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-slate-200 text-xs">中国 MBS 市场二级报价与定价指标表</span>
          </div>
          <span className="text-xs text-slate-400">实时定价引擎计算 • 100,000+ 底层房贷关联</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <th className="p-3 font-medium">证券代码</th>
                <th className="p-3 font-medium">分层名称</th>
                <th className="p-3 font-medium">评级</th>
                <th className="p-3 font-medium text-right">净价 (Clean Price)</th>
                <th className="p-3 font-medium text-right">到期收益率 (YTM)</th>
                <th className="p-3 font-medium text-right">Z-Spread</th>
                <th className="p-3 font-medium text-right">OAS (bp)</th>
                <th className="p-3 font-medium text-right">加权寿命 (WAL)</th>
                <th className="p-3 font-medium text-right">修正久期</th>
                <th className="p-3 font-medium text-right">当前余额 (亿元)</th>
                <th className="p-3 font-medium text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredTranches.map((t) => (
                <tr key={t.tranche_id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="p-3 text-cyan-400 font-bold">{t.secTicker}</td>
                  <td className="p-3 font-medium text-slate-200">{t.tranche_name}</td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        t.rating_agency_rating === 'AAA'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : t.rating_agency_rating.startsWith('A')
                          ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}
                    >
                      {t.rating_agency_rating}
                    </span>
                  </td>
                  <td className="p-3 text-right font-bold text-slate-100">{t.clean_price.toFixed(2)}</td>
                  <td className="p-3 text-right text-emerald-400 font-semibold">{(t.ytm * 100).toFixed(2)}%</td>
                  <td className="p-3 text-right text-amber-300 font-mono">{t.z_spread} bp</td>
                  <td className="p-3 text-right text-cyan-300 font-mono">{t.oas} bp</td>
                  <td className="p-3 text-right text-slate-300">{t.wal} 年</td>
                  <td className="p-3 text-right text-slate-300">{t.duration} 年</td>
                  <td className="p-3 text-right text-slate-200 font-bold font-mono">
                    {(t.current_balance / 1e8).toFixed(2)}
                  </td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => onSelectSecurity(t.security_id)}
                      className="px-2.5 py-1 bg-cyan-950 hover:bg-cyan-900 border border-cyan-700 text-cyan-300 text-[11px] rounded transition-colors"
                    >
                      透视分析
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
