import React, { useState } from 'react';
import { InvariantCheckResult } from '../types/mbs';
import { Code2, ShieldCheck, Play, Terminal, CheckCircle2, AlertTriangle, FileCode } from 'lucide-react';

export const CodeEngineBrowser: React.FC = () => {
  const [activeCodeTab, setActiveCodeTab] = useState<'python' | 'rust' | 'sql' | 'invariants'>('invariants');
  const [invariants, setInvariants] = useState<InvariantCheckResult[]>([]);
  const [runningTests, setRunningTests] = useState<boolean>(false);

  const handleRunInvariants = async () => {
    setRunningTests(true);
    try {
      const res = await fetch('/api/invariants');
      const data = await res.json();
      setInvariants(data);
    } catch (err) {
      console.error(err);
    } finally {
      setRunningTests(false);
    }
  };

  const samplePythonCode = `'''
RHINOQUANT CHINA MBS - Financial Calculation Layer (Python Engine)
Decimal-based cashflow amortization & waterfall modeling.
'''
from decimal import Decimal, ROUND_HALF_UP

class MortgageCashflowEngine:
    def calculate_pmt(self, principal: Decimal, annual_rate: Decimal, months: int) -> Decimal:
        r = annual_rate / Decimal("12")
        one_plus_r_n = (Decimal("1") + r) ** months
        pmt = (principal * r * one_plus_r_n) / (one_plus_r_n - Decimal("1"))
        return pmt.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
`;

  const sampleRustCode = `// RHINOQUANT CHINA MBS - High Performance Rust Engine
// Parallel Monte Carlo & Pool Cashflow Matrix Calculations

pub fn simulate_pool(params: &PoolParams) -> Vec<MonthlyResult> {
    let mut results = Vec::with_capacity(params.wam as usize);
    let mut balance = params.initial_balance;
    let smm = 1.0 - (1.0 - params.cpr).powf(1.0 / 12.0);
    // ... parallel rayon SIMD execution ...
    results
}
`;

  const sampleSqlCode = `-- RHINOQUANT CHINA MBS - PostgreSQL Schema (PostgreSQL 16+)
-- Meets Section LXIV: 25+ Core Financial Tables & Versioned Data Structures

CREATE TABLE borrowers (
    borrower_id VARCHAR(64) PRIMARY KEY,
    name_hash VARCHAR(64) NOT NULL,
    monthly_income NUMERIC(15, 2) NOT NULL,
    debt_service_ratio NUMERIC(5, 4) NOT NULL,
    credit_score INT NOT NULL
);
`;

  return (
    <div className="space-y-4 p-4 font-mono text-slate-200 text-xs">
      {/* Code Browser & Runner Selector */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <FileCode className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-slate-100">底层系统代码工程与金融不变量校验系统</span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveCodeTab('invariants')}
            className={`px-3 py-1 rounded transition-colors ${
              activeCodeTab === 'invariants'
                ? 'bg-cyan-600 text-white font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            🛡️ 运行金融不变量校验 (9规则)
          </button>
          <button
            onClick={() => setActiveCodeTab('python')}
            className={`px-3 py-1 rounded transition-colors ${
              activeCodeTab === 'python'
                ? 'bg-cyan-600 text-white font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            🐍 Python 引擎源码
          </button>
          <button
            onClick={() => setActiveCodeTab('rust')}
            className={`px-3 py-1 rounded transition-colors ${
              activeCodeTab === 'rust'
                ? 'bg-cyan-600 text-white font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            🦀 Rust 高性能核心
          </button>
          <button
            onClick={() => setActiveCodeTab('sql')}
            className={`px-3 py-1 rounded transition-colors ${
              activeCodeTab === 'sql'
                ? 'bg-cyan-600 text-white font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            🗄️ PostgreSQL 数据库 Schema
          </button>
        </div>
      </div>

      {/* Financial Invariants Runner Tab */}
      {activeCodeTab === 'invariants' && (
        <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
            <div>
              <div className="font-bold text-slate-100 text-sm flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>RhinoQuant 机构级金融守恒与不变量自动校验套件</span>
              </div>
              <div className="text-slate-400 text-xs mt-0.5">
                实时验证: 资金守恒、复式记账平衡、久期凹性约束、NAV一致性
              </div>
            </div>

            <button
              onClick={handleRunInvariants}
              disabled={runningTests}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded transition-colors flex items-center space-x-1.5"
            >
              <Play className="w-3.5 h-3.5" />
              <span>{runningTests ? '校验推演中...' : '立即执行 9 项守恒测试'}</span>
            </button>
          </div>

          {invariants.length > 0 ? (
            <div className="space-y-2">
              {invariants.map((inv) => (
                <div
                  key={inv.rule_id}
                  className="p-3 bg-slate-950 rounded border border-slate-800 flex items-start justify-between"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2 font-bold text-slate-200">
                      <span className="text-cyan-400">{inv.rule_id}</span>
                      <span>{inv.name}</span>
                    </div>
                    <div className="text-slate-400 text-[11px]">{inv.details}</div>
                  </div>

                  <span
                    className={`px-2.5 py-1 rounded text-xs font-bold border shrink-0 ${
                      inv.status === 'PASSED'
                        ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                        : 'bg-rose-950 text-rose-400 border-rose-800'
                    }`}
                  >
                    {inv.status === 'PASSED' ? '✓ 测试通过 (PASSED)' : '✗ 测试失败 (FAILED)'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500 bg-slate-950 rounded border border-slate-800/80">
              点击上方按钮开始对当前合成市场、资产池、SPV与会计账本执行金融守恒逻辑校验。
            </div>
          )}
        </div>
      )}

      {/* Source Code Inspector Tabs */}
      {activeCodeTab !== 'invariants' && (
        <div className="bg-slate-950 border border-slate-800 rounded p-4">
          <div className="text-xs text-slate-400 mb-2 font-mono">
            源码路径:{' '}
            {activeCodeTab === 'python'
              ? 'python-engine/cashflows/engine.py'
              : activeCodeTab === 'rust'
              ? 'rust-core/src/cashflow.rs'
              : 'database/schema/mbs_schema.sql'}
          </div>
          <pre className="text-emerald-400 font-mono text-xs overflow-x-auto bg-slate-900 p-4 rounded border border-slate-800 leading-relaxed">
            {activeCodeTab === 'python'
              ? samplePythonCode
              : activeCodeTab === 'rust'
              ? sampleRustCode
              : sampleSqlCode}
          </pre>
        </div>
      )}
    </div>
  );
};
