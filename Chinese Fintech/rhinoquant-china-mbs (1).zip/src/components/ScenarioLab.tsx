import React, { useState } from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Sliders, Zap, ShieldAlert, TrendingDown, Cpu, Activity } from 'lucide-react';

export const ScenarioLab: React.FC = () => {
  const [activePreset, setActivePreset] = useState<string>('BASE');
  const [simulating, setSimulating] = useState<boolean>(false);
  const [monteCarloDone, setMonteCarloDone] = useState<boolean>(false);

  // Generate 100 sample Monte Carlo Price Path points for visualization
  const mcPaths = Array.from({ length: 50 }).map((_, idx) => ({
    step: `T+${idx}`,
    pathP5: 98.2 + Math.sin(idx * 0.2) * 0.5 - idx * 0.05,
    pathP50: 100.2 + Math.cos(idx * 0.15) * 0.3,
    pathP95: 102.1 + Math.sin(idx * 0.1) * 0.4 + idx * 0.03
  }));

  const presets = [
    { id: 'BASE', name: '基准情景 (Base)', rate: 0, priceDrop: 0, cpr: '1.0x', pd: '1.0x' },
    { id: 'RATE_SPIKE', name: '利率大涨 (+200bp)', rate: 200, priceDrop: 0, cpr: '0.4x', pd: '1.2x' },
    { id: 'PROPERTY_CRASH', name: '房价重挫 (-20%)', rate: -50, priceDrop: -20, cpr: '0.6x', pd: '3.5x' },
    { id: 'PREPAY_SURGE', name: '提前偿还浪潮 (+300% CPR)', rate: -150, priceDrop: 5, cpr: '3.0x', pd: '0.5x' },
    { id: 'BLACK_SWAN', name: '黑天鹅情景 (Double Shock)', rate: 250, priceDrop: -30, cpr: '0.3x', pd: '6.0x' }
  ];

  const handleRunMonteCarlo = () => {
    setSimulating(true);
    setTimeout(() => {
      setSimulating(false);
      setMonteCarloDone(true);
    }, 600);
  };

  return (
    <div className="space-y-4 p-4 font-mono text-slate-200">
      {/* Preset Scenario Cards */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-3">
        <div className="flex items-center space-x-2 font-bold text-xs text-cyan-400 border-b border-slate-800 pb-2">
          <Zap className="w-4 h-4" />
          <span>宏观情景预设实验室与压力测试 (Scenario Presets & Stress Test)</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-xs">
          {presets.map((p) => (
            <button
              key={p.id}
              onClick={() => setActivePreset(p.id)}
              className={`p-3 rounded border text-left transition-colors ${
                activePreset === p.id
                  ? 'bg-slate-800 border-cyan-500 text-slate-100'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="font-bold text-slate-200 mb-1">{p.name}</div>
              <div className="space-y-0.5 text-[11px] text-slate-400">
                <div>利率: <span className="text-cyan-400">{p.rate > 0 ? `+${p.rate}` : p.rate}bp</span></div>
                <div>房价: <span className="text-amber-400">{p.priceDrop}%</span></div>
                <div>违约率: <span className="text-rose-400">{p.pd}</span></div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Stress Test Metrics Results */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded">
          <div className="text-slate-400">优先 A1 级预计价格变动</div>
          <div className="text-2xl font-bold text-emerald-400 mt-1">
            {activePreset === 'RATE_SPIKE' ? '-1.85%' : activePreset === 'BLACK_SWAN' ? '-4.20%' : '+0.45%'}
          </div>
          <div className="text-slate-500 text-[11px] mt-1">净价变动至: {activePreset === 'RATE_SPIKE' ? '98.40' : '100.70'}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded">
          <div className="text-slate-400">次级/权益层 Expected Loss (预期损失)</div>
          <div className="text-2xl font-bold text-rose-400 mt-1">
            {activePreset === 'PROPERTY_CRASH' ? '12.4%' : activePreset === 'BLACK_SWAN' ? '28.5%' : '0.8%'}
          </div>
          <div className="text-slate-500 text-[11px] mt-1">优先级受 15% 损益缓冲区充分保护</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded">
          <div className="text-slate-400">组合 WAL 拓展/缩短 (Extension Risk)</div>
          <div className="text-2xl font-bold text-cyan-400 mt-1">
            {activePreset === 'RATE_SPIKE' ? '4.80 年 (+1.2y)' : activePreset === 'PREPAY_SURGE' ? '1.80 年 (-1.8y)' : '3.60 年'}
          </div>
          <div className="text-slate-500 text-[11px] mt-1">由于提前偿还率 CPR 随利率变动</div>
        </div>
      </div>

      {/* Monte Carlo 1,000 Path Simulation Area Chart */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-xs">
          <div className="flex items-center space-x-2 font-bold text-slate-200">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>1,000 次蒙特卡洛随机路径模拟 (Monte Carlo Price Path Fan Chart)</span>
          </div>

          <button
            onClick={handleRunMonteCarlo}
            disabled={simulating}
            className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded font-bold transition-colors flex items-center space-x-1.5"
          >
            <Activity className="w-3.5 h-3.5" />
            <span>{simulating ? '并发算力计算中...' : '运行 1,000 路径推演'}</span>
          </button>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={mcPaths} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="step" stroke="#94a3b8" tick={{ fontSize: 10 }} />
              <YAxis domain={['auto', 'auto']} stroke="#94a3b8" tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: 11 }} />
              <Area type="monotone" dataKey="pathP95" name="95th 分位数 (乐观)" stroke="#10b981" fill="#10b981" fillOpacity={0.15} />
              <Area type="monotone" dataKey="pathP50" name="50th 中位数" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.3} />
              <Area type="monotone" dataKey="pathP5" name="5th 分位数 (悲观)" stroke="#f43f5e" fill="#f43f5e" fillOpacity={0.2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
