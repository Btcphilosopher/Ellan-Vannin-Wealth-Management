-- RHINOQUANT CHINA MBS - Database Schema (PostgreSQL 16+)
-- Meets Section LXIV: 25+ Core Financial Tables & Versioned Data Structures

CREATE TABLE borrowers (
    borrower_id VARCHAR(64) PRIMARY KEY,
    name_hash VARCHAR(64) NOT NULL,
    age INT NOT NULL,
    monthly_income NUMERIC(15, 2) NOT NULL,
    debt_service_ratio NUMERIC(5, 4) NOT NULL,
    credit_score INT NOT NULL,
    credit_band VARCHAR(10) NOT NULL,
    employment_type VARCHAR(50) NOT NULL,
    region VARCHAR(50) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE properties (
    property_id VARCHAR(64) PRIMARY KEY,
    address_code VARCHAR(64) NOT NULL,
    region VARCHAR(50) NOT NULL,
    property_type VARCHAR(50) NOT NULL,
    occupancy_type VARCHAR(50) NOT NULL,
    origination_value NUMERIC(15, 2) NOT NULL,
    current_value NUMERIC(15, 2) NOT NULL,
    area_sqm NUMERIC(8, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE mortgage_loans (
    loan_id VARCHAR(64) PRIMARY KEY,
    borrower_id VARCHAR(64) REFERENCES borrowers(borrower_id),
    property_id VARCHAR(64) REFERENCES properties(property_id),
    origination_date DATE NOT NULL,
    original_balance NUMERIC(15, 2) NOT NULL,
    current_balance NUMERIC(15, 2) NOT NULL,
    interest_rate NUMERIC(6, 4) NOT NULL,
    loan_term INT NOT NULL,
    remaining_term INT NOT NULL,
    seasoning INT NOT NULL,
    payment_frequency VARCHAR(20) DEFAULT 'MONTHLY',
    amortisation_type VARCHAR(30) DEFAULT 'EQUAL_PAYMENT',
    monthly_pmt NUMERIC(15, 2) NOT NULL,
    loan_status VARCHAR(30) NOT NULL,
    property_value NUMERIC(15, 2) NOT NULL,
    loan_to_value NUMERIC(5, 4) NOT NULL,
    region VARCHAR(50) NOT NULL,
    credit_band VARCHAR(10) NOT NULL,
    version INT DEFAULT 1,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE loan_pools (
    pool_id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    originator VARCHAR(100) NOT NULL,
    loan_count INT NOT NULL,
    original_balance NUMERIC(18, 2) NOT NULL,
    current_balance NUMERIC(18, 2) NOT NULL,
    weighted_average_coupon NUMERIC(6, 4) NOT NULL,
    weighted_average_maturity INT NOT NULL,
    weighted_average_ltv NUMERIC(5, 4) NOT NULL,
    weighted_average_age INT NOT NULL,
    cpr_3m NUMERIC(5, 4) NOT NULL,
    default_rate_annual NUMERIC(5, 4) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE spvs (
    spv_id VARCHAR(64) PRIMARY KEY,
    spv_name VARCHAR(150) NOT NULL,
    trustee VARCHAR(100) NOT NULL,
    servicer VARCHAR(100) NOT NULL,
    pool_id VARCHAR(64) REFERENCES loan_pools(pool_id),
    total_asset_balance NUMERIC(18, 2) NOT NULL,
    total_securities_balance NUMERIC(18, 2) NOT NULL,
    overcollateralization NUMERIC(6, 4) NOT NULL,
    reserve_account_balance NUMERIC(15, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE securities (
    security_id VARCHAR(64) PRIMARY KEY,
    ticker VARCHAR(30) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    spv_id VARCHAR(64) REFERENCES spvs(spv_id),
    issue_date DATE NOT NULL,
    maturity_date DATE NOT NULL,
    total_issue_amount NUMERIC(18, 2) NOT NULL,
    current_total_balance NUMERIC(18, 2) NOT NULL,
    underlying_pool_id VARCHAR(64) REFERENCES loan_pools(pool_id)
);

CREATE TABLE tranches (
    tranche_id VARCHAR(64) PRIMARY KEY,
    security_id VARCHAR(64) REFERENCES securities(security_id),
    tranche_name VARCHAR(100) NOT NULL,
    priority INT NOT NULL,
    initial_balance NUMERIC(18, 2) NOT NULL,
    current_balance NUMERIC(18, 2) NOT NULL,
    coupon_rate NUMERIC(6, 4) NOT NULL,
    coupon_type VARCHAR(20) NOT NULL,
    benchmark VARCHAR(30) NOT NULL,
    spread_bp INT NOT NULL,
    seniority VARCHAR(20) NOT NULL,
    attachment_point NUMERIC(5, 4) NOT NULL,
    detachment_point NUMERIC(5, 4) NOT NULL,
    rating_agency_rating VARCHAR(10) NOT NULL,
    clean_price NUMERIC(8, 4) NOT NULL,
    dirty_price NUMERIC(8, 4) NOT NULL,
    ytm NUMERIC(6, 4) NOT NULL,
    wal NUMERIC(6, 2) NOT NULL,
    duration NUMERIC(6, 2) NOT NULL,
    convexity NUMERIC(6, 2) NOT NULL,
    dv01 NUMERIC(15, 2) NOT NULL,
    z_spread INT NOT NULL,
    oas INT NOT NULL
);

CREATE TABLE trades (
    trade_id VARCHAR(64) PRIMARY KEY,
    security_id VARCHAR(64) REFERENCES securities(security_id),
    tranche_id VARCHAR(64) REFERENCES tranches(tranche_id),
    side VARCHAR(10) NOT NULL,
    price NUMERIC(8, 4) NOT NULL,
    quantity NUMERIC(18, 2) NOT NULL,
    status VARCHAR(30) NOT NULL,
    counterparty VARCHAR(100) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE audit_events (
    event_id VARCHAR(64) PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    user_name VARCHAR(50) NOT NULL,
    action VARCHAR(100) NOT NULL,
    target_object VARCHAR(100) NOT NULL,
    old_value TEXT,
    new_value TEXT,
    model_version VARCHAR(30) NOT NULL
);
