"""
RHINOQUANT CHINA MBS - Financial Calculation Layer (Python 3.12+ Engine)
Decimal-based cashflow amortization and waterfall modeling.
"""

from decimal import Decimal, ROUND_HALF_UP
from typing import List, Dict, Any

class MortgageCashflowEngine:
    def __init__(self, currency_unit: str = "RMB"):
        self.currency_unit = currency_unit

    def calculate_pmt(self, principal: Decimal, annual_rate: Decimal, months: int) -> Decimal:
        """
        Equal Payment Amortization PMT calculation.
        PMT = P * r * (1+r)^n / ((1+r)^n - 1)
        """
        if months <= 0 or principal <= Decimal("0"):
            return Decimal("0.00")
        if annual_rate <= Decimal("0"):
            return (principal / Decimal(months)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        
        r = annual_rate / Decimal("12")
        one_plus_r_n = (Decimal("1") + r) ** months
        pmt = (principal * r * one_plus_r_n) / (one_plus_r_n - Decimal("1"))
        return pmt.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    def cpr_to_smm(self, cpr: float) -> float:
        """SMM = 1 - (1 - CPR)^(1/12)"""
        if cpr <= 0.0:
            return 0.0
        return 1.0 - ((1.0 - cpr) ** (1.0 / 12.0))

    def run_monthly_amortization(
        self,
        principal: Decimal,
        annual_rate: Decimal,
        wam: int,
        cpr: float = 0.08,
        pd_annual: float = 0.005,
        lgd: float = 0.25
    ) -> List[Dict[str, Any]]:
        cashflows = []
        curr_bal = principal
        smm = self.cpr_to_smm(cpr)
        monthly_pd = 1.0 - ((1.0 - pd_annual) ** (1.0 / 12.0))

        for month in range(1, wam + 1):
            if curr_bal <= Decimal("0.01"):
                break
            
            monthly_rate = annual_rate / Decimal("12")
            scheduled_pmt = self.calculate_pmt(curr_bal, annual_rate, wam - month + 1)
            sched_interest = (curr_bal * monthly_rate).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            sched_principal = min(curr_bal, max(Decimal("0.00"), scheduled_pmt - sched_interest))

            bal_after_sched = curr_bal - sched_principal
            prepay_amt = (bal_after_sched * Decimal(str(smm))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            
            bal_after_prepay = bal_after_sched - prepay_amt
            default_bal = (bal_after_prepay * Decimal(str(monthly_pd))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

            recovery_amt = (default_bal * Decimal(str(1.0 - lgd))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            loss_amt = default_bal - recovery_amt

            ending_bal = max(Decimal("0.00"), bal_after_prepay - default_bal)
            total_cash = sched_principal + sched_interest + prepay_amt + recovery_amt

            cashflows.append({
                "month": month,
                "beginning_balance": float(curr_bal),
                "scheduled_principal": float(sched_principal),
                "scheduled_interest": float(sched_interest),
                "prepayment": float(prepay_amt),
                "default": float(default_bal),
                "recovery": float(recovery_amt),
                "loss": float(loss_amt),
                "total_cash": float(total_cash),
                "ending_balance": float(ending_bal)
            })

            curr_bal = ending_bal

        return cashflows
