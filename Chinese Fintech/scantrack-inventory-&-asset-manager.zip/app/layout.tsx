import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'ScanTrack | Real-Time Inventory & Asset Tracking',
  description: 'Real-time inventory management dashboard with live database sync, barcode & QR scanner, asset tracking, stock analytics, and audit logging.',
  openGraph: {
    title: 'ScanTrack | Real-Time Inventory & Asset Tracking',
    description: 'Real-time inventory management dashboard with live database sync, barcode & QR scanner, asset tracking, stock analytics, and audit logging.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ScanTrack | Real-Time Inventory & Asset Tracking',
    description: 'Real-time inventory management dashboard with live database sync, barcode & QR scanner, asset tracking, stock analytics, and audit logging.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
