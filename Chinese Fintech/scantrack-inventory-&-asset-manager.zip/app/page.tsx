'use client';

import React, { useState, useEffect } from 'react';
import { InventoryProvider, useInventory } from '@/context/InventoryContext';
import { Navbar } from '@/components/Navbar';
import { InventoryOverview } from '@/components/InventoryOverview';
import { InventoryCatalog } from '@/components/InventoryCatalog';
import { AuditLogsView } from '@/components/AuditLogsView';
import { BarcodeScannerModal } from '@/components/BarcodeScannerModal';
import { ItemFormModal } from '@/components/ItemFormModal';
import { StockMovementModal } from '@/components/StockMovementModal';
import { AssetTagModal } from '@/components/AssetTagModal';
import { AssetDetailModal } from '@/components/AssetDetailModal';
import { UserSwitcherModal } from '@/components/UserSwitcherModal';
import { InventoryItem } from '@/types/inventory';
import { 
  Camera, 
  RotateCcw, 
  Download, 
  Upload, 
  ShieldCheck, 
  Layers, 
  Check, 
  Sparkles,
  Barcode
} from 'lucide-react';

function DashboardContent() {
  const { items, resetToDefault, exportJson, importJson, lastSyncTime } = useInventory();

  const [activeTab, setActiveTab] = useState<'overview' | 'catalog' | 'audit'>('overview');
  
  // Modals state
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isItemFormOpen, setIsItemFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  
  const [detailItem, setDetailItem] = useState<InventoryItem | null>(null);
  const [movementItem, setMovementItem] = useState<InventoryItem | null>(null);
  const [movementType, setMovementType] = useState<'in' | 'out' | 'adjust'>('in');
  
  const [printTagItem, setPrintTagItem] = useState<InventoryItem | null>(null);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);

  // Global hotkeys (Press 'S' or 'B' to quick-open scanner)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // If user is typing in an input or textarea, ignore
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }

      if (e.key.toLowerCase() === 'b' || e.key.toLowerCase() === 's') {
        e.preventDefault();
        setIsScannerOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleOpenEdit = (item: InventoryItem) => {
    setEditingItem(item);
    setIsItemFormOpen(true);
  };

  const handleOpenMovement = (item: InventoryItem, type: 'in' | 'out' | 'adjust' = 'in') => {
    setMovementItem(item);
    setMovementType(type);
  };

  const handleImportJsonFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = importJson(content);
        if (!success) {
          alert('Invalid JSON inventory backup file structure.');
        }
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-neutral-100/70 text-neutral-900 flex flex-col font-sans antialiased">
      {/* Top Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenScanner={() => setIsScannerOpen(true)}
        onOpenUserModal={() => setIsUserModalOpen(true)}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'overview' && (
          <InventoryOverview
            onOpenScanner={() => setIsScannerOpen(true)}
            onOpenCreateModal={() => {
              setEditingItem(null);
              setIsItemFormOpen(true);
            }}
            onSelectItem={(item) => setDetailItem(item)}
            onNavigateToCatalog={() => setActiveTab('catalog')}
          />
        )}

        {activeTab === 'catalog' && (
          <InventoryCatalog
            onSelectItem={(item) => setDetailItem(item)}
            onEditItem={handleOpenEdit}
            onOpenMovement={handleOpenMovement}
            onPrintTag={(item) => setPrintTagItem(item)}
            onOpenCreate={() => {
              setEditingItem(null);
              setIsItemFormOpen(true);
            }}
          />
        )}

        {activeTab === 'audit' && <AuditLogsView />}
      </main>

      {/* Footer */}
      <footer className="mt-auto bg-white border-t border-neutral-200 py-6 text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>
              Real-time synchronization active • {items.length} assets tracked • Last synced:{' '}
              {lastSyncTime.toLocaleTimeString()}
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => resetToDefault()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-neutral-200 hover:bg-neutral-50 hover:text-neutral-900 transition-colors"
              title="Reset catalog back to initial demo dataset"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Demo Catalog
            </button>

            <button
              onClick={exportJson}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-neutral-200 hover:bg-neutral-50 hover:text-neutral-900 transition-colors"
              title="Download full JSON database dump"
            >
              <Download className="w-3.5 h-3.5" />
              Backup JSON
            </button>

            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-neutral-200 hover:bg-neutral-50 hover:text-neutral-900 cursor-pointer transition-colors">
              <Upload className="w-3.5 h-3.5" />
              Restore JSON
              <input
                type="file"
                accept=".json"
                onChange={handleImportJsonFile}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </footer>

      {/* Floating Action Button for Mobile Scanner */}
      <button
        onClick={() => setIsScannerOpen(true)}
        className="fixed bottom-6 right-6 md:hidden z-30 p-4 rounded-full bg-teal-600 hover:bg-teal-700 text-white shadow-xl flex items-center justify-center transition-transform active:scale-95"
        aria-label="Scan barcode"
      >
        <Camera className="w-6 h-6" />
      </button>

      {/* Barcode Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onItemSelect={(item) => {
          setDetailItem(item);
        }}
      />

      {/* Create / Edit Item Modal */}
      <ItemFormModal
        isOpen={isItemFormOpen}
        onClose={() => {
          setIsItemFormOpen(false);
          setEditingItem(null);
        }}
        initialItem={editingItem}
      />

      {/* Stock Movement In/Out/Adjust Modal */}
      <StockMovementModal
        item={movementItem}
        isOpen={!!movementItem}
        onClose={() => setMovementItem(null)}
        defaultType={movementType}
      />

      {/* Printable Barcode Label Modal */}
      <AssetTagModal
        item={printTagItem}
        isOpen={!!printTagItem}
        onClose={() => setPrintTagItem(null)}
      />

      {/* Asset Detail Drawer / Modal */}
      <AssetDetailModal
        item={detailItem}
        isOpen={!!detailItem}
        onClose={() => setDetailItem(null)}
        onEdit={handleOpenEdit}
        onMovement={handleOpenMovement}
        onPrintTag={(item) => setPrintTagItem(item)}
      />

      {/* User Authentication Switcher */}
      <UserSwitcherModal
        isOpen={isUserModalOpen}
        onClose={() => setIsUserModalOpen(false)}
      />
    </div>
  );
}

export default function Page() {
  return (
    <InventoryProvider>
      <DashboardContent />
    </InventoryProvider>
  );
}
