export type StockStatus = 'in_stock' | 'low_stock' | 'out_of_stock' | 'reserved';

export interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  barcode: string; // Barcode number / UPC / EAN-13
  category: string;
  quantity: number;
  minStockThreshold: number;
  costPrice: number;
  sellingPrice: number;
  location: string; // e.g. Aisle A-02, Shelf 3
  status: StockStatus;
  batchNumber: string;
  expiryDate?: string;
  imageUrl?: string;
  supplier?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type AuditAction = 
  | 'stock_in' 
  | 'stock_out' 
  | 'adjust' 
  | 'created' 
  | 'updated' 
  | 'deleted' 
  | 'scanned';

export interface AuditLog {
  id: string;
  itemId: string;
  itemName: string;
  sku: string;
  barcode: string;
  action: AuditAction;
  quantityChanged: number;
  previousQty: number;
  newQty: number;
  userId: string;
  userName: string;
  userRole: string;
  reason: string;
  timestamp: string;
}

export type UserRole = 'admin' | 'inventory_manager' | 'warehouse_scanner' | 'auditor';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  department: string;
}

export type ScanAction = 'view' | 'stock_in_one' | 'stock_out_one' | 'custom_adjust';
