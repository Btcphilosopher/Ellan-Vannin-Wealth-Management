'use client';

import React, { useState, useEffect } from 'react';
import { InventoryItem } from '@/types/inventory';
import { useInventory } from '@/context/InventoryContext';
import { CATEGORIES } from '@/lib/mockData';
import { X, Sparkles, Package, Barcode, DollarSign, MapPin, Layers, Save } from 'lucide-react';

interface ItemFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialItem?: InventoryItem | null;
}

export function ItemFormModal({ isOpen, onClose, initialItem }: ItemFormModalProps) {
  const { addItem, updateItem } = useInventory();

  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [barcode, setBarcode] = useState('');
  const [category, setCategory] = useState('Skincare');
  const [quantity, setQuantity] = useState(10);
  const [minStockThreshold, setMinStockThreshold] = useState(15);
  const [costPrice, setCostPrice] = useState(25);
  const [sellingPrice, setSellingPrice] = useState(79);
  const [location, setLocation] = useState('Aisle A-01 • Shelf 01');
  const [batchNumber, setBatchNumber] = useState('LOT-2026-');
  const [expiryDate, setExpiryDate] = useState('2028-12-31');
  const [supplier, setSupplier] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const generateRandomSku = () => {
    const prefixes = ['WAT-SKN', 'WAT-COS', 'WAT-BDY', 'WAT-HLT', 'WAT-HAR'];
    const randPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const randNum = Math.floor(1000 + Math.random() * 9000);
    setSku(`${randPrefix}-${randNum}`);
  };

  const generateRandomBarcode = () => {
    // 12-digit standard UPC format
    let code = '69';
    for (let i = 0; i < 10; i++) {
      code += Math.floor(Math.random() * 10).toString();
    }
    setBarcode(code);
  };

  useEffect(() => {
    if (initialItem) {
      setName(initialItem.name);
      setSku(initialItem.sku);
      setBarcode(initialItem.barcode);
      setCategory(initialItem.category);
      setQuantity(initialItem.quantity);
      setMinStockThreshold(initialItem.minStockThreshold);
      setCostPrice(initialItem.costPrice);
      setSellingPrice(initialItem.sellingPrice);
      setLocation(initialItem.location);
      setBatchNumber(initialItem.batchNumber || '');
      setExpiryDate(initialItem.expiryDate || '');
      setSupplier(initialItem.supplier || '');
      setImageUrl(initialItem.imageUrl || '');
      setNotes(initialItem.notes || '');
    } else {
      // Default new item values
      setName('');
      generateRandomSku();
      generateRandomBarcode();
      setCategory('Skincare');
      setQuantity(25);
      setMinStockThreshold(10);
      setCostPrice(30);
      setSellingPrice(89);
      setLocation('Aisle A-02 • Shelf 03');
      setBatchNumber(`LOT-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`);
      setExpiryDate('2028-12-31');
      setSupplier('Apex BioCosmetics Ltd');
      setImageUrl('https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400&auto=format&fit=crop&q=80');
      setNotes('');
    }
    setErrors({});
  }, [initialItem, isOpen]);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = 'Asset item name is required';
    if (!sku.trim()) errs.sku = 'SKU identifier is required';
    if (!barcode.trim()) errs.barcode = 'Barcode number is required';
    if (quantity < 0) errs.quantity = 'Quantity cannot be negative';
    if (minStockThreshold < 0) errs.minStockThreshold = 'Threshold cannot be negative';
    if (costPrice < 0) errs.costPrice = 'Cost price cannot be negative';
    if (sellingPrice < 0) errs.sellingPrice = 'Selling price cannot be negative';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    if (initialItem) {
      updateItem(initialItem.id, {
        name,
        sku,
        barcode,
        category,
        quantity,
        minStockThreshold,
        costPrice,
        sellingPrice,
        location,
        batchNumber,
        expiryDate,
        supplier,
        imageUrl,
        notes,
      });
    } else {
      addItem({
        name,
        sku,
        barcode,
        category,
        quantity,
        minStockThreshold,
        costPrice,
        sellingPrice,
        location,
        batchNumber,
        expiryDate,
        supplier,
        imageUrl,
        notes,
      });
    }

    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 bg-linear-to-r from-teal-900 to-teal-800 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-500/20 rounded-lg text-teal-300 ring-1 ring-teal-400/30">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">
                {initialItem ? 'Edit Asset Catalog Item' : 'Register New Inventory Asset'}
              </h3>
              <p className="text-xs text-teal-200/80">Configure SKU, barcode, stock levels, and warehouse location</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-teal-200 hover:text-white hover:bg-teal-700/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
          {/* Item Name */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              Item Name & Description <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Luminous Hydrating Serum 50ml"
              className={`w-full px-3 py-2 text-sm bg-neutral-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white ${
                errors.name ? 'border-red-500' : 'border-neutral-300'
              }`}
            />
            {errors.name && <p className="text-red-500 text-[11px] mt-1">{errors.name}</p>}
          </div>

          {/* SKU & Barcode Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-neutral-700">
                  SKU Identifier <span className="text-red-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={generateRandomSku}
                  className="text-[11px] text-teal-600 hover:text-teal-700 font-semibold flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" /> Auto Gen
                </button>
              </div>
              <div className="relative">
                <Layers className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={sku}
                  onChange={(e) => setSku(e.target.value)}
                  placeholder="WAT-SKN-0101"
                  className={`w-full pl-9 pr-3 py-2 text-sm font-mono bg-neutral-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white ${
                    errors.sku ? 'border-red-500' : 'border-neutral-300'
                  }`}
                />
              </div>
              {errors.sku && <p className="text-red-500 text-[11px] mt-1">{errors.sku}</p>}
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-neutral-700">
                  Barcode / UPC / EAN <span className="text-red-500">*</span>
                </label>
                <button
                  type="button"
                  onClick={generateRandomBarcode}
                  className="text-[11px] text-teal-600 hover:text-teal-700 font-semibold flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" /> Auto UPC
                </button>
              </div>
              <div className="relative">
                <Barcode className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  placeholder="690123456701"
                  className={`w-full pl-9 pr-3 py-2 text-sm font-mono bg-neutral-50 border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white ${
                    errors.barcode ? 'border-red-500' : 'border-neutral-300'
                  }`}
                />
              </div>
              {errors.barcode && <p className="text-red-500 text-[11px] mt-1">{errors.barcode}</p>}
            </div>
          </div>

          {/* Category & Location */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
              >
                {CATEGORIES.filter((c) => c !== 'All Categories').map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">Warehouse Location</label>
              <div className="relative">
                <MapPin className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="Aisle A-01 • Shelf 02"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
                />
              </div>
            </div>
          </div>

          {/* Quantity & Threshold */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3 bg-neutral-50 rounded-xl border border-neutral-200">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">Current Stock Quantity</label>
              <input
                type="number"
                min="0"
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 text-sm font-bold text-neutral-900 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
              <p className="text-[11px] text-neutral-500 mt-0.5">Physical count in inventory</p>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">Min. Stock Alert Threshold</label>
              <input
                type="number"
                min="1"
                value={minStockThreshold}
                onChange={(e) => setMinStockThreshold(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 text-sm font-bold text-neutral-900 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
              <p className="text-[11px] text-neutral-500 mt-0.5">Triggers &quot;Low Stock&quot; warning badge</p>
            </div>
          </div>

          {/* Pricing Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">Cost Price (¥)</label>
              <div className="relative">
                <DollarSign className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={costPrice}
                  onChange={(e) => setCostPrice(parseFloat(e.target.value) || 0)}
                  className="w-full pl-9 pr-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">Selling Retail Price (¥)</label>
              <div className="relative">
                <DollarSign className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={sellingPrice}
                  onChange={(e) => setSellingPrice(parseFloat(e.target.value) || 0)}
                  className="w-full pl-9 pr-3 py-2 text-sm font-semibold bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
                />
              </div>
            </div>
          </div>

          {/* Lot & Expiry & Supplier */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">Lot / Batch Number</label>
              <input
                type="text"
                value={batchNumber}
                onChange={(e) => setBatchNumber(e.target.value)}
                placeholder="LOT-2026-X1"
                className="w-full px-3 py-2 text-sm font-mono bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
              />
            </div>
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">Expiry Date</label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
              />
            </div>
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">Supplier</label>
              <input
                type="text"
                value={supplier}
                onChange={(e) => setSupplier(e.target.value)}
                placeholder="Apex BioCosmetics"
                className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
              />
            </div>
          </div>

          {/* Image URL & Notes */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">Product Photo URL</label>
            <input
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="https://images.unsplash.com/photo-..."
              className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-neutral-700 mb-1">Internal Asset Notes / Handling</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Temperature requirements, fragile packaging, security shelf notes..."
              className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
            />
          </div>

          {/* Submit Actions */}
          <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg text-sm font-medium hover:bg-neutral-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors"
            >
              <Save className="w-4 h-4" />
              {initialItem ? 'Update Asset' : 'Save New Asset'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
