'use client';

import React from 'react';
import { useInventory } from '@/context/InventoryContext';
import { 
  Package, 
  AlertTriangle, 
  XCircle, 
  DollarSign, 
  TrendingUp, 
  Camera, 
  Plus, 
  FileSpreadsheet, 
  ArrowUpRight,
  ShieldCheck,
  CheckCircle,
  Clock,
  Sparkles
} from 'lucide-react';
import { InventoryItem } from '@/types/inventory';

interface InventoryOverviewProps {
  onOpenScanner: () => void;
  onOpenCreateModal: () => void;
  onSelectItem: (item: InventoryItem) => void;
  onNavigateToCatalog: () => void;
}

export function InventoryOverview({
  onOpenScanner,
  onOpenCreateModal,
  onSelectItem,
  onNavigateToCatalog,
}: InventoryOverviewProps) {
  const { items, auditLogs, exportCsv } = useInventory();

  // Metrics computation
  const totalUnits = items.reduce((acc, i) => acc + i.quantity, 0);
  const totalRetailValue = items.reduce((acc, i) => acc + i.quantity * i.sellingPrice, 0);
  const totalCostValue = items.reduce((acc, i) => acc + i.quantity * i.costPrice, 0);
  const potentialProfit = totalRetailValue - totalCostValue;

  const lowStockItems = items.filter((i) => i.quantity > 0 && i.quantity <= i.minStockThreshold);
  const outOfStockItems = items.filter((i) => i.quantity === 0);
  const healthyItems = items.filter((i) => i.quantity > i.minStockThreshold);

  const healthScore = items.length > 0 ? Math.round((healthyItems.length / items.length) * 100) : 100;

  // Category breakdown
  const categoryStats = items.reduce((acc: Record<string, { count: number; units: number }>, item) => {
    if (!acc[item.category]) {
      acc[item.category] = { count: 0, units: 0 };
    }
    acc[item.category].count += 1;
    acc[item.category].units += item.quantity;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {/* Hero Welcome / Action Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-linear-to-r from-teal-900 via-teal-800 to-emerald-900 text-white p-6 sm:p-8 shadow-lg">
        {/* Decorative background grid and glow */}
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-teal-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/30 text-teal-200 text-xs font-semibold mb-3 border border-teal-400/30">
              <Sparkles className="w-3.5 h-3.5 text-teal-300" />
              <span>Real-Time Barcode & Asset Tracking</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Warehouse & Store Inventory Control
            </h2>
            <p className="text-sm text-teal-100/90 mt-2 leading-relaxed">
              Track physical retail beauty & wellness assets, scan UPC/EAN barcodes via camera or laser scanner, monitor stock depletion, and synchronize audits across devices.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={onOpenScanner}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-white hover:bg-neutral-100 text-teal-950 font-bold rounded-xl text-sm shadow-md transition-all transform hover:-translate-y-0.5"
            >
              <Camera className="w-4 h-4 text-teal-700" />
              Scan Barcode
            </button>
            <button
              onClick={onOpenCreateModal}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-teal-600/90 hover:bg-teal-500 text-white font-semibold rounded-xl text-sm border border-teal-400/40 shadow-sm transition-all"
            >
              <Plus className="w-4 h-4" />
              Add Asset
            </button>
            <button
              onClick={exportCsv}
              className="inline-flex items-center gap-2 px-3.5 py-2.5 bg-neutral-900/60 hover:bg-neutral-900 text-teal-100 font-medium rounded-xl text-sm border border-teal-500/30 transition-all"
            >
              <FileSpreadsheet className="w-4 h-4" />
              Export CSV
            </button>
          </div>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="p-5 bg-white rounded-xl border border-neutral-200 shadow-xs hover:border-neutral-300 transition-all">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Retail Valuation</span>
            <div className="p-2 rounded-lg bg-teal-50 text-teal-700">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-neutral-900">
            ¥{totalRetailValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-neutral-500">
            <span className="text-emerald-600 font-bold">¥{potentialProfit.toFixed(0)}</span>
            <span>est. gross margin</span>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="p-5 bg-white rounded-xl border border-neutral-200 shadow-xs hover:border-neutral-300 transition-all">
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Physical Stock Count</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-700">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-neutral-900">
            {totalUnits.toLocaleString()}{' '}
            <span className="text-sm font-medium text-neutral-500">units</span>
          </p>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-neutral-500">
            <span className="font-semibold text-neutral-800">{items.length}</span>
            <span>registered SKUs cataloged</span>
          </div>
        </div>

        {/* Metric 3 */}
        <div className={`p-5 rounded-xl border shadow-xs transition-all ${
          lowStockItems.length > 0
            ? 'bg-amber-50/50 border-amber-200'
            : 'bg-white border-neutral-200'
        }`}>
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-900">
              Low Stock Warnings
            </span>
            <div className="p-2 rounded-lg bg-amber-100 text-amber-700">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-950">
            {lowStockItems.length}{' '}
            <span className="text-sm font-medium text-amber-800">SKUs</span>
          </p>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-amber-800 font-medium">
            <span>Requires replenishment</span>
          </div>
        </div>

        {/* Metric 4 */}
        <div className={`p-5 rounded-xl border shadow-xs transition-all ${
          outOfStockItems.length > 0
            ? 'bg-rose-50/50 border-rose-200'
            : 'bg-white border-neutral-200'
        }`}>
          <div className="flex items-center justify-between text-neutral-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-900">
              Stockout Items
            </span>
            <div className="p-2 rounded-lg bg-rose-100 text-rose-700">
              <XCircle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-rose-950">
            {outOfStockItems.length}{' '}
            <span className="text-sm font-medium text-rose-800">SKUs</span>
          </p>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-rose-700 font-medium">
            <span>Zero inventory balance</span>
          </div>
        </div>
      </div>

      {/* Grid: Stock Alerts & Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Urgent Attention / Action Needed List */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-neutral-200 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-neutral-900 text-base">Restock & Depletion Alerts</h3>
              <p className="text-xs text-neutral-500">Items below minimum safety threshold</p>
            </div>
            <button
              onClick={onNavigateToCatalog}
              className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1"
            >
              View Full Catalog <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {[...outOfStockItems, ...lowStockItems].length === 0 ? (
              <div className="p-8 text-center bg-emerald-50/50 rounded-xl border border-emerald-100 text-emerald-800">
                <CheckCircle className="w-8 h-8 mx-auto mb-2 text-emerald-600" />
                <p className="font-bold text-sm">All Stock Levels Healthy!</p>
                <p className="text-xs text-emerald-600 mt-0.5">
                  No assets are currently below their minimum threshold.
                </p>
              </div>
            ) : (
              [...outOfStockItems, ...lowStockItems].map((item) => (
                <div
                  key={item.id}
                  onClick={() => onSelectItem(item)}
                  className="flex items-center justify-between p-3.5 rounded-xl border border-neutral-200 hover:border-teal-300 hover:bg-neutral-50/80 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-neutral-100 overflow-hidden shrink-0 border border-neutral-200 flex items-center justify-center">
                      {item.imageUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                      ) : (
                        <Package className="w-5 h-5 text-neutral-400" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-neutral-900 group-hover:text-teal-700 transition-colors">
                          {item.name}
                        </span>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-neutral-100 text-neutral-600">
                          {item.sku}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-500 mt-0.5">
                        Location: {item.location} • Min: {item.minStockThreshold}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[11px] font-extrabold ${
                          item.quantity === 0
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {item.quantity === 0 ? 'Out of Stock' : `${item.quantity} in stock`}
                      </span>
                      <p className="text-[10px] text-neutral-400 mt-0.5">
                        UPC: {item.barcode}
                      </p>
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-neutral-400 group-hover:text-teal-600 transition-transform group-hover:translate-x-0.5" />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Category Breakdown & Warehouse Health */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-xs">
            <h3 className="font-bold text-neutral-900 text-sm mb-1">Catalog Health Index</h3>
            <p className="text-xs text-neutral-500 mb-4">Stock buffer & inventory availability</p>

            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-neutral-700">Operational Readiness</span>
              <span className="text-sm font-black text-teal-700">{healthScore}%</span>
            </div>
            <div className="w-full bg-neutral-100 rounded-full h-3 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  healthScore >= 80 ? 'bg-teal-600' : healthScore >= 50 ? 'bg-amber-500' : 'bg-rose-500'
                }`}
                style={{ width: `${healthScore}%` }}
              />
            </div>

            <div className="mt-4 pt-4 border-t border-neutral-100 space-y-2 text-xs">
              <div className="flex justify-between text-neutral-600">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-teal-500" /> Healthy stock ({healthyItems.length})
                </span>
                <span className="font-semibold">{Math.round((healthyItems.length / (items.length || 1)) * 100)}%</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500" /> Low stock alert ({lowStockItems.length})
                </span>
                <span className="font-semibold">{Math.round((lowStockItems.length / (items.length || 1)) * 100)}%</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500" /> Out of stock ({outOfStockItems.length})
                </span>
                <span className="font-semibold">{Math.round((outOfStockItems.length / (items.length || 1)) * 100)}%</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-neutral-200 p-5 shadow-xs">
            <h3 className="font-bold text-neutral-900 text-sm mb-3">Units By Category</h3>
            <div className="space-y-3">
              {Object.entries(categoryStats).map(([cat, stat]) => {
                const pct = totalUnits > 0 ? Math.round((stat.units / totalUnits) * 100) : 0;
                return (
                  <div key={cat} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-neutral-800">{cat}</span>
                      <span className="font-bold text-neutral-600">{stat.units} units ({pct}%)</span>
                    </div>
                    <div className="w-full bg-neutral-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="h-full bg-teal-700 rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
