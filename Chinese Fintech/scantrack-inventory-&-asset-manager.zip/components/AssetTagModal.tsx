'use client';

import React, { useRef } from 'react';
import { InventoryItem } from '@/types/inventory';
import { BarcodeGenerator } from './BarcodeGenerator';
import { X, Printer, Download, MapPin, Tag, Calendar, Layers } from 'lucide-react';

interface AssetTagModalProps {
  item: InventoryItem | null;
  isOpen: boolean;
  onClose: () => void;
}

export function AssetTagModal({ item, isOpen, onClose }: AssetTagModalProps) {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !item) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 bg-neutral-900 text-white">
          <div className="flex items-center gap-2.5">
            <Tag className="w-5 h-5 text-teal-400" />
            <div>
              <h3 className="font-bold text-base">Print Asset & Barcode Tag</h3>
              <p className="text-xs text-neutral-400">Standard 4x2 inch thermal / shelf label format</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Label Preview */}
        <div className="p-6 bg-neutral-100 flex flex-col items-center">
          <div
            ref={printRef}
            className="w-full max-w-md bg-white p-5 rounded-xl border-2 border-neutral-800 shadow-md flex flex-col justify-between print:m-0 print:border-none print:shadow-none"
          >
            {/* Top row */}
            <div className="flex items-start justify-between border-b border-dashed border-neutral-300 pb-3 mb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                  {item.category}
                </span>
                <h4 className="font-bold text-neutral-900 text-base leading-tight mt-1.5 line-clamp-2">
                  {item.name}
                </h4>
              </div>
              <div className="text-right shrink-0 ml-3">
                <span className="text-xs text-neutral-500 font-medium">Retail Price</span>
                <p className="font-extrabold text-lg text-neutral-900 leading-tight">
                  ¥{item.sellingPrice.toFixed(2)}
                </p>
              </div>
            </div>

            {/* Central Barcode */}
            <div className="flex flex-col items-center justify-center py-2 my-1 bg-neutral-50/50 rounded-lg p-3">
              <BarcodeGenerator
                value={item.barcode}
                width={240}
                height={55}
                showText={true}
                className="bg-transparent border-none shadow-none"
              />
            </div>

            {/* Bottom details metadata */}
            <div className="grid grid-cols-2 gap-2 text-[11px] pt-3 border-t border-dashed border-neutral-300 text-neutral-600">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                <span className="truncate"><strong>Loc:</strong> {item.location}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                <span className="truncate"><strong>SKU:</strong> {item.sku}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                <span className="truncate"><strong>Lot:</strong> {item.batchNumber}</span>
              </div>
              {item.expiryDate && (
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                  <span className="truncate"><strong>Exp:</strong> {item.expiryDate}</span>
                </div>
              )}
            </div>
          </div>

          <p className="text-[11px] text-neutral-500 mt-3 text-center">
            Standard barcode label ready for laser scanner guns, mobile cameras, and inventory audits.
          </p>
        </div>

        {/* Modal Actions */}
        <div className="px-6 py-4 bg-white border-t border-neutral-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg text-sm font-medium hover:bg-neutral-50 transition-colors"
          >
            Close
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              Print Label Tag
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
