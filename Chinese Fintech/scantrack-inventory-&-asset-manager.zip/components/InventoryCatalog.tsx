'use client';

import React, { useState, useMemo } from 'react';
import { InventoryItem } from '@/types/inventory';
import { useInventory } from '@/context/InventoryContext';
import { CATEGORIES } from '@/lib/mockData';
import { BarcodeGenerator } from './BarcodeGenerator';
import { 
  Search, 
  Filter, 
  Plus, 
  Minus, 
  Printer, 
  Edit3, 
  Trash2, 
  LayoutGrid, 
  List, 
  ArrowUpDown, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  MapPin, 
  Barcode as BarcodeIcon,
  Layers,
  ArrowRightLeft,
  Sparkles
} from 'lucide-react';

interface InventoryCatalogProps {
  onSelectItem: (item: InventoryItem) => void;
  onEditItem: (item: InventoryItem) => void;
  onOpenMovement: (item: InventoryItem, type: 'in' | 'out' | 'adjust') => void;
  onPrintTag: (item: InventoryItem) => void;
  onOpenCreate: () => void;
}

export function InventoryCatalog({
  onSelectItem,
  onEditItem,
  onOpenMovement,
  onPrintTag,
  onOpenCreate,
}: InventoryCatalogProps) {
  const { items, deleteItem, adjustStock } = useInventory();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'quantity' | 'price' | 'location'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [itemToDelete, setItemToDelete] = useState<InventoryItem | null>(null);

  // Filter and sort items
  const filteredItems = useMemo(() => {
    return items
      .filter((item) => {
        const matchesSearch =
          item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.barcode.includes(searchTerm) ||
          item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.batchNumber.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesCategory =
          selectedCategory === 'All Categories' || item.category === selectedCategory;

        const matchesStatus =
          selectedStatus === 'all' ||
          (selectedStatus === 'in_stock' && item.quantity > item.minStockThreshold) ||
          (selectedStatus === 'low_stock' && item.quantity > 0 && item.quantity <= item.minStockThreshold) ||
          (selectedStatus === 'out_of_stock' && item.quantity === 0);

        return matchesSearch && matchesCategory && matchesStatus;
      })
      .sort((a, b) => {
        let valA: string | number;
        let valB: string | number;
        if (sortBy === 'price') {
          valA = a.sellingPrice;
          valB = b.sellingPrice;
        } else {
          valA = a[sortBy];
          valB = b[sortBy];
        }
        if (typeof valA === 'string' && typeof valB === 'string') {
          return sortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
        }
        if (typeof valA === 'number' && typeof valB === 'number') {
          return sortOrder === 'asc' ? valA - valB : valB - valA;
        }
        return 0;
      });
  }, [items, searchTerm, selectedCategory, selectedStatus, sortBy, sortOrder]);

  const toggleSort = (field: 'name' | 'quantity' | 'price' | 'location') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  const getStatusBadge = (item: InventoryItem) => {
    if (item.quantity === 0) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
          <XCircle className="w-3 h-3" /> Out of Stock
        </span>
      );
    }
    if (item.quantity <= item.minStockThreshold) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
          <AlertTriangle className="w-3 h-3" /> Low Stock ({item.quantity})
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
        <CheckCircle2 className="w-3 h-3" /> In Stock ({item.quantity})
      </span>
    );
  };

  return (
    <div className="space-y-4">
      {/* Controls Bar */}
      <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search by name, SKU, barcode, location, or batch lot..."
              className="w-full pl-9 pr-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-neutral-400 hover:text-neutral-600"
              >
                Clear
              </button>
            )}
          </div>

          {/* View mode toggle & Add */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-neutral-100 p-1 rounded-lg border border-neutral-200">
              <button
                onClick={() => setViewMode('table')}
                title="Table List View"
                className={`p-1.5 rounded-md transition-colors ${
                  viewMode === 'table' ? 'bg-white shadow-2xs text-teal-700 font-bold' : 'text-neutral-500 hover:text-neutral-900'
                }`}
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('cards')}
                title="Visual Barcode Grid View"
                className={`p-1.5 rounded-md transition-colors ${
                  viewMode === 'cards' ? 'bg-white shadow-2xs text-teal-700 font-bold' : 'text-neutral-500 hover:text-neutral-900'
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={onOpenCreate}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              New Asset
            </button>
          </div>
        </div>

        {/* Filter Chips & Status Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-neutral-100 text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-neutral-500 font-medium flex items-center gap-1 mr-1">
              <Filter className="w-3.5 h-3.5 text-teal-600" /> Category:
            </span>
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  selectedCategory === cat
                    ? 'bg-teal-700 text-white font-bold shadow-2xs'
                    : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200 font-medium'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-2.5 py-1 text-xs bg-neutral-50 border border-neutral-300 rounded-md font-medium text-neutral-700 focus:outline-none"
            >
              <option value="all">All Stock Statuses</option>
              <option value="in_stock">Healthy (In Stock)</option>
              <option value="low_stock">Low Stock Warnings</option>
              <option value="out_of_stock">Out of Stock</option>
            </select>
          </div>
        </div>
      </div>

      {/* Item View (Table vs Cards) */}
      {viewMode === 'table' ? (
        <div className="bg-white rounded-xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-neutral-50 border-b border-neutral-200 text-neutral-600 uppercase tracking-wider text-[11px] font-semibold">
                  <th
                    onClick={() => toggleSort('name')}
                    className="py-3 px-4 cursor-pointer hover:bg-neutral-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Item / Asset Name</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="py-3 px-4">SKU & Barcode</th>
                  <th className="py-3 px-4">Category</th>
                  <th
                    onClick={() => toggleSort('location')}
                    className="py-3 px-4 cursor-pointer hover:bg-neutral-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Location</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('quantity')}
                    className="py-3 px-4 cursor-pointer hover:bg-neutral-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Quantity</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('price')}
                    className="py-3 px-4 cursor-pointer hover:bg-neutral-100 transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      <span>Price (¥)</span>
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-neutral-400">
                      No inventory assets found matching your criteria.
                    </td>
                  </tr>
                ) : (
                  filteredItems.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-neutral-50/80 transition-colors group cursor-pointer"
                      onClick={() => onSelectItem(item)}
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-neutral-100 border border-neutral-200 overflow-hidden shrink-0 flex items-center justify-center">
                            {item.imageUrl ? (
                              // eslint-disable-next-line @next/next/no-img-element
                              <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                            ) : (
                              <Layers className="w-4 h-4 text-neutral-400" />
                            )}
                          </div>
                          <div>
                            <span className="font-bold text-neutral-900 group-hover:text-teal-700 transition-colors line-clamp-1">
                              {item.name}
                            </span>
                            <span className="text-[11px] text-neutral-500">
                              Lot: {item.batchNumber}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 font-mono">
                        <div className="font-semibold text-neutral-800">{item.sku}</div>
                        <div className="text-[11px] text-neutral-500 flex items-center gap-1">
                          <BarcodeIcon className="w-3 h-3 text-neutral-400" />
                          {item.barcode}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="inline-block px-2 py-0.5 rounded bg-neutral-100 text-neutral-700 font-medium">
                          {item.category}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-neutral-600">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                          <span>{item.location}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => adjustStock(item.id, -1, 'Quick Table -1')}
                            disabled={item.quantity <= 0}
                            className="p-1 rounded bg-neutral-100 hover:bg-amber-100 hover:text-amber-800 text-neutral-600 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                            title="Quick Stock -1"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="font-black text-neutral-900 w-8 text-center text-sm">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => adjustStock(item.id, 1, 'Quick Table +1')}
                            className="p-1 rounded bg-neutral-100 hover:bg-emerald-100 hover:text-emerald-800 text-neutral-600 transition-colors"
                            title="Quick Stock +1"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-bold text-neutral-900">¥{item.sellingPrice.toFixed(2)}</div>
                        <div className="text-[10px] text-neutral-400">Cost: ¥{item.costPrice.toFixed(2)}</div>
                      </td>

                      <td className="py-3.5 px-4">{getStatusBadge(item)}</td>

                      <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onOpenMovement(item, 'in')}
                            title="Adjust / Stock Movement"
                            className="p-1.5 text-neutral-500 hover:text-teal-700 hover:bg-teal-50 rounded-lg transition-colors"
                          >
                            <ArrowRightLeft className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onPrintTag(item)}
                            title="Print Barcode Tag"
                            className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onEditItem(item)}
                            title="Edit Item"
                            className="p-1.5 text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg transition-colors"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setItemToDelete(item)}
                            title="Delete Item"
                            className="p-1.5 text-neutral-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Visual Card Grid with scannable barcodes right on the screen */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectItem(item)}
              className="bg-white rounded-xl border border-neutral-200 overflow-hidden shadow-xs hover:border-teal-300 hover:shadow-md transition-all flex flex-col justify-between group cursor-pointer"
            >
              <div>
                {/* Image and badges */}
                <div className="relative h-44 bg-neutral-100 overflow-hidden">
                  {item.imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-neutral-400">
                      <Layers className="w-8 h-8" />
                    </div>
                  )}
                  <div className="absolute top-2.5 left-2.5">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-neutral-900/80 backdrop-blur-xs text-white">
                      {item.category}
                    </span>
                  </div>
                  <div className="absolute top-2.5 right-2.5">{getStatusBadge(item)}</div>
                </div>

                {/* Card Info */}
                <div className="p-4 space-y-3">
                  <div>
                    <h4 className="font-bold text-neutral-900 text-sm line-clamp-1 group-hover:text-teal-700 transition-colors">
                      {item.name}
                    </h4>
                    <p className="text-xs text-neutral-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3 text-neutral-400" />
                      {item.location}
                    </p>
                  </div>

                  {/* Scannable Barcode Preview */}
                  <div className="py-2 px-1 bg-neutral-50 rounded-lg flex flex-col items-center border border-neutral-100">
                    <BarcodeGenerator
                      value={item.barcode}
                      width={180}
                      height={40}
                      showText={true}
                      className="bg-transparent border-none shadow-none p-0"
                    />
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 border-t border-neutral-100">
                    <div>
                      <span className="text-neutral-500 text-[11px]">Stock</span>
                      <p className="font-extrabold text-neutral-900 text-base leading-tight">
                        {item.quantity}{' '}
                        <span className="text-xs font-normal text-neutral-500">units</span>
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-neutral-500 text-[11px]">Price</span>
                      <p className="font-extrabold text-teal-800 text-base leading-tight">
                        ¥{item.sellingPrice.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action buttons footer */}
              <div
                className="px-4 py-2.5 bg-neutral-50 border-t border-neutral-100 flex items-center justify-between"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => adjustStock(item.id, -1, 'Card Quick -1')}
                    disabled={item.quantity <= 0}
                    className="p-1 rounded bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 disabled:opacity-30"
                    title="Stock -1"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => adjustStock(item.id, 1, 'Card Quick +1')}
                    className="p-1 rounded bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700"
                    title="Stock +1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onOpenMovement(item, 'in')}
                    className="p-1.5 text-neutral-600 hover:text-teal-700 rounded hover:bg-neutral-200"
                    title="Adjust stock"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onPrintTag(item)}
                    className="p-1.5 text-neutral-600 hover:text-neutral-900 rounded hover:bg-neutral-200"
                    title="Print barcode tag"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onEditItem(item)}
                    className="p-1.5 text-neutral-600 hover:text-neutral-900 rounded hover:bg-neutral-200"
                    title="Edit item"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {itemToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-5 border border-neutral-200 animate-scale-in">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mb-3">
              <Trash2 className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-neutral-900 text-base">Archive & Delete Asset?</h3>
            <p className="text-xs text-neutral-600 mt-1">
              Are you sure you want to remove <strong>{itemToDelete.name}</strong> ({itemToDelete.sku}) from the catalog? This will log an audit transaction.
            </p>
            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                onClick={() => setItemToDelete(null)}
                className="px-3.5 py-1.5 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  deleteItem(itemToDelete.id);
                  setItemToDelete(null);
                }}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors shadow-2xs"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
