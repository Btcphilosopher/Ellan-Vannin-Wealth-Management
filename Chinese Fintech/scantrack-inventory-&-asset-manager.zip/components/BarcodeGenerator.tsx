'use client';

import React, { useMemo } from 'react';

interface BarcodeGeneratorProps {
  value: string;
  width?: number;
  height?: number;
  showText?: boolean;
  className?: string;
}

// Deterministic Code-128 / 2-of-5 style barcode pattern generator for clean SVG display
export function BarcodeGenerator({
  value,
  width = 160,
  height = 50,
  showText = true,
  className = '',
}: BarcodeGeneratorProps) {
  const bars = useMemo(() => {
    if (!value) return [];
    
    // Hash each char to deterministic bar widths (1, 2, 3, or 4 units)
    let pattern: number[] = [2, 1, 1, 2]; // Start guard
    
    for (let i = 0; i < value.length; i++) {
      const code = value.charCodeAt(i);
      // generate 4 bar-space widths based on char code
      const b1 = ((code * 3 + 1) % 3) + 1;
      const s1 = ((code * 7 + 2) % 3) + 1;
      const b2 = ((code * 5 + 3) % 3) + 1;
      const s2 = ((code * 11 + 4) % 3) + 1;
      pattern.push(b1, s1, b2, s2);
    }
    
    pattern.push(2, 1, 2, 2); // Stop guard
    
    const totalUnits = pattern.reduce((acc, curr) => acc + curr, 0);
    const unitWidth = width / totalUnits;
    
    let currentX = 0;
    const rects: { x: number; width: number; isBar: boolean }[] = [];
    
    pattern.forEach((len, idx) => {
      const barWidth = len * unitWidth;
      const isBar = idx % 2 === 0;
      if (isBar) {
        rects.push({ x: currentX, width: barWidth, isBar: true });
      }
      currentX += barWidth;
    });

    return rects;
  }, [value, width]);

  return (
    <div className={`inline-flex flex-col items-center bg-white p-2 rounded border border-neutral-200 shadow-xs ${className}`}>
      <svg
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-auto overflow-visible"
        aria-label={`Barcode for ${value}`}
      >
        {bars.map((bar, i) => (
          <rect
            key={i}
            x={bar.x}
            y={0}
            width={Math.max(1, bar.width)}
            height={height}
            fill="#111827"
          />
        ))}
      </svg>
      {showText && (
        <span className="font-mono text-[11px] font-bold tracking-widest text-neutral-700 mt-1 select-all">
          {value}
        </span>
      )}
    </div>
  );
}
