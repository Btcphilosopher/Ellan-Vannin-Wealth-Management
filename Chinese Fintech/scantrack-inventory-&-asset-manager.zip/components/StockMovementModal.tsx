'use client';

import React, { useState } from 'react';
import { InventoryItem } from '@/types/inventory';
import { useInventory } from '@/context/InventoryContext';
import { X, ArrowDownRight, ArrowUpRight, Scale, CheckCircle2 } from 'lucide-react';

interface StockMovementModalProps {
  item: InventoryItem | null;
  isOpen: boolean;
  onClose: () => void;
  defaultType?: 'in' | 'out' | 'adjust';
}

export function StockMovementModal({
  item,
  isOpen,
  onClose,
  defaultType = 'in',
}: StockMovementModalProps) {
  const { adjustStock } = useInventory();
  const [movementType, setMovementType] = useState<'in' | 'out' | 'adjust'>(defaultType);
  const [quantity, setQuantity] = useState<number>(10);
  const [reason, setReason] = useState<string>('');
  const [targetCount, setTargetCount] = useState<number>(item?.quantity || 0);

  if (!isOpen || !item) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let changeQty = 0;

    if (movementType === 'in') {
      changeQty = Math.abs(quantity);
    } else if (movementType === 'out') {
      changeQty = -Math.abs(quantity);
    } else {
      // Direct adjustment / cycle count
      changeQty = targetCount - item.quantity;
    }

    const defaultReason =
      movementType === 'in'
        ? `Inbound Receiving (${quantity} units)`
        : movementType === 'out'
        ? `Outbound Fulfillment (${quantity} units)`
        : `Physical Inventory Cycle Count`;

    adjustStock(item.id, changeQty, reason.trim() || defaultReason);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 bg-neutral-900 text-white">
          <div>
            <h3 className="font-bold text-base leading-tight">Record Stock Movement</h3>
            <p className="text-xs text-neutral-400 mt-0.5">Asset: {item.name}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Info */}
        <div className="px-6 py-3 bg-neutral-50 border-b border-neutral-200 flex items-center justify-between text-xs">
          <div>
            <span className="text-neutral-500 font-medium">SKU:</span>{' '}
            <strong className="font-mono text-neutral-800">{item.sku}</strong>
          </div>
          <div>
            <span className="text-neutral-500 font-medium">Current Stock:</span>{' '}
            <strong className="text-teal-700 text-sm font-bold">{item.quantity} units</strong>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Movement Type Toggle */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1.5">Action Type</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setMovementType('in')}
                className={`py-2 px-2.5 rounded-lg border font-semibold flex flex-col items-center gap-1 transition-all ${
                  movementType === 'in'
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-500/20'
                    : 'border-neutral-200 hover:bg-neutral-50 text-neutral-600'
                }`}
              >
                <ArrowDownRight className="w-4 h-4 text-emerald-600" />
                <span>Stock In (+)</span>
              </button>

              <button
                type="button"
                onClick={() => setMovementType('out')}
                className={`py-2 px-2.5 rounded-lg border font-semibold flex flex-col items-center gap-1 transition-all ${
                  movementType === 'out'
                    ? 'border-amber-500 bg-amber-50 text-amber-800 ring-2 ring-amber-500/20'
                    : 'border-neutral-200 hover:bg-neutral-50 text-neutral-600'
                }`}
              >
                <ArrowUpRight className="w-4 h-4 text-amber-600" />
                <span>Stock Out (-)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMovementType('adjust');
                  setTargetCount(item.quantity);
                }}
                className={`py-2 px-2.5 rounded-lg border font-semibold flex flex-col items-center gap-1 transition-all ${
                  movementType === 'adjust'
                    ? 'border-teal-500 bg-teal-50 text-teal-800 ring-2 ring-teal-500/20'
                    : 'border-neutral-200 hover:bg-neutral-50 text-neutral-600'
                }`}
              >
                <Scale className="w-4 h-4 text-teal-600" />
                <span>Audit Adjust</span>
              </button>
            </div>
          </div>

          {/* Quantity Input */}
          {movementType === 'adjust' ? (
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                New Counted Physical Quantity
              </label>
              <input
                type="number"
                min="0"
                value={targetCount}
                onChange={(e) => setTargetCount(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 text-base font-bold text-neutral-900 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
              />
              <p className="text-[11px] text-neutral-500 mt-1">
                Stock will change from <strong>{item.quantity}</strong> to{' '}
                <strong>{targetCount}</strong> ({targetCount - item.quantity >= 0 ? '+' : ''}
                {targetCount - item.quantity} delta)
              </p>
            </div>
          ) : (
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {movementType === 'in' ? 'Units to Add (Inbound)' : 'Units to Deduct (Outbound)'}
              </label>
              <input
                type="number"
                min="1"
                max={movementType === 'out' ? item.quantity : 99999}
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2 text-base font-bold text-neutral-900 bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
              />
              <p className="text-[11px] text-neutral-500 mt-1">
                New resulting stock:{' '}
                <strong>
                  {movementType === 'in' ? item.quantity + quantity : Math.max(0, item.quantity - quantity)}{' '}
                  units
                </strong>
              </p>
            </div>
          )}

          {/* Reason / Reference */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              Reason / PO / Invoice / Ticket Number
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder={
                movementType === 'in'
                  ? 'e.g. PO-2026-992 from Apex BioCosmetics'
                  : movementType === 'out'
                  ? 'e.g. Order #ORD-4011 Dispatch to Downtown Store'
                  : 'e.g. Annual physical count variance'
              }
              className="w-full px-3 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white"
            />
          </div>

          {/* Quick preset chips */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] text-neutral-500">Quick:</span>
            {[1, 5, 10, 25, 50].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => setQuantity(n)}
                className="px-2 py-0.5 rounded bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-semibold text-[11px] transition-colors"
              >
                +{n}
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="pt-4 border-t border-neutral-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-lg text-sm font-medium hover:bg-neutral-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors"
            >
              <CheckCircle2 className="w-4 h-4" />
              Apply Movement
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
