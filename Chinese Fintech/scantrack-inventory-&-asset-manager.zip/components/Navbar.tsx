'use client';

import React from 'react';
import { useInventory } from '@/context/InventoryContext';
import { 
  Scan, 
  Camera, 
  ShieldCheck, 
  RefreshCw, 
  Layers, 
  BarChart3, 
  History, 
  Database,
  Wifi,
  Package
} from 'lucide-react';

interface NavbarProps {
  activeTab: 'overview' | 'catalog' | 'audit';
  setActiveTab: (tab: 'overview' | 'catalog' | 'audit') => void;
  onOpenScanner: () => void;
  onOpenUserModal: () => void;
}

export function Navbar({
  activeTab,
  setActiveTab,
  onOpenScanner,
  onOpenUserModal,
}: NavbarProps) {
  const { currentUser, isOnline, resetToDefault } = useInventory();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand Logo */}
          <div className="flex items-center gap-6">
            <div
              onClick={() => setActiveTab('overview')}
              className="flex items-center gap-2.5 cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-800 to-teal-600 text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-transform">
                <Scan className="w-5 h-5 text-teal-200" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-extrabold text-lg text-neutral-900 tracking-tight">
                    ScanTrack
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded bg-teal-100 text-teal-800">
                    Live
                  </span>
                </div>
                <p className="text-[10px] text-neutral-400 font-medium -mt-0.5">
                  Real-Time Asset & Barcode System
                </p>
              </div>
            </div>

            {/* Main Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1 bg-neutral-100 p-1 rounded-xl border border-neutral-200/80">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'overview'
                    ? 'bg-white text-teal-900 shadow-xs'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                Dashboard Overview
              </button>

              <button
                onClick={() => setActiveTab('catalog')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'catalog'
                    ? 'bg-white text-teal-900 shadow-xs'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                <Package className="w-3.5 h-3.5" />
                Inventory Catalog
              </button>

              <button
                onClick={() => setActiveTab('audit')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeTab === 'audit'
                    ? 'bg-white text-teal-900 shadow-xs'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                Audit Trail
              </button>
            </nav>
          </div>

          {/* Right Action Utilities */}
          <div className="flex items-center gap-2.5">
            {/* Real-time sync status pill */}
            <div className="hidden lg:flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Real-Time Sync Active</span>
            </div>

            {/* Quick Barcode Scanner Button */}
            <button
              onClick={onOpenScanner}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-teal-700 to-teal-800 hover:from-teal-600 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all transform active:scale-95"
            >
              <Camera className="w-4 h-4 text-teal-200" />
              <span className="hidden sm:inline">Scan Barcode</span>
            </button>

            {/* User Profile Switcher */}
            <button
              onClick={onOpenUserModal}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-neutral-200 hover:border-teal-300 hover:bg-neutral-50 transition-all text-left"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-7 h-7 rounded-full object-cover border border-neutral-200"
              />
              <div className="hidden sm:block text-left">
                <span className="font-bold text-xs text-neutral-900 block leading-tight">
                  {currentUser.name}
                </span>
                <span className="text-[10px] text-teal-700 font-semibold block capitalize">
                  {currentUser.role.replace('_', ' ')}
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Tab bar */}
        <div className="md:hidden flex items-center justify-between py-2 border-t border-neutral-100 text-xs">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex-1 py-1 text-center font-semibold ${
              activeTab === 'overview' ? 'text-teal-700 border-b-2 border-teal-700' : 'text-neutral-500'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('catalog')}
            className={`flex-1 py-1 text-center font-semibold ${
              activeTab === 'catalog' ? 'text-teal-700 border-b-2 border-teal-700' : 'text-neutral-500'
            }`}
          >
            Catalog
          </button>
          <button
            onClick={() => setActiveTab('audit')}
            className={`flex-1 py-1 text-center font-semibold ${
              activeTab === 'audit' ? 'text-teal-700 border-b-2 border-teal-700' : 'text-neutral-500'
            }`}
          >
            Audit Trail
          </button>
        </div>
      </div>
    </header>
  );
}
