'use client';

import React, { useState } from 'react';
import { useInventory } from '@/context/InventoryContext';
import { UserProfile, UserRole } from '@/types/inventory';
import { X, Shield, User, CheckCircle2, LogIn, Key, Briefcase } from 'lucide-react';

interface UserSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function UserSwitcherModal({ isOpen, onClose }: UserSwitcherModalProps) {
  const { currentUser, setCurrentUser, availableUsers } = useInventory();
  const [customName, setCustomName] = useState('');
  const [customEmail, setCustomEmail] = useState('');
  const [customRole, setCustomRole] = useState<UserRole>('inventory_manager');
  const [isCreatingCustom, setIsCreatingCustom] = useState(false);

  if (!isOpen) return null;

  const handleSelectUser = (user: UserProfile) => {
    setCurrentUser(user);
    onClose();
  };

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim() || !customEmail.trim()) return;

    const newUser: UserProfile = {
      id: `usr_${Date.now()}`,
      name: customName.trim(),
      email: customEmail.trim(),
      role: customRole,
      avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`,
      department: customRole === 'admin' ? 'Executive' : 'Supply Chain',
    };

    setCurrentUser(newUser);
    onClose();
  };

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'admin':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800">
            System Admin
          </span>
        );
      case 'inventory_manager':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-teal-100 text-teal-800">
            Inventory Manager
          </span>
        );
      case 'warehouse_scanner':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800">
            Fulfillment Scanner
          </span>
        );
      case 'auditor':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800">
            Field Auditor
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 bg-neutral-900 text-white">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-teal-400" />
            <div>
              <h3 className="font-bold text-base">User Authentication & Roles</h3>
              <p className="text-xs text-neutral-400">Switch active account for role-based audit tracking</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <div className="space-y-2">
            <label className="block text-xs font-bold text-neutral-700">
              Select Authenticated Profile:
            </label>
            {availableUsers.map((user) => {
              const isSelected = user.id === currentUser.id;
              return (
                <div
                  key={user.id}
                  onClick={() => handleSelectUser(user)}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                    isSelected
                      ? 'border-teal-500 bg-teal-50/80 ring-2 ring-teal-500/20'
                      : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-10 h-10 rounded-full object-cover border border-neutral-200"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-neutral-900 text-sm">{user.name}</span>
                        {getRoleBadge(user.role)}
                      </div>
                      <p className="text-xs text-neutral-500">{user.email}</p>
                    </div>
                  </div>
                  {isSelected && <CheckCircle2 className="w-5 h-5 text-teal-600 shrink-0" />}
                </div>
              );
            })}
          </div>

          {/* Toggle Custom Sign In */}
          {!isCreatingCustom ? (
            <button
              onClick={() => setIsCreatingCustom(true)}
              className="w-full py-2.5 px-3 border border-dashed border-neutral-300 hover:border-teal-500 hover:bg-teal-50/30 rounded-xl text-xs font-semibold text-neutral-700 flex items-center justify-center gap-2 transition-colors"
            >
              <LogIn className="w-4 h-4 text-teal-600" />
              Sign in with Custom Credentials
            </button>
          ) : (
            <form onSubmit={handleCreateCustom} className="p-4 bg-neutral-50 rounded-xl border border-neutral-200 space-y-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-neutral-800">Custom User Login</span>
                <button
                  type="button"
                  onClick={() => setIsCreatingCustom(false)}
                  className="text-[11px] text-neutral-500 hover:text-neutral-800"
                >
                  Cancel
                </button>
              </div>

              <div>
                <label className="block text-neutral-600 mb-1 font-medium">Full Name</label>
                <input
                  type="text"
                  required
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="e.g. Alex Morgan"
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-neutral-600 mb-1 font-medium">Work Email</label>
                <input
                  type="email"
                  required
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  placeholder="alex.m@retailhub.com"
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-neutral-600 mb-1 font-medium">Assigned Role</label>
                <select
                  value={customRole}
                  onChange={(e) => setCustomRole(e.target.value as UserRole)}
                  className="w-full px-3 py-1.5 bg-white border border-neutral-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-teal-500"
                >
                  <option value="admin">System Admin (Full Access)</option>
                  <option value="inventory_manager">Inventory Manager (Stock & Catalog)</option>
                  <option value="warehouse_scanner">Fulfillment Scanner (Barcode & Receipts)</option>
                  <option value="auditor">Field Auditor (Stock Counts)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-lg transition-colors mt-2"
              >
                Sign In as Custom User
              </button>
            </form>
          )}
        </div>

        <div className="px-6 py-3 bg-neutral-50 border-t border-neutral-200 text-center text-[11px] text-neutral-500">
          User identity is stamped onto all real-time transaction records & audit logs.
        </div>
      </div>
    </div>
  );
}
