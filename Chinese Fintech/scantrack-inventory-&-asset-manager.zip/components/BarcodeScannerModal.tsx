'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { soundFX } from '@/lib/audio';
import { useInventory } from '@/context/InventoryContext';
import { InventoryItem, ScanAction } from '@/types/inventory';
import { 
  Camera, 
  X, 
  Zap, 
  Plus, 
  Minus, 
  Search, 
  Upload, 
  AlertCircle, 
  CheckCircle2, 
  Volume2, 
  RefreshCw,
  Barcode as BarcodeIcon,
  Package
} from 'lucide-react';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onItemSelect?: (item: InventoryItem) => void;
  defaultAction?: ScanAction;
}

export function BarcodeScannerModal({
  isOpen,
  onClose,
  onItemSelect,
  defaultAction = 'view',
}: BarcodeScannerModalProps) {
  const { items, findItemByBarcode, adjustStock } = useInventory();
  const [scanAction, setScanAction] = useState<ScanAction>(defaultAction);
  const [manualCode, setManualCode] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [lastScannedItem, setLastScannedItem] = useState<InventoryItem | null>(null);
  const [lastScannedCode, setLastScannedCode] = useState<string | null>(null);
  const [scanSuccessFeedback, setScanSuccessFeedback] = useState<string | null>(null);
  const [continuousCount, setContinuousCount] = useState(0);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const readerElementId = 'barcode-camera-viewport';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const manualInputRef = useRef<HTMLInputElement>(null);

  // Process a detected barcode or SKU code
  const handleBarcodeDetected = useCallback(
    (code: string) => {
      const cleanCode = code.trim();
      if (!cleanCode) return;

      const item = findItemByBarcode(cleanCode);
      setLastScannedCode(cleanCode);

      if (item) {
        soundFX.playScanSuccess();
        setLastScannedItem(item);

        if (scanAction === 'stock_in_one') {
          adjustStock(item.id, 1, 'Quick Barcode Scanner (+1)');
          setScanSuccessFeedback(`Added +1 to ${item.name} (New Qty: ${item.quantity + 1})`);
          setContinuousCount((prev) => prev + 1);
        } else if (scanAction === 'stock_out_one') {
          if (item.quantity > 0) {
            adjustStock(item.id, -1, 'Quick Barcode Scanner (-1)');
            setScanSuccessFeedback(`Dispatched -1 from ${item.name} (New Qty: ${item.quantity - 1})`);
            setContinuousCount((prev) => prev + 1);
          } else {
            soundFX.playScanError();
            setScanSuccessFeedback(`Item is already out of stock!`);
          }
        } else {
          setScanSuccessFeedback(`Found: ${item.name} [${item.sku}]`);
          if (onItemSelect) {
            onItemSelect(item);
          }
        }
      } else {
        soundFX.playScanError();
        setLastScannedItem(null);
        setScanSuccessFeedback(`Barcode "${cleanCode}" not found in catalog.`);
      }

      // Auto-clear feedback banner after 3.5s
      setTimeout(() => {
        setScanSuccessFeedback(null);
      }, 3500);
    },
    [findItemByBarcode, adjustStock, scanAction, onItemSelect]
  );

  // Start HTML5 Camera Scanner
  const startCamera = useCallback(async () => {
    setCameraError(null);
    try {
      // If previous scanner exists, stop it
      if (scannerRef.current) {
        try {
          await scannerRef.current.stop();
        } catch {
          // ignore
        }
      }

      const html5QrCode = new Html5Qrcode(readerElementId, {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.QR_CODE,
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.EAN_8,
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
        ],
        verbose: false,
      });
      scannerRef.current = html5QrCode;

      const config = {
        fps: 15,
        qrbox: { width: 280, height: 180 },
        aspectRatio: 1.333,
      };

      await html5QrCode.start(
        { facingMode: 'environment' },
        config,
        (decodedText) => {
          handleBarcodeDetected(decodedText);
        },
        () => {
          // Frame scan error - ignore frame ticks
        }
      );

      setCameraActive(true);
    } catch (err: unknown) {
      console.warn('Camera initiation failed:', err);
      setCameraActive(false);
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('Permission') || msg.includes('NotAllowedError')) {
        setCameraError('Camera access was blocked. You can upload barcode photos or use the simulated scanner below.');
      } else {
        setCameraError('No live camera available or unsupported in current environment. Use photo upload or test barcodes.');
      }
    }
  }, [handleBarcodeDetected]);

  // Stop Camera
  const stopCamera = useCallback(async () => {
    if (scannerRef.current) {
      try {
        if (scannerRef.current.isScanning) {
          await scannerRef.current.stop();
        }
      } catch {
        // ignore
      }
      scannerRef.current = null;
    }
    setCameraActive(false);
  }, []);

  // Handle open/close lifecycle
  useEffect(() => {
    if (isOpen) {
      // Small delay to ensure DOM element is ready
      const t = setTimeout(() => {
        startCamera();
        if (manualInputRef.current) {
          manualInputRef.current.focus();
        }
      }, 300);
      return () => clearTimeout(t);
    } else {
      stopCamera();
      setLastScannedItem(null);
      setLastScannedCode(null);
      setScanSuccessFeedback(null);
      setContinuousCount(0);
    }
  }, [isOpen, startCamera, stopCamera]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  // Handle image file upload scanning
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const html5QrCode = new Html5Qrcode('temp-file-scanner');
      const result = await html5QrCode.scanFile(file, true);
      handleBarcodeDetected(result);
    } catch {
      soundFX.playScanError();
      setScanSuccessFeedback('Could not detect a clear barcode in this image. Try another photo or enter code manually.');
    }
  };

  // Handle Manual code submit or physical USB laser scanner enter
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    handleBarcodeDetected(manualCode.trim());
    setManualCode('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/75 backdrop-blur-xs transition-opacity animate-fade-in">
      {/* Hidden container for file decoding */}
      <div id="temp-file-scanner" className="hidden" />

      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden border border-neutral-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 bg-linear-to-r from-teal-900 to-teal-800 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-500/20 rounded-lg text-teal-300 ring-1 ring-teal-400/30">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg leading-tight">Barcode & Asset Scanner</h3>
                <span className="px-2 py-0.5 text-[11px] font-semibold tracking-wider uppercase rounded-full bg-teal-400/20 text-teal-200 border border-teal-300/30">
                  Live Vision
                </span>
              </div>
              <p className="text-xs text-teal-200/80">Point camera at UPC/EAN, Code-128 or QR tag</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-teal-200 hover:text-white hover:bg-teal-700/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Mode Selector Bar */}
        <div className="px-6 py-3 bg-neutral-50 border-b border-neutral-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <span className="font-semibold text-neutral-600 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-teal-600" />
            Scan Action:
          </span>
          <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-neutral-200 shadow-2xs">
            <button
              onClick={() => setScanAction('view')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
                scanAction === 'view'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              Lookup / View
            </button>
            <button
              onClick={() => setScanAction('stock_in_one')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
                scanAction === 'stock_in_one'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              Stock In (+1)
            </button>
            <button
              onClick={() => setScanAction('stock_out_one')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
                scanAction === 'stock_out_one'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              <Minus className="w-3.5 h-3.5" />
              Stock Out (-1)
            </button>
          </div>
          {continuousCount > 0 && (
            <span className="text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Scanned this session: {continuousCount}
            </span>
          )}
        </div>

        {/* Feedback Alert if scan occurred */}
        {scanSuccessFeedback && (
          <div className="px-6 py-2.5 bg-teal-50 border-b border-teal-100 flex items-center justify-between text-xs text-teal-900 animate-fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
              <span className="font-medium">{scanSuccessFeedback}</span>
            </div>
            <Volume2 className="w-3.5 h-3.5 text-teal-500 animate-pulse" />
          </div>
        )}

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Camera Viewport or Fallback Container */}
          <div className="relative rounded-xl overflow-hidden bg-neutral-950 border-2 border-neutral-800 shadow-inner min-h-[240px] flex flex-col items-center justify-center">
            {/* The actual HTML5-QRCODE mounting div */}
            <div
              id={readerElementId}
              className={`w-full max-w-md ${cameraActive ? 'block' : 'hidden'}`}
            />

            {!cameraActive && (
              <div className="p-6 text-center text-neutral-300 max-w-sm">
                <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-400">
                  <Camera className="w-6 h-6" />
                </div>
                <h4 className="font-semibold text-white mb-1">
                  {cameraError ? 'Camera Standby / Sandboxed' : 'Initializing Camera...'}
                </h4>
                <p className="text-xs text-neutral-400 mb-4">
                  {cameraError || 'Allow camera access in your browser or use the quick barcode options below.'}
                </p>
                <div className="flex items-center justify-center gap-2">
                  <button
                    onClick={startCamera}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Retry Camera
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-semibold border border-neutral-700 transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Upload Photo
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
              </div>
            )}

            {/* Target Reticle Overlay while camera is active */}
            {cameraActive && (
              <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
                <div className="w-64 h-36 border-2 border-teal-400/80 rounded-xl relative shadow-[0_0_20px_rgba(45,212,191,0.3)]">
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-teal-300 -mt-0.5 -ml-0.5" />
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-teal-300 -mt-0.5 -mr-0.5" />
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-teal-300 -mb-0.5 -ml-0.5" />
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-teal-300 -mb-0.5 -mr-0.5" />
                  <div className="absolute inset-x-0 top-1/2 h-0.5 bg-red-500/60 shadow-[0_0_8px_red] animate-pulse" />
                </div>
                <span className="text-[11px] text-teal-300 font-medium mt-3 bg-neutral-900/80 px-2 py-0.5 rounded-full backdrop-blur-xs">
                  Align barcode in frame
                </span>
              </div>
            )}
          </div>

          {/* Scanned Item Quick Summary Preview */}
          {lastScannedItem && (
            <div className="p-4 rounded-xl border border-teal-200 bg-teal-50/60 flex items-center justify-between gap-4 animate-scale-in">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-white border border-teal-200 overflow-hidden shrink-0 flex items-center justify-center">
                  {lastScannedItem.imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={lastScannedItem.imageUrl}
                      alt={lastScannedItem.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Package className="w-6 h-6 text-teal-600" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h5 className="font-bold text-neutral-900 text-sm">{lastScannedItem.name}</h5>
                    <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-700 font-semibold">
                      {lastScannedItem.sku}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-600 mt-0.5">
                    Location: <strong className="text-neutral-800">{lastScannedItem.location}</strong> • Current Stock:{' '}
                    <strong className="text-teal-700">{lastScannedItem.quantity} units</strong> • Price: ¥{lastScannedItem.sellingPrice.toFixed(2)}
                  </p>
                </div>
              </div>

              {onItemSelect && (
                <button
                  onClick={() => {
                    onItemSelect(lastScannedItem);
                    onClose();
                  }}
                  className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-bold transition-colors shrink-0 shadow-2xs"
                >
                  Open Record
                </button>
              )}
            </div>
          )}

          {/* Manual Input or Handheld Laser Scanner Wedge */}
          <form onSubmit={handleManualSubmit} className="space-y-1.5">
            <label className="block text-xs font-semibold text-neutral-700">
              Manual Barcode / Handheld Scanner Input (Press Enter):
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <BarcodeIcon className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  ref={manualInputRef}
                  type="text"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder="e.g. 690123456701 or WAT-SKN-0101"
                  className="w-full pl-9 pr-4 py-2 text-sm bg-neutral-50 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:bg-white font-mono"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Scan Code
              </button>
            </div>
          </form>

          {/* Quick Click-to-Test Barcode Palette */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-neutral-700 flex items-center gap-1.5">
                <BarcodeIcon className="w-3.5 h-3.5 text-teal-600" />
                Test Scanners Instantly (Click any sample barcode):
              </span>
              <span className="text-[11px] text-neutral-500">Live Catalog Barcodes</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {items.slice(0, 8).map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleBarcodeDetected(item.barcode)}
                  className="p-2 text-left bg-neutral-50 hover:bg-teal-50/80 hover:border-teal-300 border border-neutral-200 rounded-lg transition-all group"
                >
                  <p className="text-[11px] font-bold text-neutral-800 truncate group-hover:text-teal-700">
                    {item.name}
                  </p>
                  <p className="text-[10px] font-mono text-neutral-500 truncate mt-0.5">
                    {item.barcode}
                  </p>
                  <span className="inline-block mt-1 text-[9px] px-1.5 py-0.2 bg-white rounded border border-neutral-200 text-neutral-600">
                    Qty: {item.quantity}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-neutral-50 border-t border-neutral-200 flex items-center justify-between text-xs text-neutral-500">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Barcode Engine: EAN-13, Code-128, UPC-A, QR</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white border border-neutral-300 hover:bg-neutral-100 rounded-lg text-neutral-700 font-medium transition-colors"
          >
            Done Scanning
          </button>
        </div>
      </div>
    </div>
  );
}
