'use client';

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { InventoryItem, AuditLog, UserProfile, StockStatus } from '@/types/inventory';
import { INITIAL_ITEMS, INITIAL_USERS } from '@/lib/mockData';
import { soundFX } from '@/lib/audio';

interface InventoryContextType {
  items: InventoryItem[];
  auditLogs: AuditLog[];
  currentUser: UserProfile;
  isOnline: boolean;
  lastSyncTime: Date;
  // Item CRUD
  addItem: (item: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt' | 'status'>) => InventoryItem;
  updateItem: (id: string, updates: Partial<InventoryItem>) => void;
  deleteItem: (id: string) => void;
  adjustStock: (id: string, changeQty: number, reason: string) => boolean;
  // Lookups
  findItemByBarcode: (barcodeOrSku: string) => InventoryItem | undefined;
  // User Management
  setCurrentUser: (user: UserProfile) => void;
  availableUsers: UserProfile[];
  // Utilities
  resetToDefault: () => void;
  exportCsv: () => void;
  exportJson: () => void;
  importJson: (jsonData: string) => boolean;
}

const InventoryContext = createContext<InventoryContextType | null>(null);

const STORAGE_KEY_ITEMS = 'scantrack_inventory_items_v2';
const STORAGE_KEY_LOGS = 'scantrack_inventory_logs_v2';
const STORAGE_KEY_USER = 'scantrack_active_user_v2';

export function InventoryProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile>(INITIAL_USERS[0]);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const [isInitialized, setIsInitialized] = useState<boolean>(false);

  // Helper to calculate status based on qty and threshold
  const computeStatus = (qty: number, minThreshold: number): StockStatus => {
    if (qty <= 0) return 'out_of_stock';
    if (qty <= minThreshold) return 'low_stock';
    return 'in_stock';
  };

  // Broadcast channel for true real-time multi-tab cross-window synchronization
  const broadcastSync = useCallback((type: string, payload?: unknown) => {
    if (typeof window === 'undefined') return;
    try {
      if ('BroadcastChannel' in window) {
        const channel = new BroadcastChannel('scantrack_channel');
        channel.postMessage({ type, payload, timestamp: Date.now() });
        channel.close();
      }
    } catch {
      // Ignore broadcast errors in restricted environments
    }
  }, []);

  // Initialize from LocalStorage or seed data
  useEffect(() => {
    if (typeof window === 'undefined') return;

    try {
      const savedItems = localStorage.getItem(STORAGE_KEY_ITEMS);
      const savedLogs = localStorage.getItem(STORAGE_KEY_LOGS);
      const savedUser = localStorage.getItem(STORAGE_KEY_USER);

      if (savedItems) {
        setItems(JSON.parse(savedItems));
      } else {
        setItems(INITIAL_ITEMS);
        localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(INITIAL_ITEMS));
      }

      if (savedLogs) {
        setAuditLogs(JSON.parse(savedLogs));
      } else {
        // Initial seed logs
        const initialLogs: AuditLog[] = [
          {
            id: 'log_init_01',
            itemId: 'itm_001',
            itemName: 'Luminous Hydrating Serum',
            sku: 'WAT-SKN-0101',
            barcode: '690123456701',
            action: 'stock_in',
            quantityChanged: 50,
            previousQty: 92,
            newQty: 142,
            userId: INITIAL_USERS[0].id,
            userName: INITIAL_USERS[0].name,
            userRole: INITIAL_USERS[0].role,
            reason: 'Inbound PO-2026-884 Received',
            timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
          },
          {
            id: 'log_init_02',
            itemId: 'itm_005',
            itemName: 'Vitality Gold Softgel Complex',
            sku: 'WAT-HLT-0401',
            barcode: '690123456705',
            action: 'stock_out',
            quantityChanged: -20,
            previousQty: 20,
            newQty: 0,
            userId: INITIAL_USERS[1].id,
            userName: INITIAL_USERS[1].name,
            userRole: INITIAL_USERS[1].role,
            reason: 'Store Replenishment Dispatch (Order #SH-4091)',
            timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
          },
        ];
        setAuditLogs(initialLogs);
        localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(initialLogs));
      }

      if (savedUser) {
        setCurrentUser(JSON.parse(savedUser));
      }
    } catch (e) {
      console.warn('Storage initial load error:', e);
      setItems(INITIAL_ITEMS);
    } finally {
      setIsInitialized(true);
    }

    // Listen to network status
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // BroadcastChannel listener
    let channel: BroadcastChannel | null = null;
    try {
      if ('BroadcastChannel' in window) {
        channel = new BroadcastChannel('scantrack_channel');
        channel.onmessage = (event) => {
          if (event.data?.type === 'SYNC_REFRESH') {
            const freshItems = localStorage.getItem(STORAGE_KEY_ITEMS);
            const freshLogs = localStorage.getItem(STORAGE_KEY_LOGS);
            if (freshItems) setItems(JSON.parse(freshItems));
            if (freshLogs) setAuditLogs(JSON.parse(freshLogs));
            setLastSyncTime(new Date());
          }
        };
      }
    } catch {
      // Ignore broadcast errors
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (channel) channel.close();
    };
  }, []);

  // Save items on change
  useEffect(() => {
    if (!isInitialized || typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(items));
      setLastSyncTime(new Date());
    } catch (e) {
      console.error('Failed to save items:', e);
    }
  }, [items, isInitialized]);

  // Save logs on change
  useEffect(() => {
    if (!isInitialized || typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(auditLogs));
    } catch (e) {
      console.error('Failed to save logs:', e);
    }
  }, [auditLogs, isInitialized]);

  // Save current user on change
  const handleSetCurrentUser = (user: UserProfile) => {
    setCurrentUser(user);
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
    }
  };

  // Add Item
  const addItem = (itemData: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt' | 'status'>): InventoryItem => {
    const now = new Date().toISOString();
    const newItem: InventoryItem = {
      ...itemData,
      id: `itm_${Date.now()}`,
      status: computeStatus(itemData.quantity, itemData.minStockThreshold),
      createdAt: now,
      updatedAt: now,
    };

    setItems((prev) => [newItem, ...prev]);

    // Create audit log
    const log: AuditLog = {
      id: `log_${Date.now()}`,
      itemId: newItem.id,
      itemName: newItem.name,
      sku: newItem.sku,
      barcode: newItem.barcode,
      action: 'created',
      quantityChanged: newItem.quantity,
      previousQty: 0,
      newQty: newItem.quantity,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      reason: 'New asset catalog entry registered',
      timestamp: now,
    };
    setAuditLogs((prev) => [log, ...prev]);
    soundFX.playStockUpdate();
    broadcastSync('SYNC_REFRESH');

    return newItem;
  };

  // Update Item
  const updateItem = (id: string, updates: Partial<InventoryItem>) => {
    const now = new Date().toISOString();
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newQty = updates.quantity !== undefined ? updates.quantity : item.quantity;
          const newMin = updates.minStockThreshold !== undefined ? updates.minStockThreshold : item.minStockThreshold;
          const updatedItem = {
            ...item,
            ...updates,
            status: computeStatus(newQty, newMin),
            updatedAt: now,
          };

          // If quantity changed, log it
          if (updates.quantity !== undefined && updates.quantity !== item.quantity) {
            const diff = updates.quantity - item.quantity;
            const log: AuditLog = {
              id: `log_${Date.now()}`,
              itemId: item.id,
              itemName: item.name,
              sku: item.sku,
              barcode: item.barcode,
              action: diff > 0 ? 'stock_in' : 'stock_out',
              quantityChanged: diff,
              previousQty: item.quantity,
              newQty: updates.quantity,
              userId: currentUser.id,
              userName: currentUser.name,
              userRole: currentUser.role,
              reason: 'Quantity modified via item editor',
              timestamp: now,
            };
            setAuditLogs((l) => [log, ...l]);
          } else {
            const log: AuditLog = {
              id: `log_${Date.now()}`,
              itemId: item.id,
              itemName: item.name,
              sku: item.sku,
              barcode: item.barcode,
              action: 'updated',
              quantityChanged: 0,
              previousQty: item.quantity,
              newQty: item.quantity,
              userId: currentUser.id,
              userName: currentUser.name,
              userRole: currentUser.role,
              reason: 'Asset metadata / pricing updated',
              timestamp: now,
            };
            setAuditLogs((l) => [log, ...l]);
          }

          return updatedItem;
        }
        return item;
      })
    );
    soundFX.playStockUpdate();
    broadcastSync('SYNC_REFRESH');
  };

  // Delete Item
  const deleteItem = (id: string) => {
    const target = items.find((i) => i.id === id);
    if (!target) return;

    setItems((prev) => prev.filter((i) => i.id !== id));

    const log: AuditLog = {
      id: `log_${Date.now()}`,
      itemId: target.id,
      itemName: target.name,
      sku: target.sku,
      barcode: target.barcode,
      action: 'deleted',
      quantityChanged: -target.quantity,
      previousQty: target.quantity,
      newQty: 0,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      reason: 'Asset archived & removed from active inventory',
      timestamp: new Date().toISOString(),
    };
    setAuditLogs((prev) => [log, ...prev]);
    broadcastSync('SYNC_REFRESH');
  };

  // Adjust Stock (+ or - count)
  const adjustStock = (id: string, changeQty: number, reason: string): boolean => {
    const target = items.find((i) => i.id === id);
    if (!target) return false;

    const previousQty = target.quantity;
    const newQty = Math.max(0, previousQty + changeQty);
    const now = new Date().toISOString();

    setItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          return {
            ...item,
            quantity: newQty,
            status: computeStatus(newQty, item.minStockThreshold),
            updatedAt: now,
          };
        }
        return item;
      })
    );

    const log: AuditLog = {
      id: `log_${Date.now()}`,
      itemId: target.id,
      itemName: target.name,
      sku: target.sku,
      barcode: target.barcode,
      action: changeQty > 0 ? 'stock_in' : changeQty < 0 ? 'stock_out' : 'adjust',
      quantityChanged: changeQty,
      previousQty,
      newQty,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      reason: reason || (changeQty > 0 ? 'Stock In Receipt' : 'Stock Out Fulfillment'),
      timestamp: now,
    };

    setAuditLogs((prev) => [log, ...prev]);
    soundFX.playStockUpdate();
    broadcastSync('SYNC_REFRESH');
    return true;
  };

  // Find item by Barcode or SKU
  const findItemByBarcode = (query: string): InventoryItem | undefined => {
    if (!query) return undefined;
    const clean = query.trim().toLowerCase();
    return items.find(
      (item) =>
        item.barcode.toLowerCase() === clean ||
        item.sku.toLowerCase() === clean ||
        item.id.toLowerCase() === clean
    );
  };

  // Reset to default seed
  const resetToDefault = () => {
    setItems(INITIAL_ITEMS);
    localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(INITIAL_ITEMS));
    soundFX.playScanSuccess();
    broadcastSync('SYNC_REFRESH');
  };

  // Export CSV
  const exportCsv = () => {
    if (!items.length) return;
    const headers = ['ID', 'Name', 'SKU', 'Barcode', 'Category', 'Quantity', 'MinThreshold', 'CostPrice', 'SellingPrice', 'Location', 'Status', 'Batch', 'Expiry'];
    const rows = items.map((i) => [
      i.id,
      `"${i.name.replace(/"/g, '""')}"`,
      i.sku,
      i.barcode,
      i.category,
      i.quantity,
      i.minStockThreshold,
      i.costPrice,
      i.sellingPrice,
      `"${i.location}"`,
      i.status,
      i.batchNumber,
      i.expiryDate || '',
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `inventory_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export JSON
  const exportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(items, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `inventory_data_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Import JSON
  const importJson = (jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].sku && parsed[0].name) {
        setItems(parsed);
        localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(parsed));
        soundFX.playScanSuccess();
        broadcastSync('SYNC_REFRESH');
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  return (
    <InventoryContext.Provider
      value={{
        items,
        auditLogs,
        currentUser,
        isOnline,
        lastSyncTime,
        addItem,
        updateItem,
        deleteItem,
        adjustStock,
        findItemByBarcode,
        setCurrentUser: handleSetCurrentUser,
        availableUsers: INITIAL_USERS,
        resetToDefault,
        exportCsv,
        exportJson,
        importJson,
      }}
    >
      {children}
    </InventoryContext.Provider>
  );
}

export function useInventory() {
  const context = useContext(InventoryContext);
  if (!context) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
}
