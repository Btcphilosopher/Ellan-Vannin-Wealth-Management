package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.EtfItem
import com.example.ui.components.StatCard
import com.example.ui.theme.*

@Composable
fun ResearchWorkbenchScreen(
    allEtfs: List<EtfItem>,
    modifier: Modifier = Modifier
) {
    var selectedEtfIds by remember { mutableStateOf(setOf("510300", "588000", "518880", "513050")) }

    val comparedEtfs = remember(selectedEtfIds, allEtfs) {
        allEtfs.filter { it.fundId in selectedEtfIds }
    }

    val pythonApiSnippet = remember(comparedEtfs) {
        """
# HUAFUND TERMINAL PYTHON RESEARCH API
from huafund import ETF, Portfolio

# 1. Fetch live ETF digital twin state
etf = ETF("510300")
print(etf.price(), etf.iopv(), etf.pcf())

# 2. Evaluate Overlap & Tracking Error
overlap = etf.overlap("${comparedEtfs.firstOrNull()?.fundId ?: "510300"}", "513050")
print("Weight Overlap:", overlap.weight_overlap_pct)

# 3. Optimize Portfolio Risk
port = Portfolio()
port.add("510300", 0.35)
port.add("513050", 0.25)
port.risk()
        """.trimIndent()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Research Workbench Title Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanTerminal),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "量化研究工作台 (RESEARCH WORKBENCH)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "支持 5,000+ ETF 标的多维度对比、指数调整冲击模拟与 Python/R 终端导出一键集成",
                        fontSize = 10.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("标的选择对比 (最多选择5只):", fontSize = 10.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        allEtfs.take(6).forEach { etf ->
                            val isSel = etf.fundId in selectedEtfIds
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (isSel) GoldTerminal.copy(alpha = 0.25f) else TerminalSurfaceVariant,
                                        RoundedCornerShape(3.dp)
                                    )
                                    .border(1.dp, if (isSel) GoldTerminal else TerminalBorder)
                                    .clickable {
                                        selectedEtfIds = if (isSel) selectedEtfIds - etf.fundId else selectedEtfIds + etf.fundId
                                    }
                                    .padding(vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = etf.shortName,
                                    fontSize = 9.sp,
                                    color = if (isSel) GoldTerminal else TextSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Comparison Matrix Table
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = "核心指标多维横向对比矩阵 (HEAD-TO-HEAD MATRIX)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("标的", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.2f))
                        Text("最新价", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("涨跌幅", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("跟踪误差", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("管理费率", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("持有总成本TCO", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.2f))
                    }
                }
            }
        }

        items(comparedEtfs) { etf ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TerminalBorder),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(etf.shortName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1.2f))
                    Text("${etf.price}", fontSize = 11.sp, color = CyanTerminal, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(
                        "${if (etf.changePercent >= 0) "+" else ""}${etf.changePercent}%",
                        fontSize = 11.sp,
                        color = if (etf.changePercent >= 0) PriceUpGreen else PriceDownRed,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${etf.trackingErrorPct}%", fontSize = 10.sp, color = GoldTerminal, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("${etf.managementFee}%", fontSize = 10.sp, color = TextSecondary, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("${etf.managementFee + etf.custodyFee + 0.10}%", fontSize = 10.sp, color = PurpleTerminal, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.2f))
                }
            }
        }

        // Python Terminal Code Generator Snippet Box
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldTerminal),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Python API 终端交互代码 (PYTHON RESEARCH API SNIPPET)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalBackground)
                            .border(1.dp, TerminalBorder)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = pythonApiSnippet,
                            fontSize = 10.sp,
                            color = PriceUpGreen,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
