package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TerminalDarkColorScheme = darkColorScheme(
    primary = CyanTerminal,
    onPrimary = Color.Black,
    primaryContainer = TerminalSurfaceVariant,
    onPrimaryContainer = CyanTerminal,
    secondary = GoldTerminal,
    onSecondary = Color.Black,
    secondaryContainer = TerminalSurfaceVariant,
    onSecondaryContainer = GoldTerminal,
    tertiary = PurpleTerminal,
    background = TerminalBackground,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder,
    outlineVariant = TerminalBorderHighlight
)

@Composable
fun HuafundTerminalTheme(
    darkTheme: Boolean = true, // Force Dark Institutional Terminal Theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalDarkColorScheme,
        typography = Typography,
        content = content
    )
}
