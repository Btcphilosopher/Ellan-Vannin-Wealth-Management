package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticMarketEngine
import com.example.data.models.EtfItem
import com.example.ui.theme.*

data class AiMessage(
    val id: String,
    val sender: String, // "USER" or "HUAFUND_AI"
    val text: String,
    val timestamp: String
)

@Composable
fun HuafundAiScreen(
    selectedEtf: EtfItem?,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    val messages = remember {
        mutableStateListOf(
            AiMessage(
                id = "m1",
                sender = "HUAFUND_AI",
                text = SyntheticMarketEngine.askHuafundAi("欢迎使用华基AI机构级助手"),
                timestamp = "09:42"
            )
        )
    }

    fun handleSend(query: String) {
        if (query.isBlank()) return
        val userMsg = AiMessage("u_${System.currentTimeMillis()}", "USER", query, "09:43")
        messages.add(userMsg)

        val aiResponse = SyntheticMarketEngine.askHuafundAi(query)
        val aiMsg = AiMessage("a_${System.currentTimeMillis()}", "HUAFUND_AI", aiResponse, "09:43")
        messages.add(aiMsg)
        inputText = ""
        keyboardController?.hide()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp)
    ) {
        // AI Title Header
        Card(
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, PurpleTerminal),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI Icon",
                    tint = PurpleTerminal,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "华基 AI 机构级 ETF 助手 (HUAFUND AI ASSISTANT)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PurpleTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "当前聚焦标的: ${selectedEtf?.name ?: "沪深300ETF"} (${selectedEtf?.fundId ?: "510300"}) | 数据可追溯至交易所源头",
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Preset Prompt Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val presets = listOf(
                "为什么这只 ETF 今天折价？",
                "分析套利成本与净收益",
                "一二级申赎 PCF 篮子分析",
                "组合持仓穿透检测"
            )
            presets.forEach { preset ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(TerminalSurfaceVariant, RoundedCornerShape(3.dp))
                        .border(1.dp, TerminalBorder)
                        .clickable { handleSend(preset) }
                        .padding(vertical = 4.dp, horizontal = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = preset,
                        fontSize = 9.sp,
                        color = GoldTerminal,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Chat Conversation Stream
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                val isAi = msg.sender == "HUAFUND_AI"
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isAi) TerminalSurface else TerminalSurfaceVariant
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isAi) PurpleTerminal.copy(alpha = 0.5f) else CyanTerminal.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isAi) "华基 AI 机构推理引擎" else "机构交易员",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isAi) PurpleTerminal else CyanTerminal
                            )
                            Text(
                                text = msg.timestamp,
                                fontSize = 9.sp,
                                color = TextMuted
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = msg.text,
                            fontSize = 11.sp,
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Input Field Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("向华基 AI 提问 (例: 为什么折价? 套利风险? 申赎成本?)", fontSize = 10.sp, color = TextMuted) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PurpleTerminal,
                    unfocusedBorderColor = TerminalBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_input_field"),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { handleSend(inputText) })
            )

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = { handleSend(inputText) },
                modifier = Modifier
                    .size(44.dp)
                    .background(PurpleTerminal, RoundedCornerShape(4.dp))
                    .testTag("ai_send_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = Color.Black
                )
            }
        }
    }
}
