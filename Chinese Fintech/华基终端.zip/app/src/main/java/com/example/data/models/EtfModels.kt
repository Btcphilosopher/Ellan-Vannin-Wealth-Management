package com.example.data.models

import androidx.compose.ui.graphics.Color

// User Workstation Persona Role
enum class WorkstationRole(val title: String, val desc: String) {
    FUND_MANAGER("ETF基金经理", "组合/NAV/IOPV/PCF/申赎/风险"),
    MARKET_MAKER("ETF做市商", "盘口/Spread/库存/对冲/PnL"),
    ARBITRAGE_TRADER("ETF套利交易员", "折溢价/IOPV/PCF/一二级市场成本/一键套利"),
    RESEARCHER("ETF量化研究员", "指数/因子/资金流/穿透/重叠分析"),
    RISK_MANAGER("ETF风险经理", "VaR/ES/流动性/跟踪误差/压力测试")
}

// Asset Classification
enum class EtfAssetClass(val label: String) {
    BROAD_BASE("宽基ETF"),
    SECTOR("行业ETF"),
    THEMATIC("主题ETF"),
    TECH("科技ETF"),
    GOLD("黄金ETF"),
    COMMODITY("商品ETF"),
    BOND("债券ETF"),
    CROSS_BORDER("跨境ETF"),
    ACTIVE("主动ETF"),
    MONEY_MARKET("货币ETF")
}

enum class DigitalTwinState {
    LIVE, HISTORICAL, REPLAY, FORECAST, SCENARIO
}

// Core ETF Model
data class EtfItem(
    val fundId: String,            // e.g. "510300"
    val ticker: String,            // e.g. "510300.SH"
    val exchange: String,          // "SSE" or "SZSE" or "HKEX"
    val name: String,              // e.g. "华泰柏瑞沪深300ETF"
    val shortName: String,         // e.g. "HUA300"
    val fundManager: String,       // e.g. "华基基金"
    val custodian: String,         // e.g. "中国工商银行"
    val indexId: String,           // e.g. "000300"
    val indexName: String,         // e.g. "沪深300指数"
    val assetClass: EtfAssetClass,
    val isPassive: Boolean = true, // false for Active ETF
    val currency: String = "CNY",
    val listingDate: String = "2012-05-28",
    val managementFee: Double = 0.15, // % per annum
    val custodyFee: Double = 0.05,    // % per annum
    
    // Live Market Data
    val price: Double,
    val changePercent: Double,
    val prevClose: Double,
    val open: Double,
    val high: Double,
    val low: Double,
    val volumeShares: Long,
    val amountRmbBn: Double,       // Amount in RMB Billion
    
    // ETF Valuations
    val nav: Double,
    val iopv: Double,
    val premiumDiscountPct: Double, // (Price - IOPV) / IOPV * 100
    val aumBn: Double,              // AUM in RMB Billion
    val totalSharesBn: Double,
    val dailyNetFlowMb: Double,     // Daily Net Creation/Redemption Flow in RMB Million
    
    // Performance & Risk Metrics
    val trackingErrorPct: Double,  // 20D Rolling Tracking Error
    val trackingDifferencePct: Double,
    val liquidityScore: String = "AAA", // AAA, AA, A, B
    val bidPrice: Double,
    val askPrice: Double,
    val bidSize: Long,
    val askSize: Long,
    
    // Active ETF specific
    val activeShare: Double = 0.0,
    val alphaPct: Double = 0.0,
    val beta: Double = 1.0,
    
    // Primary Market Creation Unit
    val creationUnitSize: Long = 1000000L, // e.g. 1 Million shares
    val creationCostRatePct: Double = 0.12,
    val redemptionCostRatePct: Double = 0.12
)

// PCF Component Detail
data class PcfComponent(
    val securityCode: String,
    val securityName: String,
    val quantity: Long,
    val weightPct: Double,
    val price: Double,
    val marketValueRmb: Double,
    val cashSubstituteType: String, // "允许", "必须", "禁止"
    val cashSubstitutePremiumPct: Double = 0.0,
    val isSuspended: Boolean = false
)

// Portfolio Composition File (PCF)
data class PcfFile(
    val fundId: String,
    val tradeDate: String,
    val version: String, // "V1", "V2", "V3"
    val components: List<PcfComponent>,
    val cashComponentRmb: Double,
    val cashSubstituteRmb: Double,
    val estimatedCashRmb: Double,
    val creationUnitSize: Long,
    val redemptionUnitSize: Long,
    val timestamp: String,
    val isApproved: Boolean = true
)

data class PcfDiff(
    val fundId: String,
    val compareDate: String,
    val addedComponents: List<PcfComponent>,
    val removedComponents: List<PcfComponent>,
    val quantityChangedCount: Int,
    val weightChangedCount: Int,
    val cashComponentDeltaRmb: Double
)

// Index Model & Constituents
data class IndexItem(
    val indexId: String,
    val name: String,
    val provider: String,
    val baseDate: String,
    val baseValue: Double,
    val currentValue: Double,
    val changePct: Double,
    val rebalanceFrequency: String,
    val constituents: List<IndexConstituent>
)

data class IndexConstituent(
    val code: String,
    val name: String,
    val weightPct: Double,
    val price: Double,
    val changePct: Double,
    val marketCapBn: Double,
    val sector: String,
    val contributionPts: Double
)

// Market Making L2 Depth & Inventory
data class OrderBookLevel(
    val bidPrice: Double,
    val bidSize: Long,
    val askPrice: Double,
    val askSize: Long
)

data class MarketMakingQuote(
    val etfId: String,
    val depth: List<OrderBookLevel>,
    val spreadBps: Double,
    val inventoryShares: Long,
    val maxInventoryShares: Long = 5000000L,
    val hedgePositionShares: Long,
    val quoteRatioPct: Double,
    val fillRatioPct: Double,
    val pnlTodayRmb: Double,
    val inventoryRiskLevel: String = "NORMAL" // NORMAL, HIGH, WARNING
)

// Arbitrage Opportunity Matrix
data class ArbitrageOpportunity(
    val etfId: String,
    val etfName: String,
    val marketPrice: Double,
    val iopv: Double,
    val nav: Double,
    val grossArbitragePct: Double, // (Price - IOPV) / IOPV
    val creationCostPct: Double,
    val redemptionCostPct: Double,
    val tradingCommissionPct: Double = 0.03,
    val marketImpactPct: Double = 0.05,
    val cashSubstituteCostPct: Double = 0.02,
    val netArbitragePct: Double,
    val isDiscountArb: Boolean, // True = Discount (Buy ETF, Redeem basket); False = Premium (Buy Basket, Create ETF)
    val recommendedAction: String,
    val estimatedProfitRmb: Double
)

// Multi-ETF Portfolio Look-Through
data class PortfolioPosition(
    val etfId: String,
    val etfName: String,
    val weightPct: Double,
    val totalValueRmb: Double
)

data class LookThroughConstituent(
    val stockCode: String,
    val stockName: String,
    val totalEffectiveWeightPct: Double,
    val totalMarketValueRmb: Double,
    val sector: String,
    val heldInEtfs: List<String>
)

data class OverlapDetail(
    val etfAId: String,
    val etfAName: String,
    val etfBId: String,
    val etfBName: String,
    val sharedConstituentCount: Int,
    val weightOverlapPct: Double,
    val jaccardSimilarityPct: Double,
    val correlation: Double
)

// Risk Matrix & Stress Testing
data class RiskSnapshot(
    val var95DailyPct: Double,       // 95% 1-day Value at Risk %
    val expectedShortfallPct: Double, // ES 97.5%
    val rollingBeta: Double,
    val trackingRiskPct: Double,
    val liquidityScore: String,
    val maxDrawdownPct: Double,
    val fxExposurePct: Double = 0.0,
    val alerts: List<String>
)

data class StressTestScenario(
    val name: String,
    val marketMovePct: Double,
    val fxMovePct: Double,
    val liquidityDropPct: Double,
    val estimatedEtfPnlPct: Double,
    val estimatedPortfolioLossRmb: Double
)

// News & Announcements
data class EtfNews(
    val id: String,
    val title: String,
    val source: String,
    val category: String, // "ETF", "指数", "申赎清单", "宏观", "交易所"
    val timestamp: String,
    val summary: String,
    val relatedEtfId: String? = null,
    val isUrgent: Boolean = false
)
