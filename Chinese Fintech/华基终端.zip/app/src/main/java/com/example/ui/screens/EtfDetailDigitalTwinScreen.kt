package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticMarketEngine
import com.example.data.models.DigitalTwinState
import com.example.data.models.EtfItem
import com.example.ui.components.StatCard
import com.example.ui.components.ThreeLineCanvasChart
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun EtfDetailDigitalTwinScreen(
    etf: EtfItem,
    modifier: Modifier = Modifier
) {
    var twinState by remember { mutableStateOf(DigitalTwinState.LIVE) }
    var selectedScenario by remember { mutableStateOf<String?>(null) }

    // Historical price points for 3-line chart
    val priceHistory = remember(etf.fundId, etf.price) {
        listOf(
            etf.prevClose,
            etf.open,
            etf.low,
            (etf.low + etf.high) / 2.0,
            etf.high * 0.99,
            etf.price
        )
    }
    val navHistory = remember(etf.fundId, etf.nav) {
        listOf(
            etf.nav - 0.02,
            etf.nav - 0.015,
            etf.nav - 0.01,
            etf.nav - 0.005,
            etf.nav - 0.002,
            etf.nav
        )
    }
    val iopvHistory = remember(etf.fundId, etf.iopv) {
        listOf(
            etf.iopv - 0.018,
            etf.iopv - 0.012,
            etf.iopv - 0.008,
            etf.iopv - 0.003,
            etf.iopv - 0.001,
            etf.iopv
        )
    }

    val risk = remember(etf) { SyntheticMarketEngine.calculateRisk(etf) }
    val arb = remember(etf) { SyntheticMarketEngine.evaluateArbitrage(etf) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Ticker Bar Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanTerminal),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = etf.name,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = etf.ticker,
                                    fontSize = 11.sp,
                                    color = GoldTerminal,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Text(
                                text = "管理人: ${etf.fundManager} | 托管人: ${etf.custodian} | 跟踪指数: ${etf.indexName}",
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }

                        // Digital Twin State Pill
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            DigitalTwinState.values().take(3).forEach { state ->
                                val isSel = state == twinState
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (isSel) CyanTerminal.copy(alpha = 0.25f) else TerminalSurfaceVariant,
                                            RoundedCornerShape(3.dp)
                                        )
                                        .border(1.dp, if (isSel) CyanTerminal else TerminalBorder)
                                        .clickable { twinState = state }
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = state.name,
                                        fontSize = 9.sp,
                                        color = if (isSel) CyanTerminal else TextSecondary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // 4 Core Valuations Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatCard(
                            title = "最新价 (Market Price)",
                            value = String.format(Locale.CHINA, "%.3f", etf.price),
                            subValue = String.format(Locale.CHINA, "%s%.2f%%", if (etf.changePercent >= 0) "+" else "", etf.changePercent),
                            valueColor = CyanTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "官方净值 (NAV)",
                            value = String.format(Locale.CHINA, "%.3f", etf.nav),
                            subValue = "昨日收盘正式结算",
                            valueColor = PurpleTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "实时参考估值 (IOPV)",
                            value = String.format(Locale.CHINA, "%.3f", etf.iopv),
                            subValue = "成分股笔笔实时推算",
                            valueColor = GoldTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "折溢价率 (Prem/Disc)",
                            value = String.format(Locale.CHINA, "%s%.2f%%", if (etf.premiumDiscountPct >= 0) "+" else "", etf.premiumDiscountPct),
                            subValue = if (etf.premiumDiscountPct >= 0) "二级市场溢价" else "二级市场折价",
                            valueColor = if (etf.premiumDiscountPct >= 0) PriceUpGreen else PriceDownRed,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Three Line Chart Section (Price vs IOPV vs NAV)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ETF 三线拟合图 (Market Price vs IOPV vs NAV)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanTerminal,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(CyanTerminal)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Market Price", fontSize = 9.sp, color = TextSecondary)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(GoldTerminal)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("IOPV", fontSize = 9.sp, color = TextSecondary)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(PurpleTerminal)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("NAV", fontSize = 9.sp, color = TextSecondary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    ThreeLineCanvasChart(
                        prices = priceHistory,
                        navs = navHistory,
                        iopvs = iopvHistory
                    )
                }
            }
        }

        // Active ETF metrics if active
        if (!etf.isPassive) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PurpleTerminal),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "主动管理 ETF 核心指标 (ACTIVE MANAGEMENT METRICS)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PurpleTerminal,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "Alpha超额收益: +${etf.alphaPct}%",
                                fontSize = 11.sp,
                                color = PriceUpGreen,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "Beta因子: ${etf.beta}",
                                fontSize = 11.sp,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "Active Share(主动差异度): ${etf.activeShare}%",
                                fontSize = 11.sp,
                                color = GoldTerminal,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Risk & Arbitrage Summary Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            "跟踪误差 & 风险矩阵",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldTerminal
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "20日滚动跟踪误差: ${etf.trackingErrorPct}%",
                            fontSize = 10.sp,
                            color = TextPrimary
                        )
                        Text(
                            "日度 95% VaR: ${risk.var95DailyPct}%",
                            fontSize = 10.sp,
                            color = TextPrimary
                        )
                        Text(
                            "流动性内部分级: ${etf.liquidityScore}",
                            fontSize = 10.sp,
                            color = CyanTerminal,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            "套利精算评估",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanTerminal
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "毛套利空间: ${arb.grossArbitragePct}%",
                            fontSize = 10.sp,
                            color = TextPrimary
                        )
                        Text(
                            "净套利空间(扣除费率): ${arb.netArbitragePct}%",
                            fontSize = 10.sp,
                            color = if (arb.netArbitragePct > 0) PriceUpGreen else TextMuted
                        )
                        Text(
                            "预估可得收益: ¥${arb.estimatedProfitRmb}元",
                            fontSize = 10.sp,
                            color = GoldTerminal,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Scenario Testing Interactive Buttons
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = "ETF 数字孪生压力测试 (SCENARIO LAB)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val scenarios = listOf("沪深300 -10%", "人民币贬值 +3%", "主力成分股停牌", "流动性枯竭")
                        scenarios.forEach { sc ->
                            val isSel = selectedScenario == sc
                            Button(
                                onClick = { selectedScenario = if (isSel) null else sc },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSel) GoldTerminal else TerminalSurfaceVariant,
                                    contentColor = if (isSel) Color.Black else TextPrimary
                                ),
                                shape = RoundedCornerShape(4.dp),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(sc, fontSize = 9.sp, maxLines = 1)
                            }
                        }
                    }

                    if (selectedScenario != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TerminalBackground)
                                .border(1.dp, GoldTerminal)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "【情景模拟输出: $selectedScenario】\n" +
                                        "• 预计 IOPV 偏差: ${if (selectedScenario?.contains("停牌") == true) "0.45% (现金替代锁定)" else "-8.20%"}\n" +
                                        "• 申赎交投市场冲击: 交易成本预计上升 0.18%\n" +
                                        "• 建议风控动作: 提高做市商库存对冲比例至 100%",
                                fontSize = 10.sp,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }
    }
}
