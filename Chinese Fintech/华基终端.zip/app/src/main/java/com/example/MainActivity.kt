package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticMarketEngine
import com.example.data.models.WorkstationRole
import com.example.ui.components.CommandBarDialog
import com.example.ui.components.TerminalHeader
import com.example.ui.screens.*
import com.example.ui.theme.CyanTerminal
import com.example.ui.theme.GoldTerminal
import com.example.ui.theme.HuafundTerminalTheme
import com.example.ui.theme.TerminalBackground
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class NavTab(val label: String, val icon: ImageVector) {
    MARKET("市场总览", Icons.Default.ShowChart),
    ETF_DETAIL("ETF数字孪生", Icons.Default.MonetizationOn),
    PCF("申赎清单", Icons.Default.ReceiptLong),
    ARBITRAGE("做市与套利", Icons.Default.CompareArrows),
    PORTFOLIO("组合穿透", Icons.Default.PieChart),
    RESEARCH("量化研究", Icons.Default.Analytics),
    AI("华基AI", Icons.Default.AutoAwesome)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HuafundTerminalTheme {
                MainWorkstationApp()
            }
        }
    }
}

@Composable
fun MainWorkstationApp() {
    val etfList by SyntheticMarketEngine.etfList.collectAsState()
    val selectedEtf by SyntheticMarketEngine.selectedEtf.collectAsState()
    val activeRole by SyntheticMarketEngine.activeRole.collectAsState()

    var currentTab by remember { mutableStateOf(NavTab.MARKET) }
    var isCommandBarOpen by remember { mutableStateOf(false) }

    // Start high-speed market tick updates
    LaunchedEffect(Unit) {
        SyntheticMarketEngine.marketTickFlow().collect {
            // Flow triggers recomposition of live tick prices
        }
    }

    val currentEtfItem = selectedEtf ?: etfList.firstOrNull()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("huafund_main_scaffold"),
        containerColor = TerminalBackground,
        topBar = {
            TerminalHeader(
                activeRole = activeRole,
                onSelectRole = { role ->
                    SyntheticMarketEngine.setRole(role)
                    // Auto-switch tab based on persona
                    when (role) {
                        WorkstationRole.FUND_MANAGER -> currentTab = NavTab.ETF_DETAIL
                        WorkstationRole.MARKET_MAKER -> currentTab = NavTab.ARBITRAGE
                        WorkstationRole.ARBITRAGE_TRADER -> currentTab = NavTab.ARBITRAGE
                        WorkstationRole.RESEARCHER -> currentTab = NavTab.RESEARCH
                        WorkstationRole.RISK_MANAGER -> currentTab = NavTab.PORTFOLIO
                    }
                },
                onOpenCommandBar = { isCommandBarOpen = true }
            )
        },
        bottomBar = {
            // Institutional Bottom Navigation Rail
            NavigationBar(
                containerColor = TerminalSurface,
                contentColor = TextPrimary,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .border(1.dp, TerminalBorder)
            ) {
                NavTab.values().forEach { tab ->
                    val isSel = tab == currentTab
                    NavigationBarItem(
                        selected = isSel,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                tint = if (isSel) CyanTerminal else TextMuted
                            )
                        },
                        label = {
                            Text(
                                text = tab.label,
                                fontSize = 9.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) CyanTerminal else TextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = CyanTerminal.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                NavTab.MARKET -> MarketOverviewScreen(
                    etfList = etfList,
                    onSelectEtf = { fundId ->
                        SyntheticMarketEngine.selectEtf(fundId)
                        currentTab = NavTab.ETF_DETAIL
                    }
                )
                NavTab.ETF_DETAIL -> currentEtfItem?.let {
                    EtfDetailDigitalTwinScreen(etf = it)
                }
                NavTab.PCF -> currentEtfItem?.let {
                    PcfPrimaryMarketScreen(etf = it)
                }
                NavTab.ARBITRAGE -> currentEtfItem?.let {
                    ArbitrageMarketMakingScreen(etf = it)
                }
                NavTab.PORTFOLIO -> PortfolioLookThroughRiskScreen(allEtfs = etfList)
                NavTab.RESEARCH -> ResearchWorkbenchScreen(allEtfs = etfList)
                NavTab.AI -> HuafundAiScreen(selectedEtf = currentEtfItem)
            }
        }

        if (isCommandBarOpen) {
            CommandBarDialog(
                allEtfs = etfList,
                onDismiss = { isCommandBarOpen = false },
                onSelectEtf = { fundId ->
                    SyntheticMarketEngine.selectEtf(fundId)
                    currentTab = NavTab.ETF_DETAIL
                },
                onExecuteCommand = { cmd ->
                    val upper = cmd.trim().uppercase()
                    when {
                        upper.contains("FLOW") || upper.contains("MARKET") -> currentTab = NavTab.MARKET
                        upper.contains("PCF") -> currentTab = NavTab.PCF
                        upper.contains("IOPV") || upper.contains("ETF") -> currentTab = NavTab.ETF_DETAIL
                        upper.contains("ARB") || upper.contains("MM") -> currentTab = NavTab.ARBITRAGE
                        upper.contains("PORT") || upper.contains("RISK") -> currentTab = NavTab.PORTFOLIO
                        upper.contains("RESEARCH") -> currentTab = NavTab.RESEARCH
                        upper.contains("AI") -> currentTab = NavTab.AI
                    }
                }
            )
        }
    }
}
