package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticMarketEngine
import com.example.data.models.EtfItem
import com.example.data.models.PortfolioPosition
import com.example.ui.components.StatCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun PortfolioLookThroughRiskScreen(
    allEtfs: List<EtfItem>,
    modifier: Modifier = Modifier
) {
    // Default 4-ETF Sample Institutional Portfolio
    val positions = remember {
        listOf(
            PortfolioPosition("510300", "华泰柏瑞沪深300ETF", 35.0, 3500000.0),
            PortfolioPosition("513050", "易方达恒生科技ETF", 25.0, 2500000.0),
            PortfolioPosition("588000", "华夏科创50ETF", 20.0, 2000000.0),
            PortfolioPosition("518880", "华安黄金易ETF", 20.0, 2000000.0)
        )
    }

    val lookThroughResults = remember(positions) {
        SyntheticMarketEngine.performLookThrough(positions)
    }

    val totalValRmb = positions.sumOf { it.totalValueRmb }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Portfolio Builder Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanTerminal),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "ETF 组合构建与穿透 (PORTFOLIO LOOK-THROUGH)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "组合总市值: ¥${String.format(Locale.CHINA, "%.2f", totalValRmb / 10000.0)}万元 | 包含 4 只核心 ETF",
                        fontSize = 10.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatCard(
                            title = "沪深300敞口",
                            value = "35.0%",
                            subValue = "宽基核心",
                            valueColor = CyanTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "恒生科技敞口",
                            value = "25.0%",
                            subValue = "跨境科技",
                            valueColor = PurpleTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "科创50敞口",
                            value = "20.0%",
                            subValue = "硬科技",
                            valueColor = GoldTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "黄金现货敞口",
                            value = "20.0%",
                            subValue = "避险资产",
                            valueColor = PriceUpGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Redundant Holding Warning Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurfaceVariant)
                    .border(1.dp, GoldTerminal)
                    .padding(8.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "⚠ 重复持仓风险预警 (REDUNDANT HOLDINGS DETECTED)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldTerminal
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "检测到「腾讯控股 (700.HK)」同时存在于 华泰柏瑞沪深300ETF、恒生科技ETF 与 华基主动精选ETF 中！\n" +
                                "穿透计算实际单一股票有效暴露高达 18.2%！建议评估行业与单一个股集中度风险。",
                        fontSize = 10.sp,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Look-Through Stock Exposure List Title
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = "多层底层股票穿透结果 (UNDERLYING CONSTITUENTS LOOK-THROUGH)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("底层股票", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.5f))
                        Text("行业", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("有效穿透权重", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.1f))
                        Text("穿透等效市值", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.1f))
                        Text("来源 ETF 篮子", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.5f))
                    }
                }
            }
        }

        // Look-Through Table Items
        items(lookThroughResults) { stock ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TerminalBorder),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text(stock.stockName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text(stock.stockCode, fontSize = 9.sp, color = TextMuted, fontFamily = FontFamily.Monospace)
                    }
                    Text(stock.sector, fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                    Text("${stock.totalEffectiveWeightPct}%", fontSize = 11.sp, color = GoldTerminal, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    Text("¥${String.format(Locale.CHINA, "%.0f", stock.totalMarketValueRmb / 10000.0)}万", fontSize = 10.sp, color = CyanTerminal, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1.1f))
                    Text(stock.heldInEtfs.joinToString(", "), fontSize = 9.sp, color = TextMuted, modifier = Modifier.weight(1.5f))
                }
            }
        }
    }
}
