package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticMarketEngine
import com.example.data.models.EtfItem
import com.example.data.models.PcfComponent
import com.example.data.models.PcfFile
import com.example.ui.components.StatCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun PcfPrimaryMarketScreen(
    etf: EtfItem,
    modifier: Modifier = Modifier
) {
    val pcfMap by SyntheticMarketEngine.pcfMap.collectAsState()
    val currentPcf = remember(etf, pcfMap) {
        pcfMap[etf.fundId] ?: PcfFile(
            fundId = etf.fundId,
            tradeDate = "2026-10-05",
            version = "V1",
            cashComponentRmb = 120000.0,
            cashSubstituteRmb = 85000.0,
            estimatedCashRmb = 135000.0,
            creationUnitSize = etf.creationUnitSize,
            redemptionUnitSize = etf.creationUnitSize,
            timestamp = "09:15:00",
            components = listOf(
                PcfComponent("600519", "贵州茅台", 300, 5.82, 1680.0, 504000.0, "允许", 0.5),
                PcfComponent("300750", "宁德时代", 1500, 3.45, 198.5, 297750.0, "允许", 0.5),
                PcfComponent("601318", "中国平安", 5200, 2.91, 48.2, 250640.0, "允许", 0.0),
                PcfComponent("000858", "五粮液", 1100, 1.88, 142.1, 156310.0, "允许", 0.0),
                PcfComponent("600036", "招商银行", 5500, 2.15, 33.6, 184800.0, "允许", 0.0),
                PcfComponent("002594", "比亚迪", 600, 1.72, 245.0, 147000.0, "禁止", 0.0)
            )
        )
    }

    var selectedVersion by remember { mutableStateOf("V1") }
    var creationUnitInput by remember { mutableStateOf("1") } // 1 unit
    var isCreationMode by remember { mutableStateOf(true) } // true = Creation, false = Redemption

    val units = creationUnitInput.toLongOrNull() ?: 1L
    val simulatedBasketValRmb = remember(units, etf, currentPcf) {
        units * etf.creationUnitSize * etf.iopv
    }
    val simulatedCreationFee = remember(simulatedBasketValRmb, etf) {
        simulatedBasketValRmb * (etf.creationCostRatePct / 100.0)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Header Info & Version Picker
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanTerminal),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "PCF 申购赎回清单 (PORTFOLIO COMPOSITION FILE)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanTerminal,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "标的: ${etf.name} (${etf.ticker}) | 交易日: ${currentPcf.tradeDate} | 发布时间: ${currentPcf.timestamp}",
                                fontSize = 10.sp,
                                color = TextMuted
                            )
                        }

                        // Version selector V1, V2, V3
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("V1", "V2", "V3").forEach { ver ->
                                val isSel = ver == selectedVersion
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (isSel) GoldTerminal.copy(alpha = 0.25f) else TerminalSurfaceVariant,
                                            RoundedCornerShape(3.dp)
                                        )
                                        .border(1.dp, if (isSel) GoldTerminal else TerminalBorder)
                                        .clickable { selectedVersion = ver }
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = ver,
                                        fontSize = 10.sp,
                                        color = if (isSel) GoldTerminal else TextSecondary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Key PCF Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatCard(
                            title = "最小申赎单位 (Creation Unit)",
                            value = "${currentPcf.creationUnitSize / 10000}万份",
                            subValue = "1个篮子基准",
                            valueColor = GoldTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "预估现金部分 (Est Cash)",
                            value = String.format(Locale.CHINA, "¥%.2f万", currentPcf.cashComponentRmb / 10000.0),
                            subValue = "退补款项结算",
                            valueColor = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "现金替代总额 (Cash Substitute)",
                            value = String.format(Locale.CHINA, "¥%.2f万", currentPcf.cashSubstituteRmb / 10000.0),
                            subValue = "替代溢价: 0.50%",
                            valueColor = CyanTerminal,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Primary Creation/Redemption Simulator Input Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldTerminal),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "一级市场申购/赎回模拟器 (CREATE / REDEEM SIMULATOR)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Toggle Mode (申购 vs 赎回)
                        Row(modifier = Modifier.weight(1f)) {
                            Button(
                                onClick = { isCreationMode = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isCreationMode) PriceUpGreen else TerminalSurfaceVariant
                                ),
                                shape = RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("申购 (Creation)", fontSize = 10.sp, color = if (isCreationMode) Color.Black else TextPrimary)
                            }
                            Button(
                                onClick = { isCreationMode = false },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (!isCreationMode) PriceDownRed else TerminalSurfaceVariant
                                ),
                                shape = RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("赎回 (Redemption)", fontSize = 10.sp, color = if (!isCreationMode) Color.White else TextPrimary)
                            }
                        }

                        OutlinedTextField(
                            value = creationUnitInput,
                            onValueChange = { creationUnitInput = it },
                            label = { Text("申赎单位数 (Creation Units)", fontSize = 9.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("pcf_units_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldTerminal,
                                unfocusedBorderColor = TerminalBorder
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalSurfaceVariant)
                            .border(1.dp, TerminalBorder)
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(
                                text = "【模拟结算交收结果】",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanTerminal
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "• 拟${if (isCreationMode) "交付" else "接收"}组合证券总市值: ¥${String.format(Locale.CHINA, "%.2f", simulatedBasketValRmb / 10000.0)}万元\n" +
                                        "• 预估现金差额退补: ¥${String.format(Locale.CHINA, "%.2f", (currentPcf.cashComponentRmb * units) / 10000.0)}万元\n" +
                                        "• 预估经手费与申赎成本: ¥${String.format(Locale.CHINA, "%.2f", simulatedCreationFee)}元 (${etf.creationCostRatePct}%)\n" +
                                        "• 理论套利收益: ${if (isCreationMode) "买入成分股申购 → 二级卖出 ETF" else "二级买入 ETF 赎回 → 卖出成分股"}",
                                fontSize = 10.sp,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // PCF Component Basket Table Title
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TerminalSurface)
                    .padding(6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("成分证券", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.5f))
                Text("代码", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                Text("数量(股)", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                Text("权重", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                Text("现金替代", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.1f))
            }
        }

        // Component Basket Table
        items(currentPcf.components) { comp ->
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TerminalBorder),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(comp.securityName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1.5f))
                    Text(comp.securityCode, fontSize = 10.sp, color = TextSecondary, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("${comp.quantity}", fontSize = 10.sp, color = CyanTerminal, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("${comp.weightPct}%", fontSize = 10.sp, color = GoldTerminal, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(
                        text = "${comp.cashSubstituteType} (${comp.cashSubstitutePremiumPct}%)",
                        fontSize = 10.sp,
                        color = if (comp.cashSubstituteType == "禁止") PriceDownRed else PriceUpGreen,
                        modifier = Modifier.weight(1.1f)
                    )
                }
            }
        }
    }
}
