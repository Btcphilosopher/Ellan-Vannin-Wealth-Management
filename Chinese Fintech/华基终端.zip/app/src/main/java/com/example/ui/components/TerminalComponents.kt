package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.models.EtfItem
import com.example.data.models.OrderBookLevel
import com.example.data.models.WorkstationRole
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TerminalHeader(
    activeRole: WorkstationRole,
    onSelectRole: (WorkstationRole) -> Unit,
    onOpenCommandBar: () -> Unit,
    modifier: Modifier = Modifier
) {
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.CHINA) }
    var currentTime by remember { mutableStateOf(timeFormat.format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            currentTime = timeFormat.format(Date())
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder)
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & Platform Title
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(PriceUpGreen)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "HUAFUND TERMINAL",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanTerminal,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    color = TerminalSurfaceVariant,
                    shape = RoundedCornerShape(4.dp),
                    border = borderStroke(TerminalBorder)
                ) {
                    Text(
                        text = "华基终端 3.7",
                        fontSize = 10.sp,
                        color = GoldTerminal,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Market Clocks & Operational Status
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "上海 $currentTime",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "行情:正常",
                    fontSize = 10.sp,
                    color = PriceUpGreen,
                    modifier = Modifier
                        .background(PriceUpGreen.copy(alpha = 0.15f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "数据:模拟",
                    fontSize = 10.sp,
                    color = GoldTerminal,
                    modifier = Modifier
                        .background(GoldTerminal.copy(alpha = 0.15f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onOpenCommandBar,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("command_bar_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Command Search Bar",
                        tint = CyanTerminal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Role Selector Chips Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            WorkstationRole.values().forEach { role ->
                val isSelected = role == activeRole
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) CyanTerminal.copy(alpha = 0.2f) else TerminalSurfaceVariant)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) CyanTerminal else TerminalBorder
                        )
                        .clickable { onSelectRole(role) }
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = role.title,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) CyanTerminal else TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

private fun borderStroke(color: Color) = androidx.compose.foundation.BorderStroke(1.dp, color)

@Composable
fun StatCard(
    title: String,
    value: String,
    subValue: String? = null,
    valueColor: Color = TextPrimary,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        shape = RoundedCornerShape(4.dp),
        border = borderStroke(TerminalBorder)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(
                text = title,
                fontSize = 10.sp,
                color = TextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = valueColor,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (subValue != null) {
                Spacer(modifier = Modifier.height(1.dp))
                Text(
                    text = subValue,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun ThreeLineCanvasChart(
    prices: List<Double>,
    navs: List<Double>,
    iopvs: List<Double>,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .background(TerminalSurfaceVariant)
            .border(1.dp, TerminalBorder)
    ) {
        if (prices.isEmpty() || navs.isEmpty() || iopvs.isEmpty()) return@Canvas

        val allValues = prices + navs + iopvs
        val minVal = allValues.minOrNull() ?: 1.0
        val maxVal = allValues.maxOrNull() ?: 2.0
        val range = if (maxVal - minVal < 0.0001) 1.0 else maxVal - minVal

        val width = size.width
        val height = size.height

        fun getPoint(index: Int, total: Int, value: Double): Offset {
            val x = (index.toFloat() / (total - 1).coerceAtLeast(1)) * width
            val y = height - (((value - minVal) / range) * height).toFloat()
            return Offset(x, y)
        }

        // Price Line (Cyan)
        val pricePath = Path()
        prices.forEachIndexed { i, p ->
            val pt = getPoint(i, prices.size, p)
            if (i == 0) pricePath.moveTo(pt.x, pt.y) else pricePath.lineTo(pt.x, pt.y)
        }
        drawPath(pricePath, color = CyanTerminal, style = Stroke(width = 3f))

        // IOPV Line (Gold)
        val iopvPath = Path()
        iopvs.forEachIndexed { i, io ->
            val pt = getPoint(i, iopvs.size, io)
            if (i == 0) iopvPath.moveTo(pt.x, pt.y) else iopvPath.lineTo(pt.x, pt.y)
        }
        drawPath(iopvPath, color = GoldTerminal, style = Stroke(width = 2f))

        // NAV Line (Purple)
        val navPath = Path()
        navs.forEachIndexed { i, n ->
            val pt = getPoint(i, navs.size, n)
            if (i == 0) navPath.moveTo(pt.x, pt.y) else navPath.lineTo(pt.x, pt.y)
        }
        drawPath(navPath, color = PurpleTerminal, style = Stroke(width = 2f))
    }
}

@Composable
fun Level2OrderBookTable(
    depth: List<OrderBookLevel>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder)
            .padding(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("档位", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
            Text("买价", fontSize = 10.sp, color = PriceUpGreen, modifier = Modifier.weight(1f))
            Text("买量", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1f))
            Text("卖价", fontSize = 10.sp, color = PriceDownRed, modifier = Modifier.weight(1f))
            Text("卖量", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(4.dp))

        depth.take(5).forEachIndexed { index, lvl ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("${index + 1}", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                Text(
                    String.format(Locale.CHINA, "%.3f", lvl.bidPrice),
                    fontSize = 11.sp,
                    color = PriceUpGreen,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "${lvl.bidSize / 100}手",
                    fontSize = 10.sp,
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    String.format(Locale.CHINA, "%.3f", lvl.askPrice),
                    fontSize = 11.sp,
                    color = PriceDownRed,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "${lvl.askSize / 100}手",
                    fontSize = 10.sp,
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun CommandBarDialog(
    allEtfs: List<EtfItem>,
    onDismiss: () -> Unit,
    onSelectEtf: (String) -> Unit,
    onExecuteCommand: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    val filtered = remember(query, allEtfs) {
        if (query.isBlank()) allEtfs
        else {
            val q = query.trim().lowercase()
            allEtfs.filter {
                it.fundId.contains(q) ||
                        it.ticker.lowercase().contains(q) ||
                        it.name.lowercase().contains(q) ||
                        it.shortName.lowercase().contains(q) ||
                        it.assetClass.label.contains(q)
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalBackground),
            border = borderStroke(CyanTerminal),
            shape = RoundedCornerShape(8.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "HUAFUND COMMAND BAR",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("输入代码/名称/命令 (如: 510300, 黄金, /ARB, /PCF)", fontSize = 11.sp, color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanTerminal,
                        unfocusedBorderColor = TerminalBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("command_input_field"),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        keyboardController?.hide()
                        onExecuteCommand(query)
                        onDismiss()
                    })
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Command Shortcuts
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf("510300", "588000", "518880", "513050", "FLOW", "PCF", "IOPV", "ARB", "RISK").forEach { cmd ->
                        SuggestionChip(
                            onClick = {
                                query = cmd
                                onExecuteCommand(cmd)
                                if (cmd.length == 6 && cmd.all { it.isDigit() }) {
                                    onSelectEtf(cmd)
                                }
                                onDismiss()
                            },
                            label = { Text(cmd, fontSize = 9.sp, color = GoldTerminal) },
                            colors = SuggestionChipDefaults.suggestionChipColors(containerColor = TerminalSurfaceVariant),
                            border = borderStroke(TerminalBorder),
                            modifier = Modifier.height(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text("匹配 ETF 列表 (${filtered.size}):", fontSize = 10.sp, color = TextMuted)

                Spacer(modifier = Modifier.height(4.dp))

                LazyColumn(modifier = Modifier.heightIn(max = 240.dp)) {
                    items(filtered) { etf ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectEtf(etf.fundId)
                                    onDismiss()
                                }
                                .padding(vertical = 6.dp, horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("${etf.shortName} (${etf.fundId})", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                                Text(etf.name, fontSize = 10.sp, color = TextSecondary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${etf.price}", fontSize = 12.sp, color = CyanTerminal, fontFamily = FontFamily.Monospace)
                                Text(
                                    "${if (etf.changePercent >= 0) "+" else ""}${etf.changePercent}%",
                                    fontSize = 10.sp,
                                    color = if (etf.changePercent >= 0) PriceUpGreen else PriceDownRed,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        HorizontalDivider(color = TerminalBorder, thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}
