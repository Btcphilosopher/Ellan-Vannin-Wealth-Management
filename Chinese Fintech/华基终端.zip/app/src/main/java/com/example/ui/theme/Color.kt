package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Institutional Workstation Dark Palette
val TerminalBackground = Color(0xFF090C10)
val TerminalSurface = Color(0xFF111622)
val TerminalSurfaceVariant = Color(0xFF182030)
val TerminalBorder = Color(0xFF232D42)
val TerminalBorderHighlight = Color(0xFF344466)

// Accent Colors
val CyanTerminal = Color(0xFF00E5FF)
val GoldTerminal = Color(0xFFFFB300)
val AmberGlow = Color(0xFFFF8F00)
val BlueNeon = Color(0xFF2979FF)
val PurpleTerminal = Color(0xFFB388FF)

// Financial Indicators (Chinese Standard & High Contrast)
val PriceUpGreen = Color(0xFF00E676)      // Green for Up / Long
val PriceDownRed = Color(0xFFFF5252)     // Red for Down / Short
val FlatGray = Color(0xFF90A4AE)

// Text Hierarchy
val TextPrimary = Color(0xFFECEFF1)
val TextSecondary = Color(0xFFB0BEC5)
val TextMuted = Color(0xFF607D8B)
val TextGolden = Color(0xFFFFD54F)
