package com.example.data

import com.example.data.models.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sqrt
import kotlin.random.Random

object SyntheticMarketEngine {

    private val _etfList = MutableStateFlow<List<EtfItem>>(emptyList())
    val etfList: StateFlow<List<EtfItem>> = _etfList.asStateFlow()

    private val _selectedEtf = MutableStateFlow<EtfItem?>(null)
    val selectedEtf: StateFlow<EtfItem?> = _selectedEtf.asStateFlow()

    private val _pcfMap = MutableStateFlow<Map<String, PcfFile>>(emptyMap())
    val pcfMap: StateFlow<Map<String, PcfFile>> = _pcfMap.asStateFlow()

    private val _indexMap = MutableStateFlow<Map<String, IndexItem>>(emptyMap())
    val indexMap: StateFlow<Map<String, IndexItem>> = _indexMap.asStateFlow()

    private val _newsList = MutableStateFlow<List<EtfNews>>(emptyList())
    val newsList: StateFlow<List<EtfNews>> = _newsList.asStateFlow()

    private val _activeRole = MutableStateFlow(WorkstationRole.FUND_MANAGER)
    val activeRole: StateFlow<WorkstationRole> = _activeRole.asStateFlow()

    init {
        bootstrapSyntheticData()
    }

    fun setRole(role: WorkstationRole) {
        _activeRole.value = role
    }

    fun selectEtf(fundId: String) {
        _etfList.value.find { it.fundId == fundId || it.ticker.startsWith(fundId) }?.let {
            _selectedEtf.value = it
        }
    }

    private fun bootstrapSyntheticData() {
        // Initial indices
        val indices = mapOf(
            "000300" to IndexItem(
                indexId = "000300",
                name = "沪深300指数",
                provider = "中证指数有限公司",
                baseDate = "2004-12-31",
                baseValue = 1000.0,
                currentValue = 3885.42,
                changePct = 0.54,
                rebalanceFrequency = "每半年",
                constituents = listOf(
                    IndexConstituent("600519", "贵州茅台", 5.82, 1680.0, 0.85, 2110.0, "主要消费", 12.4),
                    IndexConstituent("300750", "宁德时代", 3.45, 198.50, 1.25, 873.0, "工业", 9.1),
                    IndexConstituent("601318", "中国平安", 2.91, 48.20, -0.41, 881.0, "金融", -2.3),
                    IndexConstituent("000858", "五粮液", 1.88, 142.10, 0.32, 551.0, "主要消费", 3.1),
                    IndexConstituent("600036", "招商银行", 2.15, 33.60, 0.15, 847.0, "金融", 1.8),
                    IndexConstituent("002594", "比亚迪", 1.72, 245.0, 2.10, 713.0, "可选消费", 6.8)
                )
            ),
            "588000" to IndexItem(
                indexId = "000688",
                name = "科创50指数",
                provider = "中证指数有限公司",
                baseDate = "2019-12-31",
                baseValue = 1000.0,
                currentValue = 982.15,
                changePct = 1.42,
                rebalanceFrequency = "每季度",
                constituents = listOf(
                    IndexConstituent("688041", "海光信息", 9.85, 82.40, 2.85, 1910.0, "信息技术", 18.2),
                    IndexConstituent("688981", "中芯国际", 8.90, 54.80, 1.62, 4350.0, "信息技术", 14.1),
                    IndexConstituent("688256", "寒武纪", 7.20, 268.0, 3.40, 1110.0, "信息技术", 22.0),
                    IndexConstituent("688008", "澜起科技", 5.10, 68.90, 0.95, 786.0, "信息技术", 8.2)
                )
            ),
            "HUA-GOLD" to IndexItem(
                indexId = "AU9999",
                name = "上海黄金交易所 Au99.99",
                provider = "SGE",
                baseDate = "2002-10-30",
                baseValue = 100.0,
                currentValue = 582.40,
                changePct = 0.28,
                rebalanceFrequency = "无",
                constituents = listOf(
                    IndexConstituent("Au9999", "黄金现货", 100.0, 582.40, 0.28, 15000.0, "大宗商品", 2.8)
                )
            )
        )
        _indexMap.value = indices

        // Initial 12 Flagship Synthetic ETFs
        val etfs = listOf(
            EtfItem(
                fundId = "510300",
                ticker = "510300.SH",
                exchange = "SSE",
                name = "华泰柏瑞沪深300ETF",
                shortName = "HUA300",
                fundManager = "华基基金",
                custodian = "中国工商银行",
                indexId = "000300",
                indexName = "沪深300指数",
                assetClass = EtfAssetClass.BROAD_BASE,
                price = 4.231,
                changePercent = 0.74,
                prevClose = 4.200,
                open = 4.210,
                high = 4.245,
                low = 4.195,
                volumeShares = 567000000L,
                amountRmbBn = 2.40,
                nav = 4.219,
                iopv = 4.225,
                premiumDiscountPct = 0.14, // (4.231 - 4.225)/4.225
                aumBn = 185.50,
                totalSharesBn = 43.84,
                dailyNetFlowMb = 482.50,
                trackingErrorPct = 0.12,
                trackingDifferencePct = -0.08,
                liquidityScore = "AAA",
                bidPrice = 4.230,
                askPrice = 4.232,
                bidSize = 1250000L,
                askSize = 980000L,
                creationUnitSize = 1000000L
            ),
            EtfItem(
                fundId = "510500",
                ticker = "510500.SH",
                exchange = "SSE",
                name = "南方中证500ETF",
                shortName = "HUA500",
                fundManager = "华基基金",
                custodian = "中国建设银行",
                indexId = "000905",
                indexName = "中证500指数",
                assetClass = EtfAssetClass.BROAD_BASE,
                price = 6.128,
                changePercent = -0.15,
                prevClose = 6.137,
                open = 6.140,
                high = 6.160,
                low = 6.110,
                volumeShares = 293000000L,
                amountRmbBn = 1.80,
                nav = 6.141,
                iopv = 6.137,
                premiumDiscountPct = -0.15,
                aumBn = 82.40,
                totalSharesBn = 13.44,
                dailyNetFlowMb = -120.00,
                trackingErrorPct = 0.18,
                trackingDifferencePct = -0.12,
                liquidityScore = "AAA",
                bidPrice = 6.127,
                askPrice = 6.129,
                bidSize = 820000L,
                askSize = 650000L,
                creationUnitSize = 900000L
            ),
            EtfItem(
                fundId = "588000",
                ticker = "588000.SH",
                exchange = "SSE",
                name = "华夏科创50ETF",
                shortName = "HUA-TECH",
                fundManager = "华基基金",
                custodian = "中国银行",
                indexId = "000688",
                indexName = "科创50指数",
                assetClass = EtfAssetClass.TECH,
                price = 1.921,
                changePercent = 1.37,
                prevClose = 1.895,
                open = 1.900,
                high = 1.935,
                low = 1.890,
                volumeShares = 2130000000L,
                amountRmbBn = 4.10,
                nav = 1.905,
                iopv = 1.914,
                premiumDiscountPct = 0.37,
                aumBn = 94.20,
                totalSharesBn = 49.03,
                dailyNetFlowMb = 890.00,
                trackingErrorPct = 0.42,
                trackingDifferencePct = 0.15,
                liquidityScore = "AAA",
                bidPrice = 1.920,
                askPrice = 1.922,
                bidSize = 3500000L,
                askSize = 2800000L,
                creationUnitSize = 1000000L
            ),
            EtfItem(
                fundId = "518880",
                ticker = "518880.SH",
                exchange = "SSE",
                name = "华安黄金易ETF",
                shortName = "HUA-GOLD",
                fundManager = "华基黄金",
                custodian = "招商银行",
                indexId = "AU9999",
                indexName = "SGEAu99.99",
                assetClass = EtfAssetClass.GOLD,
                price = 4.882,
                changePercent = 0.25,
                prevClose = 4.870,
                open = 4.875,
                high = 4.890,
                low = 4.865,
                volumeShares = 245000000L,
                amountRmbBn = 1.20,
                nav = 4.861,
                iopv = 4.870,
                premiumDiscountPct = 0.25,
                aumBn = 28.50,
                totalSharesBn = 5.83,
                dailyNetFlowMb = 145.00,
                trackingErrorPct = 0.08,
                trackingDifferencePct = 0.02,
                liquidityScore = "AA",
                bidPrice = 4.881,
                askPrice = 4.883,
                bidSize = 510000L,
                askSize = 420000L,
                creationUnitSize = 300000L
            ),
            EtfItem(
                fundId = "513050",
                ticker = "513050.SH",
                exchange = "SSE",
                name = "易方达恒生科技ETF",
                shortName = "HUA-HKTECH",
                fundManager = "华基跨境",
                custodian = "交通银行",
                indexId = "HSTECH",
                indexName = "恒生科技指数",
                assetClass = EtfAssetClass.CROSS_BORDER,
                currency = "HKD/CNY",
                price = 0.548,
                changePercent = 2.15,
                prevClose = 0.536,
                open = 0.538,
                high = 0.552,
                low = 0.535,
                volumeShares = 3800000000L,
                amountRmbBn = 2.08,
                nav = 0.541,
                iopv = 0.544,
                premiumDiscountPct = 0.73, // High premium
                aumBn = 18.20,
                totalSharesBn = 33.21,
                dailyNetFlowMb = 310.00,
                trackingErrorPct = 0.65,
                trackingDifferencePct = 0.22,
                liquidityScore = "AAA",
                bidPrice = 0.547,
                askPrice = 0.549,
                bidSize = 8900000L,
                askSize = 7500000L,
                creationUnitSize = 2000000L
            ),
            EtfItem(
                fundId = "513100",
                ticker = "513100.SH",
                exchange = "SSE",
                name = "广发纳斯达克100ETF",
                shortName = "HUA-NASDAQ",
                fundManager = "华基海外",
                custodian = "中国银行",
                indexId = "NDX",
                indexName = "纳斯达克100指数",
                assetClass = EtfAssetClass.CROSS_BORDER,
                currency = "USD/CNY",
                price = 1.482,
                changePercent = 0.88,
                prevClose = 1.469,
                open = 1.472,
                high = 1.488,
                low = 1.470,
                volumeShares = 420000000L,
                amountRmbBn = 0.62,
                nav = 1.468,
                iopv = 1.475,
                premiumDiscountPct = 0.47,
                aumBn = 15.80,
                totalSharesBn = 10.66,
                dailyNetFlowMb = 85.00,
                trackingErrorPct = 0.72,
                trackingDifferencePct = 0.35,
                liquidityScore = "AA",
                bidPrice = 1.481,
                askPrice = 1.483,
                bidSize = 1200000L,
                askSize = 950000L,
                creationUnitSize = 1000000L
            ),
            EtfItem(
                fundId = "510880",
                ticker = "510880.SH",
                exchange = "SSE",
                name = "华泰柏瑞上证红利ETF",
                shortName = "HUA-DIV",
                fundManager = "华基基金",
                custodian = "兴业银行",
                indexId = "000015",
                indexName = "上证红利指数",
                assetClass = EtfAssetClass.THEMATIC,
                price = 3.105,
                changePercent = -0.22,
                prevClose = 3.112,
                open = 3.110,
                high = 3.125,
                low = 3.098,
                volumeShares = 180000000L,
                amountRmbBn = 0.56,
                nav = 3.110,
                iopv = 3.108,
                premiumDiscountPct = -0.09,
                aumBn = 21.40,
                totalSharesBn = 6.89,
                dailyNetFlowMb = 62.00,
                trackingErrorPct = 0.15,
                trackingDifferencePct = -0.05,
                liquidityScore = "AA",
                bidPrice = 3.104,
                askPrice = 3.106,
                bidSize = 600000L,
                askSize = 480000L,
                creationUnitSize = 1000000L
            ),
            EtfItem(
                fundId = "511010",
                ticker = "511010.SH",
                exchange = "SSE",
                name = "国泰5年期国债ETF",
                shortName = "HUA-BOND",
                fundManager = "华基固收",
                custodian = "农业银行",
                indexId = "CBI5Y",
                indexName = "5年期国债指数",
                assetClass = EtfAssetClass.BOND,
                price = 104.250,
                changePercent = 0.04,
                prevClose = 104.210,
                open = 104.220,
                high = 104.260,
                low = 104.200,
                volumeShares = 12000000L,
                amountRmbBn = 1.25,
                nav = 104.240,
                iopv = 104.248,
                premiumDiscountPct = 0.002,
                aumBn = 32.10,
                totalSharesBn = 0.30,
                dailyNetFlowMb = 210.00,
                trackingErrorPct = 0.04,
                trackingDifferencePct = 0.01,
                liquidityScore = "AAA",
                bidPrice = 104.240,
                askPrice = 104.260,
                bidSize = 50000L,
                askSize = 45000L,
                creationUnitSize = 10000L
            ),
            EtfItem(
                fundId = "560000",
                ticker = "560000.SH",
                exchange = "SSE",
                name = "华基主动多因子精选ETF",
                shortName = "HUA-ACTIVE",
                fundManager = "华基基金",
                custodian = "中信银行",
                indexId = "000300",
                indexName = "基准:沪深300",
                assetClass = EtfAssetClass.ACTIVE,
                isPassive = false, // Active ETF!
                price = 1.248,
                changePercent = 1.62,
                prevClose = 1.228,
                open = 1.230,
                high = 1.255,
                low = 1.225,
                volumeShares = 85000000L,
                amountRmbBn = 0.11,
                nav = 1.242,
                iopv = 1.245,
                premiumDiscountPct = 0.24,
                aumBn = 8.50,
                totalSharesBn = 6.81,
                dailyNetFlowMb = 35.00,
                trackingErrorPct = 2.45,
                trackingDifferencePct = 1.82,
                liquidityScore = "A",
                bidPrice = 1.247,
                askPrice = 1.249,
                bidSize = 350000L,
                askSize = 290000L,
                activeShare = 68.5,
                alphaPct = 4.25,
                beta = 0.92,
                creationUnitSize = 500000L
            ),
            EtfItem(
                fundId = "518800",
                ticker = "518800.SH",
                exchange = "SSE",
                name = "国泰白银现货ETF",
                shortName = "HUA-SILVER",
                fundManager = "华基商品",
                custodian = "浦发银行",
                indexId = "AG9999",
                indexName = "SGEAg99.99",
                assetClass = EtfAssetClass.COMMODITY,
                price = 2.150,
                changePercent = -0.92,
                prevClose = 2.170,
                open = 2.165,
                high = 2.175,
                low = 2.140,
                volumeShares = 190000000L,
                amountRmbBn = 0.41,
                nav = 2.155,
                iopv = 2.152,
                premiumDiscountPct = -0.09,
                aumBn = 6.80,
                totalSharesBn = 3.16,
                dailyNetFlowMb = -18.00,
                trackingErrorPct = 0.35,
                trackingDifferencePct = -0.15,
                liquidityScore = "A",
                bidPrice = 2.149,
                askPrice = 2.151,
                bidSize = 400000L,
                askSize = 380000L,
                creationUnitSize = 500000L
            ),
            EtfItem(
                fundId = "512480",
                ticker = "512480.SH",
                exchange = "SSE",
                name = "国泰中证光伏产业ETF",
                shortName = "HUA-SOLAR",
                fundManager = "华基基金",
                custodian = "民生银行",
                indexId = "931151",
                indexName = "中证光伏产业指数",
                assetClass = EtfAssetClass.SECTOR,
                price = 0.892,
                changePercent = 2.41,
                prevClose = 0.871,
                open = 0.875,
                high = 0.901,
                low = 0.872,
                volumeShares = 650000000L,
                amountRmbBn = 0.58,
                nav = 0.888,
                iopv = 0.890,
                premiumDiscountPct = 0.22,
                aumBn = 12.40,
                totalSharesBn = 13.90,
                dailyNetFlowMb = 120.00,
                trackingErrorPct = 0.28,
                trackingDifferencePct = 0.08,
                liquidityScore = "AA",
                bidPrice = 0.891,
                askPrice = 0.893,
                bidSize = 1500000L,
                askSize = 1200000L,
                creationUnitSize = 1000000L
            ),
            EtfItem(
                fundId = "512880",
                ticker = "512880.SH",
                exchange = "SSE",
                name = "国泰中证全指证券公司ETF",
                shortName = "HUA-BROKER",
                fundManager = "华基金融",
                custodian = "中国银行",
                indexId = "399975",
                indexName = "证券公司指数",
                assetClass = EtfAssetClass.SECTOR,
                price = 1.108,
                changePercent = 1.18,
                prevClose = 1.095,
                open = 1.098,
                high = 1.118,
                low = 1.096,
                volumeShares = 1450000000L,
                amountRmbBn = 1.61,
                nav = 1.104,
                iopv = 1.106,
                premiumDiscountPct = 0.18,
                aumBn = 34.60,
                totalSharesBn = 31.22,
                dailyNetFlowMb = 230.00,
                trackingErrorPct = 0.22,
                trackingDifferencePct = 0.05,
                liquidityScore = "AAA",
                bidPrice = 1.107,
                askPrice = 1.109,
                bidSize = 3200000L,
                askSize = 2900000L,
                creationUnitSize = 1000000L
            )
        )
        _etfList.value = etfs
        _selectedEtf.value = etfs.first()

        // Bootstrap PCF files for HUA300 (510300)
        val pcf300 = PcfFile(
            fundId = "510300",
            tradeDate = "2026-10-05",
            version = "V1",
            cashComponentRmb = 142850.20,
            cashSubstituteRmb = 89200.0,
            estimatedCashRmb = 155000.0,
            creationUnitSize = 1000000L,
            redemptionUnitSize = 1000000L,
            timestamp = "09:15:00",
            components = listOf(
                PcfComponent("600519", "贵州茅台", 300, 5.82, 1680.0, 504000.0, "允许", 0.5),
                PcfComponent("300750", "宁德时代", 1500, 3.45, 198.5, 297750.0, "允许", 0.5),
                PcfComponent("601318", "中国平安", 5200, 2.91, 48.2, 250640.0, "允许", 0.0),
                PcfComponent("000858", "五粮液", 1100, 1.88, 142.1, 156310.0, "允许", 0.0),
                PcfComponent("600036", "招商银行", 5500, 2.15, 33.6, 184800.0, "允许", 0.0),
                PcfComponent("002594", "比亚迪", 600, 1.72, 245.0, 147000.0, "禁止", 0.0)
            )
        )
        _pcfMap.value = mapOf("510300" to pcf300)

        // Bootstrap News
        _newsList.value = listOf(
            EtfNews("n1", "【华基终端】今日ETF资金流入创月度新高 宽基与科创板获超30亿申购", "上交所", "申赎清单", "09:41", "沪深300与科创50单日一级市场申购净额大幅攀升，一级做市商资金交投活跃。", "510300", true),
            EtfNews("n2", "【指数调整】中证指数公司发布下季度指数定期调整预告 Notice", "中证指数", "指数", "09:37", "预计涉及沪深300指数与中证500指数各30只成分股调换，交易员预估买卖资金流动性冲击。", "510500"),
            EtfNews("n3", "【跨境ETF】恒生科技ETF折溢价率扩大至+0.73% 提示一二级市场套利空间", "华基研究", "ETF", "09:31", "由于港股开盘早盘波动，跨境ETF二级市场溢价走高，建议申赎做市商关注汇率与港股对冲。", "513050"),
            EtfNews("n4", "【黄金ETF】SGE Au99.99突破582元/克 黄金ETF总规模逼近300亿元", "上海黄金交易所", "宏观", "09:26", "黄金现货基差与ETF IOPV保持平稳，溢价率维持在+0.25%区间。", "518880")
        )
    }

    // High frequency simulation stream (1.5s interval ticks)
    fun marketTickFlow(): Flow<Unit> = flow {
        while (true) {
            delay(1500)
            mutateMarketTicks()
            emit(Unit)
        }
    }

    private fun mutateMarketTicks() {
        val currentList = _etfList.value.toMutableList()
        val updatedList = currentList.map { etf ->
            val deltaPct = (Random.nextDouble(-0.08, 0.09)) / 100.0
            val newPrice = round((etf.price * (1.0 + deltaPct)) * 1000.0) / 1000.0
            val newIopv = round((etf.iopv * (1.0 + (deltaPct * 0.95))) * 1000.0) / 1000.0
            val newNav = etf.nav
            val newPremDisc = round(((newPrice - newIopv) / newIopv * 100.0) * 100.0) / 100.0
            val newChange = round((((newPrice - etf.prevClose) / etf.prevClose) * 100.0) * 100.0) / 100.0
            
            etf.copy(
                price = newPrice,
                iopv = newIopv,
                premiumDiscountPct = newPremDisc,
                changePercent = newChange,
                bidPrice = round((newPrice - 0.001) * 1000.0) / 1000.0,
                askPrice = round((newPrice + 0.001) * 1000.0) / 1000.0,
                volumeShares = etf.volumeShares + Random.nextLong(1000, 50000)
            )
        }
        _etfList.value = updatedList

        // Sync selected ETF if any
        _selectedEtf.value?.let { selected ->
            updatedList.find { it.fundId == selected.fundId }?.let {
                _selectedEtf.value = it
            }
        }
    }

    // Arbitrage Opportunity Evaluator
    fun evaluateArbitrage(etf: EtfItem): ArbitrageOpportunity {
        val premDiscPct = etf.premiumDiscountPct
        val grossArb = premDiscPct / 100.0
        val creationCost = etf.creationCostRatePct / 100.0
        val redemptionCost = etf.redemptionCostRatePct / 100.0
        val tradingComm = 0.0003
        val marketImpact = 0.0005
        val cashSubstituteCost = 0.0002

        val totalCost = if (grossArb > 0) {
            creationCost + tradingComm + marketImpact + cashSubstituteCost
        } else {
            redemptionCost + tradingComm + marketImpact + cashSubstituteCost
        }

        val netArb = if (grossArb > 0) grossArb - totalCost else grossArb + totalCost
        val isDiscount = grossArb < 0

        val estProfitRmb = abs(netArb) * (etf.creationUnitSize * etf.price)

        val rec = when {
            netArb > 0.0015 -> "一二级市场溢价套利：买入成分股篮子 → 申购ETF → 二级市场卖出"
            netArb < -0.0015 -> "一二级市场折价套利：二级市场买入ETF → 一级市场赎回 → 卖出成分股"
            else -> "套利空间被交易与申赎成本覆盖，暂无无风险套利空间 (Observe)"
        }

        return ArbitrageOpportunity(
            etfId = etf.fundId,
            etfName = etf.name,
            marketPrice = etf.price,
            iopv = etf.iopv,
            nav = etf.nav,
            grossArbitragePct = round(grossArb * 10000.0) / 100.0,
            creationCostPct = round(creationCost * 10000.0) / 100.0,
            redemptionCostPct = round(redemptionCost * 10000.0) / 100.0,
            netArbitragePct = round(netArb * 10000.0) / 100.0,
            isDiscountArb = isDiscount,
            recommendedAction = rec,
            estimatedProfitRmb = round(estProfitRmb)
        )
    }

    // Market Making Quote Generator
    fun getMarketMakingQuote(etf: EtfItem): MarketMakingQuote {
        val basePrice = etf.price
        val depth = (1..5).map { level ->
            OrderBookLevel(
                bidPrice = round((basePrice - 0.001 * level) * 1000.0) / 1000.0,
                bidSize = Random.nextLong(100000, 1500000),
                askPrice = round((basePrice + 0.001 * level) * 1000.0) / 1000.0,
                askSize = Random.nextLong(100000, 1500000)
            )
        }
        val spread = 2.0 // bps
        val invShares = 1850000L
        val hedgeShares = -1800000L

        return MarketMakingQuote(
            etfId = etf.fundId,
            depth = depth,
            spreadBps = spread,
            inventoryShares = invShares,
            hedgePositionShares = hedgeShares,
            quoteRatioPct = 99.8,
            fillRatioPct = 34.2,
            pnlTodayRmb = 185200.0,
            inventoryRiskLevel = "NORMAL"
        )
    }

    // Multi-ETF Look-Through Analyzer
    fun performLookThrough(positions: List<PortfolioPosition>): List<LookThroughConstituent> {
        val stockMap = mutableMapOf<String, LookThroughConstituent>()

        // Fictional stock exposures mapped across ETFs
        positions.forEach { pos ->
            val etfId = pos.etfId
            val etfWeight = pos.weightPct / 100.0
            val etfVal = pos.totalValueRmb

            val constituents = when (etfId) {
                "510300" -> listOf(
                    Triple("600519", "贵州茅台", 0.0582 to "主要消费"),
                    Triple("300750", "宁德时代", 0.0345 to "工业"),
                    Triple("700.HK", "腾讯控股", 0.0800 to "信息技术"),
                    Triple("601318", "中国平安", 0.0291 to "金融")
                )
                "513050" -> listOf(
                    Triple("700.HK", "腾讯控股", 0.0800 to "信息技术"),
                    Triple("9988.HK", "阿里巴巴", 0.0820 to "可选消费"),
                    Triple("3690.HK", "美团", 0.0750 to "可选消费")
                )
                "560000" -> listOf(
                    Triple("700.HK", "腾讯控股", 0.0400 to "信息技术"),
                    Triple("600519", "贵州茅台", 0.0350 to "主要消费"),
                    Triple("688041", "海光信息", 0.0500 to "信息技术")
                )
                else -> listOf(
                    Triple("600519", "贵州茅台", 0.0200 to "主要消费"),
                    Triple("300750", "宁德时代", 0.0300 to "工业")
                )
            }

            constituents.forEach { (code, name, pair) ->
                val (stockWeightInEtf, sector) = pair
                val effectiveWeightPct = etfWeight * stockWeightInEtf * 100.0
                val effectiveValRmb = etfVal * stockWeightInEtf

                val existing = stockMap[code]
                if (existing == null) {
                    stockMap[code] = LookThroughConstituent(
                        stockCode = code,
                        stockName = name,
                        totalEffectiveWeightPct = round(effectiveWeightPct * 100.0) / 100.0,
                        totalMarketValueRmb = round(effectiveValRmb),
                        sector = sector,
                        heldInEtfs = listOf(pos.etfName)
                    )
                } else {
                    stockMap[code] = existing.copy(
                        totalEffectiveWeightPct = round((existing.totalEffectiveWeightPct + effectiveWeightPct) * 100.0) / 100.0,
                        totalMarketValueRmb = round(existing.totalMarketValueRmb + effectiveValRmb),
                        heldInEtfs = existing.heldInEtfs + pos.etfName
                    )
                }
            }
        }

        return stockMap.values.sortedByDescending { it.totalEffectiveWeightPct }
    }

    // Portfolio Overlap Finder
    fun computeOverlap(etfA: EtfItem, etfB: EtfItem): OverlapDetail {
        val overlapPct = when {
            etfA.fundId == "510300" && etfB.fundId == "560000" -> 34.2
            etfA.fundId == "510300" && etfB.fundId == "510500" -> 8.5
            etfA.assetClass == etfB.assetClass -> 62.0
            else -> 12.4
        }
        val jaccard = overlapPct / (100.0 + 100.0 - overlapPct) * 100.0

        return OverlapDetail(
            etfAId = etfA.fundId,
            etfAName = etfA.name,
            etfBId = etfB.fundId,
            etfBName = etfB.name,
            sharedConstituentCount = if (overlapPct > 30) 42 else 12,
            weightOverlapPct = overlapPct,
            jaccardSimilarityPct = round(jaccard * 10.0) / 10.0,
            correlation = round((0.4 + (overlapPct / 200.0)) * 100.0) / 100.0
        )
    }

    // Risk Snapshot
    fun calculateRisk(etf: EtfItem): RiskSnapshot {
        val var95 = round((etf.trackingErrorPct * 1.645 + 1.2) * 100.0) / 100.0
        val es = round((var95 * 1.25) * 100.0) / 100.0
        val alerts = mutableListOf<String>()

        if (abs(etf.premiumDiscountPct) > 0.3) {
            alerts.add("⚠ 折溢价率绝对值为 ${etf.premiumDiscountPct}%，超过0.30%预警线")
        }
        if (etf.trackingErrorPct > 0.5) {
            alerts.add("⚠ 20日滚动跟踪误差为 ${etf.trackingErrorPct}%，高于同类均值")
        }
        if (etf.assetClass == EtfAssetClass.CROSS_BORDER) {
            alerts.add("ℹ 跨境资产包含 HKD/USD 汇率敞口与海外交易时差")
        }
        if (alerts.isEmpty()) {
            alerts.add("✓ 核心风险指标均处于正常监控阈值内 (Live Nominal)")
        }

        return RiskSnapshot(
            var95DailyPct = var95,
            expectedShortfallPct = es,
            rollingBeta = etf.beta,
            trackingRiskPct = etf.trackingErrorPct,
            liquidityScore = etf.liquidityScore,
            maxDrawdownPct = round((etf.trackingErrorPct * 4.2 + 8.5) * 10.0) / 10.0,
            fxExposurePct = if (etf.assetClass == EtfAssetClass.CROSS_BORDER) 100.0 else 0.0,
            alerts = alerts
        )
    }

    // AI ETF Assistant Reasoning Query
    fun askHuafundAi(question: String): String {
        val lower = question.lowercase()
        val selected = _selectedEtf.value ?: _etfList.value.first()

        return when {
            "折价" in lower || "溢价" in lower || "discount" in lower || "premium" in lower -> {
                "【华基 AI 机构分析 - 折溢价剖析】\n" +
                        "标的: ${selected.name} (${selected.ticker})\n" +
                        "当前市场价: ${selected.price} 元 | 实时IOPV: ${selected.iopv} 元\n" +
                        "折溢价率: ${if (selected.premiumDiscountPct >= 0) "+" else ""}${selected.premiumDiscountPct}%\n\n" +
                        "数据证据与归因拆解:\n" +
                        "1. 二级市场申赎盘口: 申购买单挂盘 ${selected.bidSize} 份，赎回卖单挂盘 ${selected.askSize} 份，买卖Spread为 2.0 bps。\n" +
                        "2. 成分股替代现金: 今日PCF包含 ${if (selected.fundId=="510300") "6" else "成分股"} 种证券，现金替代占比正常。\n" +
                        "3. 市场做市套利空间: 扣除申购费率(${selected.creationCostRatePct}%)与冲击成本后，净套利空间为 ${evaluateArbitrage(selected).netArbitragePct}%。\n\n" +
                        "结论: ${if (selected.premiumDiscountPct > 0) "二级市场多头情绪主导，溢价微幅收窄中。" else "二级市场呈现微幅折价，做市商正通过买入ETF赎回篮子平抑价差。"}"
            }
            "申赎" in lower || "pcf" in lower || "iopv" in lower -> {
                "【华基 AI 机构分析 - 一级市场与PCF篮子】\n" +
                        "标的: ${selected.name} (${selected.ticker})\n" +
                        "最小申购赎回单位 (Creation Unit): ${selected.creationUnitSize} 份\n" +
                        "当日预估现金部分: 155,000.00 元 | 现金替代溢价率: 0.50%\n\n" +
                        "申赎流程及风险监控:\n" +
                        "• 申购组合证券市值约为 ${(selected.creationUnitSize * selected.iopv / 10000.0).let { String.format("%.2f", it) }} 万元。\n" +
                        "• PCF已发布 V1 版本，成分股交易状态正常，无停牌股票流动性锁死风险。"
            }
            "套利" in lower || "arbitrage" in lower -> {
                val arb = evaluateArbitrage(selected)
                "【华基 AI 机构分析 - 一二级市场套利精算】\n" +
                        "标的: ${arb.etfName} (${arb.etfId})\n" +
                        "理论毛套利空间: ${arb.grossArbitragePct}%\n" +
                        "扣除成本项: 申赎成本(${arb.creationCostPct}%) + 交易佣金(${arb.tradingCommissionPct}%) + 冲击成本(${arb.marketImpactPct}%)\n" +
                        "净套利空间: ${arb.netArbitragePct}%\n" +
                        "策略建议: ${arb.recommendedAction}"
            }
            "穿透" in lower || "重叠" in lower || "look-through" in lower -> {
                "【华基 AI 机构分析 - 组合持仓穿透】\n" +
                        "已完成华基 ETF 宇宙底座成分股穿透：\n" +
                        "示例：若同时持有 HUA300(510300) 与 HUA-HKTECH(513050) 及 华基主动(560000)，系统穿透检测到「腾讯控股 (700.HK)」的总有效穿透暴露占比达 18.2%！\n" +
                        "警示：需注意跨ETF重复持仓集中度风险。"
            }
            else -> {
                "【华基 AI 机构级 ETF 工作站】\n" +
                        "已为您调取标的: ${selected.name} (${selected.ticker}) 实时机构计算看板。\n" +
                        "NAV: ${selected.nav} | IOPV: ${selected.iopv} | 规模: ${selected.aumBn} 亿元 | 20D跟踪误差: ${selected.trackingErrorPct}%\n" +
                        "您可以询问: 『为什么今日折价？』, 『计算申赎PCF成本』, 『进行套利评估』, 『组合持仓穿透检测』。"
            }
        }
    }
}
