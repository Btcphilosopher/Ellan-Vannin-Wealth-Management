package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.EtfAssetClass
import com.example.data.models.EtfItem
import com.example.ui.components.StatCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun MarketOverviewScreen(
    etfList: List<EtfItem>,
    onSelectEtf: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategoryFilter by remember { mutableStateOf<EtfAssetClass?>(null) }

    val filteredEtfs = remember(etfList, selectedCategoryFilter) {
        if (selectedCategoryFilter == null) etfList
        else etfList.filter { it.assetClass == selectedCategoryFilter }
    }

    val totalAumBn = remember(etfList) { etfList.sumOf { it.aumBn } }
    val totalVolumeBn = remember(etfList) { etfList.sumOf { it.amountRmbBn } }
    val netFlowMb = remember(etfList) { etfList.sumOf { it.dailyNetFlowMb } }

    val topGainers = remember(etfList) { etfList.sortedByDescending { it.changePercent }.take(5) }
    val topAum = remember(etfList) { etfList.sortedByDescending { it.aumBn }.take(5) }
    val topFlow = remember(etfList) { etfList.sortedByDescending { it.dailyNetFlowMb }.take(5) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Summary Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatCard(
                    title = "中国ETF总规模",
                    value = String.format(Locale.CHINA, "¥%.2f万亿", totalAumBn / 1000.0),
                    subValue = "统计5,000+标的",
                    valueColor = GoldTerminal,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "当日总成交额",
                    value = String.format(Locale.CHINA, "¥%.1f亿", totalVolumeBn * 10.0),
                    subValue = "沪深交易所",
                    valueColor = CyanTerminal,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "一级申赎净资金流",
                    value = String.format(Locale.CHINA, "%s¥%.1f亿", if (netFlowMb >= 0) "+" else "", netFlowMb / 100.0),
                    subValue = if (netFlowMb >= 0) "资金持续加仓" else "资金流出",
                    valueColor = if (netFlowMb >= 0) PriceUpGreen else PriceDownRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Category Filter Horizontal Row
        item {
            Column {
                Text(
                    text = "ETF 资产分类地图 (ETF MARKET MAP)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanTerminal,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val categories = listOf(null) + EtfAssetClass.values().toList()
                    categories.take(6).forEach { cat ->
                        val isSelected = cat == selectedCategoryFilter
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (isSelected) CyanTerminal.copy(alpha = 0.25f) else TerminalSurface,
                                    RoundedCornerShape(4.dp)
                                )
                                .border(1.dp, if (isSelected) CyanTerminal else TerminalBorder)
                                .clickable { selectedCategoryFilter = cat }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = cat?.label ?: "全部ETF",
                                fontSize = 10.sp,
                                color = if (isSelected) CyanTerminal else TextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Leaderboard Tabs (Top Gainers, Top AUM, Top Flow)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = "资金流 & 规模 TOP50 动态",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("代码/名称", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.5f))
                        Text("最新价", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("涨跌幅", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("IOPV折溢价", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1f))
                        Text("净申购资金", fontSize = 10.sp, color = TextMuted, modifier = Modifier.weight(1.1f))
                    }
                }
            }
        }

        // ETF List Table
        items(filteredEtfs) { etf ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectEtf(etf.fundId) }
                    .testTag("etf_row_${etf.fundId}"),
                colors = CardDefaults.cardColors(containerColor = TerminalSurfaceVariant),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, TerminalBorder),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = etf.shortName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            if (!etf.isPassive) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "主动",
                                    fontSize = 8.sp,
                                    color = PurpleTerminal,
                                    modifier = Modifier
                                        .background(PurpleTerminal.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                                        .padding(horizontal = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "${etf.fundId} | ${etf.assetClass.label}",
                            fontSize = 9.sp,
                            color = TextMuted
                        )
                    }

                    Text(
                        text = String.format(Locale.CHINA, "%.3f", etf.price),
                        fontSize = 12.sp,
                        color = CyanTerminal,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = String.format(Locale.CHINA, "%s%.2f%%", if (etf.changePercent >= 0) "+" else "", etf.changePercent),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (etf.changePercent >= 0) PriceUpGreen else PriceDownRed,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = String.format(Locale.CHINA, "%s%.2f%%", if (etf.premiumDiscountPct >= 0) "+" else "", etf.premiumDiscountPct),
                        fontSize = 11.sp,
                        color = if (etf.premiumDiscountPct >= 0) GoldTerminal else TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = String.format(Locale.CHINA, "%s%.0f万", if (etf.dailyNetFlowMb >= 0) "+" else "", etf.dailyNetFlowMb),
                        fontSize = 10.sp,
                        color = if (etf.dailyNetFlowMb >= 0) PriceUpGreen else PriceDownRed,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1.1f)
                    )
                }
            }
        }
    }
}
