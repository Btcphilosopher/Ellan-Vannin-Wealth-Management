package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SyntheticMarketEngine
import com.example.data.models.EtfItem
import com.example.ui.components.Level2OrderBookTable
import com.example.ui.components.StatCard
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun ArbitrageMarketMakingScreen(
    etf: EtfItem,
    modifier: Modifier = Modifier
) {
    val arb = remember(etf) { SyntheticMarketEngine.evaluateArbitrage(etf) }
    val mmQuote = remember(etf) { SyntheticMarketEngine.getMarketMakingQuote(etf) }

    var isSimulatingExecution by remember { mutableStateOf(false) }
    var executionMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TerminalBackground)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Arbitrage Lab Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanTerminal),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "一二级市场套利精算实验室 (ARBITRAGE LAB)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "标的: ${etf.name} (${etf.ticker}) | 最新市场价: ${etf.price} | IOPV: ${etf.iopv}",
                        fontSize = 10.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Arbitrage Breakdown Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatCard(
                            title = "理论毛套利空间 (Gross)",
                            value = String.format(Locale.CHINA, "%s%.2f%%", if (arb.grossArbitragePct >= 0) "+" else "", arb.grossArbitragePct),
                            subValue = "(Market - IOPV) / IOPV",
                            valueColor = GoldTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "综合摩擦成本 (Costs)",
                            value = String.format(Locale.CHINA, "-%.2f%%", arb.creationCostPct + arb.tradingCommissionPct + arb.marketImpactPct),
                            subValue = "申赎费+佣金+冲击",
                            valueColor = PriceDownRed,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "净套利收益率 (Net Arb)",
                            value = String.format(Locale.CHINA, "%s%.2f%%", if (arb.netArbitragePct >= 0) "+" else "", arb.netArbitragePct),
                            subValue = "已预扣全部摩擦成本",
                            valueColor = if (arb.netArbitragePct > 0) PriceUpGreen else FlatGray,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TerminalSurfaceVariant)
                            .border(1.dp, TerminalBorder)
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(
                                text = "【做市商套利算法精算指令】",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldTerminal
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = arb.recommendedAction,
                                fontSize = 10.sp,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            isSimulatingExecution = true
                            executionMessage = "套利订单已发送模拟器: 【做市一键套利单】成交 1,000,000 份，完成成分股配对与一级申赎申请，实现锁定收益 ¥${arb.estimatedProfitRmb} 元！"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanTerminal, contentColor = Color.Black),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("execute_arbitrage_btn")
                    ) {
                        Text("一键模拟执行套利算法 (Execute Arbitrage Simulation)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    if (executionMessage != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = executionMessage!!,
                            fontSize = 10.sp,
                            color = PriceUpGreen,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Market Making Workstation Header & Level 2 Depth Table
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldTerminal),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "做市商 Level 2 盘口与库存管理 (MARKET MAKING WORKSTATION)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldTerminal,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatCard(
                            title = "买卖价差 (Spread)",
                            value = "${mmQuote.spreadBps} bps",
                            subValue = "双向报价最优区间",
                            valueColor = CyanTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "ETF 头寸库存 (Inventory)",
                            value = "${mmQuote.inventoryShares / 10000}万份",
                            subValue = "上限: ${mmQuote.maxInventoryShares / 10000}万份",
                            valueColor = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "对冲头寸 (Hedge)",
                            value = "${mmQuote.hedgePositionShares / 10000}万股",
                            subValue = "期权/期货/成分股",
                            valueColor = GoldTerminal,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "做市当日PnL",
                            value = String.format(Locale.CHINA, "¥%.1f万", mmQuote.pnlTodayRmb / 10000.0),
                            subValue = "报价+套利+对冲组合",
                            valueColor = PriceUpGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("L2 五档买卖挂单盘口:", fontSize = 11.sp, color = TextMuted)

                    Spacer(modifier = Modifier.height(4.dp))

                    Level2OrderBookTable(depth = mmQuote.depth)
                }
            }
        }
    }
}
