package com.example.terminal.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.data.MarketMasterDatabase
import com.example.terminal.domain.*
import com.example.terminal.ui.components.*
import com.example.ui.theme.*

@Composable
fun QuantFactorScreen(
    state: TerminalUiState,
    onSelectStrategy: (String) -> Unit,
    onSelectStressScenario: (MarketStressScenario) -> Unit,
    modifier: Modifier = Modifier
) {
    val backtest = state.backtestResult
    val scenario = state.selectedStressScenario

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Strategy Selector Tabs
        item {
            Text(
                text = "量化策略回测工作台 // QUANT STRATEGY WORKBENCH",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("红利低波增强策略", "申万行业动量轮动", "北向资金重仓增强").forEach { strat ->
                    val isSelected = strat == state.selectedStrategy
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) TerminalGoldBg else TerminalCardBg)
                            .border(1.dp, if (isSelected) TerminalGold else TerminalBorderSubtle, RoundedCornerShape(6.dp))
                            .clickable { onSelectStrategy(strat) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strat,
                            color = if (isSelected) TerminalGold else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // 2. Cumulative Equity Curve Chart
        item {
            TerminalCard(
                title = "${backtest.config.strategyName} 净值走势 vs 基准",
                testTag = "equity_curve_card"
            ) {
                EquityCurveChart(points = backtest.equityCurve)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(8.dp).background(TerminalGold))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("策略累计: +%.1f%%".format(backtest.totalReturnPct), color = TerminalGold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(8.dp).background(TextMuted))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("基准累计: +%.1f%%".format(backtest.benchmarkReturnPct), color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(8.dp).background(MarketLimitUp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("超额Alpha: +%.1f%%".format(backtest.alphaPct), color = MarketLimitUp, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // 3. Quantitative Risk & Performance Metrics Grid
        item {
            TerminalCard(
                title = "策略风险与业绩归因指标 // RISK & METRICS",
                testTag = "quant_metrics_card"
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricBox("年化收益率", "+%.2f%%".format(backtest.annualizedReturnPct), TerminalGold, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    MetricBox("夏普比率 (Sharpe)", "%.2f".format(backtest.sharpeRatio), TerminalCyan, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    MetricBox("最大回撤 (MaxDD)", "-%.2f%%".format(backtest.maxDrawdownPct), MarketLimitDown, Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricBox("卡玛比率 (Calmar)", "%.2f".format(backtest.calmarRatio), TextPrimary, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    MetricBox("信息比率 (IR)", "%.2f".format(backtest.informationRatio), TextPrimary, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    MetricBox("策略Beta", "%.2f".format(backtest.beta), TextPrimary, Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricBox("月度胜率", "%.1f%%".format(backtest.winRatePct), TextPrimary, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    MetricBox("年化换手率", "%.0f%%".format(backtest.turnoverRateAnnualPct), TextSecondary, Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(6.dp))
                    MetricBox("调仓周期", backtest.config.rebalancePeriod, TextSecondary, Modifier.weight(1f))
                }
            }
        }

        // 4. Macro Stress Test & Liquidity Freeze Laboratory
        item {
            TerminalCard(
                title = "极端市场压力测试实验室 // STRESS TEST LAB",
                testTag = "stress_test_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MarketMasterDatabase.stressScenarios.forEach { s ->
                        val isSel = s.scenarioId == scenario.scenarioId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) Color(0x33EF4444) else TerminalSurfaceVariant)
                                .border(1.dp, if (isSel) MarketUpRed else Color.Transparent, RoundedCornerShape(4.dp))
                                .clickable { onSelectStressScenario(s) }
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.5f)) {
                                Text(s.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(s.description, color = TextMuted, fontSize = 10.sp)
                            }
                            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                Text("指数冲击: %.1f%%".format(s.indexImpactPct), color = MarketLimitDown, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                Text("外资流出: %.0f亿".format(s.northboundOutflowBillion), color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBox(label: String, value: String, valueColor: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(TerminalSurfaceVariant)
            .padding(6.dp)
    ) {
        Column {
            Text(label, color = TextMuted, fontSize = 9.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = valueColor, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun EquityCurveChart(points: List<BacktestPoint>) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .background(TerminalDarkBg)
            .border(0.5.dp, TerminalBorderSubtle, RoundedCornerShape(4.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (points.isEmpty()) return@Canvas
            val width = size.width
            val height = size.height
            val n = points.size

            val maxVal = 70.0f
            val minVal = -10.0f
            val range = maxVal - minVal

            val stratPath = Path()
            val benchPath = Path()

            points.forEachIndexed { i, p ->
                val x = (i.toFloat() / (n - 1).coerceAtLeast(1)) * width
                val yStrat = height - ((p.strategyCumulativeReturn.toFloat() - minVal) / range) * height
                val yBench = height - ((p.benchmarkCumulativeReturn.toFloat() - minVal) / range) * height

                if (i == 0) {
                    stratPath.moveTo(x, yStrat)
                    benchPath.moveTo(x, yBench)
                } else {
                    stratPath.lineTo(x, yStrat)
                    benchPath.lineTo(x, yBench)
                }
            }

            // Draw Benchmark
            drawPath(path = benchPath, color = Color(0xFF64748B), style = Stroke(width = 1.5f))
            // Draw Strategy
            drawPath(path = stratPath, color = TerminalGold, style = Stroke(width = 2.5f))
        }
    }
}
