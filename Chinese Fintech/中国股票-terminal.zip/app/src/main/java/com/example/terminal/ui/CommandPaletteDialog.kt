package com.example.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.terminal.domain.Security
import com.example.terminal.ui.components.SegmentTag
import com.example.ui.theme.*

@Composable
fun CommandPaletteDialog(
    query: String,
    searchResults: List<Security>,
    onQueryChanged: (String) -> Unit,
    onSelectSecurity: (Security) -> Unit,
    onNavigateWorkspace: (TerminalWorkspace) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, TerminalGold, RoundedCornerShape(8.dp))
                .testTag("command_palette_dialog"),
            color = TerminalCardBg
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("全局指令与证券检索 // COMMAND PALETTE (Ctrl+K)", color = TerminalGold, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "关闭", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Search Input Field
                OutlinedTextField(
                    value = query,
                    onValueChange = onQueryChanged,
                    placeholder = { Text("输入代码/简称/拼音 (如 600519/茅台/GZMT) 或指令...", fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TerminalGold) },
                    modifier = Modifier.fillMaxWidth().testTag("command_palette_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalGold,
                        unfocusedBorderColor = TerminalBorder
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Shortcut Command Actions
                Text("快捷工作台导航:", color = TextMuted, fontSize = 10.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        TerminalWorkspace.MARKET_OVERVIEW,
                        TerminalWorkspace.SECURITY_QUOTE,
                        TerminalWorkspace.FUNDAMENTAL_DCF,
                        TerminalWorkspace.QUANT_BACKTEST
                    ).forEach { ws ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceVariant)
                                .clickable {
                                    onNavigateWorkspace(ws)
                                    onDismiss()
                                }
                                .padding(vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(ws.title, color = TerminalCyan, fontSize = 10.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Search Results
                if (searchResults.isNotEmpty()) {
                    Text("匹配证券列表:", color = TextMuted, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 200.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(searchResults) { sec ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TerminalDarkBg)
                                    .clickable {
                                        onSelectSecurity(sec)
                                        onNavigateWorkspace(TerminalWorkspace.SECURITY_QUOTE)
                                        onDismiss()
                                    }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    SegmentTag(sec.exchange.code, color = TerminalCyan)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(sec.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(sec.ticker, color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                }
                                SegmentTag(sec.swIndustryL1, color = TerminalGold)
                            }
                        }
                    }
                }
            }
        }
    }
}
