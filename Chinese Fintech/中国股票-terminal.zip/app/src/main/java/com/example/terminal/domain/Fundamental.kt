package com.example.terminal.domain

data class BalanceSheet(
    val reportPeriod: String, // e.g. "2025年年报"
    val totalAssets: FinancialValue,
    val currentAssets: FinancialValue,
    val cashAndEquivalents: FinancialValue,
    val accountsReceivable: FinancialValue,
    val inventory: FinancialValue,
    val nonCurrentAssets: FinancialValue,
    val fixedAssets: FinancialValue,
    val totalLiabilities: FinancialValue,
    val currentLiabilities: FinancialValue,
    val shortTermBorrowings: FinancialValue,
    val accountsPayable: FinancialValue,
    val nonCurrentLiabilities: FinancialValue,
    val totalEquity: FinancialValue,
    val equityAttributableToParent: FinancialValue,
    val debtToAssetRatio: Double // 资产负债率 %
)

data class IncomeStatement(
    val reportPeriod: String,
    val totalRevenue: FinancialValue,
    val operatingCost: FinancialValue,
    val grossProfit: FinancialValue,
    val grossMarginPct: Double,
    val researchAndDevelopment: FinancialValue,
    val sellingExpenses: FinancialValue,
    val adminExpenses: FinancialValue,
    val financialExpenses: FinancialValue,
    val operatingProfit: FinancialValue,
    val netProfit: FinancialValue,
    val netProfitToParent: FinancialValue,
    val netProfitGrowthYoY: Double,
    val revenueGrowthYoY: Double,
    val roePct: Double,
    val roicPct: Double
)

data class CashFlowStatement(
    val reportPeriod: String,
    val operatingCashFlow: FinancialValue,
    val investingCashFlow: FinancialValue,
    val financingCashFlow: FinancialValue,
    val capitalExpenditure: FinancialValue,
    val freeCashFlow: FinancialValue,
    val netCashChange: FinancialValue
)

data class ValuationMetrics(
    val securityId: String,
    val peTtm: Double,
    val peStatic: Double,
    val peForward: Double,
    val pePercentile5Y: Double, // 历史5年分位点 %
    val pb: Double,
    val pbPercentile5Y: Double,
    val psTtm: Double,
    val evToEbitda: Double,
    val dividendYieldTtm: Double,
    val fcfYield: Double,
    val roe: Double,
    val peg: Double
)

data class DcfModelInputs(
    val currentRevenue: Double,       // 当前营收 亿元
    val revenueGrowthStage1: Double,  // 前5年年化增速 % (e.g. 12.0%)
    val revenueGrowthStage2: Double,  // 6-10年年化增速 % (e.g. 6.0%)
    val operatingMarginPct: Double,   // 营业利润率 % (e.g. 45.0%)
    val taxRatePct: Double = 15.0,    // 实际所得税率 %
    val capexToRevenuePct: Double = 5.0, // 资本开支/营收 %
    val waccPct: Double = 8.5,        // 加权平均资本成本 WACC %
    val terminalGrowthRatePct: Double = 2.5, // 永续增长率 %
    val netDebtAmount: Double = -500.0, // 净负债 亿元 (负值代表净现金)
    val totalSharesCount: Double = 12.56 // 总股本 亿股
)

data class DcfModelResult(
    val enterpriseValue: Double,      // 企业价值 亿元
    val equityValue: Double,          // 股权价值 亿元
    val impliedSharePrice: Double,    // 每股内在价值 (元)
    val currentSharePrice: Double,    // 当前市价 (元)
    val marginOfSafetyPct: Double,    // 安全边际 / 估值溢价折价 %
    val valuationVerdict: String,     // "显著低估" / "合理区间" / "存在估值泡沫"
    val sensitivityMatrix: List<List<Double>> // [WACC rows][Terminal growth cols]
)
