package com.example.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.data.MarketMasterDatabase
import com.example.terminal.domain.*
import com.example.terminal.ui.components.*
import com.example.ui.theme.*

@Composable
fun FundamentalValuationScreen(
    state: TerminalUiState,
    onUpdateDcf: (Double?, Double?, Double?, Double?) -> Unit,
    modifier: Modifier = Modifier
) {
    val sec = state.selectedSecurity
    val (bs, inc, cf) = MarketMasterDatabase.getFinancials(sec.ticker)
    val dcfInputs = state.dcfInputs
    val dcfRes = state.dcfResult

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Company Financial Overview Card
        item {
            TerminalCard(
                title = "${sec.name} (${sec.securityId}) 财务报表核心指标",
                testTag = "financial_overview_card"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("营业收入", color = TextSecondary, fontSize = 11.sp)
                        Text(inc.totalRevenue.formatDisplay(), color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("同比 +${inc.revenueGrowthYoY}%", color = MarketUpRed, fontSize = 10.sp)
                    }
                    Column {
                        Text("归母净利润", color = TextSecondary, fontSize = 11.sp)
                        Text(inc.netProfitToParent.formatDisplay(), color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("同比 +${inc.netProfitGrowthYoY}%", color = MarketUpRed, fontSize = 10.sp)
                    }
                    Column {
                        Text("净资产收益率 (ROE)", color = TextSecondary, fontSize = 11.sp)
                        Text("${inc.roePct}%", color = TerminalGold, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text("毛利率: ${inc.grossMarginPct}%", color = TextMuted, fontSize = 10.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = TerminalBorderSubtle)
                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TerminalDataRow("货币资金", bs.cashAndEquivalents.formatDisplay(), Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(12.dp))
                    TerminalDataRow("经营现金流", cf.operatingCashFlow.formatDisplay(), Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TerminalDataRow("自由现金流", cf.freeCashFlow.formatDisplay(), Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(12.dp))
                    TerminalDataRow("资产负债率", "%.2f%%".format(bs.debtToAssetRatio), Modifier.weight(1f))
                }
            }
        }

        // 2. Interactive DCF Model Laboratory
        item {
            TerminalCard(
                title = "DCF 内在价值折现模型实验室 // DCF LAB",
                testTag = "dcf_lab_card"
            ) {
                // DCF Summary Result Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(TerminalDarkBg)
                        .border(1.dp, TerminalGold.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("每股内在价值测算", color = TextSecondary, fontSize = 11.sp)
                            Text(
                                text = "¥%.2f".format(dcfRes.impliedSharePrice),
                                color = TerminalGold,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "当前市价: ¥%.2f".format(dcfRes.currentSharePrice),
                                color = TextMuted,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("安全边际 / 溢折率", color = TextSecondary, fontSize = 11.sp)
                            val isSafe = dcfRes.marginOfSafetyPct >= 0
                            Text(
                                text = "%s%.2f%%".format(if (isSafe) "+" else "", dcfRes.marginOfSafetyPct),
                                color = if (isSafe) MarketUpRed else MarketDownGreen,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            SegmentTag(
                                name = dcfRes.valuationVerdict,
                                color = if (isSafe) MarketUpRed else MarketDownGreen
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Interactive Sliders for DCF Parameters
                Text("可调内生增长与折现假设参数:", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))

                // Slider 1: WACC
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("加权平均资本成本 (WACC)", color = TextPrimary, fontSize = 11.sp)
                        Text("%.1f%%".format(dcfInputs.waccPct), color = TerminalGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = dcfInputs.waccPct.toFloat(),
                        onValueChange = { onUpdateDcf(it.toDouble(), null, null, null) },
                        valueRange = 6.0f..12.0f,
                        steps = 11,
                        colors = SliderDefaults.colors(thumbColor = TerminalGold, activeTrackColor = TerminalGold),
                        modifier = Modifier.testTag("wacc_slider")
                    )
                }

                // Slider 2: Terminal Growth Rate
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("永续增长率 (g)", color = TextPrimary, fontSize = 11.sp)
                        Text("%.1f%%".format(dcfInputs.terminalGrowthRatePct), color = TerminalCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = dcfInputs.terminalGrowthRatePct.toFloat(),
                        onValueChange = { onUpdateDcf(null, it.toDouble(), null, null) },
                        valueRange = 1.0f..4.0f,
                        steps = 5,
                        colors = SliderDefaults.colors(thumbColor = TerminalCyan, activeTrackColor = TerminalCyan),
                        modifier = Modifier.testTag("growth_slider")
                    )
                }

                // Slider 3: Stage 1 Growth Rate
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("前5年营收复合增长率", color = TextPrimary, fontSize = 11.sp)
                        Text("%.1f%%".format(dcfInputs.revenueGrowthStage1), color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Slider(
                        value = dcfInputs.revenueGrowthStage1.toFloat(),
                        onValueChange = { onUpdateDcf(null, null, it.toDouble(), null) },
                        valueRange = 5.0f..25.0f,
                        steps = 19,
                        colors = SliderDefaults.colors(thumbColor = TextPrimary, activeTrackColor = TextPrimary),
                        modifier = Modifier.testTag("stage1_slider")
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = TerminalBorderSubtle)
                Spacer(modifier = Modifier.height(8.dp))

                // Sensitivity Matrix Heatmap Table
                Text("WACC 与 永续增长率 敏感性矩阵 (每股内在价值 ¥):", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("WACC \\ g", color = TextMuted, fontSize = 10.sp, modifier = Modifier.weight(1.2f))
                    Text("2.0%", color = TextSecondary, fontSize = 10.sp, modifier = Modifier.weight(1f))
                    Text("2.5%", color = TerminalGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("3.0%", color = TextSecondary, fontSize = 10.sp, modifier = Modifier.weight(1f))
                }

                val waccLabels = listOf("7.5%", "8.0%", "8.5%", "9.0%", "9.5%")
                dcfRes.sensitivityMatrix.take(5).forEachIndexed { i, row ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(waccLabels.getOrElse(i) { "" }, color = TextMuted, fontSize = 10.sp, modifier = Modifier.weight(1.2f))
                        row.take(3).forEach { valPrice ->
                            Text(
                                text = "¥%.1f".format(valPrice),
                                color = if (valPrice >= dcfRes.currentSharePrice) MarketUpRed else MarketDownGreen,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
