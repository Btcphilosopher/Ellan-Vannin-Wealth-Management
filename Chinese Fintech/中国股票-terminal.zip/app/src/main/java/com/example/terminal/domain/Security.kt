package com.example.terminal.domain

enum class Exchange(val code: String, val displayName: String, val city: String) {
    SSE("SH", "上海证券交易所", "上海"),
    SZSE("SZ", "深圳证券交易所", "深圳"),
    BSE("BJ", "北京证券交易所", "北京"),
    HKEX("HK", "香港交易所", "香港")
}

enum class MarketSegment(val displayName: String, val defaultPriceLimitPct: Double) {
    SSE_MAIN("上海主板", 10.0),
    SZSE_MAIN("深圳主板", 10.0),
    STAR("科创板", 20.0),
    CHINEXT("创业板", 20.0),
    BSE("北交所", 30.0),
    B_SHARE("B股", 10.0),
    ETF("ETF基金", 10.0),
    LOF("LOF基金", 10.0),
    CDR("存托凭证", 20.0)
}

enum class SecurityType(val displayName: String) {
    A_SHARE("A股普通股"),
    B_SHARE("B股"),
    INDEX("指数"),
    ETF("交易型开放式指数基金"),
    LOF("上市型开放式基金")
}

enum class RiskStatus(val displayName: String, val tag: String, val priceLimitPct: Double) {
    NORMAL("正常", "", 0.0), // Uses segment default
    ST("ST风险警示", "ST", 5.0),
    STAR_ST("*ST退市风险", "*ST", 5.0),
    DELISTING("退市整理期", "退", 10.0)
}

enum class TradingStatus(val displayName: String, val canTrade: Boolean) {
    TRADING("连续竞价", true),
    CALL_AUCTION("集合竞价", true),
    LUNCH_BREAK("午间休市", false),
    HALTED("停牌", false),
    TEMP_SUSPENDED("临时停牌", false),
    CLOSED("已收盘", false)
}

data class FinancialValue(
    val amount: Double,
    val currency: String = "CNY",
    val unitScale: String = "亿元",
    val period: String = "2025Q4",
    val source: String = "上市公司公告 / 经审计"
) {
    fun formatDisplay(): String {
        return "%.2f %s".format(amount, unitScale)
    }
}

data class Security(
    val securityId: String,          // e.g. "600519.SH"
    val ticker: String,              // e.g. "600519"
    val name: String,                // e.g. "贵州茅台"
    val fullName: String,            // e.g. "贵州茅台酒股份有限公司"
    val pinyin: String,              // e.g. "GZMT"
    val exchange: Exchange,
    val marketSegment: MarketSegment,
    val securityType: SecurityType,
    val swIndustryL1: String,        // 申万一级行业, e.g. "食品饮料"
    val swIndustryL2: String,        // 申万二级行业, e.g. "白酒"
    val csrcIndustry: String,        // 证监会行业
    val listingDate: String,
    val totalShares: Double,         // 亿股
    val floatShares: Double,         // 亿股
    val freeFloatShares: Double,     // 自由流通股本 亿股
    val currency: String = "CNY",
    val tradingStatus: TradingStatus = TradingStatus.TRADING,
    val riskStatus: RiskStatus = RiskStatus.NORMAL,
    val ipoDaysCount: Int = 999      // Days since IPO (first 5 days for STAR/ChiNext have no price limit)
) {
    val isSt: Boolean get() = riskStatus == RiskStatus.ST || riskStatus == RiskStatus.STAR_ST
}
