package com.example.terminal.domain

enum class AlertSeverity(val displayName: String) {
    CRITICAL("严重风险"),
    WARNING("重要预警"),
    INFO("常规提示")
}

data class RiskAlert(
    val alertId: String,
    val securityTicker: String,
    val securityName: String,
    val title: String,
    val description: String,
    val severity: AlertSeverity,
    val timestamp: String,
    val ruleCategory: String // "涨跌停流动性冻结" / "重大重组停牌" / "融资担保比例预警" / "财报业绩修正"
)

data class MarketAnnouncement(
    val id: String,
    val ticker: String,
    val companyName: String,
    val title: String,
    val category: String, // "业绩预告", "分红派息", "回购股份", "增持减持", "重大合同"
    val publishTime: String,
    val summary: String,
    val sentiment: String // "利好" / "利空" / "中性"
)
