package com.example.terminal.domain

enum class EtfCategory(val displayName: String) {
    BROAD_BASE("宽基ETF"),
    SECTOR_THEME("行业主题ETF"),
    CROSS_BORDER("跨境ETF"),
    BOND("债券ETF"),
    COMMODITY("商品ETF"),
    SMART_BETA("策略Smart Beta ETF")
}

data class EtfConstituent(
    val ticker: String,
    val name: String,
    val weightPct: Double,
    val shareQuantity: Long,
    val cashSubstitutionType: String // 允许现金替代 / 必须现金替代 / 禁止现金替代
)

data class EtfProduct(
    val securityId: String,
    val ticker: String,
    val name: String,
    val exchange: Exchange,
    val category: EtfCategory,
    val trackingIndexName: String,
    val trackingIndexCode: String,
    val currentPrice: Double,
    val prevClose: Double,
    val iopv: Double,                // 实时参考净值 (Indicative Optimized Portfolio Value)
    val fundSizeAum: Double,         // 基金规模 亿元
    val turnoverAmount: Double,      // 成交额 亿元
    val trackingErrorPct: Double,    // 跟踪误差 %
    val managementFeePct: Double,    // 管理费率 %
    val creationRedemptionStatus: String, // 开放申赎 / 暂停申购 / 限制大额
    val constituents: List<EtfConstituent>
) {
    val changePct: Double get() = if (prevClose > 0) ((currentPrice - prevClose) / prevClose) * 100.0 else 0.0
    // 折溢价率 = (现价 - IOPV) / IOPV * 100%
    val discountPremiumPct: Double get() = if (iopv > 0) ((currentPrice - iopv) / iopv) * 100.0 else 0.0
    val isPremium: Boolean get() = discountPremiumPct > 0.05
    val isDiscount: Boolean get() = discountPremiumPct < -0.05
}

data class EtfArbitrageAnalysis(
    val etfTicker: String,
    val etfName: String,
    val marketPrice: Double,
    val iopv: Double,
    val spreadPct: Double,
    val creationCostPct: Double = 0.12, // 申购及一二级交易佣金滑点
    val estimatedNetProfitPct: Double,
    val arbitrageDirection: String,     // "溢价套利：买入一篮子股票->申购ETF->二级市场卖出" 或 "折价套利：二级市场买入ETF->赎回一篮子股票->卖出股票"
    val riskWarning: String
)
