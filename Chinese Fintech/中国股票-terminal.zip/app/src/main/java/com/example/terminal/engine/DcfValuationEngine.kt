package com.example.terminal.engine

import com.example.terminal.domain.DcfModelInputs
import com.example.terminal.domain.DcfModelResult
import kotlin.math.pow
import kotlin.math.round

object DcfValuationEngine {

    fun calculateDcf(inputs: DcfModelInputs, currentSharePrice: Double): DcfModelResult {
        // 10-year Free Cash Flow projections
        var projectedRevenue = inputs.currentRevenue
        val fcfList = mutableListOf<Double>()

        // Years 1 - 5 (Stage 1)
        for (year in 1..5) {
            projectedRevenue *= (1.0 + inputs.revenueGrowthStage1 / 100.0)
            val ebit = projectedRevenue * (inputs.operatingMarginPct / 100.0)
            val nopat = ebit * (1.0 - inputs.taxRatePct / 100.0) // 税后净营业利润
            val capex = projectedRevenue * (inputs.capexToRevenuePct / 100.0)
            val fcf = nopat - capex // 简化自由现金流模型
            fcfList.add(fcf)
        }

        // Years 6 - 10 (Stage 2)
        for (year in 6..10) {
            projectedRevenue *= (1.0 + inputs.revenueGrowthStage2 / 100.0)
            val ebit = projectedRevenue * (inputs.operatingMarginPct / 100.0)
            val nopat = ebit * (1.0 - inputs.taxRatePct / 100.0)
            val capex = projectedRevenue * (inputs.capexToRevenuePct / 100.0)
            val fcf = nopat - capex
            fcfList.add(fcf)
        }

        val wacc = inputs.waccPct / 100.0
        val g = inputs.terminalGrowthRatePct / 100.0

        // Discounted Cash Flows for 10 years
        var pvExplicitFcf = 0.0
        for (i in 0 until 10) {
            val discountFactor = 1.0 / (1.0 + wacc).pow(i + 1)
            pvExplicitFcf += fcfList[i] * discountFactor
        }

        // Terminal Value = FCF_10 * (1 + g) / (WACC - g)
        val fcfYear10 = fcfList.last()
        val terminalValue = if (wacc > g) (fcfYear10 * (1.0 + g)) / (wacc - g) else fcfYear10 * 25.0
        val pvTerminalValue = terminalValue / (1.0 + wacc).pow(10)

        val enterpriseValue = pvExplicitFcf + pvTerminalValue
        // Equity Value = Enterprise Value - Net Debt (Note: negative net debt means cash addition)
        val equityValue = enterpriseValue - inputs.netDebtAmount

        val impliedSharePrice = if (inputs.totalSharesCount > 0) {
            (equityValue / inputs.totalSharesCount)
        } else {
            0.0
        }

        val marginOfSafety = if (currentSharePrice > 0) {
            ((impliedSharePrice - currentSharePrice) / currentSharePrice) * 100.0
        } else 0.0

        val verdict = when {
            marginOfSafety >= 20.0 -> "显著低估 (安全边际充足)"
            marginOfSafety in -10.0..20.0 -> "合理估值区间"
            marginOfSafety in -30.0..-10.0 -> "温和偏高"
            else -> "显著高估 (存在估值溢价)"
        }

        // Sensitivity Matrix: WACC (wacc - 1.0% to wacc + 1.0%), Terminal Growth (g - 0.5% to g + 0.5%)
        val sensitivity = mutableListOf<List<Double>>()
        val waccDeltas = listOf(-1.0, -0.5, 0.0, 0.5, 1.0)
        val gDeltas = listOf(-0.5, 0.0, 0.5)

        for (dw in waccDeltas) {
            val testWacc = (inputs.waccPct + dw) / 100.0
            val row = mutableListOf<Double>()
            for (dg in gDeltas) {
                val testG = (inputs.terminalGrowthRatePct + dg) / 100.0
                if (testWacc > testG) {
                    var testPv = 0.0
                    for (i in 0 until 10) {
                        testPv += fcfList[i] / (1.0 + testWacc).pow(i + 1)
                    }
                    val testTv = (fcfYear10 * (1.0 + testG)) / (testWacc - testG)
                    val testPvTv = testTv / (1.0 + testWacc).pow(10)
                    val testEq = testPv + testPvTv - inputs.netDebtAmount
                    val testPrice = testEq / inputs.totalSharesCount
                    row.add(round(testPrice * 100) / 100.0)
                } else {
                    row.add(round(impliedSharePrice * 100) / 100.0)
                }
            }
            sensitivity.add(row)
        }

        return DcfModelResult(
            enterpriseValue = round(enterpriseValue * 100) / 100.0,
            equityValue = round(equityValue * 100) / 100.0,
            impliedSharePrice = round(impliedSharePrice * 100) / 100.0,
            currentSharePrice = currentSharePrice,
            marginOfSafetyPct = round(marginOfSafety * 100) / 100.0,
            valuationVerdict = verdict,
            sensitivityMatrix = sensitivity
        )
    }
}
