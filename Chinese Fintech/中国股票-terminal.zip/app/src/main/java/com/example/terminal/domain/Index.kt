package com.example.terminal.domain

data class MarketIndex(
    val indexId: String,
    val ticker: String,
    val name: String,
    val exchange: Exchange,
    val currentLevel: Double,
    val prevClose: Double,
    val openLevel: Double,
    val highLevel: Double,
    val lowLevel: Double,
    val turnoverAmount: Double, // 成交额 亿元
    val volume: Long,           // 成交量 万手
    val upCount: Int,
    val downCount: Int,
    val flatCount: Int,
    val peTtm: Double,
    val pb: Double,
    val dividendYield: Double,
    val constituentsCount: Int
) {
    val changeLevel: Double get() = currentLevel - prevClose
    val changePct: Double get() = if (prevClose > 0) ((currentLevel - prevClose) / prevClose) * 100.0 else 0.0
}

data class IndustrySector(
    val code: String,
    val name: String,
    val leaderSecurityName: String,
    val leaderTicker: String,
    val changePct: Double,
    val totalAmount: Double, // 亿元
    val netInflow: Double,   // 资金净流入 亿元
    val upCount: Int,
    val downCount: Int,
    val peMedian: Double
)

data class MarketBreadth(
    val totalUp: Int,
    val totalDown: Int,
    val totalFlat: Int,
    val limitUpCount: Int,
    val limitDownCount: Int,
    val brokenLimitUpCount: Int, // 炸板数
    val newHighCount: Int,
    val newLowCount: Int,
    val totalMarketTurnover: Double, // 全市场成交额 亿元
    val shanghaiTurnover: Double,    // 沪市成交额 亿元
    val shenzhenTurnover: Double,    // 深市成交额 亿元
    val beijingTurnover: Double,     // 北交所成交额 亿元
    val medianChangePct: Double,     // 涨跌幅中位数 %
    val marketSentimentScore: Double // 市场情绪指数 (0-100)
)
