package com.example.terminal.domain

data class StockConnectFlow(
    val date: String,
    val time: String,
    val northboundShNetInflow: Double,  // 沪股通净流入 亿元
    val northboundSzNetInflow: Double,  // 深股通净流入 亿元
    val northboundTotalNetInflow: Double, // 北向合计 亿元
    val southboundNetInflow: Double,     // 南向港股通合计 亿元
    val northboundDailyQuotaRemaining: Double, // 每日额度剩余 亿元
    val topNorthboundBuySectors: List<String>,
    val topNorthboundSellSectors: List<String>
)

data class AhPremiumStock(
    val aTicker: String,
    val hTicker: String,
    val name: String,
    val aPriceRmb: Double,
    val hPriceHkd: Double,
    val exchangeRateHkdCny: Double = 0.925, // 1 HKD = 0.925 CNY
    val aChangePct: Double,
    val hChangePct: Double,
    val swIndustry: String
) {
    // H-share converted to RMB = hPriceHkd * exchangeRateHkdCny
    val hPriceRmb: Double get() = hPriceHkd * exchangeRateHkdCny
    // AH Premium = (A股价格 - H股折合人民币价格) / H股折合人民币价格 * 100%
    val ahPremiumPct: Double get() = if (hPriceRmb > 0) ((aPriceRmb - hPriceRmb) / hPriceRmb) * 100.0 else 0.0
}
