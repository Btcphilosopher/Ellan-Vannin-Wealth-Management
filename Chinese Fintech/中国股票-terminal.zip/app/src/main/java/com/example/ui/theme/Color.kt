package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Terminal Backgrounds
val TerminalDarkBg = Color(0xFF090D16)
val TerminalCardBg = Color(0xFF111827)
val TerminalSurfaceVariant = Color(0xFF1E293B)
val TerminalHeaderBg = Color(0xFF0F172A)
val TerminalBorder = Color(0xFF334155)
val TerminalBorderSubtle = Color(0xFF1F293D)

// Chinese Market Semantic Colors
val MarketUpRed = Color(0xFFEF4444)
val MarketUpRedBg = Color(0x22EF4444)
val MarketLimitUp = Color(0xFFFF2E54)
val MarketDownGreen = Color(0xFF10B981)
val MarketDownGreenBg = Color(0x2210B981)
val MarketLimitDown = Color(0xFF059669)
val MarketFlatGray = Color(0xFF94A3B8)

// Institutional Accents
val TerminalGold = Color(0xFFF59E0B)
val TerminalGoldBg = Color(0x22F59E0B)
val TerminalCyan = Color(0xFF38BDF8)
val TerminalBlue = Color(0xFF3B82F6)
val TerminalPurple = Color(0xFF8B5CF6)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextHighlight = Color(0xFFE2E8F0)
