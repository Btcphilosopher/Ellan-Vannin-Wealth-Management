package com.example.terminal.engine

import com.example.terminal.domain.*
import kotlin.math.max
import kotlin.math.sqrt

object BacktestEngine {

    fun runStrategy(strategyType: String): BacktestResult {
        return when (strategyType) {
            "红利低波增强策略" -> generateDividendLowVolResult()
            "申万行业动量轮动" -> generateSectorMomentumResult()
            "北向资金重仓增强" -> generateNorthboundEnhancedResult()
            else -> generateDividendLowVolResult()
        }
    }

    private fun generateDividendLowVolResult(): BacktestResult {
        val config = BacktestConfig(
            strategyName = "中证红利低波动多因子增强",
            benchmark = "沪深300 (000300.SH)",
            startDate = "2023-01-03",
            endDate = "2026-09-30",
            rebalancePeriod = "月度调仓",
            topNConstituents = 30
        )

        val points = mutableListOf<BacktestPoint>()
        val dates = listOf(
            "2023-03", "2023-06", "2023-09", "2023-12",
            "2024-03", "2024-06", "2024-09", "2024-12",
            "2025-03", "2025-06", "2025-09", "2025-12",
            "2026-03", "2026-06", "2026-09"
        )

        var stratRet = 0.0
        var benchRet = 0.0
        var maxPeak = 0.0
        var maxDd = 0.0

        // Strategy quarterly increments: steady positive drift with low volatility
        val stratDeltas = listOf(3.2, 2.8, -1.2, 4.5, 3.8, 1.9, -2.1, 5.2, 4.1, 3.5, 2.2, 4.8, 3.1, 2.6, 3.4)
        val benchDeltas = listOf(1.5, -4.2, -3.8, -2.5, 3.1, -1.8, 8.5, 2.2, -1.5, 2.1, 4.2, 1.8, -2.4, 3.5, 1.2)

        for (i in dates.indices) {
            stratRet += stratDeltas[i]
            benchRet += benchDeltas[i]
            if (stratRet > maxPeak) maxPeak = stratRet
            val currentDd = maxPeak - stratRet
            if (currentDd > maxDd) maxDd = currentDd

            points.add(
                BacktestPoint(
                    date = dates[i],
                    strategyCumulativeReturn = stratRet,
                    benchmarkCumulativeReturn = benchRet,
                    excessReturn = stratRet - benchRet,
                    portfolioDrawdown = currentDd
                )
            )
        }

        return BacktestResult(
            config = config,
            totalReturnPct = 42.0,
            annualizedReturnPct = 12.8,
            benchmarkReturnPct = 12.5,
            alphaPct = 8.6,
            beta = 0.58,
            sharpeRatio = 1.68,
            maxDrawdownPct = 6.8,
            calmarRatio = 1.88,
            informationRatio = 1.45,
            winRatePct = 68.5,
            turnoverRateAnnualPct = 85.0,
            equityCurve = points
        )
    }

    private fun generateSectorMomentumResult(): BacktestResult {
        val config = BacktestConfig(
            strategyName = "申万一级行业动量轮动",
            benchmark = "中证500 (000905.SH)",
            startDate = "2023-01-03",
            endDate = "2026-09-30",
            rebalancePeriod = "双周调仓",
            topNConstituents = 5
        )

        val points = mutableListOf<BacktestPoint>()
        val dates = listOf(
            "2023-03", "2023-06", "2023-09", "2023-12",
            "2024-03", "2024-06", "2024-09", "2024-12",
            "2025-03", "2025-06", "2025-09", "2025-12",
            "2026-03", "2026-06", "2026-09"
        )
        val stratDeltas = listOf(5.8, -3.2, 2.1, 7.5, 6.2, -4.5, 12.0, 3.8, -2.1, 8.4, 5.2, 6.1, -1.8, 9.2, 4.3)
        val benchDeltas = listOf(2.1, -5.4, -2.1, -4.8, 4.2, -3.1, 9.8, 1.2, -3.4, 3.8, 5.1, 2.1, -3.2, 4.1, 0.8)

        var stratRet = 0.0
        var benchRet = 0.0
        var maxPeak = 0.0
        var maxDd = 0.0

        for (i in dates.indices) {
            stratRet += stratDeltas[i]
            benchRet += benchDeltas[i]
            if (stratRet > maxPeak) maxPeak = stratRet
            val currentDd = maxPeak - stratRet
            if (currentDd > maxDd) maxDd = currentDd

            points.add(
                BacktestPoint(
                    date = dates[i],
                    strategyCumulativeReturn = stratRet,
                    benchmarkCumulativeReturn = benchRet,
                    excessReturn = stratRet - benchRet,
                    portfolioDrawdown = currentDd
                )
            )
        }

        return BacktestResult(
            config = config,
            totalReturnPct = 69.0,
            annualizedReturnPct = 19.4,
            benchmarkReturnPct = 10.6,
            alphaPct = 12.2,
            beta = 1.12,
            sharpeRatio = 1.42,
            maxDrawdownPct = 14.2,
            calmarRatio = 1.36,
            informationRatio = 1.21,
            winRatePct = 62.0,
            turnoverRateAnnualPct = 240.0,
            equityCurve = points
        )
    }

    private fun generateNorthboundEnhancedResult(): BacktestResult {
        val config = BacktestConfig(
            strategyName = "北向资金持续增持龙头增强",
            benchmark = "沪深300 (000300.SH)",
            startDate = "2023-01-03",
            endDate = "2026-09-30",
            rebalancePeriod = "月度调仓",
            topNConstituents = 20
        )

        val points = mutableListOf<BacktestPoint>()
        val dates = listOf(
            "2023-03", "2023-06", "2023-09", "2023-12",
            "2024-03", "2024-06", "2024-09", "2024-12",
            "2025-03", "2025-06", "2025-09", "2025-12",
            "2026-03", "2026-06", "2026-09"
        )
        val stratDeltas = listOf(4.2, 1.2, -2.5, 3.8, 4.5, 0.8, 6.2, 4.1, 1.8, 5.2, 3.9, 4.1, 1.2, 4.8, 2.9)
        val benchDeltas = listOf(1.5, -4.2, -3.8, -2.5, 3.1, -1.8, 8.5, 2.2, -1.5, 2.1, 4.2, 1.8, -2.4, 3.5, 1.2)

        var stratRet = 0.0
        var benchRet = 0.0
        var maxPeak = 0.0
        var maxDd = 0.0

        for (i in dates.indices) {
            stratRet += stratDeltas[i]
            benchRet += benchDeltas[i]
            if (stratRet > maxPeak) maxPeak = stratRet
            val currentDd = maxPeak - stratRet
            if (currentDd > maxDd) maxDd = currentDd

            points.add(
                BacktestPoint(
                    date = dates[i],
                    strategyCumulativeReturn = stratRet,
                    benchmarkCumulativeReturn = benchRet,
                    excessReturn = stratRet - benchRet,
                    portfolioDrawdown = currentDd
                )
            )
        }

        return BacktestResult(
            config = config,
            totalReturnPct = 48.2,
            annualizedReturnPct = 14.5,
            benchmarkReturnPct = 12.5,
            alphaPct = 9.8,
            beta = 0.82,
            sharpeRatio = 1.55,
            maxDrawdownPct = 8.4,
            calmarRatio = 1.72,
            informationRatio = 1.38,
            winRatePct = 65.0,
            turnoverRateAnnualPct = 110.0,
            equityCurve = points
        )
    }
}
