package com.example.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.domain.Position
import com.example.terminal.ui.components.*
import com.example.ui.theme.*

@Composable
fun PortfolioRiskScreen(
    state: TerminalUiState,
    modifier: Modifier = Modifier
) {
    val pf = state.portfolio
    val margin = pf.marginAccount

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Institutional Portfolio Summary
        item {
            TerminalCard(
                title = "${pf.name} (${pf.institutionalType.displayName}) 组合账本",
                testTag = "portfolio_summary_card"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("总资产规模", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "¥%.2f 亿".format(pf.totalAssetValue / 100000000.0),
                            color = TerminalGold,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("当日盈亏", color = TextSecondary, fontSize = 11.sp)
                        val isUp = pf.dailyPnl >= 0
                        Text(
                            text = "%s¥%.2f 万 (%s%.2f%%)".format(
                                if (isUp) "+" else "",
                                pf.dailyPnl / 10000.0,
                                if (isUp) "+" else "",
                                pf.dailyPnlPct
                            ),
                            color = if (isUp) MarketUpRed else MarketDownGreen,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("可用现金", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "¥%.2f 万".format(pf.cashBalance / 10000.0),
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = TerminalBorderSubtle)
                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TerminalDataRow("月度收益 (MTD)", "+%.2f%%".format(pf.mtdPnlPct), Modifier.weight(1f), valueColor = MarketUpRed)
                    Spacer(modifier = Modifier.width(12.dp))
                    TerminalDataRow("年度收益 (YTD)", "+%.2f%%".format(pf.ytdPnlPct), Modifier.weight(1f), valueColor = MarketUpRed)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TerminalDataRow("组合Beta (对沪深300)", "%.2f".format(pf.betaToHs300), Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(12.dp))
                    TerminalDataRow("前五大持仓集中度", "%.2f%%".format(pf.top5ConcentrationPct), Modifier.weight(1f))
                }
            }
        }

        // 2. Margin Financing Ledger & VaR Risk Analysis
        item {
            TerminalCard(
                title = "融资融券担保与 VaR 风险控制 // MARGIN & VAR",
                testTag = "margin_var_card"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("维持担保比例", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "%.1f%%".format(margin.maintenanceRatioPct),
                            color = TerminalCyan,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("预警线 140% | 平仓线 130%", color = TextMuted, fontSize = 10.sp)
                    }
                    Column {
                        Text("融资负债余额", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "¥%.2f 亿".format(margin.marginBorrowAmount / 100000000.0),
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("日度 VaR (95%置信度)", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "¥%.2f 万".format(pf.var95Daily / 10000.0),
                            color = MarketLimitUp,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // 3. Current Positions Table
        item {
            TerminalCard(
                title = "组合持仓明细 (T+1规则) // POSITIONS LEDGER",
                testTag = "positions_ledger_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("证券", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.2f))
                        Text("持股/可用", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text("成本/现价", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text("浮动盈亏", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text("权重", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(0.7f))
                    }

                    pf.positions.forEach { pos ->
                        val isUp = pos.unrealizedPnl >= 0
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceVariant.copy(alpha = 0.4f))
                                .padding(horizontal = 6.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.2f)) {
                                Text(pos.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(pos.ticker, color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text("${pos.quantity / 10000}万股", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("¥%.2f".format(pos.currentPrice), color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                Text("成本¥%.2f".format(pos.avgCostPrice), color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text(
                                text = "%s¥%.1f万".format(if (isUp) "+" else "", pos.unrealizedPnl / 10000.0),
                                color = if (isUp) MarketUpRed else MarketDownGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                            Text("%.1f%%".format(pos.weightPct), color = TerminalGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.7f))
                        }
                    }
                }
            }
        }
    }
}
