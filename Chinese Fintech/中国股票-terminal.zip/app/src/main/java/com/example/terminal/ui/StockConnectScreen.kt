package com.example.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.domain.AhPremiumStock
import com.example.terminal.domain.StockConnectFlow
import com.example.terminal.ui.components.*
import com.example.ui.theme.*

@Composable
fun StockConnectScreen(
    state: TerminalUiState,
    modifier: Modifier = Modifier
) {
    val flow = state.stockConnectFlow

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Stock Connect Overview Card
        item {
            TerminalCard(
                title = "沪深港通资金流向 // STOCK CONNECT FLOW",
                testTag = "stock_connect_flow_card"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("北向资金合计净流入", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "%s¥%.2f 亿".format(if (flow.northboundTotalNetInflow > 0) "+" else "", flow.northboundTotalNetInflow),
                            color = if (flow.northboundTotalNetInflow > 0) MarketUpRed else MarketDownGreen,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("沪股通净流入", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "%s¥%.2f 亿".format(if (flow.northboundShNetInflow > 0) "+" else "", flow.northboundShNetInflow),
                            color = if (flow.northboundShNetInflow > 0) MarketUpRed else MarketDownGreen,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("深股通净流入", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "%s¥%.2f 亿".format(if (flow.northboundSzNetInflow > 0) "+" else "", flow.northboundSzNetInflow),
                            color = if (flow.northboundSzNetInflow > 0) MarketUpRed else MarketDownGreen,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = TerminalBorderSubtle)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("南向港股通净流入", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "%s¥%.2f 亿".format(if (flow.southboundNetInflow > 0) "+" else "", flow.southboundNetInflow),
                            color = TerminalGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("北向每日额度剩余", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "¥%.2f 亿 (充足)".format(flow.northboundDailyQuotaRemaining),
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // 2. Northbound Sector Preference Breakdown
        item {
            TerminalCard(
                title = "北向外资行业增减持偏好 // SECTOR INFLOWS & OUTFLOWS",
                testTag = "northbound_sectors_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("主要净买入行业:", color = MarketUpRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    flow.topNorthboundBuySectors.forEach { sector ->
                        Text("• $sector", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("主要净卖出行业:", color = MarketDownGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    flow.topNorthboundSellSectors.forEach { sector ->
                        Text("• $sector", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // 3. AH Share Premium Comparison Table
        item {
            TerminalCard(
                title = "A/H 股溢价监控表 // AH PREMIUM MONITOR",
                testTag = "ah_premium_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("证券简称", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.2f))
                        Text("A股价格", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text("H股(HKD)", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text("AH溢价率", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.1f))
                    }

                    state.ahStocks.forEach { stock ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceVariant.copy(alpha = 0.4f))
                                .padding(horizontal = 6.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.2f)) {
                                Text(stock.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("A:${stock.aTicker} / H:${stock.hTicker}", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                            Text("¥%.2f".format(stock.aPriceRmb), color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text("HK$%.2f".format(stock.hPriceHkd), color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            val premium = stock.ahPremiumPct
                            Text(
                                text = "+%.2f%%".format(premium),
                                color = TerminalGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1.1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
