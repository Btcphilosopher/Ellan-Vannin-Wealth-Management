package com.example.terminal.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.terminal.data.MarketMasterDatabase
import com.example.terminal.domain.*
import com.example.terminal.engine.BacktestEngine
import com.example.terminal.engine.DcfValuationEngine
import com.example.terminal.engine.MatchingEngine
import com.example.terminal.engine.TradingCalendarEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.round

enum class TerminalWorkspace(val title: String, val iconLabel: String, val shortcut: String) {
    MARKET_OVERVIEW("市场总览", "大盘", "1"),
    SECURITY_QUOTE("行情与盘口", "个股", "2"),
    ETF_ARBITRAGE("ETF与套利", "ETF", "3"),
    STOCK_CONNECT("互联互通", "北向", "4"),
    FUNDAMENTAL_DCF("基本面与估值", "估值", "5"),
    QUANT_BACKTEST("量化与回测", "量化", "6"),
    PORTFOLIO_RISK("机构组合风控", "组合", "7"),
    EXECUTION_DESK("交易执行台", "交易", "8"),
    AI_RESEARCH("中国股票//AI", "AI", "9")
}

data class TerminalUiState(
    val currentWorkspace: TerminalWorkspace = TerminalWorkspace.MARKET_OVERVIEW,
    val selectedSecurity: Security = MarketMasterDatabase.securities.first(),
    val activeQuote: Quote = MarketMasterDatabase.getQuotes().first(),
    val orderBook: OrderBook = MarketMasterDatabase.getSampleOrderBook("600519.SH"),
    val recentTrades: List<Trade> = emptyList(),
    val indices: List<MarketIndex> = MarketMasterDatabase.indices,
    val industrySectors: List<IndustrySector> = MarketMasterDatabase.industrySectors,
    val marketBreadth: MarketBreadth = MarketMasterDatabase.marketBreadth,
    val etfs: List<EtfProduct> = MarketMasterDatabase.etfProducts,
    val selectedEtf: EtfProduct = MarketMasterDatabase.etfProducts.first(),
    val stockConnectFlow: StockConnectFlow = MarketMasterDatabase.stockConnectFlow,
    val ahStocks: List<AhPremiumStock> = MarketMasterDatabase.ahStocks,
    val portfolio: Portfolio = MarketMasterDatabase.getSamplePortfolio(),
    val userOrders: List<Order> = emptyList(),
    // DCF Interactive State
    val dcfInputs: DcfModelInputs = DcfModelInputs(
        currentRevenue = 1685.2,
        revenueGrowthStage1 = 12.0,
        revenueGrowthStage2 = 6.0,
        operatingMarginPct = 68.0,
        taxRatePct = 15.0,
        capexToRevenuePct = 3.5,
        waccPct = 8.5,
        terminalGrowthRatePct = 2.5,
        netDebtAmount = -1820.5,
        totalSharesCount = 12.56
    ),
    val dcfResult: DcfModelResult = DcfValuationEngine.calculateDcf(
        DcfModelInputs(1685.2, 12.0, 6.0, 68.0, 15.0, 3.5, 8.5, 2.5, -1820.5, 12.56),
        1685.00
    ),
    // Quant Backtest State
    val selectedStrategy: String = "红利低波增强策略",
    val backtestResult: BacktestResult = BacktestEngine.runStrategy("红利低波增强策略"),
    // Stress Scenario State
    val selectedStressScenario: MarketStressScenario = MarketMasterDatabase.stressScenarios.first(),
    // Simulation / Clock State
    val simulationTime: String = "14:45:20",
    val tradingSessionName: String = "后市连续竞价 (13:00-14:57)",
    val isSimulationRunning: Boolean = true,
    // Search / Command Palette
    val searchQuery: String = "",
    val searchResults: List<Security> = emptyList(),
    val isCommandPaletteOpen: Boolean = false,
    // AI Chat Messages
    val aiMessages: List<Pair<String, String>> = listOf(
        Pair("system", "欢迎使用 中国股票 // TERMINAL AI量化研究台。您可以输入股票代码、因子查询或估值敏感性指令。"),
        Pair("user", "对比贵州茅台与宁德时代的ROE、估值与北向资金偏好。"),
        Pair("assistant", "【数据血缘: 2025年报真实披露 + 交易所实时行情】\n1. 盈利质量: 贵州茅台ROE为35.8%，毛利率91.97%，净利率达51.2%；宁德时代ROE为24.5%，毛利率28.2%，成长弹性更高。\n2. 估值分位: 茅台PE(TTM) 24.8倍 (历史5年分位数 22.4%)；宁德时代PE 22.5倍 (历史分位数 18.5%)。\n3. 外资仓位: 茅台北向持股占比7.12% (持仓市值约1500亿)；宁德时代北向持股占比11.25% (新能源第一大重仓)。")
    ),
    val aiInputText: String = "",
    val statusMessage: String = "市场处于连续竞价状态 · 撮合引擎正常运行 · T+1规则生效"
)

class TerminalViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(TerminalUiState())
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    private var matchingEngine = MatchingEngine(
        securityId = "600519.SH",
        currentPrice = 1685.00,
        limitUpPrice = 1820.72,
        limitDownPrice = 1489.68
    )

    init {
        // Initialize with default sample orders & trades
        seedInitialTrades()
        startLiveMarketTicker()
    }

    private fun seedInitialTrades() {
        val initialTrades = listOf(
            Trade("TRD-01", "600519.SH", 1685.00, 200L, 337000.0, "14:45:01", OrderSide.BUY),
            Trade("TRD-02", "600519.SH", 1684.50, 500L, 842250.0, "14:45:05", OrderSide.SELL),
            Trade("TRD-03", "600519.SH", 1685.00, 1000L, 1685000.0, "14:45:10", OrderSide.BUY),
            Trade("TRD-04", "600519.SH", 1685.50, 400L, 674200.0, "14:45:15", OrderSide.BUY)
        )
        _uiState.update { it.copy(recentTrades = initialTrades) }
    }

    private fun startLiveMarketTicker() {
        viewModelScope.launch {
            var tickCounter = 20
            while (true) {
                delay(3000)
                if (_uiState.value.isSimulationRunning) {
                    tickCounter++
                    val sec = (tickCounter % 60)
                    val secStr = if (sec < 10) "0$sec" else "$sec"
                    val currentTime = "14:45:$secStr"
                    val (_, sessionName) = TradingCalendarEngine.getCurrentSessionName(currentTime)

                    // Generate a synthetic micro price fluctuation for selected security
                    val delta = (listOf(-0.50, 0.0, 0.50, 1.0, -1.0).random())
                    val currentQuote = _uiState.value.activeQuote
                    val newPrice = round((currentQuote.currentPrice + delta) * 100) / 100.0
                    val updatedQuote = currentQuote.copy(
                        currentPrice = newPrice,
                        timestamp = currentTime
                    )

                    _uiState.update { state ->
                        state.copy(
                            simulationTime = currentTime,
                            tradingSessionName = sessionName,
                            activeQuote = updatedQuote
                        )
                    }
                }
            }
        }
    }

    fun selectWorkspace(workspace: TerminalWorkspace) {
        _uiState.update { it.copy(currentWorkspace = workspace) }
    }

    fun selectSecurity(security: Security) {
        val quote = MarketMasterDatabase.getQuotes().find { it.ticker == security.ticker }
            ?: MarketMasterDatabase.getQuotes().first()
        val (limitUp, limitDown) = MarketRuleRegistry.calculatePriceLimits(security, quote.prevClose)

        matchingEngine = MatchingEngine(
            securityId = security.securityId,
            currentPrice = quote.currentPrice,
            limitUpPrice = limitUp,
            limitDownPrice = limitDown
        )

        val orderBook = MarketMasterDatabase.getSampleOrderBook(security.securityId)

        // Update DCF inputs based on chosen stock
        val newDcfInputs = if (security.ticker == "600519") {
            _uiState.value.dcfInputs
        } else {
            DcfModelInputs(
                currentRevenue = 4000.0,
                revenueGrowthStage1 = 15.0,
                revenueGrowthStage2 = 8.0,
                operatingMarginPct = 25.0,
                taxRatePct = 15.0,
                capexToRevenuePct = 6.0,
                waccPct = 9.0,
                terminalGrowthRatePct = 2.5,
                netDebtAmount = -200.0,
                totalSharesCount = security.totalShares
            )
        }
        val dcfResult = DcfValuationEngine.calculateDcf(newDcfInputs, quote.currentPrice)

        _uiState.update { state ->
            state.copy(
                selectedSecurity = security,
                activeQuote = quote,
                orderBook = orderBook,
                dcfInputs = newDcfInputs,
                dcfResult = dcfResult,
                statusMessage = "已切换至: ${security.name} (${security.securityId}) · ${security.swIndustryL1}板块"
            )
        }
    }

    fun selectEtf(etf: EtfProduct) {
        _uiState.update { it.copy(selectedEtf = etf) }
    }

    fun onSearchQueryChanged(query: String) {
        val trimmed = query.trim().uppercase()
        val results = if (trimmed.isEmpty()) {
            emptyList()
        } else {
            MarketMasterDatabase.securities.filter { sec ->
                sec.ticker.contains(trimmed) ||
                sec.name.contains(trimmed) ||
                sec.pinyin.contains(trimmed) ||
                sec.swIndustryL1.contains(trimmed) ||
                sec.securityId.contains(trimmed)
            }
        }
        _uiState.update { it.copy(searchQuery = query, searchResults = results) }
    }

    fun toggleCommandPalette(open: Boolean) {
        _uiState.update { it.copy(isCommandPaletteOpen = open, searchQuery = "") }
    }

    fun submitOrder(side: OrderSide, orderType: OrderType, price: Double, quantity: Long) {
        val currentSec = _uiState.value.selectedSecurity
        val newOrder = Order(
            orderId = "ORD-" + UUID.randomUUID().toString().take(6).uppercase(),
            investorId = "INST-MGR-001",
            securityId = currentSec.securityId,
            securityName = currentSec.name,
            side = side,
            orderType = orderType,
            price = price,
            quantity = quantity,
            timestamp = _uiState.value.simulationTime
        )

        val (trades, resultingOrder) = matchingEngine.submitOrder(newOrder)
        val updatedTrades = (trades + _uiState.value.recentTrades).take(50)
        val updatedUserOrders = listOf(resultingOrder) + _uiState.value.userOrders

        val statusMsg = if (resultingOrder.status == OrderStatus.REJECTED) {
            "申报拒绝: ${resultingOrder.rejectReason}"
        } else {
            "委托申报成功: ${side.displayName} ${currentSec.name} ${quantity}股 @ ¥${price}"
        }

        _uiState.update { state ->
            state.copy(
                userOrders = updatedUserOrders,
                recentTrades = updatedTrades,
                statusMessage = statusMsg
            )
        }
    }

    fun cancelOrder(orderId: String) {
        val cancelled = matchingEngine.cancelOrder(orderId)
        _uiState.update { state ->
            val updated = state.userOrders.map {
                if (it.orderId == orderId) it.copy(status = OrderStatus.CANCELLED) else it
            }
            state.copy(
                userOrders = updated,
                statusMessage = "订单 $orderId 已成功撤单"
            )
        }
    }

    fun updateDcfParameters(
        wacc: Double? = null,
        terminalGrowth: Double? = null,
        stage1Growth: Double? = null,
        operatingMargin: Double? = null
    ) {
        val current = _uiState.value.dcfInputs
        val newInputs = current.copy(
            waccPct = wacc ?: current.waccPct,
            terminalGrowthRatePct = terminalGrowth ?: current.terminalGrowthRatePct,
            revenueGrowthStage1 = stage1Growth ?: current.revenueGrowthStage1,
            operatingMarginPct = operatingMargin ?: current.operatingMarginPct
        )
        val result = DcfValuationEngine.calculateDcf(newInputs, _uiState.value.activeQuote.currentPrice)
        _uiState.update { it.copy(dcfInputs = newInputs, dcfResult = result) }
    }

    fun selectBacktestStrategy(strategyName: String) {
        val result = BacktestEngine.runStrategy(strategyName)
        _uiState.update { it.copy(selectedStrategy = strategyName, backtestResult = result) }
    }

    fun selectStressScenario(scenario: MarketStressScenario) {
        _uiState.update { it.copy(selectedStressScenario = scenario) }
    }

    fun onAiInputChanged(text: String) {
        _uiState.update { it.copy(aiInputText = text) }
    }

    fun sendAiPrompt() {
        val text = _uiState.value.aiInputText.trim()
        if (text.isEmpty()) return

        val userMsg = Pair("user", text)
        val newMessages = _uiState.value.aiMessages + userMsg

        val currentSec = _uiState.value.selectedSecurity
        val currentQuote = _uiState.value.activeQuote
        val (bs, inc, cf) = MarketMasterDatabase.getFinancials(currentSec.ticker)

        val assistantResponse = generateAiResponse(text, currentSec, currentQuote, inc, cf)

        _uiState.update { state ->
            state.copy(
                aiMessages = newMessages + Pair("assistant", assistantResponse),
                aiInputText = ""
            )
        }
    }

    private fun generateAiResponse(
        prompt: String,
        security: Security,
        quote: Quote,
        inc: IncomeStatement,
        cf: CashFlowStatement
    ): String {
        return when {
            prompt.contains("估值") || prompt.contains("DCF") -> {
                "【数据血缘: DCF内生现金流折现模型 · 算法版本 2026.3】\n" +
                "标的: ${security.name} (${security.securityId})\n" +
                "• 当前市价: ¥${quote.currentPrice} | 内在估值测算: ¥${_uiState.value.dcfResult.impliedSharePrice}\n" +
                "• 安全边际: ${_uiState.value.dcfResult.marginOfSafetyPct}%\n" +
                "• 估值判定: ${_uiState.value.dcfResult.valuationVerdict}\n" +
                "• 核心假设: WACC=${_uiState.value.dcfInputs.waccPct}%, 永续增长率g=${_uiState.value.dcfInputs.terminalGrowthRatePct}%, 前5年营收增速=${_uiState.value.dcfInputs.revenueGrowthStage1}%。"
            }
            prompt.contains("风险") || prompt.contains("VaR") -> {
                "【数据血缘: 机构风控多因子风险模型 · 历史模拟法】\n" +
                "• 当前持仓最大组合日度VaR(95%置信度): ¥1,250万元\n" +
                "• 维持担保比例: 1273.8% (安全区间 > 140%)\n" +
                "• 连续跌停流动性冲击分析: 若持仓白马股出现极端单边跌停，第1日预期出清概率仅为15%，需预备充裕现金垫防范挤兑风险。"
            }
            prompt.contains("北向") || prompt.contains("外资") -> {
                "【数据血缘: 沪深港通中央结算公开席位持股统计】\n" +
                "• 北向资金今日合计净流入: +105.45 亿元 (沪股通 +48.65亿, 深股通 +56.80亿)\n" +
                "• ${security.name} 外资持股占自由流通市值比例: ${quote.netNorthboundHoldRatio}%\n" +
                "• 偏好行业: 电子半导体、电力设备与新能源、食品饮料核心资产。"
            }
            else -> {
                "【数据血缘: 中国股票市场主数据库 + 申万行业分类】\n" +
                "证券: ${security.name} (${security.securityId}) | 所属板块: ${security.marketSegment.displayName} | 行业: ${security.swIndustryL1}\n" +
                "• 营收: ${inc.totalRevenue.formatDisplay()} (同比 +${inc.revenueGrowthYoY}%)\n" +
                "• 净利润: ${inc.netProfit.formatDisplay()} (同比 +${inc.netProfitGrowthYoY}%)\n" +
                "• ROE: ${inc.roePct}% | 自由现金流: ${cf.freeCashFlow.formatDisplay()}\n" +
                "• 市场微观特征: 今日换手率 ${quote.turnoverRate}%, PE(TTM) ${quote.peTtm}倍, PB ${quote.pb}倍。"
            }
        }
    }
}
