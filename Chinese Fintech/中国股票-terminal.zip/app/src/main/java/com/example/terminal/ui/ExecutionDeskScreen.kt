package com.example.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.domain.*
import com.example.terminal.ui.components.*
import com.example.ui.theme.*

@Composable
fun ExecutionDeskScreen(
    state: TerminalUiState,
    onSubmitOrder: (OrderSide, OrderType, Double, Long) -> Unit,
    onCancelOrder: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val sec = state.selectedSecurity
    val quote = state.activeQuote

    var selectedSide by remember { mutableStateOf(OrderSide.BUY) }
    var selectedOrderType by remember { mutableStateOf(OrderType.LIMIT) }
    var inputPriceText by remember(sec.ticker) { mutableStateOf("%.2f".format(quote.currentPrice)) }
    var inputQuantityText by remember { mutableStateOf("1000") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Order Ticket Panel
        item {
            TerminalCard(
                title = "机构委托交易席位 // ORDER EXECUTION TICKET",
                testTag = "execution_ticket_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Security Banner
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(TerminalDarkBg)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(sec.name, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(6.dp))
                            SegmentTag(sec.securityId, color = TerminalCyan)
                        }
                        Text("现价: ¥%.2f".format(quote.currentPrice), color = TerminalGold, fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    // Side Toggle Buttons
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { selectedSide = OrderSide.BUY },
                            modifier = Modifier.weight(1f).testTag("side_buy_btn"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedSide == OrderSide.BUY) MarketUpRed else TerminalSurfaceVariant
                            ),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("买入 (Long)", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { selectedSide = OrderSide.SELL },
                            modifier = Modifier.weight(1f).testTag("side_sell_btn"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedSide == OrderSide.SELL) MarketDownGreen else TerminalSurfaceVariant
                            ),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("卖出 (Short/Sell)", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Order Type Selector
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(OrderType.LIMIT, OrderType.MARKET).forEach { type ->
                            val isSel = selectedOrderType == type
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSel) TerminalGoldBg else TerminalSurfaceVariant)
                                    .border(1.dp, if (isSel) TerminalGold else TerminalBorderSubtle, RoundedCornerShape(4.dp))
                                    .clickable { selectedOrderType = type }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = type.displayName,
                                    color = if (isSel) TerminalGold else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    // Input Fields
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = inputPriceText,
                            onValueChange = { inputPriceText = it },
                            label = { Text("委托价格 (元)") },
                            modifier = Modifier.weight(1f).testTag("price_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalGold,
                                unfocusedBorderColor = TerminalBorder
                            ),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = inputQuantityText,
                            onValueChange = { inputQuantityText = it },
                            label = { Text("申报股数 (100整数倍)") },
                            modifier = Modifier.weight(1f).testTag("quantity_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TerminalGold,
                                unfocusedBorderColor = TerminalBorder
                            ),
                            singleLine = true
                        )
                    }

                    // Price Limit Warnings
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("涨停价: ¥%.2f".format(quote.limitUpPrice), color = MarketLimitUp, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("跌停价: ¥%.2f".format(quote.limitDownPrice), color = MarketLimitDown, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }

                    // Submit Button
                    Button(
                        onClick = {
                            val price = inputPriceText.toDoubleOrNull() ?: quote.currentPrice
                            val qty = inputQuantityText.toLongOrNull() ?: 1000L
                            onSubmitOrder(selectedSide, selectedOrderType, price, qty)
                        },
                        modifier = Modifier.fillMaxWidth().testTag("submit_order_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedSide == OrderSide.BUY) MarketUpRed else MarketDownGreen
                        ),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "提交 ${selectedSide.displayName} 申报 // SUBMIT ORDER",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // 2. User Submitted Orders Ledger
        item {
            TerminalCard(
                title = "当前会话申报订单列表 // ORDER LEDGER",
                testTag = "orders_ledger_card"
            ) {
                if (state.userOrders.isEmpty()) {
                    Text("暂无委托申报记录，请在上方提交订单。", color = TextMuted, fontSize = 11.sp)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        state.userOrders.forEach { ord ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(TerminalSurfaceVariant)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.2f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        SegmentTag(ord.side.displayName, color = if (ord.side == OrderSide.BUY) MarketUpRed else MarketDownGreen)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(ord.securityName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("${ord.orderId} · ${ord.timestamp}", color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text("¥%.2f x ${ord.quantity}股".format(ord.price), color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    Text("已成交: ${ord.filledQuantity}股", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }

                                Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(0.8f)) {
                                    SegmentTag(ord.status.displayName, color = when (ord.status) {
                                        OrderStatus.FILLED -> MarketUpRed
                                        OrderStatus.REJECTED -> MarketLimitDown
                                        OrderStatus.CANCELLED -> TextMuted
                                        else -> TerminalGold
                                    })
                                    if (ord.status == OrderStatus.ACCEPTED || ord.status == OrderStatus.PARTIAL_FILLED) {
                                        Text(
                                            text = "撤单",
                                            color = TerminalCyan,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clickable { onCancelOrder(ord.orderId) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Algorithmic Execution Cost Estimation
        item {
            TerminalCard(
                title = "算法交易执行成本测算 (VWAP / TWAP)",
                testTag = "algo_execution_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    TerminalDataRow("基准算法", "VWAP 动量成交量加权均价算法", Modifier)
                    TerminalDataRow("预计日内成交均价 (VWAP)", "¥%.2f".format(quote.currentPrice * 1.0015), Modifier)
                    TerminalDataRow("预估市场冲击成本 (Impact Cost)", "3.8 bps", Modifier)
                    TerminalDataRow("预估买卖滑点 (Slippage)", "2.5 bps", Modifier)
                    TerminalDataRow("预期完成率", "98.5%", Modifier, valueColor = TerminalGold)
                }
            }
        }
    }
}
