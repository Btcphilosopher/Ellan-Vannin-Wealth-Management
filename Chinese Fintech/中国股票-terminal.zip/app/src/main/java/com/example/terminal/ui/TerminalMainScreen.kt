package com.example.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.ui.components.SegmentTag
import com.example.ui.theme.*

@Composable
fun TerminalMainScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TerminalHeaderBar(
                state = state,
                onOpenSearch = { viewModel.toggleCommandPalette(true) }
            )
        },
        bottomBar = {
            TerminalStatusBar(state = state)
        },
        containerColor = TerminalDarkBg
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Workspace Navigation Rail / Scrollable Tab Row
            WorkspaceTabRow(
                currentWorkspace = state.currentWorkspace,
                onSelectWorkspace = { viewModel.selectWorkspace(it) }
            )

            HorizontalDivider(color = TerminalBorder)

            // Central Active Workspace
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (state.currentWorkspace) {
                    TerminalWorkspace.MARKET_OVERVIEW -> MarketOverviewScreen(
                        state = state,
                        onSelectSecurity = { viewModel.selectSecurity(it) },
                        onNavigateWorkspace = { viewModel.selectWorkspace(it) }
                    )
                    TerminalWorkspace.SECURITY_QUOTE -> SecurityDetailScreen(
                        state = state,
                        onNavigateWorkspace = { viewModel.selectWorkspace(it) }
                    )
                    TerminalWorkspace.ETF_ARBITRAGE -> EtfTerminalScreen(
                        state = state,
                        onSelectEtf = { viewModel.selectEtf(it) }
                    )
                    TerminalWorkspace.STOCK_CONNECT -> StockConnectScreen(
                        state = state
                    )
                    TerminalWorkspace.FUNDAMENTAL_DCF -> FundamentalValuationScreen(
                        state = state,
                        onUpdateDcf = { w, g, s1, m -> viewModel.updateDcfParameters(w, g, s1, m) }
                    )
                    TerminalWorkspace.QUANT_BACKTEST -> QuantFactorScreen(
                        state = state,
                        onSelectStrategy = { viewModel.selectBacktestStrategy(it) },
                        onSelectStressScenario = { viewModel.selectStressScenario(it) }
                    )
                    TerminalWorkspace.PORTFOLIO_RISK -> PortfolioRiskScreen(
                        state = state
                    )
                    TerminalWorkspace.EXECUTION_DESK -> ExecutionDeskScreen(
                        state = state,
                        onSubmitOrder = { side, type, price, qty -> viewModel.submitOrder(side, type, price, qty) },
                        onCancelOrder = { id -> viewModel.cancelOrder(id) }
                    )
                    TerminalWorkspace.AI_RESEARCH -> AiResearchScreen(
                        state = state,
                        onInputChanged = { viewModel.onAiInputChanged(it) },
                        onSendPrompt = { viewModel.sendAiPrompt() }
                    )
                }
            }
        }

        // Global Command Palette Dialog
        if (state.isCommandPaletteOpen) {
            CommandPaletteDialog(
                query = state.searchQuery,
                searchResults = state.searchResults,
                onQueryChanged = { viewModel.onSearchQueryChanged(it) },
                onSelectSecurity = { viewModel.selectSecurity(it) },
                onNavigateWorkspace = { viewModel.selectWorkspace(it) },
                onDismiss = { viewModel.toggleCommandPalette(false) }
            )
        }
    }
}

@Composable
private fun TerminalHeaderBar(
    state: TerminalUiState,
    onOpenSearch: () -> Unit
) {
    Surface(
        color = TerminalHeaderBg,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Title
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "中国股票",
                    color = TerminalGold,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = " // TERMINAL",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(6.dp))
                SegmentTag(state.tradingSessionName.take(4), color = MarketUpRed)
            }

            // Time & Search Button
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = state.simulationTime,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalSurfaceVariant)
                        .border(1.dp, TerminalBorder, RoundedCornerShape(4.dp))
                        .clickable { onOpenSearch() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("global_search_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = TerminalGold, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("搜索 Ctrl+K", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkspaceTabRow(
    currentWorkspace: TerminalWorkspace,
    onSelectWorkspace: (TerminalWorkspace) -> Unit
) {
    Surface(
        color = TerminalHeaderBg,
        modifier = Modifier.fillMaxWidth()
    ) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(TerminalWorkspace.values()) { ws ->
                val isSelected = ws == currentWorkspace
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) TerminalGoldBg else Color.Transparent)
                        .border(
                            1.dp,
                            if (isSelected) TerminalGold else Color.Transparent,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable { onSelectWorkspace(ws) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("tab_${ws.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = ws.shortcut,
                            color = if (isSelected) TerminalGold else TextMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = ws.title,
                            color = if (isSelected) TerminalGold else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TerminalStatusBar(state: TerminalUiState) {
    Surface(
        color = TerminalHeaderBg,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = state.statusMessage,
                color = TextMuted,
                fontSize = 10.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "规则引擎: SSE-2026V1 / SZSE-2026V2 | 撮合正常",
                color = TerminalCyan,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
