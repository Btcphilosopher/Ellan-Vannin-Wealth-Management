package com.example.terminal.domain

enum class OrderSide(val displayName: String) {
    BUY("买入"),
    SELL("卖出")
}

enum class OrderType(val displayName: String) {
    LIMIT("限价委托"),
    MARKET("市价最优五档即时成交"),
    CALL_AUCTION("集合竞价委托"),
    AFTER_HOURS_FIXED("盘后定价委托")
}

enum class OrderStatus(val displayName: String) {
    PENDING("待提交"),
    ACCEPTED("已申报"),
    PARTIAL_FILLED("部分成交"),
    FILLED("已全部成交"),
    CANCELLED("已撤单"),
    REJECTED("废单/已拒绝")
}

data class OrderLevel(
    val price: Double,
    val volume: Long,       // 股数
    val orderCount: Int     // 委托笔数
)

data class OrderBook(
    val securityId: String,
    val timestamp: String,
    val sequenceNumber: Long,
    val bids: List<OrderLevel>, // 买一 ~ 买五 (或买十) sorted by price descending
    val asks: List<OrderLevel>, // 卖一 ~ 卖五 (或卖十) sorted by price ascending
    val callAuctionVirtualPrice: Double = 0.0,
    val callAuctionMatchedVolume: Long = 0L,
    val callAuctionUnmatchedVolume: Long = 0L,
    val callAuctionImbalanceSide: OrderSide = OrderSide.BUY
)

data class Order(
    val orderId: String,
    val investorId: String,
    val securityId: String,
    val securityName: String,
    val side: OrderSide,
    val orderType: OrderType,
    val price: Double,
    val quantity: Long,          // 股数 (must be multiple of 100 for buy)
    val filledQuantity: Long = 0L,
    val filledAmount: Double = 0.0,
    val timestamp: String,
    val status: OrderStatus = OrderStatus.ACCEPTED,
    val rejectReason: String = ""
) {
    val remainingQuantity: Long get() = quantity - filledQuantity
    val avgFilledPrice: Double get() = if (filledQuantity > 0) filledAmount / filledQuantity else 0.0
}

data class Trade(
    val tradeId: String,
    val securityId: String,
    val price: Double,
    val volume: Long,
    val amount: Double,
    val timestamp: String,
    val side: OrderSide, // Active side (主买 / 主卖)
    val buyOrderId: String = "",
    val sellOrderId: String = ""
)

data class Quote(
    val securityId: String,
    val ticker: String,
    val name: String,
    val exchange: Exchange,
    val marketSegment: MarketSegment,
    val currentPrice: Double,
    val prevClose: Double,
    val openPrice: Double,
    val highPrice: Double,
    val lowPrice: Double,
    val limitUpPrice: Double,
    val limitDownPrice: Double,
    val volume: Long,          // 总手 (1手=100股)
    val amount: Double,        // 成交额 (元)
    val turnoverRate: Double,  // 换手率 (%)
    val peTtm: Double,
    val pb: Double,
    val dividendYield: Double,
    val totalMarketCap: Double, // 总市值 亿元
    val floatMarketCap: Double, // 流通市值 亿元
    val netNorthboundHoldRatio: Double, // 外资持股比例 %
    val marginBalance: Double,  // 融资余额 亿元
    val timestamp: String,
    val isLimitUp: Boolean = false,
    val isLimitDown: Boolean = false
) {
    val changeAmount: Double get() = currentPrice - prevClose
    val changePct: Double get() = if (prevClose > 0) ((currentPrice - prevClose) / prevClose) * 100.0 else 0.0
}
