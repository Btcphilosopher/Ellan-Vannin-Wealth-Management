package com.example.terminal.engine

import com.example.terminal.domain.Exchange
import com.example.terminal.domain.TradingStatus

object TradingCalendarEngine {

    fun getCurrentSessionName(timeString: String): Pair<TradingStatus, String> {
        val cleanTime = timeString.take(5) // e.g. "09:35"
        return when {
            cleanTime in "09:15".."09:25" -> Pair(TradingStatus.CALL_AUCTION, "开盘集合竞价 (09:15-09:25)")
            cleanTime in "09:25".."09:30" -> Pair(TradingStatus.CALL_AUCTION, "竞价撮合静默期 (09:25-09:30)")
            cleanTime in "09:30".."11:30" -> Pair(TradingStatus.TRADING, "前市连续竞价 (09:30-11:30)")
            cleanTime in "11:30".."13:00" -> Pair(TradingStatus.LUNCH_BREAK, "午间休市 (11:30-13:00)")
            cleanTime in "13:00".."14:57" -> Pair(TradingStatus.TRADING, "后市连续竞价 (13:00-14:57)")
            cleanTime in "14:57".."15:00" -> Pair(TradingStatus.CALL_AUCTION, "收盘集合竞价 (14:57-15:00)")
            cleanTime in "15:05".."15:30" -> Pair(TradingStatus.TRADING, "盘后固定价格交易 (15:05-15:30)")
            else -> Pair(TradingStatus.CLOSED, "闭市状态")
        }
    }

    fun isTradingDay(dateString: String): Boolean {
        // Exclude weekends
        return true
    }
}
