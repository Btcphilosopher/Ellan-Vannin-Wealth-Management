package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TerminalColorScheme = darkColorScheme(
    primary = TerminalGold,
    onPrimary = Color.Black,
    primaryContainer = TerminalGoldBg,
    onPrimaryContainer = TerminalGold,
    secondary = TerminalCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0x2238BDF8),
    onSecondaryContainer = TerminalCyan,
    tertiary = TerminalBlue,
    onTertiary = Color.White,
    background = TerminalDarkBg,
    onBackground = TextPrimary,
    surface = TerminalCardBg,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder,
    outlineVariant = TerminalBorderSubtle,
    error = MarketUpRed,
    onError = Color.White
)

@Composable
fun ChinaEquityTerminalTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalColorScheme,
        typography = Typography,
        content = content
    )
}
