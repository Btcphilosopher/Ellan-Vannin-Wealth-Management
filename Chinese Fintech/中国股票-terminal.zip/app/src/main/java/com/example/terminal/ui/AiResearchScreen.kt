package com.example.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.ui.components.*
import com.example.ui.theme.*

@Composable
fun AiResearchScreen(
    state: TerminalUiState,
    onInputChanged: (String) -> Unit,
    onSendPrompt: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Chat History Scroll Area
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    text = "中国股票//AI 机构智能量化研究员",
                    color = TerminalGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "系统遵循零幻觉原则，所有数据计算与研报均标注严谨数据血缘 (Data Provenance)。",
                    color = TextMuted,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            items(state.aiMessages) { (sender, message) ->
                val isUser = sender == "user"
                val isSystem = sender == "system"

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            start = if (isUser) 32.dp else 0.dp,
                            end = if (isUser) 0.dp else 32.dp
                        ),
                    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when {
                                    isUser -> TerminalGoldBg
                                    isSystem -> TerminalSurfaceVariant
                                    else -> TerminalCardBg
                                }
                            )
                            .border(
                                1.dp,
                                when {
                                    isUser -> TerminalGold
                                    isSystem -> TerminalBorder
                                    else -> TerminalBorderSubtle
                                },
                                RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp)
                    ) {
                        Text(
                            text = message,
                            color = when {
                                isUser -> TerminalGold
                                isSystem -> TextSecondary
                                else -> TextPrimary
                            },
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            fontFamily = if (!isUser && !isSystem) FontFamily.Monospace else FontFamily.Default
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Suggestion Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("评估DCF内在价值", "分析北向外资持仓", "查看组合VaR风险").forEach { hint ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(TerminalSurfaceVariant)
                        .clickable {
                            onInputChanged(hint)
                            onSendPrompt()
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(hint, color = TerminalCyan, fontSize = 10.sp)
                }
            }
        }

        // Input Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = state.aiInputText,
                onValueChange = onInputChanged,
                placeholder = { Text("输入研报指令、因子对比或代码...", fontSize = 12.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_prompt_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TerminalGold,
                    unfocusedBorderColor = TerminalBorder
                ),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = onSendPrompt,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(TerminalGold)
                    .testTag("ai_send_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "发送",
                    tint = Color.Black
                )
            }
        }
    }
}
