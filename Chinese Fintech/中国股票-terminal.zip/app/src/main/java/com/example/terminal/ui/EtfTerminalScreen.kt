package com.example.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.domain.*
import com.example.terminal.ui.components.*
import com.example.ui.theme.*

@Composable
fun EtfTerminalScreen(
    state: TerminalUiState,
    onSelectEtf: (EtfProduct) -> Unit,
    modifier: Modifier = Modifier
) {
    val etf = state.selectedEtf

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. ETF Universe Selector
        item {
            Text(
                text = "ETF 标的库 // ETF UNIVERSE",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                state.etfs.forEach { item ->
                    val isSelected = item.ticker == etf.ticker
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) TerminalGoldBg else TerminalCardBg)
                            .border(1.dp, if (isSelected) TerminalGold else TerminalBorderSubtle, RoundedCornerShape(6.dp))
                            .clickable { onSelectEtf(item) }
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SegmentTag(item.category.displayName, color = TerminalCyan)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(item.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("${item.ticker} · 标的: ${item.trackingIndexName}", color = TextMuted, fontSize = 10.sp)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("¥%.3f".format(item.currentPrice), color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            val premium = item.discountPremiumPct
                            Text(
                                text = "折溢: %s%.2f%%".format(if (premium > 0) "+" else "", premium),
                                color = if (premium > 0.05) MarketLimitUp else if (premium < -0.05) MarketLimitDown else MarketFlatGray,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // 2. Selected ETF Deep IOPV & Pricing
        item {
            TerminalCard(
                title = "${etf.name} (${etf.ticker}) 实时折溢价与IOPV监控",
                testTag = "etf_pricing_card"
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("二级市场市价", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "¥%.3f".format(etf.currentPrice),
                            color = if (etf.changePct >= 0) MarketUpRed else MarketDownGreen,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("IOPV 实时参考净值", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "¥%.3f".format(etf.iopv),
                            color = TerminalGold,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("折溢价率", color = TextSecondary, fontSize = 11.sp)
                        val disc = etf.discountPremiumPct
                        Text(
                            text = "%s%.2f%%".format(if (disc > 0) "+" else "", disc),
                            color = if (disc > 0.05) MarketLimitUp else if (disc < -0.05) MarketLimitDown else MarketFlatGray,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = TerminalBorderSubtle)
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TerminalDataRow("基金规模", "¥%.1f 亿元".format(etf.fundSizeAum), Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(12.dp))
                    TerminalDataRow("日成交额", "¥%.1f 亿元".format(etf.turnoverAmount), Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TerminalDataRow("年跟踪误差", "%.2f%%".format(etf.trackingErrorPct), Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(12.dp))
                    TerminalDataRow("管理费率", "%.2f%% / 年".format(etf.managementFeePct), Modifier.weight(1f))
                }
            }
        }

        // 3. ETF Arbitrage Lab (一级市场 vs 二级市场套利测算)
        item {
            TerminalCard(
                title = "ETF 一二级市场套利实验室 // ARBITRAGE LAB",
                testTag = "etf_arbitrage_card"
            ) {
                val premium = etf.discountPremiumPct
                val isPremiumArb = premium > 0.15
                val isDiscountArb = premium < -0.15
                val netSpread = kotlin.math.abs(premium) - 0.12 // 扣除0.12%摩擦成本

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isPremiumArb || isDiscountArb) TerminalGoldBg else TerminalSurfaceVariant)
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when {
                                isPremiumArb -> "⚡ 触发溢价套利机会 (毛基差: +%.2f%% | 净收益空间: +%.2f%%)".format(premium, netSpread)
                                isDiscountArb -> "⚡ 触发折价套利机会 (毛基差: %.2f%% | 净收益空间: +%.2f%%)".format(premium, netSpread)
                                else -> "基差处于合理无套利区间 (-0.12% ~ +0.12%)，无显著确定性套利利润"
                            },
                            color = if (isPremiumArb || isDiscountArb) TerminalGold else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Text(
                        text = "• 套利机制: 一级市场按PCF清单申赎一篮子股票，二级市场实时交易ETF份额。\n" +
                               "• 预估成本: 券商交易佣金(万一) + 经手费 + 冲击滑点(0.08%) + 现金差额替代费。\n" +
                               "• 风险提示: 需防范一篮子成分股个股涨跌停或停牌导致的现金替代溢价风险。",
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // 4. Creation & Redemption Basket (PCF 一篮子股票持仓清单)
        item {
            TerminalCard(
                title = "申赎清单核心成分股 // BASKET (PCF)",
                testTag = "pcf_card"
            ) {
                if (etf.constituents.isEmpty()) {
                    Text("跨境QDII ETF 实行全现金替代申赎模式", color = TextMuted, fontSize = 12.sp)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        etf.constituents.forEach { c ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${c.name} (${c.ticker})", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text("权重: %.2f%%".format(c.weightPct), color = TerminalGold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                Text("${c.shareQuantity} 股", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                SegmentTag(c.cashSubstitutionType, color = TerminalCyan)
                            }
                        }
                    }
                }
            }
        }
    }
}
