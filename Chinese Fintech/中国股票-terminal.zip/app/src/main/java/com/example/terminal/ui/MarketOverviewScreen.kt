package com.example.terminal.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.data.MarketMasterDatabase
import com.example.terminal.domain.*
import com.example.terminal.ui.components.*
import com.example.ui.theme.*

@Composable
fun MarketOverviewScreen(
    state: TerminalUiState,
    onSelectSecurity: (Security) -> Unit,
    onNavigateWorkspace: (TerminalWorkspace) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Major Indices Carousel / Grid
        item {
            Text(
                text = "核心指数 // MAJOR INDICES",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 6.dp)
            )
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(state.indices) { idx ->
                    IndexCard(idx = idx)
                }
            }
        }

        // 2. Market Breadth & Sentiment Section
        item {
            TerminalCard(
                title = "市场宽度与流动性 // MARKET BREADTH & LIQUIDITY",
                testTag = "market_breadth_card"
            ) {
                val b = state.marketBreadth
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    BreadthStatItem("上涨家数", "${b.totalUp}", MarketUpRed)
                    BreadthStatItem("下跌家数", "${b.totalDown}", MarketDownGreen)
                    BreadthStatItem("平盘家数", "${b.totalFlat}", MarketFlatGray)
                    BreadthStatItem("涨停 / 跌停", "${b.limitUpCount} / ${b.limitDownCount}", MarketLimitUp)
                    BreadthStatItem("涨跌中位数", "+${b.medianChangePct}%", MarketUpRed)
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = TerminalBorderSubtle)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("全市场总成交额", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "¥${b.totalMarketTurnover} 亿元",
                            color = TerminalGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column {
                        Text("沪市成交", color = TextSecondary, fontSize = 11.sp)
                        Text("¥${b.shanghaiTurnover} 亿", color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("深市成交", color = TextSecondary, fontSize = 11.sp)
                        Text("¥${b.shenzhenTurnover} 亿", color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    }
                    Column {
                        Text("北交所成交", color = TextSecondary, fontSize = 11.sp)
                        Text("¥${b.beijingTurnover} 亿", color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        // 3. SW Industry Sectors Ranking
        item {
            TerminalCard(
                title = "申万一级行业表现 // SECTOR STRENGTH",
                testTag = "industry_sectors_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    state.industrySectors.take(6).forEach { sector ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceVariant.copy(alpha = 0.5f))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.2f)) {
                                Text(sector.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                Text("领涨: ${sector.leaderSecurityName}", color = TextMuted, fontSize = 10.sp)
                            }
                            Text(
                                text = "成交: ¥${sector.totalAmount}亿",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                            MarketChangeBadge(
                                changePct = sector.changePct,
                                modifier = Modifier.weight(0.7f)
                            )
                        }
                    }
                }
            }
        }

        // 4. Core Securities Fast Access
        item {
            TerminalCard(
                title = "核心标的监控池 // CORE WATCHLIST",
                action = {
                    Text(
                        text = "切换至个股盘口 >",
                        color = TerminalCyan,
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { onNavigateWorkspace(TerminalWorkspace.SECURITY_QUOTE) }
                    )
                },
                testTag = "watchlist_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MarketMasterDatabase.securities.take(5).forEach { sec ->
                        val quote = MarketMasterDatabase.getQuotes().find { it.ticker == sec.ticker }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(TerminalSurfaceVariant.copy(alpha = 0.3f))
                                .clickable {
                                    onSelectSecurity(sec)
                                    onNavigateWorkspace(TerminalWorkspace.SECURITY_QUOTE)
                                }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                SegmentTag(sec.exchange.code, color = TerminalCyan)
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(sec.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Text(sec.ticker, color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                            if (quote != null) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("¥%.2f".format(quote.currentPrice), color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                    Text("换手: %.2f%%".format(quote.turnoverRate), color = TextMuted, fontSize = 10.sp)
                                }
                                MarketChangeBadge(changePct = quote.changePct)
                            }
                        }
                    }
                }
            }
        }

        // 5. Market Announcements & Risk Alerts
        item {
            TerminalCard(
                title = "异动公告与风控预警 // ANNOUNCEMENTS & ALERTS",
                testTag = "alerts_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MarketMasterDatabase.riskAlerts.forEach { alert ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (alert.severity == AlertSeverity.CRITICAL) Color(0x33EF4444) else Color(0x22F59E0B))
                                .border(0.5.dp, if (alert.severity == AlertSeverity.CRITICAL) MarketUpRed else TerminalGold, RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = if (alert.severity == AlertSeverity.CRITICAL) Icons.Default.Warning else Icons.Default.Info,
                                contentDescription = null,
                                tint = if (alert.severity == AlertSeverity.CRITICAL) MarketUpRed else TerminalGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${alert.securityName} (${alert.securityTicker}) - ${alert.title}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(alert.timestamp, color = TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text(alert.description, color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IndexCard(idx: MarketIndex) {
    val isUp = idx.changePct > 0
    val color = if (isUp) MarketUpRed else MarketDownGreen
    val bgColor = if (isUp) MarketUpRedBg else MarketDownGreenBg

    Box(
        modifier = Modifier
            .width(135.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(TerminalCardBg)
            .border(1.dp, TerminalBorderSubtle, RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(idx.name, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                SegmentTag(idx.exchange.code, color = TerminalCyan)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "%.2f".format(idx.currentLevel),
                color = color,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "%s%.2f".format(if (idx.changeLevel > 0) "+" else "", idx.changeLevel),
                    color = color,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "%s%.2f%%".format(if (idx.changePct > 0) "+" else "", idx.changePct),
                    color = color,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun BreadthStatItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextSecondary, fontSize = 10.sp)
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
