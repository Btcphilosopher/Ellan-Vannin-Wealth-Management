package com.example.terminal.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.terminal.domain.*
import com.example.terminal.ui.components.*
import com.example.ui.theme.*
import kotlin.math.max

@Composable
fun SecurityDetailScreen(
    state: TerminalUiState,
    onNavigateWorkspace: (TerminalWorkspace) -> Unit,
    modifier: Modifier = Modifier
) {
    val sec = state.selectedSecurity
    val quote = state.activeQuote
    val orderBook = state.orderBook
    val isUp = quote.changePct >= 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Header & Price Bar
        item {
            TerminalCard(testTag = "security_header_card") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = sec.name,
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            SegmentTag(sec.exchange.code, color = TerminalCyan)
                            Spacer(modifier = Modifier.width(4.dp))
                            SegmentTag(sec.marketSegment.displayName, color = TerminalGold)
                            if (sec.isSt) {
                                Spacer(modifier = Modifier.width(4.dp))
                                SegmentTag(sec.riskStatus.tag, color = MarketLimitUp)
                            }
                        }
                        Text(
                            text = "${sec.securityId} · ${sec.swIndustryL1} > ${sec.swIndustryL2}",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "¥%.2f".format(quote.currentPrice),
                            color = if (isUp) MarketUpRed else MarketDownGreen,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "%s%.2f".format(if (isUp) "+" else "", quote.changeAmount),
                                color = if (isUp) MarketUpRed else MarketDownGreen,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            MarketChangeBadge(changePct = quote.changePct)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = TerminalBorderSubtle)
                Spacer(modifier = Modifier.height(8.dp))

                // Price Limits and Metrics Grid
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricMini("涨停价", "¥%.2f".format(quote.limitUpPrice), MarketLimitUp)
                    MetricMini("跌停价", "¥%.2f".format(quote.limitDownPrice), MarketLimitDown)
                    MetricMini("昨收", "¥%.2f".format(quote.prevClose), TextPrimary)
                    MetricMini("今开", "¥%.2f".format(quote.openPrice), TextPrimary)
                    MetricMini("换手率", "%.2f%%".format(quote.turnoverRate), TerminalGold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricMini("总市值", "¥%.1f亿".format(quote.totalMarketCap), TextPrimary)
                    MetricMini("流通市值", "¥%.1f亿".format(quote.floatMarketCap), TextPrimary)
                    MetricMini("市盈率(TTM)", "%.1f".format(quote.peTtm), TextPrimary)
                    MetricMini("市净率", "%.2f".format(quote.pb), TextPrimary)
                    MetricMini("外资持股", "%.2f%%".format(quote.netNorthboundHoldRatio), TerminalCyan)
                }
            }
        }

        // 2. Interactive Intraday Trend & Candlestick Canvas
        item {
            TerminalCard(
                title = "日内分时走势与量能 // INTRADAY TICK DYNAMICS",
                testTag = "chart_card"
            ) {
                IntradayChart(prevClose = quote.prevClose, currentPrice = quote.currentPrice)
            }
        }

        // 3. Level-5 / Level-10 Order Book & Call Auction Equilibrium
        item {
            TerminalCard(
                title = "Level-2 深度订单簿与撮合状态 // ORDER BOOK & MATCHING",
                testTag = "order_book_card"
            ) {
                // Call Auction Virtual Match Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(TerminalSurfaceVariant)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "集合竞价均衡价: ¥%.2f".format(orderBook.callAuctionVirtualPrice),
                            color = TerminalGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "匹配量: ${orderBook.callAuctionMatchedVolume} 股 | 未匹配: ${orderBook.callAuctionUnmatchedVolume} 股",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Asks (卖五 ~ 卖一, top down from 卖五)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    val maxVolume = max(
                        orderBook.asks.maxOfOrNull { it.volume } ?: 1L,
                        orderBook.bids.maxOfOrNull { it.volume } ?: 1L
                    ).toFloat()

                    orderBook.asks.reversed().forEachIndexed { index, ask ->
                        val askLabel = "卖${orderBook.asks.size - index}"
                        OrderBookRow(
                            label = askLabel,
                            price = ask.price,
                            volume = ask.volume,
                            orderCount = ask.orderCount,
                            maxVolume = maxVolume,
                            isBid = false,
                            prevClose = quote.prevClose
                        )
                    }

                    // Price Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(TerminalBorder)
                    )

                    // Bids (买一 ~ 买五)
                    orderBook.bids.forEachIndexed { index, bid ->
                        val bidLabel = "买${index + 1}"
                        OrderBookRow(
                            label = bidLabel,
                            price = bid.price,
                            volume = bid.volume,
                            orderCount = bid.orderCount,
                            maxVolume = maxVolume,
                            isBid = true,
                            prevClose = quote.prevClose
                        )
                    }
                }
            }
        }

        // 4. Recent Tick Trades
        item {
            TerminalCard(
                title = "逐笔成交明细 // TICK-BY-TICK TRADES",
                testTag = "trades_card"
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    state.recentTrades.take(5).forEach { trade ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(trade.timestamp, color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text(
                                text = "¥%.2f".format(trade.price),
                                color = if (trade.side == OrderSide.BUY) MarketUpRed else MarketDownGreen,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Text("${trade.volume} 股", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            SegmentTag(
                                name = if (trade.side == OrderSide.BUY) "主买" else "主卖",
                                color = if (trade.side == OrderSide.BUY) MarketUpRed else MarketDownGreen
                            )
                        }
                    }
                }
            }
        }

        // 5. Quick Navigation to Execution Desk
        item {
            Button(
                onClick = { onNavigateWorkspace(TerminalWorkspace.EXECUTION_DESK) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("go_to_execution_button"),
                colors = ButtonDefaults.buttonColors(containerColor = TerminalGold),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("前往交易席位执行下单 // EXECUTION DESK", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun OrderBookRow(
    label: String,
    price: Double,
    volume: Long,
    orderCount: Int,
    maxVolume: Float,
    isBid: Boolean,
    prevClose: Double
) {
    val barColor = if (isBid) MarketUpRed.copy(alpha = 0.15f) else MarketDownGreen.copy(alpha = 0.15f)
    val priceColor = if (price >= prevClose) MarketUpRed else MarketDownGreen
    val fillFraction = (volume / maxVolume).coerceIn(0.05f, 1f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(20.dp)
    ) {
        // Background depth bar
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(fillFraction)
                .align(if (isBid) Alignment.CenterStart else Alignment.CenterEnd)
                .background(barColor)
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = TextSecondary, fontSize = 10.sp, modifier = Modifier.width(28.dp))
            Text(
                text = "¥%.2f".format(price),
                color = priceColor,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "$volume 股",
                color = TextPrimary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "$orderCount 笔",
                color = TextMuted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun MetricMini(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextMuted, fontSize = 9.sp)
        Text(value, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun IntradayChart(prevClose: Double, currentPrice: Double) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .background(TerminalDarkBg)
            .border(0.5.dp, TerminalBorderSubtle, RoundedCornerShape(4.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Reference zero line (prevClose)
            val midY = height * 0.45f
            drawLine(
                color = Color(0x5594A3B8),
                start = Offset(0f, midY),
                end = Offset(width, midY),
                strokeWidth = 1f,
                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
            )

            // Synthetic price points
            val points = listOf(
                0.0f to 0.48f, 0.1f to 0.46f, 0.2f to 0.42f, 0.3f to 0.38f,
                0.4f to 0.40f, 0.5f to 0.35f, 0.6f to 0.32f, 0.7f to 0.34f,
                0.8f to 0.30f, 0.9f to 0.28f, 1.0f to 0.25f
            )

            val path = Path()
            points.forEachIndexed { i, (xRatio, yRatio) ->
                val x = xRatio * width
                val y = yRatio * height
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }

            drawPath(
                path = path,
                color = MarketUpRed,
                style = Stroke(width = 2.5f)
            )

            // Volume sub-bars at bottom
            val barCount = 20
            val barWidth = width / barCount
            for (i in 0 until barCount) {
                val barHeight = (15 + (i * 7) % 35).toFloat()
                drawRect(
                    color = if (i % 3 == 0) MarketDownGreen.copy(alpha = 0.5f) else MarketUpRed.copy(alpha = 0.5f),
                    topLeft = Offset(i * barWidth + 2f, height - barHeight),
                    size = Size(barWidth - 4f, barHeight)
                )
            }
        }
    }
}
