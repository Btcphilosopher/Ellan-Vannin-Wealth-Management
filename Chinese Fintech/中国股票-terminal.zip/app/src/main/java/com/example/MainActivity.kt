package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.terminal.ui.TerminalMainScreen
import com.example.terminal.ui.TerminalViewModel
import com.example.ui.theme.ChinaEquityTerminalTheme

class MainActivity : ComponentActivity() {
    private val viewModel: TerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ChinaEquityTerminalTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    TerminalMainScreen(viewModel = viewModel)
                }
            }
        }
    }
}
