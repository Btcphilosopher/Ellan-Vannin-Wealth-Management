package com.example.terminal.domain

import kotlin.math.round

data class MarketRuleVersion(
    val versionId: String,
    val exchange: Exchange,
    val name: String,
    val effectiveDate: String,
    val tickSizeRmb: Double = 0.01,
    val tickSizeFund: Double = 0.001,
    val lotSizeBuy: Int = 100,
    val lotSizeSell: Int = 1, // Can sell odd lots
    val tPlusDays: Int = 1, // A-shares T+1
    val description: String
)

object MarketRuleRegistry {
    val SSE_2026 = MarketRuleVersion(
        versionId = "SSE-TR-2026V1",
        exchange = Exchange.SSE,
        name = "上海证券交易所交易规则 (2026修订版)",
        effectiveDate = "2026-03-01",
        tickSizeRmb = 0.01,
        tickSizeFund = 0.001,
        lotSizeBuy = 100,
        lotSizeSell = 1,
        tPlusDays = 1,
        description = "上海证券交易所主板、科创板及ETF竞价与做市交易规则。"
    )

    val SZSE_2026 = MarketRuleVersion(
        versionId = "SZSE-TR-2026V2",
        exchange = Exchange.SZSE,
        name = "深圳证券交易所交易规则 (2026年7月修订施行版)",
        effectiveDate = "2026-07-06",
        tickSizeRmb = 0.01,
        tickSizeFund = 0.001,
        lotSizeBuy = 100,
        lotSizeSell = 1,
        tPlusDays = 1,
        description = "深圳证券交易所主板、创业板全面注册制与盘后定价交易细则。"
    )

    val BSE_2026 = MarketRuleVersion(
        versionId = "BSE-TR-2026V1",
        exchange = Exchange.BSE,
        name = "北京证券交易所交易规则",
        effectiveDate = "2026-01-01",
        tickSizeRmb = 0.01,
        tickSizeFund = 0.001,
        lotSizeBuy = 100,
        lotSizeSell = 1,
        tPlusDays = 1,
        description = "北京证券交易所股票竞价交易实行30%涨跌幅限制规则。"
    )

    fun calculatePriceLimits(security: Security, prevClose: Double): Pair<Double, Double> {
        // Check IPO exemption (first 5 trading days on STAR/ChiNext/BSE have no limit)
        if (security.ipoDaysCount <= 5 && (security.marketSegment == MarketSegment.STAR || security.marketSegment == MarketSegment.CHINEXT || security.marketSegment == MarketSegment.BSE)) {
            return Pair(round(prevClose * 10.0 * 100) / 100.0, 0.01) // Virtually unlimited
        }

        val limitPct = when {
            security.riskStatus == RiskStatus.ST || security.riskStatus == RiskStatus.STAR_ST -> 5.0
            security.riskStatus == RiskStatus.DELISTING -> 10.0
            security.marketSegment == MarketSegment.STAR -> 20.0
            security.marketSegment == MarketSegment.CHINEXT -> 20.0
            security.marketSegment == MarketSegment.BSE -> 30.0
            security.marketSegment == MarketSegment.ETF -> {
                if (security.name.contains("科创") || security.name.contains("创业板")) 20.0 else 10.0
            }
            else -> 10.0 // Main board 10%
        }

        val limitUpRaw = prevClose * (1.0 + limitPct / 100.0)
        val limitDownRaw = prevClose * (1.0 - limitPct / 100.0)

        // Standard Chinese rounding to 2 decimal places (0.01 RMB)
        val limitUp = round(limitUpRaw * 100.0) / 100.0
        val limitDown = round(limitDownRaw * 100.0) / 100.0

        return Pair(limitUp, limitDown)
    }
}
