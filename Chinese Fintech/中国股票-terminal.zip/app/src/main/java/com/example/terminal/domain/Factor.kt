package com.example.terminal.domain

data class SecurityFactorExposure(
    val ticker: String,
    val name: String,
    val valueScore: Double,      // 价值因子 (PE/PB/股息) [-3.0 ~ +3.0]
    val qualityScore: Double,    // 质量因子 (ROE/毛利率/资产负债)
    val growthScore: Double,     // 成长因子 (营收增速/净利增速)
    val momentumScore: Double,   // 动量因子 (20日/60日收益率)
    val lowVolScore: Double,     // 低波因子 (历史波动率反向)
    val sizeScore: Double,       // 规模因子 (对数市值)
    val turnoverScore: Double,   // 换手活跃因子
    val northboundHoldScore: Double, // 北向外资偏好
    val marginFinScore: Double   // 杠杆融资做多强度
)

data class BacktestConfig(
    val strategyName: String,
    val benchmark: String = "沪深300 (000300.SH)",
    val startDate: String = "2023-01-01",
    val endDate: String = "2026-09-30",
    val initialCapital: Double = 10000000.0, // 1000万元
    val rebalancePeriod: String = "月度调仓",
    val topNConstituents: Int = 30,
    val slippageBps: Double = 5.0, // 滑点 5 bps
    val commissionRate: Double = 0.0003 // 佣金万三 + 印花税千一
)

data class BacktestPoint(
    val date: String,
    val strategyCumulativeReturn: Double, // %
    val benchmarkCumulativeReturn: Double, // %
    val excessReturn: Double,             // %
    val portfolioDrawdown: Double         // %
)

data class BacktestResult(
    val config: BacktestConfig,
    val totalReturnPct: Double,
    val annualizedReturnPct: Double,
    val benchmarkReturnPct: Double,
    val alphaPct: Double,
    val beta: Double,
    val sharpeRatio: Double,
    val maxDrawdownPct: Double,
    val calmarRatio: Double,
    val informationRatio: Double,
    val winRatePct: Double,
    val turnoverRateAnnualPct: Double,
    val equityCurve: List<BacktestPoint>
)

data class MarketStressScenario(
    val scenarioId: String,
    val name: String,
    val description: String,
    val indexImpactPct: Double,
    val highBetaDropPct: Double,
    val financialSectorDropPct: Double,
    val techSectorDropPct: Double,
    val northboundOutflowBillion: Double,
    val liquidityFreezeRiskStocks: List<String>
)
