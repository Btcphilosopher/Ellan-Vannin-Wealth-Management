package com.example.terminal.engine

import com.example.terminal.domain.*
import java.util.UUID
import kotlin.math.min
import kotlin.math.round

class MatchingEngine(
    val securityId: String,
    private var currentPrice: Double,
    private val limitUpPrice: Double,
    private val limitDownPrice: Double
) {
    // Buy orders sorted by: price DESCENDING, timestamp ASCENDING
    private val buyBook = mutableListOf<Order>()
    // Sell orders sorted by: price ASCENDING, timestamp ASCENDING
    private val sellBook = mutableListOf<Order>()

    private val executedTrades = mutableListOf<Trade>()
    private var sequenceNumber = 1000L

    fun submitOrder(order: Order): Pair<List<Trade>, Order> {
        // Price limit validation
        if (order.price > limitUpPrice || order.price < limitDownPrice) {
            val rejected = order.copy(
                status = OrderStatus.REJECTED,
                rejectReason = "价格 %.2f 超出涨跌停限制区间 [%.2f, %.2f]".format(order.price, limitDownPrice, limitUpPrice)
            )
            return Pair(emptyList(), rejected)
        }

        // Lot size validation (buy must be 100 shares multiple)
        if (order.side == OrderSide.BUY && order.quantity % 100L != 0L) {
            val rejected = order.copy(
                status = OrderStatus.REJECTED,
                rejectReason = "买入申报数量必须为100股的整数倍 (当前: %d 股)".format(order.quantity)
            )
            return Pair(emptyList(), rejected)
        }

        val trades = mutableListOf<Trade>()
        var workingOrder = order.copy(status = OrderStatus.ACCEPTED)

        if (workingOrder.side == OrderSide.BUY) {
            // Match against sell book
            val sellIterator = sellBook.iterator()
            while (sellIterator.hasNext() && workingOrder.remainingQuantity > 0) {
                val bestSell = sellIterator.next()
                // Can match if buy price >= sell price (or market order)
                if (workingOrder.orderType == OrderType.MARKET || workingOrder.price >= bestSell.price) {
                    val matchPrice = bestSell.price // Trade at resting order's price
                    val matchQty = min(workingOrder.remainingQuantity, bestSell.remainingQuantity)

                    val trade = Trade(
                        tradeId = "TRD-" + UUID.randomUUID().toString().take(8).uppercase(),
                        securityId = securityId,
                        price = matchPrice,
                        volume = matchQty,
                        amount = matchPrice * matchQty,
                        timestamp = "09:35:" + (10 + (sequenceNumber % 50)),
                        side = OrderSide.BUY,
                        buyOrderId = workingOrder.orderId,
                        sellOrderId = bestSell.orderId
                    )
                    trades.add(trade)
                    executedTrades.add(trade)
                    currentPrice = matchPrice

                    // Update resting sell order
                    val newFilledQty = bestSell.filledQuantity + matchQty
                    val newFilledAmt = bestSell.filledAmount + (matchPrice * matchQty)
                    val updatedSell = bestSell.copy(
                        filledQuantity = newFilledQty,
                        filledAmount = newFilledAmt,
                        status = if (newFilledQty >= bestSell.quantity) OrderStatus.FILLED else OrderStatus.PARTIAL_FILLED
                    )

                    if (updatedSell.status == OrderStatus.FILLED) {
                        sellIterator.remove()
                    }

                    // Update incoming buy order
                    val buyFilledQty = workingOrder.filledQuantity + matchQty
                    val buyFilledAmt = workingOrder.filledAmount + (matchPrice * matchQty)
                    workingOrder = workingOrder.copy(
                        filledQuantity = buyFilledQty,
                        filledAmount = buyFilledAmt,
                        status = if (buyFilledQty >= workingOrder.quantity) OrderStatus.FILLED else OrderStatus.PARTIAL_FILLED
                    )
                } else {
                    break // Remaining sell orders have price > buy price
                }
            }

            // If remaining quantity and is limit order, insert into buy book
            if (workingOrder.remainingQuantity > 0 && workingOrder.orderType == OrderType.LIMIT) {
                insertBuyOrder(workingOrder)
            }
        } else {
            // Match against buy book
            val buyIterator = buyBook.iterator()
            while (buyIterator.hasNext() && workingOrder.remainingQuantity > 0) {
                val bestBuy = buyIterator.next()
                if (workingOrder.orderType == OrderType.MARKET || workingOrder.price <= bestBuy.price) {
                    val matchPrice = bestBuy.price
                    val matchQty = min(workingOrder.remainingQuantity, bestBuy.remainingQuantity)

                    val trade = Trade(
                        tradeId = "TRD-" + UUID.randomUUID().toString().take(8).uppercase(),
                        securityId = securityId,
                        price = matchPrice,
                        volume = matchQty,
                        amount = matchPrice * matchQty,
                        timestamp = "09:35:" + (10 + (sequenceNumber % 50)),
                        side = OrderSide.SELL,
                        buyOrderId = bestBuy.orderId,
                        sellOrderId = workingOrder.orderId
                    )
                    trades.add(trade)
                    executedTrades.add(trade)
                    currentPrice = matchPrice

                    val newFilledQty = bestBuy.filledQuantity + matchQty
                    val newFilledAmt = bestBuy.filledAmount + (matchPrice * matchQty)
                    val updatedBuy = bestBuy.copy(
                        filledQuantity = newFilledQty,
                        filledAmount = newFilledAmt,
                        status = if (newFilledQty >= bestBuy.quantity) OrderStatus.FILLED else OrderStatus.PARTIAL_FILLED
                    )

                    if (updatedBuy.status == OrderStatus.FILLED) {
                        buyIterator.remove()
                    }

                    val sellFilledQty = workingOrder.filledQuantity + matchQty
                    val sellFilledAmt = workingOrder.filledAmount + (matchPrice * matchQty)
                    workingOrder = workingOrder.copy(
                        filledQuantity = sellFilledQty,
                        filledAmount = sellFilledAmt,
                        status = if (sellFilledQty >= workingOrder.quantity) OrderStatus.FILLED else OrderStatus.PARTIAL_FILLED
                    )
                } else {
                    break
                }
            }

            if (workingOrder.remainingQuantity > 0 && workingOrder.orderType == OrderType.LIMIT) {
                insertSellOrder(workingOrder)
            }
        }

        sequenceNumber++
        return Pair(trades, workingOrder)
    }

    private fun insertBuyOrder(order: Order) {
        // Price DESCENDING, timestamp ASCENDING
        val index = buyBook.indexOfFirst { it.price < order.price }
        if (index == -1) {
            buyBook.add(order)
        } else {
            buyBook.add(index, order)
        }
    }

    private fun insertSellOrder(order: Order) {
        // Price ASCENDING, timestamp ASCENDING
        val index = sellBook.indexOfFirst { it.price > order.price }
        if (index == -1) {
            sellBook.add(order)
        } else {
            sellBook.add(index, order)
        }
    }

    fun cancelOrder(orderId: String): Order? {
        val buyIdx = buyBook.indexOfFirst { it.orderId == orderId }
        if (buyIdx != -1) {
            val removed = buyBook.removeAt(buyIdx)
            return removed.copy(status = OrderStatus.CANCELLED)
        }
        val sellIdx = sellBook.indexOfFirst { it.orderId == orderId }
        if (sellIdx != -1) {
            val removed = sellBook.removeAt(sellIdx)
            return removed.copy(status = OrderStatus.CANCELLED)
        }
        return null
    }

    /**
     * Executes Call Auction (集合竞价最大成交量均衡价撮合)
     * Rules: 
     * 1. 产生最大成交量的价格
     * 2. 高于该价格的买入申报与低于该价格的卖出申报全部成交
     * 3. 与该价格相同的买方或卖方中至少有一方全部成交
     */
    fun executeCallAuction(): Pair<Double, Long> {
        val allPrices = (buyBook.map { it.price } + sellBook.map { it.price }).distinct().sorted()
        if (allPrices.isEmpty()) return Pair(currentPrice, 0L)

        var maxVolume = 0L
        var optimalPrice = currentPrice
        var minImbalance = Long.MAX_VALUE

        for (testPrice in allPrices) {
            val buyVol = buyBook.filter { it.price >= testPrice }.sumOf { it.remainingQuantity }
            val sellVol = sellBook.filter { it.price <= testPrice }.sumOf { it.remainingQuantity }
            val matchVol = min(buyVol, sellVol)
            val imbalance = kotlin.math.abs(buyVol - sellVol)

            if (matchVol > maxVolume || (matchVol == maxVolume && imbalance < minImbalance)) {
                maxVolume = matchVol
                optimalPrice = testPrice
                minImbalance = imbalance
            }
        }

        if (maxVolume > 0) {
            currentPrice = optimalPrice
        }
        return Pair(optimalPrice, maxVolume)
    }

    fun getOrderBookSnapshot(levels: Int = 10): OrderBook {
        val bidLevels = buyBook.groupBy { it.price }
            .map { (price, orders) ->
                OrderLevel(price, orders.sumOf { it.remainingQuantity }, orders.size)
            }
            .sortedByDescending { it.price }
            .take(levels)

        val askLevels = sellBook.groupBy { it.price }
            .map { (price, orders) ->
                OrderLevel(price, orders.sumOf { it.remainingQuantity }, orders.size)
            }
            .sortedBy { it.price }
            .take(levels)

        val (auctionPrice, auctionVol) = executeCallAuction()

        return OrderBook(
            securityId = securityId,
            timestamp = "09:30:00",
            sequenceNumber = sequenceNumber,
            bids = bidLevels,
            asks = askLevels,
            callAuctionVirtualPrice = auctionPrice,
            callAuctionMatchedVolume = auctionVol,
            callAuctionUnmatchedVolume = if (bidLevels.isNotEmpty() && askLevels.isNotEmpty()) 
                kotlin.math.abs(bidLevels.first().volume - askLevels.first().volume) else 0L
        )
    }

    fun getTrades(): List<Trade> = executedTrades.takeLast(50)
}
