package com.example.terminal.domain

enum class InstitutionalType(val displayName: String) {
    MUTUAL_FUND("公募证券投资基金"),
    PRIVATE_QUANT("私募量化多头/对冲基金"),
    BROKER_PROPRIETARY("券商自营投资部"),
    INSURANCE_ASSET("险资高股息配置专户"),
    FAMILY_OFFICE("家族办公室专户")
}

data class Position(
    val securityId: String,
    val ticker: String,
    val name: String,
    val quantity: Long,             // 持股数 (股)
    val availableQuantity: Long,    // 可用股数 (T+1规则)
    val avgCostPrice: Double,       // 持仓成本 (元)
    val currentPrice: Double,       // 最新价 (元)
    val marketValue: Double,        // 市值 (元)
    val weightPct: Double,          // 组合权重 %
    val unrealizedPnl: Double,      // 浮动盈亏 (元)
    val unrealizedPnlPct: Double,   // 浮动盈亏率 %
    val dailyPnl: Double            // 当日盈亏 (元)
)

data class MarginFinancingAccount(
    val totalCollateralValue: Double,   // 担保品总市值 (元)
    val marginBorrowAmount: Double,     // 融资负债 (元)
    val securitiesBorrowAmount: Double, // 融券负债 (元)
    val availableCash: Double,          // 可用现金 (元)
    val maintenanceRatioPct: Double,    // 维持担保比例 % (平仓线通常 130%, 预警线 140%)
    val warningLinePct: Double = 140.0,
    val liquidationLinePct: Double = 130.0,
    val maxBorrowQuota: Double = 50000000.0 // 融资融券授信额度 5000万元
) {
    val isWarning: Boolean get() = maintenanceRatioPct <= warningLinePct
    val isLiquidationRisk: Boolean get() = maintenanceRatioPct <= liquidationLinePct
}

data class Portfolio(
    val portfolioId: String,
    val name: String,
    val institutionalType: InstitutionalType,
    val initialCapital: Double,     // 初始本金
    val totalAssetValue: Double,    // 总资产
    val cashBalance: Double,        // 现金可用
    val positions: List<Position>,
    val marginAccount: MarginFinancingAccount,
    val dailyPnl: Double,
    val dailyPnlPct: Double,
    val mtdPnlPct: Double,
    val ytdPnlPct: Double,
    val var95Daily: Double,         // 95% 置信度日度 VaR (元)
    val betaToHs300: Double,
    val top5ConcentrationPct: Double
)
