package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.terminal.domain.*
import com.example.terminal.engine.DcfValuationEngine
import com.example.terminal.engine.MatchingEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app string resource from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("中国股票 TERMINAL", appName)
    }

    @Test
    fun `test matching engine price limit and order execution`() {
        val engine = MatchingEngine(
            securityId = "600519.SH",
            currentPrice = 1685.00,
            limitUpPrice = 1820.72,
            limitDownPrice = 1489.68
        )

        // Submit Sell Order @ 1685.00
        val sellOrder = Order(
            orderId = "SELL-001",
            investorId = "INV-01",
            securityId = "600519.SH",
            securityName = "贵州茅台",
            side = OrderSide.SELL,
            orderType = OrderType.LIMIT,
            price = 1685.00,
            quantity = 1000L,
            timestamp = "09:30:00"
        )
        val (trades1, resSell) = engine.submitOrder(sellOrder)
        assertEquals(0, trades1.size)
        assertEquals(OrderStatus.ACCEPTED, resSell.status)

        // Submit Matching Buy Order @ 1685.00
        val buyOrder = Order(
            orderId = "BUY-001",
            investorId = "INV-02",
            securityId = "600519.SH",
            securityName = "贵州茅台",
            side = OrderSide.BUY,
            orderType = OrderType.LIMIT,
            price = 1685.00,
            quantity = 1000L,
            timestamp = "09:30:05"
        )
        val (trades2, resBuy) = engine.submitOrder(buyOrder)
        assertEquals(1, trades2.size)
        assertEquals(1000L, trades2[0].volume)
        assertEquals(1685.00, trades2[0].price, 0.001)
        assertEquals(OrderStatus.FILLED, resBuy.status)
    }

    @Test
    fun `test DCF valuation calculation`() {
        val inputs = DcfModelInputs(
            currentRevenue = 100.0,
            revenueGrowthStage1 = 10.0,
            revenueGrowthStage2 = 5.0,
            operatingMarginPct = 40.0,
            taxRatePct = 15.0,
            capexToRevenuePct = 5.0,
            waccPct = 8.5,
            terminalGrowthRatePct = 2.5,
            netDebtAmount = 0.0,
            totalSharesCount = 10.0
        )
        val res = DcfValuationEngine.calculateDcf(inputs, 50.00)
        assertTrue(res.impliedSharePrice > 0.0)
        assertEquals(5, res.sensitivityMatrix.size)
    }
}
