"use client";

import * as React from "react";
import { 
  ShoppingCart, 
  Search, 
  Mic, 
  User, 
  ChevronRight, 
  Smartphone, 
  Tv, 
  Shirt, 
  Sparkles, 
  Baby, 
  Home, 
  Activity, 
  Utensils, 
  Car, 
  Heart, 
  Plus, 
  Minus, 
  X, 
  Check, 
  Clock, 
  ArrowRight, 
  Truck, 
  Package, 
  RotateCcw, 
  ShieldCheck, 
  ShoppingBag, 
  Grid, 
  Volume2, 
  PhoneCall, 
  Menu, 
  HeartHandshake, 
  ClipboardCheck, 
  Sparkle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { MOCK_PRODUCTS, CATEGORIES, Product, Category } from "@/lib/data";

// Type-safe Category Icon Mapper
function CategoryIcon({ name, className }: { name: string; className?: string }) {
  switch (name) {
    case 'Smartphone': return <Smartphone className={className} />;
    case 'Tv': return <Tv className={className} />;
    case 'Shirt': return <Shirt className={className} />;
    case 'Sparkles': return <Sparkles className={className} />;
    case 'Baby': return <Baby className={className} />;
    case 'Home': return <Home className={className} />;
    case 'Activity': return <Activity className={className} />;
    case 'Utensils': return <Utensils className={className} />;
    case 'Car': return <Car className={className} />;
    default: return <Smartphone className={className} />;
  }
}

// Stable Pure Counter & Helpers Outside Render Scope to satisfy React 19 ESLint Purity Rules
let toastIdCounter = 0;
function getNextToastId(): number {
  toastIdCounter += 1;
  return toastIdCounter;
}

function getRandomPhrase(): string {
  const phrases = ["九阳空气炸锅", "李宁运动鞋", "小米手机", "方便面整箱装", "蓝牙降噪耳机"];
  return phrases[Math.floor(Math.random() * phrases.length)];
}

export default function HomePage() {
  // --- STATE ---
  const [products, setProducts] = React.useState<Product[]>(MOCK_PRODUCTS);
  const [selectedCategory, setSelectedCategory] = React.useState<string | null>(null);
  const [searchQuery, setSearchQuery] = React.useState<string>("");
  const [isSearchFocused, setIsSearchFocused] = React.useState<boolean>(false);
  const [favorites, setFavorites] = React.useState<string[]>([]);
  const [cart, setCart] = React.useState<{ product: Product; quantity: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = React.useState<boolean>(false);
  const [selectedProduct, setSelectedProduct] = React.useState<Product | null>(null);
  const [activeHoverCategory, setActiveHoverCategory] = React.useState<string | null>(null);
  
  // Animation state for cart badge
  const [cartBadgeAnimate, setCartBadgeAnimate] = React.useState<boolean>(false);
  
  // Toasts
  const [toasts, setToasts] = React.useState<{ id: number; message: string; type: "success" | "info" }[]>([]);
  
  // Simulated Voice Search state
  const [isListening, setIsListening] = React.useState<boolean>(false);
  
  // Order checkout simulated steps
  const [isCheckoutOpen, setIsCheckoutOpen] = React.useState<boolean>(false);
  const [shippingAddress, setShippingAddress] = React.useState<string>("");
  const [checkoutStep, setCheckoutStep] = React.useState<"form" | "loading" | "success">("form");
  const [simulatedTracking, setSimulatedTracking] = React.useState<string[]>([]);

  // Flash Sale Timer
  const [countdown, setCountdown] = React.useState({ hours: 2, minutes: 36, seconds: 18 });

  // --- LOCAL STORAGE SYNC ---
  React.useEffect(() => {
    const savedCart = localStorage.getItem("hsg_cart");
    const savedFavs = localStorage.getItem("hsg_favorites");
    
    // Defer local storage loaded state to avoid synchronous state update cascading renders warning
    const timer = setTimeout(() => {
      if (savedCart) {
        try {
          setCart(JSON.parse(savedCart));
        } catch (e) {
          console.error(e);
        }
      }
      if (savedFavs) {
        try {
          setFavorites(JSON.parse(savedFavs));
        } catch (e) {
          console.error(e);
        }
      }
    }, 0);
    
    return () => clearTimeout(timer);
  }, []);

  const updateCartState = (newCart: { product: Product; quantity: number }[]) => {
    setCart(newCart);
    localStorage.setItem("hsg_cart", JSON.stringify(newCart));
    setCartBadgeAnimate(true);
    setTimeout(() => setCartBadgeAnimate(false), 300);
  };

  const updateFavoritesState = (newFavs: string[]) => {
    setFavorites(newFavs);
    localStorage.setItem("hsg_favorites", JSON.stringify(newFavs));
  };

  // --- FLASH SALE TIMER COUNTDOWN ---
  React.useEffect(() => {
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          // Reset countdown to keep the live effect going
          return { hours: 2, minutes: 59, seconds: 59 };
        }
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // --- TOAST TRIGGER ---
  const triggerToast = (message: string, type: "success" | "info" = "success") => {
    const id = getNextToastId();
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  };

  // --- HANDLERS ---
  const handleAddToCart = (product: Product, e?: React.MouseEvent, quantity = 1) => {
    if (e) e.stopPropagation();
    
    const existingIndex = cart.findIndex((item) => item.product.id === product.id);
    let newCart = [...cart];
    if (existingIndex > -1) {
      newCart[existingIndex].quantity += quantity;
    } else {
      newCart.push({ product, quantity });
    }
    updateCartState(newCart);
    triggerToast(`🛒 ${product.name} 已加入购物车`, "success");
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    const updated = cart.map((item) => {
      if (item.product.id === productId) {
        const newQty = item.quantity + delta;
        return { ...item, quantity: newQty < 1 ? 1 : newQty };
      }
      return item;
    }).filter((item) => item.quantity > 0);
    updateCartState(updated);
  };

  const handleRemoveFromCart = (productId: string) => {
    const updated = cart.filter((item) => item.product.id !== productId);
    updateCartState(updated);
    triggerToast("已将商品移出购物车", "info");
  };

  const handleToggleFavorite = (productId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const isFav = favorites.includes(productId);
    let newFavs = [];
    if (isFav) {
      newFavs = favorites.filter((id) => id !== productId);
      triggerToast("已取消收藏", "info");
    } else {
      newFavs = [...favorites, productId];
      triggerToast("⭐ 已加入我的收藏", "success");
    }
    updateFavoritesState(newFavs);
  };

  // Simulated Voice Listening
  const handleTriggerVoice = () => {
    if (isListening) return;
    setIsListening(true);
    triggerToast("🎤 正在聆听您的声音...", "info");
    
    const randomPhrase = getRandomPhrase();
    
    setTimeout(() => {
      setSearchQuery(randomPhrase);
      setIsListening(false);
      triggerToast(`🎤 语音识别成功: "${randomPhrase}"`, "success");
    }, 2000);
  };

  // Simulated Checkout Flow
  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shippingAddress.trim()) {
      triggerToast("请输入收货地址", "info");
      return;
    }
    setCheckoutStep("loading");
    
    setTimeout(() => {
      setCheckoutStep("success");
      setSimulatedTracking([
        "【好省购】订单创建成功 - 源头工厂已接收指令",
        "【常州智慧物流仓】机器人正在进行自动化高速分拣与多重品控",
        "【顺丰速运】包裹已打包并装入集装箱，预计明日12:00前送达"
      ]);
      // Clear cart
      updateCartState([]);
    }, 1800);
  };

  // --- SEARCH AND FILTERS ---
  const searchSuggestions = [
    "手机", "手机壳", "手机耳机", "手机充电器", "空气炸锅", "运动鞋", "洗衣机", "护肤套装", "零食"
  ].filter(s => s.toLowerCase().includes(searchQuery.toLowerCase()));

  const filteredProducts = MOCK_PRODUCTS.filter((product) => {
    const matchesCategory = selectedCategory ? product.category === selectedCategory : true;
    const matchesSearch = searchQuery 
      ? product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    return matchesCategory && matchesSearch;
  });

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div id="app-container" className="min-h-screen bg-[#F5F5F7] text-[#111417] flex flex-col font-sans selection:bg-[#F5222D] selection:text-white">
      
      {/* TOAST SYSTEM */}
      <div id="toast-container" className="fixed top-5 right-5 z-50 flex flex-col gap-2 max-w-md pointer-events-none">
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: -20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.15 } }}
              className={`px-4 py-3 rounded-xl shadow-lg flex items-center gap-2 pointer-events-auto border ${
                toast.type === "success" 
                  ? "bg-white border-green-100 text-green-800" 
                  : "bg-white border-red-100 text-red-800"
              }`}
            >
              {toast.type === "success" ? (
                <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center text-green-600 shrink-0">
                  <Check className="w-3.5 h-3.5" />
                </div>
              ) : (
                <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center text-red-600 shrink-0">
                  <Volume2 className="w-3.5 h-3.5" />
                </div>
              )}
              <span className="text-sm font-medium">{toast.message}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* TOP NOTIFIER / ANNOUNCEMENT TICKER */}
      <div id="promo-ticker" className="bg-[#FF4D2D] text-white py-1.5 px-4 text-xs font-medium text-center relative overflow-hidden hidden md:block">
        <div className="animate-pulse inline-flex items-center gap-2">
          <span className="bg-white/20 px-2 py-0.5 rounded-full text-[10px]">公告</span>
          <span>🔥 跨省极速配送体系已就绪！下单即享「源头直发·全网包邮·闪电发货」保障</span>
        </div>
      </div>

      {/* --- HEADER --- */}
      <header id="main-header" className="bg-[#111417] text-white sticky top-0 z-40 transition-shadow duration-300 shadow-md">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="flex items-center justify-between h-16 md:h-20 gap-4">
            
            {/* Logo */}
            <div 
              id="header-logo" 
              className="flex items-center gap-2 cursor-pointer shrink-0"
              onClick={() => {
                setSelectedCategory(null);
                setSearchQuery("");
              }}
            >
              {/* Specialized Chinese Ecommerce Emblem */}
              <div className="w-10 h-10 md:w-11 md:h-11 rounded-xl bg-gradient-to-tr from-[#F5222D] to-[#FF7A45] flex items-center justify-center shadow-lg shadow-red-950/20">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl md:text-2xl font-black tracking-tight text-white flex items-center gap-1">
                  好省购
                  <span className="text-[10px] bg-[#FF4D2D] text-white font-normal px-1.5 py-0.5 rounded ml-1">自营</span>
                </span>
                <span className="text-[10px] md:text-xs text-neutral-400 font-medium tracking-widest leading-none">
                  好东西 · 省更多
                </span>
              </div>
            </div>

            {/* Large Search Bar */}
            <div id="header-search-container" className="flex-1 max-w-2xl relative hidden md:block">
              <div className="relative flex items-center bg-white rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-[#F5222D] transition-all">
                <div className="pl-4 text-neutral-400 shrink-0">
                  <Search className="w-5 h-5" />
                </div>
                <input
                  type="text"
                  id="search-input"
                  className="w-full px-3 py-2.5 text-sm text-[#111417] bg-transparent outline-none placeholder:text-neutral-400"
                  placeholder="搜索你想要的商品（例如：手机、空气炸锅）..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                />
                
                {/* Voice Search Button */}
                <button
                  type="button"
                  id="mic-search-btn"
                  onClick={handleTriggerVoice}
                  className={`p-2.5 mr-1 hover:bg-neutral-100 rounded-lg text-neutral-500 transition-colors shrink-0 relative ${
                    isListening ? "text-red-500 bg-red-50" : ""
                  }`}
                  title="语音搜索"
                >
                  <Mic className={`w-5 h-5 ${isListening ? "animate-bounce" : ""}`} />
                  {isListening && (
                    <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-red-500"></span>
                    </span>
                  )}
                </button>
                
                {/* Red CTA Search Button */}
                <button 
                  id="search-submit-btn"
                  className="bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] text-white font-semibold text-sm px-6 h-[42px] hover:brightness-110 active:scale-95 transition-all shrink-0"
                >
                  搜索
                </button>
              </div>

              {/* Suggestions Dropdown */}
              {isSearchFocused && searchSuggestions.length > 0 && (
                <div id="search-suggestions" className="absolute top-full left-0 right-0 mt-1 bg-white rounded-xl shadow-xl border border-neutral-100 py-2 text-[#111417] z-50 overflow-hidden">
                  <div className="px-3 py-1 text-[11px] font-bold text-neutral-400 tracking-wider">热门推荐</div>
                  {searchSuggestions.map((suggestion) => (
                    <button
                      key={suggestion}
                      onMouseDown={() => {
                        setSearchQuery(suggestion);
                        setIsSearchFocused(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs hover:bg-neutral-50 transition-colors flex items-center justify-between"
                    >
                      <span>{suggestion}</span>
                      <span className="text-[10px] text-neutral-400">热度 9.9万+</span>
                    </button>
                  ))}
                </div>
              )}

              {/* Hot Searches */}
              <div id="hot-keywords" className="flex items-center gap-x-3 gap-y-1 mt-1.5 text-[11px] text-neutral-400 font-medium overflow-x-auto whitespace-nowrap scrollbar-none">
                <span className="font-semibold text-neutral-500">热门搜索：</span>
                {["手机", "空气炸锅", "运动鞋", "洗衣机", "护肤", "零食"].map((k) => (
                  <button 
                    key={k} 
                    onClick={() => setSearchQuery(k)}
                    className="hover:text-[#FF4D2D] transition-colors"
                  >
                    {k}
                  </button>
                ))}
              </div>
            </div>

            {/* Right Header Navigation Icons */}
            <div id="header-user-nav" className="flex items-center gap-1.5 md:gap-5 shrink-0">
              
              {/* User login */}
              <div className="flex items-center gap-1 cursor-pointer hover:text-[#FF4D2D] transition-colors py-1.5 px-2 rounded-lg hover:bg-white/5">
                <User className="w-4 h-4 md:w-5 h-5 text-neutral-300" />
                <span className="text-xs md:text-sm font-medium hidden lg:inline">登录 / 注册</span>
              </div>

              {/* My Orders */}
              <div 
                className="flex items-center gap-1 cursor-pointer hover:text-[#FF4D2D] transition-colors py-1.5 px-2 rounded-lg hover:bg-white/5"
                onClick={() => triggerToast("📅 正在载入您的自营订单列表...", "info")}
              >
                <ClipboardCheck className="w-4 h-4 md:w-5 h-5 text-neutral-300" />
                <span className="text-xs md:text-sm font-medium hidden lg:inline">我的订单</span>
              </div>

              {/* Customer Service */}
              <a 
                href="tel:400-888-8888" 
                className="flex items-center gap-1 cursor-pointer hover:text-[#FF4D2D] transition-colors py-1.5 px-2 rounded-lg hover:bg-white/5"
                onClick={(e) => {
                  e.preventDefault();
                  triggerToast("☎️ 已呼叫好省购 24小时智能在线客服", "success");
                }}
              >
                <PhoneCall className="w-4 h-4 md:w-5 h-5 text-neutral-300" />
                <span className="text-xs md:text-sm font-medium hidden lg:inline">客服</span>
              </a>

              {/* Cart Icon with numerical badge */}
              <button
                id="cart-trigger-btn"
                onClick={() => setIsCartOpen(true)}
                className="relative flex items-center gap-1 bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] text-white hover:brightness-110 active:scale-95 transition-all py-2 px-3 md:px-4 rounded-xl shadow-lg shadow-red-950/20 font-medium"
              >
                <ShoppingCart className="w-4 h-4 md:w-4.5 md:h-4.5" />
                <span className="text-xs md:text-sm hidden sm:inline">购物车</span>
                
                {/* Shake animate badge when item added */}
                <AnimatePresence>
                  {cartItemCount > 0 && (
                    <motion.span
                      key={cartItemCount}
                      initial={{ scale: 0.5 }}
                      animate={{ 
                        scale: [1, 1.3, 1],
                        rotate: cartBadgeAnimate ? [-10, 10, -10, 10, 0] : 0
                      }}
                      className="absolute -top-1.5 -right-1.5 bg-yellow-400 text-[#111417] text-[10px] md:text-xs font-black rounded-full h-5 w-5 flex items-center justify-center border border-[#111417] shadow"
                    >
                      {cartItemCount}
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* --- SECONDARY NAVIGATION BAR --- */}
      <nav id="secondary-nav" className="bg-white border-b border-neutral-200 sticky top-16 md:top-20 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="flex items-center justify-between h-11 text-xs md:text-sm font-bold">
            
            {/* Left Nav items */}
            <div className="flex items-center gap-1 md:gap-6 overflow-x-auto whitespace-nowrap scrollbar-none h-full py-1">
              {/* Category sidebar marker */}
              <div className="hidden lg:flex items-center gap-2 bg-[#FF4D2D] text-white px-5 h-11 -ml-6 mr-4 cursor-pointer select-none">
                <Menu className="w-4 h-4" />
                <span className="text-xs">全部商品分类</span>
              </div>

              {[
                { label: "首页", id: null },
                { label: "限时秒杀", id: "flash" },
                { label: "品牌特卖", id: "brand" },
                { label: "9.9包邮", id: "9.9" },
                { label: "新品上架", id: "new" },
                { label: "排行榜", id: "rank" },
                { label: "工厂直供", id: "factory" },
                { label: "百亿补贴", id: "subsidy" }
              ].map((item, index) => {
                const isActive = selectedCategory === item.id;
                return (
                  <button
                    key={index}
                    onClick={() => {
                      if (item.id === "flash") {
                        const elem = document.getElementById("flash-sale-section");
                        if (elem) elem.scrollIntoView({ behavior: "smooth" });
                      } else if (item.id === "factory") {
                        const elem = document.getElementById("factory-direct-section");
                        if (elem) elem.scrollIntoView({ behavior: "smooth" });
                      } else {
                        setSelectedCategory(item.id);
                        const elem = document.getElementById("today-hot-section");
                        if (elem) elem.scrollIntoView({ behavior: "smooth" });
                      }
                    }}
                    className={`relative h-full px-2.5 transition-colors duration-200 hover:text-[#F5222D] ${
                      isActive || (item.id === null && !selectedCategory) ? "text-[#F5222D] font-extrabold" : "text-[#555]"
                    }`}
                  >
                    {item.label}
                    {(isActive || (item.id === null && !selectedCategory)) && (
                      <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#F5222D]" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Right Tag */}
            <div className="hidden sm:flex items-center gap-1.5 text-[#F5222D] text-[11px] md:text-xs font-black uppercase tracking-wider shrink-0 bg-red-50 py-1 px-3 rounded-full border border-red-100">
              <Sparkle className="w-3.5 h-3.5" />
              <span>工厂直供 · 品质好货 · 价格更低</span>
            </div>

          </div>
        </div>
      </nav>

      {/* MOBILE STICKY SEARCH BAR */}
      <div id="mobile-search-bar" className="bg-white p-3 border-b border-neutral-100 sticky top-27 z-30 block md:hidden">
        <div className="flex items-center gap-2 bg-neutral-100 rounded-xl px-3 py-2">
          <Search className="w-4 h-4 text-neutral-400" />
          <input
            type="text"
            className="w-full bg-transparent text-xs outline-none text-[#111417]"
            placeholder="搜索你想要的商品"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button onClick={handleTriggerVoice} className="p-1 text-neutral-500">
            <Mic className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* --- MAIN BODY SECTION --- */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-6 py-4 flex flex-col gap-6 md:gap-8">
        
        {/* --- SECTION 1: SIDEBAR + HERO SECTION --- */}
        <section id="hero-area" className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Main Category Sidebar */}
          <div id="category-sidebar-container" className="bg-white rounded-2xl shadow-sm border border-neutral-100 p-2.5 flex flex-col h-[420px] justify-between relative hidden lg:flex">
            <div className="flex flex-col gap-0.5">
              {CATEGORIES.map((cat) => {
                const isActive = activeHoverCategory === cat.id;
                return (
                  <div
                    key={cat.id}
                    onMouseEnter={() => setActiveHoverCategory(cat.id)}
                    onMouseLeave={() => setActiveHoverCategory(null)}
                    className={`flex items-center justify-between px-3 py-2 text-xs font-semibold rounded-lg cursor-pointer transition-all duration-150 ${
                      isActive 
                        ? "bg-red-50 text-[#F5222D] translate-x-1" 
                        : "text-[#444] hover:bg-neutral-50 hover:text-[#111417]"
                    }`}
                    onClick={() => {
                      setSelectedCategory(cat.name);
                      const elem = document.getElementById("today-hot-section");
                      if (elem) elem.scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    <div className="flex items-center gap-2.5">
                      <CategoryIcon name={cat.iconName} className="w-4 h-4 opacity-80" />
                      <span>{cat.name}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 opacity-50" />

                    {/* Mega Menu on Hover */}
                    <AnimatePresence>
                      {isActive && (
                        <motion.div
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 10 }}
                          transition={{ duration: 0.15 }}
                          className="absolute left-full top-0 ml-1.5 w-[560px] bg-white rounded-2xl shadow-xl border border-neutral-100 p-6 z-50 text-[#111417] flex gap-6 h-[420px]"
                          onMouseEnter={() => setActiveHoverCategory(cat.id)}
                        >
                          {/* Subcategories */}
                          <div className="flex-1 border-r border-neutral-100 pr-6">
                            <h4 className="text-xs font-black text-neutral-400 mb-3 uppercase tracking-wider">
                              推荐分类
                            </h4>
                            <div className="grid grid-cols-2 gap-x-4 gap-y-3">
                              {cat.subcategories.map((sub) => (
                                <button
                                  key={sub}
                                  onClick={() => {
                                    setSearchQuery(sub);
                                    const elem = document.getElementById("today-hot-section");
                                    if (elem) elem.scrollIntoView({ behavior: "smooth" });
                                    setActiveHoverCategory(null);
                                  }}
                                  className="text-left text-xs font-medium hover:text-[#F5222D] transition-colors py-1 px-1.5 rounded hover:bg-neutral-50"
                                >
                                  {sub}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Popular Sourcing Products */}
                          <div className="w-[200px] flex flex-col">
                            <h4 className="text-xs font-black text-neutral-400 mb-3 uppercase tracking-wider">
                              源头热卖好货
                            </h4>
                            <div className="flex flex-col gap-2.5">
                              {cat.popularProducts.map((p, pIdx) => (
                                <div 
                                  key={p} 
                                  onClick={() => {
                                    setSearchQuery(p);
                                    const elem = document.getElementById("today-hot-section");
                                    if (elem) elem.scrollIntoView({ behavior: "smooth" });
                                    setActiveHoverCategory(null);
                                  }}
                                  className="flex items-center gap-2 cursor-pointer hover:bg-neutral-50 p-1.5 rounded-lg transition-colors"
                                >
                                  <div className="w-5 h-5 rounded bg-red-100 flex items-center justify-center text-[10px] text-[#F5222D] font-bold">
                                    {pIdx + 1}
                                  </div>
                                  <span className="text-[11px] font-semibold text-neutral-700 hover:text-[#F5222D] truncate">
                                    {p}
                                  </span>
                                </div>
                              ))}
                            </div>
                            {/* Visual tag banner in megamenu */}
                            <div className="mt-auto bg-gradient-to-tr from-[#F5222D]/5 to-[#FF7A45]/10 border border-red-100 p-2.5 rounded-xl text-center">
                              <span className="text-[10px] text-[#F5222D] font-bold block">
                                全仓工厂源头发货
                              </span>
                              <span className="text-[9px] text-neutral-500 block mt-0.5">
                                省去中间商，极速必达
                              </span>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
              {/* Extra classification to complete the exact list */}
              <div 
                className="flex items-center justify-between px-3 py-2 text-xs font-semibold text-neutral-500 rounded-lg cursor-pointer hover:bg-neutral-50 hover:text-[#111417]"
                onClick={() => triggerToast("更多分类正在接入工厂产线...", "info")}
              >
                <div className="flex items-center gap-2.5">
                  <Grid className="w-4 h-4 opacity-80" />
                  <span>更多分类</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 opacity-50" />
              </div>
            </div>

            {/* Industrial info panel */}
            <div className="border-t border-neutral-100 pt-3 mt-2 px-3 text-[10px] text-neutral-400 flex flex-col gap-1">
              <span className="text-[#F5222D] font-black flex items-center gap-1">
                🛡️ 消费者保障计划
              </span>
              <span>100%源头品质，假一赔十</span>
            </div>
          </div>

          {/* Hero Carousel Section */}
          <div id="hero-banner-main" className="lg:col-span-3 relative rounded-2xl overflow-hidden h-[300px] md:h-[420px] bg-neutral-900 group shadow-md border border-neutral-200">
            {/* Elegant Atmospheric Overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/45 to-transparent z-10" />
            
            {/* Sunset Cinematic Futuristic Chinese Industrial City with HSR High-speed Train Overlay */}
            <div className="absolute inset-0 scale-100 group-hover:scale-102 transition-transform duration-[6000ms] ease-out">
              <img 
                src="https://images.unsplash.com/photo-1540959733332-eab4deceeaf7?auto=format&fit=crop&w=1200&q=80" 
                alt="Chinese industrial city logistics"
                className="w-full h-full object-cover opacity-80 brightness-75"
              />
              {/* Sunset ambient colored lighting layer */}
              <div className="absolute inset-0 bg-gradient-to-tr from-[#FF4D2D]/20 via-transparent to-[#FF7A45]/15 mix-blend-color-burn" />
            </div>

            {/* Content info block */}
            <div className="absolute inset-0 z-20 flex flex-col justify-center px-6 md:px-12 text-white pointer-events-none">
              
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="flex flex-col gap-2 md:gap-3 max-w-lg pointer-events-auto"
              >
                <span className="inline-flex items-center gap-1.5 bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] text-white text-[10px] md:text-xs font-black uppercase px-2.5 py-1 rounded-full w-fit tracking-wider shadow">
                  <Sparkle className="w-3 h-3 fill-white animate-spin" />
                  今日精选
                </span>
                
                <h1 className="text-3xl md:text-5xl font-black tracking-tight leading-tight drop-shadow-sm">
                  好省购
                </h1>
                
                <p className="text-lg md:text-2xl font-bold text-yellow-400 drop-shadow-sm">
                  好东西 · 省更多
                </p>
                
                <p className="text-xs md:text-sm text-neutral-300 font-medium tracking-wide">
                  精选源头好货 ｜ 价格更低 ｜ 让生活更简单
                </p>
                
                <div className="flex items-center gap-3 mt-2 md:mt-4">
                  <button
                    onClick={() => {
                      const elem = document.getElementById("today-hot-section");
                      if (elem) elem.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] text-white font-bold text-xs md:text-sm px-6 py-2.5 md:py-3 rounded-xl hover:brightness-110 active:scale-95 transition-all flex items-center gap-1.5 shadow-lg shadow-red-500/20"
                  >
                    立即抢购
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  
                  {/* Subtle Logistic assurance */}
                  <span className="text-[10px] md:text-xs text-neutral-400 font-semibold flex items-center gap-1">
                    ⚡ 下单当日工厂直发
                  </span>
                </div>
              </motion.div>

            </div>

            {/* Absolute positioning indicator showing real industrial feel */}
            <div className="absolute bottom-4 right-4 z-20 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 hidden md:flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-ping" />
              <span className="text-[10px] text-neutral-300 font-bold">
                智能供应链：连接 48,000+ 家直供工厂
              </span>
            </div>
          </div>

        </section>

        {/* --- CATEGORY ICON STRIP --- */}
        <section id="category-strip" className="bg-white rounded-2xl p-4 md:p-6 shadow-sm border border-neutral-100">
          <div className="grid grid-cols-5 sm:grid-cols-9 gap-4 text-center">
            {[
              { label: "手机数码", icon: <Smartphone className="w-5 h-5 md:w-6 md:h-6" />, category: "手机数码" },
              { label: "家用电器", icon: <Tv className="w-5 h-5 md:w-6 md:h-6" />, category: "家用电器" },
              { label: "服饰鞋包", icon: <Shirt className="w-5 h-5 md:w-6 md:h-6" />, category: "服饰鞋包" },
              { label: "美妆个护", icon: <Sparkles className="w-5 h-5 md:w-6 md:h-6" />, category: "美妆个护" },
              { label: "母婴玩具", icon: <Baby className="w-5 h-5 md:w-6 md:h-6" />, category: "母婴玩具" },
              { label: "家居生活", icon: <Home className="w-5 h-5 md:w-6 md:h-6" />, category: "家居生活" },
              { label: "运动户外", icon: <Activity className="w-5 h-5 md:w-6 md:h-6" />, category: "运动户外" },
              { label: "食品饮料", icon: <Utensils className="w-5 h-5 md:w-6 md:h-6" />, category: "食品饮料" },
              { label: "全部分类", icon: <Grid className="w-5 h-5 md:w-6 md:h-6" />, category: null }
            ].map((item, index) => {
              const isSelected = selectedCategory === item.category;
              return (
                <div
                  key={index}
                  onClick={() => {
                    setSelectedCategory(item.category);
                    const elem = document.getElementById("today-hot-section");
                    if (elem) elem.scrollIntoView({ behavior: "smooth" });
                    triggerToast(`已定位到: ${item.label}`, "success");
                  }}
                  className="flex flex-col items-center gap-1.5 cursor-pointer group"
                >
                  <div className={`w-11 h-11 md:w-14 md:h-14 rounded-full flex items-center justify-center transition-all duration-300 ${
                    isSelected 
                      ? "bg-[#F5222D] text-white scale-110 shadow-md shadow-red-200" 
                      : "bg-neutral-50 text-[#555] hover:bg-[#FF4D2D]/10 hover:text-[#FF4D2D] hover:-translate-y-1"
                  }`}>
                    {item.icon}
                  </div>
                  <span className={`text-[11px] md:text-xs font-bold leading-tight ${
                    isSelected ? "text-[#F5222D]" : "text-neutral-600 group-hover:text-[#FF4D2D]"
                  }`}>
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        {/* --- PROMOTIONAL GRID SECTION --- */}
        <section id="promotional-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Card 1: Red/Orange Gradient */}
          <div className="bg-gradient-to-br from-[#F5222D] to-[#FF7A45] rounded-2xl p-5 text-white flex flex-col justify-between shadow-md h-[210px] relative overflow-hidden group">
            {/* Watermark Logo Background */}
            <div className="absolute right-[-10px] bottom-[-10px] text-white/5 font-black text-7xl select-none uppercase">
              HSG
            </div>
            <div>
              <span className="bg-white/20 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider">
                限时特惠
              </span>
              <h3 className="text-xl font-black mt-2 drop-shadow-sm">小米 14</h3>
              <p className="text-xs text-white/80 mt-1 font-semibold">旗舰性能 亲民体验</p>
            </div>
            <div className="flex items-end justify-between z-10">
              <span className="text-2xl font-black">¥1999 <span className="text-xs font-normal">起</span></span>
              <button 
                onClick={() => {
                  const p = MOCK_PRODUCTS.find(x => x.id === "xiaomi-14");
                  if (p) setSelectedProduct(p);
                }}
                className="bg-white text-[#F5222D] text-xs font-black px-3.5 py-1.5 rounded-xl hover:bg-neutral-100 active:scale-95 transition-all"
              >
                立即抢购 →
              </button>
            </div>
            {/* Absolute product mock image overlay */}
            <div className="absolute right-3 top-4 w-28 h-28 pointer-events-none group-hover:scale-105 transition-transform duration-300">
              <img 
                src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=300&q=80"
                alt="Xiaomi 14"
                className="w-full h-full object-contain drop-shadow-md"
              />
            </div>
          </div>

          {/* Card 2: Light Neutral Background */}
          <div className="bg-white rounded-2xl p-5 border border-neutral-200/60 text-[#111417] flex flex-col justify-between shadow-sm h-[210px] relative overflow-hidden group">
            <div>
              <span className="bg-[#FF7A45]/15 text-[#FF7A45] px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider">
                品牌特卖
              </span>
              <h3 className="text-xl font-black mt-2">海尔洗衣机</h3>
              <p className="text-xs text-neutral-500 mt-1 font-semibold">大容量直驱省电</p>
            </div>
            <div className="flex items-end justify-between z-10">
              <span className="text-2xl font-black text-[#F5222D]">¥899 <span className="text-xs font-normal text-neutral-400">起</span></span>
              <button 
                onClick={() => {
                  const p = MOCK_PRODUCTS.find(x => x.id === "haier-washing-machine");
                  if (p) setSelectedProduct(p);
                }}
                className="bg-[#F5222D] text-white text-xs font-black px-3.5 py-1.5 rounded-xl hover:brightness-110 active:scale-95 transition-all"
              >
                立即抢购 →
              </button>
            </div>
            {/* Product image */}
            <div className="absolute right-3 top-4 w-28 h-28 pointer-events-none group-hover:scale-105 transition-transform duration-300">
              <img 
                src="https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=300&q=80"
                alt="Haier Washing Machine"
                className="w-full h-full object-contain drop-shadow-sm"
              />
            </div>
          </div>

          {/* Card 3: Blue/White Ecommerce Promotion */}
          <div className="bg-gradient-to-br from-[#1E3A8A] to-[#3B82F6] rounded-2xl p-5 text-white flex flex-col justify-between shadow-md h-[210px] relative overflow-hidden group">
            <div>
              <span className="bg-white/20 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider">
                9.9包邮
              </span>
              <h3 className="text-xl font-black mt-2 drop-shadow-sm">蓝牙耳机</h3>
              <p className="text-xs text-white/80 mt-1 font-semibold">真无线 低延迟</p>
            </div>
            <div className="flex items-end justify-between z-10">
              <span className="text-2xl font-black text-yellow-300">¥9.9 <span className="text-xs font-normal text-white/70">起</span></span>
              <button 
                onClick={() => {
                  const p = MOCK_PRODUCTS.find(x => x.id === "wireless-earphones");
                  if (p) setSelectedProduct(p);
                }}
                className="bg-white text-[#1E3A8A] text-xs font-black px-3.5 py-1.5 rounded-xl hover:bg-neutral-100 active:scale-95 transition-all"
              >
                立即抢购 →
              </button>
            </div>
            {/* Product image */}
            <div className="absolute right-3 top-4 w-28 h-28 pointer-events-none group-hover:scale-105 transition-transform duration-300">
              <img 
                src="https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=300&q=80"
                alt="Wireless Earphones"
                className="w-full h-full object-contain drop-shadow-md"
              />
            </div>
          </div>

          {/* Tall Sourcing Logistics Panel (Factory direct background) */}
          <div className="bg-neutral-900 text-white rounded-2xl overflow-hidden shadow-md h-[210px] relative group border border-neutral-800">
            {/* Sourcing image */}
            <div className="absolute inset-0 z-0">
              <img 
                src="https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=500&q=80" 
                alt="Automated logistics container port"
                className="w-full h-full object-cover opacity-35 brightness-75 group-hover:scale-102 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
            </div>
            <div className="absolute inset-0 z-10 p-5 flex flex-col justify-between">
              <div>
                <span className="bg-[#FF4D2D] text-white px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider block w-fit">
                  源头直供
                </span>
                <h3 className="text-lg font-black mt-2 flex items-center gap-1 text-yellow-400">
                  工厂直发 价格更低
                </h3>
                <ul className="text-[10px] text-neutral-300 font-semibold mt-1.5 space-y-0.5">
                  <li>• 减少所有中间商环节</li>
                  <li>• 直接对接大型出厂制造产线</li>
                  <li>• 100%真正让利大众消费者</li>
                </ul>
              </div>
              <button
                onClick={() => {
                  const elem = document.getElementById("factory-direct-section");
                  if (elem) elem.scrollIntoView({ behavior: "smooth" });
                  triggerToast("🚚 正在加载智慧物流专区详情...", "success");
                }}
                className="bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] text-white text-xs font-black px-4 py-2 rounded-xl hover:brightness-110 transition-all w-full text-center block shadow"
              >
                了解更多 →
              </button>
            </div>
          </div>

        </section>

        {/* --- SECTION 2: FLASH SALE (限时秒杀) WITH TIMER --- */}
        <section id="flash-sale-section" className="bg-white rounded-2xl shadow-sm border border-neutral-100 overflow-hidden">
          
          {/* Flash Sale Header */}
          <div className="bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] px-6 py-4 text-white flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-6 bg-white rounded" />
                <span className="text-lg md:text-xl font-black tracking-wider flex items-center gap-1.5">
                  限时秒杀 <span className="text-xs bg-black/25 text-yellow-300 py-0.5 px-2 rounded-full font-bold">爆款立减</span>
                </span>
              </div>
              
              {/* Countdown Ticking */}
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-red-100 font-bold">距结束还剩:</span>
                <div className="flex items-center gap-1">
                  <span className="bg-[#111417] text-white font-extrabold text-xs px-2 py-1 rounded min-w-[24px] text-center shadow">
                    {String(countdown.hours).padStart(2, "0")}
                  </span>
                  <span className="text-white font-bold text-xs">:</span>
                  <span className="bg-[#111417] text-white font-extrabold text-xs px-2 py-1 rounded min-w-[24px] text-center shadow">
                    {String(countdown.minutes).padStart(2, "0")}
                  </span>
                  <span className="text-white font-bold text-xs">:</span>
                  <span className="bg-[#111417] text-white font-extrabold text-xs px-2 py-1 rounded min-w-[24px] text-center shadow">
                    {String(countdown.seconds).padStart(2, "0")}
                  </span>
                </div>
              </div>
            </div>
            
            <span className="text-xs text-red-100 font-medium">每逢整点更新秒杀货品 · 数量有限抢完为止</span>
          </div>

          {/* Flash Sale Grid */}
          <div className="p-6 grid grid-cols-2 md:grid-cols-4 gap-6">
            {products.filter(p => p.isFlashSale).map((product) => {
              const discount = Math.round((1 - product.price / product.originalPrice) * 100);
              return (
                <div 
                  key={product.id}
                  onClick={() => setSelectedProduct(product)}
                  className="bg-neutral-50 rounded-xl p-4 border border-neutral-100/80 cursor-pointer hover:shadow-md transition-shadow group relative overflow-hidden"
                >
                  <div className="absolute top-2 left-2 z-10 bg-[#F5222D] text-white text-[10px] font-black py-0.5 px-1.5 rounded-md">
                    {discount}% OFF
                  </div>

                  <div className="aspect-square bg-white rounded-lg overflow-hidden relative mb-3 border border-neutral-100 flex items-center justify-center">
                    <img
                      src={product.imageUrl}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-200"
                    />
                  </div>

                  <h4 className="text-xs font-black text-neutral-800 line-clamp-1 mb-1 group-hover:text-[#F5222D]">
                    {product.name}
                  </h4>
                  <p className="text-[10px] text-neutral-400 line-clamp-1 mb-2">
                    {product.description}
                  </p>

                  <div className="flex items-baseline gap-1.5 mb-2">
                    <span className="text-lg font-black text-[#F5222D]">¥{product.price}</span>
                    <span className="text-xs text-neutral-400 line-through">¥{product.originalPrice}</span>
                  </div>

                  {/* Progress bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px] text-neutral-500 font-bold">
                      <span>已抢 {product.flashSaleProgress}%</span>
                      <span>剩{100 - (product.flashSaleProgress || 0)}%</span>
                    </div>
                    <div className="w-full bg-neutral-200 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className="bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] h-full rounded-full"
                        style={{ width: `${product.flashSaleProgress}%` }}
                      />
                    </div>
                  </div>

                  {/* Add to Cart CTA */}
                  <button
                    onClick={(e) => handleAddToCart(product, e)}
                    className="w-full mt-3 bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] text-white text-xs font-bold py-2 rounded-lg hover:brightness-110 active:scale-95 transition-all text-center block shadow-sm"
                  >
                    立即开抢
                  </button>
                </div>
              );
            })}
          </div>

        </section>

        {/* --- SECTION 3: TODAY'S HOT PRODUCTS (今日热卖) --- */}
        <section id="today-hot-section" className="flex flex-col gap-4">
          
          <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
            <div className="flex items-center gap-2">
              <span className="text-xl font-black flex items-center gap-1 tracking-tight text-[#111417]">
                🔥 今日热卖
              </span>
              <span className="text-[11px] bg-[#FF4D2D]/10 text-[#FF4D2D] px-2 py-0.5 rounded-full font-black">
                高销好物榜
              </span>
            </div>

            {selectedCategory && (
              <button 
                onClick={() => setSelectedCategory(null)}
                className="text-xs text-[#F5222D] font-bold hover:underline"
              >
                重置分类过滤器 (当前: {selectedCategory})
              </button>
            )}
            
            <button 
              onClick={() => triggerToast("✨ 排行榜每5分钟实时重排计算", "success")}
              className="text-xs text-neutral-500 font-bold hover:text-[#F5222D] transition-colors flex items-center gap-1"
            >
              查看更多 →
            </button>
          </div>

          {/* Product Grid - highly optimized, dense but luxurious light schema */}
          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-2xl border border-neutral-200 p-12 text-center text-neutral-500">
              <p className="text-sm font-bold">没有找到匹配此分类或搜索条件的源头商品</p>
              <button 
                onClick={() => {
                  setSelectedCategory(null);
                  setSearchQuery("");
                }}
                className="mt-4 bg-[#F5222D] text-white font-bold text-xs px-5 py-2 rounded-xl hover:bg-red-600 transition-colors"
              >
                清空过滤条件
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
              {filteredProducts.map((product) => {
                const isFavorite = favorites.includes(product.id);
                return (
                  <div
                    key={product.id}
                    onClick={() => setSelectedProduct(product)}
                    className="bg-white rounded-2xl border border-neutral-200/70 overflow-hidden cursor-pointer shadow-sm hover:shadow-lg hover:-translate-y-1.5 transition-all duration-300 relative flex flex-col justify-between group h-full"
                  >
                    
                    {/* Badge */}
                    <div className="absolute top-2 left-2 z-10 flex flex-col gap-1">
                      <span className="bg-[#FF4D2D] text-white text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm">
                        {product.badge}
                      </span>
                    </div>

                    {/* Favorite heart button */}
                    <button
                      onClick={(e) => handleToggleFavorite(product.id, e)}
                      className="absolute top-2 right-2 z-10 p-1.5 bg-white/70 backdrop-blur-md rounded-full text-neutral-400 hover:text-red-500 hover:scale-110 active:scale-95 transition-all shadow-sm"
                      title={isFavorite ? "取消收藏" : "加入收藏"}
                    >
                      <Heart className={`w-4 h-4 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
                    </button>

                    {/* Image Area with Zoom Treatment */}
                    <div>
                      <div className="aspect-square bg-neutral-50 overflow-hidden relative border-b border-neutral-100 flex items-center justify-center">
                        <img
                          src={product.imageUrl}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>

                      {/* Info Area */}
                      <div className="p-4 flex flex-col gap-1">
                        <span className="text-[10px] text-neutral-400 font-black uppercase tracking-wider block">
                          {product.category}
                        </span>
                        
                        <h3 className="text-xs md:text-sm font-black text-neutral-800 line-clamp-1 group-hover:text-[#F5222D] transition-colors leading-snug">
                          {product.name}
                        </h3>
                        
                        <p className="text-[10px] text-neutral-500 line-clamp-1 leading-normal font-medium">
                          {product.description}
                        </p>

                        <div className="flex items-center gap-1.5 mt-1">
                          {/* Stars */}
                          <div className="flex text-yellow-400 text-[10px]">
                            {"★".repeat(Math.floor(product.rating))}
                            {product.rating % 1 !== 0 && "☆"}
                          </div>
                          <span className="text-[10px] text-neutral-400 font-bold">
                            ({product.reviewsCount})
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Price and Cart Row */}
                    <div className="px-4 pb-4 pt-1 flex items-center justify-between border-t border-neutral-50 mt-auto bg-neutral-50/50">
                      <div className="flex flex-col">
                        <span className="text-[10px] text-neutral-400 font-semibold line-through">
                          ¥{product.originalPrice}
                        </span>
                        <span className="text-base md:text-lg font-black text-[#F5222D]">
                          ¥{product.price}
                        </span>
                      </div>

                      <div className="flex flex-col items-end gap-1">
                        <span className="text-[9px] text-neutral-400 font-bold">
                          {product.salesVolume}
                        </span>
                        
                        <button
                          onClick={(e) => handleAddToCart(product, e)}
                          className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#F5222D] to-[#FF4D2D] hover:scale-105 active:scale-95 text-white flex items-center justify-center transition-all shadow shadow-red-200"
                          title="加入购物车"
                        >
                          <ShoppingCart className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </section>

        {/* --- SECTION 4: FACTORY DIRECT LOGISTIC EXPLAINER (工厂直供) --- */}
        <section id="factory-direct-section" className="bg-gradient-to-b from-neutral-900 to-[#111417] text-white rounded-3xl overflow-hidden shadow-xl border border-neutral-800">
          <div className="p-8 md:p-12">
            
            <div className="max-w-2xl text-center md:text-left">
              <span className="bg-[#FF4D2D] text-white text-[10px] font-black uppercase px-3 py-1 rounded-full tracking-wider shadow inline-block mb-3">
                供应链革新
              </span>
              <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight leading-snug">
                工厂直供 · 真正让利大众
              </h2>
              <p className="text-xs md:text-sm text-neutral-400 mt-2 font-medium">
                「好省购」深度连接全国主力工业制造大省，从出厂产线直接集装箱发往区域智慧分拣仓，精减一切中间溢价步骤。
              </p>
            </div>

            {/* Industrial Logistics Graphics Map */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-10 relative">
              {/* Process line for large screens */}
              <div className="hidden md:block absolute top-[44px] left-[15%] right-[15%] h-0.5 bg-neutral-800 z-0" />
              
              {[
                { 
                  title: "源头直发", 
                  desc: "直接对接全国核心制造厂", 
                  badge: "加价 0%",
                  icon: <Grid className="w-5 h-5 text-[#FF7A45]" />
                },
                { 
                  title: "智能仓储", 
                  desc: "自动化机器人与高速品控分拣", 
                  badge: "12分钟出单",
                  icon: <Package className="w-5 h-5 text-[#FF7A45]" />
                },
                { 
                  title: "顺丰直达", 
                  desc: "跨省专列全网极速送货上门", 
                  badge: "100%保邮",
                  icon: <Truck className="w-5 h-5 text-[#FF7A45]" />
                },
                { 
                  title: "平价惠民", 
                  desc: "剔除溢价，仅赚取薄底流水利润", 
                  badge: "均省 45%",
                  icon: <ShieldCheck className="w-5 h-5 text-[#FF7A45]" />
                }
              ].map((step, idx) => (
                <div 
                  key={idx} 
                  className="bg-white/5 border border-white/10 p-5 rounded-2xl flex flex-col items-center text-center relative z-10 hover:bg-white/10 transition-colors"
                >
                  <div className="w-12 h-12 rounded-xl bg-[#FF4D2D]/10 text-[#FF4D2D] flex items-center justify-center mb-3">
                    {step.icon}
                  </div>
                  <h4 className="text-sm font-black text-white">{step.title}</h4>
                  <p className="text-[11px] text-neutral-400 mt-1.5 leading-relaxed font-semibold">{step.desc}</p>
                  <span className="mt-3 bg-white/10 text-yellow-300 text-[10px] px-2 py-0.5 rounded font-black uppercase">
                    {step.badge}
                  </span>
                </div>
              ))}
            </div>

            {/* Logistic facts carousel summary */}
            <div className="mt-10 border-t border-neutral-800 pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-neutral-400">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#FF4D2D]" />
                <span>实时状态：长三角、珠三角、成渝大仓等智慧物流枢纽全线畅通</span>
              </div>
              <span className="font-semibold text-neutral-500">好省购 · 打造中国老百姓日常消费首选</span>
            </div>

          </div>
        </section>

      </main>

      {/* --- FOOTER --- */}
      <footer id="main-footer" className="bg-[#111417] text-[#999] border-t border-neutral-800 text-xs mt-12">
        
        {/* Core assurances row */}
        <div className="border-b border-neutral-800 py-6 bg-black/30">
          <div className="max-w-7xl mx-auto px-4 md:px-6 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { icon: <ShieldCheck className="w-5 h-5 text-[#FF4D2D] mx-auto" />, title: "正品保障", desc: "自营直供·假一赔十" },
              { icon: <RotateCcw className="w-5 h-5 text-[#FF4D2D] mx-auto" />, title: "7天无理由退换", desc: "售后无忧·放心购" },
              { icon: <Truck className="w-5 h-5 text-[#FF4D2D] mx-auto" />, title: "全国包邮", desc: "顺丰速运·部分除外" },
              { icon: <PhoneCall className="w-5 h-5 text-[#FF4D2D] mx-auto" />, title: "24h在线客服", desc: "暖心陪伴·贴心响应" }
            ].map((item, index) => (
              <div key={index} className="space-y-1">
                {item.icon}
                <h4 className="font-bold text-white text-xs">{item.title}</h4>
                <p className="text-[10px] text-neutral-500 font-medium">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Links matrix */}
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-10 grid grid-cols-2 md:grid-cols-5 gap-8">
          
          <div className="flex flex-col gap-3 col-span-2 md:col-span-2 pr-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#F5222D] to-[#FF7A45] flex items-center justify-center text-white text-xs font-black">
                省
              </div>
              <span className="text-base font-black text-white">好省购</span>
            </div>
            <p className="text-[11px] leading-relaxed text-neutral-500 font-semibold">
              好省购电商平台专注于通过数字化产业带直连模式，去除中间商加价壁垒，直接连接中国主力制造工厂与千万普通大众消费者，实现“高品质，省更多”的理想日常生活。
            </p>
            <div className="text-[10px] text-neutral-500 mt-2">
              公司地址：中国智能物流示范区（常州） 10号楼 
            </div>
          </div>

          {[
            {
              title: "购物指南",
              links: ["购物流程", "会员等级", "常见问题", "发票说明", "帮助中心"]
            },
            {
              title: "企业服务",
              links: ["工厂入驻", "品牌招商", "供应商合作", "广告服务", "廉洁监督"]
            },
            {
              title: "售后与支持",
              links: ["退换货政策", "退款流程", "客服电话", "投诉建议", "纠纷处理"]
            }
          ].map((col, index) => (
            <div key={index} className="flex flex-col gap-2.5">
              <h4 className="font-black text-white text-xs uppercase tracking-wider mb-1">
                {col.title}
              </h4>
              <ul className="space-y-1.5 font-medium text-[11px] text-neutral-500">
                {col.links.map((link) => (
                  <li key={link}>
                    <a 
                      href="#" 
                      onClick={(e) => {
                        e.preventDefault();
                        triggerToast(`已收到您的「${link}」查询请求`, "success");
                      }}
                      className="hover:text-white transition-colors"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

        </div>

        {/* Bottom credits */}
        <div className="bg-black/40 py-5 text-center text-neutral-600 text-[10px] border-t border-neutral-800">
          <div className="max-w-7xl mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center justify-between gap-3">
            <span>© 2026 好省购有限公司. 版权所有 ICP证: 苏B2-20260921</span>
            <span>好东西 · 省更多 | 技术核心依托于全自动数智供应链分拣系统</span>
          </div>
        </div>

      </footer>

      {/* --- MOBILE BOTTOM NAVIGATION BAR --- */}
      <div id="mobile-bottom-nav" className="bg-white border-t border-neutral-200 fixed bottom-0 left-0 right-0 h-14 z-40 flex items-center justify-around text-center md:hidden shadow-lg">
        {[
          { label: "首页", icon: <Home className="w-5 h-5" />, action: () => { setSelectedCategory(null); setSearchQuery(""); } },
          { label: "分类", icon: <Grid className="w-5 h-5" />, action: () => { setSelectedCategory(null); const elem = document.getElementById("category-strip"); if (elem) elem.scrollIntoView({ behavior: "smooth" }); } },
          { label: "购物车", icon: <ShoppingCart className="w-5 h-5" />, action: () => setIsCartOpen(true), badge: cartItemCount },
          { label: "我的收藏", icon: <Heart className="w-5 h-5" />, action: () => { setSelectedCategory("收藏"); triggerToast("已过滤出您的收藏夹", "success"); } }
        ].map((item, idx) => (
          <button
            key={idx}
            onClick={item.action}
            className="flex flex-col items-center gap-0.5 text-[10px] text-neutral-600 font-bold relative w-12"
          >
            <div className="text-neutral-500 hover:text-[#F5222D]">
              {item.icon}
            </div>
            <span>{item.label}</span>
            {item.badge !== undefined && item.badge > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] font-black rounded-full h-4 w-4 flex items-center justify-center">
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* --- CART DRAWER OVERLAY --- */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black z-50"
            />
            
            {/* Drawer */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.25 }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-2xl z-50 flex flex-col justify-between"
            >
              {/* Drawer Header */}
              <div className="p-4 md:p-6 border-b border-neutral-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-[#F5222D]" />
                  <h2 className="text-base md:text-lg font-black text-[#111417]">
                    我的自营购物车 ({cartItemCount})
                  </h2>
                </div>
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="p-1.5 hover:bg-neutral-100 rounded-lg text-neutral-400 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Content */}
              <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
                {cart.length === 0 ? (
                  <div className="text-center py-12 text-neutral-400 flex flex-col items-center gap-3">
                    <ShoppingBag className="w-12 h-12 stroke-[1.5] text-neutral-300" />
                    <p className="text-sm font-bold">自营购物车还是空的哦</p>
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="bg-red-50 text-[#F5222D] text-xs font-bold px-5 py-2 rounded-xl border border-red-100 hover:bg-red-100 transition-colors"
                    >
                      立即去选购
                    </button>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div 
                      key={item.product.id}
                      className="flex gap-3 bg-neutral-50 p-3 rounded-xl border border-neutral-100 relative"
                    >
                      <div className="w-16 h-16 rounded-lg bg-white overflow-hidden shrink-0 border border-neutral-100 flex items-center justify-center">
                        <img 
                          src={item.product.imageUrl} 
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <h4 className="text-xs font-black text-neutral-800 line-clamp-1">
                            {item.product.name}
                          </h4>
                          <p className="text-[10px] text-neutral-400">
                            {item.product.factoryInfo.name}
                          </p>
                        </div>
                        
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-sm font-black text-[#F5222D]">
                            ¥{item.product.price}
                          </span>
                          
                          <div className="flex items-center border border-neutral-200 rounded-lg bg-white">
                            <button
                              onClick={() => handleUpdateQuantity(item.product.id, -1)}
                              className="p-1 hover:bg-neutral-50 transition-colors"
                            >
                              <Minus className="w-3 h-3 text-neutral-500" />
                            </button>
                            <span className="px-2 text-xs font-bold text-neutral-800">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => handleUpdateQuantity(item.product.id, 1)}
                              className="p-1 hover:bg-neutral-50 transition-colors"
                            >
                              <Plus className="w-3 h-3 text-neutral-500" />
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Remove item */}
                      <button
                        onClick={() => handleRemoveFromCart(item.product.id)}
                        className="absolute top-2 right-2 p-1 text-neutral-400 hover:text-red-500 rounded-md hover:bg-neutral-100 transition-all"
                        title="移出"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>

              {/* Drawer Footer */}
              {cart.length > 0 && (
                <div className="p-4 md:p-6 border-t border-neutral-100 bg-neutral-50/50 space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-bold text-neutral-500">商品总金额</span>
                    <span className="text-xl font-black text-[#F5222D]">
                      ¥{cartTotal.toFixed(2)}
                    </span>
                  </div>

                  <div className="bg-green-50 border border-green-100 p-2.5 rounded-xl text-[10px] text-green-800 font-bold flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                    <span>恭喜！已满足全国出厂专列免邮费条件</span>
                  </div>

                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      setIsCheckoutOpen(true);
                      setCheckoutStep("form");
                    }}
                    className="w-full bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] hover:brightness-110 active:scale-95 text-white font-black text-sm py-3 rounded-xl shadow-lg shadow-red-500/10 text-center block transition-all"
                  >
                    立即前往结算
                  </button>
                </div>
              )}

            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* --- PRODUCT DETAIL MODAL --- */}
      <AnimatePresence>
        {selectedProduct && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProduct(null)}
              className="fixed inset-0 bg-black z-50"
            />

            {/* Modal */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-x-4 top-10 bottom-10 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-2xl bg-white rounded-2xl shadow-2xl z-50 overflow-hidden flex flex-col text-[#111417]"
            >
              {/* Modal Header */}
              <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
                <span className="text-xs bg-[#FF4D2D] text-white px-2 py-0.5 rounded-md font-black">
                  源头工厂自营
                </span>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="p-1 hover:bg-neutral-200 rounded-lg text-neutral-400 hover:text-[#111417] transition-all"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Scroll Container */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                
                {/* Product Layout */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Photo area */}
                  <div className="aspect-square bg-neutral-50 rounded-xl overflow-hidden relative border border-neutral-100 flex items-center justify-center">
                    <img 
                      src={selectedProduct.imageUrl} 
                      alt={selectedProduct.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 left-3 bg-red-500 text-white text-[10px] font-black px-2 py-0.5 rounded">
                      {selectedProduct.badge}
                    </div>
                  </div>

                  {/* Pricing and basics */}
                  <div className="flex flex-col justify-between gap-4">
                    <div className="space-y-1">
                      <span className="text-[10px] text-neutral-400 font-bold uppercase">
                        {selectedProduct.category} | {selectedProduct.subcategory}
                      </span>
                      <h2 className="text-lg md:text-xl font-black text-neutral-800 leading-snug">
                        {selectedProduct.name}
                      </h2>
                      <p className="text-xs text-neutral-500 font-semibold">
                        {selectedProduct.description}
                      </p>
                    </div>

                    {/* Prices */}
                    <div className="bg-red-50/50 p-4 rounded-xl border border-red-100/50 space-y-1">
                      <div className="text-[10px] text-neutral-400 font-semibold">厂供专属优惠价</div>
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-black text-[#F5222D]">
                          ¥{selectedProduct.price}
                        </span>
                        <span className="text-xs text-neutral-400 line-through">
                          出厂前原价 ¥{selectedProduct.originalPrice}
                        </span>
                        <span className="text-[10px] bg-red-500 text-white font-extrabold px-1.5 py-0.5 rounded">
                          已省 ¥{(selectedProduct.originalPrice - selectedProduct.price).toFixed(0)}
                        </span>
                      </div>
                      <div className="text-[9px] text-neutral-400 font-bold mt-1">
                        📦 本单由 {selectedProduct.factoryInfo.name} 直接发货
                      </div>
                    </div>

                    {/* Simple ratings & volume */}
                    <div className="flex items-center justify-between text-xs text-neutral-500 font-bold border-t border-neutral-100 pt-3">
                      <span>评分：★★★★★ {selectedProduct.rating}</span>
                      <span>销量：{selectedProduct.salesVolume}</span>
                    </div>

                  </div>

                </div>

                {/* Sourcing Logistics Connection Info Sheet */}
                <div className="bg-neutral-50 rounded-xl p-4 border border-neutral-100 space-y-2">
                  <h4 className="text-xs font-black text-neutral-800 flex items-center gap-1">
                    🏭 智造工厂物流追溯
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-neutral-600 font-semibold">
                    <div className="bg-white p-2.5 rounded-lg border border-neutral-100">
                      <span className="text-neutral-400 block text-[10px]">生产企业</span>
                      <span className="text-neutral-800">{selectedProduct.factoryInfo.name}</span>
                    </div>
                    <div className="bg-white p-2.5 rounded-lg border border-neutral-100">
                      <span className="text-neutral-400 block text-[10px]">始发城市</span>
                      <span className="text-neutral-800">📍 {selectedProduct.factoryInfo.location}</span>
                    </div>
                    <div className="bg-white p-2.5 rounded-lg border border-neutral-100 md:col-span-2">
                      <span className="text-neutral-400 block text-[10px]">发货及承诺</span>
                      <span className="text-[#F5222D] font-bold">{selectedProduct.factoryInfo.dispatchSpeed}</span>
                    </div>
                  </div>
                </div>

                {/* Spec details list */}
                <div className="space-y-2">
                  <h4 className="text-xs font-black text-neutral-800">
                    📋 产品规格参数
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {selectedProduct.specs.map((spec) => (
                      <div key={spec.label} className="bg-neutral-50/50 p-2.5 rounded-lg flex justify-between font-semibold">
                        <span className="text-neutral-400">{spec.label}</span>
                        <span className="text-neutral-800">{spec.value}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Modal Footer (Action row) */}
              <div className="p-4 border-t border-neutral-100 bg-neutral-50 flex items-center justify-between gap-4">
                <button
                  onClick={() => handleToggleFavorite(selectedProduct.id)}
                  className="px-4 py-2.5 rounded-xl border border-neutral-200 hover:bg-neutral-100 text-neutral-600 font-black text-xs flex items-center gap-1 bg-white"
                >
                  <Heart className={`w-4 h-4 ${favorites.includes(selectedProduct.id) ? "fill-red-500 text-red-500" : ""}`} />
                  收藏商品
                </button>

                <button
                  onClick={() => {
                    handleAddToCart(selectedProduct);
                    setSelectedProduct(null);
                  }}
                  className="flex-1 bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] text-white hover:brightness-110 active:scale-95 transition-all text-xs font-black py-3 rounded-xl text-center block shadow-md"
                >
                  加入自营购物车 (省更多)
                </button>
              </div>

            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* --- SIMULATED CHECKOUT OVERLAY DIALOG --- */}
      <AnimatePresence>
        {isCheckoutOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCheckoutOpen(false)}
              className="fixed inset-0 bg-black z-50"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed inset-x-4 top-1/2 -translate-y-1/2 md:inset-auto md:w-[480px] bg-white rounded-2xl p-6 z-50 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3 mb-4">
                <h3 className="text-sm font-black text-neutral-800 flex items-center gap-1.5">
                  📦 好省购智能绿色结算通道
                </h3>
                <button onClick={() => setIsCheckoutOpen(false)}>
                  <X className="w-5 h-5 text-neutral-400 hover:text-neutral-600" />
                </button>
              </div>

              {checkoutStep === "form" && (
                <form onSubmit={handleCheckout} className="space-y-4">
                  <div className="bg-neutral-50 p-3 rounded-xl border border-neutral-100 text-[10px] text-neutral-500 space-y-1">
                    <p className="font-bold text-[#F5222D]">出厂直邮无忧说明：</p>
                    <p>• 本订单所有商品将自动拆解为工厂原产地顺丰直邮单。</p>
                    <p>• 我们将提供全生命周期物流，假一赔十。</p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-black text-neutral-600 block">
                      请输入您的收货地址 (省/市/区/街道/门牌号)
                    </label>
                    <textarea
                      className="w-full p-3 rounded-xl border border-neutral-200 text-xs font-semibold focus:ring-2 focus:ring-[#F5222D] outline-none"
                      rows={3}
                      placeholder="例如：江苏省常州市新北区智能大道10号"
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      required
                    />
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setIsCheckoutOpen(false)}
                      className="w-1/3 py-2.5 rounded-xl border border-neutral-200 text-xs font-bold hover:bg-neutral-50"
                    >
                      返回
                    </button>
                    <button
                      type="submit"
                      className="flex-1 bg-gradient-to-r from-[#F5222D] to-[#FF4D2D] text-white py-2.5 rounded-xl text-xs font-black shadow-md hover:brightness-110 active:scale-95 transition-all"
                    >
                      提交订单并免密支付
                    </button>
                  </div>
                </form>
              )}

              {checkoutStep === "loading" && (
                <div className="text-center py-8 space-y-3">
                  <div className="w-10 h-10 border-4 border-[#F5222D] border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-xs font-black text-neutral-700 animate-pulse">
                    正在连线全国智能云仓，生成极速发货指令...
                  </p>
                </div>
              )}

              {checkoutStep === "success" && (
                <div className="space-y-4">
                  <div className="text-center py-4 text-green-600 space-y-1">
                    <div className="w-10 h-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto mb-2">
                      <Check className="w-6 h-6" />
                    </div>
                    <h4 className="text-sm font-black">🎉 支付与发货指令已下达成功</h4>
                    <p className="text-[10px] text-neutral-400">已省去中间一切环节，智慧物流仓极速备货中</p>
                  </div>

                  <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-100 space-y-2">
                    <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider block">
                      🚚 供应链实时动态
                    </span>
                    <ul className="space-y-2 text-[10px] font-semibold text-neutral-600">
                      {simulatedTracking.map((track, i) => (
                        <li key={i} className="flex gap-2">
                          <span className="text-[#F5222D]">✦</span>
                          <span>{track}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    onClick={() => setIsCheckoutOpen(false)}
                    className="w-full bg-[#111417] text-white py-2.5 rounded-xl text-xs font-black hover:bg-neutral-800 transition-colors"
                  >
                    完成，返回首页
                  </button>
                </div>
              )}

            </motion.div>
          </>
        )}
      </AnimatePresence>

    </div>
  );
}
