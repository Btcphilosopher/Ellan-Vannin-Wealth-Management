import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '好省购 - 好东西 · 省更多 | 极致性价比电商平台',
  description: '好东西 · 省更多。高效率源头采购、工厂直供的极具性价比的大众电商平台。',
  openGraph: {
    title: '好省购 - 好东西 · 省更多',
    description: '好东西 · 省更多。高效率源头采购、工厂直供的极具性价比的大众电商平台。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '好省购 - 好东西 · 省更多',
    description: '好东西 · 省更多。高效率源头采购、工厂直供的极具性价比的大众电商平台。',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
