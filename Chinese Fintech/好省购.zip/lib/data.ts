export interface Product {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  imageUrl: string;
  price: number;
  originalPrice: number;
  badge: string;
  description: string;
  salesVolume: string;
  rating: number;
  reviewsCount: number;
  specs: { label: string; value: string }[];
  factoryInfo: {
    name: string;
    location: string;
    dispatchSpeed: string;
  };
  isFlashSale?: boolean;
  flashSaleProgress?: number;
  flashSaleStock?: number;
}

export interface Category {
  id: string;
  name: string;
  iconName: string;
  subcategories: string[];
  popularProducts: string[];
}

export const CATEGORIES: Category[] = [
  {
    id: "digital",
    name: "手机数码",
    iconName: "Smartphone",
    subcategories: ["手机", "平板电脑", "耳机", "智能手表", "充电设备", "电脑配件"],
    popularProducts: ["小米 14 Pro", "华为 Mate 60 Pro", "无线蓝牙耳机", "智能健康手环"]
  },
  {
    id: "appliances",
    name: "家用电器",
    iconName: "Tv",
    subcategories: ["电视机", "冰箱", "洗衣机", "空调", "厨房电器", "生活电器"],
    popularProducts: ["海尔滚筒洗衣机", "九阳空气炸锅", "美的微波炉", "智能扫地机器人"]
  },
  {
    id: "apparel",
    name: "服饰鞋包",
    iconName: "Shirt",
    subcategories: ["男装", "女装", "运动鞋", "潮流女鞋", "双肩包", "精品男包"],
    popularProducts: ["李宁运动鞋 男款", "地平线双肩包", "极简防风风衣", "透气网面跑鞋"]
  },
  {
    id: "beauty",
    name: "美妆个护",
    iconName: "Sparkles",
    subcategories: ["补水保湿", "面部护肤", "彩妆眼影", "洗发护发", "个人清洁", "香水精油"],
    popularProducts: ["韩束红石榴护肤套装", "完美日记唇釉", "植物草本洗发水", "高保湿面霜"]
  },
  {
    id: "baby",
    name: "母婴玩具",
    iconName: "Baby",
    subcategories: ["婴儿奶粉", "纸尿裤", "益智积木", "毛绒玩具", "儿童玩具", "婴儿服饰"],
    popularProducts: ["益智拼插积木", "超柔亲肤纸尿裤", "婴幼儿有机奶粉", "仿真遥控跑车"]
  },
  {
    id: "home",
    name: "家居生活",
    iconName: "Home",
    subcategories: ["床上用品", "收纳整理", "餐具水具", "纸品湿巾", "日常洗护", "家具软装"],
    popularProducts: ["水星家纺四件套", "无痕防滑衣架", "不锈钢真空保温杯", "超柔抽取式面巾纸"]
  },
  {
    id: "sports",
    name: "运动户外",
    iconName: "Activity",
    subcategories: ["户外装备", "运动鞋服", "健身器材", "骑行装备", "露营烧烤", "运动水杯"],
    popularProducts: ["牧高笛户外帐篷", "智能计数跳绳", "超轻碳素羽毛球拍", "便携式露营椅"]
  },
  {
    id: "food",
    name: "食品饮料",
    iconName: "Utensils",
    subcategories: ["休闲零食", "方便速食", "酒水饮料", "粮油调味", "新鲜水果", "坚果炒货"],
    popularProducts: ["统一老坛酸菜方便面", "三只松鼠坚果礼盒", "农夫山泉矿泉水", "无糖黑咖啡"]
  },
  {
    id: "auto",
    name: "汽车用品",
    iconName: "Car",
    subcategories: ["车载充电", "车载香薰", "车内饰品", "安全座椅", "洗车工具", "行车记录"],
    popularProducts: ["极氪太空记忆棉颈枕", "高清夜视行车记录仪", "车载快速充电器", "固态持久汽车香膏"]
  }
];

export const MOCK_PRODUCTS: Product[] = [
  // TODAY'S HOT PRODUCTS
  {
    id: "lining-shoes",
    name: "李宁运动鞋 男款",
    category: "服饰鞋包",
    subcategory: "运动鞋",
    imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80",
    price: 89,
    originalPrice: 199,
    badge: "爆款",
    description: "轻便透气 缓震耐磨 适合日常跑步与休闲穿搭",
    salesVolume: "已售 2.8万+",
    rating: 5,
    reviewsCount: 4892,
    specs: [
      { label: "鞋帮高度", value: "低帮" },
      { label: "鞋底材质", value: "EVA/橡胶" },
      { label: "鞋面材质", value: "网布/织物" },
      { label: "适用人群", value: "男士" }
    ],
    factoryInfo: {
      name: "福建晋江运动鞋源头制造厂",
      location: "福建 泉州",
      dispatchSpeed: "下单24小时内发货"
    }
  },
  {
    id: "joyoung-airfryer",
    name: "九阳空气炸锅",
    category: "家用电器",
    subcategory: "厨房电器",
    imageUrl: "https://images.unsplash.com/photo-1621972750749-0fbb1abb7736?auto=format&fit=crop&w=600&q=80",
    price: 199,
    originalPrice: 399,
    badge: "热卖",
    description: "4.5L大容量 无油低脂 智能控温 精确时间预约",
    salesVolume: "已售 1.5万+",
    rating: 5,
    reviewsCount: 3201,
    specs: [
      { label: "容量", value: "4.5L" },
      { label: "额定功率", value: "1400W" },
      { label: "控制方式", value: "旋钮式" },
      { label: "加热方式", value: "3D热风循环" }
    ],
    factoryInfo: {
      name: "浙江宁波智能厨电制造基地",
      location: "浙江 宁波",
      dispatchSpeed: "下单12小时内闪电发货"
    }
  },
  {
    id: "kans-skincare",
    name: "韩束护肤套装",
    category: "美妆个护",
    subcategory: "面部护肤",
    imageUrl: "https://images.unsplash.com/photo-1608248597279-f99d160bfcbc?auto=format&fit=crop&w=600&q=80",
    price: 129,
    originalPrice: 299,
    badge: "热卖",
    description: "红石榴补水保湿 提亮肤色 紧致抗初老5件套",
    salesVolume: "已售 3.2万+",
    rating: 5,
    reviewsCount: 6512,
    specs: [
      { label: "适用肤质", value: "所有肤质" },
      { label: "套装内含", value: "洁面+水+乳+霜+眼霜" },
      { label: "主要成分", value: "红石榴多酚、烟酰胺" },
      { label: "功效", value: "补水保湿、抗氧化" }
    ],
    factoryInfo: {
      name: "广州白云生物科技美妆厂",
      location: "广东 广州",
      dispatchSpeed: "下单24小时内发货"
    }
  },
  {
    id: "horizon-backpack",
    name: "地平线双肩包",
    category: "服饰鞋包",
    subcategory: "双肩包",
    imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&q=80",
    price: 59,
    originalPrice: 129,
    badge: "好评",
    description: "大容量商务电脑包 防泼水多功能 差旅必备",
    salesVolume: "已售 9500+",
    rating: 4.8,
    reviewsCount: 1540,
    specs: [
      { label: "容纳电脑尺寸", value: "15.6英寸" },
      { label: "材质", value: "防撕裂涤纶面料" },
      { label: "重量", value: "0.65kg" },
      { label: "背负系统", value: "S型加宽透气肩带" }
    ],
    factoryInfo: {
      name: "河北白沟箱包出口直供厂",
      location: "河北 保定",
      dispatchSpeed: "源头直发 48小时内发货"
    }
  },
  {
    id: "tongyi-noodles",
    name: "统一方便面 24包",
    category: "食品饮料",
    subcategory: "方便速食",
    imageUrl: "https://images.unsplash.com/photo-1612966608967-3091c742f216?auto=format&fit=crop&w=600&q=80",
    price: 32,
    originalPrice: 69,
    badge: "热卖",
    description: "经典老坛酸菜牛肉面/红烧牛肉面 劲道美味 整箱囤货装",
    salesVolume: "已售 5.6万+",
    rating: 5,
    reviewsCount: 12480,
    specs: [
      { label: "规格", value: "115g * 24包 (箱装)" },
      { label: "口味", value: "经典混合装" },
      { label: "保质期", value: "6个月" },
      { label: "储存方法", value: "阴凉干燥处避免阳光直射" }
    ],
    factoryInfo: {
      name: "统一食品中原产业园园区",
      location: "河南 郑州",
      dispatchSpeed: "全国18大仓就近急速配送"
    }
  },

  // HERO / PROMOTIONAL GRID
  {
    id: "xiaomi-14",
    name: "小米 14",
    category: "手机数码",
    subcategory: "手机",
    imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80",
    price: 1999,
    originalPrice: 3999,
    badge: "限时特惠",
    description: "旗舰性能 骁龙8Gen3 徕卡影像 亲民性价比",
    salesVolume: "已售 4.5万+",
    rating: 4.9,
    reviewsCount: 9811,
    specs: [
      { label: "处理器", value: "骁龙8 Gen3 旗舰级芯片" },
      { label: "屏幕", value: "6.36英寸 1.5K 高清屏" },
      { label: "充电", value: "90W小米澎湃有线快充" },
      { label: "系统", value: "Xiaomi HyperOS" }
    ],
    factoryInfo: {
      name: "小米智能工厂北京亦庄基地",
      location: "北京 亦庄",
      dispatchSpeed: "极速顺丰包邮 24小时内发货"
    }
  },
  {
    id: "haier-washing-machine",
    name: "海尔洗衣机",
    category: "家用电器",
    subcategory: "洗衣机",
    imageUrl: "https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=600&q=80",
    price: 899,
    originalPrice: 1899,
    badge: "品牌特卖",
    description: "10KG大容量 直驱变频 滚筒洗烘一体 智能控水",
    salesVolume: "已售 1.2万+",
    rating: 4.9,
    reviewsCount: 2315,
    specs: [
      { label: "洗涤容量", value: "10kg" },
      { label: "电机类型", value: "DD直驱变频电机" },
      { label: "脱水转速", value: "1400转/分" },
      { label: "排水方式", value: "上排水" }
    ],
    factoryInfo: {
      name: "青岛海尔互联工厂超级产线",
      location: "山东 青岛",
      dispatchSpeed: "顺丰冷链物流 免费送货上门安装"
    }
  },
  {
    id: "wireless-earphones",
    name: "无线蓝牙耳机",
    category: "手机数码",
    subcategory: "耳机",
    imageUrl: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=600&q=80",
    price: 9.9,
    originalPrice: 59.9,
    badge: "9.9包邮",
    description: "真无线蓝牙5.3 智能降噪 超长续航 超低延迟",
    salesVolume: "已售 12.8万+",
    rating: 4.9,
    reviewsCount: 34105,
    specs: [
      { label: "蓝牙版本", value: "Bluetooth 5.3" },
      { label: "单次续航", value: "约6小时 (配充电仓达24小时)" },
      { label: "传输距离", value: "10米无障碍" },
      { label: "充电接口", value: "Type-C 闪充" }
    ],
    factoryInfo: {
      name: "深圳宝安数码电子源头直销厂",
      location: "广东 深圳",
      dispatchSpeed: "量产直发 下单24小时内闪电包邮"
    }
  },

  // FLASH SALE SPECIFICS
  {
    id: "powerstrip",
    name: "多功能安全插线板",
    category: "家居生活",
    subcategory: "日常洗护",
    imageUrl: "https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&w=600&q=80",
    price: 5.9,
    originalPrice: 19.9,
    badge: "秒杀",
    description: "新国标安全防过载 多插位带独立开关 1.8米线长",
    salesVolume: "已抢 9400+",
    rating: 4.8,
    reviewsCount: 5410,
    specs: [
      { label: "线长", value: "1.8米" },
      { label: "最大功率", value: "2500W" },
      { label: "插位数", value: "4五孔+3USB" },
      { label: "材质", value: "高阻燃阻热材料" }
    ],
    factoryInfo: {
      name: "浙江余姚新国标插座生产大厂",
      location: "浙江 余姚",
      dispatchSpeed: "闪电直发 24小时内发货"
    },
    isFlashSale: true,
    flashSaleProgress: 94,
    flashSaleStock: 10000
  },
  {
    id: "tissue-pack",
    name: "超柔本色抽纸 30包",
    category: "家居生活",
    subcategory: "纸品湿巾",
    imageUrl: "https://images.unsplash.com/photo-1603512301072-ca1ebae217b7?auto=format&fit=crop&w=600&q=80",
    price: 12.9,
    originalPrice: 39.9,
    badge: "爆省",
    description: "原生竹浆本色无添加 4层加厚 湿水不易破 居家囤货",
    salesVolume: "已抢 3.2万+",
    rating: 4.9,
    reviewsCount: 8902,
    specs: [
      { label: "规格", value: "110抽 * 30包/整箱" },
      { label: "层数", value: "4层加厚" },
      { label: "原料", value: "100%原生竹浆" },
      { label: "安全性", value: "母婴适用 零漂白" }
    ],
    factoryInfo: {
      name: "四川竹浆本色抽纸大型骨干厂",
      location: "四川 宜宾",
      dispatchSpeed: "原产地直发 48小时内顺丰极速达"
    },
    isFlashSale: true,
    flashSaleProgress: 75,
    flashSaleStock: 45000
  },
  {
    id: "powerbank",
    name: "20000mAh急速充电宝",
    category: "手机数码",
    subcategory: "充电设备",
    imageUrl: "https://images.unsplash.com/photo-1609592424109-dd9892f1b17c?auto=format&fit=crop&w=600&q=80",
    price: 29.9,
    originalPrice: 89.9,
    badge: "秒杀",
    description: "双向22.5W超级快充 数显大容量 兼容苹果/安卓/PD",
    salesVolume: "已抢 1.8万+",
    rating: 4.8,
    reviewsCount: 6511,
    specs: [
      { label: "电池容量", value: "20000mAh / 74Wh" },
      { label: "输出功率", value: "PD 22.5W Max" },
      { label: "输入接口", value: "Type-C / Micro" },
      { label: "安全保障", value: "十重安全保护 智能恒温" }
    ],
    factoryInfo: {
      name: "东莞松山湖新能源高科产线",
      location: "广东 东莞",
      dispatchSpeed: "当日发货 顺丰陆运直发"
    },
    isFlashSale: true,
    flashSaleProgress: 61,
    flashSaleStock: 30000
  },
  {
    id: "thermos-cup",
    name: "加厚防滑保温杯",
    category: "家居生活",
    subcategory: "餐具水具",
    imageUrl: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=600&q=80",
    price: 8.8,
    originalPrice: 29.9,
    badge: "秒杀",
    description: "316食品级不锈钢 双层抽真空 12小时持久保温保冷",
    salesVolume: "已抢 2.4万+",
    rating: 4.7,
    reviewsCount: 4210,
    specs: [
      { label: "容量", value: "500ml" },
      { label: "材质", value: "316医用级不锈钢内胆" },
      { label: "保温性能", value: "12小时 ≥ 54℃" },
      { label: "防漏设计", value: "食品级硅胶密封圈" }
    ],
    factoryInfo: {
      name: "浙江武义杯业制造出口工厂",
      location: "浙江 金华",
      dispatchSpeed: "精工制造 当日下单闪电发货"
    },
    isFlashSale: true,
    flashSaleProgress: 88,
    flashSaleStock: 28000
  },

  // ADDITIONAL CATEGORY PRODUCTS TO ENSURE CATEGORY FILTER WORKS LIKE A REAL APP
  {
    id: "huawei-mate60",
    name: "华为 Mate 60 Pro",
    category: "手机数码",
    subcategory: "手机",
    imageUrl: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=600&q=80",
    price: 4299,
    originalPrice: 6999,
    badge: "爆款",
    description: "卫星通话 麒麟9000S芯片 玄武架构 昆仑玻璃超抗摔",
    salesVolume: "已售 6.1万+",
    rating: 5,
    reviewsCount: 15421,
    specs: [
      { label: "运行内存", value: "12GB" },
      { label: "存储容量", value: "512GB" },
      { label: "电池容量", value: "5000mAh" },
      { label: "特殊功能", value: "天通卫星通话、双向北斗卫星消息" }
    ],
    factoryInfo: {
      name: "华为深圳高精密智能车间",
      location: "广东 深圳",
      dispatchSpeed: "24小时内顺丰特快顺丰速运"
    }
  },
  {
    id: "midea-microwave",
    name: "美的智能微波炉",
    category: "家用电器",
    subcategory: "厨房电器",
    imageUrl: "https://images.unsplash.com/photo-1574269909862-7e1d70bb8078?auto=format&fit=crop&w=600&q=80",
    price: 269,
    originalPrice: 499,
    badge: "热卖",
    description: "21L大容量 五档火力 智能一键除味 平板均匀加热",
    salesVolume: "已售 2.4万+",
    rating: 4.8,
    reviewsCount: 3912,
    specs: [
      { label: "容量", value: "21L" },
      { label: "输入功率", value: "1150W" },
      { label: "底盘类型", value: "平板防爆底盘" },
      { label: "保修期限", value: "全国联保3年" }
    ],
    factoryInfo: {
      name: "广东顺德世界级家电城基地",
      location: "广东 佛山",
      dispatchSpeed: "厂仓直发 送货入户"
    }
  },
  {
    id: "perfectdiary-lipstick",
    name: "完美日记丝绒唇釉",
    category: "美妆个护",
    subcategory: "彩妆眼影",
    imageUrl: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&w=600&q=80",
    price: 29,
    originalPrice: 89,
    badge: "秒杀",
    description: "经典反重力丝绒唇泥 哑光雾面 显白持久不掉色",
    salesVolume: "已售 8.5万+",
    rating: 4.8,
    reviewsCount: 18420,
    specs: [
      { label: "色号", value: "经典复古红、元气奶橘" },
      { label: "妆效", value: "哑光丝绒雾面" },
      { label: "规格", value: "3.5g" },
      { label: "产地", value: "广东" }
    ],
    factoryInfo: {
      name: "科丝美诗代工中国总部超级化妆品厂",
      location: "广东 广州",
      dispatchSpeed: "下单12小时内发货"
    }
  },
  {
    id: "building-blocks",
    name: "乐高兼容积木 城堡",
    category: "母婴玩具",
    subcategory: "益智积木",
    imageUrl: "https://images.unsplash.com/photo-1566694271850-269e5c222f20?auto=format&fit=crop&w=600&q=80",
    price: 45,
    originalPrice: 129,
    badge: "爆款",
    description: "1200+片精密颗粒 环保ABS材质 亲子互动极佳选择",
    salesVolume: "已售 1.9万+",
    rating: 4.9,
    reviewsCount: 3412,
    specs: [
      { label: "适用年龄", value: "6岁以上" },
      { label: "颗粒数量", value: "1280pcs" },
      { label: "材质", value: "食品级ABS塑料" },
      { label: "安全认证", value: "国家3C认证" }
    ],
    factoryInfo: {
      name: "广东汕头澄海益智积木源头厂",
      location: "广东 汕头",
      dispatchSpeed: "出海品质 24小时内直发"
    }
  },
  {
    id: "mercury-bedset",
    name: "水星家纺全棉被套",
    category: "家居生活",
    subcategory: "床上用品",
    imageUrl: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=600&q=80",
    price: 79,
    originalPrice: 199,
    badge: "好评",
    description: "100%全棉磨毛 亲肤柔软透气 环保活性印染不褪色",
    salesVolume: "已售 3.3万+",
    rating: 4.8,
    reviewsCount: 5122,
    specs: [
      { label: "面料成分", value: "100%全棉" },
      { label: "适用床宽", value: "1.5米 / 1.8米通用" },
      { label: "工艺", value: "斜纹高密活性印染" },
      { label: "安全等级", value: "GB18401-A类 (母婴级安全)" }
    ],
    factoryInfo: {
      name: "江苏南通中国叠石桥家电城纺织厂",
      location: "江苏 南通",
      dispatchSpeed: "24小时就近大仓配送发货"
    }
  },
  {
    id: "mugaodi-tent",
    name: "牧高笛露营帐篷",
    category: "运动户外",
    subcategory: "户外装备",
    imageUrl: "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&w=600&q=80",
    price: 159,
    originalPrice: 399,
    badge: "推荐",
    description: "3-4人双层防暴雨 智能弹簧全自动 3秒极速开帐",
    salesVolume: "已售 4200+",
    rating: 4.9,
    reviewsCount: 890,
    specs: [
      { label: "容纳人数", value: "3-4人" },
      { label: "防雨指数", value: "PU3000mm 强力防暴雨" },
      { label: "支架材质", value: "高强度玻璃纤维杆" },
      { label: "重量", value: "3.2kg" }
    ],
    factoryInfo: {
      name: "浙江绍兴高档帐篷及户外制品基地",
      location: "浙江 绍兴",
      dispatchSpeed: "厂发当日出物流单号"
    }
  },
  {
    id: "squirrel-nuts",
    name: "三只松鼠坚果大礼包",
    category: "食品饮料",
    subcategory: "休闲零食",
    imageUrl: "https://images.unsplash.com/photo-1594911774802-8822a7079af1?auto=format&fit=crop&w=600&q=80",
    price: 49,
    originalPrice: 119,
    badge: "爆款",
    description: "夏威夷果碧根果等9袋精装 每日坚果全家分享装",
    salesVolume: "已售 10.2万+",
    rating: 5,
    reviewsCount: 34091,
    specs: [
      { label: "净含量", value: "1480g" },
      { label: "零食组合", value: "碧根果、夏威夷果、炭烧腰果、巴旦木等共9包" },
      { label: "保质期", value: "240天" },
      { label: "特色", value: "低温慢烘，保留天然营养" }
    ],
    factoryInfo: {
      name: "安徽芜湖三只松鼠国家级现代物流园",
      location: "安徽 芜湖",
      dispatchSpeed: "下单10小时闪电出库顺丰直发"
    }
  },
  {
    id: "neck-pillow",
    name: "极氪车用颈枕",
    category: "汽车用品",
    subcategory: "车内饰品",
    imageUrl: "https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=600&q=80",
    price: 19,
    originalPrice: 49,
    badge: "特卖",
    description: "太空慢回弹记忆棉 科学承托颈椎 缓解长途驾驶疲劳",
    salesVolume: "已售 8000+",
    rating: 4.8,
    reviewsCount: 1205,
    specs: [
      { label: "内芯材质", value: "太空高密度记忆棉" },
      { label: "外套面料", value: "亲肤透气双面针织物" },
      { label: "固定方式", value: "高弹性松紧绑带" },
      { label: "适用车型", value: "通用型 (适配99%以上汽车座椅)" }
    ],
    factoryInfo: {
      name: "江苏常州汽车精装配件集群工厂",
      location: "江苏 常州",
      dispatchSpeed: "下单24小时内工厂直发"
    }
  }
];
