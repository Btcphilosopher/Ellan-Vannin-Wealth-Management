export type Language = 'zh' | 'en' | 'tc';

export interface Fund {
  id: string;
  name: string;
  nameEn: string;
  desc: string;
  descEn: string;
  tags: string[];
  tagsEn: string[];
  returnRate: string;
  returnPeriod: string;
  returnPeriodEn: string;
  image: string;
  aum: string;
  inceptionDate: string;
  benchmark: string;
  sharpeRatio: string;
  maxDrawdown: string;
  nav: string;
  performanceHistory: { date: string; nav: number; benchmarkNav: number }[];
  overview: string;
  overviewEn: string;
}

export interface Insight {
  id: string;
  title: string;
  titleEn: string;
  category: string;
  categoryEn: string;
  date: string;
  author: string;
  readTime: string;
  image: string;
  summary: string;
  summaryEn: string;
  content: string[];
  contentEn: string[];
  tags: string[];
}

export interface MetricItem {
  label: string;
  labelEn: string;
  value: string;
  unit: string;
  unitEn: string;
  subtext: string;
  subtextEn: string;
}
