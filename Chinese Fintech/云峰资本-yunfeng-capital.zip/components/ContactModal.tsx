'use client';

import React, { useState } from 'react';
import { X, Building2, Mail, Phone, MapPin, Send, CheckCircle2 } from 'lucide-react';
import { Language } from '@/types';

interface ContactModalProps {
  lang: Language;
  onClose: () => void;
  initialFund?: string;
}

export default function ContactModal({
  lang,
  onClose,
  initialFund = '',
}: ContactModalProps) {
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [institution, setInstitution] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState(
    initialFund ? `我们对【${initialFund}】产品策略感兴趣，希望获取详细尽调包并安排路演交流。` : ''
  );

  const t = {
    zh: {
      title: '机构合作与投资者垂询',
      sub: '面向主权基金、保险资管、家族办公室及大型机构投资者的专属对接通道',
      nameLabel: '您的姓名 / 职衔',
      instLabel: '所属机构 / 家族办公室名称',
      emailLabel: '机构工作邮箱',
      msgLabel: '垂询事宜 / 交流诉求',
      submitBtn: '提交机构垂询',
      successMsg: '我们已收到您的垂询申请，云峰资本投资者关系主管将在1个工作日内与您取得联系。',
      officesTitle: '全球投研与业务枢纽',
      offices: [
        { city: '上海总部', addr: '浦东新区世纪大道 100 号上海环球金融中心 58 层', tel: '+86 (21) 6888-8888' },
        { city: '香港办公室', addr: '中环金融街 8 号国际金融中心二期 45 层', tel: '+852 3900-8800' },
        { city: '新加坡办公室', addr: '滨海湾金融中心第一大厦 32 层', tel: '+65 6700-8800' },
      ],
    },
    en: {
      title: 'Institutional Inquiries & LP Relations',
      sub: 'Dedicated liaison channel for sovereign funds, endowments, and multi-family offices',
      nameLabel: 'Your Name / Title',
      instLabel: 'Institution / Family Office',
      emailLabel: 'Official Work Email',
      msgLabel: 'Inquiry Details / Agenda',
      submitBtn: 'Submit Inquiry',
      successMsg: 'Thank you. A senior representative from our LP Relations team will contact you within 24 hours.',
      officesTitle: 'Global Hubs',
      offices: [
        { city: 'Shanghai HQ', addr: 'Floor 58, Shanghai World Financial Center, Pudong', tel: '+86 (21) 6888-8888' },
        { city: 'Hong Kong', addr: 'Floor 45, Two International Finance Centre, Central', tel: '+852 3900-8800' },
        { city: 'Singapore', addr: 'Floor 32, Marina Bay Financial Centre Tower 1', tel: '+65 6700-8800' },
      ],
    },
    tc: {
      title: '機構合作與投資者垂詢',
      sub: '面向主權基金、保險資管、家族辦公室及大型機構投資者的專屬對接通道',
      nameLabel: '您的姓名 / 職銜',
      instLabel: '所屬機構 / 家族辦公室名稱',
      emailLabel: '機構工作郵箱',
      msgLabel: '垂詢事宜 / 交流訴求',
      submitBtn: '提交機構垂詢',
      successMsg: '我們已收到您的垂詢申請，雲峰資本投資者關係主管將在1個工作日內與您取得聯繫。',
      officesTitle: '全球投研與業務樞紐',
      offices: [
        { city: '上海總部', addr: '浦東新區世紀大道 100 號上海環球金融中心 58 層', tel: '+86 (21) 6888-8888' },
        { city: '香港辦公室', addr: '中環金融街 8 號國際金融中心二期 45 層', tel: '+852 3900-8800' },
        { city: '新加坡辦公室', addr: '濱海灣金融中心第一大廈 32 層', tel: '+65 6700-8800' },
      ],
    },
  }[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden relative animate-in fade-in zoom-in-95 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#B89358]" />
            <h3 className="text-xs font-semibold text-[#8B6E3C] uppercase tracking-wider">
              {t.title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          {!submitted ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <p className="text-xs text-gray-500 mb-4">{t.sub}</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">{t.nameLabel}</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="张先生 / Managing Director"
                    className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded focus:ring-1 focus:ring-[#B89358] focus:border-[#B89358] outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">{t.instLabel}</label>
                  <input
                    type="text"
                    required
                    value={institution}
                    onChange={(e) => setInstitution(e.target.value)}
                    placeholder="e.g. Asia Endowment / Family Office"
                    className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded focus:ring-1 focus:ring-[#B89358] focus:border-[#B89358] outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">{t.emailLabel}</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="contact@institution.com"
                  className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded focus:ring-1 focus:ring-[#B89358] focus:border-[#B89358] outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">{t.msgLabel}</label>
                <textarea
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="请详细说明您的机构配置需求与关注策略..."
                  className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded focus:ring-1 focus:ring-[#B89358] focus:border-[#B89358] outline-hidden"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded bg-[#B89358] hover:bg-[#A38048] text-white text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
              >
                {t.submitBtn}
              </button>
            </form>
          ) : (
            <div className="py-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">垂询已正式送达</h3>
              <p className="text-xs sm:text-sm text-gray-600 max-w-md mx-auto">{t.successMsg}</p>
            </div>
          )}

          {/* Offices List */}
          <div className="pt-4 border-t border-gray-100">
            <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider mb-3">
              {t.officesTitle}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {t.offices.map((office, idx) => (
                <div key={idx} className="p-3 rounded bg-gray-50 border border-gray-200 text-xs">
                  <div className="font-bold text-gray-900 mb-1">{office.city}</div>
                  <div className="text-[11px] text-gray-500 mb-1.5 leading-snug">{office.addr}</div>
                  <div className="text-[11px] text-[#8A6F3E] font-medium">{office.tel}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
