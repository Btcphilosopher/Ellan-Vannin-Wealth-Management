'use client';

import React, { useState } from 'react';
import Logo from './Logo';
import { ChevronDown, Globe, Menu, X, Lock } from 'lucide-react';
import { Language } from '@/types';

interface NavbarProps {
  currentTab: string;
  onTabChange: (tabId: string) => void;
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenLoginModal: () => void;
}

export default function Navbar({
  currentTab,
  onTabChange,
  lang,
  onLanguageChange,
  onOpenLoginModal,
}: NavbarProps) {
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', labelZh: '首页', labelEn: 'Home', labelTc: '首頁' },
    { id: 'about', labelZh: '关于我们', labelEn: 'About Us', labelTc: '關於我們' },
    { id: 'strategy', labelZh: '投资策略', labelEn: 'Strategies', labelTc: '投資策略' },
    { id: 'funds', labelZh: '产品与基金', labelEn: 'Funds', labelTc: '產品與基金' },
    { id: 'insights', labelZh: '研究与洞察', labelEn: 'Insights', labelTc: '研究與洞察' },
    { id: 'ir', labelZh: '投资者关系', labelEn: 'Investor Relations', labelTc: '投資者關係' },
  ];

  const getNavLabel = (item: (typeof navLinks)[0]) => {
    if (lang === 'en') return item.labelEn;
    if (lang === 'tc') return item.labelTc;
    return item.labelZh;
  };

  const getLanguageLabel = () => {
    if (lang === 'en') return 'English';
    if (lang === 'tc') return '繁體中文';
    return '中文';
  };

  const loginButtonText = {
    zh: '投资者登录',
    en: 'Investor Login',
    tc: '投資者登錄',
  }[lang];

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-[#E8EAEE] transition-all duration-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <button
          onClick={() => onTabChange('home')}
          className="focus:outline-hidden text-left cursor-pointer"
        >
          <Logo variant="dark" size="md" />
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center space-x-1 xl:space-x-4">
          {navLinks.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onTabChange(item.id);
                  const el = document.getElementById(item.id);
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`relative px-3.5 py-2 text-sm font-medium transition-colors cursor-pointer group ${
                  isActive
                    ? 'text-[#B89358] font-semibold'
                    : 'text-[#374151] hover:text-[#B89358]'
                }`}
              >
                <span>{getNavLabel(item)}</span>
                {/* Active indicator bar matching image */}
                {isActive && (
                  <span className="absolute bottom-0 left-3.5 right-3.5 h-[2.5px] bg-[#B89358] rounded-full" />
                )}
                {!isActive && (
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 group-hover:w-2/3 h-[2px] bg-[#C59B5F]/40 transition-all duration-300 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Action Section */}
        <div className="hidden sm:flex items-center space-x-4">
          {/* Language Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setLangMenuOpen(!langMenuOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-[#4B5563] hover:text-[#111827] font-medium rounded border border-transparent hover:border-[#E5E7EB] hover:bg-[#F9FAFB] transition-all cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-[#9CA3AF]" />
              <span>{getLanguageLabel()}</span>
              <ChevronDown className="w-3.5 h-3.5 text-[#6B7280] ml-0.5" />
            </button>

            {langMenuOpen && (
              <div
                className="absolute right-0 mt-1.5 w-32 bg-white rounded-md shadow-lg border border-[#E5E7EB] py-1 text-xs z-50 animate-in fade-in slide-in-from-top-1"
                onMouseLeave={() => setLangMenuOpen(false)}
              >
                <button
                  onClick={() => {
                    onLanguageChange('zh');
                    setLangMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 hover:bg-[#F5F2EB] flex items-center justify-between cursor-pointer ${
                    lang === 'zh' ? 'text-[#B89358] font-semibold bg-[#FAF7F2]' : 'text-gray-700'
                  }`}
                >
                  <span>简体中文</span>
                  {lang === 'zh' && <span className="w-1.5 h-1.5 rounded-full bg-[#B89358]" />}
                </button>
                <button
                  onClick={() => {
                    onLanguageChange('tc');
                    setLangMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 hover:bg-[#F5F2EB] flex items-center justify-between cursor-pointer ${
                    lang === 'tc' ? 'text-[#B89358] font-semibold bg-[#FAF7F2]' : 'text-gray-700'
                  }`}
                >
                  <span>繁體中文</span>
                  {lang === 'tc' && <span className="w-1.5 h-1.5 rounded-full bg-[#B89358]" />}
                </button>
                <button
                  onClick={() => {
                    onLanguageChange('en');
                    setLangMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 hover:bg-[#F5F2EB] flex items-center justify-between cursor-pointer ${
                    lang === 'en' ? 'text-[#B89358] font-semibold bg-[#FAF7F2]' : 'text-gray-700'
                  }`}
                >
                  <span>English</span>
                  {lang === 'en' && <span className="w-1.5 h-1.5 rounded-full bg-[#B89358]" />}
                </button>
              </div>
            )}
          </div>

          {/* Investor Login Button */}
          <button
            onClick={onOpenLoginModal}
            className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-medium text-[#A07A3B] border border-[#C5A36A] rounded hover:bg-[#B89358] hover:text-white hover:border-[#B89358] transition-all duration-200 shadow-2xs cursor-pointer active:scale-95"
          >
            <Lock className="w-3 h-3 opacity-80" />
            <span>{loginButtonText}</span>
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex sm:hidden items-center gap-2">
          <button
            onClick={onOpenLoginModal}
            className="px-2.5 py-1 text-xs text-[#A07A3B] border border-[#C5A36A] rounded"
          >
            {loginButtonText}
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-gray-700 hover:text-[#B89358] rounded-md focus:outline-hidden"
            aria-label="Toggle Navigation"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="sm:hidden bg-white border-b border-gray-200 px-4 pt-2 pb-6 space-y-3">
          <div className="flex flex-col space-y-1">
            {navLinks.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onTabChange(item.id);
                  setMobileMenuOpen(false);
                  const el = document.getElementById(item.id);
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`text-left px-3 py-2.5 rounded-md text-sm font-medium ${
                  currentTab === item.id
                    ? 'bg-[#F9F6F0] text-[#B89358] font-bold'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                {getNavLabel(item)}
              </button>
            ))}
          </div>

          <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
            <span className="text-xs text-gray-500 font-medium">语言 / Language:</span>
            <div className="flex gap-2">
              <button
                onClick={() => onLanguageChange('zh')}
                className={`text-xs px-2 py-1 rounded ${
                  lang === 'zh' ? 'bg-[#B89358] text-white' : 'bg-gray-100 text-gray-700'
                }`}
              >
                简
              </button>
              <button
                onClick={() => onLanguageChange('tc')}
                className={`text-xs px-2 py-1 rounded ${
                  lang === 'tc' ? 'bg-[#B89358] text-white' : 'bg-gray-100 text-gray-700'
                }`}
              >
                繁
              </button>
              <button
                onClick={() => onLanguageChange('en')}
                className={`text-xs px-2 py-1 rounded ${
                  lang === 'en' ? 'bg-[#B89358] text-white' : 'bg-gray-100 text-gray-700'
                }`}
              >
                EN
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
