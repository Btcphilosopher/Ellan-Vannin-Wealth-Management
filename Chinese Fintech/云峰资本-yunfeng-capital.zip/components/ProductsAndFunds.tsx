'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, TrendingUp } from 'lucide-react';
import { Fund, Language } from '@/types';

interface ProductsAndFundsProps {
  funds: Fund[];
  lang: Language;
  onSelectFund: (fund: Fund) => void;
  onViewAllFunds: () => void;
}

export default function ProductsAndFunds({
  funds,
  lang,
  onSelectFund,
  onViewAllFunds,
}: ProductsAndFundsProps) {
  const headerText = {
    zh: { title: '产品与基金', viewAll: '查看全部' },
    en: { title: 'Products & Funds', viewAll: 'View All' },
    tc: { title: '產品與基金', viewAll: '查看全部' },
  }[lang];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between pb-3.5 mb-4 border-b border-[#E5E7EB]">
        <h3 className="text-lg sm:text-xl font-bold text-[#111827] font-heading-cn">
          {headerText.title}
        </h3>
        <button
          onClick={onViewAllFunds}
          className="group inline-flex items-center gap-1 text-xs sm:text-sm text-[#4B5563] hover:text-[#B89358] transition-colors cursor-pointer"
        >
          <span>{headerText.viewAll}</span>
          <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
        </button>
      </div>

      {/* Funds List */}
      <div className="flex flex-col space-y-3.5 flex-1">
        {funds.map((fund) => {
          const name = lang === 'en' ? fund.nameEn : fund.name;
          const desc = lang === 'en' ? fund.descEn : fund.desc;
          const tags = lang === 'en' ? fund.tagsEn : fund.tags;
          const returnPeriod = lang === 'en' ? fund.returnPeriodEn : fund.returnPeriod;

          return (
            <div
              key={fund.id}
              onClick={() => onSelectFund(fund)}
              className="group p-3 sm:p-3.5 rounded-lg border border-[#EAECEF] hover:border-[#D1B588] bg-white hover:bg-[#FDFBF7] transition-all duration-200 cursor-pointer shadow-2xs hover:shadow-md flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3.5 min-w-0">
                {/* Fund Thumbnail */}
                <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded overflow-hidden shrink-0 bg-gray-100">
                  <Image
                    src={fund.image}
                    alt={name}
                    fill
                    sizes="64px"
                    className="object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
                </div>

                {/* Fund Information */}
                <div className="min-w-0">
                  <h4 className="text-sm sm:text-[15px] font-bold text-[#111827] group-hover:text-[#9A7437] transition-colors truncate">
                    {name}
                  </h4>
                  <p className="text-xs text-[#6B7280] truncate mt-0.5">
                    {desc}
                  </p>
                  <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                    <span className="text-[11px] text-[#8C939E] font-medium">
                      {tags.join(' · ')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Fund Return Metrics */}
              <div className="text-right shrink-0 pl-2">
                <span className="text-base sm:text-lg font-bold text-[#B88746] font-serif-luxury tracking-tight block">
                  {fund.returnRate}
                </span>
                <span className="text-[11px] text-[#9CA3AF] block whitespace-nowrap mt-0.5">
                  {returnPeriod}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
