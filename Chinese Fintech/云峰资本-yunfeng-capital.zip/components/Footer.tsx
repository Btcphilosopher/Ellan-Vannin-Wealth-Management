'use client';

import React, { useState } from 'react';
import Logo from './Logo';
import { Mail, Linkedin, MessageCircle, X, Shield, Phone, MapPin } from 'lucide-react';
import { Language } from '@/types';

interface FooterProps {
  lang: Language;
  onTabChange: (tab: string) => void;
  onOpenContact: () => void;
}

export default function Footer({ lang, onTabChange, onOpenContact }: FooterProps) {
  const [showWechatModal, setShowWechatModal] = useState(false);

  const t = {
    zh: {
      links: [
        { id: 'home', label: '首页' },
        { id: 'about', label: '关于我们' },
        { id: 'strategy', label: '投资策略' },
        { id: 'funds', label: '产品与基金' },
        { id: 'insights', label: '研究与洞察' },
        { id: 'ir', label: '投资者关系' },
      ],
      copyright: '© 2025 云峰资本 版权所有',
      icp: '沪ICP备20250001号',
      disclaimer: '本网站所载资料仅供参考，不构成任何投资建议、要约或邀请。投资有风险，入市需谨慎。',
      wechatTitle: '关注云峰资本微信官方公众平台',
      wechatSub: '扫描二维码获取最新宏观策略、市场深度洞察与基金净值更新',
      headquarters: '中国·上海市浦东新区陆家嘴金融贸易区环球金融中心 58 层',
    },
    en: {
      links: [
        { id: 'home', label: 'Home' },
        { id: 'about', label: 'About Us' },
        { id: 'strategy', label: 'Strategies' },
        { id: 'funds', label: 'Products & Funds' },
        { id: 'insights', label: 'Insights' },
        { id: 'ir', label: 'Investor Relations' },
      ],
      copyright: '© 2025 Yunfeng Capital. All Rights Reserved.',
      icp: 'Shanghai ICP No. 20250001',
      disclaimer: 'Information contained herein is for informational purposes only and does not constitute an offer to buy or sell securities. Past performance is no guarantee of future returns.',
      wechatTitle: 'Yunfeng Capital Official WeChat',
      wechatSub: 'Scan QR code to access research updates and official notices.',
      headquarters: 'Floor 58, Shanghai World Financial Center, Lujiazui, Pudong, Shanghai, China',
    },
    tc: {
      links: [
        { id: 'home', label: '首頁' },
        { id: 'about', label: '關於我們' },
        { id: 'strategy', label: '投資策略' },
        { id: 'funds', label: '產品與基金' },
        { id: 'insights', label: '研究與洞察' },
        { id: 'ir', label: '投資者關係' },
      ],
      copyright: '© 2025 雲峰資本 版權所有',
      icp: '滬ICP備20250001號',
      disclaimer: '本網站所載資料僅供參考，不構成任何投資建議、要約或邀請。投資有風險，入市需謹慎。',
      wechatTitle: '關注雲峰資本微信官方公眾平台',
      wechatSub: '掃描二維碼獲取最新宏觀策略、市場深度洞察與基金淨值更新',
      headquarters: '中國·上海市浦東新區陸家嘴金融貿易區環球金融中心 58 層',
    },
  }[lang];

  return (
    <footer className="w-full bg-[#15191E] border-t border-[#232830] text-gray-400 text-xs py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Row matching image layout */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-[#242A34]">
          {/* Left: Brand Logo in dark theme */}
          <button
            onClick={() => onTabChange('home')}
            className="focus:outline-hidden text-left cursor-pointer"
          >
            <Logo variant="light" size="sm" />
          </button>

          {/* Center: Navigation Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-gray-300">
            {t.links.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  onTabChange(link.id);
                  const el = document.getElementById(link.id);
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="hover:text-[#DFC79E] transition-colors cursor-pointer"
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Right: Social & Contact Icons */}
          <div className="flex items-center gap-4 text-gray-300">
            {/* WeChat Button */}
            <button
              onClick={() => setShowWechatModal(true)}
              className="w-8 h-8 rounded-full bg-[#202630] hover:bg-[#2B3442] hover:text-[#C59B5F] flex items-center justify-center transition-all cursor-pointer"
              title="WeChat Official Account"
            >
              <MessageCircle className="w-4 h-4" />
            </button>

            {/* LinkedIn Button */}
            <a
              href="https://www.linkedin.com"
              target="_blank"
              rel="noreferrer"
              className="w-8 h-8 rounded-full bg-[#202630] hover:bg-[#2B3442] hover:text-[#C59B5F] flex items-center justify-center transition-all cursor-pointer"
              title="LinkedIn Profile"
            >
              <Linkedin className="w-4 h-4" />
            </a>

            {/* Email Contact Button */}
            <button
              onClick={onOpenContact}
              className="w-8 h-8 rounded-full bg-[#202630] hover:bg-[#2B3442] hover:text-[#C59B5F] flex items-center justify-center transition-all cursor-pointer"
              title="Institutional Contact"
            >
              <Mail className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Lower Row: Copyright & Regulatory Notice */}
        <div className="pt-5 flex flex-col sm:flex-row items-center justify-between text-[11px] text-gray-500 gap-3">
          <p className="max-w-2xl text-center sm:text-left leading-relaxed">
            {t.disclaimer}
          </p>

          <div className="flex items-center gap-4 text-gray-400">
            <span>{t.copyright}</span>
            <span className="hidden sm:inline">|</span>
            <span>{t.icp}</span>
          </div>
        </div>
      </div>

      {/* WeChat QR Code Popup Modal */}
      {showWechatModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-sm w-full text-center relative animate-in fade-in zoom-in-95">
            <button
              onClick={() => setShowWechatModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1 rounded-full cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-12 h-12 rounded-full bg-[#F6F0E5] text-[#B89358] mx-auto flex items-center justify-center mb-3">
              <MessageCircle className="w-6 h-6" />
            </div>

            <h4 className="text-base font-bold text-gray-900 mb-1">
              {t.wechatTitle}
            </h4>
            <p className="text-xs text-gray-500 mb-4 px-2">
              {t.wechatSub}
            </p>

            {/* Stylized QR Code Graphic */}
            <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg inline-block mx-auto mb-4">
              <svg className="w-36 h-36" viewBox="0 0 100 100" fill="none">
                {/* QR Finder Corners */}
                <rect x="5" y="5" width="28" height="28" rx="4" fill="#1F2937" />
                <rect x="9" y="9" width="20" height="20" rx="2" fill="white" />
                <rect x="13" y="13" width="12" height="12" rx="1" fill="#B89358" />

                <rect x="67" y="5" width="28" height="28" rx="4" fill="#1F2937" />
                <rect x="71" y="9" width="20" height="20" rx="2" fill="white" />
                <rect x="75" y="13" width="12" height="12" rx="1" fill="#B89358" />

                <rect x="5" y="67" width="28" height="28" rx="4" fill="#1F2937" />
                <rect x="9" y="71" width="20" height="20" rx="2" fill="white" />
                <rect x="13" y="75" width="12" height="12" rx="1" fill="#B89358" />

                {/* Data Matrix Dots */}
                <rect x="40" y="8" width="6" height="6" fill="#1F2937" />
                <rect x="52" y="8" width="6" height="6" fill="#1F2937" />
                <rect x="40" y="20" width="6" height="6" fill="#1F2937" />
                <rect x="50" y="22" width="8" height="8" fill="#B89358" />
                <rect x="12" y="42" width="6" height="6" fill="#1F2937" />
                <rect x="24" y="46" width="6" height="6" fill="#1F2937" />
                <rect x="40" y="42" width="18" height="18" rx="3" fill="#1F2937" />
                <circle cx="49" cy="51" r="5" fill="#DFC79E" />
                <rect x="68" y="42" width="8" height="6" fill="#1F2937" />
                <rect x="80" y="48" width="6" height="6" fill="#1F2937" />
                <rect x="42" y="70" width="8" height="6" fill="#1F2937" />
                <rect x="56" y="76" width="8" height="8" fill="#1F2937" />
                <rect x="74" y="70" width="12" height="6" fill="#1F2937" />
                <rect x="78" y="82" width="8" height="8" fill="#B89358" />
              </svg>
            </div>

            <div className="text-[11px] text-gray-400">
              微信公众号 ID: YunfengCapital_Official
            </div>
          </div>
        </div>
      )}
    </footer>
  );
}
