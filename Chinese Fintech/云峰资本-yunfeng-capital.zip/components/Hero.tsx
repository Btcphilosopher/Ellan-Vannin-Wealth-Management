'use client';

import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Language } from '@/types';

interface HeroProps {
  lang: Language;
  onOpenPhilosophy: () => void;
}

export default function Hero({ lang, onOpenPhilosophy }: HeroProps) {
  const content = {
    zh: {
      tag: '专业 · 远见 · 共赢',
      titleLine1: '连接中国与世界',
      titleLine2: '创造长期价值',
      desc: '云峰资本专注于全球资本市场的多元化投资，以深度研究与全球视野，致力于为投资者创造可持续的长期回报。',
      cta: '了解我们的投资理念',
      pillars: ['全球视野', '本土智慧', '长期主义'],
    },
    en: {
      tag: 'EXPERTISE · FORESIGHT · VALUE CREATION',
      titleLine1: 'Connecting China with the World',
      titleLine2: 'Compounding Long-Term Value',
      desc: 'Yunfeng Capital focuses on diversified asset allocation across global capital markets, delivering resilient and sustainable returns through rigorous research and global perspectives.',
      cta: 'Explore Our Investment Philosophy',
      pillars: ['Global Vision', 'Local Wisdom', 'Long-termism'],
    },
    tc: {
      tag: '專業 · 遠見 · 共贏',
      titleLine1: '連接中國與世界',
      titleLine2: '創造長期價值',
      desc: '雲峰資本專注於全球資本市場的多元化投資，以深度研究與全球視野，致力於為投資者創造可持續的長期回報。',
      cta: '了解我們的投資理念',
      pillars: ['全球視野', '本土智慧', '長期主義'],
    },
  }[lang];

  return (
    <section className="relative w-full min-h-[580px] lg:min-h-[640px] xl:min-h-[680px] overflow-hidden bg-[#0F141C] flex items-center">
      {/* Background Photography with Luxury Penthouse Glass Frame */}
      <div className="absolute inset-0 z-0">
        {/* Cinematic Shanghai Lujiazui Skyline at Dusk */}
        <div
          className="absolute inset-0 bg-cover bg-center transition-all duration-700 transform scale-100"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1548013146-72479768bada?q=85&w=2600&auto=format&fit=crop')`,
            backgroundPosition: 'center 42%',
          }}
        />

        {/* Boardroom dark warm ambient tint and reflection gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0C1017]/92 via-[#0F151F]/70 to-[#0F151F]/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0C1017] via-transparent to-[#0C1017]/50" />

        {/* Polished conference table reflection sheen on the lower section */}
        <div className="absolute bottom-0 inset-x-0 h-44 bg-gradient-to-t from-[#090C11] via-[#0E131A]/90 to-transparent pointer-events-none" />

        {/* Architectural floor-to-ceiling glass vertical divider beams (subtle luxury interior detail) */}
        <div className="absolute inset-0 pointer-events-none hidden md:block">
          <div className="h-full w-full max-w-7xl mx-auto grid grid-cols-12">
            <div className="col-span-4 border-r border-black/30 shadow-2xl relative">
              <div className="absolute inset-y-0 right-0 w-[1px] bg-white/10" />
            </div>
            <div className="col-span-4 border-r border-black/30 shadow-2xl relative">
              <div className="absolute inset-y-0 right-0 w-[1px] bg-white/10" />
            </div>
            <div className="col-span-4 relative">
              <div className="absolute inset-y-0 right-0 w-[1px] bg-white/10" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-16 sm:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Hero Text Block */}
          <div className="lg:col-span-8 max-w-2xl text-left">
            {/* Tagline */}
            <div className="inline-flex items-center gap-2 mb-6">
              <span className="text-xs sm:text-sm font-medium tracking-[0.25em] text-[#CBB285] uppercase">
                {content.tag}
              </span>
            </div>

            {/* Huge Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-[56px] font-bold text-white tracking-tight leading-[1.18] mb-6 font-heading-cn drop-shadow-md">
              <span className="block">{content.titleLine1}</span>
              <span className="block mt-1 sm:mt-2 text-[#F5E6CC]">{content.titleLine2}</span>
            </h1>

            {/* Sub-paragraph */}
            <p className="text-sm sm:text-base lg:text-lg text-[#D1D5DB] leading-relaxed mb-8 max-w-xl font-normal drop-shadow-xs">
              {content.desc}
            </p>

            {/* Primary Action Button */}
            <div>
              <button
                onClick={onOpenPhilosophy}
                className="group inline-flex items-center gap-3 px-6 py-3.5 rounded bg-gradient-to-r from-[#C59B5F] to-[#A4793B] hover:from-[#D1A76B] hover:to-[#B38545] text-white text-sm sm:text-base font-medium shadow-lg hover:shadow-[#C59B5F]/20 transition-all duration-300 transform hover:-translate-y-0.5 cursor-pointer active:scale-98"
              >
                <span>{content.cta}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </div>

          {/* Right Subtle Vertical Pillars Overlay */}
          <div className="hidden lg:flex lg:col-span-4 justify-end">
            <div className="relative pl-6 py-2 border-l border-white/20 backdrop-blur-xs bg-black/10 rounded-r-lg p-4">
              <div className="flex flex-col space-y-4 text-right sm:text-left">
                {content.pillars.map((pillar, idx) => (
                  <div key={idx} className="flex items-center gap-3 group">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#C59B5F]" />
                    <span className="text-sm tracking-[0.2em] font-medium text-white/80 group-hover:text-white transition-colors">
                      {pillar}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Subtle Bottom Glow Line */}
      <div className="absolute bottom-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-[#C59B5F]/40 to-transparent z-10" />
    </section>
  );
}
