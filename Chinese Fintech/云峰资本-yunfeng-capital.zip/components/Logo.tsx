'use client';

import React from 'react';

interface LogoProps {
  variant?: 'light' | 'dark';
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export default function Logo({ variant = 'dark', className = '', size = 'md' }: LogoProps) {
  const isDark = variant === 'dark'; // Dark text on light background
  const sizeClasses = {
    sm: { icon: 'w-6 h-6', textCn: 'text-base', textEn: 'text-[9px]' },
    md: { icon: 'w-8 h-8', textCn: 'text-xl', textEn: 'text-[10px]' },
    lg: { icon: 'w-10 h-10', textCn: 'text-2xl', textEn: 'text-xs' },
  }[size];

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Geometric Double Peak Gold Mountain Emblem */}
      <svg
        viewBox="0 0 64 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`${sizeClasses.icon} shrink-0 transition-transform hover:scale-105 duration-300`}
      >
        <defs>
          <linearGradient id="peakGoldGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#DFC79E" />
            <stop offset="50%" stopColor="#C59B5F" />
            <stop offset="100%" stopColor="#926B33" />
          </linearGradient>
          <linearGradient id="peakGoldGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#B88E4E" />
            <stop offset="100%" stopColor="#6C4B18" />
          </linearGradient>
          <linearGradient id="peakGoldGrad3" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F4E6CE" />
            <stop offset="100%" stopColor="#C59B5F" />
          </linearGradient>
        </defs>

        {/* Left lower facet */}
        <polygon points="4,38 18,24 28,38" fill="url(#peakGoldGrad1)" />
        {/* Main central peak facet left */}
        <polygon points="18,24 36,4 36,38 28,38" fill="url(#peakGoldGrad3)" />
        {/* Main central peak facet right */}
        <polygon points="36,4 54,38 36,38" fill="url(#peakGoldGrad2)" />
        {/* Base horizontal grounding line */}
        <polygon points="6,42 60,42 56,44 10,44" fill="url(#peakGoldGrad1)" />
        {/* Stylized ribbon cut accent */}
        <path
          d="M12 36 L24 22 L36 34 L48 20 L58 36"
          stroke="url(#peakGoldGrad1)"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>

      {/* Brand Typography */}
      <div className="flex flex-col tracking-tight">
        <span
          className={`${sizeClasses.textCn} font-bold font-heading-cn leading-tight tracking-[0.18em] ${
            isDark ? 'text-[#1D2024]' : 'text-white'
          }`}
        >
          云峰资本
        </span>
        <span
          className={`${sizeClasses.textEn} tracking-[0.22em] font-medium uppercase leading-tight ${
            isDark ? 'text-[#7D828A]' : 'text-[#A0A6B2]'
          }`}
        >
          YUNFENG CAPITAL
        </span>
      </div>
    </div>
  );
}
