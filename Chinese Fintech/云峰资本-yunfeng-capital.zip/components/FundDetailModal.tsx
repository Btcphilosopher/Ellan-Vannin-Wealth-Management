'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, TrendingUp, Calendar, ShieldAlert, Award, Download, CheckCircle2, ChevronRight } from 'lucide-react';
import { Fund, Language } from '@/types';

interface FundDetailModalProps {
  fund: Fund | null;
  lang: Language;
  onClose: () => void;
  onOpenConsultation: (fundName: string) => void;
}

export default function FundDetailModal({
  fund,
  lang,
  onClose,
  onOpenConsultation,
}: FundDetailModalProps) {
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!fund) return null;

  const name = lang === 'en' ? fund.nameEn : fund.name;
  const desc = lang === 'en' ? fund.descEn : fund.desc;
  const overview = lang === 'en' ? fund.overviewEn : fund.overview;

  const labels = {
    zh: {
      title: '基金详情与业绩报告',
      aum: '基金规模',
      inception: '成立日期',
      nav: '最新单位净值',
      oneYear: '近1年回报',
      sharpe: '夏普比率',
      maxDd: '历史最大回撤',
      benchmark: '业绩基准',
      strategyOverview: '投资策略与方法论',
      performanceTrack: '净值走势与基准对比',
      downloadFactsheet: '下载产品月报 (PDF)',
      requestMeeting: '预约基金经理交流',
      tagsLabel: '核心属性',
    },
    en: {
      title: 'Fund Profile & Performance',
      aum: 'Fund AUM',
      inception: 'Inception Date',
      nav: 'Latest NAV',
      oneYear: '1-Year Return',
      sharpe: 'Sharpe Ratio',
      maxDd: 'Max Drawdown',
      benchmark: 'Benchmark',
      strategyOverview: 'Strategy & Methodology',
      performanceTrack: 'NAV Performance vs. Benchmark',
      downloadFactsheet: 'Download Fact Sheet (PDF)',
      requestMeeting: 'Request Manager Meeting',
      tagsLabel: 'Attributes',
    },
    tc: {
      title: '基金詳情與業績報告',
      aum: '基金規模',
      inception: '成立日期',
      nav: '最新單位淨值',
      oneYear: '近1年回報',
      sharpe: '夏普比率',
      maxDd: '歷史最大回撤',
      benchmark: '業績基準',
      strategyOverview: '投資策略與方法論',
      performanceTrack: '淨值走勢與基準對比',
      downloadFactsheet: '下載產品月報 (PDF)',
      requestMeeting: '預約基金經理交流',
      tagsLabel: '核心屬性',
    },
  }[lang];

  const handleDownload = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden relative animate-in fade-in zoom-in-95 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#B89358]" />
            <h3 className="text-sm font-semibold text-[#8B6E3C] uppercase tracking-wider">
              {labels.title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Top Banner Info */}
          <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-center">
            <div className="relative w-20 h-20 rounded-lg overflow-hidden shrink-0 shadow-xs border border-gray-100">
              <Image
                src={fund.image}
                alt={name}
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 font-heading-cn">
                  {name}
                </h2>
                <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-[#FBF4E8] text-[#9A7437] border border-[#ECD9B8]">
                  {fund.returnRate} {labels.oneYear}
                </span>
              </div>
              <p className="text-sm text-gray-600 mb-2">{desc}</p>
              <div className="flex flex-wrap gap-1.5">
                {fund.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-gray-100 text-gray-700"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-lg bg-[#FAF8F5] border border-[#F0E6D5]">
            <div>
              <span className="text-[11px] text-gray-500 block mb-1">{labels.nav}</span>
              <span className="text-lg font-bold text-gray-900 font-serif-luxury">{fund.nav}</span>
            </div>
            <div>
              <span className="text-[11px] text-gray-500 block mb-1">{labels.aum}</span>
              <span className="text-lg font-bold text-gray-900 font-serif-luxury">{fund.aum}</span>
            </div>
            <div>
              <span className="text-[11px] text-gray-500 block mb-1">{labels.sharpe}</span>
              <span className="text-lg font-bold text-[#8A6F3E] font-serif-luxury">{fund.sharpeRatio}</span>
            </div>
            <div>
              <span className="text-[11px] text-gray-500 block mb-1">{labels.maxDd}</span>
              <span className="text-lg font-bold text-gray-700 font-serif-luxury">{fund.maxDrawdown}</span>
            </div>
          </div>

          {/* Performance Chart Simulation */}
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-bold text-gray-900 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-[#B89358]" />
                <span>{labels.performanceTrack}</span>
              </h4>
              <div className="flex items-center gap-4 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-1 bg-[#B89358] rounded-full" />
                  <span className="text-gray-700 font-medium">{name}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-1 bg-gray-400 rounded-full" />
                  <span className="text-gray-500 font-medium">{fund.benchmark.split(' ')[0]}</span>
                </div>
              </div>
            </div>

            {/* SVG Interactive Line Chart */}
            <div className="h-44 w-full relative">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 500 150">
                <defs>
                  <linearGradient id="fundGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#C59B5F" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="#C59B5F" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Grid horizontal lines */}
                <line x1="0" y1="30" x2="500" y2="30" stroke="#F1F3F5" strokeDasharray="3 3" />
                <line x1="0" y1="70" x2="500" y2="70" stroke="#F1F3F5" strokeDasharray="3 3" />
                <line x1="0" y1="110" x2="500" y2="110" stroke="#F1F3F5" strokeDasharray="3 3" />

                {/* Benchmark line (grey) */}
                <path
                  d="M 20,120 L 110,115 L 200,110 L 290,105 L 380,100 L 480,95"
                  fill="none"
                  stroke="#9CA3AF"
                  strokeWidth="2"
                  strokeDasharray="4 4"
                />

                {/* Fund area gradient */}
                <path
                  d="M 20,120 L 110,105 L 200,85 L 290,65 L 380,50 L 480,35 L 480,140 L 20,140 Z"
                  fill="url(#fundGradient)"
                />

                {/* Fund performance line (gold) */}
                <path
                  d="M 20,120 L 110,105 L 200,85 L 290,65 L 380,50 L 480,35"
                  fill="none"
                  stroke="#B89358"
                  strokeWidth="3"
                  strokeLinecap="round"
                />

                {/* Data Points */}
                {[
                  { x: 20, y: 120, label: 'Q1' },
                  { x: 110, y: 105, label: 'Q2' },
                  { x: 200, y: 85, label: 'Q3' },
                  { x: 290, y: 65, label: 'Q4' },
                  { x: 380, y: 50, label: '25-Q1' },
                  { x: 480, y: 35, label: '25-Q2' },
                ].map((pt, i) => (
                  <g key={i}>
                    <circle cx={pt.x} cy={pt.y} r="4" fill="#B89358" stroke="white" strokeWidth="2" />
                    <text x={pt.x} y="145" fontSize="10" fill="#9CA3AF" textAnchor="middle">
                      {pt.label}
                    </text>
                  </g>
                ))}
              </svg>
            </div>
            <div className="text-[11px] text-gray-400 text-right mt-1">
              基准: {fund.benchmark}
            </div>
          </div>

          {/* Strategy Overview */}
          <div>
            <h4 className="text-sm font-bold text-gray-900 mb-2">
              {labels.strategyOverview}
            </h4>
            <p className="text-xs sm:text-sm text-gray-600 leading-relaxed bg-gray-50 p-4 rounded-lg border border-gray-100">
              {overview}
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-[#FAF9F6] border-t border-gray-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={handleDownload}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded border border-gray-300 text-xs font-medium text-gray-700 hover:bg-gray-100 transition-colors cursor-pointer"
          >
            {downloadSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700">已成功生成简报</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 text-gray-600" />
                <span>{labels.downloadFactsheet}</span>
              </>
            )}
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenConsultation(name);
            }}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded bg-[#B89358] hover:bg-[#A38048] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <span>{labels.requestMeeting}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
