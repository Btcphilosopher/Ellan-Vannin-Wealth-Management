'use client';

import React from 'react';
import { ArrowRight, TrendingUp, ShieldCheck, Users, Globe2 } from 'lucide-react';
import { Language } from '@/types';

interface MetricsStripProps {
  lang: Language;
  onSelectStrategy: () => void;
}

export default function MetricsStrip({ lang, onSelectStrategy }: MetricsStripProps) {
  const t = {
    zh: {
      aumLabel: '管理资产规模',
      aumValue: '$ 48.7',
      aumUnit: '亿',
      aumDate: '截至 2025 年 6 月 30 日',
      returnLabel: '成立以来年化回报',
      returnValue: '+12.6%',
      returnSub: '(净值)',
      teamLabel: '团队成员',
      teamValue: '68',
      teamSub: '来自全球 12 个国家和地区',
      coverageLabel: '策略覆盖',
      coverageText: '全球宏观 · 股票多空 · 量化 · 另类投资',
      quote: '“我们相信，真正的Alpha来自于对世界的深刻理解。”',
      author: '—— 云峰资本 投资委员会',
    },
    en: {
      aumLabel: 'Assets Under Management',
      aumValue: '$ 4.87',
      aumUnit: 'B',
      aumDate: 'As of June 30, 2025',
      returnLabel: 'Annualized Net Return',
      returnValue: '+12.6%',
      returnSub: '(Since Inception)',
      teamLabel: 'Global Team',
      teamValue: '68',
      teamSub: 'From 12 Countries & Regions',
      coverageLabel: 'Strategy Coverage',
      coverageText: 'Global Macro · L/S Equity · Quant · Alternatives',
      quote: '“We believe true Alpha originates from profound understanding of the world.”',
      author: '— Yunfeng Investment Committee',
    },
    tc: {
      aumLabel: '管理資產規模',
      aumValue: '$ 48.7',
      aumUnit: '億',
      aumDate: '截至 2025 年 6 月 30 日',
      returnLabel: '成立以來年化回報',
      returnValue: '+12.6%',
      returnSub: '(淨值)',
      teamLabel: '團隊成員',
      teamValue: '68',
      teamSub: '來自全球 12 個國家和地區',
      coverageLabel: '策略覆蓋',
      coverageText: '全球宏觀 · 股票多空 · 量化 · 另類投資',
      quote: '“我們相信，真正的Alpha來自於對世界的深刻理解。”',
      author: '—— 雲峰資本 投資委員會',
    },
  }[lang];

  return (
    <section className="w-full bg-white border-b border-[#E5E7EB] shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-0 items-center">
          {/* Stat 1: AUM */}
          <div className="lg:col-span-2 lg:pr-6 lg:border-r border-gray-200">
            <span className="text-xs text-[#6B7280] font-medium block mb-2">{t.aumLabel}</span>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl sm:text-4xl font-bold tracking-tight text-[#111827] font-serif-luxury">
                {t.aumValue}
              </span>
              <span className="text-lg font-medium text-[#4B5563] ml-1">{t.aumUnit}</span>
            </div>
            <span className="text-[11px] text-[#9CA3AF] block mt-1.5">{t.aumDate}</span>
          </div>

          {/* Stat 2: Annualized Return */}
          <div className="lg:col-span-2 lg:px-6 lg:border-r border-gray-200">
            <span className="text-xs text-[#6B7280] font-medium block mb-2">{t.returnLabel}</span>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl sm:text-4xl font-bold tracking-tight text-[#1E293B] font-serif-luxury">
                {t.returnValue}
              </span>
            </div>
            <span className="text-[11px] text-[#9CA3AF] block mt-1.5">{t.returnSub}</span>
          </div>

          {/* Stat 3: Team */}
          <div className="lg:col-span-2 lg:px-6 lg:border-r border-gray-200">
            <span className="text-xs text-[#6B7280] font-medium block mb-2">{t.teamLabel}</span>
            <div className="flex items-baseline gap-1">
              <span className="text-3xl sm:text-4xl font-bold tracking-tight text-[#111827] font-serif-luxury">
                {t.teamValue}
              </span>
            </div>
            <span className="text-[11px] text-[#9CA3AF] block mt-1.5">{t.teamSub}</span>
          </div>

          {/* Stat 4: Strategy Coverage */}
          <div className="lg:col-span-3 lg:px-6 lg:border-r border-gray-200">
            <span className="text-xs text-[#6B7280] font-medium block mb-2">{t.coverageLabel}</span>
            <button
              onClick={onSelectStrategy}
              className="group text-left inline-flex items-center gap-2 cursor-pointer transition-colors"
            >
              <span className="text-sm sm:text-[15px] font-medium text-[#1F2937] group-hover:text-[#B89358] transition-colors leading-snug">
                {t.coverageText}
              </span>
              <ArrowRight className="w-4 h-4 text-[#9CA3AF] group-hover:text-[#B89358] group-hover:translate-x-1 transition-all shrink-0" />
            </button>
          </div>

          {/* Stat 5: Investment Committee Quote */}
          <div className="lg:col-span-3 lg:pl-8">
            <blockquote className="relative">
              <p className="text-sm sm:text-[14.5px] font-serif-luxury text-[#1E293B] italic leading-relaxed">
                {t.quote}
              </p>
              <footer className="mt-2 text-xs text-[#8A714C] font-medium tracking-wide">
                {t.author}
              </footer>
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}
