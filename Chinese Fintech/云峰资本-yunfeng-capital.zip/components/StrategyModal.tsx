'use client';

import React from 'react';
import { X, Layers, Target, ShieldCheck, Cpu, ArrowUpRight } from 'lucide-react';
import { Language } from '@/types';

interface StrategyModalProps {
  lang: Language;
  onClose: () => void;
}

export default function StrategyModal({ lang, onClose }: StrategyModalProps) {
  const t = {
    zh: {
      badge: '投资策略与资产配置',
      title: '立足中国，放眼全球',
      subtitle: '我们构建了贯穿宏观周期、行业中观以及微观个股的三维立体投资研究体系。',
      pillars: [
        {
          title: '自上而下宏观研判',
          desc: '依托专有全球宏观因子库，监控跨国流动性、通胀中枢与地缘政策周期，动态调整各大类资产beta暴露。',
        },
        {
          title: '自下而上基本面选股',
          desc: '以5-10年视角深入产业生态，评估企业自由现金流折现、技术研发壁垒、国际化拓展能力与管理层治理水平。',
        },
        {
          title: '量化模型与尾部风控',
          desc: '自研高频风险归因系统，实时监控行业集中度、多因子暴露偏离度，结合衍生品对冲工具防范流动性冲击。',
        },
      ],
      sectorsTitle: '核心聚焦赛道',
      sectors: [
        '高端装备与先进半导体',
        '新能源储能与绿色电网',
        '人工智能算力与工业Agent',
        '全球化供应链龙头',
        '生物医药与创新医疗器械',
      ],
      closeBtn: '完成',
    },
    en: {
      badge: 'Investment Strategy & Allocation',
      title: 'Rooted in China, Investing Globally',
      subtitle: 'A multi-dimensional asset allocation framework synthesizing top-down macro regimes and bottom-up alpha.',
      pillars: [
        {
          title: 'Top-Down Macro Regimes',
          desc: 'Tracking cross-border liquidity cycles, real rates, and geopolitical dynamics to calibrate high-level asset class exposures.',
        },
        {
          title: 'Bottom-Up Fundamental Selection',
          desc: 'Assessing decade-long enterprise sustainability, durable ROIC, technological moats, and governance excellence.',
        },
        {
          title: 'Quantitative Risk & Tail Protection',
          desc: 'Proprietary factor attribution engines continuously monitoring factor drift and deploying derivative overlays against liquidity shocks.',
        },
      ],
      sectorsTitle: 'High-Conviction Sectors',
      sectors: [
        'Advanced Semiconductor & Precision Hardware',
        'Renewable Grid & Energy Storage',
        'Enterprise AI & Industrial Agents',
        'Global Cross-Border Supply Champions',
        'Biopharma & Innovative Medtech',
      ],
      closeBtn: 'Done',
    },
    tc: {
      badge: '投資策略與資產配置',
      title: '立足中國，放眼全球',
      subtitle: '我們構建了貫穿宏觀週期、行業中觀以及微觀個股的三維立體投資研究體系。',
      pillars: [
        {
          title: '自上而下宏觀研判',
          desc: '依托專有全球宏觀因子庫，監控跨國流動性、通脹中樞與地緣政策週期，動態調整各大類資產beta暴露。',
        },
        {
          title: '自下而上基本面選股',
          desc: '以5-10年視角深入產業生態，評估企業自由現金流折現、技術研發壁壘、國際化拓展能力與管理層治理水平。',
        },
        {
          title: '量化模型與尾部風控',
          desc: '自研高頻風險歸因系統，實時監控行業集中度、多因子暴露偏離度，結合衍生品對沖工具防範流動性衝擊。',
        },
      ],
      sectorsTitle: '核心聚焦賽道',
      sectors: [
        '高端裝備與先進半導體',
        '新能源儲能與綠色電網',
        '人工智能算力與工業Agent',
        '全球化供應鏈龍頭',
        '生物醫藥與創新醫療器械',
      ],
      closeBtn: '完成',
    },
  }[lang];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden relative animate-in fade-in zoom-in-95 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#B89358]" />
            <h3 className="text-xs font-semibold text-[#8B6E3C] uppercase tracking-wider">
              {t.badge}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 font-heading-cn mb-2">
              {t.title}
            </h2>
            <p className="text-xs sm:text-sm text-gray-500 leading-relaxed">
              {t.subtitle}
            </p>
          </div>

          {/* Strategy Pillars */}
          <div className="space-y-3">
            {t.pillars.map((item, idx) => (
              <div
                key={idx}
                className="p-4 rounded-lg bg-[#FAF8F5] border border-[#EFE5D5] flex items-start gap-3.5"
              >
                <div className="w-7 h-7 rounded-full bg-[#B89358] text-white flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                  0{idx + 1}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-gray-900 mb-1">{item.title}</h4>
                  <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Core Focus Sectors */}
          <div>
            <h4 className="text-xs font-bold text-[#8A6F3E] uppercase tracking-wider mb-3">
              {t.sectorsTitle}
            </h4>
            <div className="flex flex-wrap gap-2">
              {t.sectors.map((sector, idx) => (
                <div
                  key={idx}
                  className="px-3 py-2 rounded-lg bg-gray-100 border border-gray-200 text-xs text-gray-800 font-medium flex items-center gap-2"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-[#B89358]" />
                  <span>{sector}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-[#FAF9F6] border-t border-gray-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded bg-gray-900 hover:bg-black text-white text-xs font-medium cursor-pointer"
          >
            {t.closeBtn}
          </button>
        </div>
      </div>
    </div>
  );
}
