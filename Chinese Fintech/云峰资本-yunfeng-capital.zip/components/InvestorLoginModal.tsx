'use client';

import React, { useState } from 'react';
import { X, Lock, ShieldCheck, User, Key, Eye, EyeOff, FileText, Download, CheckCircle2, LogOut, ArrowRight } from 'lucide-react';
import { Language } from '@/types';

interface InvestorLoginModalProps {
  lang: Language;
  onClose: () => void;
}

export default function InvestorLoginModal({ lang, onClose }: InvestorLoginModalProps) {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [twoFactor, setTwoFactor] = useState('');
  const [downloadNotice, setDownloadNotice] = useState<string | null>(null);

  const t = {
    zh: {
      portalTitle: '云峰资本 机构投资者专属门户',
      subTitle: '仅限通过合规KYC准入认定的合格境外机构投资者(QFII/QDII)及高净值家族办公室',
      accountLabel: '机构账户 / 投资者代码',
      passwordLabel: '安全登录密码',
      twoFactorLabel: '动态安全密钥 (Google Authenticator / 硬件Key)',
      rememberMe: '在受信任的机构设备上保持登录',
      loginBtn: '安全登录',
      demoBtn: '一键填入演示机构账户',
      securityNotice: '系统已启用金融级 256 位 TLS 加密与双因素身份校验 (2FA)。',
      // Logged in
      welcome: '欢迎回来，全球主权主权基金客户',
      authTier: '认证券级：LP 机构投资人 (Tier 1)',
      totalCommitment: '认缴出资总额',
      currentNav: '当前组合净值估值',
      unrealizedGain: '累计回报',
      recentDocs: '近期专属受限报告与分红函',
      logout: '退出机构门户',
    },
    en: {
      portalTitle: 'Yunfeng Capital LP Investor Portal',
      subTitle: 'Restricted to accredited institutional partners (QFII/QDII) and global sovereign wealth clients',
      accountLabel: 'Institutional Account ID / LP Email',
      passwordLabel: 'Security Password',
      twoFactorLabel: 'Dynamic 2FA Token (TOTP / Hardware Key)',
      rememberMe: 'Remember this trusted workstation',
      loginBtn: 'Secure Login',
      demoBtn: 'Fill Demo Institutional Credentials',
      securityNotice: 'Protected by bank-grade 256-bit TLS encryption & FIPS-140 hardware 2FA.',
      welcome: 'Welcome, Global Institutional LP Partner',
      authTier: 'Accreditation Tier: Institutional LP (Tier 1)',
      totalCommitment: 'Total Capital Committed',
      currentNav: 'Current Portfolio Valuation',
      unrealizedGain: 'Cumulative Gain',
      recentDocs: 'Restricted Quarterly Reports & Notices',
      logout: 'Sign Out',
    },
    tc: {
      portalTitle: '雲峰資本 機構投資者專屬門戶',
      subTitle: '僅限通過合規KYC准入認定的合格境外機構投資者(QFII/QDII)及高淨值家族辦公室',
      accountLabel: '機構賬戶 / 投資者代碼',
      passwordLabel: '安全登錄密碼',
      twoFactorLabel: '動態安全密鑰 (Google Authenticator / 硬件Key)',
      rememberMe: '在受信任的機構設備上保持登錄',
      loginBtn: '安全登錄',
      demoBtn: '一鍵填入演示機構賬戶',
      securityNotice: '系統已啟用金融級 256 位 TLS 加密與雙因素身份校驗 (2FA)。',
      welcome: '歡迎回來，全球主權基金客戶',
      authTier: '認證券級：LP 機構投資人 (Tier 1)',
      totalCommitment: '認繳出資總額',
      currentNav: '當前組合淨值估值',
      unrealizedGain: '累計回報',
      recentDocs: '近期專屬受限報告與分紅函',
      logout: '退出機構門戶',
    },
  }[lang];

  const handleDemoFill = () => {
    setEmail('lp-partner@institution-fund.com');
    setPassword('YunfengSecure2025!');
    setTwoFactor('892041');
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
  };

  const handleDocDownload = (docName: string) => {
    setDownloadNotice(docName);
    setTimeout(() => setDownloadNotice(null), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-xs p-4 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden relative animate-in fade-in zoom-in-95 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#B89358]" />
            <h3 className="text-xs font-semibold text-[#8B6E3C] uppercase tracking-wider">
              {t.portalTitle}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 overflow-y-auto">
          {!isLoggedIn ? (
            <div>
              <div className="mb-6">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 font-heading-cn mb-1.5">
                  机构投资人安全通道
                </h2>
                <p className="text-xs text-gray-500 leading-relaxed">
                  {t.subTitle}
                </p>
              </div>

              {/* Login Form */}
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    {t.accountLabel}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. institution@sovereign-fund.org"
                      className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-gray-300 rounded focus:ring-1 focus:ring-[#B89358] focus:border-[#B89358] outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    {t.passwordLabel}
                  </label>
                  <div className="relative">
                    <Key className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••••••"
                      className="w-full pl-9 pr-9 py-2 text-xs sm:text-sm border border-gray-300 rounded focus:ring-1 focus:ring-[#B89358] focus:border-[#B89358] outline-hidden"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    {t.twoFactorLabel}
                  </label>
                  <input
                    type="text"
                    value={twoFactor}
                    onChange={(e) => setTwoFactor(e.target.value)}
                    placeholder="6-digit 2FA token"
                    className="w-full px-3 py-2 text-xs sm:text-sm border border-gray-300 rounded focus:ring-1 focus:ring-[#B89358] focus:border-[#B89358] outline-hidden font-mono tracking-wider"
                  />
                </div>

                <div className="flex items-center justify-between text-xs text-gray-500 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded text-[#B89358]" />
                    <span>{t.rememberMe}</span>
                  </label>
                  <span className="text-[#8A6F3E] hover:underline cursor-pointer">忘记凭证 / 重置密钥</span>
                </div>

                <div className="pt-2 space-y-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded bg-gradient-to-r from-[#B89358] to-[#9A7437] hover:from-[#C59B5F] hover:to-[#A77E3F] text-white text-xs sm:text-sm font-semibold shadow-xs transition-colors cursor-pointer"
                  >
                    {t.loginBtn}
                  </button>

                  <button
                    type="button"
                    onClick={handleDemoFill}
                    className="w-full py-2 rounded bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-medium transition-colors cursor-pointer"
                  >
                    {t.demoBtn}
                  </button>
                </div>
              </form>

              {/* Security Banner */}
              <div className="mt-6 flex items-center gap-2.5 p-3 rounded bg-gray-50 border border-gray-200 text-[11px] text-gray-500">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{t.securityNotice}</span>
              </div>
            </div>
          ) : (
            /* Logged-In Institutional Dashboard View */
            <div className="space-y-6 animate-in fade-in">
              <div className="flex items-start justify-between pb-4 border-b border-gray-100">
                <div>
                  <span className="inline-block px-2.5 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 mb-1">
                    {t.authTier}
                  </span>
                  <h3 className="text-xl font-bold text-gray-900 font-heading-cn">
                    {t.welcome}
                  </h3>
                  <p className="text-xs text-gray-500">
                    账户账户代码: YF-LP-202108-CN50 · 最近登录: 2026-11-01
                  </p>
                </div>
                <button
                  onClick={() => setIsLoggedIn(false)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded border border-gray-300 text-xs text-gray-600 hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{t.logout}</span>
                </button>
              </div>

              {/* Portfolio Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-lg bg-[#FAF8F5] border border-[#F0E6D5]">
                  <span className="text-[11px] text-gray-500 block mb-1">{t.totalCommitment}</span>
                  <span className="text-xl font-bold text-gray-900 font-serif-luxury">$ 50,000,000</span>
                  <span className="text-[10px] text-gray-400 block mt-1">认缴到位率 100%</span>
                </div>
                <div className="p-4 rounded-lg bg-[#FAF8F5] border border-[#F0E6D5]">
                  <span className="text-[11px] text-gray-500 block mb-1">{t.currentNav}</span>
                  <span className="text-xl font-bold text-[#8A6F3E] font-serif-luxury">$ 63,480,000</span>
                  <span className="text-[10px] text-emerald-600 block mt-1">+26.96% 累计净收益</span>
                </div>
                <div className="p-4 rounded-lg bg-[#FAF8F5] border border-[#F0E6D5]">
                  <span className="text-[11px] text-gray-500 block mb-1">已分配现金分红 (DPI)</span>
                  <span className="text-xl font-bold text-gray-900 font-serif-luxury">$ 8,240,000</span>
                  <span className="text-[10px] text-gray-400 block mt-1">DPI: 0.16x / TVPI: 1.43x</span>
                </div>
              </div>

              {/* Downloadable Restricted Reports */}
              <div>
                <h4 className="text-xs font-bold text-gray-800 uppercase tracking-wider mb-2.5">
                  {t.recentDocs}
                </h4>

                {downloadNotice && (
                  <div className="mb-2 p-2.5 rounded bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>已成功下载并解密文件：{downloadNotice}</span>
                  </div>
                )}

                <div className="space-y-2">
                  {[
                    {
                      name: '云峰资本 2025 年第三季度主基金投资组合运营报告 (Q3 Financial Report)',
                      date: '2025-10-15',
                      size: '4.8 MB',
                    },
                    {
                      name: '2025 年度中国资产宏观对冲策略复盘与分配计划',
                      date: '2025-09-30',
                      size: '2.4 MB',
                    },
                    {
                      name: '安永（EY）独立会计师事务所 2024 年度年度审计报告全本',
                      date: '2025-04-18',
                      size: '8.1 MB',
                    },
                  ].map((doc, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg border border-gray-200 hover:border-[#D1B588] bg-white flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <FileText className="w-4 h-4 text-[#B89358] shrink-0" />
                        <span className="text-gray-800 font-medium truncate">{doc.name}</span>
                        <span className="text-gray-400 shrink-0">({doc.size})</span>
                      </div>
                      <button
                        onClick={() => handleDocDownload(doc.name)}
                        className="inline-flex items-center gap-1 text-[#8A6F3E] hover:text-[#5E4B28] font-medium shrink-0 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>下载</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
