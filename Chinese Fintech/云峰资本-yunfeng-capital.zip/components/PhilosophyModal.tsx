'use client';

import React from 'react';
import { X, Compass, Shield, Hourglass, Globe2, CheckCircle } from 'lucide-react';
import { PHILOSOPHY_PILLARS } from '@/data/mockData';
import { Language } from '@/types';

interface PhilosophyModalProps {
  lang: Language;
  onClose: () => void;
}

export default function PhilosophyModal({ lang, onClose }: PhilosophyModalProps) {
  const t = {
    zh: {
      badge: '投资理念与方法论',
      title: '穿透周期表象，缔造复利奇迹',
      subtitle: '云峰资本坚守长期主义与价值投资精髓，致力于为全球投资者创造超越周期的稳健回报。',
      quote: '“投资不仅是发现价格与价值的偏差，更是与伟大时代最具活力的商业力量同行。”',
      closeBtn: '关闭',
    },
    en: {
      badge: 'Investment Philosophy',
      title: 'Transcending Market Cycles, Compounding Long-Term Value',
      subtitle: 'Yunfeng Capital adheres to disciplined value investing, partnering with leading enterprises to deliver enduring risk-adjusted returns.',
      quote: '“Investing is not merely exploiting price dislocations—it is walking alongside the most transformative commercial forces of our era.”',
      closeBtn: 'Close',
    },
    tc: {
      badge: '投資理念與方法論',
      title: '穿透週期表象，締造複利奇蹟',
      subtitle: '雲峰資本堅守長期主義與價值投資精髓，致力於為全球投資者創造超越週期的穩健回報。',
      quote: '“投資不僅是發現價格與價值的偏差，更是與偉大時代最具活力的商業力量同行。”',
      closeBtn: '關閉',
    },
  }[lang];

  const icons = [
    <Compass key="1" className="w-5 h-5 text-[#B89358]" />,
    <Shield key="2" className="w-5 h-5 text-[#B89358]" />,
    <Hourglass key="3" className="w-5 h-5 text-[#B89358]" />,
    <Globe2 key="4" className="w-5 h-5 text-[#B89358]" />,
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden relative animate-in fade-in zoom-in-95 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#B89358]" />
            <h3 className="text-xs font-semibold text-[#8B6E3C] uppercase tracking-wider">
              {t.badge}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          <div className="text-center max-w-xl mx-auto mb-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 font-heading-cn mb-2">
              {t.title}
            </h2>
            <p className="text-xs sm:text-sm text-gray-500 leading-relaxed">
              {t.subtitle}
            </p>
          </div>

          {/* 4 Pillars Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {PHILOSOPHY_PILLARS.map((p, idx) => {
              const title = lang === 'en' ? p.titleEn : p.title;
              const sub = lang === 'en' ? p.subtitleEn : p.subtitle;
              const desc = lang === 'en' ? p.descEn : p.desc;

              return (
                <div
                  key={idx}
                  className="p-5 rounded-lg border border-gray-200 hover:border-[#D1B588] bg-[#FCFBF8] hover:bg-white transition-all shadow-2xs hover:shadow-md"
                >
                  <div className="w-10 h-10 rounded-lg bg-[#F5EEDB] flex items-center justify-center mb-3">
                    {icons[idx]}
                  </div>
                  <h3 className="text-base font-bold text-gray-900 mb-1 font-heading-cn">
                    {title}
                  </h3>
                  <div className="text-xs text-[#8A6F3E] font-medium mb-2">
                    {sub}
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    {desc}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Highlight Quote */}
          <div className="p-4 rounded-lg bg-gradient-to-r from-[#F6F1E7] to-[#FAF7F0] border-l-4 border-[#B89358] text-center">
            <p className="text-sm font-serif-luxury text-gray-800 italic">
              {t.quote}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-[#FAF9F6] border-t border-gray-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded bg-gray-900 hover:bg-black text-white text-xs font-medium cursor-pointer"
          >
            {t.closeBtn}
          </button>
        </div>
      </div>
    </div>
  );
}
