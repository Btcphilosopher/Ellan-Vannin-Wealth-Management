'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { Insight, Language } from '@/types';

interface LatestInsightsProps {
  insights: Insight[];
  lang: Language;
  onSelectInsight: (insight: Insight) => void;
  onViewAllInsights: () => void;
}

export default function LatestInsights({
  insights,
  lang,
  onSelectInsight,
  onViewAllInsights,
}: LatestInsightsProps) {
  const headerText = {
    zh: { title: '最新洞察', viewAll: '查看全部' },
    en: { title: 'Latest Insights', viewAll: 'View All' },
    tc: { title: '最新洞察', viewAll: '查看全部' },
  }[lang];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between pb-3.5 mb-4 border-b border-[#E5E7EB]">
        <h3 className="text-lg sm:text-xl font-bold text-[#111827] font-heading-cn">
          {headerText.title}
        </h3>
        <button
          onClick={onViewAllInsights}
          className="group inline-flex items-center gap-1 text-xs sm:text-sm text-[#4B5563] hover:text-[#B89358] transition-colors cursor-pointer"
        >
          <span>{headerText.viewAll}</span>
          <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
        </button>
      </div>

      {/* Insights List */}
      <div className="flex flex-col space-y-3.5 flex-1">
        {insights.map((item) => {
          const title = lang === 'en' ? item.titleEn : item.title;
          const category = lang === 'en' ? item.categoryEn : item.category;

          return (
            <div
              key={item.id}
              onClick={() => onSelectInsight(item)}
              className="group p-2.5 rounded-lg border border-[#EAECEF] hover:border-[#D1B588] bg-white hover:bg-[#FDFBF7] transition-all duration-200 cursor-pointer shadow-2xs hover:shadow-md flex items-center gap-3.5"
            >
              {/* Thumbnail */}
              <div className="relative w-16 h-12 sm:w-20 sm:h-14 rounded overflow-hidden shrink-0 bg-gray-100">
                <Image
                  src={item.image}
                  alt={title}
                  fill
                  sizes="80px"
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
              </div>

              {/* Text Info */}
              <div className="min-w-0 flex-1">
                <h4 className="text-xs sm:text-sm font-semibold text-[#111827] group-hover:text-[#9A7437] transition-colors line-clamp-1 leading-snug">
                  {title}
                </h4>
                <div className="flex items-center gap-2 mt-1.5 text-[11px] text-[#6B7280]">
                  <span className="font-medium text-[#8A714C]">{category}</span>
                  <span className="text-gray-300">|</span>
                  <span>{item.date}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
