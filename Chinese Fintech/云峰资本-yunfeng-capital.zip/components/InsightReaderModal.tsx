'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Calendar, Clock, User, Share2, Bookmark, Check, Printer } from 'lucide-react';
import { Insight, Language } from '@/types';

interface InsightReaderModalProps {
  insight: Insight | null;
  lang: Language;
  onClose: () => void;
}

export default function InsightReaderModal({
  insight,
  lang,
  onClose,
}: InsightReaderModalProps) {
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  if (!insight) return null;

  const title = lang === 'en' ? insight.titleEn : insight.title;
  const category = lang === 'en' ? insight.categoryEn : insight.category;
  const summary = lang === 'en' ? insight.summaryEn : insight.summary;
  const content = lang === 'en' ? insight.contentEn : insight.content;

  const t = {
    zh: {
      tag: '云峰宏观与产业深度研究',
      takeaways: '核心研判要点',
      disclaimer: '免责声明：本研究仅代表云峰资本投研智库团队在报告发布日的观点，不构成直接证券买卖建议。',
      copySuccess: '链接已复制到剪贴板',
      savedSuccess: '已加入研报收藏夹',
      print: '打印研报',
    },
    en: {
      tag: 'Yunfeng Macro & Industry Research',
      takeaways: 'Key Investment Takeaways',
      disclaimer: 'Disclaimer: This report represents internal research perspectives of Yunfeng Capital at date of publication and does not constitute financial advice.',
      copySuccess: 'Link copied to clipboard',
      savedSuccess: 'Saved to reading list',
      print: 'Print Report',
    },
    tc: {
      tag: '雲峰宏觀與產業深度研究',
      takeaways: '核心研判要點',
      disclaimer: '免責聲明：本研究僅代表雲峰資本投研智庫團隊在報告發布日的觀點，不構成直接證券買賣建議。',
      copySuccess: '鏈接已複製到剪貼板',
      savedSuccess: '已加入研報收藏夾',
      print: '列印研報',
    },
  }[lang];

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden relative animate-in fade-in zoom-in-95 my-auto">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-xs font-semibold bg-[#F5EEDB] text-[#9A7437]">
              {category}
            </span>
            <span className="text-xs text-gray-500 font-medium">
              {t.tag}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="text-gray-400 hover:text-gray-700 p-1.5 rounded hover:bg-gray-200 transition-colors cursor-pointer"
              title="Share"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setSaved(!saved)}
              className={`p-1.5 rounded transition-colors cursor-pointer ${
                saved ? 'text-[#B89358]' : 'text-gray-400 hover:text-gray-700 hover:bg-gray-200'
              }`}
              title="Save"
            >
              <Bookmark className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-200 transition-colors cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Article Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          {/* Article Title */}
          <div>
            <h1 className="text-xl sm:text-3xl font-bold text-gray-900 font-heading-cn leading-snug mb-4">
              {title}
            </h1>

            {/* Metadata Bar */}
            <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500 pb-4 border-b border-gray-100">
              <div className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-[#B89358]" />
                <span>{insight.author}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-gray-400" />
                <span>{insight.date}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-gray-400" />
                <span>{insight.readTime}</span>
              </div>
            </div>
          </div>

          {/* Featured Image */}
          <div className="relative w-full h-56 sm:h-72 rounded-lg overflow-hidden shadow-xs">
            <Image
              src={insight.image}
              alt={title}
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
            <div className="absolute bottom-3 left-4 right-4 text-xs text-white/90 font-medium">
              云峰研究数据监测与产业实地走访纪要
            </div>
          </div>

          {/* Executive Summary Box */}
          <div className="p-4 rounded-lg bg-[#FAF7F0] border-l-4 border-[#B89358]">
            <h4 className="text-xs font-bold text-[#8A6F3E] uppercase tracking-wider mb-1.5">
              {t.takeaways}
            </h4>
            <p className="text-sm text-gray-700 leading-relaxed font-serif-luxury">
              {summary}
            </p>
          </div>

          {/* Paragraphs */}
          <div className="space-y-4 text-sm sm:text-base text-gray-700 leading-relaxed font-normal">
            {content.map((p, idx) => (
              <p key={idx} className="indent-6 sm:indent-8">
                {p}
              </p>
            ))}
          </div>

          {/* Tags */}
          <div className="pt-4 border-t border-gray-100 flex flex-wrap items-center gap-2">
            <span className="text-xs text-gray-400 font-medium">相关主题:</span>
            {insight.tags.map((tag, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 rounded text-xs bg-gray-100 text-gray-600 hover:bg-[#F5EEDB] hover:text-[#8A6F3E] transition-colors"
              >
                #{tag}
              </span>
            ))}
          </div>

          {/* Disclaimer */}
          <div className="text-[11px] text-gray-400 bg-gray-50 p-3 rounded">
            {t.disclaimer}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-[#FAF9F6] border-t border-gray-200 flex items-center justify-between">
          <span className="text-xs text-gray-500">
            © 云峰资本研究智库
          </span>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 text-xs text-[#8A6F3E] hover:text-[#5E4B28] font-medium cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{t.print}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
