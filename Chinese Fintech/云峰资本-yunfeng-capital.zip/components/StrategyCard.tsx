'use client';

import React from 'react';
import { ArrowRight, Compass } from 'lucide-react';
import { Language } from '@/types';

interface StrategyCardProps {
  lang: Language;
  onOpenStrategyModal: () => void;
}

export default function StrategyCard({ lang, onOpenStrategyModal }: StrategyCardProps) {
  const t = {
    zh: {
      tag: '投资策略',
      headline: '立足中国，放眼全球',
      desc: '我们采用自上而下与自下而上相结合的投资方法，聚焦具有长期增长潜力的优质资产。',
      cta: '了解更多',
    },
    en: {
      tag: 'INVESTMENT STRATEGY',
      headline: 'Rooted in China, Investing Globally',
      desc: 'Integrating top-down macro discernment with bottom-up fundamental rigor, targeting superior assets with compounding potential.',
      cta: 'Learn More',
    },
    tc: {
      tag: '投資策略',
      headline: '立足中國，放眼全球',
      desc: '我們採用自上而下與自下而上相結合的投資方法，聚焦具有長期增長潛力的優質資產。',
      cta: '了解更多',
    },
  }[lang];

  return (
    <div
      onClick={onOpenStrategyModal}
      className="group relative h-full min-h-[380px] lg:min-h-[460px] rounded-lg overflow-hidden cursor-pointer shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-end p-6 sm:p-8"
    >
      {/* Background Photography: Traditional Chinese eaves framing futuristic Pudong skyline */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1548013146-72479768bada?q=80&w=1200&auto=format&fit=crop')`,
          backgroundPosition: 'left 40%',
        }}
      />

      {/* Dark gradient overlay to match image contrast */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F15] via-[#0F141E]/75 to-[#0F141E]/30 group-hover:via-[#0F141E]/65 transition-all duration-300" />

      {/* Traditional pagoda architectural silhouette overlay for authentic aesthetic */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-radial from-[#C59B5F]/15 to-transparent pointer-events-none" />

      {/* Content overlay */}
      <div className="relative z-10 text-left">
        {/* Tag badge */}
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-black/40 backdrop-blur-xs border border-white/15 text-xs text-[#EAD0A3] font-medium mb-3">
          <Compass className="w-3.5 h-3.5" />
          <span>{t.tag}</span>
        </div>

        {/* Headline */}
        <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold text-white mb-3 font-heading-cn tracking-tight group-hover:text-[#F3E2C3] transition-colors leading-tight">
          {t.headline}
        </h3>

        {/* Paragraph */}
        <p className="text-xs sm:text-sm text-gray-300 leading-relaxed mb-5 max-w-md line-clamp-3">
          {t.desc}
        </p>

        {/* Link Button */}
        <div className="inline-flex items-center gap-2 text-xs sm:text-sm font-medium text-white group-hover:text-[#E2C394] transition-colors">
          <span>{t.cta}</span>
          <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1.5" />
        </div>
      </div>
    </div>
  );
}
