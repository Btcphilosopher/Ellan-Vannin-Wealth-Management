'use client';

import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import MetricsStrip from '@/components/MetricsStrip';
import StrategyCard from '@/components/StrategyCard';
import ProductsAndFunds from '@/components/ProductsAndFunds';
import LatestInsights from '@/components/LatestInsights';
import FundDetailModal from '@/components/FundDetailModal';
import InsightReaderModal from '@/components/InsightReaderModal';
import PhilosophyModal from '@/components/PhilosophyModal';
import StrategyModal from '@/components/StrategyModal';
import InvestorLoginModal from '@/components/InvestorLoginModal';
import ContactModal from '@/components/ContactModal';
import Footer from '@/components/Footer';

import { FUNDS, INSIGHTS } from '@/data/mockData';
import { Fund, Insight, Language } from '@/types';
import { ShieldCheck, Award, Briefcase, Globe, CheckCircle2, ChevronRight, FileCheck, Landmark } from 'lucide-react';

export default function HomePage() {
  const [lang, setLang] = useState<Language>('zh');
  const [currentTab, setCurrentTab] = useState('home');

  // Modal states
  const [selectedFund, setSelectedFund] = useState<Fund | null>(null);
  const [selectedInsight, setSelectedInsight] = useState<Insight | null>(null);
  const [philosophyOpen, setPhilosophyOpen] = useState(false);
  const [strategyOpen, setStrategyOpen] = useState(false);
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [consultationFund, setConsultationFund] = useState('');

  const t = {
    zh: {
      aboutTitle: '关于云峰资本',
      aboutSubtitle: '汇聚全球视野与本土深耕的顶尖资产管理机构',
      aboutText1: '云峰资本成立于全球经济结构转型的历史性时刻，立足中国经济高质量发展脉络，深度参与全球资本市场资源优化配置。我们拥有一支由国际资深基金经理、行业领军产业分析师与资深量化科学家组成的多维投研团队。',
      aboutText2: '十余年来，云峰资本始终秉承客户利益至上原则，累计为全球逾两百家顶级主权财富基金、知名大学捐赠基金、主权养老金及亚洲知名家族办公室创造了超越周期的超额 Alpha 回报。',
      partnersTitle: '全球托管与专业审计合规生态',
      irSectionTitle: '投资者关系与合规治理',
      irSectionSub: '恪守国际最高标准的受托人信义义务（Fiduciary Duty）与全球反洗钱合规框架',
    },
    en: {
      aboutTitle: 'About Yunfeng Capital',
      aboutSubtitle: 'A premier alternative asset management platform bridging global perspective with deep local execution',
      aboutText1: 'Founded at a pivotal juncture in global economic evolution, Yunfeng Capital anchors itself in China’s high-quality economic modernization while orchestrating strategic asset allocations across world capital markets.',
      aboutText2: 'Over the past decade, our partnership has consistently prioritized fiduciary stewardship, generating asymmetric risk-adjusted alpha for over 200 sovereign wealth funds, university endowments, state pension plans, and multi-family offices.',
      partnersTitle: 'Global Custody, Auditing & Governance Partners',
      irSectionTitle: 'Investor Relations & Governance',
      irSectionSub: 'Adhering to the highest global fiduciary duty, SEC/SFC standards, and anti-money laundering frameworks',
    },
    tc: {
      aboutTitle: '關於雲峰資本',
      aboutSubtitle: '匯聚全球視野與本土深耕的頂尖資產管理機構',
      aboutText1: '雲峰資本成立於全球經濟結構轉型的歷史性時刻，立足中國經濟高質量發展脈絡，深度參與全球資本市場資源優化配置。我們擁有一支由國際資深基金經理、行業領軍產業分析師與資深量化科學家組成的多維投研團隊。',
      aboutText2: '十餘年來，雲峰資本始終秉承客戶利益至上原則，累計為全球逾兩百家頂級主權財富基金、知名大學捐贈基金、主權養老金及亞洲知名家族辦公室創造了超越週期的超額 Alpha 回報。',
      partnersTitle: '全球託管與專業審計合規生態',
      irSectionTitle: '投資者關係與合規治理',
      irSectionSub: '恪守國際最高標準的受託人信義義務（Fiduciary Duty）與全球反洗錢合規框架',
    },
  }[lang];

  return (
    <div className="min-h-screen bg-[#FDFDFE] flex flex-col font-sans text-gray-900 selection:bg-[#EBDDC5] selection:text-[#785923]">
      {/* 1. Header Navigation */}
      <Navbar
        currentTab={currentTab}
        onTabChange={(tab) => setCurrentTab(tab)}
        lang={lang}
        onLanguageChange={(newLang) => setLang(newLang)}
        onOpenLoginModal={() => setLoginModalOpen(true)}
      />

      {/* 2. Hero Section */}
      <div id="home">
        <Hero
          lang={lang}
          onOpenPhilosophy={() => setPhilosophyOpen(true)}
        />
      </div>

      {/* 3. Performance & Scale Metrics Strip */}
      <MetricsStrip
        lang={lang}
        onSelectStrategy={() => setStrategyOpen(true)}
      />

      {/* 4. Tri-Panel Main Grid (Exact Recreation of the Mockup Design) */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
          {/* Left Feature Card: 投资策略 (4 cols on lg) */}
          <div className="lg:col-span-4 h-full" id="strategy">
            <StrategyCard
              lang={lang}
              onOpenStrategyModal={() => setStrategyOpen(true)}
            />
          </div>

          {/* Middle Column: 产品与基金 (4 cols on lg) */}
          <div className="lg:col-span-4 h-full" id="funds">
            <ProductsAndFunds
              funds={FUNDS}
              lang={lang}
              onSelectFund={(fund) => setSelectedFund(fund)}
              onViewAllFunds={() => {
                const el = document.getElementById('funds-archive');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />
          </div>

          {/* Right Column: 最新洞察 (4 cols on lg) */}
          <div className="lg:col-span-4 h-full" id="insights">
            <LatestInsights
              insights={INSIGHTS}
              lang={lang}
              onSelectInsight={(insight) => setSelectedInsight(insight)}
              onViewAllInsights={() => {
                const el = document.getElementById('insights-archive');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />
          </div>
        </div>
      </main>

      {/* 5. Institutional Governance, About & Institutional Partners Strip */}
      <section id="about" className="bg-[#FAF8F5] border-t border-b border-[#EAE6DF] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7">
              <span className="text-xs font-semibold text-[#8B6E3C] tracking-widest uppercase block mb-2">
                CORPORATE PROFILE
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 font-heading-cn mb-3">
                {t.aboutTitle}
              </h2>
              <p className="text-sm font-serif-luxury text-[#785F36] italic mb-6">
                {t.aboutSubtitle}
              </p>
              <div className="space-y-4 text-xs sm:text-sm text-gray-600 leading-relaxed font-normal">
                <p>{t.aboutText1}</p>
                <p>{t.aboutText2}</p>
              </div>

              <div className="mt-8 flex flex-wrap gap-4">
                <button
                  onClick={() => setPhilosophyOpen(true)}
                  className="px-5 py-2.5 rounded bg-[#B89358] hover:bg-[#A38048] text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  查看投资理念全景
                </button>
                <button
                  onClick={() => setContactModalOpen(true)}
                  className="px-5 py-2.5 rounded border border-gray-300 hover:border-gray-400 bg-white text-gray-800 text-xs font-medium transition-colors cursor-pointer"
                >
                  机构尽调垂询
                </button>
              </div>
            </div>

            {/* Institutional Credentials Badge Box */}
            <div className="lg:col-span-5">
              <div className="bg-white p-6 sm:p-8 rounded-xl shadow-xs border border-gray-200 space-y-5">
                <h4 className="text-sm font-bold text-gray-900 uppercase tracking-wider pb-3 border-b border-gray-100 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#B89358]" />
                  <span>{t.partnersTitle}</span>
                </h4>

                <div className="space-y-4 text-xs">
                  <div className="flex items-start gap-3">
                    <Landmark className="w-4 h-4 text-[#8B6E3C] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-gray-800 block">全球主托管银行</span>
                      <span className="text-gray-500">香港上海汇丰银行 (HSBC) / 花旗银行 (Citibank)</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <FileCheck className="w-4 h-4 text-[#8B6E3C] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-gray-800 block">独立法定审计机构</span>
                      <span className="text-gray-500">安永会计师事务所 (Ernst & Young) / 普华永道 (PwC)</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Award className="w-4 h-4 text-[#8B6E3C] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-gray-800 block">法律合规顾问</span>
                      <span className="text-gray-500">金杜律师事务所 (King & Wood Mallesons) / 迈普达 (Maples and Calder)</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-[11px] text-gray-400">
                  <span>遵循国际 GIPS 业绩披露准则</span>
                  <span className="text-emerald-700 font-medium">合规认证通过</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Investor Relations Quick Banner */}
      <section id="ir" className="bg-[#191D24] text-white py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <span className="text-xs font-semibold text-[#C59B5F] tracking-widest uppercase block mb-1">
                FIDUCIARY STEWARDSHIP
              </span>
              <h3 className="text-xl sm:text-2xl font-bold font-heading-cn">
                {t.irSectionTitle}
              </h3>
              <p className="text-xs sm:text-sm text-gray-400 mt-1 max-w-xl">
                {t.irSectionSub}
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={() => setLoginModalOpen(true)}
                className="px-5 py-2.5 rounded bg-gradient-to-r from-[#B89358] to-[#9A7437] hover:from-[#C59B5F] hover:to-[#A77E3F] text-white text-xs sm:text-sm font-semibold transition-all cursor-pointer shadow-md"
              >
                机构投资者专属入口
              </button>
              <button
                onClick={() => setContactModalOpen(true)}
                className="px-5 py-2.5 rounded border border-gray-600 hover:border-gray-400 text-gray-200 text-xs sm:text-sm font-medium transition-all cursor-pointer"
              >
                联系投资者关系部
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Footer */}
      <Footer
        lang={lang}
        onTabChange={(tab) => setCurrentTab(tab)}
        onOpenContact={() => setContactModalOpen(true)}
      />

      {/* Modals */}
      {selectedFund && (
        <FundDetailModal
          fund={selectedFund}
          lang={lang}
          onClose={() => setSelectedFund(null)}
          onOpenConsultation={(fundName) => {
            setConsultationFund(fundName);
            setContactModalOpen(true);
          }}
        />
      )}

      {selectedInsight && (
        <InsightReaderModal
          insight={selectedInsight}
          lang={lang}
          onClose={() => setSelectedInsight(null)}
        />
      )}

      {philosophyOpen && (
        <PhilosophyModal
          lang={lang}
          onClose={() => setPhilosophyOpen(false)}
        />
      )}

      {strategyOpen && (
        <StrategyModal
          lang={lang}
          onClose={() => setStrategyOpen(false)}
        />
      )}

      {loginModalOpen && (
        <InvestorLoginModal
          lang={lang}
          onClose={() => setLoginModalOpen(false)}
        />
      )}

      {contactModalOpen && (
        <ContactModal
          lang={lang}
          onClose={() => {
            setContactModalOpen(false);
            setConsultationFund('');
          }}
          initialFund={consultationFund}
        />
      )}
    </div>
  );
}
