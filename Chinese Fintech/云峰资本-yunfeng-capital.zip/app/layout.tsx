import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '云峰资本 YUNFENG CAPITAL - 连接中国与世界，创造长期价值',
  description: '云峰资本官方网站 - 专注于全球资本市场的多元化资产管理与投资策略，以深度研究与全球视野创造可持续的长期回报。',
  openGraph: {
    title: '云峰资本 YUNFENG CAPITAL',
    description: '云峰资本官方网站 - 连接中国与世界，创造长期价值。专注于全球资本市场的多元化资产管理与投资策略。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '云峰资本 YUNFENG CAPITAL',
    description: '云峰资本官方网站 - 连接中国与世界，创造长期价值。',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
