package com.example.tokyoequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.domain.model.PortfolioHolding
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun PortfolioRiskScreen(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    val holdings by viewModel.portfolioHoldings.collectAsState()
    val risk by viewModel.portfolioRisk.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TokyoDarkBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: Portfolio Executive Summary & NAV
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "機関投資家ポートフォリオ (DEMO PORTFOLIO)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TokyoTextPrimary
                        )
                        Surface(shape = RoundedCornerShape(2.dp), color = TokyoBlueDark) {
                            Text(
                                text = "MULTI-ASSET MANDATE",
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text("純資産総額 (NAV)", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
                            Text(
                                "${String.format("%,.0f", risk?.navJpy ?: 250_000_000.0)} JPY",
                                style = MaterialTheme.typography.displayMedium,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("通算トータルリターン", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
                            val ret = risk?.totalReturnPercent ?: 7.85
                            val isPos = ret >= 0
                            Text(
                                "${if (isPos) "+" else ""}${String.format("%.2f", ret)}%",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (isPos) TokyoPositiveGreen else TokyoNegativeRed
                            )
                        }
                    }
                }
            }
        }

        // Section 2: Comprehensive Risk Analytics & VaR
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "リスク分析 & VaR (Value at Risk / Expected Shortfall)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RiskMetricTile("1日VaR (95%信頼区間)", "${String.format("%,.0f", risk?.var95DailyJpy ?: 3_450_000.0)} 円", "日次想定最大損失額", TokyoNegativeRed, Modifier.weight(1f))
                        RiskMetricTile("Expected Shortfall (CVaR)", "${String.format("%,.0f", risk?.expectedShortfallJpy ?: 4_320_000.0)} 円", "裾野リスク期待損失", TokyoNegativeRed, Modifier.weight(1f))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RiskMetricTile("年率ボラティリティ", "${String.format("%.1f", risk?.annualizedVolatility ?: 17.8)}%", "JPXヒストリカル252日", TokyoWarningGold, Modifier.weight(1f))
                        RiskMetricTile("シャープレシオ (Sharpe)", String.format("%.2f", risk?.sharpeRatio ?: 1.42), "無リスク金利: 10Y JGB", TokyoPositiveGreen, Modifier.weight(1f))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RiskMetricTile("TOPIX ベータ (Beta)", String.format("%.2f", risk?.betaToTopix ?: 1.08), "市場感応度", TokyoBlueGlow, Modifier.weight(1f))
                        RiskMetricTile("トラッキングエラー", "${String.format("%.2f", risk?.trackingError ?: 2.4)}%", "ベンチマーク乖離度", TokyoTextSecondary, Modifier.weight(1f))
                    }
                }
            }
        }

        // Section 3: Asset Holdings Breakdown
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "組入銘柄・資産内訳 (Holdings & P&L)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    holdings.forEach { h ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(h.ticker, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TokyoBlueGlow)
                                    Text(h.name, style = MaterialTheme.typography.bodyMedium, color = TokyoTextPrimary)
                                }
                                Text(
                                    "${h.assetClass} | 保有: ${String.format("%,d", h.quantity)}株 | 取得単価: ${String.format("%,.1f", h.averageCost)}円",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TokyoTextMuted
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "${String.format("%,.0f", h.marketValue)} 円 (${h.weightPercent}%)",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoTextPrimary
                                )
                                val isPos = h.unrealizedPnl >= 0
                                Text(
                                    "損益: ${if (isPos) "+" else ""}${String.format("%,.0f", h.unrealizedPnl)} 円 (${if (isPos) "+" else ""}${String.format("%.2f", h.pnlPercent)}%)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPos) TokyoPositiveGreen else TokyoNegativeRed
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RiskMetricTile(label: String, value: String, desc: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = TokyoSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, TokyoGridLine)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, maxLines = 1)
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = color)
            Text(desc, style = MaterialTheme.typography.labelSmall, color = TokyoTextDim, maxLines = 1)
        }
    }
}
