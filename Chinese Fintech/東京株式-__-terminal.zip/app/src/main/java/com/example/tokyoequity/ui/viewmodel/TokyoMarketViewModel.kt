package com.example.tokyoequity.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tokyoequity.data.RfqResult
import com.example.tokyoequity.data.TokyoMarketRepository
import com.example.tokyoequity.domain.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class TerminalWorkspace(val title: String, val code: String) {
    MARKET_CONTROL("市場 CONTROL", "MKT"),
    SECURITY_MASTER("銘柄 MASTER", "SEC"),
    MATCHING_ORDERBOOK("板・注文 ARROWHEAD", "MATCH"),
    INDICES_SECTORS("指数・33業種", "IDX"),
    SUPPLY_MARGIN("需給・信用・RFQ", "MARGIN"),
    DERIVATIVES("デリバティブ (先物/OP)", "DERIV"),
    RESEARCH_MACRO("リサーチ・為替マクロ", "RSCH"),
    PORTFOLIO_RISK("ポートフォリオ・リスク", "RISK"),
    REPLAY_SURVEILLANCE_API("リプレイ・監視・API", "API")
}

class TokyoMarketViewModel(
    private val repository: TokyoMarketRepository = TokyoMarketRepository()
) : ViewModel() {

    private val _currentWorkspace = MutableStateFlow(TerminalWorkspace.MARKET_CONTROL)
    val currentWorkspace: StateFlow<TerminalWorkspace> = _currentWorkspace.asStateFlow()

    val currentPhase: StateFlow<MarketPhase> = repository.currentPhase
    val currentRuleSet: StateFlow<RuleSetVersion> = repository.currentRuleSet
    val securities: StateFlow<List<SecurityMaster>> = repository.securities
    val selectedSecurityTicker: StateFlow<String> = repository.selectedSecurityTicker
    val indices: StateFlow<List<MarketIndex>> = repository.indices
    val sectorPerformances: StateFlow<List<SectorPerformance>> = repository.sectorPerformances
    val fxRates: StateFlow<List<FxRate>> = repository.fxRates
    val futures: StateFlow<List<FuturesContract>> = repository.futures
    val options: StateFlow<List<OptionContract>> = repository.options
    val userOrders: StateFlow<List<Order>> = repository.userOrders
    val recentTrades: StateFlow<List<ExecutionTrade>> = repository.recentTrades
    val portfolioHoldings: StateFlow<List<PortfolioHolding>> = repository.portfolioHoldings
    val portfolioRisk: StateFlow<PortfolioRisk?> = repository.portfolioRisk
    val surveillanceAlerts: StateFlow<List<SurveillanceAlert>> = repository.surveillanceAlerts

    // Order Book of Selected Ticker
    private val _selectedOrderBook = MutableStateFlow<OrderBook?>(null)
    val selectedOrderBook: StateFlow<OrderBook?> = _selectedOrderBook.asStateFlow()

    // Order Entry Form State
    var orderSide = MutableStateFlow(OrderSide.BUY)
    var orderType = MutableStateFlow(OrderType.LIMIT)
    var orderPrice = MutableStateFlow("3012.0")
    var orderQuantity = MutableStateFlow("1000")
    val orderNotification = MutableStateFlow<String?>(null)

    // Replay State
    val isReplaying = MutableStateFlow(false)
    val replayTime = MutableStateFlow("09:15:30 JST")
    val replaySpeed = MutableStateFlow("1x")

    // CLI & API Terminal Sandbox State
    val cliInput = MutableStateFlow("銘柄 7203")
    val cliOutput = MutableStateFlow<List<String>>(
        listOf(
            "東京株式 // TERMINAL CLI [バージョン 4.0.2-RELEASE]",
            "接続先: TSE-ARROWHEAD-DIGITAL-TWIN (SYNTHETIC_CORE)",
            "コマンド例: '市場', '銘柄 7203', '板 7203', '指数 TOPIX', '信用', '為替', 'リスク', 'help'",
            "--------------------------------------------------"
        )
    )

    // RFQ Result
    val latestRfqResult = MutableStateFlow<RfqResult?>(null)

    // Macro Scenario Selected
    val selectedMacroScenario = MutableStateFlow<MacroScenario?>(null)

    // Arrowhead System Metrics
    val arrowheadMsgsPerSec = MutableStateFlow(48500)
    val arrowheadLatencyUs = MutableStateFlow(185) // 0.185 ms
    val arrowheadCpuLoad = MutableStateFlow(24.8)

    init {
        updateSelectedOrderBook()
        startLiveSimulationEngine()
    }

    private fun startLiveSimulationEngine() {
        viewModelScope.launch {
            while (isActive) {
                delay(1200)
                updateSelectedOrderBook()
                
                // Random micro-jitter for telemetry
                arrowheadMsgsPerSec.value = 45000 + Random.nextInt(8000)
                arrowheadLatencyUs.value = 180 + Random.nextInt(15)
                arrowheadCpuLoad.value = 22.0 + (Random.nextDouble() * 5.0)

                // If replaying, advance time
                if (isReplaying.value) {
                    val sec = (System.currentTimeMillis() / 1000) % 60
                    replayTime.value = String.format("09:%02d:%02d JST", (sec / 2) % 60, sec)
                }
            }
        }
    }

    fun selectWorkspace(workspace: TerminalWorkspace) {
        _currentWorkspace.value = workspace
    }

    fun selectSecurity(ticker: String) {
        repository.selectSecurity(ticker)
        val sec = securities.value.find { it.ticker == ticker }
        if (sec != null) {
            orderPrice.value = sec.currentPrice.toString()
        }
        updateSelectedOrderBook()
    }

    fun setMarketPhase(phase: MarketPhase) {
        repository.setMarketPhase(phase)
        updateSelectedOrderBook()
    }

    fun setRuleSet(ruleSet: RuleSetVersion) {
        repository.setRuleSet(ruleSet)
        updateSelectedOrderBook()
    }

    private fun updateSelectedOrderBook() {
        _selectedOrderBook.value = repository.getOrderBook(selectedSecurityTicker.value)
    }

    fun submitOrder() {
        val ticker = selectedSecurityTicker.value
        val side = orderSide.value
        val type = orderType.value
        val price = orderPrice.value.toDoubleOrNull() ?: 0.0
        val qty = orderQuantity.value.toLongOrNull() ?: 100L

        val result = repository.submitOrder(ticker, side, type, price, qty)
        updateSelectedOrderBook()

        if (result.order.status == OrderStatus.REJECTED) {
            orderNotification.value = "⚠️ ${result.order.rejectionReason ?: "注文拒絶"}"
        } else if (result.trades.isNotEmpty()) {
            val totalFilled = result.trades.sumOf { it.quantity }
            val avgPrice = result.trades.map { it.price * it.quantity }.sum() / totalFilled
            orderNotification.value = "✅ 約定成立: ${ticker} ${side.label} ${totalFilled}株 @ ${avgPrice}円 (約定数: ${result.trades.size})"
        } else {
            orderNotification.value = "📥 板受入完了: ${ticker} ${side.label} ${qty}株 @ ${price}円 (状態: ${result.order.status.label})"
        }
    }

    fun cancelOrder(orderId: String) {
        val ok = repository.cancelOrder(orderId, selectedSecurityTicker.value)
        if (ok) {
            orderNotification.value = "🗑️ 注文取消完了: $orderId"
            updateSelectedOrderBook()
        }
    }

    fun executeEtfRfq(etfTicker: String = "1306", quantity: Long = 50000L, side: OrderSide = OrderSide.BUY) {
        val res = repository.simulateEtfRfq(etfTicker, quantity, side)
        latestRfqResult.value = res
    }

    fun runCliCommand(input: String) {
        val trimmed = input.trim()
        val currentLog = cliOutput.value.toMutableList()
        currentLog.add("> $trimmed")

        val parts = trimmed.split("\\s+".toRegex())
        val command = parts.firstOrNull()?.lowercase() ?: ""
        val arg = parts.getOrNull(1)

        when {
            command == "市場" || command == "market" || command == "status" -> {
                currentLog.add("【東京市場ステータス】")
                currentLog.add("  市場フェーズ: ${currentPhase.value.label} (${currentPhase.value.timeRange})")
                currentLog.add("  適用制度: ${currentRuleSet.value.label}")
                currentLog.add("  TOPIX: ${indices.value.find { it.indexId == "TOPIX" }?.value} pt")
                currentLog.add("  日経平均: ${indices.value.find { it.indexId == "N225" }?.value} 円")
                currentLog.add("  Arrowhead処理時間: ${arrowheadLatencyUs.value} μs (スループット: ${arrowheadMsgsPerSec.value} msg/s)")
            }
            command == "銘柄" || command == "sec" || command == "security" -> {
                val targetTicker = arg ?: selectedSecurityTicker.value
                val sec = securities.value.find { it.ticker == targetTicker }
                if (sec != null) {
                    selectSecurity(targetTicker)
                    currentLog.add("【銘柄情報】 ${sec.ticker} ${sec.name} (${sec.englishName})")
                    currentLog.add("  市場区分: ${sec.marketSegment.displayName} | 業種: ${sec.sector33.sectorName}")
                    currentLog.add("  現在値: ${sec.currentPrice} 円 (前日比: ${if (sec.priceChange >= 0) "+" else ""}${sec.priceChange} 円 / ${String.format("%.2f", sec.changePercent)}%)")
                    currentLog.add("  PER: ${sec.per}倍 | PBR: ${sec.pbr}倍 | ROE: ${sec.roe}% | 配当利回り: ${sec.dividendYield}%")
                    currentLog.add("  制限値幅: ${sec.lowerLimit} 〜 ${sec.upperLimit} 円 (基準値: ${sec.referencePrice} 円)")
                } else {
                    currentLog.add("⚠️ 銘柄コード $targetTicker が見つかりません。")
                }
            }
            command == "板" || command == "book" || command == "orderbook" -> {
                val targetTicker = arg ?: selectedSecurityTicker.value
                val book = repository.getOrderBook(targetTicker)
                currentLog.add("【板情報 (FLEX Market-by-Order)】 銘柄: $targetTicker")
                currentLog.add("  OVER ASK QTY: ${book.overAskQuantity}")
                book.asks.reversed().take(5).forEach {
                    currentLog.add(String.format("    売気配: %8.1f 円  数量: %8d 株", it.price, it.quantity))
                }
                currentLog.add("  --------------------------------------")
                book.bids.take(5).forEach {
                    currentLog.add(String.format("    買気配: %8.1f 円  数量: %8d 株", it.price, it.quantity))
                }
                currentLog.add("  UNDER BID QTY: ${book.underBidQuantity}")
            }
            command == "指数" || command == "index" || command == "indices" -> {
                currentLog.add("【日本株主要指数】")
                indices.value.forEach {
                    currentLog.add("  ${it.name.padEnd(16)}: ${String.format("%.2f", it.value)} (${if (it.dayReturnPercent >= 0) "+" else ""}${String.format("%.2f", it.dayReturnPercent)}%)")
                }
            }
            command == "信用" || command == "margin" -> {
                val sec = securities.value.find { it.ticker == selectedSecurityTicker.value }
                if (sec != null) {
                    currentLog.add("【信用需給データ】 ${sec.name} (${sec.ticker})")
                    currentLog.add("  信用買い残: ${sec.marginBuyBalance} 株 | 信用売り残: ${sec.marginSellBalance} 株")
                    currentLog.add("  信用倍率: ${String.format("%.2f", sec.marginRatio)} 倍 | 空売り比率: ${sec.shortInterestRatio}%")
                }
            }
            command == "為替" || command == "fx" -> {
                currentLog.add("【為替レート】")
                fxRates.value.forEach {
                    currentLog.add("  ${it.pair}: ${it.rate} JPY (${if (it.change >= 0) "+" else ""}${it.change})")
                }
            }
            command == "リスク" || command == "risk" -> {
                val risk = portfolioRisk.value
                if (risk != null) {
                    currentLog.add("【ポートフォリオ・リスク分析】")
                    currentLog.add("  NAV: ${String.format("%,.0f", risk.navJpy)} 円")
                    currentLog.add("  1日VaR (95%信頼区間): ${String.format("%,.0f", risk.var95DailyJpy)} 円")
                    currentLog.add("  Expected Shortfall (CVaR): ${String.format("%,.0f", risk.expectedShortfallJpy)} 円")
                    currentLog.add("  Sharpe Ratio: ${String.format("%.2f", risk.sharpeRatio)} | TOPIX Beta: ${String.format("%.2f", risk.betaToTopix)}")
                }
            }
            command == "help" || command == "ヘルプ" || command == "?" -> {
                currentLog.add("【利用可能コマンド一覧】")
                currentLog.add("  市場 (market)       : TSE市場状態・取引フェーズ・主要指数")
                currentLog.add("  銘柄 <コード> (sec) : 銘柄マスター・財務指標・値幅制限")
                currentLog.add("  板 <コード> (book)  : 10本気配値・板情報")
                currentLog.add("  指数 (index)        : TOPIX, 日経225, JPX400等の指数一覧")
                currentLog.add("  信用 (margin)       : 信用買残・売残・信用倍率")
                currentLog.add("  為替 (fx)           : USD/JPY, EUR/JPY等のリアルタイムレート")
                currentLog.add("  リスク (risk)       : 機関投資家ポートフォリオVaR・感応度")
                currentLog.add("  clear              : ターミナルログ消去")
            }
            command == "clear" || command == "cls" -> {
                currentLog.clear()
                currentLog.add("東京株式 // TERMINAL CLI — 画面をクリアしました。")
            }
            else -> {
                currentLog.add("コマンド '${trimmed}' は認識されませんでした。'help' で一覧を表示します。")
            }
        }

        cliOutput.value = currentLog
        cliInput.value = ""
    }
}
