package com.example.tokyoequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.domain.model.*
import com.example.tokyoequity.engine.TickSizeEngine
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun OrderBookMatchingScreen(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    val orderBook by viewModel.selectedOrderBook.collectAsState()
    val securities by viewModel.securities.collectAsState()
    val selectedTicker by viewModel.selectedSecurityTicker.collectAsState()
    val sec = securities.find { it.ticker == selectedTicker } ?: securities.first()

    val side by viewModel.orderSide.collectAsState()
    val orderType by viewModel.orderType.collectAsState()
    val priceText by viewModel.orderPrice.collectAsState()
    val qtyText by viewModel.orderQuantity.collectAsState()
    val notification by viewModel.orderNotification.collectAsState()

    val userOrders by viewModel.userOrders.collectAsState()
    val recentTrades by viewModel.recentTrades.collectAsState()
    val ruleSet by viewModel.currentRuleSet.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TokyoDarkBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Notification banner if any
        if (notification != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = TokyoSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, TokyoBlueGlow)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = notification ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = TokyoTextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.orderNotification.value = null },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "閉じる", tint = TokyoTextMuted, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Section 1: Arrowhead 10-Level Order Book (FLEX Market by Order)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "注文板 (ARROWHEAD 10-Level Depth)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary
                            )
                            Surface(
                                shape = RoundedCornerShape(2.dp),
                                color = TokyoBlueDark
                            ) {
                                Text(
                                    text = "FLEX MBP/MBO",
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White
                                )
                            }
                        }
                        Text(
                            text = "呼値単位: ${TickSizeEngine.getTickSize(sec.currentPrice, sec.isTopix500, ruleSet)} 円",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokyoWarningGold
                        )
                    }

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TokyoSurfaceVariant, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("売数量 (Ask Qty)", style = MaterialTheme.typography.labelSmall, color = TokyoNegativeRed, modifier = Modifier.weight(1f))
                        Text("気配値 (Price)", style = MaterialTheme.typography.labelSmall, color = TokyoTextPrimary, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text("買数量 (Bid Qty)", style = MaterialTheme.typography.labelSmall, color = TokyoPositiveGreen, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }

                    // Over Ask
                    val overQty = orderBook?.overAskQuantity ?: 145000L
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(String.format("%,d (OVER)", overQty), style = MaterialTheme.typography.bodySmall, color = TokyoTextMuted, modifier = Modifier.weight(1f))
                        Text("---", style = MaterialTheme.typography.bodySmall, color = TokyoTextMuted, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text("", modifier = Modifier.weight(1f))
                    }

                    // Asks (reversed from highest down to best ask)
                    val asks = orderBook?.asks?.reversed() ?: emptyList()
                    val maxQty = maxOf(1L, (orderBook?.asks?.maxOfOrNull { it.quantity } ?: 1000L), (orderBook?.bids?.maxOfOrNull { it.quantity } ?: 1000L))

                    asks.forEach { askLevel ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(22.dp)
                                .padding(vertical = 1.dp)
                        ) {
                            // Visual Depth Bar
                            val widthFraction = (askLevel.quantity.toFloat() / maxQty.toFloat()).coerceIn(0.05f, 1f)
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(widthFraction * 0.4f)
                                    .align(Alignment.CenterStart)
                                    .background(TokyoNegativeRed.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = String.format("%,d", askLevel.quantity),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TokyoNegativeRed,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = String.format("%,.1f", askLevel.price),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoNegativeRed,
                                    modifier = Modifier.weight(1f),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Text("", modifier = Modifier.weight(1f))
                            }
                        }
                    }

                    // Spread Divider
                    HorizontalDivider(color = TokyoGridLine, thickness = 1.dp)

                    // Bids
                    val bids = orderBook?.bids ?: emptyList()
                    bids.forEach { bidLevel ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(22.dp)
                                .padding(vertical = 1.dp)
                        ) {
                            // Visual Depth Bar
                            val widthFraction = (bidLevel.quantity.toFloat() / maxQty.toFloat()).coerceIn(0.05f, 1f)
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(widthFraction * 0.4f)
                                    .align(Alignment.CenterEnd)
                                    .background(TokyoPositiveGreen.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("", modifier = Modifier.weight(1f))
                                Text(
                                    text = String.format("%,.1f", bidLevel.price),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoPositiveGreen,
                                    modifier = Modifier.weight(1f),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Text(
                                    text = String.format("%,d", bidLevel.quantity),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TokyoPositiveGreen,
                                    modifier = Modifier.weight(1f),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.End
                                )
                            }
                        }
                    }

                    // Under Bid
                    val underQty = orderBook?.underBidQuantity ?: 182000L
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("", modifier = Modifier.weight(1f))
                        Text("---", style = MaterialTheme.typography.bodySmall, color = TokyoTextMuted, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text(String.format("%,d (UNDER)", underQty), style = MaterialTheme.typography.bodySmall, color = TokyoTextMuted, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }
                }
            }
        }

        // Section 2: Interactive Order Entry Ticket (発注端末)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "発注端末 (Arrowhead Order Entry)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TokyoTextPrimary
                        )
                        Text(
                            text = "対象: ${sec.ticker} ${sec.name}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokyoBlueGlow
                        )
                    }

                    // Buy / Sell Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.orderSide.value = OrderSide.BUY },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (side == OrderSide.BUY) TokyoPositiveGreen else TokyoSurfaceVariant
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_side_buy_button")
                        ) {
                            Text("買付 (BUY)", fontWeight = FontWeight.Bold, color = if (side == OrderSide.BUY) Color.Black else TokyoTextSecondary)
                        }

                        Button(
                            onClick = { viewModel.orderSide.value = OrderSide.SELL },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (side == OrderSide.SELL) TokyoNegativeRed else TokyoSurfaceVariant
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_side_sell_button")
                        ) {
                            Text("売付 (SELL)", fontWeight = FontWeight.Bold, color = if (side == OrderSide.SELL) Color.White else TokyoTextSecondary)
                        }
                    }

                    // Order Type (Limit / Market / Stop)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OrderType.values().forEach { t ->
                            val isSelected = orderType == t
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isSelected) TokyoBlueDark else TokyoSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TokyoBlueGlow else TokyoGridLine),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.orderType.value = t }
                            ) {
                                Box(modifier = Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = t.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) Color.White else TokyoTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // Price and Quantity Fields
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = priceText,
                            onValueChange = { viewModel.orderPrice.value = it },
                            label = { Text("注文価格 (JPY)") },
                            enabled = orderType == OrderType.LIMIT || orderType == OrderType.STOP_LIMIT,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_price_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TokyoBluePrimary,
                                unfocusedBorderColor = TokyoCardBorder
                            ),
                            shape = RoundedCornerShape(4.dp)
                        )

                        OutlinedTextField(
                            value = qtyText,
                            onValueChange = { viewModel.orderQuantity.value = it },
                            label = { Text("注文数量 (株)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("order_quantity_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TokyoBluePrimary,
                                unfocusedBorderColor = TokyoCardBorder
                            ),
                            shape = RoundedCornerShape(4.dp)
                        )
                    }

                    // Submit Order Button
                    Button(
                        onClick = { viewModel.submitOrder() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (side == OrderSide.BUY) TokyoPositiveGreen else TokyoNegativeRed
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("submit_order_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Arrowhead取引所へ発注 (${side.label} ${qtyText}株)",
                            fontWeight = FontWeight.Bold,
                            color = if (side == OrderSide.BUY) Color.Black else Color.White
                        )
                    }
                }
            }
        }

        // Section 3: Active Working Orders
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "受付中注文 (Working Orders)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    if (userOrders.isEmpty()) {
                        Text(
                            text = "現在有効な注文はありません。上の発注端末からシミュレーション注文を投入してください。",
                            style = MaterialTheme.typography.bodySmall,
                            color = TokyoTextMuted,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    } else {
                        userOrders.forEach { ord ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            ord.side.label,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (ord.side == OrderSide.BUY) TokyoPositiveGreen else TokyoNegativeRed
                                        )
                                        Text(ord.securityTicker, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TokyoTextPrimary)
                                        Text(ord.orderType.label, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
                                    }
                                    Text(
                                        "${ord.quantity}株 @ ${ord.price}円 | 約定済: ${ord.filledQuantity}株 (${ord.status.label})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TokyoTextSecondary
                                    )
                                }

                                if (ord.status == OrderStatus.ACCEPTED || ord.status == OrderStatus.PARTIALLY_FILLED) {
                                    Button(
                                        onClick = { viewModel.cancelOrder(ord.orderId) },
                                        colors = ButtonDefaults.buttonColors(containerColor = TokyoCardBackground),
                                        shape = RoundedCornerShape(3.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, TokyoNegativeRed.copy(alpha = 0.5f))
                                    ) {
                                        Text("取消", style = MaterialTheme.typography.labelSmall, color = TokyoNegativeRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 4: Realtime Executed Trades Tape
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "約定履歴 (Execution Tape)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    if (recentTrades.isEmpty()) {
                        Text(
                            text = "ザラ場約定イベント待機中...",
                            style = MaterialTheme.typography.bodySmall,
                            color = TokyoTextMuted
                        )
                    } else {
                        recentTrades.take(8).forEach { trd ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(trd.ticker, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TokyoBlueGlow)
                                    Text(
                                        trd.side.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (trd.side == OrderSide.BUY) TokyoPositiveGreen else TokyoNegativeRed
                                    )
                                    Text("${trd.quantity}株", style = MaterialTheme.typography.bodySmall, color = TokyoTextPrimary)
                                }
                                Text("${String.format("%,.1f", trd.price)} 円", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TokyoTextPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}
