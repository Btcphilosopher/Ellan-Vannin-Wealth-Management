package com.example.tokyoequity.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TokyoColorScheme = darkColorScheme(
    primary = TokyoBluePrimary,
    onPrimary = Color.White,
    primaryContainer = TokyoBlueDark,
    onPrimaryContainer = Color.White,
    secondary = TokyoPositiveGreen,
    onSecondary = Color.Black,
    secondaryContainer = TokyoPositiveGreenBg,
    onSecondaryContainer = TokyoPositiveGreen,
    tertiary = TokyoWarningGold,
    background = TokyoDarkBackground,
    onBackground = TokyoTextPrimary,
    surface = TokyoSurface,
    onSurface = TokyoTextPrimary,
    surfaceVariant = TokyoSurfaceVariant,
    onSurfaceVariant = TokyoTextSecondary,
    outline = TokyoCardBorder,
    outlineVariant = TokyoGridLine,
    error = TokyoNegativeRed,
    onError = Color.White,
    errorContainer = TokyoNegativeRedBg,
    onErrorContainer = TokyoNegativeRed
)

@Composable
fun TokyoEquityTerminalTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TokyoColorScheme,
        typography = Typography,
        content = content
    )
}
