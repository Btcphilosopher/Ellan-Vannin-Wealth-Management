package com.example.tokyoequity.engine

import com.example.tokyoequity.domain.model.RuleSetVersion

/**
 * TSE Tick Size Engine (呼値エンジン)
 * Handles standard TSE tick sizes, TOPIX500 constituent reduced tick sizes,
 * and 2027 STR (Spread-to-Tick Ratio) future rules.
 */
object TickSizeEngine {

    /**
     * Get valid tick size for a given price and rule set
     */
    fun getTickSize(
        price: Double,
        isTopix500: Boolean = true,
        ruleSet: RuleSetVersion = RuleSetVersion.CURRENT_2026
    ): Double {
        if (ruleSet == RuleSetVersion.FUTURE_2027_STR) {
            // 2027 STR Ruleset (Finer granularity based on liquidity brackets)
            return when {
                price <= 1000.0 -> 0.1
                price <= 3000.0 -> 0.5
                price <= 10000.0 -> 1.0
                price <= 30000.0 -> 2.0
                price <= 100000.0 -> 5.0
                else -> 10.0
            }
        }

        // Current TSE Ruleset
        if (isTopix500) {
            // TOPIX500 constituent tick table (小数点呼値適用)
            return when {
                price <= 1000.0 -> 0.1
                price <= 3000.0 -> 0.5
                price <= 10000.0 -> 1.0
                price <= 30000.0 -> 5.0
                price <= 100000.0 -> 10.0
                price <= 300000.0 -> 50.0
                price <= 1000000.0 -> 100.0
                else -> 500.0
            }
        } else {
            // Standard / Growth / Non-TOPIX500 tick table
            return when {
                price <= 3000.0 -> 1.0
                price <= 5000.0 -> 5.0
                price <= 30000.0 -> 10.0
                price <= 50000.0 -> 50.0
                price <= 300000.0 -> 100.0
                price <= 500000.0 -> 500.0
                price <= 3000000.0 -> 1000.0
                else -> 5000.0
            }
        }
    }

    /**
     * Validate if a price adheres to the tick size
     */
    fun isValidTick(
        price: Double,
        isTopix500: Boolean = true,
        ruleSet: RuleSetVersion = RuleSetVersion.CURRENT_2026
    ): Boolean {
        if (price <= 0) return false
        val tick = getTickSize(price, isTopix500, ruleSet)
        val remainder = (price * 10.0) % (tick * 10.0)
        return kotlin.math.abs(remainder) < 0.0001 || kotlin.math.abs(remainder - (tick * 10.0)) < 0.0001
    }

    /**
     * Round price to nearest valid tick
     */
    fun roundToTick(
        price: Double,
        isTopix500: Boolean = true,
        ruleSet: RuleSetVersion = RuleSetVersion.CURRENT_2026
    ): Double {
        val tick = getTickSize(price, isTopix500, ruleSet)
        return (Math.round(price / tick) * tick)
    }
}
