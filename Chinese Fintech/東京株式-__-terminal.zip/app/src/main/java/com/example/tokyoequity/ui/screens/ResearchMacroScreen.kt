package com.example.tokyoequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun ResearchMacroScreen(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    var selectedUsdJpyRate by remember { mutableStateOf(150.0) }
    var selectedBojHike by remember { mutableStateOf(50) } // +50bp

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TokyoDarkBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: 日本株クオンツ・ファクター研究 (Quant Factor Indices)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "日本株ファクター・リサーチ (Factor Strategies)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FactorCard("VALUE 100 (低PBR/低PER)", "+14.8%", "PBR<1倍 資本効率改善銘柄", TokyoPositiveGreen, Modifier.weight(1f))
                        FactorCard("QUALITY 100 (高ROE/ROIC)", "+18.2%", "ROE>12%, ネットキャッシュ", TokyoBlueGlow, Modifier.weight(1f))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FactorCard("DIVIDEND 100 (高配当・増配)", "+12.4%", "配当利回り>3.5%, DOE採用", TokyoWarningGold, Modifier.weight(1f))
                        FactorCard("MOMENTUM 100 (価格モメンタム)", "+21.5%", "過去6ヶ月相対リターン上位", TokyoDerivativesPurple, Modifier.weight(1f))
                    }
                }
            }
        }

        // Section 2: USD/JPY FX Sensitivity Simulator (為替感応度シミュレーター)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "USD/JPY 為替感応度シミュレーター",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TokyoTextPrimary
                        )
                        Text(
                            text = "現在レート: 151.42 JPY",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokyoBlueGlow
                        )
                    }

                    Text(
                        text = "ドル円為替レートの変動による日本企業（輸出セクター・輸入セクター）の営業利益・EPSおよびTOPIXへの波及影響を即時計算します。",
                        style = MaterialTheme.typography.bodySmall,
                        color = TokyoTextMuted
                    )

                    // Rate selection chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(140.0, 145.0, 150.0, 155.0, 160.0).forEach { rate ->
                            val isSelected = selectedUsdJpyRate == rate
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isSelected) TokyoBluePrimary else TokyoSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TokyoBlueGlow else TokyoGridLine),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedUsdJpyRate = rate }
                                    .testTag("fx_rate_select_${rate.toInt()}")
                            ) {
                                Box(modifier = Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        "${rate.toInt()}円",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else TokyoTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // Simulation Impact Results
                    val deltaRate = selectedUsdJpyRate - 150.0
                    val exportEpsImpact = deltaRate * 0.95 // approx +0.95% EPS per +1 JPY
                    val autoImpact = deltaRate * 1.8
                    val electricImpact = deltaRate * 1.2
                    val utilityImpact = -deltaRate * 1.5

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "【USD/JPY = ${selectedUsdJpyRate.toInt()}円 シナリオ試算結果】",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = TokyoTextPrimary
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("主要輸出企業 EPS変化率:", style = MaterialTheme.typography.bodySmall, color = TokyoTextSecondary)
                            Text("${if (exportEpsImpact >= 0) "+" else ""}${String.format("%.2f", exportEpsImpact)}%", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = if (exportEpsImpact >= 0) TokyoPositiveGreen else TokyoNegativeRed)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("輸送用機器 (トヨタ等) 営業益:", style = MaterialTheme.typography.bodySmall, color = TokyoTextSecondary)
                            Text("${if (autoImpact >= 0) "+" else ""}${String.format("%.1f", autoImpact)}% (1円円安で約500億円/社)", style = MaterialTheme.typography.bodySmall, color = if (autoImpact >= 0) TokyoPositiveGreen else TokyoNegativeRed)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("電気・ガス (輸入原材料) 影響:", style = MaterialTheme.typography.bodySmall, color = TokyoTextSecondary)
                            Text("${if (utilityImpact >= 0) "+" else ""}${String.format("%.1f", utilityImpact)}%", style = MaterialTheme.typography.bodySmall, color = if (utilityImpact >= 0) TokyoPositiveGreen else TokyoNegativeRed)
                        }
                    }
                }
            }
        }

        // Section 3: 日銀利上げ・マクロストレステスト (Macro Stress Scenario)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "日銀金融政策 (利上げ) ストレステスト",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(25, 50, 100).forEach { bp ->
                            val isSelected = selectedBojHike == bp
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isSelected) TokyoWarningGold else TokyoSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TokyoWarningGold else TokyoGridLine),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedBojHike = bp }
                            ) {
                                Box(modifier = Modifier.padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        "+${bp}bp (${bp.toDouble()/100}%)",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.Black else TokyoTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    val bankBenefit = selectedBojHike * 0.12
                    val reitPressure = -selectedBojHike * 0.08

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("【政策金利 +${selectedBojHike}bp 引き上げ時のセクター影響】", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TokyoTextPrimary)
                        Text("・ 銀行業 (メガバンク/地銀): 利ざや拡大により純金利収入 +${String.format("%.1f", bankBenefit)}%", style = MaterialTheme.typography.bodySmall, color = TokyoPositiveGreen)
                        Text("・ 東証REIT / 不動産: 借入調達コスト増による分配金圧迫 ${String.format("%.1f", reitPressure)}%", style = MaterialTheme.typography.bodySmall, color = TokyoNegativeRed)
                    }
                }
            }
        }
    }
}

@Composable
private fun FactorCard(title: String, ret: String, desc: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = TokyoSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TokyoTextPrimary)
                Text(ret, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = color)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
        }
    }
}
