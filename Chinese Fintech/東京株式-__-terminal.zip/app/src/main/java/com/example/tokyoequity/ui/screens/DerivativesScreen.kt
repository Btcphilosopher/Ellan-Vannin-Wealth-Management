package com.example.tokyoequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.domain.model.FuturesContract
import com.example.tokyoequity.domain.model.OptionContract
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun DerivativesScreen(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    val futures by viewModel.futures.collectAsState()
    val options by viewModel.options.collectAsState()

    var selectedOptionTab by remember { mutableStateOf("CALL") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TokyoDarkBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: Japanese Index Futures (日経225先物・TOPIX先物)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "日本株先物カーブ (Futures Curve & Basis)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    futures.forEach { fut ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    "${fut.underlying} [${fut.month}]",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoTextPrimary
                                )
                                Text(
                                    "ベーシス(現物乖離): ${if (fut.basis >= 0) "+" else ""}${fut.basis} pt | 取組高: ${String.format("%,d", fut.openInterest)}枚",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TokyoTextMuted
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "${String.format("%,.0f", fut.price)} 円",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoTextPrimary
                                )
                                val change = fut.price - fut.previousClose
                                val isPos = change >= 0
                                Text(
                                    "${if (isPos) "+" else ""}${String.format("%.1f", change)} pt",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPos) TokyoPositiveGreen else TokyoNegativeRed
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Option Chain & Black-Scholes Greeks (オプション・チェーン & グリークス)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "日経225オプション & Black-Scholes Greeks",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TokyoTextPrimary
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(
                                selected = selectedOptionTab == "CALL",
                                onClick = { selectedOptionTab = "CALL" },
                                label = { Text("CALL") }
                            )
                            FilterChip(
                                selected = selectedOptionTab == "PUT",
                                onClick = { selectedOptionTab = "PUT" },
                                label = { Text("PUT") }
                            )
                        }
                    }

                    // Options Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TokyoSurfaceVariant, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("権利行使価格", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(1.2f))
                        Text("現在値", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        Text("IV (%)", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(0.9f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        Text("Delta (Δ)", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(0.9f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        Text("Gamma (Γ)", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(0.9f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        Text("Vega (ν)", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(0.9f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }

                    val filteredOptions = options.filter { it.optionType == selectedOptionTab }
                    filteredOptions.forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "${opt.strikePrice.toInt()} 円",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary,
                                modifier = Modifier.weight(1.2f)
                            )
                            Text(
                                "${String.format("%.1f", opt.price)} 円",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedOptionTab == "CALL") TokyoPositiveGreen else TokyoNegativeRed,
                                modifier = Modifier.weight(1f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                            Text(
                                "${String.format("%.1f", opt.impliedVolatility)}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = TokyoWarningGold,
                                modifier = Modifier.weight(0.9f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                            Text(
                                String.format("%.3f", opt.delta),
                                style = MaterialTheme.typography.labelSmall,
                                color = TokyoTextSecondary,
                                modifier = Modifier.weight(0.9f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                            Text(
                                String.format("%.4f", opt.gamma),
                                style = MaterialTheme.typography.labelSmall,
                                color = TokyoTextSecondary,
                                modifier = Modifier.weight(0.9f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                            Text(
                                String.format("%.2f", opt.vega),
                                style = MaterialTheme.typography.labelSmall,
                                color = TokyoTextSecondary,
                                modifier = Modifier.weight(0.9f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                        }
                    }
                }
            }
        }
    }
}
