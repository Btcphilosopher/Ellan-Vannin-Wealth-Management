package com.example.tokyoequity.engine

/**
 * TSE Price Limit Engine (値幅制限エンジン)
 * Determines the daily upper and lower trading limits (ストップ高・ストップ安)
 * based on standard TSE reference price brackets.
 */
object PriceLimitEngine {

    data class PriceLimitResult(
        val referencePrice: Double,
        val limitRange: Double,
        val upperLimit: Double,
        val lowerLimit: Double
    )

    fun calculateLimits(referencePrice: Double): PriceLimitResult {
        val range = when {
            referencePrice < 100.0 -> 30.0
            referencePrice < 200.0 -> 50.0
            referencePrice < 500.0 -> 80.0
            referencePrice < 700.0 -> 100.0
            referencePrice < 1000.0 -> 150.0
            referencePrice < 1500.0 -> 300.0
            referencePrice < 2000.0 -> 400.0
            referencePrice < 3000.0 -> 500.0
            referencePrice < 5000.0 -> 700.0
            referencePrice < 7000.0 -> 1000.0
            referencePrice < 10000.0 -> 1500.0
            referencePrice < 15000.0 -> 3000.0
            referencePrice < 20000.0 -> 4000.0
            referencePrice < 30000.0 -> 5000.0
            referencePrice < 50000.0 -> 7000.0
            referencePrice < 70000.0 -> 10000.0
            referencePrice < 100000.0 -> 15000.0
            else -> referencePrice * 0.20
        }

        val upper = referencePrice + range
        val lower = maxOf(1.0, referencePrice - range)

        return PriceLimitResult(
            referencePrice = referencePrice,
            limitRange = range,
            upperLimit = upper,
            lowerLimit = lower
        )
    }

    fun isWithinLimits(price: Double, referencePrice: Double): Boolean {
        val limits = calculateLimits(referencePrice)
        return price in limits.lowerLimit..limits.upperLimit
    }
}
