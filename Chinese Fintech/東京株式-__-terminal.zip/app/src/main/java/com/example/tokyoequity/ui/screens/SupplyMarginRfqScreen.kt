package com.example.tokyoequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.domain.model.OrderSide
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun SupplyMarginRfqScreen(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    val securities by viewModel.securities.collectAsState()
    val selectedTicker by viewModel.selectedSecurityTicker.collectAsState()
    val sec = securities.find { it.ticker == selectedTicker } ?: securities.first()
    val rfqResult by viewModel.latestRfqResult.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TokyoDarkBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: Margin Trading & Short Interest (信用需給・貸借取引分析)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "信用需給 & 貸借残高 (${sec.name} / ${sec.ticker})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TokyoTextPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(2.dp),
                            color = TokyoSurfaceVariant
                        ) {
                            Text(
                                text = "東証公表データ週次更新",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = TokyoTextMuted
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MarginStatBadge("信用買い残", "${String.format("%,d", sec.marginBuyBalance)}株", "前週比: +4.2%", TokyoPositiveGreen, Modifier.weight(1f))
                        MarginStatBadge("信用売り残", "${String.format("%,d", sec.marginSellBalance)}株", "前週比: -1.8%", TokyoNegativeRed, Modifier.weight(1f))
                        MarginStatBadge("信用倍率", "${String.format("%.2f", sec.marginRatio)}倍", "適正レンジ (1〜3倍)", TokyoWarningGold, Modifier.weight(1f))
                        MarginStatBadge("空売り比率", "${sec.shortInterestRatio}%", "規制区分: 正常", TokyoBlueGlow, Modifier.weight(1f))
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("品貸料 (逆日歩): 0.00円/日", style = MaterialTheme.typography.labelSmall, color = TokyoTextSecondary)
                        Text("回転日数: 8.4日 (需給良好)", style = MaterialTheme.typography.labelSmall, color = TokyoPositiveGreen)
                        Text("追証ライン想定: 2,410円 (-20%)", style = MaterialTheme.typography.labelSmall, color = TokyoNegativeRed)
                    }
                }
            }
        }

        // Section 2: CONNEQTOR — Institutional ETF RFQ Platform Digital Twin
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Hub, contentDescription = null, tint = TokyoSpecialQuoteCyan, modifier = Modifier.size(18.dp))
                            Text(
                                text = "CONNEQTOR 機関投資家向けETF RFQ プラットフォーム",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary
                            )
                        }
                        Surface(shape = RoundedCornerShape(2.dp), color = TokyoBlueDark) {
                            Text(
                                text = "ETF MARKET MAKER QUOTES",
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }

                    Text(
                        text = "大口ETF取引においてArrowhead板の市場インパクトを回避し、複数指定マーケットメイカーから最良気配（Best Quote）を競争提示させて最良価格で約定執行します。",
                        style = MaterialTheme.typography.bodySmall,
                        color = TokyoTextMuted
                    )

                    Button(
                        onClick = { viewModel.executeEtfRfq("1306", 50000L, OrderSide.BUY) },
                        colors = ButtonDefaults.buttonColors(containerColor = TokyoSpecialQuoteCyan),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().testTag("execute_rfq_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("1306 NF・TOPIX 50,000口のRFQ一括見積・執行シミュレーション", color = Color.Black, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    }

                    if (rfqResult != null) {
                        val res = rfqResult!!
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                                .border(1.dp, TokyoSpecialQuoteCyan.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("RFQ ID: ${res.rfqId}", style = MaterialTheme.typography.labelSmall, color = TokyoSpecialQuoteCyan)
                                Text("最良提示ディーラー: ${res.winnerDealer}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TokyoPositiveGreen)
                            }
                            Text(
                                text = "約定価格: ${res.executedPrice} 円 (スプレッド改善: +${res.priceImprovementVsSpread} 円/口)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary
                            )

                            HorizontalDivider(color = TokyoGridLine, thickness = 1.dp)

                            Text("参加ディーラー提示状況 (Quotes):", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
                            res.dealerQuotes.forEach { q ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(q.dealerName, style = MaterialTheme.typography.bodySmall, color = TokyoTextPrimary)
                                    Text("買: ${q.bidPrice} 円 / 売: ${q.askPrice} 円 (${q.sizeAvailable}口)", style = MaterialTheme.typography.bodySmall, color = TokyoTextSecondary)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 3: ToSTNeT Digital Twin (立会外大口・自社株買い市場)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "ToSTNeT 立会外取引システム (Off-Auction Digital Twin)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    ToStNetItem("ToSTNeT-1 (単一銘柄取引)", "大口バスケット・相対取引 (08:20〜08:45 / 11:30〜12:30 / 15:30〜16:30)")
                    ToStNetItem("ToSTNeT-2 (バスケット取引)", "15銘柄以上・1億円以上のインデックスバスケット約定")
                    ToStNetItem("ToSTNeT-3 (自己株式取得)", "前日終値固定での自社株買い市場買付")
                }
            }
        }
    }
}

@Composable
private fun MarginStatBadge(label: String, value: String, sub: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = TokyoSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, TokyoGridLine)
    ) {
        Column(modifier = Modifier.padding(6.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, maxLines = 1)
            Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = color, maxLines = 1)
            Text(sub, style = MaterialTheme.typography.labelSmall, color = TokyoTextDim, maxLines = 1)
        }
    }
}

@Composable
private fun ToStNetItem(title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = TokyoBlueGlow, modifier = Modifier.size(16.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TokyoTextPrimary)
            Text(desc, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
        }
    }
}
