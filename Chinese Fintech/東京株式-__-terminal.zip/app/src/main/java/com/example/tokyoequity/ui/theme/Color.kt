package com.example.tokyoequity.ui.theme

import androidx.compose.ui.graphics.Color

// Tokyo Financial Terminal Palette (Kabutocho / Marunouchi Dark Architecture)
val TokyoDarkBackground = Color(0xFF090D16)
val TokyoSurface = Color(0xFF111726)
val TokyoSurfaceVariant = Color(0xFF182236)
val TokyoCardBackground = Color(0xFF131C2D)
val TokyoCardBorder = Color(0xFF223048)

val TokyoBluePrimary = Color(0xFF3B82F6)
val TokyoBlueDark = Color(0xFF1D4ED8)
val TokyoBlueGlow = Color(0xFF60A5FA)

val TokyoPositiveGreen = Color(0xFF10B981)
val TokyoPositiveGreenBg = Color(0xFF064E3B)
val TokyoNegativeRed = Color(0xFFEF4444)
val TokyoNegativeRedBg = Color(0xFF7F1D1D)

val TokyoWarningGold = Color(0xFFF59E0B)
val TokyoSpecialQuoteCyan = Color(0xFF06B6D4)
val TokyoDerivativesPurple = Color(0xFFA855F7)

val TokyoTextPrimary = Color(0xFFF8FAFC)
val TokyoTextSecondary = Color(0xFF94A3B8)
val TokyoTextMuted = Color(0xFF64748B)
val TokyoTextDim = Color(0xFF475569)

val TokyoGridLine = Color(0xFF1E293B)
val TokyoDivider = Color(0xFF1E293B)

val BidColor = Color(0xFF10B981)
val AskColor = Color(0xFFEF4444)
