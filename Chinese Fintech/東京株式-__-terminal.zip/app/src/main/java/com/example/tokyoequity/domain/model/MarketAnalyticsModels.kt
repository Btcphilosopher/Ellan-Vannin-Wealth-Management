package com.example.tokyoequity.domain.model

/**
 * Japanese Equity Index Model (TOPIX, Nikkei 225, JPX-Nikkei 400, etc.)
 */
data class MarketIndex(
    val indexId: String,             // e.g. "TOPIX", "N225", "JPXNK400", "CORE30"
    val name: String,
    val value: Double,
    val previousClose: Double,
    val divisor: Double,             // 指数除数
    val constituentCount: Int,
    val methodology: String,         // "浮動株調整時価総額加重", "株価換算加重", etc.
    val provider: String = "JPX / 東証デジタルツイン",
    val dayReturnPercent: Double = if (previousClose > 0) ((value - previousClose) / previousClose) * 100.0 else 0.0,
    val totalReturnIndex: Double = value * 1.342,
    val dividendYield: Double = 2.18
)

/**
 * Constituent Weight & Point Contribution (指数寄与度)
 */
data class IndexConstituent(
    val ticker: String,
    val name: String,
    val weightPercent: Double,
    val pointContribution: Double,
    val priceChange: Double,
    val marketCapTrillion: Double
)

/**
 * 33-Sector Index Summary
 */
data class SectorPerformance(
    val sector: Sector33,
    val changePercent: Double,
    val turnoverBillionJpy: Double,
    val advanceCount: Int,
    val declineCount: Int,
    val leadingTicker: String,
    val per: Double,
    val pbr: Double,
    val dividendYield: Double
)

/**
 * Futures Contract (日経225先物 / TOPIX先物)
 */
data class FuturesContract(
    val contractId: String,
    val underlying: String,
    val month: String,               // e.g. "2026-12 (期近)"
    val price: Double,
    val previousClose: Double,
    val basis: Double,               // 理論価格乖離・現物ベーシス
    val volume: Long,
    val openInterest: Long,          // 取組高
    val impliedFinancingRate: Double // 織り込み調達金利 (%)
)

/**
 * Option Chain & Black-Scholes Greeks
 */
data class OptionContract(
    val optionId: String,
    val underlying: String,
    val optionType: String,          // "CALL" or "PUT"
    val strikePrice: Double,
    val maturityDate: String,
    val timeToMaturityYears: Double,
    val price: Double,
    val impliedVolatility: Double,   // IV (%)
    val delta: Double,               // Δ
    val gamma: Double,               // Γ
    val vega: Double,                // ν
    val theta: Double,               // θ
    val rho: Double,                 // ρ
    val volume: Long,
    val openInterest: Long
)

/**
 * Macro FX Pair (為替)
 */
data class FxRate(
    val pair: String,                // "USD/JPY", "EUR/JPY", "GBP/JPY"
    val rate: Double,
    val change: Double,
    val changePercent: Double,
    val high: Double,
    val low: Double
)

/**
 * Macro Scenario Simulation
 */
data class MacroScenario(
    val scenarioId: String,
    val name: String,
    val description: String,
    val usdjpyShift: Double,         // e.g. -10 JPY, +5 JPY
    val bojRateHikeBp: Int,          // e.g. +50bp
    val topixEstimatedImpact: Double,// e.g. -2.4%
    val sectorWinners: List<String>,
    val sectorLosers: List<String>,
    val exportEpsImpact: Double      // e.g. -5.2%
)

/**
 * Multi-Asset Portfolio Holding
 */
data class PortfolioHolding(
    val securityId: String,
    val ticker: String,
    val name: String,
    val assetClass: String,          // "EQUITY", "ETF", "REIT", "FUTURES"
    val quantity: Long,
    val averageCost: Double,
    val currentPrice: Double,
    val marketValue: Double = quantity * currentPrice,
    val unrealizedPnl: Double = (currentPrice - averageCost) * quantity,
    val pnlPercent: Double = if (averageCost > 0) ((currentPrice - averageCost) / averageCost) * 100.0 else 0.0,
    val weightPercent: Double = 0.0
)

/**
 * Portfolio Risk Metrics
 */
data class PortfolioRisk(
    val navJpy: Double,
    val dailyPnlJpy: Double,
    val totalReturnPercent: Double,
    val annualizedVolatility: Double,
    val sharpeRatio: Double,
    val betaToTopix: Double,
    val var95DailyJpy: Double,       // 95% 1-day Value at Risk (JPY)
    val expectedShortfallJpy: Double,// Expected Shortfall (CVaR)
    val maxDrawdownPercent: Double,
    val trackingError: Double
)

/**
 * Market Surveillance Alert (市場監視アラート)
 */
data class SurveillanceAlert(
    val alertId: String,
    val timestamp: Long,
    val ticker: String,
    val alertType: String,           // "見せ板疑い (SPOOFING)", "気配急変 (FLASH_QUOTE)", "出来高急増 (VOLUME_SPIKE)", "連続約定異常"
    val severity: String,            // "CRITICAL", "WARNING", "INFO"
    val details: String,
    val detectedBy: String = "Arrowhead-SurveillanceEngine-v4"
)

/**
 * Data Provenance & Methodology Audit
 */
data class DataProvenance(
    val source: String = "JPX-ARROWHEAD-DIGITAL-TWIN-v4.0",
    val provider: String = "SYNTHETIC-INSTITUTIONAL-CORE",
    val timestamp: Long = System.currentTimeMillis(),
    val calculationVersion: String = "CORE-2026.10-CALC",
    val checksum: String = "sha256:7f8a9e10bc23df4"
)
