package com.example.tokyoequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.domain.model.SurveillanceAlert
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun ReplaySurveillanceApiScreen(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    val isReplaying by viewModel.isReplaying.collectAsState()
    val replayTime by viewModel.replayTime.collectAsState()
    val replaySpeed by viewModel.replaySpeed.collectAsState()
    val surveillanceAlerts by viewModel.surveillanceAlerts.collectAsState()

    val cliLog by viewModel.cliOutput.collectAsState()
    val cliInput by viewModel.cliInput.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TokyoDarkBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: Market Session Replay & Time Travel Engine (市場リプレイ再生)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.History, contentDescription = null, tint = TokyoWarningGold, modifier = Modifier.size(18.dp))
                            Text(
                                text = "市場リプレイ・イベント再生 (Market Replay Engine)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary
                            )
                        }
                        Text(
                            text = "時刻: $replayTime",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = TokyoWarningGold
                        )
                    }

                    Text(
                        text = "特定取引日（08:00 注文受付〜09:00 寄付〜11:30 前引け〜15:30 大引け）の全注文・約定・板イベントをミリ秒単位で完全再現します。",
                        style = MaterialTheme.typography.bodySmall,
                        color = TokyoTextMuted
                    )

                    // Replay Control Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { viewModel.isReplaying.value = !isReplaying },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isReplaying) TokyoWarningGold else TokyoBluePrimary
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("toggle_replay_button")
                        ) {
                            Icon(
                                imageVector = if (isReplaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (isReplaying) Color.Black else Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isReplaying) "一時停止" else "リプレイ再生開始",
                                fontWeight = FontWeight.Bold,
                                color = if (isReplaying) Color.Black else Color.White
                            )
                        }

                        // Speed toggles
                        listOf("1x", "5x", "20x").forEach { speed ->
                            val isSelected = replaySpeed == speed
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isSelected) TokyoBlueDark else TokyoSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) TokyoBlueGlow else TokyoGridLine),
                                modifier = Modifier.clickable { viewModel.replaySpeed.value = speed }
                            ) {
                                Box(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                                    Text(speed, style = MaterialTheme.typography.labelSmall, color = if (isSelected) Color.White else TokyoTextSecondary)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 2: Market Surveillance Engine Alerts (市場監視・不正検知)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = TokyoNegativeRed, modifier = Modifier.size(18.dp))
                            Text(
                                text = "市場監視・異常検知 (Market Surveillance Engine)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary
                            )
                        }
                        Text(
                            text = "検知: ${surveillanceAlerts.size}件",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokyoNegativeRed
                        )
                    }

                    surveillanceAlerts.forEach { alert ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                                .border(1.dp, TokyoNegativeRed.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${alert.alertType} [銘柄: ${alert.ticker}]",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoNegativeRed
                                )
                                Text(alert.severity, style = MaterialTheme.typography.labelSmall, color = TokyoWarningGold)
                            }
                            Text(alert.details, style = MaterialTheme.typography.labelSmall, color = TokyoTextPrimary)
                            Text("検知エンジン: ${alert.detectedBy}", style = MaterialTheme.typography.labelSmall, color = TokyoTextDim)
                        }
                    }
                }
            }
        }

        // Section 3: Interactive TOKYO MARKET API & CLI Sandbox
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = TokyoSpecialQuoteCyan, modifier = Modifier.size(18.dp))
                            Text(
                                text = "TOKYO MARKET API & 日本語CLI サンドボックス",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary
                            )
                        }
                        Surface(shape = RoundedCornerShape(2.dp), color = TokyoBlueDark) {
                            Text(
                                text = "OpenAPI 3.1 & SDK",
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }

                    // CLI Output Console Box
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFF060910),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            items(cliLog) { line ->
                                Text(
                                    text = line,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (line.startsWith(">")) TokyoBlueGlow else if (line.startsWith("【")) TokyoWarningGold else TokyoTextPrimary
                                )
                            }
                        }
                    }

                    // Quick Command Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("市場", "銘柄 7203", "板 7203", "指数", "信用", "為替", "リスク", "clear").forEach { cmd ->
                            Surface(
                                shape = RoundedCornerShape(3.dp),
                                color = TokyoSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoGridLine),
                                modifier = Modifier.clickable {
                                    viewModel.runCliCommand(cmd)
                                }
                            ) {
                                Text(
                                    text = cmd,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TokyoTextSecondary
                                )
                            }
                        }
                    }

                    // CLI Input Line
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = cliInput,
                            onValueChange = { viewModel.cliInput.value = it },
                            placeholder = { Text("コマンド入力 (例: 銘柄 6758, 板 7203, help)...") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = {
                                if (cliInput.isNotBlank()) {
                                    viewModel.runCliCommand(cliInput)
                                }
                            }),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("cli_input_field"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TokyoSpecialQuoteCyan,
                                unfocusedBorderColor = TokyoCardBorder
                            ),
                            shape = RoundedCornerShape(4.dp)
                        )

                        Button(
                            onClick = {
                                if (cliInput.isNotBlank()) {
                                    viewModel.runCliCommand(cliInput)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TokyoSpecialQuoteCyan),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.testTag("cli_execute_button")
                        ) {
                            Text("実行", fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}
