package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.tokyoequity.ui.TokyoTerminalApp
import com.example.tokyoequity.ui.theme.TokyoEquityTerminalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TokyoEquityTerminalTheme {
                TokyoTerminalApp()
            }
        }
    }
}
