package com.example.tokyoequity.domain.model

import java.util.UUID

/**
 * TSE Market Segments
 */
enum class MarketSegment(val displayName: String, val englishName: String) {
    PRIME("プライム", "Prime"),
    STANDARD("スタンダード", "Standard"),
    GROWTH("グロース", "Growth"),
    ETF("ETF/ETN", "ETF/ETN"),
    REIT("東証REIT", "REIT"),
    CB("転換社債", "CB"),
    INFRA("インフラファンド", "Infrastructure Fund")
}

/**
 * 33 TSE Industry Sectors (東証33業種)
 */
enum class Sector33(val sectorName: String, val sectorCode: String) {
    TRANSPORT_EQUIPMENT("輸送用機器", "SEC_3100"),
    ELECTRIC_APPLIANCES("電気機器", "SEC_3650"),
    INFO_COMMUNICATION("情報・通信業", "SEC_5250"),
    BANKS("銀行業", "SEC_7050"),
    WHOLESALE("卸売業", "SEC_6050"),
    RETAIL("小売業", "SEC_6100"),
    PHARMACEUTICAL("医薬品", "SEC_3250"),
    CHEMICALS("化学", "SEC_3200"),
    MACHINERY("機械", "SEC_3600"),
    SERVICES("サービス業", "SEC_9050"),
    CONSTRUCTION("建設業", "SEC_2050"),
    REAL_ESTATE("不動産業", "SEC_8050"),
    SECURITIES("証券・商品先物", "SEC_7100"),
    INSURANCE("保険業", "SEC_7150"),
    OTHER_FINANCIAL("その他金融業", "SEC_7200"),
    FOODS("食料品", "SEC_3050"),
    LAND_TRANSPORT("陸運業", "SEC_5050"),
    MARINE_TRANSPORT("海運業", "SEC_5150"),
    AIR_TRANSPORT("空運業", "SEC_5200"),
    IRON_STEEL("鉄鋼", "SEC_3450"),
    NONFERROUS_METALS("非鉄金属", "SEC_3500"),
    METAL_PRODUCTS("金属製品", "SEC_3550"),
    PRECISION_INSTRUMENTS("精密機器", "SEC_3750"),
    TEXTILES("繊維製品", "SEC_3100"),
    PULP_PAPER("パルプ・紙", "SEC_3150"),
    PETROLEUM("石油・石炭製品", "SEC_3300"),
    RUBBER("ゴム製品", "SEC_3350"),
    GLASS_CERAMICS("ガラス・土石", "SEC_3400"),
    ELECTRIC_GAS("電気・ガス業", "SEC_4050"),
    WAREHOUSING("倉庫・運輸関連", "SEC_5100"),
    MINING("鉱業", "SEC_1050"),
    FISHERY("水産・農林業", "SEC_0050"),
    OTHER_PRODUCTS("その他製品", "SEC_3800")
}

/**
 * 17 TSE Industry Sectors (東証17業種)
 */
enum class Sector17(val sectorName: String) {
    FOODS("食品"),
    ENERGY_RESOURCES("エネルギー資源"),
    CONSTRUCTION_MATERIALS("建設・資材"),
    RAW_MATERIALS_CHEMICALS("素材・化学"),
    PHARMACEUTICALS("医薬品"),
    AUTOMOBILES_TRANSPORT("自動車・輸送機"),
    STEEL_NONFERROUS("鉄鋼・非鉄"),
    MACHINERY("機械"),
    ELECTRIC_PRECISION("電機・精密"),
    INFO_COMM_SERVICES("情報通信・サービスその他"),
    ELECTRIC_GAS_UTILITIES("電力・ガス"),
    TRANSPORT_LOGISTICS("運輸・物流"),
    TRADING_COMPANIES_WHOLESALE("商社・卸売"),
    RETAIL("小売"),
    BANKS("銀行"),
    FINANCIALS_EX_BANKS("金融（除く銀行）"),
    REAL_ESTATE("不動産")
}

/**
 * Accounting Standards in Japan
 */
enum class AccountingStandard(val code: String, val label: String) {
    JGAAP("J-GAAP", "日本基準"),
    IFRS("IFRS", "国際財務報告基準"),
    US_GAAP("US-GAAP", "米国基準")
}

/**
 * Market Trading Phases
 */
enum class MarketPhase(val label: String, val timeRange: String, val description: String) {
    PRE_OPEN("注文受付 (前場)", "08:00 - 08:50", "注文受付中・板寄せ前気配計算"),
    OPENING_AUCTION("寄付板寄せ", "08:50 - 09:00", "始値決定・成行/指値マッチング"),
    CONTINUOUS_MORNING("前場ザラ場", "09:00 - 11:30", "連続取引（価格優先・時間優先）"),
    LUNCH_BREAK("前引け・昼休み", "11:30 - 12:05", "前場終了・注文受付停止"),
    AFTERNOON_PRE_OPEN("注文受付 (後場)", "12:05 - 12:30", "後場注文受付中"),
    CONTINUOUS_AFTERNOON("後場ザラ場", "12:30 - 15:25", "後場連続取引"),
    CLOSING_AUCTION("引け板寄せ", "15:25 - 15:30", "クロージング・オークション（終値形成）"),
    CLOSED("大引け・集計", "15:30 - 翌08:00", "市場終了・市場データ確定"),
    HALTED("売買停止", "臨時", "サーキットブレーカー / 臨時売買停止")
}

/**
 * TSE Ruleset Versions (Current vs 2027 STR / Random Closing)
 */
enum class RuleSetVersion(val versionId: String, val label: String, val effectiveYear: String) {
    CURRENT_2026("TSE_RULE_2026", "現行制度（呼値テーブル + 5分引けオークション）", "2024-2026"),
    FUTURE_2027_STR("TSE_RULE_2027_STR", "2027新制度（STR呼値 + ランダム・クロージング）", "2027年〜")
}

/**
 * Order Side
 */
enum class OrderSide(val label: String, val english: String) {
    BUY("買", "BUY"),
    SELL("売", "SELL")
}

/**
 * Order Type
 */
enum class OrderType(val label: String, val english: String) {
    LIMIT("指値", "LIMIT"),
    MARKET("成行", "MARKET"),
    STOP_LIMIT("逆指値", "STOP_LIMIT"),
    VWAP_TARGET("VWAP執行", "VWAP")
}

/**
 * Time In Force
 */
enum class TimeInForce(val label: String) {
    FAK("FAK (Fill and Kill)"),
    FAS("FAS (Fill and Store / Day)"),
    FOK("FOK (Fill or Kill)")
}

/**
 * Order Status
 */
enum class OrderStatus(val label: String) {
    NEW("受付中"),
    ACCEPTED("受付済"),
    PARTIALLY_FILLED("部分約定"),
    FILLED("全約定"),
    CANCELLED("取消済"),
    REJECTED("失効/エラー"),
    EXPIRED("期日満了")
}

/**
 * Special Quote (特別気配) Status
 */
enum class SpecialQuoteStatus(val label: String) {
    NORMAL("通常気配"),
    SPECIAL_BID("特別買気配 (特買)"),
    SPECIAL_ASK("特別売気配 (特売)"),
    CONTINUOUS_DISCLOSURE("連続気配表示")
}
