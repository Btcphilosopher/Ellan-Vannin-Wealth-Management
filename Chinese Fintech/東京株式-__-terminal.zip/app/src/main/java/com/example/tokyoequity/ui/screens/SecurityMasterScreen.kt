package com.example.tokyoequity.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.domain.model.SecurityMaster
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TerminalWorkspace
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun SecurityMasterScreen(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    val securities by viewModel.securities.collectAsState()
    val selectedTicker by viewModel.selectedSecurityTicker.collectAsState()
    val sec = securities.find { it.ticker == selectedTicker } ?: securities.first()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TokyoDarkBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Ticker Selector Horizontal Bar
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(securities) { item ->
                    val isSelected = item.ticker == selectedTicker
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (isSelected) TokyoBluePrimary else TokyoSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) TokyoBlueGlow else TokyoCardBorder
                        ),
                        modifier = Modifier
                            .clickable { viewModel.selectSecurity(item.ticker) }
                            .testTag("sec_select_${item.ticker}")
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Text(
                                text = "${item.ticker} ${item.name}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else TokyoTextPrimary
                            )
                            Text(
                                text = "${String.format("%,.1f", item.currentPrice)} 円",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) Color.White.copy(alpha = 0.9f) else TokyoTextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Header Security Overview
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = sec.ticker,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoBlueGlow
                                )
                                Text(
                                    text = sec.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoTextPrimary
                                )
                                Surface(
                                    shape = RoundedCornerShape(3.dp),
                                    color = TokyoSurfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, TokyoGridLine)
                                ) {
                                    Text(
                                        text = sec.marketSegment.displayName,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        color = TokyoTextSecondary
                                    )
                                }
                            }
                            Text(
                                text = "${sec.englishName} | ISIN: ${sec.isin}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TokyoTextMuted
                            )
                            Text(
                                text = "東証33業種: ${sec.sector33.sectorName} | 会計基準: ${sec.accountingStandard.label} (${sec.accountingStandard.code})",
                                style = MaterialTheme.typography.labelSmall,
                                color = TokyoTextSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${String.format("%,.1f", sec.currentPrice)} 円",
                                style = MaterialTheme.typography.displayMedium,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary
                            )
                            val isPos = sec.priceChange >= 0
                            Text(
                                text = "${if (isPos) "+" else ""}${String.format("%.1f", sec.priceChange)} (${if (isPos) "+" else ""}${String.format("%.2f", sec.changePercent)}%)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isPos) TokyoPositiveGreen else TokyoNegativeRed
                            )
                            Text(
                                text = "VWAP: ${sec.vwap} 円 | 出来高: ${String.format("%,d", sec.volume)} 株",
                                style = MaterialTheme.typography.labelSmall,
                                color = TokyoTextMuted
                            )
                        }
                    }

                    // Price Limit & Trading Unit Banner
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "制限値幅: ${sec.lowerLimit.toInt()} 〜 ${sec.upperLimit.toInt()} 円 (基準値: ${sec.referencePrice.toInt()} 円)",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokyoWarningGold
                        )
                        Text(
                            text = "単元株式数: ${sec.tradingUnit}株 | 呼値: 0.1〜1.0円",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokyoTextSecondary
                        )
                    }

                    // Jump to matching button
                    Button(
                        onClick = {
                            viewModel.selectWorkspace(TerminalWorkspace.MATCHING_ORDERBOOK)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TokyoBluePrimary),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().testTag("trade_security_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.TrendingUp, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("この銘柄のArrowhead板・注文マッチングへ", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Intraday Candlestick Chart (Simulated High-Density Canvas)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("分足ローソク足 & 出来高 (09:00〜15:30)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TokyoTextPrimary)
                        Text("高値: ${sec.highPrice} / 安値: ${sec.lowPrice}", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
                    }

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                    ) {
                        val w = size.width
                        val h = size.height
                        val candleCount = 28
                        val candleWidth = (w / candleCount) * 0.65f
                        val gap = w / candleCount

                        val minP = sec.lowPrice - 10.0
                        val maxP = sec.highPrice + 10.0
                        val range = maxOf(1.0, maxP - minP)

                        for (i in 0 until candleCount) {
                            val x = (i * gap) + (gap * 0.2f)
                            val t = i.toFloat() / candleCount
                            val openY = (h * 0.7f) - (kotlin.math.sin(t * 3.14) * (h * 0.4f)).toFloat() + ((i % 4) * 5)
                            val closeY = openY + (if (i % 2 == 0) -12f else 8f)
                            val highY = minOf(openY, closeY) - 10f
                            val lowY = maxOf(openY, closeY) + 10f

                            val isUp = closeY < openY
                            val color = if (isUp) TokyoPositiveGreen else TokyoNegativeRed

                            // Wick
                            drawLine(
                                color = color,
                                start = Offset(x + candleWidth / 2, highY),
                                end = Offset(x + candleWidth / 2, lowY),
                                strokeWidth = 1.5f
                            )

                            // Body
                            drawRect(
                                color = color,
                                topLeft = Offset(x, minOf(openY, closeY)),
                                size = Size(candleWidth, maxOf(2f, kotlin.math.abs(closeY - openY)))
                            )
                        }

                        // VWAP Line
                        drawLine(
                            color = TokyoWarningGold,
                            start = Offset(0f, h * 0.5f),
                            end = Offset(w, h * 0.45f),
                            strokeWidth = 2f
                        )
                    }
                }
            }
        }

        // Financial Fundamentals & Ratios Matrix
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "企業ファンダメンタルズ & 投資指標 (Institutional Metrics)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FundamentalBadge("PER (株価収益率)", "${sec.per} 倍", "同業平均: 13.5倍", Modifier.weight(1f))
                        FundamentalBadge("PBR (純資産倍率)", "${sec.pbr} 倍", "1倍割れ解消進捗", Modifier.weight(1f))
                        FundamentalBadge("ROE (自己資本利益率)", "${sec.roe}%", "伊藤レポート基準 8%超", Modifier.weight(1f))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FundamentalBadge("配当利回り (予想)", "${sec.dividendYield}%", "1株配当: ${sec.dividendPerShare}円", Modifier.weight(1f))
                        FundamentalBadge("配当性向", "${sec.payoutRatio}%", "DOE: 3.8%", Modifier.weight(1f))
                        FundamentalBadge("自己資本比率", "${sec.equityRatio}%", "ネットキャッシュ: ${sec.netCash}億", Modifier.weight(1f))
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FundamentalBadge("時価総額", "${String.format("%,.0f", sec.marketCap)} 億円", "浮動株比率: ${sec.freeFloatRatio * 100}%", Modifier.weight(1f))
                        FundamentalBadge("営業利益率", "${sec.operatingProfitMargin}%", "ROIC: ${sec.roic}%", Modifier.weight(1f))
                        FundamentalBadge("1株EPS / BPS", "EPS: ${sec.eps}円", "BPS: ${sec.bps}円", Modifier.weight(1f))
                    }
                }
            }
        }

        // Corporate Actions Tracker
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "コーポレートアクション & 開示履歴 (Corporate Actions)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    ActionItem("2026-10-01", "自己株式取得", "上限1,000億円 (発行済の2.1%) を市場買付 (ToSTNeT-3併用)")
                    ActionItem("2026-08-05", "決算発表 / 上方修正", "第1四半期決算・通期営業利益予想を+8.5%上方修正")
                    ActionItem("2026-05-10", "増配開示", "年間配当金を前期比+15円増配 (年間85円予定)")
                    ActionItem("2026-03-31", "株式分割", "投資単位引下げを目的とした1株→5株の株式分割を実施済")
                }
            }
        }
    }
}

@Composable
private fun FundamentalBadge(label: String, value: String, sub: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = TokyoSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, TokyoGridLine)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, maxLines = 1)
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TokyoTextPrimary)
            Text(sub, style = MaterialTheme.typography.labelSmall, color = TokyoTextDim, maxLines = 1)
        }
    }
}

@Composable
private fun ActionItem(date: String, category: String, content: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(date, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
        Surface(
            shape = RoundedCornerShape(2.dp),
            color = TokyoBlueDark
        ) {
            Text(category, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp), style = MaterialTheme.typography.labelSmall, color = Color.White)
        }
        Text(content, style = MaterialTheme.typography.bodySmall, color = TokyoTextPrimary, modifier = Modifier.weight(1f))
    }
}
