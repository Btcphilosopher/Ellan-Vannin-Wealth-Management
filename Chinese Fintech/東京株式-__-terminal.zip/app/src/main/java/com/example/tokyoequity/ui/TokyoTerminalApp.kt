package com.example.tokyoequity.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.tokyoequity.ui.components.HeaderTickerBar
import com.example.tokyoequity.ui.components.WorkspaceTabs
import com.example.tokyoequity.ui.screens.*
import com.example.tokyoequity.ui.theme.TokyoDarkBackground
import com.example.tokyoequity.ui.viewmodel.TerminalWorkspace
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun TokyoTerminalApp(
    viewModel: TokyoMarketViewModel = viewModel()
) {
    val currentWorkspace by viewModel.currentWorkspace.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(TokyoDarkBackground),
        topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
                HeaderTickerBar(viewModel = viewModel)
                WorkspaceTabs(
                    currentWorkspace = currentWorkspace,
                    onSelectWorkspace = { viewModel.selectWorkspace(it) }
                )
            }
        },
        bottomBar = {
            // Respect navigation bars
            Spacer(modifier = Modifier.navigationBarsPadding())
        },
        containerColor = TokyoDarkBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentWorkspace) {
                TerminalWorkspace.MARKET_CONTROL -> MarketControlScreen(viewModel = viewModel)
                TerminalWorkspace.SECURITY_MASTER -> SecurityMasterScreen(viewModel = viewModel)
                TerminalWorkspace.MATCHING_ORDERBOOK -> OrderBookMatchingScreen(viewModel = viewModel)
                TerminalWorkspace.INDICES_SECTORS -> IndicesSectorsScreen(viewModel = viewModel)
                TerminalWorkspace.SUPPLY_MARGIN -> SupplyMarginRfqScreen(viewModel = viewModel)
                TerminalWorkspace.DERIVATIVES -> DerivativesScreen(viewModel = viewModel)
                TerminalWorkspace.RESEARCH_MACRO -> ResearchMacroScreen(viewModel = viewModel)
                TerminalWorkspace.PORTFOLIO_RISK -> PortfolioRiskScreen(viewModel = viewModel)
                TerminalWorkspace.REPLAY_SURVEILLANCE_API -> ReplaySurveillanceApiScreen(viewModel = viewModel)
            }
        }
    }
}
