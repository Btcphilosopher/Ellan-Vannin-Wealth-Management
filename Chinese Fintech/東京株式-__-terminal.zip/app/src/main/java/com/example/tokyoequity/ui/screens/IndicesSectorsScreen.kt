package com.example.tokyoequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.domain.model.IndexConstituent
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun IndicesSectorsScreen(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    val indices by viewModel.indices.collectAsState()
    val sectors by viewModel.sectorPerformances.collectAsState()

    val topixConstituents = remember {
        listOf(
            IndexConstituent("7203", "トヨタ自動車", 4.85, +2.15, +27.0, 49.1),
            IndexConstituent("6758", "ソニーグループ", 3.42, +1.84, +270.0, 17.6),
            IndexConstituent("8306", "三菱UFJフィナンシャルG", 2.95, +1.42, +27.0, 21.9),
            IndexConstituent("6861", "キーエンス", 2.45, +0.98, +620.0, 16.6),
            IndexConstituent("8035", "東京エレクトロン", 2.20, -1.15, -550.0, 13.5),
            IndexConstituent("9432", "日本電信電話 (NTT)", 1.95, +0.45, +0.5, 14.3),
            IndexConstituent("9983", "ファーストリテイリング", 1.82, +0.78, +650.0, 15.5),
            IndexConstituent("8058", "三菱商事", 1.74, +0.65, +48.0, 13.8)
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TokyoDarkBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: Major Market Indices (TOPIX Digital Twin & Nikkei Adapter)
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "日本株主要指数 (TOPIX Digital Twin & Nikkei Adapter)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    indices.forEach { idx ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(idx.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TokyoTextPrimary)
                                Text(
                                    "算出方式: ${idx.methodology} | 採用銘柄数: ${idx.constituentCount}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TokyoTextMuted
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "${String.format("%.2f", idx.value)} pt",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoTextPrimary
                                )
                                val isPos = idx.dayReturnPercent >= 0
                                Text(
                                    "${if (isPos) "+" else ""}${String.format("%.2f", idx.dayReturnPercent)}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPos) TokyoPositiveGreen else TokyoNegativeRed
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 2: TOPIX Constituent Weights & Point Contribution
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TOPIX 構成ウェイト & 指数寄与度 (Point Contribution)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TokyoTextPrimary
                        )
                        Text(
                            text = "Σ Weights = 100.0%",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokyoPositiveGreen
                        )
                    }

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TokyoSurfaceVariant, RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("銘柄", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(2f))
                        Text("ウェイト", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        Text("寄与度 (pt)", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        Text("時価総額", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, modifier = Modifier.weight(1.2f), textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }

                    topixConstituents.forEach { c ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(2f)) {
                                Text(c.name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TokyoTextPrimary, maxLines = 1)
                                Text(c.ticker, style = MaterialTheme.typography.labelSmall, color = TokyoBlueGlow)
                            }
                            Text(
                                "${c.weightPercent}%",
                                style = MaterialTheme.typography.bodySmall,
                                color = TokyoTextSecondary,
                                modifier = Modifier.weight(1f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                            val isPos = c.pointContribution >= 0
                            Text(
                                "${if (isPos) "+" else ""}${String.format("%.2f", c.pointContribution)}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isPos) TokyoPositiveGreen else TokyoNegativeRed,
                                modifier = Modifier.weight(1f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                            Text(
                                "${c.marketCapTrillion}兆円",
                                style = MaterialTheme.typography.bodySmall,
                                color = TokyoTextMuted,
                                modifier = Modifier.weight(1.2f),
                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                            )
                        }
                    }
                }
            }
        }

        // Section 3: 33-Sector Rankings & Rotation
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "東証33業種騰落ランキング (Sector Rotation)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    sectors.sortedByDescending { it.changePercent }.forEachIndexed { idx, sec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("#${idx + 1}", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
                                Text(sec.sector.sectorName, style = MaterialTheme.typography.bodyMedium, color = TokyoTextPrimary)
                            }

                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("代金: ${sec.turnoverBillionJpy}億", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
                                val isPos = sec.changePercent >= 0
                                Text(
                                    "${if (isPos) "+" else ""}${String.format("%.2f", sec.changePercent)}%",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPos) TokyoPositiveGreen else TokyoNegativeRed
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
