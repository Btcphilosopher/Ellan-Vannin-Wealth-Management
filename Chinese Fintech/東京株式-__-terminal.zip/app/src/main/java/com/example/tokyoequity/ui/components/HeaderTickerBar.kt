package com.example.tokyoequity.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.domain.model.MarketIndex
import com.example.tokyoequity.domain.model.MarketPhase
import com.example.tokyoequity.domain.model.RuleSetVersion
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TerminalWorkspace
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun HeaderTickerBar(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    val phase by viewModel.currentPhase.collectAsState()
    val ruleSet by viewModel.currentRuleSet.collectAsState()
    val indices by viewModel.indices.collectAsState()
    val fxRates by viewModel.fxRates.collectAsState()
    var showPhaseMenu by remember { mutableStateOf(false) }
    var showRuleMenu by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(TokyoSurface)
            .border(1.dp, TokyoCardBorder)
    ) {
        // Top Branding & Controls Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(TokyoPositiveGreen, RoundedCornerShape(2.dp))
                )
                Text(
                    text = "東京株式 // TERMINAL",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TokyoTextPrimary
                )
                Surface(
                    shape = RoundedCornerShape(3.dp),
                    color = TokyoCardBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
                ) {
                    Text(
                        text = "SYNTHETIC DIGITAL TWIN",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = TokyoSpecialQuoteCyan
                    )
                }
            }

            // Phase and RuleSet Pickers
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                // Phase Dropdown
                Box {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = TokyoSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, TokyoBluePrimary),
                        modifier = Modifier
                            .clickable { showPhaseMenu = true }
                            .testTag("phase_selector_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "市場: ${phase.label}",
                                style = MaterialTheme.typography.labelMedium,
                                color = TokyoTextPrimary
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "市場フェーズ変更",
                                tint = TokyoTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showPhaseMenu,
                        onDismissRequest = { showPhaseMenu = false },
                        modifier = Modifier.background(TokyoSurface)
                    ) {
                        MarketPhase.values().forEach { p ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(p.label, style = MaterialTheme.typography.bodyMedium, color = TokyoTextPrimary)
                                        Text(p.timeRange, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
                                    }
                                },
                                onClick = {
                                    viewModel.setMarketPhase(p)
                                    showPhaseMenu = false
                                }
                            )
                        }
                    }
                }

                // RuleSet Dropdown
                Box {
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = TokyoSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, TokyoWarningGold),
                        modifier = Modifier
                            .clickable { showRuleMenu = true }
                            .testTag("ruleset_selector_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (ruleSet == RuleSetVersion.CURRENT_2026) "制度: 2026現行" else "制度: 2027 STR",
                                style = MaterialTheme.typography.labelMedium,
                                color = TokyoWarningGold
                            )
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "制度切替",
                                tint = TokyoWarningGold,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showRuleMenu,
                        onDismissRequest = { showRuleMenu = false },
                        modifier = Modifier.background(TokyoSurface)
                    ) {
                        RuleSetVersion.values().forEach { r ->
                            DropdownMenuItem(
                                text = {
                                    Text(r.label, style = MaterialTheme.typography.bodyMedium, color = TokyoTextPrimary)
                                },
                                onClick = {
                                    viewModel.setRuleSet(r)
                                    showRuleMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Horizontal Market Ticker Stream
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val topix = indices.find { it.indexId == "TOPIX" }
            val n225 = indices.find { it.indexId == "N225" }
            val usdjpy = fxRates.find { it.pair == "USD/JPY" }

            TickerItem(name = "TOPIX", value = topix?.value?.let { String.format("%.2f", it) } ?: "2,786.42", changePct = topix?.dayReturnPercent ?: 0.66)
            TickerItem(name = "日経平均", value = n225?.value?.let { String.format("%,.0f", it) } ?: "39,420", changePct = n225?.dayReturnPercent ?: 0.69)
            TickerItem(name = "USD/JPY", value = usdjpy?.rate?.toString() ?: "151.42", changePct = usdjpy?.changePercent ?: 0.38)
            TickerItem(name = "新発10年国債利回り", value = "0.985%", changePct = +2.4)
            TickerItem(name = "日経VI (ボラティリティ)", value = "19.82", changePct = -1.2)
            TickerItem(name = "東証プライム売買代金", value = "4.38兆円", changePct = 5.2)
        }
    }
}

@Composable
private fun TickerItem(name: String, value: String, changePct: Double) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(name, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TokyoTextPrimary)
        val isPos = changePct >= 0
        Text(
            text = "${if (isPos) "+" else ""}${String.format("%.2f", changePct)}%",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = if (isPos) TokyoPositiveGreen else TokyoNegativeRed
        )
    }
}

@Composable
fun WorkspaceTabs(
    currentWorkspace: TerminalWorkspace,
    onSelectWorkspace: (TerminalWorkspace) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(TokyoDarkBackground)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        TerminalWorkspace.values().forEach { workspace ->
            val isSelected = currentWorkspace == workspace
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = if (isSelected) TokyoBluePrimary else TokyoSurface,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) TokyoBlueGlow else TokyoCardBorder
                ),
                modifier = Modifier
                    .clickable { onSelectWorkspace(workspace) }
                    .testTag("tab_${workspace.code.lowercase()}")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = workspace.title,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else TokyoTextSecondary
                    )
                }
            }
        }
    }
}
