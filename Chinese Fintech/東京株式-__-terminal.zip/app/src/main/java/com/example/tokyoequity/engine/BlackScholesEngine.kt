package com.example.tokyoequity.engine

import kotlin.math.*

/**
 * Black-Scholes Options Pricing & Greeks Engine
 * For Nikkei 225 & TOPIX Index / Stock Options
 */
object BlackScholesEngine {

    // Standard Normal Cumulative Distribution Function (Abramowitz & Stegun approximation)
    private fun cdf(x: Double): Double {
        val b1 = 0.319381530
        val b2 = -0.356563782
        val b3 = 1.781477937
        val b4 = -1.821255978
        val b5 = 1.330274429
        val p = 0.2316419
        val c = 0.39894228

        if (x >= 0.0) {
            val t = 1.0 / (1.0 + p * x)
            return (1.0 - c * exp(-x * x / 2.0) * t *
                    (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        } else {
            val t = 1.0 / (1.0 - p * x)
            return (c * exp(-x * x / 2.0) * t *
                    (t * (t * (t * (t * b5 + b4) + b3) + b2) + b1))
        }
    }

    // Standard Normal Probability Density Function
    private fun pdf(x: Double): Double {
        return (1.0 / sqrt(2.0 * PI)) * exp(-0.5 * x * x)
    }

    data class OptionGreeks(
        val price: Double,
        val delta: Double,
        val gamma: Double,
        val vega: Double,
        val theta: Double,
        val rho: Double
    )

    fun calculate(
        spot: Double,
        strike: Double,
        timeYears: Double,
        volatility: Double, // e.g. 0.22 (22%)
        riskFreeRate: Double = 0.0075, // JGB 10Y / OIS (0.75%)
        isCall: Boolean = true
    ): OptionGreeks {
        if (timeYears <= 0.0) {
            val intrinsic = if (isCall) maxOf(0.0, spot - strike) else maxOf(0.0, strike - spot)
            return OptionGreeks(price = intrinsic, delta = if (isCall && spot > strike) 1.0 else 0.0, gamma = 0.0, vega = 0.0, theta = 0.0, rho = 0.0)
        }

        val sigma = maxOf(0.001, volatility)
        val sqrtT = sqrt(timeYears)
        val d1 = (ln(spot / strike) + (riskFreeRate + 0.5 * sigma * sigma) * timeYears) / (sigma * sqrtT)
        val d2 = d1 - sigma * sqrtT

        val price: Double
        val delta: Double
        val theta: Double
        val rho: Double

        val nd1 = cdf(d1)
        val nd2 = cdf(d2)
        val nPrimeD1 = pdf(d1)

        val gamma = nPrimeD1 / (spot * sigma * sqrtT)
        val vega = spot * sqrtT * nPrimeD1 / 100.0 // 1% vol change

        if (isCall) {
            price = spot * nd1 - strike * exp(-riskFreeRate * timeYears) * nd2
            delta = nd1
            theta = (-(spot * nPrimeD1 * sigma) / (2.0 * sqrtT) - riskFreeRate * strike * exp(-riskFreeRate * timeYears) * nd2) / 365.0
            rho = (strike * timeYears * exp(-riskFreeRate * timeYears) * nd2) / 100.0
        } else {
            val nMinusD1 = cdf(-d1)
            val nMinusD2 = cdf(-d2)
            price = strike * exp(-riskFreeRate * timeYears) * nMinusD2 - spot * nMinusD1
            delta = nd1 - 1.0
            theta = (-(spot * nPrimeD1 * sigma) / (2.0 * sqrtT) + riskFreeRate * strike * exp(-riskFreeRate * timeYears) * nMinusD2) / 365.0
            rho = (-strike * timeYears * exp(-riskFreeRate * timeYears) * nMinusD2) / 100.0
        }

        return OptionGreeks(
            price = maxOf(0.0, price),
            delta = delta,
            gamma = gamma,
            vega = vega,
            theta = theta,
            rho = rho
        )
    }
}
