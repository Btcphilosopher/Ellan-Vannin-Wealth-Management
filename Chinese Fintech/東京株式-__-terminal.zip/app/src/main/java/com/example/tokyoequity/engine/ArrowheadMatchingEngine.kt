package com.example.tokyoequity.engine

import com.example.tokyoequity.domain.model.*
import java.util.UUID

/**
 * ARROWHEAD DIGITAL TWIN — Matching Engine (マッチングエンジン)
 * Implements Tokyo Stock Exchange Arrowhead 4.0 execution logic:
 * - Price-Time Priority (価格優先・時間優先の原則)
 * - Zaraba (ザラ場) Continuous Matching
 * - Itayose (板寄せ) Auction Matching for Opening/Closing
 * - Special Quote (特別気配) Threshold Checks
 */
class ArrowheadMatchingEngine(
    val ticker: String,
    var referencePrice: Double,
    val isTopix500: Boolean = true,
    var ruleSet: RuleSetVersion = RuleSetVersion.CURRENT_2026
) {
    private val buyOrders = mutableListOf<Order>()  // Sorted by price desc, time asc
    private val sellOrders = mutableListOf<Order>() // Sorted by price asc, time asc
    private val tradeHistory = mutableListOf<ExecutionTrade>()
    var specialQuoteStatus: SpecialQuoteStatus = SpecialQuoteStatus.NORMAL
        private set

    init {
        seedInitialLiquidity()
    }

    private fun seedInitialLiquidity() {
        var currentBid = referencePrice
        var currentAsk = referencePrice

        // Seed 10 levels of bids and asks
        for (i in 1..10) {
            val bidTick = TickSizeEngine.getTickSize(currentBid - 0.01, isTopix500, ruleSet)
            currentBid = Math.round((currentBid - bidTick) / bidTick) * bidTick

            val askTick = TickSizeEngine.getTickSize(currentAsk + 0.01, isTopix500, ruleSet)
            currentAsk = Math.round((currentAsk + askTick) / askTick) * askTick

            val bidQty = (1000L + (i * 500L)) * 10
            val askQty = (800L + (i * 600L)) * 10

            buyOrders.add(
                Order(
                    orderId = "SEED-BID-$i-${UUID.randomUUID().toString().take(6)}",
                    securityTicker = ticker,
                    side = OrderSide.BUY,
                    orderType = OrderType.LIMIT,
                    price = currentBid,
                    quantity = bidQty,
                    status = OrderStatus.ACCEPTED,
                    participant = "MM_LIQUIDITY_PROVIDER"
                )
            )

            sellOrders.add(
                Order(
                    orderId = "SEED-ASK-$i-${UUID.randomUUID().toString().take(6)}",
                    securityTicker = ticker,
                    side = OrderSide.SELL,
                    orderType = OrderType.LIMIT,
                    price = currentAsk,
                    quantity = askQty,
                    status = OrderStatus.ACCEPTED,
                    participant = "MM_LIQUIDITY_PROVIDER"
                )
            )
        }
        sortBook()
    }

    private fun sortBook() {
        buyOrders.sortWith(compareByDescending<Order> { it.price }.thenBy { it.timestamp })
        sellOrders.sortWith(compareBy<Order> { it.price }.thenBy { it.timestamp })
    }

    /**
     * Submit an order to Arrowhead matching engine
     */
    @Synchronized
    fun submitOrder(order: Order, isAuctionPhase: Boolean = false): MatchingResult {
        // 1. Tick size validation
        if (order.orderType == OrderType.LIMIT && !TickSizeEngine.isValidTick(order.price, isTopix500, ruleSet)) {
            val validTick = TickSizeEngine.getTickSize(order.price, isTopix500, ruleSet)
            return MatchingResult(
                order = order.copy(
                    status = OrderStatus.REJECTED,
                    rejectionReason = "呼値エラー: 注文価格 ${order.price} は呼値単位($validTick 円)に適合していません。"
                ),
                trades = emptyList()
            )
        }

        // 2. Price limit check
        if (order.orderType == OrderType.LIMIT && !PriceLimitEngine.isWithinLimits(order.price, referencePrice)) {
            val limits = PriceLimitEngine.calculateLimits(referencePrice)
            return MatchingResult(
                order = order.copy(
                    status = OrderStatus.REJECTED,
                    rejectionReason = "値幅制限エラー: 注文価格 ${order.price} は制限値幅(${limits.lowerLimit} 〜 ${limits.upperLimit})を超過しています。"
                ),
                trades = emptyList()
            )
        }

        if (isAuctionPhase) {
            // Auction phase (板寄せ): Add to book and do not match until auction call
            if (order.side == OrderSide.BUY) buyOrders.add(order) else sellOrders.add(order)
            sortBook()
            return MatchingResult(order = order.copy(status = OrderStatus.ACCEPTED), trades = emptyList())
        }

        // 3. Continuous Zaraba Matching (ザラ場約定)
        val generatedTrades = mutableListOf<ExecutionTrade>()
        var workingOrder = order.copy(status = OrderStatus.ACCEPTED)

        if (order.side == OrderSide.BUY) {
            val iterator = sellOrders.iterator()
            while (iterator.hasNext() && workingOrder.remainingQuantity > 0) {
                val bestSell = iterator.next()
                val canMatch = if (order.orderType == OrderType.MARKET) true else order.price >= bestSell.price

                if (canMatch) {
                    val matchQty = minOf(workingOrder.remainingQuantity, bestSell.remainingQuantity)
                    val matchPrice = bestSell.price

                    val trade = ExecutionTrade(
                        tradeId = "TRD-${UUID.randomUUID().toString().take(8).uppercase()}",
                        orderId = order.orderId,
                        ticker = ticker,
                        price = matchPrice,
                        quantity = matchQty,
                        side = OrderSide.BUY,
                        executionType = "ZARABA_MATCH",
                        counterpart = bestSell.participant
                    )
                    generatedTrades.add(trade)
                    tradeHistory.add(trade)
                    referencePrice = matchPrice

                    val newFilled = workingOrder.filledQuantity + matchQty
                    val newAvgPrice = if (newFilled > 0) {
                        ((workingOrder.averageFillPrice * workingOrder.filledQuantity) + (matchPrice * matchQty)) / newFilled
                    } else matchPrice

                    workingOrder = workingOrder.copy(
                        filledQuantity = newFilled,
                        averageFillPrice = newAvgPrice,
                        status = if (newFilled >= workingOrder.quantity) OrderStatus.FILLED else OrderStatus.PARTIALLY_FILLED
                    )

                    val updatedSellFilled = bestSell.filledQuantity + matchQty
                    if (updatedSellFilled >= bestSell.quantity) {
                        iterator.remove()
                    } else {
                        val idx = sellOrders.indexOf(bestSell)
                        if (idx >= 0) {
                            sellOrders[idx] = bestSell.copy(
                                filledQuantity = updatedSellFilled,
                                status = OrderStatus.PARTIALLY_FILLED
                            )
                        }
                    }
                } else {
                    break
                }
            }

            if (workingOrder.remainingQuantity > 0 && workingOrder.orderType == OrderType.LIMIT) {
                buyOrders.add(workingOrder)
            }
        } else {
            // SELL Order matching against buy orders
            val iterator = buyOrders.iterator()
            while (iterator.hasNext() && workingOrder.remainingQuantity > 0) {
                val bestBuy = iterator.next()
                val canMatch = if (order.orderType == OrderType.MARKET) true else order.price <= bestBuy.price

                if (canMatch) {
                    val matchQty = minOf(workingOrder.remainingQuantity, bestBuy.remainingQuantity)
                    val matchPrice = bestBuy.price

                    val trade = ExecutionTrade(
                        tradeId = "TRD-${UUID.randomUUID().toString().take(8).uppercase()}",
                        orderId = order.orderId,
                        ticker = ticker,
                        price = matchPrice,
                        quantity = matchQty,
                        side = OrderSide.SELL,
                        executionType = "ZARABA_MATCH",
                        counterpart = bestBuy.participant
                    )
                    generatedTrades.add(trade)
                    tradeHistory.add(trade)
                    referencePrice = matchPrice

                    val newFilled = workingOrder.filledQuantity + matchQty
                    val newAvgPrice = if (newFilled > 0) {
                        ((workingOrder.averageFillPrice * workingOrder.filledQuantity) + (matchPrice * matchQty)) / newFilled
                    } else matchPrice

                    workingOrder = workingOrder.copy(
                        filledQuantity = newFilled,
                        averageFillPrice = newAvgPrice,
                        status = if (newFilled >= workingOrder.quantity) OrderStatus.FILLED else OrderStatus.PARTIALLY_FILLED
                    )

                    val updatedBuyFilled = bestBuy.filledQuantity + matchQty
                    if (updatedBuyFilled >= bestBuy.quantity) {
                        iterator.remove()
                    } else {
                        val idx = buyOrders.indexOf(bestBuy)
                        if (idx >= 0) {
                            buyOrders[idx] = bestBuy.copy(
                                filledQuantity = updatedBuyFilled,
                                status = OrderStatus.PARTIALLY_FILLED
                            )
                        }
                    }
                } else {
                    break
                }
            }

            if (workingOrder.remainingQuantity > 0 && workingOrder.orderType == OrderType.LIMIT) {
                sellOrders.add(workingOrder)
            }
        }

        sortBook()
        return MatchingResult(order = workingOrder, trades = generatedTrades)
    }

    /**
     * Run Itayose auction matching (板寄せ)
     */
    @Synchronized
    fun executeItayoseAuction(): List<ExecutionTrade> {
        if (buyOrders.isEmpty() || sellOrders.isEmpty()) return emptyList()

        // Find execution price that maximizes executable volume
        val allPrices = (buyOrders.map { it.price } + sellOrders.map { it.price }).distinct().sorted()
        var bestPrice = referencePrice
        var maxExecutableQty = 0L

        for (p in allPrices) {
            val cumulativeBuy = buyOrders.filter { it.price >= p || it.orderType == OrderType.MARKET }.sumOf { it.remainingQuantity }
            val cumulativeSell = sellOrders.filter { it.price <= p || it.orderType == OrderType.MARKET }.sumOf { it.remainingQuantity }
            val executable = minOf(cumulativeBuy, cumulativeSell)
            if (executable > maxExecutableQty) {
                maxExecutableQty = executable
                bestPrice = p
            }
        }

        if (maxExecutableQty == 0L) return emptyList()

        val auctionTrades = mutableListOf<ExecutionTrade>()
        var remainingQtyToExecute = maxExecutableQty

        val buyIter = buyOrders.iterator()
        val sellIter = sellOrders.iterator()

        while (remainingQtyToExecute > 0 && buyIter.hasNext() && sellIter.hasNext()) {
            val b = buyIter.next()
            val s = sellIter.next()
            val qty = minOf(b.remainingQuantity, s.remainingQuantity, remainingQtyToExecute)

            val trade = ExecutionTrade(
                tradeId = "AUCTION-TRD-${UUID.randomUUID().toString().take(8)}",
                orderId = b.orderId,
                ticker = ticker,
                price = bestPrice,
                quantity = qty,
                side = OrderSide.BUY,
                executionType = "ITAYOSE_AUCTION",
                counterpart = s.participant
            )
            auctionTrades.add(trade)
            tradeHistory.add(trade)
            remainingQtyToExecute -= qty
        }

        referencePrice = bestPrice
        buyOrders.removeAll { it.remainingQuantity <= 0 }
        sellOrders.removeAll { it.remainingQuantity <= 0 }
        sortBook()
        return auctionTrades
    }

    /**
     * Get Current 10-Level Order Book
     */
    @Synchronized
    fun getOrderBook(): OrderBook {
        val groupedBids = buyOrders
            .groupBy { it.price }
            .map { (price, orders) ->
                OrderBookLevel(
                    price = price,
                    quantity = orders.sumOf { it.remainingQuantity },
                    orderCount = orders.size
                )
            }
            .sortedByDescending { it.price }

        val groupedAsks = sellOrders
            .groupBy { it.price }
            .map { (price, orders) ->
                OrderBookLevel(
                    price = price,
                    quantity = orders.sumOf { it.remainingQuantity },
                    orderCount = orders.size
                )
            }
            .sortedBy { it.price }

        val top10Bids = groupedBids.take(10)
        val top10Asks = groupedAsks.take(10)
        val overAsk = groupedAsks.drop(10).sumOf { it.quantity }
        val underBid = groupedBids.drop(10).sumOf { it.quantity }

        return OrderBook(
            ticker = ticker,
            timestamp = System.currentTimeMillis(),
            bids = top10Bids,
            asks = top10Asks,
            totalBidQuantity = groupedBids.sumOf { it.quantity },
            totalAskQuantity = groupedAsks.sumOf { it.quantity },
            specialQuoteStatus = specialQuoteStatus,
            overAskQuantity = overAsk,
            underBidQuantity = underBid
        )
    }

    @Synchronized
    fun cancelOrder(orderId: String): Boolean {
        val bRemoved = buyOrders.removeIf { it.orderId == orderId }
        val sRemoved = sellOrders.removeIf { it.orderId == orderId }
        return bRemoved || sRemoved
    }

    fun getTradeHistory(): List<ExecutionTrade> = tradeHistory.toList()
}

data class MatchingResult(
    val order: Order,
    val trades: List<ExecutionTrade>
)
