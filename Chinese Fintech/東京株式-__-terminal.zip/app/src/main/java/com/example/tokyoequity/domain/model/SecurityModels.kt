package com.example.tokyoequity.domain.model

/**
 * Institutional Security Master (証券マスター)
 */
data class SecurityMaster(
    val securityId: String,          // e.g. "JP3633400001" (ISIN)
    val ticker: String,              // e.g. "7203"
    val isin: String,                // e.g. "JP3633400001"
    val name: String,                // e.g. "トヨタ自動車"
    val kana: String,                // e.g. "トヨタジドウシャ"
    val englishName: String,         // e.g. "Toyota Motor Corporation"
    val marketSegment: MarketSegment,
    val sector33: Sector33,
    val sector17: Sector17,
    val accountingStandard: AccountingStandard,
    val sharesIssued: Long,          // 発行済株式数
    val treasuryShares: Long,        // 自己株式数
    val freeFloatRatio: Double,      // 浮動株比率 (0.0 - 1.0)
    val tradingUnit: Int = 100,      // 単元株式数
    val listingDate: String,         // 上場日
    val isTopix500: Boolean,         // TOPIX500採用銘柄フラグ (呼値判定用)
    
    // Live Market Data Snapshot
    val currentPrice: Double,
    val previousClose: Double,
    val openPrice: Double,
    val highPrice: Double,
    val lowPrice: Double,
    val vwap: Double,
    val volume: Long,
    val turnover: Double,            // 売買代金 (JPY)
    val referencePrice: Double,
    val upperLimit: Double,          // ストップ高
    val lowerLimit: Double,          // ストップ安
    val specialQuoteStatus: SpecialQuoteStatus = SpecialQuoteStatus.NORMAL,
    
    // Financial Fundamentals
    val marketCap: Double,           // 時価総額 (億円)
    val per: Double,                 // 株価収益率
    val pbr: Double,                 // 株価純資産倍率
    val roe: Double,                 // 自己資本利益率 (%)
    val roic: Double,                // 投下資本利益率 (%)
    val dividendYield: Double,       // 配当利回り (%)
    val dividendPerShare: Double,    // 1株当たり配当金 (円)
    val payoutRatio: Double,         // 配当性向 (%)
    val equityRatio: Double,         // 自己資本比率 (%)
    val netCash: Double,             // ネットキャッシュ (億円)
    val operatingProfitMargin: Double, // 営業利益率 (%)
    val eps: Double,
    val bps: Double,
    
    // Margin Trading (信用残)
    val marginBuyBalance: Long,      // 信用買い残 (株)
    val marginSellBalance: Long,     // 信用売り残 (株)
    val marginRatio: Double,         // 信用倍率
    val shortInterestRatio: Double   // 空売り比率 (%)
) {
    val priceChange: Double get() = currentPrice - previousClose
    val changePercent: Double get() = if (previousClose > 0) (priceChange / previousClose) * 100.0 else 0.0
    val freeFloatMarketCap: Double get() = marketCap * freeFloatRatio
}

/**
 * Order Book Single Level (板気配)
 */
data class OrderBookLevel(
    val price: Double,
    val quantity: Long,
    val orderCount: Int = 1,
    val isSpecialQuote: Boolean = false
)

/**
 * Complete Order Book (10-Level & Depth)
 */
data class OrderBook(
    val ticker: String,
    val timestamp: Long,
    val bids: List<OrderBookLevel>, // 買気配 (降順)
    val asks: List<OrderBookLevel>, // 売気配 (昇順)
    val totalBidQuantity: Long,
    val totalAskQuantity: Long,
    val specialQuoteStatus: SpecialQuoteStatus = SpecialQuoteStatus.NORMAL,
    val overAskQuantity: Long,
    val underBidQuantity: Long
)

/**
 * Simulated Order
 */
data class Order(
    val orderId: String,
    val securityTicker: String,
    val side: OrderSide,
    val orderType: OrderType,
    val price: Double,
    val quantity: Long,
    val filledQuantity: Long = 0,
    val timeInForce: TimeInForce = TimeInForce.FAS,
    val status: OrderStatus = OrderStatus.ACCEPTED,
    val timestamp: Long = System.currentTimeMillis(),
    val participant: String = "機構投資家 (DOMESTIC_INSTITUTIONAL)",
    val averageFillPrice: Double = 0.0,
    val rejectionReason: String? = null
) {
    val remainingQuantity: Long get() = quantity - filledQuantity
}

/**
 * Execution / Trade Event (約定)
 */
data class ExecutionTrade(
    val tradeId: String,
    val orderId: String,
    val ticker: String,
    val price: Double,
    val quantity: Long,
    val side: OrderSide,
    val timestamp: Long = System.currentTimeMillis(),
    val executionType: String = "ZARABA_MATCH",
    val counterpart: String = "MM_LIQUIDITY_PROVIDER"
)
