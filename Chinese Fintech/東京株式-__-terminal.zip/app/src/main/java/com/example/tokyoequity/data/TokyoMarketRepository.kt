package com.example.tokyoequity.data

import com.example.tokyoequity.domain.model.*
import com.example.tokyoequity.engine.ArrowheadMatchingEngine
import com.example.tokyoequity.engine.BlackScholesEngine
import com.example.tokyoequity.engine.MatchingResult
import com.example.tokyoequity.engine.PriceLimitEngine
import com.example.tokyoequity.engine.RiskEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

/**
 * Tokyo Equity Market Repository & Digital Twin Core
 */
class TokyoMarketRepository {

    private val _currentPhase = MutableStateFlow(MarketPhase.CONTINUOUS_AFTERNOON)
    val currentPhase: StateFlow<MarketPhase> = _currentPhase.asStateFlow()

    private val _currentRuleSet = MutableStateFlow(RuleSetVersion.CURRENT_2026)
    val currentRuleSet: StateFlow<RuleSetVersion> = _currentRuleSet.asStateFlow()

    private val _securities = MutableStateFlow<List<SecurityMaster>>(emptyList())
    val securities: StateFlow<List<SecurityMaster>> = _securities.asStateFlow()

    private val _selectedSecurityTicker = MutableStateFlow("7203")
    val selectedSecurityTicker: StateFlow<String> = _selectedSecurityTicker.asStateFlow()

    private val _indices = MutableStateFlow<List<MarketIndex>>(emptyList())
    val indices: StateFlow<List<MarketIndex>> = _indices.asStateFlow()

    private val _sectorPerformances = MutableStateFlow<List<SectorPerformance>>(emptyList())
    val sectorPerformances: StateFlow<List<SectorPerformance>> = _sectorPerformances.asStateFlow()

    private val _fxRates = MutableStateFlow<List<FxRate>>(emptyList())
    val fxRates: StateFlow<List<FxRate>> = _fxRates.asStateFlow()

    private val _futures = MutableStateFlow<List<FuturesContract>>(emptyList())
    val futures: StateFlow<List<FuturesContract>> = _futures.asStateFlow()

    private val _options = MutableStateFlow<List<OptionContract>>(emptyList())
    val options: StateFlow<List<OptionContract>> = _options.asStateFlow()

    private val _userOrders = MutableStateFlow<List<Order>>(emptyList())
    val userOrders: StateFlow<List<Order>> = _userOrders.asStateFlow()

    private val _recentTrades = MutableStateFlow<List<ExecutionTrade>>(emptyList())
    val recentTrades: StateFlow<List<ExecutionTrade>> = _recentTrades.asStateFlow()

    private val _portfolioHoldings = MutableStateFlow<List<PortfolioHolding>>(emptyList())
    val portfolioHoldings: StateFlow<List<PortfolioHolding>> = _portfolioHoldings.asStateFlow()

    private val _portfolioRisk = MutableStateFlow<PortfolioRisk?>(null)
    val portfolioRisk: StateFlow<PortfolioRisk?> = _portfolioRisk.asStateFlow()

    private val _surveillanceAlerts = MutableStateFlow<List<SurveillanceAlert>>(emptyList())
    val surveillanceAlerts: StateFlow<List<SurveillanceAlert>> = _surveillanceAlerts.asStateFlow()

    // Matching Engines per Ticker
    private val matchingEngines = mutableMapOf<String, ArrowheadMatchingEngine>()

    init {
        initializeSecurities()
        initializeIndices()
        initializeSectors()
        initializeFxAndDerivatives()
        initializePortfolio()
        initializeSurveillance()
    }

    private fun initializeSecurities() {
        val initialList = listOf(
            createSecurity(
                ticker = "7203", isin = "JP3633400001", name = "トヨタ自動車", kana = "トヨタジドウシャ",
                englishName = "Toyota Motor Corp", segment = MarketSegment.PRIME, sector33 = Sector33.TRANSPORT_EQUIPMENT,
                sector17 = Sector17.AUTOMOBILES_TRANSPORT, accounting = AccountingStandard.IFRS,
                shares = 16_314_987_000L, treasury = 2_745_000_000L, floatRatio = 0.62,
                currentPrice = 3012.0, prevClose = 2985.0, vwap = 3004.5, volume = 28_450_000L,
                marketCap = 491400.0, per = 10.4, pbr = 1.18, roe = 14.8, roic = 10.2,
                divYield = 2.85, divPerShare = 85.0, payout = 29.5, equityRatio = 41.2, netCash = 85400.0,
                opMargin = 11.2, eps = 289.6, bps = 2552.0, marginBuy = 5420000L, marginSell = 840000L, shortInterest = 14.2
            ),
            createSecurity(
                ticker = "6758", isin = "JP3435000009", name = "ソニーグループ", kana = "ソニーグループ",
                englishName = "Sony Group Corp", segment = MarketSegment.PRIME, sector33 = Sector33.ELECTRIC_APPLIANCES,
                sector17 = Sector17.ELECTRIC_PRECISION, accounting = AccountingStandard.IFRS,
                shares = 1_234_650_000L, treasury = 8_200_000L, floatRatio = 0.85,
                currentPrice = 14250.0, prevClose = 13980.0, vwap = 14180.0, volume = 6_820_000L,
                marketCap = 175935.0, per = 17.6, pbr = 2.14, roe = 12.9, roic = 9.8,
                divYield = 1.68, divPerShare = 240.0, payout = 29.8, equityRatio = 48.5, netCash = 42100.0,
                opMargin = 12.8, eps = 809.6, bps = 6658.0, marginBuy = 2100000L, marginSell = 320000L, shortInterest = 11.8
            ),
            createSecurity(
                ticker = "9984", isin = "JP3436100006", name = "ソフトバンクグループ", kana = "ソフトバンクグループ",
                englishName = "SoftBank Group Corp", segment = MarketSegment.PRIME, sector33 = Sector33.INFO_COMMUNICATION,
                sector17 = Sector17.INFO_COMM_SERVICES, accounting = AccountingStandard.IFRS,
                shares = 1_469_840_000L, treasury = 42_000_000L, floatRatio = 0.58,
                currentPrice = 9180.0, prevClose = 9320.0, vwap = 9210.0, volume = 14_980_000L,
                marketCap = 134930.0, per = 14.2, pbr = 1.35, roe = 9.5, roic = 7.1,
                divYield = 0.48, divPerShare = 44.0, payout = 6.8, equityRatio = 26.4, netCash = 31000.0,
                opMargin = 15.4, eps = 646.4, bps = 6800.0, marginBuy = 9420000L, marginSell = 1850000L, shortInterest = 18.5
            ),
            createSecurity(
                ticker = "8306", isin = "JP3902900004", name = "三菱UFJフィナンシャルG", kana = "ミツビシユーエフジェイ",
                englishName = "Mitsubishi UFJ Financial Group", segment = MarketSegment.PRIME, sector33 = Sector33.BANKS,
                sector17 = Sector17.BANKS, accounting = AccountingStandard.JGAAP,
                shares = 12_410_000_000L, treasury = 520_000_000L, floatRatio = 0.78,
                currentPrice = 1765.0, prevClose = 1738.0, vwap = 1756.0, volume = 45_120_000L,
                marketCap = 219030.0, per = 11.8, pbr = 0.98, roe = 8.6, roic = 6.2,
                divYield = 3.62, divPerShare = 64.0, payout = 42.5, equityRatio = 5.2, netCash = 0.0,
                opMargin = 28.5, eps = 149.5, bps = 1801.0, marginBuy = 12400000L, marginSell = 2100000L, shortInterest = 8.6
            ),
            createSecurity(
                ticker = "6861", isin = "JP3236200006", name = "キーエンス", kana = "キーエンス",
                englishName = "Keyence Corp", segment = MarketSegment.PRIME, sector33 = Sector33.ELECTRIC_APPLIANCES,
                sector17 = Sector17.ELECTRIC_PRECISION, accounting = AccountingStandard.JGAAP,
                shares = 243_200_000L, treasury = 1_100_000L, floatRatio = 0.65,
                currentPrice = 68420.0, prevClose = 67800.0, vwap = 68200.0, volume = 850_000L,
                marketCap = 166397.0, per = 42.5, pbr = 5.82, roe = 14.2, roic = 18.5,
                divYield = 0.58, divPerShare = 400.0, payout = 24.8, equityRatio = 95.2, netCash = 24800.0,
                opMargin = 51.4, eps = 1610.0, bps = 11756.0, marginBuy = 410000L, marginSell = 92000L, shortInterest = 6.4
            ),
            createSecurity(
                ticker = "8035", isin = "JP3571400005", name = "東京エレクトロン", kana = "トウキョウエレクトロン",
                englishName = "Tokyo Electron Ltd", segment = MarketSegment.PRIME, sector33 = Sector33.ELECTRIC_APPLIANCES,
                sector17 = Sector17.ELECTRIC_PRECISION, accounting = AccountingStandard.JGAAP,
                shares = 471_630_000L, treasury = 6_800_000L, floatRatio = 0.88,
                currentPrice = 28650.0, prevClose = 29200.0, vwap = 28840.0, volume = 5_430_000L,
                marketCap = 135121.0, per = 26.4, pbr = 5.48, roe = 22.8, roic = 19.4,
                divYield = 2.15, divPerShare = 616.0, payout = 50.0, equityRatio = 72.8, netCash = 18400.0,
                opMargin = 28.6, eps = 1085.0, bps = 5228.0, marginBuy = 3120000L, marginSell = 840000L, shortInterest = 13.9
            ),
            createSecurity(
                ticker = "9432", isin = "JP3735400008", name = "日本電信電話 (NTT)", kana = "ニホンデンシンデンワ",
                englishName = "Nippon Telegraph and Telephone", segment = MarketSegment.PRIME, sector33 = Sector33.INFO_COMMUNICATION,
                sector17 = Sector17.INFO_COMM_SERVICES, accounting = AccountingStandard.IFRS,
                shares = 90_537_000_000L, treasury = 5_100_000_000L, floatRatio = 0.67,
                currentPrice = 158.4, prevClose = 157.9, vwap = 158.1, volume = 142_000_000L,
                marketCap = 143410.0, per = 11.2, pbr = 1.32, roe = 12.1, roic = 8.4,
                divYield = 3.28, divPerShare = 5.2, payout = 36.8, equityRatio = 38.6, netCash = 21000.0,
                opMargin = 14.1, eps = 14.14, bps = 120.0, marginBuy = 42500000L, marginSell = 3200000L, shortInterest = 7.1
            ),
            createSecurity(
                ticker = "9983", isin = "JP3802300008", name = "ファーストリテイリング", kana = "ファーストリテイリング",
                englishName = "Fast Retailing Co Ltd", segment = MarketSegment.PRIME, sector33 = Sector33.RETAIL,
                sector17 = Sector17.RETAIL, accounting = AccountingStandard.IFRS,
                shares = 318_220_000L, treasury = 12_400_000L, floatRatio = 0.52,
                currentPrice = 48600.0, prevClose = 47950.0, vwap = 48400.0, volume = 1_820_000L,
                marketCap = 154655.0, per = 38.2, pbr = 6.42, roe = 18.2, roic = 16.5,
                divYield = 1.02, divPerShare = 496.0, payout = 39.0, equityRatio = 58.2, netCash = 14200.0,
                opMargin = 16.5, eps = 1272.0, bps = 7570.0, marginBuy = 650000L, marginSell = 280000L, shortInterest = 9.4
            ),
            createSecurity(
                ticker = "1306", isin = "JP3027650005", name = "NF・TOPIX連動型投信", kana = "エヌエフトピックス",
                englishName = "NEXT FUNDS TOPIX ETF", segment = MarketSegment.ETF, sector33 = Sector33.OTHER_PRODUCTS,
                sector17 = Sector17.INFO_COMM_SERVICES, accounting = AccountingStandard.JGAAP,
                shares = 8_250_000_000L, treasury = 0L, floatRatio = 1.0,
                currentPrice = 2854.5, prevClose = 2835.0, vwap = 2848.0, volume = 8_400_000L,
                marketCap = 235496.0, per = 15.6, pbr = 1.45, roe = 9.8, roic = 7.9,
                divYield = 2.12, divPerShare = 60.5, payout = 98.0, equityRatio = 99.8, netCash = 5000.0,
                opMargin = 0.0, eps = 182.9, bps = 1968.0, marginBuy = 4100000L, marginSell = 820000L, shortInterest = 4.2
            ),
            createSecurity(
                ticker = "8951", isin = "JP3027670003", name = "日本ビルファンド投資法人", kana = "ニホンビルファンド",
                englishName = "Nippon Building Fund Inc", segment = MarketSegment.REIT, sector33 = Sector33.REAL_ESTATE,
                sector17 = Sector17.REAL_ESTATE, accounting = AccountingStandard.JGAAP,
                shares = 1_700_000L, treasury = 0L, floatRatio = 0.92,
                currentPrice = 584000.0, prevClose = 581000.0, vwap = 583000.0, volume = 4_200L,
                marketCap = 9928.0, per = 23.4, pbr = 1.02, roe = 4.6, roic = 3.8,
                divYield = 4.25, divPerShare = 24820.0, payout = 99.5, equityRatio = 52.4, netCash = 0.0,
                opMargin = 52.1, eps = 24957.0, bps = 572500.0, marginBuy = 14500L, marginSell = 2800L, shortInterest = 5.1
            )
        )

        _securities.value = initialList

        // Instantiate Matching Engines for all securities
        initialList.forEach { sec ->
            matchingEngines[sec.ticker] = ArrowheadMatchingEngine(
                ticker = sec.ticker,
                referencePrice = sec.currentPrice,
                isTopix500 = sec.isTopix500,
                ruleSet = _currentRuleSet.value
            )
        }
    }

    private fun createSecurity(
        ticker: String, isin: String, name: String, kana: String, englishName: String,
        segment: MarketSegment, sector33: Sector33, sector17: Sector17, accounting: AccountingStandard,
        shares: Long, treasury: Long, floatRatio: Double, currentPrice: Double, prevClose: Double,
        vwap: Double, volume: Long, marketCap: Double, per: Double, pbr: Double, roe: Double,
        roic: Double, divYield: Double, divPerShare: Double, payout: Double, equityRatio: Double,
        netCash: Double, opMargin: Double, eps: Double, bps: Double, marginBuy: Long,
        marginSell: Long, shortInterest: Double
    ): SecurityMaster {
        val limits = PriceLimitEngine.calculateLimits(prevClose)
        return SecurityMaster(
            securityId = isin,
            ticker = ticker,
            isin = isin,
            name = name,
            kana = kana,
            englishName = englishName,
            marketSegment = segment,
            sector33 = sector33,
            sector17 = sector17,
            accountingStandard = accounting,
            sharesIssued = shares,
            treasuryShares = treasury,
            freeFloatRatio = floatRatio,
            tradingUnit = if (segment == MarketSegment.REIT) 1 else 100,
            listingDate = "1949-05-16",
            isTopix500 = true,
            currentPrice = currentPrice,
            previousClose = prevClose,
            openPrice = prevClose + ((currentPrice - prevClose) * 0.4),
            highPrice = maxOf(currentPrice, prevClose) + (prevClose * 0.008),
            lowPrice = minOf(currentPrice, prevClose) - (prevClose * 0.006),
            vwap = vwap,
            volume = volume,
            turnover = currentPrice * volume,
            referencePrice = prevClose,
            upperLimit = limits.upperLimit,
            lowerLimit = limits.lowerLimit,
            marketCap = marketCap,
            per = per,
            pbr = pbr,
            roe = roe,
            roic = roic,
            dividendYield = divYield,
            dividendPerShare = divPerShare,
            payoutRatio = payout,
            equityRatio = equityRatio,
            netCash = netCash,
            operatingProfitMargin = opMargin,
            eps = eps,
            bps = bps,
            marginBuyBalance = marginBuy,
            marginSellBalance = marginSell,
            marginRatio = if (marginSell > 0) (marginBuy.toDouble() / marginSell.toDouble()) else 1.0,
            shortInterestRatio = shortInterest
        )
    }

    private fun initializeIndices() {
        _indices.value = listOf(
            MarketIndex(
                indexId = "TOPIX",
                name = "TOPIX (東証株価指数)",
                value = 2786.42,
                previousClose = 2768.10,
                divisor = 345678901.0,
                constituentCount = 2145,
                methodology = "浮動株調整時価総額加重",
                provider = "東京証券取引所 / デジタルツイン"
            ),
            MarketIndex(
                indexId = "N225",
                name = "日経平均株価 (日経225)",
                value = 39420.50,
                previousClose = 39150.00,
                divisor = 30.145,
                constituentCount = 225,
                methodology = "株価換算加重 (Nikkei Provider Adapter)",
                provider = "SyntheticNikkeiProvider"
            ),
            MarketIndex(
                indexId = "JPXNK400",
                name = "JPX日経インデックス400",
                value = 25180.20,
                previousClose = 25010.00,
                divisor = 1523400.0,
                constituentCount = 400,
                methodology = "ROE・営業利益ガバナンス調整加重",
                provider = "JPX / 日本経済新聞社"
            ),
            MarketIndex(
                indexId = "CORE30",
                name = "TOPIX Core30",
                value = 1320.45,
                previousClose = 1308.20,
                divisor = 4567890.0,
                constituentCount = 30,
                methodology = "大型超優良30銘柄 浮動株時価総額加重",
                provider = "東京証券取引所"
            ),
            MarketIndex(
                indexId = "REIT_INDEX",
                name = "東証REIT指数",
                value = 1742.80,
                previousClose = 1735.40,
                divisor = 987654.0,
                constituentCount = 58,
                methodology = "全REIT時価総額加重",
                provider = "東京証券取引所"
            )
        )
    }

    private fun initializeSectors() {
        _sectorPerformances.value = listOf(
            SectorPerformance(Sector33.BANKS, +1.85, 420.5, 68, 12, "8306 三菱UFJ", 11.2, 0.95, 3.8),
            SectorPerformance(Sector33.ELECTRIC_APPLIANCES, +1.42, 680.2, 142, 45, "6758 ソニーG", 21.5, 2.8, 1.8),
            SectorPerformance(Sector33.TRANSPORT_EQUIPMENT, +0.95, 390.4, 48, 18, "7203 トヨタ", 10.4, 1.18, 2.9),
            SectorPerformance(Sector33.WHOLESALE, +1.15, 280.6, 75, 20, "8058 三菱商事", 9.8, 1.25, 3.4),
            SectorPerformance(Sector33.INFO_COMMUNICATION, -0.45, 310.2, 52, 68, "9984 ソフトバンクG", 18.2, 1.9, 2.2),
            SectorPerformance(Sector33.MACHINERY, +0.82, 210.4, 88, 34, "6301 コマツ", 14.6, 1.6, 2.7),
            SectorPerformance(Sector33.CHEMICALS, +0.35, 195.0, 94, 52, "4063 信越化", 15.2, 1.8, 2.4),
            SectorPerformance(Sector33.PHARMACEUTICAL, -0.28, 160.8, 28, 42, "4502 武田薬", 22.0, 1.7, 3.9),
            SectorPerformance(Sector33.REAL_ESTATE, +0.78, 140.2, 45, 19, "8801 三井不", 13.5, 1.4, 2.1),
            SectorPerformance(Sector33.RETAIL, +0.64, 230.1, 110, 58, "9983 ファストリ", 24.1, 3.2, 1.6)
        )
    }

    private fun initializeFxAndDerivatives() {
        _fxRates.value = listOf(
            FxRate("USD/JPY", 151.42, +0.58, +0.38, 151.85, 150.72),
            FxRate("EUR/JPY", 164.20, +0.42, +0.26, 164.60, 163.75),
            FxRate("GBP/JPY", 195.80, +0.65, +0.33, 196.25, 195.10),
            FxRate("AUD/JPY", 99.45, -0.12, -0.12, 99.85, 99.20)
        )

        _futures.value = listOf(
            FuturesContract("NK225-2612", "日経225先物", "2026-12 (期近)", 39480.0, 39210.0, +59.5, 48200L, 142000L, 0.45),
            FuturesContract("NK225M-2612", "日経225 mini", "2026-12 (期近)", 39485.0, 39215.0, +64.5, 185000L, 385000L, 0.46),
            FuturesContract("TOPIX-2612", "TOPIX先物", "2026-12 (期近)", 2791.0, 2772.5, +4.58, 28400L, 89000L, 0.38)
        )

        // Options Chain for Nikkei 225
        val strikes = listOf(38000.0, 38500.0, 39000.0, 39500.0, 40000.0, 40500.0, 41000.0)
        val currentSpot = 39420.0
        val tYears = 24.0 / 365.0 // 24 days to SQ

        val opts = mutableListOf<OptionContract>()
        strikes.forEach { k ->
            val ivCall = 0.185 + (kotlin.math.abs(k - currentSpot) / currentSpot * 0.12)
            val ivPut = 0.198 + (kotlin.math.abs(k - currentSpot) / currentSpot * 0.15)

            val callGreeks = BlackScholesEngine.calculate(currentSpot, k, tYears, ivCall, 0.0075, true)
            val putGreeks = BlackScholesEngine.calculate(currentSpot, k, tYears, ivPut, 0.0075, false)

            opts.add(
                OptionContract(
                    optionId = "NK-C-${k.toInt()}",
                    underlying = "日経225",
                    optionType = "CALL",
                    strikePrice = k,
                    maturityDate = "2026-11-13 (第2金曜SQ)",
                    timeToMaturityYears = tYears,
                    price = callGreeks.price,
                    impliedVolatility = ivCall * 100.0,
                    delta = callGreeks.delta,
                    gamma = callGreeks.gamma,
                    vega = callGreeks.vega,
                    theta = callGreeks.theta,
                    rho = callGreeks.rho,
                    volume = 1240L,
                    openInterest = 5400L
                )
            )
            opts.add(
                OptionContract(
                    optionId = "NK-P-${k.toInt()}",
                    underlying = "日経225",
                    optionType = "PUT",
                    strikePrice = k,
                    maturityDate = "2026-11-13 (第2金曜SQ)",
                    timeToMaturityYears = tYears,
                    price = putGreeks.price,
                    impliedVolatility = ivPut * 100.0,
                    delta = putGreeks.delta,
                    gamma = putGreeks.gamma,
                    vega = putGreeks.vega,
                    theta = putGreeks.theta,
                    rho = putGreeks.rho,
                    volume = 1890L,
                    openInterest = 8200L
                )
            )
        }
        _options.value = opts
    }

    private fun initializePortfolio() {
        val holdings = listOf(
            PortfolioHolding("JP3633400001", "7203", "トヨタ自動車", "EQUITY", 15000L, 2850.0, 3012.0, weightPercent = 28.5),
            PortfolioHolding("JP3435000009", "6758", "ソニーグループ", "EQUITY", 2500L, 13400.0, 14250.0, weightPercent = 22.4),
            PortfolioHolding("JP3902900004", "8306", "三菱UFJフィナンシャルG", "EQUITY", 18000L, 1620.0, 1765.0, weightPercent = 20.0),
            PortfolioHolding("JP3027650005", "1306", "NF・TOPIX連動型投信", "ETF", 6000L, 2740.0, 2854.5, weightPercent = 10.8),
            PortfolioHolding("JP3027670003", "8951", "日本ビルファンド投資法人", "REIT", 40L, 560000.0, 584000.0, weightPercent = 14.7),
            PortfolioHolding("NK225-2612", "NK225-2612", "日経225先物(2612)", "FUTURES", 2L, 39100.0, 39480.0, weightPercent = 3.6)
        )
        _portfolioHoldings.value = holdings
        _portfolioRisk.value = RiskEngine.calculatePortfolioRisk(holdings)
    }

    private fun initializeSurveillance() {
        _surveillanceAlerts.value = listOf(
            SurveillanceAlert(
                alertId = "AL-2026-0091",
                timestamp = System.currentTimeMillis() - 120_000,
                ticker = "9984",
                alertType = "見せ板疑い (SPOOFING)",
                severity = "WARNING",
                details = "直近3秒間に最良気配直下で50,000株の指値追加および直後取消を4回連続検知"
            ),
            SurveillanceAlert(
                alertId = "AL-2026-0088",
                timestamp = System.currentTimeMillis() - 480_000,
                ticker = "8035",
                alertType = "気配急変 (FLASH_QUOTE)",
                severity = "INFO",
                details = "半導体セクター速報に伴い最良売気配が0.5秒間に+1.2%急伸"
            ),
            SurveillanceAlert(
                alertId = "AL-2026-0074",
                timestamp = System.currentTimeMillis() - 950_000,
                ticker = "8306",
                alertType = "出来高急増 (VOLUME_SPIKE)",
                severity = "INFO",
                details = "前場開始後10分間で1日平均出来高の18%を消化"
            )
        )
    }

    fun selectSecurity(ticker: String) {
        _selectedSecurityTicker.value = ticker
    }

    fun setRuleSet(ruleSet: RuleSetVersion) {
        _currentRuleSet.value = ruleSet
        matchingEngines.values.forEach { it.ruleSet = ruleSet }
    }

    fun setMarketPhase(phase: MarketPhase) {
        _currentPhase.value = phase
        if (phase == MarketPhase.OPENING_AUCTION || phase == MarketPhase.CLOSING_AUCTION) {
            // Trigger auction matching on all active engines
            matchingEngines.values.forEach { engine ->
                val trades = engine.executeItayoseAuction()
                if (trades.isNotEmpty()) {
                    _recentTrades.value = trades + _recentTrades.value
                }
            }
        }
    }

    fun getOrderBook(ticker: String): OrderBook {
        val engine = matchingEngines[ticker] ?: ArrowheadMatchingEngine(ticker, 3000.0)
        return engine.getOrderBook()
    }

    fun submitOrder(
        ticker: String,
        side: OrderSide,
        orderType: OrderType,
        price: Double,
        quantity: Long
    ): MatchingResult {
        val engine = matchingEngines[ticker] ?: ArrowheadMatchingEngine(ticker, price).also {
            matchingEngines[ticker] = it
        }

        val order = Order(
            orderId = "ORD-${UUID.randomUUID().toString().take(8).uppercase()}",
            securityTicker = ticker,
            side = side,
            orderType = orderType,
            price = price,
            quantity = quantity,
            timestamp = System.currentTimeMillis()
        )

        val isAuction = _currentPhase.value == MarketPhase.PRE_OPEN ||
                _currentPhase.value == MarketPhase.AFTERNOON_PRE_OPEN ||
                _currentPhase.value == MarketPhase.OPENING_AUCTION ||
                _currentPhase.value == MarketPhase.CLOSING_AUCTION

        val result = engine.submitOrder(order, isAuctionPhase = isAuction)
        _userOrders.value = listOf(result.order) + _userOrders.value

        if (result.trades.isNotEmpty()) {
            _recentTrades.value = result.trades + _recentTrades.value

            // Update live price in securities list
            val lastPrice = result.trades.last().price
            _securities.value = _securities.value.map { sec ->
                if (sec.ticker == ticker) {
                    sec.copy(
                        currentPrice = lastPrice,
                        volume = sec.volume + result.trades.sumOf { it.quantity },
                        turnover = sec.turnover + (lastPrice * result.trades.sumOf { it.quantity })
                    )
                } else sec
            }
        }

        return result
    }

    fun cancelOrder(orderId: String, ticker: String): Boolean {
        val engine = matchingEngines[ticker] ?: return false
        val removed = engine.cancelOrder(orderId)
        if (removed) {
            _userOrders.value = _userOrders.value.map { ord ->
                if (ord.orderId == orderId) ord.copy(status = OrderStatus.CANCELLED) else ord
            }
        }
        return removed
    }

    // Execute Institutional ETF RFQ (CONNEQTOR Digital Twin)
    fun simulateEtfRfq(etfTicker: String, quantity: Long, side: OrderSide): RfqResult {
        val sec = _securities.value.find { it.ticker == etfTicker } ?: _securities.value.first()
        val base = sec.currentPrice
        val quotes = listOf(
            DealerQuote("三菱UFJモルガン・スタンレー証券", base - 0.2, base + 0.2, 50000L),
            DealerQuote("野村證券", base - 0.3, base + 0.15, 80000L),
            DealerQuote("大和証券", base - 0.25, base + 0.25, 40000L),
            DealerQuote("ゴールドマン・サックス証券", base - 0.15, base + 0.3, 100000L)
        )
        val bestQuote = if (side == OrderSide.BUY) {
            quotes.minByOrNull { it.askPrice }!!
        } else {
            quotes.maxByOrNull { it.bidPrice }!!
        }
        val executedPrice = if (side == OrderSide.BUY) bestQuote.askPrice else bestQuote.bidPrice

        return RfqResult(
            rfqId = "RFQ-CNQ-${UUID.randomUUID().toString().take(6).uppercase()}",
            etfTicker = etfTicker,
            side = side,
            quantity = quantity,
            dealerQuotes = quotes,
            winnerDealer = bestQuote.dealerName,
            executedPrice = executedPrice,
            priceImprovementVsSpread = 0.15
        )
    }
}

data class DealerQuote(
    val dealerName: String,
    val bidPrice: Double,
    val askPrice: Double,
    val sizeAvailable: Long
)

data class RfqResult(
    val rfqId: String,
    val etfTicker: String,
    val side: OrderSide,
    val quantity: Long,
    val dealerQuotes: List<DealerQuote>,
    val winnerDealer: String,
    val executedPrice: Double,
    val priceImprovementVsSpread: Double
)
