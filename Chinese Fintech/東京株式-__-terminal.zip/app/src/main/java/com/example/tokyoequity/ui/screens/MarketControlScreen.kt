package com.example.tokyoequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tokyoequity.domain.model.SectorPerformance
import com.example.tokyoequity.ui.theme.*
import com.example.tokyoequity.ui.viewmodel.TerminalWorkspace
import com.example.tokyoequity.ui.viewmodel.TokyoMarketViewModel

@Composable
fun MarketControlScreen(
    viewModel: TokyoMarketViewModel,
    modifier: Modifier = Modifier
) {
    val phase by viewModel.currentPhase.collectAsState()
    val ruleSet by viewModel.currentRuleSet.collectAsState()
    val sectors by viewModel.sectorPerformances.collectAsState()
    val securities by viewModel.securities.collectAsState()
    val msgsPerSec by viewModel.arrowheadMsgsPerSec.collectAsState()
    val latencyUs by viewModel.arrowheadLatencyUs.collectAsState()
    val cpuLoad by viewModel.arrowheadCpuLoad.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TokyoDarkBackground)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section 1: Arrowhead 4.0 Digital Twin Telemetry & Control Room
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = TokyoBluePrimary, modifier = Modifier.size(18.dp))
                            Text(
                                text = "ARROWHEAD 4.0 デジタルツイン監視",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TokyoTextPrimary
                            )
                        }
                        Text(
                            text = "稼働中: 正常 (稼働率 100%)",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokyoPositiveGreen
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricBadge(
                            label = "注文応答時間 (Latency)",
                            value = "${latencyUs} μs",
                            subtext = "JPX目標: < 200μs",
                            color = TokyoPositiveGreen,
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "メッセージ配信量",
                            value = "${String.format("%,d", msgsPerSec)} msg/s",
                            subtext = "ピーク耐力: 120,000",
                            color = TokyoBlueGlow,
                            modifier = Modifier.weight(1f)
                        )
                        MetricBadge(
                            label = "マッチングCPU負荷",
                            value = "${String.format("%.1f", cpuLoad)}%",
                            subtext = "48 Cores Dedicated",
                            color = TokyoWarningGold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Section 2: Market Breadth & Summary Indicators
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "東証プライム 騰落・市場 Breadth",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        BreadthItem(label = "値上がり銘柄", count = "1,142", percent = "69.1%", color = TokyoPositiveGreen)
                        BreadthItem(label = "値下がり銘柄", count = "458", percent = "27.7%", color = TokyoNegativeRed)
                        BreadthItem(label = "変わらず", count = "52", percent = "3.2%", color = TokyoTextMuted)
                        BreadthItem(label = "ストップ高", count = "6", percent = "0.4%", color = TokyoWarningGold)
                        BreadthItem(label = "ストップ安", count = "0", percent = "0.0%", color = TokyoTextDim)
                    }
                }
            }
        }

        // Section 3: 33-Sector Heatmap & Performance Matrix
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "日本株 33業種ヒートマップ & 騰落率",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TokyoTextPrimary
                        )
                        Text(
                            text = "サイズ: 売買代金 | 色: 日次騰落率",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokyoTextMuted
                        )
                    }

                    // Sector Grid
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        sectors.chunked(2).forEach { rowSectors ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                rowSectors.forEach { secPerf ->
                                    SectorCard(
                                        sector = secPerf,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                if (rowSectors.size == 1) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 4: Key Securities Snapshot
        item {
            Card(
                shape = RoundedCornerShape(6.dp),
                colors = CardDefaults.cardColors(containerColor = TokyoSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TokyoCardBorder)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "東証代表銘柄 (Core Securities)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TokyoTextPrimary
                    )

                    securities.take(6).forEach { sec ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(TokyoSurfaceVariant, RoundedCornerShape(4.dp))
                                .clickable {
                                    viewModel.selectSecurity(sec.ticker)
                                    viewModel.selectWorkspace(TerminalWorkspace.SECURITY_MASTER)
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(sec.ticker, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TokyoBlueGlow)
                                    Text(sec.name, style = MaterialTheme.typography.bodyMedium, color = TokyoTextPrimary)
                                }
                                Text(
                                    "${sec.marketSegment.displayName} | ${sec.sector33.sectorName} | 出来高: ${String.format("%,d", sec.volume)}株",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TokyoTextMuted
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    "${String.format("%,.1f", sec.currentPrice)} 円",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TokyoTextPrimary
                                )
                                val isPos = sec.priceChange >= 0
                                Text(
                                    "${if (isPos) "+" else ""}${String.format("%.1f", sec.priceChange)} (${if (isPos) "+" else ""}${String.format("%.2f", sec.changePercent)}%)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isPos) TokyoPositiveGreen else TokyoNegativeRed
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBadge(
    label: String,
    value: String,
    subtext: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = TokyoSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, TokyoGridLine)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, maxLines = 1)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
            Text(subtext, style = MaterialTheme.typography.labelSmall, color = TokyoTextDim)
        }
    }
}

@Composable
private fun BreadthItem(label: String, count: String, percent: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted)
        Text(count, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = color)
        Text(percent, style = MaterialTheme.typography.labelSmall, color = TokyoTextDim)
    }
}

@Composable
private fun SectorCard(
    sector: SectorPerformance,
    modifier: Modifier = Modifier
) {
    val isPos = sector.changePercent >= 0
    val bgColor = if (isPos) TokyoPositiveGreenBg.copy(alpha = 0.4f) else TokyoNegativeRedBg.copy(alpha = 0.4f)
    val accentColor = if (isPos) TokyoPositiveGreen else TokyoNegativeRed

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    sector.sector.sectorName,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = TokyoTextPrimary,
                    maxLines = 1
                )
                Text(
                    "${if (isPos) "+" else ""}${String.format("%.2f", sector.changePercent)}%",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = accentColor
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("代金: ${sector.turnoverBillionJpy}億円", style = MaterialTheme.typography.labelSmall, color = TokyoTextSecondary)
                Text("PER: ${sector.per}倍", style = MaterialTheme.typography.labelSmall, color = TokyoTextSecondary)
            }
            Text("主導: ${sector.leadingTicker}", style = MaterialTheme.typography.labelSmall, color = TokyoTextMuted, maxLines = 1)
        }
    }
}
