package com.example

import com.example.tokyoequity.domain.model.*
import com.example.tokyoequity.engine.ArrowheadMatchingEngine
import com.example.tokyoequity.engine.BlackScholesEngine
import com.example.tokyoequity.engine.PriceLimitEngine
import com.example.tokyoequity.engine.RiskEngine
import com.example.tokyoequity.engine.TickSizeEngine
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testTickSizeEngine() {
        // TOPIX500 Current Ruleset
        val tick1 = TickSizeEngine.getTickSize(2500.0, isTopix500 = true, ruleSet = RuleSetVersion.CURRENT_2026)
        assertEquals(0.5, tick1, 0.001)

        val tick2 = TickSizeEngine.getTickSize(5000.0, isTopix500 = true, ruleSet = RuleSetVersion.CURRENT_2026)
        assertEquals(1.0, tick2, 0.001)

        // 2027 STR Ruleset
        val tickStr = TickSizeEngine.getTickSize(800.0, isTopix500 = true, ruleSet = RuleSetVersion.FUTURE_2027_STR)
        assertEquals(0.1, tickStr, 0.001)
    }

    @Test
    fun testPriceLimitEngine() {
        val limits = PriceLimitEngine.calculateLimits(3000.0)
        assertEquals(3700.0, limits.upperLimit, 0.001)
        assertEquals(2300.0, limits.lowerLimit, 0.001)
        assertTrue(PriceLimitEngine.isWithinLimits(3200.0, 3000.0))
        assertFalse(PriceLimitEngine.isWithinLimits(4000.0, 3000.0))
    }

    @Test
    fun testArrowheadMatchingEngine() {
        val engine = ArrowheadMatchingEngine(ticker = "7203", referencePrice = 3000.0, isTopix500 = true)
        val initialBook = engine.getOrderBook()

        // Invariant: Best Bid < Best Ask
        val bestBid = initialBook.bids.first().price
        val bestAsk = initialBook.asks.first().price
        assertTrue("Best Bid ($bestBid) must be less than Best Ask ($bestAsk)", bestBid < bestAsk)

        // Submit matching limit buy order at best ask
        val buyOrder = Order(
            orderId = "TEST-BUY-1",
            securityTicker = "7203",
            side = OrderSide.BUY,
            orderType = OrderType.LIMIT,
            price = bestAsk,
            quantity = 2000L
        )

        val result = engine.submitOrder(buyOrder)
        assertEquals(OrderStatus.FILLED, result.order.status)
        assertTrue(result.trades.isNotEmpty())
        assertEquals(2000L, result.trades.sumOf { it.quantity })
    }

    @Test
    fun testBlackScholesGreeks() {
        val greeks = BlackScholesEngine.calculate(
            spot = 39000.0,
            strike = 39000.0,
            timeYears = 30.0 / 365.0,
            volatility = 0.20,
            riskFreeRate = 0.0075,
            isCall = true
        )

        assertTrue(greeks.price > 0)
        assertTrue(greeks.delta in 0.45..0.55) // ATM Call Delta ~ 0.50
        assertTrue(greeks.gamma > 0)
        assertTrue(greeks.vega > 0)
        assertTrue(greeks.theta < 0) // Time decay is negative
    }

    @Test
    fun testRiskEngine() {
        val holdings = listOf(
            PortfolioHolding("JP3633400001", "7203", "トヨタ自動車", "EQUITY", 10000L, 2900.0, 3000.0),
            PortfolioHolding("JP3435000009", "6758", "ソニーグループ", "EQUITY", 2000L, 14000.0, 14200.0)
        )
        val risk = RiskEngine.calculatePortfolioRisk(holdings, cashJpy = 10_000_000.0)

        // Invariant: NAV = Cash + Market Value of holdings
        val expectedMarketVal = (10000L * 3000.0) + (2000L * 14200.0) // 30,000,000 + 28,400,000 = 58,400,000
        val expectedNav = 10_000_000.0 + expectedMarketVal
        assertEquals(expectedNav, risk.navJpy, 0.01)
        assertTrue(risk.var95DailyJpy > 0)
        assertTrue(risk.expectedShortfallJpy > risk.var95DailyJpy)
    }
}
