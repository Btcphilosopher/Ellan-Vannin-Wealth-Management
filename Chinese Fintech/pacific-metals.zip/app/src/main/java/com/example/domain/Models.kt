package com.example.domain

import java.math.BigDecimal
import java.util.Date
import java.util.UUID

enum class Metal {
    GOLD, SILVER
}

enum class Currency {
    USD, EUR, GBP, AUD, CAD, CHF, JPY, CNY, HKD, SGD
}

enum class OperatingCenter(val city: String, val focus: String) {
    LOS_ANGELES("Los Angeles", "Bullion, Private clients, Jewellery, Finance, Logistics"),
    SAN_FRANCISCO("San Francisco", "Technology, Family offices, Institutional wealth"),
    SAN_DIEGO("San Diego", "Private clients, Cross-border trade"),
    SACRAMENTO("Sacramento", "Government/business"),
    OAKLAND("Oakland", "Logistics"),
    FRESNO("Fresno", "Central Valley"),
    SAN_JOSE("San Jose", "Technology wealth"),
    LONG_BEACH("Long Beach", "Logistics/import/export"),
    ANAHEIM_OC("Anaheim / Orange County", "Private wealth")
}

enum class CustomerType {
    PERSONAL, PROFESSIONAL, BUSINESS, INSTITUTION, TRUST, RETIREMENT
}

enum class ProductClass {
    BAR, COIN
}

data class Product(
    val id: String,
    val name: String,
    val metal: Metal,
    val productClass: ProductClass,
    val weightOz: BigDecimal,
    val weightGrams: BigDecimal,
    val purity: BigDecimal,
    val refiner: String,
    val fabricationPremium: BigDecimal, // Fixed dollar premium per piece or unit
    val designName: String? = null
)

// Gold and Silver bars represent serialized, fully physical assets
data class PhysicalBar(
    val barId: String,
    val serialNumber: String,
    val metal: Metal,
    val refiner: String,
    val brand: String,
    val purity: BigDecimal,
    val grossWeight: BigDecimal, // in Oz or Grams depending on unit
    val fineWeight: BigDecimal,  // gross * purity
    val unit: String,            // "oz" or "g" or "kg"
    val assayReference: String,
    val manufactureDate: Date,
    val ownerId: String,         // Customer ID or "MERCHANT_INVENTORY"
    val vault: OperatingCenter,
    val vaultPosition: String,   // E.g., "Aisle 4, Grid B2, Drawer 12"
    val allocationStatus: AllocationStatus, // ALLOCATED, UNALLOCATED (unallocated bars in general stock)
    val custodyStatus: CustodyStatus,       // CUSTODY, RELEASED, IN_TRANSIT
    val valuationUsd: BigDecimal,
    val createdAt: Date,
    val updatedAt: Date
)

enum class AllocationStatus {
    ALLOCATED, UNALLOCATED
}

enum class CustodyStatus {
    CUSTODY, RELEASED, IN_TRANSIT
}

// Bulllion Coin architecture representation
data class BullionCoin(
    val coinId: String,
    val name: String,
    val metal: Metal,
    val grossWeightOz: BigDecimal,
    val purity: BigDecimal,
    val faceValue: BigDecimal,
    val legalTenderCountry: String,
    val mintageYear: Int,
    val refiner: String,
    val ownerId: String,
    val vault: OperatingCenter,
    val custodyStatus: CustodyStatus,
    val valuationUsd: BigDecimal
)

// Metal Passports are generated to represent physical title ownership
data class MetalPassport(
    val passportId: String,
    val barIdOrCoinId: String,
    val serialNumber: String,
    val metal: Metal,
    val refiner: String,
    val brand: String,
    val grossWeight: BigDecimal,
    val unit: String,
    val fineWeight: BigDecimal,
    val purity: BigDecimal,
    val assayReference: String,
    val ownerName: String,
    val vault: OperatingCenter,
    val allocationDate: Date,
    val currentStatus: String,
    val movementHistory: List<MovementEvent>
)

data class MovementEvent(
    val timestamp: Date,
    val eventType: String, // "DEPOSIT", "ALLOCATION", "VAULT_TRANSFER", "RELEASE", "SHIPPED"
    val description: String,
    val operatorId: String
)

// Invoices and confirmations are constructed from structured domain data
data class MerchantDocument(
    val documentId: String,
    val documentType: DocumentType,
    val customerName: String,
    val date: Date,
    val lineItems: List<DocLineItem>,
    val subtotal: BigDecimal,
    val premium: BigDecimal,
    val storageFee: BigDecimal,
    val deliveryFee: BigDecimal,
    val taxAmount: BigDecimal,
    val totalAmount: BigDecimal,
    val taxNotes: String,
    val jurisdiction: String
)

enum class DocumentType {
    PURCHASE_CONFIRMATION, SALES_CONFIRMATION, INVOICE, VAULT_STATEMENT, METAL_STATEMENT, OWNERSHIP_STATEMENT, ASSAY_CERTIFICATE, DELIVERY_RECEIPT
}

data class DocLineItem(
    val description: String,
    val qty: Int,
    val unitPrice: BigDecimal,
    val total: BigDecimal
)

// Event sourcing models
data class EventLogEntry(
    val eventId: String = UUID.randomUUID().toString(),
    val eventType: String,
    val timestamp: Date = Date(),
    val entityId: String,
    val payloadJson: String,
    val version: Int = 1
)
