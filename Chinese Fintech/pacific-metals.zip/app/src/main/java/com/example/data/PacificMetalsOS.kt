package com.example.data

import com.example.domain.*
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Date
import java.util.UUID
import kotlin.random.Random
import com.example.domain.Currency

object PacificMetalsOS {

    // --- State variables representing the system database ---
    var cashBalanceUsd = BigDecimal("250000.00") // Starting $250k
    var unallocatedGoldOz = BigDecimal("0.0")
    var unallocatedSilverOz = BigDecimal("0.0")

    var customerKycStatus = KycStatus.APPROVED
    var customerRiskScore = 15
    var activeResaleCertificate: ResaleCertificate? = null

    // Physical items held in Vaults (Allocated)
    val allocatedBars = mutableListOf<PhysicalBar>()
    val complianceCases = mutableListOf<ComplianceCase>()
    val secondhandItems = mutableListOf<SecondhandItem>()
    val documentArchive = mutableListOf<MerchantDocument>()
    val transactionHistory = mutableListOf<OrderRecord>()

    // Fictional Merchant Inventory reserves (for unallocated backing & sell liquidity)
    var merchantGoldReserveOz = BigDecimal("1000.00")
    var merchantSilverReserveOz = BigDecimal("5000.00")

    init {
        // Seed the system with initial items representing realistic premium bullion assets
        seedInitialAssets()
    }

    private fun seedInitialAssets() {
        // Create 2 pre-allocated gold bars for the demo customer
        allocatedBars.add(
            PhysicalBar(
                barId = "CA-AU-000421",
                serialNumber = "PAMP-AU-9999-421",
                metal = Metal.GOLD,
                refiner = "PAMP SA",
                brand = "PAMP Suisse",
                purity = BigDecimal("0.9999"),
                grossWeight = BigDecimal("100.000"), // 100 grams
                fineWeight = BigDecimal("99.990"),
                unit = "g",
                assayReference = "ASSAY-44281",
                manufactureDate = Date(124, 4, 15),
                ownerId = "CLIENT-CAL-94105",
                vault = OperatingCenter.LOS_ANGELES,
                vaultPosition = "Vault A, Row 4, Slot 12",
                allocationStatus = AllocationStatus.ALLOCATED,
                custodyStatus = CustodyStatus.CUSTODY,
                valuationUsd = BigDecimal("17420.00"),
                createdAt = Date(),
                updatedAt = Date()
            )
        )

        allocatedBars.add(
            PhysicalBar(
                barId = "CA-AG-000812",
                serialNumber = "PAMP-AG-9990-812",
                metal = Metal.SILVER,
                refiner = "PAMP SA",
                brand = "PAMP Suisse",
                purity = BigDecimal("0.999"),
                grossWeight = BigDecimal("1000.000"), // 1 kg
                fineWeight = BigDecimal("999.000"),
                unit = "g",
                assayReference = "ASSAY-22104",
                manufactureDate = Date(124, 6, 20),
                ownerId = "CLIENT-CAL-94105",
                vault = OperatingCenter.LOS_ANGELES,
                vaultPosition = "Vault B, Row 2, Slot 8",
                allocationStatus = AllocationStatus.ALLOCATED,
                custodyStatus = CustodyStatus.CUSTODY,
                valuationUsd = BigDecimal("2180.00"),
                createdAt = Date(),
                updatedAt = Date()
            )
        )

        // Seed unallocated accounts
        unallocatedGoldOz = BigDecimal("15.25")
        unallocatedSilverOz = BigDecimal("180.40")

        // Write initial balanced double-entry record to represent cash and metal deposits
        LedgerEngine.recordDoubleEntry(
            txId = "SEED-TX-001",
            debitAccount = LedgerAccount.CASH,
            creditAccount = LedgerAccount.SETTLEMENT,
            amount = cashBalanceUsd,
            unit = "USD",
            description = "Initial seed USD liquidity deposit"
        )
    }

    // --- Pricing Engine Implementation ---
    /**
     * Complete Pricing Engine algorithm:
     * Reference Price (derived from synthetic live feeds)
     * + Product Premium (dealer margins, shape difficulty, fabricator premium)
     * + Vaulting/Storage premium (if stored)
     * + Delivery (if shipped)
     * + California sales/district taxes
     * = Customer Price
     */
    fun calculateQuote(
        metal: Metal,
        productClass: ProductClass,
        weightGrams: BigDecimal,
        qty: Int,
        vaultLocation: OperatingCenter,
        isStorage: Boolean,
        isDelivery: Boolean,
        zipCode: String? = null
    ): PriceQuote {
        val qtyB = BigDecimal(qty.toString())
        val marketQuote = SyntheticMarketDataProvider.getMetalPrice(metal, Currency.USD)
        val referencePricePerOz = marketQuote.ask

        // Weight conversion helper
        val weightOz = weightGrams.divide(BigDecimal("31.1034768"), 8, RoundingMode.HALF_UP)
        val referenceSubtotal = referencePricePerOz.multiply(weightOz).multiply(qtyB)

        // Industry standard dealer premiums and margins
        val premiumRate = if (metal == Metal.GOLD) BigDecimal("0.02") else BigDecimal("0.05") // Gold 2%, Silver 5%
        val dealerMargin = referenceSubtotal.multiply(premiumRate)

        val fabricationPremiumPerPiece = if (productClass == ProductClass.COIN) {
            BigDecimal("15.00") // coins have high minting design premium
        } else {
            BigDecimal("5.00") // bars are industrially simple
        }
        val totalFabPremium = fabricationPremiumPerPiece.multiply(qtyB)

        val storageFee = if (isStorage) {
            BigDecimal("35.00").multiply(qtyB) // Flat vault processing deposit
        } else {
            BigDecimal.ZERO
        }

        val deliveryFee = if (isDelivery) {
            BigDecimal("55.00").multiply(qtyB) // Armed shipping within California
        } else {
            BigDecimal.ZERO
        }

        val totalPreTax = referenceSubtotal.add(dealerMargin).add(totalFabPremium).add(storageFee).add(deliveryFee)

        // Apply California tax calculation rules (Regulation 1599 threshold check is handled inside CaliforniaTaxEngine)
        val taxResult = CaliforniaTaxEngine.calculateCaliforniaTax(
            productMetal = metal,
            productClass = productClass,
            totalTransactionValue = totalPreTax,
            deliveryLocation = vaultLocation,
            resaleCertificate = activeResaleCertificate,
            zipCode = zipCode
        )

        val totalCustomerPrice = totalPreTax.add(taxResult.totalTax)

        return PriceQuote(
            metal = metal,
            qty = qty,
            referencePriceUnit = referencePricePerOz,
            subtotalReference = referenceSubtotal.setScale(2, RoundingMode.HALF_UP),
            dealerMargin = dealerMargin.setScale(2, RoundingMode.HALF_UP),
            fabricationPremium = totalFabPremium.setScale(2, RoundingMode.HALF_UP),
            storageFee = storageFee.setScale(2, RoundingMode.HALF_UP),
            deliveryFee = deliveryFee.setScale(2, RoundingMode.HALF_UP),
            taxAmount = taxResult.totalTax.setScale(2, RoundingMode.HALF_UP),
            totalPrice = totalCustomerPrice.setScale(2, RoundingMode.HALF_UP),
            isExempt = taxResult.isExempt,
            exemptionReason = taxResult.exemptionReason,
            taxRatePercent = taxResult.taxRate.multiply(BigDecimal("100")).setScale(2, RoundingMode.HALF_UP),
            taxLog = taxResult.calculationLog,
            ruleVersion = taxResult.ruleVersion
        )
    }

    // --- Order Placement Experience (BUY) ---
    @Synchronized
    fun executePurchase(
        metal: Metal,
        productClass: ProductClass,
        weightGrams: BigDecimal,
        qty: Int,
        vaultLocation: OperatingCenter,
        isStorage: Boolean,
        isDelivery: Boolean,
        idempotencyKey: String,
        zipCode: String? = null
    ): PurchaseResult {
        // 1. Check if order was already executed using the Idempotency Key
        val cachedRecord = transactionHistory.find { it.idempotencyKey == idempotencyKey }
        if (cachedRecord != null) {
            return PurchaseResult.Success(
                order = cachedRecord,
                message = "Duplicate transaction intercepted by Idempotency engine. Return cached success."
            )
        }

        // 2. Perform fresh calculation quote
        val quote = calculateQuote(metal, productClass, weightGrams, qty, vaultLocation, isStorage, isDelivery, zipCode)

        // 3. Liquidity and KYC Checks
        if (cashBalanceUsd < quote.totalPrice) {
            return PurchaseResult.Error("Insufficient cash funds available. Total needed: $${quote.totalPrice}, Wallet Cash: $${cashBalanceUsd}")
        }
        if (customerKycStatus != KycStatus.APPROVED) {
            return PurchaseResult.Error("Account Compliance Block: KYC Status is currently '${customerKycStatus}'. Transaction restricted.")
        }

        // 4. Evaluate risk
        val transactionRisk = ComplianceEngine.evaluateTransactionRisk(
            customerId = "CLIENT-CAL-94105",
            amount = quote.totalPrice,
            customerType = CustomerType.PERSONAL,
            kycStatus = customerKycStatus,
            isCashLike = false
        )
        if (transactionRisk > 75) {
            // Trigger automatic Compliance Case opened
            val caseId = "CASE-" + UUID.randomUUID().toString().take(6).uppercase()
            complianceCases.add(
                ComplianceCase(
                    caseId = caseId,
                    customerId = "CLIENT-CAL-94105",
                    transactionId = idempotencyKey,
                    flagReason = "Automated high risk score ($transactionRisk/100) triggered during transaction processing",
                    riskRating = "HIGH",
                    status = CaseStatus.OPEN,
                    openedAt = Date(),
                    resolvedAt = null,
                    auditorNotes = "Case pending secondary evaluation by Chief Compliance Officer."
                )
            )
            return PurchaseResult.Error("Compliance Risk Limit Exceeded. Transaction flagged. Opened Case Reference: $caseId")
        }

        // 5. Update Cash Balance and Ledger
        cashBalanceUsd = cashBalanceUsd.subtract(quote.totalPrice).setScale(2, RoundingMode.HALF_UP)

        // Record standard double-entry bookkeeping journal entries
        val txId = "TX-" + UUID.randomUUID().toString().take(8).uppercase()
        LedgerEngine.recordDoubleEntry(
            txId = txId,
            debitAccount = LedgerAccount.CASH,
            creditAccount = LedgerAccount.REVENUE,
            amount = quote.totalPrice,
            unit = "USD",
            description = "Customer purchase of ${qty}x ${weightGrams}g ${metal.name} products"
        )

        // 6. Allocate metal
        val allocatedList = mutableListOf<PhysicalBar>()
        val totalWeightOz = weightGrams.multiply(BigDecimal(qty.toString())).divide(BigDecimal("31.1034768"), 8, RoundingMode.HALF_UP)

        if (isStorage) {
            // Generate serialized allocated Physical bars
            for (i in 1..qty) {
                val serialNum = "PAC-${metal.name.take(2)}-${UUID.randomUUID().toString().take(8).uppercase()}"
                val barId = "CA-${metal.name.take(2)}-" + UUID.randomUUID().toString().take(6).uppercase()
                val newBar = PhysicalBar(
                    barId = barId,
                    serialNumber = serialNum,
                    metal = metal,
                    refiner = "Pacific Refineries Inc (California)",
                    brand = "Pacific Metals Corp",
                    purity = if (metal == Metal.GOLD) BigDecimal("0.9999") else BigDecimal("0.999"),
                    grossWeight = weightGrams,
                    fineWeight = weightGrams.multiply(if (metal == Metal.GOLD) BigDecimal("0.9999") else BigDecimal("0.999")),
                    unit = "g",
                    assayReference = "ASS-REV-${UUID.randomUUID().toString().take(5).uppercase()}",
                    manufactureDate = Date(),
                    ownerId = "CLIENT-CAL-94105",
                    vault = vaultLocation,
                    vaultPosition = "Aisle ${Random.nextInt(1, 10)}, Tray ${Random.nextInt(5, 50)}",
                    allocationStatus = AllocationStatus.ALLOCATED,
                    custodyStatus = CustodyStatus.CUSTODY,
                    valuationUsd = quote.totalPrice.divide(BigDecimal(qty.toString()), 2, RoundingMode.HALF_UP),
                    createdAt = Date(),
                    updatedAt = Date()
                )
                allocatedBars.add(newBar)
                allocatedList.add(newBar)
            }
        } else {
            // Unallocated general account update if client selects physical handoff or standard delivery routing
            if (metal == Metal.GOLD) {
                unallocatedGoldOz = unallocatedGoldOz.add(totalWeightOz).setScale(4, RoundingMode.HALF_UP)
            } else {
                unallocatedSilverOz = unallocatedSilverOz.add(totalWeightOz).setScale(4, RoundingMode.HALF_UP)
            }
        }

        // 7. Archive Invoice document
        val invoiceDoc = MerchantDocument(
            documentId = "INV-$txId",
            documentType = DocumentType.INVOICE,
            customerName = "California Private Client",
            date = Date(),
            lineItems = listOf(
                DocLineItem("Physical ${metal.name} Bullion Allocation (${weightGrams}g, Purity ${if(metal == Metal.GOLD) "999.9" else "999"})", qty, quote.referencePriceUnit, quote.subtotalReference)
            ),
            subtotal = quote.subtotalReference,
            premium = quote.dealerMargin.add(quote.fabricationPremium),
            storageFee = quote.storageFee,
            deliveryFee = quote.deliveryFee,
            taxAmount = quote.taxAmount,
            totalAmount = quote.totalPrice,
            taxNotes = quote.exemptionReason,
            jurisdiction = vaultLocation.city
        )
        documentArchive.add(invoiceDoc)

        val orderRecord = OrderRecord(
            orderId = txId,
            metal = metal,
            productClass = productClass,
            weightGrams = weightGrams,
            qty = qty,
            quote = quote,
            vault = vaultLocation,
            isStorage = isStorage,
            isDelivery = isDelivery,
            idempotencyKey = idempotencyKey,
            createdAt = Date(),
            status = "SETTLED"
        )
        transactionHistory.add(orderRecord)

        return PurchaseResult.Success(
            order = orderRecord,
            message = "Purchase successfully settled. ${if (isStorage) "${qty} physical serialized bars safely placed in ${vaultLocation.city} vault." else "Unallocated metal balance updated."}"
        )
    }

    // --- Order Disposal Experience (SELL) ---
    @Synchronized
    fun executeSale(
        barId: String?, // Null if selling unallocated, or specific serial bar id
        metal: Metal,
        sellOz: BigDecimal,
        idempotencyKey: String
    ): SellResult {
        // Check duplicate
        val cachedRecord = transactionHistory.find { it.idempotencyKey == idempotencyKey }
        if (cachedRecord != null) {
            return SellResult.Success(
                netProceedsUsd = cachedRecord.quote.totalPrice,
                message = "Duplicate transaction intercepted by Idempotency engine. Return cached success."
            )
        }

        val liveQuote = SyntheticMarketDataProvider.getMetalPrice(metal, Currency.USD)
        val dealerBidPerOz = liveQuote.bid

        val isAllocated = barId != null
        var resolvedFineWeightOz = sellOz

        if (isAllocated) {
            val bar = allocatedBars.find { it.barId == barId }
                ?: return SellResult.Error("No physical serialized bar found in vault matching key: $barId")

            // Convert bar weight to Ounces
            val barWeightG = bar.fineWeight
            resolvedFineWeightOz = if (bar.unit == "g") {
                barWeightG.divide(BigDecimal("31.1034768"), 8, RoundingMode.HALF_UP)
            } else {
                bar.fineWeight
            }
            allocatedBars.remove(bar) // Relinquish title
        } else {
            // Sell from unallocated balance
            if (metal == Metal.GOLD) {
                if (unallocatedGoldOz < sellOz) {
                    return SellResult.Error("Unallocated GOLD balance insufficient. Required: $sellOz, Balance: $unallocatedGoldOz")
                }
                unallocatedGoldOz = unallocatedGoldOz.subtract(sellOz)
            } else {
                if (unallocatedSilverOz < sellOz) {
                    return SellResult.Error("Unallocated SILVER balance insufficient. Required: $sellOz, Balance: $unallocatedSilverOz")
                }
                unallocatedSilverOz = unallocatedSilverOz.subtract(sellOz)
            }
        }

        val rawProceeds = dealerBidPerOz.multiply(resolvedFineWeightOz)
        val feeAmount = rawProceeds.multiply(BigDecimal("0.005")) // 0.5% disposal fee
        val netProceeds = rawProceeds.subtract(feeAmount).setScale(2, RoundingMode.HALF_UP)

        // Update customer cash balance
        cashBalanceUsd = cashBalanceUsd.add(netProceeds).setScale(2, RoundingMode.HALF_UP)

        // Journal double-entry logs
        val txId = "SELL-TX-" + UUID.randomUUID().toString().take(8).uppercase()
        LedgerEngine.recordDoubleEntry(
            txId = txId,
            debitAccount = LedgerAccount.SETTLEMENT,
            creditAccount = LedgerAccount.CASH,
            amount = netProceeds,
            unit = "USD",
            description = "Disposal settlement of ${resolvedFineWeightOz.setScale(3, RoundingMode.HALF_UP)} oz of ${metal.name}"
        )

        val emptyQuote = PriceQuote(
            metal = metal,
            qty = 1,
            referencePriceUnit = dealerBidPerOz,
            subtotalReference = rawProceeds,
            dealerMargin = feeAmount,
            fabricationPremium = BigDecimal.ZERO,
            storageFee = BigDecimal.ZERO,
            deliveryFee = BigDecimal.ZERO,
            taxAmount = BigDecimal.ZERO,
            totalPrice = netProceeds,
            isExempt = true,
            exemptionReason = "Bullion disposal is not subject to retail California CDTFA sales tax",
            taxRatePercent = BigDecimal.ZERO,
            taxLog = "Disposal sale evaluated as custom business liquidation.",
            ruleVersion = "v2026.1"
        )

        val orderRecord = OrderRecord(
            orderId = txId,
            metal = metal,
            productClass = ProductClass.BAR,
            weightGrams = resolvedFineWeightOz.multiply(BigDecimal("31.1034768")),
            qty = 1,
            quote = emptyQuote,
            vault = OperatingCenter.LOS_ANGELES,
            isStorage = true,
            isDelivery = false,
            idempotencyKey = idempotencyKey,
            createdAt = Date(),
            status = "EXECUTED"
        )
        transactionHistory.add(orderRecord)

        return SellResult.Success(
            netProceedsUsd = netProceeds,
            message = "Successfully disposed of ${resolvedFineWeightOz.setScale(4, RoundingMode.HALF_UP)} oz ${metal.name}. Settled instantly to USD cash balance."
        )
    }

    // --- California Buyback Desk (Verification, Weighing, Assay Lab) ---
    fun submitBuyback(
        description: String,
        metal: Metal,
        weightGrams: BigDecimal,
        declaredPurity: BigDecimal,
        method: String // "XRF", "Fire Assay", "Density"
    ): BuybackOffer {
        val fineWeightG = weightGrams.multiply(declaredPurity).setScale(3, RoundingMode.HALF_UP)
        val fineWeightOz = fineWeightG.divide(BigDecimal("31.1034768"), 8, RoundingMode.HALF_UP)

        val liveQuote = SyntheticMarketDataProvider.getMetalPrice(metal, Currency.USD)
        val marketPrice = liveQuote.bid

        val rawValue = marketPrice.multiply(fineWeightOz)
        val buybackDiscount = BigDecimal("0.02") // 2% discount on raw scrap jewelry/bullion
        val offerAmount = rawValue.subtract(rawValue.multiply(buybackDiscount)).setScale(2, RoundingMode.HALF_UP)

        val auditLog = "ASSAY: Certified using $method method. Captured Fine Weight: ${fineWeightG}g. Confidence Level: 99.8%. Result: Valid."

        val item = SecondhandItem(
            itemId = "SH-" + UUID.randomUUID().toString().take(6).uppercase(),
            description = description,
            reportedMetal = metal,
            weightGrams = weightGrams,
            purityPercentage = declaredPurity.multiply(BigDecimal("100")),
            sellerName = "California Private Client",
            sellerIdNumber = "CA-DL-F9384821",
            sellerIdType = "CA_DRIVERS_LICENSE",
            fingerprintCaptured = true,
            assayConfidence = BigDecimal("0.998"),
            offeringPrice = offerAmount,
            capssReferenceNumber = "CAPSS-PENDING",
            currentStatus = SecondhandStatus.ACQUIRED_HOLD,
            dateAcquired = Date(),
            holdReleaseDate = Date(System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000)), // 30-day CA hold
            createdByOperatorId = "OPERATOR-ASSAYER-CAL-9"
        )

        return BuybackOffer(
            item = item,
            offerAmount = offerAmount,
            marketBidPrice = marketPrice,
            assayLog = auditLog
        )
    }

    fun acceptBuyback(offer: BuybackOffer) {
        val reportedItem = ComplianceEngine.submitToCAPSS(offer.item)
        secondhandItems.add(reportedItem)

        // Pay the customer
        cashBalanceUsd = cashBalanceUsd.add(offer.offerAmount).setScale(2, RoundingMode.HALF_UP)

        // Write ledger entry
        LedgerEngine.recordDoubleEntry(
            txId = offer.item.itemId,
            debitAccount = LedgerAccount.CASH,
            creditAccount = LedgerAccount.SETTLEMENT,
            amount = offer.offerAmount,
            unit = "USD",
            description = "California Secondhand Dealer CAPSS reported Buyback of ${offer.item.description}"
        )
    }

    // --- Dynamic Portfolio Calculation ---
    fun getPortfolioSnapshot(): PortfolioSnapshot {
        val liveGold = SyntheticMarketDataProvider.getMetalPrice(Metal.GOLD, Currency.USD)
        val liveSilver = SyntheticMarketDataProvider.getMetalPrice(Metal.SILVER, Currency.USD)

        val goldMid = liveGold.mid
        val silverMid = liveSilver.mid

        // Count allocated gold weight
        val allocatedGoldOz = allocatedBars.filter { it.metal == Metal.GOLD }.sumOf {
            if (it.unit == "g") it.fineWeight.divide(BigDecimal("31.1034768"), 8, RoundingMode.HALF_UP)
            else it.fineWeight
        }

        // Count allocated silver weight
        val allocatedSilverOz = allocatedBars.filter { it.metal == Metal.SILVER }.sumOf {
            if (it.unit == "g") it.fineWeight.divide(BigDecimal("31.1034768"), 8, RoundingMode.HALF_UP)
            else it.fineWeight
        }

        val totalGoldOz = allocatedGoldOz.add(unallocatedGoldOz)
        val totalSilverOz = allocatedSilverOz.add(unallocatedSilverOz)

        val goldValuation = totalGoldOz.multiply(goldMid).setScale(2, RoundingMode.HALF_UP)
        val silverValuation = totalSilverOz.multiply(silverMid).setScale(2, RoundingMode.HALF_UP)

        val totalValuation = goldValuation.add(silverValuation).add(cashBalanceUsd)

        // Seeded cost basis assumptions to compute Unrealized P&L
        val estimatedGoldCostBasis = BigDecimal("120000.00")
        val estimatedSilverCostBasis = BigDecimal("10000.00")
        val unrealizedPl = goldValuation.add(silverValuation).subtract(estimatedGoldCostBasis).subtract(estimatedSilverCostBasis)

        return PortfolioSnapshot(
            cashBalance = cashBalanceUsd,
            allocatedGoldOz = allocatedGoldOz,
            unallocatedGoldOz = unallocatedGoldOz,
            totalGoldOz = totalGoldOz,
            allocatedSilverOz = allocatedSilverOz,
            unallocatedSilverOz = unallocatedSilverOz,
            totalSilverOz = totalSilverOz,
            goldValuationUsd = goldValuation,
            silverValuationUsd = silverValuation,
            unrealizedPlUsd = unrealizedPl,
            totalPortfolioValueUsd = totalValuation
        )
    }
}

// --- Companion structures ---
data class PriceQuote(
    val metal: Metal,
    val qty: Int,
    val referencePriceUnit: BigDecimal,
    val subtotalReference: BigDecimal,
    val dealerMargin: BigDecimal,
    val fabricationPremium: BigDecimal,
    val storageFee: BigDecimal,
    val deliveryFee: BigDecimal,
    val taxAmount: BigDecimal,
    val totalPrice: BigDecimal,
    val isExempt: Boolean,
    val exemptionReason: String,
    val taxRatePercent: BigDecimal,
    val taxLog: String,
    val ruleVersion: String
)

sealed class PurchaseResult {
    data class Success(val order: OrderRecord, val message: String) : PurchaseResult()
    data class Error(val message: String) : PurchaseResult()
}

sealed class SellResult {
    data class Success(val netProceedsUsd: BigDecimal, val message: String) : SellResult()
    data class Error(val message: String) : SellResult()
}

data class OrderRecord(
    val orderId: String,
    val metal: Metal,
    val productClass: ProductClass,
    val weightGrams: BigDecimal,
    val qty: Int,
    val quote: PriceQuote,
    val vault: OperatingCenter,
    val isStorage: Boolean,
    val isDelivery: Boolean,
    val idempotencyKey: String,
    val createdAt: Date,
    val status: String
)

data class BuybackOffer(
    val item: SecondhandItem,
    val offerAmount: BigDecimal,
    val marketBidPrice: BigDecimal,
    val assayLog: String
)

data class PortfolioSnapshot(
    val cashBalance: BigDecimal,
    val allocatedGoldOz: BigDecimal,
    val unallocatedGoldOz: BigDecimal,
    val totalGoldOz: BigDecimal,
    val allocatedSilverOz: BigDecimal,
    val unallocatedSilverOz: BigDecimal,
    val totalSilverOz: BigDecimal,
    val goldValuationUsd: BigDecimal,
    val silverValuationUsd: BigDecimal,
    val unrealizedPlUsd: BigDecimal,
    val totalPortfolioValueUsd: BigDecimal
)
