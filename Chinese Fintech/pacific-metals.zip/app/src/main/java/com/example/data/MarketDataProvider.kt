package com.example.data

import com.example.domain.Metal
import com.example.domain.Currency
import com.example.domain.OperatingCenter
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Date
import kotlin.random.Random

data class MarketQuote(
    val metal: Metal,
    val currency: Currency,
    val bid: BigDecimal,
    val ask: BigDecimal,
    val spread: BigDecimal,
    val mid: BigDecimal,
    val changePercent: BigDecimal,
    val timestamp: Date,
    val provider: String,
    val marketStatus: String
)

data class FxQuote(
    val pair: String, // e.g. "USD/EUR"
    val rate: BigDecimal,
    val bid: BigDecimal,
    val ask: BigDecimal,
    val changePercent: BigDecimal,
    val timestamp: Date
)

data class VaultStatus(
    val location: OperatingCenter,
    val capacityKg: BigDecimal,
    val occupiedKg: BigDecimal,
    val availableKg: BigDecimal,
    val goldWeightOz: BigDecimal,
    val silverWeightOz: BigDecimal,
    val allocatedCount: Int,
    val unallocatedCount: Int,
    val securityStatus: String,
    val insuranceStatus: String
)

interface MarketDataProvider {
    fun getMetalPrice(metal: Metal, currency: Currency): MarketQuote
    fun getFxRate(target: Currency): FxQuote
    fun getVaults(): List<VaultStatus>
}

object SyntheticMarketDataProvider : MarketDataProvider {

    private val rand = Random(42) // Replayable Pacific Metals Seed

    // Base market values (mid USD)
    private var goldBaseMid = BigDecimal("5420.80")
    private var silverBaseMid = BigDecimal("68.42")

    // FX base rates vs 1 USD
    private val fxBaseRates = mapOf(
        Currency.USD to BigDecimal("1.0000"),
        Currency.EUR to BigDecimal("0.9125"),
        Currency.GBP to BigDecimal("0.7850"),
        Currency.AUD to BigDecimal("1.4920"),
        Currency.CAD to BigDecimal("1.3540"),
        Currency.CHF to BigDecimal("0.8980"),
        Currency.JPY to BigDecimal("143.5000"),
        Currency.CNY to BigDecimal("7.1250"),
        Currency.HKD to BigDecimal("7.8100"),
        Currency.SGD to BigDecimal("1.3320")
    )

    fun tickPrices() {
        // Simulates realistic random walk ticks
        val goldChange = (rand.nextDouble() - 0.48) * 4.5
        val silverChange = (rand.nextDouble() - 0.47) * 0.15

        goldBaseMid = goldBaseMid.add(BigDecimal(goldChange.toString())).setScale(2, RoundingMode.HALF_UP)
        silverBaseMid = silverBaseMid.add(BigDecimal(silverChange.toString())).setScale(2, RoundingMode.HALF_UP)
    }

    override fun getMetalPrice(metal: Metal, currency: Currency): MarketQuote {
        val baseMid = if (metal == Metal.GOLD) goldBaseMid else silverBaseMid
        val fxRate = fxBaseRates[currency] ?: BigDecimal.ONE

        // Convert base USD mid price to target currency
        val mid = baseMid.multiply(fxRate).setScale(4, RoundingMode.HALF_UP)
        // Spread of 0.25% for gold, 0.45% for silver
        val spreadFactor = if (metal == Metal.GOLD) BigDecimal("0.0025") else BigDecimal("0.0045")
        val halfSpread = mid.multiply(spreadFactor).divide(BigDecimal("2.0"), 4, RoundingMode.HALF_UP)

        val bid = mid.subtract(halfSpread).setScale(2, RoundingMode.HALF_UP)
        val ask = mid.add(halfSpread).setScale(2, RoundingMode.HALF_UP)
        val spread = ask.subtract(bid).setScale(2, RoundingMode.HALF_UP)

        val change = if (metal == Metal.GOLD) BigDecimal("0.72") else BigDecimal("1.31")

        return MarketQuote(
            metal = metal,
            currency = currency,
            bid = bid,
            ask = ask,
            spread = spread,
            mid = mid.setScale(2, RoundingMode.HALF_UP),
            changePercent = change,
            timestamp = Date(),
            provider = "Pacific Metals Direct Bullion Feed (Fictional)",
            marketStatus = "ACTIVE"
        )
    }

    override fun getFxRate(target: Currency): FxQuote {
        val rate = fxBaseRates[target] ?: BigDecimal.ONE
        val spreadVal = rate.multiply(BigDecimal("0.0005"))
        val bid = rate.subtract(spreadVal).setScale(4, RoundingMode.HALF_UP)
        val ask = rate.add(spreadVal).setScale(4, RoundingMode.HALF_UP)

        return FxQuote(
            pair = "USD/${target.name}",
            rate = rate.setScale(4, RoundingMode.HALF_UP),
            bid = bid,
            ask = ask,
            changePercent = BigDecimal("0.12"),
            timestamp = Date()
        )
    }

    // Dynamic state vault network mapping
    override fun getVaults(): List<VaultStatus> {
        return listOf(
            VaultStatus(OperatingCenter.LOS_ANGELES, BigDecimal("25000"), BigDecimal("16840"), BigDecimal("8160"), BigDecimal("24481.25"), BigDecimal("180420.00"), 420, 182, "MAXIMUM_MILITARY_GRADE", "FULLY_INSURED_LLOYDS_LONDON"),
            VaultStatus(OperatingCenter.SAN_FRANCISCO, BigDecimal("15000"), BigDecimal("9450"), BigDecimal("5550"), BigDecimal("12110.82"), BigDecimal("92400.10"), 204, 91, "MAXIMUM_MILITARY_GRADE", "FULLY_INSURED_LLOYDS_LONDON"),
            VaultStatus(OperatingCenter.SAN_DIEGO, BigDecimal("10000"), BigDecimal("6120"), BigDecimal("3880"), BigDecimal("8420.40"), BigDecimal("44200.50"), 110, 48, "MAXIMUM_MILITARY_GRADE", "FULLY_INSURED_LLOYDS_LONDON"),
            VaultStatus(OperatingCenter.ANAHEIM_OC, BigDecimal("12000"), BigDecimal("4820"), BigDecimal("7180"), BigDecimal("5240.10"), BigDecimal("21002.30"), 84, 32, "MAXIMUM_MILITARY_GRADE", "FULLY_INSURED_LLOYDS_LONDON"),
            VaultStatus(OperatingCenter.SACRAMENTO, BigDecimal("8000"), BigDecimal("3120"), BigDecimal("4880"), BigDecimal("3140.20"), BigDecimal("11200.40"), 62, 22, "MAXIMUM_MILITARY_GRADE", "FULLY_INSURED_LLOYDS_LONDON"),
            VaultStatus(OperatingCenter.FRESNO, BigDecimal("5000"), BigDecimal("1240"), BigDecimal("3760"), BigDecimal("1120.00"), BigDecimal("5420.80"), 18, 12, "MAXIMUM_MILITARY_GRADE", "FULLY_INSURED_LLOYDS_LONDON")
        )
    }

    fun applyScenario(scenarioName: String): ScenarioImpact {
        return when (scenarioName) {
            "Gold +10%" -> {
                goldBaseMid = goldBaseMid.multiply(BigDecimal("1.10")).setScale(2, RoundingMode.HALF_UP)
                ScenarioImpact("Gold rises by 10% on geopolitical flight to safety.", goldBaseMid, silverBaseMid)
            }
            "Gold -10%" -> {
                goldBaseMid = goldBaseMid.multiply(BigDecimal("0.90")).setScale(2, RoundingMode.HALF_UP)
                ScenarioImpact("Gold drops 10% following interest rate hikes.", goldBaseMid, silverBaseMid)
            }
            "Silver +25%" -> {
                silverBaseMid = silverBaseMid.multiply(BigDecimal("1.25")).setScale(2, RoundingMode.HALF_UP)
                ScenarioImpact("Silver spikes 25% on industrial solar battery demand.", goldBaseMid, silverBaseMid)
            }
            "Silver -25%" -> {
                silverBaseMid = silverBaseMid.multiply(BigDecimal("0.75")).setScale(2, RoundingMode.HALF_UP)
                ScenarioImpact("Silver retreats 25% due to supply surplus.", goldBaseMid, silverBaseMid)
            }
            "USD strengthens" -> {
                goldBaseMid = goldBaseMid.multiply(BigDecimal("0.95")).setScale(2, RoundingMode.HALF_UP)
                silverBaseMid = silverBaseMid.multiply(BigDecimal("0.95")).setScale(2, RoundingMode.HALF_UP)
                ScenarioImpact("USD DXY rises, causing dollar-denominated metals to decrease 5%.", goldBaseMid, silverBaseMid)
            }
            "USD weakens" -> {
                goldBaseMid = goldBaseMid.multiply(BigDecimal("1.08")).setScale(2, RoundingMode.HALF_UP)
                silverBaseMid = silverBaseMid.multiply(BigDecimal("1.08")).setScale(2, RoundingMode.HALF_UP)
                ScenarioImpact("USD weakens, triggering automatic 8% inflation hedges in gold and silver.", goldBaseMid, silverBaseMid)
            }
            else -> ScenarioImpact("Normal market conditions.", goldBaseMid, silverBaseMid)
        }
    }
}

data class ScenarioImpact(
    val description: String,
    val goldPriceUsd: BigDecimal,
    val silverPriceUsd: BigDecimal
)
