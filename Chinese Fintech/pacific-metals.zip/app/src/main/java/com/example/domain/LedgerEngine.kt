package com.example.domain

import java.math.BigDecimal
import java.util.Date
import java.util.UUID

// Accounts for Double-Entry Bookkeeping
enum class LedgerAccount {
    CASH,               // Total client cash deposited / merchant working capital
    GOLD_UNALLOCATED,   // Customer unallocated gold ounces entitlement
    SILVER_UNALLOCATED, // Customer unallocated silver ounces entitlement
    PHYSICAL_GOLD_VAULT,// Weight of physical gold stored in vault (allocated & unallocated general)
    PHYSICAL_SILVER_VAULT,// Weight of physical silver stored in vault
    CUSTOMER_ALLOCATED_GOLD,  // Customer fully allocated gold title
    CUSTOMER_ALLOCATED_SILVER, // Customer fully allocated silver title
    MERCHANT_INVENTORY_GOLD,   // Merchant owned unallocated gold ounces
    MERCHANT_INVENTORY_SILVER, // Merchant owned unallocated silver ounces
    FEES_RECEIVABLE,
    REVENUE,
    SETTLEMENT,
    TAX_PAYABLE
}

data class LedgerEntry(
    val entryId: String = UUID.randomUUID().toString(),
    val transactionId: String,
    val account: LedgerAccount,
    val debitAmount: BigDecimal,  // Positive means asset increases
    val creditAmount: BigDecimal, // Positive means asset decreases / liability increases
    val unit: String,            // "USD" or "oz" or "g"
    val description: String,
    val timestamp: Date = Date()
)

data class ReconciliationReport(
    val runId: String = "REC-" + UUID.randomUUID().toString().take(8).uppercase(),
    val timestamp: Date = Date(),
    // Core physical metrics
    val totalPhysicalGoldOz: BigDecimal,
    val totalPhysicalSilverOz: BigDecimal,
    // Ledger entitlements
    val totalCustomerAllocatedGoldOz: BigDecimal,
    val totalCustomerUnallocatedGoldOz: BigDecimal,
    val totalMerchantInventoryGoldOz: BigDecimal,
    // Reconciliation outcomes
    val goldMismatch: BigDecimal,
    val silverMismatch: BigDecimal,
    val exceptions: List<String>,
    val status: String // "MATCHED" or "EXCEPTION"
)

object LedgerEngine {

    private val entryLog = mutableListOf<LedgerEntry>()

    fun recordDoubleEntry(
        txId: String,
        debitAccount: LedgerAccount,
        creditAccount: LedgerAccount,
        amount: BigDecimal,
        unit: String,
        description: String
    ): List<LedgerEntry> {
        val debit = LedgerEntry(
            transactionId = txId,
            account = debitAccount,
            debitAmount = amount,
            creditAmount = BigDecimal.ZERO,
            unit = unit,
            description = description
        )
        val credit = LedgerEntry(
            transactionId = txId,
            account = creditAccount,
            debitAmount = BigDecimal.ZERO,
            creditAmount = amount,
            unit = unit,
            description = description
        )
        entryLog.add(debit)
        entryLog.add(credit)
        return listOf(debit, credit)
    }

    fun getEntries(): List<LedgerEntry> = entryLog.toList()

    fun calculateBalance(account: LedgerAccount, unit: String): BigDecimal {
        var total = BigDecimal.ZERO
        for (entry in entryLog) {
            if (entry.account == account && entry.unit == unit) {
                total = total.add(entry.debitAmount).subtract(entry.creditAmount)
            }
        }
        return total
    }

    /**
     * Executes automatic reconciliation between physical vaults, customer ledger accounts, and merchant positions.
     */
    fun performReconciliation(
        physicalGoldBars: List<PhysicalBar>,
        physicalSilverBars: List<PhysicalBar>,
        customerUnallocatedGoldOz: BigDecimal,
        customerUnallocatedSilverOz: BigDecimal,
        merchantGoldOz: BigDecimal,
        merchantSilverOz: BigDecimal
    ): ReconciliationReport {
        // Compute total physical counts in vault
        val totalPhysicalGoldOz = physicalGoldBars.sumOf {
            if (it.unit == "g") it.fineWeight.divide(BigDecimal("31.1034768"), 8, java.math.RoundingMode.HALF_UP)
            else it.fineWeight
        }

        val totalPhysicalSilverOz = physicalSilverBars.sumOf {
            if (it.unit == "g") it.fineWeight.divide(BigDecimal("31.1034768"), 8, java.math.RoundingMode.HALF_UP)
            else it.fineWeight
        }

        // Sum allocated from physical lists where status is ALLOCATED
        val totalAllocatedGoldOz = physicalGoldBars.filter { it.allocationStatus == AllocationStatus.ALLOCATED }.sumOf {
            if (it.unit == "g") it.fineWeight.divide(BigDecimal("31.1034768"), 8, java.math.RoundingMode.HALF_UP)
            else it.fineWeight
        }

        val totalAllocatedSilverOz = physicalSilverBars.filter { it.allocationStatus == AllocationStatus.ALLOCATED }.sumOf {
            if (it.unit == "g") it.fineWeight.divide(BigDecimal("31.1034768"), 8, java.math.RoundingMode.HALF_UP)
            else it.fineWeight
        }

        // Total calculated entitlements: Customer (Allocated + Unallocated) + Merchant Working Reserve
        val totalGoldEntitlements = totalAllocatedGoldOz.add(customerUnallocatedGoldOz).add(merchantGoldOz)
        val totalSilverEntitlements = totalAllocatedSilverOz.add(customerUnallocatedSilverOz).add(merchantSilverOz)

        val goldMismatch = totalPhysicalGoldOz.subtract(totalGoldEntitlements).abs()
        val silverMismatch = totalPhysicalSilverOz.subtract(totalSilverEntitlements).abs()

        val exceptions = mutableListOf<String>()
        if (goldMismatch > BigDecimal("0.001")) {
            exceptions.add("Gold Imbalance detected: Physical vault gold ($totalPhysicalGoldOz oz) does not match total financial entitlements ($totalGoldEntitlements oz). Gap = $goldMismatch oz")
        }
        if (silverMismatch > BigDecimal("0.01")) {
            exceptions.add("Silver Imbalance detected: Physical vault silver ($totalPhysicalSilverOz oz) does not match total financial entitlements ($totalSilverEntitlements oz). Gap = $silverMismatch oz")
        }

        val status = if (exceptions.isEmpty()) "MATCHED" else "EXCEPTION"

        return ReconciliationReport(
            totalPhysicalGoldOz = totalPhysicalGoldOz,
            totalPhysicalSilverOz = totalPhysicalSilverOz,
            totalCustomerAllocatedGoldOz = totalAllocatedGoldOz,
            totalCustomerUnallocatedGoldOz = customerUnallocatedGoldOz,
            totalMerchantInventoryGoldOz = merchantGoldOz,
            goldMismatch = goldMismatch,
            silverMismatch = silverMismatch,
            exceptions = exceptions,
            status = status
        )
    }
}
