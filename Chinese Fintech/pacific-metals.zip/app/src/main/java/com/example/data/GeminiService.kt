package com.example.data

import android.util.Log
import com.example.domain.Metal
import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// Moshi Representation of Gemini API Request & Response payload
data class GeminiPart(
    @Json(name = "text") val text: String
)

data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>
)

data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>,
    @Json(name = "systemInstruction") val systemInstruction: GeminiContent? = null
)

data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent?
)

data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>?
)

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val api: GeminiApi = retrofit.create(GeminiApi::class.java)

    /**
     * Calls Gemini 3.5 API to simulate the secure back-office intelligence desk.
     * Fallbacks to high-quality synthetic rules if the API key is unavailable or empty.
     */
    suspend fun askPacificAi(userMessage: String): String = withContext(Dispatchers.IO) {
        val rawKey = com.example.BuildConfig.GEMINI_API_KEY
        val sanitizedKey = rawKey.trim()

        if (sanitizedKey.isEmpty() || sanitizedKey == "MY_GEMINI_API_KEY" || sanitizedKey == "null") {
            Log.w(TAG, "Gemini API Key is not configured in the Secrets Panel. Falling back to local merchant intelligence simulation.")
            return@withContext simulateLocalPacificAi(userMessage)
        }

        val systemPrompt = """
            You are PACIFIC AI, the intelligent back-office secure client desk for PACIFIC METALS (California Gold & Silver Bullion Merchant Platform).
            You have access to the user's active holdings context:
            - Cash Wallet: $${PacificMetalsOS.cashBalanceUsd} USD
            - Allocated Physical Gold: ${PacificMetalsOS.allocatedBars.filter { it.metal == Metal.GOLD }.size} serialized bars in secure California vaults.
            - Allocated Physical Silver: ${PacificMetalsOS.allocatedBars.filter { it.metal == Metal.SILVER }.size} serialized items.
            - Unallocated Gold: ${PacificMetalsOS.unallocatedGoldOz} oz
            - Unallocated Silver: ${PacificMetalsOS.unallocatedSilverOz} oz
            - California tax rules: qualifying bulk sales above $2,000 are completely exempt from CDTFA sales tax. Under $2,000, standard statewide rate (7.25%) plus local district rates apply.
            
            Respond as a highly experienced, professional, prestigious California wealth administrator. 
            Keep your answers concise, exceptionally accurate, and premium.
            CRITICAL: 
            - Always include a bold legal disclaimer at the bottom: "DISCLAIMER: Fictional simulation only. This is not actual tax, compliance, or financial advice."
            - Never invent fake metals prices or fake tax laws.
            - If asked to execute a trade, remind the user to use the direct BUY/SELL buttons in the app interface for secure cryptographic ledger execution.
        """.trimIndent()

        val request = GeminiRequest(
            contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = userMessage)))),
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = systemPrompt)))
        )

        try {
            val response = api.generateContent(sanitizedKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "Pacific AI is processing your secure inquiry. No direct answer was returned from the node. Please review your balance cards manually."
        } catch (e: Exception) {
            Log.e(TAG, "Network error during Gemini API exchange. Swapped to local core engine.", e)
            simulateLocalPacificAi(userMessage)
        }
    }

    private fun simulateLocalPacificAi(message: String): String {
        val query = message.lowercase(java.util.Locale.ROOT)
        val snapshot = PacificMetalsOS.getPortfolioSnapshot()

        val mainAnswer = when {
            query.contains("gold") || query.contains("worth") -> {
                "Your gold is currently valued at $${snapshot.goldValuationUsd} USD. This consists of ${snapshot.allocatedGoldOz} oz physically allocated across our secure Los Angeles vaults and ${snapshot.unallocatedGoldOz} oz of unallocated liquid metal holdings."
            }
            query.contains("silver") || query.contains("own") -> {
                "You currently hold a total of ${snapshot.totalSilverOz} oz of Silver, valued at $${snapshot.silverValuationUsd} USD, including ${snapshot.allocatedSilverOz} oz fully allocated in vault custody."
            }
            query.contains("bars") || query.contains("allocated") || query.contains("passport") -> {
                val list = PacificMetalsOS.allocatedBars.joinToString("\n") { 
                    "- ${it.serialNumber} (${it.grossWeight}${it.unit} ${it.metal} Purity ${it.purity}) stored in ${it.vault.city}" 
                }
                "Your allocated bar inventory registered in the Pacific double-entry ledger is as follows:\n$list"
            }
            query.contains("tax") || query.contains("cdtfa") || query.contains("bulk") -> {
                "Under California Regulation 1599, qualifying bulk sales of monetized or nonmonetized bullion of $2,000 or more are completely tax-exempt. Transactions under $2,000 are subject to the statewide 7.25% sales tax plus district surtaxes based on your delivery location."
            }
            query.contains("vault") || query.contains("where") -> {
                "Your physical custody items are safely vaulted in our Los Angeles Security Complex under fully-allocated conditions with redundant Lloyd's of London insurance backing."
            }
            else -> {
                "Welcome to PACIFIC AI. Your portfolio total value is $${snapshot.totalPortfolioValueUsd} USD. I can assist you with physical allocation details, California CDTFA tax questions, vault logistics, and invoice analysis."
            }
        }

        return """
            $mainAnswer
            
            **DISCLAIMER: Fictional simulation only. This is not actual tax, compliance, or financial advice.**
        """.trimIndent()
    }
}
