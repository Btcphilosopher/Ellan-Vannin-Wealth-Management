package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// California Modernism & Pacific Coastal Color Palette
val WarmWhite = Color(0xFFFBF9F6)
val Graphite = Color(0xFF242629)
val Black = Color(0xFF121315)
val DeepPacificBlue = Color(0xFF1B365D)
val MutedEucalyptus = Color(0xFF708C7D)
val Sandstone = Color(0xFFD5C4A1)

// Restrained metallic accents
val CalifornianGold = Color(0xFFD4AF37)
val PlatinumSilver = Color(0xFFBAC5CC)

// Dark / Light schemes using dynamic Material 3 configurations
val PrimaryGold = CalifornianGold
val SecondaryBlue = DeepPacificBlue
val AccentEucalyptus = MutedEucalyptus
val BackgroundSand = WarmWhite
val CardGraphite = Color(0xFF1E2124)
val TextDark = Color(0xFF121315)
val TextLight = Color(0xFFFBF9F6)
