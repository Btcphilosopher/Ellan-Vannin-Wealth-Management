package com.example.domain

import java.math.BigDecimal
import java.util.Date

data class TaxRuleVersion(
    val ruleId: String,
    val jurisdiction: String,
    val effectiveFrom: Date,
    val effectiveTo: Date?,
    val productClass: String, // "MONETIZED_BULLION", "NON_MONETIZED_BULLION", "NUMISMATIC_COINS"
    val thresholdAmount: BigDecimal, // $2,000 in California CDTFA Regulation 1599
    val baseStateTaxRate: BigDecimal, // e.g., 0.0725 for 7.25%
    val version: String,
    val sourceReference: String = "CDTFA Regulation 1599"
)

data class TaxJurisdiction(
    val name: String,
    val county: String,
    val stateRate: BigDecimal, // 7.25%
    val districtRate: BigDecimal, // local surtaxes
    val combinedRate: BigDecimal, // state + district
    val zipCodes: List<String>
)

data class ResaleCertificate(
    val sellersPermitNumber: String,
    val businessName: String,
    val businessAddress: String,
    val descriptionOfPurchase: String,
    val declaration: String,
    val signature: String,
    val submissionDate: Date,
    val status: ResaleStatus,
    val notes: String = ""
)

enum class ResaleStatus {
    PENDING, VERIFIED, REJECTED, EXPIRED
}

data class TaxCalculationResult(
    val taxableAmount: BigDecimal,
    val taxRate: BigDecimal,
    val stateTax: BigDecimal,
    val districtTax: BigDecimal,
    val totalTax: BigDecimal,
    val isExempt: Boolean,
    val exemptionReason: String,
    val ruleVersion: String,
    val calculationLog: String
)

object CaliforniaTaxEngine {

    // Versioned rules for CDTFA Regulation 1599
    val activeRules = listOf(
        TaxRuleVersion(
            ruleId = "CA-CDTFA-1599-2026",
            jurisdiction = "California",
            effectiveFrom = Date(120, 0, 1), // Jan 1, 2020
            effectiveTo = null,
            productClass = "ALL_QUALIFYING_BULLION_AND_COINS",
            thresholdAmount = BigDecimal("2000.00"), // CDTFA $2,000 threshold
            baseStateTaxRate = BigDecimal("0.0725"), // 7.25%
            version = "v2026.1"
        )
    )

    // Fictionalized and accurate CDTFA county/city rates for major CA centres
    val jurisdictions = listOf(
        TaxJurisdiction("LOS ANGELES", "Los Angeles County", BigDecimal("0.0725"), BigDecimal("0.0225"), BigDecimal("0.0950"), listOf("90001", "90012", "90025")),
        TaxJurisdiction("SAN FRANCISCO", "San Francisco County", BigDecimal("0.0725"), BigDecimal("0.01375"), BigDecimal("0.08625"), listOf("94102", "94111", "94105")),
        TaxJurisdiction("SAN DIEGO", "San Diego County", BigDecimal("0.0725"), BigDecimal("0.0050"), BigDecimal("0.0775"), listOf("92101", "92109", "92122")),
        TaxJurisdiction("SACRAMENTO", "Sacramento County", BigDecimal("0.0725"), BigDecimal("0.0150"), BigDecimal("0.0875"), listOf("95814", "95816")),
        TaxJurisdiction("OAKLAND", "Alameda County", BigDecimal("0.0725"), BigDecimal("0.0300"), BigDecimal("0.1025"), listOf("94612", "94601")),
        TaxJurisdiction("FRESNO", "Fresno County", BigDecimal("0.0725"), BigDecimal("0.0110"), BigDecimal("0.0835"), listOf("93701", "93721")),
        TaxJurisdiction("SAN JOSE", "Santa Clara County", BigDecimal("0.0725"), BigDecimal("0.02125"), BigDecimal("0.09375"), listOf("95112", "95125")),
        TaxJurisdiction("LONG BEACH", "Los Angeles County", BigDecimal("0.0725"), BigDecimal("0.0300"), BigDecimal("0.1025"), listOf("90802", "90808")),
        TaxJurisdiction("ANAHEIM_OC", "Orange County", BigDecimal("0.0725"), BigDecimal("0.0050"), BigDecimal("0.0775"), listOf("92801", "92805"))
    )

    fun resolveJurisdiction(zip: String?, city: String?): TaxJurisdiction {
        // Fallback or precise resolution
        val normalizedCity = city?.uppercase()?.trim() ?: "LOS ANGELES"
        val foundByCity = jurisdictions.find { it.name == normalizedCity }
        if (foundByCity != null) return foundByCity

        val foundByZip = jurisdictions.find { it.zipCodes.contains(zip?.trim()) }
        if (foundByZip != null) return foundByZip

        // Default to Los Angeles as standard fallback rate
        return jurisdictions.first()
    }

    /**
     * Calculates tax on precious metals transactions in California under CDTFA guidelines.
     * Rules:
     * - Qualifying bulk sales of monetized bullion, non-monetized gold or silver bullion, and
     *   numismatic coins are EXEMPT if the single transaction total is $2,000 or greater.
     * - Under $2,000, they are subject to State Tax (7.25%) + applicable local District Taxes.
     * - If the client has a valid, verified Resale Certificate, the transaction is EXEMPT.
     */
    fun calculateCaliforniaTax(
        productMetal: Metal,
        productClass: ProductClass,
        totalTransactionValue: BigDecimal,
        deliveryLocation: OperatingCenter,
        resaleCertificate: ResaleCertificate? = null,
        zipCode: String? = null
    ): TaxCalculationResult {
        val rule = activeRules.first()
        val jurisdiction = resolveJurisdiction(zipCode, deliveryLocation.name)

        val logBuilder = StringBuilder()
        logBuilder.append("Initiating California CDTFA Tax Evaluation...\n")
        logBuilder.append("Transaction Value: $${totalTransactionValue}\n")
        logBuilder.append("Metal Type: ${productMetal}, Class: ${productClass}\n")
        logBuilder.append("Target Operating Vault: ${deliveryLocation.city}\n")
        logBuilder.append("Resolved Local Jurisdiction: ${jurisdiction.name} (Combined Rate: ${(jurisdiction.combinedRate * BigDecimal("100"))}%)\n")

        // 1. Resale Certificate Exemption check
        if (resaleCertificate != null && resaleCertificate.status == ResaleStatus.VERIFIED) {
            logBuilder.append("Exemption Triggered: Valid California Resale Certificate (${resaleCertificate.sellersPermitNumber}) is registered.\n")
            return TaxCalculationResult(
                taxableAmount = BigDecimal.ZERO,
                taxRate = BigDecimal.ZERO,
                stateTax = BigDecimal.ZERO,
                districtTax = BigDecimal.ZERO,
                totalTax = BigDecimal.ZERO,
                isExempt = true,
                exemptionReason = "Resale Exemption (Certificate Verified)",
                ruleVersion = rule.version,
                calculationLog = logBuilder.toString()
            )
        }

        // 2. CDTFA Bulk Sale Exemption Check (Threshold of $2,000)
        val threshold = rule.thresholdAmount
        if (totalTransactionValue >= threshold) {
            logBuilder.append("Exemption Triggered: Transaction value ($${totalTransactionValue}) meets or exceeds the California CDTFA Bulk Sale threshold of $${threshold}.\n")
            return TaxCalculationResult(
                taxableAmount = BigDecimal.ZERO,
                taxRate = BigDecimal.ZERO,
                stateTax = BigDecimal.ZERO,
                districtTax = BigDecimal.ZERO,
                totalTax = BigDecimal.ZERO,
                isExempt = true,
                exemptionReason = "CDTFA Bulk Sale Threshold Exemption (Transaction >= $2,000)",
                ruleVersion = rule.version,
                calculationLog = logBuilder.toString()
            )
        }

        // 3. Taxable under $2,000
        logBuilder.append("Taxable Transaction: Value is under bulk threshold of $${threshold}.\n")
        val stateTax = totalTransactionValue.multiply(jurisdiction.stateRate)
        val districtTax = totalTransactionValue.multiply(jurisdiction.districtRate)
        val totalTax = stateTax.add(districtTax)

        logBuilder.append("State Tax (7.25%): $${stateTax}\n")
        logBuilder.append("District Tax (${(jurisdiction.districtRate * BigDecimal("100"))}%): $${districtTax}\n")
        logBuilder.append("Total California Sales Tax: $${totalTax}\n")

        return TaxCalculationResult(
            taxableAmount = totalTransactionValue,
            taxRate = jurisdiction.combinedRate,
            stateTax = stateTax,
            districtTax = districtTax,
            totalTax = totalTax,
            isExempt = false,
            exemptionReason = "None (Taxable sale under $2,000 threshold)",
            ruleVersion = rule.version,
            calculationLog = logBuilder.toString()
        )
    }
}
