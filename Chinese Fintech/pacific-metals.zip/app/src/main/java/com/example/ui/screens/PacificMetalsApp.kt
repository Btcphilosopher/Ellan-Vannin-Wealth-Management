package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.domain.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.UUID
import kotlin.random.Random
import com.example.domain.Currency

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PacificMetalsApp() {
    var isDarkTheme by remember { mutableStateOf(true) }
    var activePerspective by remember { mutableStateOf("CUSTOMER") } // "CUSTOMER" or "DEALER"

    MyApplicationTheme(darkTheme = isDarkTheme) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "PACIFIC METALS",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                letterSpacing = 2.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "CALIFORNIA GOLD & SILVER • MERCHANT OS",
                                fontSize = 9.sp,
                                letterSpacing = 1.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    },
                    actions = {
                        // Perspective Selector
                        SingleChoiceSegmentedButtonRow(
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            SegmentedButton(
                                selected = activePerspective == "CUSTOMER",
                                onClick = { activePerspective = "CUSTOMER" },
                                shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                            ) {
                                Text("Customer App", fontSize = 11.sp)
                            }
                            SegmentedButton(
                                selected = activePerspective == "DEALER",
                                onClick = { activePerspective = "DEALER" },
                                shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                            ) {
                                Text("Dealer Terminal", fontSize = 11.sp)
                            }
                        }

                        IconButton(onClick = { isDarkTheme = !isDarkTheme }) {
                            Icon(
                                imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "Toggle Theme"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                if (activePerspective == "CUSTOMER") {
                    CustomerAppView()
                } else {
                    DealerTerminalView()
                }
            }
        }
    }
}

// ==================================================================================
// CUSTOMER VIEW
// ==================================================================================
@Composable
fun CustomerAppView() {
    var currentSubTab by remember { mutableStateOf("HOME") } // HOME, BUY, SELL, VAULT, AI_DESK

    Column(modifier = Modifier.fillMaxSize()) {
        // Simple Bottom/Sub Navigation for Customer App
        NavigationBar(
            containerColor = MaterialTheme.colorScheme.surface,
            modifier = Modifier.height(64.dp)
        ) {
            NavigationBarItem(
                selected = currentSubTab == "HOME",
                onClick = { currentSubTab = "HOME" },
                icon = { Icon(Icons.Default.Home, "Home") },
                label = { Text("Home", fontSize = 10.sp) }
            )
            NavigationBarItem(
                selected = currentSubTab == "BUY",
                onClick = { currentSubTab = "BUY" },
                icon = { Icon(Icons.Default.AddShoppingCart, "Buy") },
                label = { Text("Buy", fontSize = 10.sp) }
            )
            NavigationBarItem(
                selected = currentSubTab == "SELL",
                onClick = { currentSubTab = "SELL" },
                icon = { Icon(Icons.Default.Sell, "Sell") },
                label = { Text("Sell", fontSize = 10.sp) }
            )
            NavigationBarItem(
                selected = currentSubTab == "VAULT",
                onClick = { currentSubTab = "VAULT" },
                icon = { Icon(Icons.Default.DoorSliding, "Vault") },
                label = { Text("My Vault", fontSize = 10.sp) }
            )
            NavigationBarItem(
                selected = currentSubTab == "AI_DESK",
                onClick = { currentSubTab = "AI_DESK" },
                icon = { Icon(Icons.Default.SmartToy, "Pacific AI") },
                label = { Text("Pacific AI", fontSize = 10.sp) }
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(16.dp)
        ) {
            when (currentSubTab) {
                "HOME" -> CustomerHomeView(
                    onNavigateToBuy = { currentSubTab = "BUY" },
                    onNavigateToSell = { currentSubTab = "SELL" },
                    onNavigateToVault = { currentSubTab = "VAULT" }
                )
                "BUY" -> CustomerBuyView()
                "SELL" -> CustomerSellView()
                "VAULT" -> CustomerVaultView()
                "AI_DESK" -> CustomerAiDeskView()
            }
        }
    }
}

@Composable
fun CustomerHomeView(
    onNavigateToBuy: () -> Unit,
    onNavigateToSell: () -> Unit,
    onNavigateToVault: () -> Unit
) {
    // Collect updated prices periodically
    var ticker by remember { mutableStateOf(0) }
    LaunchedEffect(key1 = ticker) {
        kotlinx.coroutines.delay(4000)
        SyntheticMarketDataProvider.tickPrices()
        ticker++
    }

    val goldQuote = SyntheticMarketDataProvider.getMetalPrice(Metal.GOLD, Currency.USD)
    val silverQuote = SyntheticMarketDataProvider.getMetalPrice(Metal.SILVER, Currency.USD)
    val portfolio = PacificMetalsOS.getPortfolioSnapshot()

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Hero Header Panel (California Coast Modernism inspired)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                DeepPacificBlue,
                                Color(0xFF13233F)
                            )
                        )
                    )
                    .padding(24.dp)
            ) {
                Column {
                    Text(
                        "PACIFIC METALS",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = CalifornianGold,
                        letterSpacing = 3.sp
                    )
                    Text(
                        "California Private Bullion Depository",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        "TOTAL PORTFOLIO VALUATION",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = CalifornianGold
                    )
                    Text(
                        "$${String.format("%,.2f", portfolio.totalPortfolioValueUsd)} USD",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Row(
                        modifier = Modifier.padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MutedEucalyptus)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "PHYSICALLY ALLOCATED",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Unrealized P&L: +$${String.format("%,.2f", portfolio.unrealizedPlUsd)}",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // Live Market Cards with micro charts
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Gold Card
                MarketCard(
                    metal = "GOLD",
                    symbol = "XAU/USD",
                    price = "$${String.format("%,.2f", goldQuote.mid)}",
                    change = "+${goldQuote.changePercent}%",
                    chartColor = CalifornianGold,
                    modifier = Modifier.weight(1f)
                )

                // Silver Card
                MarketCard(
                    metal = "SILVER",
                    symbol = "XAG/USD",
                    price = "$${String.format("%,.2f", silverQuote.mid)}",
                    change = "+${silverQuote.changePercent}%",
                    chartColor = PlatinumSilver,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Command Buttons
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    QuickActionButton(
                        icon = Icons.Default.ShoppingCart,
                        label = "BUY GOLD",
                        onClick = onNavigateToBuy,
                        testTag = "buy_gold_btn"
                    )
                    QuickActionButton(
                        icon = Icons.Default.CurrencyExchange,
                        label = "SELL METAL",
                        onClick = onNavigateToSell,
                        testTag = "sell_metal_btn"
                    )
                    QuickActionButton(
                        icon = Icons.Default.Security,
                        label = "MY VAULT",
                        onClick = onNavigateToVault,
                        testTag = "my_vault_btn"
                    )
                }
            }
        }

        // Holding breakdown list
        item {
            Text(
                "HOLDING ASSETS SUMMARY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            AssetRow(
                name = "Allocated Physical Gold",
                balance = "${portfolio.allocatedGoldOz.setScale(3, RoundingMode.HALF_UP)} oz",
                value = "$${String.format("%,.2f", portfolio.allocatedGoldOz.multiply(goldQuote.mid))}",
                subtitle = "${PacificMetalsOS.allocatedBars.filter { it.metal == Metal.GOLD }.size} Bars Vaulted in LA Secure Facility",
                color = CalifornianGold
            )
        }

        item {
            AssetRow(
                name = "Allocated Physical Silver",
                balance = "${portfolio.allocatedSilverOz.setScale(3, RoundingMode.HALF_UP)} oz",
                value = "$${String.format("%,.2f", portfolio.allocatedSilverOz.multiply(silverQuote.mid))}",
                subtitle = "${PacificMetalsOS.allocatedBars.filter { it.metal == Metal.SILVER }.size} Bars Vaulted in LA Secure Facility",
                color = PlatinumSilver
            )
        }

        item {
            AssetRow(
                name = "Liquid Unallocated Gold",
                balance = "${portfolio.unallocatedGoldOz} oz",
                value = "$${String.format("%,.2f", portfolio.unallocatedGoldOz.multiply(goldQuote.mid))}",
                subtitle = "Digital title backed by general reserve stock",
                color = CalifornianGold.copy(alpha = 0.7f)
            )
        }

        item {
            AssetRow(
                name = "Liquid Unallocated Silver",
                balance = "${portfolio.unallocatedSilverOz} oz",
                value = "$${String.format("%,.2f", portfolio.unallocatedSilverOz.multiply(silverQuote.mid))}",
                subtitle = "Digital title backed by general reserve stock",
                color = PlatinumSilver.copy(alpha = 0.7f)
            )
        }

        item {
            AssetRow(
                name = "USD Cash Liquidity",
                balance = "$${String.format("%,.2f", portfolio.cashBalance)} USD",
                value = "$${String.format("%,.2f", portfolio.cashBalance)}",
                subtitle = "Ready cash balance for instant settlements",
                color = MutedEucalyptus
            )
        }
    }
}

@Composable
fun MarketCard(
    metal: String,
    symbol: String,
    price: String,
    change: String,
    chartColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier.border(0.5.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    metal,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Text(
                    change,
                    color = MutedEucalyptus,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                symbol,
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                price,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Micro canvas line chart
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .padding(top = 8.dp)
            ) {
                val path = Path()
                path.moveTo(0f, size.height * 0.8f)
                path.lineTo(size.width * 0.25f, size.height * 0.75f)
                path.lineTo(size.width * 0.5f, size.height * 0.4f)
                path.lineTo(size.width * 0.75f, size.height * 0.45f)
                path.lineTo(size.width, size.height * 0.1f)

                drawPath(
                    path = path,
                    color = chartColor,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }
}

@Composable
fun QuickActionButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .clickable { onClick() }
            .testTag(testTag)
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )
    }
}

@Composable
fun AssetRow(
    name: String,
    balance: String,
    value: String,
    subtitle: String,
    color: Color
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .border(0.5.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(balance, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(value, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ==================================================================================
// BUY SCREEN
// ==================================================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerBuyView() {
    val coroutineScope = rememberCoroutineScope()
    var selectedMetal by remember { mutableStateOf(Metal.GOLD) }
    var selectedClass by remember { mutableStateOf(ProductClass.BAR) }
    var selectedWeightGrams by remember { mutableStateOf(BigDecimal("100.0")) } // 100g base
    var quantity by remember { mutableStateOf(1) }
    var activeVault by remember { mutableStateOf(OperatingCenter.LOS_ANGELES) }
    var isStorage by remember { mutableStateOf(true) }
    var zipCodeInput by remember { mutableStateOf("90012") }

    // Dynamic Quote State
    var activeQuote by remember { mutableStateOf<PriceQuote?>(null) }
    var alertMessage by remember { mutableStateOf<String?>(null) }
    var isErrorState by remember { mutableStateOf(false) }

    // Run dynamic recalculations on state parameters changed
    LaunchedEffect(selectedMetal, selectedClass, selectedWeightGrams, quantity, activeVault, isStorage, zipCodeInput) {
        activeQuote = PacificMetalsOS.calculateQuote(
            metal = selectedMetal,
            productClass = selectedClass,
            weightGrams = selectedWeightGrams,
            qty = quantity,
            vaultLocation = activeVault,
            isStorage = isStorage,
            isDelivery = !isStorage,
            zipCode = zipCodeInput
        )
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                "PREMIUM BULLION ACQUISITION",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
            Text(
                "Authorized pricing engine with real-time California CDTFA tax evaluation.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }

        // Metal Selection Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        selectedMetal = Metal.GOLD
                        selectedWeightGrams = BigDecimal("100.0")
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedMetal == Metal.GOLD) CalifornianGold else MaterialTheme.colorScheme.surface,
                        contentColor = if (selectedMetal == Metal.GOLD) Black else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Icon(Icons.Default.WorkspacePremium, null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("GOLD")
                }

                Button(
                    onClick = {
                        selectedMetal = Metal.SILVER
                        selectedWeightGrams = BigDecimal("1000.0") // 1kg
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedMetal == Metal.SILVER) PlatinumSilver else MaterialTheme.colorScheme.surface,
                        contentColor = if (selectedMetal == Metal.SILVER) Black else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Icon(Icons.Default.WorkspacePremium, null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("SILVER")
                }
            }
        }

        // Product Form Controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Product Configuration", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    // Class: Bar / Coin
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Type", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                FilterChip(
                                    selected = selectedClass == ProductClass.BAR,
                                    onClick = { selectedClass = ProductClass.BAR },
                                    label = { Text("Bullion Bar") }
                                )
                                FilterChip(
                                    selected = selectedClass == ProductClass.COIN,
                                    onClick = { selectedClass = ProductClass.COIN },
                                    label = { Text("Monetized Coin") }
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Quantity", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { if (quantity > 1) quantity-- }) {
                                    Icon(Icons.Default.Remove, "Remove")
                                }
                                Text("$quantity", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp))
                                IconButton(onClick = { quantity++ }) {
                                    Icon(Icons.Default.Add, "Add")
                                }
                            }
                        }
                    }

                    // Weight Picker
                    Text("Product Specifications", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val goldWeights = listOf(
                            "10 g" to BigDecimal("10.0"),
                            "50 g" to BigDecimal("50.0"),
                            "100 g" to BigDecimal("100.0"),
                            "1 oz" to BigDecimal("31.1035"),
                            "1 kg" to BigDecimal("1000.0")
                        )
                        val silverWeights = listOf(
                            "1 oz" to BigDecimal("31.1035"),
                            "10 oz" to BigDecimal("311.035"),
                            "1 kg" to BigDecimal("1000.0"),
                            "5 kg" to BigDecimal("5000.0")
                        )
                        val weightsToUse = if (selectedMetal == Metal.GOLD) goldWeights else silverWeights

                        weightsToUse.forEach { (label, value) ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (selectedWeightGrams == value) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.background)
                                    .border(1.dp, if (selectedWeightGrams == value) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(6.dp))
                                    .clickable { selectedWeightGrams = value }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Logistics & Tax Parameters
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Logistics & Tax Parameters", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    // Store / Ship Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { isStorage = true },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isStorage) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.background,
                                contentColor = if (isStorage) Black else MaterialTheme.colorScheme.onSurface
                            )
                        ) {
                            Text("Store in Vault", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { isStorage = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isStorage) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.background,
                                contentColor = if (!isStorage) Black else MaterialTheme.colorScheme.onSurface
                            )
                        ) {
                            Text("Direct Delivery", fontSize = 11.sp)
                        }
                    }

                    // Vault location selector
                    Text("Operating Custody Center", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val centres = listOf(OperatingCenter.LOS_ANGELES, OperatingCenter.SAN_FRANCISCO, OperatingCenter.SAN_DIEGO)
                        centres.forEach { center ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (activeVault == center) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.background)
                                    .border(1.dp, if (activeVault == center) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(6.dp))
                                    .clickable { activeVault = center }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(center.city, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // ZIP Code Input for District tax resolving
                    TextField(
                        value = zipCodeInput,
                        onValueChange = { zipCodeInput = it },
                        label = { Text("California Delivery ZIP Code") },
                        maxLines = 1,
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            }
        }

        // Quote breakdown display
        activeQuote?.let { quote ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("PRICING ENGINE AUDIT TRAIL", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                        QuoteLineItem("Reference Base Metal Price", "$${String.format("%,.2f", quote.referencePriceUnit)} / oz")
                        QuoteLineItem("Aggregated Subtotal (${selectedWeightGrams}g x $quantity)", "$${String.format("%,.2f", quote.subtotalReference)}")
                        QuoteLineItem("Merchant premium & processing", "+$${String.format("%,.2f", quote.dealerMargin)}")
                        QuoteLineItem("Fabrication/Minting Premium", "+$${String.format("%,.2f", quote.fabricationPremium)}")
                        QuoteLineItem("Vaulting initial deposit fee", "+$${String.format("%,.2f", quote.storageFee)}")
                        QuoteLineItem("California Secure Dispatch", "+$${String.format("%,.2f", quote.deliveryFee)}")

                        Divider(modifier = Modifier.padding(vertical = 4.dp))

                        QuoteLineItem("California CDTFA Tax (${quote.taxRatePercent}%)", "+$${String.format("%,.2f", quote.taxAmount)}")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("CDTFA Status:", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (quote.isExempt) MutedEucalyptus else CalifornianGold.copy(alpha = 0.3f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    if (quote.isExempt) "EXEMPT" else "TAXABLE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                        Text(
                            quote.exemptionReason,
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            textAlign = TextAlign.End,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Divider(modifier = Modifier.padding(vertical = 4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("TOTAL CUSTOMER PAYABLE", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                "$${String.format("%,.2f", quote.totalPrice)} USD",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        // Transaction Trigger Button
        item {
            var isLoading by remember { mutableStateOf(false) }

            Button(
                onClick = {
                    isLoading = true
                    coroutineScope.launch {
                        // Generate deterministic unique idempotency key
                        val iKey = "IDEM-${UUID.randomUUID()}"
                        val res = PacificMetalsOS.executePurchase(
                            metal = selectedMetal,
                            productClass = selectedClass,
                            weightGrams = selectedWeightGrams,
                            qty = quantity,
                            vaultLocation = activeVault,
                            isStorage = isStorage,
                            isDelivery = !isStorage,
                            idempotencyKey = iKey,
                            zipCode = zipCodeInput
                        )
                        isLoading = false
                        when (res) {
                            is PurchaseResult.Success -> {
                                alertMessage = res.message
                                isErrorState = false
                            }
                            is PurchaseResult.Error -> {
                                alertMessage = res.message
                                isErrorState = true
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("execute_purchase_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                enabled = !isLoading && activeQuote != null
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Black, modifier = Modifier.size(24.dp))
                } else {
                    Text("AUTHORIZE LEDGER PURCHASE", fontWeight = FontWeight.Bold, color = Black)
                }
            }
        }

        // Result notification
        alertMessage?.let { msg ->
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isErrorState) MaterialTheme.colorScheme.errorContainer else MutedEucalyptus.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isErrorState) Icons.Default.ErrorOutline else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (isErrorState) MaterialTheme.colorScheme.error else MutedEucalyptus
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                if (isErrorState) "PURCHASE DECLINED" else "PURCHASE SUCCESSFUL",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isErrorState) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                            )
                            Text(msg, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuoteLineItem(label: String, valStr: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Text(valStr, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ==================================================================================
// SELL SCREEN
// ==================================================================================
@Composable
fun CustomerSellView() {
    var selectedBarId by remember { mutableStateOf<String?>(null) }
    var sellUnallocatedAmount by remember { mutableStateOf("1.0") }
    var isSellingUnallocated by remember { mutableStateOf(false) }

    var alertMessage by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    val portfolio = PacificMetalsOS.getPortfolioSnapshot()
    val liveGoldPrice = SyntheticMarketDataProvider.getMetalPrice(Metal.GOLD, Currency.USD).bid
    val liveSilverPrice = SyntheticMarketDataProvider.getMetalPrice(Metal.SILVER, Currency.USD).bid

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                "LIQUIDATE PRECIOUS METALS",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
            Text(
                "Instantly liquidate physical allocated bars or unallocated liquid metal holdings into active cash balances.",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }

        // Sell Method chooser
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { isSellingUnallocated = false },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!isSellingUnallocated) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                        contentColor = if (!isSellingUnallocated) Black else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Text("Liquidate Serialized Bars", fontSize = 11.sp)
                }

                Button(
                    onClick = { isSellingUnallocated = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSellingUnallocated) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                        contentColor = if (isSellingUnallocated) Black else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Text("Liquidate Unallocated", fontSize = 11.sp)
                }
            }
        }

        if (!isSellingUnallocated) {
            // Serialized Bar List to choose from
            item {
                Text("Select Serialized Vault Bar Title", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            if (PacificMetalsOS.allocatedBars.isEmpty()) {
                item {
                    Text("No physical allocated bars registered. Purchase bars first to store them physically in the vault.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                }
            } else {
                items(PacificMetalsOS.allocatedBars) { bar ->
                    val isSelected = selectedBarId == bar.barId
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedBarId = bar.barId }
                            .border(
                                1.dp,
                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f),
                                RoundedCornerShape(8.dp)
                            )
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = null,
                                tint = if (bar.metal == Metal.GOLD) CalifornianGold else PlatinumSilver,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(bar.serialNumber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("${bar.grossWeight}${bar.unit} of Fine ${bar.metal.name} (Purity ${bar.purity})", fontSize = 10.sp)
                                Text("Stored: ${bar.vault.city} Vault", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                            }
                            Text(
                                if (bar.metal == Metal.GOLD) "GOLD" else "SILVER",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                color = if (bar.metal == Metal.GOLD) CalifornianGold else PlatinumSilver
                            )
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        selectedBarId?.let { bId ->
                            val res = PacificMetalsOS.executeSale(
                                barId = bId,
                                metal = Metal.GOLD, // resolved by engine
                                sellOz = BigDecimal.ZERO,
                                idempotencyKey = "DISP-${UUID.randomUUID()}"
                            )
                            selectedBarId = null
                            when (res) {
                                is SellResult.Success -> {
                                    alertMessage = res.message
                                    isError = false
                                }
                                is SellResult.Error -> {
                                    alertMessage = res.message
                                    isError = true
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = selectedBarId != null
                ) {
                    Text("CONFIRM INSTANT DISPOSAL SETTLEMENT", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            // Unallocated liquidation controls
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Unallocated Disposal Form", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                        Text("Select Asset Type", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        var metalChoice by remember { mutableStateOf(Metal.GOLD) }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { metalChoice = Metal.GOLD },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (metalChoice == Metal.GOLD) CalifornianGold else MaterialTheme.colorScheme.background,
                                    contentColor = if (metalChoice == Metal.GOLD) Black else MaterialTheme.colorScheme.onSurface
                                )
                            ) {
                                Text("Gold Account (${portfolio.unallocatedGoldOz} oz)")
                            }
                            Button(
                                onClick = { metalChoice = Metal.SILVER },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (metalChoice == Metal.SILVER) PlatinumSilver else MaterialTheme.colorScheme.background,
                                    contentColor = if (metalChoice == Metal.SILVER) Black else MaterialTheme.colorScheme.onSurface
                                )
                            ) {
                                Text("Silver Account (${portfolio.unallocatedSilverOz} oz)")
                            }
                        }

                        TextField(
                            value = sellUnallocatedAmount,
                            onValueChange = { sellUnallocatedAmount = it },
                            label = { Text("Amount to Liquidate (Ounces)") },
                            maxLines = 1,
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                        )

                        val currentPrice = if (metalChoice == Metal.GOLD) liveGoldPrice else liveSilverPrice
                        Text("Current Dealer Buyback Bid Rate: $${String.format("%,.2f", currentPrice)} USD / oz", fontSize = 11.sp, color = MutedEucalyptus, fontWeight = FontWeight.Bold)

                        Button(
                            onClick = {
                                try {
                                    val amt = BigDecimal(sellUnallocatedAmount)
                                    val res = PacificMetalsOS.executeSale(
                                        barId = null,
                                        metal = metalChoice,
                                        sellOz = amt,
                                        idempotencyKey = "DISP-${UUID.randomUUID()}"
                                    )
                                    when (res) {
                                        is SellResult.Success -> {
                                            alertMessage = res.message
                                            isError = false
                                        }
                                        is SellResult.Error -> {
                                            alertMessage = res.message
                                            isError = true
                                        }
                                    }
                                } catch (e: Exception) {
                                    alertMessage = "Invalid amount entered."
                                    isError = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("LIQUIDATE UNALLOCATED POSITION")
                        }
                    }
                }
            }
        }

        alertMessage?.let { msg ->
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isError) MaterialTheme.colorScheme.errorContainer else MutedEucalyptus.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isError) Icons.Default.ErrorOutline else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (isError) MaterialTheme.colorScheme.error else MutedEucalyptus
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(msg, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

// ==================================================================================
// VAULT VIEW
// ==================================================================================
@Composable
fun CustomerVaultView() {
    var selectedPassportBar by remember { mutableStateOf<PhysicalBar?>(null) }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(
            "CUSTODY VAULT DIGITAL LEDGER",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.primary,
            letterSpacing = 1.sp
        )

        if (selectedPassportBar == null) {
            Text("Select an allocated bar below to view its secure, cryptographic Metal Passport & physical custody provenance record.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (PacificMetalsOS.allocatedBars.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No physically allocated serialized bars currently held in vault storage.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                        }
                    }
                } else {
                    items(PacificMetalsOS.allocatedBars) { bar ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(0.5.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .clickable { selectedPassportBar = bar }
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.WorkspacePremium,
                                    null,
                                    tint = if (bar.metal == Metal.GOLD) CalifornianGold else PlatinumSilver,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(bar.serialNumber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Refiner: ${bar.refiner} • Assay: ${bar.assayReference}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                    Text("Vault Location: ${bar.vault.city}", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                                }
                                Icon(Icons.Default.ArrowForwardIos, null, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        } else {
            // Beautiful Passport view
            val bar = selectedPassportBar!!
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CalifornianGold, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "PACIFIC METALS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 2.sp,
                            color = CalifornianGold
                        )
                        IconButton(onClick = { selectedPassportBar = null }) {
                            Icon(Icons.Default.Close, "Close")
                        }
                    }

                    Text(
                        "GOLD PASSPORT",
                        fontWeight = FontWeight.Black,
                        fontSize = 24.sp,
                        letterSpacing = 1.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Divider(color = CalifornianGold)

                    PassportField("Bar ID / Node Key", bar.barId)
                    PassportField("Serial Number", bar.serialNumber)
                    PassportField("Gross Weight", "${bar.grossWeight} g")
                    PassportField("Fine Content", "${bar.fineWeight} g Fine Gold")
                    PassportField("Purity Verification", "${bar.purity} (999.9 Fine)")
                    PassportField("Certified Assayer Ref", bar.assayReference)
                    PassportField("Vault Custody Node", bar.vault.city)
                    PassportField("Physical Storage Position", bar.vaultPosition)
                    PassportField("Custody Title Owner", "Verified Client Profile")
                    PassportField("Custody Status", "PHYSICALLY ALLOCATED")

                    Divider(color = CalifornianGold.copy(alpha = 0.3f))

                    Text(
                        "CRYPTOGRAPHIC PROVENANCE LOG",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CalifornianGold
                    )
                    Text("- DEPOSIT: Assayer check complete. Vault position assigned.", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("- TITLE_ASSIGNED: Fully allocated to verified private client custody ledger.", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("- RECONCILED: Morning physical vault reconciler audit success.", fontSize = 9.sp, fontFamily = FontFamily.Monospace)

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(MutedEucalyptus.copy(alpha = 0.15f))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.QrCodeScanner, null, tint = MutedEucalyptus)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SECURE QR CODE STAMP VERIFIED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MutedEucalyptus)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PassportField(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

// ==================================================================================
// PACIFIC AI SCREEN
// ==================================================================================
@Composable
fun CustomerAiDeskView() {
    val coroutineScope = rememberCoroutineScope()
    var userText by remember { mutableStateOf("") }
    val chatMessages = remember { mutableStateListOf<Pair<String, String>>() } // Pair of "SENDER" to "TEXT"
    var isThinking by remember { mutableStateOf(false) }

    if (chatMessages.isEmpty()) {
        chatMessages.add("PACIFIC_AI" to "Greetings. I am PACIFIC AI, your secure private administrative intelligence node. Ask me about your physical allocated bars, unallocated accounts, simulated California CDTFA tax regulations, or current portfolio value.")
    }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            "PACIFIC AI ADMINISTRATIVE PORTAL",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.primary,
            letterSpacing = 1.sp
        )

        // Chat message area
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(0.5.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(chatMessages) { (sender, text) ->
                    val isAi = sender == "PACIFIC_AI"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isAi) Arrangement.Start else Arrangement.End
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isAi) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                                .border(0.5.dp, if (isAi) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                                .widthIn(max = 280.dp)
                        ) {
                            Column {
                                Text(
                                    if (isAi) "PACIFIC AI" else "CLIENT",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isAi) CalifornianGold else MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text, fontSize = 11.sp, lineHeight = 16.sp)
                            }
                        }
                    }
                }

                if (isThinking) {
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.background)
                                    .padding(12.dp)
                            ) {
                                Text("Assessing vault state...", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }

        // Suggested Queries quick chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val suggestions = listOf("Show allocated bars", "Explain California bulk tax rules", "What is my gold worth?")
            suggestions.forEach { query ->
                Box(
                    modifier = Modifier
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                        .clickable {
                            userText = query
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(query, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Text input bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextField(
                value = userText,
                onValueChange = { userText = it },
                placeholder = { Text("Ask Pacific AI administrative desk...", fontSize = 12.sp) },
                maxLines = 2,
                modifier = Modifier.weight(1f)
            )

            IconButton(
                onClick = {
                    if (userText.trim().isNotEmpty()) {
                        val userMsg = userText
                        chatMessages.add("CLIENT" to userMsg)
                        userText = ""
                        isThinking = true
                        coroutineScope.launch {
                            val aiResponse = GeminiClient.askPacificAi(userMsg)
                            isThinking = false
                            chatMessages.add("PACIFIC_AI" to aiResponse)
                        }
                    }
                },
                enabled = !isThinking && userText.trim().isNotEmpty()
            ) {
                Icon(Icons.Default.Send, "Send")
            }
        }
    }
}

// ==================================================================================
// DEALER TERMINAL VIEW
// ==================================================================================
@Composable
fun DealerTerminalView() {
    var activeBackOfficeTab by remember { mutableStateOf("MARKET") } // MARKET, VAULT_TWIN, BUYBACK, COMPLIANCE, SCENARIO, CLI

    Column(modifier = Modifier.fillMaxSize()) {
        // Back office Navigation Row (Scrollable or simple Grid)
        ScrollableTabRow(
            selectedTabIndex = when (activeBackOfficeTab) {
                "MARKET" -> 0
                "VAULT_TWIN" -> 1
                "BUYBACK" -> 2
                "COMPLIANCE" -> 3
                "SCENARIO" -> 4
                "CLI" -> 5
                else -> 0
            },
            containerColor = MaterialTheme.colorScheme.surface,
            edgePadding = 8.dp,
            modifier = Modifier.height(48.dp)
        ) {
            Tab(selected = activeBackOfficeTab == "MARKET", onClick = { activeBackOfficeTab = "MARKET" }) {
                Text("Market & RFQ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeBackOfficeTab == "VAULT_TWIN", onClick = { activeBackOfficeTab = "VAULT_TWIN" }) {
                Text("Vault Twin", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeBackOfficeTab == "BUYBACK", onClick = { activeBackOfficeTab = "BUYBACK" }) {
                Text("Buyback Desk", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeBackOfficeTab == "COMPLIANCE", onClick = { activeBackOfficeTab = "COMPLIANCE" }) {
                Text("Compliance", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeBackOfficeTab == "SCENARIO", onClick = { activeBackOfficeTab = "SCENARIO" }) {
                Text("Scenario Lab", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeBackOfficeTab == "CLI", onClick = { activeBackOfficeTab = "CLI" }) {
                Text("CLI Terminal", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(16.dp)
        ) {
            when (activeBackOfficeTab) {
                "MARKET" -> DealerMarketDesk()
                "VAULT_TWIN" -> DealerVaultTwin()
                "BUYBACK" -> DealerBuybackDesk()
                "COMPLIANCE" -> DealerComplianceDesk()
                "SCENARIO" -> DealerScenarioLab()
                "CLI" -> DealerCliConsole()
            }
        }
    }
}

@Composable
fun DealerMarketDesk() {
    var rfqAmountInput by remember { mutableStateOf("10") } // in kg
    var rfqMetal by remember { mutableStateOf(Metal.GOLD) }
    var calculatedRfqQuote by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxSize()) {
        item {
            Text("SECURE INSTITUTIONAL RFQ DESK", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
            Text("Fictional wholesale quote block generator mapping standard gold/silver weights directly to bulk trading reserves.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Wholesale RFQ Request Builder", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { rfqMetal = Metal.GOLD },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (rfqMetal == Metal.GOLD) CalifornianGold else MaterialTheme.colorScheme.background)
                        ) {
                            Text("GOLD")
                        }
                        Button(
                            onClick = { rfqMetal = Metal.SILVER },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (rfqMetal == Metal.SILVER) PlatinumSilver else MaterialTheme.colorScheme.background)
                        ) {
                            Text("SILVER")
                        }
                    }

                    TextField(
                        value = rfqAmountInput,
                        onValueChange = { rfqAmountInput = it },
                        label = { Text("Weight Requested (Kilograms)") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )

                    Button(
                        onClick = {
                            val kg = rfqAmountInput.toDoubleOrNull() ?: 10.0
                            val liveQuote = SyntheticMarketDataProvider.getMetalPrice(rfqMetal, Currency.USD)
                            val grams = BigDecimal(kg * 1000.0)
                            val oz = grams.divide(BigDecimal("31.1034768"), 8, RoundingMode.HALF_UP)
                            val valueUsd = liveQuote.ask.multiply(oz)

                            // Apply wholesale spread reduction for volume
                            val bulkDiscount = BigDecimal("0.003") // 0.3% discount
                            val wholesalePrice = valueUsd.subtract(valueUsd.multiply(bulkDiscount)).setScale(2, RoundingMode.HALF_UP)

                            calculatedRfqQuote = "BID: $${String.format("%,.2f", wholesalePrice.subtract(wholesalePrice.multiply(BigDecimal("0.001"))))}\n" +
                                    "ASK: $${String.format("%,.2f", wholesalePrice)}\n" +
                                    "Spread (0.1%): $${String.format("%,.2f", wholesalePrice.multiply(BigDecimal("0.001")))} USD\n" +
                                    "Settlement: T+1 California Bank Wire\n" +
                                    "Delivery: Physical allocated placement verified in SF Central Vault node."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CALCULATE INSTITUTIONAL RFQ BLOCK")
                    }
                }
            }
        }

        calculatedRfqQuote?.let { quote ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161E2E)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("CRYPTOGRAPHIC RFQ OFFER", fontWeight = FontWeight.Bold, color = CalifornianGold, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(quote, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun DealerVaultTwin() {
    var reconciliationReport by remember { mutableStateOf<ReconciliationReport?>(null) }
    val vaults = SyntheticMarketDataProvider.getVaults()

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxSize()) {
        item {
            Text("CALIFORNIA VAULT DIGITAL TWIN", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
            Text("Real-time physical capacity monitoring, serialized bar position indexes, and physical vs ledger reconciliation auditing.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }

        // Vault list
        items(vaults) { vault ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(vault.location.city + " SECURE VAULT", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MutedEucalyptus.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("SECURE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MutedEucalyptus)
                        }
                    }

                    // Progress bar for occupied space
                    val ratio = vault.occupiedKg.toDouble() / vault.capacityKg.toDouble()
                    LinearProgressIndicator(
                        progress = { ratio.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = CalifornianGold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Capacity occupied: ${vault.occupiedKg} / ${vault.capacityKg} kg", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        Text("${String.format("%.1f", ratio * 100)}%", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("GOLD HOLDINGS", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text("${String.format("%,.2f", vault.goldWeightOz)} oz", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = CalifornianGold)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("SILVER HOLDINGS", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text("${String.format("%,.2f", vault.silverWeightOz)} oz", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PlatinumSilver)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("BAR INDICES", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            Text("${vault.allocatedCount} Allocated", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Active Reconciliation Engine Button
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("LEDGER TO PHYSICAL VAULT RECONCILIATION", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    Text("Runs automated physical counting checks comparing all registered serialized physical bars in active vault storage against unallocated liability ledger entitlements.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))

                    Button(
                        onClick = {
                            reconciliationReport = LedgerEngine.performReconciliation(
                                physicalGoldBars = PacificMetalsOS.allocatedBars.filter { it.metal == Metal.GOLD },
                                physicalSilverBars = PacificMetalsOS.allocatedBars.filter { it.metal == Metal.SILVER },
                                customerUnallocatedGoldOz = PacificMetalsOS.unallocatedGoldOz,
                                customerUnallocatedSilverOz = PacificMetalsOS.unallocatedSilverOz,
                                merchantGoldOz = PacificMetalsOS.merchantGoldReserveOz,
                                merchantSilverOz = PacificMetalsOS.merchantSilverReserveOz
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("RUN PHYSICAL AUDIT CHECK", fontWeight = FontWeight.Bold)
                    }

                    reconciliationReport?.let { report ->
                        Divider(modifier = Modifier.padding(vertical = 4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("AUDIT STATUS", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (report.status == "MATCHED") MutedEucalyptus else MaterialTheme.colorScheme.error)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(report.status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        Text("Total Physical Gold: ${report.totalPhysicalGoldOz.setScale(3, RoundingMode.HALF_UP)} oz", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("Total Ledger Allocations: ${report.totalCustomerAllocatedGoldOz.setScale(3, RoundingMode.HALF_UP)} oz", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("Unallocated Entitlements: ${report.totalCustomerUnallocatedGoldOz.setScale(3, RoundingMode.HALF_UP)} oz", fontSize = 11.sp, fontFamily = FontFamily.Monospace)

                        if (report.exceptions.isNotEmpty()) {
                            Text("EXCEPTIONS DETECTED:", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            report.exceptions.forEach { ex ->
                                Text("• $ex", color = MaterialTheme.colorScheme.error, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        } else {
                            Text("Reconciliation successful: Physical custody matches unallocated digital double-entry entitlements perfectly.", color = MutedEucalyptus, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DealerBuybackDesk() {
    var buybackDesc by remember { mutableStateOf("Estate Scrap 14k Gold Rings") }
    var buybackMetal by remember { mutableStateOf(Metal.GOLD) }
    var buybackWeight by remember { mutableStateOf("150") } // grams
    var buybackPurity by remember { mutableStateOf("0.583") } // 14k
    var buybackMethod by remember { mutableStateOf("XRF Spectrometry") }

    var activeOffer by remember { mutableStateOf<BuybackOffer?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxSize()) {
        item {
            Text("CALIFORNIA BUYBACK & ASSAY DESK", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
            Text("Inspect, assay, and price consumer-submitted gold, scrap jewelry, and secondary bullion assets in full CAPSS compliance.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Assay Intake Form", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    TextField(
                        value = buybackDesc,
                        onValueChange = { buybackDesc = it },
                        label = { Text("Item Description") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { buybackMetal = Metal.GOLD },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (buybackMetal == Metal.GOLD) CalifornianGold else MaterialTheme.colorScheme.background)
                        ) {
                            Text("GOLD")
                        }
                        Button(
                            onClick = { buybackMetal = Metal.SILVER },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (buybackMetal == Metal.SILVER) PlatinumSilver else MaterialTheme.colorScheme.background)
                        ) {
                            Text("SILVER")
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextField(
                            value = buybackWeight,
                            onValueChange = { buybackWeight = it },
                            label = { Text("Weight (g)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        TextField(
                            value = buybackPurity,
                            onValueChange = { buybackPurity = it },
                            label = { Text("Assay Purity (0.0 - 1.0)") },
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }

                    TextField(
                        value = buybackMethod,
                        onValueChange = { buybackMethod = it },
                        label = { Text("Testing Method") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val w = BigDecimal(buybackWeight.toDoubleOrNull() ?: 100.0)
                            val p = BigDecimal(buybackPurity.toDoubleOrNull() ?: 0.999)
                            activeOffer = PacificMetalsOS.submitBuyback(
                                description = buybackDesc,
                                metal = buybackMetal,
                                weightGrams = w,
                                declaredPurity = p,
                                method = buybackMethod
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("EXECUTE INSTRUMENTED ASSAY & GENERATE OFFER", fontSize = 11.sp)
                    }
                }
            }
        }

        activeOffer?.let { offer ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CalifornianGold, RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("OFFER SHEET", fontWeight = FontWeight.Bold, color = CalifornianGold, fontSize = 11.sp)
                        Text("Assayed Fine Weight: ${offer.item.weightGrams.multiply(offer.item.purityPercentage).divide(BigDecimal("100"), 3, RoundingMode.HALF_UP)} g Fine", fontSize = 11.sp)
                        Text("Current Base Bid Rate: $${String.format("%,.2f", offer.marketBidPrice)} USD/oz", fontSize = 11.sp)
                        Text("Intake Confidence Rating: ${offer.item.assayConfidence.multiply(BigDecimal("100"))}%", fontSize = 11.sp)

                        Divider()

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("AUTHORIZED BUYBACK OFFER", fontWeight = FontWeight.Bold)
                            Text("$${String.format("%,.2f", offer.offerAmount)} USD", fontWeight = FontWeight.Black, color = CalifornianGold)
                        }

                        Text(offer.assayLog, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))

                        Button(
                            onClick = {
                                PacificMetalsOS.acceptBuyback(offer)
                                successMessage = "Offer Accepted! Liquidated scrap successfully settled to client cash wallet. CAPSS reference logged."
                                activeOffer = null
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("ACCEPT OFFER & SUBMIT CAPSS REPORT")
                        }
                    }
                }
            }
        }

        successMessage?.let { msg ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MutedEucalyptus.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(msg, modifier = Modifier.padding(16.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MutedEucalyptus)
                }
            }
        }
    }
}

@Composable
fun DealerComplianceDesk() {
    var sellersPermit by remember { mutableStateOf("CA-SP-948190") }
    var businessName by remember { mutableStateOf("Golden State Jewelers LLC") }
    var resCertStatus by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxSize()) {
        item {
            Text("COMPLIANCE & RESALE PORTAL", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
            Text("Verify tax exemption resale certificates, audit high-risk transaction cases, and maintain compliance record logs.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Register California Resale Certificate", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    TextField(
                        value = sellersPermit,
                        onValueChange = { sellersPermit = it },
                        label = { Text("CDTFA Seller's Permit Number") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    TextField(
                        value = businessName,
                        onValueChange = { businessName = it },
                        label = { Text("Registered Business Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            val newCert = ResaleCertificate(
                                sellersPermitNumber = sellersPermit,
                                businessName = businessName,
                                businessAddress = "101 Market St, San Francisco, CA",
                                descriptionOfPurchase = "Precious metal fabrication resales",
                                declaration = "I hereby declare that the property described herein is purchased for resale.",
                                signature = "Client Agent Signature",
                                submissionDate = Date(),
                                status = ResaleStatus.VERIFIED
                            )
                            PacificMetalsOS.activeResaleCertificate = newCert
                            resCertStatus = "SUCCESS: Resale Certificate verified as ACTIVE. Future transactions >= $0.0 will bypass retail CDTFA sales tax rules."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("VERIFY & LOAD CERTIFICATE", fontSize = 11.sp)
                    }
                }
            }
        }

        resCertStatus?.let { status ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MutedEucalyptus.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(status, modifier = Modifier.padding(16.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MutedEucalyptus)
                }
            }
        }

        // Compliance Alert Logs
        item {
            Text("ACTIVE COMPLIANCE CASES / AML LOGS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }

        if (PacificMetalsOS.complianceCases.isEmpty()) {
            item {
                Text("No compliance cases flagged. Transaction risks within normal parameters.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
        } else {
            items(PacificMetalsOS.complianceCases) { case ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(case.caseId, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(case.riskRating, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                        Text("Flag reason: ${case.flagReason}", fontSize = 11.sp)
                        Text("Status: ${case.status}", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
fun DealerScenarioLab() {
    var activeShockText by remember { mutableStateOf<String?>(null) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxSize()) {
        item {
            Text("CALIFORNIA MARKET SCENARIO LAB", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
            Text("Trigger fictional macro-economic shocks in California precious metals demand to stress-test double-entry ledger valuation buffers.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }

        val scenarios = listOf(
            "Gold +10%" to "Flights to safety trigger automatic gold surges.",
            "Gold -10%" to "Interest rate hikes depress gold valuations.",
            "Silver +25%" to "Solar grid battery demand spikes silver prices.",
            "Silver -25%" to "Oversupply pulls back industrial silver values.",
            "USD strengthens" to "Stronger dollar pulls down gold index.",
            "USD weakens" to "Automatic inflation hedges push metals up."
        )

        items(scenarios) { (title, description) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val res = SyntheticMarketDataProvider.applyScenario(title)
                        activeShockText = "SHOCK COMMITTED: ${res.description}\nNew Gold USD mid: $${res.goldPriceUsd}\nNew Silver USD mid: $${res.silverPriceUsd}"
                    }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                    Text(description, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }
        }

        activeShockText?.let { shock ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161E2E)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(shock, modifier = Modifier.padding(16.dp), fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun DealerCliConsole() {
    var terminalOutput by remember { mutableStateOf("Pacific Metals Merchant CLI Console Initialized.\nType 'help' or click shortcuts below to dump double-entry ledger state.\n") }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("MERCHANT REST API & CLI SIMULATOR", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)

        Card(
            colors = CardDefaults.cardColors(containerColor = Black),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
        ) {
            LazyColumn(modifier = Modifier.padding(12.dp)) {
                item {
                    Text(terminalOutput, color = Color.Green, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                }
            }
        }

        // Quick Command Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val cmds = listOf("help", "prices", "ledger", "vault", "reconcile")
            cmds.forEach { cmd ->
                Box(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                        .clickable {
                            val response = when (cmd) {
                                "help" -> "Commands:\n- prices : Dumps current live metal price quotes\n- ledger : Dumps active double-entry bookkeeping ledger logs\n- vault : Shows physical vault twin capacities\n- reconcile : Executes reconciler audit reports"
                                "prices" -> {
                                    val g = SyntheticMarketDataProvider.getMetalPrice(Metal.GOLD, Currency.USD)
                                    val s = SyntheticMarketDataProvider.getMetalPrice(Metal.SILVER, Currency.USD)
                                    "GET /api/v1/prices SUCCESS:\nGOLD: BID $${g.bid} | ASK $${g.ask} | SPREAD $${g.spread}\nSILVER: BID $${s.bid} | ASK $${s.ask} | SPREAD $${s.spread}"
                                }
                                "ledger" -> {
                                    val logs = LedgerEngine.getEntries().joinToString("\n") {
                                        "TX: ${it.transactionId} | ACC: ${it.account} | DEB: ${it.debitAmount} | CRED: ${it.creditAmount} ${it.unit}"
                                    }
                                    "GET /api/v1/ledger SUCCESS:\n$logs"
                                }
                                "vault" -> {
                                    val v = SyntheticMarketDataProvider.getVaults().joinToString("\n") {
                                        "${it.location.city}: ${it.occupiedKg}/${it.capacityKg} kg occupied. Allocated count: ${it.allocatedCount}"
                                    }
                                    "GET /api/v1/vaults SUCCESS:\n$v"
                                }
                                "reconcile" -> {
                                    val audit = LedgerEngine.performReconciliation(
                                        physicalGoldBars = PacificMetalsOS.allocatedBars.filter { it.metal == Metal.GOLD },
                                        physicalSilverBars = PacificMetalsOS.allocatedBars.filter { it.metal == Metal.SILVER },
                                        customerUnallocatedGoldOz = PacificMetalsOS.unallocatedGoldOz,
                                        customerUnallocatedSilverOz = PacificMetalsOS.unallocatedSilverOz,
                                        merchantGoldOz = PacificMetalsOS.merchantGoldReserveOz,
                                        merchantSilverOz = PacificMetalsOS.merchantSilverReserveOz
                                    )
                                    "POST /api/v1/reconcile STATUS: ${audit.status}\nGold Mismatch: ${audit.goldMismatch} oz | Silver Mismatch: ${audit.silverMismatch} oz\nExceptions: ${audit.exceptions.size}"
                                }
                                else -> "Command not found."
                            }
                            terminalOutput += "\n$ pacific-metals $cmd\n$response\n"
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(cmd, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
