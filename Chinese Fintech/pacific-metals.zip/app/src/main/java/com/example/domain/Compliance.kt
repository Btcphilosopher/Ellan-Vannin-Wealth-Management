package com.example.domain

import java.math.BigDecimal
import java.util.Date
import java.util.UUID

data class ComplianceProfile(
    val customerId: String,
    val kycStatus: KycStatus,
    val riskScore: Int, // 0 to 100
    val sourceOfWealth: String?,
    val sourceOfFunds: String?,
    val sanctionsScreeningStatus: ScreeningStatus,
    val pepStatus: Boolean, // Politically Exposed Person
    val lastAuditedAt: Date
)

enum class KycStatus {
    UNVERIFIED, PENDING_REVIEW, APPROVED, REJECTED
}

enum class ScreeningStatus {
    CLEARED, FLAG_PENDING, FLAG_CONFIRMED
}

data class ComplianceCase(
    val caseId: String,
    val customerId: String,
    val transactionId: String?,
    val flagReason: String,
    val riskRating: String, // "LOW", "MEDIUM", "HIGH", "CRITICAL"
    val status: CaseStatus,
    val openedAt: Date,
    val resolvedAt: Date?,
    val auditorNotes: String
)

enum class CaseStatus {
    OPEN, UNDER_INVESTIGATION, RESOLVED_CLEARED, RESOLVED_BLOCKED
}

// Secondhand Metal structures (California DOJ CAPSS Statewide Reporting Compliant)
data class SecondhandItem(
    val itemId: String,
    val description: String, // "Old 14k gold chain", "Scrap sterling silver spoon"
    val reportedMetal: Metal,
    val weightGrams: BigDecimal,
    val purityPercentage: BigDecimal, // assay result (e.g., 58.3 for 14k gold)
    val sellerName: String,
    val sellerIdNumber: String, // Driver's license state ID
    val sellerIdType: String,
    val fingerprintCaptured: Boolean,
    val assayConfidence: BigDecimal,
    val offeringPrice: BigDecimal,
    val capssReferenceNumber: String, // California Pawnbrokers and Secondhand Dealers System Ref
    val currentStatus: SecondhandStatus,
    val dateAcquired: Date,
    val holdReleaseDate: Date, // California requires a 30-day holding period for secondhand goods
    val createdByOperatorId: String
)

enum class SecondhandStatus {
    ACQUIRED_HOLD, // 30-day statutory holding period active
    REPORTED_CAPSS,
    HOLD_RELEASED, // Ready to melt down or resale
    REFINED,
    REJECTED
}

object ComplianceEngine {

    fun evaluateTransactionRisk(
        customerId: String,
        amount: BigDecimal,
        customerType: CustomerType,
        kycStatus: KycStatus,
        isCashLike: Boolean
    ): Int {
        var baseScore = 10

        // Increase risk for higher amounts
        if (amount > BigDecimal("10000.00")) {
            baseScore += 20
        }
        if (amount > BigDecimal("50000.00")) {
            baseScore += 30
        }

        // Increase risk if KYC is not fully approved
        if (kycStatus != KycStatus.APPROVED) {
            baseScore += 40
        }

        // Institutional / Professional lower baseline risk due to pre-vetting
        if (customerType == CustomerType.INSTITUTION || customerType == CustomerType.PROFESSIONAL) {
            baseScore -= 15
        }

        // Cash-like transactions are higher risk
        if (isCashLike) {
            baseScore += 25
        }

        return baseScore.coerceIn(0, 100)
    }

    fun submitToCAPSS(item: SecondhandItem): SecondhandItem {
        // Mocking CA DOJ CAPSS electronic API payload integration
        val capssRef = "CAPSS-CA-" + UUID.randomUUID().toString().take(8).uppercase()
        return item.copy(
            capssReferenceNumber = capssRef,
            currentStatus = SecondhandStatus.REPORTED_CAPSS
        )
    }
}
