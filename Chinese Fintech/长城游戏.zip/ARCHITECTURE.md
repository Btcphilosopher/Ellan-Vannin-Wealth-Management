# Great Wall Gaming Architecture (长城OS架构)

```
        长城游戏硬件 (Great Wall Custom APU / NVMe / Controller HAL)
                                ↓
                        Boot / Firmware (GW-EFI)
                                ↓
        Rust Platform Core (libgw_platform.so / IPC Service Engine)
        ├── Game Runtime & Process Lifecycle Supervisor (LAUNCHING -> RUNNING -> SUSPENDED -> EXITING)
        ├── Atomic Package Manager & Dual-Slot A/B Update Engine (SHA-256 Verified)
        ├── Chunked Download Engine & Resume Pipeline (Priority Queue)
        ├── Storage & NVMe Quota Manager (Game / System / Captures / Cache)
        ├── Controller Input HAL & Force Feedback (Dual Sense / Wireless 2.4GHz / BT / USB)
        ├── Cloud Save Encrypted Sync & Conflict Arbiter
        ├── Network & Packet Telemetry Diagnostics
        └── Zero-Trust Entitlement & Sandboxing Security Core
                                ↓
        Platform Native Boundary & Strongly-Typed IPC (`GreatWallPlatformApi`)
                                ↓
        Kotlin Console Shell (Jetpack Compose 10-foot Living Room UI)
        ├── Focus Engine & Controller Input Interceptor (D-pad, Sticks, A/B/X/Y, Guide)
        ├── Console Home & Hero Art Experience
        ├── Quick Menu Overlay (`快速菜单` without interrupting game state)
        ├── Game Library & Detail Management (`我的游戏`, `游戏详情`)
        ├── Chinese Editorial Game Store (`游戏商店` - 国产游戏、独立新作)
        ├── Great Wall ID & Friends Social Presence (`长城ID`, `好友`, `消息`)
        ├── Achievement Showcase (`成就` - 万里长城、百战不殆)
        ├── System Diagnostics & Developer Performance Overlay (`性能监控`, `系统诊断`)
        └── Comprehensive System Settings & Parental Safeguards (`设置`, `家长控制`)
```

## Rust & Kotlin Separation of Concerns
1. **Rust owns System Truth**: Processes, downloads, storage quotas, verified updates, SHA-256 manifests, cloud save states.
2. **Kotlin owns Presentation & Navigation**: TV 10-foot 4K interface, focus traversal, responsive visual transitions, audio haptics feedback.
