# Great Wall Gaming (长城游戏) - Console Platform Monorepo
Internal Project: `great_wall_gaming`
System Codename: `长城OS` (GWCOS v1.4.2 / v1.5.0)

## Overview
Great Wall Gaming is a serious Chinese game console platform combining:
- **Rust Platform Core**: System services, Game runtime & process manager, Download engine, Storage manager, Network diagnostics, Telemetry, Cloud Save sync, Controller HAL, and Security/IPC layer.
- **Kotlin Console Shell**: Television/Living-room 10-foot UI designed for controller navigation, rich Chinese typography, full-bleed game key art, multi-pane settings, store, library, achievements, and family/parental controls.
- **Simplified Chinese First (简体中文)**: Native contemporary gaming console terminology (开始游戏、继续游戏、云存档、快速菜单、网络诊断、家长控制、成就解锁).
