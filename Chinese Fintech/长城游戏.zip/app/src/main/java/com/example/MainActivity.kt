package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.ConsoleScreen
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.ConsoleViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: ConsoleViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        val runningGame by viewModel.runningGame.collectAsStateWithLifecycle()
        val processState by viewModel.processState.collectAsStateWithLifecycle()
        val controllerState by viewModel.controllerState.collectAsStateWithLifecycle()
        val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
        val storage by viewModel.storage.collectAsStateWithLifecycle()
        val libraryGames by viewModel.libraryGames.collectAsStateWithLifecycle()
        val storeGames by viewModel.storeGames.collectAsStateWithLifecycle()
        val downloads by viewModel.downloads.collectAsStateWithLifecycle()

        // Handle System Back Key / Gamepad B button
        BackHandler {
          viewModel.navigateBack()
        }

        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(GwBackground)
        ) {
          if (uiState.currentScreen == ConsoleScreen.BOOT) {
            BootScreen()
          } else {
            Scaffold(
              containerColor = GwBackground,
              contentWindowInsets = WindowInsets.safeDrawing,
              topBar = {
                if (uiState.currentScreen != ConsoleScreen.RUNNING_GAME_VIEW) {
                  ConsoleTopBar(
                    userProfile = uiState.userProfile,
                    controllerState = controllerState,
                    isOffline = uiState.isSimulatingOffline,
                    onAvatarClick = { viewModel.navigateTo(ConsoleScreen.SETTINGS) },
                    onQuickMenuClick = { viewModel.toggleQuickMenu() },
                    onNotificationsClick = { viewModel.showToast("已加载系统通知：3 条新消息") }
                  )
                }
              },
              bottomBar = {
                if (uiState.currentScreen != ConsoleScreen.RUNNING_GAME_VIEW) {
                  ConsoleBottomNav(
                    currentScreen = uiState.currentScreen,
                    onNavigate = { viewModel.navigateTo(it) }
                  )
                }
              }
            ) { innerPadding ->
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .padding(innerPadding)
              ) {
                when (uiState.currentScreen) {
                  ConsoleScreen.HOME -> HomeScreen(
                    featuredGame = runningGame ?: libraryGames.firstOrNull(),
                    recentGames = libraryGames,
                    onLaunchGame = { viewModel.launchOrResumeGame(it) },
                    onGameDetails = { viewModel.selectGame(it) },
                    onNavigateLibrary = { viewModel.navigateTo(ConsoleScreen.LIBRARY) },
                    onNavigateStore = { viewModel.navigateTo(ConsoleScreen.STORE) }
                  )
                  ConsoleScreen.LIBRARY -> LibraryScreen(
                    games = libraryGames,
                    onGameClick = { viewModel.selectGame(it) },
                    onLaunchGame = { viewModel.launchOrResumeGame(it) }
                  )
                  ConsoleScreen.STORE -> StoreScreen(
                    storeGames = storeGames,
                    onGameClick = { viewModel.selectGame(it) },
                    onPurchase = { viewModel.purchaseGame(it) }
                  )
                  ConsoleScreen.GAME_DETAIL -> GameDetailScreen(
                    game = uiState.selectedGame,
                    onBack = { viewModel.navigateBack() },
                    onLaunch = { viewModel.launchOrResumeGame(it) },
                    onSyncSave = { viewModel.syncCloudSave(it) },
                    onUninstall = { viewModel.uninstallGame(it) },
                    onPurchase = { viewModel.purchaseGame(it) }
                  )
                  ConsoleScreen.ACHIEVEMENTS -> AchievementsScreen(
                    achievements = viewModel.achievements
                  )
                  ConsoleScreen.FRIENDS -> FriendsScreen(
                    friends = viewModel.friends,
                    onInvite = { viewModel.showToast("已向 ${it.nicknameZh} 发送队伍联机邀请") },
                    onSendMessage = { viewModel.showToast("已打开与 ${it.nicknameZh} 的游戏私信窗口") }
                  )
                  ConsoleScreen.STORAGE -> StorageScreen(
                    storage = storage,
                    onCleanCache = { viewModel.cleanCache() }
                  )
                  ConsoleScreen.DOWNLOADS -> DownloadsScreen(
                    downloads = downloads,
                    onPause = { viewModel.pauseDownload(it) },
                    onResume = { viewModel.resumeDownload(it) },
                    onCancel = { viewModel.cancelDownload(it) }
                  )
                  ConsoleScreen.SETTINGS -> SettingsScreen(
                    userProfile = uiState.userProfile,
                    controllerState = controllerState,
                    onNavigateDiagnostics = { viewModel.navigateTo(ConsoleScreen.DIAGNOSTICS) },
                    onNavigateDeveloper = { viewModel.navigateTo(ConsoleScreen.DEVELOPER_OPTIONS) },
                    onSetHaptics = { /* Haptics updated in VM */ }
                  )
                  ConsoleScreen.DIAGNOSTICS -> DiagnosticsScreen(
                    isRunning = uiState.isDiagnosticRunning,
                    results = uiState.diagnosticResults,
                    onRunTest = { viewModel.runFullDiagnostics() },
                    onBack = { viewModel.navigateBack() }
                  )
                  ConsoleScreen.DEVELOPER_OPTIONS -> DeveloperOptionsScreen(
                    perfMode = uiState.perfOverlayMode,
                    isSimulatingOffline = uiState.isSimulatingOffline,
                    simulatedControllerDisconnected = uiState.simulatedControllerDisconnected,
                    simulatedStorageFull = uiState.simulatedStorageFull,
                    onCyclePerfMode = { viewModel.cyclePerfOverlay() },
                    onToggleOffline = { viewModel.toggleSimulateOffline() },
                    onToggleControllerDisconnect = { viewModel.toggleSimulateControllerDisconnect() },
                    onToggleStorageFull = { viewModel.toggleSimulateStorageFull() },
                    onBack = { viewModel.navigateBack() }
                  )
                  ConsoleScreen.RUNNING_GAME_VIEW -> RunningGameScreen(
                    game = runningGame ?: uiState.selectedGame,
                    processState = processState,
                    onOpenQuickMenu = { viewModel.toggleQuickMenu() },
                    onSuspend = { viewModel.suspendCurrentGame(); viewModel.navigateTo(ConsoleScreen.HOME) },
                    onExit = { viewModel.terminateCurrentGame() }
                  )
                  else -> {}
                }
              }
            }

            // Quick Menu Overlay (Can be opened on any screen or during game)
            QuickMenuOverlay(
              isOpen = uiState.isQuickMenuOpen,
              runningGame = runningGame,
              processState = processState,
              onDismiss = { viewModel.toggleQuickMenu() },
              onResumeGame = {
                runningGame?.let { viewModel.launchOrResumeGame(it) }
              },
              onSuspendGame = {
                viewModel.suspendCurrentGame()
                viewModel.toggleQuickMenu()
              },
              onExitGame = {
                viewModel.terminateCurrentGame()
              },
              onNavigateLibrary = { viewModel.navigateTo(ConsoleScreen.LIBRARY) },
              onNavigateDownloads = { viewModel.navigateTo(ConsoleScreen.DOWNLOADS) },
              onNavigateFriends = { viewModel.navigateTo(ConsoleScreen.FRIENDS) },
              onNavigateSettings = { viewModel.navigateTo(ConsoleScreen.SETTINGS) },
              onCyclePerfOverlay = { viewModel.cyclePerfOverlay() }
            )

            // Real-time Performance HUD (APU / FPS / Temp / Ram)
            PerformanceOverlay(
              mode = uiState.perfOverlayMode,
              telemetry = telemetry,
              onDismiss = { viewModel.cyclePerfOverlay() }
            )

            // Simulated Controller Disconnected Banner
            if (uiState.simulatedControllerDisconnected) {
              Surface(
                color = Color(0xF2DC2626),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                  .align(Alignment.TopCenter)
                  .padding(top = 16.dp)
                  .testTag("controller_disconnected_banner")
              ) {
                Text(
                  text = "⚠️ 长城无线手柄连接已断开，请按【长城键】重新配对 (游戏已自动暂停)",
                  color = Color.White,
                  style = MaterialTheme.typography.bodySmall,
                  modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
              }
            }

            // Simulated NVMe Storage Full Banner
            if (uiState.simulatedStorageFull) {
              Surface(
                color = Color(0xF2F59E0B),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                  .align(Alignment.TopCenter)
                  .padding(top = if (uiState.simulatedControllerDisconnected) 54.dp else 16.dp)
                  .testTag("storage_full_banner")
              ) {
                Text(
                  text = "⚠️ 内部 NVMe 固态硬盘存储空间不足 (< 5GB)，建议前往存储管理清理",
                  color = Color.Black,
                  style = MaterialTheme.typography.bodySmall,
                  modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
              }
            }

            // System Toast / Floating Notification
            uiState.toastMessageZh?.let { msg ->
              Surface(
                color = Color(0xEE1E2430),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
                modifier = Modifier
                  .align(Alignment.BottomCenter)
                  .padding(bottom = 70.dp)
                  .testTag("system_toast")
              ) {
                Text(
                  text = msg,
                  color = GwTextPrimary,
                  style = MaterialTheme.typography.bodyMedium,
                  modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}
