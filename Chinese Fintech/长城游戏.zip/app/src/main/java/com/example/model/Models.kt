package com.example.model

enum class GameProcessState(val labelZh: String) {
  LAUNCHING("正在启动"),
  RUNNING("运行中"),
  SUSPENDED("已挂起"),
  RESUMING("正在恢复"),
  EXITING("正在退出"),
  CRASHED("异常中断")
}

data class Game(
  val id: String,
  val titleZh: String,
  val subtitleZh: String,
  val developerZh: String,
  val publisherZh: String,
  val genreZh: String,
  val ageRatingZh: String,
  val fileSizeGb: Float,
  val version: String,
  val isInstalled: Boolean,
  val playTimeHours: Int,
  val lastPlayedZh: String,
  val coverDrawableRes: Int,
  val descriptionZh: String,
  val hasCloudSave: Boolean = true,
  val achievementsCount: Int = 30,
  val unlockedAchievements: Int = 12,
  val priceCny: Int = 0, // 0 = 已拥有 / 免费
  val isFavorite: Boolean = false,
  val isFeatured: Boolean = false
)

enum class DownloadState(val labelZh: String) {
  QUEUED("等待中"),
  DOWNLOADING("下载中"),
  PAUSED("暂停"),
  VERIFYING("验证中"),
  INSTALLING("安装中"),
  COMPLETED("已完成"),
  FAILED("失败")
}

data class DownloadTask(
  val id: String,
  val gameId: String,
  val gameTitleZh: String,
  val totalGb: Float,
  val downloadedGb: Float,
  val speedMbps: Float,
  val remainingMinutes: Int,
  val state: DownloadState,
  val progressPercent: Int
)

data class Achievement(
  val id: String,
  val titleZh: String,
  val descriptionZh: String,
  val rarityPercent: Float,
  val isUnlocked: Boolean,
  val unlockTimeZh: String = "",
  val categoryZh: String = "主线探索"
)

data class Friend(
  val id: String,
  val nicknameZh: String,
  val greatWallId: String,
  val isOnline: Boolean,
  val currentPlayingZh: String,
  val totalPlayHours: Int,
  val statusMessageZh: String
)

data class ControllerState(
  val id: String = "GW-CTRL-01",
  val nameZh: String = "长城无线手柄 Pro",
  val connectionType: String = "2.4GHz 无线超低延迟",
  val batteryPercent: Int = 85,
  val isCharging: Boolean = false,
  val firmwareVersion: String = "v2.1.4",
  val vibrationIntensity: Int = 80, // 0 - 100
  val lightColorRgb: Long = 0xFFDC2626
)

data class SystemTelemetry(
  val fps: Int = 60,
  val frameTimeMs: Float = 16.6f,
  val cpuUsagePercent: Int = 38,
  val gpuUsagePercent: Int = 62,
  val ramUsageGb: Float = 7.8f,
  val totalRamGb: Float = 16.0f,
  val socTemperatureC: Int = 64,
  val fanSpeedRpm: Int = 2150,
  val networkPingMs: Int = 28,
  val downloadSpeedMbps: Float = 385.2f,
  val uploadSpeedMbps: Float = 88.5f,
  val packetLossPercent: Float = 0.0f
)

data class StorageBreakdown(
  val totalGb: Float = 512.0f,
  val usedGb: Float = 328.0f,
  val gamesGb: Float = 286.0f,
  val systemGb: Float = 24.0f,
  val capturesGb: Float = 12.0f,
  val cacheGb: Float = 6.0f
) {
  val freeGb: Float get() = (totalGb - usedGb).coerceAtLeast(0f)
}

data class UserProfile(
  val greatWallId: String = "GW_883921",
  val nicknameZh: String = "天权星宿",
  val level: Int = 42,
  val totalGamesCount: Int = 18,
  val totalPlayHours: Int = 486,
  val totalAchievements: Int = 164,
  val vipStatusZh: String = "长城白金会员"
)

data class SystemNotification(
  val id: String,
  val titleZh: String,
  val contentZh: String,
  val timeZh: String,
  val isRead: Boolean = false
)
