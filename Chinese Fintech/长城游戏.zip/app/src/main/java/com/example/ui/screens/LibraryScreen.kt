package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Game
import com.example.ui.theme.*

@Composable
fun LibraryScreen(
  games: List<Game>,
  onGameClick: (Game) -> Unit,
  onLaunchGame: (Game) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("全部", "最近游玩", "已安装", "收藏", "已购买")

  val filteredGames = when (selectedTab) {
    1 -> games.filter { it.playTimeHours > 0 }
    2 -> games.filter { it.isInstalled }
    3 -> games.filter { it.isFavorite }
    4 -> games.filter { it.priceCny == 0 || it.isInstalled }
    else -> games
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp)
  ) {
    // Title & Tab filters
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "我的游戏库",
          style = MaterialTheme.typography.headlineLarge,
          fontWeight = FontWeight.Bold,
          color = GwTextPrimary
        )
        Text(
          text = "长城ID共持有 ${games.size} 款作品 • 已安装 ${games.count { it.isInstalled }} 款",
          style = MaterialTheme.typography.bodyMedium,
          color = GwSteelMuted
        )
      }

      // Filter Tabs
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(GwSurfaceVariant)
          .padding(4.dp)
      ) {
        tabs.forEachIndexed { index, label ->
          val isSelected = selectedTab == index
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(if (isSelected) GwPrimaryRed else Color.Transparent)
              .clickable { selectedTab = index }
              .padding(horizontal = 14.dp, vertical = 6.dp)
              .testTag("tab_library_$index")
          ) {
            Text(
              text = label,
              style = MaterialTheme.typography.labelMedium,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) Color.White else GwTextSecondary
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Grid of Games
    LazyVerticalGrid(
      columns = GridCells.Adaptive(minSize = 260.dp),
      horizontalArrangement = Arrangement.spacedBy(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
      contentPadding = PaddingValues(bottom = 24.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      items(filteredGames) { game ->
        LibraryGameCard(
          game = game,
          onClick = { onGameClick(game) },
          onLaunch = { onLaunchGame(game) }
        )
      }
    }
  }
}

@Composable
fun LibraryGameCard(
  game: Game,
  onClick: () -> Unit,
  onLaunch: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = GwSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("lib_card_${game.id}")
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(150.dp)
          .clip(RoundedCornerShape(8.dp))
      ) {
        Image(
          painter = painterResource(id = game.coverDrawableRes),
          contentDescription = game.titleZh,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Status badges
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(Color(0xCC0F1115))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "${game.fileSizeGb} GB",
              style = MaterialTheme.typography.labelSmall,
              color = GwSteelMuted
            )
          }

          if (game.isInstalled) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xCC10B981))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = "已安装",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = game.titleZh,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = GwTextPrimary,
        maxLines = 1
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = "成就: ${game.unlockedAchievements} / ${game.achievementsCount} • 游玩: ${game.playTimeHours}小时",
        style = MaterialTheme.typography.bodySmall,
        color = GwSteelMuted
      )

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (game.hasCloudSave) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Icon(
              imageVector = Icons.Default.CloudDone,
              contentDescription = "云存档就绪",
              tint = GwSuccess,
              modifier = Modifier.size(14.dp)
            )
            Text(
              text = "云存档正常",
              style = MaterialTheme.typography.labelSmall,
              color = GwTextSecondary
            )
          }
        } else {
          Spacer(modifier = Modifier.width(1.dp))
        }

        if (game.isInstalled) {
          Button(
            onClick = onLaunch,
            colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
            shape = RoundedCornerShape(6.dp),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
            modifier = Modifier.height(32.dp)
          ) {
            Icon(
              imageVector = Icons.Default.PlayArrow,
              contentDescription = "开始游戏",
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("开始", fontSize = 12.sp)
          }
        } else {
          OutlinedButton(
            onClick = onClick,
            shape = RoundedCornerShape(6.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            modifier = Modifier.height(32.dp)
          ) {
            Text("安装", fontSize = 12.sp)
          }
        }
      }
    }
  }
}
