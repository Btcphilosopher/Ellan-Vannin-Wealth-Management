package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.DownloadState
import com.example.model.DownloadTask
import com.example.ui.theme.*

@Composable
fun DownloadsScreen(
  downloads: List<DownloadTask>,
  onPause: (String) -> Unit,
  onResume: (String) -> Unit,
  onCancel: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp, vertical = 16.dp)
  ) {
    Text(
      text = "下载与更新管理器",
      style = MaterialTheme.typography.headlineLarge,
      fontWeight = FontWeight.Bold,
      color = GwTextPrimary
    )
    Text(
      text = "分块断点续传 • SHA-256 数据完整性实时校验",
      style = MaterialTheme.typography.bodyMedium,
      color = GwSteelMuted
    )

    Spacer(modifier = Modifier.height(20.dp))

    if (downloads.isEmpty()) {
      Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
      ) {
        Text("当前无正在进行的下载任务", color = GwTextSecondary)
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
      ) {
        items(downloads) { task ->
          DownloadItemRow(
            task = task,
            onPause = { onPause(task.id) },
            onResume = { onResume(task.id) },
            onCancel = { onCancel(task.id) }
          )
        }
      }
    }
  }
}

@Composable
fun DownloadItemRow(
  task: DownloadTask,
  onPause: () -> Unit,
  onResume: () -> Unit,
  onCancel: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = GwSurface,
    shape = RoundedCornerShape(10.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
    modifier = modifier
      .fillMaxWidth()
      .testTag("download_row_${task.id}")
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = task.gameTitleZh,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = GwTextPrimary
          )
          Text(
            text = "状态：${task.state.labelZh} • 预计剩余 ${task.remainingMinutes} 分钟",
            style = MaterialTheme.typography.bodySmall,
            color = GwSteelMuted
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          if (task.state == DownloadState.DOWNLOADING) {
            IconButton(
              onClick = onPause,
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(GwSurfaceVariant)
            ) {
              Icon(Icons.Default.Pause, contentDescription = "暂停", tint = GwTextPrimary)
            }
          } else if (task.state == DownloadState.PAUSED) {
            IconButton(
              onClick = onResume,
              modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(GwSurfaceVariant)
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = "继续", tint = GwPrimaryRed)
            }
          }

          IconButton(
            onClick = onCancel,
            modifier = Modifier
              .clip(RoundedCornerShape(6.dp))
              .background(GwSurfaceVariant)
          ) {
            Icon(Icons.Default.Close, contentDescription = "取消下载", tint = GwError)
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      LinearProgressIndicator(
        progress = { (task.progressPercent / 100f).coerceIn(0f, 1f) },
        color = GwPrimaryRed,
        trackColor = GwSurfaceVariant,
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp))
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "${String.format("%.1f", task.downloadedGb)} GB / ${task.totalGb} GB (${task.progressPercent}%)",
          style = MaterialTheme.typography.labelSmall,
          color = GwTextSecondary
        )
        Text(
          text = "${String.format("%.1f", task.speedMbps)} Mbps",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = GwSuccess
        )
      }
    }
  }
}
