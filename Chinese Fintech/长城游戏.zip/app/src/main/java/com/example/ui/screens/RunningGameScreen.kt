package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Game
import com.example.model.GameProcessState
import com.example.ui.theme.*

@Composable
fun RunningGameScreen(
  game: Game?,
  processState: GameProcessState,
  onOpenQuickMenu: () -> Unit,
  onSuspend: () -> Unit,
  onExit: () -> Unit,
  modifier: Modifier = Modifier
) {
  if (game == null) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("未检测到运行中的游戏", color = GwTextSecondary)
    }
    return
  }

  // Live simulation HUD inside the game
  var showControlBar by remember { mutableStateOf(true) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color.Black)
  ) {
    // Fullscreen Game Viewport / Key Art
    Image(
      painter = painterResource(id = game.coverDrawableRes),
      contentDescription = game.titleZh,
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize()
    )

    // Subtle dark vignette at top and bottom for game UI clarity
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          androidx.compose.ui.graphics.Brush.verticalGradient(
            colors = listOf(
              Color(0xCC0A0D12),
              Color(0x220A0D12),
              Color(0xAA0A0D12)
            )
          )
        )
    )

    // Top Header: Game Running State & Controller HUD
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(Color(0xCC111827))
          .border(1.dp, GwBorderMuted, RoundedCornerShape(8.dp))
          .padding(horizontal = 12.dp, vertical = 6.dp)
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (processState == GameProcessState.RUNNING) GwSuccess else GwWarning)
        )
        Text(
          text = game.titleZh,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = GwTextPrimary
        )
        Text(
          text = "• ${processState.labelZh} (4K 60FPS Native HDR)",
          style = MaterialTheme.typography.labelSmall,
          color = GwSteelMuted
        )
      }

      // Quick Menu Guide Button Prompt
      Button(
        onClick = onOpenQuickMenu,
        colors = ButtonDefaults.buttonColors(
          containerColor = Color(0xCCDC2626),
          contentColor = Color.White
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.testTag("in_game_quick_menu")
      ) {
        Icon(Icons.Default.Menu, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("按手柄【长城键】呼出快速菜单", style = MaterialTheme.typography.labelMedium)
      }
    }

    // Bottom Action HUD (Suspend or Return to Shell)
    Surface(
      color = Color(0xD911141A),
      shape = RoundedCornerShape(12.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(bottom = 24.dp)
        .testTag("in_game_bottom_hud")
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(Icons.Default.SportsEsports, contentDescription = null, tint = GwPrimaryRed, modifier = Modifier.size(18.dp))
          Text("已连接：长城无线手柄 Pro (2.4GHz 无损)", style = MaterialTheme.typography.bodySmall, color = GwTextSecondary)
        }

        Divider(
          modifier = Modifier
            .height(18.dp)
            .width(1.dp),
          color = GwBorderMuted
        )

        Button(
          onClick = onSuspend,
          colors = ButtonDefaults.buttonColors(containerColor = GwSurfaceVariant),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
          modifier = Modifier.height(32.dp).testTag("btn_suspend_to_home")
        ) {
          Icon(Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("挂起并返回首页", fontSize = 12.sp)
        }

        OutlinedButton(
          onClick = onExit,
          colors = ButtonDefaults.outlinedButtonColors(contentColor = GwError),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
          modifier = Modifier.height(32.dp).testTag("btn_terminate_game")
        ) {
          Text("安全退出", fontSize = 12.sp)
        }
      }
    }
  }
}
