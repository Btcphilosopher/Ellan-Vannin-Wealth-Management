package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.PerformanceOverlayMode
import com.example.ui.theme.*

@Composable
fun DeveloperOptionsScreen(
  perfMode: PerformanceOverlayMode,
  isSimulatingOffline: Boolean,
  simulatedControllerDisconnected: Boolean,
  simulatedStorageFull: Boolean,
  onCyclePerfMode: () -> Unit,
  onToggleOffline: () -> Unit,
  onToggleControllerDisconnect: () -> Unit,
  onToggleStorageFull: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp, vertical = 16.dp)
      .verticalScroll(scrollState)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(
        onClick = onBack,
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(GwSurfaceVariant)
          .testTag("dev_back")
      ) {
        Icon(Icons.Default.ArrowBack, contentDescription = "返回", tint = GwTextPrimary)
      }
      Spacer(modifier = Modifier.width(12.dp))
      Text(
        text = "系统开发者模式 (GW-DEV)",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Bold,
        color = GwTextPrimary
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "仅供长城游戏第一方与第三方授权工作室进行性能剖析与极端故障测试",
      style = MaterialTheme.typography.bodyMedium,
      color = GwSteelMuted
    )

    Spacer(modifier = Modifier.height(20.dp))

    // Performance Overlay Control
    Surface(
      color = GwSurface,
      shape = RoundedCornerShape(10.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(text = "实时性能监视浮层 (HUD)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
          Text(text = "显示 60FPS 帧率、16.6ms 帧时间、CPU/GPU 占用、SoC 温度与显存", style = MaterialTheme.typography.bodySmall, color = GwSteelMuted)
        }

        Button(
          onClick = onCyclePerfMode,
          colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("btn_cycle_perf_hud")
        ) {
          Text(perfMode.labelZh)
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(text = "系统故障状态仿真器 (Failure Simulation)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
    Spacer(modifier = Modifier.height(10.dp))

    // Fault 1: Offline mode
    SimulationSwitchRow(
      title = "模拟网络中断 (离线安全模式)",
      subtitle = "模拟断网状态，验证离线本地运行、离线单人游戏启动与云存档挂起队列",
      active = isSimulatingOffline,
      onToggle = onToggleOffline
    )

    // Fault 2: Controller disconnect
    SimulationSwitchRow(
      title = "模拟长城手柄无线信号丢失",
      subtitle = "模拟 2.4GHz 无线连接超时，验证手柄断开时的自动暂停机制与重新配对",
      active = simulatedControllerDisconnected,
      onToggle = onToggleControllerDisconnect
    )

    // Fault 3: Storage full
    SimulationSwitchRow(
      title = "模拟 NVMe 固态硬盘已满警报",
      subtitle = "模拟可用存储空间 < 5GB，验证下载队列保护与游戏存档安全边界",
      active = simulatedStorageFull,
      onToggle = onToggleStorageFull
    )
  }
}

@Composable
fun SimulationSwitchRow(
  title: String,
  subtitle: String,
  active: Boolean,
  onToggle: () -> Unit
) {
  Surface(
    color = GwSurface,
    shape = RoundedCornerShape(10.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, if (active) GwWarning else GwBorderMuted),
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium, color = GwTextPrimary)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = GwSteelMuted)
      }
      Switch(
        checked = active,
        onCheckedChange = { onToggle() },
        colors = SwitchDefaults.colors(
          checkedThumbColor = Color.White,
          checkedTrackColor = GwWarning
        )
      )
    }
  }
}
