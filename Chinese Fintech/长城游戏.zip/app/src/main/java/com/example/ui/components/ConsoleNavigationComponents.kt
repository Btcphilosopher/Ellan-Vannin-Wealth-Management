package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ControllerState
import com.example.model.UserProfile
import com.example.ui.theme.*

@Composable
fun ConsoleTopBar(
  userProfile: UserProfile,
  controllerState: ControllerState,
  isOffline: Boolean,
  onAvatarClick: () -> Unit,
  onQuickMenuClick: () -> Unit,
  onNotificationsClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 24.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    // Left: System Branding and Active User
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(GwSurfaceVariant)
          .border(1.dp, GwBorderMuted, RoundedCornerShape(8.dp))
          .padding(horizontal = 12.dp, vertical = 6.dp)
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(GwPrimaryRed)
        )
        Text(
          text = "长城游戏",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = GwTextPrimary
        )
        Text(
          text = "GWCOS",
          style = MaterialTheme.typography.labelSmall,
          color = GwSteelMuted,
          letterSpacing = 1.sp
        )
      }

      // User Profile Chip
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(GwSurfaceVariant)
          .clickable(onClick = onAvatarClick)
          .padding(horizontal = 12.dp, vertical = 6.dp)
          .testTag("user_profile_chip")
      ) {
        Box(
          modifier = Modifier
            .size(24.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(GwPrimaryRed),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = userProfile.nicknameZh.take(1),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
        }
        Text(
          text = userProfile.nicknameZh,
          style = MaterialTheme.typography.bodyMedium,
          fontWeight = FontWeight.Medium,
          color = GwTextPrimary
        )
        Text(
          text = userProfile.greatWallId,
          style = MaterialTheme.typography.labelSmall,
          color = GwSteelMuted
        )
      }
    }

    // Right: Console Hardware & System Telemetry Status Icons
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Offline / Online indicator
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(if (isOffline) GwSurfaceVariant else Color(0x1A10B981))
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Icon(
          imageVector = if (isOffline) Icons.Default.WifiOff else Icons.Default.Wifi,
          contentDescription = if (isOffline) "离线模式" else "网络正常",
          tint = if (isOffline) GwTextTertiary else GwSuccess,
          modifier = Modifier.size(16.dp)
        )
        Text(
          text = if (isOffline) "离线状态" else "千兆专网",
          style = MaterialTheme.typography.labelSmall,
          color = if (isOffline) GwTextTertiary else GwSuccess
        )
      }

      // Controller status & battery
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
          .clip(RoundedCornerShape(6.dp))
          .background(GwSurfaceVariant)
          .padding(horizontal = 8.dp, vertical = 4.dp)
      ) {
        Icon(
          imageVector = Icons.Default.SportsEsports,
          contentDescription = "长城手柄状态",
          tint = GwTextPrimary,
          modifier = Modifier.size(16.dp)
        )
        Text(
          text = "${controllerState.batteryPercent}%",
          style = MaterialTheme.typography.labelSmall,
          color = GwTextSecondary
        )
      }

      // System Quick Menu Button (Home / Guide key)
      Button(
        onClick = onQuickMenuClick,
        colors = ButtonDefaults.buttonColors(
          containerColor = GwPrimaryRed,
          contentColor = Color.White
        ),
        shape = RoundedCornerShape(8.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        modifier = Modifier
          .height(34.dp)
          .testTag("quick_menu_button")
      ) {
        Icon(
          imageVector = Icons.Default.Menu,
          contentDescription = "快速菜单",
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "快速菜单",
          style = MaterialTheme.typography.labelMedium
        )
      }

      // System Notifications Icon
      IconButton(
        onClick = onNotificationsClick,
        modifier = Modifier
          .size(36.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(GwSurfaceVariant)
          .testTag("notifications_top_button")
      ) {
        Icon(
          imageVector = Icons.Outlined.Notifications,
          contentDescription = "系统通知",
          tint = GwTextPrimary,
          modifier = Modifier.size(18.dp)
        )
      }
    }
  }
}

@Composable
fun ConsoleBottomNav(
  currentScreen: com.example.model.ConsoleScreen,
  onNavigate: (com.example.model.ConsoleScreen) -> Unit,
  modifier: Modifier = Modifier
) {
  val items = listOf(
    Triple(com.example.model.ConsoleScreen.HOME, "首页", Icons.Default.Home),
    Triple(com.example.model.ConsoleScreen.LIBRARY, "我的游戏", Icons.Default.SportsEsports),
    Triple(com.example.model.ConsoleScreen.STORE, "游戏商店", Icons.Default.Storefront),
    Triple(com.example.model.ConsoleScreen.ACHIEVEMENTS, "成就", Icons.Default.EmojiEvents),
    Triple(com.example.model.ConsoleScreen.FRIENDS, "好友", Icons.Default.People),
    Triple(com.example.model.ConsoleScreen.STORAGE, "存储空间", Icons.Default.PieChart),
    Triple(com.example.model.ConsoleScreen.SETTINGS, "系统设置", Icons.Default.Settings)
  )

  Surface(
    color = GwSurface,
    tonalElevation = 6.dp,
    border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
    modifier = modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .windowInsetsPadding(WindowInsets.navigationBars)
        .padding(horizontal = 16.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceAround,
      verticalAlignment = Alignment.CenterVertically
    ) {
      items.forEach { (screen, titleZh, icon) ->
        val isSelected = currentScreen == screen
        val interactionSource = remember { MutableInteractionSource() }

        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) GwSurfaceVariant else Color.Transparent)
            .clickable(interactionSource = interactionSource, indication = null) {
              onNavigate(screen)
            }
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("nav_${screen.name.lowercase()}")
        ) {
          Icon(
            imageVector = icon,
            contentDescription = titleZh,
            tint = if (isSelected) GwPrimaryRed else GwTextSecondary,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = titleZh,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) GwTextPrimary else GwTextSecondary
          )
        }
      }
    }
  }
}
