package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PerformanceOverlayMode
import com.example.model.SystemTelemetry
import com.example.ui.theme.*

@Composable
fun PerformanceOverlay(
  mode: PerformanceOverlayMode,
  telemetry: SystemTelemetry,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier
) {
  if (mode == PerformanceOverlayMode.OFF) return

  Box(
    modifier = modifier
      .fillMaxWidth()
      .padding(top = 60.dp, end = 24.dp),
    contentAlignment = Alignment.TopEnd
  ) {
    Surface(
      color = Color(0xE6141820),
      shape = RoundedCornerShape(8.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      tonalElevation = 8.dp,
      modifier = Modifier
        .widthIn(min = if (mode == PerformanceOverlayMode.COMPACT) 180.dp else 260.dp)
        .testTag("perf_overlay")
    ) {
      Column(
        modifier = Modifier.padding(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "性能监控 (RUST HAL)",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = GwCyan
          )
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "关闭",
            tint = GwSteelMuted,
            modifier = Modifier
              .size(14.dp)
              .clickable(onClick = onDismiss)
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // FPS and Frametime
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(text = "帧率", style = MaterialTheme.typography.bodySmall, color = GwTextSecondary)
          Text(
            text = "${telemetry.fps} FPS",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = GwSuccess,
            fontFamily = FontFamily.Monospace
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(text = "帧时间", style = MaterialTheme.typography.bodySmall, color = GwTextSecondary)
          Text(
            text = "${telemetry.frameTimeMs} ms",
            style = MaterialTheme.typography.bodySmall,
            color = GwTextPrimary,
            fontFamily = FontFamily.Monospace
          )
        }

        if (mode == PerformanceOverlayMode.DETAILED) {
          Divider(color = GwBorderMuted, modifier = Modifier.padding(vertical = 4.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "CPU 占用", style = MaterialTheme.typography.bodySmall, color = GwTextSecondary)
            Text(
              text = "${telemetry.cpuUsagePercent}%",
              style = MaterialTheme.typography.bodySmall,
              color = GwTextPrimary,
              fontFamily = FontFamily.Monospace
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "GPU 负载", style = MaterialTheme.typography.bodySmall, color = GwTextSecondary)
            Text(
              text = "${telemetry.gpuUsagePercent}%",
              style = MaterialTheme.typography.bodySmall,
              color = GwTextPrimary,
              fontFamily = FontFamily.Monospace
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "内存占用", style = MaterialTheme.typography.bodySmall, color = GwTextSecondary)
            Text(
              text = "${telemetry.ramUsageGb} / ${telemetry.totalRamGb} GB",
              style = MaterialTheme.typography.bodySmall,
              color = GwTextPrimary,
              fontFamily = FontFamily.Monospace
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "SoC 温度", style = MaterialTheme.typography.bodySmall, color = GwTextSecondary)
            Text(
              text = "${telemetry.socTemperatureC} °C",
              style = MaterialTheme.typography.bodySmall,
              color = if (telemetry.socTemperatureC > 75) GwError else GwTextPrimary,
              fontFamily = FontFamily.Monospace
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "风扇转速", style = MaterialTheme.typography.bodySmall, color = GwTextSecondary)
            Text(
              text = "${telemetry.fanSpeedRpm} RPM",
              style = MaterialTheme.typography.bodySmall,
              color = GwTextPrimary,
              fontFamily = FontFamily.Monospace
            )
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "网络延迟", style = MaterialTheme.typography.bodySmall, color = GwTextSecondary)
            Text(
              text = "${telemetry.networkPingMs} ms",
              style = MaterialTheme.typography.bodySmall,
              color = GwSuccess,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }
  }
}
