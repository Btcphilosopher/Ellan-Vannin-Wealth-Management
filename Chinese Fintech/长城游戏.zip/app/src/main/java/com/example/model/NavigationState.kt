package com.example.model

enum class ConsoleScreen {
  BOOT,
  HOME,
  LIBRARY,
  STORE,
  GAME_DETAIL,
  ACHIEVEMENTS,
  FRIENDS,
  STORAGE,
  DOWNLOADS,
  SETTINGS,
  DIAGNOSTICS,
  DEVELOPER_OPTIONS,
  RUNNING_GAME_VIEW
}

enum class PerformanceOverlayMode(val labelZh: String) {
  OFF("关闭"),
  COMPACT("简洁模式"),
  DETAILED("详细模式")
}
