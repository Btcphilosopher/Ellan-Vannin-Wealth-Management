package com.example.platform

import com.example.R
import com.example.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

/**
 * Rust Platform Core Service Implementation for Great Wall OS (长城OS).
 * Contains the authoritative game catalogue, download manager state machine,
 * real-time telemetry supervisor, and cloud sync coordinator.
 */
class GreatWallPlatformService : GreatWallPlatformApi {

  private val coroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

  private val _runningGame = MutableStateFlow<Game?>(null)
  private val _processState = MutableStateFlow(GameProcessState.SUSPENDED)
  private val _controllerState = MutableStateFlow(ControllerState())
  private val _telemetry = MutableStateFlow(SystemTelemetry())
  private val _storage = MutableStateFlow(StorageBreakdown())

  private val initialGames = listOf(
    Game(
      id = "gw-game-001",
      titleZh = "《长安风云》",
      subtitleZh = "唐代古都大世界历史动作冒险",
      developerZh = "太史游戏工作室 (Grand Historian Studio)",
      publisherZh = "长城游戏第一方发行 (GWG Interactive)",
      genreZh = "动作 / 角色扮演 / 开放世界",
      ageRatingZh = "16+ (适龄提示)",
      fileSizeGb = 84.5f,
      version = "v1.3.4",
      isInstalled = true,
      playTimeHours = 48,
      lastPlayedZh = "昨天 21:43",
      coverDrawableRes = R.drawable.img_changan,
      descriptionZh = "沉浸式盛唐神都开放世界。扮演羽林禁卫，在繁华胡市、太极宫廷与九霄飞阁之间探查神秘方士惊天秘案。光线追踪实时全局光照与全景杜比全景声支持。",
      hasCloudSave = true,
      achievementsCount = 45,
      unlockedAchievements = 28,
      isFavorite = true,
      isFeatured = true
    ),
    Game(
      id = "gw-game-002",
      titleZh = "《山海纪元》",
      subtitleZh = "东方上古神话上古异兽狩猎巨作",
      developerZh = "昆仑重工互动 (Kunlun Interactive)",
      publisherZh = "长城第一方发行 (GWG Interactive)",
      genreZh = "动作 / 狩猎 / 奇幻动作",
      ageRatingZh = "16+",
      fileSizeGb = 62.0f,
      version = "v2.0.1",
      isInstalled = true,
      playTimeHours = 32,
      lastPlayedZh = "3天前 19:15",
      coverDrawableRes = R.drawable.img_shanhai,
      descriptionZh = "取材《山海经》宏大玄幻蛮荒世界。驾驭天罡法宝，深入大荒苍茫云海与百丈上古凶兽展开殊死搏斗。支持长城超分辨率技术 (GW-FSR) 4K 60FPS 极速渲染。",
      hasCloudSave = true,
      achievementsCount = 50,
      unlockedAchievements = 19,
      isFavorite = true,
      isFeatured = true
    ),
    Game(
      id = "gw-game-003",
      titleZh = "《长城：边境》",
      subtitleZh = "硬核冷兵器要塞边防战术模拟",
      developerZh = "赤壁数字科技 (Red Cliff Studios)",
      publisherZh = "华夏互动娱乐",
      genreZh = "战术策略 / 动作冒险 / 历史防守",
      ageRatingZh = "16+",
      fileSizeGb = 45.2f,
      version = "v1.1.0",
      isInstalled = true,
      playTimeHours = 19,
      lastPlayedZh = "5天前 14:02",
      coverDrawableRes = R.drawable.img_frontier,
      descriptionZh = "万里长城关隘防卫战争巨献。风雪嘉峪关、九门烽火台联防，实时万人同屏战场模拟。真实冷兵器碰撞手柄触觉振动反馈。",
      hasCloudSave = true,
      achievementsCount = 38,
      unlockedAchievements = 14,
      isFavorite = false,
      isFeatured = true
    ),
    Game(
      id = "gw-game-004",
      titleZh = "《星河远征》",
      subtitleZh = "硬科幻深空母舰轨道探索建设",
      developerZh = "天宫未来工程工作室",
      publisherZh = "星海互娱",
      genreZh = "太空科幻 / 模拟经营 / 探索",
      ageRatingZh = "12+",
      fileSizeGb = 52.8f,
      version = "v1.0.8",
      isInstalled = true,
      playTimeHours = 24,
      lastPlayedZh = "上周",
      coverDrawableRes = R.drawable.img_star,
      descriptionZh = "人类深空领航者旗舰启航。探索南门二星系未知宜居带，规划巨构空间站与环行星轨道防御网。支持HDR10+高动态范围黑深对比度。",
      hasCloudSave = true,
      achievementsCount = 40,
      unlockedAchievements = 10,
      isFavorite = true,
      isFeatured = true
    ),
    Game(
      id = "gw-game-005",
      titleZh = "《北境铁骑》",
      subtitleZh = "开放沙盒古代骑兵军团合纵连横",
      developerZh = "朔方原野互动",
      publisherZh = "长城游戏发行",
      genreZh = "历史战略 / 角色扮演",
      ageRatingZh = "16+",
      fileSizeGb = 39.5f,
      version = "v1.0.2",
      isInstalled = false,
      playTimeHours = 0,
      lastPlayedZh = "未开始",
      coverDrawableRes = R.drawable.img_frontier,
      descriptionZh = "纵马塞外茫茫草原。招募骁勇骑士，构筑坚固营寨，在风云变幻的各方势力间建立威严秩序。",
      hasCloudSave = false,
      achievementsCount = 35,
      unlockedAchievements = 0,
      priceCny = 248
    ),
    Game(
      id = "gw-game-006",
      titleZh = "《江南夜行》",
      subtitleZh = "水墨画风烟雨江南解谜潜行武侠",
      developerZh = "青绿水墨工作组",
      publisherZh = "东方独立游戏联盟",
      genreZh = "武侠 / 独立冒险 / 解谜",
      ageRatingZh = "12+",
      fileSizeGb = 18.4f,
      version = "v1.2.0",
      isInstalled = false,
      playTimeHours = 0,
      lastPlayedZh = "未开始",
      coverDrawableRes = R.drawable.img_changan,
      descriptionZh = "姑苏城外枫桥夜泊。精雕细琢的手绘水墨渲染引擎，轻功夜探幽巷深宅，揭开古画藏宝迷局。",
      hasCloudSave = false,
      achievementsCount = 28,
      unlockedAchievements = 0,
      priceCny = 128
    )
  )

  private val _games = MutableStateFlow(initialGames)

  private val _downloads = MutableStateFlow<List<DownloadTask>>(
    listOf(
      DownloadTask(
        id = "dl-01",
        gameId = "gw-game-005",
        gameTitleZh = "《北境铁骑》",
        totalGb = 39.5f,
        downloadedGb = 23.7f,
        speedMbps = 428.5f,
        remainingMinutes = 5,
        state = DownloadState.DOWNLOADING,
        progressPercent = 60
      )
    )
  )

  private val _notifications = MutableStateFlow<List<SystemNotification>>(
    listOf(
      SystemNotification(
        id = "notif-1",
        titleZh = "系统更新可用",
        contentZh = "长城OS 1.5.0 正式版已准备就绪，优化GPU光追管线与手柄超低延迟。",
        timeZh = "10分钟前"
      ),
      SystemNotification(
        id = "notif-2",
        titleZh = "云存档同步成功",
        contentZh = "《长安风云》云存档已加密备份至长城安全云 (SHA-256校验通过)。",
        timeZh = "昨天 21:44"
      ),
      SystemNotification(
        id = "notif-3",
        titleZh = "成就解锁通知",
        contentZh = "恭喜解锁罕见成就「万里长城」(稀有度 8.4%)！",
        timeZh = "3天前"
      )
    )
  )

  init {
    // Set default boot game to Chang'an Chronicles
    _runningGame.value = initialGames[0]
    _processState.value = GameProcessState.SUSPENDED

    // Start background telemetry tick to emulate live APU sensor readings
    coroutineScope.launch {
      var counter = 0
      while (isActive) {
        delay(2000)
        counter++
        val baseFps = if (_processState.value == GameProcessState.RUNNING) 60 else 60
        val cpuJitter = (35 + (counter % 7) * 2).coerceIn(30, 65)
        val gpuJitter = if (_processState.value == GameProcessState.RUNNING) 74 + (counter % 5) else 35
        val tempJitter = if (_processState.value == GameProcessState.RUNNING) 65 + (counter % 3) else 54
        _telemetry.value = _telemetry.value.copy(
          fps = baseFps,
          cpuUsagePercent = cpuJitter,
          gpuUsagePercent = gpuJitter,
          socTemperatureC = tempJitter,
          networkPingMs = 24 + (counter % 4)
        )
      }
    }
  }

  override fun observeCurrentRunningGame(): Flow<Game?> = _runningGame.asStateFlow()
  override fun observeGameProcessState(): Flow<GameProcessState> = _processState.asStateFlow()
  override fun observeControllerState(): Flow<ControllerState> = _controllerState.asStateFlow()
  override fun observeTelemetry(): Flow<SystemTelemetry> = _telemetry.asStateFlow()
  override fun observeStorage(): Flow<StorageBreakdown> = _storage.asStateFlow()
  override fun observeLibraryGames(): Flow<List<Game>> = _games.asStateFlow()
  override fun observeStoreGames(): Flow<List<Game>> = _games.asStateFlow()
  override fun observeDownloads(): Flow<List<DownloadTask>> = _downloads.asStateFlow()
  override fun observeNotifications(): Flow<List<SystemNotification>> = _notifications.asStateFlow()

  override suspend fun launchGame(gameId: String): Result<Boolean> {
    val target = _games.value.find { it.id == gameId }
      ?: return Result.failure(IllegalArgumentException("未找到游戏"))
    _processState.value = GameProcessState.LAUNCHING
    delay(1200) // Controlled startup duration
    _runningGame.value = target
    _processState.value = GameProcessState.RUNNING
    return Result.success(true)
  }

  override suspend fun suspendCurrentGame(): Result<Boolean> {
    if (_runningGame.value != null) {
      _processState.value = GameProcessState.SUSPENDED
    }
    return Result.success(true)
  }

  override suspend fun resumeCurrentGame(): Result<Boolean> {
    if (_runningGame.value != null) {
      _processState.value = GameProcessState.RESUMING
      delay(300)
      _processState.value = GameProcessState.RUNNING
    }
    return Result.success(true)
  }

  override suspend fun terminateCurrentGame(): Result<Boolean> {
    _processState.value = GameProcessState.EXITING
    delay(400)
    _processState.value = GameProcessState.SUSPENDED
    _runningGame.value = null
    return Result.success(true)
  }

  override suspend fun purchaseGame(gameId: String): Result<Boolean> {
    delay(600)
    _games.update { list ->
      list.map { g ->
        if (g.id == gameId) g.copy(priceCny = 0, isInstalled = false) else g
      }
    }
    startDownload(gameId)
    return Result.success(true)
  }

  override suspend fun uninstallGame(gameId: String): Result<Boolean> {
    _games.update { list ->
      list.map { g ->
        if (g.id == gameId) g.copy(isInstalled = false) else g
      }
    }
    _storage.update { it.copy(usedGb = (it.usedGb - 30f).coerceAtLeast(100f)) }
    return Result.success(true)
  }

  override suspend fun startDownload(gameId: String): Result<Boolean> {
    val game = _games.value.find { it.id == gameId } ?: return Result.failure(Exception("Game not found"))
    val existing = _downloads.value.find { it.gameId == gameId }
    if (existing == null) {
      val newTask = DownloadTask(
        id = "dl-${System.currentTimeMillis()}",
        gameId = game.id,
        gameTitleZh = game.titleZh,
        totalGb = game.fileSizeGb,
        downloadedGb = 2.4f,
        speedMbps = 412.0f,
        remainingMinutes = 6,
        state = DownloadState.DOWNLOADING,
        progressPercent = 6
      )
      _downloads.update { it + newTask }
    }
    return Result.success(true)
  }

  override suspend fun pauseDownload(taskId: String): Result<Boolean> {
    _downloads.update { list ->
      list.map { if (it.id == taskId) it.copy(state = DownloadState.PAUSED) else it }
    }
    return Result.success(true)
  }

  override suspend fun resumeDownload(taskId: String): Result<Boolean> {
    _downloads.update { list ->
      list.map { if (it.id == taskId) it.copy(state = DownloadState.DOWNLOADING) else it }
    }
    return Result.success(true)
  }

  override suspend fun cancelDownload(taskId: String): Result<Boolean> {
    _downloads.update { list -> list.filterNot { it.id == taskId } }
    return Result.success(true)
  }

  override suspend fun syncCloudSave(gameId: String): Result<String> {
    delay(1000)
    return Result.success("云存档同步完成 (哈希校验通过: SHA-256 e48f...b721)")
  }

  override suspend fun setControllerHaptics(intensity: Int): Result<Boolean> {
    _controllerState.update { it.copy(vibrationIntensity = intensity) }
    return Result.success(true)
  }

  override suspend fun cleanCache(): Result<Float> {
    delay(500)
    val freed = _storage.value.cacheGb
    _storage.update {
      it.copy(
        cacheGb = 0.5f,
        usedGb = (it.usedGb - (freed - 0.5f)).coerceAtLeast(50f)
      )
    }
    return Result.success(freed - 0.5f)
  }

  override suspend fun checkSystemUpdate(): Result<String> {
    delay(400)
    return Result.success("发现新版本 长城OS v1.5.0 (大小: 2.8 GB)")
  }

  override suspend fun applySystemUpdate(): Result<Boolean> {
    delay(1500)
    return Result.success(true)
  }
}
