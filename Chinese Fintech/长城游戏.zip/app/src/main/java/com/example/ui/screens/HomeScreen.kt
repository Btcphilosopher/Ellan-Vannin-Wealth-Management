package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Game
import com.example.ui.theme.*

@Composable
fun HomeScreen(
  featuredGame: Game?,
  recentGames: List<Game>,
  onLaunchGame: (Game) -> Unit,
  onGameDetails: (Game) -> Unit,
  onNavigateLibrary: () -> Unit,
  onNavigateStore: () -> Unit,
  modifier: Modifier = Modifier
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(bottom = 24.dp)
  ) {
    // 1. Hero Artwork Section (Full-bleed TV presentation with subtle gradient)
    if (featuredGame != null) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(340.dp)
          .padding(horizontal = 24.dp)
          .clip(RoundedCornerShape(16.dp))
          .border(1.dp, GwBorderMuted, RoundedCornerShape(16.dp))
          .testTag("hero_featured_game")
      ) {
        Image(
          painter = painterResource(id = featuredGame.coverDrawableRes),
          contentDescription = featuredGame.titleZh,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay for high legibility
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.horizontalGradient(
                colors = listOf(
                  Color(0xF00F1115),
                  Color(0xCC0F1115),
                  Color(0x330F1115)
                )
              )
            )
        )

        // Hero Metadata & Primary CTA
        Column(
          modifier = Modifier
            .fillMaxHeight()
            .widthIn(max = 520.dp)
            .padding(28.dp),
          verticalArrangement = Arrangement.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(GwPrimaryRed)
                .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
              Text(
                text = "继续游玩",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
            Text(
              text = "上次游玩：${featuredGame.lastPlayedZh}",
              style = MaterialTheme.typography.labelSmall,
              color = GwSteelMuted
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          Text(
            text = featuredGame.titleZh,
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Bold,
            color = GwTextPrimary
          )

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = featuredGame.subtitleZh,
            style = MaterialTheme.typography.titleMedium,
            color = GwTextSecondary,
            maxLines = 2
          )

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.CloudDone,
                contentDescription = "云存档已同步",
                tint = GwSuccess,
                modifier = Modifier.size(16.dp)
              )
              Text(
                text = "云存档已就绪",
                style = MaterialTheme.typography.bodySmall,
                color = GwTextSecondary
              )
            }

            Text(
              text = "已累计游玩 ${featuredGame.playTimeHours} 小时",
              style = MaterialTheme.typography.bodySmall,
              color = GwSteelMuted
            )
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Primary Actions
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
              onClick = { onLaunchGame(featuredGame) },
              colors = ButtonDefaults.buttonColors(
                containerColor = GwPrimaryRed,
                contentColor = Color.White
              ),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier
                .height(44.dp)
                .testTag("hero_btn_resume")
            ) {
              Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "继续",
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "继续游戏", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
              onClick = { onGameDetails(featuredGame) },
              colors = ButtonDefaults.outlinedButtonColors(
                contentColor = GwTextPrimary
              ),
              border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier
                .height(44.dp)
                .testTag("hero_btn_details")
            ) {
              Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "查看详情",
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "查看详情")
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(28.dp))

    // 2. Horizontal "最近游玩" Section
    Column(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 24.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "最近游玩",
          style = MaterialTheme.typography.headlineMedium,
          fontWeight = FontWeight.Bold,
          color = GwTextPrimary
        )

        TextButton(
          onClick = onNavigateLibrary,
          modifier = Modifier.testTag("btn_see_all_library")
        ) {
          Text(
            text = "全部游戏 (${recentGames.size}) ›",
            style = MaterialTheme.typography.bodyMedium,
            color = GwSteelMuted
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      LazyRow(
        contentPadding = PaddingValues(horizontal = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        items(recentGames) { game ->
          GameCardCompact(
            game = game,
            onCardClick = { onGameDetails(game) },
            onQuickLaunch = { onLaunchGame(game) }
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(28.dp))

    // 3. Fast Discover / Store Banner
    Surface(
      color = GwSurfaceVariant,
      shape = RoundedCornerShape(12.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp)
        .clickable(onClick = onNavigateStore)
        .testTag("home_store_banner")
    ) {
      Row(
        modifier = Modifier.padding(20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(
            text = "国产大作与新锐独立游戏专区",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = GwTextPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "精选高规格国产主机新作，原生支持4K HDR光追与长城手柄触觉振动",
            style = MaterialTheme.typography.bodyMedium,
            color = GwTextSecondary
          )
        }
        Button(
          onClick = onNavigateStore,
          colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text("浏览商店")
        }
      }
    }
  }
}

@Composable
fun GameCardCompact(
  game: Game,
  onCardClick: () -> Unit,
  onQuickLaunch: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .width(220.dp)
      .clip(RoundedCornerShape(12.dp))
      .background(GwSurface)
      .border(1.dp, GwBorderMuted, RoundedCornerShape(12.dp))
      .clickable(onClick = onCardClick)
      .padding(10.dp)
      .testTag("game_card_${game.id}")
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(130.dp)
        .clip(RoundedCornerShape(8.dp))
    ) {
      Image(
        painter = painterResource(id = game.coverDrawableRes),
        contentDescription = game.titleZh,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
      )

      if (game.isInstalled) {
        Box(
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(6.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xCC111827))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "已安装",
            style = MaterialTheme.typography.labelSmall,
            color = GwSuccess
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Text(
      text = game.titleZh,
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = GwTextPrimary,
      maxLines = 1
    )

    Spacer(modifier = Modifier.height(2.dp))

    Text(
      text = if (game.playTimeHours > 0) "已游玩 ${game.playTimeHours}小时" else "未开始",
      style = MaterialTheme.typography.bodySmall,
      color = GwSteelMuted
    )

    Spacer(modifier = Modifier.height(8.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = game.genreZh.split("/").firstOrNull()?.trim() ?: "动作",
        style = MaterialTheme.typography.labelSmall,
        color = GwTextSecondary
      )

      FilledTonalButton(
        onClick = onQuickLaunch,
        colors = ButtonDefaults.filledTonalButtonColors(
          containerColor = GwSurfaceVariant,
          contentColor = GwTextPrimary
        ),
        shape = RoundedCornerShape(6.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
        modifier = Modifier.height(30.dp)
      ) {
        Text("启动", fontSize = 12.sp)
      }
    }
  }
}
