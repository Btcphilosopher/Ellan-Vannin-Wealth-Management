package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.StorageBreakdown
import com.example.ui.theme.*

@Composable
fun StorageScreen(
  storage: StorageBreakdown,
  onCleanCache: () -> Unit,
  modifier: Modifier = Modifier
) {
  val usedPercent = (storage.usedGb / storage.totalGb).coerceIn(0f, 1f)

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp, vertical = 16.dp)
  ) {
    Text(
      text = "内部高速NVMe存储管理",
      style = MaterialTheme.typography.headlineLarge,
      fontWeight = FontWeight.Bold,
      color = GwTextPrimary
    )
    Text(
      text = "PCIe 4.0 超高速固态硬盘 • 硬件直读解压缩",
      style = MaterialTheme.typography.bodyMedium,
      color = GwSteelMuted
    )

    Spacer(modifier = Modifier.height(20.dp))

    // Storage Gauge Card
    Surface(
      color = GwSurface,
      shape = RoundedCornerShape(12.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(20.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.Storage, contentDescription = null, tint = GwPrimaryRed)
            Text(
              text = "内部固态硬盘 (512 GB)",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = GwTextPrimary
            )
          }

          Text(
            text = "可用空间：${String.format("%.1f", storage.freeGb)} GB / ${storage.totalGb.toInt()} GB",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = GwSuccess
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Progress Bar
        LinearProgressIndicator(
          progress = { usedPercent },
          modifier = Modifier
            .fillMaxWidth()
            .height(12.dp)
            .clip(RoundedCornerShape(6.dp)),
          color = GwPrimaryRed,
          trackColor = GwSurfaceVariant
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Breakdown items
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          StorageCategoryBadge("游戏安装包", "${storage.gamesGb.toInt()} GB", GwPrimaryRed)
          StorageCategoryBadge("系统与内核", "${storage.systemGb.toInt()} GB", GwCyan)
          StorageCategoryBadge("截图与录屏", "${storage.capturesGb.toInt()} GB", GwWarning)
          StorageCategoryBadge("临时缓存", "${String.format("%.1f", storage.cacheGb)} GB", GwSteelMuted)
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    Text(
      text = "存储维护与空间清理",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = GwTextPrimary
    )

    Spacer(modifier = Modifier.height(12.dp))

    Surface(
      color = GwSurface,
      shape = RoundedCornerShape(10.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "一键清理着色器与系统临时缓存",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Medium,
            color = GwTextPrimary
          )
          Text(
            text = "安全清理已失效的着色器预编译缓存与未完成的临时安装包，绝不触动游戏存档",
            style = MaterialTheme.typography.bodySmall,
            color = GwSteelMuted
          )
        }

        Button(
          onClick = onCleanCache,
          colors = ButtonDefaults.buttonColors(containerColor = GwSurfaceVariant, contentColor = GwTextPrimary),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("btn_clean_cache")
        ) {
          Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("清理缓存")
        }
      }
    }
  }
}

@Composable
fun StorageCategoryBadge(title: String, size: String, color: Color) {
  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(3.dp)).background(color))
    Column {
      Text(title, style = MaterialTheme.typography.labelSmall, color = GwSteelMuted)
      Text(size, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
    }
  }
}
