package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
  primary = GwPrimaryRed,
  onPrimary = GwTextPrimary,
  primaryContainer = GwSurfaceVariant,
  onPrimaryContainer = GwTextPrimary,
  secondary = GwSteelMuted,
  onSecondary = GwBackground,
  background = GwBackground,
  onBackground = GwTextPrimary,
  surface = GwSurface,
  onSurface = GwTextPrimary,
  surfaceVariant = GwSurfaceVariant,
  onSurfaceVariant = GwTextSecondary,
  outline = GwBorderMuted,
  error = GwError,
  onError = GwTextPrimary
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
