package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Game
import com.example.model.GameProcessState
import com.example.ui.theme.*

@Composable
fun QuickMenuOverlay(
  isOpen: Boolean,
  runningGame: Game?,
  processState: GameProcessState,
  onDismiss: () -> Unit,
  onResumeGame: () -> Unit,
  onSuspendGame: () -> Unit,
  onExitGame: () -> Unit,
  onNavigateLibrary: () -> Unit,
  onNavigateDownloads: () -> Unit,
  onNavigateFriends: () -> Unit,
  onNavigateSettings: () -> Unit,
  onCyclePerfOverlay: () -> Unit,
  modifier: Modifier = Modifier
) {
  AnimatedVisibility(
    visible = isOpen,
    enter = slideInHorizontally(initialOffsetX = { -it }) + fadeIn(),
    exit = slideOutHorizontally(targetOffsetX = { -it }) + fadeOut(),
    modifier = modifier.fillMaxSize()
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color(0x990A0C10))
        .clickable(onClick = onDismiss)
    ) {
      Surface(
        color = GwSurface,
        tonalElevation = 16.dp,
        modifier = Modifier
          .fillMaxHeight()
          .widthIn(min = 320.dp, max = 380.dp)
          .border(1.dp, GwBorderMuted)
          .clickable(enabled = false) {} // Prevent backdrop click through
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
        ) {
          // Header
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "快速菜单",
              style = MaterialTheme.typography.headlineMedium,
              fontWeight = FontWeight.Bold,
              color = GwTextPrimary
            )
            IconButton(onClick = onDismiss) {
              Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "关闭快速菜单",
                tint = GwTextSecondary
              )
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Current game tile if active
          if (runningGame != null) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(GwSurfaceVariant)
                .border(1.dp, GwPrimaryRed, RoundedCornerShape(10.dp))
                .padding(14.dp)
            ) {
              Text(
                text = "当前进行中的游戏",
                style = MaterialTheme.typography.labelSmall,
                color = GwPrimaryRed
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = runningGame.titleZh,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = GwTextPrimary
              )
              Text(
                text = "状态：${processState.labelZh}",
                style = MaterialTheme.typography.bodySmall,
                color = GwTextSecondary
              )

              Spacer(modifier = Modifier.height(10.dp))

              Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Button(
                  onClick = onResumeGame,
                  colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.weight(1f).testTag("quick_menu_resume")
                ) {
                  Text("继续游戏", fontSize = 12.sp)
                }
                OutlinedButton(
                  onClick = onExitGame,
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = GwError),
                  shape = RoundedCornerShape(6.dp),
                  modifier = Modifier.weight(1f).testTag("quick_menu_exit")
                ) {
                  Text("退出游戏", fontSize = 12.sp)
                }
              }
            }
            Spacer(modifier = Modifier.height(16.dp))
          }

          Divider(color = GwBorderMuted)
          Spacer(modifier = Modifier.height(16.dp))

          // Quick Navigation Items
          val menuItems = listOf(
            Triple("我的游戏", Icons.Default.SportsEsports, onNavigateLibrary),
            Triple("下载与更新", Icons.Default.Download, onNavigateDownloads),
            Triple("好友与队伍", Icons.Default.People, onNavigateFriends),
            Triple("截图与录像", Icons.Default.PhotoCamera, { /* capture gallery */ }),
            Triple("性能监控浮层", Icons.Default.Speed, onCyclePerfOverlay),
            Triple("系统设置", Icons.Default.Settings, onNavigateSettings),
            Triple("休眠与关机", Icons.Default.PowerSettingsNew, onExitGame)
          )

          menuItems.forEach { (labelZh, icon, action) ->
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(14.dp),
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                  action()
                  onDismiss()
                }
                .padding(vertical = 12.dp, horizontal = 12.dp)
                .testTag("quick_item_${labelZh}")
            ) {
              Icon(
                imageVector = icon,
                contentDescription = labelZh,
                tint = GwSteelMuted,
                modifier = Modifier.size(20.dp)
              )
              Text(
                text = labelZh,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = GwTextPrimary
              )
            }
          }
        }
      }
    }
  }
}
