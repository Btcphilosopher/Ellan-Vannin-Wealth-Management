package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

@Composable
fun DiagnosticsScreen(
  isRunning: Boolean,
  results: Map<String, Boolean>,
  onRunTest: () -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val allItems = listOf("网络", "存储", "手柄", "音频", "显示", "系统文件完整性")

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp, vertical = 16.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(
        onClick = onBack,
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(GwSurfaceVariant)
          .testTag("diag_back")
      ) {
        Icon(Icons.Default.ArrowBack, contentDescription = "返回", tint = GwTextPrimary)
      }
      Spacer(modifier = Modifier.width(12.dp))
      Text(
        text = "长城主机系统自检与硬件诊断",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Bold,
        color = GwTextPrimary
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    Surface(
      color = GwSurface,
      shape = RoundedCornerShape(12.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(20.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "硬件核心自检状态",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = GwTextPrimary
          )
          Text(
            text = "检测 APU 状态、NVMe 写入健康度、长城手柄无线信号与系统内核哈希",
            style = MaterialTheme.typography.bodyMedium,
            color = GwSteelMuted
          )
        }

        Button(
          onClick = onRunTest,
          enabled = !isRunning,
          colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.testTag("btn_run_diagnostics")
        ) {
          if (isRunning) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(8.dp))
            Text("诊断中...")
          } else {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("开始全面自检")
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      items(allItems) { item ->
        val passed = results[item] == true
        val testing = isRunning && !passed

        Surface(
          color = GwSurface,
          shape = RoundedCornerShape(10.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = item,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Medium,
              color = GwTextPrimary
            )

            if (passed) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GwSuccess, modifier = Modifier.size(20.dp))
                Text("✓ 正常通过", color = GwSuccess, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
              }
            } else if (testing) {
              Text("正在验证...", color = GwWarning, style = MaterialTheme.typography.bodyMedium)
            } else {
              Text("等待测试", color = GwSteelMuted, style = MaterialTheme.typography.bodyMedium)
            }
          }
        }
      }
    }
  }
}
