package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Friend
import com.example.ui.theme.*

@Composable
fun FriendsScreen(
  friends: List<Friend>,
  onInvite: (Friend) -> Unit,
  onSendMessage: (Friend) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp, vertical = 16.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "好友与社交队伍",
          style = MaterialTheme.typography.headlineLarge,
          fontWeight = FontWeight.Bold,
          color = GwTextPrimary
        )
        Text(
          text = "${friends.count { it.isOnline }} 人在线 • 共 ${friends.size} 位好友",
          style = MaterialTheme.typography.bodyMedium,
          color = GwSteelMuted
        )
      }

      Button(
        onClick = { /* Add friend */ },
        colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
        shape = RoundedCornerShape(8.dp)
      ) {
        Icon(Icons.Default.GroupAdd, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("添加好友")
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      items(friends) { friend ->
        FriendRow(
          friend = friend,
          onInvite = { onInvite(friend) },
          onSendMessage = { onSendMessage(friend) }
        )
      }
    }
  }
}

@Composable
fun FriendRow(
  friend: Friend,
  onInvite: () -> Unit,
  onSendMessage: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = GwSurface,
    shape = RoundedCornerShape(10.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
    modifier = modifier
      .fillMaxWidth()
      .testTag("friend_row_${friend.id}")
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Avatar placeholder with online status badge
      Box(
        modifier = Modifier.size(46.dp)
      ) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(23.dp))
            .background(GwSurfaceVariant),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = friend.nicknameZh.take(1),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = GwTextPrimary
          )
        }

        Box(
          modifier = Modifier
            .size(12.dp)
            .align(Alignment.BottomEnd)
            .clip(RoundedCornerShape(6.dp))
            .background(if (friend.isOnline) GwSuccess else GwTextTertiary)
        )
      }

      Spacer(modifier = Modifier.width(16.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = friend.nicknameZh,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = GwTextPrimary
          )
          Text(
            text = friend.greatWallId,
            style = MaterialTheme.typography.labelSmall,
            color = GwSteelMuted
          )
        }

        Spacer(modifier = Modifier.height(2.dp))

        if (friend.isOnline) {
          Text(
            text = "正在游玩：${friend.currentPlayingZh}",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            color = GwSuccess
          )
          Text(
            text = friend.statusMessageZh,
            style = MaterialTheme.typography.labelSmall,
            color = GwTextSecondary
          )
        } else {
          Text(
            text = friend.statusMessageZh,
            style = MaterialTheme.typography.bodySmall,
            color = GwTextTertiary
          )
        }
      }

      Spacer(modifier = Modifier.width(16.dp))

      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (friend.isOnline) {
          Button(
            onClick = onInvite,
            colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
            shape = RoundedCornerShape(6.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Text("邀请入队", fontSize = 12.sp)
          }
        }

        IconButton(
          onClick = onSendMessage,
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(GwSurfaceVariant)
        ) {
          Icon(Icons.Default.ChatBubbleOutline, contentDescription = "私信", tint = GwTextPrimary, modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}
