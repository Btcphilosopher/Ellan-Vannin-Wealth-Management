package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Great Wall Gaming Palette:
// Chinese industrial modern consumer electronics
// Charcoal graphite, near-black, warm white, restrained cinnabar red accents, muted steel

val GwBackground = Color(0xFF0F1115)       // Deepest obsidian / graphite
val GwSurface = Color(0xFF171A21)          // Elevated console surface
val GwSurfaceVariant = Color(0xFF222631)   // Panel / card background
val GwSurfaceHigh = Color(0xFF2D3342)      // Focused / high elevation

val GwPrimaryRed = Color(0xFFDC2626)       // Restrained Chinese cinnabar red accent
val GwPrimaryRedGlow = Color(0x33DC2626)   // Subtle glow for active focus
val GwSteelMuted = Color(0xFF8B949E)       // Secondary metadata steel
val GwTextPrimary = Color(0xFFF0F3F6)      // Warm white text
val GwTextSecondary = Color(0xFFA0AAB7)    // Muted metadata text
val GwTextTertiary = Color(0xFF6B7280)     // Low-emphasis indicators

val GwBorderMuted = Color(0xFF2E3440)      // Sleek industrial border
val GwFocusBorder = Color(0xFFE2E8F0)      // Bright contrast focus border

val GwSuccess = Color(0xFF10B981)          // Diagnostic pass / online green
val GwWarning = Color(0xFFF59E0B)          // Warning amber
val GwError = Color(0xFFEF4444)            // Error red
val GwCyan = Color(0xFF06B6D4)             // Subtle telemetry cyan
