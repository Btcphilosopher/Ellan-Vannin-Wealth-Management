package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.Achievement
import com.example.ui.theme.*

@Composable
fun AchievementsScreen(
  achievements: List<Achievement>,
  modifier: Modifier = Modifier
) {
  val unlockedCount = achievements.count { it.isUnlocked }
  val totalCount = achievements.size
  val percent = if (totalCount > 0) (unlockedCount * 100) / totalCount else 0

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp, vertical = 16.dp)
  ) {
    // Header Overview
    Surface(
      color = GwSurface,
      shape = RoundedCornerShape(12.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(
            text = "主机成就馆",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = GwTextPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "已获得 $unlockedCount / $totalCount 项成就 • 完成度 $percent%",
            style = MaterialTheme.typography.bodyMedium,
            color = GwSteelMuted
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
          Column(horizontalAlignment = Alignment.End) {
            Text("稀有成就", style = MaterialTheme.typography.labelSmall, color = GwSteelMuted)
            Text("8 项", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = GwPrimaryRed)
          }
          Column(horizontalAlignment = Alignment.End) {
            Text("长城积分", style = MaterialTheme.typography.labelSmall, color = GwSteelMuted)
            Text("2,450 分", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = GwTextPrimary)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "成就列表",
      style = MaterialTheme.typography.titleMedium,
      fontWeight = FontWeight.Bold,
      color = GwTextPrimary
    )

    Spacer(modifier = Modifier.height(12.dp))

    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      items(achievements) { ach ->
        AchievementRow(achievement = ach)
      }
    }
  }
}

@Composable
fun AchievementRow(
  achievement: Achievement,
  modifier: Modifier = Modifier
) {
  Surface(
    color = if (achievement.isUnlocked) GwSurface else Color(0xFF13161C),
    shape = RoundedCornerShape(10.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, if (achievement.isUnlocked) GwBorderMuted else Color(0xFF1E232B)),
    modifier = modifier
      .fillMaxWidth()
      .testTag("ach_row_${achievement.id}")
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(if (achievement.isUnlocked) GwSurfaceVariant else Color(0xFF1B1E26)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (achievement.isUnlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
          contentDescription = null,
          tint = if (achievement.isUnlocked) GwPrimaryRed else GwTextTertiary,
          modifier = Modifier.size(24.dp)
        )
      }

      Spacer(modifier = Modifier.width(16.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = achievement.titleZh,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (achievement.isUnlocked) GwTextPrimary else GwTextTertiary
          )
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(GwSurfaceVariant)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = achievement.categoryZh,
              style = MaterialTheme.typography.labelSmall,
              color = GwSteelMuted
            )
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = achievement.descriptionZh,
          style = MaterialTheme.typography.bodySmall,
          color = if (achievement.isUnlocked) GwTextSecondary else GwTextTertiary
        )
      }

      Spacer(modifier = Modifier.width(16.dp))

      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = "稀有度: ${achievement.rarityPercent}%",
          style = MaterialTheme.typography.labelSmall,
          color = GwPrimaryRed
        )
        if (achievement.isUnlocked && achievement.unlockTimeZh.isNotEmpty()) {
          Text(
            text = achievement.unlockTimeZh,
            style = MaterialTheme.typography.labelSmall,
            color = GwSteelMuted
          )
        }
      }
    }
  }
}
