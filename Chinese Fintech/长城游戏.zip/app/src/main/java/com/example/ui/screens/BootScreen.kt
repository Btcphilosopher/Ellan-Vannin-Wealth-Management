package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

@Composable
fun BootScreen(
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "boot_pulse")
  val pulseAlpha by infiniteTransition.animateFloat(
    initialValue = 0.4f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "boot_glow"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF090B0E)),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      // Emblem Logo
      Image(
        painter = painterResource(id = R.drawable.img_gw_logo),
        contentDescription = "长城游戏标志",
        modifier = Modifier
          .size(130.dp)
          .scale(1.05f)
      )

      Spacer(modifier = Modifier.height(24.dp))

      Text(
        text = "长城游戏",
        style = MaterialTheme.typography.displayMedium,
        fontWeight = FontWeight.Bold,
        color = GwTextPrimary,
        letterSpacing = 4.sp
      )

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "GREAT WALL GAMING",
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.SemiBold,
        color = GwSteelMuted,
        letterSpacing = 5.sp
      )

      Spacer(modifier = Modifier.height(36.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.alpha(pulseAlpha)
      ) {
        Box(
          modifier = Modifier
            .size(6.dp)
            .background(GwPrimaryRed, shape = androidx.compose.foundation.shape.CircleShape)
        )
        Text(
          text = "长城OS 系统正在初始化内核服务...",
          style = MaterialTheme.typography.bodySmall,
          color = GwTextSecondary
        )
      }
    }

    // Bottom copyright and engine signature
    Column(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(bottom = 24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = "长城架构 APU 64-bit • RUST CORE PLATFORM • GWCOS 1.5.0",
        style = MaterialTheme.typography.labelSmall,
        color = Color(0xFF4B5563),
        letterSpacing = 1.sp
      )
    }
  }
}
