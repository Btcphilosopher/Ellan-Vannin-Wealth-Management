package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.platform.GreatWallPlatformApi
import com.example.platform.GreatWallPlatformService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
  val currentScreen: ConsoleScreen = ConsoleScreen.BOOT,
  val previousScreen: ConsoleScreen = ConsoleScreen.HOME,
  val isQuickMenuOpen: Boolean = false,
  val perfOverlayMode: PerformanceOverlayMode = PerformanceOverlayMode.OFF,
  val selectedGame: Game? = null,
  val userProfile: UserProfile = UserProfile(),
  val toastMessageZh: String? = null,
  val isSimulatingOffline: Boolean = false,
  val simulatedControllerDisconnected: Boolean = false,
  val simulatedStorageFull: Boolean = false,
  val isDiagnosticRunning: Boolean = false,
  val diagnosticResults: Map<String, Boolean> = emptyMap()
)

class ConsoleViewModel(
  private val platformApi: GreatWallPlatformApi = GreatWallPlatformService()
) : ViewModel() {

  private val _uiState = MutableStateFlow(UiState())
  val uiState: StateFlow<UiState> = _uiState.asStateFlow()

  val runningGame: StateFlow<Game?> = platformApi.observeCurrentRunningGame()
    .stateIn(viewModelScope, SharingStarted.Eagerly, null)

  val processState: StateFlow<GameProcessState> = platformApi.observeGameProcessState()
    .stateIn(viewModelScope, SharingStarted.Eagerly, GameProcessState.SUSPENDED)

  val controllerState: StateFlow<ControllerState> = platformApi.observeControllerState()
    .stateIn(viewModelScope, SharingStarted.Eagerly, ControllerState())

  val telemetry: StateFlow<SystemTelemetry> = platformApi.observeTelemetry()
    .stateIn(viewModelScope, SharingStarted.Eagerly, SystemTelemetry())

  val storage: StateFlow<StorageBreakdown> = platformApi.observeStorage()
    .stateIn(viewModelScope, SharingStarted.Eagerly, StorageBreakdown())

  val libraryGames: StateFlow<List<Game>> = platformApi.observeLibraryGames()
    .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

  val storeGames: StateFlow<List<Game>> = platformApi.observeStoreGames()
    .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

  val downloads: StateFlow<List<DownloadTask>> = platformApi.observeDownloads()
    .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

  val notifications: StateFlow<List<SystemNotification>> = platformApi.observeNotifications()
    .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

  // Sample static lists for social & achievements
  val achievements: List<Achievement> = listOf(
    Achievement("ach-1", "「万里长城」", "在《长城：边境》中完成九门关隘连续七日坚守", 8.4f, true, "2026-10-02 21:14", "史诗战役"),
    Achievement("ach-2", "「太极之巅」", "在《长安风云》中潜入大明宫顶层无声解除玄武机关", 14.2f, true, "2026-10-04 18:20", "隐秘暗影"),
    Achievement("ach-3", "「吞吐星河」", "在《星河远征》中完成超光速跳跃引擎首次组装测试", 22.0f, true, "2026-10-06 14:05", "深空启航"),
    Achievement("ach-4", "「大荒伏兽」", "在《山海纪元》中单人无伤降伏穷奇巨兽", 4.1f, false, "", "极限挑战"),
    Achievement("ach-5", "「百战不殆」", "累计在长城主机上游玩超过500小时", 12.5f, false, "", "主机荣耀"),
    Achievement("ach-6", "「天工开物」", "收集全部第一方游戏典藏级原画与音乐原声", 18.9f, true, "2026-09-28 10:45", "鉴赏专家")
  )

  val friends: List<Friend> = listOf(
    Friend("f-1", "李明 (大理寺断案)", "GW_910243", true, "《长安风云》", 426, "正在调查朱雀大街密道..."),
    Friend("f-2", "张伟 (塞外游侠)", "GW_334182", true, "《长城：边境》", 289, "九门烽火台联防组队中"),
    Friend("f-3", "刘云 (星舰指挥官)", "GW_552190", true, "《星河远征》", 512, "深空矿脉勘探第二象限"),
    Friend("f-4", "陈晓 (大荒猎手)", "GW_667231", false, "离线", 188, "上次在线：2小时前"),
    Friend("f-5", "王强 (墨家传人)", "GW_771890", false, "离线", 345, "上次在线：昨天")
  )

  init {
    // Restrained premium boot sequence
    viewModelScope.launch {
      delay(2200) // Brief boot reveal
      _uiState.update { it.copy(currentScreen = ConsoleScreen.HOME) }
    }
  }

  fun navigateTo(screen: ConsoleScreen) {
    _uiState.update {
      it.copy(
        previousScreen = if (it.currentScreen != screen) it.currentScreen else it.previousScreen,
        currentScreen = screen,
        isQuickMenuOpen = false
      )
    }
  }

  fun navigateBack() {
    val current = _uiState.value.currentScreen
    if (_uiState.value.isQuickMenuOpen) {
      toggleQuickMenu()
      return
    }
    if (current == ConsoleScreen.RUNNING_GAME_VIEW) {
      // Suspend game and return home
      viewModelScope.launch {
        platformApi.suspendCurrentGame()
        _uiState.update { it.copy(currentScreen = ConsoleScreen.HOME) }
      }
      return
    }
    val fallback = when (current) {
      ConsoleScreen.HOME -> ConsoleScreen.HOME
      ConsoleScreen.BOOT -> ConsoleScreen.HOME
      ConsoleScreen.GAME_DETAIL -> _uiState.value.previousScreen
      ConsoleScreen.DEVELOPER_OPTIONS -> ConsoleScreen.SETTINGS
      ConsoleScreen.DIAGNOSTICS -> ConsoleScreen.SETTINGS
      else -> ConsoleScreen.HOME
    }
    _uiState.update { it.copy(currentScreen = fallback) }
  }

  fun toggleQuickMenu() {
    _uiState.update { it.copy(isQuickMenuOpen = !it.isQuickMenuOpen) }
  }

  fun cyclePerfOverlay() {
    _uiState.update {
      val next = when (it.perfOverlayMode) {
        PerformanceOverlayMode.OFF -> PerformanceOverlayMode.COMPACT
        PerformanceOverlayMode.COMPACT -> PerformanceOverlayMode.DETAILED
        PerformanceOverlayMode.DETAILED -> PerformanceOverlayMode.OFF
      }
      it.copy(perfOverlayMode = next)
    }
  }

  fun selectGame(game: Game) {
    _uiState.update { it.copy(selectedGame = game) }
    navigateTo(ConsoleScreen.GAME_DETAIL)
  }

  fun launchOrResumeGame(game: Game) {
    viewModelScope.launch {
      _uiState.update { it.copy(selectedGame = game, isQuickMenuOpen = false) }
      platformApi.launchGame(game.id)
      _uiState.update { it.copy(currentScreen = ConsoleScreen.RUNNING_GAME_VIEW) }
      showToast("《${game.titleZh}》已启动运行")
    }
  }

  fun suspendCurrentGame() {
    viewModelScope.launch {
      platformApi.suspendCurrentGame()
      showToast("游戏已挂起并保存现场")
    }
  }

  fun terminateCurrentGame() {
    viewModelScope.launch {
      platformApi.terminateCurrentGame()
      _uiState.update { it.copy(currentScreen = ConsoleScreen.HOME, isQuickMenuOpen = false) }
      showToast("游戏已安全退出")
    }
  }

  fun purchaseGame(game: Game) {
    viewModelScope.launch {
      platformApi.purchaseGame(game.id)
      showToast("购买成功！已加入长城ID游戏库并启动下载")
    }
  }

  fun uninstallGame(game: Game) {
    viewModelScope.launch {
      platformApi.uninstallGame(game.id)
      showToast("已成功卸载《${game.titleZh}》")
      if (_uiState.value.selectedGame?.id == game.id) {
        _uiState.update { it.copy(selectedGame = it.selectedGame?.copy(isInstalled = false)) }
      }
    }
  }

  fun syncCloudSave(gameId: String) {
    viewModelScope.launch {
      val res = platformApi.syncCloudSave(gameId)
      showToast(res.getOrDefault("云存档同步完成"))
    }
  }

  fun cleanCache() {
    viewModelScope.launch {
      val freed = platformApi.cleanCache().getOrDefault(0f)
      showToast("已清理系统缓存 ${String.format("%.1f", freed)} GB")
    }
  }

  fun pauseDownload(taskId: String) {
    viewModelScope.launch { platformApi.pauseDownload(taskId) }
  }

  fun resumeDownload(taskId: String) {
    viewModelScope.launch { platformApi.resumeDownload(taskId) }
  }

  fun cancelDownload(taskId: String) {
    viewModelScope.launch { platformApi.cancelDownload(taskId) }
  }

  fun runFullDiagnostics() {
    viewModelScope.launch {
      _uiState.update { it.copy(isDiagnosticRunning = true) }
      val tests = listOf("网络", "存储", "手柄", "音频", "显示", "系统文件完整性")
      val results = mutableMapOf<String, Boolean>()
      for (test in tests) {
        delay(350)
        results[test] = true
        _uiState.update { it.copy(diagnosticResults = results.toMap()) }
      }
      _uiState.update { it.copy(isDiagnosticRunning = false) }
      showToast("系统诊断全部通过 (6/6 项目正常)")
    }
  }

  // Developer Simulation Toggles
  fun toggleSimulateOffline() {
    _uiState.update { it.copy(isSimulatingOffline = !it.isSimulatingOffline) }
    showToast(if (_uiState.value.isSimulatingOffline) "已启用：离线安全模式" else "已恢复：网络连接正常")
  }

  fun toggleSimulateControllerDisconnect() {
    _uiState.update { it.copy(simulatedControllerDisconnected = !it.simulatedControllerDisconnected) }
    showToast(if (_uiState.value.simulatedControllerDisconnected) "模拟事件：手柄连接中断" else "模拟事件：手柄重新连接 (2.4GHz)")
  }

  fun toggleSimulateStorageFull() {
    _uiState.update { it.copy(simulatedStorageFull = !it.simulatedStorageFull) }
    showToast(if (_uiState.value.simulatedStorageFull) "模拟报警：NVMe存储空间不足 (剩余 < 5GB)" else "模拟恢复：NVMe存储配额正常")
  }

  fun showToast(msg: String) {
    viewModelScope.launch {
      _uiState.update { it.copy(toastMessageZh = msg) }
      delay(3000)
      if (_uiState.value.toastMessageZh == msg) {
        _uiState.update { it.copy(toastMessageZh = null) }
      }
    }
  }
}
