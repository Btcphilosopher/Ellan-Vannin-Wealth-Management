package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Game
import com.example.ui.theme.*

@Composable
fun GameDetailScreen(
  game: Game?,
  onBack: () -> Unit,
  onLaunch: (Game) -> Unit,
  onSyncSave: (String) -> Unit,
  onUninstall: (Game) -> Unit,
  onPurchase: (Game) -> Unit,
  modifier: Modifier = Modifier
) {
  if (game == null) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("未选择游戏", color = GwTextSecondary)
    }
    return
  }

  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(horizontal = 24.dp, vertical = 16.dp)
  ) {
    // Back navigation button
    Row(verticalAlignment = Alignment.CenterVertically) {
      IconButton(
        onClick = onBack,
        modifier = Modifier
          .clip(RoundedCornerShape(8.dp))
          .background(GwSurfaceVariant)
          .testTag("game_detail_back")
      ) {
        Icon(Icons.Default.ArrowBack, contentDescription = "返回", tint = GwTextPrimary)
      }
      Spacer(modifier = Modifier.width(12.dp))
      Text(
        text = "游戏详情",
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = GwTextPrimary
      )
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Main Hero Box
    Surface(
      color = GwSurface,
      shape = RoundedCornerShape(14.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(modifier = Modifier.padding(20.dp)) {
        Box(
          modifier = Modifier
            .size(width = 300.dp, height = 180.dp)
            .clip(RoundedCornerShape(10.dp))
        ) {
          Image(
            painter = painterResource(id = game.coverDrawableRes),
            contentDescription = game.titleZh,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        }

        Spacer(modifier = Modifier.width(24.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = game.titleZh,
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Bold,
            color = GwTextPrimary
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = game.subtitleZh,
            style = MaterialTheme.typography.titleMedium,
            color = GwTextSecondary
          )
          Spacer(modifier = Modifier.height(8.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(text = "版本：${game.version}", style = MaterialTheme.typography.bodySmall, color = GwSteelMuted)
            Text(text = "大小：${game.fileSizeGb} GB", style = MaterialTheme.typography.bodySmall, color = GwSteelMuted)
            Text(text = "适龄提示：${game.ageRatingZh}", style = MaterialTheme.typography.bodySmall, color = GwSteelMuted)
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Primary Actions Bar
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (game.isInstalled) {
              Button(
                onClick = { onLaunch(game) },
                colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("detail_btn_launch")
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("开始游戏")
              }

              OutlinedButton(
                onClick = { onSyncSave(game.id) },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("detail_btn_sync_save")
              ) {
                Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("同步云存档")
              }

              OutlinedButton(
                onClick = { onUninstall(game) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = GwError),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("detail_btn_uninstall")
              ) {
                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("卸载")
              }
            } else {
              if (game.priceCny > 0) {
                Button(
                  onClick = { onPurchase(game) },
                  colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.testTag("detail_btn_buy")
                ) {
                  Text("立即购买 (¥ ${game.priceCny})")
                }
              } else {
                Button(
                  onClick = { onPurchase(game) },
                  colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.testTag("detail_btn_install")
                ) {
                  Text("下载并安装")
                }
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Detailed Specifications and Info
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Left: Description & Developer Credits
      Column(modifier = Modifier.weight(1.5f)) {
        Surface(
          color = GwSurface,
          shape = RoundedCornerShape(10.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Text(
              text = "关于作品",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = GwTextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = game.descriptionZh,
              style = MaterialTheme.typography.bodyLarge,
              color = GwTextSecondary,
              lineHeight = 24.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = GwBorderMuted)
            Spacer(modifier = Modifier.height(12.dp))
            Text(text = "开发商：${game.developerZh}", style = MaterialTheme.typography.bodyMedium, color = GwSteelMuted)
            Text(text = "发行商：${game.publisherZh}", style = MaterialTheme.typography.bodyMedium, color = GwSteelMuted)
            Text(text = "类型：${game.genreZh}", style = MaterialTheme.typography.bodyMedium, color = GwSteelMuted)
          }
        }
      }

      // Right: Console Hardware & Save Stats
      Column(modifier = Modifier.weight(1f)) {
        Surface(
          color = GwSurface,
          shape = RoundedCornerShape(10.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(18.dp)) {
            Text(
              text = "长城主机运行特性",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = GwTextPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text("✓ 4K 60FPS 极速原生渲染", style = MaterialTheme.typography.bodySmall, color = GwSuccess)
            Text("✓ 硬件光线追踪 (Ray Tracing)", style = MaterialTheme.typography.bodySmall, color = GwSuccess)
            Text("✓ 长城手柄高级触觉振动 (Haptics)", style = MaterialTheme.typography.bodySmall, color = GwSuccess)
            Text("✓ 全景空间音频 (Dolby Atmos)", style = MaterialTheme.typography.bodySmall, color = GwSuccess)
            Text("✓ NVMe 高速直读架构 (DirectStorage)", style = MaterialTheme.typography.bodySmall, color = GwSuccess)
            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = GwBorderMuted)
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = "成就进度：${game.unlockedAchievements} / ${game.achievementsCount}", style = MaterialTheme.typography.bodyMedium, color = GwTextPrimary)
            Text(text = "云存档状态：SHA-256 加密同步正常", style = MaterialTheme.typography.bodySmall, color = GwSteelMuted)
          }
        }
      }
    }
  }
}
