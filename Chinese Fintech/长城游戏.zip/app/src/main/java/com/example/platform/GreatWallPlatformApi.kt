package com.example.platform

import com.example.model.*
import kotlinx.coroutines.flow.Flow

/**
 * Strongly typed interface mirroring the Rust libgw_platform IPC architecture.
 * Rust owns authoritative system truth; Kotlin owns presentation and navigation.
 */
interface GreatWallPlatformApi {
  // Game lifecycle and process supervisor
  fun observeCurrentRunningGame(): Flow<Game?>
  fun observeGameProcessState(): Flow<GameProcessState>
  suspend fun launchGame(gameId: String): Result<Boolean>
  suspend fun suspendCurrentGame(): Result<Boolean>
  suspend fun resumeCurrentGame(): Result<Boolean>
  suspend fun terminateCurrentGame(): Result<Boolean>

  // Game catalogue and entitlements
  fun observeLibraryGames(): Flow<List<Game>>
  fun observeStoreGames(): Flow<List<Game>>
  suspend fun purchaseGame(gameId: String): Result<Boolean>
  suspend fun uninstallGame(gameId: String): Result<Boolean>

  // Download engine (Priority Queue & SHA-256 integrity verification)
  fun observeDownloads(): Flow<List<DownloadTask>>
  suspend fun startDownload(gameId: String): Result<Boolean>
  suspend fun pauseDownload(taskId: String): Result<Boolean>
  suspend fun resumeDownload(taskId: String): Result<Boolean>
  suspend fun cancelDownload(taskId: String): Result<Boolean>

  // Cloud Save Manager
  suspend fun syncCloudSave(gameId: String): Result<String>

  // Controller HAL
  fun observeControllerState(): Flow<ControllerState>
  suspend fun setControllerHaptics(intensity: Int): Result<Boolean>

  // Diagnostics and System Telemetry
  fun observeTelemetry(): Flow<SystemTelemetry>
  fun observeStorage(): Flow<StorageBreakdown>
  suspend fun cleanCache(): Result<Float>

  // System updates (Atomic dual-slot A/B)
  suspend fun checkSystemUpdate(): Result<String>
  suspend fun applySystemUpdate(): Result<Boolean>

  // Notifications
  fun observeNotifications(): Flow<List<SystemNotification>>
}
