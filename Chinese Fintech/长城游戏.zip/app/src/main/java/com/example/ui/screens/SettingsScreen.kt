package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.ControllerState
import com.example.model.UserProfile
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
  userProfile: UserProfile,
  controllerState: ControllerState,
  onNavigateDiagnostics: () -> Unit,
  onNavigateDeveloper: () -> Unit,
  onSetHaptics: (Int) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedCategory by remember { mutableStateOf("系统") }
  val categories = listOf(
    Pair("系统", Icons.Default.Computer),
    Pair("账户与长城ID", Icons.Default.Person),
    Pair("手柄与外设", Icons.Default.SportsEsports),
    Pair("显示与画面", Icons.Default.Tv),
    Pair("声音与音频", Icons.Default.VolumeUp),
    Pair("网络与连接", Icons.Default.Wifi),
    Pair("家长控制", Icons.Default.FamilyRestroom),
    Pair("辅助功能", Icons.Default.Accessibility),
    Pair("关于长城OS", Icons.Default.Info)
  )

  Row(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp, vertical = 16.dp),
    horizontalArrangement = Arrangement.spacedBy(24.dp)
  ) {
    // Left sidebar: categories
    Surface(
      color = GwSurface,
      shape = RoundedCornerShape(12.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier
        .width(240.dp)
        .fillMaxHeight()
    ) {
      LazyColumn(
        modifier = Modifier.padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        items(categories) { (name, icon) ->
          val isSelected = selectedCategory == name
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) GwSurfaceVariant else Color.Transparent)
              .clickable { selectedCategory = name }
              .padding(horizontal = 14.dp, vertical = 12.dp)
              .testTag("settings_cat_$name")
          ) {
            Icon(
              imageVector = icon,
              contentDescription = name,
              tint = if (isSelected) GwPrimaryRed else GwSteelMuted,
              modifier = Modifier.size(20.dp)
            )
            Text(
              text = name,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              color = if (isSelected) GwTextPrimary else GwTextSecondary
            )
          }
        }
      }
    }

    // Right pane: detail settings for selected category
    Surface(
      color = GwSurface,
      shape = RoundedCornerShape(12.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier
        .weight(1f)
        .fillMaxHeight()
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(24.dp)
          .verticalScroll(rememberScrollState())
      ) {
        when (selectedCategory) {
          "系统" -> SystemSettingsPane(
            onNavigateDiagnostics = onNavigateDiagnostics,
            onNavigateDeveloper = onNavigateDeveloper
          )
          "手柄与外设" -> ControllerSettingsPane(
            controllerState = controllerState,
            onSetHaptics = onSetHaptics
          )
          "账户与长城ID" -> AccountSettingsPane(userProfile = userProfile)
          "家长控制" -> ParentalControlsPane()
          "显示与画面" -> DisplaySettingsPane()
          "网络与连接" -> NetworkSettingsPane()
          else -> GenericSettingsPane(title = selectedCategory)
        }
      }
    }
  }
}

@Composable
fun SystemSettingsPane(
  onNavigateDiagnostics: () -> Unit,
  onNavigateDeveloper: () -> Unit
) {
  Text(text = "系统与维护", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
  Spacer(modifier = Modifier.height(16.dp))

  SettingRowAction("系统更新", "当前版本 长城OS v1.4.2 (最新稳定版 v1.5.0 已准备就绪)") { /* Update check */ }
  SettingRowAction("系统硬件与诊断", "运行网络、存储、手柄与完整性自检", onClick = onNavigateDiagnostics)
  SettingRowAction("开发者选项", "GPU/CPU 性能模拟、崩溃测试与底层日志", onClick = onNavigateDeveloper)
  SettingRowToggle("自动休眠", "闲置20分钟后自动进入低功耗待机模式", initial = true)
}

@Composable
fun ControllerSettingsPane(
  controllerState: ControllerState,
  onSetHaptics: (Int) -> Unit
) {
  Text(text = "长城手柄与输入设备", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
  Spacer(modifier = Modifier.height(16.dp))

  Text(text = "当前连接设备：${controllerState.nameZh}", style = MaterialTheme.typography.titleMedium, color = GwTextPrimary)
  Text(text = "连接方式：${controllerState.connectionType} • 固件版本：${controllerState.firmwareVersion}", style = MaterialTheme.typography.bodySmall, color = GwSteelMuted)

  Spacer(modifier = Modifier.height(20.dp))

  Text(text = "手柄触觉振动强度 (Haptics)：${controllerState.vibrationIntensity}%", style = MaterialTheme.typography.bodyMedium, color = GwTextPrimary)
  Slider(
    value = controllerState.vibrationIntensity.toFloat(),
    onValueChange = { onSetHaptics(it.toInt()) },
    valueRange = 0f..100f,
    colors = SliderDefaults.colors(thumbColor = GwPrimaryRed, activeTrackColor = GwPrimaryRed)
  )

  Spacer(modifier = Modifier.height(16.dp))
  SettingRowToggle("扳机阻尼自适应反馈", "在射箭与冷兵器碰撞时提供物理阻力反馈", initial = true)
  SettingRowToggle("手柄状态呼吸指示灯", "与游戏主色调及血量状态实时联动", initial = true)
}

@Composable
fun AccountSettingsPane(userProfile: UserProfile) {
  Text(text = "长城ID与安全", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
  Spacer(modifier = Modifier.height(16.dp))

  Text(text = "长城ID：${userProfile.greatWallId}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = GwTextPrimary)
  Text(text = "玩家昵称：${userProfile.nicknameZh} (等级 Lv.${userProfile.level})", style = MaterialTheme.typography.bodyMedium, color = GwSteelMuted)
  Text(text = "会员权益：${userProfile.vipStatusZh}", style = MaterialTheme.typography.bodyMedium, color = GwPrimaryRed)

  Spacer(modifier = Modifier.height(20.dp))
  SettingRowToggle("自动云存档同步", "游戏退出或挂起时自动加密上传至长城私有安全云", initial = true)
  SettingRowToggle("游戏内好友上线提醒", "有好友上线或发起队伍邀请时弹出提示", initial = true)
}

@Composable
fun ParentalControlsPane() {
  Text(text = "家长控制与健康游戏保护", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
  Spacer(modifier = Modifier.height(16.dp))

  Text("每日游戏时长限制：2 小时", style = MaterialTheme.typography.bodyMedium, color = GwTextPrimary)
  Text("允许游玩时间段：08:00 – 21:00", style = MaterialTheme.typography.bodyMedium, color = GwTextPrimary)
  Text("游戏适龄上限：16岁及以下", style = MaterialTheme.typography.bodyMedium, color = GwTextPrimary)

  Spacer(modifier = Modifier.height(16.dp))
  SettingRowToggle("商城购买人脸/密码二级验证", "防范未成年人家长未授权充值与消费", initial = true)
  SettingRowToggle("就寝时间强制锁屏守护", "到达设定就寝时点后平滑保存游戏并锁机", initial = true)
}

@Composable
fun DisplaySettingsPane() {
  Text(text = "显示与画面输出", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
  Spacer(modifier = Modifier.height(16.dp))

  SettingRowAction("输出分辨率", "3840 x 2160 (4K 60Hz 自动适配)") {}
  SettingRowToggle("HDR10+ 高动态范围", "扩展亮部细节与深邃暗场表现", initial = true)
  SettingRowToggle("可变刷新率 (VRR)", "消除画面撕裂，提供极速流畅竞技体验", initial = true)
  SettingRowToggle("长城低延迟游戏模式 (ALLM)", "HDMI 2.1 自动开启电视超低延迟模式", initial = true)
}

@Composable
fun NetworkSettingsPane() {
  Text(text = "网络连接配置", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
  Spacer(modifier = Modifier.height(16.dp))

  SettingRowAction("当前连接", "千兆有线以太网 (IPv4: 192.168.1.108)") {}
  SettingRowAction("长城游戏专用加速专网", "已直连华东低延迟专线 (平均延迟 24ms)") {}
  SettingRowToggle("局域网设备互联发现", "允许在同一家庭Wi-Fi中发现并联机长城主机", initial = true)
}

@Composable
fun GenericSettingsPane(title: String) {
  Text(text = title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = GwTextPrimary)
  Spacer(modifier = Modifier.height(16.dp))
  Text(text = "已启用长城OS智能默认配置，完全支持主机手柄与电视视距交互。", color = GwTextSecondary)
}

@Composable
fun SettingRowToggle(title: String, subtitle: String, initial: Boolean) {
  var checked by remember { mutableStateOf(initial) }
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 12.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium, color = GwTextPrimary)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = GwSteelMuted)
    }
    Switch(
      checked = checked,
      onCheckedChange = { checked = it },
      colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = GwPrimaryRed)
    )
  }
  Divider(color = GwBorderMuted)
}

@Composable
fun SettingRowAction(title: String, subtitle: String, onClick: () -> Unit) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(vertical = 12.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium, color = GwTextPrimary)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = GwSteelMuted)
    }
    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = GwSteelMuted)
  }
  Divider(color = GwBorderMuted)
}
