package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Game
import com.example.ui.theme.*

@Composable
fun StoreScreen(
  storeGames: List<Game>,
  onGameClick: (Game) -> Unit,
  onPurchase: (Game) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedCategory by remember { mutableStateOf("国产游戏精选") }
  val categories = listOf("国产游戏精选", "独立开发者", "国产大作", "新锐工作室", "编辑推荐", "免费试玩")

  val scrollState = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(horizontal = 24.dp, vertical = 16.dp)
  ) {
    // Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "长城数字游戏商店",
          style = MaterialTheme.typography.headlineLarge,
          fontWeight = FontWeight.Bold,
          color = GwTextPrimary
        )
        Text(
          text = "聚焦高品质中国游戏创作 • 数字版权直连长城ID",
          style = MaterialTheme.typography.bodyMedium,
          color = GwSteelMuted
        )
      }

      Surface(
        color = GwSurfaceVariant,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted)
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.ShoppingCart,
            contentDescription = "购物车",
            tint = GwPrimaryRed,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = "账户余额：¥ 680.00",
            style = MaterialTheme.typography.labelMedium,
            color = GwTextPrimary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Categories filter bar
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      contentPadding = PaddingValues(vertical = 4.dp)
    ) {
      items(categories) { cat ->
        val isSelected = selectedCategory == cat
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) GwPrimaryRed else GwSurfaceVariant)
            .clickable { selectedCategory = cat }
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("store_cat_$cat")
        ) {
          Text(
            text = cat,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.White else GwTextSecondary
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Editorial Spotlight Banner
    Surface(
      color = GwSurface,
      shape = RoundedCornerShape(14.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
      modifier = Modifier
        .fillMaxWidth()
        .height(180.dp)
        .clickable {
          storeGames.firstOrNull()?.let(onGameClick)
        }
        .testTag("store_spotlight_banner")
    ) {
      Row(
        modifier = Modifier.fillMaxSize(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(
          modifier = Modifier
            .weight(1f)
            .padding(24.dp),
          verticalArrangement = Arrangement.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(Icons.Default.Star, contentDescription = null, tint = GwPrimaryRed, modifier = Modifier.size(16.dp))
            Text("本周编辑强推", style = MaterialTheme.typography.labelSmall, color = GwPrimaryRed, fontWeight = FontWeight.Bold)
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text("《长安风云：终极典藏版》", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = GwTextPrimary)
          Spacer(modifier = Modifier.height(4.dp))
          Text("包含全季扩展包「九霄天枢」与全套宫廷定制冷兵器外观礼包", style = MaterialTheme.typography.bodyMedium, color = GwTextSecondary)
          Spacer(modifier = Modifier.height(12.dp))
          Text("¥ 298.00  (首周立享85折)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = GwSuccess)
        }

        Image(
          painter = painterResource(id = storeGames.firstOrNull()?.coverDrawableRes ?: com.example.R.drawable.img_changan),
          contentDescription = "推荐大作封面",
          contentScale = ContentScale.Crop,
          modifier = Modifier
            .width(260.dp)
            .fillMaxHeight()
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    Text(
      text = "精选游戏列表",
      style = MaterialTheme.typography.headlineMedium,
      fontWeight = FontWeight.Bold,
      color = GwTextPrimary
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Store Grid
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
      storeGames.forEach { game ->
        StoreProductRow(
          game = game,
          onClick = { onGameClick(game) },
          onPurchase = { onPurchase(game) }
        )
      }
    }
  }
}

@Composable
fun StoreProductRow(
  game: Game,
  onClick: () -> Unit,
  onPurchase: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = GwSurface,
    shape = RoundedCornerShape(10.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, GwBorderMuted),
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .testTag("store_row_${game.id}")
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(width = 140.dp, height = 80.dp)
          .clip(RoundedCornerShape(8.dp))
      ) {
        Image(
          painter = painterResource(id = game.coverDrawableRes),
          contentDescription = game.titleZh,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )
      }

      Spacer(modifier = Modifier.width(16.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = game.titleZh,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = GwTextPrimary
        )
        Text(
          text = "${game.developerZh} • ${game.genreZh}",
          style = MaterialTheme.typography.bodySmall,
          color = GwSteelMuted
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "适龄提示: ${game.ageRatingZh} • 安装包大小: ${game.fileSizeGb} GB",
          style = MaterialTheme.typography.labelSmall,
          color = GwTextSecondary
        )
      }

      Spacer(modifier = Modifier.width(16.dp))

      Column(horizontalAlignment = Alignment.End) {
        if (game.priceCny > 0) {
          Text(
            text = "¥ ${game.priceCny}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = GwTextPrimary
          )
          Spacer(modifier = Modifier.height(6.dp))
          Button(
            onClick = onPurchase,
            colors = ButtonDefaults.buttonColors(containerColor = GwPrimaryRed),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.testTag("btn_buy_${game.id}")
          ) {
            Text("立即购买", fontSize = 12.sp)
          }
        } else {
          Text(
            text = if (game.isInstalled) "已安装" else "已拥有",
            style = MaterialTheme.typography.bodyMedium,
            color = GwSuccess
          )
          Spacer(modifier = Modifier.height(6.dp))
          OutlinedButton(
            onClick = onClick,
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.testTag("btn_view_${game.id}")
          ) {
            Text("查看", fontSize = 12.sp)
          }
        }
      }
    }
  }
}
