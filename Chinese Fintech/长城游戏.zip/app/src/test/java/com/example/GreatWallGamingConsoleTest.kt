package com.example

import com.example.model.Game
import com.example.model.GameProcessState
import com.example.platform.GreatWallPlatformService
import com.example.viewmodel.ConsoleViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GreatWallGamingConsoleTest {

  private val testDispatcher = StandardTestDispatcher()

  @Before
  fun setUp() {
    Dispatchers.setMain(testDispatcher)
  }

  @After
  fun tearDown() {
    Dispatchers.resetMain()
  }

  @Test
  fun testPlatformServiceInitialState() = runTest {
    val service = GreatWallPlatformService()
    val games = service.observeLibraryGames().first()
    assertTrue("Initial library should contain default Chinese titles", games.isNotEmpty())
    assertEquals("《长安风云》", games[0].titleZh)

    val telemetry = service.observeTelemetry().first()
    assertTrue("Telemetry FPS should be initialized", telemetry.fps > 0)

    val storage = service.observeStorage().first()
    assertEquals(512.0f, storage.totalGb, 0.1f)
  }

  @Test
  fun testGameLaunchLifecycle() = runTest {
    val service = GreatWallPlatformService()
    val result = service.launchGame("gw-game-001")
    assertTrue("Game launch should succeed", result.isSuccess)

    val runningGame = service.observeCurrentRunningGame().first()
    assertNotNull("Running game should not be null after launch", runningGame)
    assertEquals("gw-game-001", runningGame?.id)

    val processState = service.observeGameProcessState().first()
    assertEquals(GameProcessState.RUNNING, processState)
  }

  @Test
  fun testConsoleViewModelNavigation() = runTest {
    val service = GreatWallPlatformService()
    val viewModel = ConsoleViewModel(service)

    // Initial state check
    assertEquals(com.example.model.ConsoleScreen.BOOT, viewModel.uiState.value.currentScreen)

    // Navigate to Library
    viewModel.navigateTo(com.example.model.ConsoleScreen.LIBRARY)
    assertEquals(com.example.model.ConsoleScreen.LIBRARY, viewModel.uiState.value.currentScreen)

    // Toggle Quick Menu
    viewModel.toggleQuickMenu()
    assertTrue("Quick menu should be open", viewModel.uiState.value.isQuickMenuOpen)

    viewModel.navigateBack()
    assertTrue("Quick menu should close on back navigation", !viewModel.uiState.value.isQuickMenuOpen)
  }
}
