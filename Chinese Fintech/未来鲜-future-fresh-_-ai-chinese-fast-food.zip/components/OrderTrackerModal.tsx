'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { CheckCircle2, RotateCw, X, Sparkles, MapPin, Cpu, ArrowRight } from 'lucide-react';

export default function OrderTrackerModal() {
  const { lang, activeOrder, isOrderModalOpen, setIsOrderModalOpen, cancelOrder } = useApp();
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    if (!activeOrder) return;
    const t = setInterval(() => {
      setElapsed(e => e + 1);
    }, 1000);
    return () => clearInterval(t);
  }, [activeOrder]);

  if (!isOrderModalOpen || !activeOrder) return null;

  const currentStep = activeOrder.currentStep;
  const secondsRemaining = Math.max(0, 150 - (currentStep * 40) - (elapsed % 40));

  const steps = [
    {
      titleZh: '系统确认 · 排队进入厨房',
      titleEn: 'Order Queued',
      descZh: '智能中枢已下发菜谱参数至 02号 炒菜机器人工位',
      descEn: 'Recipe parameters dispatched to Wok Station #02'
    },
    {
      titleZh: '280°C 双臂现炒进行中',
      titleEn: '280°C Robotic Wok Tossing',
      descZh: 'IH聚能瞬时大火爆炒，六轴机械臂颠锅提香中',
      descEn: 'Robotic wok tossing chicken & aromatics at 280°C'
    },
    {
      titleZh: '光谱质检 · 自动无尘装盘',
      titleEn: 'Spectral QC & Clean Plating',
      descZh: '激光测温达标，机械臂自动滑入保温出餐口',
      descEn: 'Temperature verified, automatic plate sliding'
    },
    {
      titleZh: activeOrder.diningMode === 'dine_in' ? '送餐机器人启程 · 送达您的桌位' : '出餐完成 · 叫号或到柜取餐',
      titleEn: activeOrder.diningMode === 'dine_in' ? 'Runner Bot En Route to Table' : 'Ready for Pickup',
      descZh: activeOrder.diningMode === 'dine_in'
        ? `03号送餐机器人正携带恒温保温箱驶向 ${activeOrder.tableNumber || '08'} 号桌`
        : `请凭取餐码 ${activeOrder.pickupCode} 到柜台或保温取餐柜自提`,
      descEn: activeOrder.diningMode === 'dine_in'
        ? `Autonomous bot en route to Table ${activeOrder.tableNumber || '08'}`
        : `Collect at pickup counter using code ${activeOrder.pickupCode}`
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-lg rounded-3xl bg-zinc-900 border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-white/10 bg-gradient-to-r from-red-950/80 via-zinc-900 to-zinc-900 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                {lang === 'zh' ? '机器人正在现炒' : 'Robotic Kitchen Active'}
              </span>
            </div>
            <h3 className="text-xl font-black text-white mt-0.5">
              {lang === 'zh' ? '实时出餐监控看板' : 'Real-Time Cooking Monitor'}
            </h3>
          </div>

          <button
            onClick={() => setIsOrderModalOpen(false)}
            className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Pickup Code & ETA Banner */}
        <div className="p-6 bg-zinc-950 border-b border-white/5 flex items-center justify-between">
          <div>
            <span className="text-xs text-zinc-400">
              {lang === 'zh' ? '取餐号 / 追踪码' : 'Pickup / Tracking Code'}
            </span>
            <div className="text-3xl font-black text-red-500 font-mono tracking-wider mt-0.5">
              {activeOrder.pickupCode}
            </div>
            {activeOrder.tableNumber && (
              <span className="text-xs text-zinc-300">
                {lang === 'zh' ? `入座：${activeOrder.tableNumber}号桌` : `Table: #${activeOrder.tableNumber}`}
              </span>
            )}
          </div>

          <div className="text-right">
            <span className="text-xs text-zinc-400">
              {lang === 'zh' ? '预计剩余出餐时间' : 'Est. Serving Wait'}
            </span>
            <div className="text-2xl font-black text-white font-mono tabular-nums mt-0.5">
              {Math.floor(secondsRemaining / 60)}:{(secondsRemaining % 60).toString().padStart(2, '0')}
            </div>
            <span className="text-[11px] text-amber-400">
              {lang === 'zh' ? '现炒极速出锅' : 'Fresh off the wok'}
            </span>
          </div>
        </div>

        {/* 4-Step Tracker list */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          {steps.map((s, idx) => {
            const isDone = activeOrder.currentStep > idx;
            const isCurrent = activeOrder.currentStep === idx;
            const isPending = activeOrder.currentStep < idx;

            return (
              <div key={s.titleZh} className="flex gap-4">
                {/* Step icon connector */}
                <div className="flex flex-col items-center">
                  <div
                    className={`h-9 w-9 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                      isDone
                        ? 'bg-emerald-500 text-white'
                        : isCurrent
                        ? 'bg-red-600 text-white shadow-[0_0_15px_rgba(239,68,68,0.5)] ring-4 ring-red-500/20'
                        : 'bg-zinc-800 text-zinc-500 border border-zinc-700'
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="h-5 w-5" />
                    ) : isCurrent ? (
                      <RotateCw className="h-4 w-4 animate-spin" />
                    ) : (
                      idx + 1
                    )}
                  </div>
                  {idx < steps.length - 1 && (
                    <div
                      className={`w-0.5 h-10 mt-1 ${
                        isDone ? 'bg-emerald-500/60' : 'bg-zinc-800'
                      }`}
                    />
                  )}
                </div>

                {/* Step description */}
                <div className="pt-1">
                  <div className="flex items-center gap-2">
                    <h4
                      className={`text-sm font-bold ${
                        isCurrent ? 'text-white' : isDone ? 'text-emerald-400' : 'text-zinc-500'
                      }`}
                    >
                      {lang === 'zh' ? s.titleZh : s.titleEn}
                    </h4>
                    {isCurrent && (
                      <span className="text-[10px] font-mono font-semibold text-red-400 bg-red-950/80 px-2 py-0.5 rounded border border-red-900/50">
                        {lang === 'zh' ? '正在执行' : 'IN PROGRESS'}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-zinc-400 mt-0.5 leading-relaxed">
                    {lang === 'zh' ? s.descZh : s.descEn}
                  </p>
                </div>
              </div>
            );
          })}

          {/* Dish list in order */}
          <div className="mt-4 pt-4 border-t border-white/10">
            <h5 className="text-xs font-semibold text-zinc-400 mb-2">
              {lang === 'zh' ? '本单现炒明细' : 'Order Details'}
            </h5>
            <div className="space-y-1.5 text-xs text-zinc-300">
              {activeOrder.items.map(item => (
                <div key={item.id} className="flex justify-between">
                  <span>
                    {lang === 'zh' ? item.menuItem.nameZh : item.menuItem.nameEn} × {item.quantity}
                  </span>
                  <span className="font-mono text-zinc-400">
                    ¥{(item.unitPrice * item.quantity).toFixed(1)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-6 border-t border-white/10 bg-zinc-950 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={cancelOrder}
            className="text-xs text-zinc-400 hover:text-red-400 transition-colors"
          >
            {lang === 'zh' ? '取消/重置演示' : 'Reset Order Demo'}
          </button>

          <button
            type="button"
            onClick={() => setIsOrderModalOpen(false)}
            className="py-2.5 px-6 rounded-xl text-xs font-bold text-white bg-zinc-800 hover:bg-zinc-700 transition-colors"
          >
            {lang === 'zh' ? '在后台保持出餐 (关闭视窗)' : 'Keep Cooking in Background'}
          </button>
        </div>

      </div>
    </div>
  );
}
