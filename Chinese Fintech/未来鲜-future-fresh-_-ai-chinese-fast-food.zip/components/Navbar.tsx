'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { ShoppingBag, Globe, Sparkles } from 'lucide-react';

export default function Navbar() {
  const { lang, setLang, totalCount, subtotal, setIsCartOpen, activeOrder, setIsOrderModalOpen } = useApp();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-black/85 backdrop-blur-md transition-colors">
      <div className="mx-auto flex h-18 max-w-7xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        
        {/* Zone 1: Single Brand Wordmark */}
        <a href="#" className="flex items-center gap-3 shrink-0 group">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-red-600 via-rose-600 to-amber-600 shadow-[0_0_20px_rgba(239,68,68,0.4)] transition-transform group-hover:scale-105">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-white">
              <path d="M18 11a6 6 0 0 1-12 0" />
              <path d="M5 11h14" />
              <path d="M9 17v2a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-2" />
              <path d="m8 6 1-3" />
              <path d="m16 6-1-3" />
              <path d="M12 5V3" />
            </svg>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="text-xl font-black tracking-tight text-white font-sans">
                未来鲜
              </span>
              <span className="text-xs font-semibold tracking-wider text-red-500 uppercase">
                FUTURE FRESH
              </span>
            </div>
            <span className="text-[11px] text-zinc-400 font-normal">
              {lang === 'zh' ? '中式快餐 · 更快 · 更好 · 更中国' : 'Chinese Fast Food · Faster & Smarter'}
            </span>
          </div>
        </a>

        {/* Zone 2: 4-5 Concise Single-Line Navigation Links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-zinc-300">
          <a
            href="#menu-section"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8 decoration-red-500"
          >
            {lang === 'zh' ? '菜单点餐' : 'Menu & Ordering'}
          </a>
          <a
            href="#kitchen-section"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8 decoration-red-500"
          >
            {lang === 'zh' ? 'AI 智能厨房' : 'Robotics Kitchen'}
          </a>
          <a
            href="#mobile-app-section"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8 decoration-red-500"
          >
            {lang === 'zh' ? '手机端体验' : 'Mobile Kiosk'}
          </a>
          <a
            href="#stores-section"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8 decoration-red-500"
          >
            {lang === 'zh' ? '旗舰门店' : 'Flagship Stores'}
          </a>
          <a
            href="#story-section"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 hover:underline underline-offset-8 decoration-red-500"
          >
            {lang === 'zh' ? '品牌理念' : 'Philosophy'}
          </a>
        </nav>

        {/* Zone 3: 1 Primary Action Area */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Active order quick indicator if order is cooking */}
          {activeOrder && (
            <button
              onClick={() => setIsOrderModalOpen(true)}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-amber-300 bg-amber-500/15 border border-amber-500/30 rounded-lg hover:bg-amber-500/25 transition-colors whitespace-nowrap"
            >
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              <span>{lang === 'zh' ? `订单 ${activeOrder.pickupCode} 爆炒中` : `Order ${activeOrder.pickupCode} in Wok`}</span>
            </button>
          )}

          {/* Language Switcher */}
          <button
            onClick={() => setLang(lang === 'zh' ? 'en' : 'zh')}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-zinc-300 bg-zinc-900 border border-zinc-800 rounded-lg hover:text-white hover:border-zinc-700 transition-colors whitespace-nowrap shrink-0"
            aria-label="Toggle Language"
          >
            <Globe className="h-3.5 w-3.5 text-zinc-400" />
            <span>{lang === 'zh' ? 'EN' : '中文'}</span>
          </button>

          {/* Primary Cart Action */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative flex items-center gap-2.5 px-4 py-2 text-xs font-semibold text-white bg-red-600 rounded-lg hover:bg-red-500 active:scale-[0.98] transition-all shadow-[0_0_18px_rgba(220,38,38,0.35)] whitespace-nowrap shrink-0"
            aria-label="View shopping bag"
          >
            <ShoppingBag className="h-4 w-4" />
            <span className="hidden sm:inline">
              {lang === 'zh' ? '餐盘结算' : 'Tray & Cart'}
            </span>
            {totalCount > 0 ? (
              <span className="flex items-center gap-1 font-mono tabular-nums text-white bg-red-800/80 px-1.5 py-0.5 rounded text-[11px]">
                {totalCount} · ¥{subtotal.toFixed(0)}
              </span>
            ) : (
              <span className="text-[11px] opacity-80 font-mono">0</span>
            )}
          </button>
        </div>

      </div>
    </header>
  );
}
