'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { STORES, StoreLocation } from '@/data/stores';
import { MapPin, Clock, Phone, Cpu, Users, Check } from 'lucide-react';

export default function StoreLocatorSection() {
  const { lang, selectedStoreId, setSelectedStoreId } = useApp();

  return (
    <section id="stores-section" className="w-full py-16 bg-zinc-950 border-b border-white/5 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-red-500 uppercase tracking-wider mb-2">
              <MapPin className="h-3.5 w-3.5" />
              <span>{lang === 'zh' ? '线下旗舰体验店' : 'Flagship Store Network'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              {lang === 'zh' ? '未来鲜全国概念店 · 探索身边的智能美味' : 'Future Fresh Flagship Stores'}
            </h2>
            <p className="mt-2 text-sm text-zinc-400 max-w-2xl">
              {lang === 'zh'
                ? '全部门店配备全景采光幕墙、AI炒菜机器人透明工坊与送餐机器人，提供未来感舒适用餐空间。'
                : 'Experience our transparent robotic wok studios, panoramic ambient lounges, and automated runner bots.'}
            </p>
          </div>

          <div className="text-xs text-zinc-400">
            <span>{lang === 'zh' ? '当前已选择下单门店：' : 'Selected store for ordering: '}</span>
            <span className="font-bold text-white ml-1">
              {STORES.find(s => s.id === selectedStoreId)?.nameZh}
            </span>
          </div>
        </div>

        {/* 3 Flagship Store Cards */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {STORES.map(store => {
            const isSelected = selectedStoreId === store.id;
            return (
              <div
                key={store.id}
                onClick={() => setSelectedStoreId(store.id)}
                className={`relative flex flex-col justify-between p-6 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-zinc-900 border-red-500 shadow-[0_0_25px_rgba(239,68,68,0.25)] ring-1 ring-red-500'
                    : 'bg-zinc-900/60 border-white/10 hover:border-zinc-700'
                }`}
              >
                <div>
                  {/* Top Badge */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[11px] font-semibold text-red-400 bg-red-950/80 px-2.5 py-0.5 rounded border border-red-900/50">
                      {lang === 'zh' ? store.badgeZh : store.badgeEn}
                    </span>
                    <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                      <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span>{lang === 'zh' ? '营业中' : 'Open'}</span>
                    </div>
                  </div>

                  {/* Store Name */}
                  <h3 className="text-lg font-bold text-white mb-2">
                    {lang === 'zh' ? store.nameZh : store.nameEn}
                  </h3>

                  {/* Address */}
                  <p className="text-xs text-zinc-400 mb-4 flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-zinc-500 shrink-0 mt-0.5" />
                    <span>{lang === 'zh' ? store.addressZh : store.addressEn}</span>
                  </p>

                  {/* Hours and phone */}
                  <div className="space-y-1.5 text-xs text-zinc-400 pt-3 border-t border-white/5">
                    <div className="flex items-center gap-2">
                      <Clock className="h-3.5 w-3.5 text-zinc-500" />
                      <span>{lang === 'zh' ? store.hoursZh : store.hoursEn}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-3.5 w-3.5 text-zinc-500" />
                      <span className="font-mono">{store.phone}</span>
                    </div>
                  </div>

                  {/* Telemetry numbers */}
                  <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-white/5 text-center">
                    <div className="p-2 rounded-lg bg-zinc-950">
                      <div className="text-xs font-mono font-bold text-white">{store.avgWaitMins} 分钟</div>
                      <div className="text-[10px] text-zinc-500">平均出餐</div>
                    </div>
                    <div className="p-2 rounded-lg bg-zinc-950">
                      <div className="text-xs font-mono font-bold text-amber-400">{store.robotArmsCount} 台</div>
                      <div className="text-[10px] text-zinc-500">爆炒机械臂</div>
                    </div>
                    <div className="p-2 rounded-lg bg-zinc-950">
                      <div className="text-xs font-mono font-bold text-emerald-400">{store.kiosksAvailable} 台</div>
                      <div className="text-[10px] text-zinc-500">极速点餐立柱</div>
                    </div>
                  </div>

                  {/* Features list */}
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {store.features.map(f => (
                      <span key={f} className="text-[10px] text-zinc-400 bg-zinc-950 px-2 py-0.5 rounded border border-white/5">
                        {f}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bottom select button */}
                <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
                  <span className="text-xs text-zinc-400">
                    {isSelected
                      ? (lang === 'zh' ? '✓ 已作为当前点餐门店' : '✓ Active Store')
                      : (lang === 'zh' ? '点击切换至此店' : 'Click to select')}
                  </span>
                  <div
                    className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                      isSelected ? 'bg-red-600 text-white' : 'border border-zinc-700 text-zinc-400'
                    }`}
                  >
                    {isSelected ? '✓' : ''}
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
