'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { MENU_ITEMS } from '@/data/menu';
import { Smartphone, Search, Utensils, Flame, Award, ShoppingBag, Plus, ChevronRight, Clock, Star } from 'lucide-react';

export default function PhoneMockupInteractive() {
  const { lang, addToCart, setIsCartOpen, totalCount } = useApp();
  const [activeTab, setActiveTab] = useState<'recommend' | 'hot' | 'vip' | 'orders'>('recommend');
  const [searchVal, setSearchVal] = useState('');

  // Top 3 from image: Kung Pao Chicken ¥16, Mapo Tofu ¥14, Beef Noodle ¥18
  const phoneItems = [
    MENU_ITEMS.find(i => i.id === 'kung-pao-chicken')!,
    MENU_ITEMS.find(i => i.id === 'mapo-tofu-rice')!,
    MENU_ITEMS.find(i => i.id === 'beef-shank-noodles')!,
    MENU_ITEMS.find(i => i.id === 'rougamo-signature')!,
  ].filter(Boolean);

  return (
    <section id="mobile-app-section" className="w-full py-16 bg-zinc-950 border-b border-white/5 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-red-500 uppercase tracking-wider mb-2">
              <Smartphone className="h-3.5 w-3.5" />
              <span>{lang === 'zh' ? '全场景智能点餐' : 'Mobile Experience'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              {lang === 'zh' ? '掌上未来鲜 · 15秒极速下单' : 'Future Fresh Mobile Ordering'}
            </h2>
            <p className="mt-2 text-sm text-zinc-400 max-w-2xl">
              {lang === 'zh'
                ? '无需下载APP，微信/支付宝扫码即用，亦可在下方手机沙盘中直接互动点单，实时同步购物车。'
                : 'Experience the mobile app simulator below: tap items, check live queue times, and order in seconds.'}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-zinc-400">
              {lang === 'zh' ? '交互沙盘已连接当前购物车' : 'Simulator synced with live cart'}
            </span>
          </div>
        </div>

        {/* 2-Column Split: Interactive Phone Container on Left + Feature Highlights on Right */}
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Interactive Phone Device Frame */}
          <div className="lg:col-span-5 flex justify-center">
            
            {/* Phone Chassis */}
            <div className="relative w-full max-w-[340px] rounded-[42px] p-3.5 bg-gradient-to-b from-zinc-700 via-zinc-900 to-black shadow-[0_20px_50px_rgba(0,0,0,0.8),0_0_30px_rgba(220,38,38,0.2)] border-2 border-zinc-700/60">
              
              {/* Dynamic Island / Speaker Notch */}
              <div className="absolute top-6 left-1/2 -translate-x-1/2 w-28 h-4 bg-black rounded-full z-30 flex items-center justify-center">
                <div className="h-2 w-2 rounded-full bg-zinc-800 ml-12" />
              </div>

              {/* Phone Screen Canvas */}
              <div className="relative w-full rounded-[32px] bg-zinc-950 overflow-hidden border border-white/10 flex flex-col text-white pt-2 pb-4 h-[620px]">
                
                {/* Status Bar */}
                <div className="flex items-center justify-between px-6 pt-1 text-[11px] text-zinc-400 font-mono">
                  <span>9:41</span>
                  <div className="flex items-center gap-1.5">
                    <span>5G</span>
                    <span className="text-xs">100%</span>
                  </div>
                </div>

                {/* Mobile App Header */}
                <div className="px-5 pt-4 pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-6 w-6 rounded-lg bg-red-600 flex items-center justify-center text-xs">
                        🍜
                      </div>
                      <span className="text-sm font-bold text-white">未来鲜</span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded-full border border-white/5">
                      <span>北京·未来大厦店</span>
                      <ChevronRight className="h-3 w-3" />
                    </div>
                  </div>

                  <div className="mt-2 text-xs text-zinc-400">
                    {lang === 'zh' ? '你好，欢迎光临！现炒出餐中' : 'Hello, welcome to Future Fresh!'}
                  </div>
                </div>

                {/* Search Bar inside phone */}
                <div className="px-5 mt-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-zinc-500" />
                    <input
                      type="text"
                      value={searchVal}
                      onChange={e => setSearchVal(e.target.value)}
                      placeholder={lang === 'zh' ? '搜索你想吃的...' : 'Search delicious dishes...'}
                      className="w-full pl-8 pr-3 py-1.5 text-xs bg-zinc-900/90 border border-zinc-800 rounded-xl text-white placeholder-zinc-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Scrollable Content inside phone */}
                <div className="flex-1 overflow-y-auto px-5 py-3 space-y-3.5">
                  
                  {/* Banner Card */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-red-950/80 via-red-900/40 to-zinc-900 border border-red-800/40 relative overflow-hidden">
                    <div className="relative z-10">
                      <span className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider">
                        {lang === 'zh' ? '每日新鲜 · 现炒现做' : 'FRESH DAILY'}
                      </span>
                      <h4 className="text-xs font-bold text-white mt-0.5">
                        {lang === 'zh' ? '280°C 猛火出餐 · 镬气十足' : '280°C Robotic Wok Hei'}
                      </h4>
                      <button
                        onClick={() => {
                          const item = phoneItems[0];
                          if (item) addToCart(item, 1);
                        }}
                        className="mt-2 px-2.5 py-1 rounded-md bg-red-600 text-[10px] font-bold text-white hover:bg-red-500 transition-colors"
                      >
                        {lang === 'zh' ? '立即点餐 →' : 'Order Now →'}
                      </button>
                    </div>
                  </div>

                  {/* 4 Shortcut Action Icons matching the image */}
                  <div className="grid grid-cols-4 gap-2 text-center">
                    <button
                      onClick={() => setActiveTab('recommend')}
                      className={`flex flex-col items-center p-2 rounded-xl border transition-all ${
                        activeTab === 'recommend' ? 'bg-red-950/40 border-red-500/60' : 'bg-zinc-900/70 border-white/5'
                      }`}
                    >
                      <div className="h-8 w-8 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center text-sm mb-1">
                        📋
                      </div>
                      <span className="text-[10px] text-zinc-300">
                        {lang === 'zh' ? '全部菜单' : 'Menu'}
                      </span>
                    </button>

                    <button
                      onClick={() => setActiveTab('hot')}
                      className={`flex flex-col items-center p-2 rounded-xl border transition-all ${
                        activeTab === 'hot' ? 'bg-red-950/40 border-red-500/60' : 'bg-zinc-900/70 border-white/5'
                      }`}
                    >
                      <div className="h-8 w-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center text-sm mb-1">
                        🔥
                      </div>
                      <span className="text-[10px] text-zinc-300">
                        {lang === 'zh' ? '热销榜' : 'Hot'}
                      </span>
                    </button>

                    <button
                      onClick={() => setActiveTab('vip')}
                      className={`flex flex-col items-center p-2 rounded-xl border transition-all ${
                        activeTab === 'vip' ? 'bg-red-950/40 border-red-500/60' : 'bg-zinc-900/70 border-white/5'
                      }`}
                    >
                      <div className="h-8 w-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center text-sm mb-1">
                        👑
                      </div>
                      <span className="text-[10px] text-zinc-300">
                        {lang === 'zh' ? '会员中心' : 'VIP'}
                      </span>
                    </button>

                    <button
                      onClick={() => setIsCartOpen(true)}
                      className="flex flex-col items-center p-2 rounded-xl bg-zinc-900/70 border border-white/5 text-zinc-300"
                    >
                      <div className="h-8 w-8 rounded-lg bg-zinc-800 text-zinc-300 flex items-center justify-center text-sm mb-1 relative">
                        🛍️
                        {totalCount > 0 && (
                          <span className="absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full bg-red-600 text-[9px] text-white flex items-center justify-center font-bold">
                            {totalCount}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px]">
                        {lang === 'zh' ? '我的订单' : 'Orders'}
                      </span>
                    </button>
                  </div>

                  {/* Section: 今日推荐 (Today's Recommendations) as seen in image */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-white">
                        {lang === 'zh' ? '今日推荐' : 'Today Recommendation'}
                      </span>
                      <span className="text-[10px] text-zinc-500">
                        {lang === 'zh' ? '炒菜机器人接单中' : 'AI Wok Online'}
                      </span>
                    </div>

                    <div className="space-y-2">
                      {phoneItems.map(item => (
                        <div
                          key={item.id}
                          className="p-2.5 rounded-xl bg-zinc-900 border border-white/5 flex items-center justify-between gap-2.5 hover:border-red-500/30 transition-colors"
                        >
                          <div className="flex items-center gap-2.5">
                            <div className="h-11 w-11 rounded-lg bg-zinc-800 flex items-center justify-center text-xl shrink-0">
                              {item.id === 'kung-pao-chicken' ? '🍛' : item.id === 'mapo-tofu-rice' ? '🌶️' : item.id === 'beef-shank-noodles' ? '🍜' : '🥩'}
                            </div>
                            <div>
                              <div className="text-xs font-bold text-white line-clamp-1">
                                {lang === 'zh' ? item.nameZh : item.nameEn}
                              </div>
                              <div className="flex items-center gap-1.5 text-[10px] text-zinc-400 mt-0.5">
                                <span className="font-mono text-red-400 font-bold">¥{item.price}</span>
                                <span>·</span>
                                <span>{item.cookTime}</span>
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => addToCart(item, 1)}
                            className="p-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white transition-transform active:scale-90 shrink-0"
                            aria-label={`Add ${item.nameEn}`}
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

                {/* Bottom Home Indicator */}
                <div className="w-28 h-1 bg-zinc-700 rounded-full mx-auto mt-2" />

              </div>
            </div>

          </div>

          {/* Right Column: Highlights of Mobile & Kiosk Ordering Tech */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="p-6 rounded-2xl bg-zinc-900 border border-white/10">
              <h3 className="text-lg font-bold text-white mb-2">
                {lang === 'zh' ? '0排队 · 桌面扫码直达炒菜机械臂' : 'Scan & Direct-to-Wok Queue'}
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                {lang === 'zh'
                  ? '到店落座后，直接扫描桌面NFC感应芯片或二维码，订单直连后厨机械臂调度中枢，出餐进度秒级可查。'
                  : 'Simply scan your table NFC chip or QR code upon arrival. The order directly provisions the robotic kitchen scheduler.'}
              </p>
              
              <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-zinc-300">
                <div className="p-3 rounded-xl bg-zinc-950 border border-white/5">
                  <div className="text-red-400 font-bold mb-1">15 秒</div>
                  <div className="text-[11px] text-zinc-400">平均扫码点单耗时</div>
                </div>
                <div className="p-3 rounded-xl bg-zinc-950 border border-white/5">
                  <div className="text-amber-400 font-bold mb-1">实时进度</div>
                  <div className="text-[11px] text-zinc-400">精确到下料与翻炒秒数</div>
                </div>
                <div className="p-3 rounded-xl bg-zinc-950 border border-white/5">
                  <div className="text-emerald-400 font-bold mb-1">免密极速</div>
                  <div className="text-[11px] text-zinc-400">微信/支付宝自动结算</div>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900 border border-white/10">
              <h3 className="text-lg font-bold text-white mb-2">
                {lang === 'zh' ? '送餐机器人入座 · 自动精准送达' : 'Autonomous Delivery Runner'}
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                {lang === 'zh'
                  ? '菜品出锅后，由带恒温65°C保温舱的室内激光SLAM自主巡航送餐机器人，平稳滑行送至对应座位。'
                  : 'Food is transported by LiDAR-guided indoor runner bots with 65°C thermal preservation compartments directly to table seats.'}
              </p>

              <div className="mt-4 flex flex-wrap gap-2 text-xs">
                <span className="text-zinc-400 bg-zinc-950 px-3 py-1.5 rounded-lg border border-white/5">
                  激光雷达避障 (LiDAR Collision Avoidance)
                </span>
                <span className="text-zinc-400 bg-zinc-950 px-3 py-1.5 rounded-lg border border-white/5">
                  65°C 恒温保温舱 (Thermal Tray)
                </span>
                <span className="text-zinc-400 bg-zinc-950 px-3 py-1.5 rounded-lg border border-white/5">
                  语音礼貌问候 (Audio Greeting)
                </span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
