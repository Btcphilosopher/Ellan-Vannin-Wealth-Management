'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';

export default function Footer() {
  const { lang } = useApp();

  return (
    <footer className="w-full bg-black text-zinc-400 border-t border-white/10 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-white/10">
          
          {/* Col 1: Brand Info */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xl font-black text-white">未来鲜</span>
              <span className="text-xs font-semibold text-red-500 uppercase tracking-wider">
                FUTURE FRESH
              </span>
            </div>
            <p className="text-xs text-zinc-400 max-w-md leading-relaxed">
              {lang === 'zh'
                ? '未来鲜是新一代以AI智能炒菜机器人为核心驱动力的高品质中式快餐品牌。传承非遗大师绝密烹饪参数，工业级280°C精准温控，为每一位食客重燃地道镬气。'
                : 'Future Fresh is an AI-driven Chinese fast food restaurant chain blending heritage culinary craftsmanship with precision 280°C robotic wok engineering.'}
            </p>
            <div className="mt-4 flex items-center gap-3 text-xs text-zinc-500">
              <span>京ICP备20261101号</span>
              <span aria-hidden="true">·</span>
              <span>食品经营许可证: JY111080018888</span>
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div>
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-3">
              {lang === 'zh' ? '快速导航' : 'Navigation'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#menu-section" className="hover:text-white transition-colors">
                  {lang === 'zh' ? '全量菜谱与点餐' : 'Master Menu'}
                </a>
              </li>
              <li>
                <a href="#kitchen-section" className="hover:text-white transition-colors">
                  {lang === 'zh' ? 'AI 机械臂厨房' : 'Robotic Kitchen'}
                </a>
              </li>
              <li>
                <a href="#mobile-app-section" className="hover:text-white transition-colors">
                  {lang === 'zh' ? '手机端与立柱点餐' : 'Mobile Kiosk'}
                </a>
              </li>
              <li>
                <a href="#stores-section" className="hover:text-white transition-colors">
                  {lang === 'zh' ? '全国概念门店' : 'Stores & Locations'}
                </a>
              </li>
              <li>
                <a href="#story-section" className="hover:text-white transition-colors">
                  {lang === 'zh' ? '品牌理念与非遗' : 'Heritage & Tech'}
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Service & Contact */}
          <div>
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-3">
              {lang === 'zh' ? '服务与支持' : 'Customer Care'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li className="text-zinc-300">
                {lang === 'zh' ? '全国服务热线: 400-888-2026' : 'Hotline: 400-888-2026'}
              </li>
              <li>
                {lang === 'zh' ? '服务时间: 10:00 - 22:00' : 'Hours: 10:00 - 22:00 Daily'}
              </li>
              <li>
                {lang === 'zh' ? '加盟合作: partner@weilaixian.com' : 'Franchise: partner@weilaixian.com'}
              </li>
              <li>
                {lang === 'zh' ? '食品安全监督: 100% 产地溯源' : 'Food Safety: 100% Traceable'}
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <div>
            © 2026 未来鲜 Future Fresh Inc. 保留所有权利。
          </div>
          <div className="flex items-center gap-4">
            <span className="hover:text-zinc-400 cursor-pointer">
              {lang === 'zh' ? '隐私政策' : 'Privacy Policy'}
            </span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-zinc-400 cursor-pointer">
              {lang === 'zh' ? '用户协议' : 'Terms of Service'}
            </span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-zinc-400 cursor-pointer">
              {lang === 'zh' ? '食材透明公开档案' : 'Ingredients Transparency'}
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
}
