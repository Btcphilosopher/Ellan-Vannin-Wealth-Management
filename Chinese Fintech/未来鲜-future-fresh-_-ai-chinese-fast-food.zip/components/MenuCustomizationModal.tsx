'use client';

import React, { useState } from 'react';
import { MenuItem } from '@/data/menu';
import { useApp } from '@/context/AppContext';
import { X, Flame, Clock, Plus, Minus, Check } from 'lucide-react';

interface MenuCustomizationModalProps {
  item: MenuItem | null;
  onClose: () => void;
}

export default function MenuCustomizationModal({ item, onClose }: MenuCustomizationModalProps) {
  const { lang, addToCart } = useApp();

  const defaultSpiciness = item?.availableCustomizations?.spiciness?.[0] || '微辣 (Standard)';
  const defaultPortion = item?.availableCustomizations?.portion?.[0] || '标准份 (Standard)';

  const [selectedSpiciness, setSelectedSpiciness] = useState<string>(defaultSpiciness);
  const [selectedPortion, setSelectedPortion] = useState<string>(defaultPortion);
  const [selectedAddons, setSelectedAddons] = useState<{ nameZh: string; nameEn: string; price: number }[]>([]);
  const [quantity, setQuantity] = useState(1);

  if (!item) return null;

  const toggleAddon = (addon: { nameZh: string; nameEn: string; price: number }) => {
    setSelectedAddons(prev => {
      const exists = prev.some(a => a.nameZh === addon.nameZh);
      if (exists) {
        return prev.filter(a => a.nameZh !== addon.nameZh);
      } else {
        return [...prev, addon];
      }
    });
  };

  const addonsTotal = selectedAddons.reduce((acc, a) => acc + a.price, 0);
  const unitTotal = item.price + addonsTotal;
  const grandItemTotal = unitTotal * quantity;

  const handleConfirm = () => {
    addToCart(item, quantity, {
      spiciness: selectedSpiciness,
      portion: selectedPortion,
      addons: selectedAddons,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div 
        className="relative w-full max-w-lg rounded-2xl bg-zinc-900 border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative p-6 border-b border-white/10 bg-gradient-to-b from-zinc-800/80 to-zinc-900">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>

          <div className="flex items-center gap-2 text-xs text-red-400 font-medium mb-1">
            <span>{item.cookTime} 现炒出餐</span>
            <span aria-hidden="true">·</span>
            <span>{item.calories} kcal</span>
          </div>

          <h3 className="text-xl font-bold text-white pr-8">
            {lang === 'zh' ? item.nameZh : item.nameEn}
          </h3>
          <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
            {lang === 'zh' ? item.descriptionZh : item.descriptionEn}
          </p>
        </div>

        {/* Customization Options Body */}
        <div className="p-6 space-y-6 overflow-y-auto">
          
          {/* Spiciness Selection */}
          {item.availableCustomizations?.spiciness && item.availableCustomizations.spiciness.length > 0 && (
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2.5">
                {lang === 'zh' ? '辣度选择' : 'Spiciness Preference'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {item.availableCustomizations.spiciness.map(opt => {
                  const isSelected = selectedSpiciness === opt;
                  return (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setSelectedSpiciness(opt)}
                      className={`px-3 py-2 text-xs font-medium rounded-lg text-left border transition-all ${
                        isSelected
                          ? 'border-red-500 bg-red-950/60 text-white shadow-[0_0_12px_rgba(239,68,68,0.25)]'
                          : 'border-zinc-800 bg-zinc-900/90 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Portion Selection */}
          {item.availableCustomizations?.portion && item.availableCustomizations.portion.length > 0 && (
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2.5">
                {lang === 'zh' ? '分量选择' : 'Portion Size'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                {item.availableCustomizations.portion.map(opt => {
                  const isSelected = selectedPortion === opt;
                  return (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setSelectedPortion(opt)}
                      className={`px-3 py-2 text-xs font-medium rounded-lg text-left border transition-all ${
                        isSelected
                          ? 'border-red-500 bg-red-950/60 text-white shadow-[0_0_12px_rgba(239,68,68,0.25)]'
                          : 'border-zinc-800 bg-zinc-900/90 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Add-ons */}
          {item.availableCustomizations?.addons && item.availableCustomizations.addons.length > 0 && (
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2.5">
                {lang === 'zh' ? '特色加料 (可选)' : 'Optional Add-ons'}
              </label>
              <div className="space-y-2">
                {item.availableCustomizations.addons.map(addon => {
                  const isSelected = selectedAddons.some(a => a.nameZh === addon.nameZh);
                  return (
                    <button
                      key={addon.nameZh}
                      type="button"
                      onClick={() => toggleAddon(addon)}
                      className={`w-full flex items-center justify-between p-3 rounded-lg border text-xs transition-all ${
                        isSelected
                          ? 'border-red-500/70 bg-red-950/40 text-white'
                          : 'border-zinc-800 bg-zinc-900/90 text-zinc-300 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className={`h-4 w-4 rounded flex items-center justify-center border ${
                            isSelected ? 'bg-red-600 border-red-500' : 'border-zinc-700'
                          }`}
                        >
                          {isSelected && <Check className="h-3 w-3 text-white" />}
                        </div>
                        <span className="font-medium">
                          {lang === 'zh' ? addon.nameZh : addon.nameEn}
                        </span>
                      </div>
                      <span className="font-mono tabular-nums text-red-400">
                        +¥{addon.price.toFixed(1)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quantity stepper */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
              {lang === 'zh' ? '购买数量' : 'Quantity'}
            </span>
            <div className="flex items-center gap-3 bg-zinc-800/80 p-1 rounded-lg border border-white/10">
              <button
                type="button"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="p-1 rounded text-zinc-400 hover:text-white hover:bg-zinc-700 transition-colors"
                aria-label="Decrease quantity"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="font-mono tabular-nums text-sm font-semibold text-white px-2">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity(quantity + 1)}
                className="p-1 rounded text-zinc-400 hover:text-white hover:bg-zinc-700 transition-colors"
                aria-label="Increase quantity"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
          </div>

        </div>

        {/* Footer with total and confirm */}
        <div className="p-6 border-t border-white/10 bg-zinc-950 flex items-center justify-between gap-4">
          <div className="flex flex-col">
            <span className="text-[11px] text-zinc-400">
              {lang === 'zh' ? '小计金额' : 'Total Price'}
            </span>
            <div className="flex items-baseline gap-1">
              <span className="text-xs text-red-500 font-bold">¥</span>
              <span className="text-2xl font-black text-white font-mono tabular-nums">
                {grandItemTotal.toFixed(1)}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleConfirm}
            className="flex-1 py-3 px-6 text-sm font-bold text-white bg-red-600 rounded-xl hover:bg-red-500 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(220,38,38,0.4)] text-center"
          >
            {lang === 'zh' ? `确认加入餐盘 (¥${grandItemTotal.toFixed(1)})` : `Add to Tray (¥${grandItemTotal.toFixed(1)})`}
          </button>
        </div>

      </div>
    </div>
  );
}
