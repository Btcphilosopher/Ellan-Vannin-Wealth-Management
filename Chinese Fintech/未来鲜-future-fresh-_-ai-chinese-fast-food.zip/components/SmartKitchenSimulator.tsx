'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { MENU_ITEMS, MenuItem } from '@/data/menu';
import { Cpu, Flame, Gauge, CheckCircle2, RotateCw, Play, ShieldCheck, ArrowRight } from 'lucide-react';

export default function SmartKitchenSimulator() {
  const { lang, addToCart } = useApp();

  const cookableDishes = MENU_ITEMS.filter(m => m.category === 'rice' || m.id === 'kung-pao-chicken');
  const [selectedDish, setSelectedDish] = useState<MenuItem>(cookableDishes[0]);
  const [cookingState, setCookingState] = useState<'idle' | 'dispensing' | 'wok_hei' | 'spectral_qc' | 'completed'>('idle');
  const [progress, setProgress] = useState(0);
  const [currentTemp, setCurrentTemp] = useState(25);
  const [tossCount, setTossCount] = useState(0);

  // Cooking sequence controller
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (cookingState === 'dispensing') {
      interval = setInterval(() => {
        setProgress(p => {
          if (p >= 25) {
            setCookingState('wok_hei');
            return 25;
          }
          return p + 2;
        });
        setCurrentTemp(t => Math.min(85, t + 4));
      }, 100);
    } else if (cookingState === 'wok_hei') {
      interval = setInterval(() => {
        setProgress(p => {
          if (p >= 75) {
            setCookingState('spectral_qc');
            return 75;
          }
          return p + 2;
        });
        setCurrentTemp(t => Math.min(280, t + 9));
        setTossCount(c => c + 1);
      }, 100);
    } else if (cookingState === 'spectral_qc') {
      interval = setInterval(() => {
        setProgress(p => {
          if (p >= 100) {
            setCookingState('completed');
            return 100;
          }
          return p + 2;
        });
        setCurrentTemp(t => Math.max(160, t - 6));
      }, 100);
    }

    return () => clearInterval(interval);
  }, [cookingState]);

  const startCooking = () => {
    setProgress(0);
    setCurrentTemp(25);
    setTossCount(0);
    setCookingState('dispensing');
  };

  const resetCooking = () => {
    setCookingState('idle');
    setProgress(0);
    setCurrentTemp(25);
    setTossCount(0);
  };

  return (
    <section id="kitchen-section" className="w-full py-16 bg-zinc-950 border-b border-white/5 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/70 border border-red-800/40 text-xs font-semibold text-red-400 mb-3">
            <Cpu className="h-3.5 w-3.5" />
            <span>{lang === 'zh' ? '标准化 · 高品质 · 更安全' : 'Standardized · High Quality · Safer'}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            {lang === 'zh' ? 'AI 智能炒菜机器人 · 交互实验舱' : 'AI Robotic Kitchen & Wok Simulator'}
          </h2>

          <p className="mt-3 text-sm text-zinc-400 leading-relaxed">
            {lang === 'zh'
              ? '通过数字化拆解中华烹饪工序，自研工业级高精机械臂与280°C涡流电磁爆炒系统，重塑快餐新鲜度与卫生标准。'
              : 'Witness the digital translation of master culinary arts into precision robotic wok arms, achieving genuine wok-hei at 280°C.'}
          </p>
        </div>

        {/* Interactive Simulator Console */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch rounded-3xl bg-zinc-900 border border-white/10 p-6 sm:p-8 overflow-hidden">
          
          {/* Left: Recipe Selector & Controls */}
          <div className="lg:col-span-4 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-white/10 pb-6 lg:pb-0 lg:pr-8">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  {lang === 'zh' ? '1. 选择待炒菜品' : '1. Select Dish Recipe'}
                </span>
                <span className="text-xs text-red-400 font-mono">
                  {cookableDishes.length} {lang === 'zh' ? '款可选' : 'recipes'}
                </span>
              </div>

              <div className="space-y-2.5">
                {cookableDishes.slice(0, 4).map(dish => {
                  const isSelected = selectedDish.id === dish.id;
                  return (
                    <button
                      key={dish.id}
                      onClick={() => {
                        setSelectedDish(dish);
                        resetCooking();
                      }}
                      className={`w-full p-3.5 rounded-xl text-left border transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-red-950/50 border-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.2)]'
                          : 'bg-zinc-950/60 border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-bold text-white">
                          {lang === 'zh' ? dish.nameZh : dish.nameEn}
                        </div>
                        <div className="text-[11px] text-zinc-400 mt-0.5">
                          {dish.cookTime} · ¥{dish.price}
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-zinc-300">
                          {dish.tags[0]}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Simulation trigger */}
            <div className="mt-6 pt-6 border-t border-white/10">
              {cookingState === 'idle' ? (
                <button
                  type="button"
                  onClick={startCooking}
                  className="w-full py-3.5 px-4 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-500 active:scale-95 transition-all shadow-[0_0_20px_rgba(220,38,38,0.4)] flex items-center justify-center gap-2"
                >
                  <Play className="h-4 w-4 fill-white" />
                  <span>{lang === 'zh' ? '启动 280°C 机械臂爆炒模拟' : 'Start Robotic Wok Simulation'}</span>
                </button>
              ) : cookingState === 'completed' ? (
                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={() => {
                      addToCart(selectedDish, 1);
                    }}
                    className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-500 transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(220,38,38,0.3)]"
                  >
                    <span>{lang === 'zh' ? '将这盘刚出锅的菜加入餐盘' : 'Add Fresh Dish to Cart'}</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={resetCooking}
                    className="w-full py-2 px-4 rounded-xl text-xs font-medium text-zinc-400 bg-zinc-800 hover:text-white transition-colors"
                  >
                    {lang === 'zh' ? '重新模拟' : 'Reset Simulator'}
                  </button>
                </div>
              ) : (
                <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-950 border border-red-500/30">
                  <div className="flex items-center gap-2.5">
                    <RotateCw className="h-4 w-4 text-red-400 animate-spin" />
                    <span className="text-xs font-semibold text-white">
                      {cookingState === 'dispensing' && (lang === 'zh' ? '1. 智能微量配比投料中...' : '1. Micro-dispensing...')}
                      {cookingState === 'wok_hei' && (lang === 'zh' ? '2. 280°C双机械臂颠锅爆炒中...' : '2. 280°C Robotic Wok Hei...')}
                      {cookingState === 'spectral_qc' && (lang === 'zh' ? '3. 激光光谱测温装盘中...' : '3. Spectral Quality Check...')}
                    </span>
                  </div>
                  <span className="font-mono text-xs font-bold text-red-400 tabular-nums">
                    {progress}%
                  </span>
                </div>
              )}
            </div>

          </div>

          {/* Right: Telemetry Dashboard & Robotic Visual Station */}
          <div className="lg:col-span-8 flex flex-col justify-between">
            
            {/* Top Telemetry Gauges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
              <div className="p-3.5 rounded-xl bg-zinc-950 border border-white/5">
                <span className="text-[11px] text-zinc-400 flex items-center gap-1.5">
                  <Flame className="h-3 w-3 text-red-500" />
                  <span>{lang === 'zh' ? '锅底温度' : 'Wok Temp'}</span>
                </span>
                <div className="mt-1.5 flex items-baseline gap-1">
                  <span className="text-2xl font-black font-mono text-white tabular-nums">
                    {currentTemp}
                  </span>
                  <span className="text-xs text-red-400 font-sans">°C</span>
                </div>
                <div className="mt-1 w-full bg-zinc-800 h-1 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-red-500 transition-all duration-300"
                    style={{ width: `${(currentTemp / 280) * 100}%` }}
                  />
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-zinc-950 border border-white/5">
                <span className="text-[11px] text-zinc-400 flex items-center gap-1.5">
                  <RotateCw className="h-3 w-3 text-amber-500" />
                  <span>{lang === 'zh' ? '机械臂翻炒' : 'Toss Frequency'}</span>
                </span>
                <div className="mt-1.5 flex items-baseline gap-1">
                  <span className="text-2xl font-black font-mono text-white tabular-nums">
                    {tossCount * 2}
                  </span>
                  <span className="text-xs text-amber-400 font-sans">{lang === 'zh' ? '次' : 'tosses'}</span>
                </div>
                <span className="text-[10px] text-zinc-500">
                  {lang === 'zh' ? '模拟大师级腕力' : 'Master cadence'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-zinc-950 border border-white/5">
                <span className="text-[11px] text-zinc-400 flex items-center gap-1.5">
                  <Gauge className="h-3 w-3 text-emerald-500" />
                  <span>{lang === 'zh' ? '调味精度' : 'Dispense Accuracy'}</span>
                </span>
                <div className="mt-1.5 flex items-baseline gap-1">
                  <span className="text-2xl font-black font-mono text-white tabular-nums">
                    ±0.1
                  </span>
                  <span className="text-xs text-emerald-400 font-sans">g</span>
                </div>
                <span className="text-[10px] text-zinc-500">
                  {lang === 'zh' ? '微米级泵注' : 'Micro-pump'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-zinc-950 border border-white/5">
                <span className="text-[11px] text-zinc-400 flex items-center gap-1.5">
                  <ShieldCheck className="h-3 w-3 text-cyan-500" />
                  <span>{lang === 'zh' ? '卫生标准' : 'Hygiene Rank'}</span>
                </span>
                <div className="mt-1.5 flex items-baseline gap-1">
                  <span className="text-2xl font-black font-mono text-white tabular-nums">
                    100
                  </span>
                  <span className="text-xs text-cyan-400 font-sans">%</span>
                </div>
                <span className="text-[10px] text-zinc-500">
                  {lang === 'zh' ? '全封闭洁净舱' : 'Clean room iso'}
                </span>
              </div>
            </div>

            {/* Central Animated Visualizer Station */}
            <div className="relative w-full h-64 sm:h-72 rounded-2xl bg-zinc-950 border border-white/10 flex flex-col items-center justify-center overflow-hidden p-6">
              
              {/* Grid backdrop */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:24px_24px]" />

              {/* Cooking Visual States */}
              {cookingState === 'idle' && (
                <div className="relative z-10 flex flex-col items-center text-center">
                  <div className="h-20 w-20 rounded-full bg-zinc-900 border border-white/10 flex items-center justify-center mb-3">
                    <Cpu className="h-8 w-8 text-zinc-400" />
                  </div>
                  <h4 className="text-base font-bold text-white">
                    {lang === 'zh' ? '智能厨房系统待命' : 'Kitchen Robotic System Ready'}
                  </h4>
                  <p className="text-xs text-zinc-400 mt-1 max-w-sm">
                    {lang === 'zh' ? '点击左侧“启动爆炒模拟”，实时观察数字化温控与机械臂抛炒。' : 'Click "Start Simulation" to witness real-time robotic wok tossing.'}
                  </p>
                </div>
              )}

              {cookingState === 'dispensing' && (
                <div className="relative z-10 flex flex-col items-center text-center animate-pulse">
                  <div className="h-20 w-20 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-3 text-3xl">
                    🧂
                  </div>
                  <h4 className="text-base font-bold text-amber-300">
                    {lang === 'zh' ? '阶段 1: 精准智能配料中' : 'Stage 1: Precision Ingredient Dosing'}
                  </h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    {lang === 'zh' ? '花生油 8ml · 葱姜蒜末 6g · 特调宫保汁 18ml 自动注入' : 'Automatic micro-dispense of aromatics & sauces'}
                  </p>
                </div>
              )}

              {cookingState === 'wok_hei' && (
                <div className="relative z-10 flex flex-col items-center text-center">
                  <div className="relative h-24 w-24 rounded-full bg-red-600/20 border-2 border-red-500 flex items-center justify-center mb-3 shadow-[0_0_40px_rgba(239,68,68,0.6)] animate-bounce">
                    <span className="text-4xl">🥘</span>
                    <div className="absolute -top-2 text-xs font-mono font-bold text-red-400 bg-black/80 px-2 py-0.5 rounded-full border border-red-500">
                      280°C
                    </div>
                  </div>
                  <h4 className="text-base font-bold text-red-400">
                    {lang === 'zh' ? '阶段 2: 280°C 聚能大火爆炒中' : 'Stage 2: 280°C Extreme Induction Wok Hei'}
                  </h4>
                  <p className="text-xs text-zinc-300 mt-1">
                    {lang === 'zh' ? '六轴机械臂以 42次/分 频率翻抛，锁住每一寸鲜甜汁水' : 'Six-axis robotic arms tossing at 42 RPM'}
                  </p>
                </div>
              )}

              {cookingState === 'spectral_qc' && (
                <div className="relative z-10 flex flex-col items-center text-center">
                  <div className="h-20 w-20 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mb-3 text-3xl">
                    🔍
                  </div>
                  <h4 className="text-base font-bold text-cyan-300">
                    {lang === 'zh' ? '阶段 3: 激光光谱色度质检与自动装盘' : 'Stage 3: Spectral QC & Automated Plating'}
                  </h4>
                  <p className="text-xs text-zinc-400 mt-1">
                    {lang === 'zh' ? 'AI 视觉分析色泽成熟度，自动无尘出餐装盘' : 'Visual confirmation of perfect caramelization'}
                  </p>
                </div>
              )}

              {cookingState === 'completed' && (
                <div className="relative z-10 flex flex-col items-center text-center">
                  <div className="h-20 w-20 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mb-3 text-4xl">
                    ✨
                  </div>
                  <h4 className="text-base font-bold text-emerald-400">
                    {lang === 'zh' ? '出餐完成！热气腾腾已装盘' : 'Cooking Complete! Fresh Plated'}
                  </h4>
                  <p className="text-xs text-zinc-300 mt-1">
                    {lang === 'zh' ? `${selectedDish.nameZh} 现炒出锅，可加入餐盘结账。` : `${selectedDish.nameEn} is ready to serve.`}
                  </p>
                </div>
              )}

              {/* Progress bar at the bottom */}
              <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-zinc-800">
                <div
                  className="h-full bg-gradient-to-r from-red-600 to-amber-500 transition-all duration-200"
                  style={{ width: `${progress}%` }}
                />
              </div>

            </div>

            {/* Bottom 3 Pillars matching reference image */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 pt-4 border-t border-white/5 text-xs text-zinc-400">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                <span>{lang === 'zh' ? '新鲜：现炒现做拒冷藏包' : 'Fresh: Zero pre-made pouches'}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                <span>{lang === 'zh' ? '高效：平均 165秒 极速出餐' : 'Fast: 165s rapid turnaround'}</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                <span>{lang === 'zh' ? '卫生：工业洁净舱避免飞沫' : 'Clean: Enclosed clean chamber'}</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
