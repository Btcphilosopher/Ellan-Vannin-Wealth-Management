'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Flame, Sparkles, Shield, HeartHandshake, ArrowRight } from 'lucide-react';

export default function BrandStorySection() {
  const { lang, setIsCartOpen } = useApp();

  return (
    <section id="story-section" className="w-full py-16 bg-zinc-950 border-b border-white/5 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-950/70 border border-red-800/40 text-xs font-semibold text-red-400 mb-3">
            <Sparkles className="h-3.5 w-3.5" />
            <span>{lang === 'zh' ? '美味 · 科技 · 生活' : 'Taste · Technology · Life'}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            {lang === 'zh' ? '让中国美食 · 走向更远的未来' : 'Taking Chinese Culinary Art Into the Future'}
          </h2>

          <p className="mt-3 text-sm text-zinc-400 leading-relaxed">
            {lang === 'zh'
              ? '未来鲜不仅是一家快餐厅，更是中华地道味道与现代前沿智能科技深度融合的试验场。'
              : 'Future Fresh re-engineers authentic regional Chinese gastronomy with surgical AI robotics, ensuring every dish preserves master wok-hei.'}
          </p>
        </div>

        {/* 3 Story Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="p-8 rounded-2xl bg-zinc-900 border border-white/10 flex flex-col justify-between">
            <div>
              <div className="h-12 w-12 rounded-xl bg-red-600/20 text-red-400 flex items-center justify-center mb-6">
                <Flame className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">
                {lang === 'zh' ? '百年非遗大师秘方参数化' : 'Digitized Century Master Recipes'}
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                {lang === 'zh'
                  ? '邀请陕西腊汁肉夹馍传人与川菜大师，将投料秒数、油温升温曲线与抛锅角度转化为精准的数字算法，拒绝工业味精调料包。'
                  : 'Collaborating with culinary masters to convert wok angles, heat curves, and micro-seasoning into exact algorithms.'}
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-white/5 text-xs text-zinc-500">
              {lang === 'zh' ? '传承正宗 · 镬气不减' : 'Authentic Wok Hei Preserved'}
            </div>
          </div>

          <div className="p-8 rounded-2xl bg-zinc-900 border border-white/10 flex flex-col justify-between">
            <div>
              <div className="h-12 w-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-6">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">
                {lang === 'zh' ? '千级洁净封闭工坊 · 极致卫生' : 'ISO Cleanroom Hygiene Protocol'}
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                {lang === 'zh'
                  ? '告别传统厨房油烟漫溢与飞沫污染，全封闭透明玻璃工坊配合紫外线消毒循环与负压抽风，每一次烹饪后自清洁喷淋。'
                  : 'Sealed transparent glass kitchen with HEPA negative-pressure ventilation, UV sterilization, and automated steam CIP self-cleaning.'}
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-white/5 text-xs text-zinc-500">
              {lang === 'zh' ? '每客一清洗 · 放心享用' : 'Cleaned Between Every Order'}
            </div>
          </div>

          <div className="p-8 rounded-2xl bg-zinc-900 border border-white/10 flex flex-col justify-between">
            <div>
              <div className="h-12 w-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-6">
                <HeartHandshake className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">
                {lang === 'zh' ? '高性价比地道快餐 · 惠及大众' : 'Affordable Gourmet Fast Food'}
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                {lang === 'zh'
                  ? '科技的本质是降本增效与普惠。招牌肉夹馍仅需 ¥12，现炒宫保鸡丁饭仅需 ¥16，让都市打工人在3分钟内吃到热气腾腾的地道中国菜。'
                  : 'Technology serves people. Rougamo at ¥12, Kung Pao Chicken at ¥16, ready in 3 minutes without hurting your wallet.'}
              </p>
            </div>
            <div className="mt-6 pt-4 border-t border-white/5 text-xs text-zinc-500">
              {lang === 'zh' ? '亲民价格 · 品质如一' : 'Accessible & Consistent'}
            </div>
          </div>

        </div>

        {/* Big Banner CTA mirroring bottom right card */}
        <div className="mt-12 p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-red-950 via-zinc-900 to-black border border-red-900/50 flex flex-col sm:flex-row items-center justify-between gap-6 relative overflow-hidden">
          <div className="relative z-10 max-w-xl">
            <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {lang === 'zh' ? '尝鲜新中式未来味，今天吃好每一顿' : 'Taste the Future of Chinese Gastronomy Today'}
            </h3>
            <p className="mt-2 text-xs sm:text-sm text-zinc-300">
              {lang === 'zh' ? '立即在线点单，到店即取或机器人送餐至座位，首单立享会员立减特权。' : 'Order online now for immediate pickup or autonomous table serving.'}
            </p>
          </div>

          <div className="relative z-10 flex items-center gap-3 shrink-0">
            <a
              href="#menu-section"
              className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-bold text-white bg-red-600 rounded-xl hover:bg-red-500 active:scale-95 transition-all shadow-[0_0_25px_rgba(220,38,38,0.5)] whitespace-nowrap"
            >
              <span>{lang === 'zh' ? '前往菜单点餐' : 'Explore Menu'}</span>
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>

      </div>
    </section>
  );
}
