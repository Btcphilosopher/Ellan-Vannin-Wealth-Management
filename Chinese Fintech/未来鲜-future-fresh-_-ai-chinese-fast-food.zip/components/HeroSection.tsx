'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { ArrowRight, Flame, Clock, Sparkles, Cpu, CheckCircle2 } from 'lucide-react';

interface Hotspot {
  id: string;
  x: number; // percentage from left
  y: number; // percentage from top
  titleZh: string;
  titleEn: string;
  descZh: string;
  descEn: string;
  badgeZh: string;
  badgeEn: string;
}

const HOTSPOTS: Hotspot[] = [
  {
    id: 'wok-robot',
    x: 28,
    y: 42,
    titleZh: 'AI 智能双臂现炒区',
    titleEn: 'Dual-Arm Robotic Wok Hub',
    descZh: '德国高精伺服电机模拟百年大厨翻炒抛锅，280°C大火聚能瞬时锁住食材鲜嫩与镬气。',
    descEn: 'Industrial precision servos replicate master chef wok tossing at 280°C flash induction.',
    badgeZh: '镬气十足 · 165秒出餐',
    badgeEn: 'Wok Hei · 165s Speed'
  },
  {
    id: 'kiosks',
    x: 25,
    y: 65,
    titleZh: '无感点餐交互立柱',
    titleEn: 'Ultra-Fast Smart Kiosks',
    descZh: '支持毫米波感应与多语言点餐，平均点单时间仅需15秒，零排队直通厨房队列。',
    descEn: 'Instant touchless kiosks with 15-second checkout routing directly to robotic wok queues.',
    badgeZh: '0排队 · 智能推荐',
    badgeEn: 'Zero Wait · Smart Menu'
  },
  {
    id: 'dining-room',
    x: 75,
    y: 45,
    titleZh: '新中式环幕客席区',
    titleEn: 'Panoramic Neo-Chinese Lounge',
    descZh: '圆弧形全景通透玻璃与暖木红光幕，配备自研降噪科技，让快餐享有高端餐厅的用餐氛围。',
    descEn: 'Curved panoramic glass pavilion blending heritage woodwork with warm crimson ambient light.',
    badgeZh: '声学降噪 · 舒适宽敞',
    badgeEn: 'Acoustic Comfort'
  },
  {
    id: 'rougamo-poster',
    x: 8,
    y: 35,
    titleZh: '招牌腊汁肉夹馍橱窗',
    titleEn: 'Heritage Crispy Rougamo',
    descZh: '千层酥脆白吉馍，内裹慢炖12小时香浓肉汁，传承百年月牙白吉馍制法。',
    descEn: 'Hand-laminated flaky buns packed with 12-hour spiced pork belly jus.',
    badgeZh: '非遗绝味 · 现剁现夹',
    badgeEn: 'Heritage Recipe'
  }
];

export default function HeroSection() {
  const { lang, setIsCartOpen } = useApp();
  const [activeHotspot, setActiveHotspot] = useState<Hotspot | null>(HOTSPOTS[0]);

  return (
    <section className="relative w-full overflow-hidden bg-zinc-950 pt-6 pb-12 border-b border-white/5">
      {/* Background glow lines */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-red-600/10 blur-[140px] pointer-events-none" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Top Banner Tagline */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-white/10">
          <div className="flex items-center gap-3 text-xs text-zinc-400">
            <span className="font-semibold tracking-wider text-red-500 uppercase">
              {lang === 'zh' ? '中式快餐革命' : 'Chinese Fast Food Revolution'}
            </span>
            <span aria-hidden="true" className="text-zinc-600">·</span>
            <span className="text-zinc-300">
              {lang === 'zh' ? '更快 · 更好 · 更中国' : 'Faster · Better · More Authentic'}
            </span>
            <span aria-hidden="true" className="text-zinc-600">·</span>
            <span>
              {lang === 'zh' ? '现炒现做拒绝预制菜' : '100% Made Fresh to Order'}
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs text-zinc-400">
            <span className="inline-block h-2 w-2 rounded-full bg-emerald-500" />
            <span className="font-medium text-zinc-300">
              {lang === 'zh' ? '北京·未来大厦店 营业中' : 'Beijing Flagship Open'}
            </span>
            <span className="text-zinc-500 font-mono tabular-nums">
              (10:00 - 22:00)
            </span>
          </div>
        </div>

        {/* Hero 2-Column Split */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Column: Headline and Positioning */}
          <div className="lg:col-span-5 flex flex-col justify-between py-2">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-950/60 border border-red-800/50 rounded-full text-xs text-red-400 mb-5">
                <Flame className="h-3.5 w-3.5 text-red-400" />
                <span>{lang === 'zh' ? '新中式 · 未来味' : 'New Chinese Style · Future Flavor'}</span>
              </div>

              <h1 className="text-3xl sm:text-4xl xl:text-5xl font-black tracking-tight text-white leading-[1.15] text-balance">
                {lang === 'zh' ? (
                  <>
                    地道中国味 <br />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-amber-400">
                      现在就能吃到
                    </span>
                  </>
                ) : (
                  <>
                    Authentic Chinese Flavor, <br />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-amber-400">
                      Cooked Fresh by AI
                    </span>
                  </>
                )}
              </h1>

              <p className="mt-5 text-base text-zinc-300 leading-relaxed max-w-xl">
                {lang === 'zh'
                  ? '告别冰冷预制菜。未来鲜融合百年非遗秘制配方与工业级280°C精准温控翻炒机器人，165秒极速出餐，重现大火爆炒的灵魂镬气。'
                  : 'Goodbye industrial meal pouches. Future Fresh pairs century-tested heritage culinary craftsmanship with precision 280°C robotic wok tossing—serving steaming, authentic dishes in under 3 minutes.'}
              </p>

              {/* Action buttons */}
              <div className="mt-8 flex flex-wrap items-center gap-4">
                <a
                  href="#menu-section"
                  className="inline-flex items-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-red-600 rounded-xl hover:bg-red-500 active:scale-[0.98] transition-all shadow-[0_0_24px_rgba(220,38,38,0.4)] whitespace-nowrap"
                >
                  <span>{lang === 'zh' ? '立即在线点餐' : 'Order Food Online'}</span>
                  <ArrowRight className="h-4 w-4" />
                </a>

                <a
                  href="#kitchen-section"
                  className="inline-flex items-center gap-2 px-5 py-3.5 text-sm font-medium text-zinc-300 bg-zinc-900 border border-zinc-800 rounded-xl hover:bg-zinc-800 hover:text-white transition-all whitespace-nowrap"
                >
                  <Cpu className="h-4 w-4 text-red-400" />
                  <span>{lang === 'zh' ? '查看智能厨房' : 'Robotics Kitchen'}</span>
                </a>
              </div>
            </div>

            {/* Selected Hotspot Interactive Preview Card */}
            {activeHotspot && (
              <div className="mt-8 p-4 rounded-xl bg-zinc-900/90 border border-white/10 backdrop-blur-md">
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-red-500" />
                    <span className="text-sm font-bold text-white">
                      {lang === 'zh' ? activeHotspot.titleZh : activeHotspot.titleEn}
                    </span>
                  </div>
                  <span className="text-[11px] font-medium text-red-400 bg-red-950/80 px-2 py-0.5 rounded border border-red-900/40">
                    {lang === 'zh' ? activeHotspot.badgeZh : activeHotspot.badgeEn}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  {lang === 'zh' ? activeHotspot.descZh : activeHotspot.descEn}
                </p>
                <div className="mt-2 text-[11px] text-zinc-500 flex items-center gap-2">
                  <span>{lang === 'zh' ? '提示：点击右侧图片中光圈切换探索' : 'Tip: Click markers on photo to inspect'}</span>
                </div>
              </div>
            )}
          </div>

          {/* Right Column: High-Impact Restaurant Showcase with Interactive Hotspots */}
          <div className="lg:col-span-7 relative rounded-2xl overflow-hidden border border-white/10 bg-zinc-900 group">
            {/* The restaurant flagship photo directly loaded from user asset */}
            <div className="relative w-full aspect-[16/10] sm:aspect-[16/10] overflow-hidden">
              <Image
                src="/assets/aistudio/5c56a08f-9a57-4ee6-8d4b-03f172a6d3e5_6afa6c87.png"
                alt="未来鲜 AI 智能中式快餐旗舰店实景"
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 60vw"
                className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-[1.02]"
                referrerPolicy="no-referrer"
              />

              {/* Gentle bottom-up scrim for contrast */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent pointer-events-none" />

              {/* Interactive Hotspot markers */}
              {HOTSPOTS.map((spot) => {
                const isSelected = activeHotspot?.id === spot.id;
                return (
                  <button
                    key={spot.id}
                    onClick={() => setActiveHotspot(spot)}
                    style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 flex items-center justify-center transition-all ${
                      isSelected ? 'scale-125' : 'hover:scale-115'
                    }`}
                    aria-label={`View ${spot.titleEn}`}
                  >
                    <span className="relative flex h-8 w-8 items-center justify-center">
                      <span
                        className={`absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping ${
                          isSelected ? 'bg-red-400' : 'bg-amber-400/60'
                        }`}
                      />
                      <span
                        className={`relative inline-flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold text-white shadow-lg border-2 ${
                          isSelected
                            ? 'bg-red-600 border-white ring-4 ring-red-500/40'
                            : 'bg-zinc-900/90 border-amber-400 text-amber-300'
                        }`}
                      >
                        +
                      </span>
                    </span>
                  </button>
                );
              })}

              {/* Bottom overlay badge */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-zinc-300 bg-black/70 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/10">
                <div className="flex items-center gap-2">
                  <span className="inline-block h-2 w-2 rounded-full bg-emerald-400" />
                  <span className="font-medium text-white">
                    {lang === 'zh' ? '未来鲜 1号智能旗舰店 · 实拍空间' : 'Future Fresh No.1 Concept Flagship Store'}
                  </span>
                </div>
                <div className="hidden sm:flex items-center gap-3 text-zinc-400 text-[11px]">
                  <span>AI 智能厨房</span>
                  <span>·</span>
                  <span>全景落地玻璃</span>
                  <span>·</span>
                  <span>无触点取餐</span>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* 4-Column KPI / Trust Strip below Hero Split */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 p-6 rounded-2xl bg-zinc-900/60 border border-white/10">
          
          <div className="flex flex-col">
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl sm:text-4xl font-black text-white font-mono tabular-nums tracking-tight">
                165
              </span>
              <span className="text-sm font-semibold text-red-500 font-sans">
                {lang === 'zh' ? '秒' : 'sec'}
              </span>
            </div>
            <span className="text-xs font-medium text-zinc-300 mt-1">
              {lang === 'zh' ? '平均现炒出餐时间' : 'Avg Robotic Cook Time'}
            </span>
            <span className="text-[11px] text-zinc-500 mt-0.5">
              {lang === 'zh' ? '点单到取餐无需漫长等待' : 'Fast order to table serving'}
            </span>
          </div>

          <div className="flex flex-col border-l border-white/10 pl-4 sm:pl-6">
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl sm:text-4xl font-black text-white font-mono tabular-nums tracking-tight">
                280
              </span>
              <span className="text-sm font-semibold text-amber-500 font-sans">
                °C
              </span>
            </div>
            <span className="text-xs font-medium text-zinc-300 mt-1">
              {lang === 'zh' ? '聚能IH大火爆炒' : 'Induction Wok Hei Heat'}
            </span>
            <span className="text-[11px] text-zinc-500 mt-0.5">
              {lang === 'zh' ? '精准控温锁定每一分鲜嫩' : 'Master-level flame simulation'}
            </span>
          </div>

          <div className="flex flex-col border-l border-white/10 pl-4 sm:pl-6">
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl sm:text-4xl font-black text-white font-mono tabular-nums tracking-tight">
                100
              </span>
              <span className="text-sm font-semibold text-emerald-500 font-sans">
                %
              </span>
            </div>
            <span className="text-xs font-medium text-zinc-300 mt-1">
              {lang === 'zh' ? '现炒现做拒绝预制包' : 'Freshly Stir-fried Dishes'}
            </span>
            <span className="text-[11px] text-zinc-500 mt-0.5">
              {lang === 'zh' ? '每日产地直采鲜鸡与时蔬' : 'Daily direct farm supplies'}
            </span>
          </div>

          <div className="flex flex-col border-l border-white/10 pl-4 sm:pl-6">
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl sm:text-4xl font-black text-white font-mono tabular-nums tracking-tight">
                48
              </span>
              <span className="text-sm font-semibold text-rose-500 font-sans">
                +
              </span>
            </div>
            <span className="text-xs font-medium text-zinc-300 mt-1">
              {lang === 'zh' ? '非遗大师数字化名菜' : 'Master Digital Recipes'}
            </span>
            <span className="text-[11px] text-zinc-500 mt-0.5">
              {lang === 'zh' ? '八大菜系经典配方参数化' : 'Validated flavor metrics'}
            </span>
          </div>

        </div>

      </div>
    </section>
  );
}
