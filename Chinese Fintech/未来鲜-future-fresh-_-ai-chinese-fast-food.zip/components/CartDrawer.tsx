'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { X, Trash2, Plus, Minus, ArrowRight, Utensils, ShoppingBag, Truck, Sparkles } from 'lucide-react';

export default function CartDrawer() {
  const {
    lang,
    cart,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateQuantity,
    clearCart,
    subtotal,
    discount,
    grandTotal,
    diningMode,
    setDiningMode,
    tableNumber,
    setTableNumber,
    placeOrder,
  } = useApp();

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 flex max-w-full pl-10">
        <div className="w-screen max-w-md bg-zinc-900 border-l border-white/10 shadow-2xl flex flex-col">
          
          {/* Drawer Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5 text-red-500" />
              <h3 className="text-lg font-bold text-white">
                {lang === 'zh' ? '当前点餐盘' : 'Order Tray'}
              </h3>
              <span className="text-xs text-zinc-400 font-mono">
                ({cart.length} {lang === 'zh' ? '种菜品' : 'items'})
              </span>
            </div>

            <div className="flex items-center gap-2">
              {cart.length > 0 && (
                <button
                  type="button"
                  onClick={clearCart}
                  className="text-xs text-zinc-400 hover:text-red-400 transition-colors mr-2"
                >
                  {lang === 'zh' ? '清空' : 'Clear'}
                </button>
              )}
              <button
                type="button"
                onClick={() => setIsCartOpen(false)}
                className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
                aria-label="Close cart"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

          {/* Dining Mode Selector */}
          <div className="px-6 py-4 bg-zinc-950/80 border-b border-white/5">
            <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">
              {lang === 'zh' ? '就餐方式' : 'Dining Mode'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setDiningMode('dine_in')}
                className={`py-2 px-3 text-xs font-medium rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  diningMode === 'dine_in'
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white border border-white/5'
                }`}
              >
                <Utensils className="h-3.5 w-3.5" />
                <span>{lang === 'zh' ? '堂食入座' : 'Dine-In'}</span>
              </button>

              <button
                type="button"
                onClick={() => setDiningMode('takeaway')}
                className={`py-2 px-3 text-xs font-medium rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  diningMode === 'takeaway'
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white border border-white/5'
                }`}
              >
                <ShoppingBag className="h-3.5 w-3.5" />
                <span>{lang === 'zh' ? '打包自提' : 'Takeaway'}</span>
              </button>

              <button
                type="button"
                onClick={() => setDiningMode('delivery')}
                className={`py-2 px-3 text-xs font-medium rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  diningMode === 'delivery'
                    ? 'bg-red-600 text-white shadow-sm'
                    : 'bg-zinc-900 text-zinc-400 hover:text-white border border-white/5'
                }`}
              >
                <Truck className="h-3.5 w-3.5" />
                <span>{lang === 'zh' ? '极速送达' : 'Delivery'}</span>
              </button>
            </div>

            {diningMode === 'dine_in' && (
              <div className="mt-3 flex items-center justify-between text-xs text-zinc-400 bg-zinc-900/60 p-2.5 rounded-lg border border-white/5">
                <span>{lang === 'zh' ? '当前桌号：' : 'Table Number:'}</span>
                <div className="flex items-center gap-1">
                  <span className="font-bold text-white font-mono">{tableNumber}号桌</span>
                  <input
                    type="text"
                    value={tableNumber}
                    onChange={(e) => setTableNumber(e.target.value)}
                    className="w-12 text-center py-0.5 bg-zinc-800 text-white rounded border border-zinc-700 text-xs font-mono ml-2 focus:outline-none"
                    placeholder="08"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="h-16 w-16 rounded-full bg-zinc-800/80 flex items-center justify-center text-2xl mb-3">
                  🥢
                </div>
                <h4 className="text-sm font-bold text-white">
                  {lang === 'zh' ? '餐盘暂无菜品' : 'Your tray is empty'}
                </h4>
                <p className="text-xs text-zinc-400 mt-1 max-w-xs">
                  {lang === 'zh' ? '浏览上方菜单，挑选你喜欢的现炒盖饭或经典腊汁肉夹馍吧！' : 'Explore the menu to add delicious freshly wok-tossed dishes.'}
                </p>
              </div>
            ) : (
              cart.map(item => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-xl bg-zinc-950 border border-white/5 flex flex-col gap-2.5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="text-xs font-bold text-white">
                        {lang === 'zh' ? item.menuItem.nameZh : item.menuItem.nameEn}
                      </h4>
                      
                      {/* Customization pills */}
                      <div className="mt-1 text-[11px] text-zinc-400 flex flex-wrap gap-1">
                        {item.options.spiciness && (
                          <span>{item.options.spiciness}</span>
                        )}
                        {item.options.portion && (
                          <span>· {item.options.portion}</span>
                        )}
                        {item.options.addons && item.options.addons.length > 0 && (
                          <span>· 加: {item.options.addons.map(a => lang === 'zh' ? a.nameZh : a.nameEn).join(', ')}</span>
                        )}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => removeFromCart(item.id)}
                      className="text-zinc-500 hover:text-red-400 p-1"
                      aria-label="Remove item"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-white/5">
                    <div className="text-xs font-bold text-red-400 font-mono tabular-nums">
                      ¥{(item.unitPrice * item.quantity).toFixed(1)}
                    </div>

                    <div className="flex items-center gap-2 bg-zinc-900 px-2 py-0.5 rounded-md border border-white/5">
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.id, -1)}
                        className="text-zinc-400 hover:text-white p-0.5"
                      >
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="font-mono text-xs font-semibold text-white px-1">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => updateQuantity(item.id, 1)}
                        className="text-zinc-400 hover:text-white p-0.5"
                      >
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Drawer Footer with Price Breakdown and Order Action */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-white/10 bg-zinc-950 space-y-3">
              <div className="space-y-1.5 text-xs text-zinc-400">
                <div className="flex justify-between">
                  <span>{lang === 'zh' ? '菜品小计' : 'Subtotal'}</span>
                  <span className="font-mono text-white tabular-nums">¥{subtotal.toFixed(1)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span className="flex items-center gap-1">
                      <Sparkles className="h-3 w-3" />
                      <span>{lang === 'zh' ? '满30元会员立减特权' : 'Member Promo Discount'}</span>
                    </span>
                    <span className="font-mono tabular-nums">-¥{discount.toFixed(1)}</span>
                  </div>
                )}
                {diningMode === 'takeaway' && (
                  <div className="flex justify-between">
                    <span>{lang === 'zh' ? '环保降解餐盒费' : 'Packaging'}</span>
                    <span className="font-mono text-white tabular-nums">¥2.0</span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t border-white/10 text-sm font-bold text-white">
                  <span>{lang === 'zh' ? '应付总额' : 'Total Amount'}</span>
                  <span className="text-xl font-mono text-red-500 tabular-nums">
                    ¥{grandTotal.toFixed(1)}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={placeOrder}
                className="w-full py-3.5 px-6 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-500 active:scale-95 transition-all shadow-[0_0_20px_rgba(220,38,38,0.4)] flex items-center justify-center gap-2"
              >
                <span>{lang === 'zh' ? '提交订单并通知机械臂现炒' : 'Send Order to Robotic Wok'}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
