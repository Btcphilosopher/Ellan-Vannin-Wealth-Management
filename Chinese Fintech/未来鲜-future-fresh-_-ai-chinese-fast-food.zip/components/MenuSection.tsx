'use client';

import React, { useState, useMemo } from 'react';
import { MENU_ITEMS, CATEGORIES, MenuItem } from '@/data/menu';
import { useApp } from '@/context/AppContext';
import MenuCustomizationModal from './MenuCustomizationModal';
import { Search, Flame, Clock, Plus, Star, Sparkles } from 'lucide-react';

export default function MenuSection() {
  const { lang, addToCart } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [spiceFilter, setSpiceFilter] = useState<'all' | 'spicy' | 'non-spicy'>('all');
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);

  const filteredItems = useMemo(() => {
    return MENU_ITEMS.filter(item => {
      // Category match
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      // Spice filter
      if (spiceFilter === 'spicy' && item.spiceLevel === 0) return false;
      if (spiceFilter === 'non-spicy' && item.spiceLevel > 0) return false;
      // Search match
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchZh = item.nameZh.toLowerCase().includes(q) || item.tags.some(t => t.toLowerCase().includes(q));
        const matchEn = item.nameEn.toLowerCase().includes(q);
        if (!matchZh && !matchEn) return false;
      }
      return true;
    });
  }, [selectedCategory, spiceFilter, searchQuery]);

  return (
    <section id="menu-section" className="w-full py-16 bg-zinc-950 text-white border-b border-white/5 scroll-mt-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-red-500 uppercase tracking-wider mb-2">
              <Sparkles className="h-3.5 w-3.5" />
              <span>{lang === 'zh' ? '现炒现做 · 极速出餐' : 'Master Wok Menu'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              {lang === 'zh' ? '未来鲜 · 智能厨房全量菜单' : 'Future Fresh · Smart Kitchen Menu'}
            </h2>
            <p className="mt-2 text-sm text-zinc-400 max-w-2xl">
              {lang === 'zh'
                ? '每一份餐品均由数字菜谱参数化控制，280°C猛火爆炒，严选优质产地食材，零预制调料包。'
                : 'Every meal is cooked to order by robotic induction woks, calibrated to replicate century-old master recipes with zero preservatives.'}
            </p>
          </div>

          {/* Search bar inside header */}
          <div className="relative w-full md:w-72">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={lang === 'zh' ? '搜索菜品或风味标签...' : 'Search dishes, ingredients...'}
              className="w-full pl-10 pr-4 py-2 text-xs bg-zinc-900 border border-zinc-800 rounded-xl text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Filter Toolbar: Category Segmented Controls + Spice Preference */}
        <div className="mt-8 flex flex-wrap items-center justify-between gap-4">
          
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-zinc-900 border border-white/10 rounded-xl overflow-x-auto max-w-full">
            {CATEGORIES.map(cat => {
              const isActive = selectedCategory === cat.key;
              return (
                <button
                  key={cat.key}
                  onClick={() => setSelectedCategory(cat.key)}
                  className={`px-4 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-red-600 text-white shadow-sm'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                  }`}
                >
                  {lang === 'zh' ? cat.nameZh : cat.nameEn}
                </button>
              );
            })}
          </div>

          {/* Dietary / Spice Filter */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-zinc-500">
              {lang === 'zh' ? '辣度筛选:' : 'Filter:'}
            </span>
            <div className="flex items-center gap-1 bg-zinc-900 p-1 rounded-lg border border-white/10">
              <button
                onClick={() => setSpiceFilter('all')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  spiceFilter === 'all' ? 'bg-zinc-800 text-white font-medium' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {lang === 'zh' ? '全部' : 'All'}
              </button>
              <button
                onClick={() => setSpiceFilter('spicy')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  spiceFilter === 'spicy' ? 'bg-red-950/80 text-red-300 font-medium border border-red-900/60' : 'text-zinc-400 hover:text-white'
                }`}
              >
                🌶️ {lang === 'zh' ? '有辣' : 'Spicy'}
              </button>
              <button
                onClick={() => setSpiceFilter('non-spicy')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  spiceFilter === 'non-spicy' ? 'bg-zinc-800 text-emerald-300 font-medium' : 'text-zinc-400 hover:text-white'
                }`}
              >
                🍃 {lang === 'zh' ? '清淡不辣' : 'Mild'}
              </button>
            </div>
          </div>

        </div>

        {/* 3-Column Product Grid */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredItems.map(item => {
            return (
              <div
                key={item.id}
                onClick={() => setCustomizingItem(item)}
                className="group relative flex flex-col rounded-2xl bg-zinc-900 border border-white/10 overflow-hidden hover:border-red-500/40 hover:-translate-y-1 transition-all duration-200 cursor-pointer shadow-lg"
              >
                {/* Visual Media Container (65% proportion) */}
                <div className="relative w-full aspect-[4/3] bg-zinc-950 overflow-hidden flex items-center justify-center p-6">
                  {/* Styled Culinary Visual Canvas */}
                  <div className="absolute inset-0 bg-radial from-zinc-800/40 via-zinc-900 to-zinc-950" />
                  
                  {/* Subtle decorative glow ring */}
                  <div className="absolute h-44 w-44 rounded-full bg-gradient-to-tr from-red-600/10 via-amber-600/15 to-transparent blur-xl group-hover:scale-110 transition-transform duration-500" />

                  {/* High fidelity dish graphic icon representation */}
                  <div className="relative z-10 flex flex-col items-center text-center">
                    <div className="h-24 w-24 rounded-2xl bg-zinc-900/90 border border-white/10 shadow-inner flex items-center justify-center group-hover:scale-105 transition-transform duration-300">
                      {item.category === 'signature' && (
                        <div className="flex flex-col items-center">
                          <span className="text-4xl">🥩</span>
                          <span className="text-[10px] text-amber-400 font-medium mt-1">招牌传承</span>
                        </div>
                      )}
                      {item.category === 'rice' && (
                        <div className="flex flex-col items-center">
                          <span className="text-4xl">🍛</span>
                          <span className="text-[10px] text-red-400 font-medium mt-1">猛火现炒</span>
                        </div>
                      )}
                      {item.category === 'noodles' && (
                        <div className="flex flex-col items-center">
                          <span className="text-4xl">🍜</span>
                          <span className="text-[10px] text-orange-400 font-medium mt-1">原汤手擀</span>
                        </div>
                      )}
                      {item.category === 'drinks' && (
                        <div className="flex flex-col items-center">
                          <span className="text-4xl">🥤</span>
                          <span className="text-[10px] text-emerald-400 font-medium mt-1">原果鲜榨</span>
                        </div>
                      )}
                      {item.category === 'snacks' && (
                        <div className="flex flex-col items-center">
                          <span className="text-4xl">🥟</span>
                          <span className="text-[10px] text-yellow-400 font-medium mt-1">手工点心</span>
                        </div>
                      )}
                    </div>

                    {/* Single subtle tag */}
                    <div className="mt-3 flex items-center gap-2 text-xs text-zinc-400">
                      <span>{item.tags[0]}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.cookTime}</span>
                    </div>
                  </div>

                  {/* Top badges without pill spam */}
                  <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-xs pointer-events-none">
                    {item.isPopular ? (
                      <span className="text-[11px] font-semibold text-amber-300 bg-amber-950/80 border border-amber-800/60 px-2 py-0.5 rounded">
                        {lang === 'zh' ? '热销 TOP' : 'Best Seller'}
                      </span>
                    ) : item.isChefSpecial ? (
                      <span className="text-[11px] font-semibold text-rose-300 bg-rose-950/80 border border-rose-800/60 px-2 py-0.5 rounded">
                        {lang === 'zh' ? '主厨特荐' : 'Chef Choice'}
                      </span>
                    ) : (
                      <span />
                    )}

                    <div className="flex items-center gap-1 text-[11px] font-mono text-zinc-300 bg-black/60 px-2 py-0.5 rounded backdrop-blur-sm">
                      <Star className="h-3 w-3 text-amber-400 fill-amber-400" />
                      <span>{item.rating.toFixed(1)}</span>
                    </div>
                  </div>
                </div>

                {/* Content Block */}
                <div className="flex flex-1 flex-col justify-between p-5 bg-zinc-900 border-t border-white/5">
                  <div>
                    {/* Category kicker */}
                    <div className="text-[11px] font-semibold uppercase tracking-wider text-red-500 mb-1">
                      {lang === 'zh'
                        ? CATEGORIES.find(c => c.key === item.category)?.nameZh
                        : CATEGORIES.find(c => c.key === item.category)?.nameEn}
                    </div>

                    <h3 className="text-base font-bold text-white group-hover:text-red-400 transition-colors">
                      {lang === 'zh' ? item.nameZh : item.nameEn}
                    </h3>

                    <p className="mt-1.5 text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                      {lang === 'zh' ? item.descriptionZh : item.descriptionEn}
                    </p>
                  </div>

                  {/* Card Bottom: Price + Action Button */}
                  <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-between">
                    <div className="flex items-baseline gap-2">
                      <div className="flex items-baseline gap-0.5">
                        <span className="text-xs text-red-500 font-bold">¥</span>
                        <span className="text-xl font-black text-white font-mono tabular-nums">
                          {item.price}
                        </span>
                      </div>
                      {item.originalPrice && (
                        <span className="text-xs text-zinc-500 line-through font-mono tabular-nums">
                          ¥{item.originalPrice}
                        </span>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setCustomizingItem(item);
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-red-600 rounded-lg hover:bg-red-500 active:scale-95 transition-all shadow-[0_0_12px_rgba(220,38,38,0.3)]"
                      aria-label={`Customize & add ${item.nameEn}`}
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>{lang === 'zh' ? '选规格 / 加点' : 'Select'}</span>
                    </button>
                  </div>

                </div>

              </div>
            );
          })}
        </div>

        {/* Empty state fallback */}
        {filteredItems.length === 0 && (
          <div className="text-center py-16 bg-zinc-900/50 rounded-2xl border border-white/10 mt-8">
            <p className="text-sm text-zinc-400">
              {lang === 'zh' ? '未找到符合条件的菜品，请尝试清空搜索词。' : 'No dishes found matching your search.'}
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSpiceFilter('all');
              }}
              className="mt-3 px-4 py-2 text-xs font-medium text-white bg-zinc-800 rounded-lg hover:bg-zinc-700"
            >
              {lang === 'zh' ? '重置筛选条件' : 'Reset Filters'}
            </button>
          </div>
        )}

      </div>

      {/* Customization modal */}
      <MenuCustomizationModal
        item={customizingItem}
        onClose={() => setCustomizingItem(null)}
      />
    </section>
  );
}
