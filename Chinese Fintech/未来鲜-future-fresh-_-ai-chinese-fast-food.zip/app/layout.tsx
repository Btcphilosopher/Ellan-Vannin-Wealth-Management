import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '未来鲜 Future Fresh | AI Chinese Fast Food',
  description: 'Next-generation Chinese fast food powered by AI robotic wok kitchens, authentic regional flavors, and instant smart ordering.',
  openGraph: {
    title: '未来鲜 Future Fresh | AI Chinese Fast Food',
    description: 'Next-generation Chinese fast food powered by AI robotic wok kitchens, authentic regional flavors, and instant smart ordering.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '未来鲜 Future Fresh | AI Chinese Fast Food',
    description: 'Next-generation Chinese fast food powered by AI robotic wok kitchens, authentic regional flavors, and instant smart ordering.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
