'use client';

import React from 'react';
import { AppProvider } from '@/context/AppContext';
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import MenuSection from '@/components/MenuSection';
import SmartKitchenSimulator from '@/components/SmartKitchenSimulator';
import PhoneMockupInteractive from '@/components/PhoneMockupInteractive';
import StoreLocatorSection from '@/components/StoreLocatorSection';
import BrandStorySection from '@/components/BrandStorySection';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import OrderTrackerModal from '@/components/OrderTrackerModal';

export default function HomePage() {
  return (
    <AppProvider>
      <div className="min-h-screen bg-black text-white flex flex-col font-sans selection:bg-red-600 selection:text-white">
        {/* Navigation Bar */}
        <Navbar />

        {/* Main Content Sections */}
        <main className="flex-1 w-full">
          {/* Hero Section with Flagship Photo, Interactive Hotspots & KPIs */}
          <HeroSection />

          {/* Master Wok Menu & Customization */}
          <MenuSection />

          {/* Robotic Kitchen Wok Simulator */}
          <SmartKitchenSimulator />

          {/* Mobile Kiosk Interactive Smartphone App Experience */}
          <PhoneMockupInteractive />

          {/* Flagship Store Locations */}
          <StoreLocatorSection />

          {/* Brand Philosophy & Master Heritage */}
          <BrandStorySection />
        </main>

        {/* Footer */}
        <Footer />

        {/* Slide-over Cart Drawer */}
        <CartDrawer />

        {/* Real-time Robotic Cooking Progress Modal */}
        <OrderTrackerModal />
      </div>
    </AppProvider>
  );
}
