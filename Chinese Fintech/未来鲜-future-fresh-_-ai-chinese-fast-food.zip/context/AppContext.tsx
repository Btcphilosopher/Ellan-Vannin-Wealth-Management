'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { MenuItem } from '@/data/menu';

export type Language = 'zh' | 'en';
export type DiningMode = 'dine_in' | 'takeaway' | 'delivery';

export interface CartItemOption {
  spiciness?: string;
  portion?: string;
  addons: { nameZh: string; nameEn: string; price: number }[];
}

export interface CartItem {
  id: string; // unique item cart key (e.g. itemId + options string)
  menuItem: MenuItem;
  quantity: number;
  options: CartItemOption;
  unitPrice: number;
}

export interface ActiveOrder {
  orderId: string;
  pickupCode: string; // e.g. #A-108
  tableNumber?: string;
  diningMode: DiningMode;
  items: CartItem[];
  subtotal: number;
  total: number;
  createdAt: number;
  estimatedSeconds: number;
  currentStep: number; // 0: accepted, 1: robotic wok cooking, 2: plating & QC, 3: ready / delivering
}

interface AppContextType {
  lang: Language;
  setLang: (l: Language) => void;
  cart: CartItem[];
  addToCart: (item: MenuItem, quantity?: number, options?: CartItemOption) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, delta: number) => void;
  clearCart: () => void;
  totalCount: number;
  subtotal: number;
  grandTotal: number;
  discount: number;
  diningMode: DiningMode;
  setDiningMode: (m: DiningMode) => void;
  tableNumber: string;
  setTableNumber: (t: string) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  activeOrder: ActiveOrder | null;
  placeOrder: () => void;
  cancelOrder: () => void;
  isOrderModalOpen: boolean;
  setIsOrderModalOpen: (open: boolean) => void;
  selectedStoreId: string;
  setSelectedStoreId: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLang] = useState<Language>('zh');
  const [cart, setCart] = useState<CartItem[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('weilai_cart');
        if (saved) return JSON.parse(saved);
      } catch {}
    }
    return [];
  });
  const [diningMode, setDiningMode] = useState<DiningMode>('dine_in');
  const [tableNumber, setTableNumber] = useState<string>('08');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedStoreId, setSelectedStoreId] = useState('bj-future-tower');
  const [activeOrder, setActiveOrder] = useState<ActiveOrder | null>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('weilai_cart', JSON.stringify(cart));
    } catch {}
  }, [cart]);

  // Order progression simulation
  useEffect(() => {
    if (!activeOrder) return;
    if (activeOrder.currentStep >= 3) return;

    const timer = setTimeout(() => {
      setActiveOrder(prev => {
        if (!prev) return null;
        const nextStep = prev.currentStep + 1;
        return {
          ...prev,
          currentStep: nextStep,
        };
      });
    }, 7000); // Progress every 7 seconds for interactive demo

    return () => clearTimeout(timer);
  }, [activeOrder]);

  const addToCart = (
    item: MenuItem,
    quantity = 1,
    options: CartItemOption = { addons: [] }
  ) => {
    const addonPrice = (options.addons || []).reduce((acc, a) => acc + a.price, 0);
    const unitPrice = item.price + addonPrice;
    const optionKey = `${item.id}-${options.spiciness || 'std'}-${options.portion || 'std'}-${(options.addons || []).map(a => a.nameZh).join('-')}`;

    setCart(prev => {
      const existingIndex = prev.findIndex(ci => ci.id === optionKey);
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + quantity
        };
        return next;
      } else {
        return [
          ...prev,
          {
            id: optionKey,
            menuItem: item,
            quantity,
            options,
            unitPrice
          }
        ];
      }
    });
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(ci => ci.id !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, delta: number) => {
    setCart(prev =>
      prev
        .map(ci => {
          if (ci.id === cartItemId) {
            const nextQty = ci.quantity + delta;
            return nextQty > 0 ? { ...ci, quantity: nextQty } : null;
          }
          return ci;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const clearCart = () => setCart([]);

  const totalCount = cart.reduce((acc, ci) => acc + ci.quantity, 0);
  const subtotal = cart.reduce((acc, ci) => acc + ci.unitPrice * ci.quantity, 0);
  // Member coupon if subtotal > 30, discount 3
  const discount = subtotal >= 30 ? 3 : 0;
  const packagingFee = diningMode === 'takeaway' ? 2 : 0;
  const grandTotal = Math.max(0, subtotal - discount + packagingFee);

  const placeOrder = () => {
    if (cart.length === 0) return;
    const orderNum = Math.floor(100 + Math.random() * 900);
    const newOrder: ActiveOrder = {
      orderId: `WLX-${Date.now().toString().slice(-6)}`,
      pickupCode: `#A-${orderNum}`,
      tableNumber: diningMode === 'dine_in' ? tableNumber : undefined,
      diningMode,
      items: [...cart],
      subtotal,
      total: grandTotal,
      createdAt: Date.now(),
      estimatedSeconds: 150,
      currentStep: 0,
    };

    setActiveOrder(newOrder);
    clearCart();
    setIsCartOpen(false);
    setIsOrderModalOpen(true);
  };

  const cancelOrder = () => {
    setActiveOrder(null);
    setIsOrderModalOpen(false);
  };

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalCount,
        subtotal,
        grandTotal,
        discount,
        diningMode,
        setDiningMode,
        tableNumber,
        setTableNumber,
        isCartOpen,
        setIsCartOpen,
        activeOrder,
        placeOrder,
        cancelOrder,
        isOrderModalOpen,
        setIsOrderModalOpen,
        selectedStoreId,
        setSelectedStoreId
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
