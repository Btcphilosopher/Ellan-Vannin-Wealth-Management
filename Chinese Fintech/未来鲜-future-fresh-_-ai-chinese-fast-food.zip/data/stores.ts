export interface StoreLocation {
  id: string;
  nameZh: string;
  nameEn: string;
  badgeZh: string;
  badgeEn: string;
  addressZh: string;
  addressEn: string;
  hoursZh: string;
  hoursEn: string;
  phone: string;
  statusZh: string;
  statusEn: string;
  openNow: boolean;
  activeOrders: number;
  avgWaitMins: number;
  kiosksAvailable: number;
  robotArmsCount: number;
  dineInSeats: number;
  features: string[];
}

export const STORES: StoreLocation[] = [
  {
    id: 'bj-future-tower',
    nameZh: '北京 · 未来大厦旗舰店',
    nameEn: 'Beijing · Future Tower Flagship',
    badgeZh: 'AI 标杆概念店',
    badgeEn: 'AI Concept Flagship',
    addressZh: '北京市海淀区中关村南大街1号 未来大厦首层环形光幕厅',
    addressEn: '1 Zhongguancun South Ave, Haidian, Beijing · Future Tower L1',
    hoursZh: '10:00 - 22:00 (每日不打烊)',
    hoursEn: '10:00 - 22:00 Daily',
    phone: '010-8899-2388',
    statusZh: '正常营业 · 极速出餐中',
    statusEn: 'Open · Fast Serving',
    openNow: true,
    activeOrders: 4,
    avgWaitMins: 2.8,
    kiosksAvailable: 6,
    robotArmsCount: 4,
    dineInSeats: 68,
    features: ['全景环幕落地玻璃', '双臂现炒机器人', '送餐机器人入座', '无感面容/扫码自提'],
  },
  {
    id: 'sh-zhangjiang',
    nameZh: '上海 · 张江人工智能岛店',
    nameEn: 'Shanghai · Zhangjiang AI Island Store',
    badgeZh: '科技园区智能店',
    badgeEn: 'Tech Park Smart Store',
    addressZh: '上海市浦东新区张江高科技园区博云路2号 智能创新广场B座',
    addressEn: '2 Boyun Rd, Zhangjiang Hi-Tech Park, Pudong, Shanghai',
    hoursZh: '08:00 - 21:30 (周一至周日)',
    hoursEn: '08:00 - 21:30 Mon - Sun',
    phone: '021-5088-6622',
    statusZh: '正常营业 · 畅享美味',
    statusEn: 'Open Now',
    openNow: true,
    activeOrders: 6,
    avgWaitMins: 3.2,
    kiosksAvailable: 4,
    robotArmsCount: 3,
    dineInSeats: 52,
    features: ['24H智能保温取餐柜', '大功率IH瞬炒炉', '午间白领速取线'],
  },
  {
    id: 'sz-nanshan',
    nameZh: '深圳 · 南山科技生态园店',
    nameEn: 'Shenzhen · Nanshan Eco-Tech Park Store',
    badgeZh: '极速出餐体验店',
    badgeEn: 'Speed Dining Hub',
    addressZh: '深圳市南山区高新南九道科技生态园10栋首层 101-103',
    addressEn: 'Bldg 10, Shenzhen Eco-Tech Park, Gaoxin South 9th Rd, Nanshan',
    hoursZh: '09:30 - 22:30',
    hoursEn: '09:30 - 22:30 Daily',
    phone: '0755-8699-7711',
    statusZh: '正常营业 · 欢迎光临',
    statusEn: 'Open Now',
    openNow: true,
    activeOrders: 2,
    avgWaitMins: 2.5,
    kiosksAvailable: 5,
    robotArmsCount: 4,
    dineInSeats: 60,
    features: ['室内无轨配送机器人', '现烤白吉馍明档', '双语智能屏点餐'],
  }
];
