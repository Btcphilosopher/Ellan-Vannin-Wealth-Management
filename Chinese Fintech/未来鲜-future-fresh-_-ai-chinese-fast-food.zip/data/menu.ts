export interface MenuItem {
  id: string;
  nameZh: string;
  nameEn: string;
  category: 'signature' | 'rice' | 'noodles' | 'snacks' | 'drinks';
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  cookTime: string; // e.g. "2.5 min"
  calories: number;
  spiceLevel: 0 | 1 | 2 | 3; // 0=None, 1=Mild, 2=Medium, 3=Fiery
  tags: string[];
  descriptionZh: string;
  descriptionEn: string;
  isPopular?: boolean;
  isChefSpecial?: boolean;
  availableCustomizations?: {
    spiciness?: string[];
    portion?: string[];
    addons?: { nameZh: string; nameEn: string; price: number }[];
  };
}

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'rougamo-signature',
    nameZh: '招牌经典腊汁肉夹馍',
    nameEn: 'Signature Crispy Pork Rougamo',
    category: 'signature',
    price: 12,
    originalPrice: 15,
    rating: 4.95,
    reviewsCount: 3840,
    cookTime: '1.5 分钟',
    calories: 420,
    spiceLevel: 1,
    tags: ['百年秘方', '外酥里嫩', '现烤现剁'],
    descriptionZh: '三十道工序千层酥皮白吉馍，内夹慢火炖煮12小时浓香腊汁猪肉，肥而不腻，肉汁四溢。',
    descriptionEn: '30-layer crispy baked bun stuffed with tender 12-hour slow-braised pork belly, brimming with aromatic spiced jus.',
    isPopular: true,
    isChefSpecial: true,
    availableCustomizations: {
      spiciness: ['微辣 (Classic Mild)', '加青椒微辣 (Add Green Chili)', '不辣 (No Chili)'],
      portion: ['标准份 (Standard)', '肉量加倍 (+¥5 Double Meat)'],
      addons: [
        { nameZh: '秘制溏心卤蛋', nameEn: 'Braised Lava Egg', price: 2.5 },
        { nameZh: '香脆酸青椒粒', nameEn: 'Pickled Diced Peppers', price: 1.5 },
      ]
    }
  },
  {
    id: 'kung-pao-chicken',
    nameZh: '现炒宫保鸡丁盖饭',
    nameEn: 'Robotic Wok Kung Pao Chicken Rice',
    category: 'signature',
    price: 16,
    originalPrice: 18,
    rating: 4.92,
    reviewsCount: 5210,
    cookTime: '2.5 分钟',
    calories: 610,
    spiceLevel: 2,
    tags: ['280°C镬气', '嫩滑鸡腿肉', '香脆花生'],
    descriptionZh: 'AI智能双机械臂280°C精准猛火爆炒，严选优质鸡腿肉丁与酥脆花生，荔枝微酸甜甜辣适口，镬气十足。',
    descriptionEn: 'Flash-seared at 280°C by dual robotic wok arms. Juicy diced chicken thigh, crunchy roasted peanuts in a tangy lychee-spiced reduction.',
    isPopular: true,
    availableCustomizations: {
      spiciness: ['微辣 (Mild)', '经典中辣 (Standard)', '嗜辣特调 (Extra Fiery)'],
      portion: ['标准米饭 (Normal Rice)', '加饭 (Extra Rice Free)'],
      addons: [
        { nameZh: '秘制溏心卤蛋', nameEn: 'Braised Lava Egg', price: 2.5 },
        { nameZh: '慢熬玉米排骨老火汤', nameEn: 'Corn & Rib Soup', price: 4.0 },
      ]
    }
  },
  {
    id: 'mapo-tofu-rice',
    nameZh: '天府麻婆豆腐盖饭',
    nameEn: 'Sichuan Mapo Tofu Rice Bowl',
    category: 'rice',
    price: 14,
    rating: 4.88,
    reviewsCount: 2940,
    cookTime: '2.0 分钟',
    calories: 530,
    spiceLevel: 3,
    tags: ['汉源花椒', '郫县豆瓣', '麻辣鲜香'],
    descriptionZh: '精选嫩豆腐配以特级和牛末、汉源大红袍花椒与三年陈酿郫县豆瓣，红油透亮，豆腐滑嫩如凝脂。',
    descriptionEn: 'Silken tofu stewed with hand-minced beef, fermented Pixian bean paste, and numbing Hanyuan red peppercorns.',
    isPopular: true,
    availableCustomizations: {
      spiciness: ['微麻微辣 (Gentle Numb)', '经典川味 (Authentic Sichuan)', '重麻特辣 (Heavy Numbing)'],
      portion: ['标准米饭', '免费多加饭 (Extra Rice)'],
      addons: [
        { nameZh: '爽口鲜脆泡菜', nameEn: 'Pickled Veggie Cup', price: 2.0 },
        { nameZh: '荷包蛋', nameEn: 'Crispy Fried Egg', price: 2.0 }
      ]
    }
  },
  {
    id: 'beef-shank-noodles',
    nameZh: '原汤红烧牛肉手擀面',
    nameEn: 'Slow-Simmered Beef Shank Noodles',
    category: 'noodles',
    price: 18,
    originalPrice: 22,
    rating: 4.96,
    reviewsCount: 4620,
    cookTime: '3.0 分钟',
    calories: 680,
    spiceLevel: 1,
    tags: ['老火慢炖8小时', '筋道手擀', '厚切牛腱'],
    descriptionZh: '精选安格斯草饲牛腱厚切大块，配合草果肉蔻等24味天然香料慢炖8小时，汤底醇厚浓鲜，面条弹牙劲道。',
    descriptionEn: 'Generous chunks of grass-fed Angus beef shank slow-simmered for 8 hours with 24 natural herbs in artisan broth.',
    isPopular: true,
    isChefSpecial: true,
    availableCustomizations: {
      spiciness: ['原汤微辣 (Original Mild)', '麻辣红油 (Spicy Red Oil)', '清淡不辣 (No Chili)'],
      portion: ['标准面量', '面条免费加大 (+30% Noodles)'],
      addons: [
        { nameZh: '鲜嫩绿叶时蔬', nameEn: 'Fresh Bok Choy', price: 2.0 },
        { nameZh: '加厚切牛肉一份', nameEn: 'Extra Beef Shank', price: 6.0 },
      ]
    }
  },
  {
    id: 'crispy-chicken-burger',
    nameZh: '未来香脆鸡腿堡',
    nameEn: 'Future Crispy Chicken Thigh Burger',
    category: 'signature',
    price: 15,
    rating: 4.86,
    reviewsCount: 2120,
    cookTime: '2.0 分钟',
    calories: 540,
    spiceLevel: 1,
    tags: ['整块去骨鸡腿', '九层塔风味', '外焦里嫩'],
    descriptionZh: '整块鲜嫩去骨鸡腿肉真空低温慢煮后极速裹粉起酥，特调九层塔甜辣酱汁，每一口都是多汁满足。',
    descriptionEn: 'Whole boneless tender chicken thigh, sous-vide then flash-fried for golden crispness, kissed with basil chili glaze.',
    isPopular: false,
    availableCustomizations: {
      spiciness: ['甜辣味 (Sweet & Spicy)', '椒麻风味 (Sichuan Pepper)', '原味原香 (Classic)'],
      portion: ['标准堡'],
      addons: [
        { nameZh: '芝士熔岩片', nameEn: 'Melted Cheddar', price: 2.0 },
        { nameZh: '双重脆鸡排 (+¥8)', nameEn: 'Double Patty', price: 8.0 }
      ]
    }
  },
  {
    id: 'soup-dumplings-xiaolongbao',
    nameZh: '手工鲜汁灌汤小笼包 (6只)',
    nameEn: 'Handcrafted Steamed Soup Dumplings (6pcs)',
    category: 'noodles',
    price: 15,
    rating: 4.91,
    reviewsCount: 3100,
    cookTime: '3.5 分钟',
    calories: 390,
    spiceLevel: 0,
    tags: ['皮薄如纸', '一口爆汁', '现蒸现出'],
    descriptionZh: '经典半透明薄皮，内裹浓郁皮冻与鲜土猪肉馅，蒸汽循环恒温蒸箱现蒸，先吸热汤，再蘸镇江香醋。',
    descriptionEn: 'Paper-thin delicate wrappers filled with succulent heritage pork and scalding rich gelatin broth.',
    isPopular: true,
    availableCustomizations: {
      spiciness: ['附赠镇江香醋与嫩姜丝 (With Zhenjiang Vinegar & Ginger)'],
      portion: ['一笼6只 (6 pieces)'],
      addons: [
        { nameZh: '特调辣油碟', nameEn: 'Aromatic Chili Oil', price: 1.0 }
      ]
    }
  },
  {
    id: 'tomato-egg-rice',
    nameZh: '老广经典番茄炒蛋盖饭',
    nameEn: 'Homestyle Tomato Swirl Scrambled Egg Rice',
    category: 'rice',
    price: 13,
    rating: 4.89,
    reviewsCount: 1980,
    cookTime: '2.0 分钟',
    calories: 480,
    spiceLevel: 0,
    tags: ['沙瓤番茄', '生态草鸡蛋', '国民下饭神菜'],
    descriptionZh: '新鲜沙瓤红熟番茄去皮熬出自然酸甜浓汁，三枚生态走地鸡蛋猛火炒出滑嫩蜂窝，裹满五常香米。',
    descriptionEn: 'Sun-ripened tomatoes simmered into silky sweet-tart coulis, scrambled with 3 pasture-raised organic eggs.',
    isPopular: false,
    availableCustomizations: {
      spiciness: ['原味酸甜 (Natural Sweet & Sour)'],
      portion: ['标准米饭', '免费加饭'],
      addons: [
        { nameZh: '秘制溏心卤蛋', nameEn: 'Braised Lava Egg', price: 2.5 }
      ]
    }
  },
  {
    id: 'hunan-farmhouse-pork',
    nameZh: '潇湘农家小炒肉伴饭',
    nameEn: 'Hunan Farmhouse Pork with Chili Rice',
    category: 'rice',
    price: 17,
    rating: 4.93,
    reviewsCount: 3450,
    cookTime: '2.2 分钟',
    calories: 640,
    spiceLevel: 2,
    tags: ['螺丝椒', '五花肉片', '地道湖南风味'],
    descriptionZh: '湖南特选皮薄爽脆螺丝椒，与农家优质前腿五花肉片大火爆炒，酱香浓郁，鲜辣脆爽，米饭杀手。',
    descriptionEn: 'Crisp green spiral peppers wok-seared with thinly sliced tender pork belly, seasoned with aged soy & garlic.',
    isPopular: true,
    availableCustomizations: {
      spiciness: ['地道鲜辣 (Hunan Spicy)', '减辣微辣 (Mild)', '加重特辣 (Extra Spicy)'],
      portion: ['标准米饭', '免费加饭'],
      addons: [
        { nameZh: '溏心煎蛋', nameEn: 'Sunny Egg', price: 2.0 }
      ]
    }
  },
  {
    id: 'beijing-zhajiangmian',
    nameZh: '老北京六必居炸酱手擀面',
    nameEn: 'Old Beijing Soybean Paste Noodles',
    category: 'noodles',
    price: 15,
    rating: 4.85,
    reviewsCount: 1820,
    cookTime: '2.5 分钟',
    calories: 590,
    spiceLevel: 0,
    tags: ['百年六必居酱', '现切黄瓜丝', '绿豆芽菜码'],
    descriptionZh: '传承中华老字号干黄酱与甜面酱三七开秘熬肉丁酱，配以爽脆黄瓜丝、心儿里美萝卜丝与绿豆芽。',
    descriptionEn: 'Traditional hand-pulled noodles tossed with savory braised pork mince sauce and julienned seasonal fresh vegetables.',
    availableCustomizations: {
      spiciness: ['原香不辣 (Savory)'],
      portion: ['标准份', '加面 (+¥2)'],
      addons: [
        { nameZh: '香脆蒜瓣', nameEn: 'Fresh Garlic Cloves', price: 0 }
      ]
    }
  },
  {
    id: 'drink-waxberry-lemon',
    nameZh: '鲜榨杨梅柠檬气泡水 (冷)',
    nameEn: 'Fresh Waxberry Lemon Sparkling Soda',
    category: 'drinks',
    price: 6,
    rating: 4.97,
    reviewsCount: 2900,
    cookTime: '0.5 分钟',
    calories: 110,
    spiceLevel: 0,
    tags: ['原果鲜榨', '低糖轻卡', '解腻清爽'],
    descriptionZh: '当季东魁杨梅原汁慢压，融入香水柠檬薄片与细密气泡水，酸甜清洌，搭配爆炒盖饭极致解腻。',
    descriptionEn: 'Freshly pressed seasonal Dongkui waxberry juice infused with perfume lemon slices and sparkling mineral water.',
    isPopular: true,
    availableCustomizations: {
      spiciness: ['正常冰 (Regular Ice)', '少冰 (Less Ice)', '去冰 (No Ice)'],
      portion: ['500ml 大杯'],
      addons: [
        { nameZh: '添加啵啵晶球', nameEn: 'Chewy Boba Pearls', price: 1.5 }
      ]
    }
  },
  {
    id: 'drink-iced-plum',
    nameZh: '古法九蒸冰镇酸梅汤',
    nameEn: 'Slow-Brewed Iced Smoked Plum Drink',
    category: 'drinks',
    price: 5,
    rating: 4.94,
    reviewsCount: 2210,
    cookTime: '0.5 分钟',
    calories: 95,
    spiceLevel: 0,
    tags: ['乌梅山楂', '桂花回甘', '生津止渴'],
    descriptionZh: '严选浙江优质乌梅、承德山楂、甘草与陈皮慢火熬煮4小时，出锅前撒入江南金桂，生津润喉。',
    descriptionEn: 'Smoked plums, hawthorn berries, dried tangerine peel brewed for 4 hours, scented with golden osmanthus blossoms.',
    isPopular: false
  },
  {
    id: 'soup-corn-rib',
    nameZh: '慢熬玉米排骨老火瓦罐汤',
    nameEn: 'Slow-Simmered Sweet Corn & Pork Rib Soup',
    category: 'drinks',
    price: 8,
    rating: 4.90,
    reviewsCount: 1650,
    cookTime: '1.0 分钟',
    calories: 180,
    spiceLevel: 0,
    tags: ['文火慢熬', '清甜润燥', '真材实料'],
    descriptionZh: '优质猪肋排焯水文火慢煨3小时，加入甜玉米段、胡萝卜与枸杞，汤清味美，温润养胃。',
    descriptionEn: 'Tender pork spare ribs simmered in an earthenware pot with sweet corn cob, carrots and goji berries.'
  }
];

export const CATEGORIES = [
  { key: 'all', nameZh: '全部菜单', nameEn: 'All Menu' },
  { key: 'signature', nameZh: '招牌必吃', nameEn: 'Signatures' },
  { key: 'rice', nameZh: '现炒盖饭', nameEn: 'Wok Rice Bowls' },
  { key: 'noodles', nameZh: '面食点心', nameEn: 'Noodles & Dim Sum' },
  { key: 'drinks', nameZh: '养生汤饮', nameEn: 'Drinks & Soups' },
] as const;
