package com.example.cnequity.data.repository

data class ApiEndpointInfo(
    val method: String,
    val path: String,
    val summary: String,
    val sampleRequestParams: Map<String, String>,
    val sampleResponseJson: String
)

data class WsMessageFrame(
    val timestamp: String,
    val streamTopic: String,
    val payloadJson: String
)

class ApiSdkRepository {

    fun getApiEndpoints(): List<ApiEndpointInfo> {
        return listOf(
            ApiEndpointInfo(
                method = "GET",
                path = "/api/v1/securities/master",
                summary = "查询沪深京 Security Master 标的主表",
                sampleRequestParams = mapOf("exchange" to "SSE", "market" to "MAIN", "type" to "A_SHARE"),
                sampleResponseJson = """
                {
                  "code": 200,
                  "message": "success",
                  "data": [
                    {
                      "security_id": "600519.SH",
                      "ticker": "600519",
                      "ISIN": "CNE0000018R8",
                      "exchange": "SSE",
                      "market": "MAIN",
                      "name": "贵州茅台",
                      "sw_industry_l1": "食品饮料"
                    }
                  ]
                }
                """.trimIndent()
            ),
            ApiEndpointInfo(
                method = "GET",
                path = "/api/v1/market/l2_depth",
                summary = "获取 Level-2 10档买卖盘口与分时成交",
                sampleRequestParams = mapOf("ticker" to "600519.SH"),
                sampleResponseJson = """
                {
                  "ticker": "600519.SH",
                  "last_price": 1668.50,
                  "bids": [{"price": 1668.49, "volume": 1200, "count": 14}],
                  "asks": [{"price": 1668.51, "volume": 800, "count": 9}]
                }
                """.trimIndent()
            ),
            ApiEndpointInfo(
                method = "POST",
                path = "/api/v1/rules/validate_order",
                summary = "通过 MarketRuleVersion 校验订单合规性",
                sampleRequestParams = mapOf("rule_id" to "RULE_CN_2024_V2", "ticker" to "688981.SH", "price" to "58.60", "volume" to "200"),
                sampleResponseJson = """
                {
                  "valid": true,
                  "rule_version": "RULE_CN_2024_V2",
                  "price_band": [46.88, 70.32],
                  "status": "ACCEPTED"
                }
                """.trimIndent()
            ),
            ApiEndpointInfo(
                method = "POST",
                path = "/api/v1/quant/event_study",
                summary = "触发累计超额收益率 (CAR) 事件研究计算",
                sampleRequestParams = mapOf("event_type" to "EARNINGS_SURPRISE", "window" to "[-10, 20]"),
                sampleResponseJson = """
                {
                  "event": "EARNINGS_SURPRISE",
                  "sample_size": 120,
                  "car_20d": 8.45,
                  "t_stat": 4.28,
                  "p_value": 0.0001
                }
                """.trimIndent()
            )
        )
    }

    fun generatePythonSdkCode(endpoint: ApiEndpointInfo): String {
        return """
        # Python SDK (cn_equity_core)
        from cn_equity_core import TerminalClient, RuleEngine, OrderType
        
        client = TerminalClient(api_key="env_sec_cn_key_88", host="https://api.cn-equity.core")
        
        # 1. Fetch Security Master & L2 Depth
        sec_info = client.security_master.get(ticker="${endpoint.sampleRequestParams["ticker"] ?: "600519.SH"}")
        l2_depth = client.market_data.get_l2_depth(ticker="${endpoint.sampleRequestParams["ticker"] ?: "600519.SH"}")
        
        print("L1 Last Price:", l2_depth.last_price)
        print("Bid 1 Level:", l2_depth.bids[0].price, l2_depth.bids[0].volume)
        
        # 2. Validate Order with Rules Engine
        rule_version = client.rules.get_active_version("RULE_CN_2024_V2")
        validated = rule_version.validate_order(
            ticker="600519.SH",
            price=1668.50,
            volume=100,
            order_type=OrderType.LIMIT
        )
        if validated.is_accepted:
            order_res = client.order_book.submit(validated.to_order())
            print("Order Submitted ID:", order_res.order_id)
        """.trimIndent()
    }

    fun generateRSdkCode(endpoint: ApiEndpointInfo): String {
        return """
        # R SDK (cnequitycore)
        library(cnequitycore)
        
        client <- cn_equity_connect(api_key = "env_sec_cn_key_88")
        
        # Query Security Master and Factor Library
        sec_df <- get_security_master(client, exchange = "SSE")
        factors_df <- get_factor_scores(client, ticker = "600519.SH")
        
        # Run Event Study CAR Analysis
        event_res <- run_event_study(
          client,
          event_name = "EARNINGS_SURPRISE",
          window_min = -10,
          window_max = 20
        )
        
        summary(event_res)
        plot(event_res${'$'}car_series, type = "l", col = "red", main = "CAR Event Study [-10, +20]")
        """.trimIndent()
    }

    fun generateRustSdkCode(endpoint: ApiEndpointInfo): String {
        return """
        // Rust SDK (cn_equity_core)
        use cn_equity_core::{TerminalClient, SecurityMaster, MarketDepth, OrderBuilder};
        
        #[tokio::main]
        async fn main() -> Result<(), Box<dyn std::error::Error>> {
            let client = TerminalClient::new("https://api.cn-equity.core", "env_sec_cn_key_88")?;
            
            let l2_depth: MarketDepth = client
                .market_data()
                .get_l2_depth("${endpoint.sampleRequestParams["ticker"] ?: "600519.SH"}")
                .await?;
                
            println!("Rust L2 Depth Price: {:.2}", l2_depth.last_price);
            Ok(())
        }
        """.trimIndent()
    }
}
