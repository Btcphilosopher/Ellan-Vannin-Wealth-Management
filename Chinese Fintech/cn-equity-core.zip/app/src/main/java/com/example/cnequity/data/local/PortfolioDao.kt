package com.example.cnequity.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.cnequity.model.PortfolioPositionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PortfolioDao {
    @Query("SELECT * FROM portfolio_positions ORDER BY ticker ASC")
    fun getAllPositions(): Flow<List<PortfolioPositionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosition(position: PortfolioPositionEntity)

    @Query("DELETE FROM portfolio_positions WHERE ticker = :ticker")
    suspend fun deletePosition(ticker: String)
}
