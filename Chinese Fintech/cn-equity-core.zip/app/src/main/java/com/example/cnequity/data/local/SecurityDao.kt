package com.example.cnequity.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.cnequity.model.CompanyEntity
import com.example.cnequity.model.SecurityEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SecurityDao {
    @Query("SELECT * FROM security_master ORDER BY security_id ASC")
    fun getAllSecurities(): Flow<List<SecurityEntity>>

    @Query("SELECT * FROM security_master WHERE security_id = :id LIMIT 1")
    suspend fun getSecurityById(id: String): SecurityEntity?

    @Query("SELECT * FROM security_master WHERE ticker LIKE '%' || :query || '%' OR name LIKE '%' || :query || '%' OR company_cn_name LIKE '%' || :query || '%'")
    fun searchSecurities(query: String): Flow<List<SecurityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSecurities(securities: List<SecurityEntity>)

    @Query("SELECT * FROM company_master WHERE issuer_id = :issuerId LIMIT 1")
    suspend fun getCompanyByIssuerId(issuerId: String): CompanyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompanies(companies: List<CompanyEntity>)
}
