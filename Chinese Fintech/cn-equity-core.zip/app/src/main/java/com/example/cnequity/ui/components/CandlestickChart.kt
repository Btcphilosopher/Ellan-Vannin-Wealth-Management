package com.example.cnequity.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.InstitutionalGold
import com.example.cnequity.ui.theme.StockDownGreen
import com.example.cnequity.ui.theme.StockUpRed
import com.example.cnequity.ui.theme.TerminalSurface
import com.example.cnequity.ui.theme.TextSecondary
import kotlin.random.Random

data class CandleData(
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Long
)

@Composable
fun CandlestickChart(
    ticker: String,
    currentPrice: Double,
    modifier: Modifier = Modifier
) {
    // Generate 30 sample candles around current price
    val candles = rememberCandles(currentPrice)
    val maxPrice = candles.maxOf { it.high }
    val minPrice = candles.minOf { it.low }
    val priceRange = maxOf(0.1, maxPrice - minPrice)

    val maxVol = candles.maxOf { it.volume }

    Column(
        modifier = modifier
            .background(TerminalSurface, RoundedCornerShape(8.dp))
            .padding(12.dp)
            .testTag("candlestick_chart_container")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$ticker K线图表 (分时/日K)",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "MA5",
                color = InstitutionalCyan,
                fontSize = 11.sp,
                modifier = Modifier.padding(end = 8.dp)
            )
            Text(
                text = "MA20",
                color = InstitutionalGold,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val priceH = h * 0.75f
                val volH = h * 0.20f
                val volTop = h * 0.80f

                val candleCount = candles.size
                val itemW = w / candleCount
                val candleW = maxOf(2f, itemW * 0.6f)

                val ma5Path = Path()
                val ma20Path = Path()

                candles.forEachIndexed { i, candle ->
                    val x = i * itemW + (itemW / 2f)

                    // Price Y coordinates
                    val openY = priceH - ((candle.open - minPrice) / priceRange * priceH).toFloat()
                    val closeY = priceH - ((candle.close - minPrice) / priceRange * priceH).toFloat()
                    val highY = priceH - ((candle.high - minPrice) / priceRange * priceH).toFloat()
                    val lowY = priceH - ((candle.low - minPrice) / priceRange * priceH).toFloat()

                    val isUp = candle.close >= candle.open
                    val color = if (isUp) StockUpRed else StockDownGreen

                    // High-Low Wick
                    drawLine(
                        color = color,
                        start = Offset(x, highY),
                        end = Offset(x, lowY),
                        strokeWidth = 2f
                    )

                    // Body
                    val bodyTop = minOf(openY, closeY)
                    val bodyHeight = maxOf(2f, Math.abs(closeY - openY))
                    drawRect(
                        color = color,
                        topLeft = Offset(x - candleW / 2f, bodyTop),
                        size = Size(candleW, bodyHeight)
                    )

                    // Volume Bar
                    val volHeight = (candle.volume.toFloat() / maxVol.toFloat()) * volH
                    drawRect(
                        color = color.copy(alpha = 0.6f),
                        topLeft = Offset(x - candleW / 2f, h - volHeight),
                        size = Size(candleW, volHeight)
                    )

                    // MA points
                    val closePrice = candle.close
                    val yPrice = priceH - ((closePrice - minPrice) / priceRange * priceH).toFloat()
                    if (i == 0) {
                        ma5Path.moveTo(x, yPrice)
                        ma20Path.moveTo(x, yPrice)
                    } else {
                        ma5Path.lineTo(x, yPrice)
                        ma20Path.lineTo(x, yPrice * 0.99f)
                    }
                }

                drawPath(ma5Path, color = InstitutionalCyan, style = Stroke(width = 2f))
                drawPath(ma20Path, color = InstitutionalGold, style = Stroke(width = 2f))
            }
        }
    }
}

@Composable
private fun rememberCandles(basePrice: Double): List<CandleData> {
    return androidx.compose.runtime.remember(basePrice) {
        var p = basePrice * 0.95
        (1..30).map {
            val open = p
            val change = Random.nextDouble(-0.02, 0.02) * open
            val close = open + change
            val high = maxOf(open, close) + Random.nextDouble(0.001, 0.01) * open
            val low = minOf(open, close) - Random.nextDouble(0.001, 0.01) * open
            val vol = Random.nextLong(1000, 50000)
            p = close
            CandleData(open, high, low, close, vol)
        }
    }
}
