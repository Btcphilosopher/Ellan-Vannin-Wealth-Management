package com.example.cnequity.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "market_rule_versions")
data class MarketRuleVersion(
    @PrimaryKey val rule_id: String,       // e.g. "RULE_CN_2024_V1"
    val version_name: String,               // e.g. "2024沪深京交易规则第1版"
    val effective_date: String,             // YYYY-MM-DD
    val description: String,
    val main_board_price_limit_pct: Double = 0.10,    // 10%
    val star_board_price_limit_pct: Double = 0.20,    // 20%
    val chinext_price_limit_pct: Double = 0.20,       // 20%
    val bse_price_limit_pct: Double = 0.30,          // 30%
    val st_price_limit_pct: Double = 0.05,            // 5%
    val ipo_first_day_limit: Boolean = false,         // 无涨跌幅限制
    val tick_size_a_share: Double = 0.01,
    val tick_size_b_share: Double = 0.001,
    val tick_size_etf: Double = 0.001,
    val allow_after_hours_trading: Boolean = true     // 盘后固定价格交易
)

data class TradingSession(
    val session_name: String,
    val start_time: String, // HH:mm
    val end_time: String,   // HH:mm
    val is_call_auction: Boolean
)

@Entity(tableName = "trading_calendar")
data class TradingCalendarDay(
    @PrimaryKey val date: String, // YYYY-MM-DD
    val is_trading_day: Boolean,
    val session_type: String,     // "FULL_DAY", "CLOSED"
    val holiday_name: String? = null
)

enum class CorporateActionType(val cnName: String) {
    CASH_DIVIDEND("现金分红"),
    BONUS_SHARES("送红股"),
    RIGHTS_ISSUE("配股"),
    RESERVE_TO_SHARES("转增股本")
}

@Entity(tableName = "corporate_actions")
data class CorporateAction(
    @PrimaryKey val action_id: String,
    val ticker: String,
    val announcement_date: String,
    val record_date: String,         // 股权登记日
    val ex_date: String,             // 除权除息日
    val cash_dividend_per_10: Double,// 每10股派现(元)
    val bonus_shares_per_10: Double, // 每10股送股
    val reserve_shares_per_10: Double,// 每10股转增
    val rights_issue_ratio_10: Double,// 每10股配股
    val rights_issue_price: Double   // 配股价格
)

enum class PriceAdjustMode(val cnName: String) {
    NONE("不复权"),
    FORWARD("前复权"),
    BACKWARD("后复权")
}
