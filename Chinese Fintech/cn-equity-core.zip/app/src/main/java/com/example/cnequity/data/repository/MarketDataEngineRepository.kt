package com.example.cnequity.data.repository

import com.example.cnequity.model.AuctionResult
import com.example.cnequity.model.L1Quote
import com.example.cnequity.model.L2MarketDepth
import com.example.cnequity.model.LevelDepthItem
import com.example.cnequity.model.MarketBreadth
import com.example.cnequity.model.SectorStat
import com.example.cnequity.model.TradeSide
import com.example.cnequity.model.TradeTick
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.math.round
import kotlin.random.Random

class MarketDataEngineRepository {

    private val basePrices = mapOf(
        "600519.SH" to 1668.50,
        "000858.SZ" to 138.20,
        "688981.SH" to 58.60,
        "300750.SZ" to 228.40,
        "830964.BJ" to 6.85,
        "900901.SH" to 0.685, // USD
        "200002.SZ" to 4.25,  // HKD
        "510300.SH" to 3.985,
        "508001.SH" to 9.12,
        "688009.SH" to 48.30,
        "689009.SH" to 48.30,
        "601318.SH" to 46.80,
        "002594.SZ" to 286.50
    )

    fun getL1QuoteFlow(tickerWithEx: String): Flow<L1Quote> = flow {
        var basePrice = basePrices[tickerWithEx] ?: 100.00
        val isBShare = tickerWithEx.endsWith(".SH") && tickerWithEx.startsWith("900") || tickerWithEx.startsWith("200")
        val isEtf = tickerWithEx.startsWith("510") || tickerWithEx.startsWith("159")
        val tickStep = if (isBShare || isEtf) 0.001 else 0.01

        val prevClose = roundPrice(basePrice * (1.0 + (Random.nextDouble(-0.02, 0.02))), tickStep)
        val limitUp = roundPrice(prevClose * 1.10, tickStep)
        val limitDown = roundPrice(prevClose * 0.90, tickStep)

        while (true) {
            val delta = Random.nextDouble(-0.015, 0.015) * basePrice
            val newPrice = (basePrice + delta).coerceIn(limitDown, limitUp)
            basePrice = roundPrice(newPrice, tickStep)

            val openPrice = roundPrice(prevClose * (1.0 + Random.nextDouble(-0.005, 0.005)), tickStep)
            val highPrice = maxOf(basePrice, openPrice) + Random.nextInt(0, 5) * tickStep
            val lowPrice = minOf(basePrice, openPrice) - Random.nextInt(0, 5) * tickStep
            val change = basePrice - prevClose
            val pctChange = (change / prevClose) * 100.0

            val bid1 = roundPrice(basePrice - tickStep, tickStep)
            val ask1 = roundPrice(basePrice + tickStep, tickStep)

            val name = getTickerName(tickerWithEx)

            val quote = L1Quote(
                ticker = tickerWithEx,
                name = name,
                last_price = basePrice,
                prev_close = prevClose,
                open = openPrice,
                high = highPrice,
                low = lowPrice,
                volume = Random.nextLong(10000, 850000),
                turnover = basePrice * Random.nextLong(10000, 850000),
                vwap = roundPrice(basePrice * 0.998, tickStep),
                twap = roundPrice(basePrice * 0.999, tickStep),
                bid1_price = bid1,
                bid1_vol = Random.nextLong(10, 500) * 100,
                ask1_price = ask1,
                ask1_vol = Random.nextLong(10, 500) * 100,
                change = change,
                pct_change = pctChange,
                limit_up = limitUp,
                limit_down = limitDown,
                timestamp = getCurrentTimeString()
            )

            emit(quote)
            delay(1500)
        }
    }

    fun getL2MarketDepth(tickerWithEx: String, currentLastPrice: Double): L2MarketDepth {
        val isBShare = tickerWithEx.endsWith(".SH") && tickerWithEx.startsWith("900") || tickerWithEx.startsWith("200")
        val tickStep = if (isBShare || tickerWithEx.startsWith("510")) 0.001 else 0.01

        val bids = (1..10).map { level ->
            val p = roundPrice(currentLastPrice - (level * tickStep), tickStep)
            val vol = Random.nextLong(50, 2000) * 100
            LevelDepthItem(p, vol, Random.nextInt(3, 45))
        }

        val asks = (1..10).map { level ->
            val p = roundPrice(currentLastPrice + (level * tickStep), tickStep)
            val vol = Random.nextLong(50, 2000) * 100
            LevelDepthItem(p, vol, Random.nextInt(3, 45))
        }

        val trades = (1..12).map { idx ->
            val side = when (Random.nextInt(3)) {
                0 -> TradeSide.BUY
                1 -> TradeSide.SELL
                else -> TradeSide.NEUTRAL
            }
            TradeTick(
                id = "TICK_$idx",
                time = getCurrentTimeString(),
                price = roundPrice(currentLastPrice + (Random.nextInt(-2, 3) * tickStep), tickStep),
                volume = Random.nextLong(1, 200) * 100,
                side = side
            )
        }

        return L2MarketDepth(
            ticker = tickerWithEx,
            bids = bids,
            asks = asks,
            recentTrades = trades
        )
    }

    fun calculateCallAuction(tickerWithEx: String, lastPrice: Double): AuctionResult {
        val indicativePrice = roundPrice(lastPrice * (1.0 + Random.nextDouble(-0.003, 0.003)), 0.01)
        val matchedVol = Random.nextLong(15000, 80000) * 100
        val unmatchedVol = Random.nextLong(200, 5000) * 100
        val side = if (Random.nextBoolean()) "BUY_SURPLUS" else "SELL_SURPLUS"

        return AuctionResult(
            ticker = tickerWithEx,
            indicative_price = indicativePrice,
            matched_volume = matchedVol,
            unmatched_volume = unmatchedVol,
            imbalance_side = side
        )
    }

    fun getMarketBreadth(): MarketBreadth {
        return MarketBreadth(
            total_stocks = 5382,
            up_count = 3420,
            down_count = 1680,
            flat_count = 282,
            limit_up_count = 68,
            limit_down_count = 7,
            total_turnover = 9825.4, // 亿元
            northbound_net_inflow = 42.85, // 亿元
            southbound_net_inflow = 18.20,
            up_volume_ratio = 67.4
        )
    }

    fun getSectorStats(): List<SectorStat> {
        return listOf(
            SectorStat("SW_01", "半导体芯片", "SW_L2", 3.85, 842.1, 28.5, "688981.SH", "中芯国际", 4.20),
            SectorStat("SW_02", "白酒与烈酒", "SW_L2", 1.92, 420.5, 12.3, "600519.SH", "贵州茅台", 2.15),
            SectorStat("SW_03", "锂电池新能源", "SW_L2", 2.45, 680.3, 19.8, "300750.SZ", "宁德时代", 3.10),
            SectorStat("SW_04", "人工智能算力", "SW_L1", 4.12, 1120.0, 45.2, "000977.SZ", "浪潮信息", 7.80),
            SectorStat("SW_05", "基础设施REITs", "SW_L1", 0.35, 12.4, 0.8, "508001.SH", "浙商沪杭甬", 0.42),
            SectorStat("SW_06", "大金融保险", "SW_L1", -0.45, 310.2, -8.4, "601318.SH", "中国平安", -0.60)
        )
    }

    private fun getTickerName(ticker: String): String {
        return when {
            ticker.contains("600519") -> "贵州茅台"
            ticker.contains("000858") -> "五粮液"
            ticker.contains("688981") -> "中芯国际"
            ticker.contains("300750") -> "宁德时代"
            ticker.contains("830964") -> "润农节水"
            ticker.contains("900901") -> "老凤祥B"
            ticker.contains("200002") -> "万科B"
            ticker.contains("510300") -> "沪深300ETF"
            ticker.contains("508001") -> "浙商REIT"
            ticker.contains("689009") -> "九号公司-WD"
            ticker.contains("601318") -> "中国平安"
            ticker.contains("002594") -> "比亚迪"
            else -> "A股标的"
        }
    }

    private fun roundPrice(valIn: Double, step: Double): Double {
        val multiplier = 1.0 / step
        return round(valIn * multiplier) / multiplier
    }

    private fun getCurrentTimeString(): String {
        val now = java.time.LocalTime.now()
        return String.format("%02d:%02d:%02d.%03d", now.hour, now.minute, now.second, now.nano / 1000000)
    }
}
