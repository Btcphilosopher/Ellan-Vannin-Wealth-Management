package com.example.cnequity.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.cnequity.model.OrderItem
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM simulated_orders ORDER BY submit_time DESC")
    fun getAllOrders(): Flow<List<OrderItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderItem)

    @Query("DELETE FROM simulated_orders")
    suspend fun clearAllOrders()
}
