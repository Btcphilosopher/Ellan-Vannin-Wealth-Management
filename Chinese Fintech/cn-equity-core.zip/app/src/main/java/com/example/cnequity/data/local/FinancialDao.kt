package com.example.cnequity.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.cnequity.model.FinancialStatement
import kotlinx.coroutines.flow.Flow

@Dao
interface FinancialDao {
    @Query("SELECT * FROM financial_statements WHERE ticker = :ticker ORDER BY period DESC")
    fun getFinancialsByTicker(ticker: String): Flow<List<FinancialStatement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFinancials(statements: List<FinancialStatement>)
}
