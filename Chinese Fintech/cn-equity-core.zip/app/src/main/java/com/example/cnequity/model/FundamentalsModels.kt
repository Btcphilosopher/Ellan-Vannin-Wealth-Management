package com.example.cnequity.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "financial_statements", primaryKeys = ["ticker", "period"])
data class FinancialStatement(
    val ticker: String,
    val period: String,              // e.g. "2024Q4", "2024A", "2025Q1"
    val report_date: String,
    val revenue: Double,             // 营业收入 (亿元)
    val revenue_yoy: Double,         // 营收同比 (%)
    val net_profit: Double,          // 归母净利润 (亿元)
    val net_profit_yoy: Double,      // 净利润同比 (%)
    val total_assets: Double,        // 总资产 (亿元)
    val total_liabilities: Double,   // 总负债 (亿元)
    val operating_cash_flow: Double, // 经营现金流 (亿元)
    val gross_margin: Double,        // 毛利率 (%)
    val net_margin: Double,          // 净利率 (%)
    val roe: Double,                 // ROE (%)
    val eps: Double                  // EPS (元)
)

data class EarningsForecast(
    val ticker: String,
    val year: String,                // "2025E", "2026E"
    val consensus_eps: Double,
    val consensus_revenue: Double,   // 亿元
    val consensus_net_profit: Double,// 亿元
    val target_price: Double,
    val buy_ratings: Int,
    val hold_ratings: Int,
    val sell_ratings: Int
)

data class ValuationBand(
    val ticker: String,
    val pe_ttm: Double,
    val pb: Double,
    val ps: Double,
    val ev_ebitda: Double,
    val dividend_yield: Double,      // 股息率 (%)
    val pe_hist_min: Double,
    val pe_hist_avg: Double,
    val pe_hist_max: Double,
    val pe_sd_minus_2: Double,
    val pe_sd_plus_2: Double
)

data class ShareholderHolder(
    val rank: Int,
    val name: String,
    val category: String,            // "国资委", "社保基金", "公募基金", "QFII", "陆股通", "自然人"
    val holdings_shares: Long,       // 持股数 (股)
    val holding_pct: Double,         // 占总股本 (%)
    val change_shares: Long          // 增减持数量 (股, 0为不变)
)

data class NorthboundSouthboundFlow(
    val date: String,
    val northbound_buy: Double,      // 陆股通买入 (亿元)
    val northbound_sell: Double,     // 陆股通卖出 (亿元)
    val northbound_net: Double,      // 净买入 (亿元)
    val southbound_net: Double,      // 港股通净买入 (亿元)
    val top_holdings_cn: List<Pair<String, Double>> // Ticker to holding pct
)
