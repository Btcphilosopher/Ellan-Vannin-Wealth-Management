package com.example.cnequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cnequity.model.Exchange
import com.example.cnequity.model.MarketBoard
import com.example.cnequity.model.SecurityEntity
import com.example.cnequity.model.SecurityType
import com.example.cnequity.ui.TerminalViewModel
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.InstitutionalGold
import com.example.cnequity.ui.theme.StockUpRed
import com.example.cnequity.ui.theme.TerminalBorder
import com.example.cnequity.ui.theme.TerminalSurface
import com.example.cnequity.ui.theme.TextSecondary

@Composable
fun SecurityMasterScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val securities by viewModel.securities.collectAsState()
    val selectedSecurity by viewModel.selectedSecurity.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    val filteredList = securities.filter {
        searchQuery.isEmpty() ||
                it.security_id.contains(searchQuery, ignoreCase = true) ||
                it.name.contains(searchQuery, ignoreCase = true) ||
                it.company_cn_name.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("security_master_screen")
    ) {
        // Search and Filter Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("security_search_input"),
            placeholder = { Text("搜索 Ticker / 代码 / 公司名称 (例如 600519, 科创板, 茅台)...", fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = InstitutionalCyan) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = InstitutionalCyan,
                unfocusedBorderColor = TerminalBorder,
                focusedContainerColor = TerminalSurface,
                unfocusedContainerColor = TerminalSurface
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Selected Security Banner
        selectedSecurity?.let { sec ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalCyan)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${sec.name} (${sec.security_id})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = InstitutionalCyan
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        MarketBadge(text = sec.exchange.cnName, color = InstitutionalGold)
                        Spacer(modifier = Modifier.width(4.dp))
                        MarketBadge(text = sec.market.cnName, color = StockUpRed)
                        Spacer(modifier = Modifier.width(4.dp))
                        MarketBadge(text = sec.security_type.cnName, color = InstitutionalCyan)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        InfoLabelValue("ISIN: ", sec.ISIN, modifier = Modifier.weight(1f))
                        InfoLabelValue("上市日期: ", sec.listing_date, modifier = Modifier.weight(1f))
                        InfoLabelValue("申万行业: ", "${sec.sw_industry_l1}-${sec.sw_industry_l2}", modifier = Modifier.weight(1.2f))
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        InfoLabelValue("总股本: ", "${sec.shares_outstanding / 100000000}亿股", modifier = Modifier.weight(1f))
                        InfoLabelValue("自由流通股: ", "${sec.free_float / 100000000}亿股", modifier = Modifier.weight(1f))
                        InfoLabelValue("交易状态: ", sec.status.cnName, modifier = Modifier.weight(1.2f))
                    }
                }
            }
        }

        // Master Securities Table
        Text(
            text = "Security Master 标的主表 (${filteredList.size} 项)",
            style = MaterialTheme.typography.titleSmall,
            color = TextSecondary,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("security_master_list")
        ) {
            items(filteredList) { item ->
                val isSelected = selectedSecurity?.security_id == item.security_id
                SecurityMasterRowItem(
                    security = item,
                    isSelected = isSelected,
                    onClick = { viewModel.selectSecurity(item) }
                )
            }
        }
    }
}

@Composable
private fun SecurityMasterRowItem(
    security: SecurityEntity,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) InstitutionalCyan else TerminalBorder
    val bgColor = if (isSelected) Color(0xFF1E293B) else TerminalSurface

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .background(bgColor, RoundedCornerShape(6.dp))
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(10.dp)
            .testTag("security_row_${security.ticker}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Text(
                    text = security.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = security.security_id,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = InstitutionalCyan
                )
            }

            Column(modifier = Modifier.weight(1.2f)) {
                Text(
                    text = "${security.exchange.code} / ${security.market.cnName}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = security.security_type.cnName,
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }

            Column(modifier = Modifier.weight(1.4f)) {
                Text(
                    text = security.sw_industry_l1,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "ISIN: ${security.ISIN}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary
                )
            }

            MarketBadge(
                text = security.status.cnName,
                color = if (security.status.name == "ACTIVE") InstitutionalCyan else StockUpRed
            )
        }
    }
}

@Composable
fun MarketBadge(text: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(3.dp))
            .border(0.5.dp, color, RoundedCornerShape(3.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text = text, fontSize = 9.sp, color = color, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun InfoLabelValue(label: String, value: String, modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 10.sp, color = TextSecondary)
        Text(value, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
    }
}
