package com.example.cnequity.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cnequity.model.EventStudyResult
import com.example.cnequity.model.FactorScore
import com.example.cnequity.model.PortfolioPositionEntity
import com.example.cnequity.ui.TerminalViewModel
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.InstitutionalGold
import com.example.cnequity.ui.theme.StockDownGreen
import com.example.cnequity.ui.theme.StockUpRed
import com.example.cnequity.ui.theme.TerminalBorder
import com.example.cnequity.ui.theme.TerminalSurface
import com.example.cnequity.ui.theme.TextSecondary

@Composable
fun QuantRiskScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val factorScores by viewModel.factorScores.collectAsState()
    val eventStudy by viewModel.eventStudyResult.collectAsState()
    val positions by viewModel.portfolioPositions.collectAsState()
    val summary by viewModel.portfolioSummary.collectAsState()
    val risk by viewModel.riskMetrics.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp)
            .testTag("quant_risk_screen")
    ) {
        // Portfolio Risk & VaR Header
        risk?.let { r ->
            summary?.let { s ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalCyan)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("机构组合与风险计算引擎 (Portfolio & VaR Analytics)", style = MaterialTheme.typography.titleMedium, color = InstitutionalCyan)
                            Spacer(modifier = Modifier.weight(1f))
                            Text("总资产: ${String.format("%.2f", s.total_equity / 10000)}万元", fontWeight = FontWeight.Bold, color = StockUpRed, fontSize = 13.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            QuantMetricCell("95% 1日 VaR", "${String.format("%.0f", r.var_95_daily)} 元", Modifier.weight(1f), StockDownGreen)
                            QuantMetricCell("99% 1日 VaR", "${String.format("%.0f", r.var_99_daily)} 元", Modifier.weight(1f), StockDownGreen)
                            QuantMetricCell("夏普比率 Sharpe", "${r.annualized_sharpe}", Modifier.weight(1f), InstitutionalGold)
                            QuantMetricCell("沪深300 Beta", "${r.beta_to_csi300}", Modifier.weight(1f), InstitutionalCyan)
                            QuantMetricCell("最大回撤 MaxDD", "${r.max_drawdown_pct}%", Modifier.weight(1f), StockDownGreen)
                        }
                    }
                }
            }
        }

        // Event Study Engine & CAR Chart
        eventStudy?.let { es ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalGold)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("事件研究引擎 (Event Study CAR Engine)", style = MaterialTheme.typography.titleMedium, color = InstitutionalGold)
                        Spacer(modifier = Modifier.weight(1f))
                        Text("事件: ${es.event_name} (N=${es.total_events})", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { viewModel.runEventStudy("EARNINGS_SURPRISE") },
                            colors = ButtonDefaults.buttonColors(containerColor = InstitutionalCyan),
                            modifier = Modifier.weight(1f).height(32.dp).padding(end = 4.dp)
                        ) {
                            Text("业绩超预期", fontSize = 10.sp, color = Color.Black)
                        }
                        Button(
                            onClick = { viewModel.runEventStudy("DIVIDEND_ANNOUNCEMENT") },
                            colors = ButtonDefaults.buttonColors(containerColor = InstitutionalGold),
                            modifier = Modifier.weight(1f).height(32.dp).padding(horizontal = 2.dp)
                        ) {
                            Text("高分红除权", fontSize = 10.sp, color = Color.Black)
                        }
                        Button(
                            onClick = { viewModel.runEventStudy("INDEX_INCLUSION") },
                            colors = ButtonDefaults.buttonColors(containerColor = StockUpRed),
                            modifier = Modifier.weight(1f).height(32.dp).padding(start = 4.dp)
                        ) {
                            Text("指数纳入调仓", fontSize = 10.sp, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "窗口期 [-10, +20] 天累计超额收益率 CAR 走势",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // CAR Canvas Line Chart
                    EventStudyCarChart(es = es, modifier = Modifier.fillMaxWidth().height(140.dp))

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        QuantMetricCell("事件后20日 CAR", "+${String.format("%.2f", es.post_event_20d_car)}%", Modifier.weight(1f), StockUpRed)
                        QuantMetricCell("t-统计量", "${es.t_statistic}", Modifier.weight(1f))
                        QuantMetricCell("p-值", "${es.p_value}", Modifier.weight(1f))
                        QuantMetricCell("胜率 Win Rate", "${es.win_rate_pct}%", Modifier.weight(1f), InstitutionalGold)
                    }
                }
            }
        }

        // Multi-Factor Scores Table
        Text("多因子计算模型库 (Multi-Factor Scoring Engine)", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                factorScores.forEach { factor ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.8f)) {
                            Text(factor.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Text(factor.factor_category.cnName, fontSize = 9.sp, color = InstitutionalCyan)
                        }
                        Text("Raw: ${factor.raw_value}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("Z-Score: ${factor.z_score}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = InstitutionalGold, modifier = Modifier.weight(1f))
                        Text("百分位: ${factor.rank_percentile}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StockUpRed, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        // Current Portfolio Positions Table
        Text("持仓组合标的 (Portfolio Positions)", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        positions.forEach { pos ->
            PositionRowItem(position = pos)
        }
    }
}

@Composable
private fun QuantMetricCell(label: String, value: String, modifier: Modifier, valColor: Color = InstitutionalCyan) {
    Column(modifier = modifier) {
        Text(label, fontSize = 9.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = valColor, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun EventStudyCarChart(es: EventStudyResult, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(Color(0xFF0F172A), RoundedCornerShape(6.dp))
            .padding(8.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            val points = es.window_points
            if (points.isEmpty()) return@Canvas

            val minCar = points.minOf { it.mean_car }
            val maxCar = points.maxOf { it.mean_car }
            val carRange = maxOf(0.01, maxCar - minCar)

            val path = Path()

            points.forEachIndexed { idx, pt ->
                val x = (idx.toFloat() / (points.size - 1)) * w
                val y = h - ((pt.mean_car - minCar) / carRange * h).toFloat()

                if (idx == 0) {
                    path.moveTo(x, y)
                } else {
                    path.lineTo(x, y)
                }
            }

            drawPath(path, color = InstitutionalGold, style = Stroke(width = 3f))

            // Zero reference line
            val zeroY = h - ((0.0 - minCar) / carRange * h).toFloat()
            drawLine(
                color = Color.Gray.copy(alpha = 0.5f),
                start = Offset(0f, zeroY),
                end = Offset(w, zeroY),
                strokeWidth = 1f
            )
        }
    }
}

@Composable
private fun PositionRowItem(position: PortfolioPositionEntity) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .background(TerminalSurface, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Text(position.name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(position.ticker, fontSize = 10.sp, color = InstitutionalCyan, fontFamily = FontFamily.Monospace)
            }

            Column(modifier = Modifier.weight(1f)) {
                Text("持仓: ${position.shares}股", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Text("成本: ${position.avg_cost}元", fontSize = 10.sp, color = TextSecondary)
            }

            Text("市值: ${String.format("%.1f", (position.shares * position.avg_cost) / 10000)}万元", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = StockUpRed)
        }
    }
}
