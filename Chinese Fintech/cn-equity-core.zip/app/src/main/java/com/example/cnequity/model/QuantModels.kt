package com.example.cnequity.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class FactorScore(
    val ticker: String,
    val name: String,
    val factor_category: FactorCategory,
    val raw_value: Double,
    val z_score: Double,
    val rank_percentile: Double
)

enum class FactorCategory(val cnName: String) {
    VALUE("估值因子 (Value)"),
    GROWTH("成长因子 (Growth)"),
    MOMENTUM("动量因子 (Momentum)"),
    QUALITY("质量因子 (Quality)"),
    VOLATILITY("波动率因子 (Volatility)"),
    LIQUIDITY("流动性因子 (Liquidity)")
}

data class EventStudyWindowPoint(
    val event_day: Int, // e.g. -10 to +20
    val mean_ar: Double, // Abnormal Return
    val mean_car: Double // Cumulative Abnormal Return
)

data class EventStudyResult(
    val event_name: String,
    val total_events: Int,
    val window_points: List<EventStudyWindowPoint>,
    val post_event_20d_car: Double,
    val t_statistic: Double,
    val p_value: Double,
    val win_rate_pct: Double
)

@Entity(tableName = "portfolio_positions")
data class PortfolioPositionEntity(
    @PrimaryKey val ticker: String,
    val name: String,
    val shares: Long,
    val avg_cost: Double
)

data class PortfolioSummary(
    val total_market_value: Double,
    val cash_balance: Double,
    val total_equity: Double,
    val daily_pnl: Double,
    val daily_pnl_pct: Double,
    val total_pnl: Double,
    val total_pnl_pct: Double
)

data class RiskMetrics(
    val total_equity: Double,
    val var_95_daily: Double,       // 95% 1日 VaR (元)
    val var_99_daily: Double,       // 99% 1日 VaR (元)
    val annualized_sharpe: Double,  // 夏普比率
    val beta_to_csi300: Double,     // 沪深300 Beta
    val max_drawdown_pct: Double,   // 最大回撤 (%)
    val tracking_error_pct: Double, // 跟踪误差 (%)
    val sector_allocations: Map<String, Double> // 行业暴露占比
)
