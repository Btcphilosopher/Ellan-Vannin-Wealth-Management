package com.example.cnequity.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cnequity.model.L2MarketDepth
import com.example.cnequity.model.LevelDepthItem
import com.example.cnequity.model.TradeSide
import com.example.cnequity.model.TradeTick
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.StockDownGreen
import com.example.cnequity.ui.theme.StockFlatGray
import com.example.cnequity.ui.theme.StockUpRed
import com.example.cnequity.ui.theme.TerminalBorder
import com.example.cnequity.ui.theme.TerminalSurface
import com.example.cnequity.ui.theme.TextSecondary

@Composable
fun OrderBookDepthView(
    l2Depth: L2MarketDepth,
    lastPrice: Double,
    modifier: Modifier = Modifier
) {
    val maxAskVol = l2Depth.asks.maxOfOrNull { it.volume } ?: 1L
    val maxBidVol = l2Depth.bids.maxOfOrNull { it.volume } ?: 1L
    val maxVol = maxOf(maxAskVol, maxBidVol).toFloat()

    Column(
        modifier = modifier
            .background(TerminalSurface, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("l2_orderbook_depth_container")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Level-2 十档盘口与逐笔明细",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "L2 10-Depth Stream",
                fontSize = 10.sp,
                color = InstitutionalCyan
            )
        }

        Spacer(modifier = Modifier.height(6.dp))
        HorizontalDivider(color = TerminalBorder)
        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            // Left Column: 10 Asks (Top, reversed 10->1) & 10 Bids (1->10)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 6.dp)
            ) {
                Text(
                    text = "卖十档 (Asks 10-1)",
                    fontSize = 10.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )

                l2Depth.asks.reversed().forEachIndexed { index, ask ->
                    val levelNum = 10 - index
                    DepthRowItem(
                        label = "卖$levelNum",
                        item = ask,
                        color = StockDownGreen,
                        maxVol = maxVol
                    )
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 4.dp),
                    color = InstitutionalCyan.copy(alpha = 0.5f)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("最新价: ", fontSize = 11.sp, color = TextSecondary)
                    Text(
                        text = String.format("%.2f", lastPrice),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = StockUpRed
                    )
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 4.dp),
                    color = InstitutionalCyan.copy(alpha = 0.5f)
                )

                Text(
                    text = "买十档 (Bids 1-10)",
                    fontSize = 10.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )

                l2Depth.bids.forEachIndexed { index, bid ->
                    val levelNum = index + 1
                    DepthRowItem(
                        label = "买$levelNum",
                        item = bid,
                        color = StockUpRed,
                        maxVol = maxVol
                    )
                }
            }

            // Right Column: Recent Trade Ticks
            Column(
                modifier = Modifier
                    .weight(0.9f)
                    .padding(start = 6.dp)
            ) {
                Text(
                    text = "逐笔成交 (Tape Ticks)",
                    fontSize = 10.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("时间", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1.2f))
                    Text("价格", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                    Text("成交", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1f))
                }

                l2Depth.recentTrades.take(14).forEach { tick ->
                    TradeTickRow(tick = tick)
                }
            }
        }
    }
}

@Composable
private fun DepthRowItem(
    label: String,
    item: LevelDepthItem,
    color: Color,
    maxVol: Float
) {
    val barFraction = (item.volume / maxVol).coerceIn(0.05f, 1f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(18.dp)
            .padding(vertical = 1.dp)
    ) {
        // Background Volume depth bar
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(barFraction)
                .align(Alignment.CenterStart)
                .background(color.copy(alpha = 0.18f), RoundedCornerShape(2.dp))
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontSize = 10.sp,
                color = TextSecondary,
                modifier = Modifier.width(28.dp)
            )
            Text(
                text = String.format("%.2f", item.price),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = color,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "${item.volume / 100}手",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.End
            )
        }
    }
}

@Composable
private fun TradeTickRow(tick: TradeTick) {
    val color = when (tick.side) {
        TradeSide.BUY -> StockUpRed
        TradeSide.SELL -> StockDownGreen
        TradeSide.NEUTRAL -> StockFlatGray
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = tick.time.take(8),
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            color = TextSecondary,
            modifier = Modifier.weight(1.2f)
        )
        Text(
            text = String.format("%.2f", tick.price),
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = color,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = "${tick.volume / 100}",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = color,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f)
        )
    }
}
