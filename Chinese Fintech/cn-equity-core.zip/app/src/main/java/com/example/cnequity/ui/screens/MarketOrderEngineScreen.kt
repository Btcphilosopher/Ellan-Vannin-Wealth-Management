package com.example.cnequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cnequity.model.OrderItem
import com.example.cnequity.model.OrderSide
import com.example.cnequity.model.OrderStatus
import com.example.cnequity.model.OrderType
import com.example.cnequity.ui.TerminalViewModel
import com.example.cnequity.ui.components.CandlestickChart
import com.example.cnequity.ui.components.OrderBookDepthView
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.InstitutionalGold
import com.example.cnequity.ui.theme.StockDownGreen
import com.example.cnequity.ui.theme.StockUpRed
import com.example.cnequity.ui.theme.TerminalBorder
import com.example.cnequity.ui.theme.TerminalSurface
import com.example.cnequity.ui.theme.TextSecondary

@Composable
fun MarketOrderEngineScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val sec by viewModel.selectedSecurity.collectAsState()
    val quote by viewModel.currentL1Quote.collectAsState()
    val l2Depth by viewModel.currentL2Depth.collectAsState()
    val auction by viewModel.auctionResult.collectAsState()
    val orders by viewModel.ordersList.collectAsState()
    val activeRule by viewModel.activeRuleVersion.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp)
            .testTag("market_order_engine_screen")
    ) {
        // Ticker L1 Header Strip
        quote?.let { q ->
            val isUp = q.pct_change >= 0
            val color = if (isUp) StockUpRed else StockDownGreen

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, color)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${q.name} (${q.ticker})",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = String.format("%.2f", q.last_price),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = color
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = String.format("%+.2f (%+.2f%%)", q.change, q.pct_change),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = color
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        L1InfoCell("今开", String.format("%.2f", q.open), Modifier.weight(1f))
                        L1InfoCell("最高", String.format("%.2f", q.high), Modifier.weight(1f))
                        L1InfoCell("最低", String.format("%.2f", q.low), Modifier.weight(1f))
                        L1InfoCell("涨停价", String.format("%.2f", q.limit_up), Modifier.weight(1f), StockUpRed)
                        L1InfoCell("跌停价", String.format("%.2f", q.limit_down), Modifier.weight(1f), StockDownGreen)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        L1InfoCell("成交量", "${q.volume / 100}手", Modifier.weight(1f))
                        L1InfoCell("成交额", "${String.format("%.2f", q.turnover / 100000000)}亿元", Modifier.weight(1f))
                        L1InfoCell("VWAP均价", String.format("%.2f", q.vwap), Modifier.weight(1f))
                        L1InfoCell("昨收", String.format("%.2f", q.prev_close), Modifier.weight(1f))
                        L1InfoCell("更新时间", q.timestamp, Modifier.weight(1f))
                    }
                }
            }
        }

        // Call Auction Engine Banner
        auction?.let { auc ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)),
                border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalGold)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("集合竞价撮合引擎 (Call Auction Simulator)", fontSize = 11.sp, color = InstitutionalGold, fontWeight = FontWeight.Bold)
                        Text(
                            text = "虚拟匹配价: ${auc.indicative_price} | 匹配量: ${auc.matched_volume / 100}手 | 未匹配量: ${auc.unmatched_volume / 100}手 (${auc.imbalance_side})",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Candlestick Chart & L2 Order Book Depth
        quote?.let { q ->
            CandlestickChart(
                ticker = q.ticker,
                currentPrice = q.last_price,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            )
        }

        l2Depth?.let { depth ->
            OrderBookDepthView(
                l2Depth = depth,
                lastPrice = quote?.last_price ?: 100.0,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            )
        }

        // Order Desk (交易限价单与规则校验申报)
        sec?.let { s ->
            quote?.let { q ->
                OrderSubmissionDesk(
                    security = s,
                    currentPrice = q.last_price,
                    activeRuleName = activeRule.version_name,
                    onSubmitOrder = { side, price, volume, type ->
                        viewModel.submitOrder(side, price, volume, type)
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Orders Table
        Text("订单历史与校验结果 (Simulated Order Book Log)", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        orders.take(8).forEach { ord ->
            OrderItemRow(order = ord)
        }
    }
}

@Composable
private fun L1InfoCell(label: String, value: String, modifier: Modifier, valColor: Color = MaterialTheme.colorScheme.onSurface) {
    Column(modifier = modifier) {
        Text(label, fontSize = 9.sp, color = TextSecondary)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = valColor, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun OrderSubmissionDesk(
    security: com.example.cnequity.model.SecurityEntity,
    currentPrice: Double,
    activeRuleName: String,
    onSubmitOrder: (OrderSide, Double, Long, OrderType) -> Unit
) {
    var priceText by remember(currentPrice) { mutableStateOf(String.format("%.2f", currentPrice)) }
    var volumeText by remember { mutableStateOf("100") }
    var selectedSide by remember { mutableStateOf(OrderSide.BUY) }
    var selectedType by remember { mutableStateOf(OrderType.LIMIT) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("order_submission_desk"),
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalCyan)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("机构规则交易申报 (Order Submission Desk)", style = MaterialTheme.typography.titleSmall, color = InstitutionalCyan)
                Spacer(modifier = Modifier.weight(1f))
                Text("规则版本: $activeRuleName", fontSize = 10.sp, color = InstitutionalGold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Side Selection
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { selectedSide = OrderSide.BUY },
                    colors = ButtonDefaults.buttonColors(containerColor = if (selectedSide == OrderSide.BUY) StockUpRed else Color.DarkGray),
                    modifier = Modifier.weight(1f).testTag("order_buy_button")
                ) {
                    Text("买入 (BUY)", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = { selectedSide = OrderSide.SELL },
                    colors = ButtonDefaults.buttonColors(containerColor = if (selectedSide == OrderSide.SELL) StockDownGreen else Color.DarkGray),
                    modifier = Modifier.weight(1f).testTag("order_sell_button")
                ) {
                    Text("卖出 (SELL)", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Inputs
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("申报价格 (元)") },
                    modifier = Modifier.weight(1f).testTag("order_price_input"),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = InstitutionalCyan,
                        unfocusedBorderColor = TerminalBorder
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedTextField(
                    value = volumeText,
                    onValueChange = { volumeText = it },
                    label = { Text("申报数量 (股)") },
                    modifier = Modifier.weight(1f).testTag("order_volume_input"),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = InstitutionalCyan,
                        unfocusedBorderColor = TerminalBorder
                    ),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val p = priceText.toDoubleOrNull() ?: currentPrice
                    val v = volumeText.toLongOrNull() ?: 100L
                    onSubmitOrder(selectedSide, p, v, selectedType)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("submit_order_button"),
                colors = ButtonDefaults.buttonColors(containerColor = InstitutionalCyan)
            ) {
                Text("校验并提交订单 (Submit Order to Engine)", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun OrderItemRow(order: OrderItem) {
    val statusColor = when (order.status) {
        OrderStatus.FILLED -> StockUpRed
        OrderStatus.REJECTED -> StockDownGreen
        else -> InstitutionalGold
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .background(TerminalSurface, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${order.side.cnName} ${order.ticker}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = if (order.side == OrderSide.BUY) StockUpRed else StockDownGreen
                )
                Text(order.submit_time, fontSize = 9.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
            }

            Column(modifier = Modifier.weight(1.2f)) {
                Text("${order.price}元 × ${order.volume}股", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                order.reject_reason?.let { reason ->
                    Text("拒绝原因: $reason", fontSize = 9.sp, color = StockDownGreen)
                }
            }

            MarketBadge(text = order.status.cnName, color = statusColor)
        }
    }
}
