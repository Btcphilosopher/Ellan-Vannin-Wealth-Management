package com.example.cnequity.data.repository

import com.example.cnequity.data.local.RuleDao
import com.example.cnequity.model.CorporateAction
import com.example.cnequity.model.MarketBoard
import com.example.cnequity.model.MarketRuleVersion
import com.example.cnequity.model.OrderItem
import com.example.cnequity.model.OrderSide
import com.example.cnequity.model.OrderStatus
import com.example.cnequity.model.OrderType
import com.example.cnequity.model.SecurityEntity
import com.example.cnequity.model.SecurityStatus
import com.example.cnequity.model.SecurityType
import kotlinx.coroutines.flow.Flow
import java.time.LocalTime
import kotlin.math.round

class RuleEngineRepository(private val ruleDao: RuleDao) {

    fun getRuleVersions(): Flow<List<MarketRuleVersion>> = ruleDao.getAllRuleVersions()

    suspend fun saveRuleVersion(ruleVersion: MarketRuleVersion) {
        ruleDao.insertRuleVersion(ruleVersion)
    }

    /**
     * Calculates price limits based on Market Board, ST status, and active Rule Version.
     */
    fun calculatePriceLimitBands(
        security: SecurityEntity,
        prevClose: Double,
        activeRule: MarketRuleVersion
    ): Pair<Double, Double> {
        val pct = when {
            security.name.contains("ST") -> activeRule.st_price_limit_pct
            security.market == MarketBoard.STAR -> activeRule.star_board_price_limit_pct
            security.market == MarketBoard.CHINEXT -> activeRule.chinext_price_limit_pct
            security.market == MarketBoard.BSE_BOARD -> activeRule.bse_price_limit_pct
            else -> activeRule.main_board_price_limit_pct
        }

        val step = if (security.security_type == SecurityType.B_SHARE || security.security_type == SecurityType.ETF) 0.001 else 0.01

        val upperLimit = round(prevClose * (1.0 + pct) * (1.0 / step)) * step
        val lowerLimit = round(prevClose * (1.0 - pct) * (1.0 / step)) * step

        return Pair(lowerLimit, upperLimit)
    }

    /**
     * Validates an order against trading rules and active RuleVersion.
     */
    fun validateAndSubmitOrder(
        security: SecurityEntity,
        orderType: OrderType,
        side: OrderSide,
        price: Double,
        volume: Long,
        prevClose: Double,
        activeRule: MarketRuleVersion
    ): OrderItem {
        val (limitDown, limitUp) = calculatePriceLimitBands(security, prevClose, activeRule)

        // Rule 1: Check suspension status
        if (security.status == SecurityStatus.SUSPENDED) {
            return createOrderResult(security, side, price, volume, orderType, OrderStatus.REJECTED, activeRule.rule_id, "股票已停牌，拒绝申报")
        }

        // Rule 2: Check minimum lot size (A-share: 100 shares multiple)
        if (security.security_type == SecurityType.A_SHARE && volume % 100 != 0L) {
            return createOrderResult(security, side, price, volume, orderType, OrderStatus.REJECTED, activeRule.rule_id, "A股买卖数量必须为100股的整数倍 (手)")
        }

        // Rule 3: Check Price Band Limits
        if (price > limitUp || price < limitDown) {
            return createOrderResult(
                security, side, price, volume, orderType, OrderStatus.REJECTED, activeRule.rule_id,
                "申报价格超出涨跌幅限制区间 [$limitDown, $limitUp]"
            )
        }

        // Rule 4: Check Tick Size
        val expectedTick = if (security.security_type == SecurityType.B_SHARE || security.security_type == SecurityType.ETF) activeRule.tick_size_b_share else activeRule.tick_size_a_share
        val rem = round((price / expectedTick - round(price / expectedTick)) * 1000) / 1000
        if (Math.abs(rem) > 0.0001) {
            return createOrderResult(security, side, price, volume, orderType, OrderStatus.REJECTED, activeRule.rule_id, "报价不符合最小变动单位 $expectedTick")
        }

        // Passed validation: Order Accepted & Filled/Pending
        return createOrderResult(security, side, price, volume, orderType, OrderStatus.FILLED, activeRule.rule_id, null)
    }

    /**
     * Calculates Ex-Rights / Ex-Dividend Adjusted Price (除权除息价格计算).
     * Formula: Adjusted Price = (PrevClose - CashDivPerShare + RightsIssuePrice * RightsRatio) / (1 + BonusRatio + ReserveRatio + RightsRatio)
     */
    fun calculateExRightsPrice(
        prevClose: Double,
        corporateAction: CorporateAction
    ): Double {
        val divPerShare = corporateAction.cash_dividend_per_10 / 10.0
        val bonusRatio = corporateAction.bonus_shares_per_10 / 10.0
        val reserveRatio = corporateAction.reserve_shares_per_10 / 10.0
        val rightsRatio = corporateAction.rights_issue_ratio_10 / 10.0
        val rightsPrice = corporateAction.rights_issue_price

        val numerator = prevClose - divPerShare + (rightsPrice * rightsRatio)
        val denominator = 1.0 + bonusRatio + reserveRatio + rightsRatio

        if (denominator <= 0) return prevClose
        return round((numerator / denominator) * 100.0) / 100.0
    }

    private fun createOrderResult(
        security: SecurityEntity,
        side: OrderSide,
        price: Double,
        volume: Long,
        type: OrderType,
        status: OrderStatus,
        ruleVersionId: String,
        reason: String?
    ): OrderItem {
        val now = LocalTime.now()
        val timeStr = String.format("%02d:%02d:%02d", now.hour, now.minute, now.second)
        return OrderItem(
            order_id = "ORD_" + System.currentTimeMillis().toString().takeLast(8),
            ticker = security.security_id,
            side = side,
            price = price,
            volume = volume,
            filled_volume = if (status == OrderStatus.FILLED) volume else 0,
            type = type,
            status = status,
            rule_version_id = ruleVersionId,
            submit_time = timeStr,
            reject_reason = reason
        )
    }
}
