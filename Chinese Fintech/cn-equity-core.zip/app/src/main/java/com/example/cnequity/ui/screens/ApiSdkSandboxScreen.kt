package com.example.cnequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cnequity.data.repository.ApiEndpointInfo
import com.example.cnequity.ui.TerminalViewModel
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.InstitutionalGold
import com.example.cnequity.ui.theme.StockDownGreen
import com.example.cnequity.ui.theme.StockUpRed
import com.example.cnequity.ui.theme.TerminalBorder
import com.example.cnequity.ui.theme.TerminalSurface
import com.example.cnequity.ui.theme.TextSecondary

enum class SdkLanguage(val langName: String) {
    PYTHON("Python SDK (cn_equity_core)"),
    R("R SDK (cnequitycore)"),
    RUST("Rust SDK (cn_equity_core)")
}

@Composable
fun ApiSdkSandboxScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val apiRepo = viewModel.apiSdkRepo
    val endpoints = remember { apiRepo.getApiEndpoints() }
    var selectedEndpoint by remember { mutableStateOf(endpoints.first()) }
    var selectedLang by remember { mutableStateOf(SdkLanguage.PYTHON) }
    var executionConsoleLog by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp)
            .testTag("api_sdk_sandbox_screen")
    ) {
        // Top Header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalCyan)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("API & 机构级 Multi-Language SDK 交互平台", style = MaterialTheme.typography.titleMedium, color = InstitutionalCyan)
                Text("REST API + WebSocket 实时流 + Python / R / Rust Client SDK 生成与演练", fontSize = 11.sp, color = TextSecondary)
            }
        }

        // Endpoint Selector
        Text("选择 REST API 端点 (REST Endpoints)", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        endpoints.forEach { ep ->
            val isSelected = ep.path == selectedEndpoint.path
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .background(if (isSelected) Color(0xFF1E293B) else TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, if (isSelected) InstitutionalCyan else TerminalBorder, RoundedCornerShape(6.dp))
                    .clickable { selectedEndpoint = ep }
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MarketBadge(ep.method, if (ep.method == "GET") InstitutionalCyan else StockUpRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(ep.path, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text(ep.summary, fontSize = 10.sp, color = TextSecondary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // SDK Language Selector
        Text("选择 SDK 语言生成代码 (Language Snippet Generator)", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            SdkLanguage.values().forEach { lang ->
                val isSelected = selectedLang == lang
                Button(
                    onClick = { selectedLang = lang },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) InstitutionalCyan else Color.DarkGray
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 2.dp)
                        .height(34.dp)
                ) {
                    Text(lang.langName.take(10), fontSize = 10.sp, color = if (isSelected) Color.Black else Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Generated Code View
        val codeSnippet = when (selectedLang) {
            SdkLanguage.PYTHON -> apiRepo.generatePythonSdkCode(selectedEndpoint)
            SdkLanguage.R -> apiRepo.generateRSdkCode(selectedEndpoint)
            SdkLanguage.RUST -> apiRepo.generateRustSdkCode(selectedEndpoint)
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalGold)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("自动生成 SDK 示例代码 (${selectedLang.langName})", fontSize = 11.sp, color = InstitutionalGold, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = {
                            executionConsoleLog = "Executing ${selectedLang.langName} code...\nConnecting to https://api.cn-equity.core...\nStatus 200 OK\n\nResult:\n" + selectedEndpoint.sampleResponseJson
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = InstitutionalCyan),
                        modifier = Modifier.height(28.dp).testTag("run_sdk_code_button")
                    ) {
                        Text("测试运行 (Run Code)", fontSize = 9.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF020617), RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = codeSnippet,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF38BDF8)
                    )
                }
            }
        }

        // Console Output Log
        if (executionConsoleLog.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF020617)),
                border = androidx.compose.foundation.BorderStroke(1.dp, StockDownGreen)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("终端控制台输出 (Terminal Output Console)", fontSize = 10.sp, color = StockDownGreen, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = executionConsoleLog,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}
