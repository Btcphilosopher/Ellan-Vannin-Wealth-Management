package com.example.cnequity.data.repository

import com.example.cnequity.data.local.FinancialDao
import com.example.cnequity.model.EarningsForecast
import com.example.cnequity.model.FinancialStatement
import com.example.cnequity.model.NorthboundSouthboundFlow
import com.example.cnequity.model.ShareholderHolder
import com.example.cnequity.model.ValuationBand
import kotlinx.coroutines.flow.Flow

class FundamentalsRepository(private val financialDao: FinancialDao) {

    fun getFinancials(ticker: String): Flow<List<FinancialStatement>> {
        return financialDao.getFinancialsByTicker(ticker)
    }

    suspend fun saveFinancials(list: List<FinancialStatement>) {
        financialDao.insertFinancials(list)
    }

    fun getEarningsForecast(ticker: String): EarningsForecast {
        val baseEps = when {
            ticker.contains("600519") -> 68.50
            ticker.contains("300750") -> 12.80
            ticker.contains("688981") -> 1.45
            else -> 2.50
        }
        return EarningsForecast(
            ticker = ticker,
            year = "2025E",
            consensus_eps = baseEps,
            consensus_revenue = baseEps * 18.5,
            consensus_net_profit = baseEps * 12.0,
            target_price = baseEps * 25.0,
            buy_ratings = 32,
            hold_ratings = 3,
            sell_ratings = 0
        )
    }

    fun getValuationBand(ticker: String, currentPrice: Double): ValuationBand {
        val pe = when {
            ticker.contains("600519") -> 24.5
            ticker.contains("300750") -> 18.2
            ticker.contains("688981") -> 40.5
            else -> 15.0
        }
        return ValuationBand(
            ticker = ticker,
            pe_ttm = pe,
            pb = pe * 0.25,
            ps = pe * 0.45,
            ev_ebitda = pe * 0.75,
            dividend_yield = 2.85,
            pe_hist_min = pe * 0.7,
            pe_hist_avg = pe,
            pe_hist_max = pe * 1.3,
            pe_sd_minus_2 = pe * 0.6,
            pe_sd_plus_2 = pe * 1.4
        )
    }

    fun getTopShareholders(ticker: String): List<ShareholderHolder> {
        return listOf(
            ShareholderHolder(1, "中国贵州茅台酒厂(集团)有限责任公司", "国资委/控股股东", 678291455L, 54.00, 0L),
            ShareholderHolder(2, "香港中央结算有限公司 (陆股通)", "北向外资", 88421000L, 7.04, 1250000L),
            ShareholderHolder(3, "中央汇金资产管理有限责任公司", "国家队/汇金", 10787300L, 0.86, 0L),
            ShareholderHolder(4, "中国证券金融股份有限公司", "国家队/证金", 8092000L, 0.64, 0L),
            ShareholderHolder(5, "全国社保基金一零一组合", "社保基金", 5210000L, 0.41, 300000L)
        )
    }

    fun getStockConnectFlow(): NorthboundSouthboundFlow {
        return NorthboundSouthboundFlow(
            date = "2026-10-07",
            northbound_buy = 328.4,
            northbound_sell = 285.6,
            northbound_net = 42.8,
            southbound_net = 18.2,
            top_holdings_cn = listOf(
                "600519.SH" to 7.04,
                "300750.SZ" to 8.12,
                "601318.SH" to 5.45,
                "000858.SZ" to 6.20
            )
        )
    }
}
