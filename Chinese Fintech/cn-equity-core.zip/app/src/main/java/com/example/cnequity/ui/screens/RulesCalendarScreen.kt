package com.example.cnequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cnequity.model.MarketRuleVersion
import com.example.cnequity.model.TradingCalendarDay
import com.example.cnequity.ui.TerminalViewModel
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.InstitutionalGold
import com.example.cnequity.ui.theme.StockDownGreen
import com.example.cnequity.ui.theme.StockUpRed
import com.example.cnequity.ui.theme.TerminalBorder
import com.example.cnequity.ui.theme.TerminalSurface
import com.example.cnequity.ui.theme.TextSecondary

@Composable
fun RulesCalendarScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val ruleVersions by viewModel.ruleVersions.collectAsState()
    val activeRule by viewModel.activeRuleVersion.collectAsState()
    val calendarDays by viewModel.tradingCalendar.collectAsState()
    val calculatedExPrice by viewModel.calculatedExPrice.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp)
            .testTag("rules_calendar_screen")
    ) {
        // Active Market Rule Version Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalGold)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("MarketRuleVersion 真实规则引擎配置", style = MaterialTheme.typography.titleMedium, color = InstitutionalGold, fontWeight = FontWeight.Bold)
                Text("支持历史规则回放、交易日历、价格限制、最小变动单位、竞价与公司行动", fontSize = 11.sp, color = TextSecondary)

                Spacer(modifier = Modifier.height(10.dp))

                Text("当前激活规则: ${activeRule.version_name} (${activeRule.rule_id})", fontWeight = FontWeight.Bold, color = InstitutionalCyan)
                Text("生效日期: ${activeRule.effective_date} | ${activeRule.description}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = TerminalBorder)
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    RuleValueCell("主板涨跌幅", "${activeRule.main_board_price_limit_pct * 100}%", Modifier.weight(1f))
                    RuleValueCell("科创板", "${activeRule.star_board_price_limit_pct * 100}%", Modifier.weight(1f))
                    RuleValueCell("创业板", "${activeRule.chinext_price_limit_pct * 100}%", Modifier.weight(1f))
                    RuleValueCell("北交所", "${activeRule.bse_price_limit_pct * 100}%", Modifier.weight(1f))
                    RuleValueCell("ST股票", "${activeRule.st_price_limit_pct * 100}%", Modifier.weight(1f))
                }
            }
        }

        // Rule Version Switcher
        Text("选择 MarketRuleVersion 版本 (切换与历史回放)", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        ruleVersions.forEach { rv ->
            val isActive = rv.rule_id == activeRule.rule_id
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .background(if (isActive) Color(0xFF1E293B) else TerminalSurface, RoundedCornerShape(6.dp))
                    .border(1.dp, if (isActive) InstitutionalCyan else TerminalBorder, RoundedCornerShape(6.dp))
                    .clickable { viewModel.setActiveRuleVersion(rv) }
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(rv.version_name, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("生效: ${rv.effective_date} | ${rv.description}", fontSize = 10.sp, color = TextSecondary)
                    }
                    if (isActive) {
                        MarketBadge("当前生效", InstitutionalCyan)
                    } else {
                        MarketBadge("点击切换", InstitutionalGold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Corporate Actions Ex-Rights XR/XD Calculator
        ExRightsCalculatorCard(
            calculatedExPrice = calculatedExPrice,
            onCalculate = { p, c, b, r, rr, rp ->
                viewModel.calculateExRights(p, c, b, r, rr, rp)
            }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Trading Sessions & Calendar
        Text("中国证券交易所交易时间与日历 (Sessions & Trading Calendar)", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("交易时间段规范 (Sessions)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = InstitutionalCyan)
                Spacer(modifier = Modifier.height(4.dp))

                SessionRow("开盘集合竞价 (Morning Call Auction)", "09:15 - 09:25", "09:20后不可撤单")
                SessionRow("连续竞价上午场 (Morning Continuous)", "09:30 - 11:30", "标准限价与市价申报")
                SessionRow("连续竞价下午场 (Afternoon Continuous)", "13:00 - 14:57", "标准限价与市价申报")
                SessionRow("收盘集合竞价 (Closing Call Auction)", "14:57 - 15:00", "不可撤单")
                SessionRow("盘后固定价格交易 (STAR/ChiNext After-Hours)", "15:05 - 15:30", "科创板与创业板按收盘价撮合")

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = TerminalBorder)
                Spacer(modifier = Modifier.height(8.dp))

                Text("交易日历状态 (Trading Calendar)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = InstitutionalCyan)
                Spacer(modifier = Modifier.height(4.dp))

                calendarDays.take(6).forEach { day ->
                    CalendarDayRow(day)
                }
            }
        }
    }
}

@Composable
private fun RuleValueCell(label: String, value: String, modifier: Modifier) {
    Column(modifier = modifier) {
        Text(label, fontSize = 9.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = InstitutionalCyan, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun ExRightsCalculatorCard(
    calculatedExPrice: Double?,
    onCalculate: (Double, Double, Double, Double, Double, Double) -> Unit
) {
    var prevCloseText by remember { mutableStateOf("100.00") }
    var cashDivText by remember { mutableStateOf("10.0") } // 每10股派10元
    var bonusText by remember { mutableStateOf("0.0") }
    var reserveText by remember { mutableStateOf("3.0") }  // 每10股转增3股
    var rightsRatioText by remember { mutableStateOf("0.0") }
    var rightsPriceText by remember { mutableStateOf("0.0") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ex_rights_calculator_card"),
        colors = CardDefaults.cardColors(containerColor = TerminalSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalCyan)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("除权除息算法引擎 (Ex-Rights XR/XD Price Engine)", style = MaterialTheme.typography.titleSmall, color = InstitutionalCyan)
            Text("除权参考价 = (前收盘价 - 每股股息 + 配股价×配股率) / (1 + 送股率 + 转增率 + 配股率)", fontSize = 10.sp, color = TextSecondary)

            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = prevCloseText,
                    onValueChange = { prevCloseText = it },
                    label = { Text("前收盘价") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(6.dp))
                OutlinedTextField(
                    value = cashDivText,
                    onValueChange = { cashDivText = it },
                    label = { Text("每10股派现(元)") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = bonusText,
                    onValueChange = { bonusText = it },
                    label = { Text("每10股送红股") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(6.dp))
                OutlinedTextField(
                    value = reserveText,
                    onValueChange = { reserveText = it },
                    label = { Text("每10股转增股") },
                    modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    val p = prevCloseText.toDoubleOrNull() ?: 100.0
                    val c = cashDivText.toDoubleOrNull() ?: 0.0
                    val b = bonusText.toDoubleOrNull() ?: 0.0
                    val r = reserveText.toDoubleOrNull() ?: 0.0
                    val rr = rightsRatioText.toDoubleOrNull() ?: 0.0
                    val rp = rightsPriceText.toDoubleOrNull() ?: 0.0
                    onCalculate(p, c, b, r, rr, rp)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calculate_ex_price_button"),
                colors = ButtonDefaults.buttonColors(containerColor = InstitutionalGold)
            ) {
                Text("执行除权参考价计算 (Calculate XR/XD Price)", color = Color.Black, fontWeight = FontWeight.Bold)
            }

            calculatedExPrice?.let { exPrice ->
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "除权除息首日参考价 (Ex-Rights Price): ${String.format("%.2f", exPrice)} 元",
                        fontWeight = FontWeight.Bold,
                        color = StockUpRed,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun SessionRow(title: String, time: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1.8f))
        Text(time, fontSize = 11.sp, color = InstitutionalCyan, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
        Text(desc, fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1.2f))
    }
}

@Composable
private fun CalendarDayRow(day: TradingCalendarDay) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(day.date, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
        MarketBadge(
            text = if (day.is_trading_day) "交易日" else "休市",
            color = if (day.is_trading_day) StockUpRed else StockDownGreen
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(day.holiday_name ?: "正常开市", fontSize = 10.sp, color = TextSecondary, modifier = Modifier.weight(1.5f))
    }
}
