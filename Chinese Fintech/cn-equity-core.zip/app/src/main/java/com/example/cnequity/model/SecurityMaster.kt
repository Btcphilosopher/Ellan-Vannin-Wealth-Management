package com.example.cnequity.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Exchange(val code: String, val cnName: String) {
    SSE("SSE", "上海证券交易所"),
    SZSE("SZSE", "深圳证券交易所"),
    BSE("BSE", "北京证券交易所")
}

enum class MarketBoard(val code: String, val cnName: String) {
    MAIN("MAIN", "主板"),
    STAR("STAR", "科创板"),
    CHINEXT("CHINEXT", "创业板"),
    BSE_BOARD("BSE", "北交所")
}

enum class SecurityType(val code: String, val cnName: String) {
    A_SHARE("A_SHARE", "A 股"),
    B_SHARE("B_SHARE", "B 股"),
    ETF("ETF", "ETF 基金"),
    REIT("REIT", "REITs 基础设施"),
    CDR("CDR", "存托凭证")
}

enum class SecurityStatus(val cnName: String) {
    ACTIVE("正常交易"),
    SUSPENDED("停牌"),
    DELISTED("已退市")
}

@Entity(tableName = "security_master")
data class SecurityEntity(
    @PrimaryKey val security_id: String, // e.g. "600519.SH"
    val issuer_id: String,               // e.g. "COMP001"
    val ticker: String,                  // e.g. "600519"
    val ISIN: String,                    // e.g. "CNE100000215"
    val exchange: Exchange,
    val market: MarketBoard,
    val currency: String = "CNY",
    val security_type: SecurityType,
    val listing_date: String,             // YYYY-MM-DD
    val delisting_date: String? = null,
    val shares_outstanding: Long,        // 总股本 (股)
    val free_float: Long,                // 流通股本 (股)
    val status: SecurityStatus = SecurityStatus.ACTIVE,
    val name: String,                    // Short Name e.g. "贵州茅台"
    val company_cn_name: String,         // Full Name
    val sw_industry_l1: String,          // 申万一级行业
    val sw_industry_l2: String           // 申万二级行业
)

@Entity(tableName = "company_master")
data class CompanyEntity(
    @PrimaryKey val issuer_id: String,
    val company_name: String,
    val legal_rep: String,
    val registered_capital: Double, // 亿元
    val establishment_date: String,
    val headquarters: String,
    val website: String,
    val business_summary: String
)
