package com.example.cnequity.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val TerminalBackground = Color(0xFF0B0F19)
val TerminalSurface = Color(0xFF131B2E)
val TerminalSurfaceVariant = Color(0xFF1E293B)
val TerminalBorder = Color(0xFF334155)

val InstitutionalCyan = Color(0xFF00E5FF)
val InstitutionalGold = Color(0xFFFFB703)
val InstitutionalAmber = Color(0xFFFB8500)

// Chinese Equity Market Standard: Red = UP, Green = DOWN
val StockUpRed = Color(0xFFFF4D4F)
val StockDownGreen = Color(0xFF52C41A)
val StockFlatGray = Color(0xFF8C8C8C)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

private val TerminalDarkColorScheme = darkColorScheme(
    primary = InstitutionalCyan,
    onPrimary = Color.Black,
    secondary = InstitutionalGold,
    onSecondary = Color.Black,
    tertiary = InstitutionalAmber,
    background = TerminalBackground,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = TerminalBorder
)

@Composable
fun CNEquityTerminalTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TerminalDarkColorScheme,
        content = content
    )
}
