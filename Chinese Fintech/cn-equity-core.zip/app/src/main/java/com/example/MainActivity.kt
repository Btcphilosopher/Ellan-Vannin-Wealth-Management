package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.cnequity.ui.NavigationTab
import com.example.cnequity.ui.TerminalViewModel
import com.example.cnequity.ui.components.HeaderBar
import com.example.cnequity.ui.screens.ApiSdkSandboxScreen
import com.example.cnequity.ui.screens.FundamentalsScreen
import com.example.cnequity.ui.screens.MarketOrderEngineScreen
import com.example.cnequity.ui.screens.QuantRiskScreen
import com.example.cnequity.ui.screens.RulesCalendarScreen
import com.example.cnequity.ui.screens.SecurityMasterScreen
import com.example.cnequity.ui.theme.CNEquityTerminalTheme
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.InstitutionalGold
import com.example.cnequity.ui.theme.TerminalSurface

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CNEquityTerminalTheme {
                MainTerminalApp()
            }
        }
    }
}

@Composable
fun MainTerminalApp(
    viewModel: TerminalViewModel = viewModel()
) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val activeRule by viewModel.activeRuleVersion.collectAsState()
    val breadth = viewModel.marketBreadth

    BackHandler(enabled = selectedTab != NavigationTab.SECURITY_MASTER) {
        viewModel.selectTab(NavigationTab.SECURITY_MASTER)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_scaffold"),
        topBar = {
            HeaderBar(
                activeRuleVersion = activeRule.rule_id,
                breadth = breadth
            )
        },
        bottomBar = {
            TerminalNavigationBar(
                selectedTab = selectedTab,
                onTabSelect = { viewModel.selectTab(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                NavigationTab.SECURITY_MASTER -> SecurityMasterScreen(viewModel)
                NavigationTab.MARKET_ORDER -> MarketOrderEngineScreen(viewModel)
                NavigationTab.RULES_ENGINE -> RulesCalendarScreen(viewModel)
                NavigationTab.FUNDAMENTALS -> FundamentalsScreen(viewModel)
                NavigationTab.QUANT_RISK -> QuantRiskScreen(viewModel)
                NavigationTab.API_SDK -> ApiSdkSandboxScreen(viewModel)
            }
        }
    }
}

@Composable
fun TerminalNavigationBar(
    selectedTab: NavigationTab,
    onTabSelect: (NavigationTab) -> Unit
) {
    NavigationBar(
        containerColor = TerminalSurface,
        tonalElevation = 6.dp,
        modifier = Modifier.testTag("bottom_navigation_bar")
    ) {
        NavigationTab.values().forEach { tab ->
            val isSelected = selectedTab == tab
            val icon = when (tab) {
                NavigationTab.SECURITY_MASTER -> Icons.Default.Security
                NavigationTab.MARKET_ORDER -> Icons.Default.ShowChart
                NavigationTab.RULES_ENGINE -> Icons.Default.Gavel
                NavigationTab.FUNDAMENTALS -> Icons.Default.Assessment
                NavigationTab.QUANT_RISK -> Icons.Default.Functions
                NavigationTab.API_SDK -> Icons.Default.Code
            }

            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelect(tab) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = tab.title,
                        tint = if (isSelected) InstitutionalCyan else Color.Gray
                    )
                },
                label = {
                    Text(
                        text = when (tab) {
                            NavigationTab.SECURITY_MASTER -> "Master"
                            NavigationTab.MARKET_ORDER -> "行情申报"
                            NavigationTab.RULES_ENGINE -> "规则引擎"
                            NavigationTab.FUNDAMENTALS -> "基本面"
                            NavigationTab.QUANT_RISK -> "因子风险"
                            NavigationTab.API_SDK -> "API/SDK"
                        },
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) InstitutionalCyan else Color.Gray
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = InstitutionalCyan.copy(alpha = 0.2f)
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}
