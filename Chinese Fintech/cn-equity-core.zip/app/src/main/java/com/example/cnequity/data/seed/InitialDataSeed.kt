package com.example.cnequity.data.seed

import com.example.cnequity.model.CompanyEntity
import com.example.cnequity.model.CorporateAction
import com.example.cnequity.model.Exchange
import com.example.cnequity.model.MarketBoard
import com.example.cnequity.model.MarketRuleVersion
import com.example.cnequity.model.PortfolioPositionEntity
import com.example.cnequity.model.SecurityEntity
import com.example.cnequity.model.SecurityStatus
import com.example.cnequity.model.SecurityType
import com.example.cnequity.model.TradingCalendarDay

object InitialDataSeed {

    val securities = listOf(
        SecurityEntity(
            security_id = "600519.SH",
            issuer_id = "COMP001",
            ticker = "600519",
            ISIN = "CNE0000018R8",
            exchange = Exchange.SSE,
            market = MarketBoard.MAIN,
            currency = "CNY",
            security_type = SecurityType.A_SHARE,
            listing_date = "2001-08-27",
            shares_outstanding = 1256197800L,
            free_float = 1256197800L,
            status = SecurityStatus.ACTIVE,
            name = "贵州茅台",
            company_cn_name = "贵州茅台酒股份有限公司",
            sw_industry_l1 = "食品饮料",
            sw_industry_l2 = "白酒"
        ),
        SecurityEntity(
            security_id = "000858.SZ",
            issuer_id = "COMP002",
            ticker = "000858",
            ISIN = "CNE000000X84",
            exchange = Exchange.SZSE,
            market = MarketBoard.MAIN,
            currency = "CNY",
            security_type = SecurityType.A_SHARE,
            listing_date = "1998-04-27",
            shares_outstanding = 3881608000L,
            free_float = 3881608000L,
            status = SecurityStatus.ACTIVE,
            name = "五粮液",
            company_cn_name = "宜宾五粮液股份有限公司",
            sw_industry_l1 = "食品饮料",
            sw_industry_l2 = "白酒"
        ),
        SecurityEntity(
            security_id = "688981.SH",
            issuer_id = "COMP003",
            ticker = "688981",
            ISIN = "CNE1000040G4",
            exchange = Exchange.SSE,
            market = MarketBoard.STAR,
            currency = "CNY",
            security_type = SecurityType.A_SHARE,
            listing_date = "2020-07-16",
            shares_outstanding = 7952800000L,
            free_float = 1980000000L,
            status = SecurityStatus.ACTIVE,
            name = "中芯国际",
            company_cn_name = "中芯国际集成电路制造有限公司",
            sw_industry_l1 = "电子",
            sw_industry_l2 = "半导体"
        ),
        SecurityEntity(
            security_id = "300750.SZ",
            issuer_id = "COMP004",
            ticker = "300750",
            ISIN = "CNE100003662",
            exchange = Exchange.SZSE,
            market = MarketBoard.CHINEXT,
            currency = "CNY",
            security_type = SecurityType.A_SHARE,
            listing_date = "2018-06-11",
            shares_outstanding = 4398000000L,
            free_float = 3850000000L,
            status = SecurityStatus.ACTIVE,
            name = "宁德时代",
            company_cn_name = "宁德时代新能源科技股份有限公司",
            sw_industry_l1 = "电力设备",
            sw_industry_l2 = "电池"
        ),
        SecurityEntity(
            security_id = "830964.BJ",
            issuer_id = "COMP005",
            ticker = "830964",
            ISIN = "CNE100002SY6",
            exchange = Exchange.BSE,
            market = MarketBoard.BSE_BOARD,
            currency = "CNY",
            security_type = SecurityType.A_SHARE,
            listing_date = "2021-11-15",
            shares_outstanding = 260000000L,
            free_float = 180000000L,
            status = SecurityStatus.ACTIVE,
            name = "润农节水",
            company_cn_name = "唐山润农节水灌溉股份有限公司",
            sw_industry_l1 = "机械设备",
            sw_industry_l2 = "专用设备"
        ),
        SecurityEntity(
            security_id = "900901.SH",
            issuer_id = "COMP006",
            ticker = "900901",
            ISIN = "CNE000000A23",
            exchange = Exchange.SSE,
            market = MarketBoard.MAIN,
            currency = "USD",
            security_type = SecurityType.B_SHARE,
            listing_date = "1993-05-28",
            shares_outstanding = 523110000L,
            free_float = 160000000L,
            status = SecurityStatus.ACTIVE,
            name = "老凤祥B",
            company_cn_name = "老凤祥股份有限公司",
            sw_industry_l1 = "商贸零售",
            sw_industry_l2 = "珠宝首饰"
        ),
        SecurityEntity(
            security_id = "200002.SZ",
            issuer_id = "COMP007",
            ticker = "200002",
            ISIN = "CNE000000854",
            exchange = Exchange.SZSE,
            market = MarketBoard.MAIN,
            currency = "HKD",
            security_type = SecurityType.B_SHARE,
            listing_date = "1993-05-28",
            shares_outstanding = 11930000000L,
            free_float = 1315000000L,
            status = SecurityStatus.ACTIVE,
            name = "万科B",
            company_cn_name = "万科企业股份有限公司",
            sw_industry_l1 = "房地产",
            sw_industry_l2 = "房地产开发"
        ),
        SecurityEntity(
            security_id = "510300.SH",
            issuer_id = "COMP008",
            ticker = "510300",
            ISIN = "CNE100001CS5",
            exchange = Exchange.SSE,
            market = MarketBoard.MAIN,
            currency = "CNY",
            security_type = SecurityType.ETF,
            listing_date = "2012-05-28",
            shares_outstanding = 28500000000L,
            free_float = 28500000000L,
            status = SecurityStatus.ACTIVE,
            name = "华泰柏瑞沪深300ETF",
            company_cn_name = "华泰柏瑞沪深300交易型开放式指数证券投资基金",
            sw_industry_l1 = "基金/指数",
            sw_industry_l2 = "宽基ETF"
        ),
        SecurityEntity(
            security_id = "508001.SH",
            issuer_id = "COMP009",
            ticker = "508001",
            ISIN = "CNE100004Q22",
            exchange = Exchange.SSE,
            market = MarketBoard.MAIN,
            currency = "CNY",
            security_type = SecurityType.REIT,
            listing_date = "2021-06-21",
            shares_outstanding = 500000000L,
            free_float = 500000000L,
            status = SecurityStatus.ACTIVE,
            name = "浙商沪杭甬REIT",
            company_cn_name = "浙商证券沪杭甬徽杭高速封闭式基础设施证券投资基金",
            sw_industry_l1 = "交通运输",
            sw_industry_l2 = "高速公路REIT"
        ),
        SecurityEntity(
            security_id = "689009.SH",
            issuer_id = "COMP010",
            ticker = "689009",
            ISIN = "CNE1000045Z2",
            exchange = Exchange.SSE,
            market = MarketBoard.STAR,
            currency = "CNY",
            security_type = SecurityType.CDR,
            listing_date = "2020-10-29",
            shares_outstanding = 717000000L,
            free_float = 520000000L,
            status = SecurityStatus.ACTIVE,
            name = "九号公司-WD",
            company_cn_name = "Ninebot Limited (九号有限公司存托凭证)",
            sw_industry_l1 = "汽车",
            sw_industry_l2 = "摩托车及其他"
        ),
        SecurityEntity(
            security_id = "601318.SH",
            issuer_id = "COMP011",
            ticker = "601318",
            ISIN = "CNE1000001S0",
            exchange = Exchange.SSE,
            market = MarketBoard.MAIN,
            currency = "CNY",
            security_type = SecurityType.A_SHARE,
            listing_date = "2007-03-01",
            shares_outstanding = 18210000000L,
            free_float = 10830000000L,
            status = SecurityStatus.ACTIVE,
            name = "中国平安",
            company_cn_name = "中国平安保险(集团)股份有限公司",
            sw_industry_l1 = "非银金融",
            sw_industry_l2 = "保险"
        ),
        SecurityEntity(
            security_id = "002594.SZ",
            issuer_id = "COMP012",
            ticker = "002594",
            ISIN = "CNE1000015B8",
            exchange = Exchange.SZSE,
            market = MarketBoard.MAIN,
            currency = "CNY",
            security_type = SecurityType.A_SHARE,
            listing_date = "2011-06-30",
            shares_outstanding = 2911000000L,
            free_float = 1810000000L,
            status = SecurityStatus.ACTIVE,
            name = "比亚迪",
            company_cn_name = "比亚迪股份有限公司",
            sw_industry_l1 = "汽车",
            sw_industry_l2 = "乘用车"
        )
    )

    val ruleVersions = listOf(
        MarketRuleVersion(
            rule_id = "RULE_CN_2024_V2",
            version_name = "2024中国证券市场交易规则 (现行第2版)",
            effective_date = "2024-02-01",
            description = "包含沪深京主板/科创板/创业板/北交所最新涨跌幅及盘后交易规则",
            main_board_price_limit_pct = 0.10,
            star_board_price_limit_pct = 0.20,
            chinext_price_limit_pct = 0.20,
            bse_price_limit_pct = 0.30,
            st_price_limit_pct = 0.05
        ),
        MarketRuleVersion(
            rule_id = "RULE_CN_2020_REGISTRATION",
            version_name = "2020创业板/科创板全面注册制改革规则",
            effective_date = "2020-08-24",
            description = "开启创业板20%涨跌幅与前5日无涨跌幅限制历史规则",
            main_board_price_limit_pct = 0.10,
            star_board_price_limit_pct = 0.20,
            chinext_price_limit_pct = 0.20,
            bse_price_limit_pct = 0.30,
            st_price_limit_pct = 0.05
        )
    )

    val tradingCalendar = listOf(
        TradingCalendarDay("2026-10-01", false, "CLOSED", "国庆节假期"),
        TradingCalendarDay("2026-10-02", false, "CLOSED", "国庆节假期"),
        TradingCalendarDay("2026-10-05", false, "CLOSED", "国庆节假期"),
        TradingCalendarDay("2026-10-06", false, "CLOSED", "国庆节假期"),
        TradingCalendarDay("2026-10-07", false, "CLOSED", "国庆节假期"),
        TradingCalendarDay("2026-10-08", true, "FULL_DAY", null),
        TradingCalendarDay("2026-10-09", true, "FULL_DAY", null),
        TradingCalendarDay("2026-10-12", true, "FULL_DAY", null),
        TradingCalendarDay("2026-10-13", true, "FULL_DAY", null)
    )

    val corporateActions = listOf(
        CorporateAction(
            action_id = "CA_600519_2024",
            ticker = "600519",
            announcement_date = "2024-04-03",
            record_date = "2024-06-18",
            ex_date = "2024-06-19",
            cash_dividend_per_10 = 308.76, // 每10股派308.76元
            bonus_shares_per_10 = 0.0,
            reserve_shares_per_10 = 0.0,
            rights_issue_ratio_10 = 0.0,
            rights_issue_price = 0.0
        ),
        CorporateAction(
            action_id = "CA_300750_2024",
            ticker = "300750",
            announcement_date = "2024-03-16",
            record_date = "2024-05-20",
            ex_date = "2024-05-21",
            cash_dividend_per_10 = 50.11,
            bonus_shares_per_10 = 0.0,
            reserve_shares_per_10 = 0.0,
            rights_issue_ratio_10 = 0.0,
            rights_issue_price = 0.0
        )
    )

    val initialPositions = listOf(
        PortfolioPositionEntity("600519.SH", "贵州茅台", 200, 1680.00),
        PortfolioPositionEntity("300750.SZ", "宁德时代", 1500, 215.50),
        PortfolioPositionEntity("688981.SH", "中芯国际", 5000, 52.30),
        PortfolioPositionEntity("510300.SH", "华泰柏瑞沪深300ETF", 50000, 3.82)
    )
}
