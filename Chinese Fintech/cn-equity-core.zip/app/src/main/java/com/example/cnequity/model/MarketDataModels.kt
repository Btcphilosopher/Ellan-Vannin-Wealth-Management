package com.example.cnequity.model

import androidx.room.Entity
import androidx.room.PrimaryKey

data class LevelDepthItem(
    val price: Double,
    val volume: Long,
    val orderCount: Int
)

data class TradeTick(
    val id: String,
    val time: String, // HH:mm:ss.SSS
    val price: Double,
    val volume: Long,
    val side: TradeSide // BUY, SELL, NEUTRAL
)

enum class TradeSide(val cnName: String) {
    BUY("买盘外盘"),
    SELL("卖盘内盘"),
    NEUTRAL("中性盘")
}

data class L1Quote(
    val ticker: String,
    val name: String,
    val last_price: Double,
    val prev_close: Double,
    val open: Double,
    val high: Double,
    val low: Double,
    val volume: Long,        // 成交量 (手 / 股)
    val turnover: Double,     // 成交额 (元)
    val vwap: Double,        // 成交均价 VWAP
    val twap: Double,        // 时间加权均价 TWAP
    val bid1_price: Double,
    val bid1_vol: Long,
    val ask1_price: Double,
    val ask1_vol: Long,
    val change: Double,
    val pct_change: Double,
    val limit_up: Double,
    val limit_down: Double,
    val timestamp: String
)

data class L2MarketDepth(
    val ticker: String,
    val bids: List<LevelDepthItem>, // 10 levels: 买一 to 买十
    val asks: List<LevelDepthItem>, // 10 levels: 卖一 to 卖十
    val recentTrades: List<TradeTick>
)

enum class OrderType(val cnName: String) {
    LIMIT("限价申报"),
    MARKET_BEST5_CANCEL("最优五档即时成交剩余撤销"),
    MARKET_BEST5_LIMIT("最优五档即时成交转限价"),
    CALL_AUCTION("竞价申报")
}

enum class OrderSide(val cnName: String) {
    BUY("买入"),
    SELL("卖出")
}

enum class OrderStatus(val cnName: String) {
    PENDING("待撮合"),
    PARTIAL("部分成交"),
    FILLED("全部成交"),
    CANCELLED("已撤单"),
    REJECTED("废单(规则校验拒绝)")
}

@Entity(tableName = "simulated_orders")
data class OrderItem(
    @PrimaryKey val order_id: String,
    val ticker: String,
    val side: OrderSide,
    val price: Double,
    val volume: Long,
    val filled_volume: Long = 0,
    val type: OrderType,
    val status: OrderStatus,
    val rule_version_id: String,
    val submit_time: String,
    val reject_reason: String? = null
)

data class AuctionResult(
    val ticker: String,
    val indicative_price: Double,
    val matched_volume: Long,
    val unmatched_volume: Long,
    val imbalance_side: String // "BUY_SURPLUS", "SELL_SURPLUS", "BALANCED"
)

data class MarketBreadth(
    val total_stocks: Int,
    val up_count: Int,
    val down_count: Int,
    val flat_count: Int,
    val limit_up_count: Int,
    val limit_down_count: Int,
    val total_turnover: Double, // 亿元
    val northbound_net_inflow: Double, // 亿元
    val southbound_net_inflow: Double, // 亿元
    val up_volume_ratio: Double // 上涨成交额占比
)

data class SectorStat(
    val sector_id: String,
    val sector_name: String,
    val level: String, // "SW_L1", "SW_L2", "CONCEPT"
    val change_pct: Double,
    val turnover: Double, // 亿元
    val net_capital_inflow: Double, // 亿元
    val top_stock_ticker: String,
    val top_stock_name: String,
    val top_stock_change: Double
)
