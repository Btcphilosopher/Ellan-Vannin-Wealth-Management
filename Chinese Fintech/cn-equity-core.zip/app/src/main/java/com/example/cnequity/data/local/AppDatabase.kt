package com.example.cnequity.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.cnequity.model.CompanyEntity
import com.example.cnequity.model.CorporateAction
import com.example.cnequity.model.FinancialStatement
import com.example.cnequity.model.MarketRuleVersion
import com.example.cnequity.model.OrderItem
import com.example.cnequity.model.PortfolioPositionEntity
import com.example.cnequity.model.SecurityEntity
import com.example.cnequity.model.TradingCalendarDay

@Database(
    entities = [
        SecurityEntity::class,
        CompanyEntity::class,
        OrderItem::class,
        MarketRuleVersion::class,
        TradingCalendarDay::class,
        CorporateAction::class,
        FinancialStatement::class,
        PortfolioPositionEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(RoomConverters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun securityDao(): SecurityDao
    abstract fun orderDao(): OrderDao
    abstract fun ruleDao(): RuleDao
    abstract fun financialDao(): FinancialDao
    abstract fun portfolioDao(): PortfolioDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "cn_equity_core_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
