package com.example.cnequity.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.cnequity.data.local.AppDatabase
import com.example.cnequity.data.repository.ApiSdkRepository
import com.example.cnequity.data.repository.FundamentalsRepository
import com.example.cnequity.data.repository.MarketDataEngineRepository
import com.example.cnequity.data.repository.QuantEngineRepository
import com.example.cnequity.data.repository.RuleEngineRepository
import com.example.cnequity.data.seed.InitialDataSeed
import com.example.cnequity.model.AuctionResult
import com.example.cnequity.model.CorporateAction
import com.example.cnequity.model.EarningsForecast
import com.example.cnequity.model.EventStudyResult
import com.example.cnequity.model.FactorScore
import com.example.cnequity.model.FinancialStatement
import com.example.cnequity.model.L1Quote
import com.example.cnequity.model.L2MarketDepth
import com.example.cnequity.model.MarketBreadth
import com.example.cnequity.model.MarketRuleVersion
import com.example.cnequity.model.NorthboundSouthboundFlow
import com.example.cnequity.model.OrderItem
import com.example.cnequity.model.OrderSide
import com.example.cnequity.model.OrderType
import com.example.cnequity.model.PortfolioPositionEntity
import com.example.cnequity.model.PortfolioSummary
import com.example.cnequity.model.RiskMetrics
import com.example.cnequity.model.SectorStat
import com.example.cnequity.model.SecurityEntity
import com.example.cnequity.model.ShareholderHolder
import com.example.cnequity.model.TradingCalendarDay
import com.example.cnequity.model.ValuationBand
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class NavigationTab(val title: String) {
    SECURITY_MASTER("Security Master"),
    MARKET_ORDER("Market & Order Book"),
    RULES_ENGINE("Rules & Calendar"),
    FUNDAMENTALS("Fundamentals"),
    QUANT_RISK("Quant & Risk"),
    API_SDK("API & SDK Sandbox")
}

class TerminalViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val marketDataRepo = MarketDataEngineRepository()
    private val ruleEngineRepo = RuleEngineRepository(db.ruleDao())
    private val fundamentalsRepo = FundamentalsRepository(db.financialDao())
    private val quantRepo = QuantEngineRepository(db.portfolioDao())
    val apiSdkRepo = ApiSdkRepository()

    // Active Tab Navigation
    private val _selectedTab = MutableStateFlow(NavigationTab.SECURITY_MASTER)
    val selectedTab: StateFlow<NavigationTab> = _selectedTab.asStateFlow()

    // Securities & Master Data
    val securities: StateFlow<List<SecurityEntity>> = db.securityDao().getAllSecurities()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _selectedSecurity = MutableStateFlow<SecurityEntity?>(null)
    val selectedSecurity: StateFlow<SecurityEntity?> = _selectedSecurity.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Realtime Market Data
    private val _currentL1Quote = MutableStateFlow<L1Quote?>(null)
    val currentL1Quote: StateFlow<L1Quote?> = _currentL1Quote.asStateFlow()

    private val _currentL2Depth = MutableStateFlow<L2MarketDepth?>(null)
    val currentL2Depth: StateFlow<L2MarketDepth?> = _currentL2Depth.asStateFlow()

    private val _auctionResult = MutableStateFlow<AuctionResult?>(null)
    val auctionResult: StateFlow<AuctionResult?> = _auctionResult.asStateFlow()

    val marketBreadth: MarketBreadth = marketDataRepo.getMarketBreadth()
    val sectorStats: List<SectorStat> = marketDataRepo.getSectorStats()

    // Rules Engine State
    val ruleVersions: StateFlow<List<MarketRuleVersion>> = db.ruleDao().getAllRuleVersions()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _activeRuleVersion = MutableStateFlow<MarketRuleVersion>(InitialDataSeed.ruleVersions.first())
    val activeRuleVersion: StateFlow<MarketRuleVersion> = _activeRuleVersion.asStateFlow()

    val tradingCalendar: StateFlow<List<TradingCalendarDay>> = db.ruleDao().getTradingCalendar()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val ordersList: StateFlow<List<OrderItem>> = db.orderDao().getAllOrders()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Fundamentals State
    private val _valuationBand = MutableStateFlow<ValuationBand?>(null)
    val valuationBand: StateFlow<ValuationBand?> = _valuationBand.asStateFlow()

    private val _earningsForecast = MutableStateFlow<EarningsForecast?>(null)
    val earningsForecast: StateFlow<EarningsForecast?> = _earningsForecast.asStateFlow()

    private val _topShareholders = MutableStateFlow<List<ShareholderHolder>>(emptyList())
    val topShareholders: StateFlow<List<ShareholderHolder>> = _topShareholders.asStateFlow()

    val stockConnectFlow: NorthboundSouthboundFlow = fundamentalsRepo.getStockConnectFlow()

    // Quant & Portfolio State
    val portfolioPositions: StateFlow<List<PortfolioPositionEntity>> = db.portfolioDao().getAllPositions()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _eventStudyResult = MutableStateFlow<EventStudyResult?>(null)
    val eventStudyResult: StateFlow<EventStudyResult?> = _eventStudyResult.asStateFlow()

    private val _factorScores = MutableStateFlow<List<FactorScore>>(emptyList())
    val factorScores: StateFlow<List<FactorScore>> = _factorScores.asStateFlow()

    private val _portfolioSummary = MutableStateFlow<PortfolioSummary?>(null)
    val portfolioSummary: StateFlow<PortfolioSummary?> = _portfolioSummary.asStateFlow()

    private val _riskMetrics = MutableStateFlow<RiskMetrics?>(null)
    val riskMetrics: StateFlow<RiskMetrics?> = _riskMetrics.asStateFlow()

    // Ex-Rights XR/XD Calculator output
    private val _calculatedExPrice = MutableStateFlow<Double?>(null)
    val calculatedExPrice: StateFlow<Double?> = _calculatedExPrice.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            seedDatabaseIfEmpty()
            runEventStudy("EARNINGS_SURPRISE")
        }
    }

    private suspend fun seedDatabaseIfEmpty() {
        val existing = db.securityDao().getAllSecurities().first()
        if (existing.isEmpty()) {
            db.securityDao().insertSecurities(InitialDataSeed.securities)
            InitialDataSeed.ruleVersions.forEach { db.ruleDao().insertRuleVersion(it) }
            db.ruleDao().insertCalendarDays(InitialDataSeed.tradingCalendar)
            db.ruleDao().insertCorporateActions(InitialDataSeed.corporateActions)
            InitialDataSeed.initialPositions.forEach { db.portfolioDao().insertPosition(it) }
        }

        val firstSec = db.securityDao().getAllSecurities().first().firstOrNull() ?: InitialDataSeed.securities.first()
        selectSecurity(firstSec)
    }

    fun selectTab(tab: NavigationTab) {
        _selectedTab.value = tab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectSecurity(security: SecurityEntity) {
        _selectedSecurity.value = security

        // Start quote stream for selected security
        viewModelScope.launch(Dispatchers.IO) {
            marketDataRepo.getL1QuoteFlow(security.security_id).collect { quote ->
                _currentL1Quote.value = quote
                val depth = marketDataRepo.getL2MarketDepth(security.security_id, quote.last_price)
                _currentL2Depth.value = depth
                _auctionResult.value = marketDataRepo.calculateCallAuction(security.security_id, quote.last_price)

                _valuationBand.value = fundamentalsRepo.getValuationBand(security.security_id, quote.last_price)
                _earningsForecast.value = fundamentalsRepo.getEarningsForecast(security.security_id)
                _topShareholders.value = fundamentalsRepo.getTopShareholders(security.security_id)
                _factorScores.value = quantRepo.getFactorScoresForTicker(security.security_id)

                recalculateRisk()
            }
        }
    }

    fun setActiveRuleVersion(version: MarketRuleVersion) {
        _activeRuleVersion.value = version
    }

    fun submitOrder(
        side: OrderSide,
        price: Double,
        volume: Long,
        type: OrderType
    ) {
        val sec = selectedSecurity.value ?: return
        val quote = currentL1Quote.value ?: return

        viewModelScope.launch(Dispatchers.IO) {
            val order = ruleEngineRepo.validateAndSubmitOrder(
                security = sec,
                orderType = type,
                side = side,
                price = price,
                volume = volume,
                prevClose = quote.prev_close,
                activeRule = activeRuleVersion.value
            )
            db.orderDao().insertOrder(order)
        }
    }

    fun calculateExRights(
        prevClose: Double,
        cashDiv10: Double,
        bonus10: Double,
        reserve10: Double,
        rightsRatio10: Double,
        rightsPrice: Double
    ) {
        val action = CorporateAction(
            action_id = "CALC_TEMP",
            ticker = selectedSecurity.value?.ticker ?: "600519",
            announcement_date = "2026-10-07",
            record_date = "2026-10-08",
            ex_date = "2026-10-09",
            cash_dividend_per_10 = cashDiv10,
            bonus_shares_per_10 = bonus10,
            reserve_shares_per_10 = reserve10,
            rights_issue_ratio_10 = rightsRatio10,
            rights_issue_price = rightsPrice
        )
        val exPrice = ruleEngineRepo.calculateExRightsPrice(prevClose, action)
        _calculatedExPrice.value = exPrice
    }

    fun runEventStudy(eventName: String) {
        _eventStudyResult.value = quantRepo.runEventStudy(eventName)
    }

    private fun recalculateRisk() {
        val positions = portfolioPositions.value
        val quotesMap = mapOf(
            "600519.SH" to (currentL1Quote.value?.last_price ?: 1668.50)
        )
        val (summary, risk) = quantRepo.calculatePortfolioRisk(positions, quotesMap)
        _portfolioSummary.value = summary
        _riskMetrics.value = risk
    }
}
