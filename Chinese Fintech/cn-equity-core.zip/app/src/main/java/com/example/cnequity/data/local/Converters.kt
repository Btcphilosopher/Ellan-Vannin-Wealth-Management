package com.example.cnequity.data.local

import androidx.room.TypeConverter
import com.example.cnequity.model.Exchange
import com.example.cnequity.model.MarketBoard
import com.example.cnequity.model.OrderSide
import com.example.cnequity.model.OrderStatus
import com.example.cnequity.model.OrderType
import com.example.cnequity.model.SecurityStatus
import com.example.cnequity.model.SecurityType

class RoomConverters {
    @TypeConverter
    fun fromExchange(value: Exchange): String = value.name

    @TypeConverter
    fun toExchange(value: String): Exchange = Exchange.valueOf(value)

    @TypeConverter
    fun fromMarketBoard(value: MarketBoard): String = value.name

    @TypeConverter
    fun toMarketBoard(value: String): MarketBoard = MarketBoard.valueOf(value)

    @TypeConverter
    fun fromSecurityType(value: SecurityType): String = value.name

    @TypeConverter
    fun toSecurityType(value: String): SecurityType = SecurityType.valueOf(value)

    @TypeConverter
    fun fromSecurityStatus(value: SecurityStatus): String = value.name

    @TypeConverter
    fun toSecurityStatus(value: String): SecurityStatus = SecurityStatus.valueOf(value)

    @TypeConverter
    fun fromOrderSide(value: OrderSide): String = value.name

    @TypeConverter
    fun toOrderSide(value: String): OrderSide = OrderSide.valueOf(value)

    @TypeConverter
    fun fromOrderType(value: OrderType): String = value.name

    @TypeConverter
    fun toOrderType(value: String): OrderType = OrderType.valueOf(value)

    @TypeConverter
    fun fromOrderStatus(value: OrderStatus): String = value.name

    @TypeConverter
    fun toOrderStatus(value: String): OrderStatus = OrderStatus.valueOf(value)
}
