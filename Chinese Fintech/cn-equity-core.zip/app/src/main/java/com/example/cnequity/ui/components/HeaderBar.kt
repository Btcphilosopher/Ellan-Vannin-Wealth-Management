package com.example.cnequity.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Badge
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cnequity.model.MarketBreadth
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.InstitutionalGold
import com.example.cnequity.ui.theme.StockDownGreen
import com.example.cnequity.ui.theme.StockUpRed
import com.example.cnequity.ui.theme.TerminalBorder
import com.example.cnequity.ui.theme.TerminalSurface
import com.example.cnequity.ui.theme.TextSecondary

@Composable
fun HeaderBar(
    activeRuleVersion: String,
    breadth: MarketBreadth,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("terminal_header_bar"),
        color = TerminalSurface,
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Analytics,
                    contentDescription = "CN Equity Logo",
                    tint = InstitutionalCyan
                )
                Spacer(modifier = Modifier.width(6.dp))

                Column {
                    Text(
                        text = "中国股票 // CHINA EQUITY TERMINAL",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "内部计算系统: CN-EQUITY-CORE v2.4",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Rule Badge
                Box(
                    modifier = Modifier
                        .background(InstitutionalGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Rule,
                            contentDescription = "Active Rule",
                            tint = InstitutionalGold,
                            modifier = Modifier.height(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = activeRuleVersion,
                            fontSize = 10.sp,
                            color = InstitutionalGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Market Breadth Ticker Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("全市场统计: ", fontSize = 10.sp, color = TextSecondary)

                Text("涨 ", fontSize = 10.sp, color = TextSecondary)
                Text("${breadth.up_count}", fontSize = 11.sp, color = StockUpRed, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.width(8.dp))
                Text("跌 ", fontSize = 10.sp, color = TextSecondary)
                Text("${breadth.down_count}", fontSize = 11.sp, color = StockDownGreen, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.width(8.dp))
                Text("涨停 ", fontSize = 10.sp, color = TextSecondary)
                Text("${breadth.limit_up_count}", fontSize = 11.sp, color = StockUpRed, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.width(8.dp))
                Text("跌停 ", fontSize = 10.sp, color = TextSecondary)
                Text("${breadth.limit_down_count}", fontSize = 11.sp, color = StockDownGreen, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.weight(1f))

                Text("陆股通北向: ", fontSize = 10.sp, color = TextSecondary)
                Text(
                    text = "+${breadth.northbound_net_inflow}亿",
                    fontSize = 11.sp,
                    color = StockUpRed,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
