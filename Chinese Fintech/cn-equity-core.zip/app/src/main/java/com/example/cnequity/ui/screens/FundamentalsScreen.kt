package com.example.cnequity.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cnequity.model.EarningsForecast
import com.example.cnequity.model.ShareholderHolder
import com.example.cnequity.model.ValuationBand
import com.example.cnequity.ui.TerminalViewModel
import com.example.cnequity.ui.theme.InstitutionalCyan
import com.example.cnequity.ui.theme.InstitutionalGold
import com.example.cnequity.ui.theme.StockDownGreen
import com.example.cnequity.ui.theme.StockUpRed
import com.example.cnequity.ui.theme.TerminalBorder
import com.example.cnequity.ui.theme.TerminalSurface
import com.example.cnequity.ui.theme.TextSecondary

@Composable
fun FundamentalsScreen(
    viewModel: TerminalViewModel,
    modifier: Modifier = Modifier
) {
    val sec by viewModel.selectedSecurity.collectAsState()
    val valBand by viewModel.valuationBand.collectAsState()
    val forecast by viewModel.earningsForecast.collectAsState()
    val shareholders by viewModel.topShareholders.collectAsState()
    val stockConnect = viewModel.stockConnectFlow

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp)
            .testTag("fundamentals_screen")
    ) {
        // Valuation Metrics Band Card
        valBand?.let { band ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalCyan)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${sec?.name ?: "标的"} 估值分析 Band (Valuation Metrics)", style = MaterialTheme.typography.titleMedium, color = InstitutionalCyan)
                        Spacer(modifier = Modifier.weight(1f))
                        Text("PE-TTM: ${String.format("%.1f", band.pe_ttm)}x", fontWeight = FontWeight.Bold, color = StockUpRed, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        ValMetricCell("市净率 PB", "${band.pb}x", Modifier.weight(1f))
                        ValMetricCell("市销率 PS", "${band.ps}x", Modifier.weight(1f))
                        ValMetricCell("EV/EBITDA", "${band.ev_ebitda}x", Modifier.weight(1f))
                        ValMetricCell("股息率 Div Yield", "${band.dividend_yield}%", Modifier.weight(1f), StockUpRed)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = TerminalBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    Text("历史 PE-Band 区间分布 (PE Band ±1SD / ±2SD)", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        ValMetricCell("-2SD 低估位", "${String.format("%.1f", band.pe_sd_minus_2)}x", Modifier.weight(1f), StockDownGreen)
                        ValMetricCell("历史均值 Avg", "${String.format("%.1f", band.pe_hist_avg)}x", Modifier.weight(1f), InstitutionalGold)
                        ValMetricCell("+2SD 高估位", "${String.format("%.1f", band.pe_sd_plus_2)}x", Modifier.weight(1f), StockUpRed)
                    }
                }
            }
        }

        // Consensus Earnings Forecast Card
        forecast?.let { fc ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = TerminalSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalGold)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("卖方机构一致盈利预测 (Consensus Earnings Forecast ${fc.year})", style = MaterialTheme.typography.titleMedium, color = InstitutionalGold)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        ValMetricCell("预测 EPS", "${fc.consensus_eps} 元", Modifier.weight(1f))
                        ValMetricCell("预测 营收", "${fc.consensus_revenue} 亿元", Modifier.weight(1f))
                        ValMetricCell("预测 净利润", "${fc.consensus_net_profit} 亿元", Modifier.weight(1f))
                        ValMetricCell("目标均价", "${fc.target_price} 元", Modifier.weight(1f), StockUpRed)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("机构评级分布: 买入 ${fc.buy_ratings}家 | 增持/中性 ${fc.hold_ratings}家 | 减持 ${fc.sell_ratings}家", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                }
            }
        }

        // Top 10 Shareholders Table
        Text("前十大流通股东持仓明细 (Top 10 Liquid Shareholders)", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, TerminalBorder)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                shareholders.forEach { sh ->
                    ShareholderRow(sh)
                }
            }
        }

        // Northbound / Southbound Stock Connect Flow Abstract
        Text("陆股通 / 港股通 北向与南向资金抽象与持仓走势", style = MaterialTheme.typography.titleSmall, color = TextSecondary)
        Spacer(modifier = Modifier.height(4.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, InstitutionalCyan)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("北向资金今日净买入: ", fontSize = 12.sp, color = TextSecondary)
                    Text("+${stockConnect.northbound_net} 亿元", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = StockUpRed, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.weight(1f))
                    Text("南向资金: +${stockConnect.southbound_net} 亿元", fontSize = 11.sp, color = InstitutionalGold)
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = TerminalBorder)
                Spacer(modifier = Modifier.height(8.dp))

                Text("陆股通重仓标的占比:", fontSize = 11.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                stockConnect.top_holdings_cn.forEach { (ticker, pct) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(ticker, fontSize = 11.sp, color = InstitutionalCyan, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        Text("外资持股占比: $pct%", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun ValMetricCell(label: String, value: String, modifier: Modifier, valColor: Color = InstitutionalCyan) {
    Column(modifier = modifier) {
        Text(label, fontSize = 9.sp, color = TextSecondary)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = valColor, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun ShareholderRow(holder: ShareholderHolder) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${holder.rank}.", fontSize = 11.sp, color = TextSecondary, modifier = Modifier.width(18.dp))
        Column(modifier = Modifier.weight(2f)) {
            Text(holder.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text(holder.category, fontSize = 9.sp, color = InstitutionalGold)
        }
        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text("${holder.holding_pct}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = InstitutionalCyan, fontFamily = FontFamily.Monospace)
            Text("${holder.holdings_shares / 10000}万股", fontSize = 9.sp, color = TextSecondary)
        }
    }
}
