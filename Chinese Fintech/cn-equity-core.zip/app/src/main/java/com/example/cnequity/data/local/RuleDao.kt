package com.example.cnequity.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.cnequity.model.CorporateAction
import com.example.cnequity.model.MarketRuleVersion
import com.example.cnequity.model.TradingCalendarDay
import kotlinx.coroutines.flow.Flow

@Dao
interface RuleDao {
    @Query("SELECT * FROM market_rule_versions ORDER BY effective_date DESC")
    fun getAllRuleVersions(): Flow<List<MarketRuleVersion>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRuleVersion(ruleVersion: MarketRuleVersion)

    @Query("SELECT * FROM trading_calendar ORDER BY date ASC")
    fun getTradingCalendar(): Flow<List<TradingCalendarDay>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalendarDays(days: List<TradingCalendarDay>)

    @Query("SELECT * FROM corporate_actions WHERE ticker = :ticker ORDER BY ex_date DESC")
    fun getCorporateActionsByTicker(ticker: String): Flow<List<CorporateAction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCorporateActions(actions: List<CorporateAction>)
}
