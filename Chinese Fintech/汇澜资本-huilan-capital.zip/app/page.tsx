import React from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import CapabilityGrid from '@/components/CapabilityGrid';
import Philosophy from '@/components/Philosophy';
import ResearchSection from '@/components/ResearchSection';
import AssetManagementSection from '@/components/AssetManagementSection';
import GlobalNetwork from '@/components/GlobalNetwork';
import MarketIntelligenceDashboard from '@/components/MarketIntelligenceDashboard';
import ClientExperienceSection from '@/components/ClientExperienceSection';
import Footer from '@/components/Footer';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#080807] text-[#F2EBDD] selection:bg-[#C7A66A]/30 selection:text-white">
      {/* Fixed Institutional Header */}
      <Header />

      {/* Cinematic Hero with Pudong Skyline Backdrop & Curved Market Terminal */}
      <Hero />

      {/* Institutional Capabilities (4 Architectural Plaques) */}
      <CapabilityGrid />

      {/* Investment Philosophy with Long-Term Compounding Simulation */}
      <Philosophy />

      {/* Research Centre & Chinese Financial Journal */}
      <ResearchSection />

      {/* Asset Management Multi-Strategy Matrices */}
      <AssetManagementSection />

      {/* Shanghai Headquarters & Global Connected Network */}
      <GlobalNetwork />

      {/* Live Global Market Intelligence Dashboard */}
      <MarketIntelligenceDashboard />

      {/* Private Client & Institutional Solutions */}
      <ClientExperienceSection />

      {/* Mega Black-Marble Footer */}
      <Footer />
    </main>
  );
}
