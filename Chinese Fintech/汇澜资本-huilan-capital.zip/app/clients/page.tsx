'use client';

import React from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Building, Landmark, Shield, Lock, FileText, CheckCircle2 } from 'lucide-react';

export default function ClientsPage() {
  return (
    <div className="min-h-screen bg-[#080807] text-[#F2EBDD]">
      <Header />

      {/* Hero */}
      <section className="relative pt-36 pb-20 bg-[#0B0B09] border-b border-[#C7A66A]/15 overflow-hidden">
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>INSTITUTIONAL & PRIVATE CLIENT SERVICES</span>
            </div>
            <h1 className="font-serif-sc text-4xl sm:text-5xl lg:text-6xl text-[#F2EBDD] font-normal leading-tight">
              客户服务 · 携手跨越周期
            </h1>
            <p className="text-base sm:text-lg text-[#8C877D] font-light leading-relaxed">
              汇澜资本为全球机构投资者、领军企业及超高净值家族提供量身定制的资产管理与顶层财富守护体系。
            </p>
          </div>
        </div>
      </section>

      {/* Client Pillars */}
      <section className="py-24 bg-[#080807]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          {/* Institutional Tier */}
          <div className="plaque-border p-8 sm:p-12 bg-[#11110F] space-y-6">
            <div className="flex items-center space-x-3 text-xs text-[#C7A66A] font-mono-num">
              <Building className="w-5 h-5 text-[#E2C88A]" />
              <span>TIER 01 · INSTITUTIONAL CLIENTS</span>
            </div>
            <h2 className="font-serif-sc text-3xl text-[#F2EBDD]">机构投资者综合服务</h2>
            <p className="text-xs sm:text-sm text-[#8C877D] font-light leading-relaxed max-w-3xl">
              服务对象包括主权财富基金、社保养老金、保险资管、银行理财及知名高校基金会。我们提供透明的账户隔离托管、专属投研支持与穿透式持仓对账。
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-white/[0.04] text-xs">
              <div className="p-4 bg-[#171613]">
                <div className="text-[#E2C88A] font-medium mb-1">专属账户托管 (SMA)</div>
                <div className="text-[#8C877D]">满足机构个性化投资范围、杠杆及行业限制要求</div>
              </div>
              <div className="p-4 bg-[#171613]">
                <div className="text-[#E2C88A] font-medium mb-1">宏观闭门研讨会</div>
                <div className="text-[#8C877D]">首席经济学家定期提供季度策略交流与定制研报</div>
              </div>
              <div className="p-4 bg-[#171613]">
                <div className="text-[#E2C88A] font-medium mb-1">合规审计与估值</div>
                <div className="text-[#8C877D]">国际四大会计师事务所出具年度审计报告</div>
              </div>
            </div>
          </div>

          {/* Family Office Tier */}
          <div className="plaque-border p-8 sm:p-12 bg-[#11110F] space-y-6">
            <div className="flex items-center space-x-3 text-xs text-[#C7A66A] font-mono-num">
              <Landmark className="w-5 h-5 text-[#E2C88A]" />
              <span>TIER 02 · FAMILY OFFICE & ULTRA-HNW</span>
            </div>
            <h2 className="font-serif-sc text-3xl text-[#F2EBDD]">家族办公室与代际财富传承</h2>
            <p className="text-xs sm:text-sm text-[#8C877D] font-light leading-relaxed max-w-3xl">
              为高净值家族提供从在岸/离岸家族信托设计、全球多元资产配置、家族宪章起草到二代教育培养的一站式顶层顾问。
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-white/[0.04] text-xs">
              <div className="p-4 bg-[#171613]">
                <div className="text-[#E2C88A] font-medium mb-1">跨法域信托架构</div>
                <div className="text-[#8C877D]">境内家族信托与海外离岸信托双轨顶层设计</div>
              </div>
              <div className="p-4 bg-[#171613]">
                <div className="text-[#E2C88A] font-medium mb-1">资产保全与税务规划</div>
                <div className="text-[#8C877D]">全球合规框架下的财富风险隔离与传承规划</div>
              </div>
              <div className="p-4 bg-[#171613]">
                <div className="text-[#E2C88A] font-medium mb-1">家族治理与非金融权益</div>
                <div className="text-[#8C877D]">家族理事会架构、慈善基金会与全球名校资源对接</div>
              </div>
            </div>
          </div>

          {/* Strategic Corporate Tier */}
          <div className="plaque-border p-8 sm:p-12 bg-[#11110F] space-y-6">
            <div className="flex items-center space-x-3 text-xs text-[#C7A66A] font-mono-num">
              <Shield className="w-5 h-5 text-[#E2C88A]" />
              <span>TIER 03 · CORPORATE CAPITAL ADVISORY</span>
            </div>
            <h2 className="font-serif-sc text-3xl text-[#F2EBDD]">企业战略资本与财资管理</h2>
            <p className="text-xs sm:text-sm text-[#8C877D] font-light leading-relaxed max-w-3xl">
              赋能实体经济领军企业，提供资金流动性管理、产业并购基金设计、汇率利率风险对冲与全球供应链资本赋能。
            </p>
          </div>

        </div>

        {/* NDA & Contact Commitment */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 text-center">
          <div className="p-8 bg-[#141310] border border-[#C7A66A]/30 max-w-2xl mx-auto space-y-4">
            <Lock className="w-6 h-6 text-[#E2C88A] mx-auto" />
            <div className="font-serif-sc text-xl text-[#F2EBDD]">
              最高等级机构保密承诺 (NDA)
            </div>
            <p className="text-xs text-[#8C877D] leading-relaxed">
              汇澜资本对所有潜在及签约机构的咨询信息、资产规模与合作方案均实施银行级严格保密与物理隔离。
            </p>
            <Link href="/contact" className="btn-gold-solid text-xs px-8 py-3 inline-block">
              预约一对一专属机构顾问
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
