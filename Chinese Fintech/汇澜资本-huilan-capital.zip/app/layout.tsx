import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '汇澜资本 HUILAN CAPITAL | 全球视野 · 价值共生',
  description: '汇澜资本 (HUILAN CAPITAL) — 立足中国，布局全球。专注于跨周期的价值投资与高端资产管理，与机构及家族客户共建可持续的财富未来。',
  openGraph: {
    title: '汇澜资本 HUILAN CAPITAL | 全球视野 · 价值共生',
    description: '汇澜资本 (HUILAN CAPITAL) — 专注于跨周期的价值投资与高端资产管理。',
    type: 'website',
    locale: 'zh_CN',
  },
  twitter: {
    card: 'summary_large_image',
    title: '汇澜资本 HUILAN CAPITAL',
    description: '汇澜资本 (HUILAN CAPITAL) — 立足中国，布局全球。专注于跨周期价值投资与资产管理。',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="zh-CN" className="dark scroll-smooth">
      <body className="bg-obsidian text-ivory antialiased min-h-screen selection:bg-amber-900/40 selection:text-amber-100" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}

