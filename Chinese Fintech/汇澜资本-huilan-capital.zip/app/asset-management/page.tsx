'use client';

import React from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { ASSET_MANAGEMENT_STRATEGIES } from '@/data/firm-data';
import { CheckCircle2, Shield, Layers, BarChart3, Landmark } from 'lucide-react';

export default function AssetManagementPage() {
  return (
    <div className="min-h-screen bg-[#080807] text-[#F2EBDD]">
      <Header />

      {/* Hero */}
      <section className="relative pt-36 pb-20 bg-[#0B0B09] border-b border-[#C7A66A]/15 overflow-hidden">
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>ASSET MANAGEMENT CAPABILITIES</span>
            </div>
            <h1 className="font-serif-sc text-4xl sm:text-5xl lg:text-6xl text-[#F2EBDD] font-normal leading-tight">
              全方位机构资产管理业务
            </h1>
            <p className="text-base sm:text-lg text-[#8C877D] font-light leading-relaxed">
              汇澜资本通过专户管理、集合资管计划与离岸QDII/QFII基金，为全球机构投资者提供涵盖权益、固定收益、另类投资及多资产配置的综合资管方案。
            </p>
          </div>
        </div>
      </section>

      {/* Asset Classes Grid */}
      <section className="py-24 bg-[#080807]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          {ASSET_MANAGEMENT_STRATEGIES.map((strat, idx) => (
            <div
              key={strat.id}
              className="plaque-border p-8 sm:p-12 bg-[#11110F] grid grid-cols-1 lg:grid-cols-12 gap-10 items-center"
            >
              <div className="lg:col-span-7 space-y-6">
                <div className="flex items-center space-x-3">
                  <span className="font-mono-num text-xs text-[#C7A66A] tracking-widest uppercase">
                    ASSET CLASS 0{idx + 1}
                  </span>
                  <span className="px-2.5 py-0.5 bg-[#171613] text-[10px] text-[#E2C88A] border border-[#C7A66A]/30">
                    {strat.riskProfile}
                  </span>
                </div>

                <h2 className="font-serif-sc text-3xl sm:text-4xl text-[#F2EBDD] font-normal">
                  {strat.title} · <span className="text-xl text-[#8C877D] font-mono-num">{strat.enTitle}</span>
                </h2>

                <p className="text-xs sm:text-sm text-[#8C877D] leading-relaxed font-light">
                  {strat.philosophy}
                </p>

                <div className="space-y-2">
                  <div className="text-xs text-[#8C877D] tracking-widest uppercase font-mono-num">
                    TARGET STRATEGIES · 重点配置方向
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {strat.subcategories.map((sub, sIdx) => (
                      <span
                        key={sIdx}
                        className="px-3 py-1.5 bg-[#171613] border border-white/[0.08] text-xs text-[#F2EBDD]"
                      >
                        {sub}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  {strat.features.map((f, fIdx) => (
                    <div key={fIdx} className="flex items-start space-x-2 text-xs text-[#8C877D]">
                      <CheckCircle2 className="w-4 h-4 text-[#C7A66A] shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="lg:col-span-5 bg-[#171613] p-8 border border-[#C7A66A]/20 space-y-6">
                <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase">
                  MANDATE PROFILE · 委托概况
                </div>

                <div className="space-y-4 text-xs">
                  <div>
                    <div className="text-[#8C877D]">目标回报中枢</div>
                    <div className="font-mono-num text-2xl font-medium text-[#E2C88A] mt-1">
                      {strat.allocationTarget}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/[0.05]">
                    <div className="text-[#8C877D]">基准指数</div>
                    <div className="text-[#F2EBDD] font-medium mt-0.5">{strat.benchmarks}</div>
                  </div>

                  <div className="pt-3 border-t border-white/[0.05]">
                    <div className="text-[#8C877D]">最低起投与托管方式</div>
                    <div className="text-[#F2EBDD] mt-0.5">机构专户单独开立 / 独立商业银行托管</div>
                  </div>
                </div>

                <Link
                  href="/contact"
                  className="btn-gold-outline w-full text-center text-xs py-2.5 tracking-widest block"
                >
                  申请策略尽调与白皮书
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
}
