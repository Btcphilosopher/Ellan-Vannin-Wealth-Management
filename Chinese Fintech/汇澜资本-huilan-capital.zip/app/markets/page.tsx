'use client';

import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import MarketIntelligenceDashboard from '@/components/MarketIntelligenceDashboard';
import { Clock, Globe, TrendingUp, AlertCircle, Layers } from 'lucide-react';
import { GLOBAL_MARKETS } from '@/data/market-data';

export default function MarketsPage() {
  const economicCalendar = [
    { date: '2026.09.22 09:30', region: '中国', event: '中国1年期/5年期贷款市场报价利率 (LPR)', impact: '高', forecast: '持稳' },
    { date: '2026.09.23 20:30', region: '美国', event: '美国核心PCE物价指数年率', impact: '高', forecast: '2.5%' },
    { date: '2026.09.24 16:00', region: '欧元区', event: '欧洲央行主要再融资利率决议', impact: '高', forecast: '3.00%' },
    { date: '2026.09.25 10:00', region: '中国', event: '国家统计局规模以上工业企业利润数据', impact: '中', forecast: '+5.2%' },
  ];

  return (
    <div className="min-h-screen bg-[#080807] text-[#F2EBDD]">
      <Header />

      {/* Hero */}
      <section className="relative pt-36 pb-16 bg-[#0B0B09] border-b border-[#C7A66A]/15 overflow-hidden">
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>GLOBAL MARKETS & DATA INTELLIGENCE</span>
            </div>
            <h1 className="font-serif-sc text-4xl sm:text-5xl lg:text-6xl text-[#F2EBDD] font-normal leading-tight">
              全球市场行情与宏观雷达
            </h1>
            <p className="text-base sm:text-lg text-[#8C877D] font-light leading-relaxed">
              汇澜资本实时监测全球主要股指、汇率大宗及主权债券收益率曲线，为投资团队与机构客户提供前沿市场基准。
            </p>
          </div>
        </div>
      </section>

      {/* Embedded Comprehensive Terminal Dashboard */}
      <MarketIntelligenceDashboard />

      {/* Macro Economic Calendar & Desk Updates */}
      <section className="py-20 bg-[#080807] border-t border-white/[0.04]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            
            {/* Economic Calendar */}
            <div className="lg:col-span-8 space-y-6">
              <div className="flex items-center justify-between border-b border-white/[0.06] pb-4">
                <div className="space-y-1">
                  <div className="text-xs font-mono-num text-[#C7A66A] tracking-wider uppercase">
                    MACRO CALENDAR · 宏观经济重要事件
                  </div>
                  <h3 className="font-serif-sc text-2xl text-[#F2EBDD]">本周全球宏观关键日程</h3>
                </div>
                <div className="text-xs text-[#8C877D] font-mono-num">
                  BEIJING TIME (UTC+8)
                </div>
              </div>

              <div className="space-y-3">
                {economicCalendar.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-[#11110F] border border-white/[0.04] flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-[#C7A66A]/30 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-0.5 bg-[#171613] text-[10px] text-[#E2C88A] font-medium border border-white/5">
                          {item.region}
                        </span>
                        <span className="font-mono-num text-xs text-[#8C877D]">{item.date}</span>
                      </div>
                      <div className="text-xs sm:text-sm text-[#F2EBDD] font-medium">
                        {item.event}
                      </div>
                    </div>

                    <div className="flex items-center space-x-4 text-xs font-mono-num">
                      <div>
                        <span className="text-[#8C877D] text-[10px]">市场影响: </span>
                        <span className="text-[#E2C88A]">{item.impact}</span>
                      </div>
                      <div>
                        <span className="text-[#8C877D] text-[10px]">预期值: </span>
                        <span className="text-[#F2EBDD]">{item.forecast}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Market Desk Commentary */}
            <div className="lg:col-span-4 bg-[#141310] p-6 sm:p-8 border border-[#C7A66A]/20 space-y-6">
              <div className="text-xs text-[#C7A66A] font-mono-num tracking-wider uppercase">
                DESK BRIEFING · 交易员早报
              </div>

              <div className="space-y-4 text-xs text-[#8C877D] leading-relaxed font-light">
                <p>
                  【A股及港股】：国内稳增长增量政策预期支撑风险偏好，高股息核心资产与科技出海龙头获长线机构增量资金配置。
                </p>
                <p>
                  【大宗与贵金属】：避险情绪与央行购金需求持续支撑黄金处于历史高位震荡区间；原油受全球供需再平衡影响波动率收窄。
                </p>
                <p>
                  【汇率与流动性】：离岸人民币在7.08区间维持强韧双向波动，跨境跨境结算流动性充沛。
                </p>
              </div>

              <div className="pt-4 border-t border-white/[0.05] text-[11px] text-[#8C877D]">
                * 汇澜资本交易台内部参考，不构成直接投资建议。
              </div>
            </div>

          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
