'use client';

import React, { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Search, BookOpen, Download, Filter, ChevronRight, X } from 'lucide-react';
import { RESEARCH_ARTICLES, ResearchArticle } from '@/data/research-data';

export default function ResearchPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('全部');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeArticle, setActiveArticle] = useState<ResearchArticle | null>(null);

  const categories = ['全部', '宏观视野', '产业深度', '资产配置', '量化策略'];

  const filteredArticles = RESEARCH_ARTICLES.filter((art) => {
    const matchCategory = selectedCategory === '全部' || art.category === selectedCategory;
    const matchQuery =
      art.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.abstract.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.author.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCategory && matchQuery;
  });

  return (
    <div className="min-h-screen bg-[#080807] text-[#F2EBDD]">
      <Header />

      {/* Hero Banner */}
      <section className="relative pt-36 pb-20 bg-[#0B0B09] border-b border-[#C7A66A]/15 overflow-hidden">
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>HUILAN RESEARCH INSTITUTE</span>
            </div>
            <h1 className="font-serif-sc text-4xl sm:text-5xl lg:text-6xl text-[#F2EBDD] font-normal leading-tight">
              汇澜投研智库 · 研报全集
            </h1>
            <p className="text-base sm:text-lg text-[#8C877D] font-light leading-relaxed">
              汇聚全球宏观经济、先进制造升级、大宗商品周期及量化资产配置深度智库洞见，为长线资本提供前瞻指引。
            </p>
          </div>
        </div>
      </section>

      {/* Filter and Search Bar */}
      <section className="py-8 bg-[#11110F] border-b border-white/[0.04]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Category pills */}
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 text-xs transition-colors ${
                    selectedCategory === cat
                      ? 'bg-[#C7A66A] text-[#080807] font-semibold'
                      : 'bg-[#171613] text-[#8C877D] hover:text-[#F2EBDD] border border-white/[0.04]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="搜索研报主题、作者、关键词..."
                className="w-full bg-[#171613] border border-white/[0.08] px-4 py-2 pl-10 text-xs text-[#F2EBDD] placeholder-[#8C877D] focus:outline-none focus:border-[#C7A66A]"
              />
              <Search className="w-4 h-4 text-[#8C877D] absolute left-3 top-2.5" />
            </div>

          </div>
        </div>
      </section>

      {/* Articles Grid */}
      <section className="py-20 bg-[#080807]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArticles.map((art) => (
              <div
                key={art.id}
                className="plaque-border p-8 bg-[#141310] flex flex-col justify-between group hover:bg-[#1A1814]"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between text-xs text-[#8C877D] pb-3 border-b border-white/[0.05]">
                    <span className="text-[#C7A66A] font-medium tracking-wider">{art.category}</span>
                    <span className="font-mono-num">{art.date}</span>
                  </div>

                  <h3 className="font-serif-sc text-xl text-[#F2EBDD] font-normal leading-snug group-hover:text-[#E2C88A] transition-colors">
                    {art.title}
                  </h3>

                  <div className="text-[10px] text-[#8C877D] font-mono-num">
                    {art.enTitle}
                  </div>

                  <p className="text-xs text-[#8C877D] leading-relaxed font-light line-clamp-3">
                    {art.abstract}
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-white/[0.04] space-y-4">
                  <div className="flex items-center justify-between text-xs text-[#8C877D]">
                    <span>{art.author}</span>
                    <span className="font-mono-num">{art.readTime}</span>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <button
                      onClick={() => setActiveArticle(art)}
                      className="btn-gold-outline text-xs px-4 py-1.5 tracking-wider"
                    >
                      阅读全文
                    </button>
                    <button
                      onClick={() => alert(`已生成《${art.title}》机构研报 PDF 下载链接 (文件大小: ${art.pdfSize})`)}
                      className="text-xs text-[#8C877D] hover:text-[#E2C88A] flex items-center space-x-1"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{art.pdfSize}</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredArticles.length === 0 && (
            <div className="text-center py-20 text-[#8C877D] space-y-2">
              <div className="text-lg">未找到匹配的研报成果</div>
              <div className="text-xs">请尝试更换搜索词或筛选分类</div>
            </div>
          )}

        </div>
      </section>

      {/* Reader Modal */}
      {activeArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in fade-in">
          <div className="relative w-full max-w-4xl max-h-[90vh] bg-[#11110F] border border-[#C7A66A]/30 p-6 sm:p-10 overflow-y-auto shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-[#C7A66A]/20 pb-4">
              <div className="text-xs text-[#C7A66A] tracking-widest uppercase font-mono-num">
                HUILAN INSTITUTIONAL WHITE PAPER
              </div>
              <button
                onClick={() => setActiveArticle(null)}
                className="p-1.5 text-[#8C877D] hover:text-[#F2EBDD] bg-[#171613] border border-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2">
              <div className="text-xs text-[#E2C88A] font-mono-num">{activeArticle.category} · {activeArticle.date}</div>
              <h2 className="font-serif-sc text-3xl text-[#F2EBDD]">{activeArticle.title}</h2>
              <div className="text-xs text-[#8C877D] font-mono-num">{activeArticle.enTitle}</div>
            </div>

            <div className="p-4 bg-[#171613] border-l-2 border-[#C7A66A] text-xs">
              <div className="font-medium text-[#F2EBDD]">{activeArticle.author}</div>
              <div className="text-[#8C877D] mt-0.5">{activeArticle.authorTitle}</div>
            </div>

            <div className="p-4 bg-[#141310] border border-white/5 text-xs text-[#F2EBDD]/90 italic leading-relaxed">
              【摘要】{activeArticle.abstract}
            </div>

            <div className="space-y-6 text-xs sm:text-sm text-[#8C877D] leading-relaxed font-light">
              {activeArticle.content.map((sec, idx) => (
                <div key={idx} className="space-y-3">
                  <h3 className="font-serif-sc text-lg text-[#E2C88A] font-medium">{sec.sectionTitle}</h3>
                  {sec.paragraphs.map((p, pIdx) => (
                    <p key={pIdx}>{p}</p>
                  ))}
                  {sec.keyMetrics && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
                      {sec.keyMetrics.map((m, mIdx) => (
                        <div key={mIdx} className="p-3 bg-[#171613] border border-[#C7A66A]/20">
                          <div className="text-[11px] text-[#8C877D]">{m.label}</div>
                          <div className="font-mono-num text-lg font-medium text-[#E2C88A] my-1">{m.value}</div>
                          <div className="text-[10px] text-[#8C877D]/70">{m.note}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="pt-6 border-t border-white/[0.06] flex items-center justify-between">
              <button
                onClick={() => alert(`已开始下载: 《${activeArticle.title}》`)}
                className="btn-gold-solid text-xs px-6 py-2.5"
              >
                下载完整白皮书 (PDF)
              </button>
              <button
                onClick={() => setActiveArticle(null)}
                className="text-xs text-[#8C877D] hover:text-[#F2EBDD]"
              >
                关闭阅读
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}
