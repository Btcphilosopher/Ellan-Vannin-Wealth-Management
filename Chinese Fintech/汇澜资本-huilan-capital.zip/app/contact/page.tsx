'use client';

import React, { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { MapPin, Phone, Mail, Clock, ShieldCheck, CheckCircle2, Send, Building2 } from 'lucide-react';
import { GLOBAL_HUBS } from '@/data/market-data';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    organization: '',
    role: '',
    email: '',
    phone: '',
    serviceInterest: '机构资产配置专户 (Institutional SMA)',
    message: '',
    ndaRequested: true,
  });

  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-[#080807] text-[#F2EBDD]">
      <Header />

      {/* Hero */}
      <section className="relative pt-36 pb-16 bg-[#0B0B09] border-b border-[#C7A66A]/15 overflow-hidden">
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>INSTITUTIONAL CONTACT & LIAISON</span>
            </div>
            <h1 className="font-serif-sc text-4xl sm:text-5xl lg:text-6xl text-[#F2EBDD] font-normal leading-tight">
              联系我们 · 机构业务洽谈
            </h1>
            <p className="text-base sm:text-lg text-[#8C877D] font-light leading-relaxed">
              汇澜资本全球总部位于上海陆家嘴金融中心。我们欢迎全球主权基金、大型金融机构、企业财资及超高净值家族随时联络预约。
            </p>
          </div>
        </div>
      </section>

      {/* Form and Office Details Grid */}
      <section className="py-20 bg-[#080807]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            
            {/* Form Column */}
            <div className="lg:col-span-7">
              <div className="plaque-border p-8 sm:p-12 bg-[#11110F] shadow-2xl">
                <div className="border-b border-white/[0.06] pb-6 mb-8 space-y-2">
                  <div className="text-xs font-mono-num text-[#C7A66A] tracking-wider uppercase">
                    INSTITUTIONAL INQUIRY FORM · 机构预约咨询表
                  </div>
                  <h2 className="font-serif-sc text-2xl sm:text-3xl text-[#F2EBDD]">
                    提交洽谈需求与尽调申请
                  </h2>
                  <p className="text-xs text-[#8C877D] font-light">
                    收到您的信息后，汇澜资本机构客户总监将在1个工作日内与您取得保密联系。
                  </p>
                </div>

                {submitted ? (
                  <div className="p-8 bg-[#171613] border border-[#C7A66A]/40 text-center space-y-4 animate-in fade-in">
                    <CheckCircle2 className="w-12 h-12 text-[#E2C88A] mx-auto" />
                    <h3 className="font-serif-sc text-2xl text-[#F2EBDD]">
                      预约提交成功
                    </h3>
                    <p className="text-xs text-[#8C877D] leading-relaxed max-w-md mx-auto">
                      感谢您对汇澜资本的信任。我们已将您的需求密送至相关投资委员会负责人，并将于近期向您的邮箱发送初步材料与保密协议。
                    </p>
                    <button
                      onClick={() => setSubmitted(false)}
                      className="btn-gold-outline text-xs px-6 py-2"
                    >
                      重新提交需求
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[#8C877D]">
                          您的姓名 <span className="text-[#C7A66A]">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          placeholder="例如：陈先生 / 李女士"
                          className="w-full bg-[#171613] border border-white/[0.08] p-3 text-[#F2EBDD] placeholder-[#8C877D]/60 focus:outline-none focus:border-[#C7A66A]"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-[#8C877D]">
                          机构 / 公司名称 <span className="text-[#C7A66A]">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.organization}
                          onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                          placeholder="例如：某主权基金 / 某家族办公室"
                          className="w-full bg-[#171613] border border-white/[0.08] p-3 text-[#F2EBDD] placeholder-[#8C877D]/60 focus:outline-none focus:border-[#C7A66A]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[#8C877D]">
                          电子邮箱 (建议企业邮箱) <span className="text-[#C7A66A]">*</span>
                        </label>
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="name@company.com"
                          className="w-full bg-[#171613] border border-white/[0.08] p-3 text-[#F2EBDD] placeholder-[#8C877D]/60 focus:outline-none focus:border-[#C7A66A]"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-[#8C877D]">联系电话</label>
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="+86 (21) 0000-0000"
                          className="w-full bg-[#171613] border border-white/[0.08] p-3 text-[#F2EBDD] placeholder-[#8C877D]/60 focus:outline-none focus:border-[#C7A66A]"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[#8C877D]">关注业务领域</label>
                      <select
                        value={formData.serviceInterest}
                        onChange={(e) => setFormData({ ...formData, serviceInterest: e.target.value })}
                        className="w-full bg-[#171613] border border-white/[0.08] p-3 text-[#F2EBDD] focus:outline-none focus:border-[#C7A66A]"
                      >
                        <option value="机构资产配置专户 (Institutional SMA)">机构资产配置专户 (Institutional SMA)</option>
                        <option value="家族办公室顶层架构与信托 (Family Office)">家族办公室顶层架构与信托 (Family Office)</option>
                        <option value="企业战略资本与流动性管理 (Corporate Capital)">企业战略资本与流动性管理 (Corporate Capital)</option>
                        <option value="全球宏观与多资产配置基金 (Macro Fund)">全球宏观与多资产配置基金 (Macro Fund)</option>
                        <option value="离岸QDII/QFII跨境投资通道 (Offshore Gateway)">离岸QDII/QFII跨境投资通道 (Offshore Gateway)</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[#8C877D]">需求简述或预约时间建议</label>
                      <textarea
                        rows={4}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        placeholder="请简要描述您的委托规模区间、期望沟通主题或希望拜访的办公室（上海 / 香港 / 新加坡）..."
                        className="w-full bg-[#171613] border border-white/[0.08] p-3 text-[#F2EBDD] placeholder-[#8C877D]/60 focus:outline-none focus:border-[#C7A66A]"
                      />
                    </div>

                    <div className="flex items-center space-x-2 pt-2">
                      <input
                        type="checkbox"
                        id="nda"
                        checked={formData.ndaRequested}
                        onChange={(e) => setFormData({ ...formData, ndaRequested: e.target.checked })}
                        className="accent-[#C7A66A]"
                      />
                      <label htmlFor="nda" className="text-[11px] text-[#8C877D]">
                        要求在进一步深入沟通前签署双向保密协议 (Non-Disclosure Agreement)
                      </label>
                    </div>

                    <button
                      type="submit"
                      disabled={submitting}
                      className="btn-gold-solid w-full text-xs py-3.5 tracking-widest font-medium"
                    >
                      {submitting ? '正在加密传输...' : '提交预约与保密咨询 →'}
                    </button>
                  </form>
                )}
              </div>
            </div>

            {/* Offices Column */}
            <div className="lg:col-span-5 space-y-6">
              
              {/* Shanghai HQ Card */}
              <div className="p-8 bg-[#141310] border border-[#C7A66A]/30 space-y-4 plaque-border">
                <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
                  <div className="text-xs font-mono-num text-[#E2C88A] tracking-wider uppercase">
                    GLOBAL HEADQUARTERS · 全球总部
                  </div>
                  <span className="w-2 h-2 rounded-full bg-[#E2C88A] animate-ping" />
                </div>

                <h3 className="font-serif-sc text-2xl text-[#F2EBDD]">
                  上海 · 汇澜资本大厦
                </h3>

                <div className="space-y-3 text-xs text-[#8C877D] font-light">
                  <div className="flex items-start space-x-2.5">
                    <MapPin className="w-4 h-4 text-[#C7A66A] shrink-0 mt-0.5" />
                    <span>中国上海市浦东新区陆家嘴环路 汇澜金融大厦 58-62F</span>
                  </div>
                  <div className="flex items-center space-x-2.5">
                    <Phone className="w-4 h-4 text-[#C7A66A]" />
                    <span>+86 (21) 6888-8888</span>
                  </div>
                  <div className="flex items-center space-x-2.5">
                    <Mail className="w-4 h-4 text-[#C7A66A]" />
                    <span>hq@huilancapital.com</span>
                  </div>
                  <div className="flex items-center space-x-2.5">
                    <Clock className="w-4 h-4 text-[#C7A66A]" />
                    <span>交易日 08:30 - 18:00 (CST)</span>
                  </div>
                </div>
              </div>

              {/* Regional Hubs */}
              <div className="p-8 bg-[#11110F] border border-white/[0.06] space-y-6">
                <div className="text-xs font-mono-num text-[#C7A66A] tracking-wider uppercase">
                  REGIONAL HUBS & LIAISON · 亚太及全球联络处
                </div>

                <div className="space-y-4 text-xs">
                  <div className="pb-3 border-b border-white/[0.04]">
                    <div className="text-[#F2EBDD] font-medium">香港离岸资产中心 (Hong Kong)</div>
                    <div className="text-[#8C877D]">香港中环金融街8号 国际金融中心二期 (IFC) 45F</div>
                    <div className="text-[11px] text-[#C7A66A] mt-0.5">hk@huilancapital.com</div>
                  </div>

                  <div className="pb-3 border-b border-white/[0.04]">
                    <div className="text-[#F2EBDD] font-medium">新加坡区域枢纽 (Singapore)</div>
                    <div className="text-[#8C877D]">Marina Bay Financial Centre Tower 1, Level 32</div>
                    <div className="text-[11px] text-[#C7A66A] mt-0.5">sg@huilancapital.com</div>
                  </div>

                  <div>
                    <div className="text-[#F2EBDD] font-medium">苏黎世 / 伦敦 / 纽约 代表处</div>
                    <div className="text-[#8C877D]">Bahnhofstrasse 45, Zürich · 100 Bishopsgate, London</div>
                    <div className="text-[11px] text-[#C7A66A] mt-0.5">global@huilancapital.com</div>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
