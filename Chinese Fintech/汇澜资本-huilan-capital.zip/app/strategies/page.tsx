'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { ShieldCheck, Cpu, Sliders, LineChart, Globe, CheckCircle2, ArrowRight } from 'lucide-react';
import { ASSET_MANAGEMENT_STRATEGIES } from '@/data/firm-data';

export default function StrategiesPage() {
  const [activeStrategy, setActiveStrategy] = useState(ASSET_MANAGEMENT_STRATEGIES[0]);

  return (
    <div className="min-h-screen bg-[#080807] text-[#F2EBDD]">
      <Header />

      {/* Hero Banner */}
      <section className="relative pt-36 pb-20 bg-[#0B0B09] border-b border-[#C7A66A]/15 overflow-hidden">
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>INVESTMENT STRATEGIES & FRAMEWORK</span>
            </div>
            <h1 className="font-serif-sc text-4xl sm:text-5xl lg:text-6xl text-[#F2EBDD] font-normal leading-tight">
              跨周期价值投资与多资产策略
            </h1>
            <p className="text-base sm:text-lg text-[#8C877D] font-light leading-relaxed">
              汇澜资本融合深度基本面研究、跨市场宏观风险对冲与“澜图 (LAN-GRID)”量化多因子体系，为长线资本构筑兼具韧性与成长性的资产配置矩阵。
            </p>
          </div>
        </div>
      </section>

      {/* Three Pillars of Strategy */}
      <section className="py-20 bg-[#080807] border-b border-white/[0.04]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase">
              CORE PILLARS · 投研三大支柱
            </div>
            <h2 className="font-serif-sc text-3xl sm:text-4xl text-[#F2EBDD] font-normal">
              以科学与纪律驾驭市场不确定性
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="plaque-border p-8 bg-[#11110F] space-y-4">
              <div className="p-3 bg-[#171613] border border-[#C7A66A]/30 w-fit">
                <Globe className="w-6 h-6 text-[#E2C88A]" />
              </div>
              <h3 className="font-serif-sc text-2xl text-[#F2EBDD]">宏观全天候对冲</h3>
              <p className="text-xs text-[#8C877D] leading-relaxed font-light">
                打破传统单一资产依赖，通过全球大类资产（权益、固收、大宗商品、外汇）在不同通胀与增长周期中的互补性，实现回撤平滑。
              </p>
              <div className="pt-2 text-[11px] text-[#C7A66A] font-mono-num">
                目标夏普比率 Sharpe &gt; 1.5
              </div>
            </div>

            <div className="plaque-border p-8 bg-[#11110F] space-y-4">
              <div className="p-3 bg-[#171613] border border-[#C7A66A]/30 w-fit">
                <Cpu className="w-6 h-6 text-[#E2C88A]" />
              </div>
              <h3 className="font-serif-sc text-2xl text-[#F2EBDD]">澜图量化投研引擎</h3>
              <p className="text-xs text-[#8C877D] leading-relaxed font-light">
                自主研发 LAN-GRID 智能化多因子平台，覆盖超15,000个高频基本面与另类特征，赋能组合动态再平衡与毫秒级执行。
              </p>
              <div className="pt-2 text-[11px] text-[#E2C88A] font-mono-num">
                日均数据吞吐 2.4 PB
              </div>
            </div>

            <div className="plaque-border p-8 bg-[#11110F] space-y-4">
              <div className="p-3 bg-[#171613] border border-[#C7A66A]/30 w-fit">
                <ShieldCheck className="w-6 h-6 text-[#E2C88A]" />
              </div>
              <h3 className="font-serif-sc text-2xl text-[#F2EBDD]">独立风险预算体系</h3>
              <p className="text-xs text-[#8C877D] leading-relaxed font-light">
                从单资产波动率限额、行业集中度到尾部极值压力测试，三道独立风控闸门全天候监控，杜绝永久性本金损失。
              </p>
              <div className="pt-2 text-[11px] text-[#C7A66A] font-mono-num">
                十四年历史最大回撤 &lt; 6.8%
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Deep-Dive Strategy Explorer */}
      <section className="py-24 bg-[#0B0B09]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-12 space-y-3">
            <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase">
              STRATEGY MATRIX · 策略全景矩阵
            </div>
            <h2 className="font-serif-sc text-3xl sm:text-4xl text-[#F2EBDD] font-normal">
              定制化机构资产配置策略
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Strategy Sidebar */}
            <div className="lg:col-span-4 space-y-2">
              {ASSET_MANAGEMENT_STRATEGIES.map((strat) => (
                <button
                  key={strat.id}
                  onClick={() => setActiveStrategy(strat)}
                  className={`w-full text-left p-5 border transition-all ${
                    activeStrategy.id === strat.id
                      ? 'bg-[#171613] border-[#E2C88A] text-[#F2EBDD] shadow-lg'
                      : 'bg-[#11110F] border-white/[0.04] text-[#8C877D] hover:border-[#C7A66A]/30'
                  }`}
                >
                  <div className="text-xs font-mono-num text-[#8C877D] mb-1">{strat.enTitle}</div>
                  <div className="font-serif-sc text-xl font-medium">{strat.title}</div>
                  <div className="text-xs text-[#C7A66A] mt-2 font-mono-num">{strat.allocationTarget}</div>
                </button>
              ))}
            </div>

            {/* Strategy Content Panel */}
            <div className="lg:col-span-8 plaque-border bg-[#141310] p-8 sm:p-10 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/[0.06] pb-4">
                <div>
                  <div className="text-xs font-mono-num text-[#8C877D]">{activeStrategy.enTitle}</div>
                  <h3 className="font-serif-sc text-3xl text-[#F2EBDD] font-normal mt-0.5">
                    {activeStrategy.title}
                  </h3>
                </div>
                <div className="px-3 py-1 bg-[#171613] border border-[#C7A66A]/30 text-xs font-mono-num text-[#E2C88A]">
                  {activeStrategy.riskProfile}
                </div>
              </div>

              <p className="text-xs sm:text-sm text-[#8C877D] leading-relaxed font-light">
                {activeStrategy.philosophy}
              </p>

              <div className="space-y-3">
                <div className="text-xs text-[#8C877D] tracking-widest uppercase font-mono-num">
                  STRATEGY SUBCATEGORIES · 细分配置标的
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {activeStrategy.subcategories.map((sub, sIdx) => (
                    <div key={sIdx} className="p-3 bg-[#171613] border border-white/[0.05] text-xs text-[#F2EBDD]">
                      {sub}
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <div className="text-xs text-[#8C877D] tracking-widest uppercase font-mono-num">
                  KEY FEATURES · 核心运作优势
                </div>
                {activeStrategy.features.map((feat, fIdx) => (
                  <div key={fIdx} className="flex items-start space-x-2 text-xs text-[#8C877D]">
                    <CheckCircle2 className="w-4 h-4 text-[#C7A66A] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>

              <div className="pt-6 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-4">
                <div className="text-xs text-[#8C877D]">
                  基准: <span className="text-[#F2EBDD]">{activeStrategy.benchmarks}</span>
                </div>
                <Link href="/contact" className="btn-gold-solid text-xs px-6 py-2.5 tracking-widest">
                  咨询该策略专户委托 →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
