'use client';

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'motion/react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { ShieldCheck, Award, Landmark, Globe, CheckCircle2, ChevronRight } from 'lucide-react';
import { FIRM_STATISTICS, LEADERSHIP_TEAM } from '@/data/firm-data';

export default function AboutPage() {
  const milestones = [
    { year: '2012', title: '汇澜资本于上海陆家嘴创立', desc: '以“全球视野·价值共生”为使命，获得首批中国证券投资基金业协会私募证券投资管理人备案。' },
    { year: '2015', title: '设立香港离岸资产管理中心', desc: '取得香港证监会颁发的第4类（就证券提供意见）及第9类（提供资产管理）牌照，开启全球跨境资本配置。' },
    { year: '2018', title: '上线“澜图 (LAN-GRID)”量化多因子投研中台', desc: '将高维非线性机器学习与宏观机制图谱融合，多资产策略夏普比率突破1.5。' },
    { year: '2021', title: '设立新加坡区域枢纽与家族办公室战略服务线', desc: '全面服务亚洲与全球超高净值家族及华人领军企业家代际财富平稳传承。' },
    { year: '2024', title: '总管理规模突破4,800亿元人民币', desc: '成为受全球主权基金、大型保险资管与养老金长期委托的标志性中国资产管理机构。' },
    { year: '2026', title: '深化全球六大金融枢纽协同网络', desc: '持续连接中国核心资产与全球长线资本，践行跨周期的时代价值。' },
  ];

  return (
    <div className="min-h-screen bg-[#080807] text-[#F2EBDD]">
      <Header />

      {/* Hero Banner */}
      <section className="relative pt-36 pb-20 bg-[#0B0B09] border-b border-[#C7A66A]/15 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image
            src="/images/hq-architecture.jpg"
            alt="汇澜资本上海总部"
            fill
            className="object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B0B09] via-[#0B0B09]/80 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>ABOUT HUILAN CAPITAL</span>
            </div>
            <h1 className="font-serif-sc text-4xl sm:text-5xl lg:text-6xl text-[#F2EBDD] font-normal leading-tight">
              关于汇澜 · 立足中国，布局全球
            </h1>
            <p className="text-base sm:text-lg text-[#8C877D] font-light leading-relaxed">
              汇澜资本是一家总部位于中国上海的顶尖机构级资产管理与投资服务机构。我们以严谨的跨周期价值投资与全球化资产配置能力，致力于成为全球长线资本最值得信赖的价值共生伙伴。
            </p>
          </div>

          {/* Firm Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 pt-8 border-t border-white/[0.06]">
            {FIRM_STATISTICS.map((stat, idx) => (
              <div key={idx} className="p-4 bg-[#141310] border border-[#C7A66A]/20">
                <div className="text-xs text-[#8C877D]">{stat.label}</div>
                <div className="font-mono-num text-2xl sm:text-3xl font-medium text-[#E2C88A] my-1">
                  {stat.value} <span className="text-sm text-[#F2EBDD]">{stat.unit}</span>
                </div>
                <div className="text-[10px] text-[#8C877D] font-mono-num">{stat.enLabel}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Philosophy & Institutional Mission */}
      <section className="py-24 bg-[#080807] border-b border-white/[0.04]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-6 space-y-6">
              <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase">
                OUR GOVERNANCE & CREED · 治理与信条
              </div>
              <h2 className="font-serif-sc text-3xl sm:text-4xl text-[#F2EBDD] font-normal leading-snug">
                专业 · 稳健 · 长期 · 合规
              </h2>
              <p className="text-xs sm:text-sm text-[#8C877D] leading-relaxed font-light">
                汇澜资本始终将受托人责任置于最高优先级。我们不追求短期规模的盲目扩张，而是通过建立严密的三道风险防线、独立的投资决策委员会与长效激励机制，确保每一项投资决策经得起时间与周期的淬炼。
              </p>

              <div className="space-y-3 pt-2">
                {[
                  '绝对受托人准则：始终将客户利益置于机构自身商业利益之上',
                  '穿透式全维度风控：建立严格的流动性回撤与极端情景熔断机制',
                  'ESG与可持续责任：将环境、社会与良好治理全面纳入投研底层框架',
                  '全球合规与信息披露：主动对接国际最高行业审计与合规标准'
                ].map((item, idx) => (
                  <div key={idx} className="flex items-start space-x-3 text-xs text-[#F2EBDD]/90">
                    <CheckCircle2 className="w-4 h-4 text-[#C7A66A] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-6 bg-[#11110F] p-8 border border-[#C7A66A]/30 plaque-border space-y-6">
              <div className="text-xs font-mono-num text-[#E2C88A] tracking-wider uppercase">
                INSTITUTIONAL ARCHITECTURE · 治理架构
              </div>

              <div className="space-y-4 text-xs">
                <div className="p-4 bg-[#171613] border border-white/[0.04]">
                  <div className="text-[#F2EBDD] font-medium mb-1">投资决策委员会 (Investment Committee)</div>
                  <div className="text-[#8C877D]">负责制定全机构宏观资产配置基准、战略风险预算及重大项目最终审决。</div>
                </div>

                <div className="p-4 bg-[#171613] border border-white/[0.04]">
                  <div className="text-[#F2EBDD] font-medium mb-1">独立风险管理与合规委员会 (Risk & Compliance Committee)</div>
                  <div className="text-[#8C877D]">拥有对任何违反风险预算或合规指引投资行为的“一票否决权”。</div>
                </div>

                <div className="p-4 bg-[#171613] border border-white/[0.04]">
                  <div className="text-[#F2EBDD] font-medium mb-1">汇澜宏观与前沿产业智库 (Huilan Global Institute)</div>
                  <div className="text-[#8C877D]">为投资前线提供跨周期的全球宏观推演与前沿硬科技产业深度洞察。</div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-24 bg-[#0B0B09] border-b border-white/[0.04]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-16 space-y-3">
            <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase">
              LEADERSHIP & PARTNERS · 核心管理团队
            </div>
            <h2 className="font-serif-sc text-3xl sm:text-4xl text-[#F2EBDD] font-normal">
              汇聚全球顶尖投研与资管专家
            </h2>
            <p className="text-xs sm:text-sm text-[#8C877D] font-light">
              核心合伙人均拥有逾20年国际一流主权基金、顶级投行与头部公募管理经验。
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {LEADERSHIP_TEAM.map((leader, idx) => (
              <div key={idx} className="plaque-border p-8 bg-[#141310] space-y-4">
                <div className="flex items-start justify-between border-b border-white/[0.05] pb-4">
                  <div>
                    <h3 className="font-serif-sc text-2xl text-[#F2EBDD] font-medium">
                      {leader.name}
                    </h3>
                    <div className="text-xs text-[#E2C88A] mt-1 font-light">
                      {leader.title}
                    </div>
                    <div className="text-[10px] text-[#8C877D] font-mono-num mt-0.5">
                      {leader.enTitle}
                    </div>
                  </div>
                  <div className="p-2.5 bg-[#171613] border border-[#C7A66A]/30 text-[#C7A66A]">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                </div>

                <p className="text-xs text-[#8C877D] leading-relaxed font-light">
                  {leader.bio}
                </p>

                <div className="pt-3 border-t border-white/[0.04] text-[11px] text-[#C7A66A] font-mono-num">
                  教育与学术资质: {leader.background}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Milestones History Timeline */}
      <section className="py-24 bg-[#080807]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
            <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase">
              HISTORY & MILESTONES · 发展历程
            </div>
            <h2 className="font-serif-sc text-3xl sm:text-4xl text-[#F2EBDD] font-normal">
              十四载穿越周期，铸就机构信赖
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {milestones.map((m, idx) => (
              <div key={idx} className="p-6 bg-[#11110F] border border-[#C7A66A]/20 space-y-3 relative group hover:border-[#E2C88A] transition-colors">
                <div className="font-mono-num text-3xl font-bold text-[#E2C88A]">
                  {m.year}
                </div>
                <div className="font-serif-sc text-base text-[#F2EBDD] font-medium">
                  {m.title}
                </div>
                <p className="text-xs text-[#8C877D] leading-relaxed font-light">
                  {m.desc}
                </p>
              </div>
            ))}
          </div>

          <div className="text-center mt-16">
            <Link href="/contact" className="btn-gold-solid text-xs tracking-widest px-8 py-3">
              联络汇澜资本上海总部 →
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
