export interface ResearchArticle {
  id: string;
  title: string;
  enTitle: string;
  category: '宏观视野' | '产业深度' | '资产配置' | '量化策略' | '智库专栏';
  date: string;
  author: string;
  authorTitle: string;
  readTime: string;
  isFeatured?: boolean;
  abstract: string;
  content: {
    sectionTitle: string;
    paragraphs: string[];
    keyMetrics?: { label: string; value: string; note: string }[];
  }[];
  tags: string[];
  pdfSize: string;
}

export const RESEARCH_ARTICLES: ResearchArticle[] = [
  {
    id: 'china-long-term-value',
    title: '中国资产的长期价值与全球资本的新坐标',
    enTitle: 'Long-Term Valuation of Chinese Assets and the New Coordinates of Global Capital',
    category: '宏观视野',
    date: '2026.08.18',
    author: '陈怀澜 博士',
    authorTitle: '汇澜资本首席经济学家 · 投资决策委员会主席',
    readTime: '12 分钟',
    isFeatured: true,
    pdfSize: '3.4 MB',
    abstract: '在逆全球化与产业技术革命交织的新周期中，全球资本正在重新审视中国核心资产的定价锚点。本文从全要素生产率、制造业高端化与长期估值修复三大维度，剖析中国资产的跨周期配置逻辑。',
    tags: ['宏观策略', '全球资产配置', '长期价值', '估值体系'],
    content: [
      {
        sectionTitle: '一、全球资本周期的范式转移与资产重估',
        paragraphs: [
          '过去三十年依托低通胀与自由流动贸易建立的全球资本定价模型，正在经历深刻重塑。全球供应链多元化、地缘经济重构以及去中心化清算体系的演进，使得单一维度的现金流贴现模型难以解释跨国资金流动的新趋势。',
          '在这一背景下，中国资本市场展现出极高的内生韧性。随着制造业转型升级的持续深化和战略性新兴产业的规模效应释放，以高端制造、清洁能源及新一代数字基础设施为代表的核心实体资产，正在成为全球长期主权基金与养老金配置的压舱石。'
        ],
        keyMetrics: [
          { label: '中国制造业占全球比重', value: '31.2%', note: '连续14年位居全球第一' },
          { label: '核心资产股息率溢价', value: '+240 bps', note: '相比美债实际收益率' },
          { label: '外资长期配置资金流入', value: '¥1,850 亿', note: '2026年度累计净流入' }
        ]
      },
      {
        sectionTitle: '二、制造业高端化：全要素生产率跃迁的核心引擎',
        paragraphs: [
          '中国在新一代信息技术、精密制造、航空航天及具身智能领域的研发投入强度已进入全球第一梯队。传统以劳动力成本为竞争力的模式，已彻底转向以工程工程师红利、敏捷供应链网络与自主研发闭环为核心的综合竞争壁垒。',
          '汇澜资本投研模型显示，具备全球定价权的高端制造龙头企业，其ROE中枢在跨越宏观周期波动时展现出前所未有的平稳度。'
        ]
      },
      {
        sectionTitle: '三、资产配置建议：立足确定性现金流与逆向布局',
        paragraphs: [
          '对于长线机构投资者，我们建议坚持“哑铃型”配置策略：一方面坚守具有高股息、强现金流与抗周期属性的公用事业与央国企核心资产；另一方面在周期底部逆向加仓具有全球出海能力的先进制造业领军者。'
        ]
      }
    ]
  },
  {
    id: 'global-macro-outlook',
    title: '全球宏观经济展望：多极化格局下的利率重构与资本流向',
    enTitle: 'Global Macroeconomic Outlook: Interest Rate Realignment in a Multipolar World',
    category: '宏观视野',
    date: '2026.07.25',
    author: '王梓衡',
    authorTitle: '全球宏观策略总监 · 前国际清算银行客座研究员',
    readTime: '9 分钟',
    pdfSize: '2.8 MB',
    abstract: '主要经济体央行货币政策分化加剧，美欧中性利率中枢上移与亚洲流动性环境形成显著对比。汇澜资本从跨市场流动性与主权信用利差切入，推演未来三年的全球利率中枢演进路径。',
    tags: ['利率策略', '货币政策', '主权债', '流动性'],
    content: [
      {
        sectionTitle: '一、中性利率中枢上移与债务周期的结构性约束',
        paragraphs: [
          '全球主要发达经济体公共债务比率处于二战以来历史高位，使得央行在抗击结构性通胀与维持债务可持续性之间面临双重博弈。'
        ]
      }
    ]
  },
  {
    id: 'asia-capital-markets',
    title: '亚洲资本市场观察：跨境清算创新与离岸人民币流动性池深化',
    enTitle: 'Asia Capital Markets Monitor: Cross-border Clearing and Offshore RMB Liquidity',
    category: '资产配置',
    date: '2026.06.30',
    author: '陆安琪',
    authorTitle: '离岸资本市场研究主管',
    readTime: '8 分钟',
    pdfSize: '2.1 MB',
    abstract: '香港与新加坡双枢纽在离岸资产定价中的协同效应日益凸显。伴随双边本币结算协议的扩容，离岸人民币资产的流动性深度与抗波动属性大幅提升。',
    tags: ['离岸金融', '跨境资本', '人民币国际化', '固定收益'],
    content: [
      {
        sectionTitle: '一、多边清算机制对离岸债券市场的催化效应',
        paragraphs: [
          '随着“互换通”及离岸国债期货产品的丰富，国际机构投资者对以人民币计价的优质生息资产需求进入结构性增长期。'
        ]
      }
    ]
  },
  {
    id: 'ai-industry-cycle',
    title: '人工智能与新产业周期：从算力基建到实体经济生产力裂变',
    enTitle: 'Artificial Intelligence & the New Industrial Cycle: From Compute to Real-Economy Productivity',
    category: '产业深度',
    date: '2026.05.15',
    author: '苏博宇',
    authorTitle: '前沿科技与高端制造投研总监',
    readTime: '11 分钟',
    pdfSize: '4.1 MB',
    abstract: '大模型与具身智能正由实验室技术转向工业互联网与高端装备制造的现场级应用。本篇报告深度拆解产业链价值分布，寻找具备软硬协同壁垒的时代级标的。',
    tags: ['人工智能', '硬科技', '产业投资', '半导体'],
    content: [
      {
        sectionTitle: '一、算力成本拐点与端侧工业智能的规模化落地',
        paragraphs: [
          '在工业质检、自主物流和复杂系统调度中，垂类AI模型展现出数倍于传统自动化系统的投资回报率。'
        ]
      }
    ]
  },
  {
    id: 'china-manufacturing-upgrade',
    title: '中国制造业升级：精密制造与全球化出海的第二增长曲线',
    enTitle: 'China Manufacturing Upgrade: Precision Engineering and Global Expansion',
    category: '产业深度',
    date: '2026.04.10',
    author: '林墨卿',
    authorTitle: '先进制造首席分析师',
    readTime: '10 分钟',
    pdfSize: '3.0 MB',
    abstract: '从“中国制造”到“全球布局的中国智造”，优质中国企业在东南亚、中东、东欧与拉美的本地化建厂与品牌出海正在打开全新的估值空间。',
    tags: ['先进制造', '企业出海', '供应链', '专精特新'],
    content: [
      {
        sectionTitle: '一、全球化2.0时代中国供应链的在地化赋能',
        paragraphs: [
          '中国制造业不仅是产能的输出，更是精益制造管理标准、敏捷研发体系与工业数字化平台的系统性输出。'
        ]
      }
    ]
  },
  {
    id: 'global-energy-resources',
    title: '全球能源与资源市场：双碳转型与关键矿产地缘定价权',
    enTitle: 'Global Energy and Resources: Transition Dynamics and Critical Minerals Geopolitics',
    category: '资产配置',
    date: '2026.03.02',
    author: '赵宏远',
    authorTitle: '大宗商品与能源策略师',
    readTime: '7 分钟',
    pdfSize: '2.5 MB',
    abstract: '传统化石能源资本开支受限与新能源矿物需求高增形成长期结构性缺口。本文为机构客户提供通胀对冲与战略大宗商品的仓位配置模型。',
    tags: ['大宗商品', '绿色能源', '黄金与原油', '周期投资'],
    content: [
      {
        sectionTitle: '一、关键金属的供应刚性与能源转型资本开支周期',
        paragraphs: [
          '铜、锂、镍等关键金属在新型电力系统建设中的消耗强度持续上升，而新矿投产周期长达7-10年，构筑了坚实的抗通胀中枢。'
        ]
      }
    ]
  },
  {
    id: 'long-term-rates-pricing',
    title: '长期利率与资本定价：通胀预期、期限溢价与资产组合韧性',
    enTitle: 'Long-Term Interest Rates & Asset Pricing: Inflation Expectations and Portfolio Resilience',
    category: '量化策略',
    date: '2026.01.20',
    author: '徐致远 博士',
    authorTitle: '量化工程与多资产配置总监',
    readTime: '13 分钟',
    pdfSize: '3.9 MB',
    abstract: '基于动态协方差矩阵与极值理论，构建适应高波动、非线性宏观环境的全天候资产配置框架，实证检验跨周期风险预算与下行保护机制。',
    tags: ['风险平价', '全天候策略', '量化模型', '对冲工具'],
    content: [
      {
        sectionTitle: '一、动态风险预算模型在极端市场情景下的回撤控制',
        paragraphs: [
          '通过引入宏观机制转移隐藏马尔可夫模型（HMM），实现不同经济周期阶段间各大类资产风险权重的动态再平衡。'
        ]
      }
    ]
  }
];
