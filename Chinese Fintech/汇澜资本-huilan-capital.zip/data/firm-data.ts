export interface Capability {
  id: string;
  title: string;
  enTitle: string;
  subtitle: string;
  description: string;
  bullets: string[];
  metrics: { label: string; value: string }[];
  tag: string;
}

export interface StrategyCategory {
  id: string;
  title: string;
  enTitle: string;
  shortDesc: string;
  subcategories: string[];
  philosophy: string;
  allocationTarget: string;
  riskProfile: '稳健型 (Conservative)' | '平衡型 (Balanced)' | '进取型 (Growth)' | '全天候 (All-Weather)';
  benchmarks: string;
  features: string[];
}

export interface LeadershipMember {
  name: string;
  title: string;
  enTitle: string;
  bio: string;
  background: string;
}

export const FIRM_STATISTICS = [
  { label: '总资产管理规模 (AUM)', value: '4,850', unit: '亿元', enLabel: 'Assets Under Management' },
  { label: '全球机构及家族客户', value: '680', unit: '+ 家', enLabel: 'Institutional Clients' },
  { label: '跨周期投资管理历程', value: '14', unit: '年', enLabel: 'Track Record (Years)' },
  { label: '全球金融枢纽布局', value: '6', unit: '大中心', enLabel: 'Global Financial Hubs' },
];

export const INSTITUTIONAL_CAPABILITIES: Capability[] = [
  {
    id: 'global-allocation',
    title: '全球资产配置',
    enTitle: 'Global Asset Allocation',
    subtitle: '跨市场 / 多策略',
    description: '穿透全球多资产周期，通过跨地域、跨币种、跨资产类别的立体配置架构，捕捉全球结构性增长红利并对冲单一市场系统性风险。',
    bullets: [
      '覆盖中国A股、港股、美股、欧股等核心权益市场',
      '全球主权债券、高评级信用债及结构化收益工具',
      '大宗商品与抗通胀实物资产宏观对冲',
      '动态情景模拟与流动性压力测试机制'
    ],
    metrics: [
      { label: '配置大类资产类别', value: '12 种' },
      { label: '多周期超额收益率', value: '8.4%' }
    ],
    tag: '宏观 · 多元'
  },
  {
    id: 'quant-investing',
    title: '量化投资',
    enTitle: 'Quantitative Investing',
    subtitle: '数据驱动 / 智能决策',
    description: '依托汇澜自主研发的“澜图 (LAN-GRID)”高频与多因子投研引擎，结合宏观机制识别与非线性机器学习算法，实现超额 Alpha 的持续捕获。',
    bullets: [
      '自主研发低延迟多因子风控与归因中台',
      '宏观知识图谱与另类非结构化数据语义挖掘',
      '统计套利、波动率曲面建模与CTA量化策略',
      '毫秒级自动化订单执行与智能滑点抑制'
    ],
    metrics: [
      { label: '因子特征库规模', value: '15,000+' },
      { label: '模型日均回测吞吐', value: '2.4 PB' }
    ],
    tag: '科技 · 严谨'
  },
  {
    id: 'risk-management',
    title: '风险管理',
    enTitle: 'Risk Governance',
    subtitle: '稳健合规 / 长期主义',
    description: '将合规与全面风险管理视作金融机构的生命线。建立从投资委员会、投研端到中后台的三道坚不可摧的独立风险控制防线。',
    bullets: [
      '三级独立风险预算与回撤熔断保护机制',
      '全天候流动性监控与极端黑天鹅压力测试',
      '严格穿透式底层资产合规尽职调查体系',
      '符合国际巴塞尔协议与资管新规最高标准'
    ],
    metrics: [
      { label: '历史最大回撤控制', value: '< 6.8%' },
      { label: '合规风控审核通过率', value: '100%' }
    ],
    tag: '合规 · 稳健'
  },
  {
    id: 'family-office',
    title: '家族办公室',
    enTitle: 'Family Office Advisory',
    subtitle: '财富传承 / 代际延续',
    description: '为超高净值家族与领军企业家量身定制集“家族信托架构、全球资产配置、代际教育、慈善公益与税务合规”于一体的综合顶层财富方案。',
    bullets: [
      '离岸/在岸离散型信托与法律架构搭建',
      '多代际财富平稳交接与家族宪章设计',
      '私密专属投资委员会与联合家族办协同',
      '全球顶尖医疗、教育与非金融专属权益'
    ],
    metrics: [
      { label: '服务超高净值家族', value: '120+ 户' },
      { label: '代际财富留存周期', value: '跨 3 代' }
    ],
    tag: '传承 · 尊享'
  }
];

export const ASSET_MANAGEMENT_STRATEGIES: StrategyCategory[] = [
  {
    id: 'equities',
    title: '权益投资',
    enTitle: 'Equities Investment',
    shortDesc: '中国股票 / 全球股票 / 产业投资',
    subcategories: ['中国A股核心价值', '港股及离岸中概龙头', '全球科技领航', '先进制造股权'],
    philosophy: '以产业资本的深度认知做二级市场投资，寻找具备深厚护城河、优秀现金流创造力与卓越管理层的伟大企业。',
    allocationTarget: '年化目标回报率 12% - 16%',
    riskProfile: '进取型 (Growth)',
    benchmarks: '沪深300 / MSCI China / 标普500 复合基准',
    features: [
      '深度行业基本面草根调研与产业链穿透',
      '逆向价值选股与跨周期估值安全边际',
      '赋能式投后管理与产业资源协同对接'
    ]
  },
  {
    id: 'fixed-income',
    title: '固定收益',
    enTitle: 'Fixed Income',
    shortDesc: '信用债券 / 利率策略 / 全球固定收益',
    subcategories: ['主权与政策性金融债', '高等级央国企信用债', '离岸中资美元债', '可转债与结构化票据'],
    philosophy: '在守住信用安全底线的前提下，运用久期策略、杠杆套息与信用利差挖掘，为投资者获取确定性稳健收益。',
    allocationTarget: '年化目标回报率 4.5% - 7.0%',
    riskProfile: '稳健型 (Conservative)',
    benchmarks: '中债综合财富指数 / 彭博全球综合债券指数',
    features: [
      '内部独立信评体系与全生命周期违约预警',
      '跨市场利率互换与国债期货对冲工具',
      '低波动、高流动性现金管理工具箱'
    ]
  },
  {
    id: 'alternatives',
    title: '另类资产',
    enTitle: 'Alternative Assets',
    shortDesc: '私募股权 / 基础设施 / 特殊机会',
    subcategories: ['硬科技成长股权', '绿色能源基础设施', '困境资产重组', '大宗商业地产信托'],
    philosophy: '布局非公开市场非对称收益机会，通过长期耐心资本换取非流动性溢价与战略协同价值。',
    allocationTarget: 'IRR 目标 15% - 22%',
    riskProfile: '平衡型 (Balanced)',
    benchmarks: 'Preqin 私募股权指数 / 基础设施基准',
    features: [
      '领投关键卡脖子技术与国家战略新兴产业',
      '现金流充沛的公用事业与数据中心资产',
      '专业法务清算与资产盘活处置能力'
    ]
  },
  {
    id: 'multi-asset',
    title: '多资产配置',
    enTitle: 'Multi-Asset Solutions',
    shortDesc: '宏观策略 / 风险平价 / 动态配置',
    subcategories: ['全天候风险平价', '宏观趋势对冲基金', '主权养老金定制方案', 'FOF/MOM 优选管理'],
    philosophy: '打破传统股债二元对立，通过风险因子分解与动态再平衡，打造穿越牛熊周期的“全天候”资本航母。',
    allocationTarget: '夏普比率 Sharpe Ratio > 1.4',
    riskProfile: '全天候 (All-Weather)',
    benchmarks: '全球平衡多元资产基准 (60/40 Enhanced)',
    features: [
      '全因子风险平价模型与波动率目标管理',
      '全球衍生品低摩擦风险对冲与流动性管理',
      '定制化机构风险预算与专属账户隔离托管'
    ]
  }
];

export const LEADERSHIP_TEAM: LeadershipMember[] = [
  {
    name: '陈怀澜 博士',
    title: '汇澜资本创始人 · 首席执行官兼投资决策委员会主席',
    enTitle: 'Founder, CEO & Chairman of Investment Committee',
    bio: '拥有超过25年全球资本市场与中国本土资产管理经验。曾任国际知名主权财富基金亚太区董事总经理及国内头部公募基金投资总监，主导投资规模逾千亿元人民币。清华大学五道口金融学院特聘导师，上海国际金融中心建设专家咨询委员会委员。',
    background: '北京大学经济学学士 · 哥伦比亚大学金融工程博士'
  },
  {
    name: '林韵 先生',
    title: '合伙人 · 全球宏观策略与多资产配置负责人',
    enTitle: 'Partner, Head of Global Macro & Multi-Asset Allocation',
    bio: '曾任伦敦顶尖宏观对冲基金高级合伙人兼首席策略师，专注于全球利率、外汇及大宗商品衍生品策略设计。在跨国资产配置与黑天鹅风险对冲领域享有盛誉。',
    background: '伦敦政治经济学院(LSE)经济学硕士 · CFA / FRM'
  },
  {
    name: '张昭明 博士',
    title: '合伙人 · 量化投研与金融科技首席架构师',
    enTitle: 'Partner, Chief Quantitative Strategist',
    bio: '纽约知名对冲基金前量化研究主管，长期从事高维非线性统计物理模型在金融时间序列中的应用，领导开发汇澜“澜图 (LAN-GRID)”智能投研中台。',
    background: '复旦大学物理学学士 · 麻省理工学院(MIT)应用数学博士'
  },
  {
    name: '沈思颖 女士',
    title: '合伙人 · 机构客户与家族办公室总监',
    enTitle: 'Partner, Head of Institutional & Family Office Advisory',
    bio: '历任瑞士宝盛银行及瑞银集团亚太区高管，拥有近20年服务亚洲顶级家族办公室及主权养老金的深厚积淀，主持设计数十起重大跨境信托与代际传承项目。',
    background: '香港大学法学硕士 · STEP 国际信托与财产从业者协会全资会员'
  }
];
