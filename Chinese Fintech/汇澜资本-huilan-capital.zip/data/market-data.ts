export interface MarketIndex {
  id: string;
  name: string;
  enName: string;
  code: string;
  value: string;
  numericValue: number;
  change: string;
  isPositive: boolean;
  sparkline: number[];
  category: 'indices' | 'commodities' | 'fx' | 'bonds';
  high: string;
  low: string;
  volume: string;
}

export interface CityHub {
  id: string;
  name: string;
  enName: string;
  role: string;
  address: string;
  timezone: string;
  x: number; // percentage on map
  y: number; // percentage on map
  status: 'HQ' | 'Regional Hub' | 'Representative Office';
  focus: string;
}

export const GLOBAL_MARKETS: MarketIndex[] = [
  {
    id: 'shanghai',
    name: '上证指数',
    enName: 'SSE Composite',
    code: '000001.SH',
    value: '3,287.45',
    numericValue: 3287.45,
    change: '+1.23%',
    isPositive: true,
    sparkline: [3240, 3248, 3255, 3250, 3262, 3270, 3287.45],
    category: 'indices',
    high: '3,294.10',
    low: '3,238.80',
    volume: '4,520 亿元',
  },
  {
    id: 'szse',
    name: '深证成指',
    enName: 'SZSE Component',
    code: '399001.SZ',
    value: '10,542.31',
    numericValue: 10542.31,
    change: '+1.56%',
    isPositive: true,
    sparkline: [10380, 10420, 10450, 10430, 10490, 10520, 10542.31],
    category: 'indices',
    high: '10,580.00',
    low: '10,360.20',
    volume: '5,890 亿元',
  },
  {
    id: 'hsi',
    name: '恒生指数',
    enName: 'Hang Seng Index',
    code: 'HSI.HK',
    value: '18,732.12',
    numericValue: 18732.12,
    change: '+1.34%',
    isPositive: true,
    sparkline: [18450, 18520, 18500, 18610, 18680, 18710, 18732.12],
    category: 'indices',
    high: '18,810.50',
    low: '18,410.00',
    volume: '1,280 亿港元',
  },
  {
    id: 'nasdaq',
    name: '纳斯达克',
    enName: 'NASDAQ 100',
    code: 'NDX.US',
    value: '17,891.23',
    numericValue: 17891.23,
    change: '+0.98%',
    isPositive: true,
    sparkline: [17700, 17740, 17790, 17760, 17830, 17870, 17891.23],
    category: 'indices',
    high: '17,940.00',
    low: '17,680.50',
    volume: '820 亿美元',
  },
  {
    id: 'sp500',
    name: '标普500',
    enName: 'S&P 500',
    code: 'SPX.US',
    value: '5,762.14',
    numericValue: 5762.14,
    change: '+1.12%',
    isPositive: true,
    sparkline: [5690, 5710, 5725, 5720, 5745, 5755, 5762.14],
    category: 'indices',
    high: '5,775.20',
    low: '5,685.10',
    volume: '410 亿美元',
  },
  {
    id: 'nikkei',
    name: '日经225',
    enName: 'Nikkei 225',
    code: 'N225.JP',
    value: '38,620.50',
    numericValue: 38620.5,
    change: '+0.75%',
    isPositive: true,
    sparkline: [38300, 38380, 38450, 38400, 38520, 38590, 38620.5],
    category: 'indices',
    high: '38,750.00',
    low: '38,220.00',
    volume: '2.4 万亿日元',
  },
  {
    id: 'gold',
    name: '伦敦金 / 黄金',
    enName: 'Spot Gold',
    code: 'XAU/USD',
    value: '$2,657.40',
    numericValue: 2657.4,
    change: '+0.87%',
    isPositive: true,
    sparkline: [2630, 2638, 2642, 2640, 2648, 2652, 2657.4],
    category: 'commodities',
    high: '$2,668.00',
    low: '$2,628.50',
    volume: '14.2 万手',
  },
  {
    id: 'oil',
    name: '布伦特原油',
    enName: 'Brent Crude',
    code: 'BRENT.IPE',
    value: '$72.36',
    numericValue: 72.36,
    change: '+0.43%',
    isPositive: true,
    sparkline: [71.8, 71.9, 72.1, 72.0, 72.2, 72.28, 72.36],
    category: 'commodities',
    high: '$73.10',
    low: '$71.40',
    volume: '28.5 万手',
  },
  {
    id: 'usdcnh',
    name: '美元 / 离岸人民币',
    enName: 'USD / CNH',
    code: 'USD/CNH',
    value: '7.0842',
    numericValue: 7.0842,
    change: '-0.18%',
    isPositive: false,
    sparkline: [7.102, 7.098, 7.092, 7.095, 7.088, 7.085, 7.0842],
    category: 'fx',
    high: '7.1050',
    low: '7.0810',
    volume: '340 亿美元',
  },
  {
    id: 'cn10y',
    name: '中国10年期国债收益率',
    enName: 'China 10Y Bond',
    code: 'CN10Y.BD',
    value: '2.045%',
    numericValue: 2.045,
    change: '-1.2 bps',
    isPositive: false,
    sparkline: [2.062, 2.058, 2.055, 2.052, 2.048, 2.046, 2.045],
    category: 'bonds',
    high: '2.065%',
    low: '2.040%',
    volume: '银行间主力',
  }
];

export const GLOBAL_HUBS: CityHub[] = [
  {
    id: 'shanghai',
    name: '上海',
    enName: 'Shanghai',
    role: '全球总部 & 投资决策中心',
    address: '中国上海市浦东新区陆家嘴环路 汇澜金融大厦 58-62F',
    timezone: 'Asia/Shanghai',
    x: 74,
    y: 43,
    status: 'HQ',
    focus: '宏观策略、中国权益、另类资产、全球配置总枢纽'
  },
  {
    id: 'hongkong',
    name: '香港',
    enName: 'Hong Kong',
    role: '亚太离岸资产管理中心',
    address: '香港中环金融街8号 国际金融中心二期 45F',
    timezone: 'Asia/Hong_Kong',
    x: 73,
    y: 50,
    status: 'Regional Hub',
    focus: '跨境资本流动、离岸QDII/QFII、对冲基金'
  },
  {
    id: 'singapore',
    name: '新加坡',
    enName: 'Singapore',
    role: '东南亚及家办服务枢纽',
    address: '滨海湾金融中心一号大楼 32F',
    timezone: 'Asia/Singapore',
    x: 71,
    y: 58,
    status: 'Regional Hub',
    focus: '东南亚新兴市场股权、家族办公室财富架构'
  },
  {
    id: 'london',
    name: '伦敦',
    enName: 'London',
    role: '欧洲资本与宏观研究中心',
    address: '100 Bishopsgate, City of London, EC2N 4AG',
    timezone: 'Europe/London',
    x: 48,
    y: 30,
    status: 'Regional Hub',
    focus: '欧洲固定收益、基础设施投资基金、跨国并购'
  },
  {
    id: 'newyork',
    name: '纽约',
    enName: 'New York',
    role: '美洲市场投研联络处',
    address: '30 Hudson Yards, New York, NY 10001',
    timezone: 'America/New_York',
    x: 27,
    y: 36,
    status: 'Representative Office',
    focus: '北美科技产业洞察、全球量化多因子策略'
  },
  {
    id: 'zurich',
    name: '苏黎世',
    enName: 'Zurich',
    role: '欧洲私人银行及特种另类资产',
    address: 'Bahnhofstrasse 45, 8001 Zürich, Switzerland',
    timezone: 'Europe/Zurich',
    x: 50,
    y: 33,
    status: 'Representative Office',
    focus: '高净值家族代际信托、可持续绿色金融'
  }
];
