'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X, ChevronRight, PhoneCall, ShieldCheck, Globe } from 'lucide-react';

interface HeaderProps {
  onOpenContactModal?: () => void;
}

export default function Header({ onOpenContactModal }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: '首页', href: '/' },
    { name: '关于我们', href: '/about' },
    { name: '投资策略', href: '/strategies' },
    { name: '研究中心', href: '/research' },
    { name: '资产管理', href: '/asset-management' },
    { name: '客户服务', href: '/clients' },
    { name: '市场洞察', href: '/markets' },
  ];

  return (
    <>
      <header
        id="main-header"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#12110E]/90 backdrop-blur-md border-b border-[#C7A66A]/20 shadow-2xl py-3'
            : 'bg-gradient-to-b from-black/80 via-black/30 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo Section */}
            <Link
              href="/"
              id="brand-logo-link"
              className="group flex items-center space-x-3.5 focus:outline-none"
            >
              {/* Gold Geometric Vertical Bar Logo */}
              <div className="flex items-end space-x-1 h-8 px-1">
                <span className="w-1.5 h-4 bg-gradient-to-t from-[#9A7D46] to-[#E2C88A] rounded-none transition-all duration-300 group-hover:h-5"></span>
                <span className="w-1.5 h-7 bg-gradient-to-t from-[#9A7D46] to-[#E2C88A] rounded-none transition-all duration-300 group-hover:h-8"></span>
                <span className="w-1.5 h-5 bg-gradient-to-t from-[#9A7D46] to-[#E2C88A] rounded-none transition-all duration-300 group-hover:h-6"></span>
                <span className="w-1.5 h-6 bg-gradient-to-t from-[#9A7D46] to-[#E2C88A] rounded-none transition-all duration-300 group-hover:h-7"></span>
              </div>

              <div className="flex flex-col">
                <div className="flex items-center space-x-2">
                  <span className="font-serif-sc text-xl sm:text-2xl font-bold tracking-widest text-[#F2EBDD] group-hover:text-[#E2C88A] transition-colors duration-300">
                    汇澜资本
                  </span>
                  <span className="text-[10px] tracking-wider text-[#C7A66A] font-light hidden md:inline-block border-l border-[#C7A66A]/30 pl-2">
                    HUILAN CAPITAL
                  </span>
                </div>
                <span className="text-[10px] sm:text-[11px] tracking-[0.25em] text-[#8C877D] font-light">
                  全球视野 · 价值共生
                </span>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <nav id="desktop-nav" className="hidden lg:flex items-center space-x-1 xl:space-x-2">
              {navLinks.map((item) => {
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    id={`nav-link-${item.href.replace('/', '') || 'home'}`}
                    className={`relative px-3 py-1.5 text-sm tracking-widest transition-all duration-300 group ${
                      isActive
                        ? 'text-[#E2C88A] font-medium'
                        : 'text-[#8C877D] hover:text-[#F2EBDD]'
                    }`}
                  >
                    <span>{item.name}</span>
                    {/* Subtle underline hover effect */}
                    <span
                      className={`absolute bottom-0 left-3 right-3 h-[1.5px] bg-[#C7A66A] transition-all duration-300 ${
                        isActive
                          ? 'opacity-100 scale-x-100'
                          : 'opacity-0 scale-x-0 group-hover:opacity-100 group-hover:scale-x-100'
                      }`}
                    />
                  </Link>
                );
              })}
            </nav>

            {/* Right Status Badge & Contact CTA */}
            <div className="hidden sm:flex items-center space-x-4">
              <div
                id="header-institutional-badge"
                className="hidden xl:flex items-center space-x-1.5 px-3 py-1 border border-[#C7A66A]/30 bg-[#171613]/80 rounded-none text-[12px] tracking-widest text-[#C7A66A]"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-[#E2C88A]" />
                <span>专业 · 稳健 · 长期</span>
              </div>

              <Link
                href="/contact"
                id="header-contact-btn"
                className="btn-gold-outline text-xs tracking-widest px-4 py-1.5"
              >
                联系我们
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <div className="flex lg:hidden items-center space-x-2">
              <button
                id="mobile-menu-toggle"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-[#C7A66A] hover:text-[#F2EBDD] focus:outline-none"
                aria-label="Toggle Navigation Menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="fixed inset-0 z-40 bg-black/95 backdrop-blur-xl lg:hidden pt-24 px-6 pb-8 flex flex-col justify-between overflow-y-auto animate-in fade-in duration-300"
        >
          <div className="space-y-6">
            <div className="border-b border-[#C7A66A]/20 pb-4">
              <div className="text-xl font-serif-sc text-[#F2EBDD] tracking-widest">
                汇澜资本
              </div>
              <div className="text-xs text-[#8C877D] tracking-widest mt-1">
                立足中国 · 布局全球 · 专注长期价值
              </div>
            </div>

            <nav className="flex flex-col space-y-4">
              {navLinks.map((item) => {
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center justify-between py-2 text-base tracking-widest transition-colors ${
                      isActive
                        ? 'text-[#E2C88A] font-semibold pl-2 border-l-2 border-[#C7A66A]'
                        : 'text-[#F2EBDD]/80 hover:text-[#E2C88A]'
                    }`}
                  >
                    <span>{item.name}</span>
                    <ChevronRight className="w-4 h-4 text-[#C7A66A]/60" />
                  </Link>
                );
              })}
              <Link
                href="/contact"
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between py-2 text-base tracking-widest text-[#E2C88A]"
              >
                <span>联系我们 (上海总部)</span>
                <ChevronRight className="w-4 h-4 text-[#C7A66A]" />
              </Link>
            </nav>
          </div>

          <div className="pt-8 border-t border-[#C7A66A]/20 space-y-4">
            <div className="flex items-center space-x-2 text-xs text-[#C7A66A]">
              <Globe className="w-4 h-4" />
              <span>全球资产管理与机构投资决策中心</span>
            </div>
            <p className="text-[11px] text-[#8C877D] leading-relaxed">
              上海市浦东新区陆家嘴金融中心 · 汇澜金融大厦
            </p>
            <div className="text-[11px] text-[#8C877D]">
              专业 · 稳健 · 长期 · 合规
            </div>
          </div>
        </div>
      )}
    </>
  );
}
