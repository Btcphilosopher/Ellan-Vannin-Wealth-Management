'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { motion } from 'motion/react';
import { PieChart, TrendingUp, ShieldCheck, Layers, ArrowUpRight, BarChart4, CheckCircle } from 'lucide-react';
import { ASSET_MANAGEMENT_STRATEGIES, StrategyCategory } from '@/data/firm-data';

export default function AssetManagementSection() {
  const [selectedStrategyId, setSelectedStrategyId] = useState<string>('equities');
  const selectedStrategy =
    ASSET_MANAGEMENT_STRATEGIES.find((s) => s.id === selectedStrategyId) ||
    ASSET_MANAGEMENT_STRATEGIES[0];

  // Allocation weights breakdown visual for each category
  const allocationBreakdown: Record<string, { label: string; pct: number; color: string }[]> = {
    equities: [
      { label: '中国A股核心价值龙头', pct: 45, color: '#E2C88A' },
      { label: '港股及离岸中概高股息', pct: 30, color: '#C7A66A' },
      { label: '全球先进科技与出海领军', pct: 25, color: '#8C877D' },
    ],
    'fixed-income': [
      { label: '主权债与政策性金融债', pct: 50, color: '#E2C88A' },
      { label: '高等级央国企信用债', pct: 35, color: '#C7A66A' },
      { label: '离岸美元债与结构化票据', pct: 15, color: '#8C877D' },
    ],
    alternatives: [
      { label: '硬科技与先进制造股权', pct: 40, color: '#E2C88A' },
      { label: '清洁能源与算力基础设施', pct: 35, color: '#C7A66A' },
      { label: '特殊机会与困境资产重组', pct: 25, color: '#8C877D' },
    ],
    'multi-asset': [
      { label: '全球多元宏观股票', pct: 35, color: '#E2C88A' },
      { label: '全球固定收益与利率工具', pct: 40, color: '#C7A66A' },
      { label: '大宗商品与全天候对冲', pct: 25, color: '#8C877D' },
    ],
  };

  const currentAllocation = allocationBreakdown[selectedStrategy.id] || allocationBreakdown['equities'];

  return (
    <section id="asset-management-section" className="relative py-28 bg-[#080807] border-t border-[#C7A66A]/15 overflow-hidden">
      {/* Background Architectural Graphic */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#C7A66A]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-[#C7A66A]/15 pb-8">
          <div className="space-y-3">
            <div className="flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>ASSET MANAGEMENT</span>
            </div>
            <h2 className="font-serif-sc text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F2EBDD]">
              全天候资产管理体系
            </h2>
          </div>
          <Link
            href="/asset-management"
            className="mt-4 md:mt-0 inline-flex items-center space-x-1.5 text-xs text-[#C7A66A] hover:text-[#E2C88A] tracking-widest font-light transition-colors"
          >
            <span>资管业务全景</span>
            <ArrowUpRight className="w-4 h-4" />
          </Link>
        </div>

        {/* 4 Strategy Tabs */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-10">
          {ASSET_MANAGEMENT_STRATEGIES.map((strat) => {
            const isSelected = strat.id === selectedStrategyId;
            return (
              <button
                key={strat.id}
                onClick={() => setSelectedStrategyId(strat.id)}
                className={`p-5 text-left border transition-all duration-300 relative ${
                  isSelected
                    ? 'bg-[#171613] border-[#C7A66A] shadow-lg'
                    : 'bg-[#11110F]/70 border-white/[0.06] hover:border-[#C7A66A]/40'
                }`}
              >
                {/* Active Indicator Top Line */}
                {isSelected && (
                  <div className="absolute top-0 left-0 right-0 h-[2px] bg-[#E2C88A]" />
                )}

                <div className="text-xs text-[#8C877D] tracking-wider font-mono-num mb-1">
                  {strat.enTitle}
                </div>
                <div className={`font-serif-sc text-lg sm:text-xl font-medium ${isSelected ? 'text-[#E2C88A]' : 'text-[#F2EBDD]'}`}>
                  {strat.title}
                </div>
                <div className="text-[11px] text-[#8C877D] mt-1 line-clamp-1 font-light">
                  {strat.shortDesc}
                </div>
              </button>
            );
          })}
        </div>

        {/* Strategy Detail View Container */}
        <div className="plaque-border bg-[#11110F] p-8 sm:p-12 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              <div className="space-y-2">
                <div className="inline-block px-3 py-1 bg-[#171613] border border-[#C7A66A]/30 text-xs font-mono-num text-[#E2C88A]">
                  风险属性: {selectedStrategy.riskProfile}
                </div>
                <h3 className="font-serif-sc text-2xl sm:text-3xl text-[#F2EBDD] font-normal">
                  {selectedStrategy.title} · 投资逻辑与运作机制
                </h3>
              </div>

              <p className="text-xs sm:text-sm text-[#8C877D] leading-relaxed font-light">
                {selectedStrategy.philosophy}
              </p>

              {/* Subcategories Tags */}
              <div className="space-y-2">
                <div className="text-xs text-[#8C877D] tracking-widest uppercase font-mono-num">
                  STRATEGY MODULES · 细分子策略
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedStrategy.subcategories.map((sub, sIdx) => (
                    <span
                      key={sIdx}
                      className="px-3 py-1.5 bg-[#171613] border border-white/[0.08] text-xs text-[#F2EBDD] font-light"
                    >
                      {sub}
                    </span>
                  ))}
                </div>
              </div>

              {/* Core Features */}
              <div className="space-y-2.5 pt-2">
                {selectedStrategy.features.map((feat, fIdx) => (
                  <div key={fIdx} className="flex items-start space-x-2.5 text-xs text-[#8C877D]">
                    <CheckCircle className="w-4 h-4 text-[#C7A66A] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between">
                <div className="text-xs text-[#8C877D]">
                  参考业绩基准: <span className="text-[#F2EBDD]">{selectedStrategy.benchmarks}</span>
                </div>
                <Link
                  href="/asset-management"
                  className="btn-gold-outline text-xs px-5 py-2 tracking-widest"
                >
                  详细配置指引 →
                </Link>
              </div>
            </div>

            {/* Right Interactive Portfolio Allocation Visualizer */}
            <div className="lg:col-span-5 bg-[#171613] p-6 sm:p-8 border border-[#C7A66A]/20 space-y-6">
              <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
                <div className="text-xs font-mono-num text-[#C7A66A] tracking-wider uppercase">
                  PORTFOLIO ALLOCATION MATRIX
                </div>
                <div className="text-[11px] font-mono-num text-[#E2C88A]">
                  {selectedStrategy.allocationTarget}
                </div>
              </div>

              {/* Target Return Callout */}
              <div className="p-4 bg-[#11110F] border border-[#C7A66A]/20 text-center">
                <div className="text-[11px] text-[#8C877D]">预期中枢收益区间</div>
                <div className="font-mono-num text-2xl font-medium text-[#E2C88A] my-1">
                  {selectedStrategy.allocationTarget}
                </div>
                <div className="text-[10px] text-[#8C877D]">基于严谨历史跨周期回溯模型测算</div>
              </div>

              {/* Bar Weight Visualization */}
              <div className="space-y-4">
                <div className="text-xs text-[#F2EBDD] font-medium">大类资产仓位配比示例</div>
                <div className="space-y-3">
                  {currentAllocation.map((item, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[#8C877D]">{item.label}</span>
                        <span className="font-mono-num text-[#E2C88A] font-medium">{item.pct}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-[#080807] overflow-hidden">
                        <div
                          className="h-full transition-all duration-700 ease-out"
                          style={{
                            width: `${item.pct}%`,
                            backgroundColor: item.color,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 text-[11px] text-[#8C877D] leading-relaxed border-t border-white/[0.04]">
                * 机构客户可根据自身风险预算（Risk Budget）与久期偏好进行定制化专户管理。
              </div>

            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
