'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'motion/react';
import { ArrowUpRight, TrendingUp, Shield, BarChart3, Globe, Sparkles, Layers } from 'lucide-react';
import { GLOBAL_MARKETS, MarketIndex } from '@/data/market-data';

export default function Hero() {
  const [activeMarketCategory, setActiveMarketCategory] = useState<'all' | 'indices' | 'commodities' | 'fx'>('all');
  const [marketItems, setMarketItems] = useState<MarketIndex[]>(GLOBAL_MARKETS);
  const [pulseLive, setPulseLive] = useState(true);

  // Subtle real-time fluctuation effect for institutional realism
  useEffect(() => {
    const interval = setInterval(() => {
      setPulseLive((prev) => !prev);
      setMarketItems((prev) =>
        prev.map((item) => {
          // Micro variations
          const microDelta = (Math.random() - 0.48) * 0.04;
          return {
            ...item,
            // Keep formatted display intact while animating pulse
          };
        })
      );
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const filteredMarkets =
    activeMarketCategory === 'all'
      ? marketItems.slice(0, 8)
      : marketItems.filter((m) => m.category === activeMarketCategory);

  return (
    <section
      id="hero-section"
      className="relative min-h-screen w-full flex flex-col justify-between pt-24 pb-12 lg:pb-16 overflow-hidden bg-[#080807]"
    >
      {/* Background Cinematic Panoramic Layer */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero-shanghai.jpg"
          alt="汇澜资本 - 陆家嘴金融中心全景"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center scale-[1.02] transform transition-transform duration-[10000ms] ease-out will-change-transform"
          referrerPolicy="no-referrer"
        />

        {/* Multi-layered cinematic gradient overlays for pristine readability & luxury atmosphere */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#080807]/95 via-[#080807]/65 to-[#080807]/80" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#080807] via-transparent to-[#080807]/70" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_transparent_30%,_rgba(8,8,7,0.85)_100%)]" />

        {/* Architectural warm champagne lighting shimmer */}
        <div className="absolute top-1/4 left-1/3 w-96 h-96 bg-[#C7A66A]/10 rounded-full blur-[140px] pointer-events-none" />
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full my-auto py-8 sm:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Brand Statement & Typography */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 space-y-6 sm:space-y-8"
          >
            {/* Top Sub-tag */}
            <div className="inline-flex items-center space-x-2.5 px-3 py-1 bg-[#171613]/80 border border-[#C7A66A]/30 backdrop-blur-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E2C88A] animate-pulse"></span>
              <span className="text-xs tracking-[0.2em] text-[#E2C88A] font-light">
                汇澜资本 · HUILAN CAPITAL
              </span>
            </div>

            {/* Architectural Main Chinese Headline */}
            <div className="space-y-2 sm:space-y-3">
              <h1 className="font-serif-sc text-4xl sm:text-5xl md:text-6xl lg:text-[68px] leading-[1.15] tracking-wide font-normal text-[#F2EBDD]">
                <span className="block text-transparent bg-clip-text bg-gradient-to-b from-[#FFFFFF] via-[#F2EBDD] to-[#D4C8B2]">
                  连接全球资本
                </span>
                <span className="block text-[#E2C88A]">
                  成就时代价值
                </span>
              </h1>
            </div>

            {/* Supporting Copy */}
            <div className="max-w-xl space-y-2 text-[#8C877D] text-sm sm:text-base leading-relaxed tracking-wider">
              <p className="font-light text-[#F2EBDD]/90">
                汇澜资本，立足中国，布局全球。
              </p>
              <p className="font-light">
                专注于跨周期的价值投资与资产管理，与客户共建可持续的财富未来。
              </p>
            </div>

            {/* CTA Actions */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <Link
                href="/about"
                id="hero-primary-cta"
                className="btn-gold-outline group text-xs sm:text-sm tracking-widest px-6 py-3"
              >
                <span>了解更多</span>
                <span className="ml-2 transform group-hover:translate-x-1 transition-transform">→</span>
              </Link>

              <Link
                href="/strategies"
                id="hero-secondary-cta"
                className="px-6 py-3 border border-white/10 bg-[#171613]/60 hover:bg-[#171613] text-[#8C877D] hover:text-[#F2EBDD] text-xs sm:text-sm tracking-widest transition-all duration-300"
              >
                投资策略
              </Link>
            </div>

            {/* Institutional Trust Badges */}
            <div className="pt-4 grid grid-cols-3 gap-4 border-t border-[#C7A66A]/15 max-w-lg">
              <div>
                <div className="font-mono-num text-lg sm:text-xl font-medium text-[#E2C88A]">4,850+ 亿</div>
                <div className="text-[11px] text-[#8C877D] tracking-wider mt-0.5">管理资产规模 (AUM)</div>
              </div>
              <div>
                <div className="font-mono-num text-lg sm:text-xl font-medium text-[#E2C88A]">14 年</div>
                <div className="text-[11px] text-[#8C877D] tracking-wider mt-0.5">跨周期投资积淀</div>
              </div>
              <div>
                <div className="font-mono-num text-lg sm:text-xl font-medium text-[#E2C88A]">6 大中心</div>
                <div className="text-[11px] text-[#8C877D] tracking-wider mt-0.5">全球金融枢纽</div>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Curved Global Markets Panel */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.4, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div
              id="global-markets-terminal"
              className="relative rounded-none bg-[#11110F]/90 border border-[#C7A66A]/30 backdrop-blur-xl shadow-2xl p-5 sm:p-6 overflow-hidden"
              style={{
                boxShadow: '0 24px 48px -12px rgba(0,0,0,0.85), 0 0 30px -10px rgba(199,166,106,0.15)',
              }}
            >
              {/* Subtle top gold highlight line */}
              <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#E2C88A] to-transparent opacity-70" />

              {/* Terminal Header */}
              <div className="flex items-center justify-between border-b border-[#C7A66A]/15 pb-3.5 mb-3.5">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-[#E2C88A]" />
                  <h3 className="font-serif-sc text-base sm:text-lg font-medium text-[#F2EBDD] tracking-wider">
                    全球市场概览
                  </h3>
                </div>
                <div className="flex items-center space-x-2 text-[11px] font-mono-num text-[#8C877D]">
                  <span className="flex items-center space-x-1">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500/80 animate-ping" />
                    <span className="text-[#C7A66A]">实时基准</span>
                  </span>
                  <span>|</span>
                  <Link href="/markets" className="text-[#8C877D] hover:text-[#E2C88A] transition-colors">
                    进入看板 →
                  </Link>
                </div>
              </div>

              {/* Market Data Rows */}
              <div className="space-y-1.5 max-h-[340px] overflow-y-auto pr-1">
                {filteredMarkets.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2 hover:bg-[#171613] transition-colors border-b border-white/[0.03] group"
                  >
                    {/* Market Name & Code */}
                    <div className="flex flex-col min-w-[100px]">
                      <div className="flex items-center space-x-1.5">
                        <span className="text-xs sm:text-sm text-[#F2EBDD] font-medium tracking-wide">
                          {item.name}
                        </span>
                      </div>
                      <span className="text-[10px] text-[#8C877D] font-mono-num">
                        {item.code}
                      </span>
                    </div>

                    {/* Mini SVG Sparkline */}
                    <div className="hidden sm:block w-16 h-5">
                      <svg className="w-full h-full" viewBox="0 0 60 20">
                        <polyline
                          fill="none"
                          stroke="#C7A66A"
                          strokeWidth="1.2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          points={item.sparkline
                            .map((val, idx) => {
                              const min = Math.min(...item.sparkline);
                              const max = Math.max(...item.sparkline);
                              const normY = 18 - ((val - min) / (max - min || 1)) * 14;
                              const normX = (idx / (item.sparkline.length - 1)) * 56 + 2;
                              return `${normX},${normY}`;
                            })
                            .join(' ')}
                        />
                      </svg>
                    </div>

                    {/* Value & Change */}
                    <div className="text-right">
                      <div className="font-mono-num text-xs sm:text-sm font-medium text-[#F2EBDD]">
                        {item.value}
                      </div>
                      <div
                        className={`font-mono-num text-[11px] font-medium ${
                          item.isPositive ? 'text-[#E2C88A]' : 'text-[#A39E93]'
                        }`}
                      >
                        {item.change}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Terminal Footer */}
              <div className="pt-4 mt-3 border-t border-[#C7A66A]/15 flex items-center justify-between text-[11px] text-[#8C877D] tracking-[0.2em]">
                <span className="text-[#C7A66A] font-light">
                  洞察 · 研究 · 投资 · 未来
                </span>
                <span className="font-mono-num text-[10px] text-[#8C877D]/60">
                  SHANGHAI · GLOBAL DESK
                </span>
              </div>
            </div>
          </motion.div>

        </div>
      </div>

      {/* Bottom Horizontal Institutional Capabilities Bar */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full mt-4 sm:mt-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          <Link
            href="/strategies"
            id="hero-cap-1"
            className="plaque-border p-3 sm:p-4 bg-[#11110F]/80 backdrop-blur-md flex items-center space-x-3 group"
          >
            <div className="p-2 border border-[#C7A66A]/30 text-[#E2C88A] group-hover:bg-[#C7A66A]/10 transition-colors">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-medium text-[#F2EBDD] group-hover:text-[#E2C88A] transition-colors">
                全球资产配置
              </div>
              <div className="text-[10px] text-[#8C877D] tracking-wider">
                跨市场 / 多策略
              </div>
            </div>
          </Link>

          <Link
            href="/strategies"
            id="hero-cap-2"
            className="plaque-border p-3 sm:p-4 bg-[#11110F]/80 backdrop-blur-md flex items-center space-x-3 group"
          >
            <div className="p-2 border border-[#C7A66A]/30 text-[#E2C88A] group-hover:bg-[#C7A66A]/10 transition-colors">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-medium text-[#F2EBDD] group-hover:text-[#E2C88A] transition-colors">
                量化投资
              </div>
              <div className="text-[10px] text-[#8C877D] tracking-wider">
                数据驱动 / 智能决策
              </div>
            </div>
          </Link>

          <Link
            href="/about"
            id="hero-cap-3"
            className="plaque-border p-3 sm:p-4 bg-[#11110F]/80 backdrop-blur-md flex items-center space-x-3 group"
          >
            <div className="p-2 border border-[#C7A66A]/30 text-[#E2C88A] group-hover:bg-[#C7A66A]/10 transition-colors">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-medium text-[#F2EBDD] group-hover:text-[#E2C88A] transition-colors">
                风险管理
              </div>
              <div className="text-[10px] text-[#8C877D] tracking-wider">
                稳健合规 / 长期主义
              </div>
            </div>
          </Link>

          <Link
            href="/clients"
            id="hero-cap-4"
            className="plaque-border p-3 sm:p-4 bg-[#11110F]/80 backdrop-blur-md flex items-center space-x-3 group"
          >
            <div className="p-2 border border-[#C7A66A]/30 text-[#E2C88A] group-hover:bg-[#C7A66A]/10 transition-colors">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-medium text-[#F2EBDD] group-hover:text-[#E2C88A] transition-colors">
                家族办公室
              </div>
              <div className="text-[10px] text-[#8C877D] tracking-wider">
                财富传承 / 代际延续
              </div>
            </div>
          </Link>
        </div>
      </div>
    </section>
  );
}
