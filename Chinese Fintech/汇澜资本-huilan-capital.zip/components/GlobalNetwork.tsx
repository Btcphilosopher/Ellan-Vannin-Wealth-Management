'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { motion } from 'motion/react';
import { Building2, Globe2, MapPin, Clock, Compass, Shield } from 'lucide-react';
import { GLOBAL_HUBS, CityHub } from '@/data/market-data';

export default function GlobalNetwork() {
  const [activeHub, setActiveHub] = useState<CityHub>(GLOBAL_HUBS[0]);
  const [cityTimes, setCityTimes] = useState<Record<string, string>>({});

  // Update local times for global financial centers
  useEffect(() => {
    const updateTimes = () => {
      const times: Record<string, string> = {};
      GLOBAL_HUBS.forEach((hub) => {
        try {
          const formatter = new Intl.DateTimeFormat('zh-CN', {
            timeZone: hub.timezone,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false,
          });
          times[hub.id] = formatter.format(new Date());
        } catch {
          times[hub.id] = '09:00:00';
        }
      });
      setCityTimes(times);
    };

    updateTimes();
    const interval = setInterval(updateTimes, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="global-network-section" className="relative py-28 bg-[#0B0B09] border-t border-[#C7A66A]/15 overflow-hidden">
      {/* Background Architectural Interior */}
      <div className="absolute inset-0 opacity-20 mix-blend-luminosity">
        <Image
          src="/images/hq-architecture.jpg"
          alt="汇澜资本上海总部"
          fill
          sizes="100vw"
          className="object-cover object-center"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0B0B09] via-transparent to-[#0B0B09]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16 space-y-4">
          <div className="flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
            <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
            <span>SHANGHAI HEADQUARTERS & GLOBAL NETWORK</span>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-6">
            <h2 className="font-serif-sc text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F2EBDD]">
              上海 · 中国
            </h2>
            <span className="text-xl sm:text-2xl font-serif-sc text-[#E2C88A]">
              连接中国与世界
            </span>
          </div>
          <p className="text-sm sm:text-base text-[#8C877D] font-light leading-relaxed">
            上海总部位于中国金融旗舰腹地——浦东新区陆家嘴金融中心。我们以此为全球战略枢纽，联动香港、新加坡、伦敦、纽约与苏黎世，为全球资本搭建值得托付的长期桥梁。
          </p>
        </div>

        {/* Global Stylized Map & Hubs Container */}
        <div className="plaque-border bg-[#11110F]/90 p-6 sm:p-10 shadow-2xl backdrop-blur-md">
          
          {/* Stylized SVG Map with Shanghai Central Hub */}
          <div className="relative w-full h-[320px] sm:h-[400px] bg-[#141310] border border-white/[0.04] mb-8 overflow-hidden">
            {/* World Grid Texture */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(199,166,106,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(199,166,106,0.05)_1px,transparent_1px)] bg-[size:3rem_3rem]" />

            {/* SVG Connecting Gold Lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
              {/* Shanghai is at (74, 43) */}
              {GLOBAL_HUBS.filter((h) => h.id !== 'shanghai').map((hub) => (
                <g key={hub.id}>
                  {/* Curved Gold Arc */}
                  <path
                    d={`M 74 43 Q ${(74 + hub.x) / 2} ${(43 + hub.y) / 2 - 15} ${hub.x} ${hub.y}`}
                    fill="none"
                    stroke="#C7A66A"
                    strokeWidth="0.6"
                    strokeDasharray="2 2"
                    className="opacity-60"
                  />
                </g>
              ))}
            </svg>

            {/* Hub Markers on Map */}
            {GLOBAL_HUBS.map((hub) => {
              const isSelected = activeHub.id === hub.id;
              const isHQ = hub.id === 'shanghai';
              return (
                <div
                  key={hub.id}
                  onClick={() => setActiveHub(hub)}
                  style={{ top: `${hub.y}%`, left: `${hub.x}%` }}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group z-20"
                >
                  {/* Pulsing ring */}
                  <div
                    className={`absolute inset-0 rounded-full animate-ping ${
                      isHQ ? 'bg-[#E2C88A]/60' : 'bg-[#C7A66A]/40'
                    }`}
                  />
                  
                  {/* Dot */}
                  <div
                    className={`relative w-4 h-4 rounded-full flex items-center justify-center border transition-all ${
                      isSelected
                        ? 'bg-[#E2C88A] border-white scale-125'
                        : isHQ
                        ? 'bg-[#C7A66A] border-[#E2C88A]'
                        : 'bg-[#171613] border-[#C7A66A]'
                    }`}
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-[#080807]" />
                  </div>

                  {/* City Label Badge */}
                  <div className="absolute top-5 left-1/2 transform -translate-x-1/2 whitespace-nowrap bg-[#171613]/90 border border-[#C7A66A]/30 px-2 py-0.5 text-[10px] text-[#F2EBDD] font-medium tracking-wider group-hover:border-[#E2C88A]">
                    {hub.name} {isHQ && ' (全球总部)'}
                  </div>
                </div>
              );
            })}

            {/* Watermark in corner */}
            <div className="absolute bottom-3 left-4 text-[10px] tracking-widest text-[#8C877D] font-mono-num">
              SHANGHAI FINANCIAL CENTER · GLOBAL COORDINATES
            </div>
          </div>

          {/* Active Hub Details & City Selectors */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Active Hub Card */}
            <div className="lg:col-span-6 bg-[#171613] p-6 border border-[#C7A66A]/30 space-y-4">
              <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 rounded-full bg-[#E2C88A]" />
                  <span className="font-serif-sc text-xl text-[#F2EBDD] font-medium">
                    {activeHub.name} · {activeHub.enName}
                  </span>
                </div>
                <span className="px-2.5 py-0.5 bg-[#C7A66A]/10 border border-[#C7A66A]/40 text-xs font-mono-num text-[#E2C88A]">
                  {activeHub.status}
                </span>
              </div>

              <div className="space-y-3 text-xs">
                <div className="flex items-center space-x-2 text-[#8C877D]">
                  <Clock className="w-4 h-4 text-[#C7A66A]" />
                  <span>当地实时时间: </span>
                  <span className="font-mono-num text-[#E2C88A] font-medium text-sm">
                    {cityTimes[activeHub.id] || '09:00:00'}
                  </span>
                </div>

                <div className="flex items-start space-x-2 text-[#8C877D]">
                  <MapPin className="w-4 h-4 text-[#C7A66A] shrink-0 mt-0.5" />
                  <span className="text-[#F2EBDD]">{activeHub.address}</span>
                </div>

                <div className="flex items-start space-x-2 text-[#8C877D]">
                  <Compass className="w-4 h-4 text-[#C7A66A] shrink-0 mt-0.5" />
                  <span>核心职能: <span className="text-[#F2EBDD]">{activeHub.focus}</span></span>
                </div>
              </div>
            </div>

            {/* Hubs Selector Tabs */}
            <div className="lg:col-span-6 grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {GLOBAL_HUBS.map((hub) => (
                <button
                  key={hub.id}
                  onClick={() => setActiveHub(hub)}
                  className={`p-3 text-left border transition-all ${
                    activeHub.id === hub.id
                      ? 'bg-[#1F1D18] border-[#E2C88A] text-[#F2EBDD]'
                      : 'bg-[#141310] border-white/[0.04] text-[#8C877D] hover:border-[#C7A66A]/30 hover:text-[#F2EBDD]'
                  }`}
                >
                  <div className="text-xs font-medium font-serif-sc">{hub.name}</div>
                  <div className="text-[10px] font-mono-num text-[#8C877D] mt-0.5">{hub.enName}</div>
                  <div className="text-[10px] text-[#C7A66A] mt-2 font-mono-num">
                    {cityTimes[hub.id] || '--:--:--'}
                  </div>
                </button>
              ))}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
