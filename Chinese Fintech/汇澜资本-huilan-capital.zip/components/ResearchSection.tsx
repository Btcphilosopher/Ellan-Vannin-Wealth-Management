'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { motion } from 'motion/react';
import { BookOpen, FileText, Download, ChevronRight, X, ArrowUpRight, Share2 } from 'lucide-react';
import { RESEARCH_ARTICLES, ResearchArticle } from '@/data/research-data';

export default function ResearchSection() {
  const [activeArticle, setActiveArticle] = useState<ResearchArticle | null>(null);
  const featuredArticle = RESEARCH_ARTICLES.find((a) => a.isFeatured) || RESEARCH_ARTICLES[0];
  const otherArticles = RESEARCH_ARTICLES.filter((a) => !a.isFeatured);

  return (
    <section id="research-section" className="relative py-28 bg-[#0B0B09] border-t border-[#C7A66A]/15 overflow-hidden">
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-[#C7A66A]/15 pb-8">
          <div className="space-y-3">
            <div className="flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>HUILAN RESEARCH INSTITUTE</span>
            </div>
            <h2 className="font-serif-sc text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F2EBDD]">
              研究中心 · 智库与市场洞察
            </h2>
          </div>
          <Link
            href="/research"
            className="mt-4 md:mt-0 inline-flex items-center space-x-1.5 text-xs text-[#C7A66A] hover:text-[#E2C88A] tracking-widest font-light transition-colors"
          >
            <span>研报档案库 (全集)</span>
            <ArrowUpRight className="w-4 h-4" />
          </Link>
        </div>

        {/* Featured Article Banner - Chinese Journal Editorial Layout */}
        <div className="mb-14 plaque-border bg-[#141310] p-8 sm:p-12 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-5 text-right font-serif-sc text-8xl pointer-events-none select-none text-[#C7A66A]">
            汇澜智库
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-6">
              <div className="flex flex-wrap items-center gap-3">
                <span className="px-2.5 py-1 bg-[#C7A66A]/15 border border-[#C7A66A]/40 text-[#E2C88A] text-xs tracking-widest font-medium">
                  年度重磅研报 · 首席特辑
                </span>
                <span className="text-xs font-mono-num text-[#8C877D]">
                  {featuredArticle.date}
                </span>
                <span className="text-xs text-[#8C877D]">
                  预计阅读时间 {featuredArticle.readTime}
                </span>
              </div>

              <h3 className="font-serif-sc text-2xl sm:text-3xl md:text-4xl font-normal text-[#F2EBDD] leading-tight group-hover:text-[#E2C88A] transition-colors">
                {featuredArticle.title}
              </h3>

              <div className="text-xs sm:text-sm font-light text-[#C7A66A]/80 tracking-wide font-mono-num">
                {featuredArticle.enTitle}
              </div>

              <p className="text-sm sm:text-base text-[#8C877D] leading-relaxed font-light line-clamp-3">
                {featuredArticle.abstract}
              </p>

              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => setActiveArticle(featuredArticle)}
                  className="btn-gold-solid text-xs tracking-widest px-6 py-2.5"
                >
                  阅读全文 →
                </button>
                <div className="text-xs text-[#8C877D] border-l border-white/10 pl-4 py-1">
                  <span className="text-[#F2EBDD] font-medium">{featuredArticle.author}</span> · {featuredArticle.authorTitle}
                </div>
              </div>
            </div>

            {/* Right Side Stats highlight */}
            <div className="lg:col-span-4 bg-[#171613] p-6 border border-[#C7A66A]/20 space-y-4">
              <div className="text-xs tracking-widest text-[#C7A66A] uppercase font-mono-num">
                KEY HIGHLIGHTS · 核心结论
              </div>
              <div className="space-y-3 text-xs text-[#8C877D] font-light leading-relaxed">
                <div className="p-3 bg-[#11110F] border border-white/[0.04]">
                  <div className="text-[#E2C88A] font-medium mb-1">制造业高端化突破</div>
                  <div>全要素生产率跃迁重构中国核心资产ROE中枢</div>
                </div>
                <div className="p-3 bg-[#11110F] border border-white/[0.04]">
                  <div className="text-[#E2C88A] font-medium mb-1">哑铃型资产配置</div>
                  <div>确定性高股息底仓 + 全球化出海成长进攻矛头</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Editorial Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {otherArticles.map((art, idx) => (
            <motion.div
              key={art.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="plaque-border p-7 bg-[#141310]/90 flex flex-col justify-between group hover:bg-[#1A1814]"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs text-[#8C877D] pb-3 border-b border-white/[0.05]">
                  <span className="text-[#C7A66A] font-medium tracking-wider">{art.category}</span>
                  <span className="font-mono-num">{art.date}</span>
                </div>

                <h4 className="font-serif-sc text-lg sm:text-xl text-[#F2EBDD] font-medium leading-snug group-hover:text-[#E2C88A] transition-colors">
                  {art.title}
                </h4>

                <p className="text-xs text-[#8C877D] leading-relaxed font-light line-clamp-3">
                  {art.abstract}
                </p>
              </div>

              <div className="pt-6 mt-6 border-t border-white/[0.04] flex items-center justify-between">
                <span className="text-[11px] text-[#8C877D]">
                  {art.author}
                </span>
                <button
                  onClick={() => setActiveArticle(art)}
                  className="inline-flex items-center space-x-1 text-xs text-[#C7A66A] group-hover:text-[#E2C88A] tracking-wider font-light transition-colors"
                >
                  <span>阅读全文</span>
                  <ChevronRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>

      </div>

      {/* Article Reader Modal / Drawer */}
      {activeArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-300">
          <div
            className="relative w-full max-w-4xl max-h-[90vh] bg-[#11110F] border border-[#C7A66A]/30 shadow-2xl overflow-y-auto p-6 sm:p-10"
            style={{ boxShadow: '0 25px 60px -15px rgba(0,0,0,0.9), 0 0 40px rgba(199,166,106,0.15)' }}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-[#C7A66A]/20 pb-4 mb-6">
              <div className="flex items-center space-x-2 text-xs text-[#C7A66A] tracking-widest">
                <BookOpen className="w-4 h-4" />
                <span>汇澜资本 · 机构深度研报</span>
              </div>
              <button
                onClick={() => setActiveArticle(null)}
                className="p-1.5 text-[#8C877D] hover:text-[#F2EBDD] bg-[#171613] border border-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Article Content */}
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center space-x-3 text-xs font-mono-num text-[#8C877D]">
                  <span className="text-[#E2C88A] font-medium">{activeArticle.category}</span>
                  <span>·</span>
                  <span>{activeArticle.date}</span>
                  <span>·</span>
                  <span>{activeArticle.readTime} 阅读</span>
                </div>
                <h2 className="font-serif-sc text-2xl sm:text-3xl text-[#F2EBDD] leading-tight">
                  {activeArticle.title}
                </h2>
                <div className="text-xs text-[#C7A66A]/80 font-mono-num">
                  {activeArticle.enTitle}
                </div>
              </div>

              {/* Author Banner */}
              <div className="p-4 bg-[#171613] border-l-2 border-[#C7A66A] flex items-center justify-between">
                <div>
                  <div className="text-xs font-medium text-[#F2EBDD]">{activeArticle.author}</div>
                  <div className="text-[11px] text-[#8C877D]">{activeArticle.authorTitle}</div>
                </div>
                <span className="text-[10px] text-[#8C877D] font-mono-num">PDF: {activeArticle.pdfSize}</span>
              </div>

              {/* Abstract */}
              <div className="p-4 bg-[#141310] border border-white/[0.05] text-xs sm:text-sm text-[#F2EBDD]/90 italic leading-relaxed">
                【摘要】{activeArticle.abstract}
              </div>

              {/* Body Sections */}
              <div className="space-y-6 pt-2">
                {activeArticle.content.map((sec, sIdx) => (
                  <div key={sIdx} className="space-y-3">
                    <h3 className="font-serif-sc text-lg text-[#E2C88A] font-medium">
                      {sec.sectionTitle}
                    </h3>
                    {sec.paragraphs.map((p, pIdx) => (
                      <p key={pIdx} className="text-xs sm:text-sm text-[#8C877D] leading-relaxed font-light">
                        {p}
                      </p>
                    ))}

                    {/* Optional key metrics box */}
                    {sec.keyMetrics && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
                        {sec.keyMetrics.map((m, mIdx) => (
                          <div key={mIdx} className="p-3 bg-[#171613] border border-[#C7A66A]/20">
                            <div className="text-[11px] text-[#8C877D]">{m.label}</div>
                            <div className="font-mono-num text-lg font-medium text-[#E2C88A] my-1">{m.value}</div>
                            <div className="text-[10px] text-[#8C877D]/70">{m.note}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Tags and Close */}
              <div className="pt-6 border-t border-[#C7A66A]/20 flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-2">
                  {activeArticle.tags.map((t) => (
                    <span key={t} className="px-2 py-0.5 bg-[#171613] text-[10px] text-[#8C877D] border border-white/5">
                      #{t}
                    </span>
                  ))}
                </div>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => alert(`《${activeArticle.title}》机构完整白皮书已生成下载索引。`)}
                    className="btn-gold-outline text-xs px-4 py-2"
                  >
                    下载完整研报 (PDF)
                  </button>
                  <button
                    onClick={() => setActiveArticle(null)}
                    className="px-4 py-2 bg-[#171613] text-xs text-[#8C877D] hover:text-[#F2EBDD] transition-colors"
                  >
                    关闭
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}
    </section>
  );
}
