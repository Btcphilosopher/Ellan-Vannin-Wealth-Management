'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { motion } from 'motion/react';
import { Globe2, Cpu, ShieldCheck, Landmark, ChevronRight, CheckCircle2, ArrowRight } from 'lucide-react';
import { INSTITUTIONAL_CAPABILITIES } from '@/data/firm-data';

export default function CapabilityGrid() {
  const [selectedCap, setSelectedCap] = useState<string | null>(null);

  const getIcon = (id: string) => {
    switch (id) {
      case 'global-allocation':
        return <Globe2 className="w-6 h-6 text-[#E2C88A]" />;
      case 'quant-investing':
        return <Cpu className="w-6 h-6 text-[#E2C88A]" />;
      case 'risk-management':
        return <ShieldCheck className="w-6 h-6 text-[#E2C88A]" />;
      case 'family-office':
        return <Landmark className="w-6 h-6 text-[#E2C88A]" />;
      default:
        return <Globe2 className="w-6 h-6 text-[#E2C88A]" />;
    }
  };

  return (
    <section id="capabilities-section" className="relative py-24 bg-[#0B0B09] border-t border-[#C7A66A]/15 overflow-hidden">
      {/* Background Architectural Grid Lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(199,166,106,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(199,166,106,0.03)_1px,transparent_1px)] bg-[size:4rem_4rem] pointer-events-none" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-[#C7A66A]/15 pb-8">
          <div className="space-y-3">
            <div className="flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>INSTITUTIONAL CAPABILITIES</span>
            </div>
            <h2 className="font-serif-sc text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F2EBDD]">
              全球资产配置与投研能力
            </h2>
          </div>
          <div className="mt-4 md:mt-0 max-w-md text-sm text-[#8C877D] font-light leading-relaxed">
            汇澜资本构建覆盖全生命周期与大类资产的系统化投研体系，以严谨的风险预算与跨周期配置逻辑，赋能长线资本。
          </div>
        </div>

        {/* Four Architectural Plaques Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {INSTITUTIONAL_CAPABILITIES.map((cap, idx) => (
            <motion.div
              key={cap.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: idx * 0.15 }}
              className="plaque-border group flex flex-col justify-between p-7 bg-[#141310]/95 hover:bg-[#1A1814] min-h-[380px]"
            >
              <div>
                {/* Top Plaque Header */}
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-white/[0.05]">
                  <div className="p-3 bg-[#1B1915] border border-[#C7A66A]/30 group-hover:border-[#E2C88A] transition-all duration-300">
                    {getIcon(cap.id)}
                  </div>
                  <span className="text-[10px] tracking-widest text-[#C7A66A] font-mono-num uppercase px-2 py-0.5 border border-[#C7A66A]/20">
                    {cap.tag}
                  </span>
                </div>

                {/* Plaque Titles */}
                <div className="space-y-1.5 mb-4">
                  <h3 className="font-serif-sc text-xl text-[#F2EBDD] font-medium group-hover:text-[#E2C88A] transition-colors">
                    {cap.title}
                  </h3>
                  <div className="text-xs text-[#8C877D] tracking-wider font-light">
                    {cap.subtitle}
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-[#8C877D] leading-relaxed mb-6 font-light">
                  {cap.description}
                </p>

                {/* Key Metrics */}
                <div className="grid grid-cols-2 gap-2 pt-3 border-t border-white/[0.04] mb-6">
                  {cap.metrics.map((m, mIdx) => (
                    <div key={mIdx}>
                      <div className="text-[10px] text-[#8C877D]">{m.label}</div>
                      <div className="font-mono-num text-sm text-[#E2C88A] font-medium mt-0.5">{m.value}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom Action */}
              <Link
                href="/strategies"
                className="inline-flex items-center space-x-1.5 text-xs text-[#C7A66A] group-hover:text-[#E2C88A] tracking-widest font-light transition-colors"
              >
                <span>策略详情</span>
                <ChevronRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Bottom Banner */}
        <div className="mt-12 p-6 sm:p-8 bg-[#11110F] border border-[#C7A66A]/20 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center sm:text-left">
            <div className="text-sm font-serif-sc text-[#F2EBDD]">
              定制化机构资产配置委托与专属风险预算方案
            </div>
            <div className="text-xs text-[#8C877D] font-light">
              为全球主权基金、保险资管、养老金与百亿级家族办公室提供专业顾问
            </div>
          </div>
          <Link href="/contact" className="btn-gold-solid whitespace-nowrap text-xs tracking-widest px-6 py-2.5">
            预约机构沟通
          </Link>
        </div>

      </div>
    </section>
  );
}
