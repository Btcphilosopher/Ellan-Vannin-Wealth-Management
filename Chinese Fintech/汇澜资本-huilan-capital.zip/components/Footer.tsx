'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ShieldAlert, FileText, Scale, Landmark, MapPin, Phone, Mail, X } from 'lucide-react';

export default function Footer() {
  const [activeLegalModal, setActiveLegalModal] = useState<string | null>(null);

  const legalModals: Record<string, { title: string; content: string[] }> = {
    privacy: {
      title: '隐私政策 (Privacy Policy)',
      content: [
        '汇澜资本（下称“本机构”）严格遵守《中华人民共和国个人信息保护法》及国际公认的数据合规标准。',
        '我们仅在为您提供机构资产管理、专属投研订阅或客户尽职调查（KYC）所需的最少范围内收集并处理信息。',
        '本机构承诺绝不向任何未经授权的第三方出售、泄露或共享客户隐私与商业机密。所有数字化档案均采用银行级加密存储。',
      ],
    },
    legal: {
      title: '法律声明 (Legal Statements)',
      content: [
        '本网站所刊载的所有内容，包括但不限于文字研报、数据图表、音频视频及商标标识，均受中华人民共和国著作权法及相关国际条约保护。',
        '未经汇澜资本书面正式许可，任何机构或个人不得擅自复制、转载、摘编或用于商业目的。',
        '本网站所载信息仅供参考，不构成任何法律意见、税务建议或要约邀请。',
      ],
    },
    risk: {
      title: '风险提示 (Risk Disclosure)',
      content: [
        '投资有风险，决策须审慎。金融市场价格受宏观经济、货币政策、地缘政治及流动性等多种不可预测因素影响，可能产生波动。',
        '过往投资业绩不预示其未来表现，本机构不承诺或保证任何投资策略或资管计划的最低收益或本金不受损失。',
        '投资者应根据自身的风险承受能力、投资目的及资产流动性需求独立做出投资决策。',
      ],
    },
    investor: {
      title: '投资者关系 (Investor Relations)',
      content: [
        '汇澜资本秉承公开、透明、合规的信托受托人准则。',
        '已签约机构客户可通过专属机构客户网关（Client Portal）查阅经四大会计师事务所审计的季度净值报告、资产穿透持仓及估值对账单。',
        '机构投资者服务专线: +86 (21) 6888-8888 · investor@huilancapital.com',
      ],
    },
  };

  return (
    <>
      <footer
        id="main-footer"
        className="relative bg-[#080807] border-t border-[#C7A66A]/20 pt-20 pb-12 overflow-hidden"
      >
        {/* Animated Gold Horizontal Line at top */}
        <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-[#E2C88A] to-transparent opacity-60" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          {/* Main Footer Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-16 border-b border-white/[0.06]">
            
            {/* Column 1: Brand & Positioning */}
            <div className="lg:col-span-4 space-y-6">
              <div className="flex items-center space-x-3.5">
                {/* Gold Vertical Bars */}
                <div className="flex items-end space-x-1 h-8">
                  <span className="w-1.5 h-4 bg-gradient-to-t from-[#9A7D46] to-[#E2C88A]"></span>
                  <span className="w-1.5 h-7 bg-gradient-to-t from-[#9A7D46] to-[#E2C88A]"></span>
                  <span className="w-1.5 h-5 bg-gradient-to-t from-[#9A7D46] to-[#E2C88A]"></span>
                  <span className="w-1.5 h-6 bg-gradient-to-t from-[#9A7D46] to-[#E2C88A]"></span>
                </div>
                <div>
                  <div className="font-serif-sc text-2xl font-bold tracking-widest text-[#F2EBDD]">
                    汇澜资本
                  </div>
                  <div className="text-[10px] tracking-widest text-[#C7A66A] font-mono-num">
                    HUILAN CAPITAL
                  </div>
                </div>
              </div>

              <p className="text-xs text-[#8C877D] font-light leading-relaxed max-w-sm">
                汇澜资本，立足中国，布局全球。专注于跨周期的价值投资与高端资产管理，与机构及家族客户共建可持续的财富未来。
              </p>

              <div className="pt-2 text-xs tracking-[0.25em] text-[#E2C88A] font-serif-sc">
                全球视野 · 价值共生
              </div>
            </div>

            {/* Column 2: Navigation Links */}
            <div className="lg:col-span-2 space-y-4">
              <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase">
                NAVIGATION · 导航
              </div>
              <ul className="space-y-2.5 text-xs text-[#8C877D] font-light">
                <li>
                  <Link href="/" className="hover:text-[#E2C88A] transition-colors">
                    首页概览
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="hover:text-[#E2C88A] transition-colors">
                    关于我们
                  </Link>
                </li>
                <li>
                  <Link href="/strategies" className="hover:text-[#E2C88A] transition-colors">
                    投资策略
                  </Link>
                </li>
                <li>
                  <Link href="/research" className="hover:text-[#E2C88A] transition-colors">
                    研究中心
                  </Link>
                </li>
                <li>
                  <Link href="/asset-management" className="hover:text-[#E2C88A] transition-colors">
                    资产管理
                  </Link>
                </li>
                <li>
                  <Link href="/clients" className="hover:text-[#E2C88A] transition-colors">
                    客户服务
                  </Link>
                </li>
                <li>
                  <Link href="/markets" className="hover:text-[#E2C88A] transition-colors">
                    市场洞察
                  </Link>
                </li>
              </ul>
            </div>

            {/* Column 3: Global Hubs */}
            <div className="lg:col-span-3 space-y-4">
              <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase">
                GLOBAL HUBS · 全球网络
              </div>
              <div className="space-y-3 text-xs text-[#8C877D] font-light">
                <div>
                  <div className="text-[#F2EBDD] font-medium">上海全球总部 (Shanghai HQ)</div>
                  <div className="text-[11px] text-[#8C877D]">浦东新区陆家嘴金融中心 · 汇澜金融大厦 58-62F</div>
                </div>
                <div>
                  <div className="text-[#F2EBDD] font-medium">香港离岸中心 (Hong Kong)</div>
                  <div className="text-[11px] text-[#8C877D]">中环国际金融中心二期 (IFC) 45F</div>
                </div>
                <div>
                  <div className="text-[#F2EBDD] font-medium">新加坡 / 伦敦 / 纽约 / 苏黎世</div>
                  <div className="text-[11px] text-[#8C877D]">全球联络处与宏观投研常驻代表处</div>
                </div>
              </div>
            </div>

            {/* Column 4: Institutional Contact */}
            <div className="lg:col-span-3 space-y-4">
              <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase">
                INSTITUTIONAL CONTACT · 联络
              </div>
              <div className="space-y-2.5 text-xs text-[#8C877D] font-light">
                <div className="flex items-center space-x-2">
                  <Phone className="w-3.5 h-3.5 text-[#C7A66A]" />
                  <span>总机: +86 (21) 6888-8888</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail className="w-3.5 h-3.5 text-[#C7A66A]" />
                  <span>机构邮箱: contact@huilancapital.com</span>
                </div>
                <div className="pt-2">
                  <Link
                    href="/contact"
                    className="btn-gold-outline w-full text-center text-xs py-2 tracking-widest"
                  >
                    在线预约咨询
                  </Link>
                </div>
              </div>
            </div>

          </div>

          {/* Legal & Compliance Links */}
          <div className="py-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-[#8C877D]">
            <div className="flex flex-wrap items-center gap-6">
              <button
                onClick={() => setActiveLegalModal('privacy')}
                className="hover:text-[#E2C88A] transition-colors"
              >
                隐私政策
              </button>
              <button
                onClick={() => setActiveLegalModal('legal')}
                className="hover:text-[#E2C88A] transition-colors"
              >
                法律声明
              </button>
              <button
                onClick={() => setActiveLegalModal('risk')}
                className="hover:text-[#E2C88A] transition-colors"
              >
                风险提示
              </button>
              <button
                onClick={() => setActiveLegalModal('investor')}
                className="hover:text-[#E2C88A] transition-colors"
              >
                投资者关系
              </button>
            </div>

            <div className="font-mono-num text-[11px] text-[#8C877D]/80">
              沪ICP备20260888号-1 · 中国证券投资基金业协会登记机构
            </div>
          </div>

          {/* Bottom Stamp */}
          <div className="pt-6 border-t border-white/[0.04] text-center">
            <div className="font-serif-sc text-sm sm:text-base tracking-[0.3em] text-[#C7A66A] font-light">
              汇澜资本 · 上海 · 中国
            </div>
            <div className="text-[10px] text-[#8C877D]/60 font-mono-num mt-1">
              © {new Date().getFullYear()} HUILAN CAPITAL LIMITED. ALL RIGHTS RESERVED.
            </div>
          </div>

        </div>
      </footer>

      {/* Compliance / Legal Modal */}
      {activeLegalModal && legalModals[activeLegalModal] && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="bg-[#11110F] border border-[#C7A66A]/40 max-w-lg w-full p-6 sm:p-8 shadow-2xl relative space-y-4">
            <div className="flex items-center justify-between border-b border-[#C7A66A]/20 pb-3">
              <h3 className="font-serif-sc text-lg text-[#E2C88A]">
                {legalModals[activeLegalModal].title}
              </h3>
              <button
                onClick={() => setActiveLegalModal(null)}
                className="text-[#8C877D] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3 text-xs text-[#8C877D] leading-relaxed">
              {legalModals[activeLegalModal].content.map((p, idx) => (
                <p key={idx}>{p}</p>
              ))}
            </div>
            <div className="pt-4 text-right">
              <button
                onClick={() => setActiveLegalModal(null)}
                className="btn-gold-outline text-xs px-5 py-1.5"
              >
                确认并关闭
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
