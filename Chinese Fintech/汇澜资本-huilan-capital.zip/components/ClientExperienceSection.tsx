'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { motion } from 'motion/react';
import { Building, Shield, Landmark, ArrowRight, CheckCircle2, PhoneCall, Mail } from 'lucide-react';

export default function ClientExperienceSection() {
  const [showInquiryModal, setShowInquiryModal] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);

  const services = [
    {
      id: 'institutional',
      title: '机构投资者',
      enTitle: 'INSTITUTIONAL CLIENTS',
      desc: '为全球主权财富基金、养老金、保险资管、银行理财子公司及大学捐赠基金提供覆盖全周期的大类资产配置、专户委托与流动性管理方案。',
      highlights: [
        '严格穿透式风险预算与合规托管',
        '定制化机构专户 (Separately Managed Accounts)',
        '专属宏观投研策略会与季度深度研讨',
      ],
      icon: <Building className="w-6 h-6 text-[#E2C88A]" />,
    },
    {
      id: 'family-wealth',
      title: '家族财富',
      enTitle: 'FAMILY OFFICE & WEALTH',
      desc: '围绕超高净值家族的财富保护、代际平稳传承、跨境信托与长期全球配置，构建高度私密、量身定制的顶层综合家族办公室解决方案。',
      highlights: [
        '离散型信托与跨法域法律税务架构',
        '多代际财富平稳交接与家族宪章',
        '全球顶尖医疗、教育与非金融专属顾问',
      ],
      icon: <Landmark className="w-6 h-6 text-[#E2C88A]" />,
    },
    {
      id: 'corporate-capital',
      title: '企业资本',
      enTitle: 'STRATEGIC CORPORATE CAPITAL',
      desc: '为实体领军企业提供流动性资金管理、汇率与大宗商品风险对冲、产业并购基金发起与跨境战略股权投资等综合资本赋能。',
      highlights: [
        '企业流动资金低波动稳健增值管理',
        '产业链关键卡脖子技术与出海战略并购',
        '产业资本与二级市场双向赋能闭环',
      ],
      icon: <Shield className="w-6 h-6 text-[#E2C88A]" />,
    },
  ];

  return (
    <section id="clients-section" className="relative py-28 bg-[#0B0B09] border-t border-[#C7A66A]/15 overflow-hidden">
      {/* Background radial highlight */}
      <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-[600px] h-[300px] bg-[#C7A66A]/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
          <div className="inline-flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
            <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
            <span>CLIENT PARTNERSHIP</span>
          </div>
          <h2 className="font-serif-sc text-3xl sm:text-4xl md:text-5xl font-normal text-[#F2EBDD]">
            为长期资本建立长期关系
          </h2>
          <p className="text-sm sm:text-base text-[#8C877D] font-light leading-relaxed">
            汇澜资本坚持“受人之托、忠人之事”的信托精神，以绝对的独立性、审慎的职业道德与卓越的专业能力，做客户最长情的财富守护者。
          </p>
        </div>

        {/* 3 Core Client Solutions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {services.map((srv, idx) => (
            <motion.div
              key={srv.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: idx * 0.15 }}
              className="plaque-border p-8 bg-[#141310] flex flex-col justify-between group hover:bg-[#1A1814]"
            >
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-white/[0.05]">
                  <div className="p-3 bg-[#1B1915] border border-[#C7A66A]/30 group-hover:border-[#E2C88A] transition-colors">
                    {srv.icon}
                  </div>
                  <span className="text-[10px] font-mono-num text-[#8C877D] tracking-widest">
                    TIER 0{idx + 1}
                  </span>
                </div>

                <div className="space-y-1">
                  <h3 className="font-serif-sc text-2xl text-[#F2EBDD] font-medium group-hover:text-[#E2C88A] transition-colors">
                    {srv.title}
                  </h3>
                  <div className="text-[11px] font-mono-num text-[#C7A66A] tracking-wider">
                    {srv.enTitle}
                  </div>
                </div>

                <p className="text-xs text-[#8C877D] leading-relaxed font-light">
                  {srv.desc}
                </p>

                <div className="space-y-2.5 pt-4 border-t border-white/[0.04]">
                  {srv.highlights.map((h, hIdx) => (
                    <div key={hIdx} className="flex items-start space-x-2 text-xs text-[#F2EBDD]/80 font-light">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#C7A66A] shrink-0 mt-0.5" />
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-8 mt-8 border-t border-white/[0.04]">
                <Link
                  href="/contact"
                  className="inline-flex items-center space-x-2 text-xs text-[#C7A66A] group-hover:text-[#E2C88A] tracking-widest font-light transition-colors"
                >
                  <span>定制方案沟通</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Center Institutional Call to Action */}
        <div className="text-center pt-8 border-t border-[#C7A66A]/15">
          <Link
            href="/contact"
            id="clients-contact-cta"
            className="btn-gold-solid text-xs sm:text-sm tracking-widest px-8 py-3.5 inline-flex items-center space-x-2"
          >
            <span>预约上海总部机构洽谈</span>
            <span>→</span>
          </Link>
          <div className="text-[11px] text-[#8C877D] mt-3 font-light">
            我们对所有机构咨询与家族委托签署严格国际标准保密协议 (NDA)
          </div>
        </div>

      </div>
    </section>
  );
}
