'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Shield, Compass, Globe, Check, SlidersHorizontal, ArrowUpRight } from 'lucide-react';

export default function Philosophy() {
  const [selectedHorizon, setSelectedHorizon] = useState<10 | 20 | 30>(20);
  const [selectedProfile, setSelectedProfile] = useState<'conservative' | 'allWeather' | 'growth'>('allWeather');

  // Compounding simulation points based on profile
  const returnRates = {
    conservative: 0.065,
    allWeather: 0.098,
    growth: 0.135,
  };

  const initialAmount = 100; // base 100 million
  const rate = returnRates[selectedProfile];

  // Generate data points for chart
  const years = Array.from({ length: selectedHorizon + 1 }, (_, i) => i);
  const chartPoints = years.map((yr) => {
    const val = initialAmount * Math.pow(1 + rate, yr);
    return { year: yr, value: Math.round(val * 10) / 10 };
  });

  const finalValue = chartPoints[chartPoints.length - 1].value;
  const totalMultiple = (finalValue / initialAmount).toFixed(1);

  // SVG Chart Dimensions
  const svgWidth = 650;
  const svgHeight = 240;
  const padding = { top: 20, right: 30, bottom: 40, left: 50 };
  const graphWidth = svgWidth - padding.left - padding.right;
  const graphHeight = svgHeight - padding.top - padding.bottom;

  const maxValue = Math.max(...chartPoints.map((p) => p.value)) * 1.1;
  const minValue = 80;

  const pointsString = chartPoints
    .map((p, idx) => {
      const x = padding.left + (idx / (chartPoints.length - 1)) * graphWidth;
      const y = padding.top + graphHeight - ((p.value - minValue) / (maxValue - minValue)) * graphHeight;
      return `${x},${y}`;
    })
    .join(' ');

  const areaString = `${padding.left},${padding.top + graphHeight} ${pointsString} ${padding.left + graphWidth},${padding.top + graphHeight}`;

  const principles = [
    {
      title: '价值',
      en: 'Intrinsic Value',
      desc: '寻找长期创造真实价值的企业与资产。我们穿透短期市场情绪噪音，以产业资本视角评估底层资产的自由现金流与核心壁垒。',
      icon: <Sparkles className="w-5 h-5 text-[#E2C88A]" />,
    },
    {
      title: '纪律',
      en: 'Fiduciary Discipline',
      desc: '以严格的风险控制为投资决策的重要基础。将资本安全置于首位，构建全天候回撤隔离机制与独立风险预算体系。',
      icon: <Shield className="w-5 h-5 text-[#E2C88A]" />,
    },
    {
      title: '耐心',
      en: 'Patience & Compound',
      desc: '以跨周期视角理解资本与经济演进。我们相信时间的复利效应，耐受短期波动以获取非线性增长收益。',
      icon: <Compass className="w-5 h-5 text-[#E2C88A]" />,
    },
    {
      title: '全球',
      en: 'Global Synergy',
      desc: '连接中国与全球资本市场。立足中国产业升级优势，深度协同欧美及离岸金融枢纽的资源与流动性。',
      icon: <Globe className="w-5 h-5 text-[#E2C88A]" />,
    },
  ];

  return (
    <section id="philosophy-section" className="relative py-28 bg-[#080807] overflow-hidden border-t border-[#C7A66A]/15">
      {/* Subtle background glow */}
      <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] bg-[#C7A66A]/5 rounded-full blur-[160px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-20 space-y-4">
          <div className="flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
            <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
            <span>INVESTMENT PHILOSOPHY</span>
          </div>
          <h2 className="font-serif-sc text-3xl sm:text-4xl md:text-5xl lg:text-[54px] font-normal leading-tight text-[#F2EBDD]">
            长期主义，是资本穿越周期的力量
          </h2>
          <p className="text-base sm:text-lg text-[#8C877D] font-light leading-relaxed pt-2">
            我们不预测短期市场涨跌，而是将资本配置在人类社会演进中最具确定性、具备持久护城河的高生产力资产上。
          </p>
        </div>

        {/* Institutional Research Visualization & Compounding Chart */}
        <div className="mb-20 p-6 sm:p-10 bg-[#11110F] border border-[#C7A66A]/20 shadow-2xl">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-[#C7A66A]/15">
            <div>
              <div className="text-xs tracking-widest text-[#C7A66A] font-mono-num uppercase mb-1">
                INSTITUTIONAL COMPOUNDING MODEL · 跨周期复利推演
              </div>
              <div className="text-lg font-serif-sc text-[#F2EBDD]">
                多周期风险调整后资本累积轨迹
              </div>
            </div>

            {/* Interactive Horizon & Profile Controls */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center space-x-1 bg-[#171613] p-1 border border-white/[0.08]">
                <span className="text-[11px] text-[#8C877D] px-2">周期:</span>
                {[10, 20, 30].map((h) => (
                  <button
                    key={h}
                    onClick={() => setSelectedHorizon(h as any)}
                    className={`px-3 py-1 text-xs font-mono-num transition-colors ${
                      selectedHorizon === h
                        ? 'bg-[#C7A66A] text-[#080807] font-semibold'
                        : 'text-[#8C877D] hover:text-[#F2EBDD]'
                    }`}
                  >
                    {h} 年
                  </button>
                ))}
              </div>

              <div className="flex items-center space-x-1 bg-[#171613] p-1 border border-white/[0.08]">
                <span className="text-[11px] text-[#8C877D] px-2">组合策略:</span>
                {[
                  { key: 'conservative', label: '稳健固收+' },
                  { key: 'allWeather', label: '全天候多资产' },
                  { key: 'growth', label: '进取权益' },
                ].map((item) => (
                  <button
                    key={item.key}
                    onClick={() => setSelectedProfile(item.key as any)}
                    className={`px-3 py-1 text-xs transition-colors ${
                      selectedProfile === item.key
                        ? 'bg-[#C7A66A] text-[#080807] font-medium'
                        : 'text-[#8C877D] hover:text-[#F2EBDD]'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Chart Display & Stats Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mt-6">
            
            {/* SVG Interactive Line Visualization */}
            <div className="lg:col-span-8 w-full overflow-x-auto">
              <div className="min-w-[500px]">
                <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto">
                  {/* Grid Lines */}
                  {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
                    const y = padding.top + graphHeight * ratio;
                    return (
                      <g key={ratio}>
                        <line
                          x1={padding.left}
                          y1={y}
                          x2={padding.left + graphWidth}
                          y2={y}
                          stroke="rgba(199, 166, 106, 0.08)"
                          strokeDasharray="4 4"
                        />
                      </g>
                    );
                  })}

                  {/* Area Fill */}
                  <polygon points={areaString} fill="url(#goldGradient)" opacity="0.18" />

                  {/* Line Stroke */}
                  <polyline
                    points={pointsString}
                    fill="none"
                    stroke="#C7A66A"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />

                  {/* Data Points */}
                  {chartPoints.map((p, idx) => {
                    if (idx % Math.ceil(chartPoints.length / 6) === 0 || idx === chartPoints.length - 1) {
                      const x = padding.left + (idx / (chartPoints.length - 1)) * graphWidth;
                      const y =
                        padding.top +
                        graphHeight -
                        ((p.value - minValue) / (maxValue - minValue)) * graphHeight;
                      return (
                        <g key={idx}>
                          <circle cx={x} cy={y} r="4" fill="#E2C88A" stroke="#080807" strokeWidth="2" />
                          <text
                            x={x}
                            y={y - 10}
                            textAnchor="middle"
                            fill="#E2C88A"
                            fontSize="10"
                            fontFamily="SF Pro Text, monospace"
                          >
                            ¥{p.value}M
                          </text>
                          <text
                            x={x}
                            y={padding.top + graphHeight + 20}
                            textAnchor="middle"
                            fill="#8C877D"
                            fontSize="10"
                            fontFamily="SF Pro Text, monospace"
                          >
                            {p.year}年
                          </text>
                        </g>
                      );
                    }
                    return null;
                  })}

                  {/* Gradients */}
                  <defs>
                    <linearGradient id="goldGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#E2C88A" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#C7A66A" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
            </div>

            {/* Results Sidebar */}
            <div className="lg:col-span-4 bg-[#171613] p-6 border border-[#C7A66A]/20 space-y-4">
              <div className="text-xs text-[#8C877D] tracking-wider">
                基于 1.0 亿元初始机构本金
              </div>
              <div>
                <div className="text-[11px] text-[#8C877D]">期末预估资产规模</div>
                <div className="font-mono-num text-3xl font-medium text-[#E2C88A] mt-1">
                  ¥ {finalValue} <span className="text-base text-[#F2EBDD]">亿元</span>
                </div>
                <div className="text-xs text-[#C7A66A] mt-1 font-mono-num">
                  累积增值倍数: +{totalMultiple}x
                </div>
              </div>

              <div className="pt-4 border-t border-white/[0.06] space-y-2 text-xs text-[#8C877D] font-light leading-relaxed">
                <div className="flex items-center justify-between">
                  <span>复合预期年化回报:</span>
                  <span className="font-mono-num text-[#F2EBDD] font-medium">{(rate * 100).toFixed(1)}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>最大历史回撤控制:</span>
                  <span className="font-mono-num text-[#F2EBDD] font-medium">
                    {selectedProfile === 'conservative' ? '< 3.2%' : selectedProfile === 'allWeather' ? '< 5.8%' : '< 11.5%'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Sharpe Ratio:</span>
                  <span className="font-mono-num text-[#F2EBDD] font-medium">
                    {selectedProfile === 'conservative' ? '1.82' : selectedProfile === 'allWeather' ? '1.64' : '1.38'}
                  </span>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* 4 Core Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {principles.map((item, idx) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: idx * 0.12 }}
              className="plaque-border p-7 bg-[#141310]/80 group"
            >
              <div className="flex items-center justify-between mb-6 pb-3 border-b border-white/[0.04]">
                <div className="p-2.5 bg-[#1B1915] border border-[#C7A66A]/20">
                  {item.icon}
                </div>
                <span className="font-mono-num text-xs text-[#8C877D] tracking-widest">
                  0{idx + 1}
                </span>
              </div>

              <h3 className="font-serif-sc text-2xl text-[#F2EBDD] mb-1 group-hover:text-[#E2C88A] transition-colors">
                {item.title}
              </h3>
              <div className="text-[11px] font-mono-num text-[#C7A66A] tracking-wider mb-4 uppercase">
                {item.en}
              </div>

              <p className="text-xs text-[#8C877D] leading-relaxed font-light">
                {item.desc}
              </p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
