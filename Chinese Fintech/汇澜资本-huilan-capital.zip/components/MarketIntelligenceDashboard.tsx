'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { LineChart, ArrowUpRight, TrendingUp, TrendingDown, Clock, RefreshCw, BarChart2, Globe } from 'lucide-react';
import { GLOBAL_MARKETS, MarketIndex } from '@/data/market-data';

export default function MarketIntelligenceDashboard() {
  const [activeTab, setActiveTab] = useState<'all' | 'indices' | 'commodities' | 'fx' | 'bonds'>('all');
  const [selectedAsset, setSelectedAsset] = useState<MarketIndex>(GLOBAL_MARKETS[0]);
  const [timeframe, setTimeframe] = useState<'1D' | '5D' | '1M' | '1Y' | '5Y'>('1M');

  const filteredAssets =
    activeTab === 'all'
      ? GLOBAL_MARKETS
      : GLOBAL_MARKETS.filter((item) => item.category === activeTab);

  // Generate deterministic chart data based on timeframe & selected asset using mathematical sinusoidal series
  const chartData = React.useMemo(() => {
    const pointsCount = timeframe === '1D' ? 24 : timeframe === '5D' ? 30 : timeframe === '1M' ? 30 : timeframe === '1Y' ? 36 : 40;
    const base = selectedAsset.numericValue;
    const data: { label: string; price: number; high: number; low: number }[] = [];

    const startFactor = timeframe === '5Y' ? 0.72 : timeframe === '1Y' ? 0.88 : 0.96;
    for (let i = 0; i < pointsCount; i++) {
      const progress = i / (pointsCount - 1);
      const wave1 = Math.sin(i * 0.8) * 0.02;
      const wave2 = Math.cos(i * 1.4) * 0.015;
      const upwardTrend = startFactor + progress * (1 - startFactor);
      const price = base * (upwardTrend + wave1 + wave2);
      const roundedPrice = Math.round(price * 100) / 100;
      data.push({
        label: `${i + 1}`,
        price: i === pointsCount - 1 ? base : roundedPrice,
        high: Math.round((roundedPrice + base * 0.004) * 100) / 100,
        low: Math.round((roundedPrice - base * 0.004) * 100) / 100,
      });
    }
    return data;
  }, [selectedAsset, timeframe]);
  const minPrice = Math.min(...chartData.map((d) => d.low)) * 0.995;
  const maxPrice = Math.max(...chartData.map((d) => d.high)) * 1.005;

  const svgWidth = 700;
  const svgHeight = 260;
  const padding = { top: 20, right: 30, bottom: 35, left: 60 };
  const graphWidth = svgWidth - padding.left - padding.right;
  const graphHeight = svgHeight - padding.top - padding.bottom;

  const pointsString = chartData
    .map((d, i) => {
      const x = padding.left + (i / (chartData.length - 1)) * graphWidth;
      const y = padding.top + graphHeight - ((d.price - minPrice) / (maxPrice - minPrice || 1)) * graphHeight;
      return `${x},${y}`;
    })
    .join(' ');

  const areaString = `${padding.left},${padding.top + graphHeight} ${pointsString} ${padding.left + graphWidth},${padding.top + graphHeight}`;

  return (
    <section id="markets-dashboard-section" className="relative py-28 bg-[#080807] border-t border-[#C7A66A]/15 overflow-hidden">
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 border-b border-[#C7A66A]/15 pb-8">
          <div className="space-y-3">
            <div className="flex items-center space-x-2 text-xs tracking-[0.25em] text-[#C7A66A] font-light">
              <span className="w-1.5 h-1.5 bg-[#C7A66A]"></span>
              <span>GLOBAL MARKET INTELLIGENCE</span>
            </div>
            <h2 className="font-serif-sc text-3xl sm:text-4xl lg:text-5xl font-normal text-[#F2EBDD]">
              全球市场洞察与行情看板
            </h2>
          </div>
          <div className="mt-4 md:mt-0 flex items-center space-x-3 text-xs text-[#8C877D]">
            <div className="flex items-center space-x-1.5 px-3 py-1 bg-[#171613] border border-white/[0.08]">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>全球行情数据流正常</span>
            </div>
          </div>
        </div>

        {/* Dashboard Frame */}
        <div className="plaque-border bg-[#11110F] p-6 sm:p-10 shadow-2xl">
          
          {/* Top Asset Category Selector */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-white/[0.06]">
            <div className="flex flex-wrap items-center gap-2">
              {[
                { key: 'all', label: '全部标的' },
                { key: 'indices', label: '主要股指' },
                { key: 'commodities', label: '大宗商品' },
                { key: 'fx', label: '外汇汇率' },
                { key: 'bonds', label: '利率国债' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`px-4 py-1.5 text-xs transition-colors ${
                    activeTab === tab.key
                      ? 'bg-[#C7A66A] text-[#080807] font-semibold'
                      : 'bg-[#171613] text-[#8C877D] hover:text-[#F2EBDD] border border-white/[0.04]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Timeframe selector */}
            <div className="flex items-center space-x-1 bg-[#171613] p-1 border border-white/[0.08]">
              {(['1D', '5D', '1M', '1Y', '5Y'] as const).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-2.5 py-1 text-xs font-mono-num transition-colors ${
                    timeframe === tf
                      ? 'bg-[#E2C88A] text-[#080807] font-medium'
                      : 'text-[#8C877D] hover:text-[#F2EBDD]'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>

          {/* Main Chart and Details Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mt-6">
            
            {/* Interactive SVG Chart Area */}
            <div className="lg:col-span-8 space-y-4">
              
              {/* Selected Asset Header Bar */}
              <div className="flex flex-wrap items-center justify-between bg-[#171613] p-4 border border-[#C7A66A]/20">
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <span className="font-serif-sc text-xl text-[#F2EBDD] font-medium">
                      {selectedAsset.name}
                    </span>
                    <span className="text-xs font-mono-num text-[#8C877D]">
                      ({selectedAsset.code})
                    </span>
                  </div>
                  <div className="text-[11px] text-[#C7A66A] font-mono-num">
                    {selectedAsset.enName}
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-mono-num text-2xl font-medium text-[#E2C88A]">
                    {selectedAsset.value}
                  </div>
                  <div
                    className={`font-mono-num text-xs font-medium ${
                      selectedAsset.isPositive ? 'text-[#E2C88A]' : 'text-[#8C877D]'
                    }`}
                  >
                    {selectedAsset.change} (今日波动)
                  </div>
                </div>
              </div>

              {/* Chart SVG */}
              <div className="w-full overflow-x-auto bg-[#141310] p-4 border border-white/[0.04]">
                <div className="min-w-[540px]">
                  <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto">
                    {/* Horizontal Grid */}
                    {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
                      const y = padding.top + graphHeight * ratio;
                      const priceVal = maxPrice - (maxPrice - minPrice) * ratio;
                      return (
                        <g key={ratio}>
                          <line
                            x1={padding.left}
                            y1={y}
                            x2={padding.left + graphWidth}
                            y2={y}
                            stroke="rgba(199, 166, 106, 0.08)"
                            strokeDasharray="4 4"
                          />
                          <text
                            x={padding.left - 8}
                            y={y + 4}
                            textAnchor="end"
                            fill="#8C877D"
                            fontSize="10"
                            fontFamily="monospace"
                          >
                            {priceVal > 1000 ? priceVal.toFixed(0) : priceVal.toFixed(2)}
                          </text>
                        </g>
                      );
                    })}

                    {/* Area under curve */}
                    <polygon points={areaString} fill="url(#chartGoldGrad)" opacity="0.15" />

                    {/* Primary Line */}
                    <polyline
                      points={pointsString}
                      fill="none"
                      stroke="#C7A66A"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />

                    {/* Current latest price indicator dot */}
                    {chartData.length > 0 && (
                      <g>
                        <circle
                          cx={padding.left + graphWidth}
                          cy={
                            padding.top +
                            graphHeight -
                            ((chartData[chartData.length - 1].price - minPrice) / (maxPrice - minPrice || 1)) *
                              graphHeight
                          }
                          r="4"
                          fill="#E2C88A"
                          stroke="#080807"
                          strokeWidth="2"
                        />
                      </g>
                    )}

                    <defs>
                      <linearGradient id="chartGoldGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#E2C88A" stopOpacity="0.4" />
                        <stop offset="100%" stopColor="#C7A66A" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>
              </div>

              {/* Day Range Statistics */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 bg-[#171613] border border-white/[0.04]">
                  <div className="text-[10px] text-[#8C877D]">今日最高</div>
                  <div className="font-mono-num text-sm text-[#F2EBDD] font-medium mt-0.5">
                    {selectedAsset.high}
                  </div>
                </div>
                <div className="p-3 bg-[#171613] border border-white/[0.04]">
                  <div className="text-[10px] text-[#8C877D]">今日最低</div>
                  <div className="font-mono-num text-sm text-[#F2EBDD] font-medium mt-0.5">
                    {selectedAsset.low}
                  </div>
                </div>
                <div className="p-3 bg-[#171613] border border-white/[0.04]">
                  <div className="text-[10px] text-[#8C877D]">市场活跃度 / 成交量</div>
                  <div className="font-mono-num text-sm text-[#E2C88A] font-medium mt-0.5">
                    {selectedAsset.volume}
                  </div>
                </div>
              </div>
            </div>

            {/* Right Asset List Table */}
            <div className="lg:col-span-4 bg-[#141310] border border-[#C7A66A]/20 p-4 space-y-2 max-h-[480px] overflow-y-auto">
              <div className="text-xs text-[#8C877D] tracking-widest font-mono-num uppercase pb-2 border-b border-white/[0.06]">
                SELECT ASSET · 选择资产标的
              </div>
              {filteredAssets.map((asset) => {
                const isCurrent = asset.id === selectedAsset.id;
                return (
                  <button
                    key={asset.id}
                    onClick={() => setSelectedAsset(asset)}
                    className={`w-full text-left p-3 border transition-colors flex items-center justify-between ${
                      isCurrent
                        ? 'bg-[#1F1D18] border-[#C7A66A] shadow'
                        : 'bg-[#11110F] border-white/[0.03] hover:border-[#C7A66A]/40'
                    }`}
                  >
                    <div>
                      <div className={`text-xs font-serif-sc font-medium ${isCurrent ? 'text-[#E2C88A]' : 'text-[#F2EBDD]'}`}>
                        {asset.name}
                      </div>
                      <div className="text-[10px] font-mono-num text-[#8C877D]">
                        {asset.code}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono-num text-xs font-medium text-[#F2EBDD]">
                        {asset.value}
                      </div>
                      <div
                        className={`font-mono-num text-[11px] ${
                          asset.isPositive ? 'text-[#E2C88A]' : 'text-[#8C877D]'
                        }`}
                      >
                        {asset.change}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
