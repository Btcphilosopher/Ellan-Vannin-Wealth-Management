/**
 * Express Backend Server for China Credit Risk Platform
 * 中国银行间市场信用衍生品与风险管理工作站 - 核心API与实时行情服务
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { ALL_ENTITIES, INITIAL_CDS_TRADES, INITIAL_COUNTERPARTIES, INITIAL_RISK_LIMITS } from './src/lib/syntheticData';
import { calculateCDSPricer, bootstrapHazardCurve, calculatePortfolioRiskMetrics } from './src/lib/mathEngine';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // 1. API Routes
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      system: '中国银行间市场信用违约互换与风险管理工作站数字孪生系统',
      environment: '模拟环境 · SYNTHETIC MARKET · 非真实交易',
      timestamp: new Date().toISOString(),
    });
  });

  // Market Overview API
  app.get('/api/market/overview', (req, res) => {
    const totalEntities = ALL_ENTITIES.length;
    const sortedSpreads = [...ALL_ENTITIES].map(e => e.spread5Y).sort((a,b) => a - b);
    const medianSpread = sortedSpreads[Math.floor(sortedSpreads.length / 2)];
    const avgPD = (ALL_ENTITIES.reduce((sum, e) => sum + e.pd5Y, 0) / totalEntities).toFixed(2);

    res.json({
      totalNotionalNominal: '¥ 5,842.6 亿',
      cds5YMedianSpreadBp: `${medianSpread} bp`,
      crmwActiveVolume: '¥ 1,284.3 亿',
      marketTurnover24h: '¥ 428.6 亿',
      avgImpliedPD: `${avgPD}%`,
      portfolioCVA: '¥ 12.84 亿',
      entitiesCount: totalEntities,
    });
  });

  // Reference Entities API
  app.get('/api/entities', (req, res) => {
    const { sector, rating, search } = req.query;
    let list = ALL_ENTITIES;

    if (sector && sector !== '全部') {
      list = list.filter(e => e.sector === sector);
    }
    if (rating && rating !== '全部') {
      list = list.filter(e => e.rating === rating);
    }
    if (search) {
      const q = String(search).toLowerCase();
      list = list.filter(e => e.name.toLowerCase().includes(q) || e.code.toLowerCase().includes(q));
    }

    res.json(list);
  });

  // CDS Quantitative Pricing Calculator API
  app.post('/api/pricing/cds', (req, res) => {
    const {
      notional = 100000000,
      tenorYears = 5,
      fixedCouponBp = 100,
      marketSpreadBp = 186.4,
      recoveryRate = 0.40,
      direction = '买入保护'
    } = req.body;

    const output = calculateCDSPricer({
      notional: Number(notional),
      tenorYears: Number(tenorYears),
      fixedCouponBp: Number(fixedCouponBp),
      marketSpreadBp: Number(marketSpreadBp),
      recoveryRate: Number(recoveryRate),
      direction,
    });

    res.json(output);
  });

  // Hazard Curve Bootstrapping API
  app.post('/api/curves/bootstrap', (req, res) => {
    const {
      tenors = [1, 2, 3, 5, 7, 10],
      spreads = [100, 120, 145, 186, 220, 260],
      recoveryRate = 0.40
    } = req.body;

    const curve = bootstrapHazardCurve(tenors, spreads, recoveryRate);
    res.json(curve);
  });

  // Real-time Market Ticks SSE Broadcast endpoint
  app.get('/api/market/ticks/stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const interval = setInterval(() => {
      const randomIdx = Math.floor(Math.random() * ALL_ENTITIES.length);
      const entity = ALL_ENTITIES[randomIdx];
      const deltaBp = (Math.random() - 0.48) * 3;
      const newSpread = Math.max(10, Number((entity.spread5Y + deltaBp).toFixed(1)));

      const tick = {
        timestamp: new Date().toLocaleTimeString('zh-CN', { hour12: false }),
        entityId: entity.id,
        entityName: entity.name,
        spread5Y: newSpread,
        bidSpread: Number((newSpread - 1.5).toFixed(1)),
        askSpread: Number((newSpread + 1.5).toFixed(1)),
        changeBp: Number(deltaBp.toFixed(1)),
        volume: Math.floor(Math.random() * 500) + 50,
      };

      res.write(`data: ${JSON.stringify(tick)}\n\n`);
    }, 2500);

    req.on('close', () => {
      clearInterval(interval);
    });
  });

  // Vite Middleware integration for dev or static serving for prod
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[China Credit Risk Platform] Workstation Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start workstation server:', err);
});
