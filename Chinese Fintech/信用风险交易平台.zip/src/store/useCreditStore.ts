/**
 * China Credit Risk Platform - Global State Management Store
 * 中国银行间信用风险交易平台 - Zustand 状态管理与核心金融引擎 Bus
 */

import { create } from 'zustand';
import {
  ALL_ENTITIES,
  INITIAL_CDS_INDICES,
  INITIAL_CDS_TRADES,
  INITIAL_COUNTERPARTIES,
  INITIAL_CRMA_TRADES,
  INITIAL_CRMW_INSTRUMENTS,
  INITIAL_CLN_INSTRUMENTS,
  INITIAL_MARGIN_COLLATERALS,
  INITIAL_RISK_LIMITS,
  INITIAL_STRESS_SCENARIOS,
} from '../lib/syntheticData';
import {
  CDSTrade,
  CDSIndex,
  CLNInstrument,
  Counterparty,
  CreditEvent,
  CRMATrade,
  CRMWInstrument,
  MarginCollateral,
  MarketTick,
  PortfolioMetrics,
  PortfolioPosition,
  RatingType,
  ReferenceEntity,
  RiskLimit,
  SectorType,
  StressScenario,
  StressTestResult,
  TradeStatus,
  AuditEvent,
} from '../types';
import { calculateCDSPricer, calculatePortfolioRiskMetrics } from '../lib/mathEngine';

interface CreditState {
  // Navigation & UI
  activeTab: string;
  theme: 'dark' | 'light';
  isCommandPaletteOpen: boolean;
  
  // Market & Entity State
  entities: ReferenceEntity[];
  selectedEntityId: string;
  marketTicks: MarketTick[];
  cdsIndices: CDSIndex[];
  
  // Trades & Instruments
  cdsTrades: CDSTrade[];
  crmwInstruments: CRMWInstrument[];
  crmaTrades: CRMATrade[];
  clnInstruments: CLNInstrument[];
  
  // Counterparties & Risk Limits
  counterparties: Counterparty[];
  riskLimits: RiskLimit[];
  marginCollaterals: MarginCollateral[];
  
  // Events & Audit
  creditEvents: CreditEvent[];
  auditLogs: AuditEvent[];
  
  // Stress Testing & What-If
  stressScenarios: StressScenario[];
  activeStressResult: StressTestResult | null;
  
  // Market Playback
  playbackDate: string;
  isPlayingPlayback: boolean;
  playbackSpeed: 1 | 5 | 20;

  // Real-time engine status
  isCrisisMode: boolean;
  lastTickTimestamp: string;

  // Core Actions
  setActiveTab: (tab: string) => void;
  toggleTheme: () => void;
  setCommandPaletteOpen: (open: boolean) => void;
  selectEntity: (id: string) => void;

  // Trading Actions
  createCDSTrade: (input: Partial<CDSTrade>) => CDSTrade;
  approveTrade: (tradeId: string, role: string) => void;
  createCRMWInstrument: (crmw: Partial<CRMWInstrument>) => void;

  // Quantitative Actions
  recalculatePortfolioMetrics: () => PortfolioMetrics;
  triggerCreditEvent: (entityId: string, eventType: string, description: string) => void;
  runStressTest: (scenarioId: string) => StressTestResult;
  startCreditCrisis: () => void;
  runWhatIfSimulation: (
    spreadShift: number,
    recoveryNew: number,
    downgrade: boolean,
    defaultCount: number
  ) => { loss: number; cvaChange: number; var95: number; es95: number; breachedLimits: number };

  // Playback Actions
  setPlaybackDate: (date: string) => void;
  togglePlayback: () => void;
  setPlaybackSpeed: (speed: 1 | 5 | 20) => void;

  // Curve editing
  updateEntitySpreadAndRecalculate: (entityId: string, newSpread5Y: number, newRecovery?: number) => void;
  triggerMarketTick: () => void;
}

const INITIAL_AUDIT_LOGS: AuditEvent[] = [
  { id: 'AUD-001', timestamp: '2026-09-21 09:15:22', user: '张立 (交易员 TRD-004)', action: '创建CDS交易询价', target: '华东制造控股 5Y CDS (名义本金 5亿元)', oldValue: '-', newValue: '待审批', ipAddress: '10.24.180.45', riskStatus: '正常', approvalStatus: '通过' },
  { id: 'AUD-002', timestamp: '2026-09-21 09:18:40', user: '陈浩 (风控主管 RSK-001)', action: '风控限额自动校验', target: '南方地产集团 敞口限额', oldValue: '2.85亿元', newValue: '超限警报 (95%)', ipAddress: '10.24.180.12', riskStatus: '预警', approvalStatus: '需要特批' },
  { id: 'AUD-003', timestamp: '2026-09-21 09:25:05', user: '系统自动化引擎 Engine-01', action: '执行市场利差 Tick 重估', target: '100个中国银行间参考实体', oldValue: '昨日收盘利差', newValue: '实时模拟Tick数据', ipAddress: '127.0.0.1', riskStatus: '正常', approvalStatus: '已同步' }
];

const INITIAL_CREDIT_EVENTS: CreditEvent[] = [
  {
    id: 'EVT-001', eventNo: 'CE20260812001', entityId: 'RE-3002', entityName: '深港商业置业控股',
    eventType: '债务重组', declaredDate: '2026-08-12', effectiveDate: '2026-08-15',
    description: '深港商业置业发布债务重组公告，拟对15亿元22深港置业MTN001进行展期及降息安排。',
    estimatedRecovery: 28, affectedNotional: 450000000, affectedTradeCount: 3, pnlImpact: -32500000,
    status: '理赔计算中', auditLogId: 'AUD-002'
  }
];

export const useCreditStore = create<CreditState>((set, get) => ({
  activeTab: '总览',
  theme: 'dark',
  isCommandPaletteOpen: false,

  entities: ALL_ENTITIES,
  selectedEntityId: 'RE-2001',
  marketTicks: [],
  cdsIndices: INITIAL_CDS_INDICES,

  cdsTrades: INITIAL_CDS_TRADES,
  crmwInstruments: INITIAL_CRMW_INSTRUMENTS,
  crmaTrades: INITIAL_CRMA_TRADES,
  clnInstruments: INITIAL_CLN_INSTRUMENTS,

  counterparties: INITIAL_COUNTERPARTIES,
  riskLimits: INITIAL_RISK_LIMITS,
  marginCollaterals: INITIAL_MARGIN_COLLATERALS,

  creditEvents: INITIAL_CREDIT_EVENTS,
  auditLogs: INITIAL_AUDIT_LOGS,

  stressScenarios: INITIAL_STRESS_SCENARIOS,
  activeStressResult: null,

  playbackDate: '2026-09-21',
  isPlayingPlayback: false,
  playbackSpeed: 1,

  isCrisisMode: false,
  lastTickTimestamp: new Date().toLocaleTimeString('zh-CN', { hour12: false }),

  setActiveTab: (tab) => set({ activeTab: tab }),
  toggleTheme: () => set((state) => ({ theme: state.theme === 'dark' ? 'light' : 'dark' })),
  setCommandPaletteOpen: (open) => set({ isCommandPaletteOpen: open }),
  selectEntity: (id) => set({ selectedEntityId: id }),

  createCDSTrade: (input) => {
    const state = get();
    const entity = state.entities.find((e) => e.id === input.referenceEntityId) || state.entities[0];
    const tradeNo = `CDS${new Date().toISOString().slice(0,10).replace(/-/g,'')}${Math.floor(1000 + Math.random() * 9000)}`;
    
    const notional = input.notional || 100000000;
    const tenor = input.tenor || '5Y';
    const tenorYears = parseInt(tenor.replace('Y',''), 10) || 5;
    const fixedCoupon = input.fixedCoupon || entity.spread5Y;
    const recoveryRate = input.recoveryRate || entity.recoveryRate;
    const direction = input.direction || '买入保护';

    const pricing = calculateCDSPricer({
      notional,
      tenorYears,
      fixedCouponBp: fixedCoupon,
      marketSpreadBp: entity.spread5Y,
      recoveryRate: recoveryRate / 100,
      direction,
    });

    const newTrade: CDSTrade = {
      id: `TRD-${Date.now()}`,
      tradeNo,
      tradeType: 'CDS',
      direction,
      referenceEntityId: entity.id,
      referenceEntityName: entity.name,
      referenceObligationId: entity.obligations[0]?.id || 'OBL-GENERIC',
      referenceObligationCode: entity.obligations[0]?.code || '24通用中期票据',
      notional,
      tenor,
      fixedCoupon,
      upfront: pricing.upfrontPct,
      recoveryRate,
      creditEvents: input.creditEvents || ['破产', '支付违约', '债务重组'],
      settlementType: input.settlementType || '现金结算',
      counterpartyId: input.counterpartyId || 'CP-101',
      counterpartyName: input.counterpartyName || '招商银行股份有限公司',
      tradeDate: new Date().toISOString().slice(0, 10),
      effectiveDate: new Date().toISOString().slice(0, 10),
      maturityDate: `2031-${new Date().toISOString().slice(5, 10)}`,
      status: '已成交',
      trader: '张立 (资深交易员 TRD-004)',
      marketSpread: entity.spread5Y,
      fairSpread: pricing.fairSpreadBp,
      dirtyPV: pricing.dirtyPV,
      cleanPV: pricing.cleanPV,
      protectionLegPV: pricing.protectionLegPV,
      premiumLegPV: pricing.premiumLegPV,
      accruedInterest: pricing.accruedInterest,
      dv01: pricing.dv01,
      cs01: pricing.cs01,
      pv01: pricing.pv01,
      expectedLoss: pricing.expectedLoss,
      cva: pricing.cva,
    };

    // Update state
    const updatedTrades = [newTrade, ...state.cdsTrades];
    
    // Add audit log
    const audit: AuditEvent = {
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      user: '张立 (资深交易员 TRD-004)',
      action: '创建并成交CDS合约',
      target: `${entity.name} ${tenor} CDS (¥${(notional/100000000).toFixed(1)}亿)`,
      oldValue: '询价',
      newValue: '已成交',
      ipAddress: '10.24.180.45',
      riskStatus: '正常',
      approvalStatus: '自动化风控通过',
    };

    set({
      cdsTrades: updatedTrades,
      auditLogs: [audit, ...state.auditLogs],
    });

    return newTrade;
  },

  approveTrade: (tradeId, role) => {
    set((state) => {
      const trades = state.cdsTrades.map((t) => {
        if (t.id === tradeId) {
          return { ...t, status: '已成交' as TradeStatus };
        }
        return t;
      });
      return { cdsTrades: trades };
    });
  },

  createCRMWInstrument: (crmw) => {
    set((state) => {
      const newCRMW: CRMWInstrument = {
        id: `CRMW-${Date.now()}`,
        code: crmw.code || `26${crmw.referenceEntityName?.slice(0,2)}CRMW00${state.crmwInstruments.length + 1}`,
        issuer: crmw.issuer || '招商银行股份有限公司',
        referenceEntityId: crmw.referenceEntityId || 'RE-2001',
        referenceEntityName: crmw.referenceEntityName || '华东先进制造控股集团',
        referenceObligationId: crmw.referenceObligationId || 'OBL-201',
        referenceObligationCode: crmw.referenceObligationCode || '24华东制造MTN001',
        creationAmount: crmw.creationAmount || 2.0,
        termMonths: crmw.termMonths || 36,
        feeRate: crmw.feeRate || 135,
        issuePrice: crmw.issuePrice || 1.35,
        issueDate: new Date().toISOString().slice(0, 10),
        maturityDate: '2029-09-20',
        creditEvents: ['破产', '支付违约', '债务重组'],
        settlementType: '现金结算',
        marketPrice: 100.0,
        yield: 3.5,
        volume24h: 1200,
        status: '存续中',
      };
      return { crmwInstruments: [newCRMW, ...state.crmwInstruments] };
    });
  },

  recalculatePortfolioMetrics: () => {
    const state = get();
    let totalNotional = 0;
    let totalMarketValue = 0;
    let netExposure = 0;
    let grossExposure = 0;
    let totalPnL = 0;
    let dailyPnL = 0;
    let expectedLoss = 0;
    let totalCVA = 0;
    let totalCS01 = 0;

    const sectorMap: Record<SectorType, number> = {
      '能源': 0, '制造': 0, '地产': 0, '基建': 0, '科技': 0,
      '银行': 0, '保险': 0, '交通': 0, '公用事业': 0, '消费': 0, '医药': 0, '汽车': 0
    };

    const ratingMap: Record<RatingType, number> = {
      'AAA': 0, 'AA+': 0, 'AA': 0, 'AA-': 0, 'A+': 0, 'A': 0, 'A-': 0,
      'BBB+': 0, 'BBB': 0, 'BBB-': 0, 'BB+': 0, 'BB': 0, 'B': 0, 'CCC': 0, '违约': 0
    };

    const cs01List: number[] = [];
    const notionalList: number[] = [];
    const spreadList: number[] = [];

    state.cdsTrades.forEach((trade) => {
      totalNotional += trade.notional;
      totalMarketValue += trade.cleanPV;
      grossExposure += trade.notional;

      const entity = state.entities.find((e) => e.id === trade.referenceEntityId);
      if (entity) {
        sectorMap[entity.sector] = (sectorMap[entity.sector] || 0) + trade.notional;
        ratingMap[entity.rating] = (ratingMap[entity.rating] || 0) + trade.notional;
      }

      if (trade.direction === '买入保护') {
        netExposure -= trade.notional;
      } else {
        netExposure += trade.notional;
      }

      totalPnL += trade.cleanPV;
      dailyPnL += trade.cs01 * (entity ? entity.spreadChange24h : 1);
      expectedLoss += trade.expectedLoss;
      totalCVA += trade.cva;
      totalCS01 += trade.cs01;

      cs01List.push(trade.cs01);
      notionalList.push(trade.notional);
      spreadList.push(trade.marketSpread);
    });

    const risk = calculatePortfolioRiskMetrics(notionalList, spreadList, cs01List, 0.95);

    return {
      totalNotional,
      totalMarketValue,
      netExposure,
      grossExposure,
      totalPnL,
      dailyPnL: Math.round(dailyPnL),
      expectedLoss,
      unexpectedLoss: Math.round(expectedLoss * 1.65),
      totalCVA,
      totalDVA: Math.round(totalCVA * 0.45),
      totalCS01: risk.totalCS01,
      var95: risk.varValue,
      es95: risk.esValue,
      sectorDistribution: sectorMap,
      ratingDistribution: ratingMap,
    };
  },

  triggerCreditEvent: (entityId, eventType, description) => {
    const state = get();
    const entity = state.entities.find((e) => e.id === entityId);
    if (!entity) return;

    // 1. Mark Entity as Defaulted
    const updatedEntities = state.entities.map((e) => {
      if (e.id === entityId) {
        return {
          ...e,
          status: '已违约' as const,
          rating: '违约' as RatingType,
          spread5Y: 2500, // Spike to distressed
          recoveryRate: 25,
          lastCreditEvent: `${eventType}: ${description}`,
        };
      }
      return e;
    });

    // 2. Affected Trades
    const affectedTrades = state.cdsTrades.filter((t) => t.referenceEntityId === entityId);
    const affectedNotional = affectedTrades.reduce((sum, t) => sum + t.notional, 0);

    // 3. Create Event Record
    const newCreditEvent: CreditEvent = {
      id: `EVT-${Date.now()}`,
      eventNo: `CE${new Date().toISOString().slice(0,10).replace(/-/g,'')}${Math.floor(100 + Math.random() * 900)}`,
      entityId,
      entityName: entity.name,
      eventType: eventType as any,
      declaredDate: new Date().toISOString().slice(0, 10),
      effectiveDate: new Date().toISOString().slice(0, 10),
      description,
      estimatedRecovery: 25,
      affectedNotional,
      affectedTradeCount: affectedTrades.length,
      pnlImpact: affectedNotional * (1 - 0.25) * 0.8,
      status: '理赔计算中',
      auditLogId: `AUD-${Date.now()}`,
    };

    // 4. Record Audit Log
    const audit: AuditEvent = {
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      user: '信用事件处理引擎 Credit-Event-Bus',
      action: `触发信用事件 [${eventType}]`,
      target: `${entity.name} (受影响名义本金 ¥${(affectedNotional/100000000).toFixed(1)}亿)`,
      oldValue: entity.status,
      newValue: '已违约 · 暂停衍生品交易',
      ipAddress: '127.0.0.1',
      riskStatus: '高风险',
      approvalStatus: '自动处置',
    };

    set({
      entities: updatedEntities,
      creditEvents: [newCreditEvent, ...state.creditEvents],
      auditLogs: [audit, ...state.auditLogs],
    });
  },

  runStressTest: (scenarioId) => {
    const state = get();
    const scenario = state.stressScenarios.find((s) => s.id === scenarioId) || state.stressScenarios[0];

    let portfolioLoss = 0;
    let cvaChange = 0;
    let simulatedDefaults = 0;

    state.cdsTrades.forEach((trade) => {
      const entity = state.entities.find((e) => e.id === trade.referenceEntityId);
      let spreadShift = scenario.spreadShiftBp;
      if (scenario.sectorShifts && entity && scenario.sectorShifts[entity.sector]) {
        spreadShift = scenario.sectorShifts[entity.sector]!;
      }

      const lossOnTrade = trade.cs01 * spreadShift;
      portfolioLoss += lossOnTrade;
      cvaChange += trade.cva * (scenario.pdMultiplier - 1);

      if (entity && entity.pd5Y * scenario.pdMultiplier > 35) {
        simulatedDefaults++;
      }
    });

    const result: StressTestResult = {
      scenarioId: scenario.id,
      scenarioName: scenario.name,
      portfolioLoss: Math.round(portfolioLoss),
      cvaChange: Math.round(cvaChange),
      varChange: Math.round(Math.abs(portfolioLoss * 0.35)),
      esChange: Math.round(Math.abs(portfolioLoss * 0.48)),
      simulatedDefaults,
      breachedLimitsCount: Math.min(5, Math.floor(simulatedDefaults * 1.5) + 1),
      capitalChargeImpact: Math.round(Math.abs(portfolioLoss * 0.12)),
    };

    set({ activeStressResult: result });
    return result;
  },

  startCreditCrisis: () => {
    const state = get();
    const updatedEntities = state.entities.map((e) => {
      const extraShift = e.sector === '地产' ? 220 : (e.sector === '制造' ? 140 : 80);
      const newSpread = e.spread5Y + extraShift;
      const newPd1 = Number((e.pd1Y * 2.2).toFixed(2));
      const newPd5 = Number((e.pd5Y * 2.1).toFixed(2));
      return {
        ...e,
        spread5Y: newSpread,
        pd1Y: newPd1,
        pd5Y: newPd5,
        spreadChange24h: extraShift,
        status: (newSpread > 350 ? '预警' : e.status) as any,
      };
    });

    const crisisAudit: AuditEvent = {
      id: `AUD-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      user: '风险实验室危机模拟器 CrisisSim-01',
      action: '启动系统性信用危机压力脉冲',
      target: '全平台100个信用实体及组合',
      oldValue: '常规市场状态',
      newValue: '信用危机冲击状态 (+150-300bp)',
      ipAddress: '10.24.180.99',
      riskStatus: '高风险',
      approvalStatus: '全网警报广播',
    };

    set({
      entities: updatedEntities,
      isCrisisMode: true,
      auditLogs: [crisisAudit, ...state.auditLogs],
    });
  },

  runWhatIfSimulation: (spreadShift, recoveryNew, downgrade, defaultCount) => {
    const state = get();
    let loss = 0;
    let cvaChange = 0;

    state.cdsTrades.forEach((trade) => {
      loss += trade.cs01 * spreadShift;
      if (downgrade) loss += Math.abs(trade.notional * 0.015);
      cvaChange += trade.cva * 0.25;
    });

    if (defaultCount > 0) {
      loss += defaultCount * 120000000 * (1 - recoveryNew / 100);
    }

    return {
      loss: Math.round(loss),
      cvaChange: Math.round(cvaChange),
      var95: Math.round(Math.abs(loss * 0.4)),
      es95: Math.round(Math.abs(loss * 0.55)),
      breachedLimits: defaultCount > 0 ? defaultCount + 2 : (spreadShift > 100 ? 3 : 1),
    };
  },

  setPlaybackDate: (date) => set({ playbackDate: date }),
  togglePlayback: () => set((state) => ({ isPlayingPlayback: !state.isPlayingPlayback })),
  setPlaybackSpeed: (speed) => set({ playbackSpeed: speed }),

  updateEntitySpreadAndRecalculate: (entityId, newSpread5Y, newRecovery) => {
    set((state) => {
      const updatedEntities = state.entities.map((e) => {
        if (e.id === entityId) {
          const rec = newRecovery !== undefined ? newRecovery : e.recoveryRate;
          const pd1Y = Number(((newSpread5Y / 10000) / (1 - rec/100) * 100).toFixed(2));
          const pd5Y = Number((pd1Y * 4.2).toFixed(2));
          const hazardRate = Number(((newSpread5Y / 10000) / (1 - rec/100)).toFixed(6));
          return {
            ...e,
            spread5Y: newSpread5Y,
            recoveryRate: rec,
            pd1Y,
            pd5Y,
            hazardRate,
          };
        }
        return e;
      });

      // Recalculate trades associated with this entity
      const updatedTrades = state.cdsTrades.map((t) => {
        if (t.referenceEntityId === entityId) {
          const pricing = calculateCDSPricer({
            notional: t.notional,
            tenorYears: parseInt(t.tenor.replace('Y',''), 10) || 5,
            fixedCouponBp: t.fixedCoupon,
            marketSpreadBp: newSpread5Y,
            recoveryRate: (newRecovery !== undefined ? newRecovery : t.recoveryRate) / 100,
            direction: t.direction,
          });
          return {
            ...t,
            marketSpread: newSpread5Y,
            fairSpread: pricing.fairSpreadBp,
            cleanPV: pricing.cleanPV,
            dirtyPV: pricing.dirtyPV,
            protectionLegPV: pricing.protectionLegPV,
            premiumLegPV: pricing.premiumLegPV,
            cs01: pricing.cs01,
            dv01: pricing.dv01,
            expectedLoss: pricing.expectedLoss,
            cva: pricing.cva,
          };
        }
        return t;
      });

      return { entities: updatedEntities, cdsTrades: updatedTrades };
    });
  },

  triggerMarketTick: () => {
    const { entities, isCrisisMode } = get();
    const updatedEntities = entities.map((e) => {
      const shift = Math.round((Math.random() - 0.48) * (isCrisisMode ? 15 : 2.5));
      const newSpread = Math.max(10, Math.round(e.spread5Y + shift));
      return {
        ...e,
        spread5Y: newSpread,
        spreadChange24h: Math.round((e.spreadChange24h + shift) * 10) / 10,
      };
    });
    set({
      entities: updatedEntities,
      lastTickTimestamp: new Date().toLocaleTimeString('zh-CN', { hour12: false }),
    });
  },
}));
