/**
 * China Credit Risk Platform - Synthetic China Interbank Market Data
 * 100个合成参考实体、信用衍生品、交易对手方与初始风险限额数据库
 */

import {
  CDSTrade,
  CDSIndex,
  CLNInstrument,
  Counterparty,
  CreditEvent,
  CRMATrade,
  CRMWInstrument,
  MarginCollateral,
  RatingType,
  ReferenceEntity,
  RiskLimit,
  SectorType,
  StressScenario,
} from '../types';

export const SYNTHETIC_SECTORS: SectorType[] = [
  '能源', '制造', '地产', '基建', '科技', 
  '银行', '保险', '交通', '公用事业', '消费', '医药', '汽车'
];

// Helper to generate 100 fictional Chinese enterprise entities
export const INITIAL_ENTITIES: ReferenceEntity[] = [
  // 能源
  {
    id: 'RE-1001', code: 'RE-1001', name: '华北清洁能源集团有限公司', sector: '能源', rating: 'AA+', impliedRating: 'AA+',
    spread5Y: 82, spreadChange24h: 3, pd1Y: 0.42, pd5Y: 2.13, recoveryRate: 45, hazardRate: 0.0076, status: '正常',
    totalDebt: 850, leverageRatio: 58.4, interestCoverage: 4.2, region: '北京',
    obligations: [
      { id: 'OBL-101', code: '24华北能源MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 15, couponRate: 3.15, maturityDate: '2029-05-20', seniority: '高级无担保', currentPrice: 101.2, yieldToMaturity: 2.88 },
      { id: 'OBL-102', code: '25华北能源SCP002', name: '2025年第二期超短期融资券', type: '超短期融资券', issueAmount: 10, couponRate: 2.45, maturityDate: '2026-11-15', seniority: '高级无担保', currentPrice: 100.1, yieldToMaturity: 2.35 }
    ]
  },
  {
    id: 'RE-1002', code: 'RE-1002', name: '中原国家煤炭电力投资集团', sector: '能源', rating: 'AAA', impliedRating: 'AAA',
    spread5Y: 48, spreadChange24h: -1, pd1Y: 0.12, pd5Y: 0.85, recoveryRate: 50, hazardRate: 0.0042, status: '正常',
    totalDebt: 1820, leverageRatio: 51.2, interestCoverage: 6.8, region: '河南',
    obligations: [
      { id: 'OBL-103', code: '23中原煤电MTN002', name: '2023年第二期中期票据', type: '中期票据', issueAmount: 20, couponRate: 3.40, maturityDate: '2028-08-12', seniority: '高级无担保', currentPrice: 102.5, yieldToMaturity: 2.65 }
    ]
  },
  {
    id: 'RE-1003', code: 'RE-1003', name: '西北石油化工装备集团', sector: '能源', rating: 'AA', impliedRating: 'AA-',
    spread5Y: 125, spreadChange24h: 5, pd1Y: 0.72, pd5Y: 3.82, recoveryRate: 40, hazardRate: 0.0125, status: '预警',
    totalDebt: 420, leverageRatio: 68.9, interestCoverage: 2.1, region: '陕西',
    obligations: [
      { id: 'OBL-104', code: '24西北石化MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 8, couponRate: 4.10, maturityDate: '2027-03-18', seniority: '高级无担保', currentPrice: 98.4, yieldToMaturity: 4.65 }
    ]
  },

  // 制造
  {
    id: 'RE-2001', code: 'RE-2001', name: '华东先进制造控股集团', sector: '制造', rating: 'AA', impliedRating: 'AA',
    spread5Y: 136, spreadChange24h: 7, pd1Y: 0.78, pd5Y: 4.18, recoveryRate: 40, hazardRate: 0.0136, status: '正常',
    totalDebt: 630, leverageRatio: 62.1, interestCoverage: 3.1, region: '江苏',
    obligations: [
      { id: 'OBL-201', code: '24华东制造MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 12, couponRate: 3.85, maturityDate: '2029-09-15', seniority: '高级无担保', currentPrice: 99.8, yieldToMaturity: 3.92 }
    ]
  },
  {
    id: 'RE-2002', code: 'RE-2002', name: '环渤海精密重工集团', sector: '制造', rating: 'AAA', impliedRating: 'AAA',
    spread5Y: 52, spreadChange24h: 0, pd1Y: 0.15, pd5Y: 0.98, recoveryRate: 48, hazardRate: 0.0048, status: '正常',
    totalDebt: 1100, leverageRatio: 48.5, interestCoverage: 7.5, region: '天津',
    obligations: [
      { id: 'OBL-202', code: '23环渤海MTN003', name: '2023年第三期中期票据', type: '中期票据', issueAmount: 25, couponRate: 3.20, maturityDate: '2028-11-20', seniority: '高级无担保', currentPrice: 101.8, yieldToMaturity: 2.72 }
    ]
  },
  {
    id: 'RE-2003', code: 'RE-2003', name: '长三角数控机械股份', sector: '制造', rating: 'A+', impliedRating: 'A',
    spread5Y: 210, spreadChange24h: 12, pd1Y: 1.85, pd5Y: 8.92, recoveryRate: 38, hazardRate: 0.0210, status: '预警',
    totalDebt: 280, leverageRatio: 72.4, interestCoverage: 1.8, region: '浙江',
    obligations: [
      { id: 'OBL-203', code: '24长三角机器MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 5, couponRate: 4.80, maturityDate: '2027-06-10', seniority: '高级无担保', currentPrice: 96.2, yieldToMaturity: 6.12 }
    ]
  },

  // 地产
  {
    id: 'RE-3001', code: 'RE-3001', name: '南方发展城市地产集团', sector: '地产', rating: 'A', impliedRating: 'A-',
    spread5Y: 418, spreadChange24h: 24, pd1Y: 3.92, pd5Y: 18.74, recoveryRate: 32, hazardRate: 0.0418, status: '预警',
    totalDebt: 980, leverageRatio: 79.5, interestCoverage: 1.2, region: '广东',
    obligations: [
      { id: 'OBL-301', code: '23南方地产MTN002', name: '2023年第二期中期票据', type: '中期票据', issueAmount: 10, couponRate: 5.50, maturityDate: '2026-12-10', seniority: '高级无担保', currentPrice: 88.5, yieldToMaturity: 11.20 }
    ]
  },
  {
    id: 'RE-3002', code: 'RE-3002', name: '深港商业置业控股', sector: '地产', rating: 'BBB+', impliedRating: 'BB+',
    spread5Y: 680, spreadChange24h: 45, pd1Y: 7.80, pd5Y: 31.50, recoveryRate: 28, hazardRate: 0.0680, status: '重组中',
    totalDebt: 1450, leverageRatio: 84.2, interestCoverage: 0.8, region: '深圳',
    obligations: [
      { id: 'OBL-302', code: '22深港置业MTN001', name: '2022年第一期中期票据', type: '中期票据', issueAmount: 15, couponRate: 6.20, maturityDate: '2025-10-15', seniority: '高级无担保', currentPrice: 72.1, yieldToMaturity: 22.40 }
    ]
  },
  {
    id: 'RE-3003', code: 'RE-3003', name: '成渝精品地产集团', sector: '地产', rating: 'AA', impliedRating: 'AA-',
    spread5Y: 295, spreadChange24h: 18, pd1Y: 2.10, pd5Y: 11.20, recoveryRate: 35, hazardRate: 0.0295, status: '正常',
    totalDebt: 510, leverageRatio: 69.8, interestCoverage: 2.4, region: '四川',
    obligations: [
      { id: 'OBL-303', code: '24成渝地产MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 8, couponRate: 4.60, maturityDate: '2027-08-20', seniority: '高级无担保', currentPrice: 94.8, yieldToMaturity: 6.85 }
    ]
  },

  // 基建
  {
    id: 'RE-4001', code: 'RE-4001', name: '西部基础设施投资集团', sector: '基建', rating: 'AA', impliedRating: 'AA',
    spread5Y: 174, spreadChange24h: -4, pd1Y: 1.02, pd5Y: 5.31, recoveryRate: 42, hazardRate: 0.0174, status: '正常',
    totalDebt: 1250, leverageRatio: 64.2, interestCoverage: 2.8, region: '重庆',
    obligations: [
      { id: 'OBL-401', code: '24西部基建MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 20, couponRate: 3.65, maturityDate: '2029-04-12', seniority: '高级无担保', currentPrice: 100.4, yieldToMaturity: 3.55 }
    ]
  },
  {
    id: 'RE-4002', code: 'RE-4002', name: '北方港口公路建设总公司', sector: '基建', rating: 'AAA', impliedRating: 'AAA',
    spread5Y: 65, spreadChange24h: 1, pd1Y: 0.22, pd5Y: 1.15, recoveryRate: 48, hazardRate: 0.0065, status: '正常',
    totalDebt: 2100, leverageRatio: 55.0, interestCoverage: 5.4, region: '山东',
    obligations: [
      { id: 'OBL-402', code: '23北方公路MTN002', name: '2023年第二期中期票据', type: '中期票据', issueAmount: 30, couponRate: 3.30, maturityDate: '2028-07-15', seniority: '高级无担保', currentPrice: 102.1, yieldToMaturity: 2.80 }
    ]
  },

  // 科技
  {
    id: 'RE-5001', code: 'RE-5001', name: '东海科技产业投资集团', sector: '科技', rating: 'AA+', impliedRating: 'AA+',
    spread5Y: 92, spreadChange24h: 2, pd1Y: 0.48, pd5Y: 2.45, recoveryRate: 45, hazardRate: 0.0092, status: '正常',
    totalDebt: 480, leverageRatio: 42.1, interestCoverage: 6.1, region: '上海',
    obligations: [
      { id: 'OBL-501', code: '24东海科技MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 10, couponRate: 3.25, maturityDate: '2029-10-10', seniority: '高级无担保', currentPrice: 100.8, yieldToMaturity: 3.05 }
    ]
  },
  {
    id: 'RE-5002', code: 'RE-5002', name: '中关村半导体芯片控股', sector: '科技', rating: 'AA', impliedRating: 'AA-',
    spread5Y: 158, spreadChange24h: 8, pd1Y: 0.95, pd5Y: 4.80, recoveryRate: 40, hazardRate: 0.0158, status: '正常',
    totalDebt: 320, leverageRatio: 52.3, interestCoverage: 3.8, region: '北京',
    obligations: [
      { id: 'OBL-502', code: '24中关村芯片MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 6, couponRate: 3.95, maturityDate: '2027-11-20', seniority: '高级无担保', currentPrice: 99.1, yieldToMaturity: 4.25 }
    ]
  },

  // 银行
  {
    id: 'RE-6001', code: 'RE-6001', name: '渤海商业银行股份有限公司', sector: '银行', rating: 'AAA', impliedRating: 'AAA',
    spread5Y: 38, spreadChange24h: 0, pd1Y: 0.08, pd5Y: 0.55, recoveryRate: 55, hazardRate: 0.0038, status: '正常',
    totalDebt: 3500, leverageRatio: 92.0, interestCoverage: 8.5, region: '天津',
    obligations: [
      { id: 'OBL-601', code: '24渤海银行二级01', name: '2024年第一期二级资本债券', type: '金融债', issueAmount: 50, couponRate: 3.10, maturityDate: '2034-03-15', seniority: '次级', currentPrice: 101.5, yieldToMaturity: 2.92 }
    ]
  },

  // 保险
  {
    id: 'RE-7001', code: 'RE-7001', name: '太平洋信用人寿保险集团', sector: '保险', rating: 'AAA', impliedRating: 'AAA',
    spread5Y: 42, spreadChange24h: 1, pd1Y: 0.09, pd5Y: 0.62, recoveryRate: 55, hazardRate: 0.0042, status: '正常',
    totalDebt: 1600, leverageRatio: 88.0, interestCoverage: 9.1, region: '上海',
    obligations: [
      { id: 'OBL-701', code: '23太平洋保险债01', name: '2023年第一期资本补充债券', type: '金融债', issueAmount: 30, couponRate: 3.28, maturityDate: '2033-06-20', seniority: '次级', currentPrice: 102.0, yieldToMaturity: 3.01 }
    ]
  },

  // 交通
  {
    id: 'RE-8001', code: 'RE-8001', name: '长江远洋航运物流集团', sector: '交通', rating: 'AA+', impliedRating: 'AA+',
    spread5Y: 88, spreadChange24h: -2, pd1Y: 0.44, pd5Y: 2.25, recoveryRate: 45, hazardRate: 0.0088, status: '正常',
    totalDebt: 720, leverageRatio: 56.2, interestCoverage: 4.8, region: '湖北',
    obligations: [
      { id: 'OBL-801', code: '24长江航运MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 12, couponRate: 3.35, maturityDate: '2029-01-18', seniority: '高级无担保', currentPrice: 100.9, yieldToMaturity: 3.12 }
    ]
  },

  // 公用事业
  {
    id: 'RE-9001', code: 'RE-9001', name: '水务水利环保产业总公司', sector: '公用事业', rating: 'AAA', impliedRating: 'AAA',
    spread5Y: 45, spreadChange24h: 0, pd1Y: 0.10, pd5Y: 0.72, recoveryRate: 50, hazardRate: 0.0045, status: '正常',
    totalDebt: 980, leverageRatio: 59.1, interestCoverage: 5.9, region: '浙江',
    obligations: [
      { id: 'OBL-901', code: '23水务环保MTN002', name: '2023年第二期中期票据', type: '中期票据', issueAmount: 15, couponRate: 3.12, maturityDate: '2028-09-10', seniority: '高级无担保', currentPrice: 102.2, yieldToMaturity: 2.65 }
    ]
  },

  // 消费
  {
    id: 'RE-10001', code: 'RE-10001', name: '新丝路零售消费品牌控股', sector: '消费', rating: 'AA', impliedRating: 'AA-',
    spread5Y: 165, spreadChange24h: 6, pd1Y: 0.98, pd5Y: 5.10, recoveryRate: 40, hazardRate: 0.0165, status: '正常',
    totalDebt: 340, leverageRatio: 61.0, interestCoverage: 3.4, region: '四川',
    obligations: [
      { id: 'OBL-1001', code: '24新丝路消费MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 6, couponRate: 3.90, maturityDate: '2027-05-15', seniority: '高级无担保', currentPrice: 98.8, yieldToMaturity: 4.35 }
    ]
  },

  // 医药
  {
    id: 'RE-11001', code: 'RE-11001', name: '岭南创新生物医药集团', sector: '医药', rating: 'AA+', impliedRating: 'AA+',
    spread5Y: 78, spreadChange24h: -1, pd1Y: 0.38, pd5Y: 1.95, recoveryRate: 45, hazardRate: 0.0078, status: '正常',
    totalDebt: 290, leverageRatio: 38.5, interestCoverage: 7.2, region: '广东',
    obligations: [
      { id: 'OBL-1101', code: '24岭南医药MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 8, couponRate: 3.20, maturityDate: '2029-07-22', seniority: '高级无担保', currentPrice: 101.1, yieldToMaturity: 2.95 }
    ]
  },

  // 汽车
  {
    id: 'RE-12001', code: 'RE-12001', name: '招商智能新能源汽车集团', sector: '汽车', rating: 'AA', impliedRating: 'AA',
    spread5Y: 142, spreadChange24h: 4, pd1Y: 0.82, pd5Y: 4.30, recoveryRate: 42, hazardRate: 0.0142, status: '正常',
    totalDebt: 580, leverageRatio: 64.5, interestCoverage: 3.2, region: '安徽',
    obligations: [
      { id: 'OBL-1201', code: '24招商汽车MTN001', name: '2024年第一期中期票据', type: '中期票据', issueAmount: 10, couponRate: 3.75, maturityDate: '2028-12-05', seniority: '高级无担保', currentPrice: 99.5, yieldToMaturity: 3.88 }
    ]
  }
];

// Helper programmatically populates remaining up to 100 synthetic Chinese interbank entities
const PREFIXES = ['华东', '华北', '南方', '北方', '中原', '西北', '西南', '东海', '长三角', '珠三角', '成渝', '环渤海'];
const SECTOR_NAMES: Record<SectorType, string[]> = {
  '能源': ['清洁能源', '电力集团', '煤炭能源', '新能源开发', '天然气股份'],
  '制造': ['先进装备', '精密制造', '重工控股', '智能机械', '新材料股份'],
  '地产': ['城市建设', '置业控股', '不动产集团', '产业园投资', '城市更新'],
  '基建': ['基础设施', '交通投资', '公路建设', '水利投资', '港口物流'],
  '科技': ['数字科技', '半导体', '软件信息', '光电股份', '人工智能'],
  '银行': ['商业银行', '农商银行', '城市银行'],
  '保险': ['人寿保险', '财产保险', '再保险股份'],
  '交通': ['航运集团', '轨道交通', '航空物流', '高速公路'],
  '公用事业': ['水务环保', '燃气集团', '热力供电'],
  '消费': ['零售连锁', '食品饮料', '文旅投资'],
  '医药': ['生物医药', '医疗器械', '健康产业'],
  '汽车': ['智能汽车', '新能源车', '零部件集团']
};

export function generateAll100Entities(): ReferenceEntity[] {
  const result: ReferenceEntity[] = [...INITIAL_ENTITIES];
  let idCounter = 100;

  for (let i = result.length; i < 100; i++) {
    idCounter++;
    const sector = SYNTHETIC_SECTORS[i % SYNTHETIC_SECTORS.length];
    const prefix = PREFIXES[i % PREFIXES.length];
    const subName = SECTOR_NAMES[sector][i % SECTOR_NAMES[sector].length];
    const name = `${prefix}${subName}集团有限公司`;
    
    // Rating distribution: AAA (20%), AA+ (30%), AA (30%), A+ (10%), A/BBB/BB (10%)
    const ratings: RatingType[] = ['AAA', 'AA+', 'AA+', 'AA', 'AA', 'A+', 'A', 'BBB+', 'BB+'];
    const rating = ratings[i % ratings.length];
    
    let baseSpread = 45;
    if (rating === 'AA+') baseSpread = 85;
    if (rating === 'AA') baseSpread = 140;
    if (rating === 'A+') baseSpread = 220;
    if (rating === 'A') baseSpread = 320;
    if (rating === 'BBB+') baseSpread = 480;
    if (rating === 'BB+') baseSpread = 650;

    const spread5Y = baseSpread + Math.floor((i * 7) % 35) - 10;
    const pd1Y = Number(((spread5Y / 10000) / 0.6 * 100).toFixed(2));
    const pd5Y = Number((pd1Y * 4.2).toFixed(2));
    const recoveryRate = rating === 'AAA' ? 50 : (rating.startsWith('AA') ? 42 : 35);
    const hazardRate = Number(((spread5Y / 10000) / (1 - recoveryRate/100)).toFixed(6));

    result.push({
      id: `RE-${idCounter}`,
      code: `RE-${idCounter}`,
      name,
      sector,
      rating,
      impliedRating: rating,
      spread5Y,
      spreadChange24h: (i % 5 === 0) ? 5 : ((i % 3 === 0) ? -2 : 1),
      pd1Y,
      pd5Y,
      recoveryRate,
      hazardRate,
      status: (spread5Y > 400) ? '预警' : '正常',
      totalDebt: 200 + ((i * 35) % 1500),
      leverageRatio: Number((45 + (i * 3.2) % 35).toFixed(1)),
      interestCoverage: Number((1.5 + (i * 0.8) % 6).toFixed(1)),
      region: ['北京', '上海', '广东', '江苏', '浙江', '山东', '四川', '湖北'][i % 8],
      obligations: [
        {
          id: `OBL-${idCounter}-1`,
          code: `24${prefix.slice(0, 2)}${sector}MTN001`,
          name: `2024年第一期中期票据`,
          type: '中期票据',
          issueAmount: 10 + (i % 15),
          couponRate: Number((3.0 + (spread5Y / 100)).toFixed(2)),
          maturityDate: `2029-0${(i % 9) + 1}-15`,
          seniority: '高级无担保',
          currentPrice: Number((100 - (spread5Y / 100) * 0.8).toFixed(1)),
          yieldToMaturity: Number((3.1 + (spread5Y / 100)).toFixed(2)),
        }
      ]
    });
  }

  return result;
}

export const ALL_ENTITIES = generateAll100Entities();

export const INITIAL_COUNTERPARTIES: Counterparty[] = [
  { id: 'CP-101', code: 'CP-101', name: '招商银行股份有限公司', type: '商业银行', rating: 'AAA', region: '深圳', sector: '金融', pd: 0.08, lgd: 45, totalLimit: 100, usedLimit: 42.5, availableLimit: 57.5, currentExposure: 425000000, expectedExposure: 380000000, pfe95: 580000000, cva: 12800000, status: '正常交易' },
  { id: 'CP-102', code: 'CP-102', name: '中信证券股份有限公司', type: '证券公司', rating: 'AAA', region: '北京', sector: '金融', pd: 0.12, lgd: 50, totalLimit: 80, usedLimit: 36.2, availableLimit: 43.8, currentExposure: 362000000, expectedExposure: 310000000, pfe95: 490000000, cva: 14500000, status: '正常交易' },
  { id: 'CP-103', code: 'CP-103', name: '华泰证券股份有限公司', type: '证券公司', rating: 'AA+', region: '江苏', sector: '金融', pd: 0.25, lgd: 50, totalLimit: 60, usedLimit: 28.0, availableLimit: 32.0, currentExposure: 280000000, expectedExposure: 240000000, pfe95: 380000000, cva: 18200000, status: '正常交易' },
  { id: 'CP-104', code: 'CP-104', name: '中国工商银行金融市场部', type: '商业银行', rating: 'AAA', region: '北京', sector: '金融', pd: 0.05, lgd: 45, totalLimit: 150, usedLimit: 68.4, availableLimit: 81.6, currentExposure: 684000000, expectedExposure: 610000000, pfe95: 890000000, cva: 16400000, status: '正常交易' },
  { id: 'CP-105', code: 'CP-105', name: '易方达基金管理有限公司', type: '基金公司', rating: 'AA+', region: '广州', sector: '资管', pd: 0.28, lgd: 55, totalLimit: 50, usedLimit: 19.5, availableLimit: 30.5, currentExposure: 195000000, expectedExposure: 170000000, pfe95: 260000000, cva: 11200000, status: '正常交易' },
  { id: 'CP-106', code: 'CP-106', name: '泰康资产管理有限责任公司', type: '保险公司', rating: 'AAA', region: '北京', sector: '保险', pd: 0.10, lgd: 50, totalLimit: 70, usedLimit: 22.0, availableLimit: 48.0, currentExposure: 220000000, expectedExposure: 195000000, pfe95: 290000000, cva: 8500000, status: '正常交易' },
];

export const INITIAL_CDS_TRADES: CDSTrade[] = [
  {
    id: 'TRD-1001', tradeNo: 'CDS20260919001', tradeType: 'CDS', direction: '买入保护',
    referenceEntityId: 'RE-2001', referenceEntityName: '华东先进制造控股集团',
    referenceObligationId: 'OBL-201', referenceObligationCode: '24华东制造MTN001',
    notional: 500000000, tenor: '5Y', fixedCoupon: 100, upfront: 1.42, recoveryRate: 40,
    creditEvents: ['破产', '支付违约', '债务重组'], settlementType: '现金结算',
    counterpartyId: 'CP-101', counterpartyName: '招商银行股份有限公司',
    tradeDate: '2026-03-15', effectiveDate: '2026-03-16', maturityDate: '2031-03-20',
    status: '已成交', trader: '张立 (TRD-004)',
    marketSpread: 136, fairSpread: 136, dirtyPV: 5540000, cleanPV: 5540000,
    protectionLegPV: 48320000, premiumLegPV: 42780000, accruedInterest: 520000,
    dv01: -18500, cs01: -198000, pv01: 427800, expectedLoss: 8360000, cva: 710000
  },
  {
    id: 'TRD-1002', tradeNo: 'CDS20260919002', tradeType: 'CDS', direction: '卖出保护',
    referenceEntityId: 'RE-1001', referenceEntityName: '华北清洁能源集团有限公司',
    referenceObligationId: 'OBL-101', referenceObligationCode: '24华北能源MTN001',
    notional: 300000000, tenor: '5Y', fixedCoupon: 80, upfront: 0.12, recoveryRate: 45,
    creditEvents: ['破产', '支付违约', '债务重组'], settlementType: '现金结算',
    counterpartyId: 'CP-102', counterpartyName: '中信证券股份有限公司',
    tradeDate: '2026-04-10', effectiveDate: '2026-04-11', maturityDate: '2031-04-20',
    status: '已成交', trader: '李敏 (TRD-002)',
    marketSpread: 82, fairSpread: 82, dirtyPV: -320000, cleanPV: -320000,
    protectionLegPV: 21100000, premiumLegPV: 21420000, accruedInterest: 300000,
    dv01: 11200, cs01: 118000, pv01: 267750, expectedLoss: 2920000, cva: 248000
  },
  {
    id: 'TRD-1003', tradeNo: 'CDS20260919003', tradeType: 'CDS', direction: '买入保护',
    referenceEntityId: 'RE-3001', referenceEntityName: '南方发展城市地产集团',
    referenceObligationId: 'OBL-301', referenceObligationCode: '23南方地产MTN002',
    notional: 200000000, tenor: '3Y', fixedCoupon: 200, upfront: 4.85, recoveryRate: 32,
    creditEvents: ['破产', '支付违约', '债务重组', '债务加速到期'], settlementType: '现金结算',
    counterpartyId: 'CP-103', counterpartyName: '华泰证券股份有限公司',
    tradeDate: '2026-06-01', effectiveDate: '2026-06-02', maturityDate: '2029-06-20',
    status: '已成交', trader: '张立 (TRD-004)',
    marketSpread: 418, fairSpread: 418, dirtyPV: 9700000, cleanPV: 9700000,
    protectionLegPV: 22400000, premiumLegPV: 12700000, accruedInterest: 500000,
    dv01: -9400, cs01: -142000, pv01: 63500, expectedLoss: 25480000, cva: 2160000
  }
];

export const INITIAL_CRMW_INSTRUMENTS: CRMWInstrument[] = [
  {
    id: 'CRMW-101', code: '26华东制造CRMW001', issuer: '招商银行股份有限公司',
    referenceEntityId: 'RE-2001', referenceEntityName: '华东先进制造控股集团',
    referenceObligationId: 'OBL-201', referenceObligationCode: '24华东制造MTN001',
    creationAmount: 2.0, termMonths: 36, feeRate: 135, issuePrice: 1.35,
    issueDate: '2026-02-10', maturityDate: '2029-02-10',
    creditEvents: ['破产', '支付违约', '债务重组'], settlementType: '现金结算',
    marketPrice: 101.45, yield: 3.82, volume24h: 3500, status: '存续中'
  },
  {
    id: 'CRMW-102', code: '26华北能源CRMW002', issuer: '中国工商银行股份有限公司',
    referenceEntityId: 'RE-1001', referenceEntityName: '华北清洁能源集团有限公司',
    referenceObligationId: 'OBL-101', referenceObligationCode: '24华北能源MTN001',
    creationAmount: 3.0, termMonths: 60, feeRate: 85, issuePrice: 0.85,
    issueDate: '2026-04-15', maturityDate: '2031-04-15',
    creditEvents: ['破产', '支付违约'], settlementType: '现金结算',
    marketPrice: 100.80, yield: 2.95, volume24h: 5200, status: '存续中'
  }
];

export const INITIAL_CRMA_TRADES: CRMATrade[] = [
  { id: 'CRMA-101', code: 'CRMA20260801', partyA: '招商银行', partyB: '本机构交易台', referenceEntityId: 'RE-4001', referenceEntityName: '西部基础设施投资集团', notional: 150000000, feeRate: 170, startDate: '2026-01-10', endDate: '2029-01-10', status: '已成交' }
];

export const INITIAL_CLN_INSTRUMENTS: CLNInstrument[] = [
  { id: 'CLN-101', code: '26东海CLN01', issuer: '中信证券股份有限公司', referenceEntityId: 'RE-5001', referenceEntityName: '东海科技产业投资集团', notional: 200000000, couponRate: 4.25, creditSpread: 95, issuePrice: 100, maturityDate: '2029-06-30', collateralAsset: '24附息国债10', status: '存续中' }
];

export const INITIAL_CDS_INDICES: CDSIndex[] = [
  { id: 'IDX-01', code: 'CHINA-CDS-MAIN-5Y', name: '中国银行间高评级信用违约互换指数 5Y', constituentCount: 40, averageSpread: 92.4, indexLevel: 1042.8, change24h: +1.2, duration: 4.6, sectorBreakdown: { '能源': 25, '制造': 30, '基建': 20, '科技': 15, '银行': 10 } },
  { id: 'IDX-02', code: 'CHINA-CDS-HIGHYIELD-3Y', name: '中国银行间高收益信用衍生品指数 3Y', constituentCount: 20, averageSpread: 385.2, indexLevel: 890.5, change24h: +12.4, duration: 2.7, sectorBreakdown: { '地产': 50, '制造': 30, '城投': 20 } }
];

export const INITIAL_RISK_LIMITS: RiskLimit[] = [
  { id: 'LIM-101', name: '总体信用衍生品名义本金限额', category: '总交易限额', target: '全平台组合', limitValue: 1000000, currentUsage: 584260, usagePercentage: 58.4, warningThreshold: 80, status: '正常' },
  { id: 'LIM-102', name: '房地产行业信用敞口限额', category: '单一行业', target: '地产', limitValue: 150000, currentUsage: 128400, usagePercentage: 85.6, warningThreshold: 80, status: '预警' },
  { id: 'LIM-103', name: '单一交易对手集中度 (招商银行)', category: '单一对手方', target: '招商银行股份有限公司', limitValue: 80000, currentUsage: 42500, usagePercentage: 53.1, warningThreshold: 75, status: '正常' },
  { id: 'LIM-104', name: '单一参考实体敞口 (南方地产集团)', category: '单一参考实体', target: '南方发展城市地产集团', limitValue: 30000, currentUsage: 28500, usagePercentage: 95.0, warningThreshold: 85, status: '超限' },
  { id: 'LIM-105', name: '高收益评级区间 (A及以下) 敞口限额', category: '评级区间', target: 'A及以下级', limitValue: 100000, currentUsage: 64200, usagePercentage: 64.2, warningThreshold: 80, status: '正常' }
];

export const INITIAL_STRESS_SCENARIOS: StressScenario[] = [
  { id: 'SCEN-01', name: '轻度信用恶化', description: '全市场信用利差整体走阔 25bp', spreadShiftBp: 25, pdMultiplier: 1.2, recoveryShiftPct: 0, isPreset: true },
  { id: 'SCEN-02', name: '中度信用冲击', description: '全市场信用利差走阔 75bp，违约率上浮 50%', spreadShiftBp: 75, pdMultiplier: 1.5, recoveryShiftPct: -5, isPreset: true },
  { id: 'SCEN-03', name: '严重信用冲击', description: '全市场信用利差走阔 150bp，违约率翻倍', spreadShiftBp: 150, pdMultiplier: 2.0, recoveryShiftPct: -10, isPreset: true },
  { id: 'SCEN-04', name: '系统性信用危机', description: '利差暴涨 300bp，违约概率扩大 3 倍，回收率暴跌 20%', spreadShiftBp: 300, pdMultiplier: 3.0, recoveryShiftPct: -20, isPreset: true },
  { id: 'SCEN-05', name: '房地产行业专项压力', description: '地产行业 CDS 利差走阔 250bp，违约率扩大 2.5 倍', spreadShiftBp: 50, pdMultiplier: 1.2, recoveryShiftPct: -10, sectorShifts: { '地产': 250, '制造': 40, '银行': 30 }, isPreset: true },
  { id: 'SCEN-06', name: '制造业周期性压测', description: '制造业利差扩大 120bp，相关汽车/能源板块跟随上升 80bp', spreadShiftBp: 30, pdMultiplier: 1.3, recoveryShiftPct: -5, sectorShifts: { '制造': 120, '汽车': 80, '能源': 60 }, isPreset: true },
];

export const INITIAL_MARGIN_COLLATERALS: MarginCollateral[] = [
  { id: 'COL-01', counterpartyId: 'CP-101', counterpartyName: '招商银行股份有限公司', requiredMargin: 25000000, postedMargin: 28000000, collateralType: '国债', haircut: 2.0, marginCallStatus: '充足' },
  { id: 'COL-02', counterpartyId: 'CP-103', counterpartyName: '华泰证券股份有限公司', requiredMargin: 18000000, postedMargin: 15000000, collateralType: '政策性金融债', haircut: 3.0, marginCallStatus: '补仓通知中' },
];
