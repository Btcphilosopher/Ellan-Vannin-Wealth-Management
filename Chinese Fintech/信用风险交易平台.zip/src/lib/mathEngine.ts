/**
 * China Credit Risk Platform - Quantitative Math & Pricing Engine
 * 中国信用衍生品与风险量化定价引擎 (CDS / CRM / CVA / VaR / Hazard Curves / Bootstrap)
 */

import { CreditCurvePoint, RatingType, SectorType } from '../types';

// Discount rate curve assumption (Interbank Treasury / Shibor discount curve ~ 2.1% flat for simplicity)
const RISK_FREE_RATE = 0.021;

/**
 * Calculate discount factor for time t in years: D(t) = exp(-r * t)
 */
export function discountFactor(t: number, r: number = RISK_FREE_RATE): number {
  return Math.exp(-r * t);
}

/**
 * Bootstrap Hazard Rate curve λ(t) from market CDS Spreads
 * @param tenors Tenors in years e.g. [1, 2, 3, 5, 7, 10]
 * @param spreads Spreads in basis points e.g. [120, 140, 160, 186, 210, 240]
 * @param recoveryRate Recovery rate e.g. 0.40 (40%)
 */
export function bootstrapHazardCurve(
  tenors: number[] = [1, 2, 3, 5, 7, 10],
  spreads: number[] = [100, 120, 145, 186, 220, 260],
  recoveryRate: number = 0.40
): { tenor: number; hazardRate: number; survivalProb: number; discountFactor: number }[] {
  const lgd = 1 - recoveryRate;
  const result: { tenor: number; hazardRate: number; survivalProb: number; discountFactor: number }[] = [];

  let cumHazard = 0;
  let prevT = 0;

  for (let i = 0; i < tenors.length; i++) {
    const t = tenors[i];
    const sBp = spreads[i];
    const s = sBp / 10000; // convert bp to decimal
    const deltaT = t - prevT;

    // Standard approximation: λ ≈ S / (1 - Recovery)
    // Refined piecewise constant hazard rate estimation
    let lambda = s / Math.max(0.01, lgd);

    // Minor adjustment for curve slope
    if (i > 0) {
      const prevSpread = spreads[i - 1] / 10000;
      const spreadSlope = (s - prevSpread) / deltaT;
      lambda = Math.max(0.0001, lambda + spreadSlope * 0.5);
    }

    cumHazard += lambda * deltaT;
    const survivalProb = Math.exp(-cumHazard);
    const df = discountFactor(t);

    result.push({
      tenor: t,
      hazardRate: Number(lambda.toFixed(6)),
      survivalProb: Number(survivalProb.toFixed(6)),
      discountFactor: Number(df.toFixed(6)),
    });

    prevT = t;
  }

  return result;
}

/**
 * Standardized CDS Pricing Calculator
 */
export interface CDSPricingInput {
  notional: number; // e.g. 100,000,000 (1亿元)
  tenorYears: number; // e.g. 5
  fixedCouponBp: number; // e.g. 100 (100bp)
  marketSpreadBp: number; // e.g. 186.4 (186.4bp)
  recoveryRate: number; // e.g. 0.40 (40%)
  direction: '买入保护' | '卖出保护';
}

export interface CDSPricingOutput {
  protectionLegPV: number;
  premiumLegPV: number;
  cleanPV: number;
  dirtyPV: number;
  fairSpreadBp: number;
  upfrontPct: number;
  accruedInterest: number;
  cs01: number; // P&L change per 1bp spread increase
  dv01: number; // P&L change per 1bp interest rate shift
  pv01: number; // Present Value of 1bp
  defaultProb1Y: number;
  defaultProb5Y: number;
  expectedLoss: number;
  cva: number;
}

export function calculateCDSPricer(input: CDSPricingInput): CDSPricingOutput {
  const { notional, tenorYears, fixedCouponBp, marketSpreadBp, recoveryRate, direction } = input;
  const lgd = 1 - recoveryRate;
  
  // Hazard rate λ estimation
  const lambda = (marketSpreadBp / 10000) / Math.max(0.01, lgd);

  // Time steps: quarterly payments (0.25y)
  const dt = 0.25;
  const steps = Math.round(tenorYears / dt);

  let protectionLegPV = 0;
  let premiumLegPV = 0;
  let pv01Sum = 0;

  let prevS = 1.0;

  for (let i = 1; i <= steps; i++) {
    const t = i * dt;
    const df = discountFactor(t);
    const S = Math.exp(-lambda * t);

    // Default probability during interval (prevS - S)
    const probDefaultInStep = prevS - S;

    // Protection Leg Contribution: Expected Default Payment * Discount
    const protectionStep = notional * lgd * probDefaultInStep * df;
    protectionLegPV += protectionStep;

    // Premium Leg Contribution: Coupon * dt * Survival Prob * Discount
    const couponPayment = (fixedCouponBp / 10000) * notional * dt;
    const premiumStep = couponPayment * S * df;
    premiumLegPV += premiumStep;

    // PV01 component (1bp coupon stream)
    const pv01Step = (1 / 10000) * notional * dt * S * df;
    pv01Sum += pv01Step;

    prevS = S;
  }

  // Fair Spread = Protection Leg / PV01
  const fairSpreadBp = pv01Sum > 0 ? (protectionLegPV / pv01Sum) / 10000 : marketSpreadBp;

  // Accrued interest (assuming 0.125y midway through payment period)
  const accruedInterest = notional * (fixedCouponBp / 10000) * (dt / 2);

  // Net PV from perspective of Protection Buyer:
  // Protection Buyer receives Protection Leg, pays Premium Leg
  let buyerCleanPV = protectionLegPV - premiumLegPV;
  let buyerDirtyPV = buyerCleanPV - accruedInterest;

  // Adjust for Direction
  const isBuyer = direction === '买入保护';
  const cleanPV = isBuyer ? buyerCleanPV : -buyerCleanPV;
  const dirtyPV = isBuyer ? buyerDirtyPV : -buyerDirtyPV;

  // Upfront %
  const upfrontPct = (buyerCleanPV / notional) * 100;

  // CS01 Calculation (Re-rate with +1bp market spread shift)
  const shiftedMarketSpread = marketSpreadBp + 1;
  const lambdaShifted = (shiftedMarketSpread / 10000) / Math.max(0.01, lgd);
  
  let shiftedProtPV = 0;
  let shiftedPremPV = 0;
  let prevS_shifted = 1.0;

  for (let i = 1; i <= steps; i++) {
    const t = i * dt;
    const df = discountFactor(t);
    const S_shifted = Math.exp(-lambdaShifted * t);
    const probDef = prevS_shifted - S_shifted;

    shiftedProtPV += notional * lgd * probDef * df;
    shiftedPremPV += (fixedCouponBp / 10000) * notional * dt * S_shifted * df;
    prevS_shifted = S_shifted;
  }

  const shiftedBuyerPV = shiftedProtPV - shiftedPremPV;
  // CS01: change in position value for 1bp spread increase
  const cs01 = isBuyer ? (shiftedBuyerPV - buyerCleanPV) : (buyerCleanPV - shiftedBuyerPV);

  // DV01 Calculation (Re-rate with +1bp interest rate shift)
  const dfShift = (t: number) => Math.exp(-(RISK_FREE_RATE + 0.0001) * t);
  let protDV = 0;
  let premDV = 0;
  let prevS_dv = 1.0;

  for (let i = 1; i <= steps; i++) {
    const t = i * dt;
    const df_shifted = dfShift(t);
    const S = Math.exp(-lambda * t);
    const probDef = prevS_dv - S;

    protDV += notional * lgd * probDef * df_shifted;
    premDV += (fixedCouponBp / 10000) * notional * dt * S * df_shifted;
    prevS_dv = S;
  }
  const dv01 = isBuyer ? ((protDV - premDV) - buyerCleanPV) : (buyerCleanPV - (protDV - premDV));

  // Default Probabilities
  const defaultProb1Y = (1 - Math.exp(-lambda * 1)) * 100;
  const defaultProb5Y = (1 - Math.exp(-lambda * 5)) * 100;

  const expectedLoss = notional * (defaultProb5Y / 100) * lgd;
  const cva = expectedLoss * 0.085; // CVA estimate based on 8.5% counterparty default probability & exposure

  return {
    protectionLegPV: Math.round(protectionLegPV),
    premiumLegPV: Math.round(premiumLegPV),
    cleanPV: Math.round(cleanPV),
    dirtyPV: Math.round(dirtyPV),
    fairSpreadBp: Number(fairSpreadBp.toFixed(1)),
    upfrontPct: Number(upfrontPct.toFixed(2)),
    accruedInterest: Math.round(accruedInterest),
    cs01: Math.round(cs01),
    dv01: Math.round(dv01),
    pv01: Math.round(pv01Sum),
    defaultProb1Y: Number(defaultProb1Y.toFixed(2)),
    defaultProb5Y: Number(defaultProb5Y.toFixed(2)),
    expectedLoss: Math.round(expectedLoss),
    cva: Math.round(cva),
  };
}

/**
 * 1-Year Credit Rating Migration Matrix (China Interbank Standard Synthetic)
 */
export const RATING_BUCKETS: RatingType[] = [
  'AAA', 'AA+', 'AA', 'A+', 'A', 'BBB+', 'BBB', 'BB+', 'BB', 'B', 'CCC', '违约'
];

export const MIGRATION_MATRIX_1Y: Record<string, number[]> = {
  // AAA, AA+, AA, A+, A, BBB+, BBB, BB+, BB, B, CCC, Default
  'AAA':  [0.915, 0.065, 0.015, 0.003, 0.001, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.001],
  'AA+':  [0.025, 0.880, 0.070, 0.018, 0.004, 0.001, 0.000, 0.000, 0.000, 0.000, 0.000, 0.002],
  'AA':   [0.005, 0.035, 0.860, 0.075, 0.016, 0.005, 0.001, 0.000, 0.000, 0.000, 0.000, 0.003],
  'A+':   [0.001, 0.008, 0.045, 0.840, 0.080, 0.018, 0.004, 0.001, 0.000, 0.000, 0.000, 0.003],
  'A':    [0.000, 0.002, 0.012, 0.050, 0.810, 0.090, 0.022, 0.008, 0.002, 0.000, 0.000, 0.004],
  'BBB+': [0.000, 0.000, 0.003, 0.015, 0.060, 0.780, 0.095, 0.028, 0.010, 0.003, 0.001, 0.005],
  'BBB':  [0.000, 0.000, 0.001, 0.005, 0.020, 0.070, 0.740, 0.105, 0.035, 0.012, 0.004, 0.008],
  'BB+':  [0.000, 0.000, 0.000, 0.001, 0.005, 0.025, 0.080, 0.700, 0.120, 0.040, 0.012, 0.017],
  'BB':   [0.000, 0.000, 0.000, 0.000, 0.002, 0.008, 0.030, 0.090, 0.650, 0.135, 0.045, 0.040],
  'B':    [0.000, 0.000, 0.000, 0.000, 0.000, 0.002, 0.010, 0.025, 0.080, 0.600, 0.180, 0.103],
  'CCC':  [0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.002, 0.005, 0.020, 0.090, 0.520, 0.363],
  '违约': [0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 1.000]
};

/**
 * Sector spillover correlation map for synthetic market generator
 */
export const SECTOR_CORRELATIONS: Record<SectorType, Partial<Record<SectorType, number>>> = {
  '地产': { '基建': 0.85, '银行': 0.65, '保险': 0.55, '公用事业': 0.30 },
  '制造': { '汽车': 0.75, '能源': 0.70, '科技': 0.60, '交通': 0.50, '银行': 0.40 },
  '能源': { '公用事业': 0.80, '制造': 0.70, '交通': 0.65, '基建': 0.55 },
  '基建': { '地产': 0.60, '交通': 0.70, '银行': 0.50, '能源': 0.45 },
  '银行': { '保险': 0.80, '地产': 0.65, '制造': 0.45, '基建': 0.50 },
  '保险': { '银行': 0.80, '地产': 0.55, '基建': 0.40 },
  '科技': { '制造': 0.60, '汽车': 0.50, '消费': 0.45 },
  '交通': { '能源': 0.65, '基建': 0.70, '消费': 0.50 },
  '公用事业': { '能源': 0.80, '基建': 0.45 },
  '消费': { '医药': 0.50, '汽车': 0.60, '科技': 0.45 },
  '医药': { '消费': 0.50, '科技': 0.40 },
  '汽车': { '制造': 0.75, '消费': 0.60, '科技': 0.50 },
};

/**
 * Value at Risk (VaR) & Expected Shortfall (ES) Monte Carlo / Parametric Calculation
 */
export function calculatePortfolioRiskMetrics(
  positionsNotional: number[],
  positionsSpread: number[],
  positionsCS01: number[],
  confidenceLevel: 0.95 | 0.99 = 0.95
): { varValue: number; esValue: number; totalCS01: number } {
  const totalCS01 = positionsCS01.reduce((sum, v) => sum + v, 0);

  // Daily spread volatility assumption ~ 3.5 bp
  const dailySpreadVolBp = 3.5;
  const zScore = confidenceLevel === 0.95 ? 1.645 : 2.326;
  const esMultiplier = confidenceLevel === 0.95 ? 2.063 : 2.665; // Expected shortfall factor for normal dist

  // Portfolio VaR = Total CS01 * Daily Vol * zScore
  const varValue = Math.abs(totalCS01 * dailySpreadVolBp * zScore);
  const esValue = Math.abs(totalCS01 * dailySpreadVolBp * esMultiplier);

  return {
    varValue: Math.round(varValue),
    esValue: Math.round(esValue),
    totalCS01: Math.round(totalCS01),
  };
}
