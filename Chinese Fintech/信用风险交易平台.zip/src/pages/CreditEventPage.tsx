/**
 * Credit Event Engine Page (信用事件处置中心)
 * 具备实体违约/重组状态全网广播、组合重新估值、保护支付结算与审计记录自动化触发的信用事件引擎
 */

import React, { useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  Building2,
  CheckCircle2,
  Clock,
  DollarSign,
  FileSpreadsheet,
  Flame,
  ShieldAlert,
  Zap,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';
import { EventType } from '../types';

export const CreditEventPage: React.FC = () => {
  const {
    entities,
    creditEvents,
    triggerCreditEvent,
    auditLogs,
  } = useCreditStore();

  const [selectedEntityId, setSelectedEntityId] = useState<string>(entities[0].id);
  const [eventType, setEventType] = useState<EventType>('支付违约');
  const [eventDescription, setEventDescription] = useState<string>(
    '企业触发债券利息未能按期全额支付，构成银行间市场标准信用事件。'
  );

  const selectedEntity = entities.find((e) => e.id === selectedEntityId) || entities[0];

  const handleTriggerEvent = () => {
    triggerCreditEvent(selectedEntity.id, eventType, eventDescription);
  };

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <AlertOctagon className="w-5 h-5 text-red-500 animate-pulse" />
          <h1 className="font-bold text-sm text-slate-100">
            信用事件处理引擎 (Credit Event Engine)
          </h1>
        </div>
        <span className="text-xs font-mono text-red-400 font-bold bg-red-950 px-2 py-0.5 rounded border border-red-800">
          核心风控模块 · 自动化状态变更与损益清算
        </span>
      </div>

      {/* Trigger Box vs Credit Event Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 5 Cols: Event Declaration Form */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
            <span>宣告与触发新信用事件 (Declare Event)</span>
            <span className="text-[10px] text-red-400 font-mono">ISDA/CIBM 事件认定</span>
          </div>

          <div className="space-y-3 text-xs font-mono">
            {/* Target Entity */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px] font-sans">选择违约/重组参考实体</label>
              <select
                value={selectedEntityId}
                onChange={(e) => setSelectedEntityId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-100 font-sans"
              >
                {entities.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} [{e.sector} · 当前状态: {e.status}]
                  </option>
                ))}
              </select>
            </div>

            {/* Event Type */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px] font-sans">信用事件类型</label>
              <select
                value={eventType}
                onChange={(e) => setEventType(e.target.value as EventType)}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-red-300 font-bold"
              >
                <option value="破产">破产 (Bankruptcy)</option>
                <option value="支付违约">支付违约 (Failure to Pay)</option>
                <option value="债务重组">债务重组 (Restructuring)</option>
                <option value="债务加速到期">债务加速到期 (Obligation Acceleration)</option>
                <option value="潜在加速到期">潜在加速到期 (Potential Acceleration)</option>
              </select>
            </div>

            {/* Description */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px] font-sans">事件公告与认定详情</label>
              <textarea
                value={eventDescription}
                onChange={(e) => setEventDescription(e.target.value)}
                rows={3}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-200 font-sans text-xs"
              />
            </div>

            {/* Trigger Button */}
            <div className="pt-2">
              <button
                onClick={handleTriggerEvent}
                className="w-full bg-red-900 hover:bg-red-800 text-red-100 font-bold py-2.5 rounded shadow text-xs flex items-center justify-center space-x-2 transition-all border border-red-700"
              >
                <ShieldAlert className="w-4 h-4 text-red-300" />
                <span>立即触发信用事件并广播至全系统</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right 7 Cols: Active Credit Events List */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
            <span>已知信用事件与理赔清算台账 (Credit Event Register)</span>
            <span className="text-[10px] text-slate-400 font-mono">
              共 {creditEvents.length} 个事件记录
            </span>
          </div>

          <div className="space-y-3">
            {creditEvents.map((evt) => (
              <div
                key={evt.id}
                className="bg-slate-950 border border-red-900/60 rounded p-3 text-xs space-y-2"
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2 font-bold text-red-400 font-mono">
                    <span>{evt.eventNo}</span>
                    <span className="bg-red-950 border border-red-800 px-1.5 py-0.5 rounded text-[10px]">
                      {evt.eventType}
                    </span>
                  </div>
                  <span className="text-slate-500 font-mono text-[10px]">
                    宣告日期: {evt.declaredDate}
                  </span>
                </div>

                <div className="font-semibold text-slate-100 text-sm">{evt.entityName}</div>
                <div className="text-slate-400 text-[11px]">{evt.description}</div>

                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 font-mono text-[11px]">
                  <div>
                    <span className="text-slate-500">预估回收率: </span>
                    <span className="text-amber-300 font-bold">{evt.estimatedRecovery}%</span>
                  </div>
                  <div>
                    <span className="text-slate-500">受影响名义本金: </span>
                    <span className="text-slate-200">¥ {(evt.affectedNotional / 100000000).toFixed(1)} 亿</span>
                  </div>
                  <div>
                    <span className="text-slate-500">清算损益影响: </span>
                    <span className="text-red-400 font-bold">¥ {evt.pnlImpact.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
