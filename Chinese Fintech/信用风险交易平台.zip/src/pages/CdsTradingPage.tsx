/**
 * CDS Trading Terminal & Trade Ticket Page (CDS 交易终端)
 * 具备完整量化定价引擎、生命周期追踪与敏捷风险估算的专业 CDS Trade Ticket
 */

import React, { useState, useEffect } from 'react';
import {
  Activity,
  ArrowRight,
  CheckCircle2,
  Clock,
  DollarSign,
  FileCheck2,
  HelpCircle,
  Layers,
  PlusCircle,
  RefreshCw,
  Repeat,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';
import { calculateCDSPricer } from '../lib/mathEngine';
import { EventType, SettlementType, DirectionType } from '../types';

export const CdsTradingPage: React.FC = () => {
  const {
    entities,
    selectedEntityId,
    selectEntity,
    counterparties,
    createCDSTrade,
    cdsTrades,
  } = useCreditStore();

  const selectedEntity = entities.find((e) => e.id === selectedEntityId) || entities[0];

  // Ticket Form state
  const [direction, setDirection] = useState<DirectionType>('买入保护');
  const [tradeType, setTradeType] = useState<'CDS' | 'CDS_INDEX'>('CDS');
  const [notionalMillions, setNotionalMillions] = useState<number>(500); // 500 million = 5亿元
  const [tenor, setTenor] = useState<'1Y' | '3Y' | '5Y' | '7Y' | '10Y'>('5Y');
  const [fixedCouponBp, setFixedCouponBp] = useState<number>(100);
  const [recoveryRatePct, setRecoveryRatePct] = useState<number>(selectedEntity.recoveryRate);
  const [settlementType, setSettlementType] = useState<SettlementType>('现金结算');
  const [selectedCounterpartyId, setSelectedCounterpartyId] = useState<string>(counterparties[0].id);
  const [selectedEvents, setSelectedEvents] = useState<EventType[]>(['破产', '支付违约', '债务重组']);

  // Trade lifecycle animation step
  const [activeStep, setActiveStep] = useState<number>(0); // 0=Editing, 1=Inquiry, 2=Quoted, 3=Executed, 4=Confirmed, 5=Settled
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Sync recovery rate when entity changes
  useEffect(() => {
    setRecoveryRatePct(selectedEntity.recoveryRate);
  }, [selectedEntityId]);

  const notionalBytes = notionalMillions * 1000000; // Convert 500M -> 500,000,000
  const tenorYears = parseInt(tenor.replace('Y', ''), 10) || 5;

  // Real-time Pricing output
  const pricerOutput = calculateCDSPricer({
    notional: notionalBytes,
    tenorYears,
    fixedCouponBp,
    marketSpreadBp: selectedEntity.spread5Y,
    recoveryRate: recoveryRatePct / 100,
    direction,
  });

  const handleCreateTrade = async () => {
    setIsSubmitting(true);
    setActiveStep(1); // 询价

    await new Promise((r) => setTimeout(r, 400));
    setActiveStep(2); // 报价

    await new Promise((r) => setTimeout(r, 400));
    setActiveStep(3); // 成交

    const counterparty = counterparties.find((c) => c.id === selectedCounterpartyId);

    createCDSTrade({
      referenceEntityId: selectedEntity.id,
      referenceEntityName: selectedEntity.name,
      notional: notionalBytes,
      tenor,
      fixedCoupon: fixedCouponBp,
      direction,
      recoveryRate: recoveryRatePct,
      creditEvents: selectedEvents,
      settlementType,
      counterpartyId: selectedCounterpartyId,
      counterpartyName: counterparty?.name || '招商银行股份有限公司',
    });

    await new Promise((r) => setTimeout(r, 300));
    setActiveStep(4); // 确认 / 登记 / 估值 / 风险计算

    await new Promise((r) => setTimeout(r, 300));
    setActiveStep(5); // 结算完成
    setIsSubmitting(false);
  };

  const toggleEvent = (evt: EventType) => {
    if (selectedEvents.includes(evt)) {
      setSelectedEvents(selectedEvents.filter((e) => e !== evt));
    } else {
      setSelectedEvents([...selectedEvents, evt]);
    }
  };

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      {/* Title & Ticket Header */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-3 rounded">
        <div className="flex items-center space-x-2">
          <Repeat className="w-5 h-5 text-red-500" />
          <h1 className="font-bold text-sm text-slate-100">CDS 信用违约互换专业交易终端 (Trade Ticket)</h1>
        </div>
        <div className="text-xs font-mono text-slate-400">
          参考实体: <span className="text-slate-100 font-bold">{selectedEntity.name}</span> ({selectedEntity.code}) · 市场利差: <span className="text-amber-400 font-bold">{selectedEntity.spread5Y} bp</span>
        </div>
      </div>

      {/* Main Grid: Ticket Form vs Quant Pricing Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 7 Cols: Trade Ticket Inputs */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4 space-y-4">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between items-center">
            <span>新建 CDS 交易要素填写</span>
            <span className="text-[10px] text-slate-500 font-mono">规范化标准合约 Ticket</span>
          </div>

          <div className="grid grid-cols-2 gap-4 text-xs">
            {/* Direction */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">交易方向</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setDirection('买入保护')}
                  className={`p-2 rounded font-bold text-xs border text-center transition-all ${
                    direction === '买入保护'
                      ? 'bg-blue-950 text-blue-200 border-blue-600 shadow-sm'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  买入保护 (Buy Protection)
                </button>
                <button
                  type="button"
                  onClick={() => setDirection('卖出保护')}
                  className={`p-2 rounded font-bold text-xs border text-center transition-all ${
                    direction === '卖出保护'
                      ? 'bg-purple-950 text-purple-200 border-purple-600 shadow-sm'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  卖出保护 (Sell Protection)
                </button>
              </div>
            </div>

            {/* Reference Entity Picker */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">参考实体 (Reference Entity)</label>
              <select
                value={selectedEntityId}
                onChange={(e) => selectEntity(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-slate-100 font-mono outline-hidden"
              >
                {entities.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} [{e.sector} · {e.rating} · {e.spread5Y}bp]
                  </option>
                ))}
              </select>
            </div>

            {/* Reference Obligation */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">参考债务 (Reference Obligation)</label>
              <input
                type="text"
                readOnly
                value={selectedEntity.obligations[0]?.code || '24通用中期票据01'}
                className="w-full bg-slate-950/80 border border-slate-800 rounded p-2 text-xs text-slate-300 font-mono"
              />
            </div>

            {/* Trade Type */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">交易类型</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setTradeType('CDS')}
                  className={`p-1.5 rounded font-medium border text-center ${
                    tradeType === 'CDS' ? 'bg-slate-800 text-slate-100 border-slate-600' : 'bg-slate-950 text-slate-500 border-slate-800'
                  }`}
                >
                  单体 CDS
                </button>
                <button
                  type="button"
                  onClick={() => setTradeType('CDS_INDEX')}
                  className={`p-1.5 rounded font-medium border text-center ${
                    tradeType === 'CDS_INDEX' ? 'bg-slate-800 text-slate-100 border-slate-600' : 'bg-slate-950 text-slate-500 border-slate-800'
                  }`}
                >
                  CDS 指数 (CDS Index)
                </button>
              </div>
            </div>

            {/* Notional */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">名义本金 (¥ 亿元)</label>
              <div className="relative">
                <input
                  type="number"
                  value={notionalMillions}
                  onChange={(e) => setNotionalMillions(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-amber-300 font-mono font-bold"
                />
                <span className="absolute right-2 top-2 text-[10px] text-slate-500 font-mono">
                  = ¥ {(notionalMillions * 100).toLocaleString()} 万元
                </span>
              </div>
            </div>

            {/* Tenor */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">保护期限 (Tenor)</label>
              <div className="grid grid-cols-5 gap-1 font-mono">
                {(['1Y', '3Y', '5Y', '7Y', '10Y'] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTenor(t)}
                    className={`py-1.5 rounded text-center border font-bold ${
                      tenor === t ? 'bg-amber-950 text-amber-300 border-amber-600' : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Fixed Coupon */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">约定固定费率 (Fixed Coupon bp)</label>
              <input
                type="number"
                value={fixedCouponBp}
                onChange={(e) => setFixedCouponBp(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-slate-100 font-mono"
              />
            </div>

            {/* Recovery Rate */}
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">假设回收率 (Recovery Rate %)</label>
              <input
                type="number"
                value={recoveryRatePct}
                onChange={(e) => setRecoveryRatePct(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-slate-100 font-mono"
              />
            </div>

            {/* Counterparty */}
            <div className="space-y-1 col-span-2">
              <label className="text-slate-400 text-[11px]">交易对手方 (Counterparty)</label>
              <select
                value={selectedCounterpartyId}
                onChange={(e) => setSelectedCounterpartyId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-slate-100 font-mono outline-hidden"
              >
                {counterparties.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} [{c.type} · 评级: {c.rating} · 剩余额度: ¥{c.availableLimit}亿]
                  </option>
                ))}
              </select>
            </div>

            {/* Credit Events Checkboxes */}
            <div className="space-y-1 col-span-2">
              <label className="text-slate-400 text-[11px]">约定触发信用事件 (Credit Events)</label>
              <div className="grid grid-cols-3 gap-2">
                {(['破产', '支付违约', '债务重组', '债务加速到期', '潜在加速到期'] as EventType[]).map((evt) => {
                  const isChecked = selectedEvents.includes(evt);
                  return (
                    <button
                      key={evt}
                      type="button"
                      onClick={() => toggleEvent(evt)}
                      className={`p-1.5 rounded text-[11px] border font-medium text-left flex items-center space-x-1 ${
                        isChecked ? 'bg-slate-800 text-slate-100 border-slate-600' : 'bg-slate-950 text-slate-500 border-slate-800'
                      }`}
                    >
                      <input type="checkbox" checked={isChecked} readOnly className="rounded" />
                      <span>{evt}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Submit Action Button */}
          <div className="pt-2">
            <button
              onClick={handleCreateTrade}
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-red-800 to-amber-700 hover:from-red-700 hover:to-amber-600 text-white font-bold py-2.5 rounded shadow-lg text-xs flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
            >
              <Zap className="w-4 h-4 text-amber-300" />
              <span>{isSubmitting ? '模拟交易匹配及量化计算中...' : '提交并发起模拟成交'}</span>
            </button>
          </div>
        </div>

        {/* Right 5 Cols: Quantitative Pricing Engine Outputs (Section V/VII Mandated) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 space-y-4">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between items-center">
            <span>CDS 定价与风险量化分析引擎 (Real-time Solver)</span>
            <span className="text-[10px] text-amber-400 font-mono">ISDA / CIBM 标准模型</span>
          </div>

          {/* Key Spreads & Values Grid */}
          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500">理论利差 (Fair Spread)</div>
              <div className="text-sm font-bold text-amber-300">{pricerOutput.fairSpreadBp} bp</div>
            </div>

            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500">市场利差 (Market Spread)</div>
              <div className="text-sm font-bold text-slate-200">{selectedEntity.spread5Y} bp</div>
            </div>

            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500">交易利差 (Coupon)</div>
              <div className="text-sm font-bold text-blue-400">{fixedCouponBp} bp</div>
            </div>

            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[10px] text-slate-500">预付款率 (Upfront %)</div>
              <div className="text-sm font-bold text-purple-400">{pricerOutput.upfrontPct}%</div>
            </div>
          </div>

          {/* CDS Pricing Decomposition (Section VII Mandated) */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
            <div className="text-[11px] font-bold text-slate-300 border-b border-slate-800 pb-1">
              CDS 定价分解 (Valuation Decomposition)
            </div>
            <div className="space-y-1.5 text-xs font-mono">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">保护腿 (Protection Leg PV):</span>
                <span className="text-slate-200 font-bold">¥ {pricerOutput.protectionLegPV.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">保费腿 (Premium Leg PV):</span>
                <span className="text-slate-200 font-bold">¥ {pricerOutput.premiumLegPV.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center border-t border-slate-800 pt-1">
                <span className="text-slate-300 font-bold">净现值 (Clean PV):</span>
                <span className={`text-sm font-bold ${pricerOutput.cleanPV >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  ¥ {pricerOutput.cleanPV.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          {/* Risk Sensitivity Metrics */}
          <div className="grid grid-cols-3 gap-2 text-xs font-mono text-center">
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[9px] text-slate-500">CS01 (1bp利差)</div>
              <div className="text-xs font-bold text-slate-200">¥ {pricerOutput.cs01.toLocaleString()}</div>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[9px] text-slate-500">DV01 (1bp利率)</div>
              <div className="text-xs font-bold text-slate-200">¥ {pricerOutput.dv01.toLocaleString()}</div>
            </div>
            <div className="bg-slate-950 p-2 rounded border border-slate-800">
              <div className="text-[9px] text-slate-500">PV01 (年金现值)</div>
              <div className="text-xs font-bold text-slate-200">¥ {pricerOutput.pv01.toLocaleString()}</div>
            </div>
          </div>

          {/* Risk & Credit Probability */}
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-slate-500">1年/5年 累计违约概率:</span>
              <span className="text-amber-400">{pricerOutput.defaultProb1Y}% / {pricerOutput.defaultProb5Y}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">预期损失 (Expected Loss):</span>
              <span className="text-slate-200">¥ {pricerOutput.expectedLoss.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">对手方 CVA 扣减:</span>
              <span className="text-purple-400">¥ {pricerOutput.cva.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Trade Lifecycle Stepper (Section V Mandated: 询价 -> 报价 -> 成交 -> 确认 -> 登记 -> 估值 -> 风险计算 -> 结算) */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
        <div className="text-xs font-bold text-slate-200 flex justify-between items-center">
          <span>CDS 交易生命周期流程状态 (Trade Lifecycle Tracker)</span>
          <span className="text-[10px] font-mono text-slate-500">
            {activeStep === 0 ? '准备就绪' : activeStep === 5 ? '完整生命周期已被全流程处理' : '处理中...'}
          </span>
        </div>

        <div className="grid grid-cols-8 gap-2 text-center text-xs font-mono">
          {[
            { step: 1, label: '1. 询价' },
            { step: 2, label: '2. 报价' },
            { step: 3, label: '3. 成交' },
            { step: 4, label: '4. 确认' },
            { step: 5, label: '5. 登记' },
            { step: 5, label: '6. 估值' },
            { step: 5, label: '7. 风险计算' },
            { step: 5, label: '8. 结算' },
          ].map((item, idx) => {
            const isDone = activeStep >= item.step;
            return (
              <div
                key={idx}
                className={`p-2 rounded border transition-all ${
                  isDone
                    ? 'bg-emerald-950/80 text-emerald-200 border-emerald-700 font-bold'
                    : 'bg-slate-950 text-slate-600 border-slate-800'
                }`}
              >
                <div className="text-[10px]">{item.label}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent CDS Blotter Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-3 space-y-2">
        <div className="text-xs font-bold text-slate-200">成交流水台账 (CDS Trade Blotter)</div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
                <th className="p-2">交易编号</th>
                <th className="p-2">方向</th>
                <th className="p-2">参考实体</th>
                <th className="p-2 text-right">名义本金</th>
                <th className="p-2">期限</th>
                <th className="p-2 text-right">交易费率</th>
                <th className="p-2 text-right">净现值(PV)</th>
                <th className="p-2">对手方</th>
                <th className="p-2">状态</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {cdsTrades.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/50">
                  <td className="p-2 text-blue-400 font-bold">{t.tradeNo}</td>
                  <td className="p-2">
                    <span className={`px-1 rounded ${t.direction === '买入保护' ? 'bg-blue-950 text-blue-300' : 'bg-purple-950 text-purple-300'}`}>
                      {t.direction}
                    </span>
                  </td>
                  <td className="p-2 text-slate-200">{t.referenceEntityName}</td>
                  <td className="p-2 text-right text-amber-300 font-bold">¥ {(t.notional / 100000000).toFixed(1)} 亿</td>
                  <td className="p-2">{t.tenor}</td>
                  <td className="p-2 text-right">{t.fixedCoupon} bp</td>
                  <td className="p-2 text-right text-emerald-400 font-bold">¥ {t.cleanPV.toLocaleString()}</td>
                  <td className="p-2 text-slate-400">{t.counterpartyName}</td>
                  <td className="p-2">
                    <span className="bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded text-[10px]">
                      {t.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
