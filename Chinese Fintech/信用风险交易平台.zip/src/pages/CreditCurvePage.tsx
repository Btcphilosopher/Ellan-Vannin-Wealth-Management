/**
 * Credit Curve Studio Page (信用风险曲线中心)
 * 具备多期限节点调整、Hazard Rate Bootstrap 重新推导与历史/压力情景多曲线叠对比功能
 */

import React, { useState } from 'react';
import {
  Activity,
  ArrowRight,
  BarChart,
  GitCompare,
  Layers,
  RefreshCw,
  Sliders,
  TrendingUp,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';
import { bootstrapHazardCurve } from '../lib/mathEngine';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';

export const CreditCurvePage: React.FC = () => {
  const { entities, selectedEntityId, selectEntity, updateEntitySpreadAndRecalculate } = useCreditStore();

  const entity = entities.find((e) => e.id === selectedEntityId) || entities[0];

  // Editable tenor spreads for the selected entity curve
  const [spread1Y, setSpread1Y] = useState<number>(Math.round(entity.spread5Y * 0.65));
  const [spread2Y, setSpread2Y] = useState<number>(Math.round(entity.spread5Y * 0.78));
  const [spread3Y, setSpread3Y] = useState<number>(Math.round(entity.spread5Y * 0.88));
  const [spread5Y, setSpread5Y] = useState<number>(entity.spread5Y);
  const [spread7Y, setSpread7Y] = useState<number>(Math.round(entity.spread5Y * 1.15));
  const [spread10Y, setSpread10Y] = useState<number>(Math.round(entity.spread5Y * 1.35));
  const [recoveryRate, setRecoveryRate] = useState<number>(entity.recoveryRate);

  // Comparison curves toggle
  const [showYesterday, setShowYesterday] = useState<boolean>(true);
  const [showOneWeekAgo, setShowOneWeekAgo] = useState<boolean>(true);
  const [showOneMonthAgo, setShowOneMonthAgo] = useState<boolean>(false);
  const [showStressCurve, setShowStressCurve] = useState<boolean>(true);

  // Re-bootstrap curve points
  const bootstrappedPoints = bootstrapHazardCurve(
    [1, 2, 3, 5, 7, 10],
    [spread1Y, spread2Y, spread3Y, spread5Y, spread7Y, spread10Y],
    recoveryRate / 100
  );

  // Combined chart dataset
  const chartData = [
    { tenor: '1Y', current: spread1Y, yesterday: Math.round(spread1Y * 0.96), weekAgo: Math.round(spread1Y * 0.91), monthAgo: Math.round(spread1Y * 0.85), stress: Math.round(spread1Y + 75) },
    { tenor: '2Y', current: spread2Y, yesterday: Math.round(spread2Y * 0.97), weekAgo: Math.round(spread2Y * 0.92), monthAgo: Math.round(spread2Y * 0.86), stress: Math.round(spread2Y + 90) },
    { tenor: '3Y', current: spread3Y, yesterday: Math.round(spread3Y * 0.98), weekAgo: Math.round(spread3Y * 0.93), monthAgo: Math.round(spread3Y * 0.88), stress: Math.round(spread3Y + 110) },
    { tenor: '5Y', current: spread5Y, yesterday: Math.round(spread5Y * 0.98), weekAgo: Math.round(spread5Y * 0.94), monthAgo: Math.round(spread5Y * 0.90), stress: Math.round(spread5Y + 140) },
    { tenor: '7Y', current: spread7Y, yesterday: Math.round(spread7Y * 0.99), weekAgo: Math.round(spread7Y * 0.95), monthAgo: Math.round(spread7Y * 0.91), stress: Math.round(spread7Y + 170) },
    { tenor: '10Y', current: spread10Y, yesterday: Math.round(spread10Y * 0.99), weekAgo: Math.round(spread10Y * 0.96), monthAgo: Math.round(spread10Y * 0.92), stress: Math.round(spread10Y + 200) },
  ];

  const handleApplyCurveChanges = () => {
    updateEntitySpreadAndRecalculate(entity.id, spread5Y, recoveryRate);
  };

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      {/* Header Bar */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex flex-wrap items-center justify-between text-xs gap-2">
        <div className="flex items-center space-x-3">
          <Activity className="w-5 h-5 text-amber-400" />
          <div>
            <div className="font-bold text-sm text-slate-100">
              信用曲线分析与 Bootstrapping 求解中心 (Credit Curve Studio)
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              参考实体: <span className="text-amber-300 font-bold">{entity.name}</span> | 曲线标识: CDS-{entity.code}-20260919
            </div>
          </div>
        </div>

        {/* Entity Selector */}
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 text-xs">选择参考实体:</span>
          <select
            value={selectedEntityId}
            onChange={(e) => selectEntity(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded p-1.5 font-mono outline-hidden"
          >
            {entities.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name} [{e.rating} · 5Y CDS {e.spread5Y}bp]
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 8 Cols: Chart & Bootstrapped Hazard Curve */}
        <div className="lg:col-span-8 space-y-4">
          {/* Main Comparison Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-xs text-slate-100">
                CDS 信用期限结构利差曲线对比 (Term Structure Spread Curves - bp)
              </span>

              {/* Curve Comparison Toggles */}
              <div className="flex items-center space-x-3 text-[11px] font-mono">
                <label className="flex items-center space-x-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showYesterday}
                    onChange={(e) => setShowYesterday(e.target.checked)}
                    className="rounded"
                  />
                  <span className="text-blue-400">昨日</span>
                </label>
                <label className="flex items-center space-x-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showOneWeekAgo}
                    onChange={(e) => setShowOneWeekAgo(e.target.checked)}
                    className="rounded"
                  />
                  <span className="text-emerald-400">一周前</span>
                </label>
                <label className="flex items-center space-x-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showStressCurve}
                    onChange={(e) => setShowStressCurve(e.target.checked)}
                    className="rounded"
                  />
                  <span className="text-red-400">压力情景</span>
                </label>
              </div>
            </div>

            {/* Line Chart */}
            <div className="h-72 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="tenor" stroke="#64748b" fontSize={11} />
                  <YAxis stroke="#64748b" fontSize={11} domain={['auto', 'auto']} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                  <Line type="monotone" dataKey="current" name="当前曲线" stroke="#f59e0b" strokeWidth={3} dot={{ r: 4 }} />
                  {showYesterday && <Line type="monotone" dataKey="yesterday" name="昨日曲线" stroke="#3b82f6" strokeDasharray="3 3" />}
                  {showOneWeekAgo && <Line type="monotone" dataKey="weekAgo" name="一周前曲线" stroke="#10b981" strokeDasharray="5 5" />}
                  {showStressCurve && <Line type="monotone" dataKey="stress" name="压力冲击曲线" stroke="#ef4444" strokeWidth={2} />}
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Bootstrapped Survival Probabilities & Hazard Rates Table */}
          <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-2">
            <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2">
              Bootstrapping 求解分析表 (Hazard Rates λ & Survival Probabilities S(t))
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse font-mono">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
                    <th className="p-2">期限 (Tenor)</th>
                    <th className="p-2 text-right">市场 CDS 利差</th>
                    <th className="p-2 text-right">Hazard Rate (λ)</th>
                    <th className="p-2 text-right">生存概率 S(t)</th>
                    <th className="p-2 text-right">违约概率 PD(t)</th>
                    <th className="p-2 text-right">贴现因子 D(t)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-[11px]">
                  {bootstrappedPoints.map((pt, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/50">
                      <td className="p-2 font-bold text-amber-300">{pt.tenor} 年</td>
                      <td className="p-2 text-right text-slate-100">
                        {chartData[idx].current} bp
                      </td>
                      <td className="p-2 text-right text-purple-300">{pt.hazardRate}</td>
                      <td className="p-2 text-right text-emerald-400">
                        {(pt.survivalProb * 100).toFixed(2)}%
                      </td>
                      <td className="p-2 text-right text-red-400">
                        {((1 - pt.survivalProb) * 100).toFixed(2)}%
                      </td>
                      <td className="p-2 text-right text-slate-400">{pt.discountFactor}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right 4 Cols: Curve Node Editor Controls */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded p-4 space-y-4">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between items-center">
            <span>曲线节点校准与参数编辑</span>
            <Sliders className="w-4 h-4 text-amber-400" />
          </div>

          <div className="space-y-3 text-xs">
            {/* Tenor Sliders */}
            <div className="space-y-2 font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">1Y Spread:</span>
                <span className="text-amber-300 font-bold">{spread1Y} bp</span>
              </div>
              <input
                type="range"
                min={10}
                max={1500}
                value={spread1Y}
                onChange={(e) => setSpread1Y(Number(e.target.value))}
                className="w-full accent-amber-500"
              />

              <div className="flex justify-between">
                <span className="text-slate-400">3Y Spread:</span>
                <span className="text-amber-300 font-bold">{spread3Y} bp</span>
              </div>
              <input
                type="range"
                min={10}
                max={1500}
                value={spread3Y}
                onChange={(e) => setSpread3Y(Number(e.target.value))}
                className="w-full accent-amber-500"
              />

              <div className="flex justify-between">
                <span className="text-slate-400">5Y Spread (基准):</span>
                <span className="text-amber-300 font-bold">{spread5Y} bp</span>
              </div>
              <input
                type="range"
                min={10}
                max={1500}
                value={spread5Y}
                onChange={(e) => setSpread5Y(Number(e.target.value))}
                className="w-full accent-amber-500"
              />

              <div className="flex justify-between">
                <span className="text-slate-400">10Y Spread:</span>
                <span className="text-amber-300 font-bold">{spread10Y} bp</span>
              </div>
              <input
                type="range"
                min={10}
                max={1500}
                value={spread10Y}
                onChange={(e) => setSpread10Y(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            {/* Recovery Rate */}
            <div className="space-y-1 font-mono pt-2 border-t border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">设定回收率 Recovery %:</span>
                <span className="text-blue-400 font-bold">{recoveryRate}%</span>
              </div>
              <input
                type="range"
                min={5}
                max={90}
                value={recoveryRate}
                onChange={(e) => setRecoveryRate(Number(e.target.value))}
                className="w-full accent-blue-500"
              />
            </div>

            {/* Re-calculate Button */}
            <div className="pt-2">
              <button
                onClick={handleApplyCurveChanges}
                className="w-full bg-blue-900 hover:bg-blue-800 text-blue-100 font-bold py-2 rounded shadow text-xs flex items-center justify-center space-x-2 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>重新校准并重估全组合位置</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
