/**
 * CRMW Module & Bond Issuance Linkage Simulator Page
 * 信用风险缓释凭证 (CRMW) 创设、二级交易与【CRMW+债券发行联动模拟器】
 */

import React, { useState } from 'react';
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  Coins,
  FileCheck,
  FileSpreadsheet,
  Layers,
  Play,
  PlusCircle,
  RefreshCw,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';

export const CrmwPage: React.FC = () => {
  const {
    crmwInstruments,
    entities,
    createCRMWInstrument,
    selectedEntityId,
    selectEntity,
  } = useCreditStore();

  const selectedEntity = entities.find((e) => e.id === selectedEntityId) || entities[0];

  // New CRMW creation form state
  const [issuer, setIssuer] = useState('招商银行股份有限公司');
  const [creationAmount, setCreationAmount] = useState<number>(2.0); // 2.0 亿元
  const [termMonths, setTermMonths] = useState<number>(36);
  const [feeRateBp, setFeeRateBp] = useState<number>(135);
  const [issuePrice, setIssuePrice] = useState<number>(1.35);

  // Linkage Simulator animation state
  const [simStep, setSimStep] = useState<number>(0); // 0=Idle, 1=BondIssue, 2=CRMWCreate, 3=InvestorProtected, 4=Completed
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const handleCreateCRMW = () => {
    createCRMWInstrument({
      issuer,
      referenceEntityId: selectedEntity.id,
      referenceEntityName: selectedEntity.name,
      creationAmount,
      termMonths,
      feeRate: feeRateBp,
      issuePrice,
    });
  };

  const handleRunLinkageSim = async () => {
    setIsSimulating(true);
    setSimStep(1); // 债券发行 ¥10亿元

    await new Promise((r) => setTimeout(r, 800));
    setSimStep(2); // CRMW创设 ¥2亿元

    await new Promise((r) => setTimeout(r, 800));
    setSimStep(3); // 投资者获得保护 ¥2亿元

    await new Promise((r) => setTimeout(r, 800));
    setSimStep(4); // 债券发行全额完成！
    setIsSimulating(false);
  };

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <FileSpreadsheet className="w-5 h-5 text-amber-400" />
          <h1 className="font-bold text-sm text-slate-100">
            信用风险缓释凭证 (CRMW) 交易与联动模拟中心
          </h1>
        </div>
        <span className="text-xs font-mono text-slate-400">
          中国银行间市场交易商协会 (NAFMII) 标准结构化工具
        </span>
      </div>

      {/* Section 1: CRMW + Bond Issuance Linkage Simulator (Prompt X Mandated) */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="font-bold text-xs text-slate-100">
              【CRMW + 债券发行联动联动模拟器】(Bond Issuance Protected Simulator)
            </span>
          </div>
          <button
            onClick={handleRunLinkageSim}
            disabled={isSimulating}
            className="px-3 py-1 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-bold rounded text-xs flex items-center space-x-1.5 transition-all shadow disabled:opacity-50"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isSimulating ? '联动演示运行中...' : '启动 CRMW 增信发债全流程演示'}</span>
          </button>
        </div>

        {/* Linkage Animated Flow Diagram */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-center text-xs font-mono">
          {/* Step 1 */}
          <div
            className={`p-3 rounded border transition-all space-y-1 ${
              simStep >= 1
                ? 'bg-amber-950/80 text-amber-200 border-amber-600 font-bold scale-102 shadow'
                : 'bg-slate-950 text-slate-500 border-slate-800'
            }`}
          >
            <div className="text-[10px] text-slate-400">步骤 1</div>
            <div className="text-sm font-bold text-slate-100">债券发行</div>
            <div className="text-amber-400 font-bold">¥ 10.0 亿元</div>
            <div className="text-[10px] text-slate-400">民营/高收益主体发债</div>
          </div>

          {/* Step 2 */}
          <div
            className={`p-3 rounded border transition-all space-y-1 ${
              simStep >= 2
                ? 'bg-blue-950/80 text-blue-200 border-blue-600 font-bold scale-102 shadow'
                : 'bg-slate-950 text-slate-500 border-slate-800'
            }`}
          >
            <div className="text-[10px] text-slate-400">步骤 2</div>
            <div className="text-sm font-bold text-slate-100">CRMW凭证创设</div>
            <div className="text-blue-400 font-bold">¥ 2.0 亿元</div>
            <div className="text-[10px] text-slate-400">创设机构提供信用背书</div>
          </div>

          {/* Step 3 */}
          <div
            className={`p-3 rounded border transition-all space-y-1 ${
              simStep >= 3
                ? 'bg-purple-950/80 text-purple-200 border-purple-600 font-bold scale-102 shadow'
                : 'bg-slate-950 text-slate-500 border-slate-800'
            }`}
          >
            <div className="text-[10px] text-slate-400">步骤 3</div>
            <div className="text-sm font-bold text-slate-100">投资者信用保护</div>
            <div className="text-purple-300 font-bold">¥ 2.0 亿元</div>
            <div className="text-[10px] text-slate-400">认购凭证锁定下行风险</div>
          </div>

          {/* Step 4 */}
          <div
            className={`p-3 rounded border transition-all space-y-1 ${
              simStep >= 4
                ? 'bg-emerald-950/80 text-emerald-200 border-emerald-600 font-bold scale-102 shadow'
                : 'bg-slate-950 text-slate-500 border-slate-800'
            }`}
          >
            <div className="text-[10px] text-slate-400">步骤 4</div>
            <div className="text-sm font-bold text-slate-100">债券发行圆满完成</div>
            <div className="text-emerald-400 font-bold">100% 认购完毕</div>
            <div className="text-[10px] text-emerald-300">融资金额全额到账</div>
          </div>
        </div>
      </div>

      {/* Main Content: CRMW Creation Ticket vs CRMW Market Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 5 Cols: CRMW Creation Ticket */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
            <span>创设机构发起 CRMW (Creation Ticket)</span>
            <span className="text-[10px] text-slate-500 font-mono">创设登记者</span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">创设机构 (Issuer)</label>
              <input
                type="text"
                value={issuer}
                onChange={(e) => setIssuer(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-100 font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-400 text-[11px]">参考实体 (Reference Entity)</label>
              <select
                value={selectedEntityId}
                onChange={(e) => selectEntity(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-100 font-mono"
              >
                {entities.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} [{e.rating}]
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2 font-mono">
              <div>
                <label className="text-slate-400 text-[11px]">创设规模 (亿元)</label>
                <input
                  type="number"
                  value={creationAmount}
                  onChange={(e) => setCreationAmount(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-amber-300 font-bold"
                />
              </div>
              <div>
                <label className="text-slate-400 text-[11px]">保护期限 (月)</label>
                <input
                  type="number"
                  value={termMonths}
                  onChange={(e) => setTermMonths(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 font-mono">
              <div>
                <label className="text-slate-400 text-[11px]">保护费率 (bp)</label>
                <input
                  type="number"
                  value={feeRateBp}
                  onChange={(e) => setFeeRateBp(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-100"
                />
              </div>
              <div>
                <label className="text-slate-400 text-[11px]">发行价格 (元/百元)</label>
                <input
                  type="number"
                  step="0.01"
                  value={issuePrice}
                  onChange={(e) => setIssuePrice(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-slate-100"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={handleCreateCRMW}
                className="w-full bg-amber-700 hover:bg-amber-600 text-white font-bold py-2 rounded shadow text-xs flex items-center justify-center space-x-1.5 transition-colors"
              >
                <PlusCircle className="w-4 h-4" />
                <span>登记并创设 CRMW 凭证</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right 7 Cols: CRMW Market Quote Table */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
            <span>CRMW 二级市场行情 (Secondary Market Quotes)</span>
            <span className="text-[10px] text-emerald-400 font-mono">上海清算所/大平层交易系统</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
                  <th className="p-2">凭证代码</th>
                  <th className="p-2">参考实体</th>
                  <th className="p-2">创设机构</th>
                  <th className="p-2 text-right">规模</th>
                  <th className="p-2 text-right">现价</th>
                  <th className="p-2 text-right">保护费率</th>
                  <th className="p-2 text-right">成交量</th>
                  <th className="p-2">状态</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[11px]">
                {crmwInstruments.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-800/50">
                    <td className="p-2 font-bold text-blue-400">{c.code}</td>
                    <td className="p-2 text-slate-200">{c.referenceEntityName}</td>
                    <td className="p-2 text-slate-400">{c.issuer}</td>
                    <td className="p-2 text-right text-amber-300 font-bold">¥ {c.creationAmount} 亿</td>
                    <td className="p-2 text-right text-slate-100">¥ {c.marketPrice}</td>
                    <td className="p-2 text-right text-purple-300">{c.feeRate} bp</td>
                    <td className="p-2 text-right text-slate-400">{c.volume24h} 万</td>
                    <td className="p-2">
                      <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.5 rounded text-[10px]">
                        {c.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
