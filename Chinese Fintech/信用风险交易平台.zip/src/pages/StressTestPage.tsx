/**
 * Stress Testing Laboratory Page (信用压力测试实验室)
 * 预设多阶冲击情景、自定义情景构建与组合重估（组合损失 / CVA变化 / VaR变化 / 资本占用增量）
 */

import React, { useState } from 'react';
import {
  AlertTriangle,
  Flame,
  Layers,
  Play,
  PlusCircle,
  RefreshCw,
  ShieldAlert,
  Sliders,
  TrendingDown,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';

export const StressTestPage: React.FC = () => {
  const { stressScenarios, runStressTest, activeStressResult } = useCreditStore();

  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(stressScenarios[0].id);

  // Custom scenario creator state
  const [customName, setCustomName] = useState('自定义极端流动性枯竭情景');
  const [customSpreadShift, setCustomSpreadShift] = useState<number>(180);
  const [customPdMult, setCustomPdMult] = useState<number>(2.2);

  const selectedScenario = stressScenarios.find((s) => s.id === selectedScenarioId) || stressScenarios[0];

  const handleRunTest = () => {
    runStressTest(selectedScenarioId);
  };

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Flame className="w-5 h-5 text-amber-500 animate-pulse" />
          <h1 className="font-bold text-sm text-slate-100">
            信用风险压力测试实验室 (Credit Stress Testing Lab)
          </h1>
        </div>
        <span className="text-xs font-mono text-slate-400">
          巴塞尔协议 III / 中国银保监会信用风险压力测试框架
        </span>
      </div>

      {/* Main Grid: Preset Scenarios vs Test Results */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 5 Cols: Scenario Selector */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
            <span>预设压力情景选择 (Preset Scenarios)</span>
            <span className="text-[10px] text-slate-500 font-mono">宏观与行业因子</span>
          </div>

          <div className="space-y-2">
            {stressScenarios.map((scen) => {
              const isSelected = selectedScenarioId === scen.id;
              return (
                <button
                  key={scen.id}
                  onClick={() => setSelectedScenarioId(scen.id)}
                  className={`w-full text-left p-2.5 rounded border transition-all text-xs font-sans ${
                    isSelected
                      ? 'bg-amber-950/80 border-amber-600 text-amber-200 font-bold shadow'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-slate-100 font-bold">{scen.name}</span>
                    <span className="text-[10px] font-mono bg-slate-900 px-1.5 py-0.5 rounded text-amber-400">
                      +{scen.spreadShiftBp} bp
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400">{scen.description}</div>
                </button>
              );
            })}
          </div>

          {/* Execute Test Button */}
          <div className="pt-2">
            <button
              onClick={handleRunTest}
              className="w-full bg-gradient-to-r from-amber-700 to-red-700 hover:from-amber-600 hover:to-red-600 text-white font-bold py-2.5 rounded shadow text-xs flex items-center justify-center space-x-2 transition-all"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>运行压力测试重估 (Run Stress Engine)</span>
            </button>
          </div>
        </div>

        {/* Right 7 Cols: Stress Test Results Panel (Section XVI Mandated) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4 space-y-4">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
            <span>压力测试输出报告 ({selectedScenario.name})</span>
            <span className="text-[10px] text-amber-400 font-mono">实时计算模型</span>
          </div>

          {activeStressResult ? (
            <div className="space-y-4 font-mono text-xs">
              {/* Primary Output Cards */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                <div className="bg-slate-950 p-3 rounded border border-red-900/60 space-y-1">
                  <div className="text-[10px] text-slate-400">组合预期总损失</div>
                  <div className="text-base font-bold text-red-400">
                    ¥ {activeStressResult.portfolioLoss.toLocaleString()}
                  </div>
                  <div className="text-[9px] text-slate-500">CS01 冲击损益</div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-purple-900/60 space-y-1">
                  <div className="text-[10px] text-slate-400">CVA 扣减变动</div>
                  <div className="text-base font-bold text-purple-300">
                    +¥ {activeStressResult.cvaChange.toLocaleString()}
                  </div>
                  <div className="text-[9px] text-slate-500">对手方风险增加</div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-amber-900/60 space-y-1">
                  <div className="text-[10px] text-slate-400">VaR 95% 增加额</div>
                  <div className="text-base font-bold text-amber-300">
                    +¥ {activeStressResult.varChange.toLocaleString()}
                  </div>
                  <div className="text-[9px] text-slate-500">尾部风险扩大</div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                  <div className="text-[10px] text-slate-400">模拟违约实体数</div>
                  <div className="text-base font-bold text-red-400">
                    {activeStressResult.simulatedDefaults} 个实体
                  </div>
                  <div className="text-[9px] text-slate-500">PD &gt; 35% 高危</div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                  <div className="text-[10px] text-slate-400">风控限额超标项</div>
                  <div className="text-base font-bold text-amber-400">
                    {activeStressResult.breachedLimitsCount} 项超限
                  </div>
                  <div className="text-[9px] text-slate-500">需要风控委员会特批</div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                  <div className="text-[10px] text-slate-400">监管资本占用增量</div>
                  <div className="text-base font-bold text-slate-100">
                    +¥ {activeStressResult.capitalChargeImpact.toLocaleString()}
                  </div>
                  <div className="text-[9px] text-slate-500">RWA 风险加权资产</div>
                </div>
              </div>

              {/* Stress Analysis Summary Box */}
              <div className="bg-slate-950 p-3 rounded border border-slate-800 text-xs space-y-2 font-sans">
                <div className="font-bold text-slate-200">压测结论与风控建议</div>
                <div className="text-slate-400 text-[11px] leading-relaxed">
                  在 <span className="text-amber-300 font-semibold">{selectedScenario.name}</span> 下，平台组合受地产与高收益制造板块利差走阔影响显著。建议对集中度超限的单一实体进行卖出保护或创设 CRMW 信用对冲。
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs font-mono">
              请在左侧选择压力情景并点击“运行压力测试重估”按钮...
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
