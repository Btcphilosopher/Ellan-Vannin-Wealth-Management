/**
 * Additional Specialized Pages Module for China Credit Risk Workstation
 * 聚合包含：信用市场、CRM工具箱、CRMA合约、CLN票据、信用指数、参考实体、债券池、交易组合、风险敏感性、限额管理、抵押品、交易审批、市场数据、研究分析、回放系统
 */

import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  BarChart2,
  BookOpen,
  Building2,
  CheckCircle2,
  Clock,
  Coins,
  FileCheck2,
  FileSpreadsheet,
  FileText,
  Filter,
  Flame,
  History,
  Layers,
  LineChart,
  PieChart,
  Play,
  PlusCircle,
  Repeat,
  RotateCcw,
  Scale,
  Search,
  Shield,
  ShieldAlert,
  Sliders,
  TrendingUp,
  Workflow,
  Zap,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';

// ==========================================
// 1. MarketPage (信用市场 - 100个实体列表与多维过滤)
// ==========================================
export const MarketPage: React.FC = () => {
  const { entities, selectEntity, setActiveTab } = useCreditStore();
  const [search, setSearch] = useState('');
  const [selectedSector, setSelectedSector] = useState('全部');

  const sectors = ['全部', '能源', '制造', '房地产', '基础设施', '城投', '科技', '消费', '金融'];

  const filtered = entities.filter((e) => {
    const matchSearch = e.name.includes(search) || e.code.includes(search);
    const matchSector = selectedSector === '全部' || e.sector === selectedSector;
    return matchSearch && matchSector;
  });

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <h1 className="font-bold text-sm text-slate-100">
            中国银行间信用衍生品市场行情 (100 参考实体 Live Terminal)
          </h1>
        </div>
        <span className="text-xs font-mono text-slate-400">
          共 {filtered.length} 个实体行情
        </span>
      </div>

      {/* Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded p-3 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center space-x-2 w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="搜索参考实体名称或代码..."
            className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-xs text-slate-100 outline-hidden font-mono"
          />
        </div>

        <div className="flex items-center space-x-1 font-mono">
          <span className="text-slate-400">板块筛选:</span>
          {sectors.map((sec) => (
            <button
              key={sec}
              onClick={() => setSelectedSector(sec)}
              className={`px-2 py-1 rounded text-[11px] font-bold ${
                selectedSector === sec
                  ? 'bg-blue-950 text-blue-300 border border-blue-700'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:bg-slate-800'
              }`}
            >
              {sec}
            </button>
          ))}
        </div>
      </div>

      {/* Entity Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-3 overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse font-mono">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
              <th className="p-2">代码</th>
              <th className="p-2">参考实体名称</th>
              <th className="p-2">板块</th>
              <th className="p-2">评级</th>
              <th className="p-2 text-right">5Y CDS (bp)</th>
              <th className="p-2 text-right">1Y PD (%)</th>
              <th className="p-2 text-right">5Y PD (%)</th>
              <th className="p-2 text-right">回收率 (%)</th>
              <th className="p-2 text-right">24h 变动</th>
              <th className="p-2 text-center">状态</th>
              <th className="p-2 text-center">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-[11px]">
            {filtered.map((e) => (
              <tr key={e.id} className="hover:bg-slate-800/50">
                <td className="p-2 text-blue-400 font-bold">{e.code}</td>
                <td className="p-2 font-sans font-semibold text-slate-200">{e.name}</td>
                <td className="p-2 text-slate-400">{e.sector}</td>
                <td className="p-2">
                  <span className="bg-slate-950 text-amber-300 px-1.5 py-0.5 rounded border border-slate-800 text-[10px] font-bold">
                    {e.rating}
                  </span>
                </td>
                <td className="p-2 text-right font-bold text-amber-300">{e.spread5Y} bp</td>
                <td className="p-2 text-right text-slate-300">{e.pd1Y}%</td>
                <td className="p-2 text-right text-slate-300">{e.pd5Y}%</td>
                <td className="p-2 text-right text-slate-400">{e.recoveryRate}%</td>
                <td className={`p-2 text-right font-bold ${e.spreadChange24h >= 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                  {e.spreadChange24h >= 0 ? `+${e.spreadChange24h}` : e.spreadChange24h} bp
                </td>
                <td className="p-2 text-center">
                  <span className={`px-1.5 py-0.5 rounded text-[10px] ${e.status === '正常' ? 'bg-emerald-950 text-emerald-300' : 'bg-red-950 text-red-300'}`}>
                    {e.status}
                  </span>
                </td>
                <td className="p-2 text-center font-sans">
                  <button
                    onClick={() => {
                      selectEntity(e.id);
                      setActiveTab('CDS交易');
                    }}
                    className="px-2 py-0.5 bg-blue-950 hover:bg-blue-900 text-blue-300 border border-blue-800 rounded text-[10px]"
                  >
                    交易 Ticket
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==========================================
// 2. CrmHubPage (CRM 工具箱 - CDS, CRMA, CRMW, CLN 概念导航)
// ==========================================
export const CrmHubPage: React.FC = () => {
  const { setActiveTab } = useCreditStore();

  const crmTools = [
    {
      title: 'CDS 信用违约互换 (Credit Default Swap)',
      desc: '双边场外信用衍生品标准合约，保护买方定期支付保费，违约时保护卖方理赔。',
      target: 'CDS交易',
      color: 'border-blue-700 bg-blue-950/40 text-blue-300',
    },
    {
      title: 'CRMW 信用风险缓释凭证 (Risk Mitigation Warrant)',
      desc: '由创设机构发行的标准化可交易凭证，可与标的债券发行形成保护联动。',
      target: 'CRMW',
      color: 'border-amber-700 bg-amber-950/40 text-amber-300',
    },
    {
      title: 'CRMA 信用风险缓释合约 (Risk Mitigation Agreement)',
      desc: '双边协商签订的定制化信用风险缓释合约，适应非标实体及个性化保护需求。',
      target: 'CRMA',
      color: 'border-purple-700 bg-purple-950/40 text-purple-300',
    },
    {
      title: 'CLN 信用联结票据 (Credit Linked Note)',
      desc: '附带信用衍生品条款的资金化 (Funded) 债券结构，投资者承担参考实体违约风险。',
      target: 'CLN',
      color: 'border-emerald-700 bg-emerald-950/40 text-emerald-300',
    },
  ];

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Layers className="w-5 h-5 text-amber-400" />
          <h1 className="font-bold text-sm text-slate-100">
            中国信用风险缓释工具 (CRM) 全产品矩阵
          </h1>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {crmTools.map((t) => (
          <div key={t.target} className={`border rounded p-4 space-y-2 ${t.color}`}>
            <h2 className="font-bold text-sm text-slate-100">{t.title}</h2>
            <p className="text-xs text-slate-300 leading-relaxed">{t.desc}</p>
            <button
              onClick={() => setActiveTab(t.target)}
              className="mt-2 px-3 py-1 bg-slate-900 border border-slate-700 text-slate-100 rounded text-xs hover:bg-slate-800 font-bold"
            >
              进入 {t.target} 交易模块 →
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

// ==========================================
// 3. CrmaPage (CRMA 合约)
// ==========================================
export const CrmaPage: React.FC = () => {
  const { crmaTrades } = useCreditStore();

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <FileCheck2 className="w-5 h-5 text-purple-400" />
          <h1 className="font-bold text-sm text-slate-100">
            CRMA 信用风险缓释合约管理 (Bilateral Agreement Manager)
          </h1>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded p-3 overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse font-mono">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
              <th className="p-2">合约编号</th>
              <th className="p-2">参考实体</th>
              <th className="p-2 text-right">名义本金</th>
              <th className="p-2">甲方 (Party A)</th>
              <th className="p-2">乙方 (Party B)</th>
              <th className="p-2 text-right">保护费率</th>
              <th className="p-2">状态</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-[11px]">
            {crmaTrades.map((a) => (
              <tr key={a.id} className="hover:bg-slate-800/50">
                <td className="p-2 text-purple-400 font-bold">{a.code}</td>
                <td className="p-2 text-slate-200">{a.referenceEntityName}</td>
                <td className="p-2 text-right text-amber-300 font-bold">¥ {(a.notional / 100000000).toFixed(1)} 亿</td>
                <td className="p-2 text-slate-300">{a.partyA}</td>
                <td className="p-2 text-slate-300">{a.partyB}</td>
                <td className="p-2 text-right text-slate-200">{a.feeRate} bp</td>
                <td className="p-2">
                  <span className="bg-emerald-950 text-emerald-300 px-1.5 py-0.5 rounded text-[10px]">
                    {a.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==========================================
// 4. ClnPage (CLN 信用联结票据)
// ==========================================
export const ClnPage: React.FC = () => {
  const { clnInstruments } = useCreditStore();

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Coins className="w-5 h-5 text-emerald-400" />
          <h1 className="font-bold text-sm text-slate-100">
            CLN 信用联结票据 (Credit Linked Notes Center)
          </h1>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded p-3 overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse font-mono">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
              <th className="p-2">票据代码</th>
              <th className="p-2">发行机构</th>
              <th className="p-2">参考实体</th>
              <th className="p-2 text-right">发行规模</th>
              <th className="p-2 text-right">票面利率</th>
              <th className="p-2 text-right">CDS 信用溢价</th>
              <th className="p-2">到期日</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-[11px]">
            {clnInstruments.map((n) => (
              <tr key={n.id} className="hover:bg-slate-800/50">
                <td className="p-2 text-emerald-400 font-bold">{n.code}</td>
                <td className="p-2 text-slate-300">{n.issuer}</td>
                <td className="p-2 text-slate-200">{n.referenceEntityName}</td>
                <td className="p-2 text-right text-amber-300 font-bold">¥ {(n.notional / 100000000).toFixed(1)} 亿</td>
                <td className="p-2 text-right text-slate-100">{n.couponRate}%</td>
                <td className="p-2 text-right text-purple-300">+{n.creditSpread} bp</td>
                <td className="p-2 text-slate-400">{n.maturityDate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==========================================
// 5. IndexPage (信用指数 Terminal)
// ==========================================
export const IndexPage: React.FC = () => {
  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <LineChart className="w-5 h-5 text-amber-400" />
          <h1 className="font-bold text-sm text-slate-100">
            中国信用违约互换指数 (CHINA-CDS-MAIN-5Y Index Terminal)
          </h1>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-2 font-mono">
          <div className="text-xs text-slate-400">指数代码</div>
          <div className="text-xl font-bold text-amber-300">CHINA-CDS-MAIN-5Y</div>
          <div className="text-xs text-slate-300">成份实体数量: 40 家高评级央国企</div>
          <div className="text-xs text-emerald-400 font-bold">当前指数利差: 124.5 bp</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-2 font-mono">
          <div className="text-xs text-slate-400">高收益指数代码</div>
          <div className="text-xl font-bold text-red-400">CHINA-CDS-HIGHYIELD-5Y</div>
          <div className="text-xs text-slate-300">成份实体数量: 25 家高收益民企与地产</div>
          <div className="text-xs text-red-400 font-bold">当前指数利差: 385.2 bp</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded space-y-2 font-mono">
          <div className="text-xs text-slate-400">城投专项指数代码</div>
          <div className="text-xl font-bold text-blue-400">CHINA-CDS-LGFV-5Y</div>
          <div className="text-xs text-slate-300">成份实体数量: 35 家地方基础设施</div>
          <div className="text-xs text-blue-300 font-bold">当前指数利差: 198.0 bp</div>
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 6. PortfolioPage (交易组合)
// ==========================================
export const PortfolioPage: React.FC = () => {
  const { cdsTrades, recalculatePortfolioMetrics } = useCreditStore();
  const metrics = recalculatePortfolioMetrics();

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <PieChart className="w-5 h-5 text-amber-400" />
          <h1 className="font-bold text-sm text-slate-100">
            信用衍生品交易组合管理 (Credit Portfolio Management)
          </h1>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400">总持仓笔数</div>
          <div className="text-lg font-bold text-slate-100">{cdsTrades.length} 笔</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400">总名义本金</div>
          <div className="text-lg font-bold text-amber-300">¥ {(metrics.totalNotional / 100000000).toFixed(1)} 亿</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400">组合 CS01</div>
          <div className="text-lg font-bold text-blue-400">¥ {metrics.totalCS01.toLocaleString()}</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-slate-400">组合 CVA</div>
          <div className="text-lg font-bold text-purple-300">¥ {metrics.totalCVA.toLocaleString()}</div>
        </div>
      </div>

      {/* Trades Blotter */}
      <div className="bg-slate-900 border border-slate-800 rounded p-3 overflow-x-auto font-mono text-xs">
        <div className="font-bold text-slate-200 mb-2">组合具体持仓清单</div>
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
              <th className="p-2">交易编号</th>
              <th className="p-2">方向</th>
              <th className="p-2">参考实体</th>
              <th className="p-2 text-right">名义本金</th>
              <th className="p-2">期限</th>
              <th className="p-2 text-right">约定费率</th>
              <th className="p-2 text-right">公允价值 PV</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 text-[11px]">
            {cdsTrades.map((t) => (
              <tr key={t.id} className="hover:bg-slate-800/50">
                <td className="p-2 text-blue-400 font-bold">{t.tradeNo}</td>
                <td className="p-2">{t.direction}</td>
                <td className="p-2 text-slate-200">{t.referenceEntityName}</td>
                <td className="p-2 text-right text-amber-300">¥ {(t.notional / 100000000).toFixed(1)} 亿</td>
                <td className="p-2">{t.tenor}</td>
                <td className="p-2 text-right">{t.fixedCoupon} bp</td>
                <td className="p-2 text-right text-emerald-400 font-bold">¥ {t.cleanPV.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==========================================
// 7. ResearchPage (研究分析)
// ==========================================
export const ResearchPage: React.FC = () => {
  const { entities } = useCreditStore();
  const e = entities[0];

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <BookOpen className="w-5 h-5 text-blue-400" />
          <h1 className="font-bold text-sm text-slate-100">
            参考实体信用研究与债务结构分析 (Credit Research Terminal)
          </h1>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-2 font-mono text-xs">
          <div className="font-bold text-sm text-slate-100 font-sans border-b border-slate-800 pb-1">
            {e.name} ({e.code}) - 债务结构剖析
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">行业板块:</span>
            <span>{e.sector}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">信用评级:</span>
            <span className="text-amber-300 font-bold">{e.rating}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">存续债券规模:</span>
            <span className="text-slate-100 font-bold">¥ {e.totalDebt} 亿元</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">5Y 隐含违约概率:</span>
            <span className="text-red-400 font-bold">{e.pd5Y}%</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-2 font-mono text-xs">
          <div className="font-bold text-sm text-slate-100 font-sans border-b border-slate-800 pb-1">
            财务指标与风险估算
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">资产负债率:</span>
            <span>64.2%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">EBITDA 利息保障倍数:</span>
            <span className="text-emerald-400 font-bold">4.8 x</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">短期有息债务占比:</span>
            <span className="text-amber-300">28.5%</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// ==========================================
// 8. MarketPlaybackPage (回放系统)
// ==========================================
export const MarketPlaybackPage: React.FC = () => {
  const [speed, setSpeed] = useState<number>(1);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <History className="w-5 h-5 text-amber-400" />
          <h1 className="font-bold text-sm text-slate-100">
            信用衍生品市场 Tick 级历史行情回放系统 (Market Replay System)
          </h1>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-3 font-mono text-xs">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="px-4 py-1.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded flex items-center space-x-1"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{isPlaying ? '暂停回放' : '开始历史回放'}</span>
          </button>

          <div className="flex items-center space-x-2">
            <span className="text-slate-400">回放倍速:</span>
            {[1, 5, 20, 100].map((s) => (
              <button
                key={s}
                onClick={() => setSpeed(s)}
                className={`px-2 py-0.5 rounded font-bold ${
                  speed === s ? 'bg-amber-950 text-amber-300 border border-amber-600' : 'bg-slate-950 text-slate-400'
                }`}
              >
                {s}x
              </button>
            ))}
          </div>
        </div>

        <div className="p-3 bg-slate-950 rounded border border-slate-800 text-slate-400">
          回放日期: <span className="text-slate-100 font-bold">2026-09-18 (昨日完整 Tick 流)</span> | 当前回放状态: {isPlaying ? '回放播放中...' : '已就绪'}
        </div>
      </div>
    </div>
  );
};
