/**
 * Market Overview Dashboard Page (市场总览)
 * 中国银行间信用衍生品市场大盘行情与组合风险实时指标
 */

import React from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  BarChart2,
  Building2,
  CheckCircle2,
  Flame,
  Layers,
  PieChart,
  Shield,
  TrendingUp,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, BarChart, Bar } from 'recharts';

export const OverviewPage: React.FC = () => {
  const {
    entities,
    selectEntity,
    setActiveTab,
    creditEvents,
    recalculatePortfolioMetrics,
    isCrisisMode,
  } = useCreditStore();

  const metrics = recalculatePortfolioMetrics();

  // Selected top synthetic market entities for the summary quote table
  const featuredEntities = entities.slice(0, 10);

  // Time series dummy curve data for chart
  const spreadHistory = [
    { time: '09:00', mainIndex: 182.0, yieldIndex: 375.0, cva: 12.1 },
    { time: '09:15', mainIndex: 183.2, yieldIndex: 378.2, cva: 12.3 },
    { time: '09:30', mainIndex: 185.0, yieldIndex: 382.5, cva: 12.5 },
    { time: '09:45', mainIndex: 184.1, yieldIndex: 380.1, cva: 12.4 },
    { time: '10:00', mainIndex: 186.4, yieldIndex: 385.2, cva: 12.84 },
  ];

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      {/* Top Banner Disclaimer */}
      <div className="bg-slate-900 border border-slate-800 rounded p-2.5 flex items-center justify-between text-xs">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <span className="font-semibold text-slate-200">
            中国银行间信用衍生品与风险数字交易工作站 · 运行中心
          </span>
          <span className="text-slate-500 font-mono">| 银行间市场: 交易中 | CIBM-CDS-HUB</span>
        </div>
        <div className="text-[11px] text-amber-400 font-mono font-medium bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/60">
          模拟环境 · SYNTHETIC MARKET · 非真实交易
        </div>
      </div>

      {/* Top KPI Cards Bar (Prompt IV Mandated) */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* KPI 1 */}
        <div className="bg-slate-900 border border-slate-800 p-3 rounded space-y-1">
          <div className="text-[10px] text-slate-400 font-medium">信用衍生品名义本金</div>
          <div className="text-lg font-bold font-mono text-slate-100">¥ 5,842.6 亿</div>
          <div className="text-[10px] text-emerald-400 flex items-center space-x-0.5 font-mono">
            <ArrowUpRight className="w-3 h-3" />
            <span>+¥ 18.5 亿 (今日)</span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-slate-900 border border-slate-800 p-3 rounded space-y-1">
          <div className="text-[10px] text-slate-400 font-medium">CDS 5Y 中位利差</div>
          <div className="text-lg font-bold font-mono text-amber-400">186.4 bp</div>
          <div className={`text-[10px] flex items-center space-x-0.5 font-mono ${isCrisisMode ? 'text-red-400 font-bold' : 'text-red-400'}`}>
            <ArrowUpRight className="w-3 h-3" />
            <span>+2.4 bp (走阔)</span>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-slate-900 border border-slate-800 p-3 rounded space-y-1">
          <div className="text-[10px] text-slate-400 font-medium">CRMW 活跃规模</div>
          <div className="text-lg font-bold font-mono text-slate-100">¥ 1,284.3 亿</div>
          <div className="text-[10px] text-emerald-400 flex items-center space-x-0.5 font-mono">
            <ArrowUpRight className="w-3 h-3" />
            <span>+¥ 5.0 亿 创设</span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-slate-900 border border-slate-800 p-3 rounded space-y-1">
          <div className="text-[10px] text-slate-400 font-medium">信用市场成交</div>
          <div className="text-lg font-bold font-mono text-slate-100">¥ 428.6 亿</div>
          <div className="text-[10px] text-slate-400 font-mono">24h 换手率 7.3%</div>
        </div>

        {/* KPI 5 */}
        <div className="bg-slate-900 border border-slate-800 p-3 rounded space-y-1">
          <div className="text-[10px] text-slate-400 font-medium">平均隐含违约概率</div>
          <div className="text-lg font-bold font-mono text-blue-400">3.84%</div>
          <div className="text-[10px] text-slate-400 font-mono">Hazard Rate λ=0.018</div>
        </div>

        {/* KPI 6 */}
        <div className="bg-slate-900 border border-slate-800 p-3 rounded space-y-1">
          <div className="text-[10px] text-slate-400 font-medium">组合 CVA 调整</div>
          <div className="text-lg font-bold font-mono text-purple-400">¥ 12.84 亿</div>
          <div className="text-[10px] text-amber-400 font-mono">对手方风险准备金</div>
        </div>
      </div>

      {/* Main Grid: Market Quotes Table & Real-time Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left 2 Cols: Synthetic Market Quotes Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded p-3 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-red-500" />
              <span className="font-bold text-xs text-slate-100">核心参考实体市场行情 (实时合成行情)</span>
            </div>
            <button
              onClick={() => setActiveTab('信用市场')}
              className="text-[11px] text-blue-400 hover:underline font-mono"
            >
              查看全部 100 个实体 →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px] font-mono bg-slate-950/60">
                  <th className="p-2">参考实体</th>
                  <th className="p-2">行业</th>
                  <th className="p-2">评级</th>
                  <th className="p-2 text-right">5Y CDS</th>
                  <th className="p-2 text-right">1Y PD</th>
                  <th className="p-2 text-right">5Y PD</th>
                  <th className="p-2 text-right">回收率</th>
                  <th className="p-2 text-right">变动</th>
                  <th className="p-2 text-center">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                {featuredEntities.map((e) => {
                  const isUp = e.spreadChange24h > 0;
                  return (
                    <tr key={e.id} className="hover:bg-slate-800/50 transition-colors">
                      <td className="p-2 font-sans font-semibold text-slate-200">
                        {e.name}
                      </td>
                      <td className="p-2 text-slate-400">{e.sector}</td>
                      <td className="p-2">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          e.rating.startsWith('AAA') ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                          e.rating.startsWith('AA') ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                          'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}>
                          {e.rating}
                        </span>
                      </td>
                      <td className="p-2 text-right font-bold text-amber-300">{e.spread5Y} bp</td>
                      <td className="p-2 text-right text-slate-300">{e.pd1Y}%</td>
                      <td className="p-2 text-right text-slate-300">{e.pd5Y}%</td>
                      <td className="p-2 text-right text-slate-400">{e.recoveryRate}%</td>
                      <td className={`p-2 text-right font-bold ${isUp ? 'text-red-400' : 'text-emerald-400'}`}>
                        {isUp ? `+${e.spreadChange24h}bp` : `${e.spreadChange24h}bp`}
                      </td>
                      <td className="p-2 text-center font-sans">
                        <button
                          onClick={() => {
                            selectEntity(e.id);
                            setActiveTab('CDS交易');
                          }}
                          className="px-2 py-0.5 bg-blue-950 hover:bg-blue-900 text-blue-300 border border-blue-800 rounded text-[10px] transition-colors"
                        >
                          交易
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 1 Col: Chart & Credit Risk Gauge */}
        <div className="space-y-4">
          {/* Chart 1: Spread Trend */}
          <div className="bg-slate-900 border border-slate-800 rounded p-3 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-200 border-b border-slate-800 pb-1.5">
              <span>中国 CDS 指数利差走势 (bp)</span>
              <span className="text-[10px] font-mono text-slate-500">今日分时</span>
            </div>
            <div className="h-40 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={spreadHistory}>
                  <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                  <YAxis stroke="#64748b" fontSize={10} domain={['dataMin - 5', 'dataMax + 5']} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }}
                  />
                  <Area type="monotone" dataKey="mainIndex" name="高评级指数" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.15} />
                  <Area type="monotone" dataKey="yieldIndex" name="高收益指数" stroke="#ef4444" fill="#ef4444" fillOpacity={0.1} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* CRO View Overview Box */}
          <div className="bg-slate-900 border border-slate-800 rounded p-3 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-200 border-b border-slate-800 pb-1.5">
              <div className="flex items-center space-x-1.5">
                <Shield className="w-3.5 h-3.5 text-blue-400" />
                <span>首席风险官 (CRO) 实时风控视角</span>
              </div>
              <button
                onClick={() => setActiveTab('系统管理')}
                className="text-[10px] text-blue-400 hover:underline"
              >
                风控大屏 →
              </button>
            </div>

            <div className="space-y-2 text-[11px] font-mono">
              <div>
                <div className="flex justify-between text-slate-400 mb-0.5">
                  <span>总体信用风险敞口</span>
                  <span className="text-amber-400 font-bold">78% (正常)</span>
                </div>
                <div className="w-full bg-slate-950 h-1.5 rounded overflow-hidden">
                  <div className="bg-amber-500 h-full w-[78%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-0.5">
                  <span>交易对手方 CVA 集中度</span>
                  <span className="text-blue-400 font-bold">62%</span>
                </div>
                <div className="w-full bg-slate-950 h-1.5 rounded overflow-hidden">
                  <div className="bg-blue-500 h-full w-[62%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-slate-400 mb-0.5">
                  <span>地产行业敞口集中度</span>
                  <span className="text-red-400 font-bold">85.6% (预警)</span>
                </div>
                <div className="w-full bg-slate-950 h-1.5 rounded overflow-hidden">
                  <div className="bg-red-500 h-full w-[85.6%]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
