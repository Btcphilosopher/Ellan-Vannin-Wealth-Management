/**
 * Credit Migration Matrix Page (信用评级迁移矩阵)
 * 9x9 评级迁移矩阵、1Y/3Y/5Y 迁移概率推演与点击单元格多维度组合损失下钻
 */

import React, { useState } from 'react';
import {
  GitBranch,
  HelpCircle,
  Info,
  Layers,
  PieChart,
  RefreshCw,
  X,
} from 'lucide-react';
import { MIGRATION_MATRIX_1Y, RATING_BUCKETS } from '../lib/mathEngine';
import { RatingType } from '../types';

export const CreditMigrationPage: React.FC = () => {
  const [tenorYears, setTenorYears] = useState<1 | 3 | 5>(1);
  const [selectedCell, setSelectedCell] = useState<{
    fromRating: RatingType;
    toRating: RatingType;
    prob: number;
  } | null>(null);

  // Multiplier for 3Y / 5Y transition probability compounding
  const getCompoundedProb = (from: string, toIdx: number) => {
    const baseProb = MIGRATION_MATRIX_1Y[from]?.[toIdx] || 0;
    if (tenorYears === 1) return baseProb;
    if (tenorYears === 3) {
      if (from === RATING_BUCKETS[toIdx]) return Math.pow(baseProb, 0.85);
      return Math.min(0.95, baseProb * 2.1);
    }
    // 5Y
    if (from === RATING_BUCKETS[toIdx]) return Math.pow(baseProb, 0.72);
    return Math.min(0.95, baseProb * 3.4);
  };

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      {/* Title Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <GitBranch className="w-5 h-5 text-purple-400" />
          <h1 className="font-bold text-sm text-slate-100">
            信用评级迁移分析与违约转移矩阵 (Credit Rating Migration Matrix)
          </h1>
        </div>

        {/* Tenor Selector */}
        <div className="flex items-center space-x-2 font-mono text-xs">
          <span className="text-slate-400">迁移视角:</span>
          {([1, 3, 5] as const).map((y) => (
            <button
              key={y}
              onClick={() => setTenorYears(y)}
              className={`px-2.5 py-1 rounded border font-bold ${
                tenorYears === y
                  ? 'bg-purple-950 text-purple-300 border-purple-600'
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              {y} 年迁移
            </button>
          ))}
        </div>
      </div>

      {/* Migration Matrix Grid Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
        <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
          <span>中国银行间信用评级转移概率矩阵 ({tenorYears}Y Migration Matrix)</span>
          <span className="text-[10px] text-slate-500 font-mono">点击任意单元格查看组合下钻影响</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-center text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
                <th className="p-2 text-left font-sans">初始评级 \ 期末评级</th>
                {RATING_BUCKETS.map((r) => (
                  <th key={r} className="p-2 font-bold">{r}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {RATING_BUCKETS.map((fromRating) => (
                <tr key={fromRating} className="hover:bg-slate-800/40">
                  <td className="p-2 text-left font-bold text-amber-300 bg-slate-950">
                    {fromRating}
                  </td>
                  {RATING_BUCKETS.map((toRating, toIdx) => {
                    const rawProb = getCompoundedProb(fromRating, toIdx);
                    const pct = (rawProb * 100).toFixed(2);
                    const isDiagonal = fromRating === toRating;
                    const isDefault = toRating === '违约';

                    return (
                      <td
                        key={toRating}
                        onClick={() =>
                          setSelectedCell({
                            fromRating,
                            toRating,
                            prob: rawProb,
                          })
                        }
                        className={`p-2 cursor-pointer transition-colors border-r border-slate-800/30 ${
                          isDiagonal
                            ? 'bg-slate-800/80 font-bold text-slate-100'
                            : isDefault
                            ? 'bg-red-950/60 text-red-300 font-bold'
                            : rawProb > 0.05
                            ? 'bg-purple-950/40 text-purple-200'
                            : 'text-slate-500 hover:bg-slate-800'
                        }`}
                      >
                        {pct}%
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Popup on Cell Click (Section XII Mandated) */}
      {selectedCell && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg shadow-2xl w-full max-w-md p-4 space-y-4 font-sans text-xs">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <Info className="w-4 h-4 text-purple-400" />
                <span>评级迁移下钻推演 ({selectedCell.fromRating} → {selectedCell.toRating})</span>
              </span>
              <button
                onClick={() => setSelectedCell(null)}
                className="text-slate-500 hover:text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2 font-mono">
              <div className="flex justify-between bg-slate-950 p-2 rounded">
                <span className="text-slate-400">历史统计概率:</span>
                <span className="text-slate-100 font-bold">{(selectedCell.prob * 100).toFixed(2)}%</span>
              </div>

              <div className="flex justify-between bg-slate-950 p-2 rounded">
                <span className="text-slate-400">模拟推演概率 ({tenorYears}Y):</span>
                <span className="text-purple-300 font-bold">{(selectedCell.prob * 105).toFixed(2)}%</span>
              </div>

              <div className="flex justify-between bg-slate-950 p-2 rounded">
                <span className="text-slate-400">组合受影响持仓名义本金:</span>
                <span className="text-amber-300 font-bold">¥ 8.50 亿元</span>
              </div>

              <div className="flex justify-between bg-slate-950 p-2 rounded">
                <span className="text-slate-400">估算迁移重估损失 (Expected Loss):</span>
                <span className="text-red-400 font-bold">
                  ¥ {Math.round(selectedCell.prob * 850000000 * 0.4).toLocaleString()}
                </span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setSelectedCell(null)}
                className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 py-1.5 rounded font-bold"
              >
                关闭下钻面板
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
