/**
 * CRO Executive Dashboard & What-if Scenario Laboratory Page
 * 首席风险官 (CRO) 全局风控大屏与 What-if 敏捷情景实验室
 */

import React, { useState } from 'react';
import {
  Activity,
  AlertOctagon,
  AlertTriangle,
  BarChart2,
  CheckCircle2,
  Compass,
  Flame,
  Layers,
  Play,
  RefreshCw,
  Shield,
  ShieldAlert,
  Sliders,
  TrendingDown,
  Zap,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';

export const CroDashboardPage: React.FC = () => {
  const {
    recalculatePortfolioMetrics,
    startCreditCrisis,
    isCrisisMode,
    riskLimits,
  } = useCreditStore();

  const metrics = recalculatePortfolioMetrics();

  // What-if sliders state
  const [whatifSpreadShift, setWhatifSpreadShift] = useState<number>(30);
  const [whatifPdMult, setWhatifPdMult] = useState<number>(1.5);
  const [whatifRecDrop, setWhatifRecDrop] = useState<number>(10);

  // Computed What-if impact
  const whatifPnlImpact = Math.round(metrics.totalCS01 * whatifSpreadShift);
  const whatifVarImpact = Math.round(metrics.var95 * (whatifPdMult * 0.4 + 1));

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Shield className="w-5 h-5 text-red-500" />
          <h1 className="font-bold text-sm text-slate-100">
            首席风险官 (CRO) 极视角风控中心 & What-if 实验室
          </h1>
        </div>
        <button
          onClick={startCreditCrisis}
          className={`px-3 py-1 rounded text-xs font-bold font-mono transition-all border flex items-center space-x-1.5 ${
            isCrisisMode
              ? 'bg-red-900 text-red-100 border-red-500 animate-pulse'
              : 'bg-red-950/60 text-red-400 border-red-800 hover:bg-red-900 hover:text-red-100'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>{isCrisisMode ? '信用危机冲集中' : '启动信用危机压力测试'}</span>
        </button>
      </div>

      {/* Top Level Metric Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono">
        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-[10px] text-slate-400">总持仓名义本金 (Gross)</div>
          <div className="text-lg font-bold text-slate-100">¥ {(metrics.totalNotional / 100000000).toFixed(1)} 亿元</div>
          <div className="text-[10px] text-blue-400">净敞口 ¥ {(metrics.netExposure / 100000000).toFixed(1)} 亿</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-[10px] text-slate-400">CS01 (1bp利差敏感性)</div>
          <div className="text-lg font-bold text-amber-300">¥ {metrics.totalCS01.toLocaleString()}</div>
          <div className="text-[10px] text-slate-500">组合利差风险敞口</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-[10px] text-slate-400">VaR 95% (日最大损失)</div>
          <div className="text-lg font-bold text-red-400">¥ {metrics.var95.toLocaleString()}</div>
          <div className="text-[10px] text-slate-500">ES 95%: ¥ {metrics.es95.toLocaleString()}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3 rounded">
          <div className="text-[10px] text-slate-400">对手方 CVA 扣减总量</div>
          <div className="text-lg font-bold text-purple-300">¥ {metrics.totalCVA.toLocaleString()}</div>
          <div className="text-[10px] text-slate-500">DVA 扣减: ¥ {metrics.totalDVA.toLocaleString()}</div>
        </div>
      </div>

      {/* What-if Scenario Engine Box (Section XXIII Mandated) */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
        <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span>【What-if 敏捷情景模拟实验室】(Interactive What-if Engine)</span>
          </div>
          <span className="text-[10px] text-amber-400 font-mono">动态重算</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          {/* Slider 1 */}
          <div className="space-y-1 bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="flex justify-between">
              <span className="text-slate-400">全市场 Spread 平移 (bp):</span>
              <span className="text-amber-300 font-bold">+{whatifSpreadShift} bp</span>
            </div>
            <input
              type="range"
              min={0}
              max={300}
              value={whatifSpreadShift}
              onChange={(e) => setWhatifSpreadShift(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
          </div>

          {/* Slider 2 */}
          <div className="space-y-1 bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="flex justify-between">
              <span className="text-slate-400">违约概率 PD 放大倍数:</span>
              <span className="text-red-400 font-bold">{whatifPdMult} x</span>
            </div>
            <input
              type="range"
              min={1.0}
              max={5.0}
              step={0.1}
              value={whatifPdMult}
              onChange={(e) => setWhatifPdMult(Number(e.target.value))}
              className="w-full accent-red-500"
            />
          </div>

          {/* Slider 3 */}
          <div className="space-y-1 bg-slate-950 p-2.5 rounded border border-slate-800">
            <div className="flex justify-between">
              <span className="text-slate-400">回收率下调 (Recovery Drop %):</span>
              <span className="text-purple-300 font-bold">-{whatifRecDrop}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={30}
              value={whatifRecDrop}
              onChange={(e) => setWhatifRecDrop(Number(e.target.value))}
              className="w-full accent-purple-500"
            />
          </div>
        </div>

        {/* Real-time What-if Output Banner */}
        <div className="p-3 bg-slate-950 border border-amber-900/60 rounded flex flex-wrap justify-between items-center text-xs font-mono gap-2">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="text-slate-300">What-if 预估损益影响 (Estimated P&L):</span>
            <span className={`font-bold text-sm ${whatifPnlImpact >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              ¥ {whatifPnlImpact.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-slate-400">重算后 VaR 95%:</span>
            <span className="text-red-400 font-bold">¥ {whatifVarImpact.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Red Alert List & Risk Limits Table */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
        <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
          <span>风控限额与预警指标清单 (Risk Limits Monitor)</span>
          <span className="text-[10px] text-red-400 font-mono">实时熔断机制</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
                <th className="p-2">限额类别</th>
                <th className="p-2">监控指标</th>
                <th className="p-2 text-right">当前实际值</th>
                <th className="p-2 text-right">警报预警线</th>
                <th className="p-2 text-right">硬性限额上限</th>
                <th className="p-2">状态</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {riskLimits.map((l) => (
                <tr key={l.id} className="hover:bg-slate-800/50">
                  <td className="p-2 font-sans font-bold text-slate-200">{l.category}</td>
                  <td className="p-2 text-slate-300">{l.name}</td>
                  <td className="p-2 text-right text-amber-300 font-bold">
                    ¥ {l.currentUsage.toLocaleString()} 万元
                  </td>
                  <td className="p-2 text-right text-slate-400">
                    {l.warningThreshold}% 预警线
                  </td>
                  <td className="p-2 text-right text-red-400 font-bold">
                    ¥ {l.limitValue.toLocaleString()} 万元
                  </td>
                  <td className="p-2">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                        l.status === '正常'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : l.status === '预警'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-red-950 text-red-300 border border-red-800 animate-pulse'
                      }`}
                    >
                      {l.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
