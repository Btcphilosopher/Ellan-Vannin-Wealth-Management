/**
 * Counterparty Credit Risk & CVA Engine Page (对手方风险与 CVA 引擎)
 * 实时求解对手方 EE Profile / PFE 95% Profile、CVA / DVA 调整与抵押品(Margin)追踪
 */

import React from 'react';
import {
  Shield,
  ShieldAlert,
  Sliders,
  TrendingUp,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
} from 'recharts';

export const CounterpartyCvaPage: React.FC = () => {
  const { counterparties } = useCreditStore();

  // Synthetic EE/PFE exposure profile curve data
  const profileData = [
    { time: '0Y', EE: 0, PFE: 0 },
    { time: '0.5Y', EE: 12.5, PFE: 28.0 },
    { time: '1Y', EE: 24.8, PFE: 54.2 },
    { time: '2Y', EE: 38.6, PFE: 82.5 },
    { time: '3Y', EE: 45.2, PFE: 98.4 },
    { time: '5Y', EE: 32.0, PFE: 74.0 },
    { time: '7Y', EE: 18.4, PFE: 42.0 },
    { time: '10Y', EE: 8.2, PFE: 18.5 },
  ];

  return (
    <div className="p-4 space-y-4 font-sans text-slate-200">
      {/* Title Header */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Shield className="w-5 h-5 text-blue-400" />
          <h1 className="font-bold text-sm text-slate-100">
            对手方信用风险与 CVA / DVA 调整引擎 (Counterparty Risk & CVA Engine)
          </h1>
        </div>
        <span className="text-xs font-mono text-slate-400">
          巴塞尔 III CVA 风险加权资产与 ISDA CSA 净额结算
        </span>
      </div>

      {/* Exposure Profiles & Counterparty List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 5 Cols: Expected Exposure (EE) & PFE Profile Chart */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
            <span>组合预期敞口 (EE) 与 潜在最大敞口 (PFE 95%) 曲线</span>
            <span className="text-[10px] text-blue-400 font-mono">单位: 百万元</span>
          </div>

          <div className="h-64 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={profileData}>
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }}
                />
                <Area type="monotone" dataKey="PFE" name="PFE 95% (潜在最大敞口)" stroke="#ef4444" fill="#ef4444" fillOpacity={0.15} />
                <Area type="monotone" dataKey="EE" name="EE (预期敞口)" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.25} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="p-2 bg-slate-950 rounded text-[11px] font-mono text-slate-400 space-y-1">
            <div className="flex justify-between">
              <span>峰值预期敞口 Peak EE:</span>
              <span className="text-blue-400 font-bold">¥ 45.2 百万元 (T=3Y)</span>
            </div>
            <div className="flex justify-between">
              <span>峰值 PFE 95%:</span>
              <span className="text-red-400 font-bold">¥ 98.4 百万元 (T=3Y)</span>
            </div>
          </div>
        </div>

        {/* Right 7 Cols: Counterparty CVA / DVA Master Table */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded p-4 space-y-3">
          <div className="text-xs font-bold text-slate-200 border-b border-slate-800 pb-2 flex justify-between">
            <span>交易对手方 CVA / DVA 与抵押品(Margin)台账</span>
            <span className="text-[10px] text-slate-400 font-mono">共 {counterparties.length} 家核心对手方</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px] bg-slate-950">
                  <th className="p-2">交易对手方</th>
                  <th className="p-2">评级</th>
                  <th className="p-2 text-right">总敞口</th>
                  <th className="p-2 text-right">CVA 扣减</th>
                  <th className="p-2 text-right">已履约保证金</th>
                  <th className="p-2 text-right">剩余授信额度</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-[11px]">
                {counterparties.map((cp) => (
                  <tr key={cp.id} className="hover:bg-slate-800/50">
                    <td className="p-2 font-sans font-bold text-slate-200">{cp.name}</td>
                    <td className="p-2">
                      <span className="bg-emerald-950 text-emerald-300 px-1 py-0.5 rounded text-[10px] border border-emerald-800">
                        {cp.rating}
                      </span>
                    </td>
                    <td className="p-2 text-right text-amber-300 font-bold">¥ {(cp.currentExposure / 100000000).toFixed(1)} 亿</td>
                    <td className="p-2 text-right text-purple-300">¥ {(cp.cva / 10000).toFixed(2)} 万</td>
                    <td className="p-2 text-right text-blue-300">¥ {(cp.usedLimit * 0.8).toFixed(1)} 亿</td>
                    <td className="p-2 text-right text-emerald-400 font-bold">¥ {cp.availableLimit} 亿</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
