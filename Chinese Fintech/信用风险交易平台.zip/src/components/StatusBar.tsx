/**
 * Fixed Bottom Status Bar Component
 * 中国银行间信用风险交易平台 - 底部系统与通信状态栏
 */

import React from 'react';
import { Database, Radio, Server, Wifi, Zap } from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';

export const StatusBar: React.FC = () => {
  const { lastTickTimestamp, isCrisisMode } = useCreditStore();

  return (
    <footer className="h-6 bg-slate-950 border-t border-slate-800 text-slate-400 text-[10px] px-3 flex items-center justify-between font-mono select-none shrink-0 z-30">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-1">
          <span className="text-slate-500">市场:</span>
          <span className={isCrisisMode ? 'text-red-400 font-bold' : 'text-emerald-400'}>
            {isCrisisMode ? '信用危机冲击中' : '正常'}
          </span>
        </div>

        <div className="flex items-center space-x-1">
          <span className="text-slate-500">数据:</span>
          <span className="text-blue-400">实时模拟</span>
        </div>

        <div className="flex items-center space-x-1">
          <Zap className="w-2.5 h-2.5 text-amber-400" />
          <span className="text-slate-500">交易引擎:</span>
          <span className="text-slate-300">运行</span>
        </div>

        <div className="flex items-center space-x-1">
          <Server className="w-2.5 h-2.5 text-emerald-400" />
          <span className="text-slate-500">风险引擎:</span>
          <span className="text-slate-300">运行</span>
        </div>

        <div className="flex items-center space-x-1">
          <Radio className="w-2.5 h-2.5 text-purple-400" />
          <span className="text-slate-500">信用事件引擎:</span>
          <span className="text-slate-300">运行</span>
        </div>

        <div className="flex items-center space-x-1">
          <Wifi className="w-2.5 h-2.5 text-emerald-400" />
          <span className="text-slate-500">WebSocket / SSE:</span>
          <span className="text-emerald-400">已连接</span>
        </div>

        <div className="flex items-center space-x-1">
          <Database className="w-2.5 h-2.5 text-blue-400" />
          <span className="text-slate-500">数据库:</span>
          <span className="text-slate-300">正常 (SQLite / In-Memory State)</span>
        </div>
      </div>

      <div className="flex items-center space-x-3">
        <span className="text-slate-500">内部系统时间:</span>
        <span className="text-slate-200 font-semibold">{lastTickTimestamp}</span>
      </div>
    </footer>
  );
};
