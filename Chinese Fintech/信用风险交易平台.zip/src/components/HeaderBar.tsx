/**
 * Top Navigation Header Bar
 * 中国银行间市场信用风险交易平台 - 顶部导航与全局控制栏
 */

import React from 'react';
import {
  Activity,
  AlertTriangle,
  Command,
  Moon,
  RotateCcw,
  ShieldAlert,
  Sun,
  Zap,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';

export const HeaderBar: React.FC = () => {
  const {
    theme,
    toggleTheme,
    setCommandPaletteOpen,
    isCrisisMode,
    startCreditCrisis,
    lastTickTimestamp,
    activeTab,
  } = useCreditStore();

  return (
    <header className="h-12 bg-slate-900 border-b border-slate-800 text-slate-200 px-4 flex items-center justify-between text-xs select-none sticky top-0 z-40">
      {/* Left Title & Synthetic Watermark */}
      <div className="flex items-center space-x-3">
        <div className="flex items-center space-x-2">
          <div className="w-2.5 h-2.5 bg-red-600 rounded-sm animate-pulse" />
          <span className="font-bold tracking-wider text-sm text-slate-100">
            信用风险交易平台
          </span>
          <span className="text-[10px] tracking-tight text-slate-400 uppercase font-mono hidden md:inline">
            CHINA CREDIT RISK PLATFORM
          </span>
        </div>

        <div className="bg-red-950/80 text-red-400 border border-red-800/60 px-2 py-0.5 rounded text-[11px] font-medium flex items-center space-x-1">
          <AlertTriangle className="w-3 h-3 text-red-400" />
          <span>模拟环境 · SYNTHETIC MARKET · 非真实交易</span>
        </div>
      </div>

      {/* Center Status Indicators */}
      <div className="hidden lg:flex items-center space-x-6 text-[11px] text-slate-400 font-mono">
        <div className="flex items-center space-x-1.5">
          <span className="text-slate-500">市场状态:</span>
          <span className={`flex items-center space-x-1 font-semibold ${isCrisisMode ? 'text-red-400' : 'text-emerald-400'}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${isCrisisMode ? 'bg-red-500 animate-ping' : 'bg-emerald-500'}`} />
            <span>{isCrisisMode ? '信用危机冲击中' : '正常模拟'}</span>
          </span>
        </div>

        <div className="flex items-center space-x-1.5">
          <span className="text-slate-500">交易引擎:</span>
          <span className="text-slate-200 font-semibold flex items-center space-x-1">
            <Zap className="w-3 h-3 text-amber-400" />
            <span>实时运行</span>
          </span>
        </div>

        <div className="flex items-center space-x-1.5">
          <span className="text-slate-500">风险引擎:</span>
          <span className="text-blue-400 font-semibold">CVA / VaR 实时计算</span>
        </div>

        <div className="flex items-center space-x-1.5">
          <span className="text-slate-500">数据时间:</span>
          <span className="text-slate-300 font-mono">{lastTickTimestamp}</span>
        </div>
      </div>

      {/* Right Action Tools */}
      <div className="flex items-center space-x-2">
        {/* Credit Crisis Pulse Button */}
        <button
          onClick={startCreditCrisis}
          className={`px-2.5 py-1 rounded border text-[11px] font-medium transition-all flex items-center space-x-1.5 ${
            isCrisisMode
              ? 'bg-red-900/90 text-red-200 border-red-600 animate-bounce'
              : 'bg-red-950/40 text-red-400 border-red-900/80 hover:bg-red-900/60 hover:text-red-100'
          }`}
          title="触发系统性信用危机压力测试脉冲"
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>{isCrisisMode ? '危机脉冲生效中' : '启动信用危机模拟'}</span>
        </button>

        {/* Command Palette Ctrl+K */}
        <button
          onClick={() => setCommandPaletteOpen(true)}
          className="bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 px-2.5 py-1 rounded text-[11px] flex items-center space-x-1.5"
        >
          <Command className="w-3 h-3 text-slate-400" />
          <span>命令面板</span>
          <kbd className="bg-slate-900 text-slate-400 text-[9px] px-1 rounded border border-slate-800 font-mono">
            Ctrl+K
          </kbd>
        </button>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700"
          title="切换专业视图主题"
        >
          {theme === 'dark' ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-slate-200" />}
        </button>
      </div>
    </header>
  );
};
