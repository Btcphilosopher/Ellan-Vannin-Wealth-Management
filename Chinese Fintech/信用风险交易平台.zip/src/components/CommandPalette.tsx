/**
 * Command Palette Popup (Ctrl + K)
 * 全局快速指令控制台与搜索终端
 */

import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Building2,
  Check,
  Flame,
  PlusCircle,
  Search,
  ShieldAlert,
  X,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';

export const CommandPalette: React.FC = () => {
  const {
    isCommandPaletteOpen,
    setCommandPaletteOpen,
    entities,
    setActiveTab,
    selectEntity,
    startCreditCrisis,
    triggerCreditEvent,
  } = useCreditStore();

  const [query, setQuery] = useState('');

  if (!isCommandPaletteOpen) return null;

  const filteredEntities = entities
    .filter((e) => e.name.includes(query) || e.code.includes(query) || e.sector.includes(query))
    .slice(0, 5);

  const handleEntitySelect = (id: string) => {
    selectEntity(id);
    setActiveTab('参考实体');
    setCommandPaletteOpen(false);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-start justify-center pt-20 p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-lg shadow-2xl w-full max-w-xl overflow-hidden text-slate-200 text-xs font-sans animate-in fade-in zoom-in-95 duration-150">
        {/* Input Bar */}
        <div className="p-3 border-b border-slate-800 flex items-center space-x-2">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索参考实体、交易命令、压力测试或快速导航..."
            className="w-full bg-transparent text-slate-100 placeholder-slate-500 text-xs outline-hidden"
            autoFocus
          />
          <button
            onClick={() => setCommandPaletteOpen(false)}
            className="text-slate-500 hover:text-slate-300 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Commands */}
        <div className="p-2 space-y-3 max-h-96 overflow-y-auto">
          {/* Action Short-cuts */}
          <div>
            <div className="px-2 text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
              快捷指令与动作
            </div>
            <div className="space-y-1">
              <button
                onClick={() => {
                  setActiveTab('CDS交易');
                  setCommandPaletteOpen(false);
                }}
                className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <PlusCircle className="w-3.5 h-3.5 text-blue-400" />
                  <span>新建 CDS 交易 ticket</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">交易终端</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('压力测试');
                  setCommandPaletteOpen(false);
                }}
                className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-slate-300 hover:text-white transition-colors"
              >
                <div className="flex items-center space-x-2">
                  <Flame className="w-3.5 h-3.5 text-amber-400" />
                  <span>运行信用压力测试实验室</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">风控实验室</span>
              </button>

              <button
                onClick={() => {
                  startCreditCrisis();
                  setCommandPaletteOpen(false);
                }}
                className="w-full flex items-center justify-between p-2 rounded hover:bg-red-950/60 text-red-300 hover:text-red-100 transition-colors border border-red-900/40"
              >
                <div className="flex items-center space-x-2">
                  <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
                  <span>启动系统性信用危机冲击脉冲</span>
                </div>
                <span className="text-[10px] font-mono text-red-400">高风险操作</span>
              </button>
            </div>
          </div>

          {/* Reference Entity Results */}
          {filteredEntities.length > 0 && (
            <div>
              <div className="px-2 text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                参考实体 (匹配 {filteredEntities.length} 个)
              </div>
              <div className="space-y-1">
                {filteredEntities.map((e) => (
                  <button
                    key={e.id}
                    onClick={() => handleEntitySelect(e.id)}
                    className="w-full flex items-center justify-between p-2 rounded hover:bg-slate-800 text-slate-300 transition-colors"
                  >
                    <div className="flex items-center space-x-2">
                      <Building2 className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-semibold text-slate-100">{e.name}</span>
                      <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400 font-mono">
                        {e.sector} · {e.rating}
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 font-mono text-[11px]">
                      <span className="text-amber-400 font-bold">{e.spread5Y} bp</span>
                      <span className="text-slate-500">5Y PD: {e.pd5Y}%</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-2 border-t border-slate-800 bg-slate-950 text-[10px] text-slate-500 flex justify-between font-mono">
          <span>按 ESC 退出 · 键盘上下键选择</span>
          <span>CHINA CREDIT RISK PLATFORM WORKSTATION</span>
        </div>
      </div>
    </div>
  );
};
