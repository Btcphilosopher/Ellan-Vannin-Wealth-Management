/**
 * Left Sidebar Navigation Menu
 * 中国银行间信用衍生品工作站 - 24功能模块专业导向栏
 */

import React from 'react';
import {
  Activity,
  AlertOctagon,
  BarChart3,
  BookOpen,
  Building2,
  CheckCircle2,
  Coins,
  Compass,
  FileCheck2,
  FileSpreadsheet,
  FileText,
  Flame,
  GitBranch,
  History,
  Layers,
  LineChart,
  PieChart,
  Repeat,
  Scale,
  Shield,
  ShieldAlert,
  Sliders,
  TrendingUp,
  Workflow,
} from 'lucide-react';
import { useCreditStore } from '../store/useCreditStore';

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  category: string;
  badge?: string;
}

const NAV_ITEMS: NavItem[] = [
  // 核心交易与总览
  { id: '总览', label: '总览', icon: Compass, category: '交易与决策' },
  { id: '信用市场', label: '信用市场', icon: TrendingUp, category: '交易与决策' },
  { id: 'CDS交易', label: 'CDS交易', icon: Repeat, category: '交易与决策', badge: 'HOT' },
  { id: 'CRM工具', label: 'CRM工具', icon: Layers, category: '交易与决策' },
  { id: 'CRMW', label: 'CRMW凭证', icon: FileSpreadsheet, category: '衍生产品线' },
  { id: 'CRMA', label: 'CRMA合约', icon: FileCheck2, category: '衍生产品线' },
  { id: 'CLN', label: 'CLN票据', icon: Coins, category: '衍生产品线' },
  { id: '信用指数', label: '信用指数', icon: LineChart, category: '衍生产品线' },

  // 基础资产与曲线
  { id: '参考实体', label: '参考实体', icon: Building2, category: '资产与定价' },
  { id: '债券池', label: '债券池', icon: FileText, category: '资产与定价' },
  { id: '信用曲线', label: '信用曲线', icon: Activity, category: '资产与定价' },
  { id: '交易组合', label: '交易组合', icon: PieChart, category: '组合与风险' },

  // 风险量化与中台
  { id: '风险分析', label: '风险敏感性', icon: BarChart3, category: '组合与风险' },
  { id: '压力测试', label: '压力测试', icon: Flame, category: '组合与风险' },
  { id: '信用迁移', label: '信用迁移', icon: GitBranch, category: '组合与风险' },
  { id: '对手方风险', label: '对手方CVA', icon: Shield, category: '风控与限制' },
  { id: '限额管理', label: '限额管理', icon: ShieldAlert, category: '风控与限制' },
  { id: '抵押品', label: '抵押品', icon: Scale, category: '风控与限制' },
  { id: '信用事件', label: '信用事件', icon: AlertOctagon, category: '处置与审批' },
  { id: '交易审批', label: '交易审批', icon: Workflow, category: '处置与审批' },

  // 投研与中后台
  { id: '市场数据', label: '市场数据', icon: Activity, category: '投研与系统' },
  { id: '研究分析', label: '研究分析', icon: BookOpen, category: '投研与系统' },
  { id: '回放系统', label: '回放系统', icon: History, category: '投研与系统' },
  { id: '系统管理', label: '情景/CRO', icon: Sliders, category: '投研与系统' },
];

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, creditEvents } = useCreditStore();

  const pendingEventsCount = creditEvents.filter((e) => e.status !== '完成结算').length;

  // Group by Category
  const categories = Array.from(new Set(NAV_ITEMS.map((item) => item.category)));

  return (
    <aside className="w-52 bg-slate-900/95 border-r border-slate-800 text-slate-300 flex flex-col justify-between shrink-0 select-none overflow-y-auto text-xs py-2">
      <div className="space-y-4 px-2">
        {categories.map((cat) => {
          const catItems = NAV_ITEMS.filter((i) => i.category === cat);
          return (
            <div key={cat} className="space-y-1">
              <div className="px-2 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                {cat}
              </div>
              <div className="space-y-0.5">
                {catItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded transition-all font-medium text-[11px] ${
                        isActive
                          ? 'bg-red-950/80 text-red-200 border border-red-800/80 font-bold shadow-sm'
                          : 'hover:bg-slate-800/80 hover:text-slate-100 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-red-400' : 'text-slate-400'}`} />
                        <span>{item.label}</span>
                      </div>

                      {item.badge && (
                        <span className="bg-red-900/60 text-red-300 text-[9px] px-1 rounded font-mono font-bold">
                          {item.badge}
                        </span>
                      )}

                      {item.id === '信用事件' && pendingEventsCount > 0 && (
                        <span className="bg-amber-900/80 text-amber-300 text-[9px] px-1.5 py-0.2 rounded-full font-mono font-bold animate-pulse">
                          {pendingEventsCount}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Identity Info */}
      <div className="p-2.5 mx-2 my-2 bg-slate-950/70 border border-slate-800 rounded text-[10px] text-slate-500 font-mono space-y-1">
        <div className="flex justify-between items-center text-slate-400">
          <span>银行间交易终端</span>
          <span className="text-emerald-400">v2026.9</span>
        </div>
        <div>中国金融衍生品交易工作站</div>
        <div className="text-[9px] text-slate-600 truncate">数字孪生量化与风险管理引擎</div>
      </div>
    </aside>
  );
};
