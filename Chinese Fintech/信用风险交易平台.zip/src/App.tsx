/**
 * Main Application Shell & Master Page Switcher
 * 中国银行间市场信用违约互换 / 信用风险缓释工具数字交易工作站
 */

import React, { useEffect } from 'react';
import { HeaderBar } from './components/HeaderBar';
import { Sidebar } from './components/Sidebar';
import { StatusBar } from './components/StatusBar';
import { CommandPalette } from './components/CommandPalette';
import { useCreditStore } from './store/useCreditStore';

// Pages
import { OverviewPage } from './pages/OverviewPage';
import { CdsTradingPage } from './pages/CdsTradingPage';
import { CreditCurvePage } from './pages/CreditCurvePage';
import { CrmwPage } from './pages/CrmwPage';
import { CreditEventPage } from './pages/CreditEventPage';
import { StressTestPage } from './pages/StressTestPage';
import { CreditMigrationPage } from './pages/CreditMigrationPage';
import { CounterpartyCvaPage } from './pages/CounterpartyCvaPage';
import { CroDashboardPage } from './pages/CroDashboardPage';
import {
  MarketPage,
  CrmHubPage,
  CrmaPage,
  ClnPage,
  IndexPage,
  PortfolioPage,
  ResearchPage,
  MarketPlaybackPage,
} from './pages/OtherPages';

export function App() {
  const { activeTab, setCommandPaletteOpen, triggerMarketTick } = useCreditStore();

  // Global Keyboard Listener for Ctrl+K Command Palette
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Live Market Tick Simulation Stream Loop (1.5s interval)
  useEffect(() => {
    const timer = setInterval(() => {
      triggerMarketTick();
    }, 1500);
    return () => clearInterval(timer);
  }, []);

  // Active View Switcher
  const renderActiveTab = () => {
    switch (activeTab) {
      case '总览':
        return <OverviewPage />;
      case '信用市场':
      case '参考实体':
      case '债券池':
      case '市场数据':
        return <MarketPage />;
      case 'CDS交易':
        return <CdsTradingPage />;
      case 'CRM工具':
        return <CrmHubPage />;
      case 'CRMW':
        return <CrmwPage />;
      case 'CRMA':
        return <CrmaPage />;
      case 'CLN':
        return <ClnPage />;
      case '信用指数':
        return <IndexPage />;
      case '信用曲线':
        return <CreditCurvePage />;
      case '交易组合':
      case '风险分析':
        return <PortfolioPage />;
      case '压力测试':
        return <StressTestPage />;
      case '信用迁移':
        return <CreditMigrationPage />;
      case '对手方风险':
      case '抵押品':
        return <CounterpartyCvaPage />;
      case '信用事件':
      case '限额管理':
      case '交易审批':
        return <CreditEventPage />;
      case '研究分析':
        return <ResearchPage />;
      case '回放系统':
        return <MarketPlaybackPage />;
      case '系统管理':
      default:
        return <CroDashboardPage />;
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans select-none">
      {/* Top Header Bar */}
      <HeaderBar />

      {/* Center Body: Left Sidebar + Main Workbench Content */}
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />

        <main className="flex-1 overflow-y-auto bg-slate-950/90">
          {renderActiveTab()}
        </main>
      </div>

      {/* Bottom Fixed Status Bar */}
      <StatusBar />

      {/* Command Palette Modal (Ctrl+K) */}
      <CommandPalette />
    </div>
  );
};

export default App;
