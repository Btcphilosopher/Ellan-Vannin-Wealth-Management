/**
 * China Credit Risk Platform - Data Models & Types
 * 中国银行间市场信用衍生品与风险管理工作站 - 数据类型定义
 */

export type SectorType = 
  | '能源' | '制造' | '地产' | '基建' | '科技' 
  | '银行' | '保险' | '交通' | '公用事业' | '消费' | '医药' | '汽车';

export type RatingType = 
  | 'AAA' | 'AA+' | 'AA' | 'AA-' | 'A+' | 'A' | 'A-' 
  | 'BBB+' | 'BBB' | 'BBB-' | 'BB+' | 'BB' | 'B' | 'CCC' | '违约';

export type SettlementType = '现金结算' | '实物结算';

export type EventType = 
  | '破产' | '支付违约' | '债务重组' | '债务加速到期' | '潜在加速到期';

export type DirectionType = '买入保护' | '卖出保护';

export type TradeType = 'CDS' | 'CRMA' | 'CRMW' | 'CLN' | 'CDS_INDEX' | 'BOND' | 'LOAN';

export type TradeStatus = 
  | '草稿' | '待审批' | '风险审核' | '合规审核' | '已批准' | '已拒绝' | '已成交' | '已交割' | '已终止';

export interface ReferenceObligation {
  id: string;
  code: string; // e.g. 23华东制造MTN001
  name: string;
  type: '中期票据' | '超短期融资券' | '公司债' | '企业债' | '金融债' | '定向工具';
  issueAmount: number; // 亿元
  couponRate: number; // %
  maturityDate: string;
  seniority: '高级无担保' | '次级' | '保证担保';
  currentPrice: number; // 净价 (元/百元)
  yieldToMaturity: number; // %
}

export interface ReferenceEntity {
  id: string;
  code: string; // e.g. RE-10023
  name: string; // e.g. 华东先进制造集团有限公司
  sector: SectorType;
  rating: RatingType;
  impliedRating: RatingType;
  spread5Y: number; // bp
  spreadChange24h: number; // bp
  pd1Y: number; // 1年违约概率 %
  pd5Y: number; // 5年违约概率 %
  recoveryRate: number; // 回收率 %
  hazardRate: number; // 风险率 λ
  status: '正常' | '预警' | '重组中' | '已违约';
  obligations: ReferenceObligation[];
  totalDebt: number; // 亿元
  leverageRatio: number; // 资产负债率 %
  interestCoverage: number; // 利息保障倍数
  region: string;
  lastCreditEvent?: string;
}

export interface CreditCurvePoint {
  tenor: '1Y' | '2Y' | '3Y' | '5Y' | '7Y' | '10Y';
  tenorMonths: number;
  spread: number; // bp
  hazardRate: number; // λ
  survivalProb: number; // S(t)
  discountFactor: number; // D(t)
}

export interface CreditCurve {
  entityId: string;
  entityName: string;
  asOfDate: string;
  points: CreditCurvePoint[];
}

export interface CDSTrade {
  id: string;
  tradeNo: string;
  tradeType: TradeType;
  direction: DirectionType; // 买入保护 / 卖出保护
  referenceEntityId: string;
  referenceEntityName: string;
  referenceObligationId: string;
  referenceObligationCode: string;
  notional: number; // 名义本金 (元)
  tenor: '1Y' | '3Y' | '5Y' | '7Y' | '10Y';
  fixedCoupon: number; // 约定固息 (bp)
  upfront: number; // 预付款 %
  recoveryRate: number; // 回收率 %
  creditEvents: EventType[];
  settlementType: SettlementType;
  counterpartyId: string;
  counterpartyName: string;
  tradeDate: string;
  effectiveDate: string;
  maturityDate: string;
  status: TradeStatus;
  trader: string;
  // Valuation & Risk Metrics
  marketSpread: number; // bp
  fairSpread: number; // bp
  dirtyPV: number; // 元
  cleanPV: number; // 元
  protectionLegPV: number; // 元
  premiumLegPV: number; // 元
  accruedInterest: number; // 元
  dv01: number; // 元/bp
  cs01: number; // 元/bp
  pv01: number; // 元/bp
  expectedLoss: number; // 元
  cva: number; // 元
}

export interface CRMWInstrument {
  id: string;
  code: string; // e.g. 26华东制造CRMW001
  issuer: string; // 创设机构 e.g. 招商银行 / 工商银行
  referenceEntityId: string;
  referenceEntityName: string;
  referenceObligationId: string;
  referenceObligationCode: string;
  creationAmount: number; // 创设规模 (亿元)
  termMonths: number; // 保护期限 (月)
  feeRate: number; // 保护费率 (bp)
  issuePrice: number; // 发行价格 (元/百元名义本金)
  issueDate: string;
  maturityDate: string;
  creditEvents: EventType[];
  settlementType: SettlementType;
  marketPrice: number; // 市场现价
  yield: number; // 收益率 %
  volume24h: number; // 24h成交量 (万元)
  status: '筹备中' | '存续中' | '已到期' | '触发理赔';
}

export interface CRMATrade {
  id: string;
  code: string;
  partyA: string;
  partyB: string;
  referenceEntityId: string;
  referenceEntityName: string;
  notional: number;
  feeRate: number;
  startDate: string;
  endDate: string;
  status: TradeStatus;
}

export interface CLNInstrument {
  id: string;
  code: string; // 26华东CLN01
  issuer: string;
  referenceEntityId: string;
  referenceEntityName: string;
  notional: number;
  couponRate: number; // 票面利率 %
  creditSpread: number; // 信用溢价 bp
  issuePrice: number;
  maturityDate: string;
  collateralAsset: string; // 质押资产 e.g. 国债
  status: '发行中' | '存续中' | '违约赎回' | '到期偿还';
}

export interface CDSIndex {
  id: string;
  code: string; // e.g. CHINA-CREDIT-5Y-MAIN
  name: string; // 中国银行间高评级信用衍生品指数 5Y
  constituentCount: number; // 构成实体数 (e.g. 40)
  averageSpread: number; // bp
  indexLevel: number; // 点位
  change24h: number; // 点
  duration: number; // 存续期
  sectorBreakdown: Record<string, number>;
}

export interface CreditEvent {
  id: string;
  eventNo: string;
  entityId: string;
  entityName: string;
  eventType: EventType;
  declaredDate: string;
  effectiveDate: string;
  description: string;
  estimatedRecovery: number; // %
  affectedNotional: number; // 影响名义本金 (元)
  affectedTradeCount: number;
  pnlImpact: number; // 损益影响 (元)
  status: '拟预警' | '已确认' | '理赔计算中' | '完成结算';
  auditLogId: string;
}

export interface Counterparty {
  id: string;
  code: string;
  name: string; // e.g. 中信证券 / 中信银行 / 华泰证券
  type: '商业银行' | '证券公司' | '基金公司' | '保险公司' | '理财子公司' | '信托公司';
  rating: RatingType;
  region: string;
  sector: string;
  pd: number; // %
  lgd: number; // %
  totalLimit: number; // 总额度 (亿元)
  usedLimit: number; // 已用额度 (亿元)
  availableLimit: number; // 剩余额度 (亿元)
  currentExposure: number; // 当前敞口 (元)
  expectedExposure: number; // EE (元)
  pfe95: number; // Potential Future Exposure (元)
  cva: number; // CVA (元)
  status: '正常交易' | '观察名单' | '暂停交易';
}

export interface RiskLimit {
  id: string;
  name: string;
  category: '总交易限额' | '单一对手方' | '单一行业' | '单一参考实体' | '评级区间' | '产品类型' | '久期限额';
  target: string; // e.g. 地产行业 / 华东制造控股 / AAA级
  limitValue: number; // 限额值 (万元)
  currentUsage: number; // 当前已用 (万元)
  usagePercentage: number; // %
  warningThreshold: number; // 预警线 % (e.g. 80)
  status: '正常' | '预警' | '超限';
}

export interface MarginCollateral {
  id: string;
  counterpartyId: string;
  counterpartyName: string;
  requiredMargin: number; // 履约保障金/抵押品要求 (元)
  postedMargin: number; // 已缴纳抵押品 (元)
  collateralType: '国债' | '政策性金融债' | '现金人民币' | '中央结算公司高评级债券';
  haircut: number; // 扣减率 %
  marginCallStatus: '充足' | '补仓通知中' | '已逾期';
}

export interface PortfolioPosition {
  id: string;
  tradeId: string;
  tradeType: TradeType;
  entityName: string;
  sector: SectorType;
  rating: RatingType;
  direction: DirectionType;
  notional: number; // 元
  entrySpread: number; // bp
  currentSpread: number; // bp
  marketValue: number; // 元
  unrealizedPnL: number; // 元
  dailyPnL: number; // 元
  cs01: number; // 元/bp
  dv01: number; // 元/bp
  var95: number; // 95% VaR (元)
  es95: number; // 95% Expected Shortfall (元)
}

export interface PortfolioMetrics {
  totalNotional: number; // 总名义本金 (元)
  totalMarketValue: number; // 总市场价值 (元)
  netExposure: number; // 净信用风险敞口 (元)
  grossExposure: number; // 毛风险敞口 (元)
  totalPnL: number; // 累计盈亏 (元)
  dailyPnL: number; // 当日盈亏 (元)
  expectedLoss: number; // EL (元)
  unexpectedLoss: number; // UL (元)
  totalCVA: number; // 总 CVA (元)
  totalDVA: number; // 总 DVA (元)
  totalCS01: number; // 总 CS01 (元/bp)
  var95: number; // 95% 1D VaR (元)
  es95: number; // 95% 1D Expected Shortfall (元)
  sectorDistribution: Record<SectorType, number>;
  ratingDistribution: Record<RatingType, number>;
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  spreadShiftBp: number; // 利差整体平移 (bp)
  pdMultiplier: number; // 违约概率倍数
  recoveryShiftPct: number; // 回收率变动 %
  sectorShifts?: Partial<Record<SectorType, number>>;
  isPreset: boolean;
}

export interface StressTestResult {
  scenarioId: string;
  scenarioName: string;
  portfolioLoss: number; // 组合总损失 (元)
  cvaChange: number; // CVA 增加额 (元)
  varChange: number; // VaR 增加 (元)
  esChange: number; // ES 增加 (元)
  simulatedDefaults: number; // 模拟违约实体数
  breachedLimitsCount: number; // 限额超标数
  capitalChargeImpact: number; // 资本占用增量 (元)
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  user: string; // e.g. 张立 (资深交易员 TRD-004)
  action: string; // e.g. 创建CDS交易订单
  target: string; // e.g. 华东制造控股 5Y CDS
  oldValue: string;
  newValue: string;
  ipAddress: string;
  riskStatus: '正常' | '预警' | '高风险';
  approvalStatus: string;
}

export interface MarketTick {
  timestamp: string;
  entityId: string;
  entityName: string;
  spread5Y: number;
  bidSpread: number;
  askSpread: number;
  volume: number;
  changeBp: number;
}

export interface WhatIfQuery {
  targetEntityId?: string;
  sectorName?: SectorType;
  spreadShiftBp?: number;
  recoveryNewPct?: number;
  ratingDowngradeSteps?: number;
  simulatedDefaultEntityIds?: string[];
}

export interface PlaybackState {
  isPlaying: boolean;
  currentDate: string; // '2026-01-01' ...
  speed: 1 | 5 | 20;
}
