import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// ==========================================
// 2. 模拟数据状态引擎 (内存数据库)
// ==========================================

// 初始预设政策文件
const policyDocuments = [
  {
    id: 'doc_2026_001',
    title: '《新衡市加快数字政府建设与政务服务高质量发展实施方案》',
    category: '发展规划',
    publishDept: '新衡市数字政府管理局',
    publishDate: '2026-03-10',
    effectiveDate: '2026-04-01',
    status: '正式施行',
    content: '本文件旨在推动新衡市一网通办、智慧城市、数字孪生及跨部门协同。所有模拟服务均需符合本实施方案的安全审计与数据隐私要求。',
    relatedServiceId: 'service_01'
  },
  {
    id: 'doc_2026_002',
    title: '《新衡市智慧水务与防灾减灾应急预案 (2026年修订版)》',
    category: '应急预案',
    publishDept: '市城市运行管理中心',
    publishDate: '2026-05-12',
    effectiveDate: '2026-05-15',
    status: '正式施行',
    content: '建立全天候智能环境监控与多级联动响应机制。大雨积水等事件需在一小时内向市公共设施维护中心派发工单并通知市民。',
    relatedServiceId: 'service_05'
  },
  {
    id: 'doc_2026_003',
    title: '《新衡市中小微企业数字化转型财政专项支持管理办法》',
    category: '财政支持',
    publishDept: '市财政管理处',
    publishDate: '2026-07-20',
    effectiveDate: '2026-08-01',
    status: '正式施行',
    content: '为注册在新衡市的高新技术及制造型企业，提供最高50万元人民币的数字化转型专项拨款，需在公共项目管理系统进行里程碑审计。',
    relatedServiceId: 'service_04'
  }
];

// 初始政务服务目录
const SERVICES = [
  {
    id: 'service_01',
    code: 'SP-10021',
    name: '居民户口迁移登记',
    category: '户籍服务',
    department: '市政务服务中心',
    target: '市民用户',
    condition: '需持有新衡市合法产权房产证明或合法稳定就业证明。',
    materials: ['居民身份证', '户口簿原件', '房产证明或劳动合同', '迁移原因说明书'],
    duration: '预计 3 个工作日',
    needAppointment: true,
    needManualReview: true,
    status: '正常运行'
  },
  {
    id: 'service_02',
    code: 'SP-10022',
    name: '企业设立登记审核',
    category: '企业服务',
    department: '市政务服务中心',
    target: '企业用户',
    condition: '有符合设立登记要求的股东、名称、住所、章程及注册资本。',
    materials: ['公司设立登记申请书', '公司章程', '股东身份证明', '住所使用证明'],
    duration: '预计 1 个工作日',
    needAppointment: false,
    needManualReview: true,
    status: '正常运行'
  },
  {
    id: 'service_03',
    code: 'SP-10023',
    name: '市区公共车位预约申请',
    category: '交通服务',
    department: '市交通管理中心',
    target: '市民用户',
    condition: '车辆无未处理交通违章，申请人持有新衡市有效驾驶证。',
    materials: ['行驶证复印件', '申请人驾驶证', '绿色出行倡议确认书'],
    duration: '预计 10 分钟 (自动+人工复核)',
    needAppointment: true,
    needManualReview: true,
    status: '正常运行'
  },
  {
    id: 'service_04',
    code: 'SP-10024',
    name: '科技创新项目扶持资金申报',
    category: '财政与项目申报',
    department: '市项目建设管理中心',
    target: '企业用户',
    condition: '企业信用良好，项目符合新衡市产业升级扶持目录。',
    materials: ['企业信用报告', '项目可行性研究报告', '研发预算细目表', '上一年度财务审计报告'],
    duration: '预计 7 个工作日',
    needAppointment: false,
    needManualReview: true,
    status: '正常运行'
  },
  {
    id: 'service_05',
    code: 'SP-10025',
    name: '公共设施故障上报维修',
    category: '公共设施',
    department: '市公共设施维护中心',
    target: '社会公众',
    condition: '新衡市范围内的市政照明、公共座椅、桥梁道路、传感器设备等损坏。',
    materials: ['现场故障照片', '设施位置描述', '联系人电话'],
    duration: '实时流转，24小时内分派',
    needAppointment: false,
    needManualReview: false,
    status: '正常运行'
  },
  {
    id: 'service_06',
    code: 'SP-10026',
    name: '电子身份证照申领',
    category: '证照申领',
    department: '市政务服务中心',
    target: '市民用户',
    condition: '已在新衡市公安机关申领实体居民身份证。',
    materials: ['实体身份证照扫描件', '活体人脸核验模拟截图'],
    duration: '预计 5 分钟',
    needAppointment: false,
    needManualReview: true,
    status: '正常运行'
  }
];

interface ApplicationMaterial {
  name: string;
  status: string;
  file: string | null;
}

interface ApplicationTimeline {
  operator: string;
  action: string;
  time: string;
  opinion: string;
  ruleVersion: string;
}

interface ApplicationRecord {
  id: string;
  serviceId: string;
  serviceName: string;
  department: string;
  applicantName: string;
  applicantType: string;
  submitTime: string;
  status: string;
  materials: ApplicationMaterial[];
  timeline: ApplicationTimeline[];
  result: Record<string, unknown> | null;
  evaluation: Record<string, unknown> | null;
  appeal: Record<string, unknown> | null;
  licenseUrl: string | null;
  archiveId: string | null;
}

interface EmergencyItem {
  id: string;
  type: string;
  severity: string;
  district: string;
  description: string;
  startTime: string;
  status: string;
  dispatchedTeams: string[];
  timeline: { time: string; text: string }[];
}

interface BudgetAdjustmentLog {
  operator: string;
  time: string;
  amount: number;
  reason: string;
}

interface DistrictTelemetry {
  trafficCongestion: number;
  powerLoad: number;
  waterTurbidity: number;
  sensorOnline: boolean;
}

// 初始应用申请列表 (垂直切片用)
const applications: ApplicationRecord[] = [
  {
    id: 'app_2026_001',
    serviceId: 'service_01',
    serviceName: '居民户口迁移登记',
    department: '市政务服务中心',
    applicantName: '陈志强',
    applicantType: '市民',
    submitTime: '2026-09-15 14:30',
    status: '等待人工复核', // 草稿、已提交、待受理、已受理、材料待补正、部门审核中、等待人工复核、审批通过、审批不通过、已归档
    materials: [
      { name: '居民身份证', status: '已校验', file: 'id_card_sim.png' },
      { name: '户口簿原件', status: '已校验', file: 'household_register.png' },
      { name: '房产证明', status: '已校验', file: 'property_cert.png' }
    ],
    timeline: [
      { operator: '陈志强', action: '提交申请', time: '2026-09-15 14:30', opinion: '申请落户江湾区万科新城。', ruleVersion: 'v1.0' },
      { operator: '窗口受理员-王静', action: '材料初审受理', time: '2026-09-15 15:10', opinion: '材料齐备，符合受理条件。', ruleVersion: 'v1.0' },
      { operator: '业务审核官-李明', action: '部门审核', time: '2026-09-16 09:45', opinion: '房产查验真实，符合新衡市落户政策规划。', ruleVersion: 'v1.0' }
    ],
    result: null,
    evaluation: null,
    appeal: null,
    licenseUrl: null,
    archiveId: null
  },
  {
    id: 'app_2026_002',
    serviceId: 'service_04',
    serviceName: '科技创新项目扶持资金申报',
    department: '市项目建设管理中心',
    applicantName: '新衡创科科技有限公司',
    applicantType: '企业',
    submitTime: '2026-09-16 10:00',
    status: '材料待补正',
    materials: [
      { name: '企业信用报告', status: '已校验', file: 'credit_report.png' },
      { name: '研发预算细目表', status: '需要重新上传', file: 'budget_v1.xlsx' }
    ],
    timeline: [
      { operator: '企业经办人-赵宇', action: '提交申请', time: '2026-09-16 10:00', opinion: '申请市级数字底座转型扶持补贴款。', ruleVersion: 'v1.2' },
      { operator: '资金审核官-周华', action: '材料退回修改', time: '2026-09-16 16:30', opinion: '研发预算明细不完整，请重新上传盖章版本。', ruleVersion: 'v1.2' }
    ],
    result: null,
    evaluation: null,
    appeal: null,
    licenseUrl: null,
    archiveId: null
  }
];

// 审计日志列表 (防止普通用户修改)
const auditLogs = [
  { id: 'aud_001', operator: '系统内置', role: '系统管理员', department: '市数据治理中心', actionTime: '2026-09-17 08:00:00', actionType: '系统启动', objectId: 'sys_001', originState: '离线', newState: '正常运行', reason: '服务器例行启动与健康检查', sourceIp: '127.0.0.1', result: '成功' },
  { id: 'aud_002', operator: '陈志强', role: '市民用户', department: '社会公众', actionTime: '2026-09-15 14:30:00', actionType: '提交申请', objectId: 'app_2026_001', originState: '空', newState: '已提交', reason: '提交户口迁移登记办理', sourceIp: '192.168.1.101', result: '成功' },
  { id: 'aud_003', operator: '王静', role: '窗口工作人员', department: '市政务服务中心', actionTime: '2026-09-15 15:10:00', actionType: '材料受理', objectId: 'app_2026_001', originState: '已提交', newState: '已受理', reason: '符合初审标准', sourceIp: '10.10.2.14', result: '成功' },
  { id: 'aud_004', operator: '周华', role: '审批人员', department: '市项目建设管理中心', actionTime: '2026-09-16 16:30:00', actionType: '材料退回', objectId: 'app_2026_002', originState: '已提交', newState: '材料待补正', reason: '研发预算表不符合合规要求', sourceIp: '10.10.8.22', result: '成功' }
];

// 公共设施维护工单
const maintenanceTickets = [
  { id: 't_001', title: '东湖公园南门景观路灯不亮', type: '公共照明', location: '东湖区东湖公园南门', reporter: '张先生', contact: '138****5521', submitTime: '2026-09-16 09:12', priority: '中', dept: '市公共设施维护中心', assignee: '刘师傅', status: '处理中', description: '南侧一整排共5盏路灯到了晚上不亮，怀疑是地埋电缆短路 or 定时控制器坏了。', updates: [{ time: '2026-09-16 09:12', text: '市民通过政务云枢纽故障上报成功。', operator: '张先生' }, { time: '2026-09-16 10:30', text: '工单已分派给维护一班刘师傅现场勘察。', operator: '管理中心-派单员' }] },
  { id: 't_002', title: '北岭区迎宾大道传感器断线告警', type: '传感器设备', location: '北岭区迎宾大道288号路口', reporter: '系统自动监控', contact: '10086-SIM', submitTime: '2026-09-17 01:45', priority: '高', dept: '市公共设施维护中心', assignee: '陈技术员', status: '已提交', description: '2号多功能智慧电杆下的交通流量监测雷达出现连接超时、设备不在线。', updates: [{ time: '2026-09-17 01:45', text: '系统自动化探测到传感器异常，生成维护工单。', operator: '监控引擎' }] }
];

// 城市运行模拟数据 (物联网传感器状态)
const cityTelemetry = {
  updateTime: '2026-09-17 10:30',
  summary: {
    roadStatus: '畅通 (均速 42.5 km/h)',
    waterStatus: '正常 (浊度 0.12 NTU)',
    powerStatus: '正常 (负荷率 64.2%)',
    emergencyCount: 0
  },
  districtsData: {
    '中央行政区': { trafficCongestion: 1.2, powerLoad: 72, waterTurbidity: 0.10, sensorOnline: true },
    '江湾区': { trafficCongestion: 1.5, powerLoad: 65, waterTurbidity: 0.11, sensorOnline: true },
    '北岭区': { trafficCongestion: 1.8, powerLoad: 58, waterTurbidity: 0.15, sensorOnline: false }, // 有告警设备
    '东湖区': { trafficCongestion: 1.1, powerLoad: 68, waterTurbidity: 0.09, sensorOnline: true },
    '南港区': { trafficCongestion: 1.9, powerLoad: 78, waterTurbidity: 0.13, sensorOnline: true },
    '西郊区': { trafficCongestion: 1.0, powerLoad: 45, waterTurbidity: 0.12, sensorOnline: true }
  },
  emergencyScenarios: [] as EmergencyItem[]
};

// 公共项目管理 (江湾交通、北岭水务、东湖改造、南港枢纽、西郊更新)
const projects = [
  { id: 'proj_01', name: '江湾公共交通提升工程', type: '交通设施', manager: '王大伟', budget: 15000000, planDates: '2026-01 ~ 2026-12', progress: 75, status: '建设中', milestones: [{ name: '一期公交专用道铺设', status: '已完成', date: '2026-04' }, { name: '江湾客运枢纽封顶', status: '已完成', date: '2026-08' }, { name: '智能候车亭安装调试', status: '进行中', date: '2026-11' }], risk: '低', loc: '江湾区临江大道' },
  { id: 'proj_02', name: '北岭智慧水务监测项目', type: '水利环保', manager: '周敏', budget: 8500000, planDates: '2026-03 ~ 2026-10', progress: 90, status: '已立项', milestones: [{ name: '北岭水源区传感器部署', status: '已完成', date: '2026-06' }, { name: '主干水压远程阀门改造', status: '进行中', date: '2026-09' }], risk: '中', loc: '北岭区迎宾大道' },
  { id: 'proj_03', name: '东湖公共空间提质改造', type: '城市更新', manager: '赵明', budget: 4200000, planDates: '2026-05 ~ 2026-11', progress: 45, status: '招标中', milestones: [{ name: '景观规划与绿化定方案', status: '已完成', date: '2026-06' }, { name: '南门人行道地砖拆除铺设', status: '进行中', date: '2026-09' }], risk: '低', loc: '东湖区东湖大道' },
  { id: 'proj_04', name: '南港现代化物流枢纽建设', type: '基础设施', manager: '钱伟', budget: 35000000, planDates: '2025-08 ~ 2027-06', progress: 55, status: '建设中', milestones: [{ name: '物流堆场路基硬化', status: '已完成', date: '2026-03' }, { name: '1号全自动分拣中心开工', status: '进行中', date: '2026-09' }], risk: '高', loc: '南港区港口大道' }
];

// 财政部门预算管理
const budgets = [
  { id: 'bg_01', deptId: 'dept_01', deptName: '市政务服务中心', fiscalYear: 2026, originalLimit: 12000000, usedAmount: 8500000, balance: 3500000, ratio: 70.8, adjustmentLogs: [] as BudgetAdjustmentLog[] },
  { id: 'bg_02', deptId: 'dept_02', deptName: '市城市运行管理中心', fiscalYear: 2026, originalLimit: 15000000, usedAmount: 11200000, balance: 3800000, ratio: 74.6, adjustmentLogs: [] as BudgetAdjustmentLog[] },
  { id: 'bg_03', deptId: 'dept_03', deptName: '市财政管理处', fiscalYear: 2026, originalLimit: 5000000, usedAmount: 3200000, balance: 1800000, ratio: 64.0, adjustmentLogs: [] as BudgetAdjustmentLog[] },
  { id: 'bg_04', deptId: 'dept_09', deptName: '市公共设施维护中心', fiscalYear: 2026, originalLimit: 8000000, usedAmount: 6800000, balance: 1200000, ratio: 85.0, adjustmentLogs: [] as BudgetAdjustmentLog[] }
];

// 公共资产管理
const publicAssets = [
  { id: 'ast_001', name: '市政务大厅一楼综合办证楼', type: '公共建筑', dept: '市政务服务中心', loc: '中央行政区人民路88号', purchaseDate: '2021-05-18', bookValue: 55000000, status: '在用', responsible: '办公室-陈主任' },
  { id: 'ast_002', name: '市交警一分局电动巡逻卡车', type: '公共车辆', dept: '市交通管理中心', loc: '江湾区临江大道21号', purchaseDate: '2024-03-12', bookValue: 120000, status: '在用', responsible: '后勤组-小李' },
  { id: 'ast_003', name: '城市网格环保监测微型气象站', type: '信息化设备', dept: '市城市运行管理中心', loc: '北岭区山前路', purchaseDate: '2025-06-25', bookValue: 45000, status: '维护中', responsible: '技术科-陈工' }
];

// 数据治理资产目录
const dataAssets = [
  { id: 'dt_001', name: '新衡市常住居民基础户籍数据库', dept: '市数据治理中心', category: '人口地基数据', level: '高敏感 (三级)', updateFreq: '日更', owner: '数据科-刘科长', retention: '永久保存', completeness: 99.8, accuracy: 99.5, consistency: 100.0, lineage: '各区派出所 -> 区政务局 -> 市人口底座' },
  { id: 'dt_002', name: '新衡市公共车位实时监控状态表', dept: '市交通管理中心', category: '交通传感器', level: '中敏感 (二级)', updateFreq: '分钟级', owner: '交管技术部-张工', retention: '3个月', completeness: 98.5, accuracy: 96.2, consistency: 97.5, lineage: '地磁雷达 -> 接入网关 -> 智能交通大脑' },
  { id: 'dt_003', name: '新衡市公共设施维护耗用财政账目', dept: '市公共设施维护中心', category: '财务数据', level: '极高敏感 (四级)', updateFreq: '月更', owner: '财务科-王主任', retention: '20年', completeness: 100.0, accuracy: 100.0, consistency: 100.0, lineage: '设施工单 -> 材料核销 -> 部门报销系统' }
];

// 共享授权申请
const sharingRequests = [
  { id: 'sh_001', assetId: 'dt_001', assetName: '新衡市常住居民基础户籍数据库', reqDept: '市住房服务中心', purpose: '公共保障房申请资格联动比对审核。', status: '待审批', reviewer: '数据治理人员', submitTime: '2026-09-17 09:15' }
];

// Helper to safely get and decode x-user-role header
function getUserRole(req: express.Request, defaultRole = '市民用户'): string {
  const raw = req.headers['x-user-role'];
  if (!raw) return defaultRole;
  try {
    return decodeURIComponent(String(raw));
  } catch {
    return String(raw) || defaultRole;
  }
}

// ==========================================
// 3. 权限校验中间件 (后端权限保障)
// ==========================================
function checkPermission(requiredRoles: string[]) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const userRole = getUserRole(req, '市民用户');
    // 综合管理员和系统安全管理员具有所有操作权限
    if (requiredRoles.includes(userRole) || userRole === '综合管理员' || userRole === '系统安全管理员') {
      next();
    } else {
      res.status(403).json({
        error: '权限不足',
        message: `当前操作受限。您的模拟角色 [${userRole}] 无权访问此资源，此操作需要 [${requiredRoles.join(', ')}] 权限。请在顶部“模拟账户切换器”中切换相应角色。`,
        demoRequired: requiredRoles
      });
    }
  };
}

// 辅助记录审计日志
function writeAudit(operator: string, role: string, dept: string, actionType: string, objectId: string, originState: string, newState: string, reason: string, sourceIp: string, result: string) {
  const newLog = {
    id: `aud_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    operator,
    role,
    department: dept,
    actionTime: new Date().toISOString().replace('T', ' ').substring(0, 19),
    actionType,
    objectId,
    originState,
    newState,
    reason,
    sourceIp,
    result
  };
  auditLogs.unshift(newLog);
  return newLog;
}

// ==========================================
// 4. REST API 路由
// ==========================================

// 政务服务目录
app.get('/api/services', (req, res) => {
  res.json(SERVICES);
});

// 政策文件
app.get('/api/policies', (req, res) => {
  res.json(policyDocuments);
});

// 审批申请
app.get('/api/applications', (req, res) => {
  res.json(applications);
});

// 提交申请 (市民/企业)
app.post('/api/applications', (req, res) => {
  const { serviceId, applicantName, applicantType, materials, formValues } = req.body;
  const service = SERVICES.find(s => s.id === serviceId);
  if (!service) {
    return res.status(404).json({ error: '服务不存在' });
  }

  const role = getUserRole(req, '市民用户');

  // 校验必须材料
  const currentMaterials = service.materials.map(matName => {
    const exists = materials && materials.some((m: { name: string; uploaded: boolean }) => m.name === matName && m.uploaded);
    return {
      name: matName,
      status: exists ? '已校验' : '材料待上传',
      file: exists ? 'uploaded_doc.png' : null
    };
  });

  const missingCount = currentMaterials.filter(m => m.status === '材料待上传').length;

  const newApp = {
    id: `app_${Date.now()}`,
    serviceId: service.id,
    serviceName: service.name,
    department: service.department,
    applicantName: applicantName || '测试申报人',
    applicantType: applicantType || '市民',
    submitTime: new Date().toISOString().replace('T', ' ').substring(0, 16),
    status: missingCount > 0 ? '材料待补正' : '已提交',
    materials: currentMaterials,
    timeline: [
      {
        operator: applicantName || '测试申报人',
        action: '提交申请',
        time: new Date().toISOString().replace('T', ' ').substring(0, 16),
        opinion: `在线递交申请。表单数据: ${JSON.stringify(formValues || {})}`,
        ruleVersion: 'v1.0'
      }
    ],
    result: null,
    evaluation: null,
    appeal: null,
    licenseUrl: null,
    archiveId: null
  };

  applications.unshift(newApp);

  writeAudit(
    newApp.applicantName,
    role as string,
    applicantType === '企业' ? '企业组织' : '社会公众',
    '提交申请',
    newApp.id,
    '空',
    newApp.status,
    `递交 [${service.name}] 办事申请`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({
    success: true,
    message: missingCount > 0 ? '申请已提交，但由于部分必需材料缺失，状态已置为“材料待补正”，请尽快补充。' : '申请提交成功！已进入受理队列。',
    application: newApp
  });
});

// 审批流转操作 (部门审批、补正、核核等)
app.post('/api/applications/:id/action', (req, res) => {
  const { id } = req.params;
  const { action, opinion, operator, details } = req.body;
  const userRole = getUserRole(req, '市民用户');

  const appItem = applications.find(a => a.id === id);
  if (!appItem) {
    return res.status(404).json({ error: '申请不存在' });
  }

  const oldStatus = appItem.status;
  let newStatus = oldStatus;

  // 根据按钮动作转换状态
  switch (action) {
    case '受理':
      newStatus = '已受理';
      break;
    case '退回修改':
      newStatus = '材料待补正';
      break;
    case '补正上传':
      // 模拟所有材料补全
      appItem.materials.forEach((m: ApplicationMaterial) => m.status = '已校验');
      newStatus = '已提交';
      break;
    case '部门审核':
      newStatus = '部门审核中';
      break;
    case '提交人工复核':
      newStatus = '等待人工复核';
      break;
    case '通过':
      newStatus = '审批通过';
      appItem.licenseUrl = `LIC-HE-${Math.floor(100000 + Math.random() * 900000)}`;
      appItem.result = {
        issueDate: new Date().toISOString().replace('T', ' ').substring(0, 10),
        effectivePeriod: '五年',
        issuingAuthority: appItem.department,
        legalNotice: '本电子凭证仅在 [新衡市数字政府演示沙箱] 内有效，不具法律强制效力。'
      };
      break;
    case '不通过':
      newStatus = '审批不通过';
      appItem.result = {
        rejectReason: opinion || '不符合审批条件。',
        notice: '您有权在3个工作日内点击发起申诉，申请人工纠偏复议。'
      };
      break;
    case '归档':
      newStatus = '已归档';
      appItem.archiveId = `ARC-2026-${Math.floor(100000 + Math.random() * 900000)}`;
      break;
    case '发起申诉':
      newStatus = '申诉处理中';
      appItem.appeal = {
        reason: opinion,
        time: new Date().toISOString().replace('T', ' ').substring(0, 16),
        status: '已受理分派',
        reply: null
      };
      break;
    case '提交评价':
      appItem.evaluation = {
        score: details?.score || 5,
        comment: details?.comment || '非常高效，谢谢！',
        time: new Date().toISOString().replace('T', ' ').substring(0, 16)
      };
      break;
    default:
      return res.status(400).json({ error: '无效的操作指令' });
  }

  appItem.status = newStatus;
  appItem.timeline.push({
    operator: operator || '工作人员',
    action: action,
    time: new Date().toISOString().replace('T', ' ').substring(0, 16),
    opinion: opinion || '无意见。',
    ruleVersion: 'v1.0'
  });

  writeAudit(
    operator || '操作员',
    userRole,
    appItem.department || '后台系统',
    action,
    appItem.id,
    oldStatus,
    newStatus,
    opinion || `执行业务节点流转: [${action}]`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({ success: true, message: `操作 [${action}] 已成功应用。`, application: appItem });
});

// 公共设施维护工单
app.get('/api/maintenance', (req, res) => {
  res.json(maintenanceTickets);
});

// 故障上报 (市民)
app.post('/api/maintenance', (req, res) => {
  const { title, type, location, reporter, contact, description } = req.body;
  const role = getUserRole(req, '市民用户');

  const newTicket = {
    id: `t_${Date.now()}`,
    title: title || '新上报设施故障',
    type: type || '其他设施',
    location: location || '新衡市范围',
    reporter: reporter || '匿名市民',
    contact: contact || '暂无留底',
    submitTime: new Date().toISOString().replace('T', ' ').substring(0, 16),
    priority: '中',
    dept: '市公共设施维护中心',
    assignee: '未分派',
    status: '已提交',
    description: description || '无详细描述',
    updates: [
      { time: new Date().toISOString().replace('T', ' ').substring(0, 16), text: '市民在线提交故障上报申请。', operator: reporter || '匿名市民' }
    ]
  };

  maintenanceTickets.unshift(newTicket);

  writeAudit(
    newTicket.reporter,
    role as string,
    '社会公众',
    '上报设施故障',
    newTicket.id,
    '空',
    '已提交',
    `市民上报公共设施损坏: [${newTicket.title}]`,
    req.ip || '127.0.0.1',
    '成功'
  );

  res.json({ success: true, ticket: newTicket });
});

// 更新工单状态 (公共设施维护人员)
app.post('/api/maintenance/:id/status', checkPermission(['城市运行人员', '资产管理员', '综合管理员']), (req, res) => {
  const { id } = req.params;
  const { status, operator, comments, assignee } = req.body;
  const userRole = getUserRole(req, '城市运行人员');

  const ticket = maintenanceTickets.find(t => t.id === id);
  if (!ticket) {
    return res.status(404).json({ error: '工单不存在' });
  }

  const oldStatus = ticket.status;
  ticket.status = status;
  if (assignee) {
    ticket.assignee = assignee;
  }

  ticket.updates.push({
    time: new Date().toISOString().replace('T', ' ').substring(0, 16),
    text: comments || `工单状态更新为 [${status}]`,
    operator: operator || '值班调度员'
  });

  writeAudit(
    operator || '维护调度员',
    userRole,
    '市公共设施维护中心',
    '更新工单状态',
    ticket.id,
    oldStatus,
    status,
    comments || `流转故障工单状态: ${status}`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({ success: true, ticket });
});

// 城市运行监控数据
app.get('/api/city-telemetry', (req, res) => {
  res.json(cityTelemetry);
});

// 调整模拟物联网传感器值
app.post('/api/city-telemetry/update-sensor', checkPermission(['城市运行人员', '综合管理员', '系统安全管理员']), (req, res) => {
  const { district, key, value, operator } = req.body;
  const userRole = getUserRole(req, '城市运行人员');

  const dData = cityTelemetry.districtsData[district as keyof typeof cityTelemetry.districtsData] as Record<string, number | boolean>;
  if (!dData) {
    return res.status(404).json({ error: '区划不存在' });
  }

  const oldVal = dData[key];
  dData[key] = typeof oldVal === 'boolean' ? (value === 1) : Number(value);
  cityTelemetry.updateTime = new Date().toISOString().replace('T', ' ').substring(0, 16);

  // 动态重新计算 summary
  let totalSpeed = 0;
  let speedCount = 0;

  Object.values(cityTelemetry.districtsData).forEach((d: DistrictTelemetry) => {
    totalSpeed += d.trafficCongestion;
    speedCount++;
  });

  const avgCongest = totalSpeed / speedCount;
  cityTelemetry.summary.roadStatus = avgCongest > 1.6 ? '轻度拥堵 (均速 32.1 km/h)' : '极其畅通 (均速 48.2 km/h)';

  writeAudit(
    operator || '环境监测工程师',
    userRole,
    '市城市运行管理中心',
    '调整传感器指标',
    `sensor_${district}_${key}`,
    String(oldVal),
    String(value),
    `手动调校演示传感器: [${district} - ${key}]`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({ success: true, telemetry: cityTelemetry });
});

// 触发应急事件模拟
app.post('/api/city-telemetry/trigger-emergency', checkPermission(['城市运行人员', '综合管理员']), (req, res) => {
  const { type, severity, district, operator, description } = req.body;
  const userRole = getUserRole(req, '城市运行人员');

  const newScenario = {
    id: `em_${Date.now()}`,
    type,
    severity, // 红色、橙色、黄色、蓝色
    district,
    description: description || `监测到模拟${type}灾害，已启动多方联动。`,
    startTime: new Date().toISOString().replace('T', ' ').substring(0, 16),
    status: '处置中',
    dispatchedTeams: [] as string[],
    timeline: [
      { time: new Date().toISOString().replace('T', ' ').substring(0, 16), text: `市联动中心触发 [${type}] 预警并接入模拟调度系统。` }
    ]
  };

  cityTelemetry.emergencyScenarios.unshift(newScenario);
  cityTelemetry.summary.emergencyCount = cityTelemetry.emergencyScenarios.filter((e: EmergencyItem) => e.status === '处置中').length;

  writeAudit(
    operator || '应急总指挥',
    userRole,
    '市城市运行管理中心',
    '触发应急演练',
    newScenario.id,
    '空',
    '处置中',
    `在 [${district}] 手动拉响 [${type}] (${severity}预警) 模拟演练`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({ success: true, scenario: newScenario, telemetry: cityTelemetry });
});

// 更新应急处置状态 (分派救援、关闭等)
app.post('/api/city-telemetry/emergency/:id/action', checkPermission(['城市运行人员', '综合管理员']), (req, res) => {
  const { id } = req.params;
  const { action, details, operator } = req.body;
  const userRole = getUserRole(req, '城市运行人员');

  const em = cityTelemetry.emergencyScenarios.find((e: EmergencyItem) => e.id === id);
  if (!em) {
    return res.status(404).json({ error: '应急事件不存在' });
  }

  const oldStatus = em.status;

  if (action === '派遣队伍') {
    em.dispatchedTeams.push(details.team);
    em.timeline.push({
      time: new Date().toISOString().replace('T', ' ').substring(0, 16),
      text: `已指令派往现场：${details.team} (正在奔赴中)`
    });
  } else if (action === '处置完成') {
    em.status = '已完成';
    em.timeline.push({
      time: new Date().toISOString().replace('T', ' ').substring(0, 16),
      text: '现场险情基本排除，进入后期环境清洗及排涝退去。'
    });
  } else if (action === '关闭归档') {
    em.status = '已关闭';
    em.timeline.push({
      time: new Date().toISOString().replace('T', ' ').substring(0, 16),
      text: '演练结束，正式对模拟应急记录进行全链归档。'
    });
  }

  cityTelemetry.summary.emergencyCount = cityTelemetry.emergencyScenarios.filter((e: EmergencyItem) => e.status === '处置中').length;

  writeAudit(
    operator || '联动专员',
    userRole,
    '市城市运行管理中心',
    `应急操作-${action}`,
    em.id,
    oldStatus,
    em.status,
    `调整应急流程: ${details?.team || action}`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({ success: true, scenario: em, telemetry: cityTelemetry });
});

// 公共工程项目
app.get('/api/projects', (req, res) => {
  res.json(projects);
});

// 公共财政预算
app.get('/api/budgets', (req, res) => {
  res.json(budgets);
});

// 调整部门预算额度
app.post('/api/budgets/:id/adjust', checkPermission(['财政工作人员', '部门负责人']), (req, res) => {
  const { id } = req.params;
  const { amount, reason, operator } = req.body;
  const userRole = getUserRole(req, '财政工作人员');

  const bg = budgets.find(b => b.id === id);
  if (!bg) {
    return res.status(404).json({ error: '预算条目不存在' });
  }

  const oldLimit = bg.originalLimit;
  const adjustValue = Number(amount);
  bg.originalLimit += adjustValue;
  bg.balance = bg.originalLimit - bg.usedAmount;
  bg.ratio = Number(((bg.usedAmount / bg.originalLimit) * 100).toFixed(1));

  bg.adjustmentLogs.push({
    operator: operator || '财政科主管',
    time: new Date().toISOString().replace('T', ' ').substring(0, 16),
    amount: adjustValue,
    reason: reason || '日常统筹追加。'
  });

  writeAudit(
    operator || '财政审计官',
    userRole,
    '市财政管理处',
    '财政预算微调',
    bg.id,
    String(oldLimit),
    String(bg.originalLimit),
    `手动调拨预算额度: ${adjustValue} 元。原因: ${reason}`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({ success: true, budget: bg });
});

// 公共资产
app.get('/api/assets', (req, res) => {
  res.json(publicAssets);
});

// 资产变更、折旧等登记
app.post('/api/assets/:id/transfer', checkPermission(['资产管理员', '部门负责人']), (req, res) => {
  const { id } = req.params;
  const { newDept, newResponsible, operator, reason } = req.body;
  const userRole = getUserRole(req, '资产管理员');

  const asset = publicAssets.find(a => a.id === id);
  if (!asset) {
    return res.status(404).json({ error: '资产不存在' });
  }

  const oldDept = asset.dept;
  asset.dept = newDept;
  if (newResponsible) {
    asset.responsible = newResponsible;
  }

  writeAudit(
    operator || '资产调配科员',
    userRole,
    '市公共资源管理中心',
    '资产调拨转移',
    asset.id,
    oldDept,
    newDept,
    `执行固定资产归属划转，原部门 [${oldDept}] 移交至 [${newDept}]。理由: ${reason}`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({ success: true, asset });
});

// 数据治理资产
app.get('/api/data-governance', (req, res) => {
  res.json({
    assets: dataAssets,
    requests: sharingRequests
  });
});

// 发起共享申请
app.post('/api/data-governance/request-sharing', (req, res) => {
  const { assetId, reqDept, purpose, operator } = req.body;
  const role = getUserRole(req, '市民用户');

  const asset = dataAssets.find(d => d.id === assetId);
  if (!asset) {
    return res.status(404).json({ error: '数据资产不存在' });
  }

  const newReq = {
    id: `sh_${Date.now()}`,
    assetId: asset.id,
    assetName: asset.name,
    reqDept: reqDept || '市综合政务处',
    purpose: purpose || '跨部门业务核实。',
    status: '待审批',
    reviewer: '数据治理专员',
    submitTime: new Date().toISOString().replace('T', ' ').substring(0, 16)
  };

  sharingRequests.unshift(newReq);

  writeAudit(
    operator || '数据接口人',
    role as string,
    reqDept || '外部部门',
    '申请数据共享',
    asset.id,
    '未共享',
    '申请授权中',
    `部门 [${reqDept}] 提出申请 [${asset.name}] 跨层级数据流动接口。`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({ success: true, request: newReq });
});

// 数据治理审核审批
app.post('/api/data-governance/sharing/:id/review', checkPermission(['数据治理人员', '综合管理员']), (req, res) => {
  const { id } = req.params;
  const { action, operator, reason } = req.body;
  const userRole = getUserRole(req, '数据治理人员');

  const sh = sharingRequests.find(s => s.id === id);
  if (!sh) {
    return res.status(404).json({ error: '共享申请不存在' });
  }

  const oldStatus = sh.status;
  sh.status = action === '同意' ? '已授权共享' : '已拒绝申请';

  writeAudit(
    operator || '数据治理专家',
    userRole,
    '市数据治理中心',
    '审核共享授权',
    sh.id,
    oldStatus,
    sh.status,
    `数据审批意见: ${reason || action}`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({ success: true, request: sh });
});

// 获取所有审计日志
app.get('/api/audit-logs', checkPermission(['审计人员', '系统安全管理员', '综合管理员']), (req, res) => {
  res.json(auditLogs);
});

// ==========================================
// 5. 中文人工智能政务助手: 惰性安全初始化
// ==========================================
let aiInstance: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  if (aiInstance) return aiInstance;
  const key = process.env['GEMINI_API_KEY'];
  if (!key || key === 'MY_GEMINI_API_KEY') {
    console.warn('警告: 环境变量 GEMINI_API_KEY 未配置，政务助理将运行在本地仿真规则模型。');
    return null;
  }
  try {
    aiInstance = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
    return aiInstance;
  } catch (err) {
    console.error('初始化 GoogleGenAI 客户端失败:', err);
    return null;
  }
}

// 模拟政务云助手的智能回复规则模型 (当无 key 时启动，保障可用性)
function localSimulateAI(prompt: string): string {
  const p = prompt.trim();
  if (p.includes('户口') || p.includes('落户') || p.includes('落迁移')) {
    return `【新衡市数字政府管理局 - 政务云助手】
您好！关于您咨询的【居民户口迁移登记】流程：
1. 办理条件：需要您在新衡市拥有合法房产或稳定工作满1年并缴纳社保。
2. 所需材料：身份证、户口簿原件、房产证明或经劳动局备案的劳动合同。
3. 预计办理时限：部门受理后3个工作日。
4. 当前系统状态：后台服务正常运行，目前无需排队，您可在政务大厅模块进行在线模拟申报。
本系统已在后台全面启用 [操作安全审计]，所有办理轨迹可追溯。

数据来源：新衡市常住居民基础户籍数据库 (dt_001)`;
  }
  if (p.includes('车位') || p.includes('停车') || p.includes('车牌')) {
    return `【新衡市数字政府管理局 - 政务云助手】
您好！关于【市区公共车位预约申请】服务：
1. 办理条件：申请车辆需无未处理交通违章，申请人持有有效中国驾驶证。
2. 提报材料：行驶证照片、驾驶证及新衡市倡导的绿色出行承诺协议。
3. 当前车位饱和度：城市运行监测中心提示，目前中央行政区及南港区车流较密集，建议提前通过本枢纽提报车位申领。

数据来源：市交通管理中心地磁传感器库 (dt_002)`;
  }
  if (p.includes('应急') || p.includes('积水') || p.includes('暴雨') || p.includes('停电')) {
    return `【新衡市数字政府管理局 - 政务云助手】
新衡市当前城市运行总体稳定。
如有道路暴雨积水或电网故障：
1. 请前往【城市运行监测中心】。
2. 在该模块，您可以手动触发“暴雨积水演练”或“大面积停电”应急预案。
3. 演练触发后，应急联合调度引擎将联动：市公共设施维护中心派出现场队伍，生成维护维护工单 (如 t_001)。

数据来源：市城市网格环保监测气象站 (ast_003) & 市防洪排涝应急预案 (doc_2026_002)`;
  }
  if (p.includes('项目') || p.includes('扶持资金') || p.includes('财政')) {
    return `【新衡市数字政府管理局 - 政务云助手】
您好，当前新衡市正在主推的重大公共工程包括【江湾公共交通提升工程】和【北岭智慧水务监测项目】。
对于企业申报【科技创新项目扶持资金】：
1. 流程：在线提交研发预算细目表、信用报告 -> 部门初审 -> 财政预算比对 -> 人工复核 -> 资金拨付。
2. 目前南港区物流枢纽项目由于材料待补正已暂停部分资金发放，请及时查看办事进度。

数据来源：市财政管理处部门预算明细库 (bg_01-bg_04)`;
  }

  return `【新衡市数字政府管理局 - 政务云助手】
您好！我是新衡市政务云枢纽的专属 AI 助理。

我可以为您提供：
1. 政策咨询：了解户口迁移、企业登记、车位预约等 6 大核心办件流程与所需材料；
2. 城市监控说明：解释各区交通拥堵指数（如江湾区、南港区）、空气环境濁度等参数；
3. 流程导航：引导市民提交故障报修，协助公职人员查询待办事项、财政支出比例 and 资产调拨。

请问有什么我可以帮您？
(提示：此回答由政务助手内置确定性专家策略引擎提供。本系统内所有回答均为演示，不具有实体政府效力。)`;
}

// 智能助手 API 接口
app.post('/api/ai-assistant', async (req, res) => {
  const { prompt, userRole } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: '未输入问题内容' });
  }

  const role = userRole || getUserRole(req, '市民用户');
  const client = getGeminiClient();

  let replyText = '';

  if (!client) {
    // 降级使用高保真的本地专家模型
    replyText = localSimulateAI(prompt);
  } else {
    try {
      const systemPrompt = `你是由"新衡市数字政府管理局"发布的新一代中文政府管理助手"政务云助手"。
目前运行在虚构城市"新衡市"的"政务云枢纽"平台中。
当前访问用户的角色是 [${role}]。

请遵守以下非政治、安全的行政守则：
1. 必须使用中文回答，用语严谨、克制、官方，展现专业数字政府窗口风貌。
2. 严厉警示：只能向用户提供模拟演练数据与新衡市本地设定的办事流程，必须在回答结尾或合适段落中明确包含："（声明：本数据为新衡市数字政府沙箱模拟数据，不具真实行政效力）"。
3. 不要编造虚假的现实国家政策或任何敏感军事、涉政信息。
4. 如果用户提问的内容涉及行政审批（如落户、企业设立、资金扶持），请列出必要的申请材料。
5. 针对系统已有的数据：新衡市辖有中央行政区、江湾区、北岭区、东湖区、南港区、西郊区。主要服务有户口迁移、企业登记、车位预约、项目申报、设施报修。
6. 如果用户提到要报修或处理应急，可以引导他前往【城市运行监测中心】或【办事大厅】。
7. 不要向非审计/安全管理员透露内部涉密字段（如有）。

用户当前咨询的问题：
"${prompt}"

请给出你专业的官方政务回答：`;

      const response = await client.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: systemPrompt
      });

      replyText = response.text || '暂未生成回复，请重试。';
    } catch (err) {
      console.error('Gemini 接口调用出错:', err);
      // 优雅降级
      replyText = `【新衡市数字政府管理局 - 政务云助手】
(Gemini 服务调用超时或未配置，已无缝切换至市局确定性专家模型)
${localSimulateAI(prompt)}`;
    }
  }

  // 记录安全审计日志
  writeAudit(
    'AI 智能助手',
    '系统服务',
    '市数据治理中心',
    'AI助手咨询服务',
    `ai_q_${Date.now()}`,
    '用户提问',
    'AI解答完成',
    `解答用户 [${role}] 的提问: "${prompt.substring(0, 30)}..."`,
    req.ip || '127.0.0.1',
    '成功'
  );

  return res.json({
    success: true,
    reply: replyText,
    source: client ? 'Gemini 智能引擎' : '市局确定性专家模型',
    disclaimer: '声明：本系统内置 AI 助理及所有数据仅用于政务云枢纽平台技术沙箱展示，无任何实际执法及法定行政效力。'
  });
});


// ==========================================
// 6. Angular SSR / 静态托管路由处理
// ==========================================

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000; // 确保使用 3000 端口
  app.listen(port, () => {
    console.log(`Node Express server listening on http://0.0.0.0:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
