import {ChangeDetectionStrategy, Component, signal, effect, inject} from '@angular/core';
import {CommonModule} from '@angular/common';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import * as THREE from 'three';

interface ServiceItem {
  id: string;
  code: string;
  name: string;
  category: string;
  department: string;
  target: string;
  condition: string;
  materials: string[];
  duration: string;
  needAppointment: boolean;
  needManualReview: boolean;
  status: string;
}

interface ApplicationMaterial {
  name: string;
  status: string;
  file: string | null;
}

interface ApplicationTimeline {
  operator: string;
  action: string;
  time: string;
  opinion: string;
  ruleVersion: string;
}

interface ApplicationItem {
  id: string;
  serviceId: string;
  serviceName: string;
  department: string;
  applicantName: string;
  applicantType: string;
  submitTime: string;
  status: string;
  materials: ApplicationMaterial[];
  timeline: ApplicationTimeline[];
  result?: {
    issueDate?: string;
    effectivePeriod?: string;
    issuingAuthority?: string;
    legalNotice?: string;
    rejectReason?: string;
    notice?: string;
  } | null;
  evaluation?: {
    score: number;
    comment: string;
    time: string;
  } | null;
  appeal?: {
    reason: string;
    time: string;
    status: string;
    reply: string | null;
  } | null;
  licenseUrl?: string | null;
  archiveId?: string | null;
}

interface MaintenanceTicket {
  id: string;
  title: string;
  type: string;
  location: string;
  reporter: string;
  contact: string;
  submitTime: string;
  priority: string;
  dept: string;
  assignee: string;
  status: string;
  description: string;
  updates: { time: string; text: string; operator: string }[];
}

interface AuditLog {
  id: string;
  operator: string;
  role: string;
  department: string;
  actionTime: string;
  actionType: string;
  objectId: string;
  originState: string;
  newState: string;
  reason: string;
  sourceIp: string;
  result: string;
}

interface ProjectItem {
  id: string;
  name: string;
  type: string;
  manager: string;
  budget: number;
  planDates: string;
  progress: number;
  status: string;
  milestones: { name: string; status: string; date: string }[];
  risk: string;
  loc: string;
}

interface BudgetValue {
  id: string;
  deptId: string;
  deptName: string;
  fiscalYear: number;
  originalLimit: number;
  usedAmount: number;
  balance: number;
  ratio: number;
  adjustmentLogs: unknown[];
}

interface AssetValue {
  id: string;
  name: string;
  type: string;
  dept: string;
  loc: string;
  purchaseDate: string;
  bookValue: number;
  status: string;
  responsible: string;
}

interface DataAssetItem {
  id: string;
  name: string;
  dept: string;
  category: string;
  level: string;
  updateFreq: string;
  owner: string;
  retention: string;
  completeness: number;
  accuracy: number;
  consistency: number;
  lineage: string;
}

interface SharingRequestItem {
  id: string;
  assetId: string;
  assetName: string;
  reqDept: string;
  purpose: string;
  status: string;
  reviewer: string;
  submitTime: string;
}

interface PolicyDocument {
  id: string;
  title: string;
  category: string;
  publishDept: string;
  publishDate: string;
  effectiveDate: string;
  status: string;
  content: string;
  relatedServiceId: string;
}

interface DistrictSensor {
  waterTurbidity: number;
  trafficCongestion: number;
  sensorOnline: boolean;
}

interface EmergencyScenario {
  id: string;
  type: string;
  severity: string;
  district: string;
  description: string;
  status: string;
  dispatchedTeams: string[];
}

interface CityTelemetry {
  updateTime: string;
  summary: {
    roadStatus: string;
    waterStatus: string;
    powerStatus: string;
    emergencyCount: number;
  };
  districtsData: Record<string, DistrictSensor>;
  emergencyScenarios: EmergencyScenario[];
}

interface DataGovernanceResponse {
  assets: DataAssetItem[];
  requests: SharingRequestItem[];
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  private http = inject(HttpClient);
  private fb = inject(FormBuilder);

  // ==========================================
  // 全局核心状态 (Signals)
  // ==========================================
  activeTab = signal<string>('portal');
  is3DMode = signal<boolean>(false);
  currentRole = signal<string>('市民用户');
  currentTimeStr = signal<string>('2026-09-17 10:30:00');

  // 基础列表数据
  servicesList = signal<ServiceItem[]>([]);
  policiesList = signal<PolicyDocument[]>([]);
  applicationsList = signal<ApplicationItem[]>([]);
  maintenanceList = signal<MaintenanceTicket[]>([]);
  auditLogsList = signal<AuditLog[]>([]);
  projectsList = signal<ProjectItem[]>([]);
  budgetsList = signal<BudgetValue[]>([]);
  assetsList = signal<AssetValue[]>([]);
  dataAssetsList = signal<DataAssetItem[]>([]);
  sharingRequestsList = signal<SharingRequestItem[]>([]);

  // 城市 IoT 遥测状态
  cityTelemetry = signal<CityTelemetry>({
    updateTime: '',
    summary: { roadStatus: '加载中', waterStatus: '加载中', powerStatus: '加载中', emergencyCount: 0 },
    districtsData: {},
    emergencyScenarios: []
  });

  // UI 交互辅助状态
  selectedServiceForApply = signal<ServiceItem | null>(null);
  selectedAppForDetail = signal<ApplicationItem | null>(null);
  selectedProjectForDetail = signal<ProjectItem | null>(null);
  selectedAssetForTransfer = signal<AssetValue | null>(null);
  selectedDataForSharing = signal<DataAssetItem | null>(null);
  
  // 提示信息与弹窗控制
  notificationToast = signal<{ message: string; type: 'success' | 'error' | 'warning' | null }>({ message: '', type: null });
  activeModal = signal<string | null>(null); // 'applyModal', 'appDetailModal', 'emergencyModal', 'budgetModal', 'assetModal', 'sharingModal', 'licenseModal'

  // AI 助手相关
  aiChatHistory = signal<{ role: 'user' | 'model'; text: string; time: string }[]>([]);
  aiLoading = signal<boolean>(false);
  aiInputText = signal<string>('');

  // 表单定义
  applyForm!: FormGroup;
  maintenanceForm!: FormGroup;
  emergencyForm!: FormGroup;
  budgetAdjustForm!: FormGroup;
  assetTransferForm!: FormGroup;
  dataSharingForm!: FormGroup;
  aiForm!: FormGroup;

  // 模拟材料上传文件复选框
  simulatedUploads = signal<Record<string, boolean>>({});

  DISTRICTS = ['北岭区', '中央行政区', '江湾区', '东湖区', '南港区', '西郊区'];

  constructor() {
    this.initForms();
    this.fetchInitialData();

    // 每隔 5 秒刷新下遥测数据与时间，模拟实时运行
    setInterval(() => {
      const now = new Date();
      const dateStr = now.getFullYear() + '-' +
        String(now.getMonth() + 1).padStart(2, '0') + '-' +
        String(now.getDate()).padStart(2, '0') + ' ' +
        String(now.getHours()).padStart(2, '0') + ':' +
        String(now.getMinutes()).padStart(2, '0') + ':' +
        String(now.getSeconds()).padStart(2, '0');
      this.currentTimeStr.set(dateStr);
    }, 5000);

    // 效应：当角色发生变化时，如果用户当前查看的是限制模块，自动切换到普通大厅，并刷新数据
    effect(() => {
      this.currentRole();
      this.fetchInitialData(); // 重新加载数据以使后端隔离策略生效
    });

    // 效应：当切换到城市监测并且开启了3D模式时，初始化 Three.js
    effect(() => {
      const tab = this.activeTab();
      const mode3D = this.is3DMode();
      if (tab === 'monitoring' && mode3D) {
        setTimeout(() => {
          this.initThreeCity();
        }, 100);
      } else {
        this.destroyThreeCity();
      }
    });
  }

  // ==========================================
  // 核心数据交互 (Express API)
  // ==========================================

  private getHeaders(): HttpHeaders {
    return new HttpHeaders().set('x-user-role', encodeURIComponent(this.currentRole()));
  }

  fetchInitialData() {
    const headers = this.getHeaders();
    
    // 异步加载所有数据集
    this.http.get<ServiceItem[]>('/api/services', { headers }).subscribe(data => this.servicesList.set(data));
    this.http.get<PolicyDocument[]>('/api/policies', { headers }).subscribe(data => this.policiesList.set(data));
    this.http.get<ApplicationItem[]>('/api/applications', { headers }).subscribe(data => this.applicationsList.set(data));
    this.http.get<MaintenanceTicket[]>('/api/maintenance', { headers }).subscribe(data => this.maintenanceList.set(data));
    this.http.get<CityTelemetry>('/api/city-telemetry', { headers }).subscribe(data => this.cityTelemetry.set(data));
    this.http.get<ProjectItem[]>('/api/projects', { headers }).subscribe(data => this.projectsList.set(data));
    this.http.get<BudgetValue[]>('/api/budgets', { headers }).subscribe(data => this.budgetsList.set(data));
    this.http.get<AssetValue[]>('/api/assets', { headers }).subscribe(data => this.assetsList.set(data));

    // 数据治理模块
    this.http.get<DataGovernanceResponse>('/api/data-governance', { headers }).subscribe(data => {
      this.dataAssetsList.set(data.assets);
      this.sharingRequestsList.set(data.requests);
    });

    // 审计日志模块 (需要审计员、安全管理员或综合管理员权限)
    const canAudit = ['审计人员', '系统安全管理员', '综合管理员'].includes(this.currentRole());
    if (canAudit) {
      this.http.get<AuditLog[]>('/api/audit-logs', { headers }).subscribe({
        next: (data) => this.auditLogsList.set(data),
        error: () => this.auditLogsList.set([])
      });
    } else {
      this.auditLogsList.set([]);
    }
  }

  // ==========================================
  // 表单初始化与工具函数
  // ==========================================
  private initForms() {
    this.applyForm = this.fb.group({
      applicantName: ['陈志强', [Validators.required]],
      contact: ['13912345678', [Validators.required]],
      detailReason: ['申请万科新城落户迁入，材料完备。', [Validators.required]],
    });

    this.maintenanceForm = this.fb.group({
      title: ['', [Validators.required]],
      type: ['公共照明', [Validators.required]],
      location: ['', [Validators.required]],
      reporter: ['匿名市民', [Validators.required]],
      contact: ['13900000000', [Validators.required]],
      description: ['', [Validators.required]]
    });

    this.emergencyForm = this.fb.group({
      type: ['暴雨大风', [Validators.required]],
      severity: ['黄色较大', [Validators.required]],
      district: ['北岭区', [Validators.required]],
      description: ['气象局提示将有短时强降水，地势低洼路段易造成局部道路积水，进入防汛戒备。', [Validators.required]]
    });

    this.budgetAdjustForm = this.fb.group({
      amount: [1000000, [Validators.required]],
      reason: ['为应对台风暴雨季，紧急调增公共设施维护应急抢修预算储备。', [Validators.required]]
    });

    this.assetTransferForm = this.fb.group({
      newDept: ['市公共设施维护中心', [Validators.required]],
      newResponsible: ['维护班长-张师傅', [Validators.required]],
      reason: ['原交管巡逻电动车退役划归维护班作为物资搬运车辆使用。', [Validators.required]]
    });

    this.dataSharingForm = this.fb.group({
      reqDept: ['市住房服务中心', [Validators.required]],
      purpose: ['用于新一期保障性租赁住房家庭户籍资格与房产套数联合查验。', [Validators.required]]
    });
  }

  showToast(message: string, type: 'success' | 'error' | 'warning') {
    this.notificationToast.set({ message, type });
    setTimeout(() => {
      this.notificationToast.set({ message: '', type: null });
    }, 5000);
  }

  // ==========================================
  // 业务流程 1: 在线政务申报与材料模拟
  // ==========================================
  openApplyModal(service: ServiceItem) {
    this.selectedServiceForApply.set(service);
    // 自动根据服务填充表单名字
    const userRole = this.currentRole();
    if (userRole === '企业用户') {
      this.applyForm.patchValue({ applicantName: '新衡创科科技有限公司', contact: '0755-888821', detailReason: '申请科技创新配套研发资金支持。' });
    } else {
      this.applyForm.patchValue({ applicantName: '陈志强', contact: '13912345678', detailReason: '申请万科新城落户迁入，材料完备。' });
    }
    // 重置模拟上传
    const initialUploads: Record<string, boolean> = {};
    service.materials.forEach(m => initialUploads[m] = false);
    this.simulatedUploads.set(initialUploads);
    this.activeModal.set('applyModal');
  }

  toggleSimulateUpload(materialName: string) {
    const current = { ...this.simulatedUploads() };
    current[materialName] = !current[materialName];
    this.simulatedUploads.set(current);
    this.showToast(`模拟上传材料 [${materialName}] 成功，已校验防伪哈希电子指纹。`, 'success');
  }

  submitApplication() {
    if (this.applyForm.invalid || !this.selectedServiceForApply()) return;
    const service = this.selectedServiceForApply()!;
    const formVals = this.applyForm.value;

    // 构建上传完备性
    const uploadedMaterials = Object.entries(this.simulatedUploads()).map(([name, uploaded]) => ({
      name,
      uploaded
    }));

    const body = {
      serviceId: service.id,
      applicantName: formVals.applicantName,
      applicantType: this.currentRole() === '企业用户' ? '企业' : '市民',
      materials: uploadedMaterials,
      formValues: {
        contact: formVals.contact,
        reason: formVals.detailReason
      }
    };

    const headers = this.getHeaders();
    this.http.post<{ message: string }>('/api/applications', body, { headers }).subscribe({
      next: (res) => {
        this.showToast(res.message, 'success');
        this.activeModal.set(null);
        this.fetchInitialData();
        // 自动切到 “我的办事” 进度区域
        this.activeTab.set('portal');
      },
      error: (err) => {
        this.showToast(err.error?.message || '提报申请失败', 'error');
      }
    });
  }

  // ==========================================
  // 业务流程 2: 行政审批工作流流转 (待办审核)
  // ==========================================
  executeWorkflowAction(appId: string, action: string, opinion = '已核实通过') {
    const operator = this.currentRole() === '综合管理员' ? '高级督查专员' : `审批处-${this.currentRole()}`;
    const body = {
      action,
      opinion,
      operator
    };

    const headers = this.getHeaders();
    this.http.post<{ message: string; application: ApplicationItem }>(`/api/applications/${appId}/action`, body, { headers }).subscribe({
      next: (res) => {
        this.showToast(res.message, 'success');
        this.fetchInitialData();
        // 如果打开了详情弹窗，同步更新
        if (this.selectedAppForDetail() && this.selectedAppForDetail()?.id === appId) {
          this.selectedAppForDetail.set(res.application);
        }
      },
      error: (err) => {
        this.showToast(err.error?.message || '流程流转权限校验失败', 'error');
      }
    });
  }

  submitEvaluation(appId: string, score: number, comment: string) {
    const body = {
      action: '提交评价',
      operator: '申报主体',
      details: { score, comment }
    };
    const headers = this.getHeaders();
    this.http.post<unknown>(`/api/applications/${appId}/action`, body, { headers }).subscribe({
      next: () => {
        this.showToast('非常感谢您的服务评价，该记录已不可篡改存入数据治理审计链。', 'success');
        this.fetchInitialData();
        this.activeModal.set(null);
      }
    });
  }

  submitAppeal(appId: string, reason: string) {
    if (!reason.trim()) return;
    const body = {
      action: '发起申诉',
      operator: '申诉申请人',
      opinion: reason
    };
    const headers = this.getHeaders();
    this.http.post<unknown>(`/api/applications/${appId}/action`, body, { headers }).subscribe({
      next: () => {
        this.showToast('行政申诉已受理分派。纠偏复核小组将在1个工作日内进行人工干预复核并答复。', 'warning');
        this.fetchInitialData();
        this.activeModal.set(null);
      }
    });
  }

  // ==========================================
  // 业务流程 3: 城市物联网传感器调校
  // ==========================================
  tweakSensor(district: string, key: string, val: number) {
    const body = {
      district,
      key,
      value: val,
      operator: `物联运维部-${this.currentRole()}`
    };
    const headers = this.getHeaders();
    this.http.post<{ telemetry: CityTelemetry }>('/api/city-telemetry/update-sensor', body, { headers }).subscribe({
      next: (res) => {
        this.showToast(`城市网格 [${district}] ${key === 'trafficCongestion' ? '交通指数' : '水质浊度'} 手动调校成功。新值: ${val}`, 'success');
        this.cityTelemetry.set(res.telemetry);
      },
      error: (err) => {
        this.showToast(err.error?.message || '您没有传感器运维调校权限。', 'error');
      }
    });
  }

  triggerEmergency() {
    if (this.emergencyForm.invalid) return;
    const vals = this.emergencyForm.value;
    const body = {
      type: vals.type,
      severity: vals.severity,
      district: vals.district,
      description: vals.description,
      operator: `防汛调度总长-${this.currentRole()}`
    };
    const headers = this.getHeaders();
    this.http.post<{ telemetry: CityTelemetry }>('/api/city-telemetry/trigger-emergency', body, { headers }).subscribe({
      next: (res) => {
        this.showToast(`应急联动演练成功开启！[${vals.district}] 拉响 [${vals.type}] ${vals.severity}预警。`, 'warning');
        this.cityTelemetry.set(res.telemetry);
        this.activeModal.set(null);
      },
      error: (err) => {
        this.showToast(err.error?.message || '只有城市运行专员有权拉响突发灾害演练。', 'error');
      }
    });
  }

  dispatchEmergencyTeam(eventId: string, teamName: string) {
    const body = {
      action: '派遣队伍',
      operator: `现场总指挥-${this.currentRole()}`,
      details: { team: teamName }
    };
    const headers = this.getHeaders();
    this.http.post<{ telemetry: CityTelemetry }>(`/api/city-telemetry/emergency/${eventId}/action`, body, { headers }).subscribe({
      next: (res) => {
        this.showToast(`现场指令下达成功：派遣 [${teamName}] 赶赴现场勘查排涝。`, 'success');
        this.cityTelemetry.set(res.telemetry);
      },
      error: (err) => {
        this.showToast(err.error?.message || '派遣队伍需要城市运行指挥权限。', 'error');
      }
    });
  }

  resolveEmergency(eventId: string, closeArchive = false) {
    const action = closeArchive ? '关闭归档' : '处置完成';
    const body = {
      action,
      operator: `现场总指挥-${this.currentRole()}`,
      details: {}
    };
    const headers = this.getHeaders();
    this.http.post<{ telemetry: CityTelemetry }>(`/api/city-telemetry/emergency/${eventId}/action`, body, { headers }).subscribe({
      next: (res) => {
        this.showToast(`应急演习节点流转：[${action}] 成功。`, 'success');
        this.cityTelemetry.set(res.telemetry);
      },
      error: (err) => {
        this.showToast(err.error?.message || '流转应急节点权限受阻。', 'error');
      }
    });
  }

  // ==========================================
  // 业务流程 4: 财政预算追加调整
  // ==========================================
  adjustBudget(budgetId: string) {
    if (this.budgetAdjustForm.invalid) return;
    const vals = this.budgetAdjustForm.value;
    const body = {
      amount: vals.amount,
      reason: vals.reason,
      operator: `财政科长-${this.currentRole()}`
    };
    const headers = this.getHeaders();
    this.http.post<unknown>(`/api/budgets/${budgetId}/adjust`, body, { headers }).subscribe({
      next: () => {
        this.showToast(`财政资金预算统筹微调成功！累计微调额度: ${vals.amount > 0 ? '+' : ''}${vals.amount}元。`, 'success');
        this.fetchInitialData();
        this.activeModal.set(null);
      },
      error: (err) => {
        this.showToast(err.error?.message || '微调财政资金需要财政管理员特权。', 'error');
      }
    });
  }

  // ==========================================
  // 业务流程 5: 固定资产调拨转移
  // ==========================================
  transferAsset(assetId: string) {
    if (this.assetTransferForm.invalid) return;
    const vals = this.assetTransferForm.value;
    const body = {
      newDept: vals.newDept,
      newResponsible: vals.newResponsible,
      reason: vals.reason,
      operator: `公物资产主管-${this.currentRole()}`
    };
    const headers = this.getHeaders();
    this.http.post<unknown>(`/api/assets/${assetId}/transfer`, body, { headers }).subscribe({
      next: () => {
        this.showToast(`固定公物资产转移调拨成功。原折旧估价已转移至新责任部门。`, 'success');
        this.fetchInitialData();
        this.activeModal.set(null);
      },
      error: (err) => {
        this.showToast(err.error?.message || '公物资产调拨转移需要资产管理员权限。', 'error');
      }
    });
  }

  // ==========================================
  // 业务流程 6: 数据治理跨部门共享与血缘审批
  // ==========================================
  requestDataSharing(assetId: string) {
    if (this.dataSharingForm.invalid) return;
    const vals = this.dataSharingForm.value;
    const body = {
      assetId,
      reqDept: vals.reqDept,
      purpose: vals.purpose,
      operator: `信息处数据专员-${this.currentRole()}`
    };
    const headers = this.getHeaders();
    this.http.post<unknown>('/api/data-governance/request-sharing', body, { headers }).subscribe({
      next: () => {
        this.showToast(`跨部门高敏感数据共享流转申请提交成功，已进入数据治理中心人工质检审核队列。`, 'success');
        this.fetchInitialData();
        this.activeModal.set(null);
      },
      error: (err) => {
        this.showToast(err.error?.message || '提报数据共享申请失败。', 'error');
      }
    });
  }

  reviewDataSharing(requestId: string, approve: boolean) {
    const body = {
      action: approve ? '同意' : '拒绝',
      reason: approve ? '业务契合，安全指纹审计通过。同意采用敏感脱敏级字段输出。' : '申请事由不明确，退回补充。',
      operator: `数据合规官-${this.currentRole()}`
    };
    const headers = this.getHeaders();
    this.http.post<unknown>(`/api/data-governance/sharing/${requestId}/review`, body, { headers }).subscribe({
      next: () => {
        this.showToast(`数据资产安全授信审核成功：[${body.action}] 共享交换。`, approve ? 'success' : 'warning');
        this.fetchInitialData();
      },
      error: (err) => {
        this.showToast(err.error?.message || '跨部门脱敏数据授信审批需数据治理人员特权。', 'error');
      }
    });
  }

  // ==========================================
  // 业务流程 7: 公共设施故障上报维修
  // ==========================================
  submitRepair() {
    if (this.maintenanceForm.invalid) return;
    const vals = this.maintenanceForm.value;
    const body = {
      title: vals.title,
      type: vals.type,
      location: vals.location,
      reporter: vals.reporter,
      contact: vals.contact,
      description: vals.description
    };
    const headers = this.getHeaders();
    this.http.post<unknown>('/api/maintenance', body, { headers }).subscribe({
      next: () => {
        this.showToast(`市政设施故障派单上报成功！感谢您参与新衡市城市网格共建。`, 'success');
        this.fetchInitialData();
        this.activeModal.set(null);
        // 自动重置表单
        this.maintenanceForm.reset({ reporter: '匿名市民', contact: '13900000000', type: '公共照明' });
      }
    });
  }

  updateTicketStatus(ticketId: string, nextStatus: string) {
    let comments = '设施工单推进中。';
    if (nextStatus === '处理中') comments = '现场抢修一班刘师傅携带零配件器材已抵达现场。';
    else if (nextStatus === '已完成') comments = '损坏线路及控制器部件已全部更换完毕，路灯光照测试正常亮起。故障关闭。';

    const body = {
      status: nextStatus,
      comments,
      assignee: '抢修一班-刘师傅',
      operator: `维护调度中心-${this.currentRole()}`
    };
    const headers = this.getHeaders();
    this.http.post<unknown>(`/api/maintenance/${ticketId}/status`, body, { headers }).subscribe({
      next: () => {
        this.showToast(`设施工单流转成功，状态置为 [${nextStatus}]`, 'success');
        this.fetchInitialData();
      },
      error: (err) => {
        this.showToast(err.error?.message || '您没有设施工单调度指派权。', 'error');
      }
    });
  }

  // ==========================================
  // 业务流程 8: 中文人工智能政务云助手 (Gemini)
  // ==========================================
  sendAiMessage() {
    const text = this.aiInputText().trim();
    if (!text || this.aiLoading()) return;

    // 添加用户记录
    const time = new Date().toISOString().replace('T', ' ').substring(11, 19);
    this.aiChatHistory.update(hist => [...hist, { role: 'user', text, time }]);
    this.aiInputText.set('');
    this.aiLoading.set(true);

    const body = {
      prompt: text,
      userRole: this.currentRole()
    };
    const headers = this.getHeaders();

    this.http.post<{ reply: string }>('/api/ai-assistant', body, { headers }).subscribe({
      next: (res) => {
        const modelTime = new Date().toISOString().replace('T', ' ').substring(11, 19);
        this.aiChatHistory.update(hist => [...hist, { role: 'model', text: res.reply, time: modelTime }]);
        this.aiLoading.set(false);
      },
      error: () => {
        const modelTime = new Date().toISOString().replace('T', ' ').substring(11, 19);
        this.aiChatHistory.update(hist => [...hist, {
          role: 'model',
          text: '【服务提醒】政务网络瞬时波动。政务云助手启动本地容灾策略：\n\n新衡市数字政府沙箱内暂无真实互联网接口连通。如您想体验，可尝试提问“户口迁移登记”、“路灯报修流程”或“防灾应急方案”，谢谢！',
          time: modelTime
        }]);
        this.aiLoading.set(false);
      }
    });
  }

  insertAiPrompt(prompt: string) {
    this.aiInputText.set(prompt);
  }

  clearAiChat() {
    this.aiChatHistory.set([]);
  }

  // ==========================================
  // 辅助数据计算与视图转换
  // ==========================================
  get totalPendingApprovalsCount(): number {
    return this.applicationsList().filter(a => ['已提交', '等待人工复核', '部门审核中'].includes(a.status)).length;
  }

  get totalPendingSharingRequestsCount(): number {
    return this.sharingRequestsList().filter(s => s.status === '待审批').length;
  }

  get activeEmergenciesCount(): number {
    return this.cityTelemetry().emergencyScenarios?.filter((e: EmergencyScenario) => e.status === '处置中').length || 0;
  }

  get activeMaintenanceTicketsCount(): number {
    return this.maintenanceList().filter(t => t.status !== '已完成' && t.status !== '已关闭').length;
  }

  // ==========================================
  // Three.js 3D 城市数字孪生渲染
  // ==========================================
  private threeRenderer: THREE.WebGLRenderer | null = null;
  private threeAnimationId: number | null = null;

  initThreeCity() {
    this.destroyThreeCity();

    const container = document.getElementById('three-container');
    const canvas = document.getElementById('three-canvas') as HTMLCanvasElement;
    if (!container || !canvas) return;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 400;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020617);
    scene.fog = new THREE.FogExp2(0x020617, 0.015);

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    camera.position.set(40, 50, 70);
    camera.lookAt(0, 5, 0);

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.threeRenderer = renderer;

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0x0a192f, 2.5);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x0ea5e9, 4);
    dirLight1.position.set(50, 80, 50);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xf43f5e, 2);
    dirLight2.position.set(-50, 40, -50);
    scene.add(dirLight2);

    const pointLight = new THREE.PointLight(0xe1b764, 5, 100);
    pointLight.position.set(0, 10, 0);
    scene.add(pointLight);

    // 5. Floor grid
    const size = 120;
    const divisions = 30;
    const gridHelper = new THREE.GridHelper(size, divisions, 0x334155, 0x1e293b);
    gridHelper.position.y = 0.1;
    scene.add(gridHelper);

    const floorGeo = new THREE.PlaneGeometry(size, size);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x070f2b,
      roughness: 0.8,
      metalness: 0.2
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    scene.add(floor);

    // 6. Buildings
    const buildingGroup = new THREE.Group();
    const buildingCount = 70;
    const buildings: THREE.Mesh[] = [];

    const districtColors = [
      { color: 0x38bdf8 },
      { color: 0x10b981 },
      { color: 0xf59e0b },
      { color: 0x6366f1 },
      { color: 0xec4899 },
      { color: 0x14b8a6 }
    ];

    for (let i = 0; i < buildingCount; i++) {
      const bWidth = Math.random() * 3 + 1.5;
      const bHeight = Math.random() * 16 + 4;
      const bDepth = Math.random() * 3 + 1.5;

      const geo = new THREE.BoxGeometry(bWidth, bHeight, bDepth);
      const dist = districtColors[i % districtColors.length];
      const mat = new THREE.MeshStandardMaterial({
        color: 0x1e293b,
        roughness: 0.3,
        metalness: 0.7,
        emissive: new THREE.Color(dist.color),
        emissiveIntensity: 0.15
      });

      const building = new THREE.Mesh(geo, mat);
      const angle = (i / buildingCount) * Math.PI * 2 + Math.random() * 0.4;
      const radius = 15 + Math.random() * 35;
      building.position.x = Math.cos(angle) * radius;
      building.position.z = Math.sin(angle) * radius;
      building.position.y = bHeight / 2;

      buildingGroup.add(building);
      buildings.push(building);
    }
    scene.add(buildingGroup);

    // 7. Dynamic cyber ring
    const ringGeo = new THREE.RingGeometry(3, 4, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x00f5ff, side: THREE.DoubleSide, transparent: true, opacity: 0.6 });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.5;
    scene.add(ring);

    // Cyber particle nodes
    const particleGeo = new THREE.BufferGeometry();
    const particleCount = 200;
    const posArr = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      posArr[i] = (Math.random() - 0.5) * 110;
      posArr[i + 1] = Math.random() * 25;
      posArr[i + 2] = (Math.random() - 0.5) * 110;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(posArr, 3));
    const particleMat = new THREE.PointsMaterial({
      size: 0.6,
      color: 0x0ea5e9,
      transparent: true,
      opacity: 0.8
    });
    const cloud = new THREE.Points(particleGeo, particleMat);
    scene.add(cloud);

    // 8. Resize Observer
    const resizeObserver = new ResizeObserver(entries => {
      if (!entries || entries.length === 0) return;
      const entry = entries[0];
      const w = entry.contentRect.width || width;
      const h = entry.contentRect.height || height;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
    resizeObserver.observe(container);

    // 9. Animation loop
    let angleOffset = 0;
    const animate = () => {
      this.threeAnimationId = requestAnimationFrame(animate);

      angleOffset += 0.0015;
      camera.position.x = Math.cos(angleOffset) * 80;
      camera.position.z = Math.sin(angleOffset) * 80;
      camera.lookAt(0, 8, 0);

      const time = Date.now() * 0.001;
      ring.scale.setScalar(1 + Math.sin(time * 2) * 0.3);
      ringMat.opacity = 0.3 + Math.sin(time * 3) * 0.2;

      buildings.forEach((b, idx) => {
        const mat = b.material as THREE.MeshStandardMaterial;
        mat.emissiveIntensity = 0.1 + Math.abs(Math.sin(time + idx * 0.1)) * 0.3;
      });

      renderer.render(scene, camera);
    };

    animate();
  }

  destroyThreeCity() {
    if (this.threeAnimationId) {
      cancelAnimationFrame(this.threeAnimationId);
      this.threeAnimationId = null;
    }
    if (this.threeRenderer) {
      this.threeRenderer.dispose();
      this.threeRenderer = null;
    }
  }
}
