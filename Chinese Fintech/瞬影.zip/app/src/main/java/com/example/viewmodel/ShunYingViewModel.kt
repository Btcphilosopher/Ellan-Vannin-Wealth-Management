package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class CameraEditorState(
    val selectedSampleRes: Int = R.drawable.img_demo_coffee_1789640145800,
    val isCameraPermissionGranted: Boolean = false,
    val selectedFilter: String = "原图",
    val brightness: Float = 1.0f,
    val contrast: Float = 1.0f,
    val selectedArEffect: String = "无",
    val overlayText: String = "",
    val textColorHex: String = "#FFFFFF",
    val selectedSticker: String = "",
    val selectedTimerLabel: String = "10秒后过期",
    val timerSeconds: Int = 10,
    val selectedRecipientUsername: String = "linxiaoyu"
)

class ShunYingViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    val repository = ShunYingRepository(db)

    // Current Session State
    private val _isLoggedIn = MutableStateFlow(true)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _currentUsername = MutableStateFlow("demo_user")
    val currentUsername: StateFlow<String> = _currentUsername.asStateFlow()

    private val _currentDisplayName = MutableStateFlow("演示用户")
    val currentDisplayName: StateFlow<String> = _currentDisplayName.asStateFlow()

    private val _currentBio = MutableStateFlow("记录此刻，分享当下。")
    val currentBio: StateFlow<String> = _currentBio.asStateFlow()

    // Navigation State
    private val _currentTab = MutableStateFlow("HOME") // HOME, CAMERA, STORIES, CHAT, DISCOVER, PROFILE, SETTINGS, NOTIFICATIONS
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    // Camera & Editor State
    private val _editorState = MutableStateFlow(CameraEditorState())
    val editorState: StateFlow<CameraEditorState> = _editorState.asStateFlow()

    // Snap Viewer State
    private val _activeViewingSnap = MutableStateFlow<SnapEntity?>(null)
    val activeViewingSnap: StateFlow<SnapEntity?> = _activeViewingSnap.asStateFlow()

    private val _snapCountdownSeconds = MutableStateFlow(10)
    val snapCountdownSeconds: StateFlow<Int> = _snapCountdownSeconds.asStateFlow()

    private val _isSnapExpiredNoticeVisible = MutableStateFlow(false)
    val isSnapExpiredNoticeVisible: StateFlow<Boolean> = _isSnapExpiredNoticeVisible.asStateFlow()

    // Active Chat detail state
    private val _activeChatId = MutableStateFlow<Int?>(null)
    val activeChatId: StateFlow<Int?> = _activeChatId.asStateFlow()

    private val _activeChatPeerName = MutableStateFlow("林晓雨")
    val activeChatPeerName: StateFlow<String> = _activeChatPeerName.asStateFlow()

    // Story Player State
    private val _activeStory = MutableStateFlow<StoryEntity?>(null)
    val activeStory: StateFlow<StoryEntity?> = _activeStory.asStateFlow()

    // Discover Modal State
    private val _activeDiscoverItem = MutableStateFlow<DiscoverEntity?>(null)
    val activeDiscoverItem: StateFlow<DiscoverEntity?> = _activeDiscoverItem.asStateFlow()

    private val _showRecommendationReason = MutableStateFlow(false)
    val showRecommendationReason: StateFlow<Boolean> = _showRecommendationReason.asStateFlow()

    // Settings State
    val isDarkMode = MutableStateFlow(true)
    val isReducedMotion = MutableStateFlow(false)
    val isLargeFont = MutableStateFlow(false)
    val isLocationSharingEnabled = MutableStateFlow(false)
    val isPrivateAccount = MutableStateFlow(false)

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }

    fun updateFriendStatus(friendId: Int, newStatus: String) {
        viewModelScope.launch {
            repository.updateFriendStatus(friendId, newStatus)
        }
    }

    // Room Flows
    val snaps: StateFlow<List<SnapEntity>> = repository.allSnaps.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val stories: StateFlow<List<StoryEntity>> = repository.allStories.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val chats: StateFlow<List<ChatEntity>> = repository.allChats.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val friends: StateFlow<List<FriendEntity>> = repository.allFriends.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val discoverContent: StateFlow<List<DiscoverEntity>> = repository.allDiscover.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val notifications: StateFlow<List<NotificationEntity>> = repository.allNotifications.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    init {
        viewModelScope.launch {
            repository.seedDemoDataIfEmpty()
        }
    }

    fun setTab(tab: String) {
        _currentTab.value = tab
    }

    fun loginWithDemoUser() {
        _isLoggedIn.value = true
        _currentUsername.value = "demo_user"
        _currentDisplayName.value = "演示用户"
        _currentTab.value = "HOME"
    }

    fun logout() {
        _isLoggedIn.value = false
        _currentTab.value = "LOGIN"
    }

    // Camera Editor methods
    fun setEditorSampleRes(resId: Int) {
        _editorState.value = _editorState.value.copy(selectedSampleRes = resId)
    }

    fun setEditorFilter(filterName: String) {
        _editorState.value = _editorState.value.copy(selectedFilter = filterName)
    }

    fun setEditorArEffect(effectName: String) {
        _editorState.value = _editorState.value.copy(selectedArEffect = effectName)
    }

    fun setEditorOverlayText(text: String) {
        _editorState.value = _editorState.value.copy(overlayText = text)
    }

    fun setEditorSticker(sticker: String) {
        _editorState.value = _editorState.value.copy(selectedSticker = sticker)
    }

    fun setEditorTimer(label: String, seconds: Int) {
        _editorState.value = _editorState.value.copy(selectedTimerLabel = label, timerSeconds = seconds)
    }

    fun setEditorRecipient(username: String) {
        _editorState.value = _editorState.value.copy(selectedRecipientUsername = username)
    }

    fun sendCurrentSnap(onSuccess: () -> Unit) {
        val state = _editorState.value
        viewModelScope.launch {
            val newSnap = SnapEntity(
                senderUsername = _currentUsername.value,
                senderDisplayName = _currentDisplayName.value,
                recipientUsername = state.selectedRecipientUsername,
                mediaType = "IMAGE",
                sampleDrawableRes = state.selectedSampleRes,
                filterName = state.selectedFilter,
                overlayText = if (state.overlayText.isBlank()) null else state.overlayText,
                sticker = if (state.selectedSticker.isBlank()) null else state.selectedSticker,
                durationSeconds = state.timerSeconds
            )
            repository.sendSnap(newSnap)
            onSuccess()
        }
    }

    fun publishCurrentAsStory(onSuccess: () -> Unit) {
        val state = _editorState.value
        viewModelScope.launch {
            val newStory = StoryEntity(
                username = _currentUsername.value,
                displayName = _currentDisplayName.value,
                avatarResId = R.drawable.ic_launcher_foreground,
                mediaDrawableRes = state.selectedSampleRes,
                caption = if (state.overlayText.isNotBlank()) state.overlayText else "来自我的瞬影故事 ✨"
            )
            repository.createStory(newStory)
            onSuccess()
        }
    }

    // Viewing Snap Countdown Workflow
    fun openSnapForViewing(snap: SnapEntity) {
        _activeViewingSnap.value = snap
        _isSnapExpiredNoticeVisible.value = false
        val initialSecs = if (snap.durationSeconds > 0) snap.durationSeconds else 5
        _snapCountdownSeconds.value = initialSecs

        viewModelScope.launch {
            repository.markSnapViewed(snap.id)

            // Start countdown
            var count = initialSecs
            while (count > 0 && _activeViewingSnap.value?.id == snap.id) {
                delay(1000L)
                count--
                _snapCountdownSeconds.value = count
            }

            if (_activeViewingSnap.value?.id == snap.id) {
                // Expire snap
                repository.markSnapExpired(snap.id)
                _isSnapExpiredNoticeVisible.value = true
            }
        }
    }

    fun closeSnapViewer() {
        _activeViewingSnap.value = null
        _isSnapExpiredNoticeVisible.value = false
    }

    // Chat methods
    fun openChat(chatId: Int, peerName: String) {
        _activeChatId.value = chatId
        _activeChatPeerName.value = peerName
        _currentTab.value = "CHAT_DETAIL"
    }

    fun closeChat() {
        _activeChatId.value = null
        _currentTab.value = "CHAT"
    }

    fun sendChatMessage(text: String) {
        val chatId = _activeChatId.value ?: return
        viewModelScope.launch {
            val msg = ChatMessageEntity(
                chatId = chatId,
                senderUsername = _currentUsername.value,
                senderDisplayName = _currentDisplayName.value,
                content = text,
                status = "发送中",
                timestamp = System.currentTimeMillis()
            )
            repository.sendMessage(msg)

            // Simulate Chinese instant delivery lifecycle: 发送中 -> 已发送 -> 已送达 -> 已读
            delay(500)
            repository.updateMessageStatus(msg.id, "已发送")
            delay(500)
            repository.updateMessageStatus(msg.id, "已送达")
            delay(1000)
            repository.updateMessageStatus(msg.id, "已读")
        }
    }

    // Story methods
    fun openStory(story: StoryEntity) {
        _activeStory.value = story
        viewModelScope.launch {
            repository.markStoryViewed(story.id)
        }
    }

    fun closeStory() {
        _activeStory.value = null
    }

    // Discover methods
    fun openDiscoverDetail(item: DiscoverEntity) {
        _activeDiscoverItem.value = item
    }

    fun closeDiscoverDetail() {
        _activeDiscoverItem.value = null
        _showRecommendationReason.value = false
    }

    fun toggleRecommendationReason() {
        _showRecommendationReason.value = !_showRecommendationReason.value
    }
}
