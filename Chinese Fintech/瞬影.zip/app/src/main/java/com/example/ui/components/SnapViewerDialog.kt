package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.locales.ZhCnText
import com.example.viewmodel.ShunYingViewModel

@Composable
fun SnapViewerDialog(
    viewModel: ShunYingViewModel
) {
    val snap by viewModel.activeViewingSnap.collectAsState()
    val countdown by viewModel.snapCountdownSeconds.collectAsState()
    val isExpiredNotice by viewModel.isSnapExpiredNoticeVisible.collectAsState()

    var showReportModal by remember { mutableStateOf(false) }

    if (snap != null) {
        Dialog(
            onDismissRequest = { viewModel.closeSnapViewer() },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                if (!isExpiredNotice) {
                    // Fullscreen Snap Media View
                    if (snap!!.sampleDrawableRes != null) {
                        Image(
                            painter = painterResource(id = snap!!.sampleDrawableRes!!),
                            contentDescription = "瞬拍内容",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Text & Sticker Overlays
                    if (snap!!.overlayText != null || snap!!.sticker != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.Center)
                                .background(Color.Black.copy(alpha = 0.5f))
                                .padding(vertical = 12.dp, horizontal = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (snap!!.sticker != null) {
                                    Text(snap!!.sticker!!, fontSize = 28.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                }
                                if (snap!!.overlayText != null) {
                                    Text(
                                        text = snap!!.overlayText!!,
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    // Top Bar (Sender Name, Timer Countdown, Close Button, Report)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp, start = 16.dp, end = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = snap!!.senderDisplayName.take(1),
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = snap!!.senderDisplayName,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "滤镜：${snap!!.filterName}",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Circular Timer Badge
                            Surface(
                                color = MaterialTheme.colorScheme.primary,
                                shape = CircleShape
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.Timer,
                                        contentDescription = null,
                                        tint = Color.Black,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${countdown}s",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            IconButton(
                                onClick = { showReportModal = true },
                                modifier = Modifier.testTag("btn_report_snap")
                            ) {
                                Icon(Icons.Filled.Report, contentDescription = "举报", tint = Color.White)
                            }

                            IconButton(
                                onClick = { viewModel.closeSnapViewer() },
                                modifier = Modifier.testTag("btn_close_snap")
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "关闭", tint = Color.White)
                            }
                        }
                    }

                    // Bottom Expiration Disclaimer Notice
                    Surface(
                        color = Color.Black.copy(alpha = 0.7f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 32.dp, start = 16.dp, end = 16.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = ZhCnText.SNAP_NOTICE_DISCLAIMER,
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                } else {
                    // EXPIRED OVERLAY STATE
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Timer,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = ZhCnText.SNAP_EXPIRED_TITLE,
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = ZhCnText.SNAP_EXPIRED_MSG,
                            color = Color.LightGray,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(28.dp))
                        Button(
                            onClick = { viewModel.closeSnapViewer() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("确定并返回", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (showReportModal) {
        AlertDialog(
            onDismissRequest = { showReportModal = false },
            title = { Text(ZhCnText.REPORT_CONTENT) },
            text = { Text("请选择举报原因：骚扰、不适宜内容、冒充他人、垃圾信息或其他原因。") },
            confirmButton = {
                TextButton(onClick = { showReportModal = false }) {
                    Text("提交举报", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportModal = false }) {
                    Text("取消")
                }
            }
        )
    }
}
