package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val username: String,
    val displayName: String,
    val avatarResId: Int,
    val bio: String,
    val isOnline: Boolean = true,
    val friendCount: Int = 12,
    val isDemo: Boolean = true
)

@Entity(tableName = "snaps")
data class SnapEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val senderUsername: String,
    val senderDisplayName: String,
    val recipientUsername: String,
    val mediaType: String = "IMAGE", // "IMAGE" or "VIDEO"
    val sampleDrawableRes: Int? = null,
    val filterName: String = "原图",
    val overlayText: String? = null,
    val sticker: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 10, // 0 = view once, 10, 3600, 86400
    val isViewed: Boolean = false,
    val viewedAt: Long? = null,
    val isExpired: Boolean = false,
    val allowSave: Boolean = false
)

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val displayName: String,
    val avatarResId: Int,
    val mediaDrawableRes: Int? = null,
    val caption: String,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 86400000L, // 24 hours
    val viewsCount: Int = 5,
    val isViewed: Boolean = false,
    val visibility: String = "所有好友"
)

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val peerUsername: String,
    val peerDisplayName: String,
    val peerAvatarResId: Int,
    val lastMessage: String,
    val lastMessageTime: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val isGroup: Boolean = false
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val chatId: Int,
    val senderUsername: String,
    val senderDisplayName: String,
    val content: String,
    val mediaType: String? = null,
    val sampleDrawableRes: Int? = null,
    val status: String = "已送达", // 发送中, 已发送, 已送达, 已读
    val timestamp: Long = System.currentTimeMillis(),
    val isSnap: Boolean = false
)

@Entity(tableName = "friends")
data class FriendEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val displayName: String,
    val avatarResId: Int,
    val isOnline: Boolean = true,
    val status: String = "已成为好友" // 已成为好友, 待处理, 已拉黑
)

@Entity(tableName = "discover")
data class DiscoverEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val author: String,
    val coverRes: Int,
    val category: String,
    val tags: String,
    val likesCount: Int = 120,
    val viewsCount: Int = 890,
    val isDemo: Boolean = true
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val body: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val category: String = "好友"
)
