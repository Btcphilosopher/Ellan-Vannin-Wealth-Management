package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand colors for 瞬影 (FlashSnap)
val ShunYingYellow = Color(0xFFFFFC00)
val ShunYingYellowLight = Color(0xFFFFF566)
val ShunYingYellowDark = Color(0xFFD4CE00)

val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)
val DarkCardSurface = Color(0xFF2A2A2A)

val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightCardSurface = Color(0xFFF1F3F5)

val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFFA0A0A0)

val TextPrimaryLight = Color(0xFF121212)
val TextSecondaryLight = Color(0xFF666666)

val SnapRed = Color(0xFFFF3B30)
val SnapGreen = Color(0xFF34C759)
val SnapBlue = Color(0xFF007AFF)
val SnapPurple = Color(0xFFAF52DE)
