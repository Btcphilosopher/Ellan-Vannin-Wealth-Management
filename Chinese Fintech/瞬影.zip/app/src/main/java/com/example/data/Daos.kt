package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE username = :username")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<UserEntity>)
}

@Dao
interface SnapDao {
    @Query("SELECT * FROM snaps ORDER BY createdAt DESC")
    fun getAllSnaps(): Flow<List<SnapEntity>>

    @Query("SELECT * FROM snaps WHERE recipientUsername = :username AND isExpired = 0 ORDER BY createdAt DESC")
    fun getInboxSnaps(username: String): Flow<List<SnapEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnap(snap: SnapEntity): Long

    @Query("UPDATE snaps SET isViewed = 1, viewedAt = :viewedAt WHERE id = :id")
    suspend fun markSnapViewed(id: Int, viewedAt: Long)

    @Query("UPDATE snaps SET isExpired = 1 WHERE id = :id")
    suspend fun markSnapExpired(id: Int)
}

@Dao
interface StoryDao {
    @Query("SELECT * FROM stories ORDER BY createdAt DESC")
    fun getAllStories(): Flow<List<StoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: StoryEntity)

    @Query("UPDATE stories SET isViewed = 1, viewsCount = viewsCount + 1 WHERE id = :id")
    suspend fun markStoryViewed(id: Int)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats ORDER BY lastMessageTime DESC")
    fun getAllChats(): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chat_messages WHERE chatId = :chatId ORDER BY timestamp ASC")
    fun getMessagesForChat(chatId: Int): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChat(chat: ChatEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Query("UPDATE chats SET lastMessage = :lastMsg, lastMessageTime = :time WHERE id = :chatId")
    suspend fun updateLastMessage(chatId: Int, lastMsg: String, time: Long)

    @Query("UPDATE chat_messages SET status = :status WHERE id = :messageId")
    suspend fun updateMessageStatus(messageId: Int, status: String)
}

@Dao
interface FriendDao {
    @Query("SELECT * FROM friends")
    fun getAllFriends(): Flow<List<FriendEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFriends(friends: List<FriendEntity>)

    @Query("UPDATE friends SET status = :status WHERE id = :id")
    suspend fun updateFriendStatus(id: Int, status: String)
}

@Dao
interface DiscoverDao {
    @Query("SELECT * FROM discover")
    fun getAllDiscoverContent(): Flow<List<DiscoverEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDiscoverList(list: List<DiscoverEntity>)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(list: List<NotificationEntity>)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()
}
