package com.example.data

import com.example.R
import kotlinx.coroutines.flow.Flow

class ShunYingRepository(private val db: AppDatabase) {

    val allSnaps: Flow<List<SnapEntity>> = db.snapDao().getAllSnaps()
    val allStories: Flow<List<StoryEntity>> = db.storyDao().getAllStories()
    val allChats: Flow<List<ChatEntity>> = db.chatDao().getAllChats()
    val allFriends: Flow<List<FriendEntity>> = db.friendDao().getAllFriends()
    val allDiscover: Flow<List<DiscoverEntity>> = db.discoverDao().getAllDiscoverContent()
    val allNotifications: Flow<List<NotificationEntity>> = db.notificationDao().getAllNotifications()

    fun getMessagesForChat(chatId: Int): Flow<List<ChatMessageEntity>> =
        db.chatDao().getMessagesForChat(chatId)

    suspend fun markSnapViewed(id: Int) {
        db.snapDao().markSnapViewed(id, System.currentTimeMillis())
    }

    suspend fun markSnapExpired(id: Int) {
        db.snapDao().markSnapExpired(id)
    }

    suspend fun sendSnap(snap: SnapEntity): Long {
        return db.snapDao().insertSnap(snap)
    }

    suspend fun createStory(story: StoryEntity) {
        db.storyDao().insertStory(story)
    }

    suspend fun markStoryViewed(id: Int) {
        db.storyDao().markStoryViewed(id)
    }

    suspend fun sendMessage(message: ChatMessageEntity) {
        db.chatDao().insertMessage(message)
        db.chatDao().updateLastMessage(message.chatId, message.content, message.timestamp)
    }

    suspend fun updateMessageStatus(messageId: Int, status: String) {
        db.chatDao().updateMessageStatus(messageId, status)
    }

    suspend fun markAllNotificationsRead() {
        db.notificationDao().markAllAsRead()
    }

    suspend fun updateFriendStatus(friendId: Int, newStatus: String) {
        db.friendDao().updateFriendStatus(friendId, newStatus)
    }

    suspend fun seedDemoDataIfEmpty() {
        // Seed initial users
        val existingUser = db.userDao().getUserByUsername("demo_user")
        if (existingUser == null) {
            db.userDao().insertUsers(
                listOf(
                    UserEntity("demo_user", "演示用户", R.drawable.ic_launcher_foreground, "记录此刻，分享当下。", isOnline = true, isDemo = true),
                    UserEntity("linxiaoyu", "林晓雨", R.drawable.ic_launcher_foreground, "雨后街角的咖啡香。", isOnline = true, isDemo = true),
                    UserEntity("chenmo", "陈默", R.drawable.ic_launcher_foreground, "黑白胶片与城市夜色。", isOnline = true, isDemo = true),
                    UserEntity("zhouziang", "周子昂", R.drawable.ic_launcher_foreground, "海风与夏日吉他。", isOnline = false, isDemo = true),
                    UserEntity("shenanran", "沈安然", R.drawable.ic_launcher_foreground, "发现生活中的微光。", isOnline = true, isDemo = true),
                    UserEntity("xuyan", "许言", R.drawable.ic_launcher_foreground, "夜间骑行记录。", isOnline = false, isDemo = true),
                    UserEntity("guqinghe", "顾清河", R.drawable.ic_launcher_foreground, "清澈如河，淡雅如风。", isOnline = true, isDemo = true)
                )
            )

            // Seed friends
            db.friendDao().insertFriends(
                listOf(
                    FriendEntity(1, "linxiaoyu", "林晓雨", R.drawable.ic_launcher_foreground, isOnline = true, status = "已成为好友"),
                    FriendEntity(2, "chenmo", "陈默", R.drawable.ic_launcher_foreground, isOnline = true, status = "已成为好友"),
                    FriendEntity(3, "zhouziang", "周子昂", R.drawable.ic_launcher_foreground, isOnline = false, status = "已成为好友"),
                    FriendEntity(4, "shenanran", "沈安然", R.drawable.ic_launcher_foreground, isOnline = true, status = "待处理"),
                    FriendEntity(5, "xuyan", "许言", R.drawable.ic_launcher_foreground, isOnline = false, status = "已成为好友"),
                    FriendEntity(6, "guqinghe", "顾清河", R.drawable.ic_launcher_foreground, isOnline = true, status = "待处理")
                )
            )

            // Seed Snaps
            db.snapDao().insertSnap(
                SnapEntity(
                    id = 1,
                    senderUsername = "linxiaoyu",
                    senderDisplayName = "林晓雨",
                    recipientUsername = "demo_user",
                    mediaType = "IMAGE",
                    sampleDrawableRes = R.drawable.img_demo_coffee_1789640145800,
                    filterName = "晨光",
                    overlayText = "今天的咖啡格外香醇 ☕",
                    sticker = "☕",
                    durationSeconds = 10,
                    isViewed = false,
                    isExpired = false
                )
            )

            db.snapDao().insertSnap(
                SnapEntity(
                    id = 2,
                    senderUsername = "chenmo",
                    senderDisplayName = "陈默",
                    recipientUsername = "demo_user",
                    mediaType = "IMAGE",
                    sampleDrawableRes = R.drawable.img_demo_city_1789640171239,
                    filterName = "夜间霓虹",
                    overlayText = "上海夜景真的很震撼！✨",
                    sticker = "⭐",
                    durationSeconds = 0, // View once
                    isViewed = false,
                    isExpired = false
                )
            )

            // Seed Stories
            db.storyDao().insertStory(
                StoryEntity(
                    id = 1,
                    username = "zhouziang",
                    displayName = "周子昂",
                    avatarResId = R.drawable.ic_launcher_foreground,
                    mediaDrawableRes = R.drawable.img_demo_beach_1789640158182,
                    caption = "周末去海边，感受落日余晖 🌊🌅",
                    viewsCount = 18,
                    isViewed = false
                )
            )
            db.storyDao().insertStory(
                StoryEntity(
                    id = 2,
                    username = "linxiaoyu",
                    displayName = "林晓雨",
                    avatarResId = R.drawable.ic_launcher_foreground,
                    mediaDrawableRes = R.drawable.img_demo_coffee_1789640145800,
                    caption = "今天的咖啡店放着爵士乐 🎵",
                    viewsCount = 32,
                    isViewed = false
                )
            )
            db.storyDao().insertStory(
                StoryEntity(
                    id = 3,
                    username = "chenmo",
                    displayName = "陈默",
                    avatarResId = R.drawable.ic_launcher_foreground,
                    mediaDrawableRes = R.drawable.img_demo_city_1789640171239,
                    caption = "城市黄昏，霓虹初上 ✨",
                    viewsCount = 45,
                    isViewed = false
                )
            )

            // Seed Chats
            val chatId1 = db.chatDao().insertChat(
                ChatEntity(
                    id = 1,
                    peerUsername = "linxiaoyu",
                    peerDisplayName = "林晓雨",
                    peerAvatarResId = R.drawable.ic_launcher_foreground,
                    lastMessage = "这个滤镜特别适合今天的天气。",
                    unreadCount = 1
                )
            ).toInt()

            val chatId2 = db.chatDao().insertChat(
                ChatEntity(
                    id = 2,
                    peerUsername = "chenmo",
                    peerDisplayName = "陈默",
                    peerAvatarResId = R.drawable.ic_launcher_foreground,
                    lastMessage = "刚刚拍到一张很有意思的照片。",
                    unreadCount = 0
                )
            ).toInt()

            // Seed Chat Messages
            db.chatDao().insertMessage(
                ChatMessageEntity(
                    chatId = chatId1,
                    senderUsername = "linxiaoyu",
                    senderDisplayName = "林晓雨",
                    content = "今晚要不要一起看电影？",
                    status = "已读"
                )
            )
            db.chatDao().insertMessage(
                ChatMessageEntity(
                    chatId = chatId1,
                    senderUsername = "linxiaoyu",
                    senderDisplayName = "林晓雨",
                    content = "这个滤镜特别适合今天的天气。",
                    status = "已送达"
                )
            )
            db.chatDao().insertMessage(
                ChatMessageEntity(
                    chatId = chatId2,
                    senderUsername = "chenmo",
                    senderDisplayName = "陈默",
                    content = "刚刚拍到一张很有意思的照片。",
                    status = "已读"
                )
            )

            // Seed Discover Content
            db.discoverDao().insertDiscoverList(
                listOf(
                    DiscoverEntity(1, "伦敦街角摄影", "林晓雨", R.drawable.img_demo_coffee_1789640145800, "摄影", "旅行,摄影,街道", 320, 1500),
                    DiscoverEntity(2, "上海清晨记录", "陈默", R.drawable.img_demo_city_1789640171239, "城市生活", "上海,晨景,纪实", 450, 2100),
                    DiscoverEntity(3, "成都咖啡地图", "沈安然", R.drawable.img_demo_coffee_1789640145800, "美食", "咖啡,成都,打卡", 280, 1800),
                    DiscoverEntity(4, "杭州湖边散步", "周子昂", R.drawable.img_demo_beach_1789640158182, "旅行", "西湖,散步,风光", 510, 3100),
                    DiscoverEntity(5, "北京夜色巡游", "许言", R.drawable.img_demo_city_1789640171239, "夜景", "北京,骑行,夜拍", 390, 2400),
                    DiscoverEntity(6, "广州街头音乐集", "顾清河", R.drawable.img_demo_beach_1789640158182, "音乐", "吉他,街头,现场", 620, 4200)
                )
            )

            // Seed Notifications
            db.notificationDao().insertNotifications(
                listOf(
                    NotificationEntity(1, "新的好友请求", "沈安然 向你发送了好友请求", isRead = false, category = "好友"),
                    NotificationEntity(2, "收到新瞬拍", "林晓雨 给你发送了一张短时限照片", isRead = false, category = "瞬拍"),
                    NotificationEntity(3, "故事被回复", "陈默 回复了你的故事：太美了！", isRead = true, category = "故事"),
                    NotificationEntity(4, "安全提醒", "你的账号在本地演示设备成功登录", isRead = true, category = "系统")
                )
            )
        }
    }
}
