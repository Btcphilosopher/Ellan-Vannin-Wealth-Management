package com.example.ui.pages

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.locales.ZhCnText
import com.example.viewmodel.ShunYingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ShunYingViewModel,
    onNavigateBack: () -> Unit
) {
    val isLocationSharing by viewModel.isLocationSharingEnabled.collectAsState()
    val isPrivateAccount by viewModel.isPrivateAccount.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val isReducedMotion by viewModel.isReducedMotion.collectAsState()

    var showDeleteAccountModal by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(ZhCnText.SETTINGS_TITLE, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text("隐私与安全设置", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    SettingToggleRow(
                        title = "精确地理位置共享",
                        subtitle = "默认关闭，保护你的实地定位隐私",
                        checked = isLocationSharing,
                        onCheckedChange = { viewModel.isLocationSharingEnabled.value = it }
                    )
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    SettingToggleRow(
                        title = "私密账号模式",
                        subtitle = "开启后仅受信任的已验证好友可向你发送瞬拍",
                        checked = isPrivateAccount,
                        onCheckedChange = { viewModel.isPrivateAccount.value = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("界面与无障碍", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    SettingToggleRow(
                        title = "深色沉浸主题",
                        subtitle = "夜间拍摄与视觉浏览体验最佳",
                        checked = isDarkMode,
                        onCheckedChange = { viewModel.isDarkMode.value = it }
                    )
                    Divider(modifier = Modifier.padding(vertical = 8.dp))
                    SettingToggleRow(
                        title = "减少动态效果",
                        subtitle = "降低过渡动画，提升视障及低性能设备流畅度",
                        checked = isReducedMotion,
                        onCheckedChange = { viewModel.isReducedMotion.value = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("已登录设备终端", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Devices, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("本地 Android 演示环境", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("当前活动设备 • IP 127.0.0.1", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("在线", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            OutlinedButton(
                onClick = { showDeleteAccountModal = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("注销并清除账号本地数据", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showDeleteAccountModal) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountModal = false },
            title = { Text("确认注销账号？") },
            text = { Text("此操作将完全注销该本地演示账号，并彻底清空所有瞬拍、故事及聊天历史记录。") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAccountModal = false
                        viewModel.logout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("彻底清除", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAccountModal = false }) {
                    Text("取消")
                }
            }
        )
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
