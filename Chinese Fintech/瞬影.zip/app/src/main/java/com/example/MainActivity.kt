package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.components.ShunYingBottomNav
import com.example.ui.components.SnapViewerDialog
import com.example.ui.pages.*
import com.example.ui.theme.ShunYingTheme
import com.example.viewmodel.ShunYingViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ShunYingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()
            val isLoggedIn by viewModel.isLoggedIn.collectAsState()
            val currentTab by viewModel.currentTab.collectAsState()

            ShunYingTheme(darkTheme = isDarkMode) {
                if (!isLoggedIn) {
                    if (currentTab == "REGISTER") {
                        RegisterScreen(
                            viewModel = viewModel,
                            onNavigateBack = { viewModel.logout() }
                        )
                    } else {
                        LoginScreen(
                            viewModel = viewModel,
                            onNavigateToRegister = { viewModel.setTab("REGISTER") }
                        )
                    }
                } else {
                    MainAppScaffold(
                        viewModel = viewModel,
                        currentTab = currentTab
                    )
                }
            }
        }
    }
}

@Composable
fun MainAppScaffold(
    viewModel: ShunYingViewModel,
    currentTab: String
) {
    val showBottomBar = currentTab in listOf("HOME", "STORIES", "CHAT", "DISCOVER")

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                ShunYingBottomNav(
                    currentTab = currentTab,
                    onTabSelected = { viewModel.setTab(it) }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentTab) {
                "HOME" -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToCamera = { viewModel.setTab("CAMERA") },
                    onNavigateToProfile = { viewModel.setTab("PROFILE") },
                    onNavigateToNotifications = { viewModel.setTab("NOTIFICATIONS") }
                )
                "CAMERA" -> CameraScreen(
                    viewModel = viewModel,
                    onNavigateHome = { viewModel.setTab("HOME") }
                )
                "STORIES" -> StoriesScreen(
                    viewModel = viewModel,
                    onNavigateToCamera = { viewModel.setTab("CAMERA") }
                )
                "CHAT" -> ChatScreen(
                    viewModel = viewModel,
                    onNavigateToCamera = { viewModel.setTab("CAMERA") }
                )
                "CHAT_DETAIL" -> ChatDetailScreen(
                    viewModel = viewModel
                )
                "DISCOVER" -> DiscoverScreen(
                    viewModel = viewModel
                )
                "PROFILE" -> ProfileScreen(
                    viewModel = viewModel,
                    onNavigateToSettings = { viewModel.setTab("SETTINGS") },
                    onNavigateToFriends = { viewModel.setTab("FRIENDS") }
                )
                "SETTINGS" -> SettingsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.setTab("PROFILE") }
                )
                "NOTIFICATIONS" -> NotificationsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.setTab("HOME") }
                )
                "FRIENDS" -> FriendsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.setTab("PROFILE") }
                )
                else -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToCamera = { viewModel.setTab("CAMERA") },
                    onNavigateToProfile = { viewModel.setTab("PROFILE") },
                    onNavigateToNotifications = { viewModel.setTab("NOTIFICATIONS") }
                )
            }

            // Global Fullscreen Snap Countdown Viewer Modal
            SnapViewerDialog(viewModel = viewModel)
        }
    }
}
