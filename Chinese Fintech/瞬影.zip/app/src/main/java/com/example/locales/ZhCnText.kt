package com.example.locales

object ZhCnText {
    const val APP_NAME = "瞬影"
    const val APP_SLOGAN = "此刻，值得被看见。"
    const val APP_SUBTITLE = "记录此刻，分享当下。"
    const val LOG_IN = "登录"
    const val REGISTER = "注册新账号"
    const val DEMO_LOGIN = "使用演示账号一键登录"
    const val DEMO_USER_LABEL = "演示账号：演示用户 (密码: demo123456)"
    const val DEMO_NOTICE = "提示：这是本地演示账号，不对应真实用户。"
    const val USERNAME = "用户名 / 手机号"
    const val PASSWORD = "密码"
    const val FORGOT_PASSWORD = "忘记密码？"
    const val PRIVACY_POLICY = "隐私政策"
    const val USER_AGREEMENT = "用户协议"
    
    // Bottom Nav
    const val NAV_HOME = "首页"
    const val NAV_CAMERA = "相机"
    const val NAV_STORIES = "故事"
    const val NAV_CHAT = "聊天"
    const val NAV_DISCOVER = "发现"
    
    // Top Bar & Home
    const val SEARCH_HINT = "搜索好友、故事或发现内容..."
    const val NOTIFICATIONS = "通知"
    const val EMPTY_HOME_TITLE = "这里暂时没有新的动态。"
    const val EMPTY_HOME_SUB = "去记录一个属于你的瞬间吧。"
    const val ONLINE_FRIENDS = "在线好友"
    const val UNREAD_SNAPS = "未读瞬拍"
    const val RECENT_STORIES = "近期故事"
    
    // Camera & Editor
    const val CAMERA_TITLE = "记录此刻"
    const val TAKE_PHOTO = "拍照"
    const val RECORD_VIDEO = "录像"
    const val SWITCH_CAMERA = "切换镜头"
    const val FLASH_TOGGLE = "闪光灯"
    const val PICK_DEMO_MEDIA = "选择演示素材"
    const val FILTERS = "滤镜"
    const val STICKERS = "贴纸"
    const val ADD_TEXT = "添加文字"
    const val AR_EFFECTS = "AR特效"
    const val SAVE_LOCAL = "保存至演示相册"
    const val SEND_TO_FRIEND = "发送给好友"
    const val PUBLISH_TO_STORY = "发布到故事"
    const val TIMER_SETTING = "设置查看时长"
    
    // Snap Expiration
    const val SNAP_VIEW_ONCE = "查看后立即销毁"
    const val SNAP_VIEW_10S = "查看后10秒过期"
    const val SNAP_VIEW_1H = "1小时后过期"
    const val SNAP_VIEW_24H = "24小时后过期"
    const val SNAP_EXPIRED_TITLE = "内容已过期"
    const val SNAP_EXPIRED_MSG = "该瞬拍已超过指定查看时长，已自动隐藏。"
    const val SNAP_NOTICE_DISCLAIMER = "该内容将在指定时间后从应用界面中隐藏。"
    
    // Status
    const val STATUS_SENDING = "发送中"
    const val STATUS_SENT = "已发送"
    const val STATUS_DELIVERED = "已送达"
    const val STATUS_READ = "已读"
    const val STATUS_EXPIRED = "已过期"
    const val STATUS_FAILED = "发送失败"
    
    // Camera Permission Error
    const val CAMERA_PERMISSION_ERROR = "无法访问摄像头。\n请检查浏览器/应用权限设置，或者使用演示素材继续体验。"
    
    // Chat
    const val CHAT_INPUT_HINT = "发送中文消息或瞬拍..."
    const val CHAT_TAB_ALL = "全部"
    const val CHAT_TAB_UNREAD = "未读"
    const val CHAT_TAB_FRIENDS = "好友"
    const val CHAT_TAB_GROUP = "群聊"
    
    // Friends
    const val ADD_FRIEND = "添加好友"
    const val MY_QR_CODE = "我的演示二维码"
    const val FRIEND_REQUESTS = "好友请求"
    const val BLOCK_USER = "拉黑用户"
    const val FRIEND_STATUS_ACCEPTED = "已成为好友"
    const val FRIEND_STATUS_PENDING = "待处理"
    
    // Discover
    const val RECOMMENDATION_REASON_TITLE = "为什么看到这条内容？"
    const val RECOMMENDATION_REASON_MSG = "因为你关注了该热门话题，且内容新鲜度较高。"
    const val REPORT_CONTENT = "举报内容"
    const val REPORT_SUCCESS = "举报已提交，等待审核人员处理。"
    
    // Profile & Settings
    const val PROFILE_TITLE = "个人主页"
    const val EDIT_PROFILE = "编辑资料"
    const val SETTINGS_TITLE = "设置"
    const val PRIVACY_SETTINGS = "隐私与安全设置"
    const val DEVICE_SESSIONS = "登录设备管理"
    const val ACCESSIBILITY = "无障碍辅助"
    const val LOG_OUT = "退出登录"
    const val DEMO_FLAG = "虚构演示数据"
}
