package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ShunYingYellow,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF333300),
    onPrimaryContainer = ShunYingYellowLight,
    secondary = SnapBlue,
    onSecondary = Color.White,
    tertiary = SnapPurple,
    background = DarkBackground,
    onBackground = TextPrimaryDark,
    surface = DarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = DarkCardSurface,
    onSurfaceVariant = TextSecondaryDark,
    error = SnapRed
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFFE5E000),
    onPrimary = Color.Black,
    primaryContainer = Color(0xFFFFF9B3),
    onPrimaryContainer = Color.Black,
    secondary = SnapBlue,
    onSecondary = Color.White,
    tertiary = SnapPurple,
    background = LightBackground,
    onBackground = TextPrimaryLight,
    surface = LightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = LightCardSurface,
    onSurfaceVariant = TextSecondaryLight,
    error = SnapRed
)

@Composable
fun ShunYingTheme(
    darkTheme: Boolean = true, // Default to sleek dark mode for camera/social experience
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
