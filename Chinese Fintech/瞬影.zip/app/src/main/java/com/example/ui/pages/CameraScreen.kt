package com.example.ui.pages

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.locales.ZhCnText
import com.example.viewmodel.ShunYingViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraScreen(
    viewModel: ShunYingViewModel,
    onNavigateHome: () -> Unit
) {
    val editorState by viewModel.editorState.collectAsState()
    val friends by viewModel.friends.collectAsState()

    var activeTool by remember { mutableStateOf<String?>(null) } // "FILTERS", "AR", "TEXT", "STICKERS", "TIMER", "SEND"
    var textInput by remember { mutableStateOf(editorState.overlayText) }
    var showSendSuccessDialog by remember { mutableStateOf(false) }
    var sendSuccessMsg by remember { mutableStateOf("") }

    val sampleAssets = listOf(
        Pair("咖啡店", R.drawable.img_demo_coffee_1789640145800),
        Pair("海边夕阳", R.drawable.img_demo_beach_1789640158182),
        Pair("城市夜景", R.drawable.img_demo_city_1789640171239)
    )

    val filters = listOf("原图", "晨光", "胶片日记", "城市灰阶", "暖色旅行", "夜间霓虹", "旧相册", "清透蓝调", "柔和人像")
    val arEffects = listOf("无", "👓 虚拟眼镜", "🐰 动态兔耳", "✨ 彩色光效", "🎭 炫彩面具")
    val stickers = listOf("😊", "⭐", "❤️", "☀️", "☁️", "☕", "🎵", "✈️", "🎂")
    val timers = listOf(
        Pair("查看后即销毁", 0),
        Pair("10秒后过期", 10),
        Pair("1小时后过期", 3600),
        Pair("24小时后过期", 86400)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Main Viewfinder Preview Media
        Image(
            painter = painterResource(id = editorState.selectedSampleRes),
            contentDescription = "相机实时预览/演示素材",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // AR Effect / Text / Sticker Overlays
        if (editorState.selectedArEffect != "无" || editorState.overlayText.isNotBlank() || editorState.selectedSticker.isNotBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
                    .background(Color.Black.copy(alpha = 0.4f))
                    .padding(vertical = 12.dp, horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (editorState.selectedArEffect != "无") {
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "AR特效: ${editorState.selectedArEffect}",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (editorState.selectedSticker.isNotBlank()) {
                            Text(editorState.selectedSticker, fontSize = 28.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        if (editorState.overlayText.isNotBlank()) {
                            Text(
                                text = editorState.overlayText,
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Top Toolbar (Header, Asset Selector, Flash Toggle, Permission Notice Info)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 36.dp, start = 16.dp, end = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateHome) {
                    Icon(Icons.Filled.Close, contentDescription = "关闭", tint = Color.White)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Text("滤镜: ${editorState.selectedFilter}", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Sample Asset Selector Row
            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text("切换演示素材：", color = Color.LightGray, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(sampleAssets) { asset ->
                            Surface(
                                color = if (editorState.selectedSampleRes == asset.second) MaterialTheme.colorScheme.primary else Color.DarkGray,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.clickable { viewModel.setEditorSampleRes(asset.second) }
                            ) {
                                Text(
                                    text = asset.first,
                                    color = if (editorState.selectedSampleRes == asset.second) Color.Black else Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Right Side Toolbar (Editing Tools)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SideToolIcon(
                icon = Icons.Filled.ColorLens,
                label = "滤镜",
                active = activeTool == "FILTERS",
                onClick = { activeTool = if (activeTool == "FILTERS") null else "FILTERS" }
            )

            SideToolIcon(
                icon = Icons.Filled.Face,
                label = "AR特效",
                active = activeTool == "AR",
                onClick = { activeTool = if (activeTool == "AR") null else "AR" }
            )

            SideToolIcon(
                icon = Icons.Filled.TextFields,
                label = "文字",
                active = activeTool == "TEXT",
                onClick = { activeTool = if (activeTool == "TEXT") null else "TEXT" }
            )

            SideToolIcon(
                icon = Icons.Filled.SentimentSatisfied,
                label = "贴纸",
                active = activeTool == "STICKERS",
                onClick = { activeTool = if (activeTool == "STICKERS") null else "STICKERS" }
            )

            SideToolIcon(
                icon = Icons.Filled.Timer,
                label = editorState.selectedTimerLabel,
                active = activeTool == "TIMER",
                onClick = { activeTool = if (activeTool == "TIMER") null else "TIMER" }
            )
        }

        // Sub-Tool options drawer (Filters / AR / Text / Sticker / Timer)
        if (activeTool != null) {
            Surface(
                color = Color.Black.copy(alpha = 0.85f),
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 120.dp, start = 16.dp, end = 16.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    when (activeTool) {
                        "FILTERS" -> {
                            Text("选择滤镜效果：", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(filters) { f ->
                                    FilterPill(
                                        name = f,
                                        selected = editorState.selectedFilter == f,
                                        onClick = { viewModel.setEditorFilter(f) }
                                    )
                                }
                            }
                        }
                        "AR" -> {
                            Text("演示级 AR 互动效果：", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(arEffects) { ar ->
                                    FilterPill(
                                        name = ar,
                                        selected = editorState.selectedArEffect == ar,
                                        onClick = { viewModel.setEditorArEffect(ar) }
                                    )
                                }
                            }
                        }
                        "TEXT" -> {
                            Text("添加个性文字：", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = textInput,
                                    onValueChange = { textInput = it },
                                    placeholder = { Text("输入你想说的话...", color = Color.Gray) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = Color.Gray,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        viewModel.setEditorOverlayText(textInput)
                                        activeTool = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text("确定", color = Color.Black)
                                }
                            }
                        }
                        "STICKERS" -> {
                            Text("添加趣味贴纸：", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(stickers) { st ->
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(if (editorState.selectedSticker == st) MaterialTheme.colorScheme.primary else Color.DarkGray)
                                            .clickable { viewModel.setEditorSticker(if (editorState.selectedSticker == st) "" else st) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(st, fontSize = 22.sp)
                                    }
                                }
                            }
                        }
                        "TIMER" -> {
                            Text("设置查看有效时长：", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(timers) { tm ->
                                    FilterPill(
                                        name = tm.first,
                                        selected = editorState.selectedTimerLabel == tm.first,
                                        onClick = { viewModel.setEditorTimer(tm.first, tm.second) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Primary Actions (Send to Friend / Publish Story)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp, start = 20.dp, end = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = {
                    viewModel.publishCurrentAsStory {
                        sendSuccessMsg = "已成功发布到你的24小时故事广场！"
                        showSendSuccessDialog = true
                    }
                },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.testTag("btn_publish_story")
            ) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("发布故事", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { activeTool = "SEND" },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.testTag("btn_send_snap")
            ) {
                Text("发送瞬拍", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.Filled.Send, contentDescription = null, tint = Color.Black)
            }
        }
    }

    // Recipient Selection Modal
    if (activeTool == "SEND") {
        AlertDialog(
            onDismissRequest = { activeTool = null },
            title = { Text("选择接收好友") },
            text = {
                Column {
                    Text("发送该短时限瞬拍给：", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    friends.forEach { friend ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.setEditorRecipient(friend.username) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(friend.displayName, fontWeight = FontWeight.Bold)
                            RadioButton(
                                selected = editorState.selectedRecipientUsername == friend.username,
                                onClick = { viewModel.setEditorRecipient(friend.username) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        activeTool = null
                        viewModel.sendCurrentSnap {
                            sendSuccessMsg = "瞬拍已发送给 ${editorState.selectedRecipientUsername}！"
                            showSendSuccessDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("确认发送", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { activeTool = null }) {
                    Text("取消")
                }
            }
        )
    }

    if (showSendSuccessDialog) {
        AlertDialog(
            onDismissRequest = {
                showSendSuccessDialog = false
                onNavigateHome()
            },
            title = { Text("发送成功 🎉") },
            text = { Text(sendSuccessMsg) },
            confirmButton = {
                Button(
                    onClick = {
                        showSendSuccessDialog = false
                        onNavigateHome()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("返回首页", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun SideToolIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(if (active) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.6f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = if (active) Color.Black else Color.White)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(label, color = Color.White, fontSize = 10.sp)
    }
}

@Composable
private fun FilterPill(name: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primary else Color.DarkGray,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = name,
            color = if (selected) Color.Black else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}
