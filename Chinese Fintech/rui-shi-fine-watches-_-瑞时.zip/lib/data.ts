import { WatchItem } from '@/types/watch';

export const WATCHES: WatchItem[] = [
  {
    id: 'rsi-classic-01',
    name: 'Rui Shi Classic Obsidian',
    chineseName: '瑞时 经典曜石',
    category: 'classic',
    tagline: 'Timeless elegance',
    chineseTagline: '永恒优雅 曜石墨韵',
    priceUSD: 18500,
    priceRMB: 128000,
    image: '/images/watch_classic_dial_1791201206582.jpg',
    description: 'Ultra-slim dress timepiece featuring a deep obsidian black lacquer dial with hand-applied 18K rose gold hour indices and polished leaf hands. Powered by Calibre RS-1928 manual-wound manufacture movement.',
    chineseDescription: '超薄正装腕表，配以深邃曜石黑漆表盘，镶嵌手工18K玫瑰金时标与金质柳叶针。搭载RS-1928自产手动上链机芯。',
    specs: {
      caseDiameter: '39.5 mm',
      caseThickness: '7.8 mm',
      caseMaterial: '18K Rose Gold',
      movement: 'Manual-wind Manufacture Calibre RS-1928',
      caliber: 'Calibre RS-1928',
      powerReserve: '72 Hours',
      frequency: '28,800 vph (4 Hz)',
      jewels: 28,
      waterResistance: '30 Meters (3 ATM)',
      dialFinish: 'Deep Obsidian Black Lacquer',
      strap: 'Hand-stitched Mississippiensis Alligator Leather',
    },
    inStock: true,
    featured: true,
  },
  {
    id: 'rsi-heritage-02',
    name: 'Rui Shi Heritage Porcelain',
    chineseName: '瑞时 传承白瓷',
    category: 'heritage',
    tagline: 'Inspired by tradition',
    chineseTagline: '典藏印记 白瓷青针',
    priceUSD: 24800,
    priceRMB: 168000,
    image: '/images/watch_heritage_dial_1791201220276.jpg',
    description: 'High-fire Grand Feu white enamel dial bearing a subtle red vermilion seal stamp at 6 o’clock and flame-blued tempered steel hands. Inspired by Song Dynasty aesthetic minimalism.',
    chineseDescription: '大火高温烧制白瓷珐琅表盘，六点位刻印瑞时朱砂红印章，搭配高温淬火烤蓝钢针，呈现宋代极简审美之美。',
    specs: {
      caseDiameter: '40.0 mm',
      caseThickness: '9.2 mm',
      caseMaterial: '950 Platinum',
      movement: 'Automatic Calibre RS-8800 with 22K Gold Rotor',
      caliber: 'Calibre RS-8800',
      powerReserve: '65 Hours',
      frequency: '28,800 vph (4 Hz)',
      jewels: 32,
      waterResistance: '50 Meters (5 ATM)',
      dialFinish: 'Grand Feu White Porcelain Enamel',
      strap: 'Navy Blue Alligator with Platinum Folding Clasp',
    },
    inStock: true,
    featured: true,
  },
  {
    id: 'rsi-sport-03',
    name: 'Rui Shi Sport Emerald',
    chineseName: '瑞时 尚品翠绿',
    category: 'sport',
    tagline: 'Built for adventure',
    chineseTagline: '纵横山海 翡翠日照',
    priceUSD: 16200,
    priceRMB: 112000,
    image: '/images/watch_sport_dial_1791201231195.jpg',
    description: 'High-performance mechanical luxury sport watch featuring a vibrant emerald green sunburst dial, satin-brushed stainless steel case, integrated steel bracelet, and screw-down crown.',
    chineseDescription: '高性能机械奢华运动表，配以浓郁翡翠绿太阳纹表盘、缎面打磨不锈钢表壳与一体式拉丝钢带，具有卓越抗震与防水性能。',
    specs: {
      caseDiameter: '41.0 mm',
      caseThickness: '11.5 mm',
      caseMaterial: 'Grade 316L Stainless Steel',
      movement: 'Self-winding Chronometer Calibre RS-500',
      caliber: 'Calibre RS-500',
      powerReserve: '55 Hours',
      frequency: '28,800 vph (4 Hz)',
      jewels: 26,
      waterResistance: '150 Meters (15 ATM)',
      dialFinish: 'Emerald Green Sunburst with Super-LumiNova',
      strap: 'Integrated Stainless Steel & Interchangeable Rubber Strap',
    },
    inStock: true,
    featured: true,
  },
  {
    id: 'rsi-masters-04',
    name: 'Rui Shi Masters Tourbillon',
    chineseName: '瑞时 大师飞轮',
    category: 'masters',
    tagline: 'The pinnacle of craft',
    chineseTagline: '巅峰之作 陀飞轮韵',
    priceUSD: 85000,
    priceRMB: 580000,
    image: '/images/watch_masters_tourbillon_1791201242458.jpg',
    description: 'Grand complication timepiece showcasing a one-minute Flying Tourbillon cage at 6 o’clock, hand-skeletonized bridges decorated with traditional Chinese landscape guilloché engraving.',
    chineseDescription: '高级复杂功能巅峰之作，6点钟位置设一分钟飞行陀飞轮夹板，全手工镂空机芯雕刻山水纹样，展现传世机械匠艺。',
    specs: {
      caseDiameter: '42.0 mm',
      caseThickness: '10.8 mm',
      caseMaterial: '18K Rose Gold & Platinum Trim',
      movement: 'Hand-wound Flying Tourbillon Calibre RS-TOURB-01',
      caliber: 'Calibre RS-TOURB-01',
      powerReserve: '80 Hours Twin-Barrel',
      frequency: '21,600 vph (3 Hz)',
      jewels: 38,
      waterResistance: '30 Meters (3 ATM)',
      dialFinish: 'Skeletonized 18K Gold Bridge with Landscape Engraving',
      strap: 'Hand-stitched Matte Black Alligator',
    },
    inStock: true,
    featured: true,
  },
  {
    id: 'rsi-shanshui-05',
    name: 'Rui Shi Shanshui Solitude',
    chineseName: '瑞时 山水隐世',
    category: 'heritage',
    tagline: 'Ink landscape painting on wrist',
    chineseTagline: '水墨丹青 方寸山河',
    priceUSD: 32000,
    priceRMB: 220000,
    image: '/images/hero_rui_shi_watch_1791201179449.jpg',
    description: 'Hand-painted miniature enamel dial recreating classical Chinese ink-wash landscape paintings. Each dial is a unique 1-of-1 original artwork crafted by Master Enamellers.',
    chineseDescription: '微绘珐琅大师纯手工将古典水墨山水画绘制于表盘之上，每一块表盘皆为独一无二的微型艺术杰作。',
    specs: {
      caseDiameter: '40.5 mm',
      caseThickness: '8.9 mm',
      caseMaterial: '18K Rose Gold',
      movement: 'Automatic Ultra-Thin Calibre RS-9100',
      caliber: 'Calibre RS-9100',
      powerReserve: '60 Hours',
      frequency: '28,800 vph (4 Hz)',
      jewels: 30,
      waterResistance: '30 Meters (3 ATM)',
      dialFinish: 'Hand-Painted Miniature Shanshui Enamel',
      strap: 'Burgundy Alligator Leather Strap',
    },
    inStock: true,
  },
];

export interface JournalArticle {
  id: string;
  title: string;
  chineseTitle: string;
  subtitle: string;
  chineseSubtitle: string;
  date: string;
  readTime: string;
  image: string;
  content: string[];
  chineseContent: string[];
}

export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    id: 'art-of-shanshui-dials',
    title: 'The Art of Miniature Shanshui Enamel Dials',
    chineseTitle: '方寸之间的水墨奇迹：微绘珐琅山水表盘',
    subtitle: 'How Master Artisans Paint Timeless Chinese Landscapes on a 30mm Enamel Canvas',
    chineseSubtitle: '探索大师如何在30毫米的表盘画布上临摹千载山河',
    date: 'October 2026',
    readTime: '6 min read',
    image: '/images/hero_rui_shi_watch_1791201179449.jpg',
    content: [
      'In the quiet ateliers of Rui Shi, time is not merely measured by gears and escapements; it is captured through the fluid motion of a sable hair brush fine enough to hold a single drop of enamel pigment.',
      'To recreate the atmospheric depth of Song Dynasty landscape paintings (Shanshui), master enamellers apply up to sixteen layers of mineral oxides. Each layer is fired in a kiln at temperatures exceeding 800°C.',
      'A single mistake during firing can rupture the delicate porcelain enamel, destroying weeks of painstaking handiwork. Only 1 in 5 completed dials meets the exacting standard required to bear the red Rui Shi seal.',
    ],
    chineseContent: [
      '在瑞时的静谧工坊中，时间不仅靠齿轮与擒纵机构来度量，更通过比头发丝还要细微的貂毛画笔凝聚在表盘之上。',
      '为了重现宋代山水画的苍润意境，珐琅大师需涂抹多达十六层天然矿物颜料。每涂抹一层，都必须置于800℃以上的高温窑炉中进行一次烘烤。',
      '在淬火过程中，稍有差池便会导致脆弱的瓷表盘开裂，数周的苦心心血化为乌有。最终仅有五分之一的表盘能够通过极苛严的检验，盖上瑞时朱红印章。',
    ],
  },
  {
    id: 'precision-tourbillon-craft',
    title: 'Precision & Poetics: The Rui Shi Flying Tourbillon',
    chineseTitle: '精密与诗意：瑞时飞行陀飞轮的律动',
    subtitle: 'Countering Gravity with 0.12 Grams of Hand-Polished Titanium',
    chineseSubtitle: '以0.12克手工抛光钛金属抵消重力之偏差',
    date: 'September 2026',
    readTime: '8 min read',
    image: '/images/heritage_craftsman_atelier_1791201193360.jpg',
    content: [
      'The tourbillon remains one of horology’s most poetic complications. By rotating the balance wheel and balance spring through 360 degrees every 60 seconds, it cancels out the positional errors caused by Earth’s gravitational force.',
      'At Rui Shi, our watchmakers have re-engineered the tourbillon cage to weigh a mere 0.12 grams, utilizing high-grade titanium bridges finished with hand-beveled chamfers (Anglage).',
      'The result is a mesmerizing mechanical ballet that dances like wind moving over bamboo groves, reflecting a century of Swiss-inspired engineering matched with Chinese philosophical restraint.',
    ],
    chineseContent: [
      '陀飞轮历来是钟表艺术中最具诗意的复杂功能之一。通过让摆轮与游丝在每60秒内旋转360度，它能抵消地球重力对机械走时造成的位移误差。',
      '在瑞时工坊，钟表师们重新设计了飞行陀飞轮框架，采用高级钛金夹板并经全手工倒角打磨，总重量仅为0.12克。',
      '其运转犹如清风拂过竹林，律动自如，完美融合了百载瑞士精密工艺与东方哲学沉静含蓄之美。',
    ],
  },
];

export interface BoutiqueLocation {
  city: string;
  chineseCity: string;
  name: string;
  address: string;
  phone: string;
  image: string;
}

export const BOUTIQUES: BoutiqueLocation[] = [
  {
    city: 'Shanghai',
    chineseCity: '上海',
    name: 'Rui Shi Flagship House - The Bund',
    address: 'No. 18 Zhongshan East 1st Road, Huangpu District, Shanghai',
    phone: '+86 21 6328 8888',
    image: '/images/watch_masters_tourbillon_1791201242458.jpg',
  },
  {
    city: 'Geneva',
    chineseCity: '日内瓦',
    name: 'Rui Shi Salon - Rue du Rhône',
    address: 'Rue du Rhône 42, 1204 Genève, Switzerland',
    phone: '+41 22 819 9000',
    image: '/images/watch_heritage_dial_1791201220276.jpg',
  },
  {
    city: 'London',
    chineseCity: '伦敦',
    name: 'Rui Shi Boutique - Mayfair',
    address: '28 New Bond Street, Mayfair, London W1S 2RH, UK',
    phone: '+44 20 7493 1888',
    image: '/images/watch_classic_dial_1791201206582.jpg',
  },
  {
    city: 'Tokyo',
    chineseCity: '东京',
    name: 'Rui Shi Atelier - Ginza',
    address: '6-8-7 Ginza, Chuo-ku, Tokyo 104-0061, Japan',
    phone: '+81 3 3571 8888',
    image: '/images/watch_sport_dial_1791201231195.jpg',
  },
];
