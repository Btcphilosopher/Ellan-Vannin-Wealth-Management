'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, Volume2, VolumeX, Eye } from 'lucide-react';
import { Language, WatchItem } from '@/types/watch';

interface HeroSectionProps {
  lang: Language;
  heroWatch: WatchItem;
  onExploreCollections: () => void;
  onSelectWatch: (watch: WatchItem) => void;
}

export default function HeroSection({
  lang,
  heroWatch,
  onExploreCollections,
  onSelectWatch,
}: HeroSectionProps) {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const toggleMechanicalTickSound = () => {
    setIsPlayingAudio(!isPlayingAudio);
    if (!isPlayingAudio) {
      // Simulate luxury mechanical caliber audio tick
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const playTick = (delay: number) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(1200, audioCtx.currentTime + delay);
        osc.frequency.exponentialRampToValueAtTime(300, audioCtx.currentTime + delay + 0.02);
        gain.gain.setValueAtTime(0.08, audioCtx.currentTime + delay);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + delay + 0.02);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(audioCtx.currentTime + delay);
        osc.stop(audioCtx.currentTime + delay + 0.025);
      };

      // 4 Hz = 8 ticks per second
      for (let i = 0; i < 16; i++) {
        playTick(i * 0.125);
      }
      setTimeout(() => setIsPlayingAudio(false), 2200);
    }
  };

  return (
    <section id="hero" className="relative min-h-[85vh] lg:min-h-[92vh] flex items-center overflow-hidden bg-[#0a0a0c]">
      {/* Background Hero Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero_rui_shi_watch_1791201179449.jpg"
          alt="Rui Shi Fine Mechanical Watch - Time in Harmony with Nature"
          fill
          priority
          className="object-cover object-center opacity-85 scale-105 transition-transform duration-10000 ease-linear hover:scale-100"
          referrerPolicy="no-referrer"
        />
        {/* Subtle Dark Vignette & Gradient Overlays for Readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0c]/90 via-[#0a0a0c]/50 to-transparent w-full md:w-3/5" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0c] via-transparent to-[#0a0a0c]/40" />
      </div>

      {/* Main Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-16 md:py-24 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        
        {/* Left Column - Headline & Content */}
        <div className="md:col-span-7 space-y-6">
          <div className="space-y-2">
            <h1 className="font-cinzel text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-normal tracking-wider leading-[1.15] text-[#f8f8fa]">
              {lang === 'zh' ? (
                <>
                  天人合一 <br /> 方寸与自然共时
                </>
              ) : (
                <>
                  TIME <br /> IN HARMONY <br /> WITH NATURE
                </>
              )}
            </h1>

            <p className="font-chinese text-lg sm:text-xl md:text-2xl font-light text-[#c5a059] tracking-widest pt-1">
              与自然共时
            </p>
          </div>

          <p className="text-sm sm:text-base text-[#b5b5bc] font-light leading-relaxed max-w-xl">
            {lang === 'zh'
              ? '灵感源自中国千年壮美山川，融入现代制表工艺。每一枚瑞时时计皆是传统美学与瑞士精工相碰撞的非凡结晶。'
              : 'Fine mechanical watches inspired by China’s timeless landscapes, crafted for a modern world.'}
          </p>

          <div className="pt-4 flex flex-wrap items-center gap-4">
            <button
              onClick={onExploreCollections}
              className="inline-flex items-center gap-3 px-6 py-3.5 border border-[#d4af37] text-xs font-cinzel tracking-[0.2em] font-semibold text-[#f3e5ab] bg-[#0d0d0e]/60 hover:bg-[#d4af37] hover:text-[#0a0a0c] transition-all duration-300 shadow-lg hover:shadow-[#d4af37]/20 group"
            >
              <span>{lang === 'zh' ? '探索时计系列' : 'EXPLORE COLLECTIONS'}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => onSelectWatch(heroWatch)}
              className="inline-flex items-center gap-2 px-4 py-3.5 border border-[#333338] text-xs font-cinzel tracking-widest text-[#d1d1d6] hover:border-[#888892] hover:text-white transition-all bg-[#0d0d0e]/40"
            >
              <Eye className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>{lang === 'zh' ? '鉴赏表盘细节' : 'VIEW TIMEPIECE'}</span>
            </button>

            {/* Audio Calibre Simulator Button */}
            <button
              onClick={toggleMechanicalTickSound}
              className="p-3 border border-[#333338] hover:border-[#d4af37] rounded-full text-[#d4af37] bg-[#0d0d0e]/60 hover:bg-[#121215] transition-all"
              title="Listen to 28,800 vph Calibre Beat"
            >
              {isPlayingAudio ? (
                <Volume2 className="w-4 h-4 animate-pulse text-[#d4af37]" />
              ) : (
                <VolumeX className="w-4 h-4 text-[#888892]" />
              )}
            </button>
          </div>
        </div>

        {/* Right Column - Vertical Calligraphy Stamp & Seal */}
        <div className="hidden md:flex md:col-span-5 justify-end items-center pr-4 lg:pr-8">
          <div className="flex items-center gap-6 bg-[#0d0d0e]/30 backdrop-blur-sm p-6 border-r border-[#d4af37]/30">
            <div className="writing-vertical font-chinese text-[#e5e5e7] text-lg lg:text-xl font-light leading-loose tracking-[0.4em]">
              匠心传承 时间之美
            </div>
            <div className="flex flex-col items-center gap-3">
              <div className="vermilion-seal w-7 h-12 text-xs flex items-center justify-center font-bold px-1 py-2">
                瑞时
              </div>
              <span className="text-[10px] font-mono tracking-widest text-[#a0a0ab] rotate-90 my-4">
                1928
              </span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
