'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { Language } from '@/types/watch';

interface HeritageSectionProps {
  lang: Language;
  onOpenJournal: () => void;
}

export default function HeritageSection({ lang, onOpenJournal }: HeritageSectionProps) {
  return (
    <section id="heritage" className="relative border-y border-[#222226] bg-[#0d0d0e] overflow-hidden">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 min-h-[520px]">
        
        {/* Left / Center Content Panel (Parchment & Atelier Imagery) */}
        <div className="lg:col-span-9 relative flex flex-col md:flex-row items-stretch bg-gradient-to-r from-[#ece6da] via-[#e5dfd2] to-[#dcd5c6] text-[#1a1a1c]">
          
          {/* Subtle Ink Wash Painting Backdrop Overlay */}
          <div className="p-8 md:p-12 lg:p-14 flex-1 flex flex-col justify-center space-y-5 relative z-10">
            <span className="font-cinzel text-xs tracking-[0.3em] text-[#8c734b] uppercase font-semibold">
              {lang === 'zh' ? '品牌传承' : 'OUR HERITAGE'}
            </span>

            <h2 className="font-cinzel text-2xl sm:text-3xl lg:text-4xl font-normal text-[#111113] tracking-wide leading-snug">
              {lang === 'zh' ? '百年匠心 淬炼非凡' : 'A LEGACY OF CRAFTSMANSHIP'}
            </h2>

            <p className="text-xs sm:text-sm text-[#3e3d40] font-normal leading-relaxed max-w-md">
              {lang === 'zh'
                ? '一个多世纪以来，瑞时始终坚守高级制表艺术，将中国传统水墨美学与瑞士精密机械完美交融。每一枚时计皆承载着我们对卓越品质、深厚底蕴与永恒价值的执着坚守。'
                : 'For over a century, Rui Shi has embodied the art of fine watchmaking, blending traditional Chinese aesthetics with Swiss-inspired precision. Each timepiece is a testament to our commitment to excellence, heritage and enduring value.'}
            </p>

            <div className="pt-2">
              <button
                onClick={onOpenJournal}
                className="inline-flex items-center gap-2 font-cinzel text-xs font-semibold tracking-[0.2em] text-[#111113] hover:text-[#8c734b] transition-colors group"
              >
                <span>{lang === 'zh' ? '探索瑞时传奇故事' : 'DISCOVER OUR STORY'}</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>

          {/* Master Watchmaker Photo */}
          <div className="relative w-full md:w-1/2 min-h-[300px] md:min-h-full">
            <Image
              src="/images/heritage_craftsman_atelier_1791201193360.jpg"
              alt="Master Chinese watchmaker assembling fine tourbillon watch movement"
              fill
              className="object-cover object-center"
              referrerPolicy="no-referrer"
            />
            {/* Subtle Vignette overlay to blend with parchment */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#dcd5c6] via-transparent to-transparent md:w-16" />
          </div>

        </div>

        {/* Right Dark Column with Calligraphy Vertical Text */}
        <div className="lg:col-span-3 bg-[#0d0d0e] border-t lg:border-t-0 lg:border-l border-[#222226] p-8 flex flex-col items-center justify-center relative overflow-hidden">
          
          {/* Subtle Pagoda / Ink Outline Background */}
          <div className="absolute inset-0 opacity-10 pointer-events-none flex items-center justify-center">
            <div className="w-48 h-48 border border-[#d4af37] rotate-45" />
          </div>

          <div className="relative z-10 flex flex-col items-center gap-6">
            <div className="writing-vertical font-chinese text-[#e5e5e7] text-lg lg:text-xl font-light tracking-[0.45em] leading-loose">
              传承百年 精工细作
            </div>

            <div className="vermilion-seal w-7 h-10 text-xs flex items-center justify-center font-bold">
              瑞时
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
