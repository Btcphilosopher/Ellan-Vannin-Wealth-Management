'use client';

import React from 'react';
import { ShieldCheck, Truck, Sparkles } from 'lucide-react';
import { Language } from '@/types/watch';

interface GuaranteeBarProps {
  lang: Language;
}

export default function GuaranteeBar({ lang }: GuaranteeBarProps) {
  return (
    <section className="bg-[#0a0a0c] border-t border-[#222226] py-10 relative overflow-hidden text-[#d1d1d6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8 items-center relative z-10">
        
        {/* Item 1: Authenticity */}
        <div className="flex items-center gap-4 group">
          <div className="p-3 border border-[#333338] group-hover:border-[#d4af37] text-[#d4af37] rounded-sm transition-colors bg-[#0d0d10]">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-cinzel text-xs font-semibold tracking-widest text-[#f8f8fa] uppercase">
              {lang === 'zh' ? '正品防伪保障' : 'AUTHENTICITY GUARANTEED'}
            </h4>
            <p className="text-[11px] text-[#888892] pt-0.5">
              {lang === 'zh' ? '官方正品 · 全球五年联保' : 'Official retailer · Full warranty'}
            </p>
          </div>
        </div>

        {/* Item 2: Global Shipping */}
        <div className="flex items-center gap-4 group md:border-l md:border-[#222226] md:pl-8">
          <div className="p-3 border border-[#333338] group-hover:border-[#d4af37] text-[#d4af37] rounded-sm transition-colors bg-[#0d0d10]">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-cinzel text-xs font-semibold tracking-widest text-[#f8f8fa] uppercase">
              {lang === 'zh' ? '全球尊尚速递' : 'GLOBAL SHIPPING'}
            </h4>
            <p className="text-[11px] text-[#888892] pt-0.5">
              {lang === 'zh' ? '全额全程保价特快专递' : 'Secure & insured express transportation'}
            </p>
          </div>
        </div>

        {/* Item 3: Bespoke Service */}
        <div className="flex items-center gap-4 group md:border-l md:border-[#222226] md:pl-8">
          <div className="p-3 border border-[#333338] group-hover:border-[#d4af37] text-[#d4af37] rounded-sm transition-colors bg-[#0d0d10]">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-cinzel text-xs font-semibold tracking-widest text-[#f8f8fa] uppercase">
              {lang === 'zh' ? '高级私享定制' : 'BESPOKE SERVICE'}
            </h4>
            <p className="text-[11px] text-[#888892] pt-0.5">
              {lang === 'zh' ? '专属铭刻打造传世臻品' : 'Create your own masterpiece'}
            </p>
          </div>
        </div>

      </div>

      {/* Traditional Ink Mountain Line Outline Graphic & Vermilion Chop Seal in bottom right */}
      <div className="absolute right-4 bottom-1 opacity-20 pointer-events-none hidden lg:flex items-end gap-2">
        <svg className="w-48 h-12 text-[#d4af37]" viewBox="0 0 200 50" fill="none" stroke="currentColor">
          <path d="M0 45 Q 30 20 60 35 T 120 15 T 180 40 T 200 45" strokeWidth="1" />
          <path d="M20 45 Q 50 25 80 40 T 140 25 T 200 45" strokeWidth="0.5" opacity="0.6" />
        </svg>
        <div className="vermilion-seal w-5 h-7 text-[9px] flex items-center justify-center font-bold">
          瑞
        </div>
      </div>
    </section>
  );
}
