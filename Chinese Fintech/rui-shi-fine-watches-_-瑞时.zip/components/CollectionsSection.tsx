'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Eye, ShoppingBag, Sparkles } from 'lucide-react';
import { CollectionCategory, Language, WatchItem } from '@/types/watch';

interface CollectionsSectionProps {
  lang: Language;
  watches: WatchItem[];
  onSelectWatch: (watch: WatchItem) => void;
  onAddToCart: (watch: WatchItem) => void;
  onOpenBespoke: () => void;
}

export default function CollectionsSection({
  lang,
  watches,
  onSelectWatch,
  onAddToCart,
  onOpenBespoke,
}: CollectionsSectionProps) {
  const [activeCategory, setActiveCategory] = useState<CollectionCategory>('all');

  const filteredWatches = activeCategory === 'all'
    ? watches
    : watches.filter((w) => w.category === activeCategory);

  return (
    <section id="collections" className="py-20 bg-[#0a0a0c] relative text-[#e5e5e7]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col items-start justify-between border-b border-[#222226] pb-6 mb-12">
          <div className="relative">
            <h2 className="font-cinzel text-xl sm:text-2xl lg:text-3xl font-medium tracking-[0.2em] uppercase text-[#f8f8fa]">
              {lang === 'zh' ? '瑞时经典系列' : 'THE COLLECTIONS'}
            </h2>
            <div className="w-16 h-[2px] bg-[#d4af37] mt-3" />
          </div>

          {/* Interactive Category Filter Segmented Tabs */}
          <div className="flex flex-wrap items-center gap-2 mt-6">
            {(
              [
                { id: 'all', en: 'ALL', zh: '全部' },
                { id: 'classic', en: 'CLASSIC', zh: '经典' },
                { id: 'heritage', en: 'HERITAGE', zh: '传承' },
                { id: 'sport', en: 'SPORT', zh: '尚品' },
                { id: 'masters', en: 'MASTERS', zh: '大师' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id as CollectionCategory)}
                className={`px-4 py-1.5 text-xs font-cinzel tracking-widest transition-all rounded-sm border ${
                  activeCategory === tab.id
                    ? 'border-[#d4af37] text-[#f3e5ab] bg-[#1a1a20]'
                    : 'border-[#222226] text-[#a0a0ab] hover:text-white hover:border-[#44444c]'
                }`}
              >
                {lang === 'zh' ? tab.zh : tab.en}
              </button>
            ))}
          </div>
        </div>

        {/* Watch Collection Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredWatches.map((watch) => (
            <div
              key={watch.id}
              className="group relative bg-[#121215] border border-[#222228] hover:border-[#d4af37]/60 transition-all duration-500 overflow-hidden flex flex-col justify-between"
            >
              {/* Product Image Area */}
              <div
                onClick={() => onSelectWatch(watch)}
                className="relative aspect-square w-full cursor-pointer bg-[#0a0a0c] overflow-hidden"
              >
                <Image
                  src={watch.image}
                  alt={watch.name}
                  fill
                  className="object-cover object-center group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                
                {/* Overlay hover quick view button */}
                <div className="absolute inset-0 bg-[#0a0a0c]/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectWatch(watch);
                    }}
                    className="p-2.5 bg-[#0d0d0e]/90 text-[#f3e5ab] rounded-full border border-[#d4af37] hover:bg-[#d4af37] hover:text-black transition-colors"
                    title="View Timepiece Details"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Card Text Information (Matching Mockup Typography) */}
              <div className="p-6 text-center space-y-2 border-t border-[#1f1f24] bg-[#121215]">
                <h3 className="font-cinzel text-sm sm:text-base tracking-[0.25em] font-medium text-[#f8f8fa] uppercase group-hover:text-[#f3e5ab] transition-colors">
                  {watch.category.toUpperCase()}
                </h3>

                <p className="font-serif-luxury italic text-xs text-[#a0a0ab] tracking-wide">
                  {lang === 'zh' ? watch.chineseTagline : watch.tagline}
                </p>

                <div className="pt-2 flex items-center justify-between text-xs font-mono text-[#d4af37]">
                  <span>
                    {lang === 'zh'
                      ? `¥ ${watch.priceRMB.toLocaleString()}`
                      : `$ ${watch.priceUSD.toLocaleString()}`}
                  </span>
                  
                  <button
                    onClick={() => onAddToCart(watch)}
                    className="flex items-center gap-1.5 px-3 py-1 text-[11px] font-cinzel border border-[#333338] hover:border-[#d4af37] text-[#e5e5e7] hover:text-[#f3e5ab] transition-colors rounded-sm"
                  >
                    <ShoppingBag className="w-3 h-3 text-[#d4af37]" />
                    <span>{lang === 'zh' ? '预订' : 'ADD'}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bespoke Custom Studio Banner */}
        <div className="mt-16 bg-gradient-to-r from-[#17171d] via-[#1c1c24] to-[#121216] border border-[#d4af37]/40 p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 text-xs font-cinzel text-[#d4af37] uppercase tracking-widest">
              <Sparkles className="w-4 h-4" />
              <span>{lang === 'zh' ? '瑞时高级定制工坊' : 'BESPOKE TIMEPIECE ATELIER'}</span>
            </div>
            <h3 className="font-cinzel text-xl md:text-2xl text-white font-normal">
              {lang === 'zh' ? '定制属于您的独一无二机械传世之作' : 'Create Your Personal Horological Masterpiece'}
            </h3>
            <p className="text-xs text-[#a0a0ab] max-w-xl">
              {lang === 'zh'
                ? '自主选择表壳贵金属、珐琅山水表盘、复杂功能与个性化表背书法刻字，AI智能生成专属诗意铭文。'
                : 'Select precious metals, grand feu dials, complications, and custom caseback calligraphy with AI-crafted poetic mottos.'}
            </p>
          </div>

          <button
            onClick={onOpenBespoke}
            className="px-6 py-3 bg-[#d4af37] hover:bg-[#f3e5ab] text-black font-cinzel text-xs tracking-[0.2em] font-bold transition-all shadow-lg shadow-[#d4af37]/10 whitespace-nowrap"
          >
            {lang === 'zh' ? '开启高级定制 →' : 'DESIGN YOUR WATCH →'}
          </button>
        </div>

      </div>
    </section>
  );
}
