'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, MapPin, Phone, Calendar, CheckCircle2 } from 'lucide-react';
import { BOUTIQUES, BoutiqueLocation } from '@/lib/data';
import { Language } from '@/types/watch';

interface BoutiqueModalProps {
  lang: Language;
  initialWatchName?: string;
  onClose: () => void;
}

export default function BoutiqueModal({ lang, initialWatchName, onClose }: BoutiqueModalProps) {
  const [selectedBoutique, setSelectedBoutique] = useState<BoutiqueLocation>(BOUTIQUES[0]);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: 'Tom',
    phone: '+44 20 7946 0912',
    date: '2026-10-12',
    time: '14:30',
    notes: initialWatchName ? `Interested in private fitting for ${initialWatchName}` : 'Private VIP Consultation',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-[#101014] border border-[#d4af37]/40 w-full max-w-3xl my-auto shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#222228] flex items-center justify-between bg-[#0b0b0e]">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#d4af37]" />
            <h2 className="font-cinzel text-sm font-bold text-[#f8f8fa] tracking-[0.2em] uppercase">
              {lang === 'zh' ? '预约旗舰店私享试戴与沟通' : 'BOOK BOUTIQUE APPOINTMENT'}
            </h2>
          </div>
          <button onClick={onClose} className="p-1 text-[#888892] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {!submitted ? (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              
              {/* Left Column: Select Salon */}
              <div className="md:col-span-5 space-y-3">
                <label className="text-xs font-cinzel text-[#d4af37] tracking-widest font-semibold block">
                  {lang === 'zh' ? '1. 选择尊享沙龙机构' : '1. SELECT BOUTIQUE SALON'}
                </label>

                <div className="space-y-2">
                  {BOUTIQUES.map((boutique) => (
                    <button
                      key={boutique.city}
                      onClick={() => setSelectedBoutique(boutique)}
                      className={`w-full p-3 text-left border text-xs transition-all flex items-start gap-3 ${
                        selectedBoutique.city === boutique.city
                          ? 'border-[#d4af37] bg-[#181820] text-[#f3e5ab]'
                          : 'border-[#222228] bg-[#0d0d10] text-[#a0a0ab] hover:border-[#44444c]'
                      }`}
                    >
                      <MapPin className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                      <div>
                        <div className="font-cinzel font-bold text-[#f8f8fa]">
                          {lang === 'zh' ? boutique.chineseCity : boutique.city} Salon
                        </div>
                        <div className="text-[10px] text-[#888892] line-clamp-1">
                          {boutique.name}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="p-3 bg-[#121216] border border-[#222228] space-y-2 text-[11px] text-[#a0a0ab]">
                  <p className="font-medium text-[#f8f8fa]">{selectedBoutique.name}</p>
                  <p className="flex items-center gap-1.5 text-[10px]">
                    <MapPin className="w-3 h-3 text-[#d4af37]" />
                    {selectedBoutique.address}
                  </p>
                  <p className="flex items-center gap-1.5 text-[10px] font-mono">
                    <Phone className="w-3 h-3 text-[#d4af37]" />
                    {selectedBoutique.phone}
                  </p>
                </div>
              </div>

              {/* Right Column: Appointment Form */}
              <form onSubmit={handleSubmit} className="md:col-span-7 space-y-4 text-xs">
                <label className="text-xs font-cinzel text-[#d4af37] tracking-widest font-semibold block">
                  2. {lang === 'zh' ? '预约尊享时间与联系人' : '2. APPOINTMENT DETAILS'}
                </label>

                <div className="space-y-3">
                  <div>
                    <label className="text-[10px] text-[#888892] block mb-1">GUEST NAME</label>
                    <input
                      type="text"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full bg-[#08080a] border border-[#33333e] p-2.5 text-white outline-none focus:border-[#d4af37]"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-[#888892] block mb-1">PHONE / WECHAT</label>
                    <input
                      type="text"
                      required
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="w-full bg-[#08080a] border border-[#33333e] p-2.5 text-white outline-none focus:border-[#d4af37]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-[#888892] block mb-1">DATE</label>
                      <input
                        type="date"
                        required
                        value={form.date}
                        onChange={(e) => setForm({ ...form, date: e.target.value })}
                        className="w-full bg-[#08080a] border border-[#33333e] p-2 text-white outline-none focus:border-[#d4af37]"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-[#888892] block mb-1">TIME</label>
                      <input
                        type="time"
                        required
                        value={form.time}
                        onChange={(e) => setForm({ ...form, time: e.target.value })}
                        className="w-full bg-[#08080a] border border-[#33333e] p-2 text-white outline-none focus:border-[#d4af37]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-[#888892] block mb-1">SPECIFIC INTERESTS / TIMEPIECES</label>
                    <textarea
                      rows={2}
                      value={form.notes}
                      onChange={(e) => setForm({ ...form, notes: e.target.value })}
                      className="w-full bg-[#08080a] border border-[#33333e] p-2 text-white outline-none focus:border-[#d4af37]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#d4af37] text-black font-cinzel text-xs font-bold tracking-widest hover:bg-[#f3e5ab] transition-all"
                >
                  {lang === 'zh' ? '确认提交私享预约' : 'SUBMIT PRIVATE APPOINTMENT'}
                </button>
              </form>

            </div>
          ) : (
            <div className="py-12 text-center space-y-4">
              <div className="w-12 h-12 bg-[#d4af37]/20 border border-[#d4af37] text-[#d4af37] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="font-cinzel text-base font-bold text-[#f3e5ab]">
                {lang === 'zh' ? '沙龙品鉴预约已为您确认' : 'BOUTIQUE APPOINTMENT CONFIRMED'}
              </h3>
              <p className="text-xs text-[#a0a0ab] max-w-sm mx-auto leading-relaxed">
                {lang === 'zh'
                  ? `期待在 ${selectedBoutique.name} 为您提供一对一独立制表大师品鉴服务 (${form.date} ${form.time})。`
                  : `We look forward to welcoming you to ${selectedBoutique.name} on ${form.date} at ${form.time}.`}
              </p>
              <button
                onClick={onClose}
                className="px-6 py-2 border border-[#d4af37] text-[#f3e5ab] font-cinzel text-xs tracking-widest"
              >
                {lang === 'zh' ? '完成并关闭' : 'CLOSE'}
              </button>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
