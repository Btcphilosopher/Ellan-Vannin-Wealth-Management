'use client';

import React, { useState } from 'react';
import { Search, ShoppingBag, User, Globe, Menu, X } from 'lucide-react';
import { Language } from '@/types/watch';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenSearch: () => void;
  onOpenAccount: () => void;
  onOpenBespoke: () => void;
  onNavigate: (sectionId: string) => void;
}

export default function Navbar({
  lang,
  onToggleLang,
  cartCount,
  onOpenCart,
  onOpenSearch,
  onOpenAccount,
  onOpenBespoke,
  onNavigate,
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (id: string) => {
    setMobileMenuOpen(false);
    if (id === 'bespoke') {
      onOpenBespoke();
    } else {
      onNavigate(id);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0d0d0e]/90 backdrop-blur-md border-b border-[#222226] transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Zone 1: Logo & Red Chop Seal Stamp */}
        <button
          onClick={() => handleNav('hero')}
          className="flex items-center gap-3 group text-left focus:outline-none"
        >
          <div className="vermilion-seal w-8 h-8 text-sm flex items-center justify-center font-bold tracking-tighter">
            瑞时
          </div>
          <div className="flex flex-col">
            <span className="font-cinzel text-lg font-bold tracking-widest text-[#f3e5ab] group-hover:text-white transition-colors">
              RUI SHI
            </span>
            <span className="text-[9px] tracking-[0.25em] text-[#a0a0ab] uppercase font-light -mt-0.5">
              FINE WATCHES
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 font-cinzel text-xs font-medium tracking-[0.2em] text-[#d1d1d6]">
          <button
            onClick={() => handleNav('hero')}
            className="hover:text-[#f3e5ab] transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-full after:h-[1px] after:bg-[#d4af37] after:scale-x-100"
          >
            {lang === 'zh' ? '首页' : 'HOME'}
          </button>
          <button
            onClick={() => handleNav('collections')}
            className="hover:text-[#f3e5ab] transition-colors py-1"
          >
            {lang === 'zh' ? '时计系列' : 'COLLECTIONS'}
          </button>
          <button
            onClick={() => handleNav('heritage')}
            className="hover:text-[#f3e5ab] transition-colors py-1"
          >
            {lang === 'zh' ? '品牌传承' : 'OUR HERITAGE'}
          </button>
          <button
            onClick={() => handleNav('bespoke')}
            className="hover:text-[#f3e5ab] transition-colors py-1 text-[#d4af37]"
          >
            {lang === 'zh' ? '高级定制' : 'BESPOKE'}
          </button>
          <button
            onClick={() => handleNav('journal')}
            className="hover:text-[#f3e5ab] transition-colors py-1"
          >
            {lang === 'zh' ? '瑞时刊物' : 'JOURNAL'}
          </button>
        </nav>

        {/* Zone 3: Actions (Search, Account, Cart, Language Toggle) */}
        <div className="flex items-center gap-4 text-[#d1d1d6]">
          <button
            onClick={onOpenSearch}
            aria-label="Search timepieces"
            className="p-1.5 hover:text-[#f3e5ab] transition-colors focus:outline-none"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenAccount}
            aria-label="Boutique Member Account"
            className="p-1.5 hover:text-[#f3e5ab] transition-colors focus:outline-none hidden sm:block"
          >
            <User className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenCart}
            aria-label="Shopping bag"
            className="p-1.5 hover:text-[#f3e5ab] transition-colors focus:outline-none relative"
          >
            <ShoppingBag className="w-4 h-4" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1.5 bg-[#c82323] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          <button
            onClick={onToggleLang}
            className="flex items-center gap-1.5 text-xs font-mono tracking-widest px-2 py-1 border border-[#333338] hover:border-[#d4af37] rounded text-[#d1d1d6] hover:text-[#f3e5ab] transition-all ml-1"
            title="Switch Language"
          >
            <Globe className="w-3 h-3 text-[#d4af37]" />
            <span>{lang === 'zh' ? '中文 / EN' : 'EN / 中文'}</span>
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-1.5 text-[#d1d1d6] hover:text-white"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#121215] border-b border-[#222226] px-6 py-6 space-y-4 font-cinzel text-sm tracking-widest">
          <button
            onClick={() => handleNav('hero')}
            className="block w-full text-left py-2 hover:text-[#f3e5ab]"
          >
            {lang === 'zh' ? '首页' : 'HOME'}
          </button>
          <button
            onClick={() => handleNav('collections')}
            className="block w-full text-left py-2 hover:text-[#f3e5ab]"
          >
            {lang === 'zh' ? '时计系列' : 'COLLECTIONS'}
          </button>
          <button
            onClick={() => handleNav('heritage')}
            className="block w-full text-left py-2 hover:text-[#f3e5ab]"
          >
            {lang === 'zh' ? '品牌传承' : 'OUR HERITAGE'}
          </button>
          <button
            onClick={() => handleNav('bespoke')}
            className="block w-full text-left py-2 text-[#d4af37] font-bold"
          >
            {lang === 'zh' ? '高级定制' : 'BESPOKE STUDIO'}
          </button>
          <button
            onClick={() => handleNav('journal')}
            className="block w-full text-left py-2 hover:text-[#f3e5ab]"
          >
            {lang === 'zh' ? '瑞时刊物' : 'JOURNAL'}
          </button>
          <div className="pt-4 border-t border-[#222226] flex justify-between text-xs text-[#888892]">
            <button onClick={onOpenAccount} className="hover:text-white">
              {lang === 'zh' ? '会员专区 / 尊享服务' : 'BOUTIQUE MEMBER LOGIN'}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
