'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, BookOpen, Clock } from 'lucide-react';
import { JOURNAL_ARTICLES, JournalArticle } from '@/lib/data';
import { Language } from '@/types/watch';

interface JournalSectionProps {
  lang: Language;
  onSelectArticle: (article: JournalArticle) => void;
}

export default function JournalSection({ lang, onSelectArticle }: JournalSectionProps) {
  return (
    <section id="journal" className="py-20 bg-[#0d0d10] border-t border-[#222226] text-[#e5e5e7]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-[#222226] pb-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-cinzel text-[#d4af37] tracking-widest uppercase mb-1">
              <BookOpen className="w-3.5 h-3.5" />
              <span>{lang === 'zh' ? '瑞时高尚刊物' : 'HOROLOGICAL JOURNAL'}</span>
            </div>
            <h2 className="font-cinzel text-xl sm:text-2xl lg:text-3xl font-medium tracking-[0.2em] text-[#f8f8fa]">
              {lang === 'zh' ? '钟表美学与匠心探索' : 'CRAFT & PHILOSOPHY'}
            </h2>
          </div>

          <p className="text-xs text-[#a0a0ab] max-w-md mt-4 md:mt-0">
            {lang === 'zh'
              ? '深入探究微绘珐琅、陀飞轮机械结构与东方山水美学的深度融合。'
              : 'Essays on enamel miniature painting, flying tourbillon mechanics, and oriental landscape horology.'}
          </p>
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {JOURNAL_ARTICLES.map((article) => (
            <article
              key={article.id}
              onClick={() => onSelectArticle(article)}
              className="group cursor-pointer bg-[#121216] border border-[#222228] hover:border-[#d4af37]/60 transition-all duration-500 overflow-hidden flex flex-col justify-between"
            >
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-black">
                <Image
                  src={article.image}
                  alt={article.title}
                  fill
                  className="object-cover object-center group-hover:scale-105 transition-transform duration-700 opacity-90"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="p-6 space-y-3">
                <div className="flex items-center gap-3 text-[11px] font-mono text-[#a0a0ab]">
                  <span>{article.date}</span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-[#d4af37]" />
                    {article.readTime}
                  </span>
                </div>

                <h3 className="font-cinzel text-base sm:text-lg font-bold text-[#f8f8fa] group-hover:text-[#f3e5ab] transition-colors leading-snug">
                  {lang === 'zh' ? article.chineseTitle : article.title}
                </h3>

                <p className="text-xs text-[#a0a0ab] leading-relaxed line-clamp-2">
                  {lang === 'zh' ? article.chineseSubtitle : article.subtitle}
                </p>

                <div className="pt-2 flex items-center gap-2 font-cinzel text-xs text-[#d4af37] font-semibold">
                  <span>{lang === 'zh' ? '阅读全文' : 'READ JOURNAL'}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </article>
          ))}
        </div>

      </div>
    </section>
  );
}
