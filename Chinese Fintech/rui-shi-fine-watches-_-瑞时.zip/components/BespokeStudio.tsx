'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Sparkles, Wand2, Check, ShoppingBag, Calendar } from 'lucide-react';
import { BespokeOption, Language, WatchItem } from '@/types/watch';

interface BespokeStudioProps {
  lang: Language;
  onClose: () => void;
  onAddBespokeToCart: (customWatch: WatchItem, bespokeConfig: BespokeOption) => void;
  onBookBoutique: () => void;
}

export default function BespokeStudio({
  lang,
  onClose,
  onAddBespokeToCart,
  onBookBoutique,
}: BespokeStudioProps) {
  const [config, setConfig] = useState<BespokeOption>({
    caseMaterial: '18k-rose-gold',
    dialFinish: 'shanshui-ink',
    strapMaterial: 'alligator-black',
    complication: 'flying-tourbillon',
    customEngraving: '与自然共时 匠心传百年',
  });

  const [aiResult, setAiResult] = useState<{
    chineseInscription: string;
    englishMotto: string;
    poeticStory: string;
  } | null>(null);

  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  // Price Calculation Logic based on selections
  const calculatePrice = () => {
    let base = 25000;
    if (config.caseMaterial === 'platinum-950') base += 12000;
    if (config.caseMaterial === 'damascus-steel') base += 4000;
    if (config.dialFinish === 'cloisonne-dragon') base += 15000;
    if (config.dialFinish === 'shanshui-ink') base += 18000;
    if (config.complication === 'flying-tourbillon') base += 35000;
    if (config.complication === 'moonphase-lunar') base += 8000;
    return base;
  };

  const currentUSD = calculatePrice();
  const currentRMB = currentUSD * 6.9;

  // Get preview image based on dial choice
  const getDialImage = () => {
    switch (config.dialFinish) {
      case 'shanshui-ink':
        return '/images/hero_rui_shi_watch_1791201179449.jpg';
      case 'jade-enamel':
        return '/images/watch_heritage_dial_1791201220276.jpg';
      case 'midnight-skeleton':
        return '/images/watch_classic_dial_1791201206582.jpg';
      case 'cloisonne-dragon':
        return '/images/watch_masters_tourbillon_1791201242458.jpg';
      default:
        return '/images/watch_classic_dial_1791201206582.jpg';
    }
  };

  const handleGenerateAiEngraving = async () => {
    setIsGeneratingAi(true);
    try {
      const res = await fetch('/api/gemini/engrave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          concept: config.customEngraving,
          caseMaterial: config.caseMaterial,
          dialFinish: config.dialFinish,
          lang,
        }),
      });
      const data = await res.json();
      setAiResult(data);
    } catch (err) {
      console.error('Failed to generate engraving', err);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleOrder = () => {
    const customWatch: WatchItem = {
      id: `bespoke-custom-piece`,
      name: `Rui Shi Bespoke Masterpiece`,
      chineseName: `瑞时 高级定制典藏`,
      category: 'masters',
      tagline: 'Custom Atelier Timepiece',
      chineseTagline: '私享高级定制',
      priceUSD: currentUSD,
      priceRMB: currentRMB,
      image: getDialImage(),
      description: `Bespoke timepiece featuring ${config.caseMaterial} case, ${config.dialFinish} dial, ${config.complication} complication, and laser engraved back inscription: "${aiResult?.chineseInscription || config.customEngraving}".`,
      chineseDescription: `定制时计，结合${config.caseMaterial}表壳、${config.dialFinish}表盘与${config.complication}复杂功能，表背刻印：“${aiResult?.chineseInscription || config.customEngraving}”。`,
      specs: {
        caseDiameter: '41.0 mm',
        caseThickness: '9.8 mm',
        caseMaterial: config.caseMaterial.toUpperCase(),
        movement: 'Atelier Bespoke Calibre RS-CUSTOM',
        caliber: 'Calibre RS-CUSTOM',
        powerReserve: '72 Hours',
        frequency: '28,800 vph',
        jewels: 35,
        waterResistance: '50 Meters',
        dialFinish: config.dialFinish,
        strap: config.strapMaterial,
      },
      inStock: true,
    };

    onAddBespokeToCart(customWatch, config);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-[#101014] border border-[#d4af37]/40 w-full max-w-5xl my-auto rounded-none shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#222228] flex items-center justify-between bg-[#0b0b0e]">
          <div className="flex items-center gap-3">
            <div className="vermilion-seal w-7 h-7 text-xs flex items-center justify-center font-bold">
              瑞
            </div>
            <div>
              <h2 className="font-cinzel text-base sm:text-lg font-bold text-[#f3e5ab]">
                {lang === 'zh' ? '瑞时高级定制工坊' : 'RUI SHI BESPOKE STUDIO'}
              </h2>
              <p className="text-[10px] text-[#a0a0ab] font-mono tracking-widest">
                {lang === 'zh' ? '独立制表工坊 · 1-ON-1 ATELIER CRAFTSMANSHIP' : '1-ON-1 ATELIER HOROLOGY ATELIER'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-[#888892] hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Studio Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 overflow-y-auto flex-1">
          
          {/* Left Column: Interactive Watch Visual Preview & AI Engraving Result */}
          <div className="lg:col-span-5 bg-[#08080a] p-6 border-b lg:border-b-0 lg:border-r border-[#222228] flex flex-col justify-between">
            <div>
              <div className="relative aspect-square w-full border border-[#222228] overflow-hidden bg-black mb-4">
                <Image
                  src={getDialImage()}
                  alt="Bespoke watch preview"
                  fill
                  className="object-cover object-center"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 left-3 bg-[#0d0d10]/80 backdrop-blur-md px-3 py-1 border border-[#d4af37]/30 text-[10px] font-mono text-[#d4af37]">
                  ATELIER PREVIEW
                </div>
              </div>

              {/* AI Inscription Preview Card */}
              <div className="bg-[#14141a] border border-[#33333e] p-4 space-y-2">
                <div className="flex items-center justify-between text-xs text-[#d4af37] font-cinzel">
                  <span className="flex items-center gap-1.5 font-bold">
                    <Sparkles className="w-3.5 h-3.5" />
                    {lang === 'zh' ? '表背微雕铭文' : 'CASEBACK INSCRIPTION'}
                  </span>
                  <span className="text-[10px] font-mono text-[#888892]">LASER / HAND-ENGRAVED</span>
                </div>

                {aiResult ? (
                  <div className="space-y-1.5 pt-1">
                    <p className="font-chinese text-base font-bold text-[#f3e5ab] tracking-widest">
                      {aiResult.chineseInscription}
                    </p>
                    <p className="font-serif-luxury italic text-xs text-[#d1d1d6]">
                      &quot;{aiResult.englishMotto}&quot;
                    </p>
                    <p className="text-[11px] text-[#9a9a9f] leading-relaxed pt-1">
                      {aiResult.poeticStory}
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-[#888892] italic">
                    {lang === 'zh'
                      ? '点击右侧“AI智能微雕赋诗”生成专属中文画意与英文对联'
                      : 'Click "AI Compose Inscription" on the right to generate bespoke calligraphy and poetry.'}
                  </p>
                )}
              </div>
            </div>

            {/* Price Footer Summary */}
            <div className="pt-4 border-t border-[#222228] mt-4 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#888892] font-mono block">ESTIMATED QUOTE</span>
                <span className="font-mono text-lg font-bold text-[#d4af37]">
                  {lang === 'zh' ? `¥ ${currentRMB.toLocaleString()}` : `$ ${currentUSD.toLocaleString()}`}
                </span>
              </div>
              <span className="text-[10px] text-[#a0a0ab]">Includes 5-Yr Guarantee & Wooden Box</span>
            </div>
          </div>

          {/* Right Column: Customization Controls */}
          <div className="lg:col-span-7 p-6 space-y-6 bg-[#101014] overflow-y-auto">
            
            {/* 1. Case Material */}
            <div className="space-y-2">
              <label className="text-xs font-cinzel tracking-widest text-[#f3e5ab] font-semibold block">
                1. {lang === 'zh' ? '表壳贵金属材质' : 'CASE MATERIAL'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: '18k-rose-gold', label: '18K Rose Gold', zh: '18K 玫瑰金' },
                  { id: 'platinum-950', label: '950 Platinum', zh: '950 铂金' },
                  { id: 'titanium-grade-5', label: 'Grade 5 Titanium', zh: '五级钛金属' },
                  { id: 'damascus-steel', label: 'Damascus Steel', zh: '大马士革钢' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setConfig({ ...config, caseMaterial: item.id as any })}
                    className={`p-2.5 text-xs text-left border transition-all rounded-sm flex flex-col justify-between ${
                      config.caseMaterial === item.id
                        ? 'border-[#d4af37] bg-[#1a1a22] text-[#f3e5ab]'
                        : 'border-[#222228] bg-[#0c0c0e] text-[#a0a0ab] hover:border-[#44444c]'
                    }`}
                  >
                    <span className="font-medium text-[11px]">
                      {lang === 'zh' ? item.zh : item.label}
                    </span>
                    {config.caseMaterial === item.id && <Check className="w-3 h-3 text-[#d4af37] self-end mt-1" />}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Dial Finish */}
            <div className="space-y-2">
              <label className="text-xs font-cinzel tracking-widest text-[#f3e5ab] font-semibold block">
                2. {lang === 'zh' ? '表盘艺术工艺' : 'DIAL ARTISTIC FINISH'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'shanshui-ink', label: 'Hand-Painted Shanshui Enamel', zh: '手绘微绘水墨珐琅' },
                  { id: 'jade-enamel', label: 'Grand Feu Porcelain Enamel', zh: '大火高洁白瓷珐琅' },
                  { id: 'cloisonne-dragon', label: 'Cloisonné Dragon Motif', zh: '掐丝珐琅瑞龙金纹' },
                  { id: 'midnight-skeleton', label: 'Midnight Hand-Skeletonized', zh: '曜石夜空全镂空雕刻' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setConfig({ ...config, dialFinish: item.id as any })}
                    className={`p-2.5 text-xs text-left border transition-all rounded-sm flex items-center justify-between ${
                      config.dialFinish === item.id
                        ? 'border-[#d4af37] bg-[#1a1a22] text-[#f3e5ab]'
                        : 'border-[#222228] bg-[#0c0c0e] text-[#a0a0ab] hover:border-[#44444c]'
                    }`}
                  >
                    <span>{lang === 'zh' ? item.zh : item.label}</span>
                    {config.dialFinish === item.id && <Check className="w-3 h-3 text-[#d4af37]" />}
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Mechanical Complication */}
            <div className="space-y-2">
              <label className="text-xs font-cinzel tracking-widest text-[#f3e5ab] font-semibold block">
                3. {lang === 'zh' ? '机械复杂功能' : 'HOROLOGICAL COMPLICATION'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'flying-tourbillon', label: '60s Flying Tourbillon', zh: '一分钟飞行陀飞轮' },
                  { id: 'moonphase-lunar', label: 'Aesthetic Lunar Moonphase', zh: '东方月相与星空历' },
                  { id: 'three-hand-date', label: 'Central Three-Hand & Date', zh: '大三针与日历显示' },
                  { id: 'dual-time-zone', label: 'Dual-Time Zone GMT', zh: '双时区两地时间' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setConfig({ ...config, complication: item.id as any })}
                    className={`p-2.5 text-xs text-left border transition-all rounded-sm flex items-center justify-between ${
                      config.complication === item.id
                        ? 'border-[#d4af37] bg-[#1a1a22] text-[#f3e5ab]'
                        : 'border-[#222228] bg-[#0c0c0e] text-[#a0a0ab] hover:border-[#44444c]'
                    }`}
                  >
                    <span>{lang === 'zh' ? item.zh : item.label}</span>
                    {config.complication === item.id && <Check className="w-3 h-3 text-[#d4af37]" />}
                  </button>
                ))}
              </div>
            </div>

            {/* 4. AI Engraving Generator Prompt Input */}
            <div className="space-y-2 pt-2 border-t border-[#222228]">
              <div className="flex items-center justify-between">
                <label className="text-xs font-cinzel tracking-widest text-[#f3e5ab] font-semibold">
                  4. {lang === 'zh' ? '表背定制刻字主题 (Gemini AI 赋诗)' : 'AI CALLIGRAPHY ENGRAVING THEME'}
                </label>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={config.customEngraving}
                  onChange={(e) => setConfig({ ...config, customEngraving: e.target.value })}
                  placeholder={lang === 'zh' ? '例如：松柏长青、宁静致远、赠与父亲60大寿' : 'e.g. Enduring love, Family heritage, Pine tree in winter'}
                  className="flex-1 bg-[#09090b] border border-[#33333e] focus:border-[#d4af37] px-3 py-2 text-xs text-white outline-none rounded-sm"
                />

                <button
                  onClick={handleGenerateAiEngraving}
                  disabled={isGeneratingAi}
                  className="px-4 py-2 bg-gradient-to-r from-[#d4af37] to-[#aa771c] hover:opacity-90 text-black text-xs font-semibold flex items-center gap-1.5 transition-all rounded-sm disabled:opacity-50 whitespace-nowrap"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>{isGeneratingAi ? (lang === 'zh' ? 'AI赋诗中...' : 'Composing...') : (lang === 'zh' ? 'AI 智能赋诗' : 'AI Compose')}</span>
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-4 flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleOrder}
                className="flex-1 py-3 bg-[#d4af37] hover:bg-[#f3e5ab] text-black font-cinzel text-xs font-bold tracking-[0.2em] flex items-center justify-center gap-2 transition-all rounded-sm shadow-lg shadow-[#d4af37]/10"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{lang === 'zh' ? '预订定制时计' : 'ADD BESPOKE TO BAG'}</span>
              </button>

              <button
                onClick={() => {
                  onBookBoutique();
                  onClose();
                }}
                className="flex-1 py-3 border border-[#d4af37] text-[#f3e5ab] hover:bg-[#d4af37]/10 font-cinzel text-xs font-bold tracking-[0.2em] flex items-center justify-center gap-2 transition-all rounded-sm"
              >
                <Calendar className="w-4 h-4 text-[#d4af37]" />
                <span>{lang === 'zh' ? '预约大师工坊私享沟通' : 'BOOK ATELIER CONSULTATION'}</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
