'use client';

import React, { useState } from 'react';
import { ArrowRight, Check } from 'lucide-react';
import { Language } from '@/types/watch';

interface FooterProps {
  lang: Language;
  onOpenBespoke: () => void;
  onOpenBoutiques: () => void;
  onOpenJournal: () => void;
}

export default function Footer({
  lang,
  onOpenBespoke,
  onOpenBoutiques,
  onOpenJournal,
}: FooterProps) {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 4000);
      setEmail('');
    }
  };

  return (
    <footer className="bg-[#08080a] border-t border-[#1f1f24] text-[#a0a0ab] font-sans pt-16 pb-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 relative z-10">
        
        {/* Top Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-12 border-b border-[#1b1b20]">
          
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="vermilion-seal w-8 h-8 text-xs flex items-center justify-center font-bold">
                瑞时
              </div>
              <div className="flex flex-col">
                <span className="font-cinzel text-lg font-bold tracking-widest text-[#f3e5ab]">
                  RUI SHI
                </span>
                <span className="text-[9px] tracking-[0.25em] text-[#a0a0ab] uppercase font-light">
                  FINE WATCHES
                </span>
              </div>
            </div>

            <p className="text-xs leading-relaxed text-[#888892] max-w-sm">
              {lang === 'zh'
                ? '瑞时（RUI SHI）高级独立制表品牌，秉承“天人合一，与自然共时”之哲学，将中国山水水墨与瑞士高阶机械表艺融会贯通。'
                : 'Fine mechanical timepieces inspired by China’s timeless landscapes, crafted with Swiss-inspired horological precision for discerning collectors.'}
            </p>
          </div>

          {/* Nav Links */}
          <div className="md:col-span-3 space-y-3 font-cinzel text-xs">
            <h4 className="text-[#f3e5ab] font-semibold tracking-widest uppercase">
              {lang === 'zh' ? '瑞时时计' : 'COLLECTIONS & ATELIER'}
            </h4>
            <ul className="space-y-2 text-[#a0a0ab]">
              <li>
                <a href="#collections" className="hover:text-white transition-colors">
                  {lang === 'zh' ? '经典与大师系列' : 'The Collections'}
                </a>
              </li>
              <li>
                <button onClick={onOpenBespoke} className="hover:text-white transition-colors text-left">
                  {lang === 'zh' ? '高级私享定制工坊' : 'Bespoke Custom Studio'}
                </button>
              </li>
              <li>
                <button onClick={onOpenBoutiques} className="hover:text-white transition-colors text-left">
                  {lang === 'zh' ? '全球旗舰精品店' : 'Global Salons & Boutiques'}
                </button>
              </li>
              <li>
                <button onClick={onOpenJournal} className="hover:text-white transition-colors text-left">
                  {lang === 'zh' ? '钟表美学刊物' : 'Horology Journal'}
                </button>
              </li>
            </ul>
          </div>

          {/* Newsletter Subscription */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="font-cinzel text-xs text-[#f3e5ab] font-semibold tracking-widest uppercase">
              {lang === 'zh' ? '订阅瑞时私人特刊' : 'PRIVÉ GAZETTE SUBSCRIPTION'}
            </h4>
            <p className="text-[11px] text-[#888892]">
              {lang === 'zh'
                ? '第一时间优先获取限量版新机芯发布与大师展会邀请'
                : 'Receive exclusive invitations to private salon exhibitions and limited release previews.'}
            </p>

            <form onSubmit={handleSubscribe} className="flex items-center gap-2">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={lang === 'zh' ? '您的尊贵电子邮箱' : 'Enter your email address'}
                className="bg-[#101014] border border-[#222228] focus:border-[#d4af37] px-3 py-2 text-xs text-white outline-none flex-1 rounded-none"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-[#d4af37] text-black hover:bg-[#f3e5ab] font-cinzel text-xs font-bold transition-all shrink-0"
              >
                {subscribed ? <Check className="w-4 h-4 text-black" /> : <ArrowRight className="w-4 h-4" />}
              </button>
            </form>
          </div>

        </div>

        {/* Bottom Legal & Copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#888892] font-mono gap-4">
          <div>
            © {new Date().getFullYear()} RUI SHI FINE WATCHES S.A. ALL RIGHTS RESERVED.
          </div>
          <div className="flex items-center gap-6">
            <span>TERMS OF SERVICE</span>
            <span>PRIVACY POLICY</span>
            <span>SWISS-ORIENTAL HOROLOGY</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
