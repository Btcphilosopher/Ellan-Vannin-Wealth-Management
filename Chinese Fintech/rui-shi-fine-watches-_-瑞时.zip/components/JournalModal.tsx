'use client';

import React from 'react';
import Image from 'next/image';
import { X, Clock } from 'lucide-react';
import { JournalArticle } from '@/lib/data';
import { Language } from '@/types/watch';

interface JournalModalProps {
  article: JournalArticle;
  lang: Language;
  onClose: () => void;
}

export default function JournalModal({ article, lang, onClose }: JournalModalProps) {
  const content = lang === 'zh' ? article.chineseContent : article.content;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-[#101014] border border-[#d4af37]/40 w-full max-w-3xl my-auto shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#222228] flex items-center justify-between bg-[#0b0b0e]">
          <span className="font-cinzel text-xs tracking-widest text-[#d4af37] font-semibold">
            RUI SHI HOROLOGY JOURNAL
          </span>
          <button onClick={onClose} className="p-1 text-[#888892] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-6">
          <div className="relative aspect-[16/9] w-full border border-[#222228] overflow-hidden bg-black">
            <Image
              src={article.image}
              alt={article.title}
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-3 text-xs font-mono text-[#d4af37]">
              <span>{article.date}</span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {article.readTime}
              </span>
            </div>

            <h1 className="font-cinzel text-xl sm:text-2xl font-bold text-[#f8f8fa]">
              {lang === 'zh' ? article.chineseTitle : article.title}
            </h1>

            <p className="font-serif-luxury italic text-sm text-[#c5a059]">
              {lang === 'zh' ? article.chineseSubtitle : article.subtitle}
            </p>
          </div>

          <div className="space-y-4 text-xs sm:text-sm text-[#d1d1d6] leading-relaxed border-t border-[#222228] pt-4">
            {content.map((p, idx) => (
              <p key={idx}>{p}</p>
            ))}
          </div>

          <div className="pt-6 border-t border-[#222228] flex items-center justify-between text-xs font-mono text-[#888892]">
            <span>Published by Rui Shi Fine Watches Atelier</span>
            <div className="vermilion-seal w-6 h-6 text-[10px] flex items-center justify-center font-bold">
              瑞
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
