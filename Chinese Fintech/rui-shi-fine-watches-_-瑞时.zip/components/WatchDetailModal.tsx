'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Volume2, VolumeX, ShieldCheck, ShoppingBag, Calendar, Check } from 'lucide-react';
import { Language, WatchItem } from '@/types/watch';

interface WatchDetailModalProps {
  watch: WatchItem;
  lang: Language;
  onClose: () => void;
  onAddToCart: (watch: WatchItem) => void;
  onBookBoutique: (watchName: string) => void;
}

export default function WatchDetailModal({
  watch,
  lang,
  onClose,
  onAddToCart,
  onBookBoutique,
}: WatchDetailModalProps) {
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [added, setAdded] = useState(false);

  const toggleSound = () => {
    setIsPlayingAudio(!isPlayingAudio);
    if (!isPlayingAudio) {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const playTick = (delay: number) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(1400, audioCtx.currentTime + delay);
        osc.frequency.exponentialRampToValueAtTime(350, audioCtx.currentTime + delay + 0.02);
        gain.gain.setValueAtTime(0.06, audioCtx.currentTime + delay);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + delay + 0.02);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(audioCtx.currentTime + delay);
        osc.stop(audioCtx.currentTime + delay + 0.025);
      };

      for (let i = 0; i < 20; i++) {
        playTick(i * 0.125);
      }
      setTimeout(() => setIsPlayingAudio(false), 2600);
    }
  };

  const handleAdd = () => {
    onAddToCart(watch);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-[#101014] border border-[#d4af37]/40 w-full max-w-4xl my-auto shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header Bar */}
        <div className="px-6 py-4 border-b border-[#222228] flex items-center justify-between bg-[#0b0b0e]">
          <div className="flex items-center gap-2">
            <span className="font-cinzel text-xs tracking-widest text-[#d4af37] uppercase">
              {watch.category.toUpperCase()} COLLECTION
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#888892] hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 overflow-y-auto flex-1">
          
          {/* Left Column: Macro Photography & Sound Simulator */}
          <div className="md:col-span-6 bg-[#08080a] p-6 border-b md:border-b-0 md:border-r border-[#222228] flex flex-col justify-between">
            <div className="relative aspect-square w-full border border-[#1f1f24] overflow-hidden bg-black mb-4">
              <Image
                src={watch.image}
                alt={watch.name}
                fill
                className="object-cover object-center scale-100 hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="flex items-center justify-between bg-[#14141a] p-3 border border-[#222228]">
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleSound}
                  className="p-2 bg-[#d4af37]/10 hover:bg-[#d4af37]/20 border border-[#d4af37] text-[#d4af37] rounded-full transition-colors"
                >
                  {isPlayingAudio ? (
                    <Volume2 className="w-4 h-4 animate-pulse" />
                  ) : (
                    <VolumeX className="w-4 h-4" />
                  )}
                </button>
                <span className="text-xs text-[#d1d1d6] font-mono">
                  {isPlayingAudio ? 'Calibre Beat: 28,800 vph...' : 'Listen to Mechanical Calibre Beat'}
                </span>
              </div>

              <div className="vermilion-seal w-6 h-6 text-[10px] flex items-center justify-center font-bold">
                瑞
              </div>
            </div>
          </div>

          {/* Right Column: Spec Sheet & Actions */}
          <div className="md:col-span-6 p-6 space-y-6 flex flex-col justify-between bg-[#101014]">
            <div className="space-y-4">
              <div>
                <h2 className="font-cinzel text-xl sm:text-2xl font-bold text-[#f8f8fa]">
                  {lang === 'zh' ? watch.chineseName : watch.name}
                </h2>
                <p className="font-serif-luxury italic text-sm text-[#d4af37] pt-1">
                  {lang === 'zh' ? watch.chineseTagline : watch.tagline}
                </p>
              </div>

              <div className="text-xl font-mono text-[#f3e5ab] font-bold">
                {lang === 'zh'
                  ? `¥ ${watch.priceRMB.toLocaleString()}`
                  : `$ ${watch.priceUSD.toLocaleString()}`}
              </div>

              <p className="text-xs text-[#a0a0ab] leading-relaxed">
                {lang === 'zh' ? watch.chineseDescription : watch.description}
              </p>

              {/* Technical Specifications Table */}
              <div className="space-y-2 pt-2 border-t border-[#222228]">
                <h3 className="font-cinzel text-xs font-semibold text-[#f3e5ab] tracking-widest uppercase">
                  {lang === 'zh' ? '机芯与技术规格' : 'TECHNICAL SPECIFICATIONS'}
                </h3>

                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs font-mono">
                  <div className="border-b border-[#1c1c22] pb-1">
                    <span className="text-[#888892] block text-[10px]">CASE DIAMETER</span>
                    <span className="text-[#e5e5e7]">{watch.specs.caseDiameter}</span>
                  </div>
                  <div className="border-b border-[#1c1c22] pb-1">
                    <span className="text-[#888892] block text-[10px]">CASE THICKNESS</span>
                    <span className="text-[#e5e5e7]">{watch.specs.caseThickness}</span>
                  </div>
                  <div className="border-b border-[#1c1c22] pb-1">
                    <span className="text-[#888892] block text-[10px]">POWER RESERVE</span>
                    <span className="text-[#e5e5e7]">{watch.specs.powerReserve}</span>
                  </div>
                  <div className="border-b border-[#1c1c22] pb-1">
                    <span className="text-[#888892] block text-[10px]">FREQUENCY</span>
                    <span className="text-[#e5e5e7]">{watch.specs.frequency}</span>
                  </div>
                  <div className="border-b border-[#1c1c22] pb-1 col-span-2">
                    <span className="text-[#888892] block text-[10px]">MANUFACTURE MOVEMENT</span>
                    <span className="text-[#e5e5e7]">{watch.specs.movement}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-4 border-t border-[#222228] flex flex-col gap-2">
              <button
                onClick={handleAdd}
                className="w-full py-3 bg-[#d4af37] hover:bg-[#f3e5ab] text-black font-cinzel text-xs font-bold tracking-[0.2em] flex items-center justify-center gap-2 transition-all rounded-sm"
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4 text-black" />
                    <span>{lang === 'zh' ? '已加入典藏购物袋' : 'ADDED TO SHOPPING BAG'}</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>{lang === 'zh' ? '预订此款臻品' : 'RESERVE TIMEPIECE'}</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  onBookBoutique(watch.name);
                  onClose();
                }}
                className="w-full py-2.5 border border-[#33333e] text-[#d1d1d6] hover:border-[#d4af37] hover:text-[#f3e5ab] font-cinzel text-xs tracking-[0.15em] flex items-center justify-center gap-2 transition-all rounded-sm"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>{lang === 'zh' ? '预约旗舰店专属试戴' : 'BOOK BOUTIQUE FITTING'}</span>
              </button>

              <div className="flex items-center justify-center gap-2 text-[10px] text-[#888892] pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>5-Year Official Global Warranty & Certificate of Authenticity</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
