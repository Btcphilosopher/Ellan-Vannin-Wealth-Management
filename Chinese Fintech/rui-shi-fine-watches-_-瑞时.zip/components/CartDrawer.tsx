'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Trash2, ShieldCheck, ShoppingBag, ArrowRight, CheckCircle2 } from 'lucide-react';
import { CartItem, Language } from '@/types/watch';

interface CartDrawerProps {
  cart: CartItem[];
  lang: Language;
  onClose: () => void;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  cart,
  lang,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'checkout' | 'confirmed'>('cart');
  const [orderRef, setOrderRef] = useState('');
  const [customerInfo, setCustomerInfo] = useState({
    name: 'Tom',
    email: 'tom@ahyx.org',
    address: 'No. 8 Mayfair Square',
    city: 'London',
    country: 'United Kingdom',
    phone: '+44 20 7946 0912',
  });

  const totalUSD = cart.reduce(
    (sum, item) => sum + (item.customPriceUSD || item.watch.priceUSD) * item.quantity,
    0
  );
  const totalRMB = totalUSD * 6.9;

  const handleCompleteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const randomNum = Math.floor(100000 + Math.random() * 900000);
    setOrderRef(`#RSI-2026-${randomNum}`);
    setCheckoutStep('confirmed');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex justify-end">
      <div className="bg-[#101014] border-l border-[#d4af37]/30 w-full max-w-md h-full flex flex-col justify-between shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-[#222228] flex items-center justify-between bg-[#0b0b0e]">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
            <h2 className="font-cinzel text-sm font-bold tracking-[0.2em] text-[#f8f8fa] uppercase">
              {lang === 'zh' ? '瑞时典藏购物袋' : 'YOUR SHOPPING BAG'}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#888892] hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {checkoutStep === 'cart' && (
            <>
              {cart.length === 0 ? (
                <div className="py-20 text-center space-y-4">
                  <div className="vermilion-seal w-10 h-10 text-base mx-auto flex items-center justify-center font-bold">
                    瑞
                  </div>
                  <p className="font-serif-luxury text-sm text-[#888892] italic">
                    {lang === 'zh' ? '您的购物袋暂无臻品' : 'Your shopping bag is currently empty.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div
                      key={item.watch.id}
                      className="flex gap-4 p-3 bg-[#16161d] border border-[#222228] relative"
                    >
                      <div className="relative w-20 h-20 bg-black border border-[#2a2a32] shrink-0">
                        <Image
                          src={item.watch.image}
                          alt={item.watch.name}
                          fill
                          className="object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      <div className="flex-1 space-y-1">
                        <h4 className="font-cinzel text-xs font-bold text-[#f8f8fa]">
                          {lang === 'zh' ? item.watch.chineseName : item.watch.name}
                        </h4>
                        <p className="text-[10px] text-[#888892] font-mono">
                          {item.watch.specs.caseMaterial} · {item.watch.specs.caliber}
                        </p>
                        <div className="font-mono text-xs text-[#d4af37] font-bold">
                          {lang === 'zh'
                            ? `¥ ${(item.watch.priceRMB * item.quantity).toLocaleString()}`
                            : `$ ${((item.customPriceUSD || item.watch.priceUSD) * item.quantity).toLocaleString()}`}
                        </div>

                        {/* Quantity controls */}
                        <div className="flex items-center gap-3 pt-1">
                          <div className="flex items-center border border-[#33333e] text-xs font-mono">
                            <button
                              onClick={() => onUpdateQuantity(item.watch.id, -1)}
                              className="px-2 py-0.5 hover:bg-[#222228] text-[#d1d1d6]"
                            >
                              -
                            </button>
                            <span className="px-2.5 py-0.5 text-[#f8f8fa]">{item.quantity}</span>
                            <button
                              onClick={() => onUpdateQuantity(item.watch.id, 1)}
                              className="px-2 py-0.5 hover:bg-[#222228] text-[#d1d1d6]"
                            >
                              +
                            </button>
                          </div>

                          <button
                            onClick={() => onRemoveItem(item.watch.id)}
                            className="text-[#888892] hover:text-[#c82323] transition-colors p-1"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {checkoutStep === 'checkout' && (
            <form onSubmit={handleCompleteOrder} className="space-y-4 text-xs">
              <h3 className="font-cinzel text-xs font-bold text-[#f3e5ab] tracking-widest border-b border-[#222228] pb-2">
                {lang === 'zh' ? '尊享专递配送地址' : 'INSURED EXPRESS DELIVERY ADDRESS'}
              </h3>

              <div className="space-y-3">
                <div>
                  <label className="text-[10px] text-[#888892] block mb-1">FULL NAME</label>
                  <input
                    type="text"
                    required
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                    className="w-full bg-[#08080a] border border-[#33333e] p-2.5 text-white outline-none focus:border-[#d4af37]"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-[#888892] block mb-1">EMAIL ADDRESS</label>
                  <input
                    type="email"
                    required
                    value={customerInfo.email}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
                    className="w-full bg-[#08080a] border border-[#33333e] p-2.5 text-white outline-none focus:border-[#d4af37]"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-[#888892] block mb-1">SHIPPING ADDRESS</label>
                  <input
                    type="text"
                    required
                    value={customerInfo.address}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, address: e.target.value })}
                    className="w-full bg-[#08080a] border border-[#33333e] p-2.5 text-white outline-none focus:border-[#d4af37]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-[#888892] block mb-1">CITY</label>
                    <input
                      type="text"
                      required
                      value={customerInfo.city}
                      onChange={(e) => setCustomerInfo({ ...customerInfo, city: e.target.value })}
                      className="w-full bg-[#08080a] border border-[#33333e] p-2.5 text-white outline-none focus:border-[#d4af37]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#888892] block mb-1">COUNTRY</label>
                    <input
                      type="text"
                      required
                      value={customerInfo.country}
                      onChange={(e) => setCustomerInfo({ ...customerInfo, country: e.target.value })}
                      className="w-full bg-[#08080a] border border-[#33333e] p-2.5 text-white outline-none focus:border-[#d4af37]"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-[#d4af37] text-black font-cinzel text-xs font-bold tracking-widest hover:bg-[#f3e5ab] transition-all"
                >
                  {lang === 'zh' ? '确认并预订订单' : 'CONFIRM & PLACE RESERVATION'}
                </button>
              </div>
            </form>
          )}

          {checkoutStep === 'confirmed' && (
            <div className="py-12 text-center space-y-4">
              <div className="w-12 h-12 bg-[#d4af37]/20 border border-[#d4af37] text-[#d4af37] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="font-cinzel text-base font-bold text-[#f3e5ab]">
                {lang === 'zh' ? '订单已尊享预订成功' : 'RESERVATION CONFIRMED'}
              </h3>
              <p className="text-xs text-[#a0a0ab] max-w-xs mx-auto leading-relaxed">
                {lang === 'zh'
                  ? `尊贵的大师级服务顾问将在1小时内联系您 (${customerInfo.email})，为您安排全额保价尊尚特快专递与官方认证。`
                  : `Our Senior Concierge will contact you at ${customerInfo.email} within 1 hour to finalize insured delivery.`}
              </p>
              <div className="p-3 bg-[#16161d] border border-[#222228] text-[11px] font-mono text-[#d4af37]">
                ORDER REF: {orderRef || '#RSI-2026-888888'}
              </div>
              <button
                onClick={() => {
                  onClearCart();
                  onClose();
                }}
                className="px-6 py-2 border border-[#d4af37] text-[#f3e5ab] font-cinzel text-xs tracking-widest"
              >
                {lang === 'zh' ? '返回精品平台' : 'RETURN TO PLATFORM'}
              </button>
            </div>
          )}
        </div>

        {/* Footer Bar */}
        {cart.length > 0 && checkoutStep === 'cart' && (
          <div className="p-6 border-t border-[#222228] bg-[#0b0b0e] space-y-4">
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-[#888892]">
                <span>INSURED GLOBAL EXPRESS</span>
                <span className="text-[#d4af37] font-mono">COMPLIMENTARY</span>
              </div>
              <div className="flex justify-between text-base font-mono font-bold text-[#f8f8fa] pt-1">
                <span>TOTAL</span>
                <span className="text-[#d4af37]">
                  {lang === 'zh'
                    ? `¥ ${totalRMB.toLocaleString()}`
                    : `$ ${totalUSD.toLocaleString()}`}
                </span>
              </div>
            </div>

            <button
              onClick={() => setCheckoutStep('checkout')}
              className="w-full py-3 bg-[#d4af37] hover:bg-[#f3e5ab] text-black font-cinzel text-xs font-bold tracking-[0.2em] flex items-center justify-center gap-2 transition-all"
            >
              <span>{lang === 'zh' ? '前往尊尚安全结账' : 'PROCEED TO CHECKOUT'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-2 text-[10px] text-[#888892]">
              <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
              <span>Full Insurance Coverage & Concierge Dispatch</span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
