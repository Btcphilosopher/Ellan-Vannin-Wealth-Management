export type CollectionCategory = 'all' | 'classic' | 'heritage' | 'sport' | 'masters';

export interface WatchItem {
  id: string;
  name: string;
  chineseName: string;
  category: 'classic' | 'heritage' | 'sport' | 'masters';
  tagline: string;
  chineseTagline: string;
  priceUSD: number;
  priceRMB: number;
  image: string;
  description: string;
  chineseDescription: string;
  specs: {
    caseDiameter: string;
    caseThickness: string;
    caseMaterial: string;
    movement: string;
    caliber: string;
    powerReserve: string;
    frequency: string;
    jewels: number;
    waterResistance: string;
    dialFinish: string;
    strap: string;
  };
  inStock: boolean;
  featured?: boolean;
}

export interface BespokeOption {
  caseMaterial: '18k-rose-gold' | 'platinum-950' | 'titanium-grade-5' | 'damascus-steel';
  dialFinish: 'shanshui-ink' | 'jade-enamel' | 'cloisonne-dragon' | 'midnight-skeleton';
  strapMaterial: 'alligator-black' | 'alligator-cognac' | 'silk-cordovan' | 'integrated-steel';
  complication: 'three-hand-date' | 'moonphase-lunar' | 'flying-tourbillon' | 'dual-time-zone';
  customEngraving: string;
}

export interface CartItem {
  watch: WatchItem;
  quantity: number;
  bespokeConfig?: BespokeOption;
  customPriceUSD?: number;
}

export type Language = 'en' | 'zh';
