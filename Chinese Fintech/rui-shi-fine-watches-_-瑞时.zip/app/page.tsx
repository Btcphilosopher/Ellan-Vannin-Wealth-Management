'use client';

import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import HeritageSection from '@/components/HeritageSection';
import CollectionsSection from '@/components/CollectionsSection';
import GuaranteeBar from '@/components/GuaranteeBar';
import BespokeStudio from '@/components/BespokeStudio';
import WatchDetailModal from '@/components/WatchDetailModal';
import CartDrawer from '@/components/CartDrawer';
import JournalSection from '@/components/JournalSection';
import JournalModal from '@/components/JournalModal';
import BoutiqueModal from '@/components/BoutiqueModal';
import Footer from '@/components/Footer';

import { WATCHES, JournalArticle } from '@/lib/data';
import { BespokeOption, CartItem, Language, WatchItem } from '@/types/watch';
import { Search, X } from 'lucide-react';

export default function HomePage() {
  const [lang, setLang] = useState<Language>('en');
  const [cart, setCart] = useState<CartItem[]>([]);
  
  // Modals & Drawers state
  const [selectedWatch, setSelectedWatch] = useState<WatchItem | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<JournalArticle | null>(null);
  const [isBespokeOpen, setIsBespokeOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isBoutiqueOpen, setIsBoutiqueOpen] = useState(false);
  const [boutiqueWatchInterest, setBoutiqueWatchInterest] = useState<string | undefined>(undefined);
  
  // Search Overlay
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const toggleLang = () => {
    setLang((prev) => (prev === 'en' ? 'zh' : 'en'));
  };

  const handleAddToCart = (watch: WatchItem) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.watch.id === watch.id);
      if (existing) {
        return prev.map((item) =>
          item.watch.id === watch.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { watch, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleAddBespokeToCart = (customWatch: WatchItem, bespokeConfig: BespokeOption) => {
    setCart((prev) => [
      ...prev,
      {
        watch: customWatch,
        quantity: 1,
        bespokeConfig,
        customPriceUSD: customWatch.priceUSD,
      },
    ]);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.watch.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (id: string) => {
    setCart((prev) => prev.filter((item) => item.watch.id !== id));
  };

  const handleOpenBoutique = (watchName?: string) => {
    setBoutiqueWatchInterest(watchName);
    setIsBoutiqueOpen(true);
  };

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Filtered search results
  const searchResults = searchQuery
    ? WATCHES.filter(
        (w) =>
          w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          w.chineseName.includes(searchQuery) ||
          w.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
          w.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <div className="min-h-screen bg-[#0d0d0e] text-[#e5e5e7] flex flex-col font-sans selection:bg-[#c5a059] selection:text-black">
      {/* Top Navbar */}
      <Navbar
        lang={lang}
        onToggleLang={toggleLang}
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAccount={() => handleOpenBoutique('VIP Member Lounge Access')}
        onOpenBespoke={() => setIsBespokeOpen(true)}
        onNavigate={scrollToSection}
      />

      {/* Main Page Content */}
      <main className="flex-1">
        {/* 1. Hero Section */}
        <HeroSection
          lang={lang}
          heroWatch={WATCHES[0]}
          onExploreCollections={() => scrollToSection('collections')}
          onSelectWatch={(watch) => setSelectedWatch(watch)}
        />

        {/* 2. Heritage Section */}
        <HeritageSection
          lang={lang}
          onOpenJournal={() => scrollToSection('journal')}
        />

        {/* 3. The Collections Grid */}
        <CollectionsSection
          lang={lang}
          watches={WATCHES}
          onSelectWatch={(watch) => setSelectedWatch(watch)}
          onAddToCart={handleAddToCart}
          onOpenBespoke={() => setIsBespokeOpen(true)}
        />

        {/* 4. Journal Section */}
        <JournalSection
          lang={lang}
          onSelectArticle={(article) => setSelectedArticle(article)}
        />

        {/* 5. Guarantee & Trust Bar */}
        <GuaranteeBar lang={lang} />
      </main>

      {/* Footer */}
      <Footer
        lang={lang}
        onOpenBespoke={() => setIsBespokeOpen(true)}
        onOpenBoutiques={() => handleOpenBoutique()}
        onOpenJournal={() => scrollToSection('journal')}
      />

      {/* Modals & Slide-out Drawers */}

      {/* Watch Detail Modal */}
      {selectedWatch && (
        <WatchDetailModal
          watch={selectedWatch}
          lang={lang}
          onClose={() => setSelectedWatch(null)}
          onAddToCart={handleAddToCart}
          onBookBoutique={(name) => handleOpenBoutique(name)}
        />
      )}

      {/* Bespoke Custom Studio Modal */}
      {isBespokeOpen && (
        <BespokeStudio
          lang={lang}
          onClose={() => setIsBespokeOpen(false)}
          onAddBespokeToCart={handleAddBespokeToCart}
          onBookBoutique={() => handleOpenBoutique('Bespoke Atelier Design Session')}
        />
      )}

      {/* Journal Article Modal */}
      {selectedArticle && (
        <JournalModal
          article={selectedArticle}
          lang={lang}
          onClose={() => setSelectedArticle(null)}
        />
      )}

      {/* Boutique Reservation Modal */}
      {isBoutiqueOpen && (
        <BoutiqueModal
          lang={lang}
          initialWatchName={boutiqueWatchInterest}
          onClose={() => setIsBoutiqueOpen(false)}
        />
      )}

      {/* Cart Drawer */}
      {isCartOpen && (
        <CartDrawer
          cart={cart}
          lang={lang}
          onClose={() => setIsCartOpen(false)}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveItem}
          onClearCart={() => setCart([])}
        />
      )}

      {/* Search Drawer Overlay */}
      {isSearchOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-start justify-center pt-20 px-4">
          <div className="bg-[#121216] border border-[#d4af37]/40 w-full max-w-2xl p-6 shadow-2xl relative space-y-4">
            <button
              onClick={() => setIsSearchOpen(false)}
              className="absolute top-4 right-4 p-1 text-[#888892] hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-[#33333e] pb-3">
              <Search className="w-5 h-5 text-[#d4af37]" />
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={
                  lang === 'zh'
                    ? '搜索时计作品（如：曜石、飞轮、绿生、经典...）'
                    : 'Search timepieces, complications, materials...'
                }
                className="w-full bg-transparent text-base text-white outline-none placeholder-[#666670]"
              />
            </div>

            {searchQuery && (
              <div className="space-y-3 max-h-80 overflow-y-auto pt-2">
                {searchResults.length === 0 ? (
                  <p className="text-xs text-[#888892] italic text-center py-6">
                    {lang === 'zh' ? '未找到符合条件的时计作品' : 'No timepieces found matching your search.'}
                  </p>
                ) : (
                  searchResults.map((watch) => (
                    <div
                      key={watch.id}
                      onClick={() => {
                        setSelectedWatch(watch);
                        setIsSearchOpen(false);
                      }}
                      className="p-3 bg-[#181820] hover:bg-[#22222d] cursor-pointer flex items-center justify-between border border-[#222228] transition-colors"
                    >
                      <div>
                        <h4 className="font-cinzel text-xs font-bold text-[#f8f8fa]">
                          {lang === 'zh' ? watch.chineseName : watch.name}
                        </h4>
                        <p className="text-[10px] text-[#888892] font-mono">
                          {watch.category.toUpperCase()} COLLECTION · {watch.specs.caseMaterial}
                        </p>
                      </div>

                      <span className="font-mono text-xs text-[#d4af37] font-bold">
                        {lang === 'zh'
                          ? `¥ ${watch.priceRMB.toLocaleString()}`
                          : `$ ${watch.priceUSD.toLocaleString()}`}
                      </span>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
