import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Rui Shi Fine Watches | 瑞时 — Time in Harmony with Nature',
  description: 'Fine mechanical watches inspired by China\'s timeless landscapes, crafted for a modern world with Swiss-inspired horological precision.',
  openGraph: {
    title: 'Rui Shi Fine Watches | 瑞时 — Time in Harmony with Nature',
    description: 'Fine mechanical watches inspired by China\'s timeless landscapes, crafted for a modern world with Swiss-inspired horological precision.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Rui Shi Fine Watches | 瑞时',
    description: 'Fine mechanical watches inspired by China\'s timeless landscapes, crafted for a modern world.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className="bg-[#0d0d0e] text-[#e5e5e7] antialiased selection:bg-[#c5a059] selection:text-black" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
