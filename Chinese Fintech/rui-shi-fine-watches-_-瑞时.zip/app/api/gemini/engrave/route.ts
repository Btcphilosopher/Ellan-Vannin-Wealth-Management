import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'Gemini API key is not configured.' },
        { status: 500 }
      );
    }

    const { concept, caseMaterial, dialFinish, lang } = await req.json();

    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = `You are a master Chinese horology artisan and poet for "Rui Shi Fine Watches" (瑞时).
    When a luxury client requests a custom engraving or motif story for their bespoke timepiece, you compose:
    1. A short, poetic caseback engraving text (max 12 Chinese characters AND a matching elegant English motto).
    2. A brief 2-sentence poetic backstory of how this motif matches the timepiece's craftsmanship (${caseMaterial}, ${dialFinish}).
    3. Return strictly valid JSON with no markdown formatting around it:
    {
      "chineseInscription": "...",
      "englishMotto": "...",
      "poeticStory": "..."
    }`;

    const prompt = `Client requested bespoke theme concept: "${concept || 'Harmonious nature and enduring time'}".
    Case metal: ${caseMaterial || '18K Rose Gold'}, Dial: ${dialFinish || 'Shanshui Enamel'}.
    Compose the bespoke engraving motto and backstory.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    let data;
    try {
      data = JSON.parse(responseText);
    } catch {
      data = {
        chineseInscription: '与自然共时 匠心传百年',
        englishMotto: 'In Harmony with Nature, Crafted for Eternity',
        poeticStory: 'A timeless union of natural balance and mechanical perfection, hand-engraved upon precious metal.'
      };
    }

    return NextResponse.json(data);
  } catch (error: any) {
    console.error('Gemini API engraving generation error:', error);
    return NextResponse.json(
      {
        chineseInscription: '与自然共时 匠心传百年',
        englishMotto: 'In Harmony with Nature, Crafted for Eternity',
        poeticStory: 'A timeless union of natural balance and mechanical perfection, hand-engraved upon precious metal.'
      },
      { status: 200 }
    );
  }
}
