import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '赤焰咖啡 OS — Chiyan Coffee OS',
  description: '赤焰咖啡 OS (CHIYAN COFFEE OS) — 专为城市打造的智能咖啡门店与运营管理系统 (Roasted for the City, Enterprise Café Operating System)',
  openGraph: {
    title: '赤焰咖啡 OS — Chiyan Coffee OS',
    description: '赤焰咖啡 OS (CHIYAN COFFEE OS) — 专为城市打造的智能咖啡门店与运营管理系统 (Roasted for the City, Enterprise Café Operating System)',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '赤焰咖啡 OS — Chiyan Coffee OS',
    description: '赤焰咖啡 OS (CHIYAN COFFEE OS) — 专为城市打造的智能咖啡门店与运营管理系统 (Roasted for the City, Enterprise Café Operating System)',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="zh-CN">
      <body suppressHydrationWarning className="bg-[#FFFDF8] text-[#171313] antialiased min-h-screen font-sans">
        {children}
      </body>
    </html>
  );
}
