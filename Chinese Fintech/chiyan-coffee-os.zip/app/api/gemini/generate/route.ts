import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

// Initialize the GoogleGenAI client with server secret and telemetry user-agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

export async function POST(req: NextRequest) {
  try {
    const { systemInstruction, prompt, isJson } = await req.json();

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        { 
          text: "赤焰咖啡 AI 系统未检测到 GEMINI_API_KEY 环境变量。请在「设置 > 密钥」中配置后再使用 AI 决策顾问。 (AI Key not configured. Please add GEMINI_API_KEY in Settings > Secrets to enable Chiyan AI Consultant.)",
          error: "Missing GEMINI_API_KEY"
        },
        { status: 200 } // Return graceful message to client
      );
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt || "你好，我是赤焰咖啡 OS 的 AI 商业顾问。请提供分析数据或提问。",
      config: {
        systemInstruction: systemInstruction || "你是一位精通中国新零售咖啡行业的资深商业分析师和技术专家。你说话严谨、专业、富有洞察力，主要使用中文回答。你为「赤焰咖啡 CHÌYÀN COFFEE」提供最先进的数字化、供应链和门店运营决策支持。回答中避免过于浮夸的话术，专注技术深度、数据支持和可操作的商业秩序建议。",
        responseMimeType: isJson ? "application/json" : "text/plain",
      },
    });

    return NextResponse.json({ text: response.text || "" });
  } catch (error: any) {
    console.error("Gemini API server-side error:", error);
    return NextResponse.json(
      { 
        text: `赤焰 AI 服务暂时不可用。错误原因: ${error?.message || "未知错误"}`,
        error: error?.message || "Internal Error"
      },
      { status: 500 }
    );
  }
}
