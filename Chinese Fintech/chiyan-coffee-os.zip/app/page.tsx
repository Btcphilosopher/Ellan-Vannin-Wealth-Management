"use client";

import { useState, useEffect } from "react";
import { 
  Flame, 
  Smartphone, 
  Coffee, 
  Cpu, 
  TrendingUp, 
  Sparkles, 
  RefreshCw, 
  CheckCircle, 
  X, 
  HelpCircle,
  Clock,
  ArrowRight
} from "lucide-react";

// Types & Mock Data Imports
import { Order, OrderStatus, OrderType, Store, IngredientBalance, Equipment, SimulationMode, UserRole } from "../lib/types";
import { fictionalStores, fictionalInventory, fictionalEquipment, initialPointsLedger, translations } from "../lib/mockData";

// Modular UI Panels
import CustomerApp from "../components/CustomerApp";
import BaristaConsole from "../components/BaristaConsole";
import DigitalTwin from "../components/DigitalTwin";
import AnalyticsConsole from "../components/AnalyticsConsole";
import AiConsultant from "../components/AiConsultant";

export default function Page() {
  // Global Settings
  const [lang, setLang] = useState<"zh-CN" | "en-GB">("zh-CN");
  const [activeRole, setActiveRole] = useState<UserRole>(UserRole.CUSTOMER);

  // Core Orchestrated Shared States
  const [selectedStore, setSelectedStore] = useState<Store>(fictionalStores[0]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [inventory, setInventory] = useState<IngredientBalance[]>(fictionalInventory);
  const [equipment, setEquipment] = useState<Equipment[]>(fictionalEquipment);
  const [pointsLedger, setPointsLedger] = useState(initialPointsLedger);

  // Simulation Engine states
  const [simulationActive, setSimulationActive] = useState<boolean>(true);
  const [simulationMode, setSimulationMode] = useState<SimulationMode>(SimulationMode.NORMAL);

  // Handle store updates
  const handleSelectStore = (store: Store) => {
    setSelectedStore(store);
  };

  // Add new order callback from customer app
  const handleAddOrder = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);

    // Track points earned
    if (newOrder.pointsAwarded > 0) {
      const generatedTxId = `CY-TX-${Math.floor(1000 + Math.random() * 9000)}`;
      const newPointsTx = {
        id: generatedTxId,
        memberId: "CY-MEM-8041",
        memberName: "林先生",
        amount: newOrder.pointsAwarded,
        type: "earn" as const,
        reason: `点购饮品获得积分 (${newOrder.items[0]?.product.name || "咖啡"})`,
        orderId: newOrder.id,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19)
      };
      setPointsLedger(prev => [newPointsTx, ...prev]);
    }

    // Deduct stock immediately
    setInventory(prev => {
      return prev.map(item => {
        // Find if this ingredient is used in any purchased product
        const orderItem = newOrder.items.find(i => {
          if (item.category === "beans" && i.product.traceabilityId === item.id) return true;
          if (item.id === "CY-MILK-OAT" && i.customization.milk === "燕麦奶") return true;
          if (item.id === "CY-MILK-FRESH" && i.customization.milk === "全脂牛奶") return true;
          if (item.id === "CY-SYRUP-OSM" && i.product.name.includes("桂花")) return true;
          if (item.id === "CY-PKG-CUP") return true;
          return false;
        });

        if (orderItem) {
          const deductAmt = item.category === "packaging" ? orderItem.quantity : 0.5 * orderItem.quantity;
          const remaining = item.stockOnHand - deductAmt;
          return {
            ...item,
            stockOnHand: remaining < 0 ? 0 : Number(remaining.toFixed(2))
          };
        }
        return item;
      });
    });

    // Update selected store queue density indicators
    setSelectedStore(prev => ({
      ...prev,
      queueLength: prev.queueLength + 1,
      avgPrepTime: prev.avgPrepTime + 1
    }));
  };

  // Barista console update order state callback
  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));

    // If completed or cancelled, lower queue length in selected store state
    if (status === OrderStatus.COMPLETED || status === OrderStatus.CANCELLED) {
      setSelectedStore(prev => ({
        ...prev,
        queueLength: prev.queueLength > 0 ? prev.queueLength - 1 : 0,
        avgPrepTime: prev.avgPrepTime > 2 ? prev.avgPrepTime - 1 : 2
      }));
    }
  };

  // Barista console trigger beverage remake callback
  const handleTriggerRemake = (orderId: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: OrderStatus.QUEUED } : o));
    
    // Log negative point adjust as waste audit trail
    const generatedTxId = `CY-TX-W${Math.floor(1000 + Math.random() * 9000)}`;
    const remakePointsTx = {
      id: generatedTxId,
      memberId: "CY-BARISTA-SYSTEM",
      memberName: "系统审计",
      amount: -10,
      type: "redeem" as const,
      reason: `单号 ${orderId} 触发重做，核销原料损耗折旧`,
      orderId: orderId,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };
    setPointsLedger(prev => [remakePointsTx, ...prev]);
  };

  // Barista toggle stockout item
  const handleToggleInventoryStock = (id: string) => {
    setInventory(prev => prev.map(item => {
      if (item.id === id) {
        const isCurrentlySoldOut = item.stockOnHand <= 0;
        return {
          ...item,
          stockOnHand: isCurrentlySoldOut ? 100.0 : 0.0 // Toggle between plenty and completely empty
        };
      }
      return item;
    }));
  };

  // Digital twin trigger IoT equipment failure simulation
  const handleTriggerEquipmentFailure = (eqId: string, fail: boolean) => {
    setEquipment(prev => prev.map(eq => {
      if (eq.id === eqId) {
        return {
          ...eq,
          status: fail ? "CRITICAL" : "NORMAL",
          telemetry: {
            ...eq.telemetry,
            temp: fail ? 42.0 : 93.5,
            pressure: fail ? 2.1 : 9.1,
            alertMsg: fail ? "警告：锅炉加热管断电，无法维持高压萃取！" : "运行正常 • 提取水压稳定"
          }
        };
      }
      return eq;
    }));

    if (fail) {
      setSimulationMode(SimulationMode.EQUIPMENT_FAIL);
      // Spike estimated prep time
      setSelectedStore(prev => ({
        ...prev,
        avgPrepTime: 18 // Surgically spike queue time estimate
      }));
    } else {
      setSimulationMode(SimulationMode.NORMAL);
      setSelectedStore(prev => ({
        ...prev,
        avgPrepTime: 3
      }));
    }
  };

  // Clock simulator interval hook
  useEffect(() => {
    if (!simulationActive) return;

    const interval = setInterval(() => {
      // 1. Auto advance orders in preparation if simulation is active
      setOrders(prev => {
        let orderChanged = false;
        const nextOrders = prev.map(o => {
          // If order is queued or preparing, automatically advance it through production stages
          if (o.status !== OrderStatus.COMPLETED && o.status !== OrderStatus.CANCELLED) {
            orderChanged = true;
            let nextStatus = o.status;
            if (o.status === OrderStatus.QUEUED) nextStatus = OrderStatus.EXTRACTING;
            else if (o.status === OrderStatus.EXTRACTING) nextStatus = OrderStatus.MILK_PREP;
            else if (o.status === OrderStatus.MILK_PREP) nextStatus = OrderStatus.ASSEMBLY;
            else if (o.status === OrderStatus.ASSEMBLY) nextStatus = OrderStatus.QUALITY_CHECK;
            else if (o.status === OrderStatus.QUALITY_CHECK) nextStatus = OrderStatus.READY_FOR_PICKUP;
            // Note: Ready for pickup requires customer/barista to explicitly complete it to simulate pickup checkout
            
            return {
              ...o,
              status: nextStatus,
              elapsedTimer: o.elapsedTimer + 2
            };
          }
          return o;
        });

        if (orderChanged) {
          // Subtract queue wait times gradually
          setSelectedStore(store => {
            const isAnyPreparing = nextOrders.some(no => no.status !== OrderStatus.COMPLETED && no.status !== OrderStatus.CANCELLED);
            if (!isAnyPreparing && store.queueLength > 0) {
              return {
                ...store,
                queueLength: 0,
                avgPrepTime: 3
              };
            }
            return store;
          });
        }

        return nextOrders;
      });

      // 2. Spawn random orders based on active peak simulation mode
      let spawnProbability = 0.05; // 5% chance per cycle in normal mode
      if (simulationMode === SimulationMode.BREAKFAST) spawnProbability = 0.35; // 35% in breakfast peak
      if (simulationMode === SimulationMode.AFTERNOON) spawnProbability = 0.15; // 15% in afternoon

      if (Math.random() < spawnProbability) {
        const oatMilkItem = inventory.find(i => i.id === "CY-MILK-OAT");
        const isOatMilkSoldOut = oatMilkItem ? oatMilkItem.stockOnHand <= 0 : false;
        
        // Spawn a random Order
        const productsList = ["CY-PRD-01", "CY-PRD-02", "CY-PRD-03", "CY-PRD-04", "CY-PRD-05"];
        const randomProductId = productsList[Math.floor(Math.random() * productsList.length)];
        
        const generatedId = `CY-ORD-${Math.floor(21000 + Math.random() * 9000)}`;
        const randomPickupCode = `CY-${Math.floor(500 + Math.random() * 400)}`;

        const spawnedOrder: Order = {
          id: generatedId,
          customerName: lang === "zh-CN" ? "王女士 (Ms. Wang)" : "Ms. Wang",
          storeId: selectedStore.id,
          items: [
            {
              id: `${randomProductId}-${Date.now()}`,
              product: {
                id: randomProductId,
                name: randomProductId === "CY-PRD-01" ? "燕麦桂花拿铁" : "赤焰琥珀美式",
                englishName: "Simulated Beverage",
                description: "Spontaneous customer simulation order.",
                category: "limited",
                basePrice: 24,
                image: "https://picsum.photos/seed/sim1/400/300",
                calories: 120,
                caffeine: 130,
                traceabilityId: "CY-BEAN-00041",
                isAvailable: true,
                tags: []
              },
              customization: {
                size: "中杯",
                temp: "冰",
                milk: isOatMilkSoldOut ? "全脂牛奶" : "燕麦奶",
                sweetness: "五分糖",
                espresso: "标准浓度",
                toppings: []
              },
              quantity: 1,
              price: 24
            }
          ],
          type: OrderType.PICKUP,
          status: OrderStatus.QUEUED,
          subtotal: 24,
          discount: 0,
          deliveryFee: 0,
          packagingFee: 1,
          total: 25,
          pickupCode: randomPickupCode,
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
          prepTimer: selectedStore.avgPrepTime * 60,
          elapsedTimer: 0,
          paymentMethod: "WECHAT_PAY_SIMULATOR",
          pointsAwarded: 25
        };

        handleAddOrder(spawnedOrder);
      }
    }, 4000);

    return () => clearInterval(interval);
  }, [simulationActive, simulationMode, lang, selectedStore.id, inventory]);

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFDF8] text-[#171313] antialiased">
      
      {/* Top Professional Header Bar */}
      <header className="bg-[#171313] text-[#FFFDF8] border-b border-stone-800 px-6 py-4 flex flex-col sm:flex-row justify-between items-center shrink-0 shadow-lg z-50">
        <div className="flex items-center gap-3">
          <div className="bg-[#7D101B] p-2.5 rounded-xl flex items-center justify-center border border-[#B38A45]/30">
            <Flame className="w-6 h-6 text-[#FFFDF8]" />
          </div>
          <div className="text-left">
            <h1 className="text-base font-serif font-extrabold tracking-wider text-white">
              赤焰咖啡 OS • CHIYAN COFFEE OS
            </h1>
            <p className="text-[10px] text-[#B38A45] tracking-widest uppercase font-mono mt-0.5">
              “A Chinese Coffee Ritual, Engineered as an Operating System.”
            </p>
          </div>
        </div>

        {/* Global Control Center Dock */}
        <div className="flex items-center gap-3 mt-4 sm:mt-0 flex-wrap">
          {/* Sandbox Indicator badge */}
          <span className="bg-stone-800 border border-stone-700 text-stone-400 text-[9px] font-bold px-3 py-1.5 rounded-lg tracking-widest uppercase font-mono">
            {lang === "zh-CN" ? "演示环境 • 模拟数据" : "Sandbox • Synthetic Data"}
          </span>

          {/* Language toggle selector */}
          <div className="bg-stone-800 rounded-lg p-0.5 flex border border-stone-700 text-[10px] font-bold text-stone-300">
            <button 
              onClick={() => setLang("zh-CN")}
              className={`px-3 py-1 rounded transition-colors ${lang === "zh-CN" ? "bg-[#7D101B] text-white" : "hover:text-white"}`}
            >
              中文
            </button>
            <button 
              onClick={() => setLang("en-GB")}
              className={`px-3 py-1 rounded transition-colors ${lang === "en-GB" ? "bg-[#7D101B] text-white" : "hover:text-white"}`}
            >
              EN
            </button>
          </div>
        </div>
      </header>

      {/* Role Switcher Toolbar */}
      <div className="bg-[#FFFDF8] border-b border-stone-200 px-6 py-2.5 flex items-center justify-start shrink-0 z-40 overflow-x-auto gap-1.5">
        <span className="text-[10px] text-stone-400 font-extrabold uppercase tracking-widest mr-3 shrink-0">
          {lang === "zh-CN" ? "切换沙盒端面" : "Role Views"}:
        </span>

        {[
          { id: UserRole.CUSTOMER, label: "📱 手机点单 (Customer App)", color: "hover:text-[#7D101B]" },
          { id: UserRole.BARISTA, label: "☕ 咖啡师端 (Barista Desk)", color: "hover:text-[#7D101B]" },
          { id: UserRole.STORE_MANAGER, label: "🌐 空间孪生与仿真 (Digital Twin)", color: "hover:text-[#7D101B]" },
          { id: UserRole.ANALYST, label: "📈 商业分析看板 (BI Dashboard)", color: "hover:text-[#7D101B]" },
          { id: UserRole.ADMIN, label: "🤖 AI 战略顾问 (Gemini Consult)", color: "hover:text-[#7D101B]" }
        ].map((role) => (
          <button
            key={role.id}
            onClick={() => setActiveRole(role.id)}
            className={`text-xs font-extrabold px-4 py-2 rounded-xl transition border shrink-0 ${
              activeRole === role.id 
              ? "bg-[#7D101B] border-[#7D101B] text-white shadow-sm" 
              : `bg-white border-stone-200 text-stone-600 ${role.color} hover:bg-stone-50`
            }`}
          >
            {role.label}
          </button>
        ))}
      </div>

      {/* Main Workspace Frame */}
      <main className="flex-1 overflow-hidden relative">
        {activeRole === UserRole.CUSTOMER && (
          <CustomerApp 
            lang={lang} 
            selectedStore={selectedStore} 
            onSelectStore={handleSelectStore} 
            activeOrders={orders}
            onAddOrder={handleAddOrder}
            inventory={inventory}
          />
        )}

        {activeRole === UserRole.BARISTA && (
          <BaristaConsole 
            lang={lang} 
            orders={orders} 
            onUpdateOrderStatus={handleUpdateOrderStatus} 
            onTriggerRemake={handleTriggerRemake}
            inventory={inventory}
            onToggleInventoryStock={handleToggleInventoryStock}
          />
        )}

        {activeRole === UserRole.STORE_MANAGER && (
          <DigitalTwin 
            lang={lang}
            selectedStore={selectedStore}
            equipment={equipment}
            onTriggerEquipmentFailure={handleTriggerEquipmentFailure}
            simulationActive={simulationActive}
            onToggleSimulation={setSimulationActive}
            simulationMode={simulationMode}
            onSetSimulationMode={setSimulationMode}
            ordersCount={orders.filter(o => o.status !== OrderStatus.COMPLETED && o.status !== OrderStatus.CANCELLED).length}
          />
        )}

        {activeRole === UserRole.ANALYST && (
          <AnalyticsConsole 
            lang={lang} 
            orders={orders} 
            inventory={inventory} 
            pointsLedger={pointsLedger}
          />
        )}

        {activeRole === UserRole.ADMIN && (
          <AiConsultant 
            lang={lang} 
            storeStats={{
              queueLength: selectedStore.queueLength,
              avgPrepTime: selectedStore.avgPrepTime,
              isMachineDown: equipment.find(e => e.type === "espresso")?.status === "CRITICAL"
            }}
          />
        )}
      </main>

      {/* Footer Branding Status Row */}
      <footer className="bg-[#171313] text-stone-500 border-t border-stone-800 py-3 px-6 text-center text-[10px] shrink-0 font-mono tracking-wider flex flex-col sm:flex-row justify-between items-center gap-2">
        <span>© 2026 CHÌYÀN COFFEE CO., LTD. ALL RIGHTS RESERVED.</span>
        <span className="text-[#B38A45]">
          {lang === "zh-CN" ? "赤焰咖啡智能物联网控制层集成版 (IoT Core v4.1)" : "IoT Core Gateway v4.1 Integrated"}
        </span>
      </footer>
    </div>
  );
}
