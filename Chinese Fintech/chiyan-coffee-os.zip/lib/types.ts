// Shared Domain Types for Chiyan Coffee OS

export enum OrderStatus {
  QUEUED = "QUEUED",
  EXTRACTING = "EXTRACTING",
  MILK_PREP = "MILK_PREP",
  ASSEMBLY = "ASSEMBLY",
  QUALITY_CHECK = "QUALITY_CHECK",
  READY_FOR_PICKUP = "READY_FOR_PICKUP",
  COMPLETED = "COMPLETED",
  CANCELLED = "CANCELLED"
}

export enum OrderType {
  PICKUP = "PICKUP",
  DELIVERY = "DELIVERY"
}

export enum UserRole {
  CUSTOMER = "CUSTOMER",
  BARISTA = "BARISTA",
  STORE_MANAGER = "STORE_MANAGER",
  ANALYST = "ANALYST",
  ADMIN = "ADMIN"
}

export enum SimulationMode {
  NORMAL = "NORMAL",
  BREAKFAST = "BREAKFAST",
  AFTERNOON = "AFTERNOON",
  PEAK_SPIKE = "PEAK_SPIKE",
  EQUIPMENT_FAIL = "EQUIPMENT_FAIL",
  SHORTAGE = "SHORTAGE"
}

export enum StoreType {
  FLAGSHIP = "FLAGSHIP",       // 城市旗舰店
  BUSINESS = "BUSINESS",       // 商务楼店
  MALL = "MALL",               // 商场店
  COMMUNITY = "COMMUNITY",     // 社区店
  COMPOUND = "COMPOUND"        // 烘焙咖啡复合店
}

export interface CustomizationOption {
  size: "中杯" | "大杯" | "特大杯";
  temp: "热" | "冰" | "少冰" | "去冰" | "常温";
  milk: "全脂牛奶" | "低脂牛奶" | "燕麦奶" | "椰奶" | "无乳选项";
  sweetness: "无糖" | "三分糖" | "五分糖" | "七分糖" | "全糖";
  espresso: "标准浓度" | "加一份浓缩" | "加两份浓缩" | "低咖啡因";
  toppings: string[];
}

export interface MenuItem {
  id: string;
  name: string;
  englishName: string;
  description: string;
  category: string;
  basePrice: number;
  promoPrice?: number;
  image: string;
  calories: number;
  caffeine: number; // mg
  traceabilityId: string;
  isAvailable: boolean;
  tags: string[];
}

export interface CartItem {
  id: string;
  product: MenuItem;
  customization: CustomizationOption;
  quantity: number;
  price: number;
}

export interface Order {
  id: string; // e.g. CY-ORD-20481
  customerName: string;
  storeId: string;
  items: CartItem[];
  type: OrderType;
  status: OrderStatus;
  subtotal: number;
  discount: number;
  deliveryFee: number;
  packagingFee: number;
  total: number;
  pickupCode: string;
  timestamp: string;
  prepTimer: number; // expected seconds
  elapsedTimer: number; // actual elapsed seconds
  paymentMethod: string;
  pointsAwarded: number;
}

export interface Store {
  id: string;
  name: string;
  englishName: string;
  city: string;
  district: string;
  address: string;
  englishAddress: string;
  type: StoreType;
  capacity: number;
  queueLength: number;
  avgPrepTime: number; // minutes
  manager: string;
  staffCount: number;
  lat: number;
  lng: number;
}

export interface IngredientBalance {
  id: string; // e.g. CY-BEAN-00041
  name: string;
  englishName: string;
  stockOnHand: number;
  reserved: number;
  reorderThreshold: number;
  unit: string;
  category: "beans" | "milk" | "syrups" | "packaging" | "other";
  traceabilityDetails?: {
    lotId: string;
    origin: string;
    variety: string;
    process: string;
    roastDate: string;
    profile: string;
  };
}

export interface Equipment {
  id: string;
  name: string;
  type: "espresso" | "grinder" | "refrigerator";
  status: "NORMAL" | "WARNING" | "CRITICAL";
  telemetry: {
    temp?: number; // C
    pressure?: number; // Bar
    rpm?: number; // Grinder RPM
    alertMsg?: string;
  };
}

export interface PointsTransaction {
  id: string;
  memberId: string;
  memberName: string;
  amount: number;
  type: "earn" | "redeem" | "refund";
  reason: string;
  orderId: string;
  timestamp: string;
}

export interface LocalizedLabels {
  home: string;
  menu: string;
  stores: string;
  member: string;
  my: string;
  pickup: string;
  delivery: string;
  estimatedTime: string;
  preparing: string;
  ready: string;
  orderNow: string;
  addMember: string;
  subtotal: string;
  discount: string;
  total: string;
  pay: string;
  points: string;
  digitalTwin: string;
  simulation: string;
  barista: string;
  analytics: string;
  ingredients: string;
}
