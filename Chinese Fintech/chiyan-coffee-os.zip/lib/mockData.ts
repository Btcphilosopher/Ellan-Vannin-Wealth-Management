import { MenuItem, Store, StoreType, IngredientBalance, Equipment, PointsTransaction, LocalizedLabels } from "./types";

// Translation dictionaries
export const translations: Record<"zh-CN" | "en-GB", LocalizedLabels> = {
  "zh-CN": {
    home: "首页",
    menu: "点单",
    stores: "门店",
    member: "会员",
    my: "我的",
    pickup: "自取",
    delivery: "外卖",
    estimatedTime: "预计取餐时间",
    preparing: "制作中",
    ready: "即将完成",
    orderNow: "立即下单",
    addMember: "加入会员",
    subtotal: "商品金额",
    discount: "优惠折抵",
    total: "实付金额",
    pay: "确认支付",
    points: "赤焰积分",
    digitalTwin: "数字孪生",
    simulation: "运行仿真",
    barista: "咖啡师控制台",
    analytics: "商业看板",
    ingredients: "原料库存"
  },
  "en-GB": {
    home: "Home",
    menu: "Order",
    stores: "Stores",
    member: "Loyalty",
    my: "Profile",
    pickup: "Pickup",
    delivery: "Delivery",
    estimatedTime: "Est. Prep Time",
    preparing: "Preparing",
    ready: "Ready for Pickup",
    orderNow: "Order Now",
    addMember: "Join Club",
    subtotal: "Subtotal",
    discount: "Discounts",
    total: "Total Paid",
    pay: "Confirm Payment",
    points: "Chiyan Points",
    digitalTwin: "Digital Twin",
    simulation: "Simulator",
    barista: "Barista Desk",
    analytics: "BI Dashboard",
    ingredients: "Inventory"
  }
};

// Localized Categories
export const categories: { id: string; zh: string; en: string }[] = [
  { id: "limited", zh: "季节限定", en: "Seasonal Specials" },
  { id: "espresso", zh: "浓缩与美式", en: "Espresso & Americano" },
  { id: "latte", zh: "拿铁艺术", en: "Latte Art" },
  { id: "teacoffee", zh: "新中式茶咖", en: "Tea-Coffee Ritual" },
  { id: "coldbrew", zh: "冷萃冰饮", en: "Cold Brew & Ice" },
  { id: "breakfast", zh: "烘焙早点", en: "Bakery & Breakfast" }
];

// Fictional Coffee Beans and Traceability Batches
export const fictionalProducts: MenuItem[] = [
  {
    id: "CY-PRD-01",
    name: "燕麦桂花拿铁",
    englishName: "Oatmeal Osmanthus Latte",
    description: "选用云南「丹砂」高地水洗豆，调和桂花熟蜜与有机燕麦奶，口感温润绵密，透出清澈的金桂幽香。",
    category: "limited",
    basePrice: 28,
    promoPrice: 24,
    image: "https://picsum.photos/seed/latte1/400/300",
    calories: 185,
    caffeine: 135,
    traceabilityId: "CY-BEAN-00041",
    isAvailable: true,
    tags: ["招牌", "植物奶", "低糖"]
  },
  {
    id: "CY-PRD-02",
    name: "赤焰琥珀美式",
    englishName: "Chiyan Amber Americano",
    description: "招牌中深烘焙拼配豆，前段饱满可可风味，中段呈现明亮的焦糖甜感，微苦回甘，如琥珀般深邃。",
    category: "espresso",
    basePrice: 20,
    image: "https://picsum.photos/seed/coffee1/400/300",
    calories: 15,
    caffeine: 150,
    traceabilityId: "CY-BEAN-00042",
    isAvailable: true,
    tags: ["经典", "无糖", "高咖啡因"]
  },
  {
    id: "CY-PRD-03",
    name: "大红袍茶咖拿铁",
    englishName: "Da Hong Pao Tea-Espresso",
    description: "将武夷岩茶大红袍的深邃焙火香与浓缩咖啡融合，加入全脂鲜牛奶，茶香与咖啡香交融出极致的中式韵味。",
    category: "teacoffee",
    basePrice: 28,
    promoPrice: 25,
    image: "https://picsum.photos/seed/tea1/400/300",
    calories: 210,
    caffeine: 165,
    traceabilityId: "CY-BEAN-00043",
    isAvailable: true,
    tags: ["经典茶咖", "醇厚", "独特"]
  },
  {
    id: "CY-PRD-04",
    name: "黑糖生椰乳拿铁",
    englishName: "Brown Sugar Coconut Latte",
    description: "精选低温鲜榨冷冻椰浆，搭配手作古法黑糖，椰香澎湃，甜而不腻，冷饮口感极佳。",
    category: "latte",
    basePrice: 26,
    image: "https://picsum.photos/seed/coconut1/400/300",
    calories: 245,
    caffeine: 120,
    traceabilityId: "CY-BEAN-00042",
    isAvailable: true,
    tags: ["爆款", "椰乳", "冰凉"]
  },
  {
    id: "CY-PRD-05",
    name: "茉莉冷萃咖啡",
    englishName: "Jasmine Cold Brew",
    description: "经过18小时低温缓慢萃取的单源埃塞俄比亚豆，注入新鲜采摘茉莉花茶汤，果酸与花香并重，轻盈爽口。",
    category: "coldbrew",
    basePrice: 24,
    image: "https://picsum.photos/seed/cold1/400/300",
    calories: 8,
    caffeine: 140,
    traceabilityId: "CY-BEAN-00044",
    isAvailable: true,
    tags: ["夏季推荐", "花香", "清爽"]
  },
  {
    id: "CY-PRD-06",
    name: "赤焰焦糖可颂",
    englishName: "Chiyan Caramel Croissant",
    description: "法国原产发酵黄油层层折叠烘焙，表面刷上自制焦糖浆，酥脆可口，是美式与手冲的完美伴侣。",
    category: "breakfast",
    basePrice: 16,
    promoPrice: 12,
    image: "https://picsum.photos/seed/croissant1/400/300",
    calories: 320,
    caffeine: 0,
    traceabilityId: "CY-BAKE-001",
    isAvailable: true,
    tags: ["每日烘焙", "香酥"]
  },
  {
    id: "CY-PRD-07",
    name: "红丝绒乳酪蛋糕",
    englishName: "Red Velvet Cheese Cake",
    description: "赤焰漆红主调红丝绒蛋糕胚，层叠新西兰进口海盐干酪，浓郁细腻，略带浆果微酸。",
    category: "breakfast",
    basePrice: 28,
    image: "https://picsum.photos/seed/cake1/400/300",
    calories: 450,
    caffeine: 0,
    traceabilityId: "CY-BAKE-002",
    isAvailable: true,
    tags: ["甜点", "芝士"]
  }
];

// Fictional Store Locations
export const fictionalStores: Store[] = [
  {
    id: "CY-SH-001",
    name: "上海·静安城市旗舰店",
    englishName: "Shanghai Jingan Flagship Store",
    city: "上海",
    district: "静安区",
    address: "南京西路1515号静安嘉里中心南广场",
    englishAddress: "South Plaza, Jing'an Kerry Centre, No.1515 West Nanjing Rd",
    type: StoreType.FLAGSHIP,
    capacity: 68,
    queueLength: 3,
    avgPrepTime: 3,
    manager: "张丽娜 (Lina Zhang)",
    staffCount: 8,
    lat: 31.2243,
    lng: 121.4442
  },
  {
    id: "CY-SZ-022",
    name: "深圳·南山科技园店",
    englishName: "Shenzhen Nanshan Sci-Tech Store",
    city: "深圳",
    district: "南山区",
    address: "科苑路15号科创大厦A座大堂",
    englishAddress: "Lobby, Block A, Kechuang Building, No.15 Keyuan Rd",
    type: StoreType.BUSINESS,
    capacity: 12,
    queueLength: 1,
    avgPrepTime: 2,
    manager: "刘伟宏 (Weiheng Liu)",
    staffCount: 4,
    lat: 22.5407,
    lng: 113.9472
  },
  {
    id: "CY-BJ-014",
    name: "北京·国贸商城店",
    englishName: "Beijing China World Mall Store",
    city: "北京",
    district: "朝阳区",
    address: "建国门外大街1号国贸商城地下一层SB12",
    englishAddress: "Unit SB12, B1, China World Mall, No.1 Jianguomen Outer St",
    type: StoreType.MALL,
    capacity: 35,
    queueLength: 5,
    avgPrepTime: 6,
    manager: "赵敏 (Min Zhao)",
    staffCount: 6,
    lat: 39.9085,
    lng: 116.4522
  },
  {
    id: "CY-GZ-003",
    name: "广州·天河体育东路店",
    englishName: "Guangzhou Tianhe Tiyudong Store",
    city: "广州",
    district: "天河区",
    address: "体育东路102号",
    englishAddress: "No. 102 Tiyudong Rd, Tianhe District",
    type: StoreType.COMMUNITY,
    capacity: 20,
    queueLength: 2,
    avgPrepTime: 4,
    manager: "陈宇轩 (Yuxuan Chen)",
    staffCount: 3,
    lat: 23.1365,
    lng: 113.3282
  },
  {
    id: "CY-HZ-008",
    name: "杭州·西湖断桥复合店",
    englishName: "Hangzhou Westlake Compound Store",
    city: "杭州",
    district: "西湖区",
    address: "北山街40号",
    englishAddress: "No. 40 Beishan St, Westlake District",
    type: StoreType.COMPOUND,
    capacity: 50,
    queueLength: 4,
    avgPrepTime: 5,
    manager: "徐雅琴 (Yaqin Xu)",
    staffCount: 7,
    lat: 30.2647,
    lng: 120.1552
  }
];

// Fictional Raw Materials
export const fictionalInventory: IngredientBalance[] = [
  {
    id: "CY-BEAN-00041",
    name: "云南丹砂咖啡豆",
    englishName: "Yunnan Cinnabar Beans",
    stockOnHand: 145.5,
    reserved: 12.0,
    reorderThreshold: 30.0,
    unit: "kg",
    category: "beans",
    traceabilityDetails: {
      lotId: "YNC-2026-A1",
      origin: "中国云南保山新寨坝 (Baoshan, Yunnan)",
      variety: "卡蒂姆 (Catimor)",
      process: "精品水洗双重厌氧 (Double Anaerobic Wash)",
      roastDate: "2026-09-10",
      profile: "中深烘焙 (Medium-Dark), 水果可可风味调"
    }
  },
  {
    id: "CY-BEAN-00042",
    name: "赤焰经典拼配咖啡豆",
    englishName: "Chiyan Signature Espresso Blend",
    stockOnHand: 320.0,
    reserved: 45.0,
    reorderThreshold: 50.0,
    unit: "kg",
    category: "beans",
    traceabilityDetails: {
      lotId: "CYB-2026-P9",
      origin: "云南、哥伦比亚、埃塞俄比亚拼配",
      variety: "阿拉比卡 (Arabica Blend)",
      process: "日晒与水洗混配 (Natural & Wash Blend)",
      roastDate: "2026-09-12",
      profile: "中深烘焙, 极致黑巧克力与坚果香感"
    }
  },
  {
    id: "CY-MILK-OAT",
    name: "有机低糖燕麦奶",
    englishName: "Organic Low-Sugar Oat Milk",
    stockOnHand: 180,
    reserved: 15,
    reorderThreshold: 40,
    unit: "L",
    category: "milk"
  },
  {
    id: "CY-MILK-FRESH",
    name: "大理高山牧场鲜牛奶",
    englishName: "Dali Premium Fresh Milk",
    stockOnHand: 220,
    reserved: 28,
    reorderThreshold: 50,
    unit: "L",
    category: "milk"
  },
  {
    id: "CY-SYRUP-OSM",
    name: "古法浓缩金桂熟蜜糖浆",
    englishName: "Osmanthus Flower Honey Syrup",
    stockOnHand: 18.5,
    reserved: 1.2,
    reorderThreshold: 5.0,
    unit: "kg",
    category: "syrups"
  },
  {
    id: "CY-PKG-CUP",
    name: "漆红烫金双面纸杯 (16oz)",
    englishName: "Chiyan Red-Gold Embossed Cup",
    stockOnHand: 2400,
    reserved: 120,
    reorderThreshold: 500,
    unit: "个 (pcs)",
    category: "packaging"
  }
];

// Fictional Store Equipment Telemetry
export const fictionalEquipment: Equipment[] = [
  {
    id: "CY-EQ-01",
    name: "赤焰一号 - 定制智能变压浓缩机",
    type: "espresso",
    status: "NORMAL",
    telemetry: {
      temp: 93.5,
      pressure: 9.1,
      alertMsg: "运行正常 • 提取水压稳定"
    }
  },
  {
    id: "CY-EQ-02",
    name: "赤焰高精密平刀磨豆机",
    type: "grinder",
    status: "NORMAL",
    telemetry: {
      rpm: 1420,
      temp: 34.2,
      alertMsg: "磨损度极低 • 颗粒均一性 96.8%"
    }
  },
  {
    id: "CY-EQ-03",
    name: "超低温冷链保鲜冷藏库",
    type: "refrigerator",
    status: "NORMAL",
    telemetry: {
      temp: 3.8,
      alertMsg: "保鲜冷冻温度锁死中"
    }
  }
];

// Mock Customer accounts
export interface CustomerAccount {
  id: string;
  name: string;
  phone: string;
  level: "普通会员" | "赤焰会员" | "黑金会员" | "臻享会员";
  points: number;
  avatar: string;
}

export const initialCustomers: CustomerAccount[] = [
  {
    id: "CY-MEM-8041",
    name: "张明亮 (Mingliang Zhang)",
    phone: "138****9201",
    level: "黑金会员",
    points: 1250,
    avatar: "https://picsum.photos/seed/user1/100/100"
  },
  {
    id: "CY-MEM-4093",
    name: "林静娴 (Jingxian Lin)",
    phone: "159****8820",
    level: "臻享会员",
    points: 3840,
    avatar: "https://picsum.photos/seed/user2/100/100"
  },
  {
    id: "CY-MEM-1022",
    name: "陈天恒 (Tianheng Chen)",
    phone: "135****0421",
    level: "普通会员",
    points: 240,
    avatar: "https://picsum.photos/seed/user3/100/100"
  }
];

// Static Historical Point Ledgers
export const initialPointsLedger: PointsTransaction[] = [
  {
    id: "CY-TX-001",
    memberId: "CY-MEM-8041",
    memberName: "张明亮",
    amount: 28,
    type: "earn",
    reason: "购买 燕麦桂花拿铁 获得积分",
    orderId: "CY-ORD-20311",
    timestamp: "2026-09-17 10:15:33"
  },
  {
    id: "CY-TX-002",
    memberId: "CY-MEM-4093",
    memberName: "林静娴",
    amount: -100,
    type: "redeem",
    reason: "积分换购 赤焰挂耳咖啡包 1 份",
    orderId: "CY-ORD-20315",
    timestamp: "2026-09-17 11:20:01"
  },
  {
    id: "CY-TX-003",
    memberId: "CY-MEM-1022",
    memberName: "陈天恒",
    amount: 20,
    type: "earn",
    reason: "购买 冰美式 获得积分",
    orderId: "CY-ORD-20320",
    timestamp: "2026-09-17 13:02:44"
  }
];
