import { useState } from "react";
import { 
  Coffee, 
  Clock, 
  CheckSquare, 
  AlertTriangle, 
  Package, 
  Play, 
  ArrowRight, 
  Utensils, 
  CheckCircle, 
  RefreshCw 
} from "lucide-react";
import { Order, OrderStatus, IngredientBalance } from "../lib/types";

interface BaristaConsoleProps {
  lang: "zh-CN" | "en-GB";
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
  onTriggerRemake: (orderId: string) => void;
  inventory: IngredientBalance[];
  onToggleInventoryStock: (id: string) => void;
}

export default function BaristaConsole({
  lang,
  orders,
  onUpdateOrderStatus,
  onTriggerRemake,
  inventory,
  onToggleInventoryStock
}: BaristaConsoleProps) {
  const [activeTab, setActiveTab] = useState<"production" | "inventory">("production");

  // Filter out orders that are completed, cancelled or not paid yet
  const activeProductionOrders = orders.filter(o => 
    o.status !== OrderStatus.COMPLETED && 
    o.status !== OrderStatus.CANCELLED
  );

  const getStatusActionLabel = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.QUEUED: return lang === "zh-CN" ? "开始咖啡萃取" : "Begin Extraction";
      case OrderStatus.EXTRACTING: return lang === "zh-CN" ? "打发基底牛奶" : "Steam Milk Base";
      case OrderStatus.MILK_PREP: return lang === "zh-CN" ? "进行装配融合" : "Assemble Cup";
      case OrderStatus.ASSEMBLY: return lang === "zh-CN" ? "启动品质检测" : "Begin Quality Check";
      case OrderStatus.QUALITY_CHECK: return lang === "zh-CN" ? "出杯/呼叫取杯" : "Mark Ready";
      case OrderStatus.READY_FOR_PICKUP: return lang === "zh-CN" ? "顾客核销提走" : "Mark Collected";
      default: return "";
    }
  };

  const getNextStatus = (status: OrderStatus): OrderStatus | null => {
    switch (status) {
      case OrderStatus.QUEUED: return OrderStatus.EXTRACTING;
      case OrderStatus.EXTRACTING: return OrderStatus.MILK_PREP;
      case OrderStatus.MILK_PREP: return OrderStatus.ASSEMBLY;
      case OrderStatus.ASSEMBLY: return OrderStatus.QUALITY_CHECK;
      case OrderStatus.QUALITY_CHECK: return OrderStatus.READY_FOR_PICKUP;
      case OrderStatus.READY_FOR_PICKUP: return OrderStatus.COMPLETED;
      default: return null;
    }
  };

  const getOrderStatusColor = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.QUEUED: return "bg-stone-100 text-stone-700 border-stone-300";
      case OrderStatus.EXTRACTING: return "bg-[#7D101B]/10 text-[#7D101B] border-[#7D101B]/30";
      case OrderStatus.MILK_PREP: return "bg-[#D92D3F]/10 text-[#D92D3F] border-[#D92D3F]/30";
      case OrderStatus.ASSEMBLY: return "bg-[#B38A45]/10 text-[#B38A45] border-[#B38A45]/30";
      case OrderStatus.QUALITY_CHECK: return "bg-blue-50 text-blue-700 border-blue-200";
      case OrderStatus.READY_FOR_PICKUP: return "bg-emerald-50 text-emerald-700 border-emerald-200 animate-pulse";
      default: return "bg-stone-50 text-stone-500 border-stone-200";
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#F6F3EF] border-l border-stone-200 h-full">
      {/* Console Sub-Header */}
      <div className="bg-[#171313] text-[#FFFDF8] px-6 py-4 flex justify-between items-center shrink-0 border-b border-stone-800">
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 bg-[#D92D3F] rounded-full animate-ping"></div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-widest font-serif text-[#FFFDF8]">
              {lang === "zh-CN" ? "赤焰咖啡师工作台" : "Chiyan Barista Operations Console"}
            </h2>
            <p className="text-[10px] text-stone-400 font-mono mt-0.5">
              {lang === "zh-CN" ? "静安嘉里中心店 • 2号智能吧台" : "Jingan Kerry Centre • Bar No. 2"}
            </p>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex bg-[#292526] p-0.5 rounded-lg border border-stone-700 text-xs">
          <button 
            onClick={() => setActiveTab("production")}
            className={`px-4 py-1.5 font-bold rounded-md transition ${
              activeTab === "production" 
              ? "bg-[#7D101B] text-white" 
              : "text-stone-400 hover:text-white"
            }`}
          >
            ☕ {lang === "zh-CN" ? "生产制作队列" : "Active Production Queue"} ({activeProductionOrders.length})
          </button>
          <button 
            onClick={() => setActiveTab("inventory")}
            className={`px-4 py-1.5 font-bold rounded-md transition ${
              activeTab === "inventory" 
              ? "bg-[#7D101B] text-white" 
              : "text-stone-400 hover:text-white"
            }`}
          >
            📦 {lang === "zh-CN" ? "物料售罄管理" : "Supply Stock Panel"}
          </button>
        </div>
      </div>

      {activeTab === "production" ? (
        /* Real-time Order Ticket Grid */
        <div className="flex-1 overflow-y-auto p-6">
          {activeProductionOrders.length === 0 ? (
            <div className="h-full flex flex-col justify-center items-center text-stone-400 py-16">
              <Coffee className="w-12 h-12 text-stone-300 mb-3" />
              <p className="text-sm font-medium">{lang === "zh-CN" ? "暂无待制作订单。享受宁静吧！" : "Queue is empty. Relax, Barista!"}</p>
              <p className="text-xs text-stone-500 mt-1">{lang === "zh-CN" ? "在左侧手机模拟端下单后将立即推送到此处" : "New customer app orders will appear here instantly"}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {activeProductionOrders.map((order) => {
                return (
                  <div 
                    key={order.id} 
                    className="bg-[#FFFDF8] border-2 border-stone-200 rounded-2xl shadow-sm overflow-hidden flex flex-col justify-between"
                  >
                    {/* Ticket Header */}
                    <div className="bg-[#171313] text-white p-4 flex justify-between items-center">
                      <div>
                        <span className="text-xs font-mono text-[#B38A45] font-bold">#{order.id}</span>
                        <h3 className="text-sm font-bold font-serif text-white mt-0.5">{order.customerName}</h3>
                      </div>
                      <div className="text-right">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${getOrderStatusColor(order.status)}`}>
                          {lang === "zh-CN" ? getOrderStatusChineseLabel(order.status) : order.status}
                        </span>
                        <p className="text-[9px] text-stone-400 mt-1 font-mono">
                          {order.type === "PICKUP" ? "自取 🚶" : "外卖 🛵"}
                        </p>
                      </div>
                    </div>

                    {/* Preparation Recipes */}
                    <div className="p-4 flex-1 text-left">
                      <div className="border-b border-stone-100 pb-3 mb-3">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="mb-3 last:mb-0">
                            <div className="flex justify-between items-start font-serif font-bold text-stone-900 text-sm">
                              <span>• {item.product.name} <span className="text-xs font-sans text-stone-500">× {item.quantity}</span></span>
                            </div>
                            <div className="mt-1 bg-stone-100/70 p-2.5 rounded-lg space-y-1 text-xs text-stone-600 font-sans">
                              <div>📐 <strong>{lang === "zh-CN" ? "杯型" : "Size"}:</strong> {item.customization.size}</div>
                              <div>🔥 <strong>{lang === "zh-CN" ? "温度" : "Temp"}:</strong> {item.customization.temp}</div>
                              <div>🥥 <strong>{lang === "zh-CN" ? "基底" : "Milk"}:</strong> {item.customization.milk}</div>
                              <div>🍬 <strong>{lang === "zh-CN" ? "甜度" : "Sweet"}:</strong> {item.customization.sweetness}</div>
                              <div>☕ <strong>{lang === "zh-CN" ? "浓缩" : "Espresso"}:</strong> {item.customization.espresso}</div>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Diagnostic details & timers */}
                      <div className="flex justify-between items-center text-[10px] text-stone-400 font-mono">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-stone-400" />
                          {lang === "zh-CN" ? "已等" : "Wait"}: <span className="font-bold text-stone-700">120s</span>
                        </span>
                        <span className="bg-[#FFFDF8] border border-[#B38A45]/30 text-[#B38A45] px-1.5 py-0.5 rounded">
                          {lang === "zh-CN" ? "豆批次" : "Bean"}: CY-BEAN-00041
                        </span>
                      </div>
                    </div>

                    {/* Actions Panel */}
                    <div className="bg-stone-50 p-4 border-t border-stone-200/50 flex gap-2">
                      <button 
                        onClick={() => onTriggerRemake(order.id)}
                        className="border border-stone-300 hover:bg-stone-100 text-stone-600 px-3 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        {lang === "zh-CN" ? "重做" : "Remake"}
                      </button>
                      
                      {getNextStatus(order.status) ? (
                        <button 
                          onClick={() => onUpdateOrderStatus(order.id, getNextStatus(order.status)!)}
                          className="flex-1 bg-[#7D101B] hover:bg-[#A51625] text-white py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm"
                        >
                          <Play className="w-3.5 h-3.5" />
                          <span>{getStatusActionLabel(order.status)}</span>
                          <ArrowRight className="w-3.5 h-3.5 ml-1" />
                        </button>
                      ) : (
                        <button 
                          disabled
                          className="flex-1 bg-stone-300 text-stone-500 py-2 px-3 rounded-xl text-xs font-bold cursor-not-allowed flex items-center justify-center gap-1"
                        >
                          <CheckCircle className="w-4 h-4 text-stone-400" />
                          <span>{lang === "zh-CN" ? "流程终点" : "Task Completed"}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* Inventory / Supply Sellout Simulator Panel */
        <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full text-left">
          <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm">
            <h3 className="text-base font-bold font-serif text-[#7D101B] border-b border-stone-100 pb-3 mb-4">
              {lang === "zh-CN" ? "一键模拟物料状态（影响顾客端下单）" : "Simulate Supply Stockouts (Affects Ordering)"}
            </h3>
            <p className="text-xs text-stone-500 mb-6">
              {lang === "zh-CN" ? "咖啡师可以随时标记原料售罄。当在这里标记原料“已售罄”时，左侧手机下单端对应的选项将立刻被锁定或下架，模拟最真实的软硬件系统数据互通！" 
              : "Mark items as 'Sold Out'. Doing so immediately disables corresponding options on the customer app, simulating true microservice-sync."}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {inventory.map((item) => {
                const isSoldOut = item.stockOnHand <= 0;
                return (
                  <div 
                    key={item.id} 
                    className={`p-4 rounded-xl border-2 flex justify-between items-center transition-all ${
                      isSoldOut 
                      ? "border-amber-500/30 bg-amber-500/5" 
                      : "border-stone-200 bg-white"
                    }`}
                  >
                    <div>
                      <h4 className="text-sm font-bold text-stone-900">{item.name}</h4>
                      <p className="text-[10px] text-stone-400 font-mono mt-0.5">{item.englishName} ({item.id})</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-xs text-stone-600">
                          {lang === "zh-CN" ? "当前在库" : "On Hand"}: <strong className="font-mono text-stone-950">{item.stockOnHand} {item.unit}</strong>
                        </span>
                        {isSoldOut && (
                          <span className="bg-amber-600 text-white text-[8px] font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5 animate-pulse">
                            <AlertTriangle className="w-2 h-2" />
                            {lang === "zh-CN" ? "告警：缺货" : "Stockout"}
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => onToggleInventoryStock(item.id)}
                      className={`px-4 py-2 rounded-lg text-xs font-bold transition-colors ${
                        isSoldOut 
                        ? "bg-emerald-600 hover:bg-emerald-700 text-white" 
                        : "bg-amber-600 hover:bg-amber-700 text-white"
                      }`}
                    >
                      {isSoldOut ? (lang === "zh-CN" ? "补货 +100" : "Restock +100") : (lang === "zh-CN" ? "设为售罄" : "Set Out-of-Stock")}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function getOrderStatusChineseLabel(status: OrderStatus) {
  switch (status) {
    case OrderStatus.QUEUED: return "排队中";
    case OrderStatus.EXTRACTING: return "萃取中";
    case OrderStatus.MILK_PREP: return "打发鲜奶";
    case OrderStatus.ASSEMBLY: return "装配中";
    case OrderStatus.QUALITY_CHECK: return "质检中";
    case OrderStatus.READY_FOR_PICKUP: return "待取餐";
    case OrderStatus.COMPLETED: return "已完成";
    case OrderStatus.CANCELLED: return "已取消";
  }
}
