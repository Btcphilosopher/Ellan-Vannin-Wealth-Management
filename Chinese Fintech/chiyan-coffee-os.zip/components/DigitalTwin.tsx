import { useState, useEffect } from "react";
import { 
  Activity, 
  Cpu, 
  Settings, 
  AlertTriangle, 
  CheckCircle, 
  Zap, 
  TrendingUp, 
  Users, 
  Gauge, 
  Play, 
  PowerOff 
} from "lucide-react";
import { Store, Equipment, SimulationMode } from "../lib/types";

interface DigitalTwinProps {
  lang: "zh-CN" | "en-GB";
  selectedStore: Store;
  equipment: Equipment[];
  onTriggerEquipmentFailure: (eqId: string, fail: boolean) => void;
  simulationActive: boolean;
  onToggleSimulation: (active: boolean) => void;
  simulationMode: SimulationMode;
  onSetSimulationMode: (mode: SimulationMode) => void;
  ordersCount: number;
}

export default function DigitalTwin({
  lang,
  selectedStore,
  equipment,
  onTriggerEquipmentFailure,
  simulationActive,
  onToggleSimulation,
  simulationMode,
  onSetSimulationMode,
  ordersCount
}: DigitalTwinProps) {
  // Local fluctuating metrics for high fidelity
  const [powerConsumption, setPowerConsumption] = useState<number>(4.2);
  const [activeCustomerCount, setActiveCustomerCount] = useState<number>(14);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);

  // Fluctuating values on interval for live telemetry effect
  useEffect(() => {
    if (!simulationActive) return;

    const interval = setInterval(() => {
      // Slight fluctuation in power consumption
      setPowerConsumption(prev => {
        const delta = (Math.random() - 0.5) * 0.2;
        const newVal = prev + delta;
        return newVal < 2 ? 2.5 : newVal > 6 ? 5.5 : Number(newVal.toFixed(2));
      });

      // Fluctuate active seating customers based on selected simulation mode
      setActiveCustomerCount(prev => {
        let baseline = 12;
        if (simulationMode === SimulationMode.BREAKFAST) baseline = 38;
        if (simulationMode === SimulationMode.AFTERNOON) baseline = 24;
        
        const delta = Math.floor(Math.random() * 3) - 1;
        const nextVal = prev + delta;
        return nextVal < 5 ? 5 : nextVal > selectedStore.capacity ? selectedStore.capacity - 5 : nextVal;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [simulationActive, simulationMode, selectedStore.capacity]);

  const getModeChineseName = (mode: SimulationMode) => {
    switch (mode) {
      case SimulationMode.NORMAL: return "正常营业模式";
      case SimulationMode.BREAKFAST: return "早餐高峰模式";
      case SimulationMode.AFTERNOON: return "午后休闲模式";
      case SimulationMode.PEAK_SPIKE: return "新品极速波动模式";
      case SimulationMode.EQUIPMENT_FAIL: return "设备突发故障模式";
      case SimulationMode.SHORTAGE: return "供应链物料短缺模式";
    }
  };

  const getModeDescription = (mode: SimulationMode) => {
    switch (mode) {
      case SimulationMode.NORMAL: 
        return lang === "zh-CN" ? "常规客流量，吧台及设备平稳运行" : "Standard traffic, devices normal";
      case SimulationMode.BREAKFAST: 
        return lang === "zh-CN" ? "极致客流量（8:00 - 9:30），咖啡师全载运转" : "Extreme morning peak hour";
      case SimulationMode.AFTERNOON: 
        return lang === "zh-CN" ? "休闲社交时段，烘焙及轻食组合销售上升" : "Social hour, high bakery mix";
      case SimulationMode.PEAK_SPIKE: 
        return lang === "zh-CN" ? "秋季限定发布，短时涌入大量外卖订单" : "Sudden rush of delivery orders";
      case SimulationMode.EQUIPMENT_FAIL: 
        return lang === "zh-CN" ? "模拟变压浓缩机加热管受损，制作等待急剧拉长" : "Espresso machine heater failure simulation";
      case SimulationMode.SHORTAGE: 
        return lang === "zh-CN" ? "有机燕麦奶物流延迟，系统紧急启动退单机制" : "Oat milk delayed, automated fallback";
    }
  };

  const handleModeChange = (mode: SimulationMode) => {
    onSetSimulationMode(mode);
    if (mode === SimulationMode.EQUIPMENT_FAIL) {
      // Trigger espresso machine critical error
      onTriggerEquipmentFailure("CY-EQ-01", true);
    } else {
      // Restore espresso machine
      onTriggerEquipmentFailure("CY-EQ-01", false);
    }
  };

  const espressoMachine = equipment.find(e => e.type === "espresso");
  const isMachineDown = espressoMachine?.status === "CRITICAL";

  return (
    <div className="flex-1 flex flex-col lg:flex-row h-full overflow-hidden bg-[#F6F3EF]">
      
      {/* Left: Beautiful Interactive SVG Schematic Store Layout */}
      <div className="flex-1 p-6 flex flex-col overflow-y-auto">
        <div className="bg-[#FFFDF8] rounded-2xl border border-stone-200 p-4 shadow-xs flex-1 flex flex-col justify-between min-h-[420px]">
          <div className="flex justify-between items-center border-b border-stone-100 pb-3 mb-2 shrink-0">
            <div>
              <h3 className="text-sm font-bold font-serif text-[#7D101B]">
                {selectedStore.name} — {lang === "zh-CN" ? "智能空间孪生" : "Store Digital Twin Layout"}
              </h3>
              <p className="text-[10px] text-stone-500 font-mono mt-0.5">
                {lang === "zh-CN" ? "物理空间与流体控制实时映射" : "Physical Space & Telemetry Realtime Mapping"}
              </p>
            </div>
            
            <div className="flex items-center gap-1.5 bg-[#F6F3EF] px-2.5 py-1 rounded-lg border border-stone-200">
              <span className={`w-2 h-2 rounded-full ${isMachineDown ? "bg-amber-600 animate-pulse" : "bg-emerald-600"}`}></span>
              <span className="text-[10px] font-bold text-stone-700">
                {isMachineDown ? (lang === "zh-CN" ? "空间受限 • 设备故障" : "Operational Lag") : (lang === "zh-CN" ? "完美运行中" : "Optimal")}
              </span>
            </div>
          </div>

          {/* Core Hand-Crafted Floor Plan SVG Diagram */}
          <div className="flex-1 w-full flex items-center justify-center p-2 relative">
            <svg 
              viewBox="0 0 600 360" 
              className="w-full max-w-[560px] h-auto drop-shadow-sm transition-all"
            >
              {/* Outer Walls / Floor Boundary */}
              <rect x="10" y="10" width="580" height="340" rx="16" fill="#FFFDF8" stroke="#ECE7E1" strokeWidth="3" />
              <rect x="20" y="20" width="560" height="320" rx="8" fill="#FBF9F6" stroke="#ECE7E1" strokeWidth="1" />

              {/* Entrance Gate */}
              <path d="M 20 150 L 20 210" stroke="#7D101B" strokeWidth="6" strokeLinecap="round" />
              <text x="32" y="185" fill="#7D101B" className="text-[10px] font-bold font-serif" textAnchor="start">
                {lang === "zh-CN" ? "入口 GATE" : "ENTRANCE"}
              </text>

              {/* Seating Area - Lounge Area (Top Left) */}
              <rect x="40" y="40" width="220" height="100" rx="8" fill="#F6F3EF" stroke="#ECE7E1" strokeWidth="1.5" />
              <text x="50" y="60" fill="#171313" className="text-[10px] font-extrabold font-serif">
                {lang === "zh-CN" ? "休闲客区 LOUNGE" : "SEATING ZONE"}
              </text>
              {/* Seating Tables and customer dots */}
              <circle cx="80" cy="95" r="14" fill="#E84B58" fillOpacity="0.1" stroke="#D92D3F" strokeWidth="1" />
              <circle cx="80" cy="95" r="4" fill="#D92D3F" className={simulationActive ? "animate-bounce" : ""} />
              <circle cx="150" cy="95" r="14" fill="#E84B58" fillOpacity="0.1" stroke="#D92D3F" strokeWidth="1" />
              <circle cx="150" cy="95" r="4" fill="#D92D3F" />
              <circle cx="210" cy="95" r="14" fill="#E84B58" fillOpacity="0.1" stroke="#D92D3F" strokeWidth="1" />
              <circle cx="210" cy="95" r="4" fill="#D92D3F" />
              <text x="50" y="125" fill="stone" className="text-[8px] text-stone-500">
                {lang === "zh-CN" ? `当前座位利用率: ${Math.floor((activeCustomerCount / selectedStore.capacity) * 100)}%` : `Seat Load: ${Math.floor((activeCustomerCount / selectedStore.capacity) * 100)}%`}
              </text>

              {/* Central Counter Bar (Right Half) */}
              <rect x="300" y="40" width="260" height="200" rx="12" fill="#FFFDF8" stroke="#B38A45" strokeWidth="2" strokeDasharray={isMachineDown ? "4" : "0"} />
              <text x="315" y="65" fill="#7D101B" className="text-[11px] font-extrabold font-serif tracking-wider">
                {lang === "zh-CN" ? "赤焰环形吧台 BARISTA BAR" : "CHÌYÀN ISLAND BAR"}
              </text>

              {/* Sub Barista work stations */}
              {/* Grinder & Espresso Machine Station */}
              <rect x="320" y="90" width="80" height="40" rx="4" fill="#F6F3EF" stroke="#ECE7E1" strokeWidth="1" />
              <text x="360" y="112" fill="stone" className="text-[8px] text-stone-600 font-bold" textAnchor="middle">
                {lang === "zh-CN" ? "变压浓缩吧" : "Espresso Bay"}
              </text>
              {/* Espresso machine hot status indicator */}
              <circle cx="390" cy="110" r="5" className={isMachineDown ? "fill-amber-600 animate-ping" : "fill-emerald-600"} />

              {/* Milk Steam Station */}
              <rect x="415" y="90" width="60" height="40" rx="4" fill="#F6F3EF" stroke="#ECE7E1" strokeWidth="1" />
              <text x="445" y="112" fill="stone" className="text-[8px] text-stone-600 font-bold" textAnchor="middle">
                {lang === "zh-CN" ? "打发鲜奶区" : "Milk Bay"}
              </text>
              <circle cx="465" cy="110" r="4" fill="#D92D3F" />

              {/* Hand drip / Assembly Station */}
              <rect x="490" y="90" width="55" height="40" rx="4" fill="#F6F3EF" stroke="#ECE7E1" strokeWidth="1" />
              <text x="517" y="112" fill="stone" className="text-[8px] text-stone-600 font-bold" textAnchor="middle">
                {lang === "zh-CN" ? "装配融合" : "Assembly"}
              </text>

              {/* Baristas representation (pulsing dots) */}
              <g className={simulationActive ? "animate-pulse" : ""}>
                <circle cx="360" cy="155" r="6" fill="#171313" />
                <text x="360" y="172" fill="#171313" className="text-[7px] font-bold" textAnchor="middle">咖啡师 A</text>
                
                <circle cx="445" cy="155" r="6" fill="#171313" />
                <text x="445" y="172" fill="#171313" className="text-[7px] font-bold" textAnchor="middle">咖啡师 B</text>
              </g>

              {/* Pickup counter / waiting cups */}
              <rect x="315" y="195" width="230" height="35" rx="6" fill="#7D101B" fillOpacity="0.05" stroke="#7D101B" strokeWidth="1" />
              <text x="325" y="215" fill="#7D101B" className="text-[8px] font-bold">
                {lang === "zh-CN" ? "提货窗口 PICKUP BAY" : "COLLECT AREA"}
              </text>
              {ordersCount > 0 && (
                <g className="animate-bounce">
                  <circle cx="490" cy="212" r="5" fill="#7D101B" />
                  <circle cx="510" cy="212" r="5" fill="#7D101B" />
                </g>
              )}

              {/* Active Queue density dots at Entrance */}
              <g className="opacity-90">
                <circle cx="50" cy="185" r="5" fill="#D92D3F" />
                <circle cx="75" cy="185" r="5" fill="#D92D3F" />
                <circle cx="100" cy="185" r="5" fill="#D92D3F" />
                {selectedStore.queueLength > 3 && (
                  <g>
                    <circle cx="125" cy="185" r="5" fill="#D92D3F" />
                    <circle cx="150" cy="185" r="5" fill="#D92D3F" />
                    <circle cx="175" cy="185" r="5" fill="#D92D3F" stroke="#D92D3F" strokeWidth="1" fillOpacity="0.2" className="animate-ping" />
                  </g>
                )}
                <text x="50" y="205" fill="stone" className="text-[8px] font-bold text-stone-500">
                  {lang === "zh-CN" ? `实时排队密度: ${selectedStore.queueLength} 组顾客` : `Queue Line: ${selectedStore.queueLength} groups`}
                </text>
              </g>

              {/* Energy telemetry overlay label */}
              <rect x="40" y="270" width="520" height="40" rx="8" fill="#171313" />
              <text x="55" y="294" fill="#B38A45" className="text-[9px] font-mono font-bold tracking-widest">
                OS TELEMETRY FLOW: POWER = {powerConsumption} kW/h | SEATING = {activeCustomerCount}/{selectedStore.capacity} | ACT_QUEUE = {selectedStore.queueLength}
              </text>
            </svg>
          </div>
        </div>
      </div>

      {/* Right: Simulation Controller Dashboard */}
      <div className="w-full lg:w-[360px] p-6 shrink-0 flex flex-col justify-between border-t lg:border-t-0 lg:border-l border-stone-200">
        
        {/* Core Simulation togglers */}
        <div className="space-y-6 text-left">
          <div className="bg-[#171313] text-white rounded-2xl p-4 flex justify-between items-center shadow-xs">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#B38A45]">{lang === "zh-CN" ? "全栈仿真引擎" : "Simulation Engine"}</h4>
              <p className="text-[10px] text-stone-400 mt-1">{lang === "zh-CN" ? "自动流转订单与生产状态" : "Auto-advance production cycles"}</p>
            </div>
            <button
              onClick={() => onToggleSimulation(!simulationActive)}
              className={`p-2.5 rounded-full shadow transition-colors ${
                simulationActive 
                ? "bg-[#D92D3F] hover:bg-[#A51625] text-white" 
                : "bg-stone-800 hover:bg-stone-700 text-stone-300"
              }`}
            >
              <Cpu className={`w-5 h-5 ${simulationActive ? "animate-spin" : ""}`} />
            </button>
          </div>

          {/* Mode Switcher Presets */}
          <div>
            <h4 className="text-xs font-bold text-stone-600 mb-2">{lang === "zh-CN" ? "运行模式预设 (Presets)" : "Simulation Scenarios"}</h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                { id: SimulationMode.NORMAL, label: "正常营业" },
                { id: SimulationMode.BREAKFAST, label: "早餐高峰" },
                { id: SimulationMode.AFTERNOON, label: "下午休闲" },
                { id: SimulationMode.EQUIPMENT_FAIL, label: "设备故障" }
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => handleModeChange(m.id)}
                  className={`py-2.5 px-2 border rounded-xl text-center font-bold truncate transition-colors ${
                    simulationMode === m.id 
                    ? "border-[#7D101B] bg-[#7D101B]/5 text-[#7D101B]" 
                    : "border-stone-200 text-stone-600 bg-white hover:bg-stone-50"
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
            
            {/* Active Mode Explanation text block */}
            <div className="mt-3 bg-stone-100 rounded-lg p-3 border border-stone-200 text-xs text-stone-600 leading-normal">
              <p className="font-bold text-[#7D101B] mb-0.5">{getModeChineseName(simulationMode)}</p>
              <p>{getModeDescription(simulationMode)}</p>
            </div>
          </div>

          {/* Device Telemetry status widgets */}
          <div>
            <h4 className="text-xs font-bold text-stone-600 mb-2">{lang === "zh-CN" ? "精密硬件设备监控" : "IoT Hardware Telemetry"}</h4>
            <div className="space-y-2 text-xs">
              {equipment.map((eq) => {
                const isDown = eq.status === "CRITICAL";
                return (
                  <div key={eq.id} className="bg-white rounded-xl p-3 border border-stone-200 flex justify-between items-center">
                    <div>
                      <h5 className="font-bold text-stone-900">{eq.name}</h5>
                      <div className="text-[10px] text-stone-500 font-mono mt-0.5">
                        {eq.type === "espresso" && `水温: ${eq.telemetry.temp}°C | 水压: ${eq.telemetry.pressure} bar`}
                        {eq.type === "grinder" && `转速: ${eq.telemetry.rpm} RPM | 刀盘温度: ${eq.telemetry.temp}°C`}
                        {eq.type === "refrigerator" && `库内温度: ${eq.telemetry.temp}°C`}
                      </div>
                      <p className={`text-[9px] font-medium mt-1 ${isDown ? "text-amber-600 font-extrabold" : "text-stone-400"}`}>
                        • {eq.telemetry.alertMsg}
                      </p>
                    </div>

                    {eq.type === "espresso" && (
                      <button
                        onClick={() => onTriggerEquipmentFailure(eq.id, !isDown)}
                        className={`p-1.5 rounded-lg border transition ${
                          isDown 
                          ? "bg-amber-600 border-amber-600 text-white hover:bg-amber-700" 
                          : "border-stone-300 text-stone-500 hover:bg-stone-100"
                        }`}
                        title="Simulate Breakdown"
                      >
                        <PowerOff className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Breakdown simulator warning banner */}
        {isMachineDown && (
          <div className="bg-amber-500 text-white rounded-xl p-3.5 mt-6 border border-amber-600 flex gap-2 items-start text-left text-xs shadow-md animate-pulse">
            <AlertTriangle className="w-5 h-5 text-white shrink-0 mt-0.5" />
            <div>
              <p className="font-extrabold">{lang === "zh-CN" ? "变压浓缩机受损告警" : "Espresso Boiler Malfunction"}</p>
              <p className="opacity-90 mt-1">
                {lang === "zh-CN" 
                  ? "上海门店出杯效率下跌 80%。订单平均等待时间由 3 分钟飙升至 15 分钟，前端客户端已自动同步等待提示。" 
                  : "Output drops by 80%. Wait times surge from 3m to 15m. App automatically warns customers."}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
