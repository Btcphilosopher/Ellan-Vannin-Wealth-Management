import { useState } from "react";
import { 
  TrendingUp, 
  Coins, 
  Truck, 
  Activity, 
  ArrowUpRight, 
  Award, 
  Layers, 
  ArrowRightLeft 
} from "lucide-react";
import { Order, IngredientBalance, PointsTransaction } from "../lib/types";

interface AnalyticsConsoleProps {
  lang: "zh-CN" | "en-GB";
  orders: Order[];
  inventory: IngredientBalance[];
  pointsLedger: PointsTransaction[];
}

export default function AnalyticsConsole({
  lang,
  orders,
  inventory,
  pointsLedger
}: AnalyticsConsoleProps) {
  const [activeSubTab, setActiveSubTab] = useState<"sales" | "supply" | "crm">("sales");

  // Sum total sales (synthetic historical baseline + live simulation orders)
  const totalBaseSales = 12480;
  const liveSales = orders.filter(o => o.status === "COMPLETED" || o.status === "READY_FOR_PICKUP" || o.status === "QUEUED").reduce((sum, o) => sum + o.total, 0);
  const totalGrossSales = totalBaseSales + liveSales;

  const totalBaseOrders = 482;
  const liveOrders = orders.length;
  const totalOrdersCount = totalBaseOrders + liveOrders;

  // Custom mock sales timeline datasets for ARIMA forecasting area chart
  // Representing dates Sep 11 to Sep 17 with confidence bounds
  const salesHistory = [
    { date: "09-11", sales: 1540, forecast: 1540, minBound: 1540, maxBound: 1540 },
    { date: "09-12", sales: 1680, forecast: 1680, minBound: 1680, maxBound: 1680 },
    { date: "09-13", sales: 1820, forecast: 1820, minBound: 1820, maxBound: 1820 },
    { date: "09-14", sales: 1950, forecast: 1950, minBound: 1950, maxBound: 1950 },
    { date: "09-15", sales: 2100, forecast: 2100, minBound: 2100, maxBound: 2100 },
    { date: "09-16", sales: 1750, forecast: 1850, minBound: 1650, maxBound: 2050 }, // forecasting splits
    { date: "09-17", sales: totalGrossSales % 5000, forecast: 2200, minBound: 1900, maxBound: 2500 } // forecasting splits
  ];

  const maxSalesValue = 3000;

  return (
    <div className="flex-1 flex flex-col bg-[#F6F3EF] h-full overflow-y-auto p-6 text-left">
      {/* Analytics Navbar */}
      <div className="bg-white rounded-2xl border border-stone-200 p-4 mb-6 shadow-xs flex justify-between items-center flex-wrap gap-4">
        <div>
          <h2 className="text-base font-bold font-serif text-[#7D101B]">
            {lang === "zh-CN" ? "赤焰商业智能中心 (OS-BI)" : "Chiyan OS Business Intelligence Hub"}
          </h2>
          <p className="text-[10px] text-stone-500 font-mono mt-0.5">
            {lang === "zh-CN" ? "多门店结算、高维流转监控与R语言需求预测" : "Multistore Ledger, Operational Streams & R-Based ARIMA Forecasting"}
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex bg-[#F6F3EF] p-1 rounded-lg border border-stone-200 text-xs font-bold text-stone-600">
          <button 
            onClick={() => setActiveSubTab("sales")}
            className={`px-4 py-1.5 rounded transition ${
              activeSubTab === "sales" 
              ? "bg-[#7D101B] text-white" 
              : "hover:text-[#7D101B]"
            }`}
          >
            📊 {lang === "zh-CN" ? "销售与预测" : "Sales & Forecast"}
          </button>
          <button 
            onClick={() => setActiveSubTab("supply")}
            className={`px-4 py-1.5 rounded transition ${
              activeSubTab === "supply" 
              ? "bg-[#7D101B] text-white" 
              : "hover:text-[#7D101B]"
            }`}
          >
            🌱 {lang === "zh-CN" ? "单源溯源链" : "Supply Traceability"}
          </button>
          <button 
            onClick={() => setActiveSubTab("crm")}
            className={`px-4 py-1.5 rounded transition ${
              activeSubTab === "crm" 
              ? "bg-[#7D101B] text-white" 
              : "hover:text-[#7D101B]"
            }`}
          >
            🎟️ {lang === "zh-CN" ? "积分流水账" : "Points CRM"}
          </button>
        </div>
      </div>

      {activeSubTab === "sales" && (
        /* Real-time Sales KPI & ARIMA Forecast Graphs */
        <div className="space-y-6">
          {/* Executive KPIs grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "累计营业总额 (Gross Revenue)", value: `￥${totalGrossSales.toLocaleString()}`, change: "+14.8%", color: "border-[#7D101B]" },
              { label: "全网络交易订单 (Total Orders)", value: totalOrdersCount.toLocaleString(), change: "+11.2%", color: "border-[#D92D3F]" },
              { label: "全网获赠积分 (Points Generated)", value: `${(totalOrdersCount * 22).toLocaleString()} PTS`, change: "+13.5%", color: "border-[#B38A45]" },
              { label: "平均制作效率 (Avg Prep Time)", value: "3.24 min", change: "-0.54s", color: "border-emerald-600" }
            ].map((card, idx) => (
              <div key={idx} className={`bg-white rounded-2xl p-4 border-l-4 ${card.color} border border-stone-200 shadow-xs flex flex-col justify-between h-24`}>
                <span className="text-[10px] text-stone-500 font-bold uppercase tracking-wider">{card.label}</span>
                <div className="flex justify-between items-baseline mt-1">
                  <span className="text-xl font-black text-stone-950 font-serif leading-none">{card.value}</span>
                  <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5">
                    <ArrowUpRight className="w-3 h-3" />
                    {card.change}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Forecasting Graph */}
          <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm">
            <div className="flex justify-between items-center border-b border-stone-100 pb-3 mb-4">
              <div>
                <h3 className="text-sm font-bold text-stone-950 font-serif">
                  {lang === "zh-CN" ? "赤焰 OS • 营业额时间序列与 72h 预测" : "Revenue Time Series & 72h Forecasting (ARIMA)"}
                </h3>
                <p className="text-[10px] text-stone-400 mt-0.5">
                  {lang === "zh-CN" ? "数据来自 R 语言自动化分析引擎：ARIMA(2,1,2) 季节自回归移动平均预测" : "Fictional auto-integrated R Forecasting model outputs"}
                </p>
              </div>

              {/* Legends */}
              <div className="flex gap-4 text-[10px] font-bold text-stone-500">
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#7D101B] rounded-sm"></span> 实际营业额 (Actual)</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#B38A45]/40 rounded-sm"></span> R预测范围 (ARIMA CI-95)</span>
              </div>
            </div>

            {/* Handcrafted Responsive SVG Area Chart */}
            <div className="w-full h-64 relative flex items-end justify-center">
              <svg viewBox="0 0 600 220" className="w-full h-full">
                {/* Horizontal Gridlines */}
                {[0, 1, 2, 3, 4].map((grid, idx) => {
                  const y = 20 + grid * 45;
                  const labelVal = maxSalesValue - idx * (maxSalesValue / 4);
                  return (
                    <g key={idx}>
                      <line x1="45" y1={y} x2="570" y2={y} stroke="#F6F3EF" strokeWidth="1" />
                      <text x="35" y={y + 4} fill="stone" className="text-[9px] text-stone-400 text-right" textAnchor="end">
                        ￥{labelVal}
                      </text>
                    </g>
                  );
                })}

                {/* Confidence Interval Shadow Area */}
                <path 
                  d="M 45 150 L 130 145 L 215 130 L 300 120 L 385 110 L 470 125 L 470 95 L 385 110 L 300 120 L 215 130 L 130 145 Z" 
                  fill="#B38A45" 
                  fillOpacity="0.12" 
                />
                
                {/* Confidence bounds for forecasted days */}
                <path 
                  d="M 385 110 L 470 145 L 555 160 L 555 90 L 470 85 Z" 
                  fill="#B38A45" 
                  fillOpacity="0.15" 
                  stroke="#B38A45" 
                  strokeWidth="1.5" 
                  strokeDasharray="4 4"
                />

                {/* Actual Sales Line (Thick Chiyan Red) */}
                <path 
                  d="M 45 150 L 130 142 L 215 125 L 300 112 L 385 101 L 470 125 L 555 122" 
                  fill="none" 
                  stroke="#7D101B" 
                  strokeWidth="3.5" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                />

                {/* Chart Dots */}
                <circle cx="45" cy="150" r="4" fill="#7D101B" />
                <circle cx="130" cy="142" r="4" fill="#7D101B" />
                <circle cx="215" cy="125" r="4" fill="#7D101B" />
                <circle cx="300" cy="112" r="4" fill="#7D101B" />
                <circle cx="385" cy="101" r="4" fill="#7D101B" />
                <circle cx="470" cy="125" r="4" fill="#B38A45" />
                <circle cx="555" cy="122" r="4" fill="#B38A45" />

                {/* X Axis Labels */}
                {salesHistory.map((day, idx) => {
                  const x = 45 + idx * 85;
                  return (
                    <text key={idx} x={x} y="212" fill="stone" className="text-[9px] text-stone-500 font-bold" textAnchor="middle">
                      {day.date}
                    </text>
                  );
                })}
              </svg>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === "supply" && (
        /* single-origin provenance records & logistics traceability ledger */
        <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm">
          <h3 className="text-sm font-bold text-[#7D101B] font-serif border-b border-stone-100 pb-3 mb-4">
            {lang === "zh-CN" ? "赤焰咖啡生豆批次溯源账簿" : "Single-Origin Green Beans Traceability ledger"}
          </h3>
          <p className="text-xs text-stone-500 mb-6 leading-normal">
            {lang === "zh-CN" ? "赤焰咖啡坚守精品溯源。我们从中国云南、埃塞俄比亚及哥伦比亚直接进口生豆，在仓储、烘焙与配送全程中绑定批次代码，让每一杯出杯的咖啡都有明确的批次与农户追踪记录。" 
            : "Chiyan enforces transparent seed-to-cup logging. Green beans are batch-tracked through roast configurations."}
          </p>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 uppercase font-bold tracking-wider bg-stone-50">
                  <th className="py-3 px-4">{lang === "zh-CN" ? "批次代码" : "Lot ID"}</th>
                  <th className="py-3 px-4">{lang === "zh-CN" ? "生豆产区" : "Origin Farm"}</th>
                  <th className="py-3 px-4">{lang === "zh-CN" ? "品种工艺" : "Process & Variety"}</th>
                  <th className="py-3 px-4">{lang === "zh-CN" ? "烘焙日期" : "Roast Date"}</th>
                  <th className="py-3 px-4">{lang === "zh-CN" ? "风味特征" : "Tasting Notes"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {inventory.filter(i => i.category === "beans").map((bean) => (
                  <tr key={bean.id} className="hover:bg-stone-50">
                    <td className="py-3.5 px-4 font-mono font-bold text-[#7D101B]">{bean.traceabilityDetails?.lotId || "N/A"}</td>
                    <td className="py-3.5 px-4 font-bold text-stone-900">{bean.traceabilityDetails?.origin || "N/A"}</td>
                    <td className="py-3.5 px-4 text-stone-700">{bean.traceabilityDetails?.variety} • {bean.traceabilityDetails?.process}</td>
                    <td className="py-3.5 px-4 font-mono text-stone-600">{bean.traceabilityDetails?.roastDate || "N/A"}</td>
                    <td className="py-3.5 px-4 text-[#B38A45] font-medium">{bean.traceabilityDetails?.profile || "N/A"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeSubTab === "crm" && (
        /* Member points loyalty transaction ledger */
        <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-sm">
          <h3 className="text-sm font-bold text-[#7D101B] font-serif border-b border-stone-100 pb-3 mb-4">
            {lang === "zh-CN" ? "赤焰会员积分流转审计日记" : "CRM Points Ledger Transaction Log"}
          </h3>
          <p className="text-xs text-stone-500 mb-6">
            {lang === "zh-CN" ? "审计每一笔顾客积分的赚取与兑换，确保链上资产账目精确无误。" 
            : "Reviewing all loyalty tokens to guarantee flawless accounting rules."}
          </p>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 uppercase font-bold bg-stone-50">
                  <th className="py-3 px-4">{lang === "zh-CN" ? "流转单号" : "Tx ID"}</th>
                  <th className="py-3 px-4">{lang === "zh-CN" ? "会员姓名" : "Member"}</th>
                  <th className="py-3 px-4">{lang === "zh-CN" ? "分值额度" : "Points Amount"}</th>
                  <th className="py-3 px-4">{lang === "zh-CN" ? "流转缘由" : "Description"}</th>
                  <th className="py-3 px-4">{lang === "zh-CN" ? "业务单号" : "Related Order"}</th>
                  <th className="py-3 px-4">{lang === "zh-CN" ? "时间" : "Timestamp"}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {pointsLedger.map((tx) => {
                  const isEarn = tx.type === "earn";
                  return (
                    <tr key={tx.id} className="hover:bg-stone-50">
                      <td className="py-3.5 px-4 font-mono font-bold text-[#7D101B]">{tx.id}</td>
                      <td className="py-3.5 px-4 font-bold text-stone-900">{tx.memberName}</td>
                      <td className={`py-3.5 px-4 font-black font-mono ${isEarn ? "text-emerald-600" : "text-[#7D101B]"}`}>
                        {isEarn ? `+${tx.amount}` : tx.amount}
                      </td>
                      <td className="py-3.5 px-4 text-stone-600">{tx.reason}</td>
                      <td className="py-3.5 px-4 font-mono text-stone-500">{tx.orderId}</td>
                      <td className="py-3.5 px-4 font-mono text-stone-400">{tx.timestamp}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
