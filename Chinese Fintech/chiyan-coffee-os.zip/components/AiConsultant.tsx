import { useState, useTransition } from "react";
import { Sparkles, Send, Loader2, RefreshCw, AlertCircle, HelpCircle } from "lucide-react";

interface AiConsultantProps {
  lang: "zh-CN" | "en-GB";
  storeStats: {
    queueLength: number;
    avgPrepTime: number;
    isMachineDown: boolean;
  };
}

export default function AiConsultant({ lang, storeStats }: AiConsultantProps) {
  const [query, setQuery] = useState<string>("");
  const [messages, setMessages] = useState<{ role: "user" | "ai"; text: string }[]>([
    {
      role: "ai",
      text: lang === "zh-CN" 
        ? "您好！我是赤焰智能商业决策系统绑定的 AI 战略顾问。我可以为您提供门店排队诊断、产品定价模型推荐、季节联名营销方案以及单源供应链流转评估。请问有什么可以帮您？" 
        : "Welcome to Chiyan Strategic AI Copilot. I can assist with wait-time diagnostic reviews, seasonal campaign design, pricing model analysis, or bean sourcing evaluations. What is your inquiry today?"
    }
  ]);
  const [isPending, startTransition] = useTransition();

  const prewrittenPrompts = [
    {
      zh: "📊 诊断当前嘉里中心门店排队瓶颈并提供改善建议",
      en: "📊 Diagnose current store queue bottleneck & recommend fixes",
      prompt: `我们当前在「上海·静安嘉里中心店」有 ${storeStats.queueLength} 组顾客排队，平均制作等待时间为 ${storeStats.avgPrepTime} 分钟。变压浓缩咖啡机状态是 ${storeStats.isMachineDown ? "【机器损坏故障】" : "【正常运行】"}。请基于这些实时指标，分析目前门店面临的运营瓶颈（如果机器损坏，请着重评估对排队和客诉的影响），并给出3条极具可操作性的现场调配与人手改善建议。`
    },
    {
      zh: "🍁 策划一份「燕麦桂花拿铁」秋季联名营销文案与价格设计",
      en: "🍁 Draft an autumn Osmanthus Latte marketing campaign & pricing model",
      prompt: "我们的主打新品是「燕麦桂花拿铁」（售价28元，选用云南保山单源水洗卡蒂姆豆）。请帮我们策划一份秋季限定联名活动文案（例如联动国风非遗、金秋桂花主题），写出3句具有高级感的都市宣发标语（不能低俗或烂俗），并给出关于是否采取买一赠一、还是阶梯定价的策略评估。"
    },
    {
      zh: "🌱 评估云南保山「单源卡蒂姆豆」在当前供应链下的气候与采购风险",
      en: "🌱 Assess Baoshan single-source Arabica supply-chain climate risks",
      prompt: "我们采购的精品豆是「云南保山单源卡蒂姆水洗双重厌氧豆」，批次 CY-BEAN-00041。请站在资深咖啡供应链专家的角度，分析该产地（云南保山新寨坝）在秋季的气候（如降雨、霜冻对采摘和干燥的影响）、精品咖啡豆的市场竞争局势，并为我们提出1条如何建立豆农长期互助基金、规避咖啡期货波动的建议。"
    }
  ];

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isPending) return;

    const userMsg = textToSend;
    setQuery("");
    setMessages(prev => [...prev, { role: "user", text: userMsg }]);

    // Add a placeholder message for AI
    setMessages(prev => [...prev, { role: "ai", text: "Chiyan AI Consultant is typing..." }]);

    startTransition(async () => {
      try {
        const response = await fetch("/app/api/gemini/generate", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            prompt: userMsg,
            systemInstruction: "你是一位精通中国新零售咖啡行业的资深商业分析师和数字化技术专家。你说话有深厚的行业专业度、行文干练严谨，绝不吐露空洞的营销词汇。你为「赤焰咖啡 CHÌYÀN COFFEE」提供针对数字化系统、店面效率、供应链以及营销文案的最高决策支持。回答时使用规范的简体中文分段落阐述，带有专业术语和数据逻辑支撑。"
          })
        });

        const data = await response.json();
        
        // Replace placeholder with actual response text
        setMessages(prev => {
          const updated = [...prev];
          if (updated.length > 0) {
            updated[updated.length - 1] = { role: "ai", text: data.text || "无可用分析结果" };
          }
          return updated;
        });
      } catch (err) {
        setMessages(prev => {
          const updated = [...prev];
          if (updated.length > 0) {
            updated[updated.length - 1] = { role: "ai", text: "抱歉，战略顾问接口连接超时，请检查您的 GEMINI_API_KEY 环境变量。" };
          }
          return updated;
        });
      }
    });
  };

  return (
    <div className="flex-1 flex flex-col bg-[#F6F3EF] h-full">
      {/* Scrollable messages area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 max-w-4xl mx-auto w-full text-left">
        
        {/* Intro prompt triggers */}
        <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs mb-4">
          <h3 className="text-xs font-bold uppercase tracking-widest text-[#7D101B] mb-3 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-[#D92D3F]" />
            <span>{lang === "zh-CN" ? "快速咨询主题（点击直接提问）" : "Pre-configured Scenarios"}</span>
          </h3>
          <div className="space-y-2 text-xs">
            {prewrittenPrompts.map((item, idx) => (
              <button
                key={idx}
                disabled={isPending}
                onClick={() => handleSendMessage(item.prompt)}
                className="w-full text-left p-3 border border-stone-200 rounded-xl bg-stone-50 hover:bg-[#7D101B]/5 hover:border-[#7D101B] transition font-medium text-stone-700 block whitespace-normal"
              >
                {lang === "zh-CN" ? item.zh : item.en}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Bubbles */}
        <div className="space-y-4">
          {messages.map((msg, idx) => {
            const isUser = msg.role === "user";
            return (
              <div 
                key={idx} 
                className={`flex gap-3 max-w-[85%] ${isUser ? "ml-auto flex-row-reverse" : "mr-auto"}`}
              >
                {/* Avatar */}
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  isUser ? "bg-stone-800 text-white" : "bg-[#7D101B] text-white"
                }`}>
                  {isUser ? "ME" : "OS"}
                </div>

                {/* Message Bubble */}
                <div className={`rounded-2xl p-4 text-xs leading-relaxed border ${
                  isUser 
                  ? "bg-[#7D101B] text-white border-[#7D101B] rounded-tr-none" 
                  : "bg-white text-stone-800 border-stone-200 rounded-tl-none"
                }`}>
                  <p className="whitespace-pre-line font-medium">{msg.text}</p>
                </div>
              </div>
            );
          })}

          {isPending && (
            <div className="flex gap-3 max-w-[80%] mr-auto items-center text-xs text-stone-500">
              <Loader2 className="w-4 h-4 animate-spin text-[#7D101B]" />
              <span>{lang === "zh-CN" ? "赤焰AI顾问正在精密推演中..." : "Analyzing retail database..."}</span>
            </div>
          )}
        </div>
      </div>

      {/* Input controls at bottom */}
      <div className="bg-white border-t border-stone-200 p-4 shrink-0">
        <div className="max-w-4xl mx-auto flex gap-3">
          <input 
            type="text"
            disabled={isPending}
            placeholder={lang === "zh-CN" ? "向商业顾问提问，如：‘帮我优化拿铁的奶泡配比降低供应链损耗’" : "Ask about pricing models, rosters, bean supply..."}
            className="flex-1 border border-stone-300 rounded-xl px-4 py-3 text-xs outline-none focus:border-[#7D101B] text-stone-800 disabled:bg-stone-100"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSendMessage(query)}
          />
          <button
            disabled={isPending || !query.trim()}
            onClick={() => handleSendMessage(query)}
            className="bg-[#7D101B] hover:bg-[#A51625] text-white px-5 rounded-xl font-bold transition flex items-center justify-center gap-1.5 disabled:bg-stone-300 disabled:cursor-not-allowed"
          >
            <Send className="w-4 h-4" />
            <span className="text-xs tracking-wider font-bold">{lang === "zh-CN" ? "发送" : "Consult"}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
