import { useState, useTransition, useId } from "react";
import { 
  MapPin, 
  ShoppingBag, 
  ChevronRight, 
  Search, 
  X, 
  Plus, 
  Minus, 
  Sparkles, 
  Check, 
  RotateCcw, 
  Info, 
  Flame, 
  Coins, 
  ShieldAlert 
} from "lucide-react";
import { MenuItem, Store, CartItem, Order, OrderStatus, OrderType, CustomizationOption } from "../lib/types";
import { fictionalProducts, fictionalStores, categories } from "../lib/mockData";

interface CustomerAppProps {
  lang: "zh-CN" | "en-GB";
  selectedStore: Store;
  onSelectStore: (store: Store) => void;
  activeOrders: Order[];
  onAddOrder: (order: Order) => void;
  inventory: any[];
}

export default function CustomerApp({
  lang,
  selectedStore,
  onSelectStore,
  activeOrders,
  onAddOrder,
  inventory
}: CustomerAppProps) {
  const [activeCategory, setActiveCategory] = useState<string>("limited");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isStoreModalOpen, setIsStoreModalOpen] = useState<boolean>(false);
  const [selectedProduct, setSelectedProduct] = useState<MenuItem | null>(null);
  
  // Customization State
  const [customOption, setCustomOption] = useState<CustomizationOption>({
    size: "中杯",
    temp: "冰",
    milk: "全脂牛奶",
    sweetness: "五分糖",
    espresso: "标准浓度",
    toppings: []
  });

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [orderType, setOrderType] = useState<OrderType>(OrderType.PICKUP);
  const [promoCode, setPromoCode] = useState<string>("");
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<string>("WECHAT_PAY_SIMULATOR");
  const [activeTrackingOrder, setActiveTrackingOrder] = useState<Order | null>(null);

  // Filter products by availability and categories
  const filteredProducts = fictionalProducts.filter(p => {
    const matchesCategory = p.category === activeCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.englishName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleOpenCustomizer = (product: MenuItem) => {
    // Check if ingredient (like oat milk) is sold out in parent inventory state
    const oatMilkItem = inventory.find(i => i.id === "CY-MILK-OAT");
    const isOatMilkSoldOut = oatMilkItem ? oatMilkItem.stockOnHand <= 0 : false;
    
    setSelectedProduct(product);
    setCustomOption({
      size: "中杯",
      temp: product.category === "coldbrew" ? "冰" : "热",
      milk: isOatMilkSoldOut ? "全脂牛奶" : (product.tags.includes("植物奶") ? "燕麦奶" : "全脂牛奶"),
      sweetness: "五分糖",
      espresso: "标准浓度",
      toppings: []
    });
  };

  const handleAddToCart = () => {
    if (!selectedProduct) return;
    
    // Calculate customization upcharges
    let upcharge = 0;
    if (customOption.size === "大杯") upcharge += 3;
    if (customOption.size === "特大杯") upcharge += 6;
    if (customOption.milk === "燕麦奶" || customOption.milk === "椰奶") upcharge += 2;
    if (customOption.espresso === "加一份浓缩") upcharge += 4;
    if (customOption.espresso === "加两份浓缩") upcharge += 7;
    upcharge += customOption.toppings.length * 2;

    const basePrice = selectedProduct.promoPrice || selectedProduct.basePrice;
    const itemPrice = basePrice + upcharge;

    const newCartItem: CartItem = {
      id: `${selectedProduct.id}-${Date.now()}`,
      product: selectedProduct,
      customization: { ...customOption },
      quantity: 1,
      price: itemPrice
    };

    setCart([...cart, newCartItem]);
    setSelectedProduct(null);
  };

  const handleApplyPromo = () => {
    if (promoCode.toUpperCase() === "CHIYAN-NEW") {
      setDiscountAmount(15);
    } else if (promoCode.toUpperCase() === "AUTUMN-OSMANTHUS") {
      setDiscountAmount(10);
    } else {
      setDiscountAmount(0);
    }
  };

  const calculateSubtotal = () => {
    return cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const calculateTotal = () => {
    const sub = calculateSubtotal();
    const delivery = orderType === OrderType.DELIVERY ? 6 : 0;
    const packaging = cart.length * 1; // 1 RMB per item package
    const finalVal = sub - discountAmount + delivery + packaging;
    return finalVal < 0 ? 0 : finalVal;
  };

  const handleCreateOrder = () => {
    if (cart.length === 0) return;

    const sub = calculateSubtotal();
    const finalTotal = calculateTotal();
    const generatedId = `CY-ORD-${Math.floor(10000 + Math.random() * 90000)}`;
    const randomPickupCode = `CY-${Math.floor(100 + Math.random() * 900)}`;

    const newOrder: Order = {
      id: generatedId,
      customerName: lang === "zh-CN" ? "林先生 (Mr. Lin)" : "Mr. Lin",
      storeId: selectedStore.id,
      items: [...cart],
      type: orderType,
      status: OrderStatus.QUEUED,
      subtotal: sub,
      discount: discountAmount,
      deliveryFee: orderType === OrderType.DELIVERY ? 6 : 0,
      packagingFee: cart.length * 1,
      total: finalTotal,
      pickupCode: randomPickupCode,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      prepTimer: selectedStore.avgPrepTime * 60 + 120, // baseline estimate in seconds
      elapsedTimer: 0,
      paymentMethod,
      pointsAwarded: Math.floor(finalTotal)
    };

    onAddOrder(newOrder);
    setActiveTrackingOrder(newOrder);
    setCart([]);
    setDiscountAmount(0);
    setPromoCode("");
    setIsCartOpen(false);
  };

  // Helper trigger for Demo order 1
  const loadDemo1 = () => {
    const shanghaiStore = fictionalStores.find(s => s.id === "CY-SH-001");
    if (shanghaiStore) onSelectStore(shanghaiStore);
    
    const osmanthusLatte = fictionalProducts.find(p => p.id === "CY-PRD-01");
    if (osmanthusLatte) {
      setSelectedProduct(osmanthusLatte);
      setCustomOption({
        size: "中杯",
        temp: "冰",
        milk: "燕麦奶",
        sweetness: "五分糖",
        espresso: "加一份浓缩",
        toppings: []
      });
      setOrderType(OrderType.PICKUP);
    }
  };

  // Helper trigger for Demo order 2
  const loadDemo2 = () => {
    const shenzhenStore = fictionalStores.find(s => s.id === "CY-SZ-022");
    if (shenzhenStore) onSelectStore(shenzhenStore);

    const americano = fictionalProducts.find(p => p.id === "CY-PRD-02");
    if (americano) {
      setSelectedProduct(americano);
      setCustomOption({
        size: "大杯",
        temp: "冰",
        milk: "全脂牛奶",
        sweetness: "无糖",
        espresso: "标准浓度",
        toppings: []
      });
      setOrderType(OrderType.DELIVERY);
    }
  };

  const getOrderStatusChineseLabel = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.QUEUED: return "排队中";
      case OrderStatus.EXTRACTING: return "萃取咖啡中";
      case OrderStatus.MILK_PREP: return "打发鲜奶中";
      case OrderStatus.ASSEMBLY: return "杯中拼配中";
      case OrderStatus.QUALITY_CHECK: return "大师质检中";
      case OrderStatus.READY_FOR_PICKUP: return "即将到店/请取餐";
      case OrderStatus.COMPLETED: return "已完成";
      case OrderStatus.CANCELLED: return "已取消";
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#171313] p-4 items-center justify-center">
      {/* Quick Scenario Triggers */}
      <div className="w-full max-w-[380px] mb-4 bg-[#292526] rounded-xl p-3 border border-[#7D101B]/30 flex flex-col gap-2">
        <div className="text-xs text-stone-400 font-medium flex items-center gap-1">
          <Flame className="w-3.5 h-3.5 text-[#D92D3F]" />
          <span>{lang === "zh-CN" ? "快速运行演示场景" : "One-Tap Demo Workflows"}</span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <button 
            onClick={loadDemo1}
            className="bg-[#7D101B] hover:bg-[#A51625] text-[#FFFDF8] py-2 px-2.5 rounded font-medium transition text-left flex flex-col justify-between h-14"
          >
            <span className="font-bold">① {lang === "zh-CN" ? "上海旗舰自取" : "SH Flagship"}</span>
            <span className="text-[10px] text-stone-300 truncate">燕麦桂花拿铁</span>
          </button>
          <button 
            onClick={loadDemo2}
            className="bg-[#292526] hover:bg-stone-800 text-[#FFFDF8] py-2 px-2.5 rounded font-medium border border-stone-700 transition text-left flex flex-col justify-between h-14"
          >
            <span className="font-bold text-[#B38A45]">② {lang === "zh-CN" ? "深圳科技外卖" : "SZ Tech Delivery"}</span>
            <span className="text-[10px] text-stone-400 truncate">琥珀美式·无糖</span>
          </button>
        </div>
      </div>

      {/* Phone Frame Emulator */}
      <div className="relative w-full max-w-[380px] h-[720px] bg-[#FFFDF8] rounded-[40px] border-[10px] border-stone-800 shadow-2xl overflow-hidden flex flex-col text-stone-900 select-none">
        
        {/* Phone Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-[22px] bg-stone-800 rounded-b-2xl z-50 flex items-center justify-center">
          <div className="w-2.5 h-2.5 bg-stone-900 rounded-full mr-2"></div>
          <div className="w-16 h-1 bg-stone-700 rounded"></div>
        </div>

        {/* Home Screen View / Active Tracking View Selector */}
        {activeTrackingOrder && activeTrackingOrder.status !== OrderStatus.COMPLETED && activeTrackingOrder.status !== OrderStatus.CANCELLED ? (
          /* Live Order Tracking Timeline screen */
          <div className="flex-1 flex flex-col bg-[#FFFDF8] pt-10 overflow-y-auto">
            <div className="bg-[#7D101B] text-[#FFFDF8] p-6 pb-8 text-center relative">
              <button 
                onClick={() => setActiveTrackingOrder(null)}
                className="absolute top-4 left-4 text-white hover:opacity-80 p-1"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
              <h3 className="text-sm tracking-widest opacity-80 mt-2">
                {lang === "zh-CN" ? "赤焰智能追踪" : "Live Production Tracking"}
              </h3>
              <p className="text-2xl font-bold font-serif tracking-wider mt-1">
                {getOrderStatusChineseLabel(activeTrackingOrder.status)}
              </p>
              
              {/* Pickup credentials */}
              {activeTrackingOrder.status === OrderStatus.READY_FOR_PICKUP ? (
                <div className="mt-4 bg-[#FFFDF8] text-stone-900 mx-auto rounded-xl p-4 max-w-[280px] shadow-lg border-2 border-[#B38A45] animate-pulse">
                  <div className="text-xs text-stone-500 font-bold uppercase tracking-wider">
                    {lang === "zh-CN" ? "请凭码取杯" : "Scan to Pickup"}
                  </div>
                  <div className="text-3xl font-extrabold text-[#7D101B] tracking-widest font-mono my-1">
                    {activeTrackingOrder.pickupCode}
                  </div>
                  <div className="w-full h-8 bg-[repeating-linear-gradient(90deg,#171313,#171313_4px,#fff_4px,#fff_10px)] border-t border-stone-100 mt-2"></div>
                </div>
              ) : (
                <div className="text-xs opacity-90 mt-2">
                  {lang === "zh-CN" ? "预计等待约" : "Est. remaining"} <span className="font-bold text-[#B38A45]">{(activeTrackingOrder.status === OrderStatus.QUEUED ? 4 : 2) * 60}s</span>
                </div>
              )}
            </div>

            {/* Visual Timeline Steps */}
            <div className="flex-1 p-6 flex flex-col justify-start">
              <div className="border-l-2 border-[#7D101B]/20 ml-3.5 space-y-6">
                
                {[
                  { status: OrderStatus.QUEUED, title: "排队待确认", desc: "订单进入赤焰排队系统" },
                  { status: OrderStatus.EXTRACTING, title: "变压浓缩萃取", desc: "大师级精准水压提取" },
                  { status: OrderStatus.MILK_PREP, title: "鲜奶绵密打发", desc: "蒸汽控制完美起泡" },
                  { status: OrderStatus.ASSEMBLY, title: "饮品装配融合", desc: "天然桂花蜜杯中对冲" },
                  { status: OrderStatus.QUALITY_CHECK, title: "大师品质出厂", desc: "温度、流速、克重检测" },
                  { status: OrderStatus.READY_FOR_PICKUP, title: "已装杯待取餐", desc: "置于保温吧台，请即刻享用" }
                ].map((step, idx) => {
                  const orderStatuses = Object.values(OrderStatus);
                  const currentIdx = orderStatuses.indexOf(activeTrackingOrder.status);
                  const stepIdx = orderStatuses.indexOf(step.status);
                  const isCurrent = activeTrackingOrder.status === step.status;
                  const isPassed = stepIdx < currentIdx;

                  return (
                    <div key={idx} className="relative flex items-start gap-4">
                      {/* Timeline Ball indicator */}
                      <div className={`absolute -left-[23px] w-4 h-4 rounded-full border-2 flex items-center justify-center transition-all ${
                        isPassed ? "bg-[#7D101B] border-[#7D101B] text-white" :
                        isCurrent ? "bg-[#D92D3F] border-[#D92D3F] scale-125 shadow-md shadow-[#D92D3F]/40" :
                        "bg-[#FFFDF8] border-stone-300"
                      }`}>
                        {isPassed && <Check className="w-2.5 h-2.5 text-white stroke-[3px]" />}
                      </div>

                      <div className="pl-3">
                        <h4 className={`text-sm font-bold leading-none ${isCurrent ? "text-[#7D101B]" : "text-stone-800"}`}>
                          {step.title}
                        </h4>
                        <p className="text-xs text-stone-500 mt-1">{step.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Order Traceability & Details Footer card */}
              <div className="mt-8 bg-[#F6F3EF] rounded-xl p-4 border border-stone-200">
                <div className="text-xs font-bold text-stone-700 border-b border-stone-200 pb-2 mb-2 flex justify-between items-center">
                  <span>{lang === "zh-CN" ? "单源咖啡豆溯源档案" : "Coffee Provenance Index"}</span>
                  <span className="text-[#B38A45] font-mono">CY-BEAN-00041</span>
                </div>
                <div className="text-xs text-stone-600 space-y-1">
                  <div>• {lang === "zh-CN" ? "产地" : "Origin"}: <span className="font-medium text-stone-900">保山新寨坝 (Baoshan, Yunnan)</span></div>
                  <div>• {lang === "zh-CN" ? "批次" : "Lot"}: <span className="font-mono text-[#7D101B]">YNC-2026-A1</span></div>
                  <div>• {lang === "zh-CN" ? "工艺" : "Process"}: <span className="font-medium text-stone-900">精品水洗双重厌氧</span></div>
                  <div>• {lang === "zh-CN" ? "烘焙日期" : "Roast Date"}: <span className="font-mono">2026-09-10</span></div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Normal Retail Flow screen */
          <div className="flex-1 flex flex-col pt-10">
            {/* Header Block */}
            <div className="p-4 bg-[#7D101B] text-[#FFFDF8] flex flex-col relative">
              <div className="flex justify-between items-center">
                <span className="text-lg font-serif font-bold tracking-wider">CHÌYÀN • 赤焰咖啡</span>
                <span className="text-[10px] tracking-widest uppercase text-[#B38A45]">Roasted For The City</span>
              </div>
              
              {/* Selected Store Selector Card */}
              <div 
                onClick={() => setIsStoreModalOpen(true)}
                className="mt-3 bg-[#FFFDF8] text-stone-950 p-3 rounded-xl shadow flex justify-between items-center cursor-pointer hover:bg-stone-50 transition"
              >
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#7D101B]" />
                  <div className="text-left">
                    <p className="text-xs font-bold font-sans">{selectedStore.name}</p>
                    <p className="text-[10px] text-stone-500 truncate max-w-[200px]">{selectedStore.address}</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-stone-400" />
              </div>
            </div>

            {/* Custom Horizontal Category Bar */}
            <div className="flex overflow-x-auto bg-[#F6F3EF] border-b border-stone-200 py-2.5 px-3 scrollbar-none">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`text-xs px-3.5 py-1.5 rounded-full font-bold mr-2 whitespace-nowrap transition-colors ${
                    activeCategory === cat.id 
                    ? "bg-[#7D101B] text-[#FFFDF8]" 
                    : "bg-stone-200/60 text-stone-700 hover:bg-stone-200"
                  }`}
                >
                  {lang === "zh-CN" ? cat.zh : cat.en}
                </button>
              ))}
            </div>

            {/* Live Search and Banner */}
            <div className="p-3 bg-[#FFFDF8] border-b border-stone-100 flex items-center gap-2">
              <div className="flex-1 bg-stone-100 rounded-lg flex items-center px-2.5 py-1.5 border border-stone-200">
                <Search className="w-3.5 h-3.5 text-stone-400 mr-2" />
                <input 
                  type="text" 
                  placeholder={lang === "zh-CN" ? "搜索咖啡、面包..." : "Search coffee, pastry..."}
                  className="bg-transparent text-xs outline-none w-full text-stone-800"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            {/* Active tracking ticker overlay */}
            {activeOrders.some(o => o.status !== OrderStatus.COMPLETED) && (
              <div 
                onClick={() => {
                  const active = activeOrders.find(o => o.status !== OrderStatus.COMPLETED);
                  if (active) setActiveTrackingOrder(active);
                }}
                className="bg-[#D92D3F] text-white px-4 py-2 text-xs font-bold text-center flex items-center justify-between cursor-pointer animate-pulse"
              >
                <span>☕ {lang === "zh-CN" ? "您的咖啡正在萃取中！" : "Your coffee is being brewed!"}</span>
                <span className="underline">{lang === "zh-CN" ? "点击追踪" : "Track Order"} →</span>
              </div>
            )}

            {/* Product Grid Area */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-[#FFFDF8]">
              {filteredProducts.length === 0 ? (
                <div className="text-center py-12 text-stone-400 text-xs">
                  {lang === "zh-CN" ? "暂无相关饮品" : "No beverages found"}
                </div>
              ) : (
                filteredProducts.map((p) => {
                  return (
                    <div 
                      key={p.id}
                      className="bg-[#F6F3EF]/60 hover:bg-[#F6F3EF] transition rounded-xl p-3 border border-stone-200/50 flex gap-3 cursor-pointer"
                      onClick={() => handleOpenCustomizer(p)}
                    >
                      {/* Product Image */}
                      <div className="relative w-20 h-20 bg-stone-200 rounded-lg overflow-hidden shrink-0">
                        <img 
                          src={p.image} 
                          alt={p.name} 
                          className="object-cover w-full h-full"
                        />
                        {p.promoPrice && (
                          <div className="absolute top-0 left-0 bg-[#7D101B] text-[#FFFDF8] text-[9px] font-bold px-1.5 py-0.5 rounded-br">
                            {lang === "zh-CN" ? "特惠" : "PROMO"}
                          </div>
                        )}
                      </div>

                      {/* Product Info */}
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start">
                            <h4 className="text-sm font-bold text-stone-900 font-serif">{p.name}</h4>
                            <span className="text-xs font-extrabold text-[#7D101B] font-mono">
                              ￥{p.promoPrice || p.basePrice}
                            </span>
                          </div>
                          <p className="text-[10px] text-stone-400 font-sans tracking-wide leading-none">{p.englishName}</p>
                          <p className="text-[10px] text-stone-500 line-clamp-2 mt-1 leading-normal">{p.description}</p>
                        </div>

                        {/* Badges */}
                        <div className="flex flex-wrap gap-1 mt-1">
                          {p.tags.map((t, idx) => (
                            <span key={idx} className="bg-stone-200 text-stone-600 text-[8px] font-bold px-1 py-0.5 rounded">
                              {t}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Bottom Sticky Action Bar (Floating Cart Trigger) */}
            <div className="bg-[#FFFDF8] border-t border-stone-200 p-4 flex justify-between items-center relative shadow-[0_-4px_12px_rgba(0,0,0,0.03)]">
              {cart.length > 0 ? (
                <div 
                  onClick={() => setIsCartOpen(true)}
                  className="flex-1 bg-[#7D101B] hover:bg-[#A51625] text-white py-3 px-4 rounded-xl flex justify-between items-center cursor-pointer transition shadow-lg"
                >
                  <div className="flex items-center gap-2">
                    <div className="bg-[#FFFDF8] text-[#7D101B] w-5 h-5 rounded-full flex items-center justify-center font-bold text-xs">
                      {cart.length}
                    </div>
                    <span className="text-xs font-bold">{lang === "zh-CN" ? "查看购物车" : "View Basket"}</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-bold">
                    <span className="text-xs">￥{calculateTotal()}</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </div>
              ) : (
                <div className="flex-1 text-center py-2 text-xs text-stone-400 font-medium">
                  {lang === "zh-CN" ? "选择美味饮品开始享受日常" : "Select beverages to begin"}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Store Locator Modals */}
        {isStoreModalOpen && (
          <div className="absolute inset-0 bg-[#171313]/60 backdrop-blur-xs z-[100] flex flex-col justify-end">
            <div className="bg-[#FFFDF8] rounded-t-3xl p-4 max-h-[85%] flex flex-col text-stone-800">
              <div className="flex justify-between items-center border-b border-stone-200 pb-3 mb-3">
                <h3 className="text-sm font-bold font-serif text-[#7D101B]">{lang === "zh-CN" ? "选择赤焰咖啡门店" : "Select Store"}</h3>
                <button onClick={() => setIsStoreModalOpen(false)}>
                  <X className="w-4 h-4 text-stone-400" />
                </button>
              </div>
              <div className="space-y-2 overflow-y-auto pr-1">
                {fictionalStores.map((s) => (
                  <div 
                    key={s.id}
                    onClick={() => {
                      onSelectStore(s);
                      setIsStoreModalOpen(false);
                    }}
                    className={`p-3 rounded-xl border cursor-pointer transition flex justify-between items-center ${
                      selectedStore.id === s.id 
                      ? "border-[#7D101B] bg-[#7D101B]/5" 
                      : "border-stone-200 bg-stone-50 hover:bg-stone-100"
                    }`}
                  >
                    <div className="text-left">
                      <p className="text-xs font-bold text-stone-900">{s.name}</p>
                      <p className="text-[10px] text-stone-500 mt-0.5">{s.address}</p>
                      <div className="flex gap-2 mt-1.5">
                        <span className="bg-stone-200 text-stone-600 text-[8px] font-bold px-1.5 py-0.5 rounded">
                          {lang === "zh-CN" ? "排队中" : "Queue"}: {s.queueLength} {lang === "zh-CN" ? "单" : "orders"}
                        </span>
                        <span className="bg-[#FFFDF8] text-[#B38A45] border border-[#B38A45]/30 text-[8px] font-bold px-1.5 py-0.5 rounded">
                          {lang === "zh-CN" ? "平均制作" : "Est."} {s.avgPrepTime} min
                        </span>
                      </div>
                    </div>
                    {selectedStore.id === s.id && <Check className="w-4 h-4 text-[#7D101B]" />}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Customization bottom sheet modal */}
        {selectedProduct && (
          <div className="absolute inset-0 bg-[#171313]/60 backdrop-blur-xs z-[100] flex flex-col justify-end">
            <div className="bg-[#FFFDF8] rounded-t-3xl p-5 max-h-[90%] flex flex-col text-stone-800">
              <div className="flex justify-between items-start pb-3 border-b border-stone-200 mb-4">
                <div>
                  <h3 className="text-base font-bold font-serif text-[#7D101B]">{selectedProduct.name}</h3>
                  <p className="text-[10px] text-stone-400 mt-0.5">{selectedProduct.englishName}</p>
                </div>
                <button onClick={() => setSelectedProduct(null)}>
                  <X className="w-5 h-5 text-stone-400" />
                </button>
              </div>

              {/* Scrolling Option Groups */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-1 text-left">
                {/* Size */}
                <div>
                  <h4 className="text-xs font-bold text-stone-600 mb-2">{lang === "zh-CN" ? "杯型" : "Size"}</h4>
                  <div className="grid grid-cols-3 gap-2">
                    {["中杯", "大杯", "特大杯"].map((size) => (
                      <button
                        key={size}
                        onClick={() => setCustomOption({ ...customOption, size: size as any })}
                        className={`text-xs font-bold py-2 px-1 border rounded-lg transition-colors ${
                          customOption.size === size 
                          ? "border-[#7D101B] bg-[#7D101B]/5 text-[#7D101B]" 
                          : "border-stone-200 text-stone-600 hover:bg-stone-50"
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Temperature */}
                <div>
                  <h4 className="text-xs font-bold text-stone-600 mb-2">{lang === "zh-CN" ? "温度" : "Temperature"}</h4>
                  <div className="grid grid-cols-4 gap-2">
                    {["热", "冰", "少冰", "去冰"].map((temp) => (
                      <button
                        key={temp}
                        onClick={() => setCustomOption({ ...customOption, temp: temp as any })}
                        className={`text-xs font-bold py-2 px-1 border rounded-lg transition-colors ${
                          customOption.temp === temp 
                          ? "border-[#7D101B] bg-[#7D101B]/5 text-[#7D101B]" 
                          : "border-stone-200 text-stone-600 hover:bg-stone-50"
                        }`}
                      >
                        {temp}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Sweetness */}
                <div>
                  <h4 className="text-xs font-bold text-stone-600 mb-2">{lang === "zh-CN" ? "甜度" : "Sweetness"}</h4>
                  <div className="grid grid-cols-5 gap-1">
                    {["无糖", "三分糖", "五分糖", "七分糖", "全糖"].map((sw) => (
                      <button
                        key={sw}
                        onClick={() => setCustomOption({ ...customOption, sweetness: sw as any })}
                        className={`text-[10px] font-bold py-2 border rounded transition-colors ${
                          customOption.sweetness === sw 
                          ? "border-[#7D101B] bg-[#7D101B]/5 text-[#7D101B]" 
                          : "border-stone-200 text-stone-600 hover:bg-stone-50"
                        }`}
                      >
                        {sw}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Milk */}
                <div>
                  <h4 className="text-xs font-bold text-stone-600 mb-2">{lang === "zh-CN" ? "基底奶" : "Milk Option"}</h4>
                  <div className="grid grid-cols-3 gap-2">
                    {["全脂牛奶", "低脂牛奶", "燕麦奶"].map((milk) => {
                      const isOatMilk = milk === "燕麦奶";
                      const oatMilkItem = inventory.find(i => i.id === "CY-MILK-OAT");
                      const isOatSoldOut = oatMilkItem ? oatMilkItem.stockOnHand <= 0 : false;
                      return (
                        <button
                          key={milk}
                          disabled={isOatMilk && isOatSoldOut}
                          onClick={() => setCustomOption({ ...customOption, milk: milk as any })}
                          className={`text-xs font-bold py-2 px-1 border rounded-lg transition-all relative ${
                            isOatMilk && isOatSoldOut 
                            ? "opacity-40 cursor-not-allowed bg-stone-100 border-dashed" 
                            : customOption.milk === milk 
                              ? "border-[#7D101B] bg-[#7D101B]/5 text-[#7D101B]" 
                              : "border-stone-200 text-stone-600 hover:bg-stone-50"
                          }`}
                        >
                          {milk}
                          {isOatMilk && isOatSoldOut && (
                            <span className="absolute top-0 right-0 bg-[#171313] text-white text-[7px] px-1 rounded-bl">售罄</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Extra Shot */}
                <div>
                  <h4 className="text-xs font-bold text-stone-600 mb-2">{lang === "zh-CN" ? "浓缩咖啡" : "Espresso"}</h4>
                  <div className="grid grid-cols-3 gap-2">
                    {["标准浓度", "加一份浓缩", "加两份浓缩"].map((esp) => (
                      <button
                        key={esp}
                        onClick={() => setCustomOption({ ...customOption, espresso: esp as any })}
                        className={`text-xs font-bold py-2 px-1 border rounded-lg transition-colors ${
                          customOption.espresso === esp 
                          ? "border-[#7D101B] bg-[#7D101B]/5 text-[#7D101B]" 
                          : "border-stone-200 text-stone-600 hover:bg-stone-50"
                        }`}
                      >
                        {esp}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Price & Add to Cart Action */}
              <div className="border-t border-stone-200 pt-4 mt-4 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-stone-500 uppercase font-bold tracking-wider">{lang === "zh-CN" ? "价格估算" : "Estimated Cost"}</span>
                  <div className="text-2xl font-black text-[#7D101B] font-mono leading-none mt-1">
                    ￥{selectedProduct.promoPrice || selectedProduct.basePrice}
                  </div>
                </div>
                <button
                  onClick={handleAddToCart}
                  className="bg-[#7D101B] hover:bg-[#A51625] text-[#FFFDF8] px-8 py-3 rounded-xl font-bold text-sm tracking-widest transition"
                >
                  {lang === "zh-CN" ? "加入购物车" : "Add to Cart"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Cart/Checkout Slide-Over panel */}
        {isCartOpen && (
          <div className="absolute inset-0 bg-[#171313]/60 backdrop-blur-xs z-[100] flex flex-col justify-end">
            <div className="bg-[#FFFDF8] rounded-t-3xl p-5 max-h-[92%] flex flex-col text-stone-800">
              <div className="flex justify-between items-center pb-3 border-b border-stone-200 mb-4">
                <h3 className="text-base font-bold font-serif text-[#7D101B]">{lang === "zh-CN" ? "确认订单明细" : "Cart Checkout"}</h3>
                <button onClick={() => setIsCartOpen(false)}>
                  <X className="w-5 h-5 text-stone-400" />
                </button>
              </div>

              {/* Scrollable Cart Items */}
              <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-left">
                
                {/* Delivery Type Switcher */}
                <div className="flex bg-[#F6F3EF] p-1 rounded-lg border border-stone-200/50 mb-3">
                  <button 
                    onClick={() => setOrderType(OrderType.PICKUP)}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-md transition ${
                      orderType === OrderType.PICKUP 
                      ? "bg-[#7D101B] text-white" 
                      : "text-stone-600 hover:text-[#7D101B]"
                    }`}
                  >
                    🚶 {lang === "zh-CN" ? "到店自取" : "Store Pickup"}
                  </button>
                  <button 
                    onClick={() => setOrderType(OrderType.DELIVERY)}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-md transition ${
                      orderType === OrderType.DELIVERY 
                      ? "bg-[#7D101B] text-white" 
                      : "text-stone-600 hover:text-[#7D101B]"
                    }`}
                  >
                    🛵 {lang === "zh-CN" ? "外卖配送" : "Delivery"}
                  </button>
                </div>

                {cart.map((item) => (
                  <div key={item.id} className="bg-stone-50 rounded-xl p-3 border border-stone-200 flex justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-stone-900">{item.product.name}</h4>
                      <div className="text-[10px] text-stone-500 mt-1 space-y-0.5">
                        <div>• {item.customization.size} / {item.customization.temp} / {item.customization.sweetness}</div>
                        <div>• {item.customization.milk} / {item.customization.espresso}</div>
                      </div>
                    </div>
                    <div className="flex flex-col justify-between items-end">
                      <span className="text-xs font-bold text-[#7D101B] font-mono">￥{item.price * item.quantity}</span>
                      <div className="flex items-center gap-2 bg-stone-200 rounded-lg p-0.5 mt-2">
                        <button 
                          onClick={() => {
                            if (item.quantity > 1) {
                              setCart(cart.map(i => i.id === item.id ? { ...i, quantity: i.quantity - 1 } : i));
                            } else {
                              setCart(cart.filter(i => i.id !== item.id));
                            }
                          }}
                          className="p-1 hover:bg-stone-300 rounded"
                        >
                          <Minus className="w-3 h-3 text-stone-600" />
                        </button>
                        <span className="text-xs font-extrabold px-1 font-mono">{item.quantity}</span>
                        <button 
                          onClick={() => {
                            setCart(cart.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i));
                          }}
                          className="p-1 hover:bg-stone-300 rounded"
                        >
                          <Plus className="w-3 h-3 text-stone-600" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Promo Code inputs */}
                <div className="bg-[#FFFDF8] border border-stone-200 rounded-xl p-3 mt-4">
                  <div className="text-xs font-bold text-stone-700 mb-2">{lang === "zh-CN" ? "可用的模拟优惠券" : "Simulated Coupons"}</div>
                  <div className="text-[10px] text-stone-500 mb-2 font-mono">
                    • <strong>CHIYAN-NEW</strong> (立减15元)<br/>
                    • <strong>AUTUMN-OSMANTHUS</strong> (立减10元)
                  </div>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      placeholder={lang === "zh-CN" ? "输入折扣码" : "PROMO Code"}
                      className="border border-stone-300 rounded-lg px-2.5 py-1.5 text-xs flex-1 uppercase outline-none text-stone-800"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                    />
                    <button 
                      onClick={handleApplyPromo}
                      className="bg-stone-800 hover:bg-stone-900 text-white text-xs px-4 py-1.5 rounded-lg font-bold"
                    >
                      {lang === "zh-CN" ? "核销" : "Apply"}
                    </button>
                  </div>
                </div>

                {/* Payment Simulation Selector */}
                <div className="mt-4">
                  <h4 className="text-xs font-bold text-stone-600 mb-2">{lang === "zh-CN" ? "支付通道模拟" : "Payment Gateway"}</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {[
                      { id: "WECHAT_PAY_SIMULATOR", label: "微信支付 (微信)" },
                      { id: "ALIPAY_SIMULATOR", label: "支付宝 (Alipay)" },
                      { id: "CHiyan_WALLET_SIMULATOR", label: "赤焰钱包 (余额)" }
                    ].map((m) => (
                      <button
                        key={m.id}
                        onClick={() => setPaymentMethod(m.id)}
                        className={`p-2.5 border rounded-lg text-left font-bold truncate ${
                          paymentMethod === m.id 
                          ? "border-[#7D101B] bg-[#7D101B]/5 text-[#7D101B]" 
                          : "border-stone-200 text-stone-600 hover:bg-stone-50"
                        }`}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Price Ledger breakdown */}
                <div className="border-t border-stone-200 pt-3 mt-4 space-y-1.5 text-xs text-stone-600">
                  <div className="flex justify-between">
                    <span>{lang === "zh-CN" ? "商品总额" : "Subtotal"}</span>
                    <span className="font-mono">￥{calculateSubtotal()}</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-[#7D101B] font-bold">
                      <span>{lang === "zh-CN" ? "优惠金额" : "Coupon Discount"}</span>
                      <span className="font-mono">-￥{discountAmount}</span>
                    </div>
                  )}
                  {orderType === OrderType.DELIVERY && (
                    <div className="flex justify-between">
                      <span>{lang === "zh-CN" ? "配送费用" : "Delivery Fee"}</span>
                      <span className="font-mono">￥6</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>{lang === "zh-CN" ? "环保包材费" : "Packaging Fee"}</span>
                    <span className="font-mono">￥{cart.length * 1}</span>
                  </div>
                </div>
              </div>

              {/* Confirm Pay Action */}
              <div className="border-t border-stone-200 pt-4 mt-4 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-stone-500 uppercase font-bold tracking-wider">{lang === "zh-CN" ? "应付合计" : "Total Due"}</span>
                  <div className="text-2xl font-black text-[#7D101B] font-mono leading-none mt-1">
                    ￥{calculateTotal()}
                  </div>
                </div>
                <button
                  onClick={handleCreateOrder}
                  className="bg-[#7D101B] hover:bg-[#A51625] text-white px-8 py-3.5 rounded-xl font-bold text-sm tracking-widest transition shadow-lg"
                >
                  💳 {lang === "zh-CN" ? "确认模拟支付" : "Pay Simulator"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
