'use client';

import React from 'react';
import { ArrowRight, ChevronRight, Activity } from 'lucide-react';

interface MarketQuote {
  id: string;
  code: string;
  name: string;
  englishName: string;
  unit: string;
  cnyUnit: string;
  cnyPrice: number;
  price: number;
  bid: number;
  ask: number;
  changeAmount: number;
  changePercent: number;
  high24h: number;
  low24h: number;
  sparkline: number[];
}

interface MarketStripProps {
  quotes: MarketQuote[];
  timestamp: string;
  onNavigate: (sectionId: string) => void;
  onSelectMetal: (metal: MarketQuote) => void;
}

export const MarketStrip: React.FC<MarketStripProps> = ({
  quotes,
  timestamp,
  onNavigate,
  onSelectMetal
}) => {
  const displayMetals = quotes.filter(q => ['XAUUSD', 'XAGUSD', 'XPTUSD', 'XPDUSD'].includes(q.code));

  return (
    <section className="bg-[#0e1015] border-y border-[#1c202c] py-6 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-4">
        
        {/* Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('market')}
              className="text-lg font-bold text-white hover:text-[#d4af37] transition-colors flex items-center gap-1 group"
            >
              <span>贵金属实时行情</span>
              <ChevronRight className="w-5 h-5 text-[#d4af37] group-hover:translate-x-1 transition-transform" />
            </button>
            <span className="hidden sm:inline text-[#3a4154]">|</span>
            <span className="text-xs text-[#8e94a5] font-mono flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#22c55e] animate-ping" />
              {timestamp || '2026年10月05日 18:28 (北京时间)'}
            </span>
          </div>

          <button
            onClick={() => onNavigate('market')}
            className="text-xs font-medium text-[#d4af37] hover:text-[#f3d772] flex items-center gap-1 transition-colors self-start sm:self-auto"
          >
            <span>查看全部行情</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 4 Quotes Grid matching image */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {displayMetals.map((metal) => {
            const isPositive = metal.changePercent >= 0;
            return (
              <button
                key={metal.code}
                onClick={() => onSelectMetal(metal)}
                className="bg-[#141720] border border-[#232836] hover:border-[#d4af37]/50 rounded-xl p-4 text-left transition-all hover:bg-[#1a1e2b] group shadow-lg"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-[#242b3d] text-[#d4af37] flex items-center justify-center font-bold text-xs">
                      {metal.name[0]}
                    </div>
                    <div>
                      <span className="text-sm font-bold text-white group-hover:text-[#f3d772] transition-colors">
                        {metal.name}
                      </span>
                      <span className="ml-1.5 text-[11px] font-mono text-[#8e94a5]">
                        {metal.code}
                      </span>
                    </div>
                  </div>
                  <span className="text-[11px] text-[#8e94a5] font-mono">
                    ￥{metal.cnyPrice}/克
                  </span>
                </div>

                <div className="flex items-end justify-between mt-3">
                  <div>
                    <div className="text-2xl font-bold font-mono text-white tracking-tight">
                      {metal.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                    <div className={`text-xs font-mono font-medium flex items-center gap-1.5 mt-0.5 ${isPositive ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
                      <span>{isPositive ? '+' : ''}{metal.changeAmount}</span>
                      <span>({isPositive ? '+' : ''}{metal.changePercent}%)</span>
                    </div>
                  </div>

                  {/* Sparkline Canvas / SVG */}
                  <div className="w-20 h-9">
                    <svg className="w-full h-full overflow-visible" viewBox="0 0 80 30">
                      <polyline
                        fill="none"
                        stroke={isPositive ? '#22c55e' : '#ef4444'}
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        points={metal.sparkline.map((val, idx) => {
                          const min = Math.min(...metal.sparkline);
                          const max = Math.max(...metal.sparkline);
                          const range = max - min || 1;
                          const x = (idx / (metal.sparkline.length - 1)) * 76 + 2;
                          const y = 28 - ((val - min) / range) * 24;
                          return `${x},${y}`;
                        }).join(' ')}
                      />
                    </svg>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

      </div>
    </section>
  );
};
