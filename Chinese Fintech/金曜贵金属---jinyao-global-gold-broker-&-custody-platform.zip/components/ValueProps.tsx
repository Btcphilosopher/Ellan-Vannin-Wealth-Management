'use client';

import React from 'react';
import { ShieldCheck, Globe, Users, Lock, Smartphone } from 'lucide-react';

export const ValueProps: React.FC = () => {
  const props = [
    {
      icon: ShieldCheck,
      title: '权威监管',
      desc: '受多国金融监管，资金安全有保障'
    },
    {
      icon: Globe,
      title: '全球市场',
      desc: '连接国际市场，交易品种丰富'
    },
    {
      icon: Users,
      title: '专业团队',
      desc: '资深分析师团队，提供专业支持'
    },
    {
      icon: Lock,
      title: '安全托管',
      desc: '多重风控体系，保障资产安全'
    },
    {
      icon: Smartphone,
      title: '便捷交易',
      desc: 'PC / 移动端，随时随地把握机会'
    }
  ];

  return (
    <section className="bg-[#0a0b0e] py-10 border-b border-[#1f2432]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 divide-y sm:divide-y-0 sm:divide-x divide-[#1e2330]">
          {props.map((p, idx) => {
            const IconComponent = p.icon;
            return (
              <div 
                key={idx} 
                className={`pt-4 sm:pt-0 ${idx > 0 ? 'sm:pl-6' : ''} flex flex-col items-center sm:items-start text-center sm:text-left space-y-2 group`}
              >
                <div className="w-10 h-10 rounded-xl bg-[#141822] border border-[#272d3e] group-hover:border-[#d4af37] text-[#d4af37] flex items-center justify-center transition-all group-hover:scale-105">
                  <IconComponent className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white group-hover:text-[#f3d772] transition-colors">
                    {p.title}
                  </h3>
                  <p className="text-xs text-[#8e94a5] mt-1 leading-relaxed">
                    {p.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
