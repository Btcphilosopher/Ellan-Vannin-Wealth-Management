'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, Bot, Sparkles, Send, TrendingUp, RefreshCw, FileText } from 'lucide-react';

interface AiInsightsProps {
  spotPrice: number;
}

export const AiInsights: React.FC<AiInsightsProps> = ({ spotPrice }) => {
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  const mainArticle = {
    category: '市场洞察',
    title: '黄金再度走强，全球避险情绪升温',
    summary: '近期，受地缘政治不确定性及美元走弱影响，国际金价持续上行，市场对黄金的避险需求显著增加。',
    date: '2026年10月05日',
    image: '/images/shanghai_landscape.jpg'
  };

  const sideArticles = [
    { date: '10月04日', title: '美联储降息预期温和，黄金多头再次发力' },
    { date: '10月03日', title: '全球央行持续增持黄金储备' },
    { date: '10月01日', title: '中东局势紧张，贵金属价格走高' },
    { date: '09月28日', title: '黄金ETF持仓量连续三周净流入' },
  ];

  const runAiAnalysis = async (customPrompt?: string) => {
    setIsLoadingAi(true);
    try {
      const res = await fetch('/api/ai/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: customPrompt || aiPrompt || '分析当前黄金市场走势与未来30天趋势预测',
          spotPrice: spotPrice.toString()
        })
      });
      const data = await res.json();
      setAiResponse(data.response);
    } catch (e) {
      console.error(e);
      setAiResponse('研报分析生成失败，请重试。');
    } finally {
      setIsLoadingAi(false);
    }
  };

  return (
    <section className="bg-[#0b0c10] py-16 px-4 sm:px-6 lg:px-8 border-t border-[#1c202d]">
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Screenshot Replica Market Insights Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Main Featured Article matching screenshot */}
          <div className="lg:col-span-8 bg-[#12151e] border border-[#202534] rounded-2xl overflow-hidden shadow-xl flex flex-col md:flex-row">
            
            <div className="md:w-1/2 relative h-64 md:h-auto min-h-[240px]">
              <Image
                src={mainArticle.image}
                alt={mainArticle.title}
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="md:w-1/2 p-6 lg:p-8 flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <span className="text-xs font-semibold text-[#d4af37] tracking-wider uppercase">
                  {mainArticle.category}
                </span>
                <h3 className="text-2xl font-bold text-white leading-tight">
                  {mainArticle.title}
                </h3>
                <p className="text-xs text-[#8e94a5] leading-relaxed">
                  {mainArticle.summary}
                </p>
              </div>

              <div className="pt-4 border-t border-[#1d2232] flex items-center justify-between">
                <span className="text-[11px] font-mono text-[#8e94a5]">{mainArticle.date}</span>
                <button
                  onClick={() => runAiAnalysis('请深入解读：黄金再度走强，全球避险情绪升温的核心宏观驱动力')}
                  className="text-xs font-semibold text-[#d4af37] hover:text-[#f3d772] flex items-center gap-1 transition-colors"
                >
                  <span>阅读全文 & AI深度拆解</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>

          {/* Right News Timeline matching screenshot */}
          <div className="lg:col-span-4 bg-[#12151e] border border-[#202534] rounded-2xl p-6 flex flex-col justify-between space-y-4">
            <div className="flex items-center justify-between border-b border-[#202534] pb-3">
              <span className="text-sm font-bold text-white">最新要闻与研报</span>
              <span className="text-xs font-mono text-[#d4af37]">及时快讯</span>
            </div>

            <div className="space-y-4">
              {sideArticles.map((art, idx) => (
                <button
                  key={idx}
                  onClick={() => runAiAnalysis(`分析要闻: ${art.title}`)}
                  className="w-full flex items-start gap-3 p-2.5 rounded-lg hover:bg-[#1a1e2b] transition-colors text-left group"
                >
                  <span className="text-[11px] font-mono text-[#8e94a5] shrink-0 pt-0.5">
                    {art.date}
                  </span>
                  <span className="text-xs font-medium text-[#dce1ec] group-hover:text-[#f3d772] transition-colors line-clamp-2">
                    {art.title}
                  </span>
                </button>
              ))}
            </div>

            <div className="pt-2 border-t border-[#1d2232]">
              <button
                onClick={() => runAiAnalysis()}
                className="w-full text-center text-xs font-bold text-[#d4af37] hover:underline"
              >
                生成 Gemini AI 黄金行情周报 &rarr;
              </button>
            </div>
          </div>

        </div>

        {/* Gemini AI Analyst Terminal */}
        <div className="bg-[#121520] border border-[#d4af37]/30 rounded-2xl p-6 lg:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#222838] pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#d4af37]/10 text-[#f3d772] border border-[#d4af37]/30 flex items-center justify-center shrink-0">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  金曜 AI 首席贵金属研报分析师 (Gemini 驱动)
                  <span className="text-[10px] font-mono bg-[#d4af37]/20 text-[#f3d772] px-2 py-0.5 rounded">
                    REALTIME AI
                  </span>
                </h3>
                <p className="text-xs text-[#8e94a5]">
                  实时调取全球宏观数据、央行购金走势与量化技术指标，为您的贵金属投资决策保驾护航。
                </p>
              </div>
            </div>

            {/* Quick AI Prompt Pills */}
            <div className="flex flex-wrap gap-2">
              {[
                '预测未来30天金价',
                '美联储降息对金价影响',
                '实物金条理财建议'
              ].map((p, i) => (
                <button
                  key={i}
                  onClick={() => runAiAnalysis(p)}
                  className="px-3 py-1.5 text-xs text-[#d4af37] bg-[#1a1e2b] hover:bg-[#252b3d] border border-[#2e364a] rounded-lg transition-colors"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* AI Response Display */}
          {aiResponse && (
            <div className="p-5 bg-[#0a0b10] border border-[#252c3d] rounded-xl text-xs text-[#e1e5f0] space-y-3 leading-relaxed whitespace-pre-wrap font-sans">
              <div className="flex items-center gap-2 text-[#f3d772] font-bold text-sm">
                <Sparkles className="w-4 h-4" /> 研报洞察分析结果:
              </div>
              <div>{aiResponse}</div>
            </div>
          )}

          {/* Prompt Input Box */}
          <div className="flex items-center gap-3 bg-[#0d0f16] p-2 rounded-xl border border-[#272e40]">
            <input
              type="text"
              placeholder="向金曜 AI 咨询任何黄金行情、白银走势或资产配置问题..."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && runAiAnalysis()}
              className="w-full bg-transparent text-white text-xs px-3 focus:outline-none"
            />
            <button
              onClick={() => runAiAnalysis()}
              disabled={isLoadingAi}
              className="px-5 py-2.5 bg-gradient-to-r from-[#d4af37] to-[#b89528] text-black text-xs font-bold rounded-lg hover:opacity-95 transition-all shrink-0 inline-flex items-center gap-1.5"
            >
              {isLoadingAi ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>研报生成中...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>生成研报</span>
                </>
              )}
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};
