'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, ShieldCheck, Globe, TrendingUp } from 'lucide-react';

interface HeroProps {
  onOpenAccount: () => void;
  onNavigate: (sectionId: string) => void;
  liveQuotes: any[];
}

export const Hero: React.FC<HeroProps> = ({ onOpenAccount, onNavigate, liveQuotes }) => {
  const [selectedAssetCode, setSelectedAssetCode] = useState('XAUUSD');

  const assets = [
    { code: 'XAUUSD', name: '黄金' },
    { code: 'XAGUSD', name: '白银' },
    { code: 'XPTUSD', name: '铂金' },
    { code: 'XPDUSD', name: '钯金' },
  ];

  const activeQuote = liveQuotes.find(q => q.code === selectedAssetCode) || liveQuotes[0];

  return (
    <section className="relative w-full min-h-[640px] lg:min-h-[720px] bg-[#08090b] overflow-hidden flex items-center">
      
      {/* Background Image with Measured Gradient Scrim */}
      <div className="absolute inset-0 z-0 opacity-80">
        <Image
          src="/images/hero_gold_bar.jpg"
          alt="1000g 999.9 Fine Gold Bullion Bar on Mountain Peak"
          fill
          className="object-cover object-right lg:object-center"
          priority
          referrerPolicy="no-referrer"
        />
        {/* Scrim Overlay ensuring high contrast for text */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#08090b] via-[#08090b]/85 to-transparent lg:w-3/4" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#08090b] via-transparent to-[#08090b]/40" />
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left Text Hero Box */}
          <div className="lg:col-span-8 space-y-6 max-w-2xl">
            
            {/* Tagline */}
            <div className="inline-flex items-center gap-3 text-xs sm:text-sm font-medium tracking-widest text-[#d4af37] uppercase">
              <span className="w-2 h-2 rounded-full bg-[#d4af37] animate-pulse" />
              <span>安全 · 专业 · 全球化</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.15] text-wrap">
              黄金，<br />
              <span className="gold-gradient-text">连接世界的价值</span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-[#aeb5c6] leading-relaxed max-w-xl font-normal">
              金曜贵金属为全球投资者提供专业的黄金、白银等贵金属交易与托管服务，助您把握时代机遇，守护财富价值。
            </p>

            {/* Action CTAs */}
            <div className="pt-4 flex flex-wrap items-center gap-4">
              <button
                onClick={onOpenAccount}
                className="px-7 py-3.5 text-sm font-semibold text-black bg-gradient-to-r from-[#d4af37] via-[#f3d772] to-[#b89528] hover:opacity-95 rounded-lg shadow-xl shadow-[#d4af37]/20 transition-all hover:scale-[1.02] active:scale-[0.98] inline-flex items-center gap-2 group"
              >
                <span>立即开户</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => onNavigate('trading')}
                className="px-7 py-3.5 text-sm font-medium text-white bg-[#141822]/90 hover:bg-[#1f2433] border border-[#2e3547] hover:border-[#d4af37]/50 rounded-lg transition-all"
              >
                了解更多
              </button>
            </div>

            {/* Trust Badges */}
            <div className="pt-8 grid grid-cols-3 gap-4 border-t border-white/10 max-w-md">
              <div>
                <div className="text-xl font-bold font-mono text-white">99.99%</div>
                <div className="text-xs text-[#8e94a5]">实物金存量交割率</div>
              </div>
              <div>
                <div className="text-xl font-bold font-mono text-[#f3d772]">&lt; 1ms</div>
                <div className="text-xs text-[#8e94a5]">Kotlin 撮合时延</div>
              </div>
              <div>
                <div className="text-xl font-bold font-mono text-white">5大</div>
                <div className="text-xs text-[#8e94a5]">全球顶级金库托管</div>
              </div>
            </div>

          </div>

          {/* Right Side Vertical Market Quick Selector matching Screenshot */}
          <div className="lg:col-span-4 flex justify-end">
            <div className="w-full max-w-xs bg-[#0c0e14]/80 backdrop-blur-md border border-[#222736] rounded-xl p-3 shadow-2xl space-y-2">
              <div className="px-2 py-1 flex items-center justify-between text-xs text-[#8e94a5] border-b border-[#1f2433]">
                <span>贵金属代码</span>
                <span className="font-mono text-[11px] text-[#d4af37]">实时点阵</span>
              </div>

              {assets.map((ast) => {
                const quote = liveQuotes.find(q => q.code === ast.code);
                const isSelected = selectedAssetCode === ast.code;
                const price = quote ? quote.price : '---';
                const changePct = quote ? quote.changePercent : 0;
                const isPositive = changePct >= 0;

                return (
                  <button
                    key={ast.code}
                    onClick={() => {
                      setSelectedAssetCode(ast.code);
                      onNavigate('trading');
                    }}
                    className={`w-full flex items-center justify-between p-3 rounded-lg transition-all text-left ${
                      isSelected 
                        ? 'bg-[#1e2330] border border-[#d4af37]/40 shadow-md' 
                        : 'hover:bg-[#141822] border border-transparent'
                    }`}
                  >
                    <div>
                      <div className="text-sm font-semibold text-white flex items-center gap-1.5">
                        {ast.name}
                        {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]" />}
                      </div>
                      <div className="text-[11px] text-[#8e94a5] font-mono">{ast.code}</div>
                    </div>

                    <div className="text-right">
                      <div className="font-mono font-bold text-sm text-white">${price}</div>
                      <div className={`text-xs font-mono font-medium ${isPositive ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
                        {isPositive ? '+' : ''}{changePct}%
                      </div>
                    </div>
                  </button>
                );
              })}

              <div className="pt-2">
                <button
                  onClick={() => onNavigate('market')}
                  className="w-full text-center py-2 text-xs font-medium text-[#d4af37] hover:text-[#f3d772] hover:underline"
                >
                  进入完整行情交易大厅 &rarr;
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
