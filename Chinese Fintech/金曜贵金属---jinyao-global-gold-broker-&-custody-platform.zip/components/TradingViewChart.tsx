'use client';

import React, { useState, useMemo } from 'react';
import { BarChart2, TrendingUp, Cpu, Maximize2, RefreshCw, Activity, Layers } from 'lucide-react';

interface MetalQuote {
  code: string;
  name: string;
  price: number;
  bid: number;
  ask: number;
  changeAmount: number;
  changePercent: number;
  high24h: number;
  low24h: number;
}

interface TradingViewChartProps {
  quotes: MetalQuote[];
  selectedCode: string;
  onSelectCode: (code: string) => void;
  orderBook: any;
}

export const TradingViewChart: React.FC<TradingViewChartProps> = ({
  quotes,
  selectedCode,
  onSelectCode,
  orderBook
}) => {
  const [chartMode, setChartMode] = useState<'candle' | 'line'>('candle');
  const [timeframe, setTimeframe] = useState<'1m' | '5m' | '1h' | '1d'>('1h');
  const [showIndicators, setShowIndicators] = useState(true);

  const activeQuote = quotes.find(q => q.code === selectedCode) || quotes[0] || {
    code: 'XAUUSD',
    name: '黄金',
    price: 2658.42,
    bid: 2658.22,
    ask: 2658.62,
    changeAmount: 12.36,
    changePercent: 0.47,
    high24h: 2665.10,
    low24h: 2642.80
  };

  // Pure deterministic candlestick generator
  const candleData = useMemo(() => {
    const base = activeQuote.price;
    const items = [];
    let current = base - 18;

    for (let i = 0; i < 28; i++) {
      const open = current;
      const pseudoNoise = Math.sin(i * 3.7) * 1.8 + Math.cos(i * 1.9) * 1.2;
      const close = open + (Math.sin(i * 1.3) * 3.5) + pseudoNoise;
      const high = Math.max(open, close) + Math.abs(Math.cos(i * 2.1)) * 2.2;
      const low = Math.min(open, close) - Math.abs(Math.sin(i * 2.5)) * 2.0;
      const volume = Math.floor(120 + Math.abs(Math.sin(i * 1.7)) * 420);

      items.push({
        open: Number(open.toFixed(2)),
        high: Number(high.toFixed(2)),
        low: Number(low.toFixed(2)),
        close: Number(close.toFixed(2)),
        volume,
        isBullish: close >= open
      });

      current = close;
    }
    // ensure last candle ends exactly on active quote price
    if (items.length > 0) {
      items[items.length - 1].close = activeQuote.price;
      items[items.length - 1].high = Math.max(items[items.length - 1].high, activeQuote.price);
      items[items.length - 1].low = Math.min(items[items.length - 1].low, activeQuote.price);
      items[items.length - 1].isBullish = items[items.length - 1].close >= items[items.length - 1].open;
    }

    return items;
  }, [activeQuote.price]);

  const maxPrice = useMemo(() => Math.max(...candleData.map(c => c.high)), [candleData]);
  const minPrice = useMemo(() => Math.min(...candleData.map(c => c.low)), [candleData]);
  const priceRange = maxPrice - minPrice || 1;

  const isPositive = activeQuote.changePercent >= 0;

  return (
    <div className="bg-[#12151e] border border-[#232838] rounded-xl overflow-hidden shadow-2xl">
      
      {/* Chart Top Header & Metal Tabs */}
      <div className="p-4 border-b border-[#202534] bg-[#0f1118] flex flex-wrap items-center justify-between gap-4">
        
        {/* Metal Selector Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {quotes.map((q) => (
            <button
              key={q.code}
              onClick={() => onSelectCode(q.code)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                selectedCode === q.code
                  ? 'bg-[#d4af37] text-black shadow-md'
                  : 'text-[#9a9fae] bg-[#181c28] hover:bg-[#222738] hover:text-white'
              }`}
            >
              {q.name} <span className="font-mono text-[11px] opacity-80">({q.code})</span>
            </button>
          ))}
        </div>

        {/* Timeframes & Mode Switch */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-[#181c28] p-1 rounded-lg border border-[#272d3e]">
            {(['1m', '5m', '1h', '1d'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-2.5 py-1 text-[11px] font-mono font-medium rounded ${
                  timeframe === tf ? 'bg-[#2a3144] text-[#f3d772]' : 'text-[#8e94a5] hover:text-white'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 bg-[#181c28] p-1 rounded-lg border border-[#272d3e]">
            <button
              onClick={() => setChartMode('candle')}
              className={`px-2 py-1 text-xs rounded ${chartMode === 'candle' ? 'bg-[#2a3144] text-white' : 'text-[#8e94a5]'}`}
            >
              K线图
            </button>
            <button
              onClick={() => setChartMode('line')}
              className={`px-2 py-1 text-xs rounded ${chartMode === 'line' ? 'bg-[#2a3144] text-white' : 'text-[#8e94a5]'}`}
            >
              分时图
            </button>
          </div>

          <button
            onClick={() => setShowIndicators(!showIndicators)}
            className={`px-2.5 py-1 text-xs border rounded-lg transition-colors ${
              showIndicators ? 'border-[#d4af37]/50 text-[#f3d772] bg-[#d4af37]/10' : 'border-[#272d3e] text-[#8e94a5]'
            }`}
          >
            指标 (MA/RSI)
          </button>
        </div>

      </div>

      {/* Ticker Info Header Bar */}
      <div className="px-6 py-3 bg-[#141722] border-b border-[#202534] flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
        <div className="flex items-center gap-6">
          <div>
            <span className="text-[#8e94a5]">最新价:</span>
            <span className="ml-1.5 text-lg font-bold text-white">${activeQuote.price.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-[#8e94a5]">涨跌额:</span>
            <span className={`ml-1.5 font-bold ${isPositive ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
              {isPositive ? '+' : ''}{activeQuote.changeAmount.toFixed(2)}
            </span>
          </div>
          <div>
            <span className="text-[#8e94a5]">涨跌幅:</span>
            <span className={`ml-1.5 font-bold ${isPositive ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
              {isPositive ? '+' : ''}{activeQuote.changePercent}%
            </span>
          </div>
        </div>

        <div className="hidden sm:flex items-center gap-6 text-[#9a9fae]">
          <span>最高: <strong className="text-white">${activeQuote.high24h.toFixed(2)}</strong></span>
          <span>最低: <strong className="text-white">${activeQuote.low24h.toFixed(2)}</strong></span>
          <span>买一/卖一差价: <strong className="text-[#d4af37]">${(activeQuote.ask - activeQuote.bid).toFixed(2)}</strong></span>
        </div>
      </div>

      {/* Main Chart Area + Order Book Depth Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
        
        {/* Canvas / SVG Candlestick Chart Area */}
        <div className="lg:col-span-9 p-6 relative min-h-[380px] flex flex-col justify-between">
          
          {/* Chart SVG */}
          <div className="w-full h-72 relative">
            
            {/* Horizontal Grid lines & Price Labels */}
            <div className="absolute inset-0 flex flex-col justify-between text-[10px] font-mono text-[#4a5268] pointer-events-none">
              <div className="border-b border-[#1f2434] pb-1 flex justify-between">
                <span>${maxPrice.toFixed(2)}</span>
                <span>全高点</span>
              </div>
              <div className="border-b border-[#1f2434] pb-1 flex justify-between">
                <span>${((maxPrice + minPrice) / 2).toFixed(2)}</span>
                <span>基准线</span>
              </div>
              <div className="border-b border-[#1f2434] pb-1 flex justify-between">
                <span>${minPrice.toFixed(2)}</span>
                <span>支撑位</span>
              </div>
            </div>

            {/* Candlestick graphics */}
            {chartMode === 'candle' ? (
              <svg className="w-full h-full relative z-10 overflow-visible" preserveAspectRatio="none" viewBox="0 0 100 100">
                {candleData.map((c, i) => {
                  const x = (i / (candleData.length - 1)) * 96 + 2;
                  const highY = 100 - ((c.high - minPrice) / priceRange) * 85 - 5;
                  const lowY = 100 - ((c.low - minPrice) / priceRange) * 85 - 5;
                  const openY = 100 - ((c.open - minPrice) / priceRange) * 85 - 5;
                  const closeY = 100 - ((c.close - minPrice) / priceRange) * 85 - 5;

                  const bodyTop = Math.min(openY, closeY);
                  const bodyHeight = Math.max(Math.abs(openY - closeY), 0.8);
                  const color = c.isBullish ? '#22c55e' : '#ef4444';

                  return (
                    <g key={i}>
                      {/* Wick */}
                      <line
                        x1={x}
                        y1={highY}
                        x2={x}
                        y2={lowY}
                        stroke={color}
                        strokeWidth="0.8"
                      />
                      {/* Body */}
                      <rect
                        x={x - 1.2}
                        y={bodyTop}
                        width="2.4"
                        height={bodyHeight}
                        fill={color}
                        rx="0.2"
                      />
                    </g>
                  );
                })}
              </svg>
            ) : (
              /* Line Chart Mode */
              <svg className="w-full h-full relative z-10 overflow-visible" preserveAspectRatio="none" viewBox="0 0 100 100">
                <defs>
                  <linearGradient id="chartGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#d4af37" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="#d4af37" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Fill Area */}
                <polygon
                  fill="url(#chartGradient)"
                  points={`2,95 ${candleData.map((c, i) => {
                    const x = (i / (candleData.length - 1)) * 96 + 2;
                    const y = 100 - ((c.close - minPrice) / priceRange) * 85 - 5;
                    return `${x},${y}`;
                  }).join(' ')} 98,95`}
                />

                {/* Line */}
                <polyline
                  fill="none"
                  stroke="#d4af37"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  points={candleData.map((c, i) => {
                    const x = (i / (candleData.length - 1)) * 96 + 2;
                    const y = 100 - ((c.close - minPrice) / priceRange) * 85 - 5;
                    return `${x},${y}`;
                  }).join(' ')}
                />
              </svg>
            )}

          </div>

          {/* Volume Bars */}
          <div className="w-full h-12 border-t border-[#1f2434] pt-2 flex items-end gap-1">
            {candleData.map((c, i) => (
              <div
                key={i}
                className="flex-1 rounded-t"
                style={{
                  height: `${(c.volume / 600) * 100}%`,
                  backgroundColor: c.isBullish ? 'rgba(34, 197, 94, 0.4)' : 'rgba(239, 68, 68, 0.4)'
                }}
              />
            ))}
          </div>

        </div>

        {/* Right Side Order Book Depth Panel */}
        <div className="lg:col-span-3 border-t lg:border-t-0 lg:border-l border-[#202534] bg-[#0d0f16] p-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-white border-b border-[#1f2434] pb-2">
              <span className="flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-[#d4af37]" /> 盘口挂单深度
              </span>
              <span className="text-[10px] font-mono text-[#22c55e]">Kotlin 0.8ms</span>
            </div>

            {/* Asks (Sell Orders) */}
            <div className="space-y-1 font-mono text-xs">
              <div className="text-[10px] text-[#8e94a5] flex justify-between">
                <span>卖盘价</span>
                <span>挂单量(g)</span>
              </div>
              {orderBook?.asks?.map((ask: any, idx: number) => (
                <div key={idx} className="flex justify-between items-center py-0.5 relative group">
                  <span className="text-[#ef4444] font-medium">${ask.price.toFixed(2)}</span>
                  <span className="text-white">{ask.amountGrams}g</span>
                  <div
                    className="absolute right-0 top-0 bottom-0 bg-[#ef4444]/10 rounded -z-0"
                    style={{ width: `${(ask.amountGrams / 2000) * 100}%` }}
                  />
                </div>
              ))}
            </div>

            {/* Current Price Divider */}
            <div className="py-2 my-1 border-y border-[#232a3d] bg-[#141824] px-2 flex justify-between items-center font-mono">
              <span className="text-xs text-[#8e94a5]">即时中间价</span>
              <span className="text-sm font-bold text-[#f3d772]">${activeQuote.price.toFixed(2)}</span>
            </div>

            {/* Bids (Buy Orders) */}
            <div className="space-y-1 font-mono text-xs">
              <div className="text-[10px] text-[#8e94a5] flex justify-between">
                <span>买盘价</span>
                <span>挂单量(g)</span>
              </div>
              {orderBook?.bids?.map((bid: any, idx: number) => (
                <div key={idx} className="flex justify-between items-center py-0.5 relative group">
                  <span className="text-[#22c55e] font-medium">${bid.price.toFixed(2)}</span>
                  <span className="text-white">{bid.amountGrams}g</span>
                  <div
                    className="absolute right-0 top-0 bottom-0 bg-[#22c55e]/10 rounded -z-0"
                    style={{ width: `${(bid.amountGrams / 2500) * 100}%` }}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-[#1f2434] text-[11px] text-[#8e94a5] space-y-1">
            <div className="flex justify-between">
              <span>最小变动价位:</span>
              <span className="text-white font-mono">$0.01</span>
            </div>
            <div className="flex justify-between">
              <span>杠杆交易倍数:</span>
              <span className="text-white font-mono">最高 50X</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
