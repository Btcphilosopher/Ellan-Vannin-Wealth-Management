'use client';

import React, { useState } from 'react';
import { Search, Shield, ChevronDown, User, Wallet, Cpu, Menu, X, ArrowUpRight } from 'lucide-react';

interface HeaderProps {
  onNavigate: (sectionId: string) => void;
  activeSection: string;
  onOpenAccount: () => void;
  onOpenPortfolio: () => void;
  onOpenKotlinMonitor: () => void;
  userBalanceGoldGrams: number;
  userBalanceCny: number;
}

export const Header: React.FC<HeaderProps> = ({
  onNavigate,
  activeSection,
  onOpenAccount,
  onOpenPortfolio,
  onOpenKotlinMonitor,
  userBalanceGoldGrams,
  userBalanceCny
}) => {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'hero', label: '首页' },
    { id: 'market', label: '行情' },
    { id: 'trading', label: '交易' },
    { id: 'products', label: '产品' },
    { id: 'services', label: '服务' },
    { id: 'insights', label: 'AI研报' },
    { id: 'about', label: '关于我们' },
  ];

  const quickSearchResults = [
    { title: 'XAUUSD 现货黄金', category: '国际行情', link: 'market' },
    { title: 'AU9999 上海金', category: '国内行情', link: 'market' },
    { title: '金曜1000g投资金条 999.9', category: '实物产品', link: 'products' },
    { title: '上海自贸区安全金库', category: '托管服务', link: 'services' },
  ].filter(item => item.title.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <>
      {/* Top Banner Notice */}
      <div className="bg-[#12141a] border-b border-[#222632] text-xs text-[#9a9fae] py-1.5 px-4 sm:px-8 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <span className="inline-flex items-center gap-1.5 text-[#d4af37]">
            <Shield className="w-3.5 h-3.5" />
            受多国金融监管 · 100%实物黄金1:1储备存算
          </span>
          <span className="hidden lg:inline text-[#626875]">|</span>
          <span className="hidden lg:inline text-[#9a9fae]">
            上海自贸区 · 香港 · 新加坡 · 苏黎世 · 伦敦金库安全直通
          </span>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={onOpenKotlinMonitor}
            className="inline-flex items-center gap-1 text-[#e5c158] hover:underline font-mono text-[11px]"
          >
            <Cpu className="w-3 h-3 text-[#22c55e]" />
            Kotlin微服务引擎: 运行中 (0.8ms)
          </button>
          <span className="text-[#626875]">|</span>
          <span className="text-[#9a9fae]">24小时客户专线: 400-888-9999</span>
        </div>
      </div>

      {/* Main Luxury Header */}
      <header className="sticky top-0 z-40 bg-[#0c0d10]/90 backdrop-blur-md border-b border-[#1f232e]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Zone 1: Single Brand Logo Lockup */}
          <button 
            onClick={() => onNavigate('hero')}
            className="flex items-center gap-3 text-left focus:outline-none group"
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#d4af37] via-[#f3d772] to-[#8a6d1b] p-0.5 shadow-lg shadow-[#d4af37]/10 flex items-center justify-center">
              <div className="w-full h-full bg-[#0c0d10] rounded-[7px] flex items-center justify-center">
                <div className="text-[#f3d772] font-black text-xl tracking-tighter group-hover:scale-105 transition-transform">
                  金
                </div>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight text-white group-hover:text-[#f3d772] transition-colors">
                金曜贵金属
              </span>
              <span className="text-[10px] tracking-widest text-[#8e94a5] uppercase">
                JINYAO GLOBAL GOLD
              </span>
            </div>
          </button>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`px-3.5 py-2 text-sm font-medium transition-all relative rounded-md ${
                    isActive 
                      ? 'text-[#f3d772]' 
                      : 'text-[#a1a7b8] hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-5 h-0.5 bg-[#d4af37] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Search, User Account, Open Account Actions */}
          <div className="flex items-center gap-3">
            
            {/* Search Button */}
            <button
              onClick={() => setSearchOpen(true)}
              className="p-2 text-[#9a9fae] hover:text-white hover:bg-white/5 rounded-lg transition-colors"
              title="搜索贵金属行情与产品"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* User Portfolio Mini View */}
            <button
              onClick={onOpenPortfolio}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[#2a2f3d] bg-[#141720] hover:border-[#d4af37]/40 transition-colors text-xs text-left"
            >
              <Wallet className="w-4 h-4 text-[#d4af37]" />
              <div>
                <div className="text-[10px] text-[#8e94a5]">资产持仓</div>
                <div className="font-mono text-white font-semibold">
                  {userBalanceGoldGrams.toFixed(1)}g / ￥{userBalanceCny.toLocaleString()}
                </div>
              </div>
            </button>

            {/* Login / Open Account */}
            <button
              onClick={onOpenAccount}
              className="hidden sm:inline-flex px-3.5 py-1.5 text-xs font-medium text-[#d4af37] hover:text-white border border-[#d4af37]/40 hover:border-[#d4af37] rounded-md transition-colors"
            >
              登录
            </button>

            <button
              onClick={onOpenAccount}
              className="px-4 py-2 text-xs font-semibold text-black bg-gradient-to-r from-[#d4af37] via-[#f3d772] to-[#c29b28] hover:opacity-95 rounded-md shadow-md shadow-[#d4af37]/20 transition-all hover:scale-[1.02] active:scale-[0.98] whitespace-nowrap"
            >
              立即开户
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#9a9fae] hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-[#101218] border-b border-[#222632] px-4 py-4 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`block w-full text-left px-3 py-2 text-base font-medium rounded-md ${
                  activeSection === item.id ? 'bg-[#d4af37]/10 text-[#f3d772]' : 'text-[#a1a7b8]'
                }`}
              >
                {item.label}
              </button>
            ))}
            <div className="pt-3 border-t border-[#222632] flex items-center justify-between">
              <button
                onClick={() => {
                  onOpenPortfolio();
                  setMobileMenuOpen(false);
                }}
                className="text-sm text-[#d4af37] flex items-center gap-2"
              >
                <Wallet className="w-4 h-4" /> 查看我的资产账户
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Global Search Overlay Modal */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-start justify-center pt-20 px-4">
          <div className="bg-[#141720] border border-[#2e3445] rounded-xl w-full max-w-xl p-4 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#252a38] pb-3">
              <div className="flex items-center gap-2 flex-1">
                <Search className="w-5 h-5 text-[#d4af37]" />
                <input
                  type="text"
                  placeholder="搜索贵金属代码 (如 XAUUSD)、实物金条、托管政策..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  autoFocus
                  className="bg-transparent text-white text-sm focus:outline-none w-full"
                />
              </div>
              <button 
                onClick={() => setSearchOpen(false)}
                className="text-[#8e94a5] hover:text-white text-xs px-2 py-1 rounded bg-[#1e222d]"
              >
                关闭 (ESC)
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              <div className="text-[11px] text-[#8e94a5] uppercase">快捷推荐</div>
              {quickSearchResults.map((res, i) => (
                <button
                  key={i}
                  onClick={() => {
                    onNavigate(res.link);
                    setSearchOpen(false);
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-lg bg-[#1a1e2a] hover:bg-[#252b3c] text-left transition-colors"
                >
                  <span className="text-sm text-white">{res.title}</span>
                  <span className="text-xs text-[#d4af37] flex items-center gap-1">
                    {res.category} <ArrowUpRight className="w-3.5 h-3.5" />
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
