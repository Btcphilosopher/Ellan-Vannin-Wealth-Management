'use client';

import React from 'react';
import { Wallet, ShieldCheck, X, ArrowUpRight, Lock, History } from 'lucide-react';

interface PortfolioDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  goldGrams: number;
  balanceCny: number;
  tradeHistory: any[];
}

export const PortfolioDrawer: React.FC<PortfolioDrawerProps> = ({
  isOpen,
  onClose,
  goldGrams,
  balanceCny,
  tradeHistory
}) => {
  if (!isOpen) return null;

  const totalValueCny = balanceCny + (goldGrams * 628.5);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-end">
      <div className="bg-[#10121a] border-l border-[#242b3d] w-full max-w-md h-full p-6 shadow-2xl flex flex-col justify-between overflow-y-auto space-y-6 animate-in slide-in-from-right duration-300">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1f2535] pb-4">
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-[#d4af37]" />
            <h3 className="text-lg font-bold text-white">金曜资产账户概览</h3>
          </div>
          <button onClick={onClose} className="p-1 text-[#8e94a5] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Account Total Card */}
        <div className="bg-gradient-to-br from-[#181c28] via-[#121520] to-[#0d0e14] border border-[#2d354a] rounded-2xl p-5 space-y-4 shadow-xl">
          <div className="text-xs text-[#8e94a5]">资产总估值 (折合人民币)</div>
          <div className="text-3xl font-bold font-mono text-[#f3d772]">
            ￥{totalValueCny.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>

          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-[#23293a] text-xs font-mono">
            <div>
              <div className="text-[#8e94a5]">实物黄金持仓</div>
              <div className="text-white font-bold text-base mt-0.5">{goldGrams.toFixed(1)} 克</div>
            </div>
            <div>
              <div className="text-[#8e94a5]">可用现金余额</div>
              <div className="text-white font-bold text-base mt-0.5">￥{balanceCny.toLocaleString()}</div>
            </div>
          </div>
        </div>

        {/* Vault Custody Quick Status */}
        <div className="bg-[#141722] border border-[#23293a] p-4 rounded-xl space-y-2 text-xs">
          <div className="flex items-center justify-between text-[#22c55e]">
            <span className="flex items-center gap-1.5 font-bold">
              <ShieldCheck className="w-4 h-4" /> 上海自贸区金库直连
            </span>
            <span className="font-mono text-[11px]">1:1 独立托管</span>
          </div>
          <p className="text-[#8e94a5] text-[11px]">
            您的 {goldGrams.toFixed(1)}g 黄金储备已由安联保险承保，支持生成电子存金证明或预约调拨。
          </p>
        </div>

        {/* Transaction History Log */}
        <div className="space-y-3 flex-1 overflow-y-auto">
          <div className="flex items-center gap-1.5 text-xs font-bold text-white border-b border-[#1f2535] pb-2">
            <History className="w-4 h-4 text-[#d4af37]" /> 近期交易与存算记录
          </div>

          {tradeHistory.length === 0 ? (
            <div className="text-xs text-[#8e94a5] text-center py-8">
              暂无交易记录，可在交易大厅极速建仓。
            </div>
          ) : (
            <div className="space-y-2">
              {tradeHistory.map((tx, idx) => (
                <div key={idx} className="bg-[#141722] border border-[#222838] p-3 rounded-lg text-xs font-mono space-y-1">
                  <div className="flex justify-between items-center text-white">
                    <span className="font-bold text-[#d4af37]">{tx.symbol} · {tx.side === 'BUY' ? '买入' : '卖出'}</span>
                    <span>￥{tx.totalValueCny?.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-[#8e94a5]">
                    <span>{tx.quantityGrams} 克</span>
                    <span>{tx.timestamp?.split('T')[1]?.substring(0, 8)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <button
          onClick={onClose}
          className="w-full py-3 text-xs font-bold bg-[#d4af37] text-black rounded-xl hover:opacity-95"
        >
          关闭资产卡片
        </button>

      </div>
    </div>
  );
};
