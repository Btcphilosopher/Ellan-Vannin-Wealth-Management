'use client';

import React, { useState } from 'react';
import { ShieldCheck, UserCheck, CheckCircle2, Lock, X } from 'lucide-react';

interface AccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AccountModal: React.FC<AccountModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [step, setStep] = useState<number>(1);
  const [name, setName] = useState('');
  const [idCard, setIdCard] = useState('');
  const [phone, setPhone] = useState('');
  const [riskLevel, setRiskLevel] = useState('积极型 (支持高杠杆与实物交割)');

  if (!isOpen) return null;

  const handleSubmitKYC = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
    setTimeout(() => {
      onSuccess();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#121520] border border-[#2e3548] rounded-2xl max-w-lg w-full p-6 lg:p-8 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#8e94a5] hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {step === 1 ? (
          <form onSubmit={handleSubmitKYC} className="space-y-5">
            <div className="border-b border-[#222838] pb-4">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-6 h-6 text-[#d4af37]" />
                金曜贵金属 · 投资者实名开户与资质核验
              </h3>
              <p className="text-xs text-[#8e94a5] mt-1">
                根据多国金融监管合规要求，请填写您的真实身份信息以激活交易算力。
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[#8e94a5] mb-1 font-medium">真实姓名 (与身份证件一致)</label>
                <input
                  type="text"
                  required
                  placeholder="如：张立强"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#0a0b10] border border-[#282f42] text-white p-3 rounded-lg focus:outline-none focus:border-[#d4af37]"
                />
              </div>

              <div>
                <label className="block text-[#8e94a5] mb-1 font-medium">手机号码 (接收交易与提取验证码)</label>
                <input
                  type="tel"
                  required
                  placeholder="如：13800138000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-[#0a0b10] border border-[#282f42] text-white p-3 rounded-lg focus:outline-none focus:border-[#d4af37]"
                />
              </div>

              <div>
                <label className="block text-[#8e94a5] mb-1 font-medium">身份证/护照号 (KYC合规校验)</label>
                <input
                  type="text"
                  required
                  placeholder="如：31010119900101XXXX"
                  value={idCard}
                  onChange={(e) => setIdCard(e.target.value)}
                  className="w-full bg-[#0a0b10] border border-[#282f42] text-white p-3 rounded-lg focus:outline-none focus:border-[#d4af37]"
                />
              </div>

              <div>
                <label className="block text-[#8e94a5] mb-1 font-medium">风险承受能力测评</label>
                <select
                  value={riskLevel}
                  onChange={(e) => setRiskLevel(e.target.value)}
                  className="w-full bg-[#0a0b10] border border-[#282f42] text-white p-3 rounded-lg focus:outline-none"
                >
                  <option value="积极型 (支持高杠杆与实物交割)">积极型 (支持最高 50X 杠杆与实物提现)</option>
                  <option value="稳健型 (推荐实物金条资产配置)">稳健型 (推荐 1X-10X 稳健现货投资)</option>
                  <option value="保守型 (仅限全款实物托管)">保守型 (仅限全款实物金条托管)</option>
                </select>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 text-xs font-bold text-black bg-gradient-to-r from-[#d4af37] via-[#f3d772] to-[#b89528] rounded-xl hover:opacity-95 shadow-lg shadow-[#d4af37]/20"
              >
                提交合规核验并领取 ￥1,000,000 体验模拟金
              </button>
            </div>
          </form>
        ) : (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#22c55e]/10 text-[#22c55e] flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-white">KYC 审核通过 · 账户已激活</h3>
            <p className="text-xs text-[#8e94a5]">
              恭喜，您的尊享贵金属交易与金库托管账户已成功与 Kotlin 撮合引擎绑定！
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
