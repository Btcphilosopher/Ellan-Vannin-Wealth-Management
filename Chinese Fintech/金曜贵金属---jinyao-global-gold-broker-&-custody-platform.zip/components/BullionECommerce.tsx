'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ShoppingBag, ShieldCheck, ArrowRight, Award, Lock, Truck, Check } from 'lucide-react';

interface BullionECommerceProps {
  onBuyBullion: (product: any) => void;
}

export const BullionECommerce: React.FC<BullionECommerceProps> = ({ onBuyBullion }) => {
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | 'BAR' | 'COIN'>('ALL');

  const products = [
    {
      id: 'p1000g',
      name: '金曜 1000g 千克级高纯投资金条',
      purity: 'Au99.99 纯金',
      weightGrams: 1000,
      priceCny: 628500,
      category: 'BAR',
      image: '/images/gold_bar_1000g.jpg',
      badge: '全球机构首选',
      desc: '国家金银制品质量监督检验中心全项检测，配独立编号与激光防伪证书。'
    },
    {
      id: 'p500g',
      name: '金曜 500g 尊享投资金条',
      purity: 'Au99.99 纯金',
      weightGrams: 500,
      priceCny: 314250,
      category: 'BAR',
      image: '/images/gold_bar_1000g.jpg',
      badge: '高净值精选',
      desc: '专为家族办公室与高净值资产配置设计，国际金库无缝交割。'
    },
    {
      id: 'p100g',
      name: '金曜 100g 尚品理财金条',
      purity: 'Au99.99 纯金',
      weightGrams: 100,
      priceCny: 62850,
      category: 'BAR',
      image: '/images/gold_bar_1000g.jpg',
      badge: '热销爆款',
      desc: '灵活配置，支持零散金条随时回购变现与国际金库调拨。'
    },
    {
      id: 'p50g',
      name: '金曜 50g 投资金条',
      purity: 'Au99.99 纯金',
      weightGrams: 50,
      priceCny: 31425,
      category: 'BAR',
      image: '/images/gold_bar_1000g.jpg',
      badge: '入门自选',
      desc: '适合个人投资者小额分批储备，支持极速全额提现配送。'
    },
    {
      id: 'pcoin_dragon',
      name: '龙年限定 999.9 纯金纪念章 (30g)',
      purity: 'Au99.99 纯金',
      weightGrams: 30,
      priceCny: 18850,
      category: 'COIN',
      image: '/images/gold_coin.jpg',
      badge: '限量收藏',
      desc: '大师级浮雕工艺，配黑曜石精致木盒与全球限量发行收藏证书。'
    }
  ];

  const filteredProducts = products.filter(p => selectedCategory === 'ALL' || p.category === selectedCategory);

  return (
    <section className="bg-[#0b0d12] py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#1c2130] pb-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-mono text-[#d4af37] uppercase tracking-widest">
              <Award className="w-4 h-4" /> 100% 999.9 纯金认证书
            </div>
            <h2 className="text-3xl font-bold text-white tracking-tight">
              金曜实物金条与尊享产品商城
            </h2>
            <p className="text-sm text-[#8e94a5] max-w-xl">
              提供 Au99.99 投资金条、纪念金章。所有金条均带有独立激光防伪编号，支持实物提现配送或直接入库托管。
            </p>
          </div>

          {/* Category Filter Controls */}
          <div className="flex items-center gap-1 bg-[#141824] p-1 rounded-xl border border-[#23293c]">
            <button
              onClick={() => setSelectedCategory('ALL')}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors ${
                selectedCategory === 'ALL' ? 'bg-[#d4af37] text-black font-semibold' : 'text-[#8e94a5] hover:text-white'
              }`}
            >
              全部尊享产品
            </button>
            <button
              onClick={() => setSelectedCategory('BAR')}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors ${
                selectedCategory === 'BAR' ? 'bg-[#d4af37] text-black font-semibold' : 'text-[#8e94a5] hover:text-white'
              }`}
            >
              投资金条
            </button>
            <button
              onClick={() => setSelectedCategory('COIN')}
              className={`px-4 py-2 text-xs font-medium rounded-lg transition-colors ${
                selectedCategory === 'COIN' ? 'bg-[#d4af37] text-black font-semibold' : 'text-[#8e94a5] hover:text-white'
              }`}
            >
              纪念金章/金币
            </button>
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-[#12151f] border border-[#212738] hover:border-[#d4af37]/50 rounded-2xl overflow-hidden shadow-xl transition-all hover:-translate-y-1 flex flex-col justify-between group"
            >
              
              {/* Product Image Container */}
              <div className="relative h-60 w-full bg-[#08090d] overflow-hidden">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                
                {/* Badge Overlay */}
                <div className="absolute top-3 left-3 bg-[#0c0d11]/80 backdrop-blur-md text-[#f3d772] text-[11px] font-semibold px-2.5 py-1 rounded-full border border-[#d4af37]/30">
                  {product.badge}
                </div>

                <div className="absolute bottom-3 right-3 bg-black/80 backdrop-blur-md text-white text-xs font-mono px-2.5 py-1 rounded">
                  {product.weightGrams}g / {product.purity}
                </div>
              </div>

              {/* Product Info */}
              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div className="space-y-2">
                  <h3 className="text-lg font-bold text-white group-hover:text-[#f3d772] transition-colors">
                    {product.name}
                  </h3>
                  <p className="text-xs text-[#8e94a5] leading-relaxed">
                    {product.desc}
                  </p>
                </div>

                <div className="pt-4 border-t border-[#1d2232] space-y-3">
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs text-[#8e94a5]">实时认购价</span>
                    <span className="text-2xl font-bold font-mono text-[#f3d772]">
                      ￥{product.priceCny.toLocaleString()}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-[#8e94a5]">
                    <span className="flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-[#22c55e]" /> 顺丰特快保价
                    </span>
                    <span className="flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5 text-[#d4af37]" /> 直入自贸区金库
                    </span>
                  </div>

                  <button
                    onClick={() => onBuyBullion(product)}
                    className="w-full py-3 text-xs font-bold text-black bg-gradient-to-r from-[#d4af37] via-[#f3d772] to-[#b89528] rounded-xl hover:opacity-95 shadow-md shadow-[#d4af37]/10 transition-all flex items-center justify-center gap-2"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>立即申购实物 / 预约存金</span>
                  </button>
                </div>

              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
