'use client';

import React, { useState, useEffect } from 'react';
import { Cpu, Terminal, ShieldCheck, Activity, Code2, Server, CheckCircle, RefreshCw } from 'lucide-react';

export const KotlinBackendMonitor: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'METRICS' | 'LOGS' | 'CODE'>('METRICS');
  const [selectedCodeFile, setSelectedCodeFile] = useState<string>('MarketPricingEngine.kt');
  const [engineStatus, setEngineStatus] = useState<any>(null);
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    let isMounted = true;

    async function loadInitialStatus() {
      try {
        const res = await fetch('/api/kotlin-engine/status');
        const data = await res.json();
        if (isMounted) {
          setEngineStatus(data);
        }
      } catch (e) {
        console.error(e);
      }
    }

    loadInitialStatus();

    const interval = setInterval(() => {
      const symbols = ['XAUUSD', 'XAGUSD', 'AU9999', 'XPTUSD'];
      const sym = symbols[Math.floor(Math.random() * symbols.length)];
      const price = (2658 + (Math.random() - 0.5) * 2).toFixed(2);
      const time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
      const newLog = `[${time}] [Kotlin Coroutine-Worker-${Math.floor(Math.random() * 8) + 1}] TICK_DISPATCH -> ${sym}: $${price} (Spread: $0.30) | Latency: 0.81ms`;

      if (isMounted) {
        setLogs(prev => [newLog, ...prev.slice(0, 19)]);
      }
    }, 1500);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const codeSnippets: Record<string, string> = {
    'MarketPricingEngine.kt': `package com.jinyao.gold.service

import com.jinyao.gold.model.MetalSymbol
import com.jinyao.gold.model.PriceTick
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class MarketPricingEngine {
    fun startPriceFeedStream(): Flow<PriceTick> = flow {
        while (true) {
            val tick = calculateTick(MetalSymbol.XAUUSD)
            emit(tick)
            delay(1000) // 1-second pulse broadcast
        }
    }
}`,
    'TransactionProcessor.kt': `package com.jinyao.gold.service

import com.jinyao.gold.model.ExecutionResult
import com.jinyao.gold.model.GoldOrder

class TransactionProcessor(private val riskService: RiskManagementService) {
    fun executeOrder(order: GoldOrder, currentPriceUsd: BigDecimal): ExecutionResult {
        val startTime = System.currentTimeMillis()
        if (!riskService.validateOrder(order)) {
            return ExecutionResult.rejected(order.orderId)
        }
        val auditHash = generateSha256AuditSignature(order)
        return ExecutionResult.success(order, auditHash, executionTimeMs = System.currentTimeMillis() - startTime)
    }
}`,
    'RiskManagementService.kt': `package com.jinyao.gold.service

class RiskManagementService {
    fun validateOrder(order: GoldOrder): Boolean {
        if (order.leverage > 50) return false
        if (order.isPhysicalDelivery && order.quantityGrams < BigDecimal("10.0")) return false
        return true
    }
}`
  };

  return (
    <section className="bg-[#090a0e] py-12 px-4 sm:px-6 lg:px-8 border-t border-[#1c202d]" id="kotlin-monitor">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#121520] border border-[#23293a] rounded-2xl p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#22c55e]/10 border border-[#22c55e]/30 text-[#22c55e] flex items-center justify-center shrink-0">
              <Cpu className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Kotlin 核心微服务后端引擎监控
                <span className="text-[10px] font-mono bg-[#22c55e]/20 text-[#22c55e] px-2 py-0.5 rounded">
                  ONLINE (Ktor 2.0)
                </span>
              </h3>
              <p className="text-xs text-[#8e94a5]">
                基于 Kotlin Ktor 协程机制，负责毫秒级高频多源行情聚合、杠杆强平校验与密码学账本存证。
              </p>
            </div>
          </div>

          {/* Mode Tabs */}
          <div className="flex items-center gap-1 bg-[#0d0f16] p-1 rounded-xl border border-[#1f2434]">
            <button
              onClick={() => setActiveTab('METRICS')}
              className={`px-3 py-1.5 text-xs font-mono rounded-lg transition-colors ${
                activeTab === 'METRICS' ? 'bg-[#252b3d] text-[#f3d772]' : 'text-[#8e94a5]'
              }`}
            >
              性能指标 (Metrics)
            </button>
            <button
              onClick={() => setActiveTab('LOGS')}
              className={`px-3 py-1.5 text-xs font-mono rounded-lg transition-colors ${
                activeTab === 'LOGS' ? 'bg-[#252b3d] text-[#f3d772]' : 'text-[#8e94a5]'
              }`}
            >
              实时日志 (Logs)
            </button>
            <button
              onClick={() => setActiveTab('CODE')}
              className={`px-3 py-1.5 text-xs font-mono rounded-lg transition-colors ${
                activeTab === 'CODE' ? 'bg-[#252b3d] text-[#f3d772]' : 'text-[#8e94a5]'
              }`}
            >
              源码架构 (Kotlin)
            </button>
          </div>
        </div>

        {/* Tab 1: METRICS */}
        {activeTab === 'METRICS' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#121520] border border-[#202534] p-5 rounded-xl space-y-2">
              <div className="text-xs text-[#8e94a5]">撮合处理算力 (TPS)</div>
              <div className="text-3xl font-bold font-mono text-[#f3d772]">
                {engineStatus?.metrics?.currentTps ? engineStatus.metrics.currentTps.toLocaleString() : '18,450'}
              </div>
              <div className="text-[11px] text-[#22c55e] font-mono">笔/秒 峰值吞吐量</div>
            </div>

            <div className="bg-[#121520] border border-[#202534] p-5 rounded-xl space-y-2">
              <div className="text-xs text-[#8e94a5]">行情广播时延</div>
              <div className="text-3xl font-bold font-mono text-[#22c55e]">
                {engineStatus?.metrics?.priceTickLatencyMs || 0.85}ms
              </div>
              <div className="text-[11px] text-[#8e94a5] font-mono">WebSocket 零延迟</div>
            </div>

            <div className="bg-[#121520] border border-[#202534] p-5 rounded-xl space-y-2">
              <div className="text-xs text-[#8e94a5]">Active gRPC Channels</div>
              <div className="text-3xl font-bold font-mono text-white">
                {engineStatus?.metrics?.activeGrpcChannels ? engineStatus.metrics.activeGrpcChannels.toLocaleString() : '1,284'}
              </div>
              <div className="text-[11px] text-[#8e94a5] font-mono">并发长连接 channel</div>
            </div>

            <div className="bg-[#121520] border border-[#202534] p-5 rounded-xl space-y-2">
              <div className="text-xs text-[#8e94a5]">金库实物审计量</div>
              <div className="text-3xl font-bold font-mono text-white">28.45 吨</div>
              <div className="text-[11px] text-[#d4af37] font-mono">100% 审计储备</div>
            </div>
          </div>
        )}

        {/* Tab 2: LOGS */}
        {activeTab === 'LOGS' && (
          <div className="bg-[#0a0b10] border border-[#202534] rounded-xl p-4 font-mono text-xs text-[#22c55e] h-64 overflow-y-auto space-y-1">
            <div className="text-[#8e94a5] pb-2 border-b border-[#1f2434] flex justify-between">
              <span>[Ktor Engine Terminal Live Output Stream]</span>
              <span>Status: OK</span>
            </div>
            {logs.map((log, i) => (
              <div key={i} className="hover:bg-[#131622] px-1 rounded transition-colors">
                {log}
              </div>
            ))}
          </div>
        )}

        {/* Tab 3: CODE */}
        {activeTab === 'CODE' && (
          <div className="bg-[#121520] border border-[#202534] rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12">
            <div className="lg:col-span-4 border-r border-[#202534] p-4 space-y-2 bg-[#0e1017]">
              <div className="text-xs font-bold text-[#8e94a5] uppercase">Kotlin 核心类库文件</div>
              {Object.keys(codeSnippets).map((filename) => (
                <button
                  key={filename}
                  onClick={() => setSelectedCodeFile(filename)}
                  className={`w-full text-left p-3 rounded-lg text-xs font-mono transition-colors flex items-center justify-between ${
                    selectedCodeFile === filename
                      ? 'bg-[#222838] text-[#f3d772] border border-[#d4af37]/30'
                      : 'text-[#8e94a5] hover:bg-[#161a26]'
                  }`}
                >
                  <span>{filename}</span>
                  <Code2 className="w-3.5 h-3.5" />
                </button>
              ))}
            </div>

            <div className="lg:col-span-8 p-4 bg-[#0a0b10] font-mono text-xs text-[#d4d8e8] overflow-x-auto">
              <pre>{codeSnippets[selectedCodeFile]}</pre>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
