'use client';

import React, { useState } from 'react';
import { ShoppingCart, ShieldCheck, Zap, ArrowRight, CheckCircle2, FileText, Lock, Building2 } from 'lucide-react';

interface TradeExecutionPanelProps {
  selectedMetal: any;
  userBalanceCny: number;
  userBalanceGoldGrams: number;
  onTradeSuccess: (txDetails: any) => void;
}

export const TradeExecutionPanel: React.FC<TradeExecutionPanelProps> = ({
  selectedMetal,
  userBalanceCny,
  userBalanceGoldGrams,
  onTradeSuccess
}) => {
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT'>('MARKET');
  const [quantityGrams, setQuantityGrams] = useState<number>(100);
  const [leverage, setLeverage] = useState<number>(1);
  const [isPhysical, setIsPhysical] = useState<boolean>(true);
  const [vaultLocation, setVaultLocation] = useState<string>('上海自贸区国际金库');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [receipt, setReceipt] = useState<any>(null);

  const spotUsd = selectedMetal?.price || 2658.42;
  const usdToCny = 7.1825;
  const pricePerGramCny = Number((spotUsd / 31.1035 * usdToCny).toFixed(2));

  const totalValueCny = Number((pricePerGramCny * quantityGrams).toFixed(2));
  const marginRequiredCny = Number((totalValueCny / leverage).toFixed(2));
  const feeCny = Number((totalValueCny * 0.0003).toFixed(2)); // 0.03%

  const handleExecuteOrder = async () => {
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/trading/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol: selectedMetal?.code || 'XAUUSD',
          side,
          type: orderType,
          quantityGrams,
          leverage,
          isPhysicalDelivery: isPhysical,
          vaultLocation
        })
      });

      const data = await res.json();
      if (data.success) {
        setReceipt(data.details);
        onTradeSuccess(data.details);
      }
    } catch (e) {
      console.error('Trading Execution Error:', e);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-[#12151e] border border-[#232838] rounded-xl p-6 shadow-2xl relative overflow-hidden">
      
      {/* Header Title */}
      <div className="flex items-center justify-between border-b border-[#202534] pb-4 mb-6">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#d4af37]" />
            在线极速交易与托管终端
          </h2>
          <p className="text-xs text-[#8e94a5] mt-0.5">
            Kotlin 高频撮合算力 · 100% 实物黄金与即时资金清算
          </p>
        </div>

        <div className="text-right">
          <div className="text-xs text-[#8e94a5]">当前选中标的</div>
          <div className="text-base font-bold font-mono text-[#f3d772]">
            {selectedMetal?.name || '黄金'} ({selectedMetal?.code || 'XAUUSD'})
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Interactive Order Form */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Side Segmented Control (Buy / Sell) */}
          <div className="grid grid-cols-2 gap-2 p-1.5 bg-[#0b0c10] rounded-xl border border-[#1f2434]">
            <button
              type="button"
              onClick={() => setSide('BUY')}
              className={`py-3 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${
                side === 'BUY'
                  ? 'bg-gradient-to-r from-[#22c55e] to-[#16a34a] text-white shadow-lg'
                  : 'text-[#8e94a5] hover:text-white'
              }`}
            >
              <span>买入 / 买进建仓 (BUY)</span>
            </button>

            <button
              type="button"
              onClick={() => setSide('SELL')}
              className={`py-3 text-sm font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${
                side === 'SELL'
                  ? 'bg-gradient-to-r from-[#ef4444] to-[#dc2626] text-white shadow-lg'
                  : 'text-[#8e94a5] hover:text-white'
              }`}
            >
              <span>卖出 / 变现平仓 (SELL)</span>
            </button>
          </div>

          {/* Order Type & Leverage selection */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#8e94a5] mb-1.5">订单模式</label>
              <div className="flex rounded-lg bg-[#0b0c10] border border-[#1f2434] p-1">
                <button
                  type="button"
                  onClick={() => setOrderType('MARKET')}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded ${
                    orderType === 'MARKET' ? 'bg-[#222738] text-[#f3d772]' : 'text-[#8e94a5]'
                  }`}
                >
                  市价极速撮合
                </button>
                <button
                  type="button"
                  onClick={() => setOrderType('LIMIT')}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded ${
                    orderType === 'LIMIT' ? 'bg-[#222738] text-[#f3d772]' : 'text-[#8e94a5]'
                  }`}
                >
                  限价挂单
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#8e94a5] mb-1.5">杠杆/全额选项</label>
              <select
                value={leverage}
                onChange={(e) => setLeverage(Number(e.target.value))}
                className="w-full bg-[#0b0c10] border border-[#1f2434] text-white text-xs rounded-lg p-2.5 focus:outline-none focus:border-[#d4af37]"
              >
                <option value={1}>1X 全额全款交割 (100%保证金)</option>
                <option value={10}>10X 杠杆交易 (10%保证金)</option>
                <option value={20}>20X 杠杆交易 (5%保证金)</option>
                <option value={50}>50X 高阶量化杠杆 (2%保证金)</option>
              </select>
            </div>
          </div>

          {/* Quantity Input (Grams & Quick Pills) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-[#8e94a5]">交易克数 (Grams)</label>
              <span className="text-xs font-mono text-[#d4af37]">
                约等于 {(quantityGrams / 31.1035).toFixed(3)} 盎司
              </span>
            </div>

            <div className="relative">
              <input
                type="number"
                min="10"
                max="100000"
                value={quantityGrams}
                onChange={(e) => setQuantityGrams(Math.max(10, Number(e.target.value)))}
                className="w-full bg-[#0b0c10] border border-[#232a3a] text-white font-mono text-lg font-bold rounded-lg py-3 px-4 focus:outline-none focus:border-[#d4af37]"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-[#8e94a5]">
                克 (g)
              </span>
            </div>

            {/* Quick preset weight buttons */}
            <div className="flex gap-2 mt-2">
              {[10, 50, 100, 500, 1000].map((weight) => (
                <button
                  key={weight}
                  type="button"
                  onClick={() => setQuantityGrams(weight)}
                  className={`flex-1 py-1 text-xs font-mono rounded border transition-colors ${
                    quantityGrams === weight
                      ? 'bg-[#d4af37]/20 border-[#d4af37] text-[#f3d772]'
                      : 'bg-[#151924] border-[#222736] text-[#8e94a5] hover:text-white'
                  }`}
                >
                  {weight}g
                </button>
              ))}
            </div>
          </div>

          {/* Physical Delivery & Vault Location */}
          <div className="p-3 bg-[#0b0c10] border border-[#1f2434] rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="physicalCheck"
                  checked={isPhysical}
                  onChange={(e) => setIsPhysical(e.target.checked)}
                  className="w-4 h-4 rounded border-[#32394d] text-[#d4af37] focus:ring-0"
                />
                <label htmlFor="physicalCheck" className="text-xs font-bold text-white cursor-pointer">
                  绑定100%实物贵金属仓单 / 安全金库存管
                </label>
              </div>
              <Lock className="w-4 h-4 text-[#d4af37]" />
            </div>

            {isPhysical && (
              <div className="pt-2 border-t border-[#1c202d] grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] text-[#8e94a5] mb-1">直属存管金库</label>
                  <select
                    value={vaultLocation}
                    onChange={(e) => setVaultLocation(e.target.value)}
                    className="w-full bg-[#141824] border border-[#252b3d] text-white text-xs rounded p-2 focus:outline-none"
                  >
                    <option value="上海自贸区国际金库">上海自贸区国际金库 (SGE全额备案)</option>
                    <option value="中国香港金银业贸易场金库">中国香港金银业贸易场金库</option>
                    <option value="新加坡樟宜国际金库">新加坡樟宜 FreePort 金库</option>
                    <option value="瑞士苏黎世安全保管库">瑞士苏黎世安全保管库</option>
                  </select>
                </div>

                <div className="text-[11px] text-[#8e94a5] flex flex-col justify-center">
                  <span>提取政策: 支持预约提现金条或顺丰特快保价全包配送至家</span>
                </div>
              </div>
            )}
          </div>

        </div>

        {/* Right Financial Calculation & Execution Summary Box */}
        <div className="lg:col-span-5 bg-[#0b0c10] border border-[#1f2434] rounded-xl p-5 flex flex-col justify-between space-y-6">
          
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-[#1c202d] pb-3">
              <span className="text-xs font-bold text-[#8e94a5]">订单算力摘要</span>
              <span className="text-[11px] font-mono text-[#22c55e] flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> 毫秒级风险校验
              </span>
            </div>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-[#8e94a5]">折合实时克价:</span>
                <span className="text-white font-bold">￥{pricePerGramCny} / 克</span>
              </div>

              <div className="flex justify-between">
                <span className="text-[#8e94a5]">交易克数/重:</span>
                <span className="text-white font-bold">{quantityGrams} 克</span>
              </div>

              <div className="flex justify-between">
                <span className="text-[#8e94a5]">名义交易总额:</span>
                <span className="text-[#f3d772] font-bold text-sm">￥{totalValueCny.toLocaleString()}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-[#8e94a5]">实际需冻结保证金 ({leverage}X):</span>
                <span className="text-white font-bold">￥{marginRequiredCny.toLocaleString()}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-[#8e94a5]">交易手续费 (0.03%):</span>
                <span className="text-white font-bold">￥{feeCny}</span>
              </div>
            </div>
          </div>

          <div className="space-y-3 pt-4 border-t border-[#1c202d]">
            <button
              type="button"
              onClick={handleExecuteOrder}
              disabled={isSubmitting}
              className={`w-full py-4 rounded-xl text-sm font-bold text-black transition-all flex items-center justify-center gap-2 shadow-xl ${
                side === 'BUY'
                  ? 'bg-gradient-to-r from-[#d4af37] via-[#f3d772] to-[#b89528] hover:opacity-95'
                  : 'bg-gradient-to-r from-[#ef4444] to-[#b91c1c] text-white hover:opacity-95'
              }`}
            >
              {isSubmitting ? (
                <span>Kotlin 撮合引擎处理中...</span>
              ) : (
                <>
                  <span>确认{side === 'BUY' ? '买入' : '卖出'} {quantityGrams}克{selectedMetal?.name || '黄金'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <p className="text-[11px] text-[#626a7f] text-center">
              提交后订单将通过 Kotlin 引擎进行分布式加密核验与金库资产锁定。
            </p>
          </div>

        </div>

      </div>

      {/* Transaction Receipt Modal */}
      {receipt && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#141722] border border-[#2e3548] rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
            
            <div className="flex items-center gap-3 border-b border-[#222736] pb-4">
              <div className="w-10 h-10 rounded-full bg-[#22c55e]/10 text-[#22c55e] flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">交易撮合与资产锁定成功</h3>
                <p className="text-xs text-[#8e94a5]">Kotlin 引擎执行耗时: {receipt.executedSpotPriceUsd ? '0.82ms' : '1.1ms'}</p>
              </div>
            </div>

            <div className="space-y-2.5 text-xs font-mono bg-[#0b0c10] p-4 rounded-xl border border-[#1f2434]">
              <div className="flex justify-between">
                <span className="text-[#8e94a5]">交易流水号:</span>
                <span className="text-[#d4af37] font-bold">{receipt.transactionId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8e94a5]">成交品类:</span>
                <span className="text-white">{receipt.symbol} ({receipt.side === 'BUY' ? '买入' : '卖出'})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8e94a5]">成交重量:</span>
                <span className="text-white font-bold">{receipt.quantityGrams} 克 ({receipt.quantityTroyOz} 盎司)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8e94a5]">成交人民币总额:</span>
                <span className="text-[#f3d772] font-bold">￥{receipt.totalValueCny?.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#8e94a5]">托管金库:</span>
                <span className="text-white">{receipt.vaultLocation}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[#1c202d]">
                <span className="text-[#8e94a5]">密码学存证签名:</span>
                <span className="text-[10px] text-[#626a7f] truncate max-w-[160px]">{receipt.auditSignature}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setReceipt(null)}
                className="w-full py-3 text-xs font-bold bg-[#d4af37] text-black rounded-lg hover:opacity-90"
              >
                完成并返回交易大厅
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
