'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Lock, Shield, Award, Download, CheckCircle, MapPin, FileCheck, QrCode } from 'lucide-react';

export const VaultCustody: React.FC = () => {
  const [certModalOpen, setCertModalOpen] = useState(false);
  const [holderName, setHolderName] = useState('张先生 / 尊享VIP账户');
  const [certGrams, setCertGrams] = useState(1000);
  const [certVault, setCertVault] = useState('上海自贸区国际金库 (SGE 备案)');

  const vaults = [
    {
      name: '上海自贸区国际金库',
      location: '中国 · 上海',
      capacity: '2,000 吨',
      specs: '上海黄金交易所 (SGE) 指定交割金库 · Tier-4 级防护',
      status: '正常运营'
    },
    {
      name: '香港金银业贸易场金库',
      location: '中国 · 香港',
      capacity: '800 吨',
      specs: 'CGSE AA 级认可理监事金库 · 亚太区离岸调拨中心',
      status: '正常运营'
    },
    {
      name: '新加坡樟宜 FreePort 金库',
      location: '新加坡',
      capacity: '1,200 吨',
      specs: '高安全离岸保税保管库 · 支持瑞士宝盛审计',
      status: '正常运营'
    },
    {
      name: '瑞士苏黎世安全保管库',
      location: '瑞士 · 苏黎世',
      capacity: '3,500 吨',
      specs: '欧洲核心黄金保管中心 · 独立三方安联保险承保',
      status: '正常运营'
    }
  ];

  return (
    <section className="bg-[#0c0d12] py-16 px-4 sm:px-6 lg:px-8 border-t border-[#1c2130]">
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Banner with Image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#121520] border border-[#222838] rounded-2xl overflow-hidden p-6 lg:p-10">
          <div className="lg:col-span-7 space-y-5">
            <div className="inline-flex items-center gap-2 text-xs font-mono text-[#d4af37] uppercase tracking-widest">
              <Lock className="w-4 h-4" /> 全球 5 大 Tier-4 顶级安全金库托管
            </div>
            <h2 className="text-3xl font-bold text-white tracking-tight">
              100% 独立账户隔离 · 实物黄金1:1足额存算
            </h2>
            <p className="text-sm text-[#8e94a5] leading-relaxed">
              金曜贵金属提供全球多节点金库托管服务。所有客户资产均存储于独立的保税保管库中，与金曜商业资产严格隔离，并由国际安联保险公司(Allianz)提供全额保险保护。
            </p>

            <div className="pt-2 flex flex-wrap gap-4">
              <button
                onClick={() => setCertModalOpen(true)}
                className="px-6 py-3 text-xs font-bold text-black bg-gradient-to-r from-[#d4af37] via-[#f3d772] to-[#b89528] rounded-xl hover:opacity-95 shadow-lg shadow-[#d4af37]/15 inline-flex items-center gap-2"
              >
                <FileCheck className="w-4 h-4" />
                <span>生成/查询我的金库存金证明书</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 relative h-64 rounded-xl overflow-hidden border border-[#272e42]">
            <Image
              src="/images/gold_vault.jpg"
              alt="High Security Gold Vault Interior"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4">
              <div className="text-xs text-[#f3d772] font-mono flex items-center gap-2">
                <Shield className="w-4 h-4 text-[#22c55e]" /> 实物金库独立物理隔离验真
              </div>
            </div>
          </div>
        </div>

        {/* 4 Vault Locations Grid */}
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-white">直属安全托管金库网络</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {vaults.map((vault, i) => (
              <div
                key={i}
                className="bg-[#121520] border border-[#202534] rounded-xl p-5 space-y-3 relative group hover:border-[#d4af37]/40 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-[#d4af37] flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" /> {vault.location}
                  </span>
                  <span className="text-[10px] font-mono text-[#22c55e] bg-[#22c55e]/10 px-2 py-0.5 rounded">
                    {vault.status}
                  </span>
                </div>

                <h4 className="text-base font-bold text-white group-hover:text-[#f3d772] transition-colors">
                  {vault.name}
                </h4>

                <p className="text-xs text-[#8e94a5] leading-relaxed">
                  {vault.specs}
                </p>

                <div className="pt-2 border-t border-[#1d2232] flex justify-between text-[11px] font-mono text-[#8e94a5]">
                  <span>存储容量:</span>
                  <span className="text-white font-bold">{vault.capacity}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Gold Certificate Viewer Modal */}
      {certModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#101218] border border-[#d4af37]/50 rounded-2xl max-w-lg w-full p-8 shadow-2xl space-y-6 relative overflow-hidden">
            
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#d4af37]/5 rounded-full blur-2xl pointer-events-none" />

            {/* Certificate Header */}
            <div className="text-center space-y-2 border-b border-[#232a3a] pb-4">
              <div className="text-2xl font-bold font-serif gold-gradient-text">
                金曜贵金属 · 实物黄金存管证明书
              </div>
              <div className="text-[10px] tracking-widest text-[#8e94a5] uppercase">
                JINYAO GLOBAL GOLD VAULT STORAGE CERTIFICATE
              </div>
            </div>

            {/* Certificate Body Form / Preview */}
            <div className="space-y-4 text-xs font-mono bg-[#161a26] p-5 rounded-xl border border-[#2a3144] relative">
              <div className="flex justify-between items-center">
                <span className="text-[#8e94a5]">证明编号:</span>
                <span className="text-[#d4af37] font-bold">JY-CERT-2026-98412</span>
              </div>

              <div>
                <label className="block text-[#8e94a5] mb-1">存管所有人姓名/账户:</label>
                <input
                  type="text"
                  value={holderName}
                  onChange={(e) => setHolderName(e.target.value)}
                  className="w-full bg-[#0d0f17] border border-[#2e364a] text-white p-2 rounded focus:outline-none text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#8e94a5] mb-1">存管克数 (克):</label>
                  <input
                    type="number"
                    value={certGrams}
                    onChange={(e) => setCertGrams(Number(e.target.value))}
                    className="w-full bg-[#0d0f17] border border-[#2e364a] text-white p-2 rounded focus:outline-none text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[#8e94a5] mb-1">托管金库:</label>
                  <select
                    value={certVault}
                    onChange={(e) => setCertVault(e.target.value)}
                    className="w-full bg-[#0d0f17] border border-[#2e364a] text-white p-2 rounded focus:outline-none text-xs"
                  >
                    <option value="上海自贸区国际金库 (SGE 备案)">上海自贸区国际金库</option>
                    <option value="香港金银业贸易场金库">香港金银业贸易场金库</option>
                    <option value="新加坡樟宜 FreePort 金库">新加坡樟宜 FreePort</option>
                    <option value="瑞士苏黎世安全保管库">瑞士苏黎世安全保管库</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-[#232938] flex items-center justify-between text-[11px]">
                <div className="space-y-1">
                  <div className="text-white">成色品质: Au99.99 纯金</div>
                  <div className="text-[#8e94a5]">保险承保: 德国安联保险公司 Allianz</div>
                </div>
                <div className="w-14 h-14 bg-white p-1 rounded">
                  <div className="w-full h-full bg-black flex items-center justify-center text-[8px] text-white font-mono text-center leading-tight">
                    JINYAO VERIFIED
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => alert('存金证明书电子版 (PDF) 已安全导出下载。')}
                className="flex-1 py-3 text-xs font-bold bg-[#d4af37] text-black rounded-lg hover:opacity-90 inline-flex items-center justify-center gap-1.5"
              >
                <Download className="w-4 h-4" /> 导出加密 PDF 证明文件
              </button>
              <button
                onClick={() => setCertModalOpen(false)}
                className="px-4 py-3 text-xs font-medium text-[#8e94a5] hover:text-white bg-[#1a1e2b] rounded-lg"
              >
                关闭
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
