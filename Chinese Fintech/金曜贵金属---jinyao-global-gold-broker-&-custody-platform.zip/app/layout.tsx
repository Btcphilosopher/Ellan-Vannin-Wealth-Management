import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: '金曜贵金属 | 全球贵金属交易与托管平台 (JINYAO Precious Metals)',
  description: '金曜贵金属为全球投资者提供专业的黄金、白银等贵金属交易与托管服务，助您把握时代机遇，守护财富价值。',
  openGraph: {
    title: '金曜贵金属 | 全球贵金属交易与托管平台',
    description: '金曜贵金属为全球投资者提供专业的黄金、白银等贵金属交易与托管服务。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '金曜贵金属 | 全球贵金属交易与托管平台',
    description: '金曜贵金属为全球投资者提供专业的黄金、白银等贵金属交易与托管服务。',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
