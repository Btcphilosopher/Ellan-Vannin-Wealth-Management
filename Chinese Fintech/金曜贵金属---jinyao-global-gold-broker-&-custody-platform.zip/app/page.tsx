'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { MarketStrip } from '@/components/MarketStrip';
import { ValueProps } from '@/components/ValueProps';
import { TradingViewChart } from '@/components/TradingViewChart';
import { TradeExecutionPanel } from '@/components/TradeExecutionPanel';
import { BullionECommerce } from '@/components/BullionECommerce';
import { VaultCustody } from '@/components/VaultCustody';
import { AiInsights } from '@/components/AiInsights';
import { KotlinBackendMonitor } from '@/components/KotlinBackendMonitor';
import { AccountModal } from '@/components/AccountModal';
import { PortfolioDrawer } from '@/components/PortfolioDrawer';
import { ShieldCheck, Phone, MapPin, Globe, Lock, ArrowUpRight, Award, Cpu } from 'lucide-react';

export default function Home() {
  const [activeSection, setActiveSection] = useState('hero');
  const [quotes, setQuotes] = useState<any[]>([]);
  const [orderBook, setOrderBook] = useState<any>(null);
  const [timestamp, setTimestamp] = useState<string>('');
  const [selectedCode, setSelectedCode] = useState<string>('XAUUSD');

  // Portfolio state
  const [userGoldGrams, setUserGoldGrams] = useState<number>(100.0);
  const [userBalanceCny, setUserBalanceCny] = useState<number>(500000.0);
  const [tradeHistory, setTradeHistory] = useState<any[]>([]);

  // Modals
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const [portfolioOpen, setPortfolioOpen] = useState(false);

  // Fetch real-time market quotes continuously
  useEffect(() => {
    const fetchQuotes = async () => {
      try {
        const res = await fetch('/api/market/pricing');
        const data = await res.json();
        if (data.metals) {
          setQuotes(data.metals);
          setOrderBook(data.orderBook);
          setTimestamp(data.timestamp);
        }
      } catch (e) {
        console.error('Failed to fetch pricing:', e);
      }
    };

    fetchQuotes();
    const timer = setInterval(fetchQuotes, 3000);
    return () => clearInterval(timer);
  }, []);

  const selectedMetal = quotes.find(q => q.code === selectedCode) || quotes[0] || {
    code: 'XAUUSD',
    name: '黄金',
    price: 2658.42,
    bid: 2658.22,
    ask: 2658.62,
    changeAmount: 12.36,
    changePercent: 0.47,
    high24h: 2665.10,
    low24h: 2642.80
  };

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const elem = document.getElementById(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleTradeSuccess = (tx: any) => {
    if (tx.side === 'BUY') {
      setUserGoldGrams(prev => prev + tx.quantityGrams);
      setUserBalanceCny(prev => Math.max(0, prev - tx.marginRequiredCny));
    } else {
      setUserGoldGrams(prev => Math.max(0, prev - tx.quantityGrams));
      setUserBalanceCny(prev => prev + tx.totalValueCny);
    }
    setTradeHistory(prev => [tx, ...prev]);
  };

  const handleBuyBullion = (product: any) => {
    handleTradeSuccess({
      symbol: 'AU9999 实物金条',
      side: 'BUY',
      quantityGrams: product.weightGrams,
      totalValueCny: product.priceCny,
      marginRequiredCny: product.priceCny,
      vaultLocation: '上海自贸区国际金库',
      timestamp: new Date().toISOString()
    });
    setPortfolioOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#08090c] text-white flex flex-col justify-between selection:bg-[#d4af37] selection:text-black">
      
      {/* Header */}
      <Header
        onNavigate={handleNavigate}
        activeSection={activeSection}
        onOpenAccount={() => setAccountModalOpen(true)}
        onOpenPortfolio={() => setPortfolioOpen(true)}
        onOpenKotlinMonitor={() => handleNavigate('kotlin-monitor')}
        userBalanceGoldGrams={userGoldGrams}
        userBalanceCny={userBalanceCny}
      />

      {/* Hero Section */}
      <div id="hero">
        <Hero
          onOpenAccount={() => setAccountModalOpen(true)}
          onNavigate={handleNavigate}
          liveQuotes={quotes}
        />
      </div>

      {/* Real-time Market Ticker Strip matching screenshot */}
      <div id="market">
        <MarketStrip
          quotes={quotes}
          timestamp={timestamp}
          onNavigate={handleNavigate}
          onSelectMetal={(metal) => {
            setSelectedCode(metal.code);
            handleNavigate('trading');
          }}
        />
      </div>

      {/* Value Propositions Bar matching screenshot */}
      <ValueProps />

      {/* Trading View Chart & Execution Terminal */}
      <section id="trading" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10 w-full">
        <div className="space-y-2 border-b border-[#1f2536] pb-4">
          <div className="text-xs font-mono text-[#d4af37] uppercase tracking-wider">
            HIGH FREQUENCY TRADING TERMINAL
          </div>
          <h2 className="text-3xl font-bold text-white tracking-tight">
            全球贵金属极速行情与交互交易大厅
          </h2>
          <p className="text-sm text-[#8e94a5]">
            实时查看 K 线图形、买卖深度与点差。底层依托 Kotlin 微服务提供 &lt;1ms 撮合支持。
          </p>
        </div>

        {/* Interactive Chart */}
        <TradingViewChart
          quotes={quotes}
          selectedCode={selectedCode}
          onSelectCode={setSelectedCode}
          orderBook={orderBook}
        />

        {/* Order Execution Panel */}
        <TradeExecutionPanel
          selectedMetal={selectedMetal}
          userBalanceCny={userBalanceCny}
          userBalanceGoldGrams={userGoldGrams}
          onTradeSuccess={handleTradeSuccess}
        />
      </section>

      {/* Physical Gold E-Commerce Store */}
      <div id="products">
        <BullionECommerce onBuyBullion={handleBuyBullion} />
      </div>

      {/* Vault Custody & Certificate Verification */}
      <div id="services">
        <VaultCustody />
      </div>

      {/* AI Market Insights & Gemini Report Generator matching screenshot */}
      <div id="insights">
        <AiInsights spotPrice={selectedMetal?.price || 2658.42} />
      </div>

      {/* Kotlin Microservice Backend Monitor */}
      <KotlinBackendMonitor />

      {/* About Us & Regulation Banner */}
      <section id="about" className="bg-[#0b0c10] py-16 px-4 sm:px-6 lg:px-8 border-t border-[#1c202d]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-8 space-y-4">
            <h2 className="text-2xl font-bold text-white">关于金曜贵金属 (JINYAO PRECIOUS METALS)</h2>
            <p className="text-sm text-[#8e94a5] leading-relaxed">
              金曜贵金属创立于中国上海，是全球领先的贵金属综合交易、实物金条理财及托管服务商。平台连接上海黄金交易所(SGE)、伦敦金银市场协会(LBMA)与中国香港金银业贸易场(CGSE)，致力于以安全、透明、高效的科技手段，为全球机构与个人投资者打造一站式贵金属资产配置平台。
            </p>
            <div className="flex flex-wrap gap-4 pt-2 text-xs font-mono text-[#d4af37]">
              <span>✓ 上海黄金交易所 (SGE) 综合类会员</span>
              <span>✓ 香港金银业贸易场 (CGSE) AA 类 084 号行员</span>
              <span>✓ 国际安联保险 (Allianz) 全额实物承保</span>
            </div>
          </div>

          <div className="lg:col-span-4 bg-[#121520] p-6 rounded-2xl border border-[#222838] space-y-3 text-xs">
            <div className="font-bold text-white text-sm">官方客户服务与安全专线</div>
            <div className="flex items-center gap-2 text-[#d4af37] font-mono text-base font-bold">
              <Phone className="w-4 h-4" /> 400-888-9999 (24小时)
            </div>
            <div className="text-[#8e94a5]">
              总部地址: 中国上海自由贸易试验区陆家嘴环路 1000 号金曜金融大厦 38 层
            </div>
          </div>
        </div>
      </section>

      {/* Global Luxury Footer */}
      <footer className="bg-[#06070a] border-t border-[#181c28] text-[#8e94a5] text-xs py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-3">
              <div className="text-base font-bold text-white flex items-center gap-2">
                <span className="text-[#d4af37] font-black text-lg">金</span>
                金曜贵金属
              </div>
              <p className="text-xs text-[#6e7587] leading-relaxed">
                全球贵金属交易、实物金条理财与托管平台。
              </p>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-white mb-1">交易品种</div>
              <div><a href="#trading" onClick={() => handleNavigate('trading')} className="hover:text-white">伦敦金 (XAUUSD)</a></div>
              <div><a href="#trading" onClick={() => handleNavigate('trading')} className="hover:text-white">伦敦银 (XAGUSD)</a></div>
              <div><a href="#trading" onClick={() => handleNavigate('trading')} className="hover:text-white">上金所 Au99.99</a></div>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-white mb-1">尊享服务</div>
              <div><a href="#products" onClick={() => handleNavigate('products')} className="hover:text-white">实物金条申购</a></div>
              <div><a href="#services" onClick={() => handleNavigate('services')} className="hover:text-white">金库安全托管</a></div>
              <div><a href="#insights" onClick={() => handleNavigate('insights')} className="hover:text-white">Gemini AI 智能研报</a></div>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-white mb-1">技术架构</div>
              <div className="font-mono text-[11px] text-[#22c55e] flex items-center gap-1">
                <Cpu className="w-3.5 h-3.5" /> Kotlin Coroutines High-Speed Backend
              </div>
              <div className="text-[11px] text-[#6e7587]">
                Next.js 15 App Router + Tailwind CSS + Gemini AI
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-[#141824] flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#52596b]">
            <div>
              © 2026 金曜贵金属 (JINYAO PRECIOUS METALS GLOBAL) . 保留所有权利。
            </div>
            <div className="flex gap-4">
              <span>隐私政策</span>
              <span>服务条款</span>
              <span>风险揭示书</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AccountModal
        isOpen={accountModalOpen}
        onClose={() => setAccountModalOpen(false)}
        onSuccess={() => setAccountModalOpen(false)}
      />

      <PortfolioDrawer
        isOpen={portfolioOpen}
        onClose={() => setPortfolioOpen(false)}
        goldGrams={userGoldGrams}
        balanceCny={userBalanceCny}
        tradeHistory={tradeHistory}
      />

    </div>
  );
}
