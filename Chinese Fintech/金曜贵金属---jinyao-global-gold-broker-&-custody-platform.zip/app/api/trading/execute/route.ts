import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      userId = 'USER-8892',
      symbol = 'XAUUSD',
      side = 'BUY', // BUY or SELL
      type = 'MARKET', // MARKET, LIMIT
      quantityGrams = 100,
      targetPrice,
      leverage = 1,
      isPhysicalDelivery = false,
      vaultLocation = '上海国际黄金交易中心金库'
    } = body;

    const currentSpotGoldUsd = 2658.42;
    const usdToCnyRate = 7.1825;
    const gramPriceUsd = currentSpotGoldUsd / 31.1035;
    const gramPriceCny = gramPriceUsd * usdToCnyRate;

    const totalCnyBeforeFee = Number((gramPriceCny * quantityGrams).toFixed(2));
    const feeCny = Number((totalCnyBeforeFee * 0.0003).toFixed(2)); // 0.03% broker fee
    const marginRequiredCny = Number((totalCnyBeforeFee / leverage).toFixed(2));

    const txTime = new Date().toISOString();
    const randomHash = Math.random().toString(36).substring(2, 10).toUpperCase();
    const transactionId = `JY-KT-${Date.now()}-${randomHash}`;

    // Cryptographic audit proof signature simulating Kotlin backend ledger
    const auditSignature = `0x${Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;

    const executionResult = {
      success: true,
      transactionId,
      kotlinEngineLatencyMs: Math.floor(Math.random() * 2) + 1, // 1-2ms latency
      timestamp: txTime,
      details: {
        userId,
        symbol,
        side,
        type,
        quantityGrams: Number(quantityGrams),
        quantityTroyOz: Number((quantityGrams / 31.1035).toFixed(4)),
        executedSpotPriceUsd: currentSpotGoldUsd,
        executedGramPriceCny: Number(gramPriceCny.toFixed(2)),
        totalValueCny: totalCnyBeforeFee,
        marginRequiredCny,
        feeCny,
        leverage,
        isPhysicalDelivery,
        vaultLocation: isPhysicalDelivery ? vaultLocation : '金曜电子账户托管',
        auditSignature,
        status: 'EXECUTED_AND_VAULT_LOCKED'
      }
    };

    return NextResponse.json(executionResult);
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ success: false, error: errorMessage }, { status: 400 });
  }
}
