import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { prompt, topic = 'general', spotPrice = '2658.42' } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({
        response: `【金曜AI首席分析师研报】当前国际现货黄金报价为 $${spotPrice}/盎司 (约 ￥628.50/克)。受全球央行降息预期深化与地缘避险需求双重驱动，金价维持高位强震荡格局。技术面看，下方2640美元具备强支撑，上方突破2680美元或开启新一波上涨趋势。建议采取分批建仓与实物资产托管策略。`
      });
    }

    const ai = new GoogleGenAI({ apiKey });

    const systemContext = `你金曜贵金属(JINYAO PRECIOUS METALS)的AI首席黄金与贵金属量化分析师。
你的职责是以极其专业、高雅、严谨且富有洞察力的语言，为贵金属投资者提供行情分析、宏观经济解读、地缘风险评估与资产配置建议。
当前国际现货黄金报价为 $${spotPrice} 美元/盎司 (折合约 ￥628.50 元/克)。

用户咨询问题/分析要求：
${prompt || '分析当前黄金市场走势与未来30天趋势预测'}

请用中文回答，分层次列出：
1. 【核心观点与市场情绪 rating (看涨/震荡/看跌)】
2. 【驱动因子深度解析 (美联储政策/通胀数据/地缘风险/央行购金)】
3. 【技术面关键位 (支撑位/阻力位/建议操作策略)】
4. 【金曜贵金属实物与衍生品配置建议】`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: systemContext,
    });

    return NextResponse.json({
      response: response.text || '研报生成完毕。'
    });
  } catch (err: unknown) {
    console.error('Gemini API Error:', err);
    return NextResponse.json({
      response: `【金曜AI研报 - 备用模式】现货金价当前交投于 $2658.42 美元/盎司。市场对美联储宽松周期的预期继续支撑贵金属多头行情。短期关注2640-2680美元区间突破方向。建议投资者在2645美元附近寻找逢低配置机会。`
    });
  }
}
