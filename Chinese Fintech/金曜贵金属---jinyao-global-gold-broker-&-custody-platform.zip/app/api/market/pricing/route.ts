import { NextResponse } from 'next/server';

export async function GET() {
  // Real-time market state calculation with natural micro-fluctuations
  const now = new Date();
  const timeString = now.toLocaleTimeString('zh-CN', { hour12: false });
  const dateString = now.toISOString().split('T')[0];

  // Random slight oscillation to simulate live price ticks
  const xauBase = 2658.42 + (Math.sin(Date.now() / 3000) * 0.85);
  const xagBase = 31.72 + (Math.cos(Date.now() / 4000) * 0.12);
  const xptBase = 985.60 + (Math.sin(Date.now() / 5000) * 0.45);
  const xpdBase = 1021.30 + (Math.cos(Date.now() / 3500) * 0.60);
  const au9999Base = 628.50 + (Math.sin(Date.now() / 2500) * 0.30);

  const marketData = {
    timestamp: `${dateString} ${timeString} (北京时间)`,
    usdToCny: 7.1825,
    metals: [
      {
        id: 'XAUUSD',
        code: 'XAUUSD',
        name: '黄金',
        englishName: 'Gold Spot',
        unit: '美元/盎司',
        cnyUnit: '元/克',
        cnyPrice: Number((xauBase / 31.1035 * 7.1825).toFixed(2)),
        price: Number(xauBase.toFixed(2)),
        bid: Number((xauBase - 0.20).toFixed(2)),
        ask: Number((xauBase + 0.20).toFixed(2)),
        changeAmount: 12.36,
        changePercent: 0.47,
        high24h: 2665.10,
        low24h: 2642.80,
        sparkline: [2644, 2648, 2645, 2652, 2650, 2655, 2658, Number(xauBase.toFixed(2))]
      },
      {
        id: 'XAGUSD',
        code: 'XAGUSD',
        name: '白银',
        englishName: 'Silver Spot',
        unit: '美元/盎司',
        cnyUnit: '元/克',
        cnyPrice: Number((xagBase / 31.1035 * 7.1825).toFixed(2)),
        price: Number(xagBase.toFixed(2)),
        bid: Number((xagBase - 0.02).toFixed(2)),
        ask: Number((xagBase + 0.02).toFixed(2)),
        changeAmount: 0.36,
        changePercent: 1.14,
        high24h: 31.95,
        low24h: 31.20,
        sparkline: [31.25, 31.30, 31.42, 31.50, 31.45, 31.62, 31.70, Number(xagBase.toFixed(2))]
      },
      {
        id: 'XPTUSD',
        code: 'XPTUSD',
        name: '铂金',
        englishName: 'Platinum Spot',
        unit: '美元/盎司',
        cnyUnit: '元/克',
        cnyPrice: Number((xptBase / 31.1035 * 7.1825).toFixed(2)),
        price: Number(xptBase.toFixed(2)),
        bid: Number((xptBase - 0.30).toFixed(2)),
        ask: Number((xptBase + 0.30).toFixed(2)),
        changeAmount: 7.20,
        changePercent: 0.74,
        high24h: 989.20,
        low24h: 976.50,
        sparkline: [977, 980, 978, 982, 981, 984, 985, Number(xptBase.toFixed(2))]
      },
      {
        id: 'XPDUSD',
        code: 'XPDUSD',
        name: '钯金',
        englishName: 'Palladium Spot',
        unit: '美元/盎司',
        cnyUnit: '元/克',
        cnyPrice: Number((xpdBase / 31.1035 * 7.1825).toFixed(2)),
        price: Number(xpdBase.toFixed(2)),
        bid: Number((xpdBase - 0.40).toFixed(2)),
        ask: Number((xpdBase + 0.40).toFixed(2)),
        changeAmount: 6.80,
        changePercent: 0.67,
        high24h: 1025.00,
        low24h: 1012.30,
        sparkline: [1013, 1016, 1018, 1015, 1020, 1019, 1021, Number(xpdBase.toFixed(2))]
      },
      {
        id: 'AU9999',
        code: 'AU9999',
        name: '上金所 Au99.99',
        englishName: 'SGE Gold Au9999',
        unit: '元/克',
        cnyUnit: '元/克',
        cnyPrice: Number(au9999Base.toFixed(2)),
        price: Number(au9999Base.toFixed(2)),
        bid: Number((au9999Base - 0.15).toFixed(2)),
        ask: Number((au9999Base + 0.15).toFixed(2)),
        changeAmount: 3.20,
        changePercent: 0.51,
        high24h: 630.00,
        low24h: 624.50,
        sparkline: [625, 626, 625.5, 627, 627.8, 628, 628.5, Number(au9999Base.toFixed(2))]
      }
    ],
    orderBook: {
      asks: [
        { price: Number((xauBase + 0.40).toFixed(2)), amountGrams: 1250, total: 2.1 },
        { price: Number((xauBase + 0.30).toFixed(2)), amountGrams: 800, total: 1.5 },
        { price: Number((xauBase + 0.20).toFixed(2)), amountGrams: 500, total: 0.8 },
        { price: Number((xauBase + 0.10).toFixed(2)), amountGrams: 300, total: 0.3 }
      ],
      bids: [
        { price: Number((xauBase - 0.10).toFixed(2)), amountGrams: 450, total: 0.45 },
        { price: Number((xauBase - 0.20).toFixed(2)), amountGrams: 900, total: 1.35 },
        { price: Number((xauBase - 0.30).toFixed(2)), amountGrams: 1400, total: 2.75 },
        { price: Number((xauBase - 0.40).toFixed(2)), amountGrams: 2200, total: 4.95 }
      ]
    }
  };

  return NextResponse.json(marketData);
}
