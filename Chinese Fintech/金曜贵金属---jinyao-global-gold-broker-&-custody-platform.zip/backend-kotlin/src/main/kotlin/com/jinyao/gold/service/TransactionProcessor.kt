package com.jinyao.gold.service

import com.jinyao.gold.model.ExecutionResult
import com.jinyao.gold.model.ExecutionStatus
import com.jinyao.gold.model.GoldOrder
import java.math.BigDecimal
import java.math.RoundingMode
import java.security.MessageDigest
import java.util.UUID

class TransactionProcessor(private val riskService: RiskManagementService) {

    fun executeOrder(order: GoldOrder, currentPriceUsd: BigDecimal): ExecutionResult {
        val startTime = System.currentTimeMillis()

        if (!riskService.validateOrder(order)) {
            return ExecutionResult(
                transactionId = "TX-REJ-${UUID.randomUUID().toString().take(8)}",
                orderId = order.orderId,
                status = ExecutionStatus.REJECTED,
                executedPrice = BigDecimal.ZERO,
                totalAmountCNY = BigDecimal.ZERO,
                feeCNY = BigDecimal.ZERO,
                auditHash = "",
                executionTimeMs = System.currentTimeMillis() - startTime
            )
        }

        // Convert USD/oz to CNY/gram (1 oz ≈ 31.1034768g, USD/CNY ≈ 7.18)
        val usdToCnyRate = BigDecimal("7.18")
        val gramToOzRate = BigDecimal("31.1035")

        val pricePerGramUsd = currentPriceUsd.divide(gramToOzRate, 4, RoundingMode.HALF_UP)
        val pricePerGramCny = pricePerGramUsd.multiply(usdToCnyRate).setScale(2, RoundingMode.HALF_UP)

        val totalAmountCny = pricePerGramCny.multiply(order.quantityGrams).setScale(2, RoundingMode.HALF_UP)
        val feeCny = totalAmountCny.multiply(BigDecimal("0.0003")).setScale(2, RoundingMode.HALF_UP) // 0.03% broker fee

        val txId = "JY-TX-${System.currentTimeMillis()}-${(1000..9999).random()}"
        val auditPayload = "$txId|${order.userId}|${order.symbol}|${order.quantityGrams}|$pricePerGramCny"
        val auditHash = MessageDigest.getInstance("SHA-256")
            .digest(auditPayload.toByteArray())
            .joinToString("") { "%02x".format(it) }

        return ExecutionResult(
            transactionId = txId,
            orderId = order.orderId,
            status = ExecutionStatus.EXECUTED,
            executedPrice = currentPriceUsd,
            totalAmountCNY = totalAmountCny,
            feeCNY = feeCny,
            auditHash = auditHash,
            executionTimeMs = System.currentTimeMillis() - startTime
        )
    }
}
