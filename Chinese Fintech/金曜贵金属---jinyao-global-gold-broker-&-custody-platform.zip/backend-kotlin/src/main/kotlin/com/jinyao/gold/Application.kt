package com.jinyao.gold

import com.jinyao.gold.service.MarketPricingEngine
import com.jinyao.gold.service.TransactionProcessor
import com.jinyao.gold.service.RiskManagementService
import kotlinx.coroutines.*
import java.time.Instant

/**
 * 金曜贵金属 (Jinyao Precious Metals) - Kotlin High-Performance Backend Service
 * Architecture: Ktor Coroutines + gRPC + WebSocket Engine
 * Focus: Sub-millisecond market price tick distribution & secure gold ledger transaction processing.
 */
fun main() {
    println("==================================================================")
    println("  JINYAO PRECIOUS METALS - KOTLIN BACKEND ENGINE V2.4 RUNNING     ")
    println("  Started at: ${Instant.now()}")
    println("  Active Modules: MarketPricingEngine | TransactionProcessor | RiskService ")
    println("==================================================================")

    val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Initialize Kotlin Services
    val pricingEngine = MarketPricingEngine()
    val riskService = RiskManagementService()
    val transactionProcessor = TransactionProcessor(riskService)

    // Start Real-Time Price Broadcast Pipeline
    scope.launch {
        pricingEngine.startPriceFeedStream().collect { tick ->
            // Broadcast live tick to WebSocket & gRPC clients
            println("[Kotlin Pricing Engine] TICK ${tick.symbol}: $${tick.bid} / $${tick.ask} (Spread: ${tick.spread})")
        }
    }

    // Keep service alive
    runBlocking {
        delay(Long.MAX_VALUE)
    }
}
