package com.jinyao.gold.service

import com.jinyao.gold.model.MetalSymbol
import com.jinyao.gold.model.PriceTick
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.math.BigDecimal
import java.math.RoundingMode
import java.security.SecureRandom

class MarketPricingEngine {

    private val random = SecureRandom()

    private var basePrices = mutableMapOf(
        MetalSymbol.XAUUSD to BigDecimal("2658.42"),
        MetalSymbol.XAGUSD to BigDecimal("31.72"),
        MetalSymbol.XPTUSD to BigDecimal("985.60"),
        MetalSymbol.XPDUSD to BigDecimal("1021.30"),
        MetalSymbol.AU9999 to BigDecimal("628.50")
    )

    fun startPriceFeedStream(): Flow<PriceTick> = flow {
        while (true) {
            MetalSymbol.entries.forEach { symbol ->
                val base = basePrices[symbol] ?: BigDecimal("2600.00")
                val deltaPercent = (random.nextDouble() - 0.49) * 0.0015
                val newPrice = base.multiply(BigDecimal(1.0 + deltaPercent)).setScale(2, RoundingMode.HALF_UP)
                basePrices[symbol] = newPrice

                val spreadAmount = when (symbol) {
                    MetalSymbol.XAUUSD -> BigDecimal("0.30")
                    MetalSymbol.XAGUSD -> BigDecimal("0.02")
                    MetalSymbol.AU9999 -> BigDecimal("0.10")
                    else -> BigDecimal("0.40")
                }

                val bid = newPrice.subtract(spreadAmount.divide(BigDecimal("2")))
                val ask = newPrice.add(spreadAmount.divide(BigDecimal("2")))
                val changeAmt = newPrice.subtract(base).setScale(2, RoundingMode.HALF_UP)
                val changePct = deltaPercent * 100.0

                val tick = PriceTick(
                    symbol = symbol,
                    bid = bid,
                    ask = ask,
                    lastPrice = newPrice,
                    changeAmount = changeAmt,
                    changePercent = BigDecimal(changePct).setScale(2, RoundingMode.HALF_UP),
                    high24h = newPrice.multiply(BigDecimal("1.012")).setScale(2, RoundingMode.HALF_UP),
                    low24h = newPrice.multiply(BigDecimal("0.988")).setScale(2, RoundingMode.HALF_UP),
                    volume24h = 128450L
                )
                emit(tick)
            }
            delay(1000) // 1-second price pulse stream
        }
    }
}
