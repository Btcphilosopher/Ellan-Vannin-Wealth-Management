package com.jinyao.gold.model

import java.math.BigDecimal
import java.time.Instant

enum class MetalSymbol(val code: String, val chineseName: String, val unit: String) {
    XAUUSD("XAUUSD", "伦敦金", "美元/盎司"),
    XAGUSD("XAGUSD", "伦敦银", "美元/盎司"),
    XPTUSD("XPTUSD", "铂金", "美元/盎司"),
    XPDUSD("XPDUSD", "钯金", "美元/盎司"),
    AU9999("AU9999", "上金所金", "元/克")
}

data class PriceTick(
    val symbol: MetalSymbol,
    val bid: BigDecimal,
    val ask: BigDecimal,
    val lastPrice: BigDecimal,
    val changeAmount: BigDecimal,
    val changePercent: BigDecimal,
    val high24h: BigDecimal,
    val low24h: BigDecimal,
    val volume24h: Long,
    val timestamp: Instant = Instant.now()
) {
    val spread: BigDecimal get() = ask.subtract(bid)
}

enum class OrderType { MARKET, LIMIT, STOP_LOSS }
enum class OrderSide { BUY, SELL }
enum class ExecutionStatus { PENDING, EXECUTED, REJECTED, MARGIN_CALL }

data class GoldOrder(
    val orderId: String,
    val userId: String,
    val symbol: MetalSymbol,
    val side: OrderSide,
    val type: OrderType,
    val quantityGrams: BigDecimal,
    val targetPrice: BigDecimal?,
    val leverage: Int = 1,
    val isPhysicalDelivery: Boolean = false,
    val vaultLocation: String? = null,
    val timestamp: Instant = Instant.now()
)

data class ExecutionResult(
    val transactionId: String,
    val orderId: String,
    val status: ExecutionStatus,
    val executedPrice: BigDecimal,
    val totalAmountCNY: BigDecimal,
    val feeCNY: BigDecimal,
    val auditHash: String,
    val executionTimeMs: Long
)
