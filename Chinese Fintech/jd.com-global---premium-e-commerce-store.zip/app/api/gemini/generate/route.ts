import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";
import { PRODUCTS } from "@/lib/products";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { prompt, language } = await req.json();

    const systemInstruction = `You are the official Smart E-Commerce Assistant for JD.com Global (京氏智能购物助手).
Your mission is to help shoppers explore, compare, and choose the perfect products from our official catalog.
Be polite, engaging, and highly professional.
Always write your response in the language that the user is interacting in (English or Chinese).

Official JD.com Premium Catalog:
${JSON.stringify(PRODUCTS, null, 2)}

Instructions:
1. Ground your answers strictly in our official catalog. Do not hallucinate or make up products we do not carry.
2. If a user asks for something we do not sell, politely clarify what we *do* have in our catalog that is close or fits their needs.
3. When recommending items, highlight their specific prices (e.g. ¥9,999) and key specifications.
4. Mention JD's core values when relevant:
   - 100% Authentic Guarantee (正品保障)
   - Lightning-fast Same-day Delivery via Drone Delivery Logistics (极速配送)
   - 7-Day Worry-Free Returns (售后无忧)
   - Exclusive JD PLUS VIP member savings (京氏PLUS会员)
5. Keep your responses structured with bullet points and friendly formatting. Never output raw markdown headings with double slashes (//) or snake_case tags, as per our premium design rules.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    const responseText = response.text || "I apologize, but I am unable to generate a recommendation at this moment. Please let me know how I can help!";
    return NextResponse.json({ success: true, text: responseText });
  } catch (error: any) {
    console.error("Gemini API Error in route:", error);
    return NextResponse.json(
      { success: false, error: error?.message || "Internal Server Error" },
      { status: 500 }
    );
  }
}
