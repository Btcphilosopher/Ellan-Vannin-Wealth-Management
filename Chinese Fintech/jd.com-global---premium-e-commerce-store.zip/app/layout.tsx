import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'JD.com Global - Premium E-Commerce Store',
  description: 'An interactive, feature-rich JD.com e-commerce platform clone featuring localized English/Chinese translation, smart search with real-time AI product recommendations, integrated shopping cart, product details, dynamic checkout simulators, and dynamic drone delivery tracking.',
  openGraph: {
    title: 'JD.com Global - Premium E-Commerce Store',
    description: 'An interactive, feature-rich JD.com e-commerce platform clone featuring localized English/Chinese translation, smart search with real-time AI product recommendations, integrated shopping cart, product details, dynamic checkout simulators, and dynamic drone delivery tracking.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'JD.com Global - Premium E-Commerce Store',
    description: 'An interactive, feature-rich JD.com e-commerce platform clone featuring localized English/Chinese translation, smart search with real-time AI product recommendations, integrated shopping cart, product details, dynamic checkout simulators, and dynamic drone delivery tracking.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body suppressHydrationWarning className="bg-[#f7f9fa] text-slate-800 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
