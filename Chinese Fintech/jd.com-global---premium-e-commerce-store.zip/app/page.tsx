'use client';

import React from "react";
import { StoreProvider, useStore } from "@/context/StoreContext";
import Navbar from "@/components/Navbar";
import Sidebar from "@/components/Sidebar";
import HeroSection from "@/components/HeroSection";
import CategoryGrid from "@/components/CategoryGrid";
import ProductGrid from "@/components/ProductGrid";
import CartDrawer from "@/components/CartDrawer";
import CheckoutModal from "@/components/CheckoutModal";
import AIAssistant from "@/components/AIAssistant";
import { Shield, Sparkles, Award } from "lucide-react";

// Inner coordinator component to consume Context hooks
function HomePageContent() {
  const { language } = useStore();

  const text = {
    footerText: {
      en: "© 2026 JD.com Global E-Commerce. All rights reserved. Supported by JD Autonomous Low-Altitude Drone Logistics.",
      zh: "© 2026 京东全球购旗舰店。保留所有权利。由京东未来低空无人机智能化物流网络提供全程技术支持。"
    },
    footerLinks: {
      en: ["About JD", "Logistics", "PLUS Club", "Terms of Service", "Help Center"],
      zh: ["关于京东", "未来物流", "PLUS会员俱乐部", "服务条款", "帮助中心"]
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#f7f9fa]">
      {/* 1. Header/Navigation Zone */}
      <Navbar />

      {/* 2. Main Layout Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-6 py-6 flex flex-col gap-8">
        {/* Top Split Layout: Sidebar Categories + Hero Campaign Banner */}
        <div className="flex flex-col lg:flex-row gap-6">
          <Sidebar />
          <div className="flex-1 min-w-0">
            <HeroSection />
          </div>
        </div>

        {/* Mid Showcase Layout: Category Teaser Cards & PLUS Gold VIP banner */}
        <CategoryGrid />

        {/* Bottom Showcase Layout: Dynamic Filterable Recommendations Products Grid */}
        <ProductGrid />
      </main>

      {/* 3. Sliding Overlay Components & Drawers */}
      <CartDrawer />
      <CheckoutModal />
      <AIAssistant />

      {/* 4. Bespoke Clean Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-8 px-6 mt-16 border-t border-slate-800 shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Static Unboxed links */}
          <div className="flex items-center gap-4 text-[11px] font-medium text-slate-500">
            {text.footerLinks[language].map((link, i) => (
              <span key={i} className="hover:text-white transition-colors cursor-pointer whitespace-nowrap">
                {link}
              </span>
            ))}
          </div>

          {/* Copy rights */}
          <div className="text-center md:text-right text-[10px] text-slate-500 leading-normal font-mono">
            <span>{text.footerText[language]}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function Page() {
  return (
    <StoreProvider>
      <HomePageContent />
    </StoreProvider>
  );
}
