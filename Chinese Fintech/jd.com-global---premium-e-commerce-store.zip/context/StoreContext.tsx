'use client';

import React, { createContext, useContext, useState, useEffect } from "react";
import { Product, PRODUCTS } from "@/lib/products";

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface DroneDeliveryStatus {
  step: number; // 0: Confirmed, 1: Packed, 2: Drone Scheduled, 3: Dispatched, 4: Delivered
  distanceLeft: number; // in km (simulated)
  etaMinutes: number; // simulated
  active: boolean;
}

interface StoreContextType {
  language: "en" | "zh";
  setLanguage: (lang: "en" | "zh") => void;
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isPlusUser: boolean;
  setIsPlusUser: (status: boolean) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  droneSimulation: DroneDeliveryStatus;
  startDroneSimulation: (address: string) => void;
  stopDroneSimulation: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<"en" | "zh">("zh"); // Default to Chinese as per JD mockup
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isPlusUser, setIsPlusUser] = useState<boolean>(false);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);

  const [droneSimulation, setDroneSimulation] = useState<DroneDeliveryStatus>({
    step: 0,
    distanceLeft: 12.5,
    etaMinutes: 15,
    active: false,
  });

  // Load state from localStorage on mount
  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedCart = localStorage.getItem("jd_cart");
      const savedPlus = localStorage.getItem("jd_plus_user");
      const savedLang = localStorage.getItem("jd_lang");

      if (savedCart) {
        try {
          setCart(JSON.parse(savedCart));
        } catch (e) {
          console.error("Error reading cart from localStorage:", e);
        }
      }
      if (savedPlus === "true") {
        setIsPlusUser(true);
      }
      if (savedLang === "en" || savedLang === "zh") {
        setLanguage(savedLang);
      }
    }
  }, []);

  // Save cart to localStorage when changed
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("jd_cart", JSON.stringify(cart));
    }
  }, [cart]);

  // Save PLUS status
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("jd_plus_user", isPlusUser ? "true" : "false");
    }
  }, [isPlusUser]);

  // Save language
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("jd_lang", language);
    }
  }, [language]);

  const addToCart = (product: Product, quantity = 1) => {
    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex((item) => item.product.id === product.id);
      if (existingIndex > -1) {
        const newCart = [...prevCart];
        newCart[existingIndex].quantity += quantity;
        return newCart;
      } else {
        return [...prevCart, { product, quantity }];
      }
    });
    // Visual cue
    setIsCartOpen(true);
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Live drone simulation runner
  const startDroneSimulation = (address: string) => {
    setDroneSimulation({
      step: 0,
      distanceLeft: 12.5,
      etaMinutes: 15,
      active: true,
    });

    const interval = setInterval(() => {
      setDroneSimulation((prev) => {
        if (!prev.active) {
          clearInterval(interval);
          return prev;
        }

        const nextStep = prev.step < 4 ? prev.step + 1 : 4;
        const nextDistance = Math.max(0, parseFloat((prev.distanceLeft - 3.1).toFixed(1)));
        const nextEta = Math.max(0, Math.round(prev.etaMinutes - 3.5));

        if (nextStep === 4) {
          clearInterval(interval);
          return {
            step: 4,
            distanceLeft: 0,
            etaMinutes: 0,
            active: true, // keep it true to show success modal
          };
        }

        return {
          step: nextStep,
          distanceLeft: nextDistance,
          etaMinutes: nextEta,
          active: true,
        };
      });
    }, 4500); // Progress stages every 4.5 seconds for snappy interactive feel
  };

  const stopDroneSimulation = () => {
    setDroneSimulation((prev) => ({ ...prev, active: false }));
  };

  return (
    <StoreContext.Provider
      value={{
        language,
        setLanguage,
        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        isPlusUser,
        setIsPlusUser,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        droneSimulation,
        startDroneSimulation,
        stopDroneSimulation,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error("useStore must be used within a StoreProvider");
  }
  return context;
}
