export interface Product {
  id: string;
  nameEn: string;
  nameZh: string;
  categoryEn: string;
  categoryZh: string;
  price: number;
  image: string;
  descriptionEn: string;
  descriptionZh: string;
  specs: { [key: string]: string };
  specsZh: { [key: string]: string };
  stock: number;
  featured?: boolean;
}

export const PRODUCTS: Product[] = [
  {
    id: "macbook-m4",
    nameEn: "MacBook Air M4",
    nameZh: "MacBook Air M4 笔记本电脑",
    categoryEn: "3C Digital",
    categoryZh: "3C 数码",
    price: 8999,
    image: "/images/product_macbook_air_1791188034316.jpg",
    descriptionEn: "Experience breathtaking performance and all-day battery life with the next-generation M4 chip. Housed in a super-thin aluminum chassis.",
    descriptionZh: "全新搭载 M4 芯片，拥有惊人的性能和全天候超长续航。铝合金超薄机身设计，轻盈便携。",
    specs: {
      "Processor": "Apple M4 Chip (10-core CPU, 10-core GPU)",
      "Memory": "16GB Unified Memory",
      "Storage": "512GB Superfast SSD",
      "Display": "13.6-inch Liquid Retina Display",
      "Battery": "Up to 18 hours battery life"
    },
    specsZh: {
      "处理器": "Apple M4 芯片 (10核中央处理器，10核图形处理器)",
      "内存": "16GB 统一内存",
      "存储": "512GB 超高速固态硬盘",
      "屏幕": "13.6 英寸液态视网膜显示屏",
      "电池续航": "长达 18 小时续航时间"
    },
    stock: 24,
    featured: true
  },
  {
    id: "iphone-17-pro",
    nameEn: "iPhone 17 Pro",
    nameZh: "iPhone 17 Pro 智能手机",
    categoryEn: "3C Digital",
    categoryZh: "3C 数码",
    price: 9999,
    image: "/images/category_3c_1791187975159.jpg", // high-fidelity titanium aesthetic image
    descriptionEn: "Featuring a aerospace-grade titanium design, the innovative proactive lens system, and the ultra-intelligent A19 Pro bionic chip.",
    descriptionZh: "采用航天级钛金属边框设计，配有全新一代旗舰三摄系统，搭载极速智能 A19 Pro 仿生芯片。",
    specs: {
      "Processor": "A19 Pro chip with 6-core GPU",
      "Display": "6.7-inch Super Retina XDR OLED",
      "Camera": "48MP Main | 48MP Ultrawide | 12MP 5x Telephoto",
      "Material": "Aerospace-grade Titanium",
      "Network": "Next-Gen 5G Enabled"
    },
    specsZh: {
      "处理器": "A19 Pro 芯片 搭载 6核图形处理器",
      "屏幕": "6.7 英寸超视网膜 XDR OLED 屏",
      "相机": "4800万主摄 | 4800万超广角 | 1200万 5倍光学变焦",
      "材质": "航天级钛金属机身",
      "网络": "支持双模 5G 全网通"
    },
    stock: 42,
    featured: true
  },
  {
    id: "robot-vacuum-g30",
    nameEn: "Roborock Vacuum G30",
    nameZh: "石头扫地机器人 G30",
    categoryEn: "3C Digital",
    categoryZh: "3C 数码",
    price: 3499,
    image: "/images/category_appliances_1791187985259.jpg", // Fallback / premium clean hardware
    descriptionEn: "AI-guided smart vacuum and mop. Featuring 8000Pa hyper suction, dynamic hot-water mop washing, and autonomous obstacle navigation.",
    descriptionZh: "AI 智能导航扫拖一体机。具备 8000Pa 飓风吸力、热水主动洗拖布和前沿自动避障系统。",
    specs: {
      "Suction Power": "8000Pa Hyper Suction",
      "Navigation": "LDS Laser + AI Obstacle Recognition",
      "Self-Cleaning": "60°C Hot Water Mop Self-Wash & Drying",
      "Dustbin Capacity": "400ml Internal, Auto-Empty Dock"
    },
    specsZh: {
      "吸力大小": "8000Pa 飓风超强吸力",
      "导航避障": "LDS激光雷达 + AI视觉避障",
      "自清洁": "60°C热水自清洁 & 热风烘干拖布",
      "尘盒容量": "400ml机身尘盒，支持集尘基站自动集尘"
    },
    stock: 15,
    featured: true
  },
  {
    id: "dyson-dryer",
    nameEn: "Dyson Supersonic Hair Dryer",
    nameZh: "戴森 Supersonic 吹风机",
    categoryEn: "Home Appliances",
    categoryZh: "家用电器",
    price: 2999,
    image: "/images/category_appliances_1791187985259.jpg",
    descriptionEn: "Intelligent heat control prevents extreme heat damage to protect natural shine. Engineered for different hair types.",
    descriptionZh: "智能温控系统防止过热损伤，呵护秀发自然光泽。配备多款风嘴，精准满足各种发质造型需求。",
    specs: {
      "Power": "1600W High Speed Digital Motor V9",
      "Airflow Speed": "3 Settings (Fast, Regular, Gentle)",
      "Heat Settings": "4 Precision Heat Levels including Cold Shot",
      "Weight": "660g Balanced Ergonomic Design"
    },
    specsZh: {
      "电机功率": "1600W 戴森第九代数码电机",
      "风速档位": "3档精准风速控制",
      "温度档位": "4档精准温度设置 (包含一键冷风键)",
      "机身重量": "660g 均重人体工学平衡设计"
    },
    stock: 18,
    featured: true
  },
  {
    id: "skii-skincare",
    nameEn: "SK-II Treatment Essence Set",
    nameZh: "SK-II 护肤神仙水套装",
    categoryEn: "Beauty & Cosmetics",
    categoryZh: "美妆个护",
    price: 1299,
    image: "/images/category_beauty_1791188004284.jpg",
    descriptionEn: "Unlock crystal clear skin. Formulated with over 90% Pitera, this luxury essence nourishes skin and boosts hydration.",
    descriptionZh: "焕活晶莹剔透美肌。富含 90% 以上经典 Pitera 酵母精华，密集滋养修护，强韧肌肤屏障。",
    specs: {
      "Main Ingredient": "Pitera™ Yeast Extract (>90%)",
      "Skin Type": "Suitable for All Skin Types",
      "Set Includes": "Facial Treatment Essence 230ml + Clear Lotion 30ml",
      "Benefits": "Anti-aging, hydration, brightening, texture refining"
    },
    specsZh: {
      "核心成分": "Pitera™ 经典半乳糖酵母样菌发酵产物滤液 (>90%)",
      "适用肤质": "适合各种肤质",
      "套装包含": "护肤精华露 (神仙水) 230ml + 嫩肤清莹露 30ml",
      "主要功效": "细腻毛孔、强韧屏障、提亮提拉、温和补水"
    },
    stock: 30,
    featured: true
  },
  {
    id: "scandinavian-sofa",
    nameEn: "Scandinavian Lounge Sofa",
    nameZh: "北欧极简美学布艺沙发",
    categoryEn: "Home Furnishings",
    categoryZh: "家居家装",
    price: 4500,
    image: "/images/category_home_1791187994773.jpg",
    descriptionEn: "Indulge in organic minimalism. Plush off-white natural fabric cushions with solid oak legs. Crafted for timeless interiors.",
    descriptionZh: "沉浸于有机极简美学。亲肤柔软的米白色天然棉麻面料，搭配坚固耐磨的橡木实木支架。为永恒雅致的家居空间设计。",
    specs: {
      "Dimensions": "220cm (W) x 90cm (D) x 80cm (H)",
      "Material": "Premium Cotton-Linen Blend & Solid White Oak",
      "Cushion Fill": "High-Density Resilient Memory Foam + Pure Down",
      "Capacity": "Comfortably seats 3-4 people"
    },
    specsZh: {
      "规格尺寸": "宽 220 厘米 x 深 90 厘米 x 高 80 厘米",
      "框架材质": "高档棉麻混纺面料 & F.S.C.认证北美白橡木实木",
      "填充材质": "高密度高回弹记忆海绵 + 蓬松环保白鹅绒",
      "座位承重": "可舒适容纳 3-4 人"
    },
    stock: 8,
    featured: false
  },
  {
    id: "organic-fresh-crate",
    nameEn: "Premium Organic Fresh Basket",
    nameZh: "有机时令生鲜时蔬礼盒",
    categoryEn: "Fresh Food",
    categoryZh: "食品生鲜",
    price: 299,
    image: "/images/category_food_1791188013814.jpg",
    descriptionEn: "Hand-picked organic basket including dewy heirloom tomatoes, crisp alpine lettuce, carrots, and direct-from-farm berries.",
    descriptionZh: "每日凌晨手工采摘，保证绝对鲜活。内含带露高原番茄、高山爽脆生菜、新鲜彩椒及时令有机水果。",
    specs: {
      "Origin": "Greenhouse Certified Organic Farm",
      "Delivery": "Same-day cold chain logistics",
      "Weight": "5kg of mixed premium vegetables & seasonal fruits",
      "Shelf Life": "Best consumed within 3-5 days of delivery"
    },
    specsZh: {
      "产品产地": "国家认证绿色有机示范基地",
      "配送时效": "全程冷链，当天往返达",
      "包装净重": "5千克 严选混合有机时蔬与时令水果",
      "保质期限": "建议收货后 3-5 天内食用以保证最佳鲜度"
    },
    stock: 50,
    featured: true
  },
  {
    id: "adidas-ultraboost",
    nameEn: "Adidas Ultra-Running Shoes",
    nameZh: "阿迪达斯 越野极速跑步鞋",
    categoryEn: "Sports & Outdoors",
    categoryZh: "运动户外",
    price: 699,
    image: "/images/category_food_1791188013814.jpg", // Fallback (or we render with a styled background card inside app)
    descriptionEn: "Engineered with responsive comfort cushioning and highly breathable Primeknit upper. Ideal for long-distance city training.",
    descriptionZh: "专为长距离城市路跑设计。搭载高弹缓震鞋底与超轻透气针织鞋面，干爽包裹脚踝，每一步都提供澎湃回弹反馈。",
    specs: {
      "Technology": "Responsive Energy-Return Boost Midsole",
      "Upper": "Seamless Recycled Primeknit Fabric",
      "Outsole": "Continental™ Rubber for extreme dry & wet grip",
      "Weight": "310g (Size US 9)"
    },
    specsZh: {
      "中底技术": "高弹爆发力 Boost 能量缓震中底",
      "鞋面材质": "Primeknit 一体化轻质无缝编织鞋面",
      "大底材质": "马牌 Continental™ 防滑耐磨橡胶大底",
      "单只重量": "310克 (美国标准尺码 9码)"
    },
    stock: 25,
    featured: true
  }
];
