'use client';

import React, { useState, useRef, useEffect } from "react";
import { useStore } from "@/context/StoreContext";
import { Bot, X, Send, Sparkles, MessageSquare, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
}

export default function AIAssistant() {
  const { language } = useStore();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const listRef = useRef<HTMLDivElement>(null);

  // Setup initial message
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: "welcome",
          role: "assistant",
          text: language === "en"
            ? "Hello! I am your JD AI Smart Shopping Assistant. I can recommend premium products, check specifications, or translate searches. How can I help you today?"
            : "您好！我是您的京东 AI 智能导购员。我能为您提供精准的商品推荐、核对参数规格，或帮您比较不同产品的性价比。请问有什么我可以帮您？"
        }
      ]);
    }
  }, [language, messages.length]);

  // Scroll to bottom when messages update
  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const quickPills = {
    en: [
      "Recommend a high-end laptop",
      "Is the fresh food crate organic?",
      "Tell me about SK-II Treatment Set",
      "Explain JD Drone Delivery"
    ],
    zh: [
      "推荐一款高性能笔记本",
      "生鲜礼盒是有机的吗？",
      "介绍下SK-II神仙水套装",
      "无人机配送支持哪里？"
    ]
  };

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMsg: ChatMessage = {
      id: Math.random().toString(),
      role: "user",
      text: textToSend,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);
    setErrorMsg(null);

    try {
      const response = await fetch("/api/gemini/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: textToSend, language }),
      });

      const data = await response.json();

      if (data.success && data.text) {
        const assistantMsg: ChatMessage = {
          id: Math.random().toString(),
          role: "assistant",
          text: data.text,
        };
        setMessages((prev) => [...prev, assistantMsg]);
      } else {
        throw new Error(data.error || "Failed to fetch response");
      }
    } catch (err: any) {
      console.error("AI Assistant Error:", err);
      setErrorMsg(language === "en" ? "Oops! Connection timed out. Please check your network and try again." : "抱歉！智能导购连接超时，请检查您的网络后重试。");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans select-none">
      {/* 1. Floating Action Toggler Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="bg-gradient-to-r from-slate-900 to-slate-800 hover:from-slate-800 hover:to-slate-700 text-amber-300 w-14 h-14 rounded-full shadow-2xl flex items-center justify-center cursor-pointer border border-slate-700/60 relative group"
        aria-label="Toggle AI Assistant"
      >
        <Bot className="w-6 h-6 text-amber-300 group-hover:rotate-12 transition-transform" />
        <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-red-500"></span>
        </span>
      </motion.button>

      {/* 2. Chat Drawer Panel Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.95 }}
            className="absolute bottom-16 right-0 w-[360px] sm:w-[420px] h-[520px] bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col justify-between"
          >
            {/* Header */}
            <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                <Sparkles className="w-4 h-4 text-amber-300 animate-pulse shrink-0" />
                <span>{language === "en" ? "JD AI Shopping Concierge" : "京东自营 AI 智能导购员"}</span>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-slate-500 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Messages Feed Frame */}
            <div
              ref={listRef}
              className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 scroll-smooth text-slate-200"
            >
              {messages.map((msg) => {
                const isUser = msg.role === "user";
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col max-w-[85%] text-xs ${
                      isUser ? "self-end items-end" : "self-start items-start"
                    }`}
                  >
                    <span className="text-[9px] text-slate-500 mb-0.5 uppercase tracking-wider font-semibold font-mono">
                      {isUser ? (language === "en" ? "You" : "顾客") : (language === "en" ? "JD AI" : "AI导购")}
                    </span>
                    <div
                      className={`p-3 rounded-2xl leading-relaxed text-left font-sans whitespace-pre-wrap ${
                        isUser
                          ? "bg-[#e1251b] text-white rounded-tr-none"
                          : "bg-slate-900 text-slate-100 rounded-tl-none border border-slate-800"
                      }`}
                    >
                      {msg.text}
                    </div>
                  </div>
                );
              })}

              {/* Loader */}
              {loading && (
                <div className="self-start flex flex-col items-start max-w-[80%] text-xs">
                  <span className="text-[9px] text-slate-500 mb-0.5 uppercase font-mono">AI typing...</span>
                  <div className="bg-slate-900 border border-slate-800 p-3 rounded-2xl rounded-tl-none flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-amber-300 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-amber-300 rounded-full animate-bounce delay-100"></span>
                    <span className="w-1.5 h-1.5 bg-amber-300 rounded-full animate-bounce delay-200"></span>
                  </div>
                </div>
              )}

              {/* Error Segment */}
              {errorMsg && (
                <div className="bg-red-900/20 border border-red-900/40 rounded-lg p-3 text-red-400 text-xs text-left flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p>{errorMsg}</p>
                </div>
              )}
            </div>

            {/* Static Quick Prompt Pills Grid */}
            <div className="p-3 border-t border-slate-900 bg-slate-950 flex flex-wrap gap-1.5 shrink-0 select-none">
              {(language === "en" ? quickPills.en : quickPills.zh).map((pill, i) => (
                <button
                  key={i}
                  disabled={loading}
                  onClick={() => handleSend(pill)}
                  className="bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-[10px] font-semibold py-1.5 px-2.5 rounded-full border border-slate-800 transition-colors whitespace-nowrap max-w-full truncate cursor-pointer disabled:opacity-40"
                >
                  {pill}
                </button>
              ))}
            </div>

            {/* Chat inputs */}
            <div className="p-3 border-t border-slate-900 bg-slate-900 flex items-center gap-2 shrink-0">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSend(input);
                }}
                disabled={loading}
                placeholder={language === "en" ? "Ask AI Shopping Assistant..." : "咨询AI智能导购..."}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg py-2 px-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 disabled:opacity-50"
              />
              <button
                disabled={loading || !input.trim()}
                onClick={() => handleSend(input)}
                className="bg-[#e1251b] hover:bg-[#c31c13] disabled:bg-slate-800 text-white p-2 rounded-lg transition-colors shrink-0 cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
