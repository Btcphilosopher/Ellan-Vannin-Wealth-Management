'use client';

import React, { useState } from "react";
import { useStore } from "@/context/StoreContext";
import { ArrowRight, Gift, CheckCircle, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Image from "next/image";

export default function CategoryGrid() {
  const { language, selectedCategory, setSelectedCategory, isPlusUser, setIsPlusUser } = useStore();
  const [showPlusSuccess, setShowPlusSuccess] = useState(false);

  const boards = [
    {
      id: "3C Digital",
      titleEn: "3C Digital",
      titleZh: "3C 数码",
      sloganEn: "Tech Changes Life",
      sloganZh: "科技改变生活",
      image: "/images/category_3c_1791187975159.jpg",
      bgClass: "from-blue-500/10 to-transparent",
    },
    {
      id: "Home Appliances",
      titleEn: "Home Appliances",
      titleZh: "家用电器",
      sloganEn: "Quality home, Smart Life",
      sloganZh: "品质家电 智享生活",
      image: "/images/category_appliances_1791187985259.jpg",
      bgClass: "from-purple-500/10 to-transparent",
    },
    {
      id: "Home Furnishings",
      titleEn: "Home & Furniture",
      titleZh: "家居家装",
      sloganEn: "Create Your Ideal Space",
      sloganZh: "打造理想想家",
      image: "/images/category_home_1791187994773.jpg",
      bgClass: "from-amber-500/10 to-transparent",
    },
    {
      id: "Beauty & Cosmetics",
      titleEn: "Beauty & Care",
      titleZh: "美妆个护",
      sloganEn: "Selected Global Brands",
      sloganZh: "甄选全球好物",
      image: "/images/category_beauty_1791188004284.jpg",
      bgClass: "from-pink-500/10 to-transparent",
    },
    {
      id: "Fresh Food",
      titleEn: "Fresh Food",
      titleZh: "食品生鲜",
      sloganEn: "Direct Farm Fresh Delivery",
      sloganZh: "新鲜直达 产地直供",
      image: "/images/category_food_1791188013814.jpg",
      bgClass: "from-emerald-500/10 to-transparent",
    },
  ];

  const handleBoardClick = (catId: string) => {
    setSelectedCategory(catId);
    const el = document.getElementById("today-recommendations");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleActivatePlus = () => {
    setIsPlusUser(true);
    setShowPlusSuccess(true);
    setTimeout(() => {
      setShowPlusSuccess(false);
    }, 4000);
  };

  const text = {
    explore: {
      en: "Explore",
      zh: "探索更多"
    },
    plusTitle: {
      en: "JD PLUS VIP Premium Membership",
      zh: "京氏PLUS会员"
    },
    plusSlogan: {
      en: "Exclusive VIP Privileges · Extra 10% Off Everything",
      zh: "专属权益 · 全场订单再享 9 折优惠"
    },
    plusCta: {
      en: "Activate PLUS Now",
      zh: "立即开通 ➔"
    },
    plusActivated: {
      en: "PLUS VIP Status Active!",
      zh: "金牌PLUS会员特权已生效！"
    },
    plusSuccessTitle: {
      en: "Welcome to JD PLUS VIP!",
      zh: "成功开通京氏PLUS会员！"
    },
    plusSuccessBody: {
      en: "Congratulations! An exclusive 10% discount has been auto-applied to all products in your shopping cart. Look out for the gold VIP badge!",
      zh: "恭喜！全场 10% (九折) 额外优惠已自动绑定到您的账户。结账时可享受双重折扣优惠！"
    }
  };

  return (
    <div className="w-full flex flex-col gap-6 font-sans select-none">
      {/* 1. Main Category Grid + PLUS Member side-by-side Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left 3 Columns: 5 Teaser boards grid */}
        <div className="lg:col-span-3 grid grid-cols-2 md:grid-cols-5 gap-4">
          {boards.map((board, i) => {
            const isBoardActive = selectedCategory === board.id;
            return (
              <div
                key={i}
                onClick={() => handleBoardClick(board.id)}
                className={`relative rounded-xl overflow-hidden shadow-sm hover:shadow-md cursor-pointer transition-all duration-300 transform hover:-translate-y-1 border bg-white flex flex-col justify-between p-3.5 ${
                  isBoardActive
                    ? "border-[#e1251b] ring-2 ring-red-100"
                    : "border-slate-100 hover:border-slate-300"
                }`}
              >
                {/* Title Overlay Info */}
                <div className="text-left mb-2 z-10">
                  <h3 className="text-sm font-bold text-slate-800 leading-tight">
                    {language === "en" ? board.titleEn : board.titleZh}
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5 leading-none font-medium truncate">
                    {language === "en" ? board.sloganEn : board.sloganZh}
                  </p>
                </div>

                {/* Styled Local Image Component */}
                <div className="relative w-full aspect-[4/3] rounded-md overflow-hidden bg-slate-50 mt-1">
                  <Image
                    src={board.image}
                    alt={board.titleEn}
                    fill
                    sizes="(max-width: 768px) 50vw, 20vw"
                    className="object-cover object-center transition-transform duration-500 hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Arrow indicator */}
                <div className="flex items-center justify-between text-[10px] font-bold text-slate-500 group-hover:text-[#e1251b] mt-3 border-t border-slate-50 pt-2 shrink-0">
                  <span>{language === "en" ? text.explore.en : text.explore.zh}</span>
                  <ArrowRight className="w-3 h-3 text-slate-400" />
                </div>
              </div>
            );
          })}
        </div>

        {/* Right 1 Column: JD PLUS Member Card Registration Card */}
        <div className="lg:col-span-1">
          <div className="relative rounded-xl overflow-hidden shadow-sm hover:shadow-md border border-slate-200 bg-slate-950 text-white h-full flex flex-col justify-between p-5 group min-h-[220px]">
            {/* Ambient gold glow */}
            <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/20 via-yellow-600/5 to-transparent pointer-events-none z-0"></div>

            {/* PLUS Card Graphic */}
            <div className="relative w-full aspect-[16/9] rounded-lg overflow-hidden border border-white/10 z-10 mb-4 shadow-lg shrink-0">
              <Image
                src="/images/plus_gold_banner_1791188023576.jpg"
                alt="JD PLUS Golden Card"
                fill
                sizes="(max-width: 1024px) 100vw, 25vw"
                className="object-cover object-center group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-3">
                <span className="text-[10px] font-bold text-amber-300 uppercase tracking-widest flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  VIP PREMIUM CLUB
                </span>
              </div>
            </div>

            {/* Texts */}
            <div className="text-left relative z-10 flex-1 flex flex-col justify-between gap-3">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-1.5 leading-tight">
                  <Gift className="w-4 h-4 text-amber-400 shrink-0" />
                  {language === "en" ? text.plusTitle.en : text.plusTitle.zh}
                </h4>
                <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                  {language === "en" ? text.plusSlogan.en : text.plusSlogan.zh}
                </p>
              </div>

              {/* Action Button */}
              {isPlusUser ? (
                <div className="bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-bold py-2.5 px-4 rounded-lg flex items-center justify-center gap-1.5 w-full select-none">
                  <CheckCircle className="w-4 h-4 text-amber-400" />
                  <span>{language === "en" ? text.plusActivated.en : text.plusActivated.zh}</span>
                </div>
              ) : (
                <button
                  onClick={handleActivatePlus}
                  className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-bold py-2.5 px-4 rounded-lg transition-all active:scale-95 shadow-md hover:shadow-lg w-full flex items-center justify-center gap-1 cursor-pointer"
                >
                  <span>{language === "en" ? text.plusCta.en : text.plusCta.zh}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 2. Success Modal Overlay */}
      <AnimatePresence>
        {showPlusSuccess && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-amber-400/50 rounded-xl shadow-2xl p-6 w-full max-w-md text-slate-100 text-left relative overflow-hidden"
            >
              {/* Gold light particle effect in corners */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none"></div>

              <div className="flex flex-col items-center text-center gap-4">
                <div className="w-16 h-16 rounded-full bg-amber-400/20 border-2 border-amber-400 flex items-center justify-center text-amber-400 animate-bounce">
                  <Gift className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-extrabold text-white">
                  {language === "en" ? text.plusSuccessTitle.en : text.plusSuccessTitle.zh}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed max-w-sm">
                  {language === "en" ? text.plusSuccessBody.en : text.plusSuccessBody.zh}
                </p>
                <button
                  onClick={() => setShowPlusSuccess(false)}
                  className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-xs py-2.5 px-8 rounded-full transition-all active:scale-95 mt-2"
                >
                  OK
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
