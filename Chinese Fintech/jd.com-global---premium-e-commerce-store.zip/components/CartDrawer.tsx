'use client';

import React from "react";
import { useStore } from "@/context/StoreContext";
import { ShoppingBag, X, Minus, Plus, Trash2, Gift, CreditCard } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Image from "next/image";

export default function CartDrawer() {
  const {
    language,
    cart,
    updateCartQuantity,
    removeFromCart,
    isCartOpen,
    setIsCartOpen,
    isPlusUser,
    setIsCheckoutOpen,
  } = useStore();

  const FREE_SHIPPING_THRESHOLD = 499;

  // Calculators
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discount = isPlusUser ? subtotal * 0.1 : 0;
  const finalTotal = subtotal - discount;
  const shippingFee = finalTotal >= FREE_SHIPPING_THRESHOLD || finalTotal === 0 ? 0 : 50;
  const grandTotal = finalTotal + shippingFee;

  const progressPct = Math.min(100, Math.round((subtotal / FREE_SHIPPING_THRESHOLD) * 100));
  const amountToFree = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);

  const text = {
    title: {
      en: "Shopping Cart",
      zh: "我的购物车"
    },
    emptyTitle: {
      en: "Your cart is empty",
      zh: "您的购物车空空如也"
    },
    emptyBody: {
      en: "Explore our categories and add smart tech, cosmetics, and organic food items!",
      zh: "快去挑选心仪的智能数码、美妆护肤、食品生鲜好物吧！"
    },
    shippingActive: {
      en: "🎉 Free Drone Delivery is active on this order!",
      zh: "🎉 恭喜！本单已满足免无人机运费标准！"
    },
    shippingRemaining: {
      en: `Add ¥${amountToFree.toLocaleString()} more for Free Drone Delivery.`,
      zh: `还差 ¥${amountToFree.toLocaleString()} 即可享受无人机极速免运费。`
    },
    checkoutBtn: {
      en: "Proceed to Checkout",
      zh: "立即结账"
    },
    summarySubtotal: {
      en: "Subtotal",
      zh: "商品金额"
    },
    summaryDiscount: {
      en: "PLUS VIP Savings (10% Off)",
      zh: "PLUS会员特权立减 (9折)"
    },
    summaryShipping: {
      en: "Drone Shipping Fee",
      zh: "无人机配送费"
    },
    summaryTotal: {
      en: "Grand Total",
      zh: "应付总额"
    },
    quantityLimit: {
      en: "Limit reached",
      zh: "超出库存"
    }
  };

  const handleCheckoutClick = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden font-sans select-none">
          {/* Backdrop mask */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="absolute inset-0 bg-black/50 backdrop-blur-xs"
          ></motion.div>

          {/* Drawer Panel */}
          <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.3 }}
              className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between"
            >
              {/* Header */}
              <div className="border-b border-slate-100 px-6 py-5 flex items-center justify-between bg-slate-50">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-[#e1251b]" />
                  <h2 className="text-base font-bold text-slate-800">
                    {language === "en" ? text.title.en : text.title.zh}
                  </h2>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Items Frame */}
              <div className="flex-1 overflow-y-auto px-6 py-4 flex flex-col gap-4">
                {cart.length > 0 ? (
                  <>
                    {/* Free shipping banner progress */}
                    <div className="bg-slate-50 border border-slate-100 rounded-lg p-3 text-left">
                      <p className="text-[10px] font-semibold text-slate-700 leading-tight">
                        {subtotal >= FREE_SHIPPING_THRESHOLD
                          ? (language === "en" ? text.shippingActive.en : text.shippingActive.zh)
                          : (language === "en" ? text.shippingRemaining.en : text.shippingRemaining.zh)}
                      </p>
                      <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2 overflow-hidden">
                        <div
                          className="bg-[#e1251b] h-full transition-all duration-500"
                          style={{ width: `${progressPct}%` }}
                        ></div>
                      </div>
                    </div>

                    {/* Cart Items List */}
                    <div className="flex flex-col gap-3.5 mt-2">
                      {cart.map((item) => (
                        <div
                          key={item.product.id}
                          className="flex items-center gap-4 pb-3.5 border-b border-slate-100"
                        >
                          {/* Image Box */}
                          <div className="relative w-16 h-16 rounded-md overflow-hidden bg-slate-50 border border-slate-100 shrink-0">
                            <Image
                              src={item.product.image}
                              alt={item.product.nameEn}
                              fill
                              sizes="64px"
                              className="object-cover object-center"
                              referrerPolicy="no-referrer"
                            />
                          </div>

                          {/* Info Column */}
                          <div className="flex-1 text-left flex flex-col gap-1 min-w-0">
                            <span className="text-[9px] font-bold text-[#e1251b]/80 uppercase">
                              {language === "en" ? item.product.categoryEn : item.product.categoryZh}
                            </span>
                            <h4 className="text-xs font-semibold text-slate-800 truncate">
                              {language === "en" ? item.product.nameEn : item.product.nameZh}
                            </h4>
                            <span className="text-xs font-bold text-slate-800 font-mono tabular-nums leading-none">
                              ¥{item.product.price.toLocaleString()}
                            </span>
                          </div>

                          {/* Controls Row */}
                          <div className="flex flex-col items-end gap-2 shrink-0">
                            {/* Stepper */}
                            <div className="flex items-center border border-slate-200 rounded-md bg-slate-50 h-7 overflow-hidden text-xs">
                              <button
                                onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                                className="px-2 py-1 text-slate-500 hover:bg-slate-200 transition-colors h-full flex items-center justify-center"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="w-8 text-center font-bold font-mono">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                                disabled={item.quantity >= item.product.stock}
                                className="px-2 py-1 text-slate-500 hover:bg-slate-200 transition-colors h-full flex items-center justify-center disabled:opacity-30"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>

                            {/* Trash Delete */}
                            <button
                              onClick={() => removeFromCart(item.product.id)}
                              className="text-slate-400 hover:text-[#e1251b] transition-colors p-1"
                              title="Remove item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  /* Empty State View */
                  <div className="flex-1 flex flex-col items-center justify-center text-center gap-4 py-12">
                    <div className="w-16 h-16 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-300">
                      <ShoppingBag className="w-8 h-8" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-800">
                        {language === "en" ? text.emptyTitle.en : text.emptyTitle.zh}
                      </h3>
                      <p className="text-xs text-slate-400 mt-1.5 leading-relaxed max-w-xs">
                        {language === "en" ? text.emptyBody.en : text.emptyBody.zh}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Footer Summary Container */}
              {cart.length > 0 && (
                <div className="border-t border-slate-100 px-6 py-5 bg-slate-50 flex flex-col gap-4 shrink-0 text-xs">
                  {/* Ledger lines */}
                  <div className="flex flex-col gap-2 font-medium text-slate-500">
                    <div className="flex justify-between items-center">
                      <span>{language === "en" ? text.summarySubtotal.en : text.summarySubtotal.zh}</span>
                      <span className="font-mono tabular-nums text-slate-700">¥{subtotal.toLocaleString()}</span>
                    </div>

                    {isPlusUser && (
                      <div className="flex justify-between items-center text-amber-600 font-semibold bg-amber-50 rounded px-2 py-1">
                        <span className="flex items-center gap-1">
                          <Gift className="w-3.5 h-3.5" />
                          {language === "en" ? text.summaryDiscount.en : text.summaryDiscount.zh}
                        </span>
                        <span className="font-mono tabular-nums">-¥{discount.toLocaleString()}</span>
                      </div>
                    )}

                    <div className="flex justify-between items-center">
                      <span>{language === "en" ? text.summaryShipping.en : text.summaryShipping.zh}</span>
                      <span className="font-mono tabular-nums text-slate-700">
                        {shippingFee === 0 ? (
                          <span className="text-emerald-600 font-bold uppercase text-[10px]">FREE</span>
                        ) : (
                          `¥${shippingFee}`
                        )}
                      </span>
                    </div>

                    <div className="flex justify-between items-center border-t border-slate-200 pt-2.5 mt-1 text-sm text-slate-800 font-extrabold">
                      <span>{language === "en" ? text.summaryTotal.en : text.summaryTotal.zh}</span>
                      <span className="text-[#e1251b] font-mono tabular-nums">¥{grandTotal.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Checkout Action Button */}
                  <button
                    onClick={handleCheckoutClick}
                    className="w-full bg-[#e1251b] hover:bg-[#c31c13] text-white py-3.5 px-4 rounded-lg font-bold text-sm transition-all flex items-center justify-center gap-2 active:scale-95 shadow-md hover:shadow-lg cursor-pointer"
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>{language === "en" ? text.checkoutBtn.en : text.checkoutBtn.zh}</span>
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
}
