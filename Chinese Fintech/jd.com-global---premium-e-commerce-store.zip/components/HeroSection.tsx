'use client';

import React, { useState, useEffect } from "react";
import { useStore } from "@/context/StoreContext";
import { ShieldCheck, Truck, RotateCcw, Award, Globe, Play, Compass, BatteryCharging, ShieldAlert } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function HeroSection() {
  const { language } = useStore();
  const [isDroneModalOpen, setIsDroneModalOpen] = useState(false);
  const [simulationStep, setSimulationStep] = useState(0);
  const [telemetry, setTelemetry] = useState({
    speed: 0,
    altitude: 0,
    battery: 100,
    distanceLeft: 4.8,
  });

  const text = {
    title: {
      en: "Faster Delivery, Better Life Within Reach",
      zh: "更快的配送 让美好生活触手可及"
    },
    subtitle: {
      en: "JD 2030 Intelligent Autonomous Logistics Network: Same-day delivery, 1-hour local fulfillment, global direct dispatch.",
      zh: "京东 2030 智能物流网络：全国当日达 · 1小时极速达 · 全球购直接通关。"
    },
    cta: {
      en: "Explore JD Drone Future Logistics ➔",
      zh: "探索京东未来物流 ➔"
    },
    benefits: [
      {
        titleEn: "Guaranteed Authentic",
        titleZh: "正品保障",
        descEn: "100% Official Products, 10x Refund",
        descZh: "100% 正品 假一赔十",
        icon: ShieldCheck
      },
      {
        titleEn: "Lightning Delivery",
        titleZh: "极速配送",
        descEn: "Same-Day Delivery, 1hr Fulfillment",
        descZh: "当日达 · 1小时达",
        icon: Truck
      },
      {
        titleEn: "Worry-Free Aftersales",
        titleZh: "售后无忧",
        descEn: "7-Day Free Easy Return Service",
        descZh: "7天无理由退换货",
        icon: RotateCcw
      },
      {
        titleEn: "PLUS VIP Member",
        titleZh: "PLUS会员",
        descEn: "Exclusive Savings & Support",
        descZh: "专属权益 尊享服务",
        icon: Award
      },
      {
        titleEn: "Global Sourcing",
        titleZh: "全球购",
        descEn: "Overseas Direct Mail, Certified",
        descZh: "海外直邮 正品保障",
        icon: Globe
      }
    ],
    droneTrackerTitle: {
      en: "JD Drone autonomous Flight Terminal (Simulated)",
      zh: "京东无人机自适应航路控制台 (全景模拟)"
    },
    droneStatus: [
      { en: "Pre-flight Diagnostics & Loading", zh: "起飞前系统诊断与货物装载" },
      { en: "Ascending & Aligning To Flight Corridor", zh: "上升至低空航路并校正坐标" },
      { en: "Cruise Speed Active - Heading To Customer", zh: "高速巡航中 - 正向目的地飞往" },
      { en: "Descending To Safe Drop Zone altitude", zh: "正在降落至安全空域空投点" },
      { en: "Delivery Complete - Returning To Base Hub", zh: "投递完成 - 自动返航至集散中心" }
    ],
    close: {
      en: "Dismiss Console",
      zh: "关闭控制台"
    }
  };

  // Run drone telemetry updates while modal is open
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isDroneModalOpen) {
      setSimulationStep(0);
      setTelemetry({
        speed: 0,
        altitude: 0,
        battery: 100,
        distanceLeft: 4.8,
      });

      interval = setInterval(() => {
        setSimulationStep((prevStep) => {
          const nextStep = prevStep < 4 ? prevStep + 1 : 4;

          setTelemetry((prevTel) => {
            let nextSpeed = 0;
            let nextAlt = 0;
            let nextBat = prevTel.battery - Math.floor(Math.random() * 5 + 3);
            let nextDist = Math.max(0, parseFloat((prevTel.distanceLeft - 1.2).toFixed(1)));

            if (nextStep === 1) {
              nextSpeed = 35; // km/h
              nextAlt = 85; // meters
            } else if (nextStep === 2) {
              nextSpeed = 75;
              nextAlt = 120;
            } else if (nextStep === 3) {
              nextSpeed = 20;
              nextAlt = 15;
            } else if (nextStep === 4) {
              nextSpeed = 0;
              nextAlt = 0;
              nextDist = 0;
            }

            return {
              speed: nextSpeed,
              altitude: nextAlt,
              battery: Math.max(10, nextBat),
              distanceLeft: nextDist,
            };
          });

          return nextStep;
        });
      }, 3000);
    }

    return () => clearInterval(interval);
  }, [isDroneModalOpen]);

  return (
    <div className="w-full flex flex-col gap-6 font-sans select-none">
      {/* 1. Main Banner with Background */}
      <div
        className="relative w-full h-[360px] lg:h-[420px] rounded-2xl overflow-hidden shadow-lg bg-cover bg-center flex items-center"
        style={{
          backgroundImage: `linear-gradient(to right, rgba(0,0,0,0.85) 30%, rgba(0,0,0,0.3) 70%, rgba(0,0,0,0.15)), url('/images/hero_drone_delivery_1791187962371.jpg')`,
        }}
      >
        {/* Core Headline Overlay */}
        <div className="max-w-2xl px-6 lg:px-12 text-left z-10">
          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-2xl lg:text-4xl font-extrabold text-white leading-tight"
            style={{ textWrap: "balance" }}
          >
            {language === "en" ? text.title.en : text.title.zh}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-3 text-xs lg:text-sm text-slate-300 leading-relaxed max-w-xl"
          >
            {language === "en" ? text.subtitle.en : text.subtitle.zh}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-6 flex flex-wrap gap-3"
          >
            <button
              onClick={() => setIsDroneModalOpen(true)}
              className="bg-[#e1251b] hover:bg-[#c31c13] text-white text-xs lg:text-sm font-semibold py-3 px-6 rounded-full transition-all shadow-md hover:shadow-lg hover:scale-105 active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <Truck className="w-4 h-4 text-white" />
              <span>{language === "en" ? text.cta.en : text.cta.zh}</span>
            </button>
          </motion.div>
        </div>

        {/* Small floating status indicators overlay */}
        <div className="absolute right-4 bottom-4 hidden md:flex items-center gap-3 bg-black/60 backdrop-blur-md rounded-lg py-1.5 px-3 border border-white/10 text-[10px] text-emerald-400 font-mono">
          <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
          <span>AUTONOMOUS DRONE LOGISTICS ONLINE // ACTIVE FLEETS: 142</span>
        </div>
      </div>

      {/* 2. Core Trust Badges Bar */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 py-4 px-6 grid grid-cols-2 md:grid-cols-5 gap-4 lg:gap-6 divide-x-0 md:divide-x divide-slate-100">
        {text.benefits.map((benefit, i) => {
          const Icon = benefit.icon;
          return (
            <div
              key={i}
              className="flex items-center gap-3 justify-start md:justify-center px-2 py-1 md:py-0"
            >
              <div className="w-9 h-9 rounded-full bg-red-50 flex items-center justify-center text-[#e1251b] shrink-0">
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h4 className="text-xs font-bold text-slate-800">
                  {language === "en" ? benefit.titleEn : benefit.titleZh}
                </h4>
                <p className="text-[10px] text-slate-400 mt-0.5 truncate">
                  {language === "en" ? benefit.descEn : benefit.descZh}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* 3. Drone Flight Simulator Modal */}
      <AnimatePresence>
        {isDroneModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-950 border border-slate-800 rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden text-slate-200 text-left font-mono"
            >
              {/* Terminal Title */}
              <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                  <span>{language === "en" ? text.droneTrackerTitle.en : text.droneTrackerTitle.zh}</span>
                </div>
                <button
                  onClick={() => setIsDroneModalOpen(false)}
                  className="text-slate-500 hover:text-white transition-colors"
                >
                  ✕
                </button>
              </div>

              <div className="p-6 flex flex-col gap-6">
                {/* Visual Route Grid */}
                <div className="grid grid-cols-5 gap-2 relative mt-4">
                  {/* Progress Line */}
                  <div className="absolute top-4 left-4 right-4 h-0.5 bg-slate-800 z-0"></div>
                  <div
                    className="absolute top-4 left-4 h-0.5 bg-[#e1251b] z-0 transition-all duration-1000"
                    style={{ width: `${simulationStep * 25}%` }}
                  ></div>

                  {[0, 1, 2, 3, 4].map((step) => (
                    <div key={step} className="flex flex-col items-center text-center z-10">
                      <div
                        className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                          simulationStep >= step
                            ? "bg-[#e1251b] text-white ring-4 ring-red-900/30"
                            : "bg-slate-900 text-slate-500 border border-slate-800"
                        }`}
                      >
                        {step + 1}
                      </div>
                      <span className="text-[9px] mt-2 text-slate-400 font-semibold uppercase leading-none hidden md:block">
                        {step === 0 && (language === "en" ? "Load" : "装载")}
                        {step === 1 && (language === "en" ? "Takeoff" : "起飞")}
                        {step === 2 && (language === "en" ? "En Route" : "巡航")}
                        {step === 3 && (language === "en" ? "Descend" : "降落")}
                        {step === 4 && (language === "en" ? "Done" : "妥投")}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Simulated Flight Feed Log */}
                <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-4 flex flex-col gap-3 min-h-[90px] justify-center relative">
                  <div className="text-xs text-[#e1251b] font-bold uppercase flex items-center gap-1.5">
                    <Compass className="w-4 h-4 animate-spin text-red-500" />
                    <span>Live Tracking Node Status:</span>
                  </div>
                  <p className="text-sm font-bold text-white">
                    {language === "en"
                      ? text.droneStatus[simulationStep].en
                      : text.droneStatus[simulationStep].zh}
                  </p>
                </div>

                {/* Telemetry Dashboard Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-900/40 border border-slate-800/80 rounded-lg p-4">
                  <div className="text-left border-r border-slate-800/60 pr-2">
                    <div className="text-[10px] text-slate-500 uppercase">GPS Distance Left</div>
                    <div className="text-xl font-bold text-white font-mono mt-0.5">
                      {telemetry.distanceLeft} <span className="text-xs text-slate-400">km</span>
                    </div>
                  </div>
                  <div className="text-left border-r border-slate-800/60 px-2">
                    <div className="text-[10px] text-slate-500 uppercase">Speed Indicator</div>
                    <div className="text-xl font-bold text-white font-mono mt-0.5">
                      {telemetry.speed} <span className="text-xs text-slate-400">km/h</span>
                    </div>
                  </div>
                  <div className="text-left border-r border-slate-800/60 px-2">
                    <div className="text-[10px] text-slate-500 uppercase">Flight Altitude</div>
                    <div className="text-xl font-bold text-white font-mono mt-0.5">
                      {telemetry.altitude} <span className="text-xs text-slate-400">meters</span>
                    </div>
                  </div>
                  <div className="text-left px-2">
                    <div className="text-[10px] text-slate-500 uppercase flex items-center gap-1">
                      <BatteryCharging className="w-3 h-3 text-emerald-400" />
                      <span>Battery Capacity</span>
                    </div>
                    <div className="text-xl font-bold text-emerald-400 font-mono mt-0.5">
                      {telemetry.battery}%
                    </div>
                  </div>
                </div>

                {/* Bottom Dismiss */}
                <div className="flex items-center justify-between border-t border-slate-800 pt-4 mt-2">
                  <div className="text-[9px] text-slate-500 max-w-sm text-left leading-normal">
                    *JD Drone-Express is powered by autonomous coordinate corridor matching. Standard air density controls are active.
                  </div>
                  <button
                    onClick={() => setIsDroneModalOpen(false)}
                    className="bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold py-2.5 px-5 rounded-md transition-all active:scale-95"
                  >
                    {language === "en" ? text.close.en : text.close.zh}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
