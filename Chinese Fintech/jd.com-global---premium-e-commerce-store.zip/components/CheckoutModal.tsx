'use client';

import React, { useState } from "react";
import { useStore } from "@/context/StoreContext";
import { CreditCard, Truck, CheckCircle, MapPin, Phone, User, Landmark, Compass, BatteryCharging, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Image from "next/image";

export default function CheckoutModal() {
  const {
    language,
    cart,
    clearCart,
    isPlusUser,
    isCheckoutOpen,
    setIsCheckoutOpen,
    droneSimulation,
    startDroneSimulation,
    stopDroneSimulation,
  } = useStore();

  const [formData, setFormData] = useState({
    name: "Tom ahX",
    phone: "+86 138-0013-8000",
    address: "Chaoyang District No.108, JD S-Hub Tower A, Beijing",
    zip: "100020",
  });

  const [paymentMethod, setPaymentMethod] = useState<"card" | "cod">("cod"); // Prefer Cash on Delivery for trust demo
  const [orderCompleted, setOrderCompleted] = useState(false);
  const [formErrors, setFormErrors] = useState<string | null>(null);

  const FREE_SHIPPING_THRESHOLD = 499;

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discount = isPlusUser ? subtotal * 0.1 : 0;
  const finalTotal = subtotal - discount;
  const shippingFee = finalTotal >= FREE_SHIPPING_THRESHOLD || finalTotal === 0 ? 0 : 50;
  const grandTotal = finalTotal + shippingFee;

  const text = {
    title: {
      en: "Secure Checkout & Address Verification",
      zh: "极速安全结算与地址核验"
    },
    verificationSub: {
      en: "Please verify your delivery address. Autononous Drone Delivery requires correct GPS coordinates matching your postal code.",
      zh: "请填写并核对您的收货人信息。无人机GPS极速航线要求邮政编码必须精确对准所在社区。"
    },
    labelName: {
      en: "Consignee Full Name / 收货人姓名",
      zh: "收货人姓名"
    },
    labelPhone: {
      en: "Mobile Phone Number / 联系电话",
      zh: "联系电话"
    },
    labelAddress: {
      en: "Detailed GPS Address / 详细收货地址",
      zh: "详细收货地址"
    },
    labelZip: {
      en: "Postal / ZIP Code (6-digits) / 邮政编码",
      zh: "邮政编码"
    },
    paymentTitle: {
      en: "Select Settlement Method",
      zh: "选择支付方式"
    },
    payCod: {
      en: "Cash on Delivery (COD) / 货到付款",
      zh: "货到付款 (支持验货后付款，安心免定金)"
    },
    payCard: {
      en: "Credit Card Payments / 信用卡支付",
      zh: "信用卡 / 储蓄卡快捷支付 (立省 ¥5 现金)"
    },
    submitBtn: {
      en: `Confirm Order & Dispatch Drone (¥${grandTotal.toLocaleString()})`,
      zh: `提交订单 · 调度无人机配送 (共计 ¥${grandTotal.toLocaleString()})`
    },
    summaryTitle: {
      en: "Consolidated Summary",
      zh: "商品清单摘要"
    },
    flightTitle: {
      en: "JD Express Autonomous drone Flight Terminal",
      zh: "京东自营航线三维物流轨迹监控"
    },
    flightStatus: [
      { en: "Drone Dispatching Confirmed — Preparing cargo capsule at warehouse hub...", zh: "订单指令确认 — 正在总仓调拨并装载耐空压密封保温舱..." },
      { en: "GPS Route matching computed. Drone takeoff verified. Ascending to 100m corridor...", zh: "航路微积分匹配完毕。无人机起飞升空，正在校准风速爬升中..." },
      { en: "Entering high-speed cruise corridor. Telemetry speed locked at 75km/h...", zh: "已并入主航线巡航走廊。遥测时速锁定 75km/h，GPS巡航飞往目的地..." },
      { en: "Approaching coordinates. Commencing local spatial scan for safe drop altitude...", zh: "已飞抵目的地空域。降高至安全距离并进行三维激光雷达避障扫描..." },
      { en: "Package safely landed in drop box! Verification code: 824-JD. Returning to hangar...", zh: "包裹已安全空投着陆！签收提货码: 824-JD。无人机正自主返航..." }
    ],
    droneSpeed: { en: "Velocity", zh: "飞行时速" },
    droneAlt: { en: "Altitude", zh: "飞行高度" },
    droneBattery: { en: "Battery", zh: "电池余量" },
    finishSimulation: {
      en: "Complete Order & Return to Store",
      zh: "确认收货并返回商城"
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.address || !formData.zip) {
      setFormErrors(language === "en" ? "All verification fields are required!" : "请填写所有收货人核验字段！");
      return;
    }
    if (formData.zip.length < 5) {
      setFormErrors(language === "en" ? "Postal code must be valid!" : "请填写正确的邮政编码！");
      return;
    }

    setFormErrors(null);
    setOrderCompleted(true);
    // Trigger Context simulation state
    startDroneSimulation(formData.address);
  };

  const handleFinishSimulation = () => {
    stopDroneSimulation();
    setOrderCompleted(false);
    setIsCheckoutOpen(false);
    clearCart();
  };

  return (
    <AnimatePresence>
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm select-none font-sans overflow-y-auto">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden text-slate-800 text-left my-8"
          >
            {/* Header */}
            <div className="border-b border-slate-100 px-6 py-4 flex items-center justify-between bg-slate-50 shrink-0">
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <Truck className="w-5 h-5 text-[#e1251b]" />
                <span>{orderCompleted ? (language === "en" ? "Drone Logistics Live Stream" : "物流无人机轨迹实时调度中") : (language === "en" ? text.title.en : text.title.zh)}</span>
              </h3>
              {!orderCompleted && (
                <button
                  onClick={() => setIsCheckoutOpen(false)}
                  className="text-slate-400 hover:text-slate-800 p-1"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Container */}
            <div className="p-6 lg:p-8 overflow-y-auto">
              {!orderCompleted ? (
                /* Phase 1: Address Input Form & Summary Grid */
                <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
                  {/* Left 3 Columns: Address Form */}
                  <form onSubmit={handleSubmit} className="md:col-span-3 flex flex-col gap-5 text-left">
                    <p className="text-[11px] text-slate-400 leading-relaxed bg-slate-50 border border-slate-100 p-3 rounded-lg">
                      {language === "en" ? text.verificationSub.en : text.verificationSub.zh}
                    </p>

                    {formErrors && (
                      <div className="bg-red-50 text-red-600 text-xs py-2 px-3 rounded-lg border border-red-100 flex items-center gap-1.5">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>{formErrors}</span>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Name */}
                      <div className="flex flex-col gap-1.5">
                        <label className="text-[10px] font-bold text-slate-500 uppercase">{language === "en" ? "Full Name" : "收货人姓名"}</label>
                        <div className="relative">
                          <User className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                          <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-[#e1251b]"
                            placeholder="e.g. Tom ahX"
                          />
                        </div>
                      </div>

                      {/* Phone */}
                      <div className="flex flex-col gap-1.5">
                        <label className="text-[10px] font-bold text-slate-500 uppercase">{language === "en" ? "Phone Number" : "联系电话"}</label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                          <input
                            type="text"
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-[#e1251b]"
                            placeholder="e.g. +86 138-xxxx-xxxx"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Address */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">{language === "en" ? "Detailed GPS Delivery Address" : "详细收货地址 (自动对准无人机投递点)"}</label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                        <input
                          type="text"
                          name="address"
                          value={formData.address}
                          onChange={handleInputChange}
                          className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-[#e1251b]"
                          placeholder="Consignee Street details..."
                        />
                      </div>
                    </div>

                    {/* Zip Code */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">{language === "en" ? "Postal Code (Precise Location)" : "邮政编码 (对准低空GPS降落廊)"}</label>
                      <div className="relative">
                        <Landmark className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                        <input
                          type="text"
                          name="zip"
                          maxLength={6}
                          value={formData.zip}
                          onChange={handleInputChange}
                          className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-[#e1251b]"
                          placeholder="100020"
                        />
                      </div>
                    </div>

                    {/* Payment methods */}
                    <div className="flex flex-col gap-2.5 mt-2">
                      <span className="text-[10px] font-bold text-slate-500 uppercase text-left">
                        {language === "en" ? text.paymentTitle.en : text.paymentTitle.zh}
                      </span>
                      <div className="flex flex-col gap-2">
                        {/* COD */}
                        <label
                          onClick={() => setPaymentMethod("cod")}
                          className={`flex items-start gap-3 p-3 border rounded-lg cursor-pointer transition-all ${
                            paymentMethod === "cod"
                              ? "border-[#e1251b] bg-red-50/20"
                              : "border-slate-200 hover:border-slate-300"
                          }`}
                        >
                          <input
                            type="radio"
                            name="pay"
                            checked={paymentMethod === "cod"}
                            onChange={() => {}}
                            className="mt-0.5 text-[#e1251b] focus:ring-[#e1251b]"
                          />
                          <div className="text-left text-xs">
                            <span className="font-bold block text-slate-800">
                              {language === "en" ? "Cash on Delivery (COD)" : "货到付款 (安心免单)"}
                            </span>
                            <span className="text-[10px] text-slate-400 mt-0.5 block leading-normal">
                              {language === "en" ? "Verify cargo at drone box, pay securely using WeChat or Cash upon arrival." : "智能空投降落后直接进行开箱验货。支持当面刷卡、微信及现金付款。"}
                            </span>
                          </div>
                        </label>

                        {/* Card */}
                        <label
                          onClick={() => setPaymentMethod("card")}
                          className={`flex items-start gap-3 p-3 border rounded-lg cursor-pointer transition-all ${
                            paymentMethod === "card"
                              ? "border-[#e1251b] bg-red-50/20"
                              : "border-slate-200 hover:border-slate-300"
                          }`}
                        >
                          <input
                            type="radio"
                            name="pay"
                            checked={paymentMethod === "card"}
                            onChange={() => {}}
                            className="mt-0.5 text-[#e1251b] focus:ring-[#e1251b]"
                          />
                          <div className="text-left text-xs">
                            <span className="font-bold block text-slate-800">
                              {language === "en" ? "Quick Credit / Debit Cards" : "在线快捷支付"}
                            </span>
                            <span className="text-[10px] text-slate-400 mt-0.5 block leading-normal">
                              {language === "en" ? "Supports global UnionPay, Visa, Mastercard. Instantly save an extra ¥5." : "支持全球银联卡、Visa和万事达。实时在线快捷核销，立省 ¥5 现金。"}
                            </span>
                          </div>
                        </label>
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-[#e1251b] hover:bg-[#c31c13] text-white py-3.5 px-4 rounded-lg font-bold text-xs transition-all active:scale-95 shadow-md hover:shadow-lg mt-3 flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Truck className="w-4 h-4" />
                      <span>{language === "en" ? text.submitBtn.en : text.submitBtn.zh}</span>
                    </button>
                  </form>

                  {/* Right 2 Columns: Order summary list */}
                  <div className="md:col-span-2 border-l border-slate-100 pl-0 md:pl-6 text-left flex flex-col gap-4">
                    <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                      {language === "en" ? text.summaryTitle.en : text.summaryTitle.zh}
                    </h4>
                    <div className="flex flex-col gap-3 max-h-[220px] overflow-y-auto pr-2">
                      {cart.map((item) => (
                        <div key={item.product.id} className="flex items-center gap-3 text-xs">
                          <div className="relative w-10 h-10 rounded bg-slate-50 border border-slate-100 shrink-0">
                            <Image
                              src={item.product.image}
                              alt={item.product.nameEn}
                              fill
                              sizes="40px"
                              className="object-cover object-center"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h5 className="font-semibold text-slate-800 truncate leading-none">
                              {language === "en" ? item.product.nameEn : item.product.nameZh}
                            </h5>
                            <span className="text-[10px] text-slate-400 mt-1 block">
                              Qty: {item.quantity} · ¥{item.product.price.toLocaleString()}
                            </span>
                          </div>
                          <span className="font-mono font-bold text-slate-800 tabular-nums shrink-0">
                            ¥{(item.product.price * item.quantity).toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Consolidated Pricing List */}
                    <div className="border-t border-slate-100 pt-3 flex flex-col gap-2 text-xs text-slate-500 font-medium">
                      <div className="flex justify-between">
                        <span>Subtotal</span>
                        <span className="font-mono tabular-nums">¥{subtotal.toLocaleString()}</span>
                      </div>
                      {isPlusUser && (
                        <div className="flex justify-between text-amber-600 font-bold">
                          <span>PLUS 10% Saving</span>
                          <span className="font-mono tabular-nums">-¥{discount.toLocaleString()}</span>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span>Drone Delivery</span>
                        <span>{shippingFee === 0 ? "FREE" : `¥${shippingFee}`}</span>
                      </div>
                      <div className="flex justify-between border-t border-slate-100 pt-3 text-sm text-slate-900 font-black">
                        <span>Amount Payable</span>
                        <span className="text-[#e1251b] font-mono tabular-nums">¥{grandTotal.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                /* Phase 2: Live Flight Simulation Dashboard */
                <div className="flex flex-col gap-6 text-slate-200 bg-slate-950 rounded-xl p-6 border border-slate-800 font-mono">
                  {/* Dashboard Title */}
                  <div className="text-left flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="text-xs font-bold text-slate-400 flex items-center gap-2">
                      <span className="w-2.5 h-2.5 bg-red-500 rounded-full animate-ping"></span>
                      <span>{language === "en" ? text.flightTitle.en : text.flightTitle.zh}</span>
                    </div>
                    <span className="bg-[#e1251b]/10 text-[#e1251b] border border-red-900/30 text-[9px] px-2 py-0.5 rounded font-black uppercase">
                      ACTIVE LINK TERMINAL
                    </span>
                  </div>

                  {/* Progressive Horizontal Tracking Bar */}
                  <div className="grid grid-cols-5 gap-2 relative mt-4">
                    {/* Line */}
                    <div className="absolute top-4 left-4 right-4 h-0.5 bg-slate-800 z-0"></div>
                    <div
                      className="absolute top-4 left-4 h-0.5 bg-[#e1251b] z-0 transition-all duration-1000"
                      style={{ width: `${droneSimulation.step * 25}%` }}
                    ></div>

                    {[0, 1, 2, 3, 4].map((step) => (
                      <div key={step} className="flex flex-col items-center text-center z-10">
                        <div
                          className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                            droneSimulation.step >= step
                              ? "bg-[#e1251b] text-white ring-4 ring-red-950"
                              : "bg-slate-900 text-slate-500 border border-slate-800"
                          }`}
                        >
                          {step + 1}
                        </div>
                        <span className="text-[8px] lg:text-[9px] mt-2 text-slate-400 font-bold uppercase leading-none hidden sm:block">
                          {step === 0 && (language === "en" ? "Verify" : "确认")}
                          {step === 1 && (language === "en" ? "Corridor" : "航路计算")}
                          {step === 2 && (language === "en" ? "Flying" : "空中巡航")}
                          {step === 3 && (language === "en" ? "Descend" : "局部避障")}
                          {step === 4 && (language === "en" ? "Arrived" : "成功妥投")}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Telemetry Output Log */}
                  <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 text-left min-h-[90px] flex flex-col justify-center gap-3">
                    <div className="text-[10px] text-[#e1251b] font-bold uppercase flex items-center gap-1.5">
                      <Compass className="w-4 h-4 animate-spin text-red-500 shrink-0" />
                      <span>GPS Active Status Log:</span>
                    </div>
                    <p className="text-xs lg:text-sm font-bold text-white leading-normal">
                      {text.flightStatus[droneSimulation.step][language]}
                    </p>
                  </div>

                  {/* Live telemetry boards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-900/40 border border-slate-800/60 rounded-lg p-4 text-left">
                    <div className="border-r border-slate-800/60 pr-2">
                      <div className="text-[9px] text-slate-500 uppercase">Distance Remaining</div>
                      <div className="text-lg font-bold text-white font-mono mt-0.5">
                        {droneSimulation.distanceLeft} <span className="text-[11px] text-slate-400">km</span>
                      </div>
                    </div>
                    <div className="border-r border-slate-800/60 px-2">
                      <div className="text-[9px] text-slate-500 uppercase">{language === "en" ? text.droneSpeed.en : text.droneSpeed.zh}</div>
                      <div className="text-lg font-bold text-white font-mono mt-0.5">
                        {droneSimulation.step === 0 ? 0 : droneSimulation.step === 4 ? 0 : droneSimulation.step === 3 ? 15 : 75} <span className="text-[11px] text-slate-400">km/h</span>
                      </div>
                    </div>
                    <div className="border-r border-slate-800/60 px-2">
                      <div className="text-[9px] text-slate-500 uppercase">{language === "en" ? text.droneAlt.en : text.droneAlt.zh}</div>
                      <div className="text-lg font-bold text-white font-mono mt-0.5">
                        {droneSimulation.step === 0 ? 0 : droneSimulation.step === 4 ? 0 : droneSimulation.step === 3 ? 12 : 115} <span className="text-[11px] text-slate-400">meters</span>
                      </div>
                    </div>
                    <div className="px-2">
                      <div className="text-[9px] text-slate-500 uppercase flex items-center gap-1">
                        <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
                        <span>{language === "en" ? text.droneBattery.en : text.droneBattery.zh}</span>
                      </div>
                      <div className="text-lg font-bold text-emerald-400 font-mono mt-0.5">
                        {Math.max(15, 100 - droneSimulation.step * 21)}%
                      </div>
                    </div>
                  </div>

                  {/* Action complete button */}
                  {droneSimulation.step === 4 && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="border-t border-slate-800 pt-4 mt-2 flex flex-col sm:flex-row items-center justify-between gap-4"
                    >
                      <div className="text-left text-[10px] text-slate-500 max-w-md leading-normal">
                        Your secure verification receipt has been logged. Delivery matches GPS coordinates. Thanks for choosing JD Smart Logistics.
                      </div>
                      <button
                        onClick={handleFinishSimulation}
                        className="bg-[#e1251b] hover:bg-[#c31c13] text-white text-xs font-bold py-3 px-6 rounded-lg transition-all active:scale-95 shadow-md flex items-center gap-1.5 cursor-pointer"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>{language === "en" ? text.finishSimulation.en : text.finishSimulation.zh}</span>
                      </button>
                    </motion.div>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
