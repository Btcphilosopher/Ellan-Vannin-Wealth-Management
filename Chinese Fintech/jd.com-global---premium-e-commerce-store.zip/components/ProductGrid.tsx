'use client';

import React, { useState } from "react";
import { useStore } from "@/context/StoreContext";
import { Product, PRODUCTS } from "@/lib/products";
import { ShoppingCart, Eye, SearchSlash } from "lucide-react";
import ProductDetailModal from "./ProductDetailModal";
import { motion, AnimatePresence } from "motion/react";
import Image from "next/image";

export default function ProductGrid() {
  const { language, selectedCategory, setSelectedCategory, searchQuery, addToCart } = useStore();
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Filter products based on search bar text AND selected sidebar category
  const filteredProducts = PRODUCTS.filter((product) => {
    // 1. Filter by category
    const matchesCategory =
      selectedCategory === "All" ||
      selectedCategory === "Global" || // Show everything for global
      product.categoryEn === selectedCategory;

    // 2. Filter by search query
    const searchLower = searchQuery.toLowerCase();
    const matchesSearch =
      searchLower === "" ||
      product.nameEn.toLowerCase().includes(searchLower) ||
      product.nameZh.toLowerCase().includes(searchLower) ||
      product.descriptionEn.toLowerCase().includes(searchLower) ||
      product.descriptionZh.toLowerCase().includes(searchLower) ||
      product.categoryEn.toLowerCase().includes(searchLower) ||
      product.categoryZh.toLowerCase().includes(searchLower);

    return matchesCategory && matchesSearch;
  });

  const text = {
    sectionTitle: {
      en: "Today's Featured Recommendations",
      zh: "今日推荐"
    },
    sectionSub: {
      en: "Hand-picked Quality Imports & Smart Living Tech",
      zh: "精选好物 品质生活"
    },
    buyBtn: {
      en: "Quick Buy",
      zh: "立即购买"
    },
    viewBtn: {
      en: "Quick View",
      zh: "商品详情"
    },
    noResults: {
      en: "No items match your search. Try adjusting filters or searching other products!",
      zh: "没有找到符合条件的商品。请尝试修改搜索词或选择其他商品分类！"
    },
    clearFilters: {
      en: "Reset Category Filters",
      zh: "重置商品分类"
    },
    filterAll: {
      en: "All",
      zh: "全部"
    }
  };

  const categoriesShort = [
    { id: "All", en: "All", zh: "全部推荐" },
    { id: "3C Digital", en: "Digital", zh: "3C 数码" },
    { id: "Home Appliances", en: "Appliances", zh: "家用电器" },
    { id: "Home Furnishings", en: "Home & Furniture", zh: "家居家装" },
    { id: "Beauty & Cosmetics", en: "Beauty & Cosmetics", zh: "美妆个护" },
    { id: "Fresh Food", en: "Fresh Food", zh: "食品生鲜" },
  ];

  return (
    <div id="today-recommendations" className="w-full flex flex-col gap-6 font-sans select-none scroll-mt-24">
      {/* 1. Interactive Recommendation Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-200 pb-4">
        <div className="text-left">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-5 bg-[#e1251b] rounded-sm"></span>
            <h2 className="text-xl lg:text-2xl font-extrabold text-slate-900 tracking-tight">
              {language === "en" ? text.sectionTitle.en : text.sectionTitle.zh}
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 font-medium">
            {language === "en" ? text.sectionSub.en : text.sectionSub.zh}
          </p>
        </div>

        {/* Dynamic segmented categories filter for snappy localized selections */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg overflow-x-auto max-w-full scrollbar-none whitespace-nowrap self-start md:self-auto shrink-0 text-xs">
          {categoriesShort.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 font-semibold rounded-md transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? "bg-[#e1251b] text-white shadow-sm"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              {language === "en" ? cat.en : cat.zh}
            </button>
          ))}
        </div>
      </div>

      {/* 2. Grid Display of Product Cards */}
      <AnimatePresence mode="popLayout">
        {filteredProducts.length > 0 ? (
          <motion.div
            layout
            className="grid grid-cols-2 md:grid-cols-4 gap-6"
          >
            {filteredProducts.map((product) => (
              <motion.div
                key={product.id}
                layout
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.25 }}
                className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden flex flex-col group hover:-translate-y-1 hover:shadow-md hover:border-slate-200 transition-all duration-300 relative"
              >
                {/* Image Section - leading with 70% of card visual weight */}
                <div
                  onClick={() => setSelectedProduct(product)}
                  className="relative w-full aspect-square bg-[#f9f9f8] cursor-pointer overflow-hidden"
                >
                  <Image
                    src={product.image}
                    alt={product.nameEn}
                    fill
                    sizes="(max-width: 768px) 50vw, 25vw"
                    className="object-cover object-center transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />

                  {/* Stock tag */}
                  <span className="absolute top-2 left-2 bg-black/60 backdrop-blur-md text-[9px] text-white font-bold px-2 py-0.5 rounded uppercase">
                    {language === "en" ? `In Stock (${product.stock})` : `有货 (${product.stock})`}
                  </span>

                  {/* Quick-add hover overlays (hidden on mobile, reveals on desktop hover) */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedProduct(product);
                      }}
                      className="bg-white hover:bg-slate-100 text-slate-800 p-2.5 rounded-full shadow-md transition-all active:scale-90"
                      title={language === "en" ? text.viewBtn.en : text.viewBtn.zh}
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        addToCart(product, 1);
                      }}
                      className="bg-[#e1251b] hover:bg-[#c31c13] text-white p-2.5 rounded-full shadow-md transition-all active:scale-90"
                      title={language === "en" ? text.buyBtn.en : text.buyBtn.zh}
                    >
                      <ShoppingCart className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Info Segment */}
                <div className="p-4 flex-1 flex flex-col justify-between text-left gap-2 border-t border-slate-50">
                  <div className="cursor-pointer" onClick={() => setSelectedProduct(product)}>
                    {/* Brand or Category Kicker - Unboxed quiet metadata */}
                    <span className="text-[10px] font-bold tracking-wider text-[#e1251b]/85 uppercase">
                      {language === "en" ? product.categoryEn : product.categoryZh}
                    </span>

                    {/* Product Name */}
                    <h3 className="text-xs lg:text-sm font-semibold text-slate-800 mt-1 line-clamp-1 group-hover:text-[#e1251b] transition-colors">
                      {language === "en" ? product.nameEn : product.nameZh}
                    </h3>

                    {/* Short Description */}
                    <p className="text-[10px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {language === "en" ? product.descriptionEn : product.descriptionZh}
                    </p>
                  </div>

                  {/* Price Tag with monospace figures and Buy Trigger */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-50 mt-1 shrink-0">
                    <span className="text-sm lg:text-base font-black text-[#e1251b] font-mono tabular-nums leading-none">
                      ¥{product.price.toLocaleString()}
                    </span>

                    <button
                      onClick={() => addToCart(product, 1)}
                      className="text-xs font-bold text-[#e1251b] hover:text-[#c31c13] bg-red-50 hover:bg-red-100 py-1.5 px-3 rounded-full transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>{language === "en" ? "Add" : "加购"}</span>
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        ) : (
          /* Empty state */
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full bg-white border border-slate-100 rounded-xl py-16 px-4 flex flex-col items-center text-center justify-center gap-4"
          >
            <div className="w-16 h-16 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 border border-slate-100">
              <SearchSlash className="w-8 h-8" />
            </div>
            <div className="max-w-md">
              <h4 className="text-sm font-bold text-slate-800">
                {language === "en" ? "No Matching Products" : "未找到匹配商品"}
              </h4>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                {language === "en" ? text.noResults.en : text.noResults.zh}
              </p>
            </div>
            <button
              onClick={() => {
                setSelectedCategory("All");
                // Clear any search queries
                const searchInput = document.querySelector('input[type="text"]') as HTMLInputElement;
                if (searchInput) searchInput.value = "";
                // Hard reset
                window.location.reload();
              }}
              className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold py-2 px-5 rounded-md transition-all active:scale-95"
            >
              {language === "en" ? text.clearFilters.en : text.clearFilters.zh}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 3. Product Specification Pop-up Modal */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
}
