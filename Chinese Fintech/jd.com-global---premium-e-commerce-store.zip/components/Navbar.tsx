'use client';

import React, { useState } from "react";
import { useStore } from "@/context/StoreContext";
import { ShoppingCart, Search, Globe, User, LogOut, CheckCircle, Gift } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Navbar() {
  const {
    language,
    setLanguage,
    cart,
    searchQuery,
    setSearchQuery,
    isPlusUser,
    setIsPlusUser,
    setIsCartOpen,
  } = useStore();

  const [showPromo, setShowPromo] = useState(true);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const cartItemsCount = cart.reduce((total, item) => total + item.quantity, 0);

  // Localized text mappings
  const text = {
    promo: {
      en: "🎉 Autumn Festival: Free Autonomous Drone Delivery on orders above ¥499! PLUS members save 10% on all items.",
      zh: "🎉 京东金秋盛典：单笔订单满 ¥499 免智能无人机极速达运费！PLUS会员全场尊享额外 9 折优惠。"
    },
    slogan: {
      en: "Bespoke Delivery · Quality Life",
      zh: "多 · 快 · 好 · 省"
    },
    searchPlaceholder: {
      en: "Search products, brands, tech, beauty...",
      zh: "搜索 商品、品牌、智能数码、大牌美妆..."
    },
    searchButton: {
      en: "Search",
      zh: "搜索"
    },
    myJd: {
      en: "My Account",
      zh: "我的京东"
    },
    cart: {
      en: "Cart",
      zh: "购物车"
    },
    plusBadge: {
      en: "PLUS VIP",
      zh: "PLUS会员"
    },
    loginTitle: {
      en: "Welcome to JD Global",
      zh: "欢迎来到京东全球购"
    },
    loginSub: {
      en: "VIP member benefits are active!",
      zh: "金牌PLUS特权已生效！"
    },
    logout: {
      en: "Logout / Standard View",
      zh: "退出 / 恢复普通版"
    },
    becomePlus: {
      en: "Activate PLUS VIP",
      zh: "立即开通PLUS会员"
    }
  };

  return (
    <div className="w-full sticky top-0 z-40 bg-white shadow-sm">
      {/* 1. Dismissible Promo Strip - Max 40px */}
      <AnimatePresence>
        {showPromo && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-[#e1251b] text-white text-xs py-2 px-4 flex items-center justify-between font-medium leading-none shrink-0"
          >
            <div className="flex-1 text-center truncate">
              {language === "en" ? text.promo.en : text.promo.zh}
            </div>
            <button
              onClick={() => setShowPromo(false)}
              className="ml-2 text-white/80 hover:text-white transition-colors p-1"
              aria-label="Dismiss banner"
            >
              ✕
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. Main Navbar Row */}
      <div className="max-w-7xl mx-auto px-4 lg:px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Zone 1: Brand & Slogan */}
        <div className="flex items-center justify-between w-full md:w-auto">
          <div className="flex items-baseline gap-3">
            <a href="/" className="flex flex-col select-none">
              <span className="text-2xl lg:text-3xl font-extrabold tracking-tight text-[#e1251b]">
                JD.COM <span className="text-xl lg:text-2xl font-bold font-sans">京东</span>
              </span>
              <span className="text-[10px] tracking-[0.25em] text-[#e1251b] font-medium leading-none mt-0.5">
                {language === "en" ? text.slogan.en : text.slogan.zh}
              </span>
            </a>
            {isPlusUser && (
              <span className="bg-gradient-to-r from-amber-500 to-yellow-600 text-black text-[10px] font-bold px-2 py-0.5 rounded shadow-sm border border-amber-300 flex items-center gap-1 select-none whitespace-nowrap animate-pulse">
                <Gift className="w-3 h-3 text-black" />
                {language === "en" ? text.plusBadge.en : text.plusBadge.zh}
              </span>
            )}
          </div>

          {/* Small Viewport Menu Actions */}
          <div className="flex items-center gap-3 md:hidden">
            <button
              onClick={() => setLanguage(language === "en" ? "zh" : "en")}
              className="p-2 text-slate-600 hover:text-[#e1251b] transition-colors flex items-center gap-1"
              aria-label="Toggle language"
            >
              <Globe className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIsCartOpen(true)}
              className="p-2 text-slate-600 hover:text-[#e1251b] transition-colors relative"
              aria-label="View cart"
            >
              <ShoppingCart className="w-6 h-6" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#e1251b] text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center font-mono animate-bounce">
                  {cartItemsCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Zone 2: Search Input & Brand Keywords */}
        <div className="w-full md:max-w-2xl flex-1">
          <form
            onSubmit={(e) => e.preventDefault()}
            className="flex w-full rounded-md shadow-sm border-2 border-[#e1251b] overflow-hidden bg-white"
          >
            <div className="flex-1 flex items-center px-3 text-slate-400">
              <Search className="w-5 h-5 shrink-0 mr-2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={language === "en" ? text.searchPlaceholder.en : text.searchPlaceholder.zh}
                className="w-full py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:outline-none border-0"
              />
            </div>
            <button
              type="submit"
              className="bg-[#e1251b] hover:bg-[#c31c13] text-white text-sm font-semibold px-6 py-2.5 transition-all flex items-center justify-center gap-1 whitespace-nowrap active:scale-95"
            >
              {language === "en" ? text.searchButton.en : text.searchButton.zh}
            </button>
          </form>

          {/* Quick links to seed searching */}
          <div className="flex items-center gap-3 mt-1.5 px-1 overflow-x-auto scrollbar-none whitespace-nowrap text-[11px] text-slate-500">
            <button onClick={() => setSearchQuery("MacBook")} className="hover:text-[#e1251b] transition-colors">MacBook Air M4</button>
            <span>·</span>
            <button onClick={() => setSearchQuery("iPhone")} className="hover:text-[#e1251b] transition-colors">iPhone 17 Pro</button>
            <span>·</span>
            <button onClick={() => setSearchQuery("Roborock")} className="hover:text-[#e1251b] transition-colors">Roborock扫地机</button>
            <span>·</span>
            <button onClick={() => setSearchQuery("SK-II")} className="hover:text-[#e1251b] transition-colors">SK-II神仙水</button>
            <span>·</span>
            <button onClick={() => setSearchQuery("Sofa")} className="hover:text-[#e1251b] transition-colors">北欧极简沙发</button>
          </div>
        </div>

        {/* Zone 3: Desktop Global Controls & Shopping Cart */}
        <div className="hidden md:flex items-center gap-6 shrink-0 font-medium text-sm text-slate-700">
          {/* Language Switcher */}
          <button
            onClick={() => setLanguage(language === "en" ? "zh" : "en")}
            className="flex items-center gap-1.5 py-1 px-2.5 hover:text-[#e1251b] hover:bg-slate-50 rounded-md transition-all whitespace-nowrap text-xs font-semibold"
            title="Toggle Language / 切换语言"
          >
            <Globe className="w-4 h-4 text-slate-500 shrink-0" />
            <span>{language === "en" ? "简体中文" : "English"}</span>
          </button>

          {/* Interactive User Area */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-1.5 py-1 px-2.5 hover:text-[#e1251b] hover:bg-slate-50 rounded-md transition-all text-xs font-semibold"
            >
              <User className="w-4 h-4 text-slate-500" />
              <span>{language === "en" ? text.myJd.en : text.myJd.zh}</span>
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-slate-100 py-4 px-4 z-50 text-slate-700">
                <div className="flex items-center gap-3 border-b border-slate-100 pb-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center border border-slate-200">
                    <User className="w-5 h-5 text-slate-500" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-sm flex items-center gap-1">
                      <span>Tom ahX</span>
                      {isPlusUser && (
                        <span className="bg-gradient-to-r from-amber-500 to-yellow-600 text-black text-[9px] font-black px-1 rounded">PLUS</span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400">tom@ahyx.org</div>
                  </div>
                </div>

                {isPlusUser ? (
                  <div className="bg-amber-50/50 border border-amber-200/60 rounded-md p-2.5 text-xs text-amber-800 text-left mb-3">
                    <div className="font-bold flex items-center gap-1 mb-0.5">
                      <CheckCircle className="w-3.5 h-3.5 text-amber-600" />
                      {language === "en" ? text.loginTitle.en : text.loginTitle.zh}
                    </div>
                    <div>{language === "en" ? text.loginSub.en : text.loginSub.zh}</div>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      setIsPlusUser(true);
                      setShowUserMenu(false);
                    }}
                    className="w-full bg-gradient-to-r from-slate-900 to-slate-800 hover:from-slate-800 hover:to-slate-700 text-amber-300 text-xs font-bold py-2 px-3 rounded-md transition-all text-center flex items-center justify-center gap-1 mb-3 shadow-md"
                  >
                    <Gift className="w-3.5 h-3.5" />
                    {language === "en" ? text.becomePlus.en : text.becomePlus.zh}
                  </button>
                )}

                {isPlusUser && (
                  <button
                    onClick={() => {
                      setIsPlusUser(false);
                      setShowUserMenu(false);
                    }}
                    className="w-full flex items-center justify-center gap-1 text-slate-400 hover:text-[#e1251b] transition-colors text-xs py-1.5 border-t border-slate-100 mt-2"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>{language === "en" ? text.logout.en : text.logout.zh}</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Desktop Shopping Cart Trigger */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="flex items-center gap-2 bg-[#fcf2f2] hover:bg-[#f9e5e5] text-[#e1251b] border border-red-100 py-1.5 px-4 rounded-full transition-all group active:scale-95 text-xs font-bold"
          >
            <ShoppingCart className="w-4 h-4 group-hover:scale-110 transition-transform" />
            <span>{language === "en" ? text.cart.en : text.cart.zh}</span>
            <span className="bg-[#e1251b] text-white text-[10px] font-mono font-bold rounded-full min-w-5 h-5 px-1.5 flex items-center justify-center">
              {cartItemsCount}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
