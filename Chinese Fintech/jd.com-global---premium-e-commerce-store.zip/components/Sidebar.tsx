'use client';

import React from "react";
import { useStore } from "@/context/StoreContext";
import {
  Smartphone,
  Tv,
  Monitor,
  Home,
  Sparkles,
  Baby,
  Utensils,
  Dribbble,
  Car,
  BookOpen,
  Heart,
  Globe2,
  Grid
} from "lucide-react";

export default function Sidebar() {
  const { language, selectedCategory, setSelectedCategory } = useStore();

  const categories = [
    { id: "All", en: "All Products", zh: "全部商品分类", icon: Grid },
    { id: "3C Digital", en: "Phone & Digital", zh: "手机 / 数码 / 智能设备", icon: Smartphone },
    { id: "Home Appliances", en: "Home Appliances", zh: "家用电器", icon: Tv },
    { id: "Computer", en: "Computer & Office", zh: "电脑 / 办公", icon: Monitor },
    { id: "Home Furnishings", en: "Home & Furniture", zh: "家居 / 家装 / 家纺", icon: Home },
    { id: "Beauty & Cosmetics", en: "Beauty & Personal Care", zh: "美妆 / 个护 / 个人护理", icon: Sparkles },
    { id: "Maternal & Infant", en: "Baby & Toys", zh: "母婴 / 玩具 / 童装", icon: Baby },
    { id: "Fresh Food", en: "Food & Fresh", zh: "食品 / 生鲜 / 酒水", icon: Utensils },
    { id: "Sports & Outdoors", en: "Sports & Outdoors", zh: "运动 / 户外 / 旅行", icon: Dribbble },
    { id: "Automotive", en: "Automotive Parts", zh: "汽车 / 用品 / 维修", icon: Car },
    { id: "Books", en: "Books & Media", zh: "图书 / 音乐 / 影视", icon: BookOpen },
    { id: "Pets", en: "Pets & Supplies", zh: "宠物 / 宠物用品", icon: Heart },
    { id: "Global", en: "Global Buy", zh: "全球购 / 海外直邮", icon: Globe2 },
  ];

  const handleCategoryClick = (catId: string) => {
    setSelectedCategory(catId);
    // Smooth scroll to product grid
    const el = document.getElementById("today-recommendations");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="w-full lg:w-64 bg-[#1e2330] text-slate-300 rounded-lg shadow-md overflow-hidden shrink-0 flex flex-col font-sans select-none border border-slate-800">
      <div className="bg-[#151922] px-4 py-3 border-b border-slate-800">
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#e1251b] flex items-center gap-2">
          <span className="w-1.5 h-3 bg-[#e1251b] rounded-sm"></span>
          {language === "en" ? "Product Categories" : "全部商品分类"}
        </h3>
      </div>
      <nav className="flex flex-row lg:flex-col overflow-x-auto lg:overflow-x-visible py-2 divide-x lg:divide-x-0 lg:divide-y divide-slate-800 scrollbar-none">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = selectedCategory === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => handleCategoryClick(cat.id)}
              className={`w-full text-left px-4 py-3 flex items-center gap-3 transition-all text-xs font-medium whitespace-nowrap lg:whitespace-normal shrink-0 ${
                isActive
                  ? "bg-[#e1251b] text-white font-bold"
                  : "hover:bg-[#252b3b] hover:text-white"
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-white" : "text-slate-400"}`} />
              <span className="truncate">{language === "en" ? cat.en : cat.zh}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
