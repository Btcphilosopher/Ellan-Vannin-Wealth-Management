'use client';

import React, { useState } from "react";
import { Product } from "@/lib/products";
import { useStore } from "@/context/StoreContext";
import { ShieldCheck, ArrowLeft, ShoppingCart, Minus, Plus, Truck, HelpCircle } from "lucide-react";
import { motion } from "motion/react";
import Image from "next/image";

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
}

export default function ProductDetailModal({ product, onClose }: ProductDetailModalProps) {
  const { language, addToCart } = useStore();
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<"desc" | "specs">("desc");

  const increment = () => {
    if (quantity < product.stock) {
      setQuantity(quantity + 1);
    }
  };

  const decrement = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
    onClose();
  };

  const text = {
    back: {
      en: "Back to Catalog",
      zh: "返回商品列表"
    },
    specsTab: {
      en: "Technical Specifications",
      zh: "规格参数"
    },
    descTab: {
      en: "Product Details",
      zh: "商品介绍"
    },
    variant: {
      en: "Select Variant",
      zh: "选择规格"
    },
    standard: {
      en: "Official Standard Edition",
      zh: "官方标配"
    },
    quantityLabel: {
      en: "Quantity",
      zh: "购买数量"
    },
    addCartBtn: {
      en: "Add to Cart",
      zh: "加入购物车"
    },
    stockWarning: {
      en: "In stock, ready for same-day delivery",
      zh: "极速闪电发货 · 现货速达"
    },
    shippingTip: {
      en: "Delivered by JD Express Drone Fleet within 2 hours.",
      zh: "支持京东自营无人机极速航线，下单后2小时送达。"
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm select-none font-sans overflow-y-auto">
      <motion.div
        initial={{ scale: 0.96, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden text-slate-800 text-left my-8"
      >
        {/* Back Link Header */}
        <div className="border-b border-slate-100 px-6 py-4 flex items-center justify-between bg-slate-50">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-[#e1251b] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{language === "en" ? text.back.en : text.back.zh}</span>
          </button>
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
            ID: {product.id.toUpperCase()}
          </span>
        </div>

        {/* Core Layout Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-6 lg:p-8">
          {/* Left Column: Fixed aspect-ratio image display on soft gray pedestal */}
          <div className="flex flex-col gap-4">
            <div className="relative w-full aspect-square bg-[#f9f9f8] rounded-xl overflow-hidden border border-slate-100">
              <Image
                src={product.image}
                alt={product.nameEn}
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover object-center"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Guarantee badge row */}
            <div className="bg-slate-50 rounded-lg p-3 flex items-center gap-3 text-[10px] text-slate-500 font-medium">
              <ShieldCheck className="w-4 h-4 text-[#e1251b] shrink-0" />
              <span>{language === "en" ? "Official Authentic · 10x Refund Guarantee" : "京东自营正品保障 · 假一赔十"}</span>
            </div>
          </div>

          {/* Right Column: Contiguous Purchase Module (PDP Container) */}
          <div className="flex flex-col justify-between gap-6">
            {/* Basic Info block */}
            <div className="text-left flex flex-col gap-2">
              <span className="text-[10px] font-bold tracking-widest text-[#e1251b] uppercase">
                {language === "en" ? product.categoryEn : product.categoryZh}
              </span>
              <h2 className="text-lg lg:text-xl font-bold text-slate-900 leading-snug">
                {language === "en" ? product.nameEn : product.nameZh}
              </h2>

              {/* Monospace Price Block */}
              <div className="bg-red-50/50 border border-red-100/50 rounded-lg p-3.5 mt-2 flex items-baseline gap-2">
                <span className="text-xs text-[#e1251b] font-bold">¥</span>
                <span className="text-2xl font-black text-[#e1251b] font-mono tabular-nums leading-none">
                  {product.price.toLocaleString()}
                </span>
                <span className="text-[10px] text-slate-400 font-medium ml-1">
                  {language === "en" ? "Inclusive of tax & clearing" : "已含跨境税费"}
                </span>
              </div>
            </div>

            {/* Segment Tab Selectors (Description vs Specs) */}
            <div className="flex border-b border-slate-200 text-xs font-semibold">
              <button
                onClick={() => setActiveTab("desc")}
                className={`pb-2.5 px-1 mr-6 transition-all border-b-2 cursor-pointer ${
                  activeTab === "desc"
                    ? "border-[#e1251b] text-slate-900 font-bold"
                    : "border-transparent text-slate-400 hover:text-slate-600"
                }`}
              >
                {language === "en" ? text.descTab.en : text.descTab.zh}
              </button>
              <button
                onClick={() => setActiveTab("specs")}
                className={`pb-2.5 px-1 transition-all border-b-2 cursor-pointer ${
                  activeTab === "specs"
                    ? "border-[#e1251b] text-slate-900 font-bold"
                    : "border-transparent text-slate-400 hover:text-slate-600"
                }`}
              >
                {language === "en" ? text.specsTab.en : text.specsTab.zh}
              </button>
            </div>

            {/* Tab Contents Frame */}
            <div className="min-h-[110px] text-xs text-slate-600 leading-relaxed text-left">
              {activeTab === "desc" ? (
                <p>{language === "en" ? product.descriptionEn : product.descriptionZh}</p>
              ) : (
                /* Specifications Matrix Table */
                <table className="w-full border-collapse">
                  <tbody>
                    {Object.entries(language === "en" ? product.specs : product.specsZh).map(([key, val]) => (
                      <tr key={key} className="border-b border-slate-100">
                        <td className="py-2 pr-4 font-bold text-slate-700 w-1/3 truncate">{key}</td>
                        <td className="py-2 text-slate-500">{val}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            {/* Variant selections & Actions block */}
            <div className="flex flex-col gap-4 border-t border-slate-100 pt-4 mt-2">
              {/* Variant Selector */}
              <div className="text-left">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                  {language === "en" ? text.variant.en : text.variant.zh}
                </span>
                <span className="inline-block bg-slate-100 text-slate-800 text-xs font-semibold py-2 px-4 rounded-md border border-slate-200">
                  {language === "en" ? text.standard.en : text.standard.zh}
                </span>
              </div>

              {/* Quantity Stepper & Buy Action */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mt-2">
                <div className="flex items-center border border-slate-300 rounded-md overflow-hidden bg-slate-50 shrink-0 h-11">
                  <button
                    onClick={decrement}
                    disabled={quantity <= 1}
                    className="p-3 text-slate-500 hover:bg-slate-200 transition-colors disabled:opacity-30 disabled:hover:bg-transparent h-full flex items-center justify-center"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-12 text-center text-xs font-bold font-mono">
                    {quantity}
                  </span>
                  <button
                    onClick={increment}
                    disabled={quantity >= product.stock}
                    className="p-3 text-slate-500 hover:bg-slate-200 transition-colors disabled:opacity-30 disabled:hover:bg-transparent h-full flex items-center justify-center"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={handleAddToCart}
                  className="bg-[#e1251b] hover:bg-[#c31c13] text-white text-xs lg:text-sm font-bold py-3 px-6 rounded-md transition-all flex items-center justify-center gap-2 flex-1 active:scale-95 shadow-md hover:shadow-lg h-11 cursor-pointer"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>{language === "en" ? text.addCartBtn.en : text.addCartBtn.zh}</span>
                </button>
              </div>

              {/* Fast shipping disclaimer segment */}
              <div className="mt-2 text-left text-[10px] text-slate-400 flex flex-col gap-1 leading-normal">
                <span className="text-slate-500 font-bold flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-emerald-500" />
                  {language === "en" ? text.stockWarning.en : text.stockWarning.zh}
                </span>
                <span>{language === "en" ? text.shippingTip.en : text.shippingTip.zh}</span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
