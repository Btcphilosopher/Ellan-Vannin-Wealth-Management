/**
 * SG Banking Systems - Domain Types & Interfaces
 * Universal French Banking Platform
 */

export type Locale = 'fr-FR' | 'en-GB';

export type UserRole = 
  | 'CUSTOMER'
  | 'RELATIONSHIP_MANAGER'
  | 'OPERATIONS'
  | 'TREASURY'
  | 'RISK'
  | 'COMPLIANCE'
  | 'AUDITOR'
  | 'ADMINISTRATOR';

export interface BankUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  preferredLocale: Locale;
  personaTitle: {
    'fr-FR': string;
    'en-GB': string;
  };
  customerId?: string;
  organizationId?: string;
}

export type AccountType = 
  | 'CURRENT' 
  | 'SAVINGS' 
  | 'TERM_DEPOSIT' 
  | 'MULTI_CURRENCY' 
  | 'BUSINESS' 
  | 'INVESTMENT';

export type Currency = 'EUR' | 'USD' | 'GBP' | 'CHF' | 'JPY' | 'CNY' | 'CAD' | 'AUD' | 'SEK' | 'NOK' | 'DKK';

export interface Account {
  id: string;
  accountNumber: string;
  iban: string;
  bic: string;
  name: string;
  type: AccountType;
  currency: Currency;
  customerId: string;
  status: 'ACTIVE' | 'BLOCKED' | 'DORMANT' | 'CLOSED';
  interestRate: number; // e.g., 0.03 for 3.00%
  ledgerBalance: string; // Exact Decimal string
  availableBalance: string; // Exact Decimal string
  pendingBalance: string; // Exact Decimal string
  openedAt: string;
  overdraftLimit: string;
}

export interface LedgerEntry {
  id: string;
  transactionId: string;
  accountId: string;
  entryType: 'DEBIT' | 'CREDIT';
  amount: string; // Decimal representation
  currency: Currency;
  bookingDate: string;
  valueDate: string;
  narrative: string;
  balanceAfter: string;
}

export type TransactionStatus = 'PENDING' | 'POSTED' | 'REVERSED' | 'FAILED' | 'SETTLED';
export type TransactionCategory = 
  | 'TRANSFER' 
  | 'CARD_PAYMENT' 
  | 'SALARY' 
  | 'UTILITIES' 
  | 'MORTGAGE' 
  | 'INVESTMENT' 
  | 'FEE' 
  | 'INTEREST' 
  | 'FX_TRADE'
  | 'TREASURY';

export interface Transaction {
  id: string;
  reference: string;
  sourceAccountId: string;
  destinationAccountId?: string;
  counterpartyName: string;
  counterpartyIban?: string;
  counterpartyBic?: string;
  amount: string;
  currency: Currency;
  exchangeRate?: string;
  fee: string;
  status: TransactionStatus;
  category: TransactionCategory;
  narrative: string;
  bookingDate: string;
  valueDate: string;
  createdAt: string;
  auditTrailId: string;
}

export type PaymentType = 
  | 'INTERNAL' 
  | 'SEPA_CREDIT' 
  | 'SEPA_INSTANT' 
  | 'SWIFT_INTERNATIONAL' 
  | 'DIRECT_DEBIT' 
  | 'STANDING_ORDER';

export type PaymentStatus = 
  | 'DRAFT' 
  | 'PENDING_APPROVAL' 
  | 'AUTHORISED' 
  | 'PROCESSING' 
  | 'SETTLED' 
  | 'FAILED' 
  | 'REJECTED' 
  | 'CANCELLED' 
  | 'REVERSED';

export interface PaymentInstruction {
  id: string;
  reference: string;
  sourceAccountId: string;
  destinationIban: string;
  destinationBic: string;
  beneficiaryName: string;
  amount: string;
  currency: Currency;
  type: PaymentType;
  status: PaymentStatus;
  urgency: 'NORMAL' | 'INSTANT' | 'URGENT';
  purposeCode: string;
  remittanceInformation: string;
  complianceChecked: boolean;
  complianceScore: number;
  scheduledDate?: string;
  settlementDate?: string;
  createdAt: string;
  authorizedBy?: string;
  rejectionReason?: string;
}

export interface Beneficiary {
  id: string;
  name: string;
  iban: string;
  bic: string;
  bankName: string;
  country: string;
  currency: Currency;
  isTrusted: boolean;
  category: string;
}

export interface Card {
  id: string;
  accountId: string;
  cardNumberMasked: string;
  cardHolder: string;
  cardType: 'DEBIT' | 'CREDIT' | 'VIRTUAL' | 'CORPORATE';
  cardBrand: 'VISA_INFINITE' | 'VISA_PREMIER' | 'VISA_CLASSIC' | 'MASTERCARD_WORLD_ELITE';
  expiryDate: string;
  status: 'ACTIVE' | 'FROZEN' | 'BLOCKED' | 'EXPIRED';
  monthlySpendLimit: string;
  currentSpend: string;
  contactlessEnabled: boolean;
  onlinePaymentsEnabled: boolean;
  foreignPaymentsEnabled: boolean;
  atmWithdrawalEnabled: boolean;
  pinSet: boolean;
}

export interface LoanScheduleItem {
  installmentNumber: number;
  dueDate: string;
  monthlyPayment: string;
  principalAmount: string;
  interestAmount: string;
  insuranceAmount: string;
  remainingPrincipal: string;
  isPaid: boolean;
}

export interface Loan {
  id: string;
  contractNumber: string;
  customerId: string;
  loanType: 'MORTGAGE' | 'CONSUMER' | 'CORPORATE' | 'REVOLVING';
  rateType: 'FIXED' | 'VARIABLE';
  initialPrincipal: string;
  outstandingPrincipal: string;
  annualInterestRate: number; // e.g. 0.032 for 3.2%
  termMonths: number;
  startDate: string;
  maturityDate: string;
  monthlyPayment: string;
  insuranceRate: number;
  propertyValue?: string; // For mortgages
  ltvRatio?: number; // Loan to value
  nextPaymentDate: string;
  status: 'ACTIVE' | 'SETTLED' | 'DELINQUENT';
  schedule: LoanScheduleItem[];
}

export interface FXRate {
  pair: string; // e.g. 'EUR/USD'
  baseCurrency: Currency;
  quoteCurrency: Currency;
  bid: number;
  ask: number;
  mid: number;
  change24h: number;
  lastUpdated: string;
  source: string;
}

export interface Security {
  isin: string;
  ticker: string;
  name: string;
  assetClass: 'EQUITY' | 'BOND' | 'ETF' | 'FUND' | 'STRUCTURED';
  currency: Currency;
  lastPrice: number;
  change24h: number;
  sector: string;
  country: string;
  coupon?: number; // For bonds
  maturity?: string; // For bonds
}

export interface Position {
  id: string;
  portfolioId: string;
  security: Security;
  quantity: number;
  averageCostBasis: number;
  currentPrice: number;
  marketValue: number;
  unrealizedPnL: number;
  unrealizedPnLPercent: number;
  weightPercent: number;
}

export interface Portfolio {
  id: string;
  customerId: string;
  name: string;
  currency: Currency;
  totalMarketValue: number;
  totalCostBasis: number;
  unrealizedPnL: number;
  unrealizedPnLPercent: number;
  cashBalance: number;
  assetAllocation: {
    equities: number;
    bonds: number;
    etfs: number;
    cash: number;
    structured: number;
  };
  positions: Position[];
}

export interface BondAnalytics {
  isin: string;
  name: string;
  couponRate: number;
  yearsToMaturity: number;
  parValue: number;
  marketPrice: number;
  yieldToMaturity: number;
  cleanPrice: number;
  dirtyPrice: number;
  accruedInterest: number;
  modifiedDuration: number;
  macaulayDuration: number;
  convexity: number;
}

export interface YieldCurvePoint {
  tenor: string;
  years: number;
  yield: number;
  changeBps: number;
}

export interface TreasuryPosition {
  id: string;
  entityName: string;
  currency: Currency;
  availableCash: string;
  inflowDay: string;
  outflowDay: string;
  netPosition: string;
  creditFacilityLimit: string;
  creditFacilityDrawn: string;
  forecast30d: string;
}

export interface RiskLimit {
  id: string;
  category: 'CREDIT' | 'MARKET_FX' | 'LIQUIDITY' | 'COUNTERPARTY';
  counterpartyName: string;
  limitAmount: number;
  currentExposure: number;
  utilizationPercent: number;
  status: 'NORMAL' | 'WARNING' | 'BREACHED';
  currency: Currency;
  lastReviewDate: string;
}

export interface AMLAlert {
  id: string;
  transactionId?: string;
  customerId: string;
  customerName: string;
  ruleTriggered: string;
  ruleDescription: {
    'fr-FR': string;
    'en-GB': string;
  };
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'NEW' | 'INVESTIGATING' | 'ESCALATED' | 'DISMISSED' | 'REPORTED_TRACFIN';
  amount: string;
  currency: Currency;
  riskScore: number;
  createdAt: string;
  assignedAnalyst?: string;
  notes?: string;
}

export type KYCStatus = 'NOT_STARTED' | 'DOCUMENTS_REQUIRED' | 'UNDER_REVIEW' | 'VERIFIED' | 'REJECTED' | 'EXPIRED';

export interface KYCProfile {
  id: string;
  customerId: string;
  customerName: string;
  type: 'INDIVIDUAL' | 'CORPORATE';
  status: KYCStatus;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  nationality: string;
  taxResidency: string;
  documentsSubmitted: {
    idCard: boolean;
    proofOfAddress: boolean;
    taxNotice: boolean;
    incorporationCertificate?: boolean;
    beneficialOwnersList?: boolean;
  };
  reviewDate: string;
  nextRenewalDate: string;
}

export interface ReconciliationItem {
  id: string;
  ledgerTransactionId: string;
  processorReference: string;
  settlementBatchId: string;
  amountLedger: string;
  amountSettled: string;
  currency: Currency;
  bookingDate: string;
  status: 'MATCHED' | 'UNMATCHED' | 'EXCEPTION' | 'RESOLVED';
  variance: string;
  comments?: string;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  entityType: string;
  entityId: string;
  previousState?: string;
  newState?: string;
  reason: string;
  correlationId: string;
  ipAddress: string;
  status: 'SUCCESS' | 'FAILURE' | 'BLOCKED';
}

export interface BankNotification {
  id: string;
  title: {
    'fr-FR': string;
    'en-GB': string;
  };
  message: {
    'fr-FR': string;
    'en-GB': string;
  };
  type: 'PAYMENT' | 'SECURITY' | 'COMPLIANCE' | 'MARKET' | 'SYSTEM';
  timestamp: string;
  read: boolean;
  actionUrl?: string;
}
