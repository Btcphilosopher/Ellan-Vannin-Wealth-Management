/**
 * SG Banking Systems - Bilingual Localization Context & Hooks
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { dictionary, TranslationKey } from './dictionary';
import { Locale, Currency } from '../types/domain';

interface TranslationContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: TranslationKey, fallback?: string) => string;
  formatCurrency: (amount: number | string, currency?: Currency) => string;
  formatNumber: (value: number | string, decimals?: number) => string;
  formatDate: (dateStr: string, options?: Intl.DateTimeFormatOptions) => string;
  formatPercentage: (ratio: number, decimals?: number) => string;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export const TranslationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [locale, setLocaleState] = useState<Locale>(() => {
    const saved = localStorage.getItem('sg_banking_locale');
    return (saved === 'fr-FR' || saved === 'en-GB') ? (saved as Locale) : 'fr-FR';
  });

  const setLocale = (newLocale: Locale) => {
    setLocaleState(newLocale);
    localStorage.setItem('sg_banking_locale', newLocale);
    document.documentElement.lang = newLocale === 'fr-FR' ? 'fr' : 'en';
  };

  useEffect(() => {
    document.documentElement.lang = locale === 'fr-FR' ? 'fr' : 'en';
  }, [locale]);

  const t = (key: TranslationKey, fallback?: string): string => {
    const entry = dictionary[key];
    if (!entry) return fallback || String(key);
    return entry[locale] || fallback || String(key);
  };

  const formatCurrency = (amount: number | string, currency: Currency = 'EUR'): string => {
    const numeric = typeof amount === 'string' ? parseFloat(amount) : amount;
    if (isNaN(numeric)) return `0.00 ${currency}`;

    try {
      return new Intl.NumberFormat(locale, {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(numeric);
    } catch {
      return `${numeric.toFixed(2)} ${currency}`;
    }
  };

  const formatNumber = (value: number | string, decimals: number = 2): string => {
    const numeric = typeof value === 'string' ? parseFloat(value) : value;
    if (isNaN(numeric)) return '0';

    return new Intl.NumberFormat(locale, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(numeric);
  };

  const formatDate = (dateStr: string, options?: Intl.DateTimeFormatOptions): string => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) return dateStr;
      
      const defaultOptions: Intl.DateTimeFormatOptions = options || {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      };
      return new Intl.DateTimeFormat(locale, defaultOptions).format(date);
    } catch {
      return dateStr;
    }
  };

  const formatPercentage = (ratio: number, decimals: number = 2): string => {
    return new Intl.NumberFormat(locale, {
      style: 'percent',
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(ratio);
  };

  return (
    <TranslationContext.Provider
      value={{
        locale,
        setLocale,
        t,
        formatCurrency,
        formatNumber,
        formatDate,
        formatPercentage,
      }}
    >
      {children}
    </TranslationContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(TranslationContext);
  if (!context) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
};
