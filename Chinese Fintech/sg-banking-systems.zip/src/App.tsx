/**
 * SG Banking Systems - Universal Bilingual Banking Platform
 * Root Application Container & Module Router
 */

import React, { useState, useEffect } from 'react';
import { TranslationProvider } from './localisation/useTranslation';
import { BankingProvider, useBanking } from './context/BankingContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { HomeOverviewView } from './components/views/HomeOverviewView';
import { AccountsView } from './components/views/AccountsView';
import { PaymentsView } from './components/views/PaymentsView';
import { CardsView } from './components/views/CardsView';
import { LoansView } from './components/views/LoansView';
import { SavingsView } from './components/views/SavingsView';
import { WealthView } from './components/views/WealthView';
import { MarketsView } from './components/views/MarketsView';
import { FixedIncomeView } from './components/views/FixedIncomeView';
import { TreasuryView } from './components/views/TreasuryView';
import { RiskView } from './components/views/RiskView';
import { ComplianceView } from './components/views/ComplianceView';
import { ReconciliationView } from './components/views/ReconciliationView';
import { ReportsView } from './components/views/ReportsView';
import { AuditView } from './components/views/AuditView';
import { CliView } from './components/views/CliView';
import { ObservabilityView } from './components/views/ObservabilityView';
import { CliConsoleModal } from './components/modals/CliConsoleModal';
import { Menu, X } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const [activeView, setActiveView] = useState('home');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isCliModalOpen, setIsCliModalOpen] = useState(false);

  // Global keyboard shortcut (Ctrl+` or Cmd+K) to open CLI console
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === '`' || e.key === 'k')) {
        e.preventDefault();
        setIsCliModalOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const renderCurrentView = () => {
    switch (activeView) {
      case 'home':
        return <HomeOverviewView onNavigate={setActiveView} />;
      case 'accounts':
        return <AccountsView onNavigate={setActiveView} />;
      case 'payments':
        return <PaymentsView />;
      case 'cards':
        return <CardsView />;
      case 'loans':
        return <LoansView />;
      case 'savings':
        return <SavingsView />;
      case 'wealth':
        return <WealthView />;
      case 'markets':
        return <MarketsView />;
      case 'fixedIncome':
        return <FixedIncomeView />;
      case 'treasury':
        return <TreasuryView />;
      case 'risk':
        return <RiskView />;
      case 'compliance':
        return <ComplianceView />;
      case 'reconciliation':
        return <ReconciliationView />;
      case 'reports':
        return <ReportsView />;
      case 'audit':
        return <AuditView />;
      case 'cli':
        return <CliView />;
      case 'observability':
        return <ObservabilityView />;
      default:
        return <HomeOverviewView onNavigate={setActiveView} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#090b10] text-[#e1e4ea] flex flex-col font-sans selection:bg-[#e60028] selection:text-white">
      {/* Global Header */}
      <Header
        activeView={activeView}
        onOpenCli={() => setIsCliModalOpen(true)}
      />

      {/* Mobile Top Navigation Trigger */}
      <div className="lg:hidden px-4 py-2.5 bg-[#0f121a] border-b border-[#1f2533] flex items-center justify-between">
        <button
          onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
          className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-[#151923] border border-[#273042] text-xs font-semibold text-[#cbd5e1]"
        >
          {isMobileSidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          <span>Menu Bancaire</span>
        </button>

        <span className="text-xs font-mono font-bold text-red-400 uppercase">
          {activeView}
        </span>
      </div>

      {/* Main Structural Body: Sidebar + Active View */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          activeView={activeView}
          setActiveView={setActiveView}
          isMobileOpen={isMobileSidebarOpen}
          setIsMobileOpen={setIsMobileSidebarOpen}
        />

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#090b10]">
          <div className="max-w-7xl mx-auto">
            {renderCurrentView()}
          </div>
        </main>
      </div>

      {/* Global CLI Modal */}
      <CliConsoleModal
        isOpen={isCliModalOpen}
        onClose={() => setIsCliModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <TranslationProvider>
      <BankingProvider>
        <MainAppContent />
      </BankingProvider>
    </TranslationProvider>
  );
}
