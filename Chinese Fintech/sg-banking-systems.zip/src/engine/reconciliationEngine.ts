/**
 * SG Banking Systems - 3-Way Reconciliation & Clearing Engine
 * Matches Internal Core Ledger vs Payment Processors (SEPA/SWIFT) vs Settlement Clearing Records
 */

import { Decimal } from 'decimal.js';
import { ReconciliationItem, Transaction } from '../types/domain';

export class ReconciliationEngine {
  /**
   * Run synthetic automated 3-way reconciliation batch
   */
  static runReconciliation(
    internalTransactions: Transaction[],
    existingItems: ReconciliationItem[] = []
  ): {
    matchedCount: number;
    unmatchedCount: number;
    exceptionCount: number;
    totalAmountLedger: string;
    totalAmountSettled: string;
    items: ReconciliationItem[];
  } {
    const items: ReconciliationItem[] = [...existingItems];
    let totalLedger = new Decimal(0);
    let totalSettled = new Decimal(0);

    for (const tx of internalTransactions) {
      const alreadyPresent = items.some(it => it.ledgerTransactionId === tx.id);
      if (!alreadyPresent) {
        // Generate simulated external settlement counterpart
        const amt = new Decimal(tx.amount);
        totalLedger = totalLedger.plus(amt);

        // Deterministic simulation: 95% perfect match, 5% artificial timing or fee variance
        const isException = Math.random() < 0.05 && amt.gt(500);
        const settledAmt = isException ? amt.minus(new Decimal(3.50)) : amt;
        totalSettled = totalSettled.plus(settledAmt);
        const variance = amt.minus(settledAmt);

        const status = isException ? 'EXCEPTION' : 'MATCHED';

        items.unshift({
          id: `REC-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          ledgerTransactionId: tx.id,
          processorReference: `STEP2-SEPA-BATCH-${tx.reference}`,
          settlementBatchId: `TARGET2-CLR-${Math.floor(100000 + Math.random() * 900000)}`,
          amountLedger: amt.toFixed(2),
          amountSettled: settledAmt.toFixed(2),
          currency: tx.currency,
          bookingDate: tx.bookingDate,
          status,
          variance: variance.abs().toFixed(2),
          comments: isException ? 'Écart de 3.50 € détecté (Frais de réseau intermédiaire non provisionnés).' : 'Lettrage parfait 100%.',
        });
      }
    }

    const matched = items.filter(i => i.status === 'MATCHED' || i.status === 'RESOLVED').length;
    const unmatched = items.filter(i => i.status === 'UNMATCHED').length;
    const exceptions = items.filter(i => i.status === 'EXCEPTION').length;

    return {
      matchedCount: matched,
      unmatchedCount: unmatched,
      exceptionCount: exceptions,
      totalAmountLedger: totalLedger.toFixed(2),
      totalAmountSettled: totalSettled.toFixed(2),
      items,
    };
  }

  /**
   * Resolve an unmatched discrepancy with audit commentary
   */
  static resolveException(item: ReconciliationItem, comment: string): ReconciliationItem {
    return {
      ...item,
      status: 'RESOLVED',
      comments: `Régularisé: ${comment}`,
    };
  }
}
