/**
 * SG Banking Systems - Quantitative Fixed Income & Bond Analytics Engine
 * Precise pricing, Yield-to-Maturity (Newton-Raphson), Macaulay & Modified Duration, Convexity
 */

import { BondAnalytics } from '../types/domain';

export class BondEngine {
  /**
   * Price a fixed-rate bond given Yield to Maturity (YTM)
   */
  static calculateBondPrice(
    couponRate: number, // e.g. 0.035 for 3.5%
    ytm: number, // e.g. 0.032 for 3.2%
    yearsToMaturity: number,
    parValue: number = 100,
    couponFrequency: number = 1
  ): number {
    const n = yearsToMaturity * couponFrequency;
    const c = (couponRate * parValue) / couponFrequency;
    const y = ytm / couponFrequency;

    if (y === 0) {
      return c * n + parValue;
    }

    // PV of coupons: c * [1 - (1+y)^-n] / y
    const pvCoupons = (c * (1 - Math.pow(1 + y, -n))) / y;
    // PV of par: parValue / (1+y)^n
    const pvPar = parValue / Math.pow(1 + y, n);

    return pvCoupons + pvPar;
  }

  /**
   * Estimate Yield to Maturity (YTM) given Market Price using Newton-Raphson
   */
  static calculateYTM(
    marketPrice: number,
    couponRate: number,
    yearsToMaturity: number,
    parValue: number = 100,
    couponFrequency: number = 1,
    maxIter: number = 100,
    tol: number = 1e-7
  ): number {
    // Initial guess
    const annualCoupon = couponRate * parValue;
    let ytm = (annualCoupon + (parValue - marketPrice) / yearsToMaturity) / ((parValue + marketPrice) / 2);

    for (let i = 0; i < maxIter; i++) {
      const price = this.calculateBondPrice(couponRate, ytm, yearsToMaturity, parValue, couponFrequency);
      const diff = price - marketPrice;
      if (Math.abs(diff) < tol) {
        return ytm;
      }

      // Derivative dPrice/dYTM
      const dy = 0.0001;
      const priceUp = this.calculateBondPrice(couponRate, ytm + dy, yearsToMaturity, parValue, couponFrequency);
      const derivative = (priceUp - price) / dy;

      if (Math.abs(derivative) < 1e-12) break;
      ytm = ytm - diff / derivative;

      if (ytm < -0.05) ytm = 0.0001; // Guard against extreme divergence
    }

    return ytm;
  }

  /**
   * Full analytics suite for an institutional bond
   */
  static analyzeBond(
    isin: string,
    name: string,
    couponRate: number,
    yearsToMaturity: number,
    marketPrice: number,
    parValue: number = 100,
    daysSinceLastCoupon: number = 142,
    daysInYear: number = 365
  ): BondAnalytics {
    const ytm = this.calculateYTM(marketPrice, couponRate, yearsToMaturity, parValue);
    
    // Accrued interest
    const annualCoupon = couponRate * parValue;
    const accruedInterest = annualCoupon * (daysSinceLastCoupon / daysInYear);
    const cleanPrice = marketPrice;
    const dirtyPrice = cleanPrice + accruedInterest;

    // Macaulay Duration: Sum( t * PV(CF_t) ) / Price
    const n = Math.ceil(yearsToMaturity);
    let weightedCashFlows = 0;
    for (let t = 1; t <= n; t++) {
      const cf = t === n ? annualCoupon + parValue : annualCoupon;
      const pv = cf / Math.pow(1 + ytm, t);
      weightedCashFlows += t * pv;
    }
    const macaulayDuration = weightedCashFlows / dirtyPrice;
    const modifiedDuration = macaulayDuration / (1 + ytm);

    // Convexity: [ Sum( t * (t+1) * PV(CF_t) ) ] / [ DirtyPrice * (1+ytm)^2 ]
    let convexitySum = 0;
    for (let t = 1; t <= n; t++) {
      const cf = t === n ? annualCoupon + parValue : annualCoupon;
      const pv = cf / Math.pow(1 + ytm, t);
      convexitySum += t * (t + 1) * pv;
    }
    const convexity = convexitySum / (dirtyPrice * Math.pow(1 + ytm, 2));

    return {
      isin,
      name,
      couponRate,
      yearsToMaturity,
      parValue,
      marketPrice,
      yieldToMaturity: ytm,
      cleanPrice: Number(cleanPrice.toFixed(4)),
      dirtyPrice: Number(dirtyPrice.toFixed(4)),
      accruedInterest: Number(accruedInterest.toFixed(4)),
      modifiedDuration: Number(modifiedDuration.toFixed(3)),
      macaulayDuration: Number(macaulayDuration.toFixed(3)),
      convexity: Number(convexity.toFixed(3)),
    };
  }
}
