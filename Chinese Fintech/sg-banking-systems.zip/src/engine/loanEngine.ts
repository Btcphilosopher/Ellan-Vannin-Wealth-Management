/**
 * SG Banking Systems - Loan & Mortgage Quantitative Engine
 * Calculates amortization schedules, monthly annuities, early repayment impact, and LTV
 */

import { Decimal } from 'decimal.js';
import { Loan, LoanScheduleItem } from '../types/domain';

export class LoanEngine {
  /**
   * Standard French / European Annuity Formula (Constant Monthly Payment)
   * M = P * [ r * (1 + r)^n ] / [ (1 + r)^n - 1 ]
   * where:
   * P = principal loan amount
   * r = monthly interest rate (annualRate / 12)
   * n = total number of months
   */
  static calculateMonthlyPayment(
    principalStr: string | number,
    annualRate: number,
    termMonths: number,
    monthlyInsuranceRate: number = 0.0003 // e.g. 0.36% annual insurance
  ): {
    totalMonthlyPayment: string;
    principalAndInterest: string;
    monthlyInsurance: string;
    totalInterest: string;
    totalCost: string;
  } {
    const P = new Decimal(principalStr);
    const n = termMonths;
    const r = new Decimal(annualRate).dividedBy(12);

    if (r.isZero() || annualRate === 0) {
      const pMonthly = P.dividedBy(n);
      const insurance = P.times(monthlyInsuranceRate);
      const totalMonthly = pMonthly.plus(insurance);
      return {
        totalMonthlyPayment: totalMonthly.toFixed(2),
        principalAndInterest: pMonthly.toFixed(2),
        monthlyInsurance: insurance.toFixed(2),
        totalInterest: '0.00',
        totalCost: P.plus(insurance.times(n)).toFixed(2),
      };
    }

    // (1 + r)^n
    const onePlusR = r.plus(1);
    const compound = onePlusR.pow(n);

    // [ r * (1 + r)^n ] / [ (1 + r)^n - 1 ]
    const numerator = r.times(compound);
    const denominator = compound.minus(1);
    const factor = numerator.dividedBy(denominator);

    const principalAndInterest = P.times(factor);
    const monthlyInsurance = P.times(monthlyInsuranceRate);
    const totalMonthlyPayment = principalAndInterest.plus(monthlyInsurance);

    const totalPaid = principalAndInterest.times(n);
    const totalInterest = totalPaid.minus(P);
    const totalCost = totalPaid.plus(monthlyInsurance.times(n));

    return {
      totalMonthlyPayment: totalMonthlyPayment.toFixed(2),
      principalAndInterest: principalAndInterest.toFixed(2),
      monthlyInsurance: monthlyInsurance.toFixed(2),
      totalInterest: totalInterest.toFixed(2),
      totalCost: totalCost.toFixed(2),
    };
  }

  /**
   * Generates a complete mathematical amortisation schedule
   */
  static generateSchedule(
    principalStr: string | number,
    annualRate: number,
    termMonths: number,
    startDateStr: string,
    monthlyInsuranceRate: number = 0.0003
  ): LoanScheduleItem[] {
    let remaining = new Decimal(principalStr);
    const r = new Decimal(annualRate).dividedBy(12);
    const { principalAndInterest, monthlyInsurance } = this.calculateMonthlyPayment(
      principalStr,
      annualRate,
      termMonths,
      monthlyInsuranceRate
    );
    const monthlyPI = new Decimal(principalAndInterest);
    const insurance = new Decimal(monthlyInsurance);
    const totalMonthly = monthlyPI.plus(insurance);

    const schedule: LoanScheduleItem[] = [];
    const start = new Date(startDateStr);

    for (let i = 1; i <= termMonths; i++) {
      const dueDate = new Date(start);
      dueDate.setMonth(dueDate.getMonth() + i);

      const interestAmount = remaining.times(r);
      let principalAmount = monthlyPI.minus(interestAmount);

      // Handle final installment rounding adjustments
      if (i === termMonths || principalAmount.gt(remaining)) {
        principalAmount = remaining;
        remaining = new Decimal(0);
      } else {
        remaining = remaining.minus(principalAmount);
      }

      schedule.push({
        installmentNumber: i,
        dueDate: dueDate.toISOString().split('T')[0],
        monthlyPayment: totalMonthly.toFixed(2),
        principalAmount: principalAmount.toFixed(2),
        interestAmount: interestAmount.toFixed(2),
        insuranceAmount: insurance.toFixed(2),
        remainingPrincipal: remaining.toFixed(2),
        isPaid: false,
      });

      if (remaining.lte(0)) break;
    }

    return schedule;
  }

  /**
   * Calculate Loan-to-Value (LTV) Ratio for Mortgages
   */
  static calculateLTV(loanAmountStr: string, propertyValueStr: string): number {
    const loan = new Decimal(loanAmountStr || 0);
    const property = new Decimal(propertyValueStr || 1);
    if (property.isZero()) return 0;
    return loan.dividedBy(property).toNumber();
  }

  /**
   * Simulate early partial or full repayment
   */
  static simulateEarlyRepayment(
    loan: Loan,
    repaymentAmountStr: string,
    option: 'REDUCE_TERM' | 'REDUCE_PAYMENT'
  ): {
    newMonthlyPayment: string;
    newRemainingMonths: number;
    interestSavings: string;
    newOutstanding: string;
  } {
    const currentOutstanding = new Decimal(loan.outstandingPrincipal);
    const repayment = new Decimal(repaymentAmountStr);
    const newOutstanding = currentOutstanding.minus(repayment).clamp(0, currentOutstanding);

    if (newOutstanding.isZero()) {
      return {
        newMonthlyPayment: '0.00',
        newRemainingMonths: 0,
        interestSavings: new Decimal(loan.monthlyPayment).times(loan.termMonths).minus(currentOutstanding).toFixed(2),
        newOutstanding: '0.00',
      };
    }

    if (option === 'REDUCE_PAYMENT') {
      const calc = this.calculateMonthlyPayment(newOutstanding.toString(), loan.annualInterestRate, loan.termMonths, loan.insuranceRate / 12);
      const oldTotalCost = new Decimal(loan.monthlyPayment).times(loan.termMonths);
      const newTotalCost = new Decimal(calc.totalMonthlyPayment).times(loan.termMonths).plus(repayment);
      const savings = oldTotalCost.minus(newTotalCost);

      return {
        newMonthlyPayment: calc.totalMonthlyPayment,
        newRemainingMonths: loan.termMonths,
        interestSavings: savings.gt(0) ? savings.toFixed(2) : '0.00',
        newOutstanding: newOutstanding.toFixed(2),
      };
    } else {
      // REDUCE_TERM: keep monthly payment same, recalculate number of months
      const r = new Decimal(loan.annualInterestRate).dividedBy(12);
      const pMonthly = new Decimal(loan.monthlyPayment).minus(newOutstanding.times(loan.insuranceRate / 12));
      
      // n = - ln(1 - (r * P / M)) / ln(1 + r)
      const ratio = r.times(newOutstanding).dividedBy(pMonthly);
      let newMonths = loan.termMonths;
      if (ratio.lt(1)) {
        const numerator = Math.log(1 - ratio.toNumber());
        const denominator = Math.log(1 + r.toNumber());
        newMonths = Math.ceil(-numerator / denominator);
      }

      const oldTotalCost = new Decimal(loan.monthlyPayment).times(loan.termMonths);
      const newTotalCost = new Decimal(loan.monthlyPayment).times(newMonths).plus(repayment);
      const savings = oldTotalCost.minus(newTotalCost);

      return {
        newMonthlyPayment: loan.monthlyPayment,
        newRemainingMonths: Math.max(1, newMonths),
        interestSavings: savings.gt(0) ? savings.toFixed(2) : '0.00',
        newOutstanding: newOutstanding.toFixed(2),
      };
    }
  }
}
