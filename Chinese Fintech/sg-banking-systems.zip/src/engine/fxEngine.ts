/**
 * SG Banking Systems - Institutional Foreign Exchange (FX) Engine
 * Multi-currency spot rates, bid/ask spreads, currency conversion, and rate triangulations
 */

import { Decimal } from 'decimal.js';
import { Currency, FXRate } from '../types/domain';

export const INITIAL_FX_RATES: FXRate[] = [
  { pair: 'EUR/USD', baseCurrency: 'EUR', quoteCurrency: 'USD', bid: 1.0842, ask: 1.0846, mid: 1.0844, change24h: 0.0028, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
  { pair: 'EUR/GBP', baseCurrency: 'EUR', quoteCurrency: 'GBP', bid: 0.8540, ask: 0.8544, mid: 0.8542, change24h: -0.0014, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
  { pair: 'EUR/CHF', baseCurrency: 'EUR', quoteCurrency: 'CHF', bid: 0.9620, ask: 0.9625, mid: 0.9622, change24h: 0.0008, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
  { pair: 'EUR/JPY', baseCurrency: 'EUR', quoteCurrency: 'JPY', bid: 164.80, ask: 164.92, mid: 164.86, change24h: 0.45, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
  { pair: 'GBP/USD', baseCurrency: 'GBP', quoteCurrency: 'USD', bid: 1.2690, ask: 1.2695, mid: 1.2692, change24h: 0.0035, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
  { pair: 'USD/JPY', baseCurrency: 'USD', quoteCurrency: 'JPY', bid: 152.02, ask: 152.08, mid: 152.05, change24h: 0.18, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
  { pair: 'USD/CHF', baseCurrency: 'USD', quoteCurrency: 'CHF', bid: 0.8872, ask: 0.8876, mid: 0.8874, change24h: -0.0011, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
  { pair: 'EUR/CNY', baseCurrency: 'EUR', quoteCurrency: 'CNY', bid: 7.8420, ask: 7.8460, mid: 7.8440, change24h: 0.0120, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
  { pair: 'EUR/CAD', baseCurrency: 'EUR', quoteCurrency: 'CAD', bid: 1.4820, ask: 1.4828, mid: 1.4824, change24h: -0.0032, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
  { pair: 'EUR/AUD', baseCurrency: 'EUR', quoteCurrency: 'AUD', bid: 1.6450, ask: 1.6460, mid: 1.6455, change24h: 0.0040, lastUpdated: new Date().toISOString(), source: 'SG European Rates & FX Desk' },
];

export class FXEngine {
  /**
   * Convert an amount from fromCurrency to toCurrency
   */
  static convert(
    amountStr: string | number,
    fromCurrency: Currency,
    toCurrency: Currency,
    rates: FXRate[] = INITIAL_FX_RATES,
    includeSpread: boolean = true
  ): {
    convertedAmount: string;
    rateUsed: number;
    spreadFee: string;
    inverseRate: number;
  } {
    const amount = new Decimal(amountStr || 0);

    if (fromCurrency === toCurrency) {
      return {
        convertedAmount: amount.toFixed(2),
        rateUsed: 1.0,
        spreadFee: '0.00',
        inverseRate: 1.0,
      };
    }

    // Direct pair: from/to
    const directPair = rates.find(r => r.baseCurrency === fromCurrency && r.quoteCurrency === toCurrency);
    if (directPair) {
      const rate = includeSpread ? directPair.bid : directPair.mid;
      const converted = amount.times(rate);
      const spreadDiff = amount.times(directPair.ask - directPair.bid).dividedBy(2);
      return {
        convertedAmount: converted.toFixed(2),
        rateUsed: rate,
        spreadFee: spreadDiff.toFixed(2),
        inverseRate: 1 / rate,
      };
    }

    // Reverse pair: to/from
    const reversePair = rates.find(r => r.baseCurrency === toCurrency && r.quoteCurrency === fromCurrency);
    if (reversePair) {
      const rate = 1 / (includeSpread ? reversePair.ask : reversePair.mid);
      const converted = amount.times(rate);
      const spreadDiff = amount.times(reversePair.ask - reversePair.bid).dividedBy(2 * reversePair.mid);
      return {
        convertedAmount: converted.toFixed(2),
        rateUsed: rate,
        spreadFee: spreadDiff.toFixed(2),
        inverseRate: 1 / rate,
      };
    }

    // Triangular arbitrage through EUR
    const fromToEUR = fromCurrency === 'EUR' ? 1 : this.convert(1, fromCurrency, 'EUR', rates, false).rateUsed;
    const eurToTarget = toCurrency === 'EUR' ? 1 : this.convert(1, 'EUR', toCurrency, rates, false).rateUsed;
    const crossRate = fromToEUR * eurToTarget;
    const converted = amount.times(crossRate);

    return {
      convertedAmount: converted.toFixed(2),
      rateUsed: crossRate,
      spreadFee: amount.times(0.0008).toFixed(2), // 8 bps institutional spread
      inverseRate: 1 / crossRate,
    };
  }
}
