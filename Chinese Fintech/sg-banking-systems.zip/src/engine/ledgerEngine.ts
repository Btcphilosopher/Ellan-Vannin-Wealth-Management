/**
 * SG Banking Systems - Core Double-Entry Accounting Ledger Engine
 * Implements strict monetary arithmetic with Decimal.js
 * Rule: Total Debits == Total Credits for every balanced transaction
 */

import { Decimal } from 'decimal.js';
import { Account, LedgerEntry, Transaction, Currency } from '../types/domain';

// Set high precision for financial accounting
Decimal.set({ precision: 28, rounding: Decimal.ROUND_HALF_UP });

export interface BalancedPostingResult {
  success: boolean;
  transaction: Transaction;
  debitEntry: LedgerEntry;
  creditEntry: LedgerEntry;
  updatedSourceAccount: Account;
  updatedDestAccount?: Account;
  error?: string;
}

export interface LedgerVerificationResult {
  isBalanced: boolean;
  totalDebits: string;
  totalCredits: string;
  entryCount: number;
  transactionCount: number;
  variance: string;
  verifiedAt: string;
  unbalancedTransactions: string[];
}

export class LedgerEngine {
  /**
   * Recalculate available balance from ledger balance, pending holds, and overdraft
   */
  static calculateAvailableBalance(
    ledgerBalance: string,
    pendingHolds: string = '0',
    overdraftLimit: string = '0'
  ): string {
    const ledger = new Decimal(ledgerBalance || 0);
    const holds = new Decimal(pendingHolds || 0);
    const overdraft = new Decimal(overdraftLimit || 0);
    return ledger.minus(holds).plus(overdraft).toFixed(2);
  }

  /**
   * Create and post a balanced double-entry transaction
   */
  static postTransfer(
    sourceAccount: Account,
    destAccount: Account | undefined,
    amountStr: string,
    feeStr: string = '0',
    narrative: string,
    counterpartyName: string,
    counterpartyIban?: string,
    counterpartyBic?: string
  ): BalancedPostingResult {
    try {
      const amount = new Decimal(amountStr);
      const fee = new Decimal(feeStr);
      const totalDebit = amount.plus(fee);

      if (amount.lte(0)) {
        return {
          success: false,
          error: 'Le montant de la transaction doit être strictement positif.',
          transaction: {} as Transaction,
          debitEntry: {} as LedgerEntry,
          creditEntry: {} as LedgerEntry,
          updatedSourceAccount: sourceAccount,
        };
      }

      // Check sufficient funds (ledger + overdraft)
      const currentAvailable = new Decimal(sourceAccount.availableBalance);
      if (currentAvailable.lt(totalDebit)) {
        return {
          success: false,
          error: `Solde insuffisant. Disponible: ${sourceAccount.availableBalance} ${sourceAccount.currency}, Requis: ${totalDebit.toFixed(2)} ${sourceAccount.currency}`,
          transaction: {} as Transaction,
          debitEntry: {} as LedgerEntry,
          creditEntry: {} as LedgerEntry,
          updatedSourceAccount: sourceAccount,
        };
      }

      const now = new Date().toISOString();
      const bookingDate = now.split('T')[0];
      const valueDate = bookingDate;
      const txId = `TX-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
      const ref = `SG-SEPA-${Math.floor(10000000 + Math.random() * 90000000)}`;

      // Update Source Account Balance
      const newSourceLedger = new Decimal(sourceAccount.ledgerBalance).minus(totalDebit);
      const updatedSourceAccount: Account = {
        ...sourceAccount,
        ledgerBalance: newSourceLedger.toFixed(2),
        availableBalance: this.calculateAvailableBalance(newSourceLedger.toFixed(2), sourceAccount.pendingBalance, sourceAccount.overdraftLimit),
      };

      // Debit Entry (Source)
      const debitEntry: LedgerEntry = {
        id: `LED-${Date.now()}-DR`,
        transactionId: txId,
        accountId: sourceAccount.id,
        entryType: 'DEBIT',
        amount: totalDebit.toFixed(2),
        currency: sourceAccount.currency,
        bookingDate,
        valueDate,
        narrative: `Débit: ${narrative}`,
        balanceAfter: updatedSourceAccount.ledgerBalance,
      };

      // Update Destination Account Balance if internal
      let updatedDestAccount: Account | undefined = undefined;
      let creditBalanceAfter = 'N/A';

      if (destAccount) {
        const newDestLedger = new Decimal(destAccount.ledgerBalance).plus(amount);
        updatedDestAccount = {
          ...destAccount,
          ledgerBalance: newDestLedger.toFixed(2),
          availableBalance: this.calculateAvailableBalance(newDestLedger.toFixed(2), destAccount.pendingBalance, destAccount.overdraftLimit),
        };
        creditBalanceAfter = updatedDestAccount.ledgerBalance;
      }

      // Credit Entry (Destination or Nostro/Settlement clearing)
      const creditEntry: LedgerEntry = {
        id: `LED-${Date.now()}-CR`,
        transactionId: txId,
        accountId: destAccount ? destAccount.id : 'NOSTRO-SEPA-CLEARING-EUR',
        entryType: 'CREDIT',
        amount: totalDebit.toFixed(2),
        currency: sourceAccount.currency,
        bookingDate,
        valueDate,
        narrative: `Crédit: ${narrative}`,
        balanceAfter: creditBalanceAfter,
      };

      const transaction: Transaction = {
        id: txId,
        reference: ref,
        sourceAccountId: sourceAccount.id,
        destinationAccountId: destAccount?.id,
        counterpartyName,
        counterpartyIban: counterpartyIban || destAccount?.iban,
        counterpartyBic: counterpartyBic || destAccount?.bic || 'SOGEFRPP',
        amount: amount.toFixed(2),
        currency: sourceAccount.currency,
        fee: fee.toFixed(2),
        status: 'POSTED',
        category: 'TRANSFER',
        narrative,
        bookingDate,
        valueDate,
        createdAt: now,
        auditTrailId: `AUD-${Date.now()}`,
      };

      return {
        success: true,
        transaction,
        debitEntry,
        creditEntry,
        updatedSourceAccount,
        updatedDestAccount,
      };
    } catch (err: any) {
      return {
        success: false,
        error: err?.message || 'Erreur inattendue du grand livre comptable.',
        transaction: {} as Transaction,
        debitEntry: {} as LedgerEntry,
        creditEntry: {} as LedgerEntry,
        updatedSourceAccount: sourceAccount,
      };
    }
  }

  /**
   * Post a direct credit deposit into an account (e.g. Salary, initial deposit, wire transfer receipt)
   */
  static postDeposit(
    destAccount: Account,
    amountStr: string,
    narrative: string,
    originName: string = 'Dépôt Bancaire / Virement Reçu'
  ): BalancedPostingResult {
    const amount = new Decimal(amountStr);
    const now = new Date().toISOString();
    const bookingDate = now.split('T')[0];
    const txId = `TX-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    const ref = `SG-DEP-${Math.floor(10000000 + Math.random() * 90000000)}`;

    const newDestLedger = new Decimal(destAccount.ledgerBalance).plus(amount);
    const updatedDestAccount: Account = {
      ...destAccount,
      ledgerBalance: newDestLedger.toFixed(2),
      availableBalance: this.calculateAvailableBalance(newDestLedger.toFixed(2), destAccount.pendingBalance, destAccount.overdraftLimit),
    };

    const creditEntry: LedgerEntry = {
      id: `LED-${Date.now()}-CR`,
      transactionId: txId,
      accountId: destAccount.id,
      entryType: 'CREDIT',
      amount: amount.toFixed(2),
      currency: destAccount.currency,
      bookingDate,
      valueDate: bookingDate,
      narrative: `Crédit: ${narrative}`,
      balanceAfter: updatedDestAccount.ledgerBalance,
    };

    const debitEntry: LedgerEntry = {
      id: `LED-${Date.now()}-DR`,
      transactionId: txId,
      accountId: 'CENTRAL-BANK-SETTLEMENT-RESERVE',
      entryType: 'DEBIT',
      amount: amount.toFixed(2),
      currency: destAccount.currency,
      bookingDate,
      valueDate: bookingDate,
      narrative: `Compensation Centrale: ${narrative}`,
      balanceAfter: 'N/A',
    };

    const transaction: Transaction = {
      id: txId,
      reference: ref,
      sourceAccountId: 'CENTRAL-BANK-SETTLEMENT-RESERVE',
      destinationAccountId: destAccount.id,
      counterpartyName: originName,
      counterpartyIban: 'FR7630003012345678901234567',
      counterpartyBic: 'BDFEFRPP',
      amount: amount.toFixed(2),
      currency: destAccount.currency,
      fee: '0.00',
      status: 'POSTED',
      category: 'TRANSFER',
      narrative,
      bookingDate,
      valueDate: bookingDate,
      createdAt: now,
      auditTrailId: `AUD-${Date.now()}`,
    };

    return {
      success: true,
      transaction,
      debitEntry,
      creditEntry,
      updatedSourceAccount: destAccount, // placeholder
      updatedDestAccount,
    };
  }

  /**
   * Verify the entire General Ledger for Debits == Credits integrity
   */
  static verifyLedger(entries: LedgerEntry[]): LedgerVerificationResult {
    let totalDebits = new Decimal(0);
    let totalCredits = new Decimal(0);
    const txMap = new Map<string, { debits: Decimal; credits: Decimal }>();

    for (const entry of entries) {
      const amount = new Decimal(entry.amount || 0);
      if (entry.entryType === 'DEBIT') {
        totalDebits = totalDebits.plus(amount);
      } else {
        totalCredits = totalCredits.plus(amount);
      }

      if (!txMap.has(entry.transactionId)) {
        txMap.set(entry.transactionId, { debits: new Decimal(0), credits: new Decimal(0) });
      }
      const item = txMap.get(entry.transactionId)!;
      if (entry.entryType === 'DEBIT') {
        item.debits = item.debits.plus(amount);
      } else {
        item.credits = item.credits.plus(amount);
      }
    }

    const unbalanced: string[] = [];
    txMap.forEach((val, txId) => {
      if (!val.debits.equals(val.credits)) {
        unbalanced.push(txId);
      }
    });

    const variance = totalDebits.minus(totalCredits).abs();
    const isBalanced = variance.isZero() && unbalanced.length === 0;

    return {
      isBalanced,
      totalDebits: totalDebits.toFixed(2),
      totalCredits: totalCredits.toFixed(2),
      entryCount: entries.length,
      transactionCount: txMap.size,
      variance: variance.toFixed(2),
      verifiedAt: new Date().toISOString(),
      unbalancedTransactions: unbalanced,
    };
  }
}
