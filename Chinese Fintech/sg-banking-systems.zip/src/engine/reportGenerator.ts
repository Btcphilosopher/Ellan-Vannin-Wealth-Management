/**
 * SG Banking Systems - Bilingual Statement & Report Export Generator
 * Supports CSV, JSON, and formatted printable/downloadable HTML/PDF representations
 */

import { Account, Transaction, Loan, TreasuryPosition, AuditEvent, Locale } from '../types/domain';

export class ReportGenerator {
  /**
   * Generates a CSV string of Account Transactions
   */
  static generateAccountStatementCSV(account: Account, transactions: Transaction[], locale: Locale): string {
    const isFr = locale === 'fr-FR';
    const headers = isFr
      ? ['Date Comptable', 'Date Valeur', 'Reference', 'Contrepartie', 'Sens', 'Montant', 'Devise', 'Libelle']
      : ['Booking Date', 'Value Date', 'Reference', 'Counterparty', 'Side', 'Amount', 'Currency', 'Narrative'];

    const rows = transactions.map(t => {
      const isDebit = t.sourceAccountId === account.id;
      return [
        t.bookingDate,
        t.valueDate,
        t.reference,
        `"${t.counterpartyName.replace(/"/g, '""')}"`,
        isDebit ? 'DEBIT' : 'CREDIT',
        t.amount,
        t.currency,
        `"${t.narrative.replace(/"/g, '""')}"`,
      ].join(';');
    });

    return [headers.join(';'), ...rows].join('\n');
  }

  /**
   * Generates a CSV of Loan Amortisation Schedule
   */
  static generateLoanScheduleCSV(loan: Loan, locale: Locale): string {
    const isFr = locale === 'fr-FR';
    const headers = isFr
      ? ['Echeance', 'Date', 'Mensualite', 'Capital', 'Interets', 'Assurance', 'Capital Restant']
      : ['Installment', 'Due Date', 'Payment', 'Principal', 'Interest', 'Insurance', 'Remaining Principal'];

    const rows = loan.schedule.map(s => {
      return [
        s.installmentNumber,
        s.dueDate,
        s.monthlyPayment,
        s.principalAmount,
        s.interestAmount,
        s.insuranceAmount,
        s.remainingPrincipal,
      ].join(';');
    });

    return [headers.join(';'), ...rows].join('\n');
  }

  /**
   * Generates a CSV of Audit Events
   */
  static generateAuditLogCSV(events: AuditEvent[], locale: Locale): string {
    const isFr = locale === 'fr-FR';
    const headers = isFr
      ? ['Horodatage', 'Utilisateur', 'Role', 'Action', 'Entite', 'ID Entite', 'Statut', 'Correlation ID', 'Motif']
      : ['Timestamp', 'User', 'Role', 'Action', 'Entity', 'Entity ID', 'Status', 'Correlation ID', 'Reason'];

    const rows = events.map(e => {
      return [
        e.timestamp,
        `"${e.userName.replace(/"/g, '""')}"`,
        e.userRole,
        `"${e.action.replace(/"/g, '""')}"`,
        e.entityType,
        e.entityId,
        e.status,
        e.correlationId,
        `"${e.reason.replace(/"/g, '""')}"`,
      ].join(';');
    });

    return [headers.join(';'), ...rows].join('\n');
  }

  /**
   * Download a generated string payload as a client file
   */
  static downloadFile(content: string, filename: string, mimeType: string = 'text/csv;charset=utf-8;') {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
