/**
 * SG Banking Systems - Compliance, AML Transaction Monitoring & KYC Rules Engine
 * Synthetic Tracfin-standard compliance screening and rule evaluation
 */

import { Decimal } from 'decimal.js';
import { AMLAlert, PaymentInstruction, Transaction, KYCProfile, KYCStatus } from '../types/domain';

export class AMLEngine {
  /**
   * Evaluates a payment instruction against compliance & AML surveillance rules
   */
  static evaluatePayment(
    payment: PaymentInstruction,
    recentTransactions: Transaction[] = []
  ): {
    approved: boolean;
    riskScore: number; // 0 to 100
    alert?: AMLAlert;
    reasons: string[];
  } {
    const amount = new Decimal(payment.amount);
    let riskScore = 10;
    const reasons: string[] = [];

    // Rule 1: High value threshold (Tracfin mandatory reporting trigger > €10,000)
    if (amount.gte(10000)) {
      riskScore += 45;
      reasons.push('Seuil de déclaration Tracfin dépassé (> 10 000 €).');
    }

    // Rule 2: Very high value (> €50,000)
    if (amount.gte(50000)) {
      riskScore += 35;
      reasons.push('Transaction d\'un montant exceptionnel (> 50 000 €).');
    }

    // Rule 3: Structuring / Smurfing pattern detection (Multiple transactions just under 10k within 48 hours)
    const recentSub10k = recentTransactions.filter(t => {
      const amt = parseFloat(t.amount);
      return amt >= 7500 && amt < 10000;
    });
    if (amount.gte(7500) && amount.lt(10000) && recentSub10k.length >= 2) {
      riskScore += 50;
      reasons.push('Suspicion de fractionnement de montants (structuring sous le seuil de 10 000 €).');
    }

    // Rule 4: International High-Risk Country IBAN Check
    const highRiskIbanPrefixes = ['RU', 'IR', 'KP', 'SY', 'MM'];
    const destIbanPrefix = payment.destinationIban?.substring(0, 2)?.toUpperCase();
    if (highRiskIbanPrefixes.includes(destIbanPrefix)) {
      riskScore += 60;
      reasons.push(`Destination vers une juridiction sous surveillance renforcée (${destIbanPrefix}).`);
    }

    // Rule 5: Rapid velocity check
    if (recentTransactions.length > 10) {
      riskScore += 15;
      reasons.push('Fréquence inhabituelle de mouvements sur le compte.');
    }

    riskScore = Math.min(100, Math.max(0, riskScore));
    const approved = riskScore < 70;

    let alert: AMLAlert | undefined = undefined;
    if (riskScore >= 50) {
      alert = {
        id: `AML-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        transactionId: payment.id,
        customerId: payment.sourceAccountId,
        customerName: payment.beneficiaryName,
        ruleTriggered: riskScore >= 75 ? 'RULE-HIGH-RISK-TRANSACTION' : 'RULE-THRESHOLD-REVIEW',
        ruleDescription: {
          'fr-FR': reasons.join(' ') || 'Alerte de surveillance transactionnelle automatique.',
          'en-GB': 'Automated transaction monitoring surveillance alert triggered.',
        },
        severity: riskScore >= 80 ? 'CRITICAL' : riskScore >= 60 ? 'HIGH' : 'MEDIUM',
        status: 'NEW',
        amount: payment.amount,
        currency: payment.currency,
        riskScore,
        createdAt: new Date().toISOString(),
      };
    }

    return {
      approved,
      riskScore,
      alert,
      reasons,
    };
  }

  /**
   * Updates KYC workflow status
   */
  static evaluateKYC(profile: KYCProfile, newStatus: KYCStatus): KYCProfile {
    return {
      ...profile,
      status: newStatus,
      reviewDate: new Date().toISOString().split('T')[0],
    };
  }
}
