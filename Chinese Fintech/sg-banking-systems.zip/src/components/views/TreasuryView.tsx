/**
 * SG Banking Systems - Corporate Cash Management & Group Treasury View
 * Multi-entity cash pooling, daily inflows/outflows, credit facility utilization, 30-day forecast
 */

import React, { useState } from 'react';
import { 
  BarChart3, ArrowDownLeft, ArrowUpRight, DollarSign, Building, 
  Download, RefreshCw, CheckCircle2, TrendingUp, Layers
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { ReportGenerator } from '../../engine/reportGenerator';

export const TreasuryView: React.FC = () => {
  const { locale, t, formatCurrency } = useTranslation();
  const { treasuryPositions, logAudit } = useBanking();

  const [poolingSuccess, setPoolingSuccess] = useState(false);

  const handleSimulateCashSweep = () => {
    logAudit('TREASURY_CASH_SWEEP', 'TREASURY', 'POOL-AEROTECH-FR', 'Centralisation de trésorerie (Zero-Balance Account Cash Pooling) exécutée.');
    setPoolingSuccess(true);
    setTimeout(() => setPoolingSuccess(false), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
            {t('nav.treasury')} & Cash Management
          </h1>
          <p className="text-xs text-[#828f9f] font-mono">
            AéroTech France SA & Filiales Internationales • Cash Pooling Automatisé ZBA
          </p>
        </div>

        <button
          onClick={handleSimulateCashSweep}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold shadow-md shadow-red-950/40 transition-all"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>{t('treasury.cashPooling')} (Cash Sweep ZBA)</span>
        </button>
      </div>

      {poolingSuccess && (
        <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-700/60 text-emerald-300 text-xs flex items-center space-x-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>Cash Pooling ZBA exécuté : soldes des filiales nivelés et centralisés au siège Paris !</span>
        </div>
      )}

      {/* Positions Table */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
          <span>{t('treasury.positions')} Multi-Entités</span>
          <span className="text-[11px] text-[#717e92] font-mono font-normal">Position J+0</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                <th className="pb-3 font-semibold">Entité Juridique</th>
                <th className="pb-3 font-semibold text-right">{t('treasury.availableCash')}</th>
                <th className="pb-3 font-semibold text-right">{t('treasury.inflowDay')}</th>
                <th className="pb-3 font-semibold text-right">{t('treasury.outflowDay')}</th>
                <th className="pb-3 font-semibold text-right">{t('treasury.netPosition')}</th>
                <th className="pb-3 font-semibold text-right">{t('treasury.creditFacility')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b202c]">
              {treasuryPositions.map(pos => (
                <tr key={pos.id} className="hover:bg-[#161a25] transition-colors">
                  <td className="py-3 font-bold text-white font-sans">{pos.entityName}</td>
                  <td className="py-3 text-right font-bold text-emerald-400">
                    {formatCurrency(pos.availableCash, pos.currency)}
                  </td>
                  <td className="py-3 text-right text-emerald-300">
                    +{formatCurrency(pos.inflowDay, pos.currency)}
                  </td>
                  <td className="py-3 text-right text-red-300">
                    -{formatCurrency(pos.outflowDay, pos.currency)}
                  </td>
                  <td className="py-3 text-right font-bold text-white">
                    {formatCurrency(pos.netPosition, pos.currency)}
                  </td>
                  <td className="py-3 text-right text-[#94a3b8]">
                    {formatCurrency(pos.creditFacilityDrawn, pos.currency)} / {formatCurrency(pos.creditFacilityLimit, pos.currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
