/**
 * SG Banking Systems - Reports, Statements & Export Studio
 * Generates official French/English bilingual account statements, loan schedules, treasury reports, and audit logs
 */

import React from 'react';
import { 
  FileText, Download, Landmark, BarChart3, History, CheckCircle2, Globe 
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { ReportGenerator } from '../../engine/reportGenerator';

export const ReportsView: React.FC = () => {
  const { locale, t } = useTranslation();
  const { selectedAccount, transactions, loans, auditEvents } = useBanking();

  const accountTransactions = transactions.filter(
    t => t.sourceAccountId === selectedAccount.id || t.destinationAccountId === selectedAccount.id
  );
  const primaryLoan = loans[0];

  const handleDownloadAccountCSV = () => {
    const csv = ReportGenerator.generateAccountStatementCSV(selectedAccount, accountTransactions, locale);
    ReportGenerator.downloadFile(csv, `Releve_Bancaire_${selectedAccount.id}_${locale}.csv`);
  };

  const handleDownloadLoanCSV = () => {
    if (!primaryLoan) return;
    const csv = ReportGenerator.generateLoanScheduleCSV(primaryLoan, locale);
    ReportGenerator.downloadFile(csv, `Echeancier_Pret_${primaryLoan.contractNumber}_${locale}.csv`);
  };

  const handleDownloadAuditCSV = () => {
    const csv = ReportGenerator.generateAuditLogCSV(auditEvents, locale);
    ReportGenerator.downloadFile(csv, `Journal_Audit_SecOps_${locale}.csv`);
  };

  const handleDownloadJSON = (type: string, data: any) => {
    const jsonStr = JSON.stringify(data, null, 2);
    ReportGenerator.downloadFile(jsonStr, `Export_${type}_${Date.now()}.json`, 'application/json');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
          {t('reports.title')} & {t('dashboard.downloadStatement')}
        </h1>
        <p className="text-xs text-[#828f9f] font-mono">
          Génération de relevés officiels bilingues (FR / EN) • Formats CSV, JSON & Relevé Certifié
        </p>
      </div>

      {/* Reports Catalog */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Account Statement Report */}
        <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="p-2 rounded-xl bg-red-950/50 border border-red-800/30 text-red-400 w-fit">
              <FileText className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">
              {t('reports.accountStatement')} ({locale})
            </h3>
            <p className="text-xs text-[#7e8c9e] leading-relaxed">
              Relevé officiel des opérations bancaires, dates de valeur, références SEPA et soldes certifiés.
            </p>
          </div>

          <div className="space-y-2 pt-4 border-t border-[#1f2533]">
            <button
              onClick={handleDownloadAccountCSV}
              className="w-full py-2.5 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold flex items-center justify-center space-x-2 shadow"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('reports.exportCsv')}</span>
            </button>
            <button
              onClick={() => handleDownloadJSON('Account_Statement', { account: selectedAccount, transactions: accountTransactions })}
              className="w-full py-2.5 rounded-xl bg-[#1a202d] hover:bg-[#222a3b] text-[#cbd5e1] text-xs font-semibold flex items-center justify-center space-x-2"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('reports.exportJson')}</span>
            </button>
          </div>
        </div>

        {/* Loan Amortisation Report */}
        <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="p-2 rounded-xl bg-purple-950/50 border border-purple-800/30 text-purple-400 w-fit">
              <Landmark className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">
              {t('loan.downloadSchedule')} ({locale})
            </h3>
            <p className="text-xs text-[#7e8c9e] leading-relaxed">
              Tableau complet des échéances, décomposition capital/intérêts et capital restant dû.
            </p>
          </div>

          <div className="space-y-2 pt-4 border-t border-[#1f2533]">
            <button
              onClick={handleDownloadLoanCSV}
              className="w-full py-2.5 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold flex items-center justify-center space-x-2 shadow"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('reports.exportCsv')}</span>
            </button>
            <button
              onClick={() => handleDownloadJSON('Loan_Schedule', primaryLoan)}
              className="w-full py-2.5 rounded-xl bg-[#1a202d] hover:bg-[#222a3b] text-[#cbd5e1] text-xs font-semibold flex items-center justify-center space-x-2"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('reports.exportJson')}</span>
            </button>
          </div>
        </div>

        {/* Audit Trail Report */}
        <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="p-2 rounded-xl bg-emerald-950/50 border border-emerald-800/30 text-emerald-400 w-fit">
              <History className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white">
              Journal d'Audit & Sécurité ({locale})
            </h3>
            <p className="text-xs text-[#7e8c9e] leading-relaxed">
              Piste d'audit infalsifiable, identifiants de corrélation et horodatage certifié des opérations.
            </p>
          </div>

          <div className="space-y-2 pt-4 border-t border-[#1f2533]">
            <button
              onClick={handleDownloadAuditCSV}
              className="w-full py-2.5 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold flex items-center justify-center space-x-2 shadow"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('reports.exportCsv')}</span>
            </button>
            <button
              onClick={() => handleDownloadJSON('Audit_Trail', auditEvents)}
              className="w-full py-2.5 rounded-xl bg-[#1a202d] hover:bg-[#222a3b] text-[#cbd5e1] text-xs font-semibold flex items-center justify-center space-x-2"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('reports.exportJson')}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
