/**
 * SG Banking Systems - Enterprise Risk Management & Counterparty Limits View
 * Basel III Ratios, Liquidity Coverage Ratio (LCR), Counterparty Limits & Exposure Matrix
 */

import React from 'react';
import { 
  Activity, ShieldAlert, AlertTriangle, CheckCircle2, TrendingDown, Sliders
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';

export const RiskView: React.FC = () => {
  const { locale, t, formatCurrency } = useTranslation();
  const { riskLimits } = useBanking();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
          {t('nav.risk')} & Gestion des Risques Prudentiels
        </h1>
        <p className="text-xs text-[#828f9f] font-mono">
          Normes Bâle III • Ratios de Solvabilité CET1, Ratio de Liquidité LCR & Surveillance des Limites
        </p>
      </div>

      {/* Basel III Key Ratios */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">Ratio de Solvabilité CET1 (Core Tier 1)</div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            13.8%
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">Exigence réglementaire BCE: 9.75% (Coussin +4.05%)</div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">Ratio de Liquidité Court Terme (LCR)</div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            154.2%
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">Seuil minimum prudentiel: 100.0%</div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">Ratio de Levier Bâle III</div>
          <div className="text-2xl font-bold font-mono text-white">
            4.6%
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">Seuil minimum: 3.0%</div>
        </div>
      </div>

      {/* Counterparty Limits Matrix */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-red-400" />
            <span>{t('risk.counterpartyLimits')} & Exposition de Marché</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">CONTRÔLE PERMANENT</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                <th className="pb-3 font-semibold">Catégorie</th>
                <th className="pb-3 font-semibold">Contrepartie / Facteur de Risque</th>
                <th className="pb-3 font-semibold text-right">{t('risk.currentExposure')}</th>
                <th className="pb-3 font-semibold text-right">{t('risk.limitAmount')}</th>
                <th className="pb-3 font-semibold text-right">{t('risk.utilization')}</th>
                <th className="pb-3 font-semibold text-center">Statut Prudentiel</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b202c]">
              {riskLimits.map(r => {
                const isWarning = r.status === 'WARNING';
                return (
                  <tr key={r.id} className="hover:bg-[#161a25] transition-colors">
                    <td className="py-3 text-[#94a3b8]">{r.category}</td>
                    <td className="py-3 font-bold text-white font-sans">{r.counterpartyName}</td>
                    <td className="py-3 text-right font-bold text-white">
                      {formatCurrency(r.currentExposure.toFixed(2), r.currency)}
                    </td>
                    <td className="py-3 text-right text-[#94a3b8]">
                      {formatCurrency(r.limitAmount.toFixed(2), r.currency)}
                    </td>
                    <td className="py-3 text-right font-bold">
                      <span className={isWarning ? 'text-amber-400' : 'text-emerald-400'}>
                        {r.utilizationPercent.toFixed(1)}%
                      </span>
                    </td>
                    <td className="py-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        isWarning
                          ? 'bg-amber-950/60 text-amber-300 border border-amber-800/50'
                          : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50'
                      }`}>
                        {r.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
