/**
 * SG Banking Systems - French Regulated Savings (Livret A, LDD, Term Deposits)
 * Interest capitalization formula, annual interest projections, and transfer to current account
 */

import React, { useState } from 'react';
import { 
  PiggyBank, TrendingUp, ShieldCheck, ArrowRight, ArrowDownLeft, PlusCircle 
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';

export const SavingsView: React.FC = () => {
  const { locale, t, formatCurrency } = useTranslation();
  const { accounts, simulateDeposit } = useBanking();

  const savingsAcc = accounts.find(a => a.type === 'SAVINGS') || accounts[1];
  const balance = parseFloat(savingsAcc?.ledgerBalance || '0');
  const rate = savingsAcc?.interestRate || 0.03;

  const annualInterest = balance * rate;
  const monthlyInterest = annualInterest / 12;

  // 5-year projection
  const projections = [1, 2, 3, 5, 10].map(years => {
    const projected = balance * Math.pow(1 + rate, years);
    return { years, amount: projected, gain: projected - balance };
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
          {t('nav.savings')} & Épargne Réglementée
        </h1>
        <p className="text-xs text-[#828f9f] font-mono">
          Livret A Supérieur • Taux réglementé Banque de France net d'impôt et de prélèvements sociaux
        </p>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('account.balance')}</div>
          <div className="text-2xl font-bold font-mono text-white">
            {formatCurrency(balance.toFixed(2), 'EUR')}
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">Plafond légal: 22 950 € (Dépassé avec intérêts capitalisés)</div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">Rémunération Annuelle Nette</div>
          <div className="text-2xl font-bold font-mono text-blue-400">
            {(rate * 100).toFixed(2)}% net
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">Exonération totale IRPP & CSG/CRDS</div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">Intérêts Estimés au 31 Décembre</div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            +{formatCurrency(annualInterest.toFixed(2), 'EUR')} / an
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">Soit environ +{formatCurrency(monthlyInterest.toFixed(2), 'EUR')} / mois</div>
        </div>
      </div>

      {/* Projections Table */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
          <TrendingUp className="w-4 h-4 text-blue-400" />
          <span>Projection des Intérêts Composés Capitalisés</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                <th className="pb-3 font-semibold">Horizon de Placement</th>
                <th className="pb-3 font-semibold text-right">Capital Futur Projeté</th>
                <th className="pb-3 font-semibold text-right">Gain Cumulé Net</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b202c]">
              {projections.map(p => (
                <tr key={p.years} className="hover:bg-[#161a25] transition-colors">
                  <td className="py-3 text-white font-semibold">{p.years} an{p.years > 1 ? 's' : ''}</td>
                  <td className="py-3 text-right font-bold text-white">{formatCurrency(p.amount.toFixed(2), 'EUR')}</td>
                  <td className="py-3 text-right font-bold text-emerald-400">+{formatCurrency(p.gain.toFixed(2), 'EUR')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
