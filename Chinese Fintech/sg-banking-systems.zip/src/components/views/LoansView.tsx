/**
 * SG Banking Systems - French Mortgage & Loans Management View
 * Features real French loan amortisation schedules, early repayment simulator, and loan calculator
 */

import React, { useState } from 'react';
import { 
  Landmark, Calculator, Download, TrendingDown, Clock, ShieldCheck, 
  ChevronRight, Calendar, ArrowRight, CheckCircle2, Percent
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { LoanEngine } from '../../engine/loanEngine';
import { ReportGenerator } from '../../engine/reportGenerator';

export const LoansView: React.FC = () => {
  const { locale, t, formatCurrency, formatDate } = useTranslation();
  const { loans, simulateEarlyLoanRepayment } = useBanking();

  const [selectedLoanId, setSelectedLoanId] = useState<string>(loans[0]?.id || '');
  const [activeTab, setActiveTab] = useState<'DETAILS' | 'SCHEDULE' | 'EARLY_REPAYMENT' | 'SIMULATOR'>('DETAILS');

  // Early Repayment State
  const [earlyAmount, setEarlyAmount] = useState('25000');
  const [earlyOption, setEarlyOption] = useState<'REDUCE_TERM' | 'REDUCE_PAYMENT'>('REDUCE_TERM');
  const [repaymentSuccess, setRepaymentSuccess] = useState(false);

  // New Loan Calculator State
  const [calcPrincipal, setCalcPrincipal] = useState('300000');
  const [calcRate, setCalcRate] = useState('3.45');
  const [calcYears, setCalcYears] = useState('20');
  const [calcInsurance, setCalcInsurance] = useState('0.36');

  const selectedLoan = loans.find(l => l.id === selectedLoanId) || loans[0];

  // Simulator computed results
  const simPrincipal = parseFloat(calcPrincipal) || 0;
  const simRate = (parseFloat(calcRate) || 0) / 100;
  const simMonths = (parseInt(calcYears) || 0) * 12;
  const simInsRate = ((parseFloat(calcInsurance) || 0) / 100) / 12;

  const simMonthly = simMonths > 0 ? LoanEngine.calculateMonthlyPayment(simPrincipal, simRate, simMonths, simInsRate) : { principalAndInterest: '0', monthlyInsurance: '0', totalMonthlyPayment: '0', totalInterest: '0', totalCost: '0' };
  const simTotalInterest = (parseFloat(simMonthly.principalAndInterest) * simMonths) - simPrincipal;
  const simTotalInsurance = parseFloat(simMonthly.monthlyInsurance) * simMonths;

  const handleEarlyRepay = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedLoan && earlyAmount) {
      simulateEarlyLoanRepayment(selectedLoan.id, earlyAmount, earlyOption);
      setRepaymentSuccess(true);
      setTimeout(() => setRepaymentSuccess(false), 4000);
    }
  };

  const handleExportScheduleCSV = () => {
    if (!selectedLoan) return;
    const csv = ReportGenerator.generateLoanScheduleCSV(selectedLoan, locale);
    ReportGenerator.downloadFile(csv, `Tableau_Amortissement_${selectedLoan.contractNumber}_${locale}.csv`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
            {t('nav.loans')} & {t('loan.mortgage')}
          </h1>
          <p className="text-xs text-[#828f9f] font-mono">
            Tableau d'amortissement actuariel • Formule standard de rente certaine
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={handleExportScheduleCSV}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-[#171b26] hover:bg-[#202636] border border-[#273042] text-xs font-semibold text-[#cbd5e1] transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#94a3b8]" />
            <span>{t('loan.downloadSchedule')}</span>
          </button>
        </div>
      </div>

      {/* Main Loan Highlight Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('loan.outstandingPrincipal')}</div>
          <div className="text-2xl font-bold font-mono text-white">
            {formatCurrency(selectedLoan.outstandingPrincipal, 'EUR')}
          </div>
          <div className="text-[11px] text-[#616e82] font-mono mt-1">
            Capital initial: {formatCurrency(selectedLoan.initialPrincipal, 'EUR')}
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('loan.monthlyPayment')}</div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {formatCurrency(selectedLoan.monthlyPayment, 'EUR')}
          </div>
          <div className="text-[11px] text-[#616e82] font-mono mt-1">
            Assurance emprunteur incluse
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('loan.interestRate')} (Fixe)</div>
          <div className="text-2xl font-bold font-mono text-[#cbd5e1]">
            {(selectedLoan.annualInterestRate * 100).toFixed(2)}%
          </div>
          <div className="text-[11px] text-[#616e82] font-mono mt-1">
            TAEG: {((selectedLoan.annualInterestRate + selectedLoan.insuranceRate) * 100).toFixed(2)}%
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('loan.remainingTerm')}</div>
          <div className="text-2xl font-bold font-mono text-white">
            {selectedLoan.termMonths} mois
          </div>
          <div className="text-[11px] text-[#616e82] font-mono mt-1">
            Fin: {formatDate(selectedLoan.maturityDate)}
          </div>
        </div>
      </div>

      {/* Tabs & Workbench */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-6">
        {/* Tab Controls */}
        <div className="flex items-center space-x-2 bg-[#0e1017] p-1 rounded-xl border border-[#1f2533] w-fit flex-wrap">
          <button
            onClick={() => setActiveTab('DETAILS')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'DETAILS' ? 'bg-red-950/70 text-white border border-red-800/40' : 'text-[#8491a3] hover:text-white'
            }`}
          >
            Fiche Contrat & Garanties
          </button>
          <button
            onClick={() => setActiveTab('SCHEDULE')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'SCHEDULE' ? 'bg-red-950/70 text-white border border-red-800/40' : 'text-[#8491a3] hover:text-white'
            }`}
          >
            Échéancier Détaillé ({selectedLoan.schedule.length} mensualités)
          </button>
          <button
            onClick={() => setActiveTab('EARLY_REPAYMENT')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'EARLY_REPAYMENT' ? 'bg-red-950/70 text-white border border-red-800/40' : 'text-[#8491a3] hover:text-white'
            }`}
          >
            Simulateur Remboursement Anticipé
          </button>
          <button
            onClick={() => setActiveTab('SIMULATOR')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'SIMULATOR' ? 'bg-red-950/70 text-white border border-red-800/40' : 'text-[#8491a3] hover:text-white'
            }`}
          >
            Nouveau Projet de Crédit
          </button>
        </div>

        {/* Tab 1: Contract Details */}
        {activeTab === 'DETAILS' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
            <div className="p-5 rounded-xl bg-[#0e1017] border border-[#212737] space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-sans mb-3">
                Caractéristiques Prêt Immobilier
              </h3>
              <div className="flex justify-between pb-2 border-b border-[#1c2230]">
                <span className="text-[#6d798d]">N° Contrat SG:</span>
                <span className="text-white font-bold">{selectedLoan.contractNumber}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#1c2230]">
                <span className="text-[#6d798d]">Type de Prêt:</span>
                <span className="text-white">Prêt Amortissable Taux Fixe</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#1c2230]">
                <span className="text-[#6d798d]">Date de Déblocage des Fonds:</span>
                <span className="text-white">{formatDate(selectedLoan.startDate)}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#1c2230]">
                <span className="text-[#6d798d]">Prochaine Échéance:</span>
                <span className="text-emerald-400 font-bold">{formatDate(selectedLoan.nextPaymentDate)}</span>
              </div>
            </div>

            <div className="p-5 rounded-xl bg-[#0e1017] border border-[#212737] space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-sans mb-3">
                Garanties & Ratio LTV (Loan-to-Value)
              </h3>
              <div className="flex justify-between pb-2 border-b border-[#1c2230]">
                <span className="text-[#6d798d]">Valeur du Bien Immobilier:</span>
                <span className="text-white font-bold">{formatCurrency(selectedLoan.propertyValue || 0, 'EUR')}</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#1c2230]">
                <span className="text-[#6d798d]">Ratio LTV Actuel:</span>
                <span className="text-emerald-400 font-bold">{((selectedLoan.ltvRatio || 0) * 100).toFixed(1)}%</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#1c2230]">
                <span className="text-[#6d798d]">Organisme de Caution:</span>
                <span className="text-white">Crédit Logement France</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#1c2230]">
                <span className="text-[#6d798d]">Assurance Décès-Invalidité:</span>
                <span className="text-white">Sogécap Prévoyance</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Full Schedule */}
        {activeTab === 'SCHEDULE' && (
          <div className="overflow-x-auto max-h-[500px]">
            <table className="w-full text-left text-xs font-mono">
              <thead className="sticky top-0 bg-[#131620] border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                <tr>
                  <th className="pb-3 font-semibold">N°</th>
                  <th className="pb-3 font-semibold">{t('loan.dueDate')}</th>
                  <th className="pb-3 font-semibold text-right">{t('loan.monthlyPayment')}</th>
                  <th className="pb-3 font-semibold text-right">{t('loan.principal')}</th>
                  <th className="pb-3 font-semibold text-right">{t('loan.interest')}</th>
                  <th className="pb-3 font-semibold text-right">{t('loan.insurance')}</th>
                  <th className="pb-3 font-semibold text-right">{t('loan.remainingPrincipal')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b202c]">
                {selectedLoan.schedule.slice(0, 36).map(row => (
                  <tr key={row.installmentNumber} className="hover:bg-[#161a25] transition-colors">
                    <td className="py-2.5 text-[#738096]">#{row.installmentNumber}</td>
                    <td className="py-2.5 text-white">{formatDate(row.dueDate)}</td>
                    <td className="py-2.5 text-right font-bold text-white">
                      {formatCurrency(row.monthlyPayment, 'EUR')}
                    </td>
                    <td className="py-2.5 text-right text-emerald-400">
                      {formatCurrency(row.principalAmount, 'EUR')}
                    </td>
                    <td className="py-2.5 text-right text-amber-400">
                      {formatCurrency(row.interestAmount, 'EUR')}
                    </td>
                    <td className="py-2.5 text-right text-[#8896ab]">
                      {formatCurrency(row.insuranceAmount, 'EUR')}
                    </td>
                    <td className="py-2.5 text-right font-bold text-white">
                      {formatCurrency(row.remainingPrincipal, 'EUR')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab 3: Early Repayment Simulator */}
        {activeTab === 'EARLY_REPAYMENT' && (
          <div className="max-w-xl space-y-5">
            <div>
              <h3 className="text-sm font-bold text-white mb-1">
                Simulation de Remboursement Anticipé Partiel
              </h3>
              <p className="text-xs text-[#8c97ab]">
                Calculez l'impact d'un remboursement exceptionnel sur vos mensualités ou la durée de votre prêt.
              </p>
            </div>

            {repaymentSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-700/60 text-emerald-300 text-xs flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>Remboursement anticipé appliqué et nouveau tableau d'amortissement recalculé !</span>
              </div>
            )}

            <form onSubmit={handleEarlyRepay} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1.5">
                  Montant à rembourser (€)
                </label>
                <input
                  type="number"
                  step="1000"
                  value={earlyAmount}
                  onChange={(e) => setEarlyAmount(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-mono text-sm font-bold focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1.5">
                  Option de Restructuration
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setEarlyOption('REDUCE_TERM')}
                    className={`p-3 rounded-xl text-left border transition-all ${
                      earlyOption === 'REDUCE_TERM'
                        ? 'bg-red-950/60 border-red-700/60 text-white shadow'
                        : 'bg-[#0e1017] border-[#222836] text-[#7e8b9e]'
                    }`}
                  >
                    <div className="text-xs font-bold">Réduire la Durée</div>
                    <div className="text-[10px] mt-0.5 opacity-80">Garde la même mensualité, raccourcit le prêt</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setEarlyOption('REDUCE_PAYMENT')}
                    className={`p-3 rounded-xl text-left border transition-all ${
                      earlyOption === 'REDUCE_PAYMENT'
                        ? 'bg-red-950/60 border-red-700/60 text-white shadow'
                        : 'bg-[#0e1017] border-[#222836] text-[#7e8b9e]'
                    }`}
                  >
                    <div className="text-xs font-bold">Réduire la Mensualité</div>
                    <div className="text-[10px] mt-0.5 opacity-80">Garde la même durée, allège l'échéance</div>
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold uppercase tracking-wider shadow"
              >
                Appliquer le Remboursement & Recalculer
              </button>
            </form>
          </div>
        )}

        {/* Tab 4: New Loan Calculator */}
        {activeTab === 'SIMULATOR' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Montant du Financement (€)
                </label>
                <input
                  type="number"
                  value={calcPrincipal}
                  onChange={(e) => setCalcPrincipal(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-mono text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                    Taux d'Intérêt Annuel (%)
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    value={calcRate}
                    onChange={(e) => setCalcRate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                    Durée (Années)
                  </label>
                  <input
                    type="number"
                    value={calcYears}
                    onChange={(e) => setCalcYears(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-mono text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Taux Assurance Emprunteur (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={calcInsurance}
                  onChange={(e) => setCalcInsurance(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-mono text-sm"
                />
              </div>
            </div>

            <div className="p-6 rounded-xl bg-[#0e1017] border border-[#212737] space-y-4 font-mono">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-sans">
                Résultat Actuariel du Financement
              </h3>

              <div className="space-y-3 text-xs">
                <div className="flex justify-between">
                  <span className="text-[#6c788c]">Mensualité Totale (avec assurance):</span>
                  <span className="text-emerald-400 font-bold text-base">
                    {formatCurrency(simMonthly.totalMonthlyPayment, 'EUR')} / mois
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6c788c]">Dont Hors Assurance:</span>
                  <span className="text-white">{formatCurrency(simMonthly.principalAndInterest, 'EUR')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6c788c]">Dont Assurance Mensuelle:</span>
                  <span className="text-[#8896ab]">{formatCurrency(simMonthly.monthlyInsurance, 'EUR')}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-[#1c2230]">
                  <span className="text-[#6c788c]">Coût Total des Intérêts:</span>
                  <span className="text-amber-400 font-bold">{formatCurrency(simTotalInterest.toFixed(2), 'EUR')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6c788c]">Coût Total de l'Assurance:</span>
                  <span className="text-white">{formatCurrency(simTotalInsurance.toFixed(2), 'EUR')}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
