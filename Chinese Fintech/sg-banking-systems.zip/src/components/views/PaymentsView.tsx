/**
 * SG Banking Systems - SEPA & Instant Payments Studio
 * End-to-end payment pipeline: Validation -> Compliance/AML scan -> Authorization -> Settlement -> Ledger posting
 */

import React, { useState } from 'react';
import { 
  Send, UserCheck, ShieldCheck, AlertTriangle, CheckCircle2, 
  ArrowRight, PlusCircle, RefreshCw, Zap, Clock, FileText, Lock
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { Beneficiary, AMLAlert } from '../../types/domain';

export const PaymentsView: React.FC = () => {
  const { locale, t, formatCurrency, formatDate } = useTranslation();
  const { 
    accounts, selectedAccount, executePayment, beneficiaries, 
    addBeneficiary, transactions
  } = useBanking();

  // Payment Form State
  const [sourceAccountId, setSourceAccountId] = useState<string>(selectedAccount.id);
  const [selectedBeneficiaryId, setSelectedBeneficiaryId] = useState<string>(beneficiaries[0]?.id || 'CUSTOM');
  const [customIban, setCustomIban] = useState('');
  const [customBic, setCustomBic] = useState('SOGEFRPP');
  const [customName, setCustomName] = useState('');
  const [amount, setAmount] = useState('450.00');
  const [narrative, setNarrative] = useState('Virement SEPA — Règlement Facture');
  const [isInstant, setIsInstant] = useState(true);

  // Workflow Pipeline State
  const [step, setStep] = useState<'FORM' | 'CONFIRMATION' | 'PROCESSING' | 'SUCCESS' | 'BLOCKED'>('FORM');
  const [executionResult, setExecutionResult] = useState<{ message: string; alert?: AMLAlert } | null>(null);
  const [otpCode, setOtpCode] = useState('849201');

  // New Beneficiary Modal
  const [beneficiaryModalOpen, setBeneficiaryModalOpen] = useState(false);
  const [newBenName, setNewBenName] = useState('');
  const [newBenIban, setNewBenIban] = useState('');
  const [newBenBic, setNewBenBic] = useState('BNPAFRPP');
  const [newBenBank, setNewBenBank] = useState('BNP Paribas');

  const activeSourceAccount = accounts.find(a => a.id === sourceAccountId) || selectedAccount;
  const currentBeneficiary = beneficiaries.find(b => b.id === selectedBeneficiaryId);

  const destIban = selectedBeneficiaryId === 'CUSTOM' ? customIban : currentBeneficiary?.iban || '';
  const destBic = selectedBeneficiaryId === 'CUSTOM' ? customBic : currentBeneficiary?.bic || '';
  const destName = selectedBeneficiaryId === 'CUSTOM' ? customName : currentBeneficiary?.name || '';

  const handleStartPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destIban || !destName || !amount) return;
    setStep('CONFIRMATION');
  };

  const handleAuthorizeAndSettle = async () => {
    setStep('PROCESSING');

    try {
      const result = await executePayment({
        sourceAccountId: activeSourceAccount.id,
        destinationIban: destIban,
        destinationBic: destBic,
        beneficiaryName: destName,
        amount,
        narrative,
        isInstant,
      });

      setExecutionResult(result);
      if (result.success) {
        setStep('SUCCESS');
      } else {
        setStep('BLOCKED');
      }
    } catch (err: any) {
      setExecutionResult({ message: err.message || 'Erreur inattendue' });
      setStep('BLOCKED');
    }
  };

  const handleAddBeneficiary = (e: React.FormEvent) => {
    e.preventDefault();
    if (newBenName && newBenIban) {
      const created = addBeneficiary({
        name: newBenName,
        iban: newBenIban,
        bic: newBenBic,
        bankName: newBenBank,
        country: 'FR',
        currency: 'EUR',
        isTrusted: true,
        category: 'Nouveau Tiers',
      });
      setSelectedBeneficiaryId(created.id);
      setBeneficiaryModalOpen(false);
      setNewBenName('');
      setNewBenIban('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
            {t('payments.title')}
          </h1>
          <p className="text-xs text-[#828f9f] font-mono">
            SEPA Credit Transfer & SEPA Instant • Validation Tracfin automatique
          </p>
        </div>

        <button
          onClick={() => setBeneficiaryModalOpen(true)}
          className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-[#171b26] hover:bg-[#202636] border border-[#273042] text-xs font-semibold text-[#cbd5e1] transition-colors"
        >
          <PlusCircle className="w-3.5 h-3.5 text-red-400" />
          <span>{t('payments.addBeneficiary')}</span>
        </button>
      </div>

      {/* Main Container */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive Execution Wizard */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-[#131620] border border-[#242b3b] shadow-xl">
          {/* Step 1: Input Form */}
          {step === 'FORM' && (
            <form onSubmit={handleStartPayment} className="space-y-5">
              <div className="flex items-center space-x-2 pb-3 border-b border-[#212737] text-xs font-bold text-white uppercase tracking-wider">
                <Send className="w-4 h-4 text-red-400" />
                <span>1. Saisie de l'Ordre de Virement</span>
              </div>

              {/* Source Account Selector */}
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1.5">
                  {t('payments.sourceAccount')}
                </label>
                <select
                  value={sourceAccountId}
                  onChange={(e) => setSourceAccountId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white text-xs font-mono focus:outline-none focus:border-red-500"
                >
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name} — Solde Dispo: {formatCurrency(acc.availableBalance, acc.currency)} ({acc.iban})
                    </option>
                  ))}
                </select>
              </div>

              {/* Beneficiary Selector */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-[#8c97ab]">
                    {t('payments.beneficiary')}
                  </label>
                  <button
                    type="button"
                    onClick={() => setBeneficiaryModalOpen(true)}
                    className="text-[11px] text-red-400 hover:text-red-300 font-semibold"
                  >
                    + Nouveau Bénéficiaire
                  </button>
                </div>

                <select
                  value={selectedBeneficiaryId}
                  onChange={(e) => setSelectedBeneficiaryId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white text-xs font-mono focus:outline-none focus:border-red-500"
                >
                  {beneficiaries.map(ben => (
                    <option key={ben.id} value={ben.id}>
                      {ben.name} ({ben.bankName} • {ben.iban})
                    </option>
                  ))}
                  <option value="CUSTOM">Saisir un autre IBAN manuellement...</option>
                </select>
              </div>

              {/* Custom IBAN inputs if custom chosen */}
              {selectedBeneficiaryId === 'CUSTOM' && (
                <div className="p-4 rounded-xl bg-[#0e1017] border border-[#212737] space-y-3 font-mono text-xs">
                  <div>
                    <label className="text-[11px] text-[#717e92] block mb-1">Nom du Tiers Bénéficiaire</label>
                    <input
                      type="text"
                      placeholder="Ex: M. Jean Martin"
                      value={customName}
                      onChange={(e) => setCustomName(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#141722] border border-[#283244] text-white text-xs focus:outline-none focus:border-red-500"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-[#717e92] block mb-1">IBAN SEPA</label>
                      <input
                        type="text"
                        placeholder="FR76 ..."
                        value={customIban}
                        onChange={(e) => setCustomIban(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-[#141722] border border-[#283244] text-white text-xs focus:outline-none focus:border-red-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-[#717e92] block mb-1">BIC / SWIFT</label>
                      <input
                        type="text"
                        value={customBic}
                        onChange={(e) => setCustomBic(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg bg-[#141722] border border-[#283244] text-white text-xs focus:outline-none focus:border-red-500"
                        required
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Amount & Execution Speed */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-[#8c97ab] block mb-1.5">
                    {t('payments.amount')} ({activeSourceAccount.currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-mono text-sm font-bold focus:outline-none focus:border-red-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#8c97ab] block mb-1.5">
                    {t('payments.executionDate')}
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setIsInstant(true)}
                      className={`px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 border transition-all ${
                        isInstant
                          ? 'bg-red-950/60 border-red-700/60 text-white shadow-sm'
                          : 'bg-[#0e1017] border-[#222836] text-[#7e8b9e]'
                      }`}
                    >
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      <span>{t('payments.instantTransfer')} (10s)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setIsInstant(false)}
                      className={`px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 border transition-all ${
                        !isInstant
                          ? 'bg-red-950/60 border-red-700/60 text-white shadow-sm'
                          : 'bg-[#0e1017] border-[#222836] text-[#7e8b9e]'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5 text-[#8896ab]" />
                      <span>{t('payments.standardTransfer')} (J+1)</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Narrative / Motive */}
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1.5">
                  {t('payments.narrative')} (Motif du Virement)
                </label>
                <input
                  type="text"
                  value={narrative}
                  onChange={(e) => setNarrative(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white text-xs focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 shadow-lg shadow-red-950/40 transition-all"
                >
                  <span>Passer à la Vérification Prudentielle</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* Step 2: Confirmation & Dual Authentication */}
          {step === 'CONFIRMATION' && (
            <div className="space-y-5">
              <div className="flex items-center space-x-2 pb-3 border-b border-[#212737] text-xs font-bold text-white uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>2. Confirmation & Authentification Forte (DSP2 / 3DS)</span>
              </div>

              <div className="p-4 rounded-xl bg-[#0e1017] border border-[#212737] space-y-3 font-mono text-xs">
                <div className="flex justify-between">
                  <span className="text-[#727f94]">Compte Débiteur:</span>
                  <span className="text-white font-bold">{activeSourceAccount.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#727f94]">Bénéficiaire Créditeur:</span>
                  <span className="text-white font-bold">{destName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#727f94]">IBAN Destinataire:</span>
                  <span className="text-white font-bold tracking-wider">{destIban}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#727f94]">Montant du Virement:</span>
                  <span className="text-emerald-400 font-bold text-sm">
                    {formatCurrency(amount, activeSourceAccount.currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#727f94]">Type de Règlement:</span>
                  <span className="text-amber-400 font-bold">
                    {isInstant ? 'SEPA INSTANT (Règlement temps réel)' : 'SEPA STANDARD (Compensation J+1)'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#727f94]">Frais de Réseau:</span>
                  <span className="text-white font-bold">0.00 EUR (Inclus)</span>
                </div>
              </div>

              {/* Passcode Simulation */}
              <div className="p-4 rounded-xl bg-[#171b26] border border-[#273042] space-y-2">
                <div className="flex items-center space-x-2 text-xs font-semibold text-white">
                  <Lock className="w-3.5 h-3.5 text-red-400" />
                  <span>Validation Sécurité Pass SG Mobile</span>
                </div>
                <p className="text-[11px] text-[#808ea3]">
                  Code de sécurité envoyé sur votre terminal certifié : <strong className="font-mono text-white">849 201</strong>
                </p>
                <input
                  type="text"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  className="w-36 px-3 py-1.5 rounded-lg bg-[#0e1017] border border-[#313b4e] text-white font-mono text-sm tracking-widest text-center"
                />
              </div>

              <div className="flex items-center space-x-3 pt-2">
                <button
                  onClick={() => setStep('FORM')}
                  className="flex-1 py-2.5 rounded-xl bg-[#1a202d] hover:bg-[#222a3b] text-[#8c97ab] text-xs font-semibold hover:text-white transition-colors"
                >
                  {t('common.cancel')}
                </button>
                <button
                  onClick={handleAuthorizeAndSettle}
                  className="flex-1 py-2.5 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-2 shadow-lg shadow-red-950/40"
                >
                  <span>Autoriser & Comptabiliser</span>
                  <CheckCircle2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Processing Animation */}
          {step === 'PROCESSING' && (
            <div className="py-12 flex flex-col items-center justify-center space-y-4 text-center">
              <RefreshCw className="w-8 h-8 text-red-500 animate-spin" />
              <div>
                <h3 className="text-sm font-bold text-white">Exécution du Virement en Cours...</h3>
                <p className="text-xs text-[#7e8c9f] font-mono mt-1">
                  1. Contrôle Tracfin • 2. Écritures Grand Livre • 3. Débit Compensation SEPA
                </p>
              </div>
            </div>
          )}

          {/* Step 4: Success Result */}
          {step === 'SUCCESS' && (
            <div className="py-6 space-y-5 text-center">
              <div className="w-12 h-12 rounded-full bg-emerald-950/60 border border-emerald-700/60 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>

              <div>
                <h2 className="text-lg font-bold text-white">Virement Comptabilisé avec Succès</h2>
                <p className="text-xs text-[#808ea3] mt-1">{executionResult?.message}</p>
              </div>

              <div className="p-4 rounded-xl bg-[#0e1017] border border-[#1e2433] max-w-md mx-auto text-left font-mono text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#6d798d]">Statut Règlement:</span>
                  <span className="text-emerald-400 font-semibold">SETTLED & POSTED</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6d798d]">Nouveau Solde Débiteur:</span>
                  <span className="text-white font-bold">
                    {formatCurrency(activeSourceAccount.ledgerBalance, activeSourceAccount.currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6d798d]">Grand Livre:</span>
                  <span className="text-white font-semibold">Débit & Crédit équilibrés (Partie Double)</span>
                </div>
              </div>

              <div className="flex items-center justify-center space-x-3 pt-2">
                <button
                  onClick={() => {
                    setAmount('100.00');
                    setStep('FORM');
                  }}
                  className="px-5 py-2.5 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold shadow"
                >
                  Effectuer un Nouveau Virement
                </button>
              </div>
            </div>
          )}

          {/* Step 5: AML / Compliance Blocked */}
          {step === 'BLOCKED' && (
            <div className="py-6 space-y-5 text-center">
              <div className="w-12 h-12 rounded-full bg-red-950/60 border border-red-700/60 text-red-400 flex items-center justify-center mx-auto">
                <AlertTriangle className="w-6 h-6" />
              </div>

              <div>
                <h2 className="text-lg font-bold text-white">Virement Suspendu — Alerte Conformité</h2>
                <p className="text-xs text-[#808ea3] mt-1">{executionResult?.message}</p>
              </div>

              {executionResult?.alert && (
                <div className="p-4 rounded-xl bg-red-950/20 border border-red-800/40 max-w-md mx-auto text-left font-mono text-xs space-y-2">
                  <div className="flex justify-between">
                    <span className="text-red-300">Alerte ID:</span>
                    <span className="text-white font-semibold">{executionResult.alert.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-red-300">Score de Risque AML:</span>
                    <span className="text-amber-400 font-bold">{executionResult.alert.riskScore} / 100</span>
                  </div>
                  <div className="text-[11px] text-red-200 mt-1">
                    {executionResult.alert.ruleDescription[locale]}
                  </div>
                </div>
              )}

              <button
                onClick={() => setStep('FORM')}
                className="px-5 py-2.5 rounded-xl bg-[#1a202d] text-white text-xs font-bold"
              >
                Retour au Formulaire
              </button>
            </div>
          )}
        </div>

        {/* Right 1 Col: Saved Beneficiaries Directory */}
        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#212737]">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              {t('payments.savedBeneficiaries')} ({beneficiaries.length})
            </h3>
          </div>

          <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
            {beneficiaries.map(ben => (
              <div
                key={ben.id}
                onClick={() => {
                  setSelectedBeneficiaryId(ben.id);
                  setStep('FORM');
                }}
                className={`p-3 rounded-xl border transition-all cursor-pointer ${
                  selectedBeneficiaryId === ben.id
                    ? 'bg-red-950/40 border-red-800/50 text-white'
                    : 'bg-[#10121a] hover:bg-[#161a25] border-[#1e2330] text-[#8c97ab]'
                }`}
              >
                <div className="flex items-center justify-between text-xs font-semibold mb-1">
                  <span className="text-white truncate">{ben.name}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#1e2434] text-[#a0aec0]">
                    {ben.bankName}
                  </span>
                </div>
                <div className="text-[11px] font-mono text-[#6d798d] truncate">{ben.iban}</div>
                <div className="text-[10px] text-[#556275] mt-1">{ben.category}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Add Beneficiary Modal */}
      {beneficiaryModalOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#131620] rounded-2xl border border-[#2b3347] p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">
              {t('payments.addBeneficiary')}
            </h3>
            <p className="text-xs text-[#8c97ab] mb-4">
              Enregistrement d'un nouveau tiers SEPA certifié avec contrôle automatique de clé IBAN.
            </p>

            <form onSubmit={handleAddBeneficiary} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Nom ou Raison Sociale
                </label>
                <input
                  type="text"
                  placeholder="Ex: Société Civile Haussmann"
                  value={newBenName}
                  onChange={(e) => setNewBenName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#273042] text-white text-xs focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  IBAN International
                </label>
                <input
                  type="text"
                  placeholder="FR76 ..."
                  value={newBenIban}
                  onChange={(e) => setNewBenIban(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#273042] text-white font-mono text-xs focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                    Code BIC / SWIFT
                  </label>
                  <input
                    type="text"
                    value={newBenBic}
                    onChange={(e) => setNewBenBic(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#273042] text-white font-mono text-xs focus:outline-none focus:border-red-500"
                    required
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                    Banque Domiciliataire
                  </label>
                  <input
                    type="text"
                    value={newBenBank}
                    onChange={(e) => setNewBenBank(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#273042] text-white text-xs focus:outline-none focus:border-red-500"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setBeneficiaryModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#1a202d] text-[#8c97ab] text-xs font-semibold hover:text-white"
                >
                  {t('common.cancel')}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold shadow"
                >
                  Enregistrer le Bénéficiaire
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
