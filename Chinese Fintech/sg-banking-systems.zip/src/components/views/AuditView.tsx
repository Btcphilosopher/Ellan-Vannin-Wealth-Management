/**
 * SG Banking Systems - Immutable Audit Trail & SecOps Activity Log
 * Cryptographic correlation IDs, tamper-evident action recording, and compliance export
 */

import React, { useState } from 'react';
import { 
  History, Search, ShieldCheck, Download, Filter, CheckCircle2, Lock 
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { ReportGenerator } from '../../engine/reportGenerator';

export const AuditView: React.FC = () => {
  const { locale, t, formatDate } = useTranslation();
  const { auditEvents } = useBanking();

  const [search, setSearch] = useState('');

  const filteredEvents = auditEvents.filter(e => 
    e.action.toLowerCase().includes(search.toLowerCase()) ||
    e.userName.toLowerCase().includes(search.toLowerCase()) ||
    e.reason.toLowerCase().includes(search.toLowerCase()) ||
    e.correlationId.toLowerCase().includes(search.toLowerCase())
  );

  const handleExportCSV = () => {
    const csv = ReportGenerator.generateAuditLogCSV(auditEvents, locale);
    ReportGenerator.downloadFile(csv, `Journal_Audit_${locale}.csv`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
            {t('nav.audit')} & Journal des Événements
          </h1>
          <p className="text-xs text-[#828f9f] font-mono">
            Piste d'audit infalsifiable • Enregistrement non répudiable avec ID de corrélation
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={handleExportCSV}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-[#171b26] hover:bg-[#202636] border border-[#273042] text-xs font-semibold text-[#cbd5e1] transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#94a3b8]" />
            <span>{t('reports.exportCsv')}</span>
          </button>
        </div>
      </div>

      {/* Audit Log Table Container */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <Lock className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Événements de Sécurité & Opérations Enregistrées ({filteredEvents.length})
            </span>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#677387]" />
            <input
              type="text"
              placeholder="Rechercher par action, utilisateur ou corrélation..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-8 pr-3 py-1.5 rounded-lg bg-[#0e1017] border border-[#222938] text-xs text-white focus:outline-none focus:border-red-500 font-mono w-64 sm:w-80"
            />
          </div>
        </div>

        <div className="overflow-x-auto max-h-[550px]">
          <table className="w-full text-left text-xs font-mono">
            <thead className="sticky top-0 bg-[#131620] border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
              <tr>
                <th className="pb-3 font-semibold">Horodatage</th>
                <th className="pb-3 font-semibold">Utilisateur & Rôle</th>
                <th className="pb-3 font-semibold">Action & Entité</th>
                <th className="pb-3 font-semibold">Motif / Justification</th>
                <th className="pb-3 font-semibold">Correlation ID</th>
                <th className="pb-3 font-semibold text-center">Statut</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b202c]">
              {filteredEvents.map(e => (
                <tr key={e.id} className="hover:bg-[#161a25] transition-colors">
                  <td className="py-3 text-[#94a3b8]">
                    {new Date(e.timestamp).toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </td>
                  <td className="py-3">
                    <div className="font-bold text-white font-sans">{e.userName}</div>
                    <div className="text-[10px] text-[#707d92]">{e.userRole}</div>
                  </td>
                  <td className="py-3">
                    <span className="font-semibold text-red-400">{e.action}</span>
                    <div className="text-[10px] text-[#637082]">{e.entityType} • {e.entityId}</div>
                  </td>
                  <td className="py-3 text-white font-sans text-xs max-w-xs">{e.reason}</td>
                  <td className="py-3 text-[#707d92] text-[11px]">{e.correlationId}</td>
                  <td className="py-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      e.status === 'SUCCESS' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40' : 'bg-red-950/60 text-red-300 border border-red-800/40'
                    }`}>
                      {e.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
