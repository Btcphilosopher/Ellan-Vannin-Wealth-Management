/**
 * SG Banking Systems - French Bank Cards Management (Visa Infinite / Premier)
 * Card physical/virtual toggles: Contactless, Online 3DS, Foreign currency payments, ATM limits, Card lock
 */

import React, { useState } from 'react';
import { 
  CreditCard, ShieldCheck, Lock, Unlock, Eye, EyeOff, 
  Wifi, Globe, Smartphone, Sliders, AlertCircle, CheckCircle2
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { Card } from '../../types/domain';

export const CardsView: React.FC = () => {
  const { locale, t, formatCurrency } = useTranslation();
  const { cards, updateCardSettings } = useBanking();

  const [selectedCardId, setSelectedCardId] = useState<string>(cards[0]?.id || '');
  const [showFullDetails, setShowFullDetails] = useState(false);

  const selectedCard = cards.find(c => c.id === selectedCardId) || cards[0];

  const handleToggle = (key: keyof Card) => {
    if (!selectedCard) return;
    const currentVal = selectedCard[key];
    updateCardSettings(selectedCard.id, { [key]: !currentVal });
  };

  const handleToggleFreeze = () => {
    if (!selectedCard) return;
    const newStatus = selectedCard.status === 'ACTIVE' ? 'FROZEN' : 'ACTIVE';
    updateCardSettings(selectedCard.id, { status: newStatus });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
          {t('cards.title')}
        </h1>
        <p className="text-xs text-[#828f9f] font-mono">
          Cartes Bancaires Visa Infinite & Premier • Gestion des plafonds et sécurité temps réel
        </p>
      </div>

      {/* Cards List / Selector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Card Visual & Selector */}
        <div className="space-y-4">
          {cards.map(card => {
            const isSelected = card.id === selectedCardId;
            const isFrozen = card.status === 'FROZEN';

            return (
              <div
                key={card.id}
                onClick={() => setSelectedCardId(card.id)}
                className={`p-6 rounded-2xl cursor-pointer transition-all relative overflow-hidden shadow-2xl ${
                  isSelected
                    ? 'ring-2 ring-red-500 scale-[1.01]'
                    : 'opacity-70 hover:opacity-100'
                } ${
                  card.cardBrand === 'VISA_INFINITE'
                    ? 'bg-gradient-to-br from-[#1a1c24] via-[#0d0e12] to-[#050608] border border-[#333b4d]'
                    : 'bg-gradient-to-br from-[#785b1a] via-[#483710] to-[#1e1707] border border-[#967425]'
                }`}
              >
                {/* Visual Card Chip & Hologram */}
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center space-x-2">
                    <div className="w-10 h-7 rounded bg-gradient-to-tr from-amber-300 to-amber-100 border border-amber-400 flex items-center justify-center">
                      <div className="w-5 h-4 border border-amber-800/40 rounded-sm"></div>
                    </div>
                    <Wifi className="w-4 h-4 text-white/60 rotate-90" />
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-mono font-bold tracking-widest text-white/90">
                      SOCIÉTÉ GÉNÉRALE
                    </span>
                  </div>
                </div>

                {/* Card Number */}
                <div className="font-mono text-lg font-bold tracking-widest text-white mb-6">
                  {showFullDetails ? '4970 8821 3491 4821' : card.cardNumberMasked}
                </div>

                {/* Card Holder & Expiry */}
                <div className="flex items-end justify-between text-xs font-mono">
                  <div>
                    <div className="text-[9px] text-white/60 uppercase">Titulaire</div>
                    <div className="font-bold text-white tracking-wider">{card.cardHolder}</div>
                  </div>

                  <div className="text-right">
                    <div className="text-[9px] text-white/60 uppercase">Expire Fin</div>
                    <div className="font-bold text-white">{card.expiryDate}</div>
                  </div>
                </div>

                {/* Frozen Overlay */}
                {isFrozen && (
                  <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center space-x-2 text-red-400 font-bold font-mono text-xs">
                    <Lock className="w-4 h-4" />
                    <span>CARTE VERROUILLÉE</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Right 2 Cols: Card Controls & Limits */}
        <div className="lg:col-span-2 space-y-6">
          {/* Spending Limits Card */}
          <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-red-400" />
              <span>{t('card.spendingLimit')} & Consommation Mensuelle</span>
            </h3>

            <div>
              <div className="flex justify-between text-xs font-mono mb-2">
                <span className="text-[#7e8b9f]">Plafond de Paiement (30 jours glissants):</span>
                <span className="text-white font-bold">
                  {formatCurrency(selectedCard.currentSpend, 'EUR')} / {formatCurrency(selectedCard.monthlySpendLimit, 'EUR')}
                </span>
              </div>
              <div className="w-full h-2 rounded-full bg-[#0e1017] overflow-hidden border border-[#1f2533]">
                <div
                  className="h-full bg-red-500 rounded-full"
                  style={{
                    width: `${Math.min(100, (parseFloat(selectedCard.currentSpend) / parseFloat(selectedCard.monthlySpendLimit)) * 100)}%`
                  }}
                ></div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between text-xs font-mono text-[#828f9f]">
              <span>Plafond Retrait DAB: <strong className="text-white">2 500 € / 7 jours</strong></span>
              <button
                onClick={handleToggleFreeze}
                className={`px-3 py-1.5 rounded-lg font-semibold flex items-center space-x-1.5 border transition-all ${
                  selectedCard.status === 'FROZEN'
                    ? 'bg-emerald-950/60 border-emerald-700/60 text-emerald-300'
                    : 'bg-red-950/60 border-red-700/60 text-red-300'
                }`}
              >
                {selectedCard.status === 'FROZEN' ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                <span>{selectedCard.status === 'FROZEN' ? 'Débloquer la Carte' : 'Bloquer Temporairement'}</span>
              </button>
            </div>
          </div>

          {/* Security & Feature Toggles */}
          <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              {t('card.cardSecurity')} & Options d'Utilisation
            </h3>

            <div className="divide-y divide-[#1d2330]">
              {/* Contactless */}
              <div className="py-3 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-[#191e2b] text-red-400">
                    <Wifi className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">{t('card.contactless')}</div>
                    <div className="text-[11px] text-[#717e92]">Paiements sans contact jusqu'à 50 € par transaction</div>
                  </div>
                </div>

                <button
                  onClick={() => handleToggle('contactlessEnabled')}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    selectedCard.contactlessEnabled ? 'bg-emerald-500' : 'bg-[#222838]'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    selectedCard.contactlessEnabled ? 'right-1' : 'left-1'
                  }`}></div>
                </button>
              </div>

              {/* Online Payments */}
              <div className="py-3 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-[#191e2b] text-red-400">
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">{t('card.onlinePayments')}</div>
                    <div className="text-[11px] text-[#717e92]">Achats e-commerce sécurisés par Pass Sécurité 3D-Secure</div>
                  </div>
                </div>

                <button
                  onClick={() => handleToggle('onlinePaymentsEnabled')}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    selectedCard.onlinePaymentsEnabled ? 'bg-emerald-500' : 'bg-[#222838]'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    selectedCard.onlinePaymentsEnabled ? 'right-1' : 'left-1'
                  }`}></div>
                </button>
              </div>

              {/* Foreign Payments */}
              <div className="py-3 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-[#191e2b] text-red-400">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">{t('card.foreignPayments')}</div>
                    <div className="text-[11px] text-[#717e92]">Utilisation hors zone Euro & devises étrangères</div>
                  </div>
                </div>

                <button
                  onClick={() => handleToggle('foreignPaymentsEnabled')}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    selectedCard.foreignPaymentsEnabled ? 'bg-emerald-500' : 'bg-[#222838]'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    selectedCard.foreignPaymentsEnabled ? 'right-1' : 'left-1'
                  }`}></div>
                </button>
              </div>

              {/* ATM Withdrawals */}
              <div className="py-3 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-lg bg-[#191e2b] text-red-400">
                    <CreditCard className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">{t('card.atmWithdrawals')}</div>
                    <div className="text-[11px] text-[#717e92]">Retraits aux distributeurs automatiques de billets</div>
                  </div>
                </div>

                <button
                  onClick={() => handleToggle('atmWithdrawalEnabled')}
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    selectedCard.atmWithdrawalEnabled ? 'bg-emerald-500' : 'bg-[#222838]'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    selectedCard.atmWithdrawalEnabled ? 'right-1' : 'left-1'
                  }`}></div>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
