/**
 * SG Banking Systems - Private Banking & Wealth Management View
 * Portfolios, Asset allocation, Securities holdings, and interactive live order execution
 */

import React, { useState } from 'react';
import { 
  Briefcase, TrendingUp, PieChart, ShoppingBag, ArrowUpRight, ArrowDownLeft,
  Download, CheckCircle2, RefreshCw
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { Portfolio, Security } from '../../types/domain';

export const WealthView: React.FC = () => {
  const { locale, t, formatCurrency } = useTranslation();
  const { portfolios, securities, tradeSecurity, currentUser } = useBanking();

  const userPortfolio = portfolios.find(p => p.customerId === currentUser.customerId) || portfolios[0];

  // Trade Modal State
  const [tradeModalOpen, setTradeModalOpen] = useState(false);
  const [tradeType, setTradeType] = useState<'BUY' | 'SELL'>('BUY');
  const [selectedIsin, setSelectedIsin] = useState(securities[0]?.isin || '');
  const [tradeQuantity, setTradeQuantity] = useState('10');
  const [tradeFeedback, setTradeFeedback] = useState<string | null>(null);

  const activeSecurity = securities.find(s => s.isin === selectedIsin) || securities[0];
  const orderTotal = (parseInt(tradeQuantity) || 0) * (activeSecurity?.lastPrice || 0);

  const handleExecuteTrade = (e: React.FormEvent) => {
    e.preventDefault();
    const qty = parseInt(tradeQuantity);
    if (qty > 0 && selectedIsin) {
      const ok = tradeSecurity(userPortfolio.id, selectedIsin, qty, tradeType);
      if (ok) {
        setTradeFeedback(`Ordre de ${tradeType === 'BUY' ? 'Achat' : 'Vente'} de ${qty} titres exécuté avec succès.`);
        setTimeout(() => {
          setTradeFeedback(null);
          setTradeModalOpen(false);
        }, 2000);
      } else {
        setTradeFeedback(`Échec de l'ordre: Solde d'espèces ou quantité insuffisante.`);
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
            {t('wealth.title')} & Banque Privée
          </h1>
          <p className="text-xs text-[#828f9f] font-mono">
            Mandat de Gestion SG Horizon • Valorisation en temps réel et passage d'ordres
          </p>
        </div>

        <button
          onClick={() => setTradeModalOpen(true)}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold shadow-md shadow-red-950/40 transition-all"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>Passer un Ordre de Bourse</span>
        </button>
      </div>

      {/* Main KPI Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('wealth.totalValuation')}</div>
          <div className="text-2xl font-bold font-mono text-white">
            {formatCurrency(userPortfolio.totalMarketValue, userPortfolio.currency)}
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">
            Prix de revient global: {formatCurrency(userPortfolio.totalCostBasis, userPortfolio.currency)}
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('wealth.unrealizedPnL')}</div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            +{formatCurrency(userPortfolio.unrealizedPnL, userPortfolio.currency)}
          </div>
          <div className="text-[11px] text-emerald-400 font-mono mt-1">
            +{(userPortfolio.unrealizedPnLPercent * 100).toFixed(2)}% de plus-value latente
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('wealth.cashAvailable')}</div>
          <div className="text-2xl font-bold font-mono text-white">
            {formatCurrency(userPortfolio.cashBalance, userPortfolio.currency)}
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">
            Disponible pour investissement immédiat
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">Nombre de Lignes en Portefeuille</div>
          <div className="text-2xl font-bold font-mono text-[#cbd5e1]">
            {userPortfolio.positions.length} actifs
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">
            Actions (58%), Obligations (24%), ETFs (11%)
          </div>
        </div>
      </div>

      {/* Asset Allocation & Positions Table */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
          <span>{t('wealth.holdings')}</span>
          <span className="text-[11px] text-[#717e92] font-mono font-normal">Cours Euronext Paris (J+0)</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                <th className="pb-3 font-semibold">Instrument & ISIN</th>
                <th className="pb-3 font-semibold">Classe d'Actif</th>
                <th className="pb-3 font-semibold text-right">Quantité</th>
                <th className="pb-3 font-semibold text-right">PRU (€)</th>
                <th className="pb-3 font-semibold text-right">Dernier Cours</th>
                <th className="pb-3 font-semibold text-right">Valorisation</th>
                <th className="pb-3 font-semibold text-right">Plus/Moins-Value</th>
                <th className="pb-3 font-semibold text-right">Poids</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b202c]">
              {userPortfolio.positions.map(pos => {
                const isPositive = pos.unrealizedPnL >= 0;
                return (
                  <tr key={pos.id} className="hover:bg-[#161a25] transition-colors">
                    <td className="py-3">
                      <div className="font-bold text-white font-sans">{pos.security.name}</div>
                      <div className="text-[10px] text-[#6d798d]">{pos.security.isin} • {pos.security.ticker}</div>
                    </td>
                    <td className="py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-[#181d29] text-[#93a0b5] border border-[#252c3d]">
                        {pos.security.assetClass}
                      </span>
                    </td>
                    <td className="py-3 text-right font-bold text-white">{pos.quantity}</td>
                    <td className="py-3 text-right text-[#94a3b8]">{pos.averageCostBasis.toFixed(2)} €</td>
                    <td className="py-3 text-right font-bold text-white">{pos.currentPrice.toFixed(2)} €</td>
                    <td className="py-3 text-right font-bold text-white">{formatCurrency(pos.marketValue, 'EUR')}</td>
                    <td className={`py-3 text-right font-bold ${isPositive ? 'text-emerald-400' : 'text-red-400'}`}>
                      {isPositive ? '+' : ''}{formatCurrency(pos.unrealizedPnL, 'EUR')} ({isPositive ? '+' : ''}{(pos.unrealizedPnLPercent * 100).toFixed(1)}%)
                    </td>
                    <td className="py-3 text-right text-[#cbd5e1] font-semibold">{pos.weightPercent.toFixed(1)}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Trade Modal */}
      {tradeModalOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#131620] rounded-2xl border border-[#2b3347] p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-1">
              Passage d'Ordre de Bourse Euronext
            </h3>
            <p className="text-xs text-[#8c97ab] mb-4">
              Exécution au marché avec débit/crédit immédiat du compte espèces.
            </p>

            {tradeFeedback && (
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-700/60 text-emerald-300 text-xs mb-4">
                {tradeFeedback}
              </div>
            )}

            <form onSubmit={handleExecuteTrade} className="space-y-4">
              {/* Buy / Sell Toggle */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-[#0e1017] rounded-xl border border-[#222838]">
                <button
                  type="button"
                  onClick={() => setTradeType('BUY')}
                  className={`py-2 rounded-lg text-xs font-bold transition-all ${
                    tradeType === 'BUY' ? 'bg-emerald-600 text-white' : 'text-[#7e8b9f]'
                  }`}
                >
                  ACHAT (BUY)
                </button>
                <button
                  type="button"
                  onClick={() => setTradeType('SELL')}
                  className={`py-2 rounded-lg text-xs font-bold transition-all ${
                    tradeType === 'SELL' ? 'bg-red-600 text-white' : 'text-[#7e8b9f]'
                  }`}
                >
                  VENTE (SELL)
                </button>
              </div>

              {/* Security Selector */}
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Instrument Financier
                </label>
                <select
                  value={selectedIsin}
                  onChange={(e) => setSelectedIsin(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#0e1017] border border-[#273042] text-white text-xs font-mono"
                >
                  {securities.map(s => (
                    <option key={s.isin} value={s.isin}>
                      {s.name} ({s.ticker}) — Cours: {s.lastPrice} EUR
                    </option>
                  ))}
                </select>
              </div>

              {/* Quantity */}
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Quantité de Titres
                </label>
                <input
                  type="number"
                  min="1"
                  value={tradeQuantity}
                  onChange={(e) => setTradeQuantity(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#0e1017] border border-[#273042] text-white font-mono text-sm font-bold"
                  required
                />
              </div>

              {/* Order Estimation */}
              <div className="p-3 rounded-xl bg-[#0e1017] border border-[#202636] font-mono text-xs space-y-1">
                <div className="flex justify-between text-[#727f92]">
                  <span>Montant Estimé de l'Ordre:</span>
                  <span className="text-white font-bold">{formatCurrency(orderTotal.toFixed(2), 'EUR')}</span>
                </div>
                <div className="flex justify-between text-[#727f92]">
                  <span>Frais de Courtage SG:</span>
                  <span className="text-emerald-400 font-bold">0.00 EUR</span>
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setTradeModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#1a202d] text-[#8c97ab] text-xs font-semibold hover:text-white"
                >
                  {t('common.cancel')}
                </button>
                <button
                  type="submit"
                  className={`px-4 py-2 rounded-lg text-white text-xs font-bold shadow ${
                    tradeType === 'BUY' ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-red-600 hover:bg-red-500'
                  }`}
                >
                  Confirmer l'Ordre
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
