/**
 * SG Banking Systems - Financial Markets & FX Desk View
 * Live Market Tickers, European Benchmark Equities, Yield Curves, and FX Spot Matrix
 */

import React, { useState } from 'react';
import { 
  TrendingUp, ArrowUpRight, ArrowDownLeft, RefreshCw, DollarSign, 
  Binary, Activity, BarChart2, Globe
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { FXEngine } from '../../engine/fxEngine';
import { Currency } from '../../types/domain';

export const MarketsView: React.FC = () => {
  const { locale, t, formatCurrency } = useTranslation();
  const { securities, fxRates, yieldCurve } = useBanking();

  // Quick FX Converter State
  const [convAmount, setConvAmount] = useState('100000');
  const [fromCurr, setFromCurr] = useState<Currency>('EUR');
  const [toCurr, setToCurr] = useState<Currency>('USD');

  const convertedResult = FXEngine.convert(convAmount, fromCurr, toCurr, fxRates);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
          {t('nav.markets')} & {t('fx.title')}
        </h1>
        <p className="text-xs text-[#828f9f] font-mono">
          Salle des Marchés SG • Cours Euronext Paris, Matrice de Change FX Spot & Courbe des Taux Souverains
        </p>
      </div>

      {/* FX Spot Matrix & Live Converter Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: FX Spot Rates Matrix */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Globe className="w-4 h-4 text-emerald-400" />
              <span>{t('fx.spotRates')} (Marché Interbancaire)</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-mono">STREAMING ACTIF</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                  <th className="pb-3 font-semibold">{t('fx.pair')}</th>
                  <th className="pb-3 font-semibold text-right">{t('fx.bid')} (Achat)</th>
                  <th className="pb-3 font-semibold text-right">{t('fx.ask')} (Vente)</th>
                  <th className="pb-3 font-semibold text-right">Cours Médian</th>
                  <th className="pb-3 font-semibold text-right">{t('fx.variation')} (24h)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b202c]">
                {fxRates.map(f => (
                  <tr key={f.pair} className="hover:bg-[#161a25] transition-colors">
                    <td className="py-3 font-bold text-white">{f.pair}</td>
                    <td className="py-3 text-right text-[#cbd5e1]">{f.bid.toFixed(4)}</td>
                    <td className="py-3 text-right text-[#cbd5e1]">{f.ask.toFixed(4)}</td>
                    <td className="py-3 text-right font-bold text-white">{f.mid.toFixed(4)}</td>
                    <td className={`py-3 text-right font-bold ${f.change24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {f.change24h >= 0 ? '+' : ''}{f.change24h}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 1 Col: Institutional FX Conversion Calculator */}
        <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4 font-mono">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider font-sans">
            Calculateur de Conversion FX
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-[#808ea3] block mb-1">Montant à convertir</label>
              <input
                type="number"
                value={convAmount}
                onChange={(e) => setConvAmount(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#252d3e] text-white font-bold"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[#808ea3] block mb-1">De (Devise Source)</label>
                <select
                  value={fromCurr}
                  onChange={(e) => setFromCurr(e.target.value as Currency)}
                  className="w-full px-2.5 py-2 rounded-lg bg-[#0e1017] border border-[#252d3e] text-white"
                >
                  <option value="EUR">EUR (€)</option>
                  <option value="USD">USD ($)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="CHF">CHF</option>
                  <option value="JPY">JPY (¥)</option>
                </select>
              </div>

              <div>
                <label className="text-[#808ea3] block mb-1">Vers (Devise Cible)</label>
                <select
                  value={toCurr}
                  onChange={(e) => setToCurr(e.target.value as Currency)}
                  className="w-full px-2.5 py-2 rounded-lg bg-[#0e1017] border border-[#252d3e] text-white"
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="CHF">CHF</option>
                  <option value="JPY">JPY (¥)</option>
                </select>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#0e1017] border border-[#1f2533] space-y-2 mt-4">
              <div className="text-[#728094] text-[11px]">Montant Converti Net:</div>
              <div className="text-xl font-bold text-emerald-400">
                {convertedResult.convertedAmount} {toCurr}
              </div>
              <div className="text-[10px] text-[#556275]">
                Taux appliqué: 1 {fromCurr} = {convertedResult.rateUsed} {toCurr}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* French Sovereign Yield Curve (Courbe des OAT) */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="w-4 h-4 text-blue-400" />
            <span>{t('markets.yieldCurve')} (OAT France Benchmark)</span>
          </div>
          <span className="text-[11px] text-[#717e92] font-mono font-normal">Source: Agence France Trésor</span>
        </h3>

        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-3">
          {yieldCurve.map(pt => (
            <div key={pt.tenor} className="p-3 rounded-xl bg-[#0e1017] border border-[#1f2533] text-center font-mono">
              <div className="text-[10px] text-[#6b778c] font-bold">{pt.tenor}</div>
              <div className="text-sm font-bold text-white mt-1">{pt.yield.toFixed(2)}%</div>
              <div className={`text-[10px] mt-1 ${pt.changeBps >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                {pt.changeBps >= 0 ? '+' : ''}{pt.changeBps} bps
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* European Equities & Indices */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider">
          Actions de Référence & Grandes Valeurs Européennes
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {securities.slice(0, 4).map(s => (
            <div key={s.isin} className="p-4 rounded-xl bg-[#0e1017] border border-[#1f2533] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-white truncate">{s.name}</span>
                <span className={`font-mono font-bold ${s.change24h >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {s.change24h >= 0 ? '+' : ''}{s.change24h}%
                </span>
              </div>
              <div className="text-lg font-bold font-mono text-white">
                {s.lastPrice.toFixed(2)} {s.currency}
              </div>
              <div className="text-[10px] text-[#637082] font-mono truncate">
                {s.isin} • {s.sector}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
