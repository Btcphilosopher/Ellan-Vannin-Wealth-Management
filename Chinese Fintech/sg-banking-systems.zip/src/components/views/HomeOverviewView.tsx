/**
 * SG Banking Systems - Home Customer Banking Overview View
 * Implements full French & English customer overview with live linked accounts, cards, loans, wealth
 */

import React, { useState } from 'react';
import { 
  Wallet, CreditCard, Landmark, Briefcase, ArrowUpRight, ArrowDownLeft, 
  Download, Send, PlusCircle, ShieldCheck, ChevronRight, FileText, CheckCircle2
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';

interface HomeOverviewViewProps {
  onNavigate: (view: string) => void;
}

export const HomeOverviewView: React.FC<HomeOverviewViewProps> = ({ onNavigate }) => {
  const { locale, t, formatCurrency, formatDate } = useTranslation();
  const { 
    currentUser, accounts, cards, loans, portfolios, transactions,
    simulateDeposit 
  } = useBanking();

  const [depositModalOpen, setDepositModalOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState('1500');
  const [depositNarrative, setDepositNarrative] = useState('Dépôt de chèque / Virement externe');

  // Filter accounts for current user
  const userAccounts = accounts.filter(a => a.customerId === currentUser.customerId || a.customerId === currentUser.organizationId);
  const currentAccount = userAccounts.find(a => a.type === 'CURRENT') || accounts[0];
  const savingsAccount = userAccounts.find(a => a.type === 'SAVINGS');
  const userCards = cards.filter(c => c.accountId === currentAccount.id);
  const primaryCard = userCards[0] || cards[0];
  const userLoans = loans.filter(l => l.customerId === currentUser.customerId);
  const primaryLoan = userLoans[0] || loans[0];
  const userPortfolio = portfolios.find(p => p.customerId === currentUser.customerId) || portfolios[0];

  const recentTxs = transactions.slice(0, 5);

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (depositAmount && currentAccount) {
      simulateDeposit(currentAccount.id, depositAmount, depositNarrative);
      setDepositModalOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner with Greeting */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#171b26] via-[#141722] to-[#0f1118] border border-[#262d3e] shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-80 bg-gradient-to-l from-red-950/20 to-transparent pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center space-x-2 text-xs font-mono text-red-400 mb-1">
              <span>{t('dashboard.overview')}</span>
              <span>•</span>
              <span className="text-[#8896ab]">{currentUser.personaTitle[locale]}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white font-sans tracking-tight">
              {t('dashboard.greeting')}, {currentUser.name.split(' ')[0]}
            </h1>
          </div>

          {/* Action pills */}
          <div className="flex items-center space-x-2.5 flex-wrap">
            <button
              onClick={() => onNavigate('payments')}
              className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold transition-all shadow-md shadow-red-950/40"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{t('dashboard.makeTransfer')}</span>
            </button>

            <button
              onClick={() => setDepositModalOpen(true)}
              className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-[#1a202d] hover:bg-[#222a3b] border border-[#2f384d] text-xs font-semibold text-[#cbd5e1] transition-all"
            >
              <PlusCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t('account.simulateDeposit')}</span>
            </button>

            <button
              onClick={() => onNavigate('reports')}
              className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-[#1a202d] hover:bg-[#222a3b] border border-[#2f384d] text-xs font-semibold text-[#cbd5e1] transition-all"
            >
              <Download className="w-3.5 h-3.5 text-[#94a3b8]" />
              <span>{t('dashboard.downloadStatement')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main 4 Metric Grid (Accounts, Cards, Loans, Wealth) */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* Current Account */}
        <div 
          onClick={() => onNavigate('accounts')}
          className="p-5 rounded-xl bg-[#131620] hover:bg-[#181c28] border border-[#242b3b] hover:border-[#3b465e] transition-all cursor-pointer group shadow-sm"
        >
          <div className="flex items-center justify-between text-xs text-[#7e8b9f] mb-3">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 rounded-lg bg-red-950/50 border border-red-800/30 text-red-400">
                <Wallet className="w-4 h-4" />
              </div>
              <span className="font-semibold text-white">{t('account.current')}</span>
            </div>
            <ChevronRight className="w-4 h-4 text-[#59657b] group-hover:text-white transition-colors" />
          </div>

          <div className="text-2xl font-bold font-mono text-white tracking-tight">
            {formatCurrency(currentAccount.ledgerBalance, currentAccount.currency)}
          </div>

          <div className="mt-2 text-xs text-[#7e8b9f] flex items-center justify-between font-mono">
            <span>{t('account.availableBalance')}:</span>
            <span className="text-emerald-400 font-semibold">
              {formatCurrency(currentAccount.availableBalance, currentAccount.currency)}
            </span>
          </div>
        </div>

        {/* Savings Account */}
        {savingsAccount && (
          <div 
            onClick={() => onNavigate('savings')}
            className="p-5 rounded-xl bg-[#131620] hover:bg-[#181c28] border border-[#242b3b] hover:border-[#3b465e] transition-all cursor-pointer group shadow-sm"
          >
            <div className="flex items-center justify-between text-xs text-[#7e8b9f] mb-3">
              <div className="flex items-center space-x-2">
                <div className="p-1.5 rounded-lg bg-blue-950/50 border border-blue-800/30 text-blue-400">
                  <Wallet className="w-4 h-4" />
                </div>
                <span className="font-semibold text-white">{t('account.savings')}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#59657b] group-hover:text-white transition-colors" />
            </div>

            <div className="text-2xl font-bold font-mono text-white tracking-tight">
              {formatCurrency(savingsAccount.ledgerBalance, savingsAccount.currency)}
            </div>

            <div className="mt-2 text-xs text-[#7e8b9f] flex items-center justify-between font-mono">
              <span>{t('account.interestRate')}:</span>
              <span className="text-blue-400 font-semibold">
                {(savingsAccount.interestRate * 100).toFixed(2)}% net
              </span>
            </div>
          </div>
        )}

        {/* Primary Card */}
        {primaryCard && (
          <div 
            onClick={() => onNavigate('cards')}
            className="p-5 rounded-xl bg-[#131620] hover:bg-[#181c28] border border-[#242b3b] hover:border-[#3b465e] transition-all cursor-pointer group shadow-sm"
          >
            <div className="flex items-center justify-between text-xs text-[#7e8b9f] mb-3">
              <div className="flex items-center space-x-2">
                <div className="p-1.5 rounded-lg bg-amber-950/50 border border-amber-800/30 text-amber-400">
                  <CreditCard className="w-4 h-4" />
                </div>
                <span className="font-semibold text-white">Carte Visa</span>
              </div>
              <span className="font-mono text-xs text-white">{primaryCard.cardNumberMasked}</span>
            </div>

            <div className="text-xs text-[#7e8b9f]">{t('card.spendingLimit')}</div>
            <div className="text-xl font-bold font-mono text-white tracking-tight mt-0.5">
              {formatCurrency(primaryCard.currentSpend, 'EUR')} / {formatCurrency(primaryCard.monthlySpendLimit, 'EUR')}
            </div>

            <div className="mt-2 text-[11px] text-emerald-400 flex items-center space-x-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Paiement Sans Contact Activé</span>
            </div>
          </div>
        )}

        {/* Mortgage / Loan */}
        {primaryLoan && (
          <div 
            onClick={() => onNavigate('loans')}
            className="p-5 rounded-xl bg-[#131620] hover:bg-[#181c28] border border-[#242b3b] hover:border-[#3b465e] transition-all cursor-pointer group shadow-sm"
          >
            <div className="flex items-center justify-between text-xs text-[#7e8b9f] mb-3">
              <div className="flex items-center space-x-2">
                <div className="p-1.5 rounded-lg bg-purple-950/50 border border-purple-800/30 text-purple-400">
                  <Landmark className="w-4 h-4" />
                </div>
                <span className="font-semibold text-white">{t('loan.mortgage')}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#59657b] group-hover:text-white transition-colors" />
            </div>

            <div className="text-2xl font-bold font-mono text-white tracking-tight">
              {formatCurrency(primaryLoan.outstandingPrincipal, 'EUR')}
            </div>

            <div className="mt-2 text-xs text-[#7e8b9f] flex items-center justify-between font-mono">
              <span>{t('loan.monthlyPayment')}:</span>
              <span className="text-white font-semibold">
                {formatCurrency(primaryLoan.monthlyPayment, 'EUR')}
              </span>
            </div>
          </div>
        )}

        {/* Wealth Portfolio */}
        {userPortfolio && (
          <div 
            onClick={() => onNavigate('wealth')}
            className="p-5 rounded-xl bg-[#131620] hover:bg-[#181c28] border border-[#242b3b] hover:border-[#3b465e] transition-all cursor-pointer group shadow-sm"
          >
            <div className="flex items-center justify-between text-xs text-[#7e8b9f] mb-3">
              <div className="flex items-center space-x-2">
                <div className="p-1.5 rounded-lg bg-emerald-950/50 border border-emerald-800/30 text-emerald-400">
                  <Briefcase className="w-4 h-4" />
                </div>
                <span className="font-semibold text-white">{t('wealth.title')}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#59657b] group-hover:text-white transition-colors" />
            </div>

            <div className="text-2xl font-bold font-mono text-white tracking-tight">
              {formatCurrency(userPortfolio.totalMarketValue, userPortfolio.currency)}
            </div>

            <div className="mt-2 text-xs text-emerald-400 flex items-center justify-between font-mono">
              <span>{t('wealth.unrealizedPnL')}:</span>
              <span className="font-semibold">
                +{formatCurrency(userPortfolio.unrealizedPnL, userPortfolio.currency)} (+{(userPortfolio.unrealizedPnLPercent * 100).toFixed(1)}%)
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Transactions & Account Details Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Operations */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-[#131620] border border-[#242b3b]">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#212737]">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider font-sans">
              {t('dashboard.recentOperations')}
            </h2>
            <button
              onClick={() => onNavigate('accounts')}
              className="text-xs text-red-400 hover:text-red-300 font-semibold transition-colors"
            >
              Voir Tout ({transactions.length})
            </button>
          </div>

          <div className="space-y-2.5">
            {recentTxs.map((tx) => {
              const isCredit = tx.destinationAccountId === currentAccount.id;
              return (
                <div
                  key={tx.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-[#10121a] hover:bg-[#171b26] border border-[#1e2330] transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${isCredit ? 'bg-emerald-950/40 text-emerald-400' : 'bg-red-950/40 text-red-400'}`}>
                      {isCredit ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-white">
                        {tx.counterpartyName}
                      </div>
                      <div className="text-[11px] text-[#788599] font-mono">
                        {tx.narrative} • {formatDate(tx.bookingDate)}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className={`text-xs font-bold font-mono ${isCredit ? 'text-emerald-400' : 'text-white'}`}>
                      {isCredit ? '+' : '-'}{formatCurrency(tx.amount, tx.currency)}
                    </div>
                    <div className="text-[10px] text-[#6b7688] font-mono">
                      Réf: {tx.reference}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Account Details & IBAN card */}
        <div className="space-y-4">
          <div className="p-5 rounded-xl bg-[#131620] border border-[#242b3b]">
            <h3 className="text-xs font-bold text-[#8c97aa] uppercase tracking-wider mb-3">
              {t('account.iban')} & BIC / SWIFT
            </h3>

            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 rounded-lg bg-[#0e1017] border border-[#1e2332]">
                <div className="text-[10px] text-[#667285] mb-1">IBAN (FRANCE)</div>
                <div className="text-white font-semibold tracking-wider select-all">
                  {currentAccount.iban}
                </div>
              </div>

              <div className="p-3 rounded-lg bg-[#0e1017] border border-[#1e2332]">
                <div className="text-[10px] text-[#667285] mb-1">CODE BIC / SWIFT</div>
                <div className="text-white font-semibold tracking-wider">
                  {currentAccount.bic} (SOCIÉTÉ GÉNÉRALE PARIS)
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-[#1e2433] flex items-center justify-between text-[11px] text-[#79869c]">
              <span>Titulaire:</span>
              <span className="text-white font-semibold">{currentUser.name}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Deposit Simulation Modal */}
      {depositModalOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#131620] rounded-2xl border border-[#2b3347] p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">
              {t('account.simulateDeposit')}
            </h3>
            <p className="text-xs text-[#8c97ab] mb-4">
              Simule l'encaissement d'un virement ou dépôt d'espèces avec génération immédiate des écritures en partie double.
            </p>

            <form onSubmit={handleDepositSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Montant en Euros (€)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#273042] text-white font-mono text-sm focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Libellé Comptable
                </label>
                <input
                  type="text"
                  value={depositNarrative}
                  onChange={(e) => setDepositNarrative(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#273042] text-white text-xs focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setDepositModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#1a202d] text-[#8c97ab] text-xs font-semibold hover:text-white"
                >
                  {t('common.cancel')}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold shadow"
                >
                  Comptabiliser le Dépôt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
