/**
 * SG Banking Systems - 3-Way Reconciliation & Clearing Engine View
 * Matches Core General Ledger vs Payment Gateways (SEPA/SWIFT) vs Settlement Clearing
 */

import React, { useState } from 'react';
import { 
  GitCompare, RefreshCw, CheckCircle2, AlertTriangle, 
  FileText, ArrowRight, ShieldCheck 
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';

export const ReconciliationView: React.FC = () => {
  const { locale, t, formatCurrency, formatDate } = useTranslation();
  const { 
    reconciliationItems, runReconciliationBatch, resolveReconciliationItem, 
    transactions 
  } = useBanking();

  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [resolutionComment, setResolutionComment] = useState('Écart de frais régularisé au compte de charges.');

  const matched = reconciliationItems.filter(i => i.status === 'MATCHED' || i.status === 'RESOLVED').length;
  const exceptions = reconciliationItems.filter(i => i.status === 'EXCEPTION').length;

  const handleRunBatch = () => {
    runReconciliationBatch();
  };

  const handleResolve = (id: string) => {
    resolveReconciliationItem(id, resolutionComment);
    setResolvingId(null);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
            {t('nav.reconciliation')} 3-Voies (3-Way Matching)
          </h1>
          <p className="text-xs text-[#828f9f] font-mono">
            Lettrage automatisé : Grand Livre Core ↔ Processeur STEP2/SEPA ↔ Compensation TARGET2
          </p>
        </div>

        <button
          onClick={handleRunBatch}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold shadow-md shadow-red-950/40 transition-all"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>{t('reconciliation.runBatch')}</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('reconciliation.matched')} (Lettrées à 100%)</div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {matched} écritures
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">Concordance parfaite des montants</div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('reconciliation.exceptions')} (Écarts / Suspens)</div>
          <div className="text-2xl font-bold font-mono text-amber-400">
            {exceptions} suspens
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">Écarts de frais ou décalages de date de valeur</div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">Taux d'Automatisation STP</div>
          <div className="text-2xl font-bold font-mono text-white">
            99.4%
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">Straight-Through Processing sans intervention</div>
        </div>
      </div>

      {/* Reconciliation Table */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider">
          Journal de Rapprochement & Lettrage Comptable
        </h3>

        {reconciliationItems.length === 0 ? (
          <div className="py-12 text-center text-xs text-[#717e92] font-mono space-y-3">
            <p>Aucun batch de rapprochement exécuté pour cette session.</p>
            <button
              onClick={handleRunBatch}
              className="px-4 py-2 rounded-xl bg-red-950/50 hover:bg-red-900/60 border border-red-800/40 text-red-200 text-xs font-bold"
            >
              Lancer le Rapprochement Automatique Maintenant
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                  <th className="pb-3 font-semibold">Réf. Grand Livre</th>
                  <th className="pb-3 font-semibold">Réf. Compensation TARGET2</th>
                  <th className="pb-3 font-semibold text-right">Montant GL</th>
                  <th className="pb-3 font-semibold text-right">Montant Compensé</th>
                  <th className="pb-3 font-semibold text-right">Écart</th>
                  <th className="pb-3 font-semibold text-center">Statut Lettrage</th>
                  <th className="pb-3 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b202c]">
                {reconciliationItems.map(item => {
                  const isEx = item.status === 'EXCEPTION';
                  return (
                    <tr key={item.id} className="hover:bg-[#161a25] transition-colors">
                      <td className="py-3 text-red-400 font-semibold">{item.ledgerTransactionId}</td>
                      <td className="py-3 text-[#94a3b8]">{item.settlementBatchId}</td>
                      <td className="py-3 text-right font-bold text-white">
                        {formatCurrency(item.amountLedger, item.currency)}
                      </td>
                      <td className="py-3 text-right text-[#cbd5e1]">
                        {formatCurrency(item.amountSettled, item.currency)}
                      </td>
                      <td className="py-3 text-right font-bold">
                        <span className={isEx ? 'text-amber-400' : 'text-emerald-400'}>
                          {item.variance} {item.currency}
                        </span>
                      </td>
                      <td className="py-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isEx ? 'bg-amber-950/60 text-amber-300 border border-amber-800/50' : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/50'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        {isEx ? (
                          <button
                            onClick={() => setResolvingId(item.id)}
                            className="text-[11px] font-semibold text-red-400 hover:text-red-300"
                          >
                            Régulariser...
                          </button>
                        ) : (
                          <span className="text-[10px] text-[#556275]">Lettré ✓</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Resolve Exception Modal */}
      {resolvingId && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#131620] rounded-2xl border border-[#2b3347] p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">
              Régularisation d'Écart de Rapprochement
            </h3>
            <p className="text-xs text-[#8c97ab] mb-4">
              Justification comptable de la régularisation de l'écart.
            </p>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Motif d'Écriture de Régularisation
                </label>
                <input
                  type="text"
                  value={resolutionComment}
                  onChange={(e) => setResolutionComment(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#273042] text-white text-xs"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setResolvingId(null)}
                  className="px-4 py-2 rounded-lg bg-[#1a202d] text-[#8c97ab] text-xs font-semibold hover:text-white"
                >
                  {t('common.cancel')}
                </button>
                <button
                  type="button"
                  onClick={() => handleResolve(resolvingId)}
                  className="px-4 py-2 rounded-lg bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold shadow"
                >
                  Valider la Régularisation
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
