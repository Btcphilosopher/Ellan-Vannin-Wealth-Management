/**
 * SG Banking Systems - Compliance, AML Transaction Monitoring & KYC Lifecycle View
 * Tracfin alerts surveillance, SAR escalation, and client identity verification dossiers
 */

import React, { useState } from 'react';
import { 
  ShieldAlert, UserCheck, AlertTriangle, CheckCircle2, 
  FileText, Search, Filter, ShieldCheck, ChevronRight
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { AMLAlert, KYCProfile } from '../../types/domain';

export const ComplianceView: React.FC = () => {
  const { locale, t, formatCurrency, formatDate } = useTranslation();
  const { amlAlerts, updateAmlAlertStatus, kycProfiles, currentUser } = useBanking();

  const [activeTab, setActiveTab] = useState<'AML_ALERTS' | 'KYC_PROFILES'>('AML_ALERTS');
  const [selectedAlertId, setSelectedAlertId] = useState<string | null>(amlAlerts[0]?.id || null);
  const [analystNotes, setAnalystNotes] = useState('');

  const selectedAlert = amlAlerts.find(a => a.id === selectedAlertId);

  const handleResolveAlert = (status: AMLAlert['status']) => {
    if (selectedAlert) {
      updateAmlAlertStatus(selectedAlert.id, status, analystNotes);
      setAnalystNotes('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
          {t('nav.compliance')} & Surveillance AML / Tracfin
        </h1>
        <p className="text-xs text-[#828f9f] font-mono">
          Détection de blanchiment d'argent, gel des avoirs & conformité KYC/Loi Sapin II
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 bg-[#0e1017] p-1 rounded-xl border border-[#1f2533] w-fit">
        <button
          onClick={() => setActiveTab('AML_ALERTS')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'AML_ALERTS'
              ? 'bg-red-950/70 text-white border border-red-800/40 shadow-sm'
              : 'text-[#8491a3] hover:text-white'
          }`}
        >
          {t('compliance.amlAlerts')} ({amlAlerts.length})
        </button>
        <button
          onClick={() => setActiveTab('KYC_PROFILES')}
          className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'KYC_PROFILES'
              ? 'bg-red-950/70 text-white border border-red-800/40 shadow-sm'
              : 'text-[#8491a3] hover:text-white'
          }`}
        >
          {t('compliance.kycStatus')} ({kycProfiles.length})
        </button>
      </div>

      {/* Tab 1: AML Alerts */}
      {activeTab === 'AML_ALERTS' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Alerts List */}
          <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider pb-2 border-b border-[#212737]">
              Alertes de Surveillance ({amlAlerts.length})
            </h3>

            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {amlAlerts.map(alert => {
                const isSelected = alert.id === selectedAlertId;
                const isCritical = alert.severity === 'CRITICAL';
                return (
                  <div
                    key={alert.id}
                    onClick={() => setSelectedAlertId(alert.id)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-red-950/50 border-red-700 text-white shadow-md'
                        : 'bg-[#0e1017] hover:bg-[#161a25] border-[#1f2533] text-[#8c97ab]'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-semibold mb-1">
                      <span className="truncate">{alert.customerName}</span>
                      <span className={`px-1.5 py-0.2 rounded text-[9px] font-mono font-bold ${
                        isCritical ? 'bg-red-950 text-red-300 border border-red-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        {alert.severity}
                      </span>
                    </div>

                    <div className="text-[11px] font-mono text-white font-bold">
                      {formatCurrency(alert.amount, alert.currency)}
                    </div>

                    <div className="text-[10px] text-[#6d7a8e] mt-1 truncate">
                      Score Risque: <strong className="text-amber-400">{alert.riskScore}/100</strong> • Statut: {alert.status}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Alert Investigation Dossier */}
          <div className="lg:col-span-2 p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
            {selectedAlert ? (
              <div className="space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-[#212737]">
                  <div>
                    <h3 className="text-sm font-bold text-white">
                      Dossier d'Investigation : {selectedAlert.id}
                    </h3>
                    <div className="text-xs text-[#707d92] font-mono">
                      Règle: {selectedAlert.ruleTriggered}
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-[#191e2b] text-white text-xs font-mono font-bold border border-[#2a3346]">
                    {selectedAlert.status}
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-[#0e1017] border border-[#212737] space-y-3 font-mono text-xs">
                  <div className="flex justify-between">
                    <span className="text-[#6d798d]">Client / Tiers Cible:</span>
                    <span className="text-white font-bold">{selectedAlert.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#6d798d]">Montant en Cause:</span>
                    <span className="text-emerald-400 font-bold">
                      {formatCurrency(selectedAlert.amount, selectedAlert.currency)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#6d798d]">Score de Risque Algorithmique:</span>
                    <span className="text-red-400 font-bold text-sm">{selectedAlert.riskScore} / 100</span>
                  </div>
                  <div className="pt-2 border-t border-[#1c2230] text-white font-sans text-xs">
                    {selectedAlert.ruleDescription[locale]}
                  </div>
                </div>

                {/* Analyst resolution actions */}
                <div className="space-y-3 pt-2">
                  <label className="text-xs font-semibold text-[#8c97ab] block">
                    Commentaire de l'Analyste Conformité
                  </label>
                  <textarea
                    rows={2}
                    value={analystNotes}
                    onChange={(e) => setAnalystNotes(e.target.value)}
                    placeholder="Saisissez la justification de la décision d'analyse..."
                    className="w-full p-3 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white text-xs focus:outline-none focus:border-red-500"
                  />

                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => handleResolveAlert('DISMISSED')}
                      className="flex-1 py-2.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/70 border border-emerald-700/60 text-emerald-300 text-xs font-bold"
                    >
                      Classer sans Suite (Faux Positif)
                    </button>
                    <button
                      onClick={() => handleResolveAlert('ESCALATED')}
                      className="flex-1 py-2.5 rounded-xl bg-red-950/70 hover:bg-red-900/80 border border-red-700/70 text-red-200 text-xs font-bold"
                    >
                      Déclarer à Tracfin (Déclaration de Soupçon)
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-[#717e92]">
                Sélectionnez une alerte pour afficher le dossier d'analyse.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: KYC Profiles */}
      {activeTab === 'KYC_PROFILES' && (
        <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            Dossiers d'Identification Client (KYC - Know Your Customer)
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                  <th className="pb-3 font-semibold">Client</th>
                  <th className="pb-3 font-semibold">Type</th>
                  <th className="pb-3 font-semibold">Nationalité & Résidence</th>
                  <th className="pb-3 font-semibold">Niveau de Risque</th>
                  <th className="pb-3 font-semibold">Dernière Revue</th>
                  <th className="pb-3 font-semibold text-center">Statut KYC</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b202c]">
                {kycProfiles.map(k => (
                  <tr key={k.id} className="hover:bg-[#161a25] transition-colors">
                    <td className="py-3 font-bold text-white font-sans">{k.customerName}</td>
                    <td className="py-3 text-[#94a3b8]">{k.type}</td>
                    <td className="py-3 text-[#cbd5e1]">{k.taxResidency}</td>
                    <td className="py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950/50 text-emerald-300 border border-emerald-800/40">
                        {k.riskLevel}
                      </span>
                    </td>
                    <td className="py-3 text-[#94a3b8]">{formatDate(k.reviewDate)}</td>
                    <td className="py-3 text-center">
                      <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-950/60 text-emerald-300 border border-emerald-700/50">
                        {k.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
