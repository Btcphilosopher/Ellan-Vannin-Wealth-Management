/**
 * SG Banking Systems - Accounts & Core General Ledger View
 * Shows double-entry balance, ledger entries, booking vs value dates, and search filters
 */

import React, { useState } from 'react';
import { 
  Wallet, ArrowDownLeft, ArrowUpRight, Search, Filter, Download, 
  PlusCircle, CheckCircle2, ShieldAlert, Calendar, RefreshCw
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { Account } from '../../types/domain';
import { ReportGenerator } from '../../engine/reportGenerator';

interface AccountsViewProps {
  onNavigate?: (view: string) => void;
}

export const AccountsView: React.FC<AccountsViewProps> = ({ onNavigate }) => {
  const { locale, t, formatCurrency, formatDate } = useTranslation();
  const { 
    accounts, selectedAccountId, setSelectedAccountId, selectedAccount,
    ledgerEntries, transactions, simulateDeposit, ledgerVerification, verifyLedgerNow
  } = useBanking();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'DEBIT' | 'CREDIT'>('ALL');
  const [activeTab, setActiveTab] = useState<'OPERATIONS' | 'LEDGER_ENTRIES' | 'RIB'>('OPERATIONS');
  const [depositModalOpen, setDepositModalOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState('2500');
  const [depositNarrative, setDepositNarrative] = useState('Dépôt / Virement reçu externe');

  // Filter transactions for selected account
  const accountTransactions = transactions.filter(
    tx => tx.sourceAccountId === selectedAccount.id || tx.destinationAccountId === selectedAccount.id
  );

  const filteredTransactions = accountTransactions.filter(tx => {
    const matchesSearch = 
      tx.counterpartyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.narrative.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tx.reference.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (!matchesSearch) return false;

    if (filterType === 'DEBIT') return tx.sourceAccountId === selectedAccount.id;
    if (filterType === 'CREDIT') return tx.destinationAccountId === selectedAccount.id;
    return true;
  });

  // Filter ledger entries for selected account
  const accountLedgerEntries = ledgerEntries.filter(e => e.accountId === selectedAccount.id);

  const handleDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (depositAmount) {
      simulateDeposit(selectedAccount.id, depositAmount, depositNarrative);
      setDepositModalOpen(false);
    }
  };

  const handleExportCSV = () => {
    const csv = ReportGenerator.generateAccountStatementCSV(selectedAccount, accountTransactions, locale);
    ReportGenerator.downloadFile(csv, `Releve_${selectedAccount.accountNumber.replace(/\s+/g, '_')}_${locale}.csv`);
  };

  return (
    <div className="space-y-6">
      {/* Header & Account Selection bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
            {t('nav.accounts')} & {t('ledger.title')}
          </h1>
          <p className="text-xs text-[#828f9f] font-mono">
            Modèle comptable en partie double • Solde calculé en temps réel
          </p>
        </div>

        <div className="flex items-center space-x-2.5 flex-wrap">
          <button
            onClick={() => setDepositModalOpen(true)}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-red-950/40 hover:bg-red-900/50 border border-red-800/40 text-xs font-semibold text-red-200 transition-colors shadow-sm"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>{t('account.simulateDeposit')}</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-[#171b26] hover:bg-[#202636] border border-[#273042] text-xs font-semibold text-[#cbd5e1] transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#94a3b8]" />
            <span>{t('reports.exportCsv')}</span>
          </button>
        </div>
      </div>

      {/* Account Pills Switcher */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2">
        {accounts.map(acc => {
          const isSelected = acc.id === selectedAccountId;
          return (
            <button
              key={acc.id}
              onClick={() => setSelectedAccountId(acc.id)}
              className={`px-4 py-2.5 rounded-xl text-left font-mono transition-all flex-shrink-0 border ${
                isSelected
                  ? 'bg-gradient-to-r from-red-950/70 to-[#191e2b] border-red-700/60 text-white shadow-md'
                  : 'bg-[#12141c] hover:bg-[#181c28] border-[#222736] text-[#8e9aa8]'
              }`}
            >
              <div className="text-xs font-semibold flex items-center space-x-2">
                <span className="truncate max-w-[180px]">{acc.name}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-black/40 text-[#a0aec0]">
                  {acc.currency}
                </span>
              </div>
              <div className="text-sm font-bold mt-1 text-white">
                {formatCurrency(acc.ledgerBalance, acc.currency)}
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Account Overview Card */}
      <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 divide-y md:divide-y-0 md:divide-x divide-[#212838]">
          {/* Ledger Balance */}
          <div className="pb-3 md:pb-0 md:pr-4">
            <div className="text-xs text-[#7e8b9f] font-medium mb-1">{t('account.balance')}</div>
            <div className="text-2xl font-bold font-mono text-white">
              {formatCurrency(selectedAccount.ledgerBalance, selectedAccount.currency)}
            </div>
            <div className="text-[11px] text-[#637082] font-mono mt-1">
              Solde officiel issu du Grand Livre
            </div>
          </div>

          {/* Available Balance */}
          <div className="py-3 md:py-0 md:px-4">
            <div className="text-xs text-[#7e8b9f] font-medium mb-1">{t('account.availableBalance')}</div>
            <div className="text-2xl font-bold font-mono text-emerald-400">
              {formatCurrency(selectedAccount.availableBalance, selectedAccount.currency)}
            </div>
            <div className="text-[11px] text-[#637082] font-mono mt-1">
              Disponible immédiatement (découvert inclus)
            </div>
          </div>

          {/* Overdraft Facility */}
          <div className="py-3 md:py-0 md:px-4">
            <div className="text-xs text-[#7e8b9f] font-medium mb-1">{t('account.overdraft')}</div>
            <div className="text-2xl font-bold font-mono text-[#cbd5e1]">
              {formatCurrency(selectedAccount.overdraftLimit, selectedAccount.currency)}
            </div>
            <div className="text-[11px] text-[#637082] font-mono mt-1">
              Autorisation contractuelle
            </div>
          </div>

          {/* Ledger Status Verification */}
          <div className="pt-3 md:pt-0 md:pl-4 flex flex-col justify-center">
            <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs">
              <CheckCircle2 className="w-4 h-4" />
              <span>{t('header.auditVerified')}</span>
            </div>
            <div className="text-[11px] text-[#788599] font-mono mt-1">
              Total Débits = Total Crédits: {ledgerVerification.totalDebits} EUR
            </div>
          </div>
        </div>
      </div>

      {/* Tabs: Operations vs Double-Entry Ledger vs RIB */}
      <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#212737]">
          {/* Tab buttons */}
          <div className="flex items-center space-x-2 bg-[#0e1017] p-1 rounded-xl border border-[#1f2533]">
            <button
              onClick={() => setActiveTab('OPERATIONS')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'OPERATIONS'
                  ? 'bg-red-950/70 text-white border border-red-800/40 shadow-sm'
                  : 'text-[#8491a3] hover:text-white'
              }`}
            >
              Opérations Bancaires ({filteredTransactions.length})
            </button>
            <button
              onClick={() => setActiveTab('LEDGER_ENTRIES')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'LEDGER_ENTRIES'
                  ? 'bg-red-950/70 text-white border border-red-800/40 shadow-sm'
                  : 'text-[#8491a3] hover:text-white'
              }`}
            >
              Écritures Grand Livre ({accountLedgerEntries.length})
            </button>
            <button
              onClick={() => setActiveTab('RIB')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'RIB'
                  ? 'bg-red-950/70 text-white border border-red-800/40 shadow-sm'
                  : 'text-[#8491a3] hover:text-white'
              }`}
            >
              Détails IBAN / RIB
            </button>
          </div>

          {/* Search & Filters (only for operations & ledger) */}
          {activeTab !== 'RIB' && (
            <div className="flex items-center space-x-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#677387]" />
                <input
                  type="text"
                  placeholder={t('common.search')}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 pr-3 py-1.5 rounded-lg bg-[#0e1017] border border-[#222938] text-xs text-white focus:outline-none focus:border-red-500 font-mono w-44 sm:w-56"
                />
              </div>

              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="px-2.5 py-1.5 rounded-lg bg-[#0e1017] border border-[#222938] text-xs text-[#cbd5e1] focus:outline-none focus:border-red-500 font-mono"
              >
                <option value="ALL">{t('common.all')}</option>
                <option value="CREDIT">Crédits (+)</option>
                <option value="DEBIT">Débits (-)</option>
              </select>
            </div>
          )}
        </div>

        {/* Tab 1: Operations Table */}
        {activeTab === 'OPERATIONS' && (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                  <th className="pb-3 font-semibold">{t('ledger.bookingDate')}</th>
                  <th className="pb-3 font-semibold">{t('ledger.valueDate')}</th>
                  <th className="pb-3 font-semibold">Contrepartie & Libellé</th>
                  <th className="pb-3 font-semibold">Référence SEPA</th>
                  <th className="pb-3 font-semibold text-right">{t('common.amount')}</th>
                  <th className="pb-3 font-semibold text-center">{t('common.status')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b202c]">
                {filteredTransactions.map(tx => {
                  const isCredit = tx.destinationAccountId === selectedAccount.id;
                  return (
                    <tr key={tx.id} className="hover:bg-[#161a25] transition-colors">
                      <td className="py-3 text-[#94a3b8]">{formatDate(tx.bookingDate)}</td>
                      <td className="py-3 text-[#717e92]">{formatDate(tx.valueDate)}</td>
                      <td className="py-3">
                        <div className="font-semibold text-white">{tx.counterpartyName}</div>
                        <div className="text-[11px] text-[#788599] font-sans">{tx.narrative}</div>
                      </td>
                      <td className="py-3 text-[#79869c] text-[11px]">{tx.reference}</td>
                      <td className="py-3 text-right font-bold">
                        <span className={isCredit ? 'text-emerald-400' : 'text-white'}>
                          {isCredit ? '+' : '-'}{formatCurrency(tx.amount, tx.currency)}
                        </span>
                      </td>
                      <td className="py-3 text-center">
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950/50 text-emerald-300 border border-emerald-800/30">
                          {tx.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab 2: Double-Entry Ledger Entries */}
        {activeTab === 'LEDGER_ENTRIES' && (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-[#212737] text-[#707c8f] uppercase text-[10px]">
                  <th className="pb-3 font-semibold">ID Écriture</th>
                  <th className="pb-3 font-semibold">{t('ledger.bookingDate')}</th>
                  <th className="pb-3 font-semibold">{t('ledger.entryType')}</th>
                  <th className="pb-3 font-semibold">{t('ledger.narrative')}</th>
                  <th className="pb-3 font-semibold text-right">{t('common.amount')}</th>
                  <th className="pb-3 font-semibold text-right">Solde Après Écriture</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b202c]">
                {accountLedgerEntries.map(e => (
                  <tr key={e.id} className="hover:bg-[#161a25] transition-colors">
                    <td className="py-3 text-red-400 font-semibold">{e.id}</td>
                    <td className="py-3 text-[#94a3b8]">{formatDate(e.bookingDate)}</td>
                    <td className="py-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        e.entryType === 'CREDIT' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40' : 'bg-red-950/60 text-red-300 border border-red-800/40'
                      }`}>
                        {e.entryType}
                      </span>
                    </td>
                    <td className="py-3 text-white font-sans text-xs">{e.narrative}</td>
                    <td className="py-3 text-right font-bold">
                      <span className={e.entryType === 'CREDIT' ? 'text-emerald-400' : 'text-white'}>
                        {formatCurrency(e.amount, e.currency)}
                      </span>
                    </td>
                    <td className="py-3 text-right text-[#a0aec0] font-bold">
                      {formatCurrency(e.balanceAfter, e.currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Tab 3: Official IBAN & Bank Details */}
        {activeTab === 'RIB' && (
          <div className="mt-4 p-6 rounded-xl bg-[#0e1017] border border-[#212737] space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2230]">
              <span className="text-[#7e8b9f]">BANQUE DÉPOSITAIRE</span>
              <span className="text-white font-bold">SOCIÉTÉ GÉNÉRALE PARIS</span>
            </div>

            <div className="flex items-center justify-between pb-3 border-b border-[#1c2230]">
              <span className="text-[#7e8b9f]">INTITULÉ DU COMPTE</span>
              <span className="text-white font-bold">{selectedAccount.name}</span>
            </div>

            <div className="flex items-center justify-between pb-3 border-b border-[#1c2230]">
              <span className="text-[#7e8b9f]">IBAN INTERNATIONAL</span>
              <span className="text-white font-bold select-all tracking-widest">{selectedAccount.iban}</span>
            </div>

            <div className="flex items-center justify-between pb-3 border-b border-[#1c2230]">
              <span className="text-[#7e8b9f]">CODE BIC / SWIFT</span>
              <span className="text-white font-bold">{selectedAccount.bic}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[#7e8b9f]">DEVISE DE TENUE DE COMPTE</span>
              <span className="text-emerald-400 font-bold">{selectedAccount.currency} (EUR)</span>
            </div>
          </div>
        )}
      </div>

      {/* Deposit Simulation Modal */}
      {depositModalOpen && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="w-full max-w-md bg-[#131620] rounded-2xl border border-[#2b3347] p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-2">
              {t('account.simulateDeposit')} — {selectedAccount.name}
            </h3>
            <p className="text-xs text-[#8c97ab] mb-4">
              Génère instantanément les écritures de débit (Compensation centrale) et crédit ({selectedAccount.name}).
            </p>

            <form onSubmit={handleDeposit} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Montant en {selectedAccount.currency}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#273042] text-white font-mono text-sm focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#8c97ab] block mb-1">
                  Libellé Comptable
                </label>
                <input
                  type="text"
                  value={depositNarrative}
                  onChange={(e) => setDepositNarrative(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#0e1017] border border-[#273042] text-white text-xs focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setDepositModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#1a202d] text-[#8c97ab] text-xs font-semibold hover:text-white"
                >
                  {t('common.cancel')}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#e60028] hover:bg-[#c80023] text-white text-xs font-bold shadow"
                >
                  Valider l'Écriture
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
