/**
 * SG Banking Systems - Full Interactive CLI Terminal View
 * Native command line interface executing sgbank commands
 */

import React, { useState, useRef, useEffect } from 'react';
import { Terminal, CornerDownLeft, Trash2, HelpCircle } from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';

interface CommandHistoryItem {
  command: string;
  output: string;
  timestamp: string;
}

export const CliView: React.FC = () => {
  const { locale, t } = useTranslation();
  const { executeCliCommand } = useBanking();

  const [input, setInput] = useState('');
  const [history, setHistory] = useState<CommandHistoryItem[]>([
    {
      command: 'sgbank ledger verify',
      output: executeCliCommand('sgbank ledger verify'),
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const output = executeCliCommand(input);
    setHistory(prev => [
      ...prev,
      {
        command: input,
        output,
        timestamp: new Date().toLocaleTimeString(),
      },
    ]);
    setInput('');
  };

  const clearHistory = () => {
    setHistory([]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight flex items-center space-x-2">
            <Terminal className="w-6 h-6 text-red-400" />
            <span>{t('cli.title')}</span>
          </h1>
          <p className="text-xs text-[#828f9f] font-mono">
            Console d'administration financière & automatisation système
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => {
              const res = executeCliCommand('help');
              setHistory(prev => [...prev, { command: 'help', output: res, timestamp: new Date().toLocaleTimeString() }]);
            }}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-[#171b26] hover:bg-[#202636] border border-[#273042] text-xs font-semibold text-[#cbd5e1] transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5 text-red-400" />
            <span>{t('cli.help')}</span>
          </button>

          <button
            onClick={clearHistory}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-[#171b26] hover:bg-[#202636] border border-[#273042] text-xs font-semibold text-[#cbd5e1] transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5 text-[#8592a6]" />
            <span>{t('cli.clear')}</span>
          </button>
        </div>
      </div>

      {/* Terminal Window */}
      <div className="rounded-2xl bg-[#090b10] border border-[#222838] shadow-2xl overflow-hidden font-mono text-xs flex flex-col h-[600px]">
        {/* Terminal Title Bar */}
        <div className="px-4 py-2.5 bg-[#0f121a] border-b border-[#1f2533] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
            <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
            <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
            <span className="text-xs text-[#6e7b8f] font-semibold ml-2">sgbank-core-cli (v3.6-pro)</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-bold">SESSION AUTHENTIFIÉE</span>
        </div>

        {/* Output Stream */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4">
          <div className="text-[#647184] leading-relaxed">
            SG Banking Systems CLI Initialized. Tapez <strong className="text-white">help</strong> ou <strong className="text-red-400">sgbank test</strong> pour exécuter la suite de validation.
          </div>

          {history.map((item, idx) => (
            <div key={idx} className="space-y-1">
              <div className="flex items-center space-x-2 text-red-400 font-bold">
                <span className="text-[#556275]">sgbank@core:~$</span>
                <span>{item.command}</span>
                <span className="text-[10px] text-[#444f60] font-normal ml-auto">{item.timestamp}</span>
              </div>
              <pre className="text-[#d8e2ef] whitespace-pre-wrap font-mono pl-4 border-l-2 border-[#1f2536] text-[11px] leading-relaxed">
                {item.output}
              </pre>
            </div>
          ))}
          <div ref={endRef} />
        </div>

        {/* Input Bar */}
        <form onSubmit={handleCommand} className="p-3 bg-[#0d0f15] border-t border-[#1f2533] flex items-center space-x-3">
          <span className="text-red-400 font-bold">sgbank@core:~$</span>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t('cli.enterCommand')}
            className="flex-1 bg-transparent text-white focus:outline-none text-xs font-mono"
            autoFocus
          />
          <button
            type="submit"
            className="p-1.5 rounded-lg bg-red-950/80 hover:bg-red-900 border border-red-800/50 text-red-300"
          >
            <CornerDownLeft className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
