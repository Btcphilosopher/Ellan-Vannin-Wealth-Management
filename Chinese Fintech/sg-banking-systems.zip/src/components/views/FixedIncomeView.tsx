/**
 * SG Banking Systems - Quantitative Fixed Income & Bond Analytics Workbench
 * YTM (Newton-Raphson), Clean & Dirty Price, Accrued Interest, Macaulay & Modified Duration, Convexity
 */

import React, { useState } from 'react';
import { 
  Binary, TrendingUp, Sliders, Activity, ArrowRight, ShieldCheck 
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { BondEngine } from '../../engine/bondEngine';

export const FixedIncomeView: React.FC = () => {
  const { locale, t } = useTranslation();

  // Selected Bond Simulation Parameters
  const [couponRate, setCouponRate] = useState('3.00');
  const [marketPrice, setMarketPrice] = useState('98.75');
  const [yearsToMaturity, setYearsToMaturity] = useState('10');
  const [rateShockBps, setRateShockBps] = useState('50');

  const cRate = (parseFloat(couponRate) || 0) / 100;
  const mPrice = parseFloat(marketPrice) || 100;
  const ytmYears = parseFloat(yearsToMaturity) || 10;
  const shock = (parseFloat(rateShockBps) || 0) / 10000;

  const analytics = BondEngine.analyzeBond(
    'FR0014007L85',
    'OAT France Benchmark Souverain',
    cRate,
    ytmYears,
    mPrice
  );

  // Price impact with Duration + Convexity Taylor approximation:
  // dP/P ≈ -D_mod * dy + 0.5 * C * (dy)^2
  const dP_up = (-analytics.modifiedDuration * shock + 0.5 * analytics.convexity * Math.pow(shock, 2)) * 100;
  const dP_down = (-analytics.modifiedDuration * (-shock) + 0.5 * analytics.convexity * Math.pow(-shock, 2)) * 100;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white font-sans tracking-tight">
          {t('nav.fixedIncome')} & Analyse Obligataire Quantitative
        </h1>
        <p className="text-xs text-[#828f9f] font-mono">
          Pricing Actuariel OAT • Méthode Newton-Raphson • Sensibilité & Convexité
        </p>
      </div>

      {/* Analytics KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('bonds.ytm')} (Rendement Actuariel)</div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {(analytics.yieldToMaturity * 100).toFixed(3)}%
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">
            Résolution Newton-Raphson (Tolérance 10⁻⁷)
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('bonds.modifiedDuration')} (Sensibilité)</div>
          <div className="text-2xl font-bold font-mono text-white">
            {analytics.modifiedDuration.toFixed(3)} ans
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">
            Macaulay Duration: {analytics.macaulayDuration.toFixed(3)} ans
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('bonds.convexity')} (Convexité)</div>
          <div className="text-2xl font-bold font-mono text-blue-400">
            {analytics.convexity.toFixed(3)}
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">
            Effet de second ordre protecteur
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-[#131620] border border-[#242b3b]">
          <div className="text-xs text-[#7e8b9f] mb-1">{t('bonds.dirtyPrice')} (Plein Coupon)</div>
          <div className="text-2xl font-bold font-mono text-white">
            {analytics.dirtyPrice.toFixed(3)}%
          </div>
          <div className="text-[11px] text-[#606d80] font-mono mt-1">
            {t('bonds.accruedInterest')}: {analytics.accruedInterest.toFixed(3)}%
          </div>
        </div>
      </div>

      {/* Simulator Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Input Parameters */}
        <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-red-400" />
            <span>Paramètres de l'Obligation OAT</span>
          </h3>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <label className="text-[#808ea3] block mb-1">Cours Pied de Coupon (Clean Price %):</label>
              <input
                type="number"
                step="0.05"
                value={marketPrice}
                onChange={(e) => setMarketPrice(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-bold"
              />
            </div>

            <div>
              <label className="text-[#808ea3] block mb-1">Taux Facial du Coupon Annuel (%):</label>
              <input
                type="number"
                step="0.05"
                value={couponRate}
                onChange={(e) => setCouponRate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-bold"
              />
            </div>

            <div>
              <label className="text-[#808ea3] block mb-1">Maturité Restante (Années):</label>
              <input
                type="number"
                step="0.5"
                value={yearsToMaturity}
                onChange={(e) => setYearsToMaturity(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-bold"
              />
            </div>

            <div>
              <label className="text-[#808ea3] block mb-1">Scénario de Choc de Taux (bps):</label>
              <input
                type="number"
                step="10"
                value={rateShockBps}
                onChange={(e) => setRateShockBps(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-[#0e1017] border border-[#252d3e] text-white font-bold"
              />
            </div>
          </div>
        </div>

        {/* Right: Stress Test Shock Matrix */}
        <div className="p-6 rounded-2xl bg-[#131620] border border-[#242b3b] space-y-4 font-mono">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider font-sans">
            Simulation d'Impact de Choc de Taux (Stress Testing)
          </h3>

          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-xl bg-[#0e1017] border border-[#202636] space-y-2">
              <div className="text-amber-400 font-bold text-xs">
                Choc à la hausse des taux (+{rateShockBps} bps):
              </div>
              <div className="text-xl font-bold text-red-400">
                {dP_up.toFixed(2)}%
              </div>
              <div className="text-[11px] text-[#6d7a8d]">
                Impact estimé sur le cours de l'obligation en cas de durcissement monétaire.
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#0e1017] border border-[#202636] space-y-2">
              <div className="text-emerald-400 font-bold text-xs">
                Choc à la baisse des taux (-{rateShockBps} bps):
              </div>
              <div className="text-xl font-bold text-emerald-400">
                +{dP_down.toFixed(2)}%
              </div>
              <div className="text-[11px] text-[#6d7a8d]">
                Gain estimé sur le cours en cas d'assouplissement monétaire de la BCE.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
