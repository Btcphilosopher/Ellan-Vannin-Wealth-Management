/**
 * SG Banking Systems - Institutional Navigation Sidebar
 * Categorized according to French Universal Banking Architecture
 */

import React from 'react';
import { 
  Home, Wallet, Send, CreditCard, Landmark, PiggyBank, 
  TrendingUp, BarChart3, Binary, Briefcase, Activity, 
  ShieldAlert, GitCompare, FileText, History, Terminal, Cpu
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { TranslationKey } from '../../localisation/dictionary';

interface NavItem {
  id: string;
  labelKey: TranslationKey;
  icon: React.ElementType;
  badge?: string;
}

interface NavSection {
  titleFr: string;
  titleEn: string;
  items: NavItem[];
}

interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  activeView, 
  setActiveView, 
  isMobileOpen, 
  setIsMobileOpen 
}) => {
  const { locale, t } = useTranslation();

  const sections: NavSection[] = [
    {
      titleFr: 'BANQUE DU QUOTIDIEN',
      titleEn: 'RETAIL & DIGITAL BANKING',
      items: [
        { id: 'home', labelKey: 'nav.home', icon: Home },
        { id: 'accounts', labelKey: 'nav.accounts', icon: Wallet },
        { id: 'payments', labelKey: 'nav.payments', icon: Send },
        { id: 'cards', labelKey: 'nav.cards', icon: CreditCard },
        { id: 'loans', labelKey: 'nav.loans', icon: Landmark },
        { id: 'savings', labelKey: 'nav.savings', icon: PiggyBank },
      ],
    },
    {
      titleFr: 'MARCHÉS & BANQUE PRIVÉE',
      titleEn: 'MARKETS & WEALTH',
      items: [
        { id: 'wealth', labelKey: 'nav.wealth', icon: Briefcase },
        { id: 'markets', labelKey: 'nav.markets', icon: TrendingUp },
        { id: 'fixedIncome', labelKey: 'nav.fixedIncome', icon: Binary },
      ],
    },
    {
      titleFr: 'CORPORATE & TRÉSORERIE',
      titleEn: 'CORPORATE & TREASURY',
      items: [
        { id: 'treasury', labelKey: 'nav.treasury', icon: BarChart3 },
        { id: 'risk', labelKey: 'nav.risk', icon: Activity },
      ],
    },
    {
      titleFr: 'CONTRÔLE & EXPLOITATION',
      titleEn: 'GOVERNANCE & OPERATIONS',
      items: [
        { id: 'compliance', labelKey: 'nav.compliance', icon: ShieldAlert },
        { id: 'reconciliation', labelKey: 'nav.reconciliation', icon: GitCompare },
        { id: 'reports', labelKey: 'nav.reports', icon: FileText },
        { id: 'audit', labelKey: 'nav.audit', icon: History },
        { id: 'cli', labelKey: 'nav.cli', icon: Terminal, badge: 'CLI' },
        { id: 'observability', labelKey: 'nav.observability', icon: Cpu },
      ],
    },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-30 lg:hidden backdrop-blur-sm"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      <aside className={`
        fixed lg:static top-0 bottom-0 left-0 z-40
        w-64 bg-[#0d0f15] border-r border-[#1f2433]
        flex flex-col flex-shrink-0 transition-transform duration-300
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Navigation list */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          {sections.map((section, sIdx) => (
            <div key={sIdx} className="space-y-1">
              <div className="px-3 pb-1.5 text-[10px] font-bold tracking-wider text-[#5a6578] uppercase font-mono">
                {locale === 'fr-FR' ? section.titleFr : section.titleEn}
              </div>

              <div className="space-y-0.5">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeView === item.id;

                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveView(item.id);
                        setIsMobileOpen(false);
                      }}
                      className={`
                        w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all group
                        ${isActive
                          ? 'bg-gradient-to-r from-red-950/70 to-[#181d29] text-white border-l-2 border-[#e60028] shadow-sm'
                          : 'text-[#8c97ab] hover:text-white hover:bg-[#141722]'
                        }
                      `}
                    >
                      <div className="flex items-center space-x-2.5">
                        <Icon className={`w-4 h-4 transition-colors ${isActive ? 'text-[#ff3355]' : 'text-[#68748a] group-hover:text-white'}`} />
                        <span className="truncate">{t(item.labelKey)}</span>
                      </div>

                      {item.badge && (
                        <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-800/40">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Institutional footnote */}
        <div className="p-3 border-t border-[#1a1f2c] bg-[#0a0c10] text-[10px] text-[#556073] font-mono flex items-center justify-between">
          <span>PARIS LA DÉFENSE</span>
          <span className="text-emerald-400 font-semibold">TARGET2 / SEPA OK</span>
        </div>
      </aside>
    </>
  );
};
