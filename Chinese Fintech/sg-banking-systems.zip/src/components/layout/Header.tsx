/**
 * SG Banking Systems - Institutional Header
 * Features brand symbol, live markets ticker, persona switcher, language selector,
 * double-entry ledger status badge, and notifications.
 */

import React, { useState } from 'react';
import { 
  Building2, Globe, ShieldCheck, UserCheck, Bell, Terminal, CheckCircle2, 
  ChevronDown, ArrowUpRight, TrendingUp, AlertTriangle, Layers
} from 'lucide-react';
import { useTranslation } from '../../localisation/useTranslation';
import { useBanking } from '../../context/BankingContext';
import { Locale } from '../../types/domain';

interface HeaderProps {
  onOpenCli: () => void;
  activeView: string;
}

export const Header: React.FC<HeaderProps> = ({ onOpenCli, activeView }) => {
  const { locale, setLocale, t, formatCurrency } = useTranslation();
  const { 
    currentUser, switchUser, availableUsers, ledgerVerification, 
    notifications, markNotificationAsRead, fxRates, securities
  } = useBanking();

  const [showPersonaMenu, setShowPersonaMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;
  const eurUsd = fxRates.find(f => f.pair === 'EUR/USD');
  const sgStock = securities.find(s => s.ticker === 'GLE.PA');

  return (
    <header className="sticky top-0 z-40 bg-[#0f1118]/95 backdrop-blur-md border-b border-[#222838]">
      {/* Top institutional streaming ticker */}
      <div className="hidden lg:flex items-center justify-between px-6 py-1 bg-[#090a0f] border-b border-[#1c202d] text-xs font-mono text-[#8a94a6]">
        <div className="flex items-center space-x-6 overflow-x-auto py-0.5">
          <div className="flex items-center space-x-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-[#a0aec0] font-semibold">MARCHÉS / SG DESK:</span>
          </div>

          <div className="flex items-center space-x-1">
            <span className="text-white">CAC 40</span>
            <span className="text-[#e2e8f0]">7,642.18</span>
            <span className="text-emerald-400 flex items-center font-semibold">+0.68%</span>
          </div>

          <div className="flex items-center space-x-1">
            <span className="text-white">SOCIÉTÉ GÉNÉRALE (GLE.PA)</span>
            <span className="text-[#e2e8f0]">{sgStock?.lastPrice.toFixed(2)} €</span>
            <span className="text-emerald-400 font-semibold">+{sgStock?.change24h}%</span>
          </div>

          <div className="flex items-center space-x-1">
            <span className="text-white">EUR/USD</span>
            <span className="text-[#e2e8f0]">{eurUsd?.mid.toFixed(4)}</span>
            <span className="text-emerald-400 font-semibold">+{eurUsd?.change24h}</span>
          </div>

          <div className="flex items-center space-x-1">
            <span className="text-white">OAT FRANCE 10Y</span>
            <span className="text-[#e2e8f0]">3.08%</span>
            <span className="text-amber-400 font-semibold">+2.3 bps</span>
          </div>
        </div>

        <div className="flex items-center space-x-4 pl-4">
          <div className="flex items-center space-x-1.5 text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span className="text-[11px] font-medium tracking-tight">
              {t('header.auditVerified')}
            </span>
          </div>
        </div>
      </div>

      {/* Main navigation header bar */}
      <div className="px-6 py-3 flex items-center justify-between">
        {/* Brand identity */}
        <div className="flex items-center space-x-4">
          {/* Institutional SG-style dual geometric square */}
          <div className="flex items-center space-x-3 group cursor-pointer">
            <div className="w-9 h-9 rounded-md overflow-hidden flex flex-col border border-[#ff3355]/30 shadow-lg shadow-red-950/30">
              <div className="h-1/2 bg-[#e60028] flex items-center justify-center">
                <div className="w-2 h-0.5 bg-white/80 rounded-full"></div>
              </div>
              <div className="h-1/2 bg-[#12141c] flex items-center justify-center">
                <div className="w-2 h-0.5 bg-[#e60028] rounded-full"></div>
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-base font-bold tracking-tight text-white uppercase font-sans">
                  SG Banking Systems
                </span>
                <span className="text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-red-950/60 border border-red-800/40 text-red-300 font-mono font-medium">
                  v3.6 PRO
                </span>
              </div>
              <div className="text-[11px] text-[#7d8799] tracking-normal">
                {t('app.tagline')}
              </div>
            </div>
          </div>
        </div>

        {/* Right side controls: CLI terminal button, Persona Switcher, Language toggle, Notifications */}
        <div className="flex items-center space-x-3">
          {/* Quick CLI Launcher */}
          <button
            onClick={onOpenCli}
            className="flex items-center space-x-2 px-3 py-1.5 rounded-md bg-[#161a24] hover:bg-[#1f2533] border border-[#2b3345] text-xs font-mono text-[#cbd5e1] transition-colors shadow-sm"
            title="Ouvrir la console sgbank CLI"
          >
            <Terminal className="w-3.5 h-3.5 text-red-400" />
            <span className="hidden sm:inline font-medium">sgbank CLI</span>
          </button>

          {/* Bilingual Language Switcher */}
          <div className="flex items-center bg-[#131722] p-0.5 rounded-lg border border-[#242b3b]">
            <button
              onClick={() => setLocale('fr-FR')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                locale === 'fr-FR'
                  ? 'bg-[#e60028] text-white shadow'
                  : 'text-[#8b95a5] hover:text-white'
              }`}
            >
              FR
            </button>
            <button
              onClick={() => setLocale('en-GB')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                locale === 'en-GB'
                  ? 'bg-[#e60028] text-white shadow'
                  : 'text-[#8b95a5] hover:text-white'
              }`}
            >
              EN
            </button>
          </div>

          {/* Notifications Trigger */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-lg bg-[#141722] hover:bg-[#1c2230] border border-[#262c3d] text-[#a0aec0] hover:text-white transition-colors"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#e60028] text-white text-[10px] font-bold flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notifications Dropdown */}
            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-xl bg-[#131620] border border-[#293144] shadow-2xl z-50 p-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#232938]">
                  <div className="flex items-center space-x-2">
                    <Bell className="w-4 h-4 text-red-400" />
                    <span className="text-sm font-semibold text-white">{t('header.notifications')}</span>
                  </div>
                  <span className="text-xs text-[#7d8799] font-mono">{notifications.length} événements</span>
                </div>

                <div className="mt-3 space-y-2.5 max-h-72 overflow-y-auto pr-1">
                  {notifications.map(n => (
                    <div
                      key={n.id}
                      onClick={() => markNotificationAsRead(n.id)}
                      className={`p-3 rounded-lg border transition-colors cursor-pointer ${
                        n.read
                          ? 'bg-[#10121a]/60 border-[#1e2330] text-[#828c9e]'
                          : 'bg-[#181d2a] border-[#313b50] text-[#e2e8f0]'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs font-semibold mb-1">
                        <span className={n.read ? 'text-[#a0aec0]' : 'text-red-400'}>
                          {n.title[locale]}
                        </span>
                        <span className="text-[10px] font-mono text-[#6c7689]">
                          {new Date(n.timestamp).toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-xs leading-relaxed">{n.message[locale]}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Persona Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowPersonaMenu(!showPersonaMenu)}
              className="flex items-center space-x-3 p-1.5 pr-3 rounded-xl bg-[#141722] hover:bg-[#1b202e] border border-[#262d3e] transition-all text-left"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-8 h-8 rounded-lg object-cover border border-[#3b445a]"
              />
              <div className="hidden md:block">
                <div className="text-xs font-semibold text-white leading-tight flex items-center space-x-1.5">
                  <span>{currentUser.name}</span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#202737] text-red-300 font-mono">
                    {currentUser.role}
                  </span>
                </div>
                <div className="text-[10px] text-[#717b8f] truncate max-w-[170px]">
                  {currentUser.personaTitle[locale]}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-[#8591a5]" />
            </button>

            {/* Persona Switcher Menu */}
            {showPersonaMenu && (
              <div className="absolute right-0 mt-2 w-80 rounded-xl bg-[#131620] border border-[#2a3245] shadow-2xl z-50 p-2">
                <div className="px-3 py-2 text-[11px] font-semibold text-[#707b90] uppercase tracking-wider border-b border-[#212737]">
                  {t('header.switchPersona')}
                </div>
                <div className="mt-1 space-y-1">
                  {availableUsers.map(user => {
                    const isSelected = user.id === currentUser.id;
                    return (
                      <button
                        key={user.id}
                        onClick={() => {
                          switchUser(user.id);
                          setShowPersonaMenu(false);
                        }}
                        className={`w-full flex items-center space-x-3 p-2.5 rounded-lg text-left transition-colors ${
                          isSelected ? 'bg-red-950/40 border border-red-800/50 text-white' : 'hover:bg-[#181d29] text-[#cbd5e1]'
                        }`}
                      >
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-8 h-8 rounded-lg object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-semibold flex items-center justify-between">
                            <span className="truncate">{user.name}</span>
                            <span className="text-[9px] font-mono px-1 py-0.5 rounded bg-[#1f2536] text-[#93a1b8]">
                              {user.role}
                            </span>
                          </div>
                          <div className="text-[10px] text-[#79859b] truncate">
                            {user.personaTitle[locale]}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
