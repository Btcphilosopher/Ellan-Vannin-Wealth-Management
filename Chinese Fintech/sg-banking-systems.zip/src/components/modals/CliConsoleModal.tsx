/**
 * SG Banking Systems - Global Floating CLI Modal
 * Can be opened from anywhere via the header button or keyboard shortcut
 */

import React, { useState, useRef, useEffect } from 'react';
import { Terminal, X, CornerDownLeft, Trash2 } from 'lucide-react';
import { useBanking } from '../../context/BankingContext';
import { useTranslation } from '../../localisation/useTranslation';

interface CliConsoleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CliConsoleModal: React.FC<CliConsoleModalProps> = ({ isOpen, onClose }) => {
  const { executeCliCommand } = useBanking();
  const { t } = useTranslation();

  const [input, setInput] = useState('');
  const [history, setHistory] = useState<{ command: string; output: string }[]>([
    {
      command: 'sgbank ledger verify',
      output: executeCliCommand('sgbank ledger verify'),
    },
  ]);

  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [history, isOpen]);

  if (!isOpen) return null;

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const output = executeCliCommand(input);
    setHistory(prev => [...prev, { command: input, output }]);
    setInput('');
  };

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="w-full max-w-3xl bg-[#090b10] rounded-2xl border border-[#262e42] shadow-2xl overflow-hidden flex flex-col h-[550px] font-mono text-xs">
        {/* Title Bar */}
        <div className="px-4 py-2.5 bg-[#0f121a] border-b border-[#1f2533] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Terminal className="w-4 h-4 text-red-400" />
            <span className="text-white font-bold">sgbank CLI — Terminal Superviseur</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setHistory([])}
              className="p-1 rounded text-[#717e92] hover:text-white"
              title="Effacer l'historique"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded text-[#717e92] hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Console stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3">
          {history.map((item, idx) => (
            <div key={idx} className="space-y-1">
              <div className="text-red-400 font-bold flex items-center space-x-2">
                <span className="text-[#556275]">sgbank@core:~$</span>
                <span>{item.command}</span>
              </div>
              <pre className="text-[#d8e2ef] whitespace-pre-wrap pl-3 border-l-2 border-[#1e2536] text-[11px]">
                {item.output}
              </pre>
            </div>
          ))}
          <div ref={endRef} />
        </div>

        {/* Input Bar */}
        <form onSubmit={handleCommand} className="p-3 bg-[#0d0f15] border-t border-[#1f2533] flex items-center space-x-3">
          <span className="text-red-400 font-bold">sgbank@core:~$</span>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Tapez help ou une commande sgbank..."
            className="flex-1 bg-transparent text-white focus:outline-none text-xs font-mono"
            autoFocus
          />
          <button
            type="submit"
            className="p-1.5 rounded-lg bg-red-950/80 hover:bg-red-900 text-red-300"
          >
            <CornerDownLeft className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
