/**
 * 华市 (HUASHI TERMINAL) - 专业金融市场终端核心数据模型与类型定义
 */

export type TerminalTab =
  | 'overview'
  | 'market'          // 市场总览
  | 'stock_detail'    // 股票详情
  | 'industry'        // 行业终端
  | 'screener'        // 股票筛选器
  | 'comparison'      // 公司多维比较
  | 'etf_fund'
  | 'fund_etf'        // 基金与ETF中心
  | 'bond_market'
  | 'bond'            // 债券市场与收益率曲线
  | 'macro'           // 宏观经济中心
  | 'fx_commodity'    // 外汇与大宗商品
  | 'capital_flow'    // 市场资金流向
  | 'market_breadth'  // 市场宽度与情绪
  | 'watchlist'       // 自选股监控
  | 'portfolio'       // 模拟投资组合
  | 'quant_research'
  | 'quant'           // 量化研究与因子回测
  | 'news_filing'     // 财经资讯与公司公告
  | 'ai_assistant'    // 华市智能投研助手
  | 'calculators'
  | 'calculator'      // 金融衍生计算器
  | 'workspace'
  | 'custom_workspace'// 自定义多窗口工作台
  | 'data_quality'    // 数据质量与源监控
  | 'audit_rbac';     // 权限与审计日志

export type MarketRegion = 'ALL' | 'CN' | 'HK' | 'US' | 'GLOBAL';

export interface MarketIndex {
  code: string;
  name: string;
  region: MarketRegion;
  price: number;
  change: number;
  changePct: number;
  open: number;
  high: number;
  low: number;
  volume: string; // e.g. "2.38亿手"
  turnover: string; // e.g. "3142.67亿"
  updateTime: string;
  status: '交易中' | '已收盘' | '盘前' | '休市';
  sparkline: number[];
}

export interface Level2OrderEntry {
  level: number; // 1 to 5 or 10
  price: number;
  volume: number;
}

export interface Level2OrderBook {
  bids: Level2OrderEntry[]; // 买一至买五/十
  asks: Level2OrderEntry[]; // 卖一至卖五/十
  largeInflow: number;     // 超大单净流入 (万元)
  midInflow: number;       // 中单净流入
  retailInflow: number;    // 小单净流入
  outerVolume: number;     // 外盘 (主动买)
  innerVolume: number;     // 内盘 (主动卖)
}

export interface KLineEventPin {
  date: string;
  type: '财报' | '分红' | '拆股' | '重大公告';
  title: string;
  description: string;
}

export interface KLineBar {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;      // 手
  turnover: number;    // 万元
  changePct: number;
  ma5?: number;
  ma10?: number;
  ma20?: number;
  ma60?: number;
  macd?: number;
  dif?: number;
  dea?: number;
  rsi?: number;
  k?: number;
  d?: number;
  j?: number;
  bollUpper?: number;
  bollMid?: number;
  bollLower?: number;
  events?: KLineEventPin[];
}

export type ChartPeriod = '分时' | '5日' | '日K' | '周K' | '月K' | '季K' | '年K';
export type AdjustType = '前复权' | '后复权' | '不复权';
export type TechIndicator = 'MA' | 'EMA' | 'MACD' | 'RSI' | 'KDJ' | 'BOLL' | 'VOL' | 'ATR' | 'OBV';

export interface FinancialStatementRow {
  name: string;
  isHeader?: boolean;
  indent?: boolean;
  history: Record<string, number | null>; // year or quarter string -> value in 亿元
}

export interface CompanyFinancials {
  years: string[];
  quarters: string[];
  incomeStatement: FinancialStatementRow[];
  balanceSheet: FinancialStatementRow[];
  cashFlowStatement: FinancialStatementRow[];
}

export interface ValuationMetrics {
  peTTM: number;
  peDynamic: number;
  pb: number;
  ps: number;
  evEbitda: number;
  dividendYield: number; // %
  peg: number;
  fcfYield: number; // %
  totalMarketCap: number; // 亿元
  floatMarketCap: number; // 亿元
  totalShares: number; // 亿股
  floatShares: number; // 亿股
  high52w: number;
  low52w: number;
}

export interface ProfitabilityMetrics {
  revenue: number; // 亿元
  revenueYoY: number; // %
  netProfit: number; // 亿元
  netProfitYoY: number; // %
  grossMargin: number; // %
  operatingMargin: number; // %
  netMargin: number; // %
  roe: number; // %
  roa: number; // %
  roic: number; // %
  debtToAssetRatio: number; // %
  currentRatio: number;
  quickRatio: number;
  cashEquivalents: number; // 亿元
  interestCoverage: number;
}

export interface CompanyProfile {
  code: string;
  name: string;
  exchange: '沪市主板' | '深市主板' | '科创板' | '创业板' | '北交所' | '港股主板';
  sector: string;
  industry: string;
  establishedDate: string;
  ipoDate: string;
  headquarters: string;
  chairman: string;
  auditor: string;
  website: string;
  description: string;
  businessSegments: { name: string; sharePct: number; revenue: number }[];
}

export interface StockQuote {
  code: string;
  name: string;
  exchange: string;
  sector: string;
  industry: string;
  price: number;
  change: number;
  changePct: number;
  open: number;
  high: number;
  low: number;
  prevClose: number;
  volume: number; // 手
  turnover: number; // 万元
  turnoverRate: number; // %
  amplitude: number; // %
  state: '交易中' | '已收盘' | '停牌' | '盘前';
  updateTime: string;
  valuation: ValuationMetrics;
  profitability: ProfitabilityMetrics;
  profile: CompanyProfile;
  orderBook: Level2OrderBook;
  isStarred?: boolean;
}

export interface IndustrySector {
  code: string;
  name: string;
  category: '金融' | '消费' | '科技' | '制造' | '医药' | '周期' | '基础设施';
  changePct: number;
  turnover: number; // 亿元
  pe: number;
  pb: number;
  roe: number;
  stockCount: number;
  upCount: number;
  downCount: number;
  leadingStock: { code: string; name: string; changePct: number; price: number };
  worstStock: { code: string; name: string; changePct: number; price: number };
  netCapitalInflow: number; // 亿元
  topHoldings: string[]; // Stock codes
}

export interface MarketBreadth {
  upCount: number;
  downCount: number;
  flatCount: number;
  limitUpCount: number;
  limitDownCount: number;
  totalTurnover: number; // 亿元
  aboveMA20Count: number;
  aboveMA50Count: number;
  aboveMA200Count: number;
  newHigh52wCount: number;
  newLow52wCount: number;
  volumeExpansionRatio: number; // 成交量放大系数
  sentimentScore: number; // 0 - 100 情绪温度计
}

export interface CapitalFlowDetail {
  northboundToday: number; // 亿元
  northboundHistorical: { date: string; shanghaiInflow: number; shenzhenInflow: number; total: number }[];
  southboundToday: number; // 亿元
  mainInflowToday: number; // 亿元 主力资金
  retailInflowToday: number; // 散户资金
  sectorFlows: { name: string; inflow: number; changePct: number }[];
  stockFlows: { code: string; name: string; inflow: number; changePct: number }[];
}

export interface ETFFundItem {
  code: string;
  name: string;
  category: '股票ETF' | '行业ETF' | '跨境QDII' | '债券ETF' | '商品ETF';
  price: number;
  changePct: number;
  aum: number; // 规模 (亿元)
  turnover: number; // 成交额 (万元)
  trackingIndex: string;
  trackingError: number; // %
  premiumDiscountRate: number; // 折溢价率 %
  mgmtFee: number; // %
  holdings: { name: string; code: string; weightPct: number }[];
  sectorWeights: { name: string; weightPct: number }[];
  navHistory: { date: string; nav: number; cumulativeNav: number }[];
}

export interface BondItem {
  code: string;
  name: string;
  type: '国债' | '地方政府债' | '金融债' | '企业债' | '公司债' | '可转债';
  maturityYears: number;
  couponRate: number; // 票面利率 %
  ytm: number; // 到期收益率 %
  duration: number; // 久期 (年)
  convexity: number; // 凸性
  creditRating: 'AAA' | 'AA+' | 'AA' | 'AA-' | '无评级';
  cleanPrice: number; // 净价
  dirtyPrice: number; // 全价
  volume: number; // 万元
}

export interface YieldCurveData {
  tenor: string; // "1M", "3M", "6M", "1Y", "2Y", "3Y", "5Y", "7Y", "10Y", "20Y", "30Y"
  today: number;
  yesterday: number;
  oneWeekAgo: number;
  oneMonthAgo: number;
  oneYearAgo: number;
}

export interface MacroIndicator {
  id: string;
  name: string;
  category: '增长' | '通胀' | '金融货币' | '贸易与产业' | '就业与民生';
  latestValue: string;
  previousValue: string;
  forecastValue: string; // 明确标注为市场调查预测
  publishDate: string;
  frequency: '月度' | '季度' | '年度' | '高频';
  source: string; // 如：国家统计局 / 中国人民银行 / 海关总署
  unit: string;
  description: string;
  history: { date: string; value: number; forecast?: number }[];
}

export interface FXCommodityItem {
  code: string;
  name: string;
  category: '外汇汇率' | '贵金属' | '能源' | '工业金属' | '农产品与周期';
  spotPrice: number;
  futurePrice?: number;
  change: number;
  changePct: number;
  high: number;
  low: number;
  volatility30d: number; // 30日历史波动率 %
  openInterest?: number; // 持仓量
  volume: number;
  unit: string;
  sparkline: number[];
}

export interface NewsItem {
  id: string;
  title: string;
  timestamp: string;
  source: string;
  author?: string;
  category: '市场快讯' | 'A股聚焦' | '宏观政策' | '行业动态' | '公司研报' | '国际市场';
  tags: string[];
  relatedStocks: { code: string; name: string }[];
  relatedIndustries: string[];
  content: string;
  summary?: string;
  importance: '普通' | '重要' | '特急';
  isDemo: boolean;
}

export interface AnnouncementItem {
  id: string;
  title: string;
  publishDate: string;
  companyCode: string;
  companyName: string;
  category: '年度报告' | '季度报告' | '业绩预告' | '分红配股' | '重大事项' | '股权激励' | '并购重组';
  fileType: 'PDF' | 'DOC';
  fileSize: string;
  summary: string;
  isDemo: boolean;
  date?: string;
  time?: string;
  stockName?: string;
  stockCode?: string;
  type?: string;
}

export interface WatchlistGroup {
  id: string;
  name: string;
  stockCodes: string[];
  createdTime: string;
}

export interface PortfolioPosition {
  stockCode: string;
  name: string;
  shares: number;
  buyPrice: number;
  currentPrice: number;
  costValue: number;
  marketValue: number;
  pnl: number;
  pnlPct: number;
  weightPct: number;
}

export interface PortfolioSimulation {
  id: string;
  name: string;
  initialCapital: number;
  totalMarketValue: number;
  cash: number;
  totalPnl: number;
  totalPnlPct: number;
  sharpeRatio: number;
  maxDrawdown: number;
  volatility: number;
  benchmark: string;
  positions: PortfolioPosition[];
  equityCurve: { date: string; portfolioVal: number; benchmarkVal: number }[];
}

export interface QuantFactor {
  id: string;
  name: string;
  category: '价值因子' | '成长因子' | '质量因子' | '动量因子' | '低波动' | '红利因子';
  description: string;
  weight: number;
}

export interface QuantBacktestConfig {
  name: string;
  factors: QuantFactor[];
  startDate: string;
  endDate: string;
  rebalanceFrequency: '每周' | '双周' | '每月' | '每季';
  benchmark: '沪深300' | '中证500' | '中证1000' | '创业板指';
  commissionRate: number; // 佣金率 万分之
  slippage: number; // 滑点 %
  topHoldingsCount: number; // 持仓股票数量
}

export interface QuantBacktestResult {
  cumulativeReturn: number; // %
  annualizedReturn: number; // %
  benchmarkReturn: number; // %
  alpha: number;
  beta: number;
  sharpeRatio: number;
  maxDrawdown: number; // %
  winRatePct: number; // %
  turnoverAnnualPct: number; // %
  equityCurve: { date: string; strategy: number; benchmark: number; excess: number }[];
  monthlyReturns: { year: number; month: number; returnPct: number }[];
  disclaimer: string;
}

export interface DataQualityNode {
  name: string;
  type: 'L1行情' | 'L2深度行情' | '财务数据库' | '宏观时序' | '公告资讯流' | '债券估值';
  provider: string;
  status: '正常' | '轻微延迟' | '降级运行' | '离线';
  latencyMs: number;
  missingRatePct: number;
  packetCountToday: number;
  lastHeartbeat: string;
  qualityGrade: 'A+' | 'A' | 'B' | 'C';
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  action: '查询公司财务' | '执行量化回测' | '导出行情数据' | '修改自选组合' | '调用AI投研推理' | '调整权限策略';
  target: string;
  ip: string;
  status: '成功' | '警告' | '拦截';
  details: string;
}

export type UserRoleType = '普通用户' | '专业用户' | '机构研究员' | '投资经理' | '系统管理员';

export interface UserRoleInfo {
  role: UserRoleType;
  userName: string;
  institution: string;
  permissions: string[];
}
