/**
 * 华市 (HuaShi) - 中国金融市场专业数据终端
 * Professional Financial Market Data Terminal for China Equities, Macro, Bonds & Quant Research
 */

import React, { useState, useEffect } from 'react';
import { TerminalHeader } from './components/TerminalHeader';
import { SidebarNav } from './components/SidebarNav';
import { TopTickerBar } from './components/TopTickerBar';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { TerminalTab, StockQuote } from './types';
import { STOCKS_DATABASE } from './services/mockDataEngine';

// 各大专业功能视图
import { MarketOverviewView } from './views/MarketOverviewView';
import { StockDetailView } from './views/StockDetailView';
import { IndustryTerminalView } from './views/IndustryTerminalView';
import { StockScreenerView } from './views/StockScreenerView';
import { CompanyComparisonView } from './views/CompanyComparisonView';
import { ETFFundCenterView } from './views/ETFFundCenterView';
import { BondMarketView } from './views/BondMarketView';
import { MacroEconomyView } from './views/MacroEconomyView';
import { FXCommodityView } from './views/FXCommodityView';
import { CapitalFlowView } from './views/CapitalFlowView';
import { MarketBreadthView } from './views/MarketBreadthView';
import { WatchlistView } from './views/WatchlistView';
import { PortfolioView } from './views/PortfolioView';
import { QuantResearchView } from './views/QuantResearchView';
import { NewsDisclosureView } from './views/NewsDisclosureView';
import { AiResearchAssistantView } from './views/AiResearchAssistantView';
import { FinancialCalculatorsView } from './views/FinancialCalculatorsView';
import { DataQualityView } from './views/DataQualityView';
import { AuditRbacView } from './views/AuditRbacView';
import { CustomWorkspaceView } from './views/CustomWorkspaceView';

export default function App() {
  const [activeTab, setActiveTab] = useState<TerminalTab>('overview');
  const [selectedStockCode, setSelectedStockCode] = useState<string>('600519');
  const [isSearchModalOpen, setIsSearchModalOpen] = useState<boolean>(false);

  // 全局键盘快捷键监听 (F1-F12 及 Ctrl+K / Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // 快捷键全局搜索
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchModalOpen(true);
        return;
      }

      // Escape 关闭弹窗
      if (e.key === 'Escape') {
        setIsSearchModalOpen(false);
        return;
      }

      // 功能键直达
      const keyTabMap: Record<string, TerminalTab> = {
        F1: 'overview',
        F2: 'stock_detail',
        F3: 'industry',
        F4: 'screener',
        F5: 'comparison',
        F6: 'etf_fund',
        F7: 'bond_market',
        F8: 'macro',
        F9: 'fx_commodity',
        F10: 'news_filing',
        F11: 'ai_assistant',
        F12: 'workspace'
      };

      if (keyTabMap[e.key]) {
        e.preventDefault();
        setActiveTab(keyTabMap[e.key]);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleSelectStock = (code: string) => {
    setSelectedStockCode(code);
    setActiveTab('stock_detail');
  };

  const handleSelectSector = (code: string) => {
    setActiveTab('industry');
  };

  const handleSelectMacro = (id: string) => {
    setActiveTab('macro');
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#0a0d12] text-[#c9d1d9] select-none font-sans">
      {/* 顶部全局状态栏 */}
      <TerminalHeader
        activeTab={activeTab}
        onOpenSearch={() => setIsSearchModalOpen(true)}
        onSelectTab={setActiveTab}
      />

      {/* 顶部高频行情跑马灯 */}
      <TopTickerBar onSelectStock={handleSelectStock} />

      {/* 主工作区：左侧专业导航栏 + 右侧功能视窗 */}
      <div className="flex flex-1 overflow-hidden relative">
        <SidebarNav
          activeTab={activeTab}
          onSelectTab={setActiveTab}
        />

        {/* 动态视图容器 */}
        <main className="flex-1 flex flex-col overflow-hidden relative bg-[#090d13]">
          {activeTab === 'overview' && (
            <MarketOverviewView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'stock_detail' && (
            <StockDetailView
              stockCode={selectedStockCode}
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
              onTriggerAiResearch={(stock) => {
                setSelectedStockCode(stock.code);
                setActiveTab('ai_assistant');
              }}
            />
          )}

          {activeTab === 'industry' && (
            <IndustryTerminalView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'screener' && (
            <StockScreenerView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'comparison' && (
            <CompanyComparisonView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'etf_fund' && (
            <ETFFundCenterView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'bond_market' && (
            <BondMarketView onSelectTab={setActiveTab} />
          )}

          {activeTab === 'macro' && (
            <MacroEconomyView onSelectTab={setActiveTab} />
          )}

          {activeTab === 'fx_commodity' && (
            <FXCommodityView onSelectTab={setActiveTab} />
          )}

          {activeTab === 'capital_flow' && (
            <CapitalFlowView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'market_breadth' && (
            <MarketBreadthView onSelectTab={setActiveTab} />
          )}

          {activeTab === 'watchlist' && (
            <WatchlistView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'portfolio' && (
            <PortfolioView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'quant_research' && (
            <QuantResearchView onSelectTab={setActiveTab} />
          )}

          {activeTab === 'news_filing' && (
            <NewsDisclosureView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'ai_assistant' && (
            <AiResearchAssistantView
              initialStock={STOCKS_DATABASE.find(s => s.code === selectedStockCode)}
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}

          {activeTab === 'calculators' && (
            <FinancialCalculatorsView onSelectTab={setActiveTab} />
          )}

          {activeTab === 'data_quality' && (
            <DataQualityView onSelectTab={setActiveTab} />
          )}

          {activeTab === 'audit_rbac' && (
            <AuditRbacView onSelectTab={setActiveTab} />
          )}

          {activeTab === 'workspace' && (
            <CustomWorkspaceView
              onSelectStock={handleSelectStock}
              onSelectTab={setActiveTab}
            />
          )}
        </main>
      </div>

      {/* 全局搜索弹窗 (Cmd/Ctrl+K) */}
      <GlobalSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectStock={handleSelectStock}
        onSelectSector={handleSelectSector}
        onSelectMacro={handleSelectMacro}
      />
    </div>
  );
}
