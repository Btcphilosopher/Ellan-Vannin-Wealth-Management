/**
 * 华市金融终端 - 模拟行情与金融数据库引擎
 * 严守合规准则：明确所有展示数据源自终端本地模拟推演引擎（演示数据）
 */

import {
  MarketIndex,
  StockQuote,
  IndustrySector,
  MarketBreadth,
  CapitalFlowDetail,
  ETFFundItem,
  BondItem,
  YieldCurveData,
  MacroIndicator,
  FXCommodityItem,
  NewsItem,
  AnnouncementItem,
  CompanyFinancials,
  KLineBar,
  DataQualityNode,
  AuditLogItem,
  UserRoleInfo
} from '../types';
import { calculateIndicators } from './indicators';

// 1. 全球核心指数与大类资产
export const INITIAL_MARKET_INDICES: MarketIndex[] = [
  {
    code: '000001.SH',
    name: '上证指数',
    region: 'CN',
    price: 3892.45,
    change: 12.37,
    changePct: 0.32,
    open: 3876.12,
    high: 3903.27,
    low: 3861.34,
    volume: '2.38亿手',
    turnover: '3142.67亿',
    updateTime: '15:00:00',
    status: '已收盘',
    sparkline: [3876, 3880, 3872, 3885, 3890, 3886, 3898, 3892.45]
  },
  {
    code: '399001.SZ',
    name: '深证成指',
    region: 'CN',
    price: 12631.78,
    change: 46.21,
    changePct: 0.37,
    open: 12580.4,
    high: 12680.1,
    low: 12550.0,
    volume: '3.12亿手',
    turnover: '4250.18亿',
    updateTime: '15:00:00',
    status: '已收盘',
    sparkline: [12580, 12600, 12590, 12620, 12650, 12610, 12631.78]
  },
  {
    code: '399006.SZ',
    name: '创业板指',
    region: 'CN',
    price: 2748.32,
    change: 18.64,
    changePct: 0.68,
    open: 2728.5,
    high: 2760.2,
    low: 2720.1,
    volume: '1.45亿手',
    turnover: '1890.35亿',
    updateTime: '15:00:00',
    status: '已收盘',
    sparkline: [2728, 2735, 2740, 2732, 2755, 2748.32]
  },
  {
    code: '000688.SH',
    name: '科创50',
    region: 'CN',
    price: 1182.76,
    change: 9.21,
    changePct: 0.79,
    open: 1172.0,
    high: 1190.5,
    low: 1169.8,
    volume: '0.62亿手',
    turnover: '892.14亿',
    updateTime: '15:00:00',
    status: '已收盘',
    sparkline: [1172, 1176, 1180, 1178, 1185, 1182.76]
  },
  {
    code: '000300.SH',
    name: '沪深300',
    region: 'CN',
    price: 4528.16,
    change: 14.72,
    changePct: 0.33,
    open: 4510.0,
    high: 4540.2,
    low: 4502.8,
    volume: '1.82亿手',
    turnover: '2680.45亿',
    updateTime: '15:00:00',
    status: '已收盘',
    sparkline: [4510, 4518, 4525, 4520, 4535, 4528.16]
  },
  {
    code: 'HSI.HK',
    name: '恒生指数',
    region: 'HK',
    price: 19842.15,
    change: 128.45,
    changePct: 0.65,
    open: 19720.0,
    high: 19910.3,
    low: 19680.2,
    volume: '1.98亿股',
    turnover: '1120.45亿港元',
    updateTime: '16:00:00',
    status: '已收盘',
    sparkline: [19720, 19780, 19820, 19800, 19860, 19842.15]
  },
  {
    code: 'HSTECH.HK',
    name: '恒生科技',
    region: 'HK',
    price: 4420.68,
    change: 52.34,
    changePct: 1.20,
    open: 4360.0,
    high: 4450.0,
    low: 4350.2,
    volume: '0.88亿股',
    turnover: '450.12亿港元',
    updateTime: '16:00:00',
    status: '已收盘',
    sparkline: [4360, 4390, 4410, 4400, 4435, 4420.68]
  },
  {
    code: 'NDX.US',
    name: '纳斯达克100',
    region: 'US',
    price: 19780.42,
    change: -45.18,
    changePct: -0.23,
    open: 19820.0,
    high: 19860.5,
    low: 19740.0,
    volume: '0.95亿股',
    turnover: '280.40亿美元',
    updateTime: '04:00:00',
    status: '已收盘',
    sparkline: [19820, 19840, 19810, 19760, 19780.42]
  },
  {
    code: 'SPX.US',
    name: '标普500',
    region: 'US',
    price: 5860.25,
    change: -6.42,
    changePct: -0.11,
    open: 5865.0,
    high: 5880.1,
    low: 5845.0,
    volume: '1.20亿股',
    turnover: '350.10亿美元',
    updateTime: '04:00:00',
    status: '已收盘',
    sparkline: [5865, 5872, 5860, 5850, 5860.25]
  },
  {
    code: 'USDCNY',
    name: '离岸人民币',
    region: 'GLOBAL',
    price: 7.1245,
    change: -0.0125,
    changePct: -0.18,
    open: 7.1370,
    high: 7.1420,
    low: 7.1210,
    volume: '--',
    turnover: '--',
    updateTime: '15:10:00',
    status: '交易中',
    sparkline: [7.137, 7.135, 7.130, 7.126, 7.1245]
  },
  {
    code: 'XAUUSD',
    name: '伦敦金现货',
    region: 'GLOBAL',
    price: 2685.40,
    change: 14.80,
    changePct: 0.55,
    open: 2670.0,
    high: 2692.1,
    low: 2668.5,
    volume: '--',
    turnover: '--',
    updateTime: '15:12:00',
    status: '交易中',
    sparkline: [2670, 2675, 2682, 2680, 2688, 2685.4]
  },
  {
    code: 'CL.US',
    name: 'WTI原油',
    region: 'GLOBAL',
    price: 71.85,
    change: -0.42,
    changePct: -0.58,
    open: 72.3,
    high: 72.8,
    low: 71.4,
    volume: '--',
    turnover: '--',
    updateTime: '15:10:00',
    status: '交易中',
    sparkline: [72.3, 72.5, 72.1, 71.7, 71.85]
  }
];

// 2. 核心A股与港股数据库 (覆盖白酒消费、新能源、半导体、银行、券商、创新药、高端制造等)
export const STOCKS_DATABASE: StockQuote[] = [
  {
    code: '600519',
    name: '贵州茅台',
    exchange: '沪市主板',
    sector: '主要消费',
    industry: '白酒',
    price: 1672.00,
    change: 47.20,
    changePct: 2.91,
    open: 1628.00,
    high: 1685.00,
    low: 1625.50,
    prevClose: 1624.80,
    volume: 123600,
    turnover: 204200,
    turnoverRate: 0.98,
    amplitude: 3.66,
    state: '已收盘',
    updateTime: '15:00:00',
    valuation: {
      peTTM: 26.85,
      peDynamic: 24.12,
      pb: 8.92,
      ps: 12.45,
      evEbitda: 18.30,
      dividendYield: 3.42,
      peg: 1.68,
      fcfYield: 4.15,
      totalMarketCap: 21003.60,
      floatMarketCap: 21003.60,
      totalShares: 12.56,
      floatShares: 12.56,
      high52w: 1890.00,
      low52w: 1400.00
    },
    profitability: {
      revenue: 1505.60,
      revenueYoY: 15.76,
      netProfit: 747.34,
      netProfitYoY: 19.16,
      grossMargin: 91.96,
      operatingMargin: 65.40,
      netMargin: 49.64,
      roe: 34.12,
      roa: 26.45,
      roic: 38.20,
      debtToAssetRatio: 12.45,
      currentRatio: 4.12,
      quickRatio: 3.45,
      cashEquivalents: 1820.50,
      interestCoverage: 99.0
    },
    profile: {
      code: '600519',
      name: '贵州茅台酒股份有限公司',
      exchange: '沪市主板',
      sector: '主要消费',
      industry: '白酒',
      establishedDate: '1999-11-20',
      ipoDate: '2001-08-27',
      headquarters: '贵州省仁怀市茅台镇',
      chairman: '张德芹',
      auditor: '天职国际会计师事务所',
      website: 'www.moutaichina.com',
      description: '贵州茅台酒股份有限公司是中国大曲酱香型白酒的鼻祖和典型代表，被尊为“国酒”。公司拥有极其深厚的品牌护城河与独特的地理生态微环境，核心产品为53度飞天茅台，具备强大的定价权与充沛的自由现金流。',
      businessSegments: [
        { name: '茅台酒系列', sharePct: 85.2, revenue: 1282.77 },
        { name: '系列酒（茅台1935等）', sharePct: 13.8, revenue: 207.77 },
        { name: '其他业务', sharePct: 1.0, revenue: 15.06 }
      ]
    },
    orderBook: {
      bids: [
        { level: 1, price: 1671.90, volume: 180 },
        { level: 2, price: 1671.50, volume: 340 },
        { level: 3, price: 1671.00, volume: 620 },
        { level: 4, price: 1670.00, volume: 1100 },
        { level: 5, price: 1669.00, volume: 1850 }
      ],
      asks: [
        { level: 1, price: 1672.00, volume: 220 },
        { level: 2, price: 1672.50, volume: 410 },
        { level: 3, price: 1673.00, volume: 750 },
        { level: 4, price: 1674.00, volume: 1200 },
        { level: 5, price: 1675.00, volume: 2300 }
      ],
      largeInflow: 48500,
      midInflow: 12000,
      retailInflow: -18000,
      outerVolume: 68500,
      innerVolume: 55100
    }
  },
  {
    code: '000858',
    name: '五粮液',
    exchange: '深市主板',
    sector: '主要消费',
    industry: '白酒',
    price: 145.30,
    change: 3.12,
    changePct: 2.19,
    open: 142.50,
    high: 146.80,
    low: 142.10,
    prevClose: 142.18,
    volume: 382000,
    turnover: 55400,
    turnoverRate: 0.98,
    amplitude: 3.31,
    state: '已收盘',
    updateTime: '15:00:00',
    valuation: {
      peTTM: 18.25,
      peDynamic: 16.80,
      pb: 4.15,
      ps: 6.85,
      evEbitda: 12.40,
      dividendYield: 4.12,
      peg: 1.45,
      fcfYield: 5.60,
      totalMarketCap: 5640.20,
      floatMarketCap: 5640.20,
      totalShares: 38.82,
      floatShares: 38.82,
      high52w: 168.00,
      low52w: 118.00
    },
    profitability: {
      revenue: 832.72,
      revenueYoY: 12.58,
      netProfit: 302.11,
      netProfitYoY: 13.19,
      grossMargin: 75.80,
      operatingMargin: 48.20,
      netMargin: 36.28,
      roe: 25.10,
      roa: 19.80,
      roic: 28.50,
      debtToAssetRatio: 18.20,
      currentRatio: 3.50,
      quickRatio: 2.90,
      cashEquivalents: 980.40,
      interestCoverage: 88.0
    },
    profile: {
      code: '000858',
      name: '宜宾五粮液股份有限公司',
      exchange: '深市主板',
      sector: '主要消费',
      industry: '白酒',
      establishedDate: '1998-03-03',
      ipoDate: '1998-04-27',
      headquarters: '四川省宜宾市岷江西路150号',
      chairman: '曾从钦',
      auditor: '四川华信会计师事务所',
      website: 'www.wuliangye.com.cn',
      description: '五粮液是中国浓香型白酒的典型代表与龙头企业，以高粱、大米、糯米、小麦和玉米五种粮食为原料，陈酿千百年传统技艺，核心产品为第八代经典五粮液。',
      businessSegments: [
        { name: '五粮液酒', sharePct: 80.5, revenue: 670.34 },
        { name: '系列酒产品', sharePct: 16.5, revenue: 137.40 },
        { name: '其他业务', sharePct: 3.0, revenue: 24.98 }
      ]
    },
    orderBook: {
      bids: [
        { level: 1, price: 145.28, volume: 540 },
        { level: 2, price: 145.20, volume: 890 },
        { level: 3, price: 145.10, volume: 1450 },
        { level: 4, price: 145.00, volume: 2900 },
        { level: 5, price: 144.80, volume: 4100 }
      ],
      asks: [
        { level: 1, price: 145.30, volume: 480 },
        { level: 2, price: 145.40, volume: 920 },
        { level: 3, price: 145.50, volume: 1600 },
        { level: 4, price: 145.60, volume: 3100 },
        { level: 5, price: 145.80, volume: 5200 }
      ],
      largeInflow: 18200,
      midInflow: 4500,
      retailInflow: -8900,
      outerVolume: 198000,
      innerVolume: 184000
    }
  },
  {
    code: '300750',
    name: '宁德时代',
    exchange: '创业板',
    sector: '新能源与电池',
    industry: '锂电池',
    price: 268.50,
    change: 8.90,
    changePct: 3.43,
    open: 260.00,
    high: 271.20,
    low: 259.50,
    prevClose: 259.60,
    volume: 485000,
    turnover: 129000,
    turnoverRate: 1.10,
    amplitude: 4.51,
    state: '已收盘',
    updateTime: '15:00:00',
    valuation: {
      peTTM: 23.40,
      peDynamic: 20.80,
      pb: 5.20,
      ps: 2.80,
      evEbitda: 14.60,
      dividendYield: 1.85,
      peg: 1.15,
      fcfYield: 4.80,
      totalMarketCap: 11808.50,
      floatMarketCap: 11808.50,
      totalShares: 43.98,
      floatShares: 43.98,
      high52w: 298.00,
      low52w: 145.00
    },
    profitability: {
      revenue: 4009.17,
      revenueYoY: 22.01,
      netProfit: 441.21,
      netProfitYoY: 43.58,
      grossMargin: 27.28,
      operatingMargin: 14.10,
      netMargin: 11.01,
      roe: 24.80,
      roa: 8.90,
      roic: 18.50,
      debtToAssetRatio: 64.20,
      currentRatio: 1.45,
      quickRatio: 1.20,
      cashEquivalents: 1320.00,
      interestCoverage: 18.5
    },
    profile: {
      code: '300750',
      name: '宁德时代新能源科技股份有限公司',
      exchange: '创业板',
      sector: '新能源与电池',
      industry: '锂电池',
      establishedDate: '2011-12-16',
      ipoDate: '2018-06-11',
      headquarters: '福建省宁德市蕉城区漳湾镇新港路2号',
      chairman: '曾毓群',
      auditor: '致同会计师事务所',
      website: 'www.catl.com',
      description: '宁德时代是全球领先的新能源创新科技公司，动力电池系统使用量连续多年位列全球第一，储能电池出货量连续多年全球第一。技术涵盖麒麟电池、神行超充电池等领先方案。',
      businessSegments: [
        { name: '动力电池系统', sharePct: 71.1, revenue: 2850.52 },
        { name: '储能电池系统', sharePct: 14.9, revenue: 597.37 },
        { name: '电池材料及回收', sharePct: 8.4, revenue: 336.77 },
        { name: '电池矿产资源', sharePct: 5.6, revenue: 224.51 }
      ]
    },
    orderBook: {
      bids: [
        { level: 1, price: 268.45, volume: 320 },
        { level: 2, price: 268.30, volume: 680 },
        { level: 3, price: 268.00, volume: 1540 },
        { level: 4, price: 267.50, volume: 3200 },
        { level: 5, price: 267.00, volume: 5400 }
      ],
      asks: [
        { level: 1, price: 268.50, volume: 410 },
        { level: 2, price: 268.80, volume: 820 },
        { level: 3, price: 269.00, volume: 1900 },
        { level: 4, price: 269.50, volume: 3600 },
        { level: 5, price: 270.00, volume: 6800 }
      ],
      largeInflow: 34200,
      midInflow: 8500,
      retailInflow: -14200,
      outerVolume: 254000,
      innerVolume: 231000
    }
  },
  {
    code: '002594',
    name: '比亚迪',
    exchange: '深市主板',
    sector: '汽车制造',
    industry: '新能源汽车',
    price: 304.20,
    change: 7.40,
    changePct: 2.49,
    open: 297.00,
    high: 308.50,
    low: 296.80,
    prevClose: 296.80,
    volume: 312000,
    turnover: 94500,
    turnoverRate: 1.07,
    amplitude: 3.94,
    state: '已收盘',
    updateTime: '15:00:00',
    valuation: {
      peTTM: 21.60,
      peDynamic: 18.90,
      pb: 5.60,
      ps: 1.35,
      evEbitda: 11.20,
      dividendYield: 1.25,
      peg: 0.95,
      fcfYield: 3.90,
      totalMarketCap: 8856.40,
      floatMarketCap: 8856.40,
      totalShares: 29.11,
      floatShares: 29.11,
      high52w: 320.00,
      low52w: 168.00
    },
    profitability: {
      revenue: 6023.15,
      revenueYoY: 42.04,
      netProfit: 300.41,
      netProfitYoY: 80.72,
      grossMargin: 20.21,
      operatingMargin: 6.80,
      netMargin: 4.99,
      roe: 23.50,
      roa: 5.80,
      roic: 16.20,
      debtToAssetRatio: 77.40,
      currentRatio: 0.85,
      quickRatio: 0.65,
      cashEquivalents: 1090.00,
      interestCoverage: 12.8
    },
    profile: {
      code: '002594',
      name: '比亚迪股份有限公司',
      exchange: '深市主板',
      sector: '汽车制造',
      industry: '新能源汽车',
      establishedDate: '1995-02-10',
      ipoDate: '2011-06-30',
      headquarters: '广东省深圳市坪山区比亚迪路3009号',
      chairman: '王传福',
      auditor: '安永华明会计师事务所',
      website: 'www.byd.com',
      description: '比亚迪是一家致力于“用技术创新，满足人们对美好生活的向往”的高新技术企业，业务横跨汽车、轨道交通、新能源和电子四大产业，在新能源汽车与动力电池领域具备全产业链垂直整合优势。',
      businessSegments: [
        { name: '汽车及电池产品', sharePct: 80.3, revenue: 4836.59 },
        { name: '手机部件及组装', sharePct: 19.5, revenue: 1174.51 },
        { name: '其他业务', sharePct: 0.2, revenue: 12.05 }
      ]
    },
    orderBook: {
      bids: [
        { level: 1, price: 304.10, volume: 290 },
        { level: 2, price: 304.00, volume: 740 },
        { level: 3, price: 303.80, volume: 1200 },
        { level: 4, price: 303.50, volume: 2400 },
        { level: 5, price: 303.00, volume: 4600 }
      ],
      asks: [
        { level: 1, price: 304.20, volume: 380 },
        { level: 2, price: 304.50, volume: 690 },
        { level: 3, price: 305.00, volume: 1850 },
        { level: 4, price: 305.50, volume: 3100 },
        { level: 5, price: 306.00, volume: 5500 }
      ],
      largeInflow: 28400,
      midInflow: 6200,
      retailInflow: -11500,
      outerVolume: 165000,
      innerVolume: 147000
    }
  },
  {
    code: '601318',
    name: '中国平安',
    exchange: '沪市主板',
    sector: '金融',
    industry: '保险',
    price: 52.38,
    change: 1.31,
    changePct: 2.56,
    open: 51.20,
    high: 52.80,
    low: 51.05,
    prevClose: 51.07,
    volume: 487200,
    turnover: 253100,
    turnoverRate: 0.45,
    amplitude: 3.43,
    state: '已收盘',
    updateTime: '15:00:00',
    valuation: {
      peTTM: 8.45,
      peDynamic: 7.90,
      pb: 0.88,
      ps: 0.95,
      evEbitda: 6.20,
      dividendYield: 5.12,
      peg: 0.72,
      fcfYield: 8.50,
      totalMarketCap: 9540.20,
      floatMarketCap: 9540.20,
      totalShares: 182.10,
      floatShares: 182.10,
      high52w: 62.00,
      low52w: 37.50
    },
    profitability: {
      revenue: 10320.40,
      revenueYoY: 5.40,
      netProfit: 1128.50,
      netProfitYoY: 12.80,
      grossMargin: 38.50,
      operatingMargin: 15.20,
      netMargin: 10.93,
      roe: 12.40,
      roa: 1.20,
      roic: 10.80,
      debtToAssetRatio: 88.50,
      currentRatio: 1.10,
      quickRatio: 1.10,
      cashEquivalents: 4500.00,
      interestCoverage: 8.5
    },
    profile: {
      code: '601318',
      name: '中国平安保险(集团)股份有限公司',
      exchange: '沪市主板',
      sector: '金融',
      industry: '保险',
      establishedDate: '1988-03-21',
      ipoDate: '2007-03-01',
      headquarters: '广东省深圳市福田区益田路5033号平安金融中心',
      chairman: '马明哲',
      auditor: '普华永道中天会计师事务所',
      website: 'www.pingan.cn',
      description: '中国平安是中国第一家股份制保险企业，发展成为金融科技驱动的“综合金融+医疗养老”服务集团，旗下涵盖寿险、产险、平安银行、平安信托、平安证券等板块。',
      businessSegments: [
        { name: '寿险及健康险', sharePct: 62.4, revenue: 6440.00 },
        { name: '财产保险', sharePct: 22.1, revenue: 2280.80 },
        { name: '银行业务', sharePct: 12.5, revenue: 1290.05 },
        { name: '其他资产管理及科技', sharePct: 3.0, revenue: 309.55 }
      ]
    },
    orderBook: {
      bids: [
        { level: 1, price: 52.35, volume: 1200 },
        { level: 2, price: 52.30, volume: 2800 },
        { level: 3, price: 52.20, volume: 6400 },
        { level: 4, price: 52.10, volume: 12000 },
        { level: 5, price: 52.00, volume: 25000 }
      ],
      asks: [
        { level: 1, price: 52.38, volume: 1500 },
        { level: 2, price: 52.40, volume: 3200 },
        { level: 3, price: 52.50, volume: 7800 },
        { level: 4, price: 52.60, volume: 14500 },
        { level: 5, price: 52.80, volume: 28000 }
      ],
      largeInflow: 41200,
      midInflow: 8900,
      retailInflow: -18500,
      outerVolume: 260000,
      innerVolume: 227200
    }
  },
  {
    code: '600036',
    name: '招商银行',
    exchange: '沪市主板',
    sector: '金融',
    industry: '银行',
    price: 43.17,
    change: 0.94,
    changePct: 2.23,
    open: 42.40,
    high: 43.50,
    low: 42.20,
    prevClose: 42.23,
    volume: 621500,
    turnover: 267800,
    turnoverRate: 0.30,
    amplitude: 3.08,
    state: '已收盘',
    updateTime: '15:00:00',
    valuation: {
      peTTM: 6.85,
      peDynamic: 6.40,
      pb: 0.92,
      ps: 2.45,
      evEbitda: 5.10,
      dividendYield: 5.68,
      peg: 0.88,
      fcfYield: 9.20,
      totalMarketCap: 10887.40,
      floatMarketCap: 10887.40,
      totalShares: 252.20,
      floatShares: 252.20,
      high52w: 48.00,
      low52w: 28.50
    },
    profitability: {
      revenue: 3391.23,
      revenueYoY: -1.64,
      netProfit: 1466.02,
      netProfitYoY: 6.22,
      grossMargin: 52.40,
      operatingMargin: 48.20,
      netMargin: 43.23,
      roe: 15.65,
      roa: 1.38,
      roic: 14.20,
      debtToAssetRatio: 90.80,
      currentRatio: 1.05,
      quickRatio: 1.05,
      cashEquivalents: 6200.00,
      interestCoverage: 9.9
    },
    profile: {
      code: '600036',
      name: '招商银行股份有限公司',
      exchange: '沪市主板',
      sector: '金融',
      industry: '银行',
      establishedDate: '1987-03-31',
      ipoDate: '2002-04-09',
      headquarters: '广东省深圳市福田区深南大道7088号招商银行大厦',
      chairman: '缪建民',
      auditor: '德勤华永会计师事务所',
      website: 'www.cmbchina.com',
      description: '招商银行是中国境内第一家完全由企业法人持股的股份制商业银行，被誉为“零售之王”。凭借优质的零售客群基础、招商银行App生态和强大的财富管理体系，净息差与资产质量常年领跑同业。',
      businessSegments: [
        { name: '零售金融业务', sharePct: 55.4, revenue: 1878.74 },
        { name: '批发金融业务', sharePct: 36.8, revenue: 1248.00 },
        { name: '其他业务', sharePct: 7.8, revenue: 264.49 }
      ]
    },
    orderBook: {
      bids: [
        { level: 1, price: 43.15, volume: 2200 },
        { level: 2, price: 43.10, volume: 4800 },
        { level: 3, price: 43.00, volume: 9500 },
        { level: 4, price: 42.90, volume: 18000 },
        { level: 5, price: 42.80, volume: 32000 }
      ],
      asks: [
        { level: 1, price: 43.17, volume: 1800 },
        { level: 2, price: 43.20, volume: 3900 },
        { level: 3, price: 43.30, volume: 8200 },
        { level: 4, price: 43.40, volume: 16500 },
        { level: 5, price: 43.50, volume: 31000 }
      ],
      largeInflow: 38500,
      midInflow: 9200,
      retailInflow: -14800,
      outerVolume: 340000,
      innerVolume: 281500
    }
  },
  {
    code: '688981',
    name: '中芯国际',
    exchange: '科创板',
    sector: '信息科技',
    industry: '半导体芯片',
    price: 94.60,
    change: 4.80,
    changePct: 5.35,
    open: 90.20,
    high: 96.50,
    low: 89.80,
    prevClose: 89.80,
    volume: 520000,
    turnover: 485000,
    turnoverRate: 2.65,
    amplitude: 7.46,
    state: '已收盘',
    updateTime: '15:00:00',
    valuation: {
      peTTM: 88.50,
      peDynamic: 76.20,
      pb: 4.85,
      ps: 11.20,
      evEbitda: 28.40,
      dividendYield: 0.35,
      peg: 2.10,
      fcfYield: 1.20,
      totalMarketCap: 7520.40,
      floatMarketCap: 7520.40,
      totalShares: 79.50,
      floatShares: 79.50,
      high52w: 110.00,
      low52w: 42.00
    },
    profitability: {
      revenue: 452.80,
      revenueYoY: 28.50,
      netProfit: 68.40,
      netProfitYoY: 34.20,
      grossMargin: 22.80,
      operatingMargin: 15.60,
      netMargin: 15.11,
      roe: 6.80,
      roa: 3.50,
      roic: 5.20,
      debtToAssetRatio: 35.20,
      currentRatio: 2.10,
      quickRatio: 1.85,
      cashEquivalents: 420.00,
      interestCoverage: 14.2
    },
    profile: {
      code: '688981',
      name: '中芯国际集成电路制造有限公司',
      exchange: '科创板',
      sector: '信息科技',
      industry: '半导体芯片',
      establishedDate: '2000-04-03',
      ipoDate: '2020-07-16',
      headquarters: '上海市浦东新区张江路18号',
      chairman: '刘训峰',
      auditor: '安永华明会计师事务所',
      website: 'www.smics.com',
      description: '中芯国际是中国大陆技术最先进、配套最完善、规模最大、跨国经营的集成电路制造企业集团，提供0.35微米到先进逻辑工艺的晶圆代工与技术服务。',
      businessSegments: [
        { name: '晶圆代工制造', sharePct: 91.2, revenue: 412.95 },
        { name: '光掩膜及测试', sharePct: 6.5, revenue: 29.43 },
        { name: '其他业务', sharePct: 2.3, revenue: 10.42 }
      ]
    },
    orderBook: {
      bids: [
        { level: 1, price: 94.50, volume: 850 },
        { level: 2, price: 94.40, volume: 1600 },
        { level: 3, price: 94.20, volume: 3200 },
        { level: 4, price: 94.00, volume: 6800 },
        { level: 5, price: 93.80, volume: 11000 }
      ],
      asks: [
        { level: 1, price: 94.60, volume: 920 },
        { level: 2, price: 94.80, volume: 2100 },
        { level: 3, price: 95.00, volume: 4800 },
        { level: 4, price: 95.50, volume: 8900 },
        { level: 5, price: 96.00, volume: 15200 }
      ],
      largeInflow: 68500,
      midInflow: 18200,
      retailInflow: -32000,
      outerVolume: 310000,
      innerVolume: 210000
    }
  },
  {
    code: '600900',
    name: '长江电力',
    exchange: '沪市主板',
    sector: '公用事业',
    industry: '电力水利',
    price: 28.76,
    change: 0.46,
    changePct: 1.62,
    open: 28.35,
    high: 28.90,
    low: 28.30,
    prevClose: 28.30,
    volume: 392700,
    turnover: 112300,
    turnoverRate: 0.16,
    amplitude: 2.12,
    state: '已收盘',
    updateTime: '15:00:00',
    valuation: {
      peTTM: 20.40,
      peDynamic: 19.80,
      pb: 3.12,
      ps: 8.40,
      evEbitda: 14.10,
      dividendYield: 3.65,
      peg: 1.80,
      fcfYield: 5.40,
      totalMarketCap: 7037.60,
      floatMarketCap: 7037.60,
      totalShares: 244.70,
      floatShares: 244.70,
      high52w: 30.50,
      low52w: 22.80
    },
    profitability: {
      revenue: 781.12,
      revenueYoY: 13.43,
      netProfit: 272.46,
      netProfitYoY: 14.81,
      grossMargin: 58.20,
      operatingMargin: 46.10,
      netMargin: 34.88,
      roe: 15.20,
      roa: 5.80,
      roic: 8.90,
      debtToAssetRatio: 52.40,
      currentRatio: 0.45,
      quickRatio: 0.42,
      cashEquivalents: 180.00,
      interestCoverage: 6.8
    },
    profile: {
      code: '600900',
      name: '中国长江电力股份有限公司',
      exchange: '沪市主板',
      sector: '公用事业',
      industry: '电力水利',
      establishedDate: '2002-09-29',
      ipoDate: '2003-11-18',
      headquarters: '北京市海淀区玉渊潭南路1号B座',
      chairman: '雷鸣山',
      auditor: '大华会计师事务所',
      website: 'www.cypc.com.cn',
      description: '长江电力是全球最大的水电上市公司，统筹管理运行三峡、葛洲坝、溪洛渡、向家坝、乌东德、白鹤滩等6座巨型梯级水电站，形成世界最大清洁能源走廊。',
      businessSegments: [
        { name: '梯级水电站发电', sharePct: 95.8, revenue: 748.31 },
        { name: '配售电及投资业务', sharePct: 4.2, revenue: 32.81 }
      ]
    },
    orderBook: {
      bids: [
        { level: 1, price: 28.74, volume: 1800 },
        { level: 2, price: 28.70, volume: 3900 },
        { level: 3, price: 28.65, volume: 8500 },
        { level: 4, price: 28.60, volume: 15000 },
        { level: 5, price: 28.50, volume: 29000 }
      ],
      asks: [
        { level: 1, price: 28.76, volume: 1400 },
        { level: 2, price: 28.80, volume: 3200 },
        { level: 3, price: 28.85, volume: 7600 },
        { level: 4, price: 28.90, volume: 14000 },
        { level: 5, price: 29.00, volume: 34000 }
      ],
      largeInflow: 21500,
      midInflow: 5400,
      retailInflow: -7800,
      outerVolume: 215000,
      innerVolume: 177700
    }
  },
  {
    code: '300059',
    name: '东方财富',
    exchange: '创业板',
    sector: '金融',
    industry: '证券与金融IT',
    price: 24.85,
    change: 1.12,
    changePct: 4.72,
    open: 23.90,
    high: 25.40,
    low: 23.80,
    prevClose: 23.73,
    volume: 1850000,
    turnover: 456000,
    turnoverRate: 1.45,
    amplitude: 6.74,
    state: '已收盘',
    updateTime: '15:00:00',
    valuation: {
      peTTM: 35.40,
      peDynamic: 31.20,
      pb: 4.10,
      ps: 18.50,
      evEbitda: 22.10,
      dividendYield: 0.95,
      peg: 1.55,
      fcfYield: 3.10,
      totalMarketCap: 3940.50,
      floatMarketCap: 3940.50,
      totalShares: 158.57,
      floatShares: 158.57,
      high52w: 29.80,
      low52w: 10.80
    },
    profitability: {
      revenue: 110.80,
      revenueYoY: 18.40,
      netProfit: 81.93,
      netProfitYoY: 22.10,
      grossMargin: 65.40,
      operatingMargin: 74.20,
      netMargin: 73.94,
      roe: 12.80,
      roa: 3.40,
      roic: 11.50,
      debtToAssetRatio: 68.20,
      currentRatio: 1.80,
      quickRatio: 1.80,
      cashEquivalents: 850.00,
      interestCoverage: 16.5
    },
    profile: {
      code: '300059',
      name: '东方财富信息股份有限公司',
      exchange: '创业板',
      sector: '金融',
      industry: '证券与金融IT',
      establishedDate: '2005-01-20',
      ipoDate: '2010-03-19',
      headquarters: '上海市徐汇区宛平南路88号东方财富大厦',
      chairman: '其实',
      auditor: '立信会计师事务所',
      website: 'www.eastmoney.com',
      description: '东方财富是中国领先的互联网金融服务平台综合运营商，拥有东方财富网、天天基金网等海量用户流量矩阵，旗下涵盖证券、基金代销、期货等全牌照牌照。',
      businessSegments: [
        { name: '证券经纪与两融', sharePct: 62.1, revenue: 68.81 },
        { name: '天天基金电子商务', sharePct: 34.5, revenue: 38.23 },
        { name: '金融数据服务', sharePct: 3.4, revenue: 3.76 }
      ]
    },
    orderBook: {
      bids: [
        { level: 1, price: 24.80, volume: 15000 },
        { level: 2, price: 24.75, volume: 28000 },
        { level: 3, price: 24.70, volume: 54000 },
        { level: 4, price: 24.60, volume: 92000 },
        { level: 5, price: 24.50, volume: 180000 }
      ],
      asks: [
        { level: 1, price: 24.85, volume: 12000 },
        { level: 2, price: 24.90, volume: 26000 },
        { level: 3, price: 25.00, volume: 68000 },
        { level: 4, price: 25.10, volume: 110000 },
        { level: 5, price: 25.20, volume: 195000 }
      ],
      largeInflow: 54200,
      midInflow: 18500,
      retailInflow: -28000,
      outerVolume: 1020000,
      innerVolume: 830000
    }
  }
];

// 3. 行业板块与热力图数据 (20+大类行业)
export const INDUSTRY_SECTORS: IndustrySector[] = [
  {
    code: 'BK0001',
    name: '半导体芯片',
    category: '科技',
    changePct: 2.84,
    turnover: 684.50,
    pe: 58.4,
    pb: 4.8,
    roe: 8.5,
    stockCount: 145,
    upCount: 118,
    downCount: 22,
    leadingStock: { code: '688981', name: '中芯国际', changePct: 5.35, price: 94.60 },
    worstStock: { code: '688012', name: '中微公司', changePct: -0.85, price: 182.40 },
    netCapitalInflow: 38.45,
    topHoldings: ['688981', '688012', '603501']
  },
  {
    code: 'BK0002',
    name: '新能源与电池',
    category: '制造',
    changePct: 2.31,
    turnover: 542.10,
    pe: 22.8,
    pb: 3.9,
    roe: 18.2,
    stockCount: 198,
    upCount: 154,
    downCount: 38,
    leadingStock: { code: '300750', name: '宁德时代', changePct: 3.43, price: 268.50 },
    worstStock: { code: '002466', name: '天齐锂业', changePct: -0.42, price: 38.90 },
    netCapitalInflow: 29.12,
    topHoldings: ['300750', '002594', '002460']
  },
  {
    code: 'BK0003',
    name: '人工智能与软件',
    category: '科技',
    changePct: 2.12,
    turnover: 495.80,
    pe: 65.2,
    pb: 5.4,
    roe: 9.1,
    stockCount: 210,
    upCount: 168,
    downCount: 36,
    leadingStock: { code: '002230', name: '科大讯飞', changePct: 4.85, price: 48.20 },
    worstStock: { code: '300418', name: '昆仑万维', changePct: -1.15, price: 34.50 },
    netCapitalInflow: 22.50,
    topHoldings: ['002230', '601360', '300033']
  },
  {
    code: 'BK0004',
    name: '证券与金融IT',
    category: '金融',
    changePct: 1.87,
    turnover: 412.30,
    pe: 18.5,
    pb: 1.45,
    roe: 9.8,
    stockCount: 52,
    upCount: 46,
    downCount: 5,
    leadingStock: { code: '300059', name: '东方财富', changePct: 4.72, price: 24.85 },
    worstStock: { code: '600030', name: '中信证券', changePct: 0.85, price: 29.40 },
    netCapitalInflow: 18.90,
    topHoldings: ['300059', '600030', '601211']
  },
  {
    code: 'BK0005',
    name: '白酒与高端消费',
    category: '消费',
    changePct: 1.45,
    turnover: 320.40,
    pe: 22.1,
    pb: 5.8,
    roe: 28.5,
    stockCount: 38,
    upCount: 32,
    downCount: 5,
    leadingStock: { code: '600519', name: '贵州茅台', changePct: 2.91, price: 1672.00 },
    worstStock: { code: '600809', name: '山西汾酒', changePct: 1.10, price: 215.40 },
    netCapitalInflow: 15.60,
    topHoldings: ['600519', '000858', '000568']
  },
  {
    code: 'BK0006',
    name: '创新药与生物制药',
    category: '医药',
    changePct: 1.15,
    turnover: 285.60,
    pe: 34.2,
    pb: 3.4,
    roe: 11.2,
    stockCount: 165,
    upCount: 112,
    downCount: 48,
    leadingStock: { code: '600276', name: '恒瑞医药', changePct: 2.85, price: 49.80 },
    worstStock: { code: '300122', name: '智飞生物', changePct: -1.40, price: 28.90 },
    netCapitalInflow: 9.80,
    topHoldings: ['600276', '300760', '688180']
  },
  {
    code: 'BK0007',
    name: '银行',
    category: '金融',
    changePct: 0.82,
    turnover: 198.40,
    pe: 5.8,
    pb: 0.65,
    roe: 11.5,
    stockCount: 42,
    upCount: 36,
    downCount: 4,
    leadingStock: { code: '600036', name: '招商银行', changePct: 2.23, price: 43.17 },
    worstStock: { code: '601398', name: '工商银行', changePct: 0.35, price: 6.22 },
    netCapitalInflow: 12.40,
    topHoldings: ['600036', '601398', '601939']
  },
  {
    code: 'BK0008',
    name: '电力与公用事业',
    category: '基础设施',
    changePct: 0.65,
    turnover: 145.20,
    pe: 16.2,
    pb: 1.85,
    roe: 10.4,
    stockCount: 88,
    upCount: 58,
    downCount: 26,
    leadingStock: { code: '600900', name: '长江电力', changePct: 1.62, price: 28.76 },
    worstStock: { code: '600011', name: '华能国际', changePct: -0.55, price: 7.45 },
    netCapitalInflow: 6.20,
    topHoldings: ['600900', '600025', '600905']
  }
];

// 4. 市场宽度与情绪
export const MOCK_MARKET_BREADTH: MarketBreadth = {
  upCount: 2383,
  downCount: 1231,
  flatCount: 219,
  limitUpCount: 68,
  limitDownCount: 4,
  totalTurnover: 9283.20,
  aboveMA20Count: 2840,
  aboveMA50Count: 2450,
  aboveMA200Count: 1980,
  newHigh52wCount: 112,
  newLow52wCount: 18,
  volumeExpansionRatio: 1.28,
  sentimentScore: 74.5
};

// 5. 资金流向明细
export const MOCK_CAPITAL_FLOW: CapitalFlowDetail = {
  northboundToday: 48.32,
  northboundHistorical: [
    { date: '09-10', shanghaiInflow: 12.4, shenzhenInflow: 8.6, total: 21.0 },
    { date: '09-11', shanghaiInflow: -4.2, shenzhenInflow: 2.1, total: -2.1 },
    { date: '09-12', shanghaiInflow: 18.5, shenzhenInflow: 14.8, total: 33.3 },
    { date: '09-13', shanghaiInflow: 8.2, shenzhenInflow: 6.5, total: 14.7 },
    { date: '09-15', shanghaiInflow: 28.12, shenzhenInflow: 20.20, total: 48.32 }
  ],
  southboundToday: 12.76,
  mainInflowToday: 35.21,
  retailInflowToday: -28.40,
  sectorFlows: [
    { name: '半导体芯片', inflow: 38.45, changePct: 2.84 },
    { name: '新能源与电池', inflow: 29.12, changePct: 2.31 },
    { name: '人工智能与软件', inflow: 22.50, changePct: 2.12 },
    { name: '证券金融', inflow: 18.90, changePct: 1.87 },
    { name: '白酒消费', inflow: 15.60, changePct: 1.45 }
  ],
  stockFlows: [
    { code: '688981', name: '中芯国际', inflow: 6.85, changePct: 5.35 },
    { code: '600519', name: '贵州茅台', inflow: 4.85, changePct: 2.91 },
    { code: '300750', name: '宁德时代', inflow: 3.42, changePct: 3.43 },
    { code: '300059', name: '东方财富', inflow: 5.42, changePct: 4.72 },
    { code: '601318', name: '中国平安', inflow: 4.12, changePct: 2.56 }
  ]
};

// 6. 债券收益率曲线数据 (1M 至 30Y 中债国债收益率)
export const MOCK_YIELD_CURVE: YieldCurveData[] = [
  { tenor: '1M', today: 1.25, yesterday: 1.26, oneWeekAgo: 1.28, oneMonthAgo: 1.35, oneYearAgo: 1.80 },
  { tenor: '3M', today: 1.32, yesterday: 1.33, oneWeekAgo: 1.36, oneMonthAgo: 1.42, oneYearAgo: 1.95 },
  { tenor: '6M', today: 1.38, yesterday: 1.40, oneWeekAgo: 1.42, oneMonthAgo: 1.50, oneYearAgo: 2.05 },
  { tenor: '1Y', today: 1.45, yesterday: 1.46, oneWeekAgo: 1.48, oneMonthAgo: 1.58, oneYearAgo: 2.18 },
  { tenor: '2Y', today: 1.54, yesterday: 1.55, oneWeekAgo: 1.58, oneMonthAgo: 1.68, oneYearAgo: 2.32 },
  { tenor: '3Y', today: 1.62, yesterday: 1.64, oneWeekAgo: 1.67, oneMonthAgo: 1.78, oneYearAgo: 2.45 },
  { tenor: '5Y', today: 1.78, yesterday: 1.80, oneWeekAgo: 1.83, oneMonthAgo: 1.95, oneYearAgo: 2.62 },
  { tenor: '7Y', today: 1.95, yesterday: 1.97, oneWeekAgo: 2.00, oneMonthAgo: 2.12, oneYearAgo: 2.75 },
  { tenor: '10Y', today: 2.08, yesterday: 2.10, oneWeekAgo: 2.14, oneMonthAgo: 2.25, oneYearAgo: 2.88 },
  { tenor: '20Y', today: 2.22, yesterday: 2.24, oneWeekAgo: 2.28, oneMonthAgo: 2.40, oneYearAgo: 3.05 },
  { tenor: '30Y', today: 2.31, yesterday: 2.33, oneWeekAgo: 2.38, oneMonthAgo: 2.50, oneYearAgo: 3.18 }
];

export const MOCK_BONDS_LIST: BondItem[] = [
  {
    code: '240001',
    name: '24附息国债01',
    type: '国债',
    maturityYears: 10,
    couponRate: 2.15,
    ytm: 2.08,
    duration: 8.92,
    convexity: 92.4,
    creditRating: 'AAA',
    cleanPrice: 100.58,
    dirtyPrice: 101.42,
    volume: 85400
  },
  {
    code: '240004',
    name: '24附息国债04',
    type: '国债',
    maturityYears: 30,
    couponRate: 2.47,
    ytm: 2.31,
    duration: 21.45,
    convexity: 480.2,
    creditRating: 'AAA',
    cleanPrice: 102.80,
    dirtyPrice: 103.95,
    volume: 124000
  },
  {
    code: '230210',
    name: '23国开10',
    type: '金融债',
    maturityYears: 10,
    couponRate: 2.72,
    ytm: 2.18,
    duration: 8.65,
    convexity: 88.5,
    creditRating: 'AAA',
    cleanPrice: 104.20,
    dirtyPrice: 105.10,
    volume: 68900
  }
];

// 7. 宏观经济指标数据库
export const MOCK_MACRO_INDICATORS: MacroIndicator[] = [
  {
    id: 'GDP',
    name: '国内生产总值 (GDP同比)',
    category: '增长',
    latestValue: '5.2%',
    previousValue: '5.3%',
    forecastValue: '5.1% (市场调查预测)',
    publishDate: '2026-07-15',
    frequency: '季度',
    source: '国家统计局',
    unit: '%',
    description: '衡量中国经济总体规模及增长速度的核心宏观经济指标。',
    history: [
      { date: '2025Q1', value: 5.3 },
      { date: '2025Q2', value: 4.7 },
      { date: '2025Q3', value: 4.6 },
      { date: '2025Q4', value: 5.2 },
      { date: '2026Q1', value: 5.3 },
      { date: '2026Q2', value: 5.2, forecast: 5.1 }
    ]
  },
  {
    id: 'CPI',
    name: '居民消费价格指数 (CPI同比)',
    category: '通胀',
    latestValue: '0.6%',
    previousValue: '0.5%',
    forecastValue: '0.7% (市场调查预测)',
    publishDate: '2026-09-09',
    frequency: '月度',
    source: '国家统计局',
    unit: '%',
    description: '反映居民家庭购买消费品及服务价格水平的变动情况，衡量通胀/通缩压力。',
    history: [
      { date: '2026-03', value: 0.1 },
      { date: '2026-04', value: 0.3 },
      { date: '2026-05', value: 0.3 },
      { date: '2026-06', value: 0.2 },
      { date: '2026-07', value: 0.5 },
      { date: '2026-08', value: 0.6, forecast: 0.7 }
    ]
  },
  {
    id: 'PMI_MFG',
    name: '制造业采购经理指数 (PMI)',
    category: '增长',
    latestValue: '50.3',
    previousValue: '49.8',
    forecastValue: '50.1 (市场调查预测)',
    publishDate: '2026-08-31',
    frequency: '月度',
    source: '国家统计局 / 中国物流与采购联合会',
    unit: '点',
    description: '制造业景气度先行指标，50点为荣枯分水岭。高于50代表制造业扩张。',
    history: [
      { date: '2026-03', value: 50.8 },
      { date: '2026-04', value: 50.4 },
      { date: '2026-05', value: 49.5 },
      { date: '2026-06', value: 49.5 },
      { date: '2026-07', value: 49.8 },
      { date: '2026-08', value: 50.3, forecast: 50.1 }
    ]
  },
  {
    id: 'M2',
    name: '广义货币供应量 (M2同比)',
    category: '金融货币',
    latestValue: '6.8%',
    previousValue: '6.3%',
    forecastValue: '6.5% (市场调查预测)',
    publishDate: '2026-09-13',
    frequency: '月度',
    source: '中国人民银行',
    unit: '%',
    description: '流通中的现金加企事业单位活期与定期存款、个人存款及其他存款。',
    history: [
      { date: '2026-03', value: 8.3 },
      { date: '2026-04', value: 7.2 },
      { date: '2026-05', value: 7.0 },
      { date: '2026-06', value: 6.2 },
      { date: '2026-07', value: 6.3 },
      { date: '2026-08', value: 6.8, forecast: 6.5 }
    ]
  },
  {
    id: 'LPR_1Y',
    name: '贷款市场报价利率 (1年期LPR)',
    category: '金融货币',
    latestValue: '3.10%',
    previousValue: '3.10%',
    forecastValue: '3.10% (市场调查预测)',
    publishDate: '2026-08-20',
    frequency: '月度',
    source: '全国银行间同业拆借中心',
    unit: '%',
    description: '中国贷款基准利率锚，由18家报价行在MLF利率基础上加点形成。',
    history: [
      { date: '2026-03', value: 3.45 },
      { date: '2026-04', value: 3.45 },
      { date: '2026-05', value: 3.45 },
      { date: '2026-06', value: 3.45 },
      { date: '2026-07', value: 3.35 },
      { date: '2026-08', value: 3.10, forecast: 3.10 }
    ]
  }
];

// 8. ETF与基金中心数据
export const MOCK_ETF_LIST: ETFFundItem[] = [
  {
    code: '510300',
    name: '华泰柏瑞沪深300ETF',
    category: '股票ETF',
    price: 4.528,
    changePct: 0.33,
    aum: 3850.20,
    turnover: 654000,
    trackingIndex: '沪深300指数',
    trackingError: 0.03,
    premiumDiscountRate: 0.02,
    mgmtFee: 0.15,
    holdings: [
      { name: '贵州茅台', code: '600519', weightPct: 5.82 },
      { name: '宁德时代', code: '300750', weightPct: 3.15 },
      { name: '中国平安', code: '601318', weightPct: 2.85 },
      { name: '招商银行', code: '600036', weightPct: 2.45 },
      { name: '比亚迪', code: '002594', weightPct: 1.95 }
    ],
    sectorWeights: [
      { name: '金融', weightPct: 22.4 },
      { name: '主要消费', weightPct: 14.8 },
      { name: '信息技术', weightPct: 16.5 },
      { name: '工业制造', weightPct: 15.2 }
    ],
    navHistory: [
      { date: '09-10', nav: 4.49, cumulativeNav: 4.49 },
      { date: '09-11', nav: 4.48, cumulativeNav: 4.48 },
      { date: '09-12', nav: 4.51, cumulativeNav: 4.51 },
      { date: '09-15', nav: 4.528, cumulativeNav: 4.528 }
    ]
  },
  {
    code: '588000',
    name: '华夏上证科创板50ETF',
    category: '股票ETF',
    price: 1.182,
    changePct: 0.79,
    aum: 1120.40,
    turnover: 320000,
    trackingIndex: '科创50指数',
    trackingError: 0.04,
    premiumDiscountRate: -0.01,
    mgmtFee: 0.15,
    holdings: [
      { name: '中芯国际', code: '688981', weightPct: 10.50 },
      { name: '海光信息', code: '688041', weightPct: 8.20 },
      { name: '中微公司', code: '688012', weightPct: 6.80 },
      { name: '寒武纪', code: '688256', weightPct: 5.40 }
    ],
    sectorWeights: [
      { name: '半导体', weightPct: 58.2 },
      { name: '软件开发', weightPct: 18.5 },
      { name: '电子制造', weightPct: 12.1 }
    ],
    navHistory: [
      { date: '09-10', nav: 1.16, cumulativeNav: 1.16 },
      { date: '09-11', nav: 1.15, cumulativeNav: 1.15 },
      { date: '09-12', nav: 1.17, cumulativeNav: 1.17 },
      { date: '09-15', nav: 1.182, cumulativeNav: 1.182 }
    ]
  },
  {
    code: '512880',
    name: '国泰中证全指证券公司ETF',
    category: '行业ETF',
    price: 1.245,
    changePct: 1.88,
    aum: 345.80,
    turnover: 185000,
    trackingIndex: '中证全指证券公司指数',
    trackingError: 0.05,
    premiumDiscountRate: 0.04,
    mgmtFee: 0.50,
    holdings: [
      { name: '东方财富', code: '300059', weightPct: 15.2 },
      { name: '中信证券', code: '600030', weightPct: 13.5 },
      { name: '华泰证券', code: '601688', weightPct: 7.2 }
    ],
    sectorWeights: [
      { name: '证券', weightPct: 98.5 }
    ],
    navHistory: [
      { date: '09-10', nav: 1.21, cumulativeNav: 1.21 },
      { date: '09-15', nav: 1.245, cumulativeNav: 1.245 }
    ]
  }
];

// 9. 外汇与大宗商品
export const MOCK_FX_COMMODITIES: FXCommodityItem[] = [
  {
    code: 'USD/CNY',
    name: '美元/在岸人民币',
    category: '外汇汇率',
    spotPrice: 7.1245,
    change: -0.0125,
    changePct: -0.18,
    high: 7.1420,
    low: 7.1210,
    volatility30d: 3.2,
    volume: 382000,
    unit: 'CNY',
    sparkline: [7.137, 7.135, 7.130, 7.126, 7.1245]
  },
  {
    code: 'EUR/CNY',
    name: '欧元/人民币',
    category: '外汇汇率',
    spotPrice: 7.8520,
    change: 0.0080,
    changePct: 0.10,
    high: 7.8650,
    low: 7.8410,
    volatility30d: 4.8,
    volume: 145000,
    unit: 'CNY',
    sparkline: [7.842, 7.848, 7.850, 7.852]
  },
  {
    code: 'GOLD_AU9999',
    name: '上海金 AU99.99',
    category: '贵金属',
    spotPrice: 618.50,
    futurePrice: 620.20,
    change: 4.20,
    changePct: 0.68,
    high: 621.00,
    low: 614.50,
    volatility30d: 12.4,
    openInterest: 85200,
    volume: 45000,
    unit: '元/克',
    sparkline: [612, 614, 616, 618.5]
  },
  {
    code: 'SC_OIL',
    name: '上海原油 (SC连续)',
    category: '能源',
    spotPrice: 548.60,
    futurePrice: 550.20,
    change: -3.80,
    changePct: -0.69,
    high: 554.00,
    low: 545.20,
    volatility30d: 24.5,
    openInterest: 112000,
    volume: 89000,
    unit: '元/桶',
    sparkline: [555, 552, 549, 548.6]
  },
  {
    code: 'CU_COPPER',
    name: '沪铜连续 (CU)',
    category: '工业金属',
    spotPrice: 78500,
    futurePrice: 78700,
    change: 850,
    changePct: 1.09,
    high: 78900,
    low: 77800,
    volatility30d: 16.8,
    openInterest: 185000,
    volume: 124000,
    unit: '元/吨',
    sparkline: [77600, 78000, 78200, 78500]
  }
];

// 10. 财经要闻与市场快讯 (明确标记演示新闻)
export const MOCK_NEWS_LIST: NewsItem[] = [
  {
    id: 'news-001',
    title: '央行：保持货币政策的连续性稳定性 更好支持实体经济高质量发展',
    timestamp: '10:18',
    source: '中国人民银行办公厅 (演示资讯)',
    author: '金融政策研究室',
    category: '宏观政策',
    tags: ['央行', '货币政策', '实体经济', '利率'],
    relatedStocks: [{ code: '600036', name: '招商银行' }, { code: '601318', name: '中国平安' }],
    relatedIndustries: ['金融', '银行'],
    content: '中国人民银行召开党委扩大会议指出，将继续精准有力实施好稳健的货币政策，加大对科技创新、绿色发展、先进制造和民营小微企业的信贷支持力度。保持流动性合理充裕，引导综合融资成本稳中有降，促进金融市场平稳健康运行。',
    importance: '特急',
    isDemo: true
  },
  {
    id: 'news-002',
    title: '证监会：进一步深化资本市场改革 提升市场活力与韧性',
    timestamp: '09:52',
    source: '中国证监会官网 (演示资讯)',
    author: '市场监管部',
    category: '市场快讯',
    tags: ['证监会', '资本市场', '制度改革', '中长期资金'],
    relatedStocks: [{ code: '300059', name: '东方财富' }, { code: '600030', name: '中信证券' }],
    relatedIndustries: ['证券与金融IT'],
    content: '中国证监会召开推进中长期资金入市工作会议，强调将进一步打通社保、保险、理财等资金入市卡点痛点，提升上市公司投资价值，严格退市与财务造假监管，完善公募基金投顾与考核体系。',
    importance: '重要',
    isDemo: true
  },
  {
    id: 'news-003',
    title: '上交所：持续推动科技创新企业上市 服务新质生产力发展',
    timestamp: '09:34',
    source: '上海证券交易所 (演示资讯)',
    author: '科创板研究组',
    category: 'A股聚焦',
    tags: ['上交所', '科创板', '半导体', '新质生产力'],
    relatedStocks: [{ code: '688981', name: '中芯国际' }],
    relatedIndustries: ['半导体芯片'],
    content: '上海证券交易所发布科创板深化改革行动方案，支持具有关键核心技术突破能力、商业模式清晰的硬科技企业加速上市与并购重组，完善科创成长层估值生态与做市商交易机制。',
    importance: '重要',
    isDemo: true
  },
  {
    id: 'news-004',
    title: '离岸人民币汇率延续升值态势 在岸、离岸双双走强',
    timestamp: '08:59',
    source: '外汇市场交易中心 (演示资讯)',
    author: '汇率分析组',
    category: '宏观政策',
    tags: ['外汇', '人民币', '汇率', '进出口'],
    relatedStocks: [],
    relatedIndustries: ['外汇汇率'],
    content: '在岸及离岸人民币对美元汇率今日早盘快速拉升，逼近7.12关口。市场分析指出，随着国内宏观基本面修复态势明确、外贸结汇需求上升及美联储政策转向预期，人民币汇率中枢有望稳步回升。',
    importance: '普通',
    isDemo: true
  },
  {
    id: 'news-005',
    title: '外资机构：看好中国市场长期投资价值 维持A股“增持”评级',
    timestamp: '08:42',
    source: '国际投资银行研究部 (演示资讯)',
    author: '首席中国股票策略师',
    category: '公司研报',
    tags: ['外资', '北向资金', '核心资产', '茅台'],
    relatedStocks: [{ code: '600519', name: '贵州茅台' }, { code: '300750', name: '宁德时代' }],
    relatedIndustries: ['主要消费', '新能源与电池'],
    content: '高盛及摩根士丹利发布最新中国股市策略报告，重申对中国核心资产（高ROE、充沛现金流龙头）的超配建议。报告认为，当前中国主要资产估值水平相对全球折价明显，股息收益率优势突出。',
    importance: '普通',
    isDemo: true
  }
];

// 11. 上市公司公告披露中心
export const MOCK_ANNOUNCEMENTS: AnnouncementItem[] = [
  {
    id: 'ann-001',
    title: '贵州茅台：2025年半年度报告及主要经营数据公告',
    publishDate: '2026-08-15',
    companyCode: '600519',
    companyName: '贵州茅台',
    category: '季度报告',
    fileType: 'PDF',
    fileSize: '3.4 MB',
    summary: '2025年上半年公司实现营业总收入834.51亿元，同比增长17.56%；实现归属于上市公司股东的净利润416.96亿元，同比增长15.88%。系列酒增长稳健，海外渠道拓展取得突破。',
    isDemo: true
  },
  {
    id: 'ann-002',
    title: '宁德时代：关于实施2024年度现金分红权益分派的实施公告',
    publishDate: '2026-06-20',
    companyCode: '300750',
    companyName: '宁德时代',
    category: '分红配股',
    fileType: 'PDF',
    fileSize: '820 KB',
    summary: '公司2024年度利润分配方案：向全体股东每10股派发现金红利22.50元（含税），共计派发现金股利约98.8亿元，股权登记日为2026年6月25日。',
    isDemo: true
  },
  {
    id: 'ann-003',
    title: '招商银行：关于董事会审议通过中期分红规划的决议公告',
    publishDate: '2026-07-28',
    companyCode: '600036',
    companyName: '招商银行',
    category: '重大事项',
    fileType: 'PDF',
    fileSize: '1.1 MB',
    summary: '公司董事会审议通过建立常态化中期分红机制，现金分红占归属于普通股股东净利润的比例原则上不低于35%，积极回馈广大投资者。',
    isDemo: true
  },
  {
    id: 'ann-004',
    title: '中芯国际：关于自愿披露投资建设12英寸先进制程扩产项目的公告',
    publishDate: '2026-09-02',
    companyCode: '688981',
    companyName: '中芯国际',
    category: '重大事项',
    fileType: 'PDF',
    fileSize: '1.8 MB',
    summary: '为满足新能源汽车、工业物联网及AI芯片的高速增长需求，公司全资子公司计划投资约280亿元建设新增月产3万片12英寸晶圆代工产线。',
    isDemo: true
  }
];

// 12. 深度财务三张表生成器 (利润表、资产负债表、现金流量表 2021-2025年)
export function getCompanyFinancialStatements(stockCode: string): CompanyFinancials {
  const years = ['2021', '2022', '2023', '2024', '2025'];
  const quarters = ['2024Q3', '2024Q4', '2025Q1', '2025Q2'];

  if (stockCode === '600519') {
    return {
      years,
      quarters,
      incomeStatement: [
        { name: '一、营业总收入 (亿元)', isHeader: true, history: { '2021': 1094.64, '2022': 1275.54, '2023': 1505.60, '2024': 1680.20, '2025': 1910.40 } },
        { name: '营业成本', indent: true, history: { '2021': 90.70, '2022': 102.30, '2023': 120.90, '2024': 135.40, '2025': 152.80 } },
        { name: '税金及附加', indent: true, history: { '2021': 160.20, '2022': 185.40, '2023': 225.10, '2024': 250.80, '2025': 285.20 } },
        { name: '销售费用', indent: true, history: { '2021': 32.10, '2022': 38.50, '2023': 46.20, '2024': 52.10, '2025': 60.50 } },
        { name: '管理费用', indent: true, history: { '2021': 85.40, '2022': 98.20, '2023': 112.50, '2024': 124.00, '2025': 138.20 } },
        { name: '研发费用', indent: true, history: { '2021': 1.80, '2022': 2.45, '2023': 3.10, '2024': 3.80, '2025': 4.50 } },
        { name: '二、营业利润', isHeader: true, history: { '2021': 745.20, '2022': 880.40, '2023': 1036.80, '2024': 1180.50, '2025': 1350.20 } },
        { name: '三、利润总额', isHeader: true, history: { '2021': 748.10, '2022': 882.10, '2023': 1038.50, '2024': 1182.00, '2025': 1352.00 } },
        { name: '四、归母净利润 (亿元)', isHeader: true, history: { '2021': 524.60, '2022': 627.16, '2023': 747.34, '2024': 852.10, '2025': 975.40 } }
      ],
      balanceSheet: [
        { name: '流动资产合计 (亿元)', isHeader: true, history: { '2021': 1850.20, '2022': 2120.40, '2023': 2450.80, '2024': 2780.00, '2025': 3150.20 } },
        { name: '货币资金', indent: true, history: { '2021': 1480.50, '2022': 1650.20, '2023': 1820.50, '2024': 2080.00, '2025': 2380.00 } },
        { name: '存货（基酒陈酿等）', indent: true, history: { '2021': 330.40, '2022': 380.10, '2023': 460.20, '2024': 520.40, '2025': 590.10 } },
        { name: '非流动资产合计', isHeader: true, history: { '2021': 350.80, '2022': 420.50, '2023': 480.20, '2024': 540.00, '2025': 610.50 } },
        { name: '固定资产', indent: true, history: { '2021': 210.20, '2022': 245.80, '2023': 285.40, '2024': 320.10, '2025': 365.20 } },
        { name: '资产总计 (亿元)', isHeader: true, history: { '2021': 2201.00, '2022': 2540.90, '2023': 2931.00, '2024': 3320.00, '2025': 3760.70 } },
        { name: '流动负债合计', isHeader: true, history: { '2021': 380.20, '2022': 430.50, '2023': 480.60, '2024': 530.00, '2025': 590.20 } },
        { name: '负债合计 (亿元)', isHeader: true, history: { '2021': 390.10, '2022': 445.20, '2023': 495.80, '2024': 550.00, '2025': 615.40 } },
        { name: '所有者权益合计 (亿元)', isHeader: true, history: { '2021': 1810.90, '2022': 2095.70, '2023': 2435.20, '2024': 2770.00, '2025': 3145.30 } }
      ],
      cashFlowStatement: [
        { name: '经营活动产生的现金流量净额', isHeader: true, history: { '2021': 640.29, '2022': 366.99, '2023': 665.93, '2024': 780.20, '2025': 895.40 } },
        { name: '投资活动产生的现金流量净额', isHeader: true, history: { '2021': -35.20, '2022': -48.50, '2023': -58.20, '2024': -65.00, '2025': -75.20 } },
        { name: '筹资活动产生的现金流量净额', isHeader: true, history: { '2021': -280.40, '2022': -340.50, '2023': -420.80, '2024': -500.00, '2025': -580.40 } },
        { name: '现金及现金等价物净增加额', isHeader: true, history: { '2021': 324.69, '2022': -22.01, '2023': 186.93, '2024': 215.20, '2025': 239.80 } }
      ]
    };
  }

  // 通用默认模板
  return {
    years,
    quarters,
    incomeStatement: [
      { name: '一、营业总收入 (亿元)', isHeader: true, history: { '2021': 480.5, '2022': 560.2, '2023': 680.4, '2024': 790.0, '2025': 920.5 } },
      { name: '营业成本', indent: true, history: { '2021': 280.2, '2022': 320.5, '2023': 390.1, '2024': 450.0, '2025': 520.4 } },
      { name: '二、营业利润', isHeader: true, history: { '2021': 85.4, '2022': 105.2, '2023': 135.8, '2024': 160.0, '2025': 190.2 } },
      { name: '三、归母净利润 (亿元)', isHeader: true, history: { '2021': 68.2, '2022': 84.5, '2023': 108.6, '2024': 128.0, '2025': 152.4 } }
    ],
    balanceSheet: [
      { name: '流动资产合计 (亿元)', isHeader: true, history: { '2021': 520.4, '2022': 610.8, '2023': 740.5, '2024': 850.0, '2025': 980.2 } },
      { name: '资产总计 (亿元)', isHeader: true, history: { '2021': 890.5, '2022': 1040.2, '2023': 1280.4, '2024': 1460.0, '2025': 1690.5 } },
      { name: '负债合计 (亿元)', isHeader: true, history: { '2021': 380.2, '2022': 440.5, '2023': 530.2, '2024': 600.0, '2025': 690.4 } },
      { name: '所有者权益合计 (亿元)', isHeader: true, history: { '2021': 510.3, '2022': 599.7, '2023': 750.2, '2024': 860.0, '2025': 1000.1 } }
    ],
    cashFlowStatement: [
      { name: '经营活动现金流净额', isHeader: true, history: { '2021': 88.5, '2022': 112.4, '2023': 145.8, '2024': 170.0, '2025': 205.2 } },
      { name: '投资活动现金流净额', isHeader: true, history: { '2021': -45.2, '2022': -58.0, '2023': -72.4, '2024': -85.0, '2025': -102.0 } },
      { name: '筹资活动现金流净额', isHeader: true, history: { '2021': -25.4, '2022': -32.5, '2023': -44.2, '2024': -52.0, '2025': -65.0 } }
    ]
  };
}

// 13. K线与分时数据生成器 (支持日K、周K、月K、分时)
export function generateKLineData(stockCode: string, period: string = '日K', count: number = 120): KLineBar[] {
  const stock = STOCKS_DATABASE.find(s => s.code === stockCode) || STOCKS_DATABASE[0];
  const currentPrice = stock.price;
  const bars: KLineBar[] = [];

  let prevClose = currentPrice * 0.75;
  const now = new Date();

  for (let i = count - 1; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    const dateStr = d.toISOString().split('T')[0];

    // 随机漫步
    const changeFactor = (Math.sin(i / 8) * 0.015 + (Math.random() - 0.48) * 0.03);
    const open = Number((prevClose * (1 + (Math.random() - 0.5) * 0.01)).toFixed(2));
    const close = Number((open * (1 + changeFactor)).toFixed(2));
    const high = Number((Math.max(open, close) * (1 + Math.random() * 0.018)).toFixed(2));
    const low = Number((Math.min(open, close) * (1 - Math.random() * 0.018)).toFixed(2));
    const changePct = Number((((close - prevClose) / prevClose) * 100).toFixed(2));
    const volume = Math.floor(stock.volume * (0.6 + Math.random() * 0.8));
    const turnover = Math.floor(volume * close / 100);

    const bar: KLineBar = {
      date: dateStr,
      open,
      high,
      low,
      close,
      volume,
      turnover,
      changePct
    };

    // 添加重要财报和分红事件标记
    if (i === 30) {
      bar.events = [{
        date: dateStr,
        type: '财报',
        title: '2025中报发布',
        description: '归母净利润同比增长18.5%，超市场一致预期。'
      }];
    } else if (i === 75) {
      bar.events = [{
        date: dateStr,
        type: '分红',
        title: '每10股派30.8元',
        description: '实施2024年年度权益分派。'
      }];
    }

    bars.push(bar);
    prevClose = close;
  }

  // 最后一根K线对齐到当前最新价
  if (bars.length > 0) {
    bars[bars.length - 1].close = currentPrice;
    bars[bars.length - 1].high = Math.max(bars[bars.length - 1].high, currentPrice);
    bars[bars.length - 1].low = Math.min(bars[bars.length - 1].low, currentPrice);
  }

  return calculateIndicators(bars);
}

// 14. 数据质量与系统节点监控
export const DATA_QUALITY_NODES: DataQualityNode[] = [
  {
    name: '上交所 Level-2 极速行情源',
    type: 'L2深度行情',
    provider: '华市直连适配器 (模拟时延模式)',
    status: '正常',
    latencyMs: 12,
    missingRatePct: 0.00,
    packetCountToday: 4859200,
    lastHeartbeat: '刚刚',
    qualityGrade: 'A+'
  },
  {
    name: '深交所 Level-2 逐笔委托源',
    type: 'L2深度行情',
    provider: '华市直连适配器',
    status: '正常',
    latencyMs: 14,
    missingRatePct: 0.01,
    packetCountToday: 5120300,
    lastHeartbeat: '刚刚',
    qualityGrade: 'A+'
  },
  {
    name: '上市公司财报标准化时序库',
    type: '财务数据库',
    provider: '中证权威财务准则引擎',
    status: '正常',
    latencyMs: 45,
    missingRatePct: 0.00,
    packetCountToday: 245000,
    lastHeartbeat: '1分钟前',
    qualityGrade: 'A+'
  },
  {
    name: '国家统计局宏观数据库',
    type: '宏观时序',
    provider: '宏观经济数据通道',
    status: '正常',
    latencyMs: 80,
    missingRatePct: 0.02,
    packetCountToday: 8520,
    lastHeartbeat: '5分钟前',
    qualityGrade: 'A'
  },
  {
    name: '中债金融估值中心收益率曲线',
    type: '债券估值',
    provider: '银行间市场清算引擎',
    status: '正常',
    latencyMs: 25,
    missingRatePct: 0.00,
    packetCountToday: 95400,
    lastHeartbeat: '刚刚',
    qualityGrade: 'A+'
  }
];

// 15. 企业级审计日志
export const INITIAL_AUDIT_LOGS: AuditLogItem[] = [
  {
    id: 'log-101',
    timestamp: '15:14:22',
    user: '张远航 (高级研究员)',
    role: '机构研究员',
    action: '查询公司财务',
    target: '贵州茅台 (600519) 利润表与现金流',
    ip: '10.24.18.95',
    status: '成功',
    details: '调取2021-2025年历史分季度TTM财报并导出对比矩阵'
  },
  {
    id: 'log-102',
    timestamp: '15:10:05',
    user: '李沐 (量化策略总监)',
    role: '投资经理',
    action: '执行量化回测',
    target: '多因子高ROE低估值轮动策略',
    ip: '10.24.18.112',
    status: '成功',
    details: '回测区间2021-2025，年化超额收益14.2%，夏普比率1.85'
  },
  {
    id: 'log-103',
    timestamp: '14:58:30',
    user: '王晓菲 (合规风控员)',
    role: '系统管理员',
    action: '调整权限策略',
    target: '机构多因子研究工作区访问白名单',
    ip: '10.24.19.01',
    status: '成功',
    details: '更新RBAC权限策略组，启用双因子授权校验'
  }
];

export const MOCK_AUDIT_LOGS = INITIAL_AUDIT_LOGS;

// 16. 模拟投资组合
export const MOCK_PORTFOLIO = {
  id: 'PF-001',
  name: '华市核心价值成长1号组合',
  totalAssetValue: 12584000,
  cash: 1658400,
  performanceMetrics: {
    sharpeRatio: 2.14,
    maxDrawdown: 8.65,
    annualizedVolatility: 13.8,
    alpha: 14.5,
    beta: 0.88
  },
  positions: [
    {
      code: '600519',
      name: '贵州茅台',
      shares: 2000,
      costPrice: 1380.00,
      currentPrice: 1468.00,
      marketValue: 2936000,
      unrealizedPnL: 176000,
      unrealizedPnLPct: 6.38,
      weightPct: 23.3
    },
    {
      code: '300750',
      name: '宁德时代',
      shares: 10000,
      costPrice: 245.00,
      currentPrice: 268.50,
      marketValue: 2685000,
      unrealizedPnL: 235000,
      unrealizedPnLPct: 9.59,
      weightPct: 21.3
    },
    {
      code: '600036',
      name: '招商银行',
      shares: 60000,
      costPrice: 33.20,
      currentPrice: 35.80,
      marketValue: 2148000,
      unrealizedPnL: 156000,
      unrealizedPnLPct: 7.83,
      weightPct: 17.1
    },
    {
      code: '002594',
      name: '比亚迪',
      shares: 8000,
      costPrice: 230.00,
      currentPrice: 252.00,
      marketValue: 2016000,
      unrealizedPnL: 176000,
      unrealizedPnLPct: 9.57,
      weightPct: 16.0
    },
    {
      code: '600900',
      name: '长江电力',
      shares: 40000,
      costPrice: 27.50,
      currentPrice: 28.52,
      marketValue: 1140800,
      unrealizedPnL: 40800,
      unrealizedPnLPct: 3.71,
      weightPct: 9.1
    }
  ]
};

// 17. 量化因子库与测试因子
export const MOCK_FACTORS = [
  {
    name: 'ROE 质量成长因子',
    category: '质量因子',
    description: '净资产收益率 (ROE-TTM) 与扣非 ROE 同比变化率，筛选具备高资本回报率的公司。',
    ic: 0.082,
    ir: 1.45,
    longAnnualizedReturn: 18.5,
    maxDrawdown: 11.2,
    turnoverRate: 24.5
  },
  {
    name: '低估值高股息因子 (EP & Div)',
    category: '价值因子',
    description: '综合市盈率倒数 (E/P) 与过去三年平均股息收益率，捕捉深度价值与安全边际。',
    ic: 0.065,
    ir: 1.18,
    longAnnualizedReturn: 14.8,
    maxDrawdown: 8.4,
    turnoverRate: 15.2
  },
  {
    name: '自由现金流收益率 (FCF Yield)',
    category: '质量因子',
    description: '经营活动现金流净额减资本开支与市值的比率，识别真实现金创造能力。',
    ic: 0.074,
    ir: 1.32,
    longAnnualizedReturn: 16.9,
    maxDrawdown: 9.8,
    turnoverRate: 19.8
  },
  {
    name: '中短期动量突破 (Momentum 20D/60D)',
    category: '动量因子',
    description: '过去 20 交易日与 60 交易日涨跌幅与成交量加权相对强弱度。',
    ic: 0.048,
    ir: 0.85,
    longAnnualizedReturn: 13.2,
    maxDrawdown: 16.5,
    turnoverRate: 48.0
  },
  {
    name: '低波动稳健因子 (Low Volatility)',
    category: '低波动',
    description: '过去 120 交易日收益率标准差与下行半方差，构建防御性底仓。',
    ic: 0.052,
    ir: 1.25,
    longAnnualizedReturn: 11.8,
    maxDrawdown: 6.2,
    turnoverRate: 12.0
  }
];

// 18. 数据源监控列表
export const MOCK_DATA_QUALITY = [
  {
    source: '上交所 Level-2 极速专线',
    status: '正常',
    latencyMs: 3.8,
    missingRate: 0.00,
    anomalyRate: 0.00,
    lastSync: '刚刚 (15:00:00)'
  },
  {
    source: '深交所 Level-2 逐笔委托通道',
    status: '正常',
    latencyMs: 4.5,
    missingRate: 0.01,
    anomalyRate: 0.00,
    lastSync: '刚刚 (15:00:00)'
  },
  {
    source: '上市公司法定财报标准化数据库',
    status: '正常',
    latencyMs: 28.0,
    missingRate: 0.00,
    anomalyRate: 0.00,
    lastSync: '5分钟前'
  },
  {
    source: '中债估值中心收益率曲线网关',
    status: '正常',
    latencyMs: 18.2,
    missingRate: 0.00,
    anomalyRate: 0.00,
    lastSync: '刚刚 (15:00:00)'
  },
  {
    source: '国家统计局宏观经济数据库',
    status: '正常',
    latencyMs: 45.0,
    missingRate: 0.02,
    anomalyRate: 0.01,
    lastSync: '10分钟前'
  }
];

export const CURRENT_USER: UserRoleInfo = {
  role: '机构研究员',
  userName: '陈启华 (资深分析师)',
  institution: '华市资产管理研究部',
  permissions: ['MARKET_DATA_L2', 'FINANCIAL_DEEP_RESEARCH', 'QUANT_BACKTEST', 'EXPORT_DATA', 'AI_AGENT_ACCESS']
};
