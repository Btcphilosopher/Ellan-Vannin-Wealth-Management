/**
 * 华市金融终端 - 专业技术指标与时序数学计算引擎
 */

import { KLineBar } from '../types';

export function calculateIndicators(bars: KLineBar[]): KLineBar[] {
  if (!bars || bars.length === 0) return [];
  const result: KLineBar[] = JSON.parse(JSON.stringify(bars));

  // 1. Calculate Simple Moving Averages (MA5, MA10, MA20, MA60)
  for (let i = 0; i < result.length; i++) {
    result[i].ma5 = calcSMA(result, i, 5);
    result[i].ma10 = calcSMA(result, i, 10);
    result[i].ma20 = calcSMA(result, i, 20);
    result[i].ma60 = calcSMA(result, i, 60);
  }

  // 2. Calculate MACD (12, 26, 9)
  let ema12 = result[0].close;
  let ema26 = result[0].close;
  let dea = 0;

  for (let i = 0; i < result.length; i++) {
    const close = result[i].close;
    ema12 = (close * 2 + ema12 * 11) / 13;
    ema26 = (close * 2 + ema26 * 25) / 27;
    const dif = ema12 - ema26;
    dea = (dif * 2 + dea * 8) / 10;
    const macd = (dif - dea) * 2;

    result[i].dif = Number(dif.toFixed(2));
    result[i].dea = Number(dea.toFixed(2));
    result[i].macd = Number(macd.toFixed(2));
  }

  // 3. Calculate RSI (14)
  for (let i = 0; i < result.length; i++) {
    if (i < 14) {
      result[i].rsi = 50;
      continue;
    }
    let gain = 0;
    let loss = 0;
    for (let j = i - 13; j <= i; j++) {
      const change = result[j].close - result[j - 1].close;
      if (change > 0) gain += change;
      else loss -= change;
    }
    const rs = loss === 0 ? 100 : (gain / 14) / (loss / 14);
    result[i].rsi = Number((100 - (100 / (1 + rs))).toFixed(2));
  }

  // 4. Calculate KDJ (9, 3, 3)
  let prevK = 50;
  let prevD = 50;
  for (let i = 0; i < result.length; i++) {
    const start = Math.max(0, i - 8);
    const slice = result.slice(start, i + 1);
    const lowestLow = Math.min(...slice.map(b => b.low));
    const highestHigh = Math.max(...slice.map(b => b.high));

    let rsv = 50;
    if (highestHigh !== lowestLow) {
      rsv = ((result[i].close - lowestLow) / (highestHigh - lowestLow)) * 100;
    }
    const k = (2 / 3) * prevK + (1 / 3) * rsv;
    const d = (2 / 3) * prevD + (1 / 3) * k;
    const j = 3 * k - 2 * d;

    result[i].k = Number(k.toFixed(2));
    result[i].d = Number(d.toFixed(2));
    result[i].j = Number(j.toFixed(2));

    prevK = k;
    prevD = d;
  }

  // 5. Calculate Bollinger Bands (20, 2)
  for (let i = 0; i < result.length; i++) {
    if (i < 19) {
      result[i].bollMid = result[i].close;
      result[i].bollUpper = result[i].close * 1.05;
      result[i].bollLower = result[i].close * 0.95;
      continue;
    }
    const slice = result.slice(i - 19, i + 1);
    const ma20 = slice.reduce((sum, b) => sum + b.close, 0) / 20;
    const variance = slice.reduce((sum, b) => sum + Math.pow(b.close - ma20, 2), 0) / 20;
    const stdDev = Math.sqrt(variance);

    result[i].bollMid = Number(ma20.toFixed(2));
    result[i].bollUpper = Number((ma20 + 2 * stdDev).toFixed(2));
    result[i].bollLower = Number((ma20 - 2 * stdDev).toFixed(2));
  }

  return result;
}

function calcSMA(bars: KLineBar[], currentIndex: number, period: number): number | undefined {
  if (currentIndex < period - 1) return undefined;
  let sum = 0;
  for (let i = currentIndex - period + 1; i <= currentIndex; i++) {
    sum += bars[i].close;
  }
  return Number((sum / period).toFixed(2));
}
