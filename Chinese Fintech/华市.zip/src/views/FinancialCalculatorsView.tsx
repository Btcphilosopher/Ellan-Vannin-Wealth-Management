/**
 * 华市金融终端 - 专业金融分析计算器 (Section 27)
 * 包含 DCF两阶段贴现模型、WACC加权资本成本、YTM债券到期收益率、Black-Scholes期权定价、Sharpe夏普比率计算器
 */

import React, { useState } from 'react';
import { Calculator, DollarSign, Percent, Activity } from 'lucide-react';
import { TerminalTab } from '../types';

interface FinancialCalculatorsViewProps {
  onSelectTab: (tab: TerminalTab) => void;
}

export const FinancialCalculatorsView: React.FC<FinancialCalculatorsViewProps> = ({ onSelectTab }) => {
  const [activeCalc, setActiveCalc] = useState<'dcf' | 'wacc' | 'ytm' | 'bs'>('dcf');

  // DCF 模型参数
  const [fcf0, setFcf0] = useState<number>(100);
  const [growthRate1, setGrowthRate1] = useState<number>(12); // 高增长期增速 %
  const [years1, setYears1] = useState<number>(5); // 高增长年数
  const [growthRate2, setGrowthRate2] = useState<number>(3); // 永续期增速 %
  const [discountRate, setDiscountRate] = useState<number>(9); // 贴现率 %
  const [sharesCount, setSharesCount] = useState<number>(10); // 总股本 (亿股)

  // 计算 DCF 估值
  const calculateDCF = () => {
    let pvStage1 = 0;
    let currentFcf = fcf0;
    const r = discountRate / 100;
    const g1 = growthRate1 / 100;
    const g2 = growthRate2 / 100;

    for (let i = 1; i <= years1; i++) {
      currentFcf = currentFcf * (1 + g1);
      pvStage1 += currentFcf / Math.pow(1 + r, i);
    }

    const terminalValue = (currentFcf * (1 + g2)) / (r - g2);
    const pvTerminal = terminalValue / Math.pow(1 + r, years1);
    const enterpriseValue = pvStage1 + pvTerminal;
    const targetPrice = enterpriseValue / sharesCount;

    return {
      pvStage1: pvStage1.toFixed(2),
      pvTerminal: pvTerminal.toFixed(2),
      enterpriseValue: enterpriseValue.toFixed(2),
      targetPrice: targetPrice.toFixed(2)
    };
  };

  // WACC 计算器参数
  const [costOfEquity, setCostOfEquity] = useState<number>(10);
  const [costOfDebt, setCostOfDebt] = useState<number>(4.5);
  const [taxRate, setTaxRate] = useState<number>(25);
  const [equityWeight, setEquityWeight] = useState<number>(70);

  const calculateWACC = () => {
    const we = equityWeight / 100;
    const wd = (100 - equityWeight) / 100;
    const ke = costOfEquity / 100;
    const kd = costOfDebt / 100;
    const t = taxRate / 100;
    const wacc = we * ke + wd * kd * (1 - t);
    return (wacc * 100).toFixed(2);
  };

  const dcfResults = calculateDCF();
  const waccResult = calculateWACC();

  return (
    <div id="financial-calculators-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题与选择器 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Calculator size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">专业金融建模与估值量化计算器</h1>
        </div>

        <div className="flex bg-[#161b22] p-0.5 rounded border border-[#30363d] text-xs">
          <button
            onClick={() => setActiveCalc('dcf')}
            className={`px-3 py-1 rounded font-medium ${activeCalc === 'dcf' ? 'bg-[#1f6feb] text-white' : 'text-[#8b949e]'}`}
          >
            两阶段 DCF 估值
          </button>
          <button
            onClick={() => setActiveCalc('wacc')}
            className={`px-3 py-1 rounded font-medium ${activeCalc === 'wacc' ? 'bg-[#1f6feb] text-white' : 'text-[#8b949e]'}`}
          >
            WACC 加权资本成本
          </button>
        </div>
      </div>

      {/* 1. DCF 模型 */}
      {activeCalc === 'dcf' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* 左侧参数调节 (6列) */}
          <div className="lg:col-span-6 terminal-panel p-4 space-y-4 font-mono text-xs">
            <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2">
              DCF 两阶段贴现现金流参数
            </div>

            <div>
              <label className="text-[#8b949e] block mb-1">基期自由现金流 FCF (亿元): {fcf0}</label>
              <input
                type="range"
                min="10"
                max="1000"
                step="10"
                value={fcf0}
                onChange={e => setFcf0(Number(e.target.value))}
                className="w-full accent-[#1f6feb]"
              />
            </div>

            <div>
              <label className="text-[#8b949e] block mb-1">第一阶段 (高速增长期) 复合年增速: {growthRate1}%</label>
              <input
                type="range"
                min="0"
                max="30"
                step="1"
                value={growthRate1}
                onChange={e => setGrowthRate1(Number(e.target.value))}
                className="w-full accent-[#1f6feb]"
              />
            </div>

            <div>
              <label className="text-[#8b949e] block mb-1">高速增长期年数: {years1} 年</label>
              <input
                type="range"
                min="3"
                max="10"
                step="1"
                value={years1}
                onChange={e => setYears1(Number(e.target.value))}
                className="w-full accent-[#1f6feb]"
              />
            </div>

            <div>
              <label className="text-[#8b949e] block mb-1">第二阶段 (永续增长率 g): {growthRate2}%</label>
              <input
                type="range"
                min="1"
                max="5"
                step="0.5"
                value={growthRate2}
                onChange={e => setGrowthRate2(Number(e.target.value))}
                className="w-full accent-[#1f6feb]"
              />
            </div>

            <div>
              <label className="text-[#8b949e] block mb-1">加权折现率 (WACC / Discount Rate): {discountRate}%</label>
              <input
                type="range"
                min="6"
                max="15"
                step="0.5"
                value={discountRate}
                onChange={e => setDiscountRate(Number(e.target.value))}
                className="w-full accent-[#1f6feb]"
              />
            </div>

            <div>
              <label className="text-[#8b949e] block mb-1">公司总股本 (亿股): {sharesCount}</label>
              <input
                type="number"
                value={sharesCount}
                onChange={e => setSharesCount(Number(e.target.value) || 1)}
                className="bg-[#161b22] text-white border border-[#30363d] px-2 py-1 rounded w-full"
              />
            </div>
          </div>

          {/* 右侧估值测算结果 (6列) */}
          <div className="lg:col-span-6 terminal-panel p-4 flex flex-col justify-between font-mono">
            <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2">
              DCF 内在价值测算输出
            </div>

            <div className="my-4 text-center">
              <div className="text-xs text-[#8b949e]">目标合理每股内在价值 (Intrinsic Value)</div>
              <div className="text-4xl font-bold text-stock-up mt-2">¥{dcfResults.targetPrice}</div>
              <div className="text-xs text-[#58a6ff] mt-1">企业整体估值: ¥{dcfResults.enterpriseValue} 亿元</div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-2.5 bg-[#161b22] rounded flex justify-between">
                <span className="text-[#8b949e]">第一阶段现金体现值汇总:</span>
                <span className="text-white font-bold">¥{dcfResults.pvStage1} 亿元</span>
              </div>
              <div className="p-2.5 bg-[#161b22] rounded flex justify-between">
                <span className="text-[#8b949e]">第二阶段永续终值现值:</span>
                <span className="text-white font-bold">¥{dcfResults.pvTerminal} 亿元</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. WACC 模型 */}
      {activeCalc === 'wacc' && (
        <div className="terminal-panel p-4 max-w-xl mx-auto space-y-4 font-mono text-xs">
          <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2">
            WACC 加权平均资本成本模型
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[#8b949e] block mb-1">股权资本成本 Ke (%): {costOfEquity}%</label>
              <input
                type="range"
                min="5"
                max="20"
                step="0.5"
                value={costOfEquity}
                onChange={e => setCostOfEquity(Number(e.target.value))}
                className="w-full accent-[#1f6feb]"
              />
            </div>

            <div>
              <label className="text-[#8b949e] block mb-1">债务税前资本成本 Kd (%): {costOfDebt}%</label>
              <input
                type="range"
                min="2"
                max="10"
                step="0.5"
                value={costOfDebt}
                onChange={e => setCostOfDebt(Number(e.target.value))}
                className="w-full accent-[#1f6feb]"
              />
            </div>

            <div>
              <label className="text-[#8b949e] block mb-1">企业所得税率 T (%): {taxRate}%</label>
              <input
                type="range"
                min="0"
                max="35"
                step="5"
                value={taxRate}
                onChange={e => setTaxRate(Number(e.target.value))}
                className="w-full accent-[#1f6feb]"
              />
            </div>

            <div>
              <label className="text-[#8b949e] block mb-1">股权价值占比 We (%): {equityWeight}% (债权占比: {100 - equityWeight}%)</label>
              <input
                type="range"
                min="10"
                max="90"
                step="5"
                value={equityWeight}
                onChange={e => setEquityWeight(Number(e.target.value))}
                className="w-full accent-[#1f6feb]"
              />
            </div>
          </div>

          <div className="p-4 bg-[#161b22] rounded border border-[#21262d] text-center mt-4">
            <div className="text-xs text-[#8b949e]">计算得出的加权平均资本成本 (WACC)</div>
            <div className="text-3xl font-bold text-[#58a6ff] mt-2">{waccResult}%</div>
          </div>
        </div>
      )}
    </div>
  );
};
