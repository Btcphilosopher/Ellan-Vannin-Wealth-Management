/**
 * 华市金融终端 - 权限控制与合规审计日志 (Section 30)
 */

import React from 'react';
import { ShieldCheck, UserCheck, Lock, FileText, CheckCircle2 } from 'lucide-react';
import { MOCK_AUDIT_LOGS } from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface AuditRbacViewProps {
  onSelectTab: (tab: TerminalTab) => void;
}

export const AuditRbacView: React.FC<AuditRbacViewProps> = ({ onSelectTab }) => {
  return (
    <div id="audit-rbac-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <ShieldCheck size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">企业级权限合规与不可篡改审计追踪</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
            RBAC 角色权限模型 · 监管可溯源
          </span>
        </div>
      </div>

      {/* 角色矩阵卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-xs font-bold text-white flex items-center justify-between">
            <span>量化研究员 (Quant)</span>
            <span className="text-[10px] px-1 rounded bg-[#1f6feb]/20 text-[#58a6ff]">活跃</span>
          </div>
          <p className="text-[11px] text-[#8b949e] mt-1.5 leading-relaxed">
            权限范围：因子实验室回测、L2 高频行情订阅、Python 脚本投研环境。
          </p>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-xs font-bold text-white flex items-center justify-between">
            <span>基金经理 (PM)</span>
            <span className="text-[10px] px-1 rounded bg-[#238636]/20 text-[#3fb950]">活跃</span>
          </div>
          <p className="text-[11px] text-[#8b949e] mt-1.5 leading-relaxed">
            权限范围：组合资产配置、指令下达审批、持仓风险归因、绩效报表导出。
          </p>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-xs font-bold text-white flex items-center justify-between">
            <span>风控合规官 (Risk)</span>
            <span className="text-[10px] px-1 rounded bg-[#d29922]/20 text-[#e3b341]">活跃</span>
          </div>
          <p className="text-[11px] text-[#8b949e] mt-1.5 leading-relaxed">
            权限范围：限仓风控阀值设定、全量合规审计日志查看、异常交易熔断。
          </p>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-xs font-bold text-white flex items-center justify-between">
            <span>超级管理员 (Admin)</span>
            <span className="text-[10px] px-1 rounded bg-[#f85149]/20 text-stock-up">最高</span>
          </div>
          <p className="text-[11px] text-[#8b949e] mt-1.5 leading-relaxed">
            权限范围：节点服务健康监控、数据源接入网关管理、用户与角色授权。
          </p>
        </div>
      </div>

      {/* 审计日志数据表 */}
      <div className="terminal-panel p-3">
        <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 mb-3">
          操作审计与安全合规流水
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2.5 px-3">流水号 / 时间</th>
                <th className="py-2.5 px-3">操作用户</th>
                <th className="py-2.5 px-3">分配角色</th>
                <th className="py-2.5 px-3">操作动作</th>
                <th className="py-2.5 px-3">操作对象</th>
                <th className="py-2.5 px-3">终端 IP / 网段</th>
                <th className="py-2.5 px-3 text-center">执行状态</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {MOCK_AUDIT_LOGS.map(log => (
                <tr key={log.id} className="hover:bg-[#161b22]">
                  <td className="py-2.5 px-3">
                    <span className="font-bold text-white mr-2">{log.id}</span>
                    <span className="text-[#8b949e]">{log.timestamp}</span>
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-white">{log.user}</td>
                  <td className="py-2.5 px-3 text-[#58a6ff]">{log.role}</td>
                  <td className="py-2.5 px-3 text-[#c9d1d9]">{log.action}</td>
                  <td className="py-2.5 px-3 text-white">{log.target}</td>
                  <td className="py-2.5 px-3 text-[#8b949e]">{log.ip}</td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-1.5 py-0.5 rounded bg-[#238636]/20 text-[#3fb950] text-[10px] font-bold">
                      {log.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
