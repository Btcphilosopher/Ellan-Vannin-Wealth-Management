/**
 * 华市金融终端 - 自定义多窗口工作台与预置交易台 (Section 23)
 */

import React, { useState } from 'react';
import { LayoutGrid, Maximize2, SplitSquareVertical, Sliders, ExternalLink } from 'lucide-react';
import { STOCKS_DATABASE, INITIAL_MARKET_INDICES, INDUSTRY_SECTORS } from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface CustomWorkspaceViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const CustomWorkspaceView: React.FC<CustomWorkspaceViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  const [activeLayout, setActiveLayout] = useState<'4-grid' | 'macro-trader' | 'quant-desk'>('4-grid');

  return (
    <div id="custom-workspace-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部控制栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <LayoutGrid size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">多窗口自定义交易工作台 (Multi-Pane Workspace)</h1>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => setActiveLayout('4-grid')}
            className={`px-3 py-1 rounded font-medium ${activeLayout === '4-grid' ? 'bg-[#1f6feb] text-white' : 'bg-[#161b22] text-[#8b949e]'}`}
          >
            标准四分屏监控
          </button>
          <button
            onClick={() => setActiveLayout('macro-trader')}
            className={`px-3 py-1 rounded font-medium ${activeLayout === 'macro-trader' ? 'bg-[#1f6feb] text-white' : 'bg-[#161b22] text-[#8b949e]'}`}
          >
            宏观固收交易台
          </button>
          <button
            onClick={() => setActiveLayout('quant-desk')}
            className={`px-3 py-1 rounded font-medium ${activeLayout === 'quant-desk' ? 'bg-[#1f6feb] text-white' : 'bg-[#161b22] text-[#8b949e]'}`}
          >
            量化因子研究台
          </button>
        </div>
      </div>

      {/* 4分屏布局 */}
      {activeLayout === '4-grid' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* 窗口 1: 核心指数 */}
          <div className="terminal-panel p-3">
            <div className="flex justify-between items-center pb-2 border-b border-[#21262d] mb-2 text-xs">
              <span className="font-bold text-white">窗口 1: 主要市场指数</span>
              <button onClick={() => onSelectTab('overview')} className="text-[#58a6ff] hover:underline">展开 →</button>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              {INITIAL_MARKET_INDICES.slice(0, 4).map(idx => (
                <div key={idx.code} className="flex justify-between p-1.5 bg-[#161b22] rounded">
                  <span className="text-white font-medium">{idx.name}</span>
                  <span className={`font-bold ${idx.changePct >= 0 ? 'text-stock-up' : 'text-stock-down'}`}>
                    {idx.price.toFixed(2)} ({idx.changePct >= 0 ? '+' : ''}{idx.changePct}%)
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* 窗口 2: 行业板块 */}
          <div className="terminal-panel p-3">
            <div className="flex justify-between items-center pb-2 border-b border-[#21262d] mb-2 text-xs">
              <span className="font-bold text-white">窗口 2: 领涨行业热力</span>
              <button onClick={() => onSelectTab('industry')} className="text-[#58a6ff] hover:underline">展开 →</button>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              {INDUSTRY_SECTORS.slice(0, 4).map(sec => (
                <div key={sec.code} className="flex justify-between p-1.5 bg-[#161b22] rounded">
                  <span className="text-white">{sec.name}</span>
                  <span className={`font-bold ${sec.changePct >= 0 ? 'text-stock-up' : 'text-stock-down'}`}>
                    +{sec.changePct}% (领涨: {sec.leadingStock.name})
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* 窗口 3: 核心标的行情 */}
          <div className="terminal-panel p-3">
            <div className="flex justify-between items-center pb-2 border-b border-[#21262d] mb-2 text-xs">
              <span className="font-bold text-white">窗口 3: 重点关注个股</span>
              <button onClick={() => onSelectTab('screener')} className="text-[#58a6ff] hover:underline">选股 →</button>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              {STOCKS_DATABASE.slice(0, 4).map(stk => (
                <div
                  key={stk.code}
                  onClick={() => onSelectStock(stk.code)}
                  className="flex justify-between p-1.5 bg-[#161b22] rounded cursor-pointer hover:border hover:border-[#58a6ff]"
                >
                  <span className="text-white font-medium">{stk.name} ({stk.code})</span>
                  <span className={`font-bold ${stk.changePct >= 0 ? 'text-stock-up' : 'text-stock-down'}`}>
                    ¥{stk.price.toFixed(2)} ({stk.changePct >= 0 ? '+' : ''}{stk.changePct}%)
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* 窗口 4: 快速快捷工具 */}
          <div className="terminal-panel p-3 flex flex-col justify-between">
            <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 mb-2">
              窗口 4: 投研分析直达
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => onSelectTab('ai_assistant')}
                className="p-3 bg-[#161b22] hover:bg-[#1c2128] rounded border border-[#21262d] text-left text-white"
              >
                <div className="font-bold text-[#3fb950]">AI 投研助手</div>
                <div className="text-[10px] text-[#8b949e] mt-1">智能研报与财报拆解</div>
              </button>
              <button
                onClick={() => onSelectTab('calculators')}
                className="p-3 bg-[#161b22] hover:bg-[#1c2128] rounded border border-[#21262d] text-left text-white"
              >
                <div className="font-bold text-[#58a6ff]">DCF/WACC计算器</div>
                <div className="text-[10px] text-[#8b949e] mt-1">内在价值估值推演</div>
              </button>
              <button
                onClick={() => onSelectTab('bond_market')}
                className="p-3 bg-[#161b22] hover:bg-[#1c2128] rounded border border-[#21262d] text-left text-white"
              >
                <div className="font-bold text-[#e3b341]">国债收益率曲线</div>
                <div className="text-[10px] text-[#8b949e] mt-1">利率期限结构穿透</div>
              </button>
              <button
                onClick={() => onSelectTab('quant_research')}
                className="p-3 bg-[#161b22] hover:bg-[#1c2128] rounded border border-[#21262d] text-left text-white"
              >
                <div className="font-bold text-[#d29922]">量化因子实验室</div>
                <div className="text-[10px] text-[#8b949e] mt-1">IC/IR 策略回测</div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 宏观或量化专用台 */}
      {activeLayout !== '4-grid' && (
        <div className="terminal-panel p-6 text-center space-y-3 font-mono">
          <div className="text-white text-sm font-bold">
            已成功加载 {activeLayout === 'macro-trader' ? '【宏观固收交易台】' : '【量化因子策略研究台】'} 布局模版
          </div>
          <p className="text-xs text-[#8b949e]">
            已为您预载对应专业模块的数据流与指标组合，支持拖拽自适应网格。
          </p>
          <div className="pt-2">
            <button
              onClick={() => onSelectTab(activeLayout === 'macro-trader' ? 'macro' : 'quant_research')}
              className="px-4 py-2 bg-[#1f6feb] text-white rounded text-xs font-semibold"
            >
              直接进入全屏分析模块 →
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
