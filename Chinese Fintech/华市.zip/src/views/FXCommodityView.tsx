/**
 * 华市金融终端 - 外汇与大宗商品市场 (Section 19)
 */

import React, { useState } from 'react';
import { DollarSign, TrendingUp, Layers } from 'lucide-react';
import { MOCK_FX_COMMODITIES } from '../services/mockDataEngine';
import { FXCommodityItem, TerminalTab } from '../types';

interface FXCommodityViewProps {
  onSelectTab: (tab: TerminalTab) => void;
}

export const FXCommodityView: React.FC<FXCommodityViewProps> = ({ onSelectTab }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const categories = ['ALL', '外汇汇率', '贵金属', '能源', '工业金属'];

  const filteredItems = MOCK_FX_COMMODITIES.filter(
    item => selectedCategory === 'ALL' || item.category === selectedCategory
  );

  return (
    <div id="fx-commodity-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <DollarSign size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">全球外汇汇率与大宗商品衍生品</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#3fb950]">
            上期所 · 郑商所 · 大商所 · 国际汇市
          </span>
        </div>

        <div className="flex items-center gap-1 text-xs">
          {categories.map(c => (
            <button
              key={c}
              onClick={() => setSelectedCategory(c)}
              className={`px-2.5 py-1 rounded font-mono transition-colors ${
                selectedCategory === c
                  ? 'bg-[#1f6feb] text-white font-semibold'
                  : 'text-[#8b949e] hover:bg-[#161b22] hover:text-white'
              }`}
            >
              {c === 'ALL' ? '全部资产' : c}
            </button>
          ))}
        </div>
      </div>

      {/* 资产列表 */}
      <div className="terminal-panel p-3">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2.5 px-3">资产代码 / 名称</th>
                <th className="py-2.5 px-3">大类</th>
                <th className="py-2.5 px-3 text-right">最新现价 / 点位</th>
                <th className="py-2.5 px-3 text-right">涨跌额</th>
                <th className="py-2.5 px-3 text-right">涨跌幅 (%)</th>
                <th className="py-2.5 px-3 text-right">最高 / 最低</th>
                <th className="py-2.5 px-3 text-right">30日历史波动率</th>
                <th className="py-2.5 px-3 text-right">计价单位</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {filteredItems.map(item => {
                const isUp = item.changePct >= 0;
                return (
                  <tr key={item.code} className="hover:bg-[#161b22]">
                    <td className="py-2.5 px-3">
                      <span className="font-bold text-white mr-2">{item.name}</span>
                      <span className="text-[#58a6ff]">{item.code}</span>
                    </td>
                    <td className="py-2.5 px-3 text-[#c9d1d9]">{item.category}</td>
                    <td className={`py-2.5 px-3 text-right font-bold text-base ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {item.spotPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: item.spotPrice < 10 ? 4 : 2 })}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isUp ? '+' : ''}{item.change.toFixed(2)}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isUp ? '+' : ''}{item.changePct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#c9d1d9]">
                      {item.high} / {item.low}
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#58a6ff]">{item.volatility30d}%</td>
                    <td className="py-2.5 px-3 text-right text-[#8b949e]">{item.unit}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
