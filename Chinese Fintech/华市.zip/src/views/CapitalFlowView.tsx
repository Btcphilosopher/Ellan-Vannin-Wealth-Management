/**
 * 华市金融终端 - 市场资金流向与北向资金监控 (Section 14)
 */

import React from 'react';
import { Layers, ArrowUpRight, TrendingUp, DollarSign } from 'lucide-react';
import { MOCK_CAPITAL_FLOW, STOCKS_DATABASE } from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface CapitalFlowViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const CapitalFlowView: React.FC<CapitalFlowViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  return (
    <div id="capital-flow-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Layers size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">主力资金与北向陆股通时序穿透</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#3fb950]">
            沪深港通 · 超大单席位追踪
          </span>
        </div>
      </div>

      {/* 核心指标矩阵 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 font-mono">
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">北向资金今日净流入</div>
          <div className="text-2xl font-bold text-stock-up mt-1">+{MOCK_CAPITAL_FLOW.northboundToday} 亿元</div>
          <div className="text-[10px] text-[#8b949e] mt-1">沪股通 +28.12亿 / 深股通 +20.20亿</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">南向港股通今日净流入</div>
          <div className="text-2xl font-bold text-stock-up mt-1">+{MOCK_CAPITAL_FLOW.southboundToday} 亿元</div>
          <div className="text-[10px] text-[#8b949e] mt-1">港股通(沪) +7.2亿 / 港股通(深) +5.56亿</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">主力大单净流入 (全市场)</div>
          <div className="text-2xl font-bold text-stock-up mt-1">+{MOCK_CAPITAL_FLOW.mainInflowToday} 亿元</div>
          <div className="text-[10px] text-[#8b949e] mt-1">机构超大单持续做多</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">散户资金净流入</div>
          <div className="text-2xl font-bold text-stock-down mt-1">{MOCK_CAPITAL_FLOW.retailInflowToday} 亿元</div>
          <div className="text-[10px] text-[#8b949e] mt-1">高抛低吸换手活跃</div>
        </div>
      </div>

      {/* 北向资金历史时序明细 & 行业资金排行榜 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 北向资金近5日净流入 (6列) */}
        <div className="lg:col-span-6 terminal-panel p-3">
          <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 mb-3">
            北向陆股通历史时序净买入 (亿元)
          </div>
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2 px-3">日期</th>
                <th className="py-2 px-3 text-right">沪股通</th>
                <th className="py-2 px-3 text-right">深股通</th>
                <th className="py-2 px-3 text-right">合计净买入</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {MOCK_CAPITAL_FLOW.northboundHistorical.map(row => {
                const isTotalUp = row.total >= 0;
                return (
                  <tr key={row.date} className="hover:bg-[#161b22]">
                    <td className="py-2 px-3 font-bold text-white">{row.date}</td>
                    <td className={`py-2 px-3 text-right ${row.shanghaiInflow >= 0 ? 'text-stock-up' : 'text-stock-down'}`}>
                      {row.shanghaiInflow > 0 ? '+' : ''}{row.shanghaiInflow.toFixed(2)}
                    </td>
                    <td className={`py-2 px-3 text-right ${row.shenzhenInflow >= 0 ? 'text-stock-up' : 'text-stock-down'}`}>
                      {row.shenzhenInflow > 0 ? '+' : ''}{row.shenzhenInflow.toFixed(2)}
                    </td>
                    <td className={`py-2 px-3 text-right font-bold ${isTotalUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isTotalUp ? '+' : ''}{row.total.toFixed(2)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* 行业主力资金净流入榜 (6列) */}
        <div className="lg:col-span-6 terminal-panel p-3">
          <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 mb-3">
            板块主力净流入排名 (亿元)
          </div>
          <div className="space-y-2 text-xs font-mono">
            {MOCK_CAPITAL_FLOW.sectorFlows.map((sf, idx) => (
              <div key={sf.name} className="p-2.5 bg-[#161b22] rounded border border-[#21262d] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[#8b949e] font-bold">0{idx + 1}.</span>
                  <span className="text-white font-semibold">{sf.name}</span>
                  <span className="text-stock-up font-bold">+{sf.changePct}%</span>
                </div>
                <div className="text-right">
                  <span className="text-base font-bold text-[#58a6ff]">+{sf.inflow.toFixed(2)} 亿</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
