/**
 * 华市金融终端 - ETF与公募基金中心 (Section 17)
 */

import React, { useState } from 'react';
import { PieChart as PieIcon, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { MOCK_ETF_LIST } from '../services/mockDataEngine';
import { ETFFundItem, TerminalTab } from '../types';

interface ETFFundCenterViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const ETFFundCenterView: React.FC<ETFFundCenterViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  const [selectedEtf, setSelectedEtf] = useState<ETFFundItem>(MOCK_ETF_LIST[0]);

  return (
    <div id="etf-fund-center-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <PieIcon size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">ETF与场内公募基金研究中心</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
            跟踪误差 · 折溢价率 · 穿透重仓股
          </span>
        </div>
      </div>

      {/* ETF列表卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {MOCK_ETF_LIST.map(etf => {
          const isSelected = selectedEtf.code === etf.code;
          return (
            <div
              key={etf.code}
              onClick={() => setSelectedEtf(etf)}
              className={`p-3 rounded border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-[#161b22] border-[#58a6ff] ring-1 ring-[#58a6ff]'
                  : 'bg-[#0d1117] border-[#21262d] hover:border-[#30363d]'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-white">{etf.name}</span>
                <span className="text-[10px] text-[#58a6ff] font-mono">{etf.code}</span>
              </div>
              <div className="font-mono text-xl font-bold my-1 text-stock-up">
                ¥{etf.price.toFixed(3)} (+{etf.changePct}%)
              </div>
              <div className="text-[11px] text-[#8b949e] flex justify-between font-mono mt-2">
                <span>规模: <strong className="text-white">{etf.aum}亿</strong></span>
                <span>折溢价: <strong className={etf.premiumDiscountRate >= 0 ? 'text-stock-up' : 'text-stock-down'}>{etf.premiumDiscountRate}%</strong></span>
                <span>管理费: <strong className="text-[#3fb950]">{etf.mgmtFee}%</strong></span>
              </div>
            </div>
          );
        })}
      </div>

      {/* ETF穿透深度分析 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 前十大权重重仓股 (7列) */}
        <div className="lg:col-span-7 terminal-panel p-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#21262d] mb-3">
            <span className="text-xs font-bold text-white">
              【{selectedEtf.name}】前十大重仓股票穿透
            </span>
            <span className="text-[11px] font-mono text-[#8b949e]">
              跟踪基准: {selectedEtf.trackingIndex} (跟踪误差: {selectedEtf.trackingError}%)
            </span>
          </div>

          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2 px-3">标的代码 / 名称</th>
                <th className="py-2 px-3 text-right">持仓权重 (%)</th>
                <th className="py-2 px-3 text-center">快捷研究</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {selectedEtf.holdings.map((h, i) => (
                <tr key={h.code} className="hover:bg-[#161b22]">
                  <td className="py-2 px-3">
                    <span className="text-[#8b949e] mr-2">0{i + 1}.</span>
                    <span className="font-bold text-white mr-2">{h.name}</span>
                    <span className="text-[#58a6ff]">{h.code}</span>
                  </td>
                  <td className="py-2 px-3 text-right font-bold text-white">
                    {h.weightPct.toFixed(2)}%
                  </td>
                  <td className="py-2 px-3 text-center">
                    <button
                      onClick={() => onSelectStock(h.code)}
                      className="px-2 py-0.5 rounded bg-[#1f6feb] text-white text-[10px]"
                    >
                      查看个股
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* 行业配置与净值走势 (5列) */}
        <div className="lg:col-span-5 terminal-panel p-3 space-y-4">
          <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2">
            行业持仓权重分布
          </div>

          <div className="space-y-2 text-xs font-mono">
            {selectedEtf.sectorWeights.map(sw => (
              <div key={sw.name} className="p-2 bg-[#161b22] rounded border border-[#21262d]">
                <div className="flex justify-between mb-1">
                  <span className="text-white">{sw.name}</span>
                  <span className="text-[#58a6ff] font-bold">{sw.weightPct}%</span>
                </div>
                <div className="w-full h-1.5 bg-[#21262d] rounded overflow-hidden">
                  <div style={{ width: `${sw.weightPct}%` }} className="bg-[#58a6ff] h-full" />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-[#161b22] rounded border border-[#21262d] text-xs font-mono text-[#8b949e] space-y-1">
            <div className="text-white font-semibold flex items-center gap-1">
              <CheckCircle2 size={13} className="text-[#3fb950]" />
              ETF流动性与做市评估
            </div>
            <div>今日日均成交额: <strong>{(selectedEtf.turnover / 10000).toFixed(1)} 亿元</strong></div>
            <div>申赎实时买卖买卖点位紧密，流动性等级评定为 <strong>一级极优</strong>。</div>
          </div>
        </div>
      </div>
    </div>
  );
};
