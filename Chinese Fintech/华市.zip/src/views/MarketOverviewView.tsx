/**
 * 华市金融终端 - 专业市场总览首页 (Section 6)
 * 包含全球主要市场概览、A股核心指数、行业板块热力图、市场宽度与情绪、北向资金流向与实时快讯
 */

import React, { useState } from 'react';
import { TrendingUp, ArrowUpRight, ArrowDownRight, Layers, Activity, Compass, Flame } from 'lucide-react';
import {
  INITIAL_MARKET_INDICES,
  STOCKS_DATABASE,
  INDUSTRY_SECTORS,
  MOCK_MARKET_BREADTH,
  MOCK_CAPITAL_FLOW,
  MOCK_NEWS_LIST
} from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface MarketOverviewViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const MarketOverviewView: React.FC<MarketOverviewViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  const [selectedRegion, setSelectedRegion] = useState<'ALL' | 'CN' | 'HK' | 'US' | 'GLOBAL'>('ALL');

  const filteredIndices = INITIAL_MARKET_INDICES.filter(
    idx => selectedRegion === 'ALL' || idx.region === selectedRegion
  );

  return (
    <div id="market-overview-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部市场标语与快速标签 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Activity size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">全球宏观与中国市场行情总览</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
            行情撮合频率: 3秒/笔 · 演示仿真引擎
          </span>
        </div>

        {/* 区域筛选器 */}
        <div className="flex items-center gap-1 text-xs">
          {(['ALL', 'CN', 'HK', 'US', 'GLOBAL'] as const).map(reg => {
            const labelMap = { ALL: '全部资产', CN: 'A股指数', HK: '港股', US: '美股', GLOBAL: '大宗与汇率' };
            return (
              <button
                key={reg}
                onClick={() => setSelectedRegion(reg)}
                className={`px-2.5 py-1 rounded font-mono transition-colors ${
                  selectedRegion === reg
                    ? 'bg-[#1f6feb] text-white font-semibold'
                    : 'text-[#8b949e] hover:bg-[#161b22] hover:text-white'
                }`}
              >
                {labelMap[reg]}
              </button>
            );
          })}
        </div>
      </div>

      {/* 第一行：大类资产网格卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {filteredIndices.map(idx => {
          const isUp = idx.changePct >= 0;
          return (
            <div
              key={idx.code}
              onClick={() => onSelectTab('market_breadth')}
              className="terminal-card p-3 cursor-pointer hover:border-[#58a6ff] transition-all group flex flex-col justify-between"
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-[#c9d1d9] font-semibold group-hover:text-[#58a6ff]">{idx.name}</span>
                <span className={`text-[10px] font-mono px-1 rounded ${isUp ? 'bg-red-950/60 text-stock-up' : 'bg-green-950/60 text-stock-down'}`}>
                  {idx.status}
                </span>
              </div>
              <div className={`font-mono text-lg font-bold my-1 ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                {idx.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: idx.price < 10 ? 4 : 2 })}
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono">
                <span className={isUp ? 'text-stock-up' : 'text-stock-down'}>
                  {isUp ? '+' : ''}{idx.change.toFixed(2)}
                </span>
                <span className={`font-semibold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                  {isUp ? '+' : ''}{idx.changePct.toFixed(2)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 第二行：核心板块热力矩阵 & 市场宽度情绪 & 北向资金 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 行业板块热力矩阵 (7列) */}
        <div className="lg:col-span-7 terminal-panel p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-[#21262d] mb-3">
            <div className="flex items-center gap-2">
              <Flame size={16} className="text-[#f85149]" />
              <span className="text-xs font-bold text-white">行业板块涨跌幅与资金流入</span>
            </div>
            <button
              onClick={() => onSelectTab('industry')}
              className="text-xs text-[#58a6ff] hover:underline flex items-center gap-1 font-mono"
            >
              查看全部板块 <ArrowUpRight size={13} />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {INDUSTRY_SECTORS.map(sec => {
              const isUp = sec.changePct >= 0;
              return (
                <div
                  key={sec.code}
                  onClick={() => onSelectTab('industry')}
                  className={`p-2.5 rounded border transition-all cursor-pointer ${
                    isUp
                      ? 'bg-red-950/20 border-red-900/40 hover:border-red-500'
                      : 'bg-green-950/20 border-green-900/40 hover:border-green-500'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">{sec.name}</span>
                    <span className={`font-mono text-xs font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isUp ? '+' : ''}{sec.changePct.toFixed(2)}%
                    </span>
                  </div>
                  <div className="mt-2 text-[10px] text-[#8b949e] flex justify-between">
                    <span>领涨: {sec.leadingStock.name}</span>
                    <span className={sec.leadingStock.changePct >= 0 ? 'text-stock-up' : 'text-stock-down'}>
                      +{sec.leadingStock.changePct}%
                    </span>
                  </div>
                  <div className="text-[10px] text-[#8b949e] mt-0.5">
                    净流入: <span className="text-[#58a6ff] font-mono">{sec.netCapitalInflow}亿</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 市场宽度与情绪指标 (5列) */}
        <div className="lg:col-span-5 terminal-panel p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-[#21262d] mb-3">
            <div className="flex items-center gap-2">
              <Compass size={16} className="text-[#e3b341]" />
              <span className="text-xs font-bold text-white">市场情绪与涨跌分布</span>
            </div>
            <span className="text-[10px] text-[#8b949e] font-mono">情绪评分: <strong>{MOCK_MARKET_BREADTH.sentimentScore} / 100</strong></span>
          </div>

          <div className="space-y-3">
            {/* 涨跌家数比率条 */}
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-stock-up font-bold">上涨 {MOCK_MARKET_BREADTH.upCount} 家</span>
                <span className="text-[#8b949e]">平盘 {MOCK_MARKET_BREADTH.flatCount} 家</span>
                <span className="text-stock-down font-bold">下跌 {MOCK_MARKET_BREADTH.downCount} 家</span>
              </div>
              <div className="w-full h-2.5 bg-[#161b22] rounded overflow-hidden flex">
                <div
                  style={{ width: `${(MOCK_MARKET_BREADTH.upCount / (MOCK_MARKET_BREADTH.upCount + MOCK_MARKET_BREADTH.downCount + MOCK_MARKET_BREADTH.flatCount)) * 100}%` }}
                  className="bg-[#f85149]"
                />
                <div
                  style={{ width: `${(MOCK_MARKET_BREADTH.flatCount / (MOCK_MARKET_BREADTH.upCount + MOCK_MARKET_BREADTH.downCount + MOCK_MARKET_BREADTH.flatCount)) * 100}%` }}
                  className="bg-[#8b949e]"
                />
                <div
                  style={{ width: `${(MOCK_MARKET_BREADTH.downCount / (MOCK_MARKET_BREADTH.upCount + MOCK_MARKET_BREADTH.downCount + MOCK_MARKET_BREADTH.flatCount)) * 100}%` }}
                  className="bg-[#3fb950]"
                />
              </div>
            </div>

            {/* 市场核心广度数据矩阵 */}
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
                <div className="text-[10px] text-[#8b949e]">涨停 / 跌停</div>
                <div className="font-mono font-bold mt-0.5">
                  <span className="text-stock-up">{MOCK_MARKET_BREADTH.limitUpCount}</span>
                  <span className="text-[#8b949e] mx-1">/</span>
                  <span className="text-stock-down">{MOCK_MARKET_BREADTH.limitDownCount}</span>
                </div>
              </div>
              <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
                <div className="text-[10px] text-[#8b949e]">两市总成交额</div>
                <div className="font-mono font-bold text-white mt-0.5">{MOCK_MARKET_BREADTH.totalTurnover} 亿</div>
              </div>
              <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
                <div className="text-[10px] text-[#8b949e]">站上20日均线占比</div>
                <div className="font-mono font-bold text-[#58a6ff] mt-0.5">74.2%</div>
              </div>
            </div>

            {/* 北向资金简报 */}
            <div className="p-2.5 rounded bg-[#161b22] border border-[#21262d] flex items-center justify-between text-xs">
              <div>
                <div className="text-[11px] font-semibold text-white">北向陆股通资金 (今日净买入)</div>
                <div className="text-[10px] text-[#8b949e] mt-0.5">沪股通 +28.12亿 · 深股通 +20.20亿</div>
              </div>
              <div className="text-right">
                <div className="font-mono text-base font-bold text-stock-up">+{MOCK_CAPITAL_FLOW.northboundToday} 亿元</div>
                <button
                  onClick={() => onSelectTab('capital_flow')}
                  className="text-[10px] text-[#58a6ff] hover:underline"
                >
                  资金流向详情 →
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 第三行：核心标的龙虎榜 & 实时财经快讯 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 核心关注A股高频监控列表 (8列) */}
        <div className="lg:col-span-8 terminal-panel p-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#21262d] mb-2">
            <div className="flex items-center gap-2">
              <TrendingUp size={16} className="text-[#58a6ff]" />
              <span className="text-xs font-bold text-white">市场核心标的报价与估值</span>
            </div>
            <button
              onClick={() => onSelectTab('screener')}
              className="text-xs text-[#58a6ff] hover:underline"
            >
              高级选股器 →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="text-[#8b949e] border-b border-[#21262d] bg-[#161b22]">
                <tr>
                  <th className="py-2 px-2">代码 / 名称</th>
                  <th className="py-2 px-2 text-right">最新价 (¥)</th>
                  <th className="py-2 px-2 text-right">涨跌幅</th>
                  <th className="py-2 px-2 text-right">换手率</th>
                  <th className="py-2 px-2 text-right">市盈率 (TTM)</th>
                  <th className="py-2 px-2 text-right">总市值 (亿)</th>
                  <th className="py-2 px-2 text-center">操作</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#21262d]">
                {STOCKS_DATABASE.map(stock => {
                  const isUp = stock.changePct >= 0;
                  return (
                    <tr
                      key={stock.code}
                      onClick={() => onSelectStock(stock.code)}
                      className="hover:bg-[#161b22] cursor-pointer transition-colors"
                    >
                      <td className="py-2.5 px-2">
                        <div className="font-bold text-white flex items-center gap-1.5">
                          {stock.name}
                          <span className="text-[10px] text-[#8b949e] font-normal">{stock.exchange}</span>
                        </div>
                        <div className="text-[11px] text-[#58a6ff]">{stock.code}</div>
                      </td>
                      <td className={`py-2.5 px-2 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                        {stock.price.toFixed(2)}
                      </td>
                      <td className={`py-2.5 px-2 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                        {isUp ? '+' : ''}{stock.changePct.toFixed(2)}%
                      </td>
                      <td className="py-2.5 px-2 text-right text-[#c9d1d9]">{stock.turnoverRate.toFixed(2)}%</td>
                      <td className="py-2.5 px-2 text-right text-[#c9d1d9]">{stock.valuation.peTTM.toFixed(1)}</td>
                      <td className="py-2.5 px-2 text-right text-white font-semibold">
                        {stock.valuation.totalMarketCap.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-2 text-center">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectStock(stock.code);
                          }}
                          className="px-2 py-1 rounded bg-[#1f6feb] hover:bg-[#388bfd] text-white text-[10px] font-sans font-medium"
                        >
                          深度研究
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* 实时快讯与权威政策 (4列) */}
        <div className="lg:col-span-4 terminal-panel p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-[#21262d] mb-2">
            <div className="flex items-center gap-2">
              <Layers size={16} className="text-[#3fb950]" />
              <span className="text-xs font-bold text-white">华市 7x24 财经电报</span>
            </div>
            <button
              onClick={() => onSelectTab('news_filing')}
              className="text-xs text-[#58a6ff] hover:underline"
            >
              全部资讯 →
            </button>
          </div>

          <div className="space-y-3 overflow-y-auto max-h-[340px] terminal-scrollbar pr-1">
            {MOCK_NEWS_LIST.map(news => (
              <div
                key={news.id}
                onClick={() => onSelectTab('news_filing')}
                className="p-2 rounded bg-[#161b22] hover:bg-[#1c2128] border border-[#21262d] cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between text-[10px] text-[#8b949e] mb-1">
                  <span className="font-mono text-[#58a6ff]">{news.timestamp}</span>
                  <span className={`px-1 rounded ${news.importance === '特急' ? 'bg-red-900/60 text-stock-up font-bold' : 'bg-[#21262d] text-[#8b949e]'}`}>
                    {news.category}
                  </span>
                </div>
                <div className="text-xs font-semibold text-[#c9d1d9] leading-snug line-clamp-2 hover:text-white">
                  {news.title}
                </div>
                <div className="mt-1 text-[10px] text-[#8b949e] flex items-center justify-between">
                  <span>{news.source}</span>
                  {news.relatedStocks.length > 0 && (
                    <span className="text-[#58a6ff]">关联: {news.relatedStocks[0].name}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
