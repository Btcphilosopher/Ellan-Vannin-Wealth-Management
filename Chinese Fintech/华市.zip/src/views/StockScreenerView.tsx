/**
 * 华市金融终端 - 多维股票量化筛选器 (Section 21)
 */

import React, { useState, useMemo } from 'react';
import { Filter, Download, Sparkles, RefreshCw } from 'lucide-react';
import { STOCKS_DATABASE } from '../services/mockDataEngine';
import { StockQuote, TerminalTab } from '../types';

interface StockScreenerViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const StockScreenerView: React.FC<StockScreenerViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  const [minRoe, setMinRoe] = useState<number>(10);
  const [maxPe, setMaxPe] = useState<number>(40);
  const [minDividend, setMinDividend] = useState<number>(1.0);
  const [minMarketCap, setMinMarketCap] = useState<number>(3000);
  const [minRevenueGrowth, setMinRevenueGrowth] = useState<number>(5);
  const [selectedExchange, setSelectedExchange] = useState<string>('ALL');

  // 预设选股策略
  const applyPreset = (preset: 'buffett' | 'dividend' | 'growth') => {
    if (preset === 'buffett') {
      setMinRoe(20);
      setMaxPe(30);
      setMinDividend(2.0);
      setMinMarketCap(5000);
      setMinRevenueGrowth(10);
    } else if (preset === 'dividend') {
      setMinRoe(10);
      setMaxPe(15);
      setMinDividend(4.0);
      setMinMarketCap(3000);
      setMinRevenueGrowth(0);
    } else if (preset === 'growth') {
      setMinRoe(15);
      setMaxPe(80);
      setMinDividend(0.5);
      setMinMarketCap(3000);
      setMinRevenueGrowth(20);
    }
  };

  const filteredStocks = useMemo(() => {
    return STOCKS_DATABASE.filter(s => {
      if (s.profitability.roe < minRoe) return false;
      if (s.valuation.peTTM > maxPe) return false;
      if (s.valuation.dividendYield < minDividend) return false;
      if (s.valuation.totalMarketCap < minMarketCap) return false;
      if (s.profitability.revenueYoY < minRevenueGrowth) return false;
      if (selectedExchange !== 'ALL' && s.exchange !== selectedExchange) return false;
      return true;
    });
  }, [minRoe, maxPe, minDividend, minMarketCap, minRevenueGrowth, selectedExchange]);

  const handleExportCSV = () => {
    const headers = ['代码', '名称', '交易所', '行业', '最新价', 'PE(TTM)', 'PB', 'ROE(%)', '股息率(%)', '总市值(亿)'];
    const rows = filteredStocks.map(s => [
      s.code,
      s.name,
      s.exchange,
      s.industry,
      s.price,
      s.valuation.peTTM,
      s.valuation.pb,
      s.profitability.roe,
      s.valuation.dividendYield,
      s.valuation.totalMarketCap
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `huashi_screener_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="stock-screener-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部控制栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Filter size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">专业级股票多因子量化筛选器</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#3fb950]">
            已筛选出 {filteredStocks.length} 支标的
          </span>
        </div>

        {/* 策略预设 */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-[#8b949e]">经典策略:</span>
          <button
            onClick={() => applyPreset('buffett')}
            className="px-2.5 py-1 rounded bg-[#161b22] hover:bg-[#1f242c] text-[#58a6ff] border border-[#30363d] flex items-center gap-1"
          >
            <Sparkles size={12} /> 高ROE核心白马
          </button>
          <button
            onClick={() => applyPreset('dividend')}
            className="px-2.5 py-1 rounded bg-[#161b22] hover:bg-[#1f242c] text-[#3fb950] border border-[#30363d]"
          >
            低估值高股息红利
          </button>
          <button
            onClick={() => applyPreset('growth')}
            className="px-2.5 py-1 rounded bg-[#161b22] hover:bg-[#1f242c] text-[#e3b341] border border-[#30363d]"
          >
            高成长科技龙头
          </button>
          <button
            onClick={handleExportCSV}
            className="px-2.5 py-1 rounded bg-[#1f6feb] text-white flex items-center gap-1 font-medium"
          >
            <Download size={13} /> 导出CSV
          </button>
        </div>
      </div>

      {/* 筛选参数调节面板 */}
      <div className="terminal-panel p-3 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 text-xs font-mono">
        <div>
          <label className="text-[#8b949e] block mb-1">净资产收益率 ROE ≥ {minRoe}%</label>
          <input
            type="range"
            min="0"
            max="35"
            step="1"
            value={minRoe}
            onChange={e => setMinRoe(Number(e.target.value))}
            className="w-full accent-[#1f6feb]"
          />
        </div>

        <div>
          <label className="text-[#8b949e] block mb-1">市盈率 PE (TTM) ≤ {maxPe}倍</label>
          <input
            type="range"
            min="5"
            max="100"
            step="5"
            value={maxPe}
            onChange={e => setMaxPe(Number(e.target.value))}
            className="w-full accent-[#1f6feb]"
          />
        </div>

        <div>
          <label className="text-[#8b949e] block mb-1">股息率 ≥ {minDividend}%</label>
          <input
            type="range"
            min="0"
            max="8"
            step="0.5"
            value={minDividend}
            onChange={e => setMinDividend(Number(e.target.value))}
            className="w-full accent-[#1f6feb]"
          />
        </div>

        <div>
          <label className="text-[#8b949e] block mb-1">总市值 ≥ {minMarketCap}亿元</label>
          <input
            type="range"
            min="500"
            max="20000"
            step="500"
            value={minMarketCap}
            onChange={e => setMinMarketCap(Number(e.target.value))}
            className="w-full accent-[#1f6feb]"
          />
        </div>

        <div>
          <label className="text-[#8b949e] block mb-1">营收增速 ≥ {minRevenueGrowth}%</label>
          <input
            type="range"
            min="-10"
            max="50"
            step="5"
            value={minRevenueGrowth}
            onChange={e => setMinRevenueGrowth(Number(e.target.value))}
            className="w-full accent-[#1f6feb]"
          />
        </div>

        <div>
          <label className="text-[#8b949e] block mb-1">板块市场</label>
          <select
            value={selectedExchange}
            onChange={e => setSelectedExchange(e.target.value)}
            className="w-full bg-[#161b22] text-white p-1 rounded border border-[#30363d]"
          >
            <option value="ALL">全部板块</option>
            <option value="沪市主板">沪市主板</option>
            <option value="深市主板">深市主板</option>
            <option value="科创板">科创板</option>
            <option value="创业板">创业板</option>
          </select>
        </div>
      </div>

      {/* 筛选结果数据表 */}
      <div className="terminal-panel p-3">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2.5 px-3">代码 / 名称</th>
                <th className="py-2.5 px-3">板块 / 行业</th>
                <th className="py-2.5 px-3 text-right">最新价 (¥)</th>
                <th className="py-2.5 px-3 text-right">涨跌幅</th>
                <th className="py-2.5 px-3 text-right">PE (TTM)</th>
                <th className="py-2.5 px-3 text-right">PB</th>
                <th className="py-2.5 px-3 text-right">ROE (%)</th>
                <th className="py-2.5 px-3 text-right">股息率 (%)</th>
                <th className="py-2.5 px-3 text-right">营收同比</th>
                <th className="py-2.5 px-3 text-right">总市值 (亿)</th>
                <th className="py-2.5 px-3 text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {filteredStocks.map(stock => {
                const isUp = stock.changePct >= 0;
                return (
                  <tr
                    key={stock.code}
                    onClick={() => onSelectStock(stock.code)}
                    className="hover:bg-[#161b22] cursor-pointer transition-colors"
                  >
                    <td className="py-2.5 px-3">
                      <span className="font-bold text-white mr-2">{stock.name}</span>
                      <span className="text-[#58a6ff]">{stock.code}</span>
                    </td>
                    <td className="py-2.5 px-3 text-[#8b949e]">
                      {stock.exchange} · {stock.industry}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {stock.price.toFixed(2)}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isUp ? '+' : ''}{stock.changePct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-white font-semibold">{stock.valuation.peTTM}</td>
                    <td className="py-2.5 px-3 text-right text-[#c9d1d9]">{stock.valuation.pb}</td>
                    <td className="py-2.5 px-3 text-right text-[#58a6ff] font-bold">{stock.profitability.roe}%</td>
                    <td className="py-2.5 px-3 text-right text-[#3fb950] font-bold">{stock.valuation.dividendYield}%</td>
                    <td className="py-2.5 px-3 text-right text-[#c9d1d9]">{stock.profitability.revenueYoY}%</td>
                    <td className="py-2.5 px-3 text-right text-white font-semibold">{stock.valuation.totalMarketCap.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectStock(stock.code);
                        }}
                        className="px-2.5 py-1 rounded bg-[#1f6feb] text-white text-[11px]"
                      >
                        深度分析
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
