/**
 * 华市金融终端 - 债券市场与中债国债收益率曲线 (Section 18)
 */

import React, { useState } from 'react';
import { Landmark, TrendingDown, Layers, BarChart2 } from 'lucide-react';
import { MOCK_YIELD_CURVE, MOCK_BONDS_LIST } from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface BondMarketViewProps {
  onSelectTab: (tab: TerminalTab) => void;
}

export const BondMarketView: React.FC<BondMarketViewProps> = ({ onSelectTab }) => {
  const [selectedTenor, setSelectedTenor] = useState<string>('10Y');

  // 计算 10Y - 2Y 期限利差 (bp)
  const y10 = MOCK_YIELD_CURVE.find(y => y.tenor === '10Y')?.today || 2.08;
  const y2 = MOCK_YIELD_CURVE.find(y => y.tenor === '2Y')?.today || 1.54;
  const spread10_2 = ((y10 - y2) * 100).toFixed(1);

  // SVG 收益率曲线绘图坐标
  const width = 600;
  const height = 220;
  const margin = { top: 20, right: 30, bottom: 30, left: 40 };
  const plotWidth = width - margin.left - margin.right;
  const plotHeight = height - margin.top - margin.bottom;

  const minYield = 1.0;
  const maxYield = 3.5;

  const getX = (index: number) => margin.left + (index / (MOCK_YIELD_CURVE.length - 1)) * plotWidth;
  const getY = (val: number) => margin.top + (1 - (val - minYield) / (maxYield - minYield)) * plotHeight;

  const todayPath = `M ${MOCK_YIELD_CURVE.map((d, i) => `${getX(i)},${getY(d.today)}`).join(' L ')}`;
  const lastYearPath = `M ${MOCK_YIELD_CURVE.map((d, i) => `${getX(i)},${getY(d.oneYearAgo)}`).join(' L ')}`;

  return (
    <div id="bond-market-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Landmark size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">固定收益与中债国债收益率曲线</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
            中债估值中心直连 · 1M-30Y 关键期限
          </span>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="px-2.5 py-1 bg-[#161b22] rounded border border-[#30363d] text-[#8b949e]">
            10Y-2Y 期限利差: <strong className="text-[#58a6ff]">{spread10_2} BP</strong>
          </div>
          <div className="px-2.5 py-1 bg-[#161b22] rounded border border-[#30363d] text-[#8b949e]">
            10年期国债收益率: <strong className="text-white font-bold">{y10}%</strong>
          </div>
        </div>
      </div>

      {/* 收益率曲线可视化与期限矩阵 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 收益率曲线交互图 (7列) */}
        <div className="lg:col-span-7 terminal-panel p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-[#21262d] mb-2">
            <span className="text-xs font-bold text-white">中债国债到期收益率曲线 (Yield Curve)</span>
            <div className="flex items-center gap-3 text-[11px] font-mono">
              <span className="flex items-center gap-1 text-[#58a6ff]">
                <span className="w-2.5 h-0.5 bg-[#58a6ff] inline-block" /> 今日最新
              </span>
              <span className="flex items-center gap-1 text-[#8b949e]">
                <span className="w-2.5 h-0.5 bg-[#8b949e] inline-block border-dashed" /> 一年前
              </span>
            </div>
          </div>

          {/* SVG 曲线 */}
          <div className="w-full overflow-hidden bg-[#090d13] rounded border border-[#21262d] p-2">
            <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-[200px]">
              {/* 网格线 */}
              {[1.5, 2.0, 2.5, 3.0].map(yVal => (
                <g key={yVal}>
                  <line x1={margin.left} y1={getY(yVal)} x2={width - margin.right} y2={getY(yVal)} stroke="#21262d" strokeDasharray="3,3" />
                  <text x={margin.left - 5} y={getY(yVal) + 3} fill="#8b949e" fontSize="9" textAnchor="end" fontFamily="monospace">{yVal}%</text>
                </g>
              ))}

              {/* 历史一年前曲线 */}
              <path d={lastYearPath} fill="none" stroke="#8b949e" strokeWidth="1.5" strokeDasharray="4,4" opacity="0.6" />

              {/* 今日最新曲线 */}
              <path d={todayPath} fill="none" stroke="#58a6ff" strokeWidth="2.5" />

              {/* 期限点 */}
              {MOCK_YIELD_CURVE.map((d, i) => (
                <g key={d.tenor}>
                  <circle
                    cx={getX(i)}
                    cy={getY(d.today)}
                    r="4"
                    fill="#1f6feb"
                    stroke="#ffffff"
                    strokeWidth="1.5"
                    className="cursor-pointer hover:r-6"
                    onClick={() => setSelectedTenor(d.tenor)}
                  />
                  <text x={getX(i)} y={height - 10} fill="#8b949e" fontSize="9" textAnchor="middle" fontFamily="monospace">
                    {d.tenor}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </div>

        {/* 关键期限收益率明细表 (5列) */}
        <div className="lg:col-span-5 terminal-panel p-3">
          <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 mb-2">
            关键期限到期收益率表 (%)
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
                <tr>
                  <th className="py-1.5 px-2">期限</th>
                  <th className="py-1.5 px-2 text-right">今日</th>
                  <th className="py-1.5 px-2 text-right">昨日</th>
                  <th className="py-1.5 px-2 text-right">1月前</th>
                  <th className="py-1.5 px-2 text-right">1年前</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#21262d]">
                {MOCK_YIELD_CURVE.map(d => (
                  <tr key={d.tenor} className="hover:bg-[#161b22]">
                    <td className="py-1.5 px-2 font-bold text-white">{d.tenor}</td>
                    <td className="py-1.5 px-2 text-right font-bold text-[#58a6ff]">{d.today.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-right text-[#c9d1d9]">{d.yesterday.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-right text-[#8b949e]">{d.oneMonthAgo.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-right text-[#8b949e]">{d.oneYearAgo.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 核心国债与金融债现券列表 */}
      <div className="terminal-panel p-3">
        <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 mb-3 flex items-center justify-between">
          <span>银行间与交易所核心现券报价</span>
          <span className="text-[10px] text-[#8b949e] font-normal">久期 · 凸性 · 到期收益率 YTM</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2 px-3">债券代码 / 券名</th>
                <th className="py-2 px-3">类型</th>
                <th className="py-2 px-3 text-right">剩余期限 (年)</th>
                <th className="py-2 px-3 text-right">票面利率 (%)</th>
                <th className="py-2 px-3 text-right">到期收益率 YTM (%)</th>
                <th className="py-2 px-3 text-right">修正久期</th>
                <th className="py-2 px-3 text-right">凸性</th>
                <th className="py-2 px-3 text-right">净价 (¥)</th>
                <th className="py-2 px-3 text-center">评级</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {MOCK_BONDS_LIST.map(bond => (
                <tr key={bond.code} className="hover:bg-[#161b22]">
                  <td className="py-2.5 px-3">
                    <span className="font-bold text-white mr-2">{bond.name}</span>
                    <span className="text-[#58a6ff]">{bond.code}</span>
                  </td>
                  <td className="py-2.5 px-3 text-[#c9d1d9]">{bond.type}</td>
                  <td className="py-2.5 px-3 text-right text-white font-bold">{bond.maturityYears}</td>
                  <td className="py-2.5 px-3 text-right text-[#c9d1d9]">{bond.couponRate.toFixed(2)}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-[#58a6ff]">{bond.ytm.toFixed(2)}%</td>
                  <td className="py-2.5 px-3 text-right text-white">{bond.duration}</td>
                  <td className="py-2.5 px-3 text-right text-[#c9d1d9]">{bond.convexity}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-white">{bond.cleanPrice.toFixed(2)}</td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-1.5 py-0.5 rounded bg-[#238636]/20 text-[#3fb950] border border-[#238636]/40 font-bold text-[10px]">
                      {bond.creditRating}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
