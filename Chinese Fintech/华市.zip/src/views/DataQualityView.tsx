/**
 * 华市金融终端 - 数据质量中心与源治理 (Section 29)
 */

import React from 'react';
import { Database, ShieldCheck, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';
import { MOCK_DATA_QUALITY } from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface DataQualityViewProps {
  onSelectTab: (tab: TerminalTab) => void;
}

export const DataQualityView: React.FC<DataQualityViewProps> = ({ onSelectTab }) => {
  return (
    <div id="data-quality-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Database size={18} className="text-[#3fb950]" />
          <h1 className="text-sm font-bold text-white tracking-wide">金融数据质量监控与源治理总控台</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#3fb950]">
            全链路低延迟 · 字段完整率 99.98%
          </span>
        </div>
      </div>

      {/* 整体概览卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 font-mono">
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">行情网关平均延迟</div>
          <div className="text-2xl font-bold text-[#3fb950] mt-1">4.2 ms</div>
          <div className="text-[10px] text-[#8b949e] mt-1">专线直连上交所 / 深交所</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">日均数据吞吐量</div>
          <div className="text-2xl font-bold text-white mt-1">1.8 亿条</div>
          <div className="text-[10px] text-[#8b949e] mt-1">Tick / Level 2 / 财报</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">数据审计校验规则</div>
          <div className="text-2xl font-bold text-[#58a6ff] mt-1">128 项</div>
          <div className="text-[10px] text-[#8b949e] mt-1">涵盖资产平衡/除权除息</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">数据服务 SLA 可用性</div>
          <div className="text-2xl font-bold text-[#3fb950] mt-1">99.995%</div>
          <div className="text-[10px] text-[#8b949e] mt-1">高可用双活容灾</div>
        </div>
      </div>

      {/* 数据源监控表 */}
      <div className="terminal-panel p-3">
        <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 mb-3">
          核心金融数据源节点运行状态
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2.5 px-3">数据源类别 / 机构</th>
                <th className="py-2.5 px-3">节点状态</th>
                <th className="py-2.5 px-3 text-right">网络延迟</th>
                <th className="py-2.5 px-3 text-right">数据缺失率 (%)</th>
                <th className="py-2.5 px-3 text-right">校验异常率 (%)</th>
                <th className="py-2.5 px-3 text-right">最后心跳时间</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {MOCK_DATA_QUALITY.map((dq, idx) => (
                <tr key={idx} className="hover:bg-[#161b22]">
                  <td className="py-2.5 px-3 font-bold text-white">{dq.source}</td>
                  <td className="py-2.5 px-3">
                    <span className="flex items-center gap-1.5 text-[#3fb950]">
                      <span className="w-2 h-2 rounded-full bg-[#3fb950] animate-pulse" />
                      {dq.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-white font-bold">{dq.latencyMs} ms</td>
                  <td className="py-2.5 px-3 text-right text-[#c9d1d9]">{dq.missingRate}%</td>
                  <td className="py-2.5 px-3 text-right text-[#3fb950]">{dq.anomalyRate}%</td>
                  <td className="py-2.5 px-3 text-right text-[#8b949e]">{dq.lastSync}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
