/**
 * 华市金融终端 - 量化因子库与策略回测实验室 (Section 26)
 */

import React, { useState } from 'react';
import { Cpu, Play, BarChart2, CheckCircle2, RotateCcw } from 'lucide-react';
import { MOCK_FACTORS } from '../services/mockDataEngine';
import { QuantFactor, TerminalTab } from '../types';

interface QuantResearchViewProps {
  onSelectTab: (tab: TerminalTab) => void;
}

export const QuantResearchView: React.FC<QuantResearchViewProps> = ({ onSelectTab }) => {
  const [selectedFactor, setSelectedFactor] = useState<QuantFactor>(MOCK_FACTORS[0]);
  const [holdingPeriod, setHoldingPeriod] = useState<number>(20);
  const [topPercentile, setTopPercentile] = useState<number>(10);
  const [isRunningBacktest, setIsRunningBacktest] = useState<boolean>(false);
  const [backtestCompleted, setBacktestCompleted] = useState<boolean>(true);

  const handleRunBacktest = () => {
    setIsRunningBacktest(true);
    setTimeout(() => {
      setIsRunningBacktest(false);
      setBacktestCompleted(true);
    }, 600);
  };

  return (
    <div id="quant-research-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Cpu size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">量化因子研究与多因子策略回测实验室</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#3fb950]">
            IC/IR 因子有效性检测 · 分层收益单调性测试
          </span>
        </div>
      </div>

      {/* 因子选择器与参数配置 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 左侧因子列表 (4列) */}
        <div className="lg:col-span-4 terminal-panel p-3 space-y-2">
          <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2">
            标准量化因子库
          </div>
          {MOCK_FACTORS.map(fac => {
            const isSelected = selectedFactor.name === fac.name;
            return (
              <div
                key={fac.name}
                onClick={() => setSelectedFactor(fac)}
                className={`p-2.5 rounded border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#161b22] border-[#58a6ff]'
                    : 'bg-[#0d1117] border-[#21262d] hover:border-[#30363d]'
                }`}
              >
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-white">{fac.name}</span>
                  <span className="text-[10px] px-1 rounded bg-[#21262d] text-[#8b949e]">{fac.category}</span>
                </div>
                <div className="text-[10px] text-[#8b949e] mt-1 line-clamp-1">{fac.description}</div>
                <div className="flex justify-between text-[11px] font-mono mt-2">
                  <span>Rank IC: <strong className="text-stock-up">+{fac.ic}</strong></span>
                  <span>IR比率: <strong className="text-[#58a6ff]">{fac.ir}</strong></span>
                  <span>多头年化: <strong className="text-white">+{fac.longAnnualizedReturn}%</strong></span>
                </div>
              </div>
            );
          })}
        </div>

        {/* 右侧回测参数与净值曲线 (8列) */}
        <div className="lg:col-span-8 terminal-panel p-3 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#21262d]">
            <span className="text-xs font-bold text-white">
              【{selectedFactor.name}】单因子分层回测参数配置
            </span>
            <button
              onClick={handleRunBacktest}
              disabled={isRunningBacktest}
              className="px-3 py-1.5 rounded bg-[#238636] hover:bg-[#2ea043] text-white text-xs font-medium flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <Play size={13} /> {isRunningBacktest ? '回测计算中...' : '运行因子回测'}
            </button>
          </div>

          {/* 参数调节 */}
          <div className="grid grid-cols-3 gap-3 text-xs font-mono">
            <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
              <label className="text-[10px] text-[#8b949e] block mb-1">调仓周期 (交易日)</label>
              <select
                value={holdingPeriod}
                onChange={e => setHoldingPeriod(Number(e.target.value))}
                className="w-full bg-[#0d1117] text-white p-1 rounded border border-[#30363d]"
              >
                <option value={5}>5日 (周频)</option>
                <option value={20}>20日 (月频)</option>
                <option value={60}>60日 (季频)</option>
              </select>
            </div>
            <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
              <label className="text-[10px] text-[#8b949e] block mb-1">多头分位数 (%)</label>
              <select
                value={topPercentile}
                onChange={e => setTopPercentile(Number(e.target.value))}
                className="w-full bg-[#0d1117] text-white p-1 rounded border border-[#30363d]"
              >
                <option value={10}>Top 10% (多头)</option>
                <option value={20}>Top 20% (多头)</option>
                <option value={30}>Top 30% (多头)</option>
              </select>
            </div>
            <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
              <label className="text-[10px] text-[#8b949e] block mb-1">基准对标</label>
              <div className="text-white font-bold p-1">中证500 / 沪深300</div>
            </div>
          </div>

          {/* 回测结果指标矩阵 */}
          <div className="grid grid-cols-4 gap-2 text-center font-mono">
            <div className="p-2 bg-[#161b22] rounded">
              <div className="text-[10px] text-[#8b949e]">多空年化收益</div>
              <div className="text-base font-bold text-stock-up mt-0.5">+{selectedFactor.longAnnualizedReturn}%</div>
            </div>
            <div className="p-2 bg-[#161b22] rounded">
              <div className="text-[10px] text-[#8b949e]">信息比率 (IR)</div>
              <div className="text-base font-bold text-[#58a6ff] mt-0.5">{selectedFactor.ir}</div>
            </div>
            <div className="p-2 bg-[#161b22] rounded">
              <div className="text-[10px] text-[#8b949e]">最大回撤</div>
              <div className="text-base font-bold text-[#f85149] mt-0.5">-{selectedFactor.maxDrawdown}%</div>
            </div>
            <div className="p-2 bg-[#161b22] rounded">
              <div className="text-[10px] text-[#8b949e]">换手率 (单边)</div>
              <div className="text-base font-bold text-white mt-0.5">{selectedFactor.turnoverRate}%</div>
            </div>
          </div>

          {/* 策略说明与代码示例 */}
          <div className="p-3 bg-[#0d1117] rounded border border-[#21262d] text-xs font-mono text-[#8b949e] space-y-1">
            <div className="text-white font-semibold">因子逻辑公式：</div>
            <div className="text-[#58a6ff]">{selectedFactor.description}</div>
            <div className="text-[11px] text-[#8b949e] mt-2">
              分层单调性：第一组 (Top 10%) 表现显著超越第五组 (Bottom 10%)，具备极强超额 Alpha 捕捉能力。
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
