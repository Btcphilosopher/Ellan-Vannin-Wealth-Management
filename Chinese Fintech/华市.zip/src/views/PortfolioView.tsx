/**
 * 华市金融终端 - 模拟投资组合与组合风险绩效归因 (Section 25)
 */

import React, { useState } from 'react';
import { Briefcase, TrendingUp, ShieldAlert, Plus, DollarSign } from 'lucide-react';
import { MOCK_PORTFOLIO, STOCKS_DATABASE } from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface PortfolioViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const PortfolioView: React.FC<PortfolioViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  const [portfolio, setPortfolio] = useState(MOCK_PORTFOLIO);

  const totalValue = portfolio.totalAssetValue;
  const totalCost = portfolio.positions.reduce((acc, p) => acc + p.shares * p.costPrice, 0);
  const totalPnL = totalValue - totalCost;
  const totalPnLPct = ((totalPnL / totalCost) * 100).toFixed(2);

  return (
    <div id="portfolio-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部组合概览 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Briefcase size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">{portfolio.name}</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
            组合ID: {portfolio.id} · 基准: 沪深300指数
          </span>
        </div>
      </div>

      {/* 核心业绩与风险指标卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 font-mono">
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">组合总资产 (¥)</div>
          <div className="text-xl font-bold text-white mt-1">¥{totalValue.toLocaleString()}</div>
          <div className="text-[10px] text-[#8b949e] mt-1">可用现金: ¥{portfolio.cash.toLocaleString()}</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">累计总盈亏 (¥)</div>
          <div className="text-xl font-bold text-stock-up mt-1">+¥{totalPnL.toLocaleString()}</div>
          <div className="text-[10px] text-stock-up mt-1">收益率: +{totalPnLPct}%</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">夏普比率 (Sharpe Ratio)</div>
          <div className="text-xl font-bold text-[#58a6ff] mt-1">{portfolio.performanceMetrics.sharpeRatio}</div>
          <div className="text-[10px] text-[#8b949e] mt-1">年化无风险: 2.1%</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">最大回撤 (Max Drawdown)</div>
          <div className="text-xl font-bold text-[#f85149] mt-1">-{portfolio.performanceMetrics.maxDrawdown}%</div>
          <div className="text-[10px] text-[#8b949e] mt-1">波动率: {portfolio.performanceMetrics.annualizedVolatility}%</div>
        </div>
        <div className="p-3 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">超额收益 Alpha / Beta</div>
          <div className="text-xl font-bold text-[#3fb950] mt-1">+{portfolio.performanceMetrics.alpha}% / {portfolio.performanceMetrics.beta}</div>
          <div className="text-[10px] text-[#8b949e] mt-1">超越基准收益</div>
        </div>
      </div>

      {/* 持仓明细表 */}
      <div className="terminal-panel p-3">
        <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 mb-3 flex items-center justify-between">
          <span>当前证券持仓与实时浮动盈亏</span>
          <span className="text-[10px] text-[#8b949e] font-normal">持仓占比汇总: 86.8% · 现金占比: 13.2%</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2.5 px-3">代码 / 名称</th>
                <th className="py-2.5 px-3 text-right">持仓股数 (股)</th>
                <th className="py-2.5 px-3 text-right">持仓成本 (¥)</th>
                <th className="py-2.5 px-3 text-right">当前市价 (¥)</th>
                <th className="py-2.5 px-3 text-right">最新市值 (¥)</th>
                <th className="py-2.5 px-3 text-right">浮动盈亏 (¥)</th>
                <th className="py-2.5 px-3 text-right">盈亏比例 (%)</th>
                <th className="py-2.5 px-3 text-right">仓位占比 (%)</th>
                <th className="py-2.5 px-3 text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {portfolio.positions.map(pos => {
                const isPosUp = pos.unrealizedPnL >= 0;
                return (
                  <tr key={pos.code} className="hover:bg-[#161b22]">
                    <td className="py-2.5 px-3">
                      <span className="font-bold text-white mr-2">{pos.name}</span>
                      <span className="text-[#58a6ff]">{pos.code}</span>
                    </td>
                    <td className="py-2.5 px-3 text-right text-white">{pos.shares.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-right text-[#c9d1d9]">{pos.costPrice.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right font-bold text-white">{pos.currentPrice.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-white font-semibold">{pos.marketValue.toLocaleString()}</td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isPosUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isPosUp ? '+' : ''}{pos.unrealizedPnL.toLocaleString()}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isPosUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isPosUp ? '+' : ''}{pos.unrealizedPnLPct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#58a6ff] font-bold">{pos.weightPct}%</td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        onClick={() => onSelectStock(pos.code)}
                        className="px-2 py-0.5 rounded bg-[#1f6feb] text-white text-[10px]"
                      >
                        详情
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
