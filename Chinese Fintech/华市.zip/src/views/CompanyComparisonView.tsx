/**
 * 华市金融终端 - 上市公司多维对标与同业深度比较 (Section 11)
 */

import React, { useState } from 'react';
import { ArrowLeftRight, Plus, Trash2 } from 'lucide-react';
import { STOCKS_DATABASE } from '../services/mockDataEngine';
import { StockQuote, TerminalTab } from '../types';

interface CompanyComparisonViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const CompanyComparisonView: React.FC<CompanyComparisonViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  // 默认对比三支代表性龙头：贵州茅台、五粮液、宁德时代
  const [selectedCodes, setSelectedCodes] = useState<string[]>(['600519', '000858', '300750']);

  const comparisonStocks = STOCKS_DATABASE.filter(s => selectedCodes.includes(s.code));

  const handleAddStock = (code: string) => {
    if (!selectedCodes.includes(code) && selectedCodes.length < 5) {
      setSelectedCodes([...selectedCodes, code]);
    }
  };

  const handleRemoveStock = (code: string) => {
    if (selectedCodes.length > 1) {
      setSelectedCodes(selectedCodes.filter(c => c !== code));
    }
  };

  return (
    <div id="company-comparison-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部控制栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <ArrowLeftRight size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">公司同业估值与财务质量多维对标</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
            横向对比 {comparisonStocks.length} 支标的
          </span>
        </div>

        {/* 添加对比标的 */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-[#8b949e]">添加标的:</span>
          <select
            onChange={e => {
              if (e.target.value) handleAddStock(e.target.value);
            }}
            value=""
            className="bg-[#161b22] text-xs text-white border border-[#30363d] rounded px-2.5 py-1 font-mono focus:outline-none"
          >
            <option value="">+ 选择对比股票...</option>
            {STOCKS_DATABASE.filter(s => !selectedCodes.includes(s.code)).map(s => (
              <option key={s.code} value={s.code}>
                {s.name} ({s.code}) - {s.industry}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 标的卡片行 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {comparisonStocks.map(stock => (
          <div key={stock.code} className="p-3 bg-[#161b22] rounded border border-[#21262d] relative group">
            <button
              onClick={() => handleRemoveStock(stock.code)}
              className="absolute top-2 right-2 text-[#8b949e] hover:text-[#f85149] transition-colors p-1"
              title="移除对比"
            >
              <Trash2 size={13} />
            </button>
            <div className="font-bold text-white text-sm">{stock.name}</div>
            <div className="text-[11px] text-[#58a6ff] font-mono">{stock.code} · {stock.industry}</div>
            <div className="mt-2 text-base font-mono font-bold text-white">¥{stock.price.toFixed(2)}</div>
            <div className={`text-xs font-mono font-semibold ${stock.changePct >= 0 ? 'text-stock-up' : 'text-stock-down'}`}>
              {stock.changePct >= 0 ? '+' : ''}{stock.changePct}%
            </div>
          </div>
        ))}
      </div>

      {/* 多维对比矩阵表格 */}
      <div className="terminal-panel p-3">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2.5 px-3 w-48">对比分析维度 / 指标</th>
                {comparisonStocks.map(s => (
                  <th key={s.code} className="py-2.5 px-3 text-right">
                    <div className="text-white font-bold">{s.name}</div>
                    <div className="text-[10px] text-[#58a6ff] font-normal">{s.code}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {/* 1. 估值维度 */}
              <tr className="bg-[#161b22]/40 text-[#58a6ff] font-bold">
                <td colSpan={comparisonStocks.length + 1} className="py-2 px-3">
                  一、估值乘数矩阵
                </td>
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">市盈率 (PE-TTM)</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right font-bold text-white">{s.valuation.peTTM} 倍</td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">市净率 (PB)</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right text-white">{s.valuation.pb} 倍</td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">市销率 (PS)</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right text-white">{s.valuation.ps} 倍</td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">EV / EBITDA</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right text-white">{s.valuation.evEbitda} 倍</td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">股息收益率 (TTM)</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right font-bold text-[#3fb950]">{s.valuation.dividendYield}%</td>
                ))}
              </tr>

              {/* 2. 盈利质量与回报 */}
              <tr className="bg-[#161b22]/40 text-[#58a6ff] font-bold">
                <td colSpan={comparisonStocks.length + 1} className="py-2 px-3">
                  二、盈利质量与资本回报
                </td>
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">净资产收益率 (ROE)</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right font-bold text-[#58a6ff]">{s.profitability.roe}%</td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">投入资本回报率 (ROIC)</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right text-white">{s.profitability.roic}%</td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">销售毛利率 (Gross Margin)</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right text-white">{s.profitability.grossMargin}%</td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">销售净利率 (Net Margin)</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right text-white">{s.profitability.netMargin}%</td>
                ))}
              </tr>

              {/* 3. 增长与成长性 */}
              <tr className="bg-[#161b22]/40 text-[#58a6ff] font-bold">
                <td colSpan={comparisonStocks.length + 1} className="py-2 px-3">
                  三、成长性与增长动能
                </td>
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">营业收入同比增长</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right font-bold text-white">+{s.profitability.revenueYoY}%</td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">归母净利润同比增长</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right font-bold text-white">+{s.profitability.netProfitYoY}%</td>
                ))}
              </tr>

              {/* 4. 偿债与稳健度 */}
              <tr className="bg-[#161b22]/40 text-[#58a6ff] font-bold">
                <td colSpan={comparisonStocks.length + 1} className="py-2 px-3">
                  四、偿债与资产流动性
                </td>
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">资产负债率</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right text-white">{s.profitability.debtToAssetRatio}%</td>
                ))}
              </tr>
              <tr>
                <td className="py-2 px-3 text-[#c9d1d9] pl-6">货币资金及等价物 (亿)</td>
                {comparisonStocks.map(s => (
                  <td key={s.code} className="py-2 px-3 text-right text-white">{s.profitability.cashEquivalents.toLocaleString()}</td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
