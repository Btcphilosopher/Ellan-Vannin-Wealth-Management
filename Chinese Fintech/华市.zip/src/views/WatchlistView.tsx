/**
 * 华市金融终端 - 自选股多列表管理与实时监控 (Section 24)
 */

import React, { useState } from 'react';
import { Bookmark, Plus, Trash2, TrendingUp, Sparkles } from 'lucide-react';
import { STOCKS_DATABASE } from '../services/mockDataEngine';
import { StockQuote, TerminalTab } from '../types';

interface WatchlistViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const WatchlistView: React.FC<WatchlistViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  const [activeGroup, setActiveGroup] = useState<string>('核心底仓');
  const [groups, setGroups] = useState<Record<string, string[]>>({
    '核心底仓': ['600519', '600036', '600900'],
    '高成长制造': ['300750', '002594', '688981'],
    '金融与券商': ['601318', '300059']
  });

  const [newGroupName, setNewGroupName] = useState('');
  const [showAddGroup, setShowAddGroup] = useState(false);

  const currentCodes = groups[activeGroup] || [];
  const watchlistStocks = STOCKS_DATABASE.filter(s => currentCodes.includes(s.code));

  const handleCreateGroup = () => {
    if (newGroupName.trim() && !groups[newGroupName.trim()]) {
      setGroups({ ...groups, [newGroupName.trim()]: ['600519'] });
      setActiveGroup(newGroupName.trim());
      setNewGroupName('');
      setShowAddGroup(false);
    }
  };

  const handleRemoveStock = (code: string) => {
    setGroups({
      ...groups,
      [activeGroup]: currentCodes.filter(c => c !== code)
    });
  };

  return (
    <div id="watchlist-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题与分组栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Bookmark size={18} className="text-[#e3b341]" />
          <h1 className="text-sm font-bold text-white tracking-wide">自选证券组合与实时盯盘监控</h1>
        </div>

        {/* 分组切换与创建 */}
        <div className="flex items-center gap-2 text-xs">
          {Object.keys(groups).map(g => (
            <button
              key={g}
              onClick={() => setActiveGroup(g)}
              className={`px-3 py-1 rounded font-medium transition-colors ${
                activeGroup === g
                  ? 'bg-[#1f6feb] text-white'
                  : 'bg-[#161b22] text-[#8b949e] hover:text-white border border-[#21262d]'
              }`}
            >
              {g} ({groups[g].length})
            </button>
          ))}

          {showAddGroup ? (
            <div className="flex items-center gap-1">
              <input
                type="text"
                placeholder="分组名称..."
                value={newGroupName}
                onChange={e => setNewGroupName(e.target.value)}
                className="bg-[#161b22] text-xs text-white border border-[#30363d] px-2 py-0.5 rounded"
              />
              <button
                onClick={handleCreateGroup}
                className="px-2 py-0.5 bg-[#238636] text-white rounded text-xs"
              >
                确定
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowAddGroup(true)}
              className="px-2 py-1 bg-[#161b22] text-[#8b949e] hover:text-white rounded border border-[#21262d] flex items-center gap-1"
            >
              <Plus size={12} /> 新建分组
            </button>
          )}
        </div>
      </div>

      {/* 自选股数据表 */}
      <div className="terminal-panel p-3">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2.5 px-3">标的代码 / 名称</th>
                <th className="py-2.5 px-3">板块 / 行业</th>
                <th className="py-2.5 px-3 text-right">最新价 (¥)</th>
                <th className="py-2.5 px-3 text-right">涨跌额</th>
                <th className="py-2.5 px-3 text-right">涨跌幅 (%)</th>
                <th className="py-2.5 px-3 text-right">换手率</th>
                <th className="py-2.5 px-3 text-right">PE (TTM)</th>
                <th className="py-2.5 px-3 text-right">股息率</th>
                <th className="py-2.5 px-3 text-right">总市值 (亿)</th>
                <th className="py-2.5 px-3 text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {watchlistStocks.map(stock => {
                const isUp = stock.changePct >= 0;
                return (
                  <tr
                    key={stock.code}
                    onClick={() => onSelectStock(stock.code)}
                    className="hover:bg-[#161b22] cursor-pointer transition-colors"
                  >
                    <td className="py-2.5 px-3">
                      <span className="font-bold text-white mr-2">{stock.name}</span>
                      <span className="text-[#58a6ff]">{stock.code}</span>
                    </td>
                    <td className="py-2.5 px-3 text-[#8b949e]">
                      {stock.exchange} · {stock.industry}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold text-sm ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {stock.price.toFixed(2)}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isUp ? '+' : ''}{stock.change.toFixed(2)}
                    </td>
                    <td className={`py-2.5 px-3 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isUp ? '+' : ''}{stock.changePct.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#c9d1d9]">{stock.turnoverRate}%</td>
                    <td className="py-2.5 px-3 text-right text-white">{stock.valuation.peTTM}</td>
                    <td className="py-2.5 px-3 text-right text-[#3fb950] font-bold">{stock.valuation.dividendYield}%</td>
                    <td className="py-2.5 px-3 text-right text-white font-semibold">{stock.valuation.totalMarketCap.toLocaleString()}</td>
                    <td className="py-2.5 px-3 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemoveStock(stock.code);
                        }}
                        className="p-1 text-[#8b949e] hover:text-[#f85149] rounded"
                        title="从分组移除"
                      >
                        <Trash2 size={13} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
