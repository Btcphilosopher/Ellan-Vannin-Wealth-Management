/**
 * 华市金融终端 - 7x24 财经电报与上市公司法定信息披露 (Section 20)
 */

import React, { useState } from 'react';
import { Newspaper, Search, FileText, ExternalLink, Filter } from 'lucide-react';
import { MOCK_NEWS_LIST, MOCK_ANNOUNCEMENTS } from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface NewsDisclosureViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const NewsDisclosureView: React.FC<NewsDisclosureViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  const [activeTab, setActiveTab] = useState<'news' | 'announcements'>('news');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');

  const filteredNews = MOCK_NEWS_LIST.filter(n => {
    if (selectedCategory !== 'ALL' && n.category !== selectedCategory) return false;
    if (searchQuery && !n.title.includes(searchQuery) && !n.summary.includes(searchQuery)) return false;
    return true;
  });

  const filteredAnnouncements = MOCK_ANNOUNCEMENTS.filter(a => {
    if (searchQuery && !a.title.includes(searchQuery) && !a.stockName.includes(searchQuery) && !a.stockCode.includes(searchQuery)) return false;
    return true;
  });

  return (
    <div id="news-disclosure-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题与Tab栏 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Newspaper size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">财经要闻、行业资讯与法定披露公告</h1>
        </div>

        {/* 资讯与公告切换 */}
        <div className="flex items-center gap-2">
          <div className="flex bg-[#161b22] p-0.5 rounded border border-[#30363d] text-xs">
            <button
              onClick={() => setActiveTab('news')}
              className={`px-3 py-1 rounded font-medium ${activeTab === 'news' ? 'bg-[#1f6feb] text-white' : 'text-[#8b949e]'}`}
            >
              7x24 实时电报
            </button>
            <button
              onClick={() => setActiveTab('announcements')}
              className={`px-3 py-1 rounded font-medium ${activeTab === 'announcements' ? 'bg-[#1f6feb] text-white' : 'text-[#8b949e]'}`}
            >
              上市公司法定公告
            </button>
          </div>

          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#8b949e]" />
            <input
              type="text"
              placeholder="搜索资讯或公告关键词..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-[#161b22] text-xs text-white border border-[#30363d] rounded pl-8 pr-3 py-1 font-mono focus:outline-none focus:border-[#58a6ff] w-56"
            />
          </div>
        </div>
      </div>

      {/* 资讯模式 */}
      {activeTab === 'news' && (
        <div className="terminal-panel p-3 space-y-3">
          <div className="space-y-2">
            {filteredNews.map(news => (
              <div key={news.id} className="p-3 bg-[#161b22] rounded border border-[#21262d] hover:border-[#30363d] transition-colors space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[#58a6ff] font-bold">{news.timestamp}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${news.importance === '特急' ? 'bg-red-950/80 text-stock-up font-bold' : 'bg-[#21262d] text-[#8b949e]'}`}>
                      {news.category}
                    </span>
                    <span className="text-[10px] text-[#8b949e]">{news.source}</span>
                  </div>
                  {news.relatedStocks.length > 0 && (
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] text-[#8b949e]">关联标的:</span>
                      {news.relatedStocks.map(rs => (
                        <button
                          key={rs.code}
                          onClick={() => onSelectStock(rs.code)}
                          className="text-xs text-[#58a6ff] hover:underline font-mono"
                        >
                          {rs.name} ({rs.code})
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <h3 className="text-sm font-bold text-white leading-snug">{news.title}</h3>
                <p className="text-xs text-[#c9d1d9] leading-relaxed">{news.summary}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 公告模式 */}
      {activeTab === 'announcements' && (
        <div className="terminal-panel p-3">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2.5 px-3">公告发布时间</th>
                <th className="py-2.5 px-3">标的代码 / 名称</th>
                <th className="py-2.5 px-3">类型</th>
                <th className="py-2.5 px-3">公告标题</th>
                <th className="py-2.5 px-3 text-right">文件大小</th>
                <th className="py-2.5 px-3 text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {filteredAnnouncements.map(ann => (
                <tr key={ann.id} className="hover:bg-[#161b22]">
                  <td className="py-2.5 px-3 text-[#8b949e]">{ann.date} {ann.time}</td>
                  <td className="py-2.5 px-3">
                    <span className="font-bold text-white mr-2">{ann.stockName}</span>
                    <span className="text-[#58a6ff]">{ann.stockCode}</span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="px-1.5 py-0.5 rounded bg-[#21262d] text-white text-[10px]">
                      {ann.type}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-white max-w-md truncate">
                    {ann.title}
                  </td>
                  <td className="py-2.5 px-3 text-right text-[#8b949e]">{ann.fileSize}</td>
                  <td className="py-2.5 px-3 text-center">
                    <button
                      onClick={() => onSelectStock(ann.stockCode)}
                      className="px-2.5 py-1 rounded bg-[#1f6feb] text-white text-[10px]"
                    >
                      查看研报
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
