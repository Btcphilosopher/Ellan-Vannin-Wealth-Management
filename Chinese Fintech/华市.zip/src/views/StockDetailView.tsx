/**
 * 华市金融终端 - 个股全景与深度行情投研视图 (Section 7, 8, 9, 10)
 * 包含十档/五档买卖盘口、K线/分时图、三张财务报表、估值与盈利能力指标、公司概况与主营构成
 */

import React, { useState, useMemo } from 'react';
import {
  Bookmark,
  Share2,
  Download,
  Bot,
  ArrowLeftRight,
  TrendingUp,
  FileSpreadsheet,
  Building,
  DollarSign,
  PieChart as PieIcon
} from 'lucide-react';
import { StockQuote, TerminalTab } from '../types';
import {
  STOCKS_DATABASE,
  generateKLineData,
  getCompanyFinancialStatements
} from '../services/mockDataEngine';
import { FinancialChart } from '../components/FinancialChart';

interface StockDetailViewProps {
  stockCode: string;
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
  onTriggerAiResearch?: (stock: StockQuote) => void;
}

export const StockDetailView: React.FC<StockDetailViewProps> = ({
  stockCode,
  onSelectStock,
  onSelectTab,
  onTriggerAiResearch
}) => {
  const stock = useMemo(() => {
    return STOCKS_DATABASE.find(s => s.code === stockCode) || STOCKS_DATABASE[0];
  }, [stockCode]);

  const [activeSubTab, setActiveSubTab] = useState<'chart' | 'financials' | 'valuation' | 'profile'>('chart');
  const [statementType, setStatementType] = useState<'income' | 'balance' | 'cashflow'>('income');
  const [isStarred, setIsStarred] = useState(false);

  // 获取该股票的K线数据与财报数据
  const kLineData = useMemo(() => generateKLineData(stock.code, '日K', 120), [stock.code]);
  const financials = useMemo(() => getCompanyFinancialStatements(stock.code), [stock.code]);

  const isUp = stock.changePct >= 0;

  return (
    <div id="stock-detail-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标的快捷切换与信息栏 */}
      <div className="terminal-panel p-3 flex flex-wrap items-center justify-between gap-4">
        {/* 左侧股票核心报价与基础资料 */}
        <div className="flex items-center gap-4">
          <select
            value={stock.code}
            onChange={(e) => onSelectStock(e.target.value)}
            className="bg-[#161b22] text-white border border-[#30363d] rounded px-2.5 py-1.5 text-xs font-mono font-bold focus:outline-none focus:border-[#58a6ff]"
          >
            {STOCKS_DATABASE.map(s => (
              <option key={s.code} value={s.code}>
                {s.name} ({s.code}) - {s.exchange}
              </option>
            ))}
          </select>

          <div>
            <div className="flex items-baseline gap-3">
              <span className={`text-2xl font-mono font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                ¥{stock.price.toFixed(2)}
              </span>
              <span className={`text-sm font-mono font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                {isUp ? '+' : ''}{stock.change.toFixed(2)} ({isUp ? '+' : ''}{stock.changePct.toFixed(2)}%)
              </span>
              <span className="text-xs px-1.5 py-0.5 rounded bg-[#161b22] border border-[#30363d] text-[#8b949e]">
                {stock.state} · 15:00:00
              </span>
            </div>
            <div className="text-[11px] text-[#8b949e] flex items-center gap-3 mt-1 font-mono">
              <span>行业: <strong className="text-white">{stock.industry}</strong></span>
              <span>板块: <strong className="text-white">{stock.sector}</strong></span>
              <span>振幅: <strong className="text-white">{stock.amplitude}%</strong></span>
              <span>换手: <strong className="text-white">{stock.turnoverRate}%</strong></span>
            </div>
          </div>
        </div>

        {/* 顶部快速操作按键 */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsStarred(!isStarred)}
            className={`px-3 py-1.5 rounded text-xs flex items-center gap-1.5 transition-colors ${
              isStarred
                ? 'bg-[#e3b341] text-black font-semibold'
                : 'bg-[#161b22] text-[#8b949e] hover:text-white border border-[#30363d]'
            }`}
          >
            <Bookmark size={14} className={isStarred ? 'fill-black' : ''} />
            {isStarred ? '已关注' : '加入自选'}
          </button>

          <button
            onClick={() => onSelectTab('comparison')}
            className="px-3 py-1.5 rounded text-xs bg-[#161b22] text-[#8b949e] hover:text-white border border-[#30363d] flex items-center gap-1.5"
          >
            <ArrowLeftRight size={14} />
            同业对比
          </button>

          <button
            onClick={() => {
              if (onTriggerAiResearch) onTriggerAiResearch(stock);
              else onSelectTab('ai_assistant');
            }}
            className="px-3 py-1.5 rounded text-xs bg-gradient-to-r from-[#1f6feb] to-[#238636] text-white font-medium flex items-center gap-1.5 shadow"
          >
            <Bot size={14} />
            AI 智能研报
          </button>
        </div>
      </div>

      {/* 核心指标参数条 (开高低收、市盈率、市值、成交额) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2 text-xs font-mono">
        <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">今开 / 昨收</div>
          <div className="font-bold text-white mt-0.5">{stock.open.toFixed(2)} / {stock.prevClose.toFixed(2)}</div>
        </div>
        <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">最高 / 最低</div>
          <div className="font-bold text-white mt-0.5">
            <span className="text-stock-up">{stock.high.toFixed(2)}</span> / <span className="text-stock-down">{stock.low.toFixed(2)}</span>
          </div>
        </div>
        <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">成交量 / 成交额</div>
          <div className="font-bold text-[#e3b341] mt-0.5">{(stock.volume / 10000).toFixed(1)}万手 / {(stock.turnover / 10000).toFixed(1)}亿</div>
        </div>
        <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">市盈率 (TTM)</div>
          <div className="font-bold text-white mt-0.5">{stock.valuation.peTTM} 倍</div>
        </div>
        <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">市净率 (PB)</div>
          <div className="font-bold text-white mt-0.5">{stock.valuation.pb} 倍</div>
        </div>
        <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">股息率 (TTM)</div>
          <div className="font-bold text-[#3fb950] mt-0.5">{stock.valuation.dividendYield}%</div>
        </div>
        <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">净资产收益率 (ROE)</div>
          <div className="font-bold text-[#58a6ff] mt-0.5">{stock.profitability.roe}%</div>
        </div>
        <div className="p-2 bg-[#161b22] rounded border border-[#21262d]">
          <div className="text-[10px] text-[#8b949e]">总市值 (亿元)</div>
          <div className="font-bold text-white mt-0.5">{stock.valuation.totalMarketCap.toLocaleString()}</div>
        </div>
      </div>

      {/* 主工作区：左侧图表与财报分析，右侧五档/十档买卖盘口 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 左侧主要分析面板 (9列) */}
        <div className="lg:col-span-9 space-y-3">
          {/* 子功能切换Tab */}
          <div className="flex items-center gap-2 border-b border-[#21262d] pb-2 text-xs">
            <button
              onClick={() => setActiveSubTab('chart')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded font-medium transition-colors ${
                activeSubTab === 'chart'
                  ? 'bg-[#1f6feb] text-white'
                  : 'text-[#8b949e] hover:text-white hover:bg-[#161b22]'
              }`}
            >
              <TrendingUp size={14} /> 行情图表与指标
            </button>
            <button
              onClick={() => setActiveSubTab('financials')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded font-medium transition-colors ${
                activeSubTab === 'financials'
                  ? 'bg-[#1f6feb] text-white'
                  : 'text-[#8b949e] hover:text-white hover:bg-[#161b22]'
              }`}
            >
              <FileSpreadsheet size={14} /> 财务报表 (三张表)
            </button>
            <button
              onClick={() => setActiveSubTab('valuation')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded font-medium transition-colors ${
                activeSubTab === 'valuation'
                  ? 'bg-[#1f6feb] text-white'
                  : 'text-[#8b949e] hover:text-white hover:bg-[#161b22]'
              }`}
            >
              <DollarSign size={14} /> 估值与盈利能力
            </button>
            <button
              onClick={() => setActiveSubTab('profile')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded font-medium transition-colors ${
                activeSubTab === 'profile'
                  ? 'bg-[#1f6feb] text-white'
                  : 'text-[#8b949e] hover:text-white hover:bg-[#161b22]'
              }`}
            >
              <Building size={14} /> 公司资料与主营构成
            </button>
          </div>

          {/* 1. K线与分时图表 */}
          {activeSubTab === 'chart' && (
            <FinancialChart
              data={kLineData}
              stockName={stock.name}
              stockCode={stock.code}
              currentPrice={stock.price}
            />
          )}

          {/* 2. 财务报表 (利润表 / 资产负债表 / 现金流量表) */}
          {activeSubTab === 'financials' && (
            <div className="terminal-panel p-3 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#21262d]">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">标准化时序财务报表 (中证权威会计准则)</span>
                  <div className="flex items-center gap-1 bg-[#161b22] p-0.5 rounded border border-[#30363d] text-xs">
                    <button
                      onClick={() => setStatementType('income')}
                      className={`px-2.5 py-1 rounded font-medium ${statementType === 'income' ? 'bg-[#1f6feb] text-white' : 'text-[#8b949e]'}`}
                    >
                      利润表
                    </button>
                    <button
                      onClick={() => setStatementType('balance')}
                      className={`px-2.5 py-1 rounded font-medium ${statementType === 'balance' ? 'bg-[#1f6feb] text-white' : 'text-[#8b949e]'}`}
                    >
                      资产负债表
                    </button>
                    <button
                      onClick={() => setStatementType('cashflow')}
                      className={`px-2.5 py-1 rounded font-medium ${statementType === 'cashflow' ? 'bg-[#1f6feb] text-white' : 'text-[#8b949e]'}`}
                    >
                      现金流量表
                    </button>
                  </div>
                </div>
                <span className="text-[11px] text-[#8b949e] font-mono">单位: 亿元人民币</span>
              </div>

              {/* 表格 */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
                    <tr>
                      <th className="py-2 px-3">会计科目</th>
                      {financials.years.map(y => (
                        <th key={y} className="py-2 px-3 text-right">{y}年度</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#21262d]">
                    {(statementType === 'income'
                      ? financials.incomeStatement
                      : statementType === 'balance'
                      ? financials.balanceSheet
                      : financials.cashFlowStatement
                    ).map((row, idx) => (
                      <tr key={idx} className={row.isHeader ? 'bg-[#161b22]/50 font-semibold text-white' : 'hover:bg-[#161b22] text-[#c9d1d9]'}>
                        <td className={`py-2 px-3 ${row.indent ? 'pl-6 text-[#8b949e]' : ''}`}>
                          {row.name}
                        </td>
                        {financials.years.map(y => {
                          const val = row.history[y];
                          return (
                            <td key={y} className="py-2 px-3 text-right font-mono">
                              {val !== undefined && val !== null ? val.toLocaleString(undefined, { minimumFractionDigits: 2 }) : '--'}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 3. 估值模型与盈利能力指标 */}
          {activeSubTab === 'valuation' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="terminal-panel p-3 space-y-3">
                <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 flex items-center justify-between">
                  <span>估值与市场定价指标</span>
                  <span className="text-[10px] text-[#8b949e] font-normal">多维度乘数矩阵</span>
                </div>
                <div className="space-y-2 text-xs font-mono">
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">市盈率 (PE-TTM)</span>
                    <span className="text-white font-bold">{stock.valuation.peTTM} 倍</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">动态市盈率 (PE-Forward)</span>
                    <span className="text-white font-bold">{stock.valuation.peDynamic} 倍</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">市净率 (PB)</span>
                    <span className="text-white font-bold">{stock.valuation.pb} 倍</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">市销率 (PS)</span>
                    <span className="text-white font-bold">{stock.valuation.ps} 倍</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">EV / EBITDA</span>
                    <span className="text-white font-bold">{stock.valuation.evEbitda} 倍</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">PEG 估值成长比</span>
                    <span className="text-white font-bold">{stock.valuation.peg}</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">自由现金流收益率 (FCF Yield)</span>
                    <span className="text-[#3fb950] font-bold">{stock.valuation.fcfYield}%</span>
                  </div>
                </div>
              </div>

              <div className="terminal-panel p-3 space-y-3">
                <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2 flex items-center justify-between">
                  <span>盈利能力与杜邦拆解</span>
                  <span className="text-[10px] text-[#8b949e] font-normal">资产质量与回报率</span>
                </div>
                <div className="space-y-2 text-xs font-mono">
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">净资产收益率 (ROE)</span>
                    <span className="text-[#58a6ff] font-bold">{stock.profitability.roe}%</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">总资产报酬率 (ROA)</span>
                    <span className="text-white font-bold">{stock.profitability.roa}%</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">投入资本回报率 (ROIC)</span>
                    <span className="text-white font-bold">{stock.profitability.roic}%</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">销售毛利率 (Gross Margin)</span>
                    <span className="text-white font-bold">{stock.profitability.grossMargin}%</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">销售净利率 (Net Margin)</span>
                    <span className="text-white font-bold">{stock.profitability.netMargin}%</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">资产负债率</span>
                    <span className="text-white font-bold">{stock.profitability.debtToAssetRatio}%</span>
                  </div>
                  <div className="flex justify-between p-1.5 bg-[#161b22] rounded">
                    <span className="text-[#8b949e]">流动比率 / 速动比率</span>
                    <span className="text-white font-bold">{stock.profitability.currentRatio} / {stock.profitability.quickRatio}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4. 公司资料与主营业务拆分 */}
          {activeSubTab === 'profile' && (
            <div className="terminal-panel p-3 space-y-4">
              <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2">
                公司概况与管理层
              </div>
              <p className="text-xs text-[#c9d1d9] leading-relaxed">
                {stock.profile.description}
              </p>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
                <div className="p-2 bg-[#161b22] rounded">
                  <div className="text-[10px] text-[#8b949e]">董事长 / 法定代表人</div>
                  <div className="font-bold text-white mt-0.5">{stock.profile.chairman}</div>
                </div>
                <div className="p-2 bg-[#161b22] rounded">
                  <div className="text-[10px] text-[#8b949e]">上市日期</div>
                  <div className="font-bold text-white mt-0.5">{stock.profile.ipoDate}</div>
                </div>
                <div className="p-2 bg-[#161b22] rounded">
                  <div className="text-[10px] text-[#8b949e]">总部地点</div>
                  <div className="font-bold text-white mt-0.5">{stock.profile.headquarters}</div>
                </div>
                <div className="p-2 bg-[#161b22] rounded">
                  <div className="text-[10px] text-[#8b949e]">审计机构</div>
                  <div className="font-bold text-white mt-0.5">{stock.profile.auditor}</div>
                </div>
              </div>

              {/* 主营业务构成 */}
              <div>
                <div className="text-xs font-bold text-white mb-2 flex items-center gap-1.5">
                  <PieIcon size={14} className="text-[#58a6ff]" />
                  主营业务收入构成 (按产品板块)
                </div>
                <div className="space-y-2">
                  {stock.profile.businessSegments.map(seg => (
                    <div key={seg.name} className="p-2 bg-[#161b22] rounded border border-[#21262d]">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-white font-medium">{seg.name}</span>
                        <span className="text-[#58a6ff] font-mono">{seg.revenue} 亿元 ({seg.sharePct}%)</span>
                      </div>
                      <div className="w-full h-1.5 bg-[#21262d] rounded overflow-hidden">
                        <div style={{ width: `${seg.sharePct}%` }} className="bg-[#1f6feb] h-full" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 右侧深度行情盘口与资金流向 (3列) */}
        <div className="lg:col-span-3 space-y-3">
          {/* Level 2 五档/十档深度委托盘 */}
          <div className="terminal-panel p-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#21262d] mb-2 text-xs">
              <span className="font-bold text-white">五档委托行情 (L2深度)</span>
              <span className="text-[10px] font-mono text-[#3fb950]">盘口直连</span>
            </div>

            {/* 卖五至卖一 (倒序展示) */}
            <div className="space-y-1 text-xs font-mono">
              {[...stock.orderBook.asks].reverse().map(ask => (
                <div key={`ask-${ask.level}`} className="flex items-center justify-between text-[11px] py-0.5 hover:bg-[#161b22] px-1 rounded">
                  <span className="text-[#8b949e]">卖{ask.level}</span>
                  <span className="text-stock-up font-semibold">{ask.price.toFixed(2)}</span>
                  <span className="text-[#c9d1d9]">{ask.volume}</span>
                </div>
              ))}
            </div>

            <div className="my-2 border-t border-[#30363d]" />

            {/* 买一至买五 */}
            <div className="space-y-1 text-xs font-mono">
              {stock.orderBook.bids.map(bid => (
                <div key={`bid-${bid.level}`} className="flex items-center justify-between text-[11px] py-0.5 hover:bg-[#161b22] px-1 rounded">
                  <span className="text-[#8b949e]">买{bid.level}</span>
                  <span className="text-stock-down font-semibold">{bid.price.toFixed(2)}</span>
                  <span className="text-[#c9d1d9]">{bid.volume}</span>
                </div>
              ))}
            </div>

            {/* 内外盘分布 */}
            <div className="mt-3 pt-2 border-t border-[#21262d] text-xs font-mono space-y-1.5">
              <div className="flex justify-between text-[11px]">
                <span className="text-stock-up font-semibold">外盘 (主动买): {(stock.orderBook.outerVolume / 10000).toFixed(1)}万</span>
                <span className="text-stock-down font-semibold">内盘 (主动卖): {(stock.orderBook.innerVolume / 10000).toFixed(1)}万</span>
              </div>
              <div className="w-full h-1.5 bg-[#161b22] rounded overflow-hidden flex">
                <div
                  style={{ width: `${(stock.orderBook.outerVolume / (stock.orderBook.outerVolume + stock.orderBook.innerVolume)) * 100}%` }}
                  className="bg-[#f85149]"
                />
                <div
                  style={{ width: `${(stock.orderBook.innerVolume / (stock.orderBook.outerVolume + stock.orderBook.innerVolume)) * 100}%` }}
                  className="bg-[#3fb950]"
                />
              </div>
            </div>

            {/* 大单/主力资金流向 */}
            <div className="mt-3 pt-2 border-t border-[#21262d] text-xs font-mono space-y-1">
              <div className="text-[11px] text-[#8b949e]">今日主力资金流向 (万元)</div>
              <div className="flex justify-between text-[11px]">
                <span className="text-[#8b949e]">超大单净流入:</span>
                <span className={stock.orderBook.largeInflow >= 0 ? 'text-stock-up font-bold' : 'text-stock-down font-bold'}>
                  {stock.orderBook.largeInflow > 0 ? '+' : ''}{stock.orderBook.largeInflow.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-[#8b949e]">中单净流入:</span>
                <span className={stock.orderBook.midInflow >= 0 ? 'text-stock-up' : 'text-stock-down'}>
                  {stock.orderBook.midInflow > 0 ? '+' : ''}{stock.orderBook.midInflow.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between text-[11px]">
                <span className="text-[#8b949e]">散户单净流入:</span>
                <span className={stock.orderBook.retailInflow >= 0 ? 'text-stock-up' : 'text-stock-down'}>
                  {stock.orderBook.retailInflow > 0 ? '+' : ''}{stock.orderBook.retailInflow.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
