/**
 * 华市金融终端 - 市场宽度与情绪多维分析 (Section 15)
 */

import React from 'react';
import { Compass, TrendingUp, BarChart2, CheckCircle } from 'lucide-react';
import { MOCK_MARKET_BREADTH } from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface MarketBreadthViewProps {
  onSelectTab: (tab: TerminalTab) => void;
}

export const MarketBreadthView: React.FC<MarketBreadthViewProps> = ({ onSelectTab }) => {
  const totalStocks = MOCK_MARKET_BREADTH.upCount + MOCK_MARKET_BREADTH.downCount + MOCK_MARKET_BREADTH.flatCount;

  return (
    <div id="market-breadth-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Compass size={18} className="text-[#e3b341]" />
          <h1 className="text-sm font-bold text-white tracking-wide">市场广度指标与投资者情绪温度计</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
            全市场 {totalStocks} 支A股标的广度全景
          </span>
        </div>
      </div>

      {/* 情绪温度计与涨跌大盘统计 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 市场情绪综合评分 (5列) */}
        <div className="lg:col-span-5 terminal-panel p-4 flex flex-col justify-between items-center text-center">
          <div className="w-full text-xs font-bold text-white border-b border-[#21262d] pb-2 text-left">
            华市多因子市场情绪指数
          </div>

          <div className="my-4">
            <div className="text-5xl font-mono font-bold text-[#e3b341]">
              {MOCK_MARKET_BREADTH.sentimentScore}
            </div>
            <div className="text-xs font-semibold text-white mt-1">情绪状态：积极偏多 (Greed)</div>
            <div className="text-[10px] text-[#8b949e] mt-1">基于涨停跌停比、均线广度、放量动能综合计算</div>
          </div>

          <div className="w-full bg-[#161b22] p-2.5 rounded border border-[#21262d] text-left text-xs font-mono">
            <div className="flex justify-between mb-1">
              <span className="text-[#8b949e]">成交量相对放大系数:</span>
              <span className="text-stock-up font-bold">{MOCK_MARKET_BREADTH.volumeExpansionRatio}x</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#8b949e]">两市总成交额:</span>
              <span className="text-white font-bold">{MOCK_MARKET_BREADTH.totalTurnover} 亿元</span>
            </div>
          </div>
        </div>

        {/* 均线宽度与52周新高 (7列) */}
        <div className="lg:col-span-7 terminal-panel p-4 space-y-4">
          <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2">
            关键均线以上个股占比 (Moving Average Breadth)
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-[#c9d1d9]">站上 20日 均线个股数</span>
                <span className="text-[#58a6ff] font-bold">
                  {MOCK_MARKET_BREADTH.aboveMA20Count} 支 ({(MOCK_MARKET_BREADTH.aboveMA20Count / totalStocks * 100).toFixed(1)}%)
                </span>
              </div>
              <div className="w-full h-2 bg-[#161b22] rounded overflow-hidden">
                <div style={{ width: `${(MOCK_MARKET_BREADTH.aboveMA20Count / totalStocks) * 100}%` }} className="bg-[#1f6feb] h-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-[#c9d1d9]">站上 50日 均线个股数</span>
                <span className="text-[#3fb950] font-bold">
                  {MOCK_MARKET_BREADTH.aboveMA50Count} 支 ({(MOCK_MARKET_BREADTH.aboveMA50Count / totalStocks * 100).toFixed(1)}%)
                </span>
              </div>
              <div className="w-full h-2 bg-[#161b22] rounded overflow-hidden">
                <div style={{ width: `${(MOCK_MARKET_BREADTH.aboveMA50Count / totalStocks) * 100}%` }} className="bg-[#238636] h-full" />
              </div>
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-[#c9d1d9]">站上 200日 牛熊分界线个股数</span>
                <span className="text-[#e3b341] font-bold">
                  {MOCK_MARKET_BREADTH.aboveMA200Count} 支 ({(MOCK_MARKET_BREADTH.aboveMA200Count / totalStocks * 100).toFixed(1)}%)
                </span>
              </div>
              <div className="w-full h-2 bg-[#161b22] rounded overflow-hidden">
                <div style={{ width: `${(MOCK_MARKET_BREADTH.aboveMA200Count / totalStocks) * 100}%` }} className="bg-[#d29922] h-full" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2 font-mono">
            <div className="p-2.5 bg-[#161b22] rounded border border-[#21262d] text-center">
              <div className="text-[10px] text-[#8b949e]">创52周新高个股数</div>
              <div className="text-xl font-bold text-stock-up mt-0.5">+{MOCK_MARKET_BREADTH.newHigh52wCount} 支</div>
            </div>
            <div className="p-2.5 bg-[#161b22] rounded border border-[#21262d] text-center">
              <div className="text-[10px] text-[#8b949e]">创52周新低个股数</div>
              <div className="text-xl font-bold text-stock-down mt-0.5">-{MOCK_MARKET_BREADTH.newLow52wCount} 支</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
