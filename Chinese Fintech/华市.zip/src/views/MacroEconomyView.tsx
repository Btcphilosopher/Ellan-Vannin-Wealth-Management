/**
 * 华市金融终端 - 宏观经济指标中心 (Section 16)
 */

import React, { useState } from 'react';
import { Coins, TrendingUp, Calendar, Info } from 'lucide-react';
import { MOCK_MACRO_INDICATORS } from '../services/mockDataEngine';
import { MacroIndicator, TerminalTab } from '../types';

interface MacroEconomyViewProps {
  onSelectTab: (tab: TerminalTab) => void;
}

export const MacroEconomyView: React.FC<MacroEconomyViewProps> = ({ onSelectTab }) => {
  const [selectedMacro, setSelectedMacro] = useState<MacroIndicator>(MOCK_MACRO_INDICATORS[0]);
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  const categories = ['ALL', '增长', '通胀', '金融货币'];

  const filteredIndicators = MOCK_MACRO_INDICATORS.filter(
    m => categoryFilter === 'ALL' || m.category === categoryFilter
  );

  return (
    <div id="macro-economy-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Coins size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">宏观经济核心时序指标库</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
            国家统计局 · 中国人民银行 · 权威发布
          </span>
        </div>

        {/* 分类筛选 */}
        <div className="flex items-center gap-1 text-xs">
          {categories.map(c => (
            <button
              key={c}
              onClick={() => setCategoryFilter(c)}
              className={`px-2.5 py-1 rounded font-mono transition-colors ${
                categoryFilter === c
                  ? 'bg-[#1f6feb] text-white font-semibold'
                  : 'text-[#8b949e] hover:bg-[#161b22] hover:text-white'
              }`}
            >
              {c === 'ALL' ? '全部宏观' : c}
            </button>
          ))}
        </div>
      </div>

      {/* 宏观指标卡片矩阵 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {filteredIndicators.map(macro => {
          const isSelected = selectedMacro.id === macro.id;
          return (
            <div
              key={macro.id}
              onClick={() => setSelectedMacro(macro)}
              className={`p-3 rounded border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-[#161b22] border-[#58a6ff] ring-1 ring-[#58a6ff]'
                  : 'bg-[#0d1117] border-[#21262d] hover:border-[#30363d]'
              }`}
            >
              <div className="text-[10px] text-[#8b949e] flex justify-between">
                <span>{macro.category} · {macro.frequency}</span>
                <span className="text-[#58a6ff]">{macro.publishDate}</span>
              </div>
              <div className="text-xs font-bold text-white mt-1 line-clamp-1">{macro.name}</div>
              <div className="font-mono text-2xl font-bold my-2 text-white">{macro.latestValue}</div>
              <div className="text-[10px] text-[#8b949e] flex justify-between font-mono">
                <span>前值: {macro.previousValue}</span>
                <span className="text-[#e3b341]">预测: {macro.forecastValue}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 选中宏观指标的历史时序趋势图与详细拆解 */}
      <div className="terminal-panel p-4 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#21262d]">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              {selectedMacro.name} 时序演化与机构预测
            </h2>
            <p className="text-xs text-[#8b949e] mt-1">{selectedMacro.description} (数据发布源: {selectedMacro.source})</p>
          </div>
          <div className="text-right font-mono">
            <div className="text-lg font-bold text-[#58a6ff]">{selectedMacro.latestValue}</div>
            <div className="text-[10px] text-[#8b949e]">最新报告期: {selectedMacro.publishDate}</div>
          </div>
        </div>

        {/* 历史时序数据柱状/折线矩阵 */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {selectedMacro.history.map(item => (
            <div key={item.date} className="p-3 bg-[#161b22] rounded border border-[#21262d] text-center font-mono">
              <div className="text-[11px] text-[#8b949e] mb-1">{item.date}</div>
              <div className="text-base font-bold text-white">{item.value} {selectedMacro.unit}</div>
              {item.forecast && (
                <div className="text-[10px] text-[#e3b341] mt-1">预测: {item.forecast}</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
