/**
 * 华市金融终端 - 行业与板块深度终端 (Section 13)
 */

import React, { useState } from 'react';
import { Grid, ArrowUpRight, TrendingUp, Layers } from 'lucide-react';
import { INDUSTRY_SECTORS, STOCKS_DATABASE } from '../services/mockDataEngine';
import { IndustrySector, TerminalTab } from '../types';

interface IndustryTerminalViewProps {
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const IndustryTerminalView: React.FC<IndustryTerminalViewProps> = ({
  onSelectStock,
  onSelectTab
}) => {
  const [selectedSector, setSelectedSector] = useState<IndustrySector>(INDUSTRY_SECTORS[0]);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');

  const categories = ['ALL', '科技', '消费', '金融', '制造', '医药', '基础设施'];

  const filteredSectors = INDUSTRY_SECTORS.filter(
    s => filterCategory === 'ALL' || s.category === filterCategory
  );

  return (
    <div id="industry-terminal-view" className="flex-1 p-4 overflow-y-auto terminal-scrollbar space-y-4">
      {/* 顶部筛选与标题 */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1117] p-3 rounded border border-[#21262d]">
        <div className="flex items-center gap-2">
          <Grid size={18} className="text-[#58a6ff]" />
          <h1 className="text-sm font-bold text-white tracking-wide">中信一级行业与概念板块终端</h1>
          <span className="text-[10px] bg-[#161b22] px-2 py-0.5 rounded border border-[#30363d] text-[#8b949e]">
            8大产业大类 · 实时估值与资金穿透
          </span>
        </div>

        {/* 类别筛选 */}
        <div className="flex items-center gap-1 text-xs">
          {categories.map(c => (
            <button
              key={c}
              onClick={() => setFilterCategory(c)}
              className={`px-2.5 py-1 rounded font-mono transition-colors ${
                filterCategory === c
                  ? 'bg-[#1f6feb] text-white font-semibold'
                  : 'text-[#8b949e] hover:bg-[#161b22] hover:text-white'
              }`}
            >
              {c === 'ALL' ? '全部行业' : c}
            </button>
          ))}
        </div>
      </div>

      {/* 行业卡片网格 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {filteredSectors.map(sec => {
          const isUp = sec.changePct >= 0;
          const isSelected = selectedSector.code === sec.code;
          return (
            <div
              key={sec.code}
              onClick={() => setSelectedSector(sec)}
              className={`p-3 rounded border cursor-pointer transition-all ${
                isSelected
                  ? 'bg-[#161b22] border-[#58a6ff] ring-1 ring-[#58a6ff]'
                  : 'bg-[#0d1117] border-[#21262d] hover:border-[#30363d]'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-white">{sec.name}</span>
                <span className={`text-[10px] px-1 rounded ${isUp ? 'bg-red-950/60 text-stock-up' : 'bg-green-950/60 text-stock-down'}`}>
                  {sec.category}
                </span>
              </div>
              <div className={`font-mono text-xl font-bold my-1 ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                {isUp ? '+' : ''}{sec.changePct.toFixed(2)}%
              </div>
              <div className="text-[11px] text-[#8b949e] flex justify-between font-mono mt-2">
                <span>成交: <strong className="text-white">{sec.turnover}亿</strong></span>
                <span>市盈率: <strong className="text-white">{sec.pe}</strong></span>
                <span>ROE: <strong className="text-[#58a6ff]">{sec.roe}%</strong></span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 选中板块的深度穿透面板 */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* 板块成分股与领涨领跌 (8列) */}
        <div className="lg:col-span-8 terminal-panel p-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#21262d] mb-3">
            <div className="flex items-center gap-2">
              <Layers size={16} className="text-[#58a6ff]" />
              <span className="text-xs font-bold text-white">
                【{selectedSector.name}】行业成分股与主力动向
              </span>
            </div>
            <span className="text-xs font-mono text-[#8b949e]">
              成分股总数: {selectedSector.stockCount} 家 (上涨 {selectedSector.upCount} / 下跌 {selectedSector.downCount})
            </span>
          </div>

          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#161b22] text-[#8b949e] border-b border-[#21262d]">
              <tr>
                <th className="py-2 px-3">代码 / 名称</th>
                <th className="py-2 px-3 text-right">最新价</th>
                <th className="py-2 px-3 text-right">涨跌幅</th>
                <th className="py-2 px-3 text-right">PE (TTM)</th>
                <th className="py-2 px-3 text-right">市值 (亿)</th>
                <th className="py-2 px-3 text-center">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#21262d]">
              {STOCKS_DATABASE.map(stock => {
                const isUp = stock.changePct >= 0;
                return (
                  <tr
                    key={stock.code}
                    onClick={() => onSelectStock(stock.code)}
                    className="hover:bg-[#161b22] cursor-pointer"
                  >
                    <td className="py-2 px-3">
                      <span className="font-bold text-white mr-2">{stock.name}</span>
                      <span className="text-[#58a6ff]">{stock.code}</span>
                    </td>
                    <td className={`py-2 px-3 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {stock.price.toFixed(2)}
                    </td>
                    <td className={`py-2 px-3 text-right font-bold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                      {isUp ? '+' : ''}{stock.changePct.toFixed(2)}%
                    </td>
                    <td className="py-2 px-3 text-right text-[#c9d1d9]">{stock.valuation.peTTM}</td>
                    <td className="py-2 px-3 text-right text-white font-semibold">{stock.valuation.totalMarketCap.toLocaleString()}</td>
                    <td className="py-2 px-3 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectStock(stock.code);
                        }}
                        className="px-2 py-0.5 rounded bg-[#1f6feb] text-white text-[10px]"
                      >
                        详情
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* 板块统计与领头羊 (4列) */}
        <div className="lg:col-span-4 terminal-panel p-3 space-y-4">
          <div className="text-xs font-bold text-white border-b border-[#21262d] pb-2">
            板块核心特征与估值分位数
          </div>

          <div className="space-y-3 text-xs font-mono">
            <div className="p-2.5 bg-[#161b22] rounded border border-[#21262d]">
              <div className="text-[#8b949e] text-[10px]">今日领涨先锋</div>
              <div className="flex justify-between items-center mt-1">
                <span className="text-white font-bold">{selectedSector.leadingStock.name} ({selectedSector.leadingStock.code})</span>
                <span className="text-stock-up font-bold">+{selectedSector.leadingStock.changePct}%</span>
              </div>
            </div>

            <div className="p-2.5 bg-[#161b22] rounded border border-[#21262d]">
              <div className="text-[#8b949e] text-[10px]">今日领跌标的</div>
              <div className="flex justify-between items-center mt-1">
                <span className="text-white font-bold">{selectedSector.worstStock.name} ({selectedSector.worstStock.code})</span>
                <span className="text-stock-down font-bold">{selectedSector.worstStock.changePct}%</span>
              </div>
            </div>

            <div className="p-2.5 bg-[#161b22] rounded border border-[#21262d]">
              <div className="text-[#8b949e] text-[10px]">主力净流入资金</div>
              <div className="text-base font-bold text-[#58a6ff] mt-0.5">
                +{selectedSector.netCapitalInflow} 亿元
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
