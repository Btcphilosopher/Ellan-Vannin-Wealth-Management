/**
 * 华市金融终端 - 顶部全球大类资产与核心指数动态跑马灯
 */

import React, { useState, useEffect } from 'react';
import { MarketIndex } from '../types';
import { INITIAL_MARKET_INDICES } from '../services/mockDataEngine';

interface TopTickerBarProps {
  onSelectIndex?: (index: MarketIndex) => void;
}

export const TopTickerBar: React.FC<TopTickerBarProps> = ({ onSelectIndex }) => {
  const [indices, setIndices] = useState<MarketIndex[]>(INITIAL_MARKET_INDICES);
  const [activeTickCode, setActiveTickCode] = useState<string | null>(null);

  // 模拟行情高频微幅跳动效果
  useEffect(() => {
    const interval = setInterval(() => {
      setIndices(prev => {
        const randomIndex = Math.floor(Math.random() * prev.length);
        const item = prev[randomIndex];
        // 仅跳动活跃指数
        const delta = (Math.random() - 0.49) * (item.price * 0.0008);
        const newPrice = Number((item.price + delta).toFixed(item.price > 500 ? 2 : 4));
        const newChange = Number((item.change + delta).toFixed(2));
        const newPct = Number((item.changePct + (delta / item.price) * 100).toFixed(2));

        setActiveTickCode(item.code);
        setTimeout(() => setActiveTickCode(null), 800);

        return prev.map((idx, i) => i === randomIndex ? { ...idx, price: newPrice, change: newChange, changePct: newPct } : idx);
      });
    }, 2400);

    return () => clearInterval(interval);
  }, []);

  return (
    <div id="top-ticker-bar" className="w-full bg-[#0d1117] border-b border-[#21262d] px-3 py-1.5 flex items-center overflow-x-auto terminal-scrollbar select-none z-30">
      <div className="flex items-center gap-1 shrink-0 mr-3 text-[11px] font-semibold text-[#8b949e]">
        <span className="w-2 h-2 rounded-full bg-[#238636] animate-pulse"></span>
        <span className="tracking-wider">实时快讯源</span>
        <span className="text-[10px] px-1 py-0.2 bg-[#161b22] rounded border border-[#30363d] text-[#58a6ff]">L2直连</span>
      </div>

      <div className="flex items-center gap-4 text-xs font-mono whitespace-nowrap">
        {indices.map(idx => {
          const isUp = idx.changePct >= 0;
          const isTicking = activeTickCode === idx.code;

          return (
            <div
              key={idx.code}
              id={`ticker-item-${idx.code.replace('.', '-')}`}
              onClick={() => onSelectIndex && onSelectIndex(idx)}
              className={`flex items-center gap-2 px-2 py-0.5 rounded cursor-pointer transition-all hover:bg-[#161b22] ${
                isTicking ? (isUp ? 'flash-tick-up' : 'flash-tick-down') : ''
              }`}
            >
              <span className="text-[#c9d1d9] font-medium text-[11px]">{idx.name}</span>
              <span className={`font-semibold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                {idx.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}
              </span>
              <span className={`text-[11px] font-mono ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                {isUp ? '+' : ''}{idx.changePct.toFixed(2)}%
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
