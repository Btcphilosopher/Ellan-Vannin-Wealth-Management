/**
 * 华市金融终端 - 侧边专业功能导航面板
 */

import React from 'react';
import {
  TrendingUp,
  LineChart,
  Grid,
  Filter,
  Layers,
  ArrowLeftRight,
  PieChart,
  Landmark,
  Coins,
  DollarSign,
  Compass,
  Cpu,
  Bookmark,
  Briefcase,
  FileText,
  Bot,
  Calculator,
  Layout,
  Database,
  Shield
} from 'lucide-react';
import { TerminalTab } from '../types';

interface SidebarNavProps {
  activeTab: TerminalTab;
  onSelectTab: (tab: TerminalTab) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

interface NavItem {
  id: TerminalTab;
  label: string;
  icon: React.ReactNode;
  shortcut?: string;
  badge?: string;
}

interface NavGroup {
  groupName: string;
  items: NavItem[];
}

export const SidebarNav: React.FC<SidebarNavProps> = ({
  activeTab,
  onSelectTab,
  collapsed,
  onToggleCollapse
}) => {
  const groups: NavGroup[] = [
    {
      groupName: '核心行情',
      items: [
        { id: 'market', label: '市场总览', icon: <TrendingUp size={15} />, shortcut: 'F1' },
        { id: 'stock_detail', label: '个股深度行情', icon: <LineChart size={15} />, shortcut: 'F2' },
        { id: 'industry', label: '行业与板块', icon: <Grid size={15} />, shortcut: 'F3' },
        { id: 'watchlist', label: '自选股监控', icon: <Bookmark size={15} />, shortcut: 'F4' }
      ]
    },
    {
      groupName: '数据分析与筛选',
      items: [
        { id: 'screener', label: '多维股票筛选', icon: <Filter size={15} /> },
        { id: 'comparison', label: '公司多维对比', icon: <ArrowLeftRight size={15} /> },
        { id: 'capital_flow', label: '主力与北向资金', icon: <Layers size={15} /> },
        { id: 'market_breadth', label: '市场宽度与情绪', icon: <Compass size={15} /> }
      ]
    },
    {
      groupName: '多资产与宏观',
      items: [
        { id: 'fund_etf', label: 'ETF与基金中心', icon: <PieChart size={15} /> },
        { id: 'bond', label: '债券与收益率曲线', icon: <Landmark size={15} /> },
        { id: 'macro', label: '宏观经济指标', icon: <Coins size={15} /> },
        { id: 'fx_commodity', label: '外汇与大宗商品', icon: <DollarSign size={15} /> }
      ]
    },
    {
      groupName: '量化与投研',
      items: [
        { id: 'ai_assistant', label: 'AI智能投研助理', icon: <Bot size={15} />, badge: 'Gemini' },
        { id: 'quant', label: '因子回测引擎', icon: <Cpu size={15} /> },
        { id: 'portfolio', label: '模拟组合管理', icon: <Briefcase size={15} /> },
        { id: 'news_filing', label: '资讯与公告披露', icon: <FileText size={15} /> },
        { id: 'calculator', label: '金融分析计算器', icon: <Calculator size={15} /> }
      ]
    },
    {
      groupName: '系统与工作台',
      items: [
        { id: 'custom_workspace', label: '多窗口工作台', icon: <Layout size={15} /> },
        { id: 'data_quality', label: '数据源节点监控', icon: <Database size={15} /> },
        { id: 'audit_rbac', label: '合规与审计日志', icon: <Shield size={15} /> }
      ]
    }
  ];

  return (
    <aside
      id="terminal-sidebar-nav"
      className={`bg-[#0d1117] border-r border-[#21262d] flex flex-col justify-between transition-all duration-200 shrink-0 ${
        collapsed ? 'w-14' : 'w-56'
      }`}
    >
      <div className="flex-1 overflow-y-auto terminal-scrollbar py-2">
        {groups.map((group, gIdx) => (
          <div key={group.groupName} className="mb-3">
            {!collapsed && (
              <div className="px-3 py-1 text-[10px] font-semibold tracking-wider text-[#8b949e] uppercase">
                {group.groupName}
              </div>
            )}
            <div className="space-y-0.5 px-1.5">
              {group.items.map(item => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`sidebar-tab-${item.id}`}
                    onClick={() => onSelectTab(item.id)}
                    title={collapsed ? `${item.label} (${item.shortcut || ''})` : undefined}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs transition-colors text-left ${
                      isActive
                        ? 'bg-[#1f6feb] text-white font-medium shadow-sm'
                        : 'text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <span className={isActive ? 'text-white' : 'text-[#8b949e]'}>{item.icon}</span>
                      {!collapsed && <span className="truncate">{item.label}</span>}
                    </div>

                    {!collapsed && (
                      <div className="flex items-center gap-1">
                        {item.badge && (
                          <span className="text-[9px] px-1 py-0.2 rounded bg-[#238636] text-white font-mono">
                            {item.badge}
                          </span>
                        )}
                        {item.shortcut && (
                          <span className="text-[10px] font-mono text-[#484f58] bg-[#161b22] px-1 rounded border border-[#21262d]">
                            {item.shortcut}
                          </span>
                        )}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
            {gIdx < groups.length - 1 && <div className="my-2 border-b border-[#21262d] mx-2" />}
          </div>
        ))}
      </div>

      {/* 底部折叠切换按钮 */}
      <div className="p-2 border-t border-[#21262d] flex items-center justify-between">
        <button
          onClick={onToggleCollapse}
          className="w-full py-1 text-center text-[11px] text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22] rounded transition-colors"
        >
          {collapsed ? '▶' : '◀ 收起侧栏'}
        </button>
      </div>
    </aside>
  );
};
