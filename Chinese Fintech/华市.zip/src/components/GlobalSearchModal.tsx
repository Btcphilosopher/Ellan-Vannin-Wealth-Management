/**
 * 华市金融终端 - 全局指令与标的快速搜索框 (Ctrl+K 触发)
 */

import React, { useState, useEffect, useRef } from 'react';
import { Search, X, TrendingUp, ArrowRight, CornerDownLeft } from 'lucide-react';
import { STOCKS_DATABASE, INDUSTRY_SECTORS, MOCK_MACRO_INDICATORS } from '../services/mockDataEngine';
import { TerminalTab } from '../types';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectStock: (code: string) => void;
  onSelectTab: (tab: TerminalTab) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectStock,
  onSelectTab
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const normalized = query.trim().toLowerCase();

  // 匹配股票
  const matchedStocks = STOCKS_DATABASE.filter(s =>
    s.code.toLowerCase().includes(normalized) ||
    s.name.toLowerCase().includes(normalized) ||
    s.industry.toLowerCase().includes(normalized)
  ).slice(0, 6);

  // 匹配板块
  const matchedSectors = INDUSTRY_SECTORS.filter(sec =>
    sec.name.toLowerCase().includes(normalized) ||
    sec.code.toLowerCase().includes(normalized)
  ).slice(0, 4);

  // 匹配宏观
  const matchedMacros = MOCK_MACRO_INDICATORS.filter(m =>
    m.name.toLowerCase().includes(normalized) ||
    m.id.toLowerCase().includes(normalized)
  ).slice(0, 3);

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-start justify-center pt-20 z-50 p-4">
      <div
        id="global-search-dialog"
        className="w-full max-w-2xl bg-[#0d1117] border border-[#30363d] rounded-lg shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150"
      >
        {/* 输入框 */}
        <div className="flex items-center px-4 py-3 border-b border-[#21262d] bg-[#161b22]">
          <Search size={18} className="text-[#58a6ff] mr-3 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            placeholder="搜索股票代码、名称、行业板块、宏观指标或终端指令..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Escape') onClose();
              if (e.key === 'Enter' && matchedStocks.length > 0) {
                onSelectStock(matchedStocks[0].code);
                onClose();
              }
            }}
            className="w-full bg-transparent text-sm text-white placeholder-[#8b949e] focus:outline-none font-mono"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-[#8b949e] hover:text-white p-1">
              <X size={16} />
            </button>
          )}
          <span className="text-[10px] bg-[#21262d] text-[#8b949e] px-1.5 py-0.5 rounded ml-2 font-mono">ESC 退出</span>
        </div>

        {/* 结果区域 */}
        <div className="max-h-[380px] overflow-y-auto terminal-scrollbar p-3 space-y-4">
          {/* 股票标的 */}
          {matchedStocks.length > 0 && (
            <div>
              <div className="text-[10px] font-semibold text-[#8b949e] uppercase px-2 mb-1.5">股票与核心资产</div>
              <div className="space-y-1">
                {matchedStocks.map(stock => {
                  const isUp = stock.changePct >= 0;
                  return (
                    <div
                      key={stock.code}
                      onClick={() => {
                        onSelectStock(stock.code);
                        onClose();
                      }}
                      className="flex items-center justify-between px-3 py-2 rounded hover:bg-[#161b22] cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <span className="font-mono text-xs font-bold text-[#58a6ff] bg-[#161b22] px-1.5 py-0.5 rounded border border-[#21262d]">
                          {stock.code}
                        </span>
                        <div>
                          <div className="text-sm font-semibold text-white group-hover:text-[#58a6ff]">{stock.name}</div>
                          <div className="text-[11px] text-[#8b949e]">{stock.exchange} · {stock.industry}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`font-mono text-sm font-semibold ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                          ¥{stock.price.toFixed(2)}
                        </div>
                        <div className={`font-mono text-xs ${isUp ? 'text-stock-up' : 'text-stock-down'}`}>
                          {isUp ? '+' : ''}{stock.changePct.toFixed(2)}%
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 行业板块 */}
          {matchedSectors.length > 0 && (
            <div>
              <div className="text-[10px] font-semibold text-[#8b949e] uppercase px-2 mb-1.5">行业与板块</div>
              <div className="grid grid-cols-2 gap-2">
                {matchedSectors.map(sec => (
                  <div
                    key={sec.code}
                    onClick={() => {
                      onSelectTab('industry');
                      onClose();
                    }}
                    className="flex items-center justify-between p-2.5 rounded bg-[#161b22] hover:bg-[#1f242c] cursor-pointer border border-[#21262d]"
                  >
                    <div>
                      <div className="text-xs font-semibold text-white">{sec.name}</div>
                      <div className="text-[10px] text-[#8b949e]">成分股: {sec.stockCount}家</div>
                    </div>
                    <div className={`font-mono text-xs font-bold ${sec.changePct >= 0 ? 'text-stock-up' : 'text-stock-down'}`}>
                      {sec.changePct >= 0 ? '+' : ''}{sec.changePct}%
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 宏观指标 */}
          {matchedMacros.length > 0 && (
            <div>
              <div className="text-[10px] font-semibold text-[#8b949e] uppercase px-2 mb-1.5">宏观经济指标</div>
              <div className="space-y-1">
                {matchedMacros.map(m => (
                  <div
                    key={m.id}
                    onClick={() => {
                      onSelectTab('macro');
                      onClose();
                    }}
                    className="flex items-center justify-between px-3 py-2 rounded hover:bg-[#161b22] cursor-pointer text-xs"
                  >
                    <span className="text-white">{m.name}</span>
                    <span className="font-mono text-[#58a6ff]">{m.latestValue}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {matchedStocks.length === 0 && matchedSectors.length === 0 && matchedMacros.length === 0 && (
            <div className="py-8 text-center text-xs text-[#8b949e]">
              未检索到符合条件的标的或功能，请尝试输入代码（如 600519）或行业名称。
            </div>
          )}
        </div>

        {/* 底部快捷操作条 */}
        <div className="px-4 py-2 bg-[#161b22] border-t border-[#21262d] flex items-center justify-between text-[11px] text-[#8b949e] font-mono">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1"><CornerDownLeft size={12} /> 选择确认</span>
            <span>ESC 取消</span>
          </div>
          <span className="text-[#3fb950]">华市毫秒级检索索引就绪</span>
        </div>
      </div>
    </div>
  );
};
