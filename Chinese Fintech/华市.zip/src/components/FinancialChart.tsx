/**
 * 华市金融终端 - 交互式专业级K线与分时图表组件
 * 支持分时/5日/日K/周K/月K、复权切换、主图MA/BOLL指标、副图VOL/MACD/RSI/KDJ指标、事件标记、十字光标
 */

import React, { useState, useMemo, useRef } from 'react';
import { KLineBar, ChartPeriod, AdjustType, TechIndicator } from '../types';

interface FinancialChartProps {
  data: KLineBar[];
  stockName: string;
  stockCode: string;
  currentPrice: number;
}

export const FinancialChart: React.FC<FinancialChartProps> = ({
  data,
  stockName,
  stockCode,
  currentPrice
}) => {
  const [period, setPeriod] = useState<ChartPeriod>('日K');
  const [adjustType, setAdjustType] = useState<AdjustType>('前复权');
  const [mainIndicator, setMainIndicator] = useState<'MA' | 'BOLL' | 'NONE'>('MA');
  const [subIndicator, setSubIndicator] = useState<TechIndicator>('VOL');
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  // 显示的K线切片（最多展示80-120根以便清晰可读）
  const displayBars = useMemo(() => {
    return data.slice(-80);
  }, [data]);

  const activeBar = hoverIndex !== null && displayBars[hoverIndex] ? displayBars[hoverIndex] : displayBars[displayBars.length - 1];

  // 计算价格坐标范围
  const { minPrice, maxPrice, maxVolume } = useMemo(() => {
    if (!displayBars || displayBars.length === 0) return { minPrice: 0, maxPrice: 100, maxVolume: 100 };
    let min = Infinity;
    let max = -Infinity;
    let maxVol = 0;

    displayBars.forEach(b => {
      if (b.low < min) min = b.low;
      if (b.high > max) max = b.high;
      if (mainIndicator === 'BOLL') {
        if (b.bollLower && b.bollLower < min) min = b.bollLower;
        if (b.bollUpper && b.bollUpper > max) max = b.bollUpper;
      }
      if (mainIndicator === 'MA') {
        if (b.ma5) { min = Math.min(min, b.ma5); max = Math.max(max, b.ma5); }
        if (b.ma20) { min = Math.min(min, b.ma20); max = Math.max(max, b.ma20); }
      }
      if (b.volume > maxVol) maxVol = b.volume;
    });

    const pad = (max - min) * 0.05 || 1;
    return {
      minPrice: min - pad,
      maxPrice: max + pad,
      maxVolume: maxVol * 1.15
    };
  }, [displayBars, mainIndicator]);

  // SVG尺寸与比例
  const width = 800;
  const mainHeight = 280;
  const subHeight = 100;
  const totalHeight = 400;
  const margin = { top: 20, right: 60, bottom: 20, left: 10 };

  const plotWidth = width - margin.left - margin.right;
  const barWidth = Math.max(4, plotWidth / (displayBars.length || 1));
  const candleBodyWidth = Math.max(2, barWidth * 0.68);

  const getY = (price: number) => {
    if (maxPrice === minPrice) return mainHeight / 2;
    return margin.top + (1 - (price - minPrice) / (maxPrice - minPrice)) * (mainHeight - margin.top);
  };

  const getSubY = (val: number, minVal: number, maxVal: number) => {
    if (maxVal === minVal) return mainHeight + 20 + subHeight / 2;
    return mainHeight + 25 + (1 - (val - minVal) / (maxVal - minVal)) * (subHeight - 15);
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - margin.left;
    const index = Math.floor(x / barWidth);
    if (index >= 0 && index < displayBars.length) {
      setHoverIndex(index);
    }
  };

  const handleMouseLeave = () => {
    setHoverIndex(null);
  };

  // 生成MA线点集
  const getLinePath = (getter: (b: KLineBar) => number | undefined) => {
    const points: string[] = [];
    displayBars.forEach((b, i) => {
      const val = getter(b);
      if (val !== undefined) {
        const x = margin.left + i * barWidth + barWidth / 2;
        const y = getY(val);
        points.push(`${x},${y}`);
      }
    });
    return points.length > 1 ? `M ${points.join(' L ')}` : '';
  };

  return (
    <div id="financial-chart-container" className="terminal-panel p-3 bg-[#0d1117] border border-[#21262d] rounded flex flex-col gap-2">
      {/* 顶部工具栏: 周期、复权、指标切换 */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-[#21262d] text-xs">
        <div className="flex items-center gap-1">
          <span className="text-[#8b949e] font-mono mr-1">周期:</span>
          {(['分时', '5日', '日K', '周K', '月K'] as ChartPeriod[]).map(p => (
            <button
              key={p}
              id={`chart-period-${p}`}
              onClick={() => setPeriod(p)}
              className={`px-2 py-0.5 rounded text-xs transition-colors font-mono ${
                period === p
                  ? 'bg-[#1f6feb] text-white font-semibold'
                  : 'text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22]'
              }`}
            >
              {p}
            </button>
          ))}
          <div className="h-3 w-[1px] bg-[#30363d] mx-1" />
          {(['前复权', '后复权', '不复权'] as AdjustType[]).map(adj => (
            <button
              key={adj}
              id={`chart-adjust-${adj}`}
              onClick={() => setAdjustType(adj)}
              className={`px-1.5 py-0.5 rounded text-[11px] font-mono ${
                adjustType === adj
                  ? 'text-[#58a6ff] bg-[#161b22] border border-[#30363d]'
                  : 'text-[#8b949e] hover:text-[#c9d1d9]'
              }`}
            >
              {adj}
            </button>
          ))}
        </div>

        {/* 主图与副图指标切换 */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <span className="text-[#8b949e]">主图:</span>
            {(['MA', 'BOLL', 'NONE'] as const).map(m => (
              <button
                key={m}
                onClick={() => setMainIndicator(m)}
                className={`px-1.5 py-0.5 text-[11px] rounded font-mono ${
                  mainIndicator === m ? 'bg-[#238636] text-white' : 'text-[#8b949e] hover:text-white'
                }`}
              >
                {m === 'NONE' ? '无' : m}
              </button>
            ))}
          </div>

          <div className="h-3 w-[1px] bg-[#30363d]" />

          <div className="flex items-center gap-1">
            <span className="text-[#8b949e]">副图:</span>
            {(['VOL', 'MACD', 'RSI', 'KDJ'] as TechIndicator[]).map(sub => (
              <button
                key={sub}
                onClick={() => setSubIndicator(sub)}
                className={`px-1.5 py-0.5 text-[11px] rounded font-mono ${
                  subIndicator === sub ? 'bg-[#8957e5] text-white' : 'text-[#8b949e] hover:text-white'
                }`}
              >
                {sub}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 活跃K线数据指示栏 */}
      {activeBar && (
        <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono py-1 px-2 bg-[#161b22] rounded border border-[#21262d]">
          <span className="text-white font-semibold">{stockName} ({stockCode})</span>
          <span className="text-[#8b949e]">日期: <strong className="text-white">{activeBar.date}</strong></span>
          <span>开: <strong className="text-white">{activeBar.open.toFixed(2)}</strong></span>
          <span>高: <strong className="text-stock-up">{activeBar.high.toFixed(2)}</strong></span>
          <span>低: <strong className="text-stock-down">{activeBar.low.toFixed(2)}</strong></span>
          <span>收: <strong className={activeBar.close >= activeBar.open ? 'text-stock-up' : 'text-stock-down'}>{activeBar.close.toFixed(2)}</strong></span>
          <span>涨跌: <strong className={activeBar.changePct >= 0 ? 'text-stock-up' : 'text-stock-down'}>{activeBar.changePct >= 0 ? '+' : ''}{activeBar.changePct}%</strong></span>
          <span>成交量: <strong className="text-[#e3b341]">{(activeBar.volume / 10000).toFixed(1)}万手</strong></span>
          {mainIndicator === 'MA' && (
            <>
              {activeBar.ma5 && <span className="text-[#e3b341]">MA5: {activeBar.ma5}</span>}
              {activeBar.ma10 && <span className="text-[#58a6ff]">MA10: {activeBar.ma10}</span>}
              {activeBar.ma20 && <span className="text-[#bc8cff]">MA20: {activeBar.ma20}</span>}
            </>
          )}
        </div>
      )}

      {/* SVG K线图表主体 */}
      <div ref={containerRef} className="relative w-full overflow-hidden bg-[#090d13] rounded border border-[#21262d]">
        <svg
          viewBox={`0 0 ${width} ${totalHeight}`}
          className="w-full h-[360px] cursor-crosshair select-none"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          {/* 背景网格 */}
          <line x1={margin.left} y1={margin.top} x2={width - margin.right} y2={margin.top} stroke="#21262d" strokeDasharray="3,3" />
          <line x1={margin.left} y1={mainHeight / 2} x2={width - margin.right} y2={mainHeight / 2} stroke="#21262d" strokeDasharray="3,3" />
          <line x1={margin.left} y1={mainHeight} x2={width - margin.right} y2={mainHeight} stroke="#30363d" />
          <line x1={margin.left} y1={mainHeight + 20} x2={width - margin.right} y2={mainHeight + 20} stroke="#21262d" />
          <line x1={margin.left} y1={totalHeight - margin.bottom} x2={width - margin.right} y2={totalHeight - margin.bottom} stroke="#30363d" />

          {/* 价格坐标轴标签 (右侧) */}
          <text x={width - margin.right + 6} y={margin.top + 8} fill="#8b949e" fontSize="10" fontFamily="monospace">{maxPrice.toFixed(2)}</text>
          <text x={width - margin.right + 6} y={mainHeight / 2 + 3} fill="#8b949e" fontSize="10" fontFamily="monospace">{((maxPrice + minPrice) / 2).toFixed(2)}</text>
          <text x={width - margin.right + 6} y={mainHeight - 4} fill="#8b949e" fontSize="10" fontFamily="monospace">{minPrice.toFixed(2)}</text>

          {/* 主图：MA 均线 */}
          {mainIndicator === 'MA' && (
            <>
              <path d={getLinePath(b => b.ma5)} fill="none" stroke="#e3b341" strokeWidth="1.2" opacity="0.9" />
              <path d={getLinePath(b => b.ma10)} fill="none" stroke="#58a6ff" strokeWidth="1.2" opacity="0.9" />
              <path d={getLinePath(b => b.ma20)} fill="none" stroke="#bc8cff" strokeWidth="1.2" opacity="0.9" />
              <path d={getLinePath(b => b.ma60)} fill="none" stroke="#3fb950" strokeWidth="1.2" opacity="0.9" />
            </>
          )}

          {/* 主图：布林带 BOLL */}
          {mainIndicator === 'BOLL' && (
            <>
              <path d={getLinePath(b => b.bollUpper)} fill="none" stroke="#f85149" strokeWidth="1" strokeDasharray="2,2" />
              <path d={getLinePath(b => b.bollMid)} fill="none" stroke="#58a6ff" strokeWidth="1.2" />
              <path d={getLinePath(b => b.bollLower)} fill="none" stroke="#3fb950" strokeWidth="1" strokeDasharray="2,2" />
            </>
          )}

          {/* K线蜡烛图 */}
          {displayBars.map((bar, i) => {
            const isUp = bar.close >= bar.open;
            const color = isUp ? '#f85149' : '#3fb950'; // 中国市场：红涨绿跌
            const xCenter = margin.left + i * barWidth + barWidth / 2;
            const xLeft = xCenter - candleBodyWidth / 2;

            const yOpen = getY(bar.open);
            const yClose = getY(bar.close);
            const yHigh = getY(bar.high);
            const yLow = getY(bar.low);

            const bodyTop = Math.min(yOpen, yClose);
            const bodyHeight = Math.max(1.5, Math.abs(yOpen - yClose));

            return (
              <g key={bar.date}>
                {/* 上下影线 */}
                <line x1={xCenter} y1={yHigh} x2={xCenter} y2={yLow} stroke={color} strokeWidth="1" />
                {/* 蜡烛实体 */}
                <rect
                  x={xLeft}
                  y={bodyTop}
                  width={candleBodyWidth}
                  height={bodyHeight}
                  fill={isUp ? color : color}
                  stroke={color}
                  strokeWidth="0.5"
                />

                {/* 事件标记 (如分红、财报) */}
                {bar.events && bar.events.length > 0 && (
                  <g transform={`translate(${xCenter}, ${yHigh - 12})`} className="cursor-pointer">
                    <circle r="5" fill="#e3b341" stroke="#ffffff" strokeWidth="1" />
                    <text textAnchor="middle" y="3" fill="#0d1117" fontSize="8" fontWeight="bold">E</text>
                  </g>
                )}
              </g>
            );
          })}

          {/* 副图：成交量 (VOL) */}
          {subIndicator === 'VOL' && (
            <g>
              <text x={margin.left + 5} y={mainHeight + 16} fill="#8b949e" fontSize="10" fontFamily="monospace">VOL (成交量手)</text>
              {displayBars.map((bar, i) => {
                const isUp = bar.close >= bar.open;
                const color = isUp ? '#f85149' : '#3fb950';
                const xCenter = margin.left + i * barWidth + barWidth / 2;
                const xLeft = xCenter - candleBodyWidth / 2;
                const volHeight = maxVolume > 0 ? (bar.volume / maxVolume) * (subHeight - 20) : 0;
                const yTop = totalHeight - margin.bottom - volHeight;

                return (
                  <rect
                    key={`vol-${bar.date}`}
                    x={xLeft}
                    y={yTop}
                    width={candleBodyWidth}
                    height={volHeight}
                    fill={color}
                    opacity="0.85"
                  />
                );
              })}
            </g>
          )}

          {/* 十字光标与辅助线 */}
          {hoverIndex !== null && displayBars[hoverIndex] && (
            <g>
              {/* 垂直线 */}
              <line
                x1={margin.left + hoverIndex * barWidth + barWidth / 2}
                y1={margin.top}
                x2={margin.left + hoverIndex * barWidth + barWidth / 2}
                y2={totalHeight - margin.bottom}
                stroke="#58a6ff"
                strokeWidth="1"
                strokeDasharray="3,3"
              />
              {/* 水平线 */}
              <line
                x1={margin.left}
                y1={getY(displayBars[hoverIndex].close)}
                x2={width - margin.right}
                y2={getY(displayBars[hoverIndex].close)}
                stroke="#58a6ff"
                strokeWidth="1"
                strokeDasharray="3,3"
              />
              {/* 右侧价格指示框 */}
              <rect
                x={width - margin.right}
                y={getY(displayBars[hoverIndex].close) - 9}
                width={55}
                height={18}
                fill="#1f6feb"
                rx="2"
              />
              <text
                x={width - margin.right + 4}
                y={getY(displayBars[hoverIndex].close) + 4}
                fill="#ffffff"
                fontSize="10"
                fontFamily="monospace"
                fontWeight="bold"
              >
                {displayBars[hoverIndex].close.toFixed(2)}
              </text>
            </g>
          )}
        </svg>
      </div>
    </div>
  );
};
