/**
 * 华市金融终端 - 顶部全局导航栏与控制台
 */

import React, { useState, useEffect } from 'react';
import { Search, Command, ShieldCheck, HelpCircle, Activity } from 'lucide-react';
import { CURRENT_USER } from '../services/mockDataEngine';

interface TerminalHeaderProps {
  onOpenSearch: () => void;
  onOpenHelp: () => void;
  onSelectTab: (tab: any) => void;
}

export const TerminalHeader: React.FC<TerminalHeaderProps> = ({
  onOpenSearch,
  onOpenHelp,
  onSelectTab
}) => {
  const [beijingTime, setBeijingTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('zh-CN', { hour12: false });
      const dateStr = now.toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' });
      setBeijingTime(`${dateStr} ${timeStr} (UTC+8)`);
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header id="terminal-header" className="w-full bg-[#090d13] border-b border-[#21262d] px-4 py-2 flex items-center justify-between z-40 select-none">
      {/* 品牌标识与终端定位 */}
      <div className="flex items-center gap-3">
        <div
          onClick={() => onSelectTab('market')}
          className="flex items-center gap-2 cursor-pointer group"
        >
          <div className="w-7 h-7 rounded bg-gradient-to-br from-[#1f6feb] to-[#238636] flex items-center justify-center text-white font-bold text-base shadow">
            华
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-white font-bold tracking-wider text-sm group-hover:text-[#58a6ff] transition-colors">
                华市
              </span>
              <span className="text-[10px] uppercase font-mono px-1 py-0.5 rounded bg-[#161b22] border border-[#30363d] text-[#8b949e]">
                HUASHI TERMINAL v3.7
              </span>
            </div>
            <div className="text-[10px] text-[#8b949e] font-sans">中国金融市场专业数据终端</div>
          </div>
        </div>

        {/* 市场状态指示器 */}
        <div className="hidden lg:flex items-center gap-2 ml-4 pl-4 border-l border-[#21262d] text-xs">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#161b22] border border-[#30363d]">
            <span className="w-2 h-2 rounded-full bg-[#3fb950]" />
            <span className="text-[#c9d1d9] text-[11px]">A股: 已收盘</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#161b22] border border-[#30363d]">
            <span className="w-2 h-2 rounded-full bg-[#58a6ff] animate-pulse" />
            <span className="text-[#c9d1d9] text-[11px]">银行间/外汇: 交易中</span>
          </div>
        </div>
      </div>

      {/* 中部快速指令搜索框 */}
      <div className="flex-1 max-w-md mx-4">
        <button
          id="global-search-trigger"
          onClick={onOpenSearch}
          className="w-full bg-[#161b22] hover:bg-[#1c2128] border border-[#30363d] hover:border-[#58a6ff] rounded px-3 py-1.5 text-xs text-[#8b949e] flex items-center justify-between transition-all"
        >
          <div className="flex items-center gap-2">
            <Search size={14} className="text-[#8b949e]" />
            <span>输入代码、简拼、公司名或指令 (如 600519、茅台、HQ)...</span>
          </div>
          <div className="flex items-center gap-1 text-[10px] font-mono bg-[#0d1117] px-1.5 py-0.5 rounded border border-[#21262d] text-[#8b949e]">
            <Command size={10} />
            <span>K</span>
          </div>
        </button>
      </div>

      {/* 右侧工具栏、用户角色与系统状态 */}
      <div className="flex items-center gap-3">
        {/* 数据源声明 Badge */}
        <div className="hidden sm:flex items-center gap-1.5 px-2 py-1 rounded bg-[#21262d] text-[10px] text-[#e3b341]">
          <Activity size={12} />
          <span>本地模拟推演 (演示数据)</span>
        </div>

        {/* 快捷键帮助 */}
        <button
          id="shortcuts-help-btn"
          onClick={onOpenHelp}
          className="p-1.5 text-[#8b949e] hover:text-[#c9d1d9] hover:bg-[#161b22] rounded transition-colors"
          title="键盘快捷键与终端指南"
        >
          <HelpCircle size={16} />
        </button>

        {/* 用户角色与机构 */}
        <div className="flex items-center gap-2 pl-3 border-l border-[#21262d]">
          <div className="w-6 h-6 rounded-full bg-[#1f6feb] flex items-center justify-center text-white text-xs font-semibold">
            陈
          </div>
          <div className="hidden md:block text-left">
            <div className="text-xs text-[#c9d1d9] font-medium leading-none flex items-center gap-1">
              {CURRENT_USER.userName}
              <ShieldCheck size={12} className="text-[#3fb950]" />
            </div>
            <div className="text-[10px] text-[#8b949e] mt-0.5">{CURRENT_USER.role}</div>
          </div>
        </div>

        {/* 北京时间 */}
        <div className="hidden xl:block text-right font-mono text-[11px] text-[#8b949e] pl-2">
          {beijingTime}
        </div>
      </div>
    </header>
  );
};
