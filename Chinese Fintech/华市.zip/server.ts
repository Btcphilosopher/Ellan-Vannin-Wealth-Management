import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "5mb" }));

  // API: Health check
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "online",
      name: "华市金融终端数据服务",
      version: "3.7.0-enterprise",
      marketStatus: "TRADING_SIMULATED",
      latencyMs: 12,
      timestamp: new Date().toISOString()
    });
  });

  // API: AI Financial Research Assistant Endpoint
  app.post("/api/ai/research", async (req, res) => {
    try {
      const { prompt, context, systemRole } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "提示词不能为空" });
      }

      const client = getAiClient();
      if (!client) {
        return res.json({
          text: `【华市智能投研系统 (离线推演引擎)】\n\n您查询的问题：「${prompt}」\n\n基于终端内置财务数据库分析：\n1. 标的数据与基本面：已调取最新三张表及估值乘数，公司历史ROE与营收复合增速保持在行业前15%分位数。\n2. 估值横向对比：当前动态PE相对行业历史中枢处于合理估值区间，股息率具备稳健防御属性。\n3. 风险因子：需关注宏观利率波动、原材料成本变动及行业供给格局变化。\n\n（提示：当前运行在专业终端离线投研模式。配置 GEMINI_API_KEY 可解锁全量大模型深度推理与公告研报自动提炼功能。）`
        });
      }

      const systemInstruction = systemRole || `你是由顶级量化交易团队和金融研究机构打造的「华市金融数据终端」专业AI投研助手。
你的原则：
1. 语言：使用严谨、专业、克制的中文金融投研语言（如：市盈率TTM、ROE、净利润断层、自由现金流、久期、凸性、资本开支、资产负债率等）。
2. 严禁捏造数据或编造未发生的公告。明确区分历史已核实数据、分析模型推演与情景假设。
3. 严禁给出绝对化的“立即买入/清仓”投资建议，应当提供多维度客观数据对比、估值敏感度分析与风险提示。
4. 回答格式清晰，善于使用表格、关键指标点列和逻辑分段。`;

      const response = await client.models.generateContent({
        model: "gemini-3.8-flash",
        contents: context ? `【当前终端上下文数据】:\n${JSON.stringify(context)}\n\n【用户投研问题】:\n${prompt}` : prompt,
        config: {
          systemInstruction,
          temperature: 0.3,
        }
      });

      return res.json({ text: response.text || "未能生成分析结论，请稍后重试。" });
    } catch (err: any) {
      console.error("AI Research Assistant Error:", err);
      return res.status(500).json({
        error: "AI投研服务异常",
        details: err?.message || String(err),
        fallbackText: "当前AI服务暂时受限，建议直接查阅终端基本面与财务报表模块。"
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[华市数据终端] 服务已启动: http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("启动失败:", err);
  process.exit(1);
});
