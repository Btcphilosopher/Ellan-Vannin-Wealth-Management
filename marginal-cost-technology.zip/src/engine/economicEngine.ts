import {
  EconomicParameters,
  EquilibriumResult,
  CurvePoint,
  CausalTraceStep,
  SectorData,
  SupplyChainNode,
  PriceDiscoveryStep,
} from '../types';

/**
 * Calculates Marginal Cost MC(q) for a given output level q
 */
export function calculateMarginalCost(
  q: number,
  params: EconomicParameters
): number {
  const {
    wageRate,
    energyPriceIndex,
    rawMaterialCostIndex,
    capitalCostRate,
    productivityFactor,
    maxCapacity,
    capacitySteepness,
    taxPerUnit,
    subsidyPerUnit,
  } = params;

  // Base variable input cost component (scaled by indices and wage)
  const baseVariableInput =
    (energyPriceIndex / 100) * 18 +
    (rawMaterialCostIndex / 100) * 22 +
    (wageRate / 28) * 16 +
    (capitalCostRate / 5.5) * 8;

  // Efficiency scaling by technology productivity tau
  const tau = Math.max(0.1, productivityFactor);
  const baseMC = baseVariableInput / tau;

  // Asymptotic capacity constraint penalty as Q approaches maxCapacity
  const utilisationRatio = Math.max(0, q) / Math.max(1, maxCapacity);
  let capacityPenalty = 0;

  if (utilisationRatio > 0.05) {
    const safetyMargin = Math.max(0.01, 1.0 - utilisationRatio);
    capacityPenalty =
      baseMC * 0.25 * Math.pow(utilisationRatio / safetyMargin, capacitySteepness);
  }

  // Net tax / subsidy adjustment
  const netTax = taxPerUnit - subsidyPerUnit;

  return Math.max(0.1, baseMC + capacityPenalty + netTax);
}

/**
 * Calculates Average Variable Cost AVC(q)
 */
export function calculateAVC(q: number, params: EconomicParameters): number {
  if (q <= 0.1) return calculateMarginalCost(0.1, params);
  
  // Numerical integration over [0, q] for AVC
  const steps = 20;
  const dq = q / steps;
  let sumVC = 0;
  for (let i = 0; i < steps; i++) {
    const midQ = (i + 0.5) * dq;
    sumVC += calculateMarginalCost(midQ, params) * dq;
  }
  return sumVC / q;
}

/**
 * Calculates Average Total Cost ATC(q) = TFC/q + AVC(q)
 */
export function calculateATC(q: number, params: EconomicParameters): number {
  if (q <= 0.1) return 999;
  return params.fixedCost / q + calculateAVC(q, params);
}

/**
 * Calculates Demand Price P_D(q)
 */
export function calculateDemandPrice(
  q: number,
  params: EconomicParameters
): number {
  const { demandIntercept, demandSlope, incomeFactor } = params;
  const incomeShift = (incomeFactor - 100) * 0.4;
  const price = demandIntercept + incomeShift - demandSlope * q;
  return Math.max(0, price);
}

/**
 * Calculates Marginal Revenue MR(q) for monopoly / market demand
 */
export function calculateMarginalRevenue(
  q: number,
  params: EconomicParameters
): number {
  const { demandIntercept, demandSlope, incomeFactor } = params;
  const incomeShift = (incomeFactor - 100) * 0.4;
  // MR = P + q * dP/dq = A - 2*b*q
  return demandIntercept + incomeShift - 2 * demandSlope * q;
}

/**
 * Solve for Market Equilibrium (P*, Q*) where Demand(Q) = Supply(Q) [MC(Q)]
 */
export function calculateEquilibrium(
  params: EconomicParameters
): EquilibriumResult {
  const maxQSearch = Math.min(params.maxCapacity * 0.99, 300);
  let bestQ = 0;
  let minDiff = Infinity;
  const steps = 600;

  for (let i = 1; i <= steps; i++) {
    const q = (i / steps) * maxQSearch;
    const pDemand = calculateDemandPrice(q, params);
    const mc = calculateMarginalCost(q, params);
    const diff = Math.abs(pDemand - mc);

    if (diff < minDiff) {
      minDiff = diff;
      bestQ = q;
    }
  }

  const qEquilibrium = Math.max(1, bestQ);
  const pEquilibrium = calculateDemandPrice(qEquilibrium, params);
  const mcAtEquilibrium = calculateMarginalCost(qEquilibrium, params);
  const pConsumer = pEquilibrium;
  const pProducer = pEquilibrium - params.taxPerUnit + params.subsidyPerUnit;

  // Compute Consumer Surplus (CS) = Area under Demand above P* from 0 to Q*
  let cs = 0;
  const csSteps = 100;
  const dqCS = qEquilibrium / csSteps;
  for (let i = 0; i < csSteps; i++) {
    const qMid = (i + 0.5) * dqCS;
    const pd = calculateDemandPrice(qMid, params);
    cs += (pd - pConsumer) * dqCS;
  }
  cs = Math.max(0, cs);

  // Compute Producer Surplus (PS) = Area under P* above MC from 0 to Q*
  let ps = 0;
  for (let i = 0; i < csSteps; i++) {
    const qMid = (i + 0.5) * dqCS;
    const mc = calculateMarginalCost(qMid, params);
    ps += (pProducer - mc) * dqCS;
  }
  ps = Math.max(0, ps);

  // Compute Deadweight Loss if tax or subsidy exists
  let deadweightLoss = 0;
  if (params.taxPerUnit > 0 || params.subsidyPerUnit > 0) {
    // Difference from undistorted equilibrium Q_free
    const undistortedParams = { ...params, taxPerUnit: 0, subsidyPerUnit: 0 };
    let qFree = qEquilibrium;
    let minDiffFree = Infinity;
    for (let i = 1; i <= steps; i++) {
      const q = (i / steps) * maxQSearch;
      const pd = calculateDemandPrice(q, undistortedParams);
      const mc = calculateMarginalCost(q, undistortedParams);
      const diff = Math.abs(pd - mc);
      if (diff < minDiffFree) {
        minDiffFree = diff;
        qFree = q;
      }
    }
    const deltaQ = Math.abs(qFree - qEquilibrium);
    deadweightLoss = 0.5 * deltaQ * Math.abs(params.taxPerUnit - params.subsidyPerUnit);
  }

  const taxRevenue = params.taxPerUnit * qEquilibrium;
  const capacityUtilisation = (qEquilibrium / params.maxCapacity) * 100;
  const mcNextUnit = calculateMarginalCost(qEquilibrium + 1, params);
  const atcAtEquilibrium = calculateATC(qEquilibrium, params);
  const avcAtEquilibrium = calculateAVC(qEquilibrium, params);

  // Elasticities at equilibrium point
  const deltaQ = 0.5;
  const pPlus = calculateDemandPrice(qEquilibrium + deltaQ, params);
  const dPdQ = (pPlus - pEquilibrium) / deltaQ;
  const elasticityDemand =
    dPdQ !== 0 ? (1 / dPdQ) * (pEquilibrium / qEquilibrium) : -1;

  const mcPlus = calculateMarginalCost(qEquilibrium + deltaQ, params);
  const dMCdQ = (mcPlus - mcAtEquilibrium) / deltaQ;
  const elasticitySupply =
    dMCdQ !== 0 ? (1 / dMCdQ) * (pEquilibrium / qEquilibrium) : 1;

  return {
    pEquilibrium,
    qEquilibrium,
    pConsumer,
    pProducer,
    consumerSurplus: cs,
    producerSurplus: ps,
    taxRevenue,
    deadweightLoss,
    capacityUtilisation,
    mcAtEquilibrium,
    mcNextUnit,
    atcAtEquilibrium,
    avcAtEquilibrium,
    isShortage: false,
    isSurplus: false,
    shortageSurplusAmount: 0,
    elasticityDemandAtEquilibrium: elasticityDemand,
    elasticitySupplyAtEquilibrium: elasticitySupply,
  };
}

/**
 * Generate curve points for plotting Supply, Demand, MC, ATC, AVC, MR
 */
export function generateCurvePoints(
  params: EconomicParameters,
  pointCount = 80
): CurvePoint[] {
  const points: CurvePoint[] = [];
  const maxQPlot = params.maxCapacity * 1.15;

  for (let i = 1; i <= pointCount; i++) {
    const q = (i / pointCount) * maxQPlot;
    const demand = calculateDemandPrice(q, params);
    const mc = calculateMarginalCost(q, params);
    const atc = calculateATC(q, params);
    const avc = calculateAVC(q, params);
    const mr = calculateMarginalRevenue(q, params);

    points.push({
      q,
      demand,
      supply: mc,
      mc,
      atc: Math.min(300, atc),
      avc: Math.min(300, avc),
      mr: Math.max(-50, mr),
    });
  }

  return points;
}

/**
 * Generates the "Why Did This Change?" causal pathway steps
 */
export function generateCausalTrace(
  prevParams: EconomicParameters,
  currParams: EconomicParameters,
  prevEq: EquilibriumResult,
  currEq: EquilibriumResult
): CausalTraceStep[] {
  const steps: CausalTraceStep[] = [];

  // Check energy change
  if (Math.abs(currParams.energyPriceIndex - prevParams.energyPriceIndex) > 1) {
    const deltaEnergy =
      ((currParams.energyPriceIndex - prevParams.energyPriceIndex) /
        prevParams.energyPriceIndex) *
      100;
    const deltaMC =
      ((currEq.mcAtEquilibrium - prevEq.mcAtEquilibrium) /
        Math.max(0.1, prevEq.mcAtEquilibrium)) *
      100;

    steps.push({
      id: 'energy-shift',
      variable: 'Energy Input Price',
      changeText: `Energy Tariff Index ${deltaEnergy > 0 ? '+' : ''}${deltaEnergy.toFixed(1)}%`,
      impactValue: `Base MC ${deltaMC > 0 ? '+' : ''}${deltaMC.toFixed(1)}%`,
      direction: deltaEnergy > 0 ? 'up' : 'down',
      explanation: 'Energy input cost scales unit electricity & heat generation expenses directly into variable marginal cost.',
      equationText: 'dMC/dE = 0.35 * (E_index / 100) / tau',
    });
  }

  // Check productivity change
  if (Math.abs(currParams.productivityFactor - prevParams.productivityFactor) > 0.02) {
    const deltaProd =
      ((currParams.productivityFactor - prevParams.productivityFactor) /
        prevParams.productivityFactor) *
      100;
    steps.push({
      id: 'prod-shift',
      variable: 'Technology Productivity (τ)',
      changeText: `Productivity Factor ${deltaProd > 0 ? '+' : ''}${deltaProd.toFixed(1)}%`,
      impactValue: `Marginal Cost -${Math.abs(deltaProd * 0.8).toFixed(1)}%`,
      direction: deltaProd > 0 ? 'down' : 'up',
      explanation: 'Higher technological efficiency tau reduces required inputs per unit of production, shifting the entire MC curve downward.',
      equationText: 'MC(Q) = BaseCost / tau + Penalty(Q/Q_max)',
    });
  }

  // Check demand intercept change
  if (Math.abs(currParams.demandIntercept - prevParams.demandIntercept) > 2) {
    const deltaDem =
      ((currParams.demandIntercept - prevParams.demandIntercept) /
        prevParams.demandIntercept) *
      100;
    steps.push({
      id: 'demand-shift',
      variable: 'Consumer Demand Willingness-to-Pay',
      changeText: `Demand Intercept ${deltaDem > 0 ? '+' : ''}${deltaDem.toFixed(1)}%`,
      impactValue: `Market Price Shift`,
      direction: deltaDem > 0 ? 'up' : 'down',
      explanation: 'Changes in consumer preference, income, or export demand shift the willingness-to-pay intercept vertically.',
      equationText: 'P_D(Q) = A + deltaA - b*Q',
    });
  }

  // Check capacity change
  if (Math.abs(currParams.maxCapacity - prevParams.maxCapacity) > 2) {
    const deltaCap = currParams.maxCapacity - prevParams.maxCapacity;
    steps.push({
      id: 'capacity-shift',
      variable: 'Installed Physical Capacity (Q_max)',
      changeText: `Capacity limit ${deltaCap > 0 ? '+' : ''}${deltaCap.toFixed(0)} units`,
      impactValue: `Utilisation ${currEq.capacityUtilisation.toFixed(1)}%`,
      direction: deltaCap > 0 ? 'down' : 'up',
      explanation: 'Expanding capacity moves the asymptotic wall further right, allowing higher throughput without exponential cost acceleration.',
      equationText: 'Penalty = 0.25 * (Q / (Q_max - Q))^beta',
    });
  }

  // Supply / Equilibrium response step
  const deltaP =
    ((currEq.pEquilibrium - prevEq.pEquilibrium) / prevEq.pEquilibrium) * 100;
  const deltaQ =
    ((currEq.qEquilibrium - prevEq.qEquilibrium) / prevEq.qEquilibrium) * 100;

  if (Math.abs(deltaP) > 0.1 || Math.abs(deltaQ) > 0.1) {
    steps.push({
      id: 'market-clearing',
      variable: 'Equilibrium Market Clearing',
      changeText: `Price P* £${currEq.pEquilibrium.toFixed(2)} (${deltaP > 0 ? '+' : ''}${deltaP.toFixed(1)}%)`,
      impactValue: `Quantity Q* ${currEq.qEquilibrium.toFixed(1)}u (${deltaQ > 0 ? '+' : ''}${deltaQ.toFixed(1)}%)`,
      direction: deltaP > 0 ? 'up' : 'down',
      explanation: 'The market clearing mechanism finds the price and quantity intersection where marginal cost equals consumer willingness to pay.',
      equationText: 'P*(Q*) = MC(Q*) = P_Demand(Q*)',
    });
  }

  // Default step if no changes
  if (steps.length === 0) {
    steps.push({
      id: 'baseline-state',
      variable: 'System Equilibrium Stable',
      changeText: 'Baseline British Institutional State',
      impactValue: `P* = £${currEq.pEquilibrium.toFixed(2)}, Q* = ${currEq.qEquilibrium.toFixed(1)}u`,
      direction: 'neutral',
      explanation: 'The reactive economic system is currently operating at optimal steady-state equilibrium.',
      equationText: 'MC = P* = £' + currEq.pEquilibrium.toFixed(2),
    });
  }

  return steps;
}

/**
 * Recalculate Sector Heatmap items based on current parameters
 */
export function recalculateSectors(
  sectors: SectorData[],
  params: EconomicParameters
): SectorData[] {
  return sectors.map((sec) => {
    const energyImpact =
      (params.energyPriceIndex / 100) * sec.energySensitivity;
    const wageImpact = (params.wageRate / 28) * sec.labourSensitivity;
    const capitalImpact =
      (params.capitalCostRate / 5.5) * sec.capitalSensitivity;

    const totalSensitivityFactor =
      (energyImpact + wageImpact + capitalImpact) /
      Math.max(0.1, params.productivityFactor);

    const calculatedMC = sec.baseCost * totalSensitivityFactor;
    const trend = ((calculatedMC - sec.baseCost) / sec.baseCost) * 100;
    const util = Math.min(
      99.5,
      Math.max(
        30,
        sec.capacityUtilisation +
          (params.productivityFactor - 1.0) * 10 -
          (params.energyPriceIndex - 100) * 0.1
      )
    );

    return {
      ...sec,
      marginalCost: calculatedMC,
      costTrendPct: trend,
      capacityUtilisation: util,
    };
  });
}

/**
 * Recalculate Supply Chain nodes pass-through values
 */
export function recalculateSupplyChain(
  nodes: SupplyChainNode[],
  params: EconomicParameters
): SupplyChainNode[] {
  let runningCost = 0;

  return nodes.map((node, index) => {
    const tau = Math.max(0.1, params.productivityFactor);
    let stageValueAdded = node.valueAddedMC;

    // Apply parameter multipliers based on stage
    if (node.id === 'sc-1') {
      stageValueAdded *= params.rawMaterialCostIndex / 100;
    } else if (node.id === 'sc-2') {
      stageValueAdded *= params.energyPriceIndex / 100;
    } else if (node.id === 'sc-3') {
      stageValueAdded *= (params.wageRate / 28) / tau;
    } else if (node.id === 'sc-4') {
      stageValueAdded *= params.energyPriceIndex / 100;
    }

    const inputCost = index === 0 ? node.inputCost : runningCost;
    const cumulativeMC = inputCost + stageValueAdded;
    runningCost = cumulativeMC;

    const utilisation = Math.min(
      98,
      (params.maxCapacity / node.capacityLimit) * 85
    );
    const isBottleneck = utilisation > 85;

    return {
      ...node,
      inputCost,
      valueAddedMC: stageValueAdded,
      cumulativeMC,
      utilisationPct: utilisation,
      isBottleneck,
    };
  });
}

/**
 * Generates Price Discovery Tâtonnement steps
 */
export function generatePriceDiscoverySteps(
  params: EconomicParameters
): PriceDiscoveryStep[] {
  const eq = calculateEquilibrium(params);
  const steps: PriceDiscoveryStep[] = [];
  let currentP = eq.pEquilibrium * 1.45; // Start above equilibrium
  const alpha = 0.15; // Adjustment speed

  for (let i = 1; i <= 10; i++) {
    // Demand Q at currentP
    const qDemand = Math.max(
      0,
      (params.demandIntercept - currentP) / params.demandSlope
    );

    // Supply Q at currentP (solve MC(Q) = currentP)
    let qSupply = 0;
    for (let q = 1; q <= params.maxCapacity; q += 0.5) {
      if (calculateMarginalCost(q, params) >= currentP) {
        qSupply = q;
        break;
      }
      qSupply = q;
    }

    const excessDemand = qDemand - qSupply;

    steps.push({
      step: i,
      price: currentP,
      qDemanded: qDemand,
      qSupplied: qSupply,
      excessDemand,
    });

    // Price adjustment step: P_{t+1} = P_t + alpha * (Q_D - Q_S)
    currentP = Math.max(5, currentP + alpha * excessDemand);
  }

  return steps;
}
