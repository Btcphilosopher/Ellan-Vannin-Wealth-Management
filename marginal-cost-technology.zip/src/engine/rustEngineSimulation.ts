import { RustSimulationStats, EconomicParameters } from '../types';

/**
 * Rust Simulation Engine Simulation Class
 * Simulates high-speed WASM micro-firm agents, real-time solver ticks,
 * and memory/CPU telemetry for MARGINAL COST TECHNOLOGY platform.
 */
export class RustSimulationEngine {
  private activeFirmsCount = 125000;
  private currentTicks = 0;
  private startTime = Date.now();

  public getStats(params: EconomicParameters): RustSimulationStats {
    this.currentTicks++;
    const now = Date.now();
    const elapsedSec = (now - this.startTime) / 1000;

    // Simulate high-frequency WASM calculations
    const baseIterations = 1450000;
    const capacityImpact = (params.maxCapacity / 150) * 100000;
    const iterationsPerSec = Math.round(
      baseIterations + capacityImpact + (Math.sin(this.currentTicks * 0.1) * 80000)
    );

    const tickTimeMs = parseFloat((0.14 + Math.sin(this.currentTicks) * 0.04).toFixed(3));
    const memoryUsageMb = parseFloat((42.5 + (params.maxCapacity / 20) + Math.cos(this.currentTicks * 0.05) * 1.5).toFixed(1));

    return {
      simulatedFirmsCount: this.activeFirmsCount,
      iterationsPerSec,
      tickTimeMs,
      memoryUsageMb,
      simdVectorisation: true,
      activeThreads: 16,
      marketClearingMicroseconds: Math.round(18 + Math.random() * 6),
      agentStrategyDistribution: {
        profitMax: 68,
        marketShareMax: 22,
        capExExpansion: 10,
      },
    };
  }

  public setFirmCount(count: number) {
    this.activeFirmsCount = count;
  }
}

export const rustEngine = new RustSimulationEngine();
