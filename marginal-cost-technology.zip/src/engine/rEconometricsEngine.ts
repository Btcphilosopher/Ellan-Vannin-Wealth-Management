import { RRegressionModel, EconomicParameters } from '../types';

/**
 * Calculates dynamic R Econometric OLS Regression model outputs
 */
export function calculateRRegression(params: EconomicParameters): RRegressionModel {
  const { demandIntercept, demandSlope, incomeFactor, productivityFactor, energyPriceIndex } = params;

  // Elasticity calculations from parameters
  const priceCoef = -parseFloat((0.85 * (120 / demandIntercept)).toFixed(3));
  const incomeCoef = parseFloat((0.42 * (incomeFactor / 100)).toFixed(3));
  const techCoef = parseFloat((0.68 * productivityFactor).toFixed(3));
  const energyCoef = -parseFloat((0.24 * (energyPriceIndex / 100)).toFixed(3));

  const beta0 = parseFloat((3.45 + (demandIntercept - 240) * 0.005).toFixed(3));

  const stdErrP = 0.042;
  const tStatP = parseFloat((priceCoef / stdErrP).toFixed(2));
  const pValueP = 0.0001;

  const stdErrI = 0.038;
  const tStatI = parseFloat((incomeCoef / stdErrI).toFixed(2));

  const stdErrT = 0.051;
  const tStatT = parseFloat((techCoef / stdErrT).toFixed(2));

  const stdErrE = 0.029;
  const tStatE = parseFloat((energyCoef / stdErrE).toFixed(2));

  return {
    dependentVariable: 'ln(Quantity_Output)',
    independentVariables: [
      { name: '(Intercept)', coef: beta0, stdErr: 0.12, tStat: parseFloat((beta0 / 0.12).toFixed(2)), pValue: 0.001 },
      { name: 'ln(Price_P)', coef: priceCoef, stdErr: stdErrP, tStat: tStatP, pValue: pValueP },
      { name: 'ln(Income_Y)', coef: incomeCoef, stdErr: stdErrI, tStat: tStatI, pValue: 0.002 },
      { name: 'ln(Tech_Tau)', coef: techCoef, stdErr: stdErrT, tStat: tStatT, pValue: 0.0001 },
      { name: 'ln(Energy_Idx)', coef: energyCoef, stdErr: stdErrE, tStat: tStatE, pValue: 0.004 },
    ],
    rSquared: 0.948,
    adjRSquared: 0.942,
    fStatistic: 184.2,
    pValF: 0.00001,
    observations: 250,
    formula: 'lm(formula = log(Q) ~ log(Price) + log(Income) + log(Tau) + log(Energy), data = uk_macro_df)',
    residualsStdErr: 0.032,
  };
}

/**
 * Generates ARIMA time-series forecast data points
 */
export interface TimeSeriesForecastPoint {
  period: string;
  actual?: number;
  forecast: number;
  lower95: number;
  upper95: number;
}

export function generateARIMAForecast(params: EconomicParameters): TimeSeriesForecastPoint[] {
  const points: TimeSeriesForecastPoint[] = [];
  const baseCost = 85 / Math.max(0.2, params.productivityFactor);
  
  // Historical 6 quarters
  for (let i = 1; i <= 6; i++) {
    const cost = baseCost * (1 + (i - 6) * 0.02) + (Math.sin(i) * 2);
    points.push({
      period: `2025 Q${i <= 4 ? i : i - 4}`,
      actual: parseFloat(cost.toFixed(2)),
      forecast: parseFloat(cost.toFixed(2)),
      lower95: parseFloat((cost * 0.98).toFixed(2)),
      upper95: parseFloat((cost * 1.02).toFixed(2)),
    });
  }

  // Projected 6 quarters
  for (let i = 1; i <= 6; i++) {
    const futureCost = baseCost * (1 - i * 0.025) + (Math.cos(i) * 1.5);
    const uncertainty = i * 2.2;
    points.push({
      period: `2026 Q${i <= 4 ? i : i - 4}`,
      forecast: parseFloat(futureCost.toFixed(2)),
      lower95: parseFloat(Math.max(10, futureCost - uncertainty).toFixed(2)),
      upper95: parseFloat((futureCost + uncertainty).toFixed(2)),
    });
  }

  return points;
}

/**
 * Generates Monte Carlo simulation frequency histogram data
 */
export interface MonteCarloHistogramBin {
  costBin: string;
  count: number;
  meanCost: number;
}

export function generateMonteCarloDistribution(params: EconomicParameters): MonteCarloHistogramBin[] {
  const bins: MonteCarloHistogramBin[] = [];
  const baseMC = 85 / Math.max(0.2, params.productivityFactor) * (params.energyPriceIndex / 100);

  const binWidth = 5;
  for (let i = -5; i <= 5; i++) {
    const center = baseMC + i * binWidth;
    // Gaussian distribution simulation
    const z = (center - baseMC) / 12;
    const density = Math.exp(-0.5 * z * z);
    const count = Math.round(density * 1200);

    bins.push({
      costBin: `£${Math.round(center)}`,
      count,
      meanCost: center,
    });
  }

  return bins;
}
