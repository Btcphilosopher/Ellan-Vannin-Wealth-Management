import {
  EconomicParameters,
  SectorData,
  SupplyChainNode,
  TechGeneration,
  ScenarioPreset,
  CounterfactualQuestion,
} from '../types';

export const BASELINE_PARAMETERS: EconomicParameters = {
  // Demand Parameters
  demandIntercept: 240, // Base willingness to pay £240
  demandSlope: 1.2, // Price drops £1.20 per unit
  incomeFactor: 100, // Nominal income index
  priceElasticityDemand: -0.85,

  // Cost & Supply Parameters
  fixedCost: 4500, // £4,500 fixed overhead
  wageRate: 28, // £28/hr
  energyPriceIndex: 100, // Base energy index
  rawMaterialCostIndex: 100, // Base materials index
  capitalCostRate: 5.5, // 5.5% interest/CapEx cost rate
  productivityFactor: 1.0, // Base productivity tau = 1.0

  // Capacity Parameters
  maxCapacity: 150, // Physical capacity limit = 150 units
  capacitySteepness: 2.2, // Asymptotic penalty exponent

  // Policy Parameters
  taxPerUnit: 0,
  subsidyPerUnit: 0,
  interestRate: 4.25, // Bank of England rate %
  infrastructureInvestment: 50, // £50M

  // Expectations
  expectedFuturePrice: 110,
};

export const INITIAL_SECTORS: SectorData[] = [
  {
    id: 'energy',
    name: 'Clean Energy Grid',
    iconName: 'Zap',
    marginalCost: 38.5,
    baseCost: 45.0,
    costTrendPct: -14.4,
    capacityUtilisation: 84.2,
    techIntensity: 'Extreme',
    energySensitivity: 0.15,
    labourSensitivity: 0.25,
    capitalSensitivity: 0.6,
  },
  {
    id: 'semiconductors',
    name: 'Advanced Microchips',
    iconName: 'Cpu',
    marginalCost: 12.4,
    baseCost: 22.0,
    costTrendPct: -43.6,
    capacityUtilisation: 96.8,
    techIntensity: 'Extreme',
    energySensitivity: 0.35,
    labourSensitivity: 0.2,
    capitalSensitivity: 0.45,
  },
  {
    id: 'computing',
    name: 'AI High-Performance Computing',
    iconName: 'Server',
    marginalCost: 18.2,
    baseCost: 35.0,
    costTrendPct: -48.0,
    capacityUtilisation: 98.4,
    techIntensity: 'Extreme',
    energySensitivity: 0.55,
    labourSensitivity: 0.15,
    capitalSensitivity: 0.3,
  },
  {
    id: 'transport',
    name: 'Autonomous Freight & Rail',
    iconName: 'Truck',
    marginalCost: 52.0,
    baseCost: 65.0,
    costTrendPct: -20.0,
    capacityUtilisation: 78.5,
    techIntensity: 'High',
    energySensitivity: 0.45,
    labourSensitivity: 0.35,
    capitalSensitivity: 0.2,
  },
  {
    id: 'manufacturing',
    name: 'Precision Heavy Industrial',
    iconName: 'Factory',
    marginalCost: 74.8,
    baseCost: 82.0,
    costTrendPct: -8.8,
    capacityUtilisation: 88.0,
    techIntensity: 'High',
    energySensitivity: 0.4,
    labourSensitivity: 0.35,
    capitalSensitivity: 0.25,
  },
  {
    id: 'construction',
    name: 'Modular Infrastructure',
    iconName: 'Building2',
    marginalCost: 110.5,
    baseCost: 115.0,
    costTrendPct: -3.9,
    capacityUtilisation: 82.0,
    techIntensity: 'Moderate',
    energySensitivity: 0.25,
    labourSensitivity: 0.55,
    capitalSensitivity: 0.2,
  },
  {
    id: 'agriculture',
    name: 'Vertical & Automated Agritech',
    iconName: 'Sprout',
    marginalCost: 28.6,
    baseCost: 36.0,
    costTrendPct: -20.5,
    capacityUtilisation: 71.4,
    techIntensity: 'High',
    energySensitivity: 0.35,
    labourSensitivity: 0.3,
    capitalSensitivity: 0.35,
  },
  {
    id: 'pharma',
    name: 'Bio-Synthetic Therapeutics',
    iconName: 'Dna',
    marginalCost: 14.2,
    baseCost: 28.0,
    costTrendPct: -49.3,
    capacityUtilisation: 68.0,
    techIntensity: 'Extreme',
    energySensitivity: 0.1,
    labourSensitivity: 0.5,
    capitalSensitivity: 0.4,
  },
];

export const INITIAL_SUPPLY_CHAIN: SupplyChainNode[] = [
  {
    id: 'sc-1',
    stageName: 'Raw Materials Extraction',
    description: 'High-purity critical metals, lithium, copper & rare earths',
    inputCost: 18.0,
    valueAddedMC: 12.0,
    cumulativeMC: 30.0,
    capacityLimit: 180,
    currentThroughput: 105,
    utilisationPct: 58.3,
    isBottleneck: false,
    efficiencyRating: 88,
  },
  {
    id: 'sc-2',
    stageName: 'Energy & Power Generation',
    description: 'Nuclear & offshore wind grid baseload supply',
    inputCost: 30.0,
    valueAddedMC: 18.5,
    cumulativeMC: 48.5,
    capacityLimit: 160,
    currentThroughput: 138,
    utilisationPct: 86.3,
    isBottleneck: false,
    efficiencyRating: 92,
  },
  {
    id: 'sc-3',
    stageName: 'Advanced Manufacturing',
    description: 'Robotic precision fab & cyber-physical assembly line',
    inputCost: 48.5,
    valueAddedMC: 24.0,
    cumulativeMC: 72.5,
    capacityLimit: 150,
    currentThroughput: 132,
    utilisationPct: 88.0,
    isBottleneck: true,
    efficiencyRating: 84,
  },
  {
    id: 'sc-4',
    stageName: 'Freight Logistics & Rail',
    description: 'Automated electric rail networks & port terminals',
    inputCost: 72.5,
    valueAddedMC: 8.5,
    cumulativeMC: 81.0,
    capacityLimit: 200,
    currentThroughput: 132,
    utilisationPct: 66.0,
    isBottleneck: false,
    efficiencyRating: 95,
  },
  {
    id: 'sc-5',
    stageName: 'Regional Distribution',
    description: 'Last-mile automated fulfilment hubs',
    inputCost: 81.0,
    valueAddedMC: 6.2,
    cumulativeMC: 87.2,
    capacityLimit: 175,
    currentThroughput: 132,
    utilisationPct: 75.4,
    isBottleneck: false,
    efficiencyRating: 91,
  },
  {
    id: 'sc-6',
    stageName: 'Final Institutional Demand',
    description: 'End-user consumer & enterprise market allocation',
    inputCost: 87.2,
    valueAddedMC: 4.8,
    cumulativeMC: 92.0,
    capacityLimit: 220,
    currentThroughput: 132,
    utilisationPct: 60.0,
    isBottleneck: false,
    efficiencyRating: 97,
  },
];

export const TECH_GENERATIONS: TechGeneration[] = [
  {
    id: 'gen-1',
    era: 'Industrial Gen I',
    name: 'Mechanical Steam & Iron',
    year: 1840,
    mcReductionPct: 0,
    capacityMultiplier: 1.0,
    energyEfficiencyPct: 25,
    description: 'Early mechanisation, high labor intensity, linear cost escalation.',
    active: false,
  },
  {
    id: 'gen-2',
    era: 'Industrial Gen II',
    name: 'Grid Electrification & Assembly',
    year: 1920,
    mcReductionPct: 35,
    capacityMultiplier: 2.2,
    energyEfficiencyPct: 50,
    description: 'Standardised flow manufacturing and electrical motive power.',
    active: false,
  },
  {
    id: 'gen-3',
    era: 'Digital Gen III',
    name: 'Microprocessors & PLC Automation',
    year: 1980,
    mcReductionPct: 60,
    capacityMultiplier: 4.5,
    energyEfficiencyPct: 70,
    description: 'Computerised numerical control, just-in-time inventory systems.',
    active: false,
  },
  {
    id: 'gen-4',
    era: 'Cybernetic Gen IV',
    name: 'Additive & Autonomous Robotics',
    year: 2018,
    mcReductionPct: 80,
    capacityMultiplier: 8.0,
    energyEfficiencyPct: 88,
    description: 'Real-time telemetry, predictive maintenance, automated logistics.',
    active: false,
  },
  {
    id: 'gen-5',
    era: 'Quantum & AI Gen V',
    name: 'Self-Optimising Synthesis (Current)',
    year: 2026,
    mcReductionPct: 92,
    capacityMultiplier: 15.0,
    energyEfficiencyPct: 96,
    description: 'Near-zero marginal cost information processing, closed-loop economic optimization.',
    active: true,
  },
];

export const SCENARIO_PRESETS: ScenarioPreset[] = [
  {
    id: 'energy-shock',
    title: 'Energy Price Shock (+150%)',
    badge: 'Macro Crisis',
    description: 'Geopolitical disruption spiking natural gas and electricity grid tariffs.',
    icon: 'Flame',
    params: {
      energyPriceIndex: 250,
      rawMaterialCostIndex: 130,
    },
    storyline: 'Severe spike in power generation tariffs drives energy-intensive industries up the marginal cost curve. Supply contracts sharply, pushing up market price.',
  },
  {
    id: 'ai-boom',
    title: 'AI & Cybernetic Productivity Boom',
    badge: 'Tech Surge',
    description: 'Broad implementation of autonomous algorithms and robotic assembly lowers labor and coordination cost.',
    icon: 'Sparkles',
    params: {
      productivityFactor: 1.65,
      wageRate: 26,
      rawMaterialCostIndex: 85,
    },
    storyline: 'Productivity factor increases by 65%. Marginal cost collapses, pushing the supply curve outward and expanding total welfare.',
  },
  {
    id: 'industrial-renaissance',
    title: 'Industrial CapEx Renaissance',
    badge: 'Capital Build',
    description: 'Government infrastructure programs & cheap capital expand physical production ceiling by 50%.',
    icon: 'Building',
    params: {
      maxCapacity: 220,
      infrastructureInvestment: 250,
      capitalCostRate: 3.2,
      fixedCost: 6500,
    },
    storyline: 'Major expansion in installed capacity Q_max removes capacity bottlenecks, allowing high-volume output without cost exponential spike.',
  },
  {
    id: 'supply-chain-crisis',
    title: 'Global Logistics Bottleneck',
    badge: 'Supply Bottleneck',
    description: 'Chokepoint disruptions double raw material freight and component costs while limiting max throughput.',
    icon: 'PackageX',
    params: {
      rawMaterialCostIndex: 185,
      maxCapacity: 110,
      energyPriceIndex: 140,
    },
    storyline: 'Chokepoints restrict maximum throughput while input prices soar. The MC curve steepens abruptly at low output levels.',
  },
  {
    id: 'cheap-capital',
    title: 'Central Bank Rate Cuts (-300bps)',
    badge: 'Monetary Stimulus',
    description: 'Substantial drop in interest rates reduces capital costs and stimulates consumer demand.',
    icon: 'Coins',
    params: {
      interestRate: 1.25,
      capitalCostRate: 2.5,
      demandIntercept: 280,
    },
    storyline: 'Lower interest rates stimulate investment and consumer demand simultaneously, shifting the demand curve upward and rightward.',
  },
  {
    id: 'quantum-breakthrough',
    title: 'Quantum Synthesis Breakthrough',
    badge: 'Sovereign Shift',
    description: 'Generational leap in material science drops marginal manufacturing cost by 50%.',
    icon: 'Atom',
    params: {
      productivityFactor: 2.1,
      energyPriceIndex: 65,
      rawMaterialCostIndex: 70,
    },
    storyline: 'Transformative technological leap drops unit variable cost across all production tiers. Supply shifts massively to lower prices.',
  },
  {
    id: 'demand-collapse',
    title: 'Macro Demand Collapse (-35%)',
    badge: 'Recession',
    description: 'Global economic contraction drops consumer willingness to pay across all price levels.',
    icon: 'TrendingDown',
    params: {
      demandIntercept: 155,
      demandSlope: 1.5,
    },
    storyline: 'Aggregate demand falls dramatically, creating market excess capacity and forcing producers down their marginal cost curves.',
  },
];

export const COUNTERFACTUAL_QUESTIONS: CounterfactualQuestion[] = [
  {
    id: 'cf-1',
    question: 'What happens if computing cost falls by 70%?',
    category: 'Technological Deflation',
    impactSummary: 'Productivity surges +45%, MC drops £22/unit, supply expands +28%.',
    applyParams: {
      productivityFactor: 1.45,
      energyPriceIndex: 85,
    },
  },
  {
    id: 'cf-2',
    question: 'What happens if electricity becomes 40% cheaper?',
    category: 'Energy Transition',
    impactSummary: 'Base variable cost falls £18/unit, capacity utilisation improves, prices drop 14%.',
    applyParams: {
      energyPriceIndex: 60,
    },
  },
  {
    id: 'cf-3',
    question: 'What happens if productivity rises 5% per year for 5 years?',
    category: 'Compound Growth',
    impactSummary: 'Compound productivity reaches tau = 1.28, shifting supply right and lowering market price by 21%.',
    applyParams: {
      productivityFactor: 1.28,
    },
  },
  {
    id: 'cf-4',
    question: 'What happens if demand doubles due to new export markets?',
    category: 'Export Shock',
    impactSummary: 'Demand intercept rises to £420, price surges until capacity constraint accelerates MC.',
    applyParams: {
      demandIntercept: 420,
    },
  },
  {
    id: 'cf-5',
    question: 'What happens if capacity cannot expand for five years under demand pressure?',
    category: 'Infrastructure Inelasticity',
    impactSummary: 'Capacity bottleneck forces producer to operate on steep asymptotic MC segment.',
    applyParams: {
      maxCapacity: 115,
      capacitySteepness: 3.5,
      demandIntercept: 300,
    },
  },
  {
    id: 'cf-6',
    question: 'What happens if central bank cuts interest rates by 3.0%?',
    category: 'Monetary Policy',
    impactSummary: 'Capital cost rate drops to 2.5%, stimulating demand and easing fixed capital expansion.',
    applyParams: {
      interestRate: 1.25,
      capitalCostRate: 2.5,
    },
  },
  {
    id: 'cf-7',
    question: 'What happens if a £25/unit green carbon tax is levied on production?',
    category: 'Environmental Tax',
    impactSummary: 'MC curve shifts up vertically by £25, creating DWL of £185M and dividing tax burden between buyer and seller.',
    applyParams: {
      taxPerUnit: 25,
    },
  },
];
