/**
 * Types and interfaces for MARGINAL COST TECHNOLOGY
 * Anglo-Futurist Economic Computing Platform
 */

export interface EconomicParameters {
  // Demand Parameters
  demandIntercept: number; // Demand A (Base price at Q=0)
  demandSlope: number; // Demand b (Price drop per unit of Q)
  incomeFactor: number; // Income parameter shifting demand
  priceElasticityDemand: number; // Price elasticity Ed
  
  // Cost & Supply Parameters
  fixedCost: number; // Total Fixed Cost (TFC)
  wageRate: number; // Wage rate per labor unit ($/hr)
  energyPriceIndex: number; // Energy price index (Base = 100)
  rawMaterialCostIndex: number; // Raw material index (Base = 100)
  capitalCostRate: number; // Interest / Capital cost rate %
  productivityFactor: number; // Tech Productivity factor tau (higher = lower MC)
  
  // Capacity Parameters
  maxCapacity: number; // Maximum physical capacity Q_max
  capacitySteepness: number; // Asymptotic acceleration exponent
  
  // Policy & Market Parameters
  taxPerUnit: number; // Excise tax or tariff per unit
  subsidyPerUnit: number; // Production subsidy per unit
  interestRate: number; // Central bank base rate %
  infrastructureInvestment: number; // Govt infrastructure investment £M
  
  // Market dynamics
  expectedFuturePrice: number; // Producer price expectation
}

export interface CurvePoint {
  q: number;
  price?: number;
  mc?: number;
  atc?: number;
  avc?: number;
  demand?: number;
  supply?: number;
  mr?: number;
}

export interface EquilibriumResult {
  pEquilibrium: number; // Market clearing price P*
  qEquilibrium: number; // Market clearing quantity Q*
  pConsumer: number; // Price paid by consumer (P* + tax - subsidy share)
  pProducer: number; // Net price received by producer
  consumerSurplus: number; // CS
  producerSurplus: number; // PS
  taxRevenue: number; // Tax revenue generated
  deadweightLoss: number; // DWL from taxes/distortions
  capacityUtilisation: number; // (Q* / Q_max) * 100%
  mcAtEquilibrium: number; // MC(Q*)
  mcNextUnit: number; // MC(Q* + 1)
  atcAtEquilibrium: number; // ATC(Q*)
  avcAtEquilibrium: number; // AVC(Q*)
  isShortage: boolean;
  isSurplus: boolean;
  shortageSurplusAmount: number;
  elasticityDemandAtEquilibrium: number;
  elasticitySupplyAtEquilibrium: number;
}

export interface CausalTraceStep {
  id: string;
  variable: string;
  changeText: string;
  impactValue: string;
  direction: 'up' | 'down' | 'neutral';
  explanation: string;
  equationText?: string;
}

export interface SectorData {
  id: string;
  name: string;
  iconName: string;
  marginalCost: number; // £/unit
  baseCost: number;
  costTrendPct: number; // e.g. -4.2% or +12.1%
  capacityUtilisation: number; // %
  techIntensity: 'Extreme' | 'High' | 'Moderate' | 'Low';
  energySensitivity: number; // 0.0 - 1.0
  labourSensitivity: number;
  capitalSensitivity: number;
}

export interface SupplyChainNode {
  id: string;
  stageName: string;
  description: string;
  inputCost: number;
  valueAddedMC: number;
  cumulativeMC: number;
  capacityLimit: number;
  currentThroughput: number;
  utilisationPct: number;
  isBottleneck: boolean;
  efficiencyRating: number; // 0-100%
}

export interface TechGeneration {
  id: string;
  era: string;
  name: string;
  year: number;
  mcReductionPct: number;
  capacityMultiplier: number;
  energyEfficiencyPct: number;
  description: string;
  active: boolean;
}

export interface ScenarioPreset {
  id: string;
  title: string;
  badge: string;
  description: string;
  icon: string;
  params: Partial<EconomicParameters>;
  storyline: string;
}

export interface CounterfactualQuestion {
  id: string;
  question: string;
  category: string;
  impactSummary: string;
  applyParams: Partial<EconomicParameters>;
}

export interface RustSimulationStats {
  simulatedFirmsCount: number;
  iterationsPerSec: number;
  tickTimeMs: number;
  memoryUsageMb: number;
  simdVectorisation: boolean;
  activeThreads: number;
  marketClearingMicroseconds: number;
  agentStrategyDistribution: { profitMax: number; marketShareMax: number; capExExpansion: number };
}

export interface RRegressionModel {
  dependentVariable: string;
  independentVariables: { name: string; coef: number; stdErr: number; tStat: number; pValue: number }[];
  rSquared: number;
  adjRSquared: number;
  fStatistic: number;
  pValF: number;
  observations: number;
  formula: string;
  residualsStdErr: number;
}

export interface PriceDiscoveryStep {
  step: number;
  price: number;
  qDemanded: number;
  qSupplied: number;
  excessDemand: number;
}
