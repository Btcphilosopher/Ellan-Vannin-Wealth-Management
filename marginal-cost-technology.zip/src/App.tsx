import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  EconomicParameters,
  ScenarioPreset,
  CounterfactualQuestion,
  CausalTraceStep,
} from './types';
import {
  BASELINE_PARAMETERS,
  INITIAL_SECTORS,
} from './data/initialEconomicData';
import {
  calculateEquilibrium,
  generateCausalTrace,
  recalculateSectors,
} from './engine/economicEngine';
import { rustEngine } from './engine/rustEngineSimulation';

// Subcomponents
import { Header } from './components/Header';
import { CausalTraceBanner } from './components/CausalTraceBanner';
import { SectorHeatmapWidget } from './components/SectorHeatmapWidget';
import { RustRArchitectureDiagram } from './components/RustRArchitectureDiagram';

// Panels
import { MarketEquilibriumPanel } from './components/panels/MarketEquilibriumPanel';
import { MarginalCostPanel } from './components/panels/MarginalCostPanel';
import { TechnologyFrontierPanel } from './components/panels/TechnologyFrontierPanel';
import { SupplyChainPanel } from './components/panels/SupplyChainPanel';
import { CapacityUtilisationPanel } from './components/panels/CapacityUtilisationPanel';
import { PriceDiscoveryPanel } from './components/panels/PriceDiscoveryPanel';
import { REconometricsPanel } from './components/panels/REconometricsPanel';
import { RustSimulationPanel } from './components/panels/RustSimulationPanel';
import { ScenarioLaboratoryPanel } from './components/panels/ScenarioLaboratoryPanel';
import { PolicyInvestmentPanel } from './components/panels/PolicyInvestmentPanel';

export default function App() {
  const [params, setParams] = useState<EconomicParameters>(BASELINE_PARAMETERS);
  const prevParamsRef = useRef<EconomicParameters>(BASELINE_PARAMETERS);

  const [activeTab, setActiveTab] = useState('equilibrium');
  const [activeScenario, setActiveScenario] = useState<ScenarioPreset | null>(null);
  const [archDiagramOpen, setArchDiagramOpen] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(false);

  // Compute live equilibrium
  const equilibrium = useMemo(() => {
    return calculateEquilibrium(params);
  }, [params]);

  const prevEquilibrium = useMemo(() => {
    return calculateEquilibrium(prevParamsRef.current);
  }, [params]);

  // Generate reactive causal trace steps
  const causalSteps: CausalTraceStep[] = useMemo(() => {
    return generateCausalTrace(
      prevParamsRef.current,
      params,
      prevEquilibrium,
      equilibrium
    );
  }, [params, equilibrium, prevEquilibrium]);

  // Recalculate sectors
  const updatedSectors = useMemo(() => {
    return recalculateSectors(INITIAL_SECTORS, params);
  }, [params]);

  // Rust WASM telemetry stats
  const rustStats = useMemo(() => {
    return rustEngine.getStats(params);
  }, [params]);

  // Parameter update handler
  const handleUpdateParams = (newParams: Partial<EconomicParameters>) => {
    prevParamsRef.current = { ...params };
    setParams((prev) => ({ ...prev, ...newParams }));
  };

  // Reset baseline handler
  const handleResetBaseline = () => {
    prevParamsRef.current = { ...params };
    setParams(BASELINE_PARAMETERS);
    setActiveScenario(null);
  };

  // Apply scenario preset
  const handleApplyScenario = (scenario: ScenarioPreset) => {
    prevParamsRef.current = { ...params };
    setParams({
      ...BASELINE_PARAMETERS,
      ...scenario.params,
    });
    setActiveScenario(scenario);
  };

  // Apply counterfactual
  const handleApplyCounterfactual = (cf: CounterfactualQuestion) => {
    prevParamsRef.current = { ...params };
    setParams((prev) => ({
      ...prev,
      ...cf.applyParams,
    }));
  };

  return (
    <div className="min-h-screen bg-[#0D1117] text-[#F5F2ED] flex flex-col font-sans radial-luxury-grid selection:bg-[#C5A059]/30 selection:text-black">
      {/* Top Header */}
      <Header
        equilibrium={equilibrium}
        rustStats={rustStats}
        activeScenario={activeScenario}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onResetBaseline={handleResetBaseline}
        audioEnabled={audioEnabled}
        setAudioEnabled={setAudioEnabled}
        onOpenArchDiagram={() => setArchDiagramOpen(true)}
      />

      {/* Reactive Causal Transmission Banner */}
      <CausalTraceBanner steps={causalSteps} />

      {/* Main Observatory Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-8">
        {/* Active Panel View Render */}
        {activeTab === 'equilibrium' && (
          <MarketEquilibriumPanel
            params={params}
            onUpdateParams={handleUpdateParams}
            equilibrium={equilibrium}
          />
        )}

        {activeTab === 'mc-engine' && (
          <MarginalCostPanel
            params={params}
            onUpdateParams={handleUpdateParams}
            equilibrium={equilibrium}
          />
        )}

        {activeTab === 'tech-frontier' && (
          <TechnologyFrontierPanel
            params={params}
            onUpdateParams={handleUpdateParams}
          />
        )}

        {activeTab === 'supply-chain' && <SupplyChainPanel params={params} />}

        {activeTab === 'capacity' && (
          <CapacityUtilisationPanel
            params={params}
            onUpdateParams={handleUpdateParams}
            equilibrium={equilibrium}
          />
        )}

        {activeTab === 'price-discovery' && <PriceDiscoveryPanel params={params} />}

        {activeTab === 'r-econometrics' && <REconometricsPanel params={params} />}

        {activeTab === 'rust-sim' && (
          <RustSimulationPanel params={params} rustStats={rustStats} />
        )}

        {activeTab === 'scenarios' && (
          <ScenarioLaboratoryPanel
            params={params}
            onApplyScenario={handleApplyScenario}
            onApplyCounterfactual={handleApplyCounterfactual}
            activeScenario={activeScenario}
          />
        )}

        {activeTab === 'policy' && (
          <PolicyInvestmentPanel
            params={params}
            onUpdateParams={handleUpdateParams}
            equilibrium={equilibrium}
          />
        )}

        {/* Global Industrial Sector Heatmap Widget (visible at bottom of major panels) */}
        <SectorHeatmapWidget sectors={updatedSectors} />
      </main>

      {/* Footer */}
      <footer className="h-8 bg-[#C5A059] text-black flex items-center justify-between px-8 text-[9px] font-bold tracking-[0.2em] uppercase shrink-0">
        <span>SOVEREIGN ECONOMIC COMPUTATION UNIT &copy; 2026</span>
        <span className="hidden sm:inline">SECURITY CLASS: ALPHA-SOVEREIGN</span>
        <span>SYSTEM: V.4.82-MARGCOST</span>
      </footer>

      {/* Rust x R Architecture Modal Diagram */}
      <RustRArchitectureDiagram
        isOpen={archDiagramOpen}
        onClose={() => setArchDiagramOpen(false)}
      />
    </div>
  );
}
