import React from 'react';
import { EconomicParameters, EquilibriumResult } from '../../types';
import {
  calculateMarginalCost,
  calculateATC,
  calculateAVC,
} from '../../engine/economicEngine';
import {
  BarChart3,
  Sliders,
  Zap,
  DollarSign,
  TrendingUp,
  Cpu,
  Layers,
  Percent,
} from 'lucide-react';

interface MarginalCostPanelProps {
  params: EconomicParameters;
  onUpdateParams: (newParams: Partial<EconomicParameters>) => void;
  equilibrium: EquilibriumResult;
}

export const MarginalCostPanel: React.FC<MarginalCostPanelProps> = ({
  params,
  onUpdateParams,
  equilibrium,
}) => {
  const currentQ = equilibrium.qEquilibrium;
  const currentMC = calculateMarginalCost(currentQ, params);
  const currentATC = calculateATC(currentQ, params);
  const currentAVC = calculateAVC(currentQ, params);
  const fixedCostPerUnit = params.fixedCost / Math.max(1, currentQ);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BarChart3 className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif font-bold text-base text-[#f3e5ab] uppercase tracking-wider">
              MARGINAL COST ENGINE — CENTRAL ORGANISING ARCHITECTURE
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-sans max-w-3xl">
            Marginal cost represents the additional economic cost required to produce one additional unit of output. In this reactive engine, technological efficiency shifts MC downward, input prices scale it, and capacity constraints cause exponential acceleration near maximum capacity.
          </p>
        </div>

        <div className="bg-[#141c2b] px-4 py-2 rounded-lg border border-[#c5a059]/30 font-mono text-xs flex items-center gap-4">
          <div>
            <div className="text-slate-400">Current MC(Q*)</div>
            <div className="text-lg font-bold text-[#38bdf8]">
              £{currentMC.toFixed(2)}
            </div>
          </div>
          <div className="h-6 w-px bg-slate-700" />
          <div>
            <div className="text-slate-400">MC Next Unit (+1u)</div>
            <div className="text-lg font-bold text-amber-400">
              £{equilibrium.mcNextUnit.toFixed(2)}
            </div>
          </div>
        </div>
      </div>

      {/* Cost Decomposition Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="text-slate-400 mb-1">Marginal Cost (MC)</div>
          <div className="text-2xl font-bold text-[#38bdf8] mb-1">
            £{currentMC.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-500">
            Incremental cost of unit #{Math.round(currentQ)}
          </div>
        </div>

        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="text-slate-400 mb-1">Average Total Cost (ATC)</div>
          <div className="text-2xl font-bold text-amber-400 mb-1">
            £{currentATC.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-500">
            Total cost per unit (AFC + AVC)
          </div>
        </div>

        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="text-slate-400 mb-1">Average Variable Cost (AVC)</div>
          <div className="text-2xl font-bold text-purple-400 mb-1">
            £{currentAVC.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-500">
            Variable inputs per unit
          </div>
        </div>

        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="text-slate-400 mb-1">Average Fixed Cost (AFC)</div>
          <div className="text-2xl font-bold text-emerald-400 mb-1">
            £{fixedCostPerUnit.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-500">
            TFC (£{params.fixedCost}) / Q* ({currentQ.toFixed(1)})
          </div>
        </div>
      </div>

      {/* Input Price & Productivity Controls */}
      <div className="bg-[#0f172a] p-5 rounded-xl border border-[#c5a059]/30 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-[#c5a059]/20 pb-2">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#c5a059]" />
            <h3 className="font-serif font-bold text-sm text-[#f3e5ab] uppercase tracking-wider">
              MARGINAL COST INPUT LEVERS & TECHNOLOGICAL EFFICIENCY (τ)
            </h3>
          </div>
          <span className="text-xs font-mono text-[#38bdf8]">
            [Live Cost Propagation]
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 text-xs font-mono">
          {/* Tech Productivity Tau */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-[#c5a059]/30 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold flex items-center gap-1.5 text-[#f3e5ab]">
                <Cpu className="w-4 h-4 text-[#c5a059]" />
                <span>Productivity Factor (τ):</span>
              </span>
              <span className="text-[#34d399] font-bold text-sm">
                {params.productivityFactor.toFixed(2)}x
              </span>
            </div>
            <input
              type="range"
              min="0.3"
              max="2.5"
              step="0.05"
              value={params.productivityFactor}
              onChange={(e) =>
                onUpdateParams({ productivityFactor: parseFloat(e.target.value) })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 leading-tight">
              Higher productivity scales down required energy, material & labor inputs across all output tiers.
            </div>
          </div>

          {/* Energy Price Index */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold flex items-center gap-1.5 text-slate-300">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Energy Tariff Index:</span>
              </span>
              <span className="text-amber-400 font-bold text-sm">
                {params.energyPriceIndex} idx
              </span>
            </div>
            <input
              type="range"
              min="40"
              max="300"
              step="5"
              value={params.energyPriceIndex}
              onChange={(e) =>
                onUpdateParams({ energyPriceIndex: parseFloat(e.target.value) })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 leading-tight">
              Base grid electricity & gas tariff (100 = Baseline £38/MWh).
            </div>
          </div>

          {/* Wage Rate */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold flex items-center gap-1.5 text-slate-300">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Labour Wage Rate:</span>
              </span>
              <span className="text-emerald-400 font-bold text-sm">
                £{params.wageRate}/hr
              </span>
            </div>
            <input
              type="range"
              min="15"
              max="60"
              step="1"
              value={params.wageRate}
              onChange={(e) =>
                onUpdateParams({ wageRate: parseFloat(e.target.value) })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 leading-tight">
              Direct hourly labor compensation across manufacturing & technical sectors.
            </div>
          </div>

          {/* Raw Material Cost Index */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold flex items-center gap-1.5 text-slate-300">
                <Layers className="w-4 h-4 text-[#38bdf8]" />
                <span>Raw Material Index:</span>
              </span>
              <span className="text-[#38bdf8] font-bold text-sm">
                {params.rawMaterialCostIndex} idx
              </span>
            </div>
            <input
              type="range"
              min="50"
              max="250"
              step="5"
              value={params.rawMaterialCostIndex}
              onChange={(e) =>
                onUpdateParams({ rawMaterialCostIndex: parseFloat(e.target.value) })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 leading-tight">
              Critical metals, rare earths, polymers and chemical feedstocks.
            </div>
          </div>

          {/* Fixed Costs TFC */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold text-slate-300">Total Fixed Costs (TFC):</span>
              <span className="text-amber-400 font-bold text-sm">
                £{params.fixedCost}
              </span>
            </div>
            <input
              type="range"
              min="1000"
              max="12000"
              step="250"
              value={params.fixedCost}
              onChange={(e) =>
                onUpdateParams({ fixedCost: parseFloat(e.target.value) })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 leading-tight">
              Capital infrastructure, leases, R&D overhead & fixed machinery depreciation.
            </div>
          </div>

          {/* Capital Interest Rate */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold text-slate-300">Capital Cost Rate:</span>
              <span className="text-purple-400 font-bold text-sm">
                {params.capitalCostRate.toFixed(1)}%
              </span>
            </div>
            <input
              type="range"
              min="1.0"
              max="12.0"
              step="0.25"
              value={params.capitalCostRate}
              onChange={(e) =>
                onUpdateParams({ capitalCostRate: parseFloat(e.target.value) })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400 leading-tight">
              Financing & CapEx cost rate affecting fixed asset expansion.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
