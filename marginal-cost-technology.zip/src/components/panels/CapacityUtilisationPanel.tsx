import React from 'react';
import { EconomicParameters, EquilibriumResult } from '../../types';
import { calculateMarginalCost } from '../../engine/economicEngine';
import { Cpu, AlertTriangle, TrendingUp, Gauge, HardDrive, ShieldCheck, Zap } from 'lucide-react';

interface CapacityPanelProps {
  params: EconomicParameters;
  onUpdateParams: (newParams: Partial<EconomicParameters>) => void;
  equilibrium: EquilibriumResult;
}

export const CapacityUtilisationPanel: React.FC<CapacityPanelProps> = ({
  params,
  onUpdateParams,
  equilibrium,
}) => {
  const currentQ = equilibrium.qEquilibrium;
  const maxCap = params.maxCapacity;
  const util = equilibrium.capacityUtilisation;

  // Derivative dMC/dQ at currentQ
  const mcCurrent = calculateMarginalCost(currentQ, params);
  const mcNext = calculateMarginalCost(currentQ + 1, params);
  const dMCdQ = mcNext - mcCurrent;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Gauge className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif font-bold text-base text-[#f3e5ab] uppercase tracking-wider">
              INDUSTRIAL CONTROL ROOM — CAPACITY & UTILISATION MONITOR
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-sans max-w-3xl">
            When capacity utilisation approaches 100%, physical bottlenecks cause the marginal cost curve to accelerate asymptotically. Expanding installed capacity (Q_max) flattens the cost curve at high output.
          </p>
        </div>

        <div className="bg-[#141c2b] px-4 py-2 rounded-lg border border-[#c5a059]/30 font-mono text-xs flex items-center gap-3">
          <Cpu className="w-4 h-4 text-[#c5a059]" />
          <div>
            <div className="text-slate-400">Utilisation Gauge</div>
            <div
              className={`text-lg font-bold ${
                util > 88 ? 'text-amber-400' : 'text-emerald-400'
              }`}
            >
              {util.toFixed(1)}%
            </div>
          </div>
        </div>
      </div>

      {/* Control Room Gauges Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Gauge 1: Installed Capacity vs Output */}
        <div className="bg-[#0f172a] p-5 rounded-xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-serif font-bold text-xs uppercase text-[#f3e5ab] tracking-wider">
              INSTALLED CAPACITY VS OUTPUT
            </span>
            <HardDrive className="w-4 h-4 text-[#c5a059]" />
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">Active Output Q*:</span>
              <span className="text-[#34d399] font-bold">{currentQ.toFixed(1)} units</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Max Physical Limit Q_max:</span>
              <span className="text-amber-400 font-bold">{maxCap} units</span>
            </div>

            {/* Utilisation visual bar */}
            <div className="space-y-1 pt-2">
              <div className="w-full bg-slate-800 h-4 rounded-full overflow-hidden p-0.5 border border-slate-700">
                <div
                  className={`h-full rounded-full transition-all ${
                    util > 90
                      ? 'bg-gradient-to-r from-amber-500 to-rose-500'
                      : 'bg-gradient-to-r from-emerald-500 to-sky-500'
                  }`}
                  style={{ width: `${Math.min(100, util)}%` }}
                />
              </div>
            </div>
          </div>

          {/* Interactive Capacity Slider */}
          <div className="pt-2 border-t border-slate-800 space-y-2 font-mono text-xs">
            <div className="flex justify-between text-slate-300">
              <span>Expand Physical Capacity:</span>
              <span className="text-[#38bdf8] font-bold">{params.maxCapacity} units</span>
            </div>
            <input
              type="range"
              min="80"
              max="300"
              step="5"
              value={params.maxCapacity}
              onChange={(e) =>
                onUpdateParams({ maxCapacity: parseFloat(e.target.value) })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
          </div>
        </div>

        {/* Gauge 2: Next Unit Marginal Cost Derivative */}
        <div className="bg-[#0f172a] p-5 rounded-xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-serif font-bold text-xs uppercase text-[#f3e5ab] tracking-wider">
              MARGINAL COST DERIVATIVE (dMC/dQ)
            </span>
            <TrendingUp className="w-4 h-4 text-[#38bdf8]" />
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="bg-[#141c2b] p-3 rounded border border-slate-800">
              <div className="text-slate-400">Current Unit MC:</div>
              <div className="text-lg font-bold text-[#38bdf8]">
                £{mcCurrent.toFixed(2)}
              </div>
            </div>

            <div className="bg-[#141c2b] p-3 rounded border border-slate-800">
              <div className="text-slate-400">Next Unit MC (+1 unit):</div>
              <div className="text-lg font-bold text-amber-400">
                £{mcNext.toFixed(2)}
              </div>
            </div>

            <div className="bg-[#141c2b] p-3 rounded border border-slate-800 flex justify-between items-center">
              <span className="text-slate-400">Asymptotic Slope (dMC/dQ):</span>
              <span className="text-rose-400 font-bold text-sm">
                +£{dMCdQ.toFixed(2)} / unit
              </span>
            </div>
          </div>
        </div>

        {/* Gauge 3: Capacity Expansion ROI Estimator */}
        <div className="bg-[#0f172a] p-5 rounded-xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-serif font-bold text-xs uppercase text-[#f3e5ab] tracking-wider">
              CAPITAL EXPANSION INVESTMENT ROI
            </span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="text-slate-300 leading-relaxed font-sans">
              Expanding physical plant capacity by +25% reduces marginal cost derivative by suppressing asymptotic pressure.
            </div>

            <div className="bg-[#141c2b] p-3 rounded border border-slate-800 space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>CapEx Required:</span>
                <span className="text-amber-400 font-bold">£24.5 M</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Annual Unit MC Savings:</span>
                <span className="text-[#34d399] font-bold">£12.2 / unit</span>
              </div>
              <div className="flex justify-between text-slate-400 pt-1 border-t border-slate-800/80">
                <span className="text-[#f3e5ab]">Internal Rate of Return (IRR):</span>
                <span className="text-[#38bdf8] font-bold text-sm">18.4%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
