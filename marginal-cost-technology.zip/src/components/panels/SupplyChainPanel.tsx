import React from 'react';
import { EconomicParameters, SupplyChainNode } from '../../types';
import { recalculateSupplyChain } from '../../engine/economicEngine';
import { INITIAL_SUPPLY_CHAIN } from '../../data/initialEconomicData';
import { Layers, AlertOctagon, ArrowRight, CheckCircle2, Cpu, Factory, Truck, Zap } from 'lucide-react';

interface SupplyChainPanelProps {
  params: EconomicParameters;
}

export const SupplyChainPanel: React.FC<SupplyChainPanelProps> = ({ params }) => {
  const supplyChainNodes = recalculateSupplyChain(INITIAL_SUPPLY_CHAIN, params);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Layers className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif font-bold text-base text-[#f3e5ab] uppercase tracking-wider">
              INDUSTRIAL SUPPLY CHAIN MATRIX & COST PASS-THROUGH
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-sans max-w-3xl">
            Each supply chain stage adds value-added marginal cost. When upstream input tariffs or energy costs spike, cost increases propagate down the chain to final consumer market equilibrium. Bottlenecks accelerate marginal cost for subsequent stages.
          </p>
        </div>

        <div className="bg-[#141c2b] px-4 py-2 rounded-lg border border-[#c5a059]/30 font-mono text-xs text-right">
          <div className="text-slate-400">Final Cumulative MC</div>
          <div className="text-lg font-bold text-[#38bdf8]">
            £{supplyChainNodes[supplyChainNodes.length - 1].cumulativeMC.toFixed(2)}/u
          </div>
        </div>
      </div>

      {/* Multi-stage pipeline layout */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {supplyChainNodes.map((node, index) => {
          return (
            <div
              key={node.id}
              className={`p-4 rounded-xl border flex flex-col justify-between space-y-3 shadow-lg relative ${
                node.isBottleneck
                  ? 'bg-gradient-to-br from-amber-950/60 to-[#0f172a] border-amber-500/80 ring-1 ring-amber-500/30'
                  : 'bg-[#0f172a] border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#c5a059]/20 text-[#f3e5ab] border border-[#c5a059]/30">
                    STAGE 0{index + 1}
                  </span>
                  {node.isBottleneck ? (
                    <span className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/50 animate-pulse">
                      <AlertOctagon className="w-3 h-3 text-amber-400" />
                      <span>CRITICAL BOTTLENECK</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[10px] font-mono text-emerald-400">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Optimal Flow</span>
                    </span>
                  )}
                </div>

                <h3 className="font-serif font-bold text-sm text-[#f3e5ab] mb-1">
                  {node.stageName}
                </h3>
                <p className="text-xs text-slate-300 font-sans mb-3">
                  {node.description}
                </p>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-800 font-mono text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Input Base MC:</span>
                  <span className="text-slate-200">£{node.inputCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Stage Value-Added MC:</span>
                  <span className="text-amber-400 font-bold">+£{node.valueAddedMC.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-400 pt-1 border-t border-slate-800/60">
                  <span className="text-[#f3e5ab]">Cumulative Stage MC:</span>
                  <span className="text-[#38bdf8] font-bold text-sm">
                    £{node.cumulativeMC.toFixed(2)}
                  </span>
                </div>

                {/* Utilisation Bar */}
                <div className="pt-2">
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Capacity Utilisation:</span>
                    <span
                      className={`font-bold ${
                        node.utilisationPct > 85
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {node.utilisationPct.toFixed(1)}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        node.utilisationPct > 85 ? 'bg-amber-400' : 'bg-emerald-400'
                      }`}
                      style={{ width: `${Math.min(100, node.utilisationPct)}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
