import React from 'react';
import { EconomicParameters, TechGeneration } from '../../types';
import { TECH_GENERATIONS } from '../../data/initialEconomicData';
import { Sparkles, Cpu, Clock, Zap, ArrowRight, CheckCircle2, Award } from 'lucide-react';

interface TechnologyFrontierPanelProps {
  params: EconomicParameters;
  onUpdateParams: (newParams: Partial<EconomicParameters>) => void;
}

export const TechnologyFrontierPanel: React.FC<TechnologyFrontierPanelProps> = ({
  params,
  onUpdateParams,
}) => {
  const handleSelectTechGen = (gen: TechGeneration) => {
    // Map gen reduction to productivity factor
    const newTau = 1.0 + (gen.mcReductionPct / 100) * 1.5;
    const newCap = 120 * (gen.capacityMultiplier * 0.3);
    onUpdateParams({
      productivityFactor: parseFloat(newTau.toFixed(2)),
      maxCapacity: Math.round(Math.min(350, Math.max(100, newCap))),
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif font-bold text-base text-[#f3e5ab] uppercase tracking-wider">
              TECHNOLOGY FRONTIER — SHIFTING THE ECONOMIC VIABILITY BOUNDARY
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-sans max-w-3xl">
            Technological progress fundamentally shifts the marginal cost curve downward and rightward. Each technological generation lowers unit variable inputs while expanding the physical throughput ceiling without incurring early asymptotic capacity penalties.
          </p>
        </div>

        <div className="bg-[#141c2b] px-4 py-2 rounded-lg border border-[#c5a059]/30 font-mono text-xs text-right">
          <div className="text-slate-400">Current Frontier Efficiency</div>
          <div className="text-lg font-bold text-[#34d399]">
            τ = {params.productivityFactor.toFixed(2)}x
          </div>
        </div>
      </div>

      {/* Technology Timeline Generation Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="font-serif font-bold text-xs uppercase text-[#f3e5ab] tracking-wider">
            HISTORICAL & FUTURISTIC TECHNOLOGY GENERATIONS
          </h3>
          <span className="text-xs font-mono text-slate-400">
            [Click Generation to Activate Model Parameters]
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          {TECH_GENERATIONS.map((gen) => {
            const isCurrentlySelected =
              Math.abs(params.productivityFactor - (1.0 + (gen.mcReductionPct / 100) * 1.5)) < 0.25;

            return (
              <div
                key={gen.id}
                onClick={() => handleSelectTechGen(gen)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                  isCurrentlySelected
                    ? 'bg-gradient-to-b from-[#1e293b] to-[#141c2b] border-[#c5a059] shadow-xl ring-2 ring-[#c5a059]/30'
                    : 'bg-[#0f172a] border-slate-800 hover:border-[#c5a059]/50 hover:bg-[#141c2b]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#c5a059]/15 text-[#f3e5ab] border border-[#c5a059]/30">
                      {gen.year}
                    </span>
                    {isCurrentlySelected && (
                      <CheckCircle2 className="w-4 h-4 text-[#34d399]" />
                    )}
                  </div>
                  <div className="text-xs font-serif font-bold text-[#f3e5ab] mb-1">
                    {gen.name}
                  </div>
                  <div className="text-[11px] font-mono text-[#38bdf8] mb-2">
                    {gen.era}
                  </div>
                  <p className="text-[11px] text-slate-300 font-sans leading-snug">
                    {gen.description}
                  </p>
                </div>

                <div className="space-y-1.5 pt-2 border-t border-slate-800/80 font-mono text-[11px]">
                  <div className="flex justify-between text-slate-400">
                    <span>MC Reduction:</span>
                    <span className="text-[#34d399] font-bold">-{gen.mcReductionPct}%</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Cap Capacity:</span>
                    <span className="text-amber-400 font-bold">{gen.capacityMultiplier}x</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Energy Eff:</span>
                    <span className="text-[#38bdf8] font-bold">{gen.energyEfficiencyPct}%</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Production Possibilities & Viability Frontier Comparison */}
      <div className="bg-[#0f172a] p-5 rounded-xl border border-[#c5a059]/30 shadow-xl grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="font-serif font-bold text-sm text-[#f3e5ab] uppercase tracking-wider mb-2">
            UNIT COST SHIFT FRONTIER ANALYSIS
          </h3>
          <p className="text-xs text-slate-300 font-sans leading-relaxed mb-4">
            When technology improves, the average total cost curve (ATC) drops across all volume levels. Lowering fixed and variable costs expands economic surplus and enables profitable production at lower consumer prices.
          </p>

          <div className="space-y-3 font-mono text-xs">
            <div className="bg-[#141c2b] p-3 rounded border border-slate-800 flex justify-between items-center">
              <span className="text-slate-400">Productivity Multiplier (τ):</span>
              <span className="text-[#34d399] font-bold text-sm">
                {params.productivityFactor.toFixed(2)}x Baseline
              </span>
            </div>
            <div className="bg-[#141c2b] p-3 rounded border border-slate-800 flex justify-between items-center">
              <span className="text-slate-400">Physical Throughput Limit (Q_max):</span>
              <span className="text-amber-400 font-bold text-sm">
                {params.maxCapacity} units
              </span>
            </div>
          </div>
        </div>

        <div className="bg-[#141c2b] p-4 rounded-xl border border-slate-800 flex flex-col justify-center items-center text-center space-y-3">
          <Award className="w-10 h-10 text-[#c5a059]" />
          <h4 className="font-serif font-bold text-sm text-[#f3e5ab]">
            SOVEREIGN TECHNOLOGICAL LEADERSHIP
          </h4>
          <p className="text-xs text-slate-300 font-sans max-w-md">
            Investing in next-generation cybernetic production shifts the UK marginal cost curve to the global efficiency frontier, preventing Dutch-disease margin compression.
          </p>
        </div>
      </div>
    </div>
  );
};
