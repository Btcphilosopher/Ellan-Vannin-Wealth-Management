import React from 'react';
import { EconomicParameters } from '../../types';
import {
  calculateRRegression,
  generateARIMAForecast,
  generateMonteCarloDistribution,
} from '../../engine/rEconometricsEngine';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { BarChart3, Binary, FileText, Code2, Sparkles, TrendingUp } from 'lucide-react';

interface REconometricsPanelProps {
  params: EconomicParameters;
}

export const REconometricsPanel: React.FC<REconometricsPanelProps> = ({ params }) => {
  const regression = calculateRRegression(params);
  const forecastData = generateARIMAForecast(params);
  const monteCarloData = generateMonteCarloDistribution(params);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <BarChart3 className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif font-bold text-base text-[#f3e5ab] uppercase tracking-wider">
              R STATISTICAL & ECONOMETRIC WORKSPACE
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-sans max-w-3xl">
            R provides the statistical and econometric analytical layer, performing log-linear OLS regressions, elasticity estimations, confidence intervals, ARIMA time-series forecasting, and Monte Carlo risk distributions.
          </p>
        </div>

        <div className="bg-[#141c2b] px-4 py-2 rounded-lg border border-[#c5a059]/30 font-mono text-xs flex items-center gap-3">
          <Code2 className="w-4 h-4 text-[#38bdf8]" />
          <div>
            <div className="text-slate-400">R Session</div>
            <div className="text-emerald-400 font-bold">R v4.4.2 Active</div>
          </div>
        </div>
      </div>

      {/* Main OLS Regression Console Output */}
      <div className="bg-[#0b101a] p-5 rounded-xl border border-[#c5a059]/30 font-mono text-xs shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <span className="text-[#f3e5ab] font-serif font-bold tracking-wider uppercase">
            SUMMARY OF OLS REGRESSION MODEL — [R stats::lm()]
          </span>
          <span className="text-slate-400">N = {regression.observations} obs</span>
        </div>

        <div className="p-3 bg-[#141c2b] rounded border border-slate-800 text-[#38bdf8]">
          <span className="text-[#c5a059]">Call: </span>
          {regression.formula}
        </div>

        {/* Coefficients Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-serif text-[11px]">
                <th className="pb-2">Coefficients</th>
                <th className="pb-2">Estimate</th>
                <th className="pb-2">Std. Error</th>
                <th className="pb-2">t value</th>
                <th className="pb-2">Pr(&gt;|t|)</th>
                <th className="pb-2">Signif</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {regression.independentVariables.map((v) => (
                <tr key={v.name} className="hover:bg-slate-800/30">
                  <td className="py-2 text-[#f3e5ab] font-bold">{v.name}</td>
                  <td className="py-2 text-[#38bdf8]">{v.coef.toFixed(4)}</td>
                  <td className="py-2 text-slate-400">{v.stdErr.toFixed(4)}</td>
                  <td className="py-2 text-amber-400">{v.tStat.toFixed(2)}</td>
                  <td className="py-2 text-emerald-400">{v.pValue.toFixed(4)}</td>
                  <td className="py-2 text-amber-400">***</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-800 text-slate-300 text-[11px]">
          <div>
            Residual Std Error: <span className="text-amber-400">{regression.residualsStdErr}</span> on {regression.observations - 5} DF
          </div>
          <div>
            Multiple R-squared: <span className="text-[#34d399] font-bold">{regression.rSquared}</span>, Adjusted R-squared: <span className="text-[#34d399] font-bold">{regression.adjRSquared}</span>
          </div>
          <div>
            F-statistic: <span className="text-[#38bdf8] font-bold">{regression.fStatistic}</span> (p-value: {regression.pValF})
          </div>
        </div>
      </div>

      {/* Visual Charts: ARIMA Forecast & Monte Carlo Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ARIMA Forecast Chart */}
        <div className="bg-[#0f172a] p-5 rounded-xl border border-slate-800 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-serif font-bold text-xs uppercase text-[#f3e5ab] tracking-wider">
              ARIMA TIME-SERIES COST FORECAST (95% CI)
            </span>
            <TrendingUp className="w-4 h-4 text-[#38bdf8]" />
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={forecastData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="period" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#141c2b',
                    borderColor: '#c5a059',
                    fontSize: '11px',
                    fontFamily: 'JetBrains Mono, monospace',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="upper95"
                  stroke="none"
                  fill="#38bdf8"
                  fillOpacity={0.15}
                />
                <Area
                  type="monotone"
                  dataKey="lower95"
                  stroke="none"
                  fill="#0f172a"
                  fillOpacity={1.0}
                />
                <Area
                  type="monotone"
                  dataKey="forecast"
                  stroke="#38bdf8"
                  strokeWidth={2}
                  fill="none"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Monte Carlo Distribution Histogram */}
        <div className="bg-[#0f172a] p-5 rounded-xl border border-slate-800 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-serif font-bold text-xs uppercase text-[#f3e5ab] tracking-wider">
              MONTE CARLO MARGINAL COST RISK DISTRIBUTION
            </span>
            <Sparkles className="w-4 h-4 text-[#c5a059]" />
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monteCarloData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="costBin" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#141c2b',
                    borderColor: '#c5a059',
                    fontSize: '11px',
                    fontFamily: 'JetBrains Mono, monospace',
                  }}
                />
                <Bar dataKey="count" fill="#c5a059" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
