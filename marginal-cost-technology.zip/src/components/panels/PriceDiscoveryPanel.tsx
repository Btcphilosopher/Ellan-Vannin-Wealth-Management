import React, { useState, useEffect } from 'react';
import { EconomicParameters, PriceDiscoveryStep } from '../../types';
import { generatePriceDiscoverySteps } from '../../engine/economicEngine';
import { ArrowRightLeft, Play, Pause, RotateCcw, CheckCircle2, TrendingDown } from 'lucide-react';

interface PriceDiscoveryPanelProps {
  params: EconomicParameters;
}

export const PriceDiscoveryPanel: React.FC<PriceDiscoveryPanelProps> = ({ params }) => {
  const steps = generatePriceDiscoverySteps(params);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentStepIndex((prev) => (prev + 1) % steps.length);
      }, 1200);
    }
    return () => clearInterval(interval);
  }, [isPlaying, steps.length]);

  const currentStep = steps[currentStepIndex];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ArrowRightLeft className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif font-bold text-base text-[#f3e5ab] uppercase tracking-wider">
              PRICE DISCOVERY & TÂTONNEMENT CLEARING MECHANISM
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-sans max-w-3xl">
            Watch market prices emerge dynamically through Walrasian tâtonnement order matching. When price is above equilibrium, excess supply forces prices down; when below, excess demand bids prices up until market clearing is achieved.
          </p>
        </div>

        {/* Play / Pause / Reset Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#1e293b] hover:bg-[#2c3b52] border border-[#c5a059]/40 text-xs font-mono text-[#f3e5ab] cursor-pointer"
          >
            {isPlaying ? <Pause className="w-4 h-4 text-amber-400" /> : <Play className="w-4 h-4 text-[#34d399]" />}
            <span>{isPlaying ? 'Pause' : 'Play Sequence'}</span>
          </button>
          <button
            onClick={() => setCurrentStepIndex(0)}
            className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
            title="Reset to Iteration 1"
          >
            <RotateCcw className="w-4 h-4 text-[#c5a059]" />
          </button>
        </div>
      </div>

      {/* Main Animated Stage */}
      <div className="bg-[#0f172a] p-6 rounded-xl border border-[#c5a059]/30 shadow-2xl grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Active Iteration Focus (Cols 1-5) */}
        <div className="lg:col-span-5 bg-[#141c2b] p-5 rounded-xl border border-[#c5a059]/30 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-[#c5a059] px-2 py-0.5 rounded bg-[#c5a059]/15 border border-[#c5a059]/30">
              ITERATION 0{currentStep.step} / 10
            </span>
            <span className="text-xs font-mono text-slate-400">Walrasian Auctioneer</span>
          </div>

          <div className="space-y-3 font-mono">
            <div>
              <div className="text-xs text-slate-400">Trial Market Price:</div>
              <div className="text-3xl font-bold text-[#38bdf8]">
                £{currentStep.price.toFixed(2)}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="bg-[#0b101a] p-3 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400">Q Demanded:</div>
                <div className="text-lg font-bold text-[#34d399]">
                  {currentStep.qDemanded.toFixed(1)} u
                </div>
              </div>

              <div className="bg-[#0b101a] p-3 rounded border border-slate-800">
                <div className="text-[11px] text-slate-400">Q Supplied:</div>
                <div className="text-lg font-bold text-[#38bdf8]">
                  {currentStep.qSupplied.toFixed(1)} u
                </div>
              </div>
            </div>

            <div className="bg-[#0b101a] p-3 rounded border border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-400">Excess Market Demand:</span>
              <span
                className={`font-bold text-sm ${
                  currentStep.excessDemand > 0
                    ? 'text-amber-400'
                    : currentStep.excessDemand < 0
                    ? 'text-rose-400'
                    : 'text-emerald-400'
                }`}
              >
                {currentStep.excessDemand > 0 ? '+' : ''}
                {currentStep.excessDemand.toFixed(1)} u
              </span>
            </div>
          </div>
        </div>

        {/* Right: Convergence Sequence Steps Table (Cols 6-12) */}
        <div className="lg:col-span-7 bg-[#141c2b] p-4 rounded-xl border border-slate-800 overflow-x-auto">
          <table className="w-full text-left font-mono text-xs text-slate-200">
            <thead>
              <tr className="border-b border-slate-700 text-slate-400 font-serif text-[11px]">
                <th className="pb-2">Step</th>
                <th className="pb-2">Trial Price</th>
                <th className="pb-2">Q Demanded</th>
                <th className="pb-2">Q Supplied</th>
                <th className="pb-2">Imbalance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {steps.map((st, idx) => {
                const isActive = idx === currentStepIndex;
                return (
                  <tr
                    key={st.step}
                    onClick={() => setCurrentStepIndex(idx)}
                    className={`cursor-pointer transition-colors ${
                      isActive ? 'bg-[#c5a059]/20 font-bold text-[#f3e5ab]' : 'hover:bg-slate-800/40'
                    }`}
                  >
                    <td className="py-2.5 px-2">#{st.step}</td>
                    <td className="py-2.5 px-2 text-[#38bdf8]">£{st.price.toFixed(2)}</td>
                    <td className="py-2.5 px-2 text-[#34d399]">{st.qDemanded.toFixed(1)}</td>
                    <td className="py-2.5 px-2 text-slate-300">{st.qSupplied.toFixed(1)}</td>
                    <td
                      className={`py-2.5 px-2 ${
                        st.excessDemand > 0
                          ? 'text-amber-400'
                          : st.excessDemand < 0
                          ? 'text-rose-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {st.excessDemand > 0 ? '+' : ''}
                      {st.excessDemand.toFixed(1)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
