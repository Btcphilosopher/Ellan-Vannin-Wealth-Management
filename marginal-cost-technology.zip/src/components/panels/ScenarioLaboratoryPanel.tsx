import React from 'react';
import { EconomicParameters, ScenarioPreset, CounterfactualQuestion } from '../../types';
import { SCENARIO_PRESETS, COUNTERFACTUAL_QUESTIONS } from '../../data/initialEconomicData';
import { ShieldAlert, Sparkles, Flame, Coins, Building, PackageX, Atom, TrendingDown, ArrowRight, CheckCircle2 } from 'lucide-react';

interface ScenarioLaboratoryPanelProps {
  params: EconomicParameters;
  onApplyScenario: (scenario: ScenarioPreset) => void;
  onApplyCounterfactual: (cf: CounterfactualQuestion) => void;
  activeScenario: ScenarioPreset | null;
}

export const ScenarioLaboratoryPanel: React.FC<ScenarioLaboratoryPanelProps> = ({
  params,
  onApplyScenario,
  onApplyCounterfactual,
  activeScenario,
}) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ShieldAlert className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif font-bold text-base text-[#f3e5ab] uppercase tracking-wider">
              SCENARIO LABORATORY & COUNTERFACTUAL ENGINE
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-sans max-w-3xl">
            Simulate alternative global macro states and technological shocks. Selecting a scenario or counterfactual hypothesis immediately propagates changes across marginal costs, supply, demand, equilibrium price, and welfare distribution.
          </p>
        </div>
      </div>

      {/* Preset Macro Scenarios Grid */}
      <div className="space-y-3">
        <h3 className="font-serif font-bold text-xs uppercase text-[#f3e5ab] tracking-wider px-1">
          ONE-CLICK MACROECONOMIC & TECHNOLOGICAL SCENARIOS
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {SCENARIO_PRESETS.map((sc) => {
            const isActive = activeScenario?.id === sc.id;
            return (
              <div
                key={sc.id}
                onClick={() => onApplyScenario(sc)}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 shadow-lg ${
                  isActive
                    ? 'bg-gradient-to-br from-[#1e293b] via-[#141c2b] to-[#0f172a] border-[#c5a059] ring-2 ring-[#c5a059]/40 shadow-2xl'
                    : 'bg-[#0f172a] border-slate-800 hover:border-[#c5a059]/50 hover:bg-[#141c2b]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-500/40">
                      {sc.badge}
                    </span>
                    {isActive && (
                      <span className="flex items-center gap-1 text-[10px] font-mono text-emerald-400">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>ACTIVE</span>
                      </span>
                    )}
                  </div>

                  <h4 className="font-serif font-bold text-sm text-[#f3e5ab] mb-1">
                    {sc.title}
                  </h4>
                  <p className="text-xs text-slate-300 font-sans leading-relaxed mb-2">
                    {sc.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-[#38bdf8]">
                  <span>Trigger Scenario</span>
                  <ArrowRight className="w-4 h-4 text-[#c5a059]" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Counterfactual Question Cards */}
      <div className="space-y-3 pt-2">
        <h3 className="font-serif font-bold text-xs uppercase text-[#f3e5ab] tracking-wider px-1">
          COUNTERFACTUAL HYPOTHESIS TESTING
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {COUNTERFACTUAL_QUESTIONS.map((cf) => (
            <div
              key={cf.id}
              onClick={() => onApplyCounterfactual(cf)}
              className="p-4 rounded-xl bg-[#0f172a] border border-slate-800 hover:border-[#c5a059]/50 hover:bg-[#141c2b] transition-all cursor-pointer shadow-md space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-[#38bdf8] border border-slate-700">
                  {cf.category}
                </span>
                <span className="text-xs font-mono text-[#c5a059]">Run Hypothesis →</span>
              </div>

              <h4 className="font-serif font-bold text-sm text-[#f3e5ab]">
                "{cf.question}"
              </h4>

              <div className="text-xs font-mono text-emerald-400/90 pt-1 border-t border-slate-800/80">
                Impact: {cf.impactSummary}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
