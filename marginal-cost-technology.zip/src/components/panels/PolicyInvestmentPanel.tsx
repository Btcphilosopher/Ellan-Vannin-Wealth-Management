import React from 'react';
import { EconomicParameters, EquilibriumResult } from '../../types';
import { Sliders, Compass, DollarSign, Percent, ShieldCheck, AlertCircle, Building2 } from 'lucide-react';

interface PolicyInvestmentPanelProps {
  params: EconomicParameters;
  onUpdateParams: (newParams: Partial<EconomicParameters>) => void;
  equilibrium: EquilibriumResult;
}

export const PolicyInvestmentPanel: React.FC<PolicyInvestmentPanelProps> = ({
  params,
  onUpdateParams,
  equilibrium,
}) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Compass className="w-5 h-5 text-[#c5a059]" />
            <h2 className="font-serif font-bold text-base text-[#f3e5ab] uppercase tracking-wider">
              POLICY & INVESTMENT MODE — FISCAL, MONETARY & WELFARE ANALYSIS
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-sans max-w-3xl">
            Test government tax policy, production subsidies, central bank base interest rates, and public infrastructure investments. Observe the resulting division of tax burden, deadweight loss, and net national economic welfare.
          </p>
        </div>

        <div className="bg-[#141c2b] px-4 py-2 rounded-lg border border-[#c5a059]/30 font-mono text-xs text-right">
          <div className="text-slate-400">Deadweight Loss (DWL)</div>
          <div className="text-lg font-bold text-rose-400">
            £{equilibrium.deadweightLoss.toFixed(1)} M
          </div>
        </div>
      </div>

      {/* Welfare Impact Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="text-slate-400 mb-1">Consumer Surplus (CS)</div>
          <div className="text-2xl font-bold text-emerald-400">
            £{equilibrium.consumerSurplus.toFixed(1)} M
          </div>
          <div className="text-[10px] text-slate-500">Buyer net economic benefit</div>
        </div>

        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="text-slate-400 mb-1">Producer Surplus (PS)</div>
          <div className="text-2xl font-bold text-[#38bdf8]">
            £{equilibrium.producerSurplus.toFixed(1)} M
          </div>
          <div className="text-[10px] text-slate-500">Firm net profit above MC</div>
        </div>

        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="text-slate-400 mb-1">Govt Tax Revenue</div>
          <div className="text-2xl font-bold text-amber-400">
            £{equilibrium.taxRevenue.toFixed(1)} M
          </div>
          <div className="text-[10px] text-slate-500">Tax per unit × Q*</div>
        </div>

        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="text-slate-400 mb-1">Total Economic Welfare</div>
          <div className="text-2xl font-bold text-[#f3e5ab]">
            £{(equilibrium.consumerSurplus + equilibrium.producerSurplus + equilibrium.taxRevenue - equilibrium.deadweightLoss).toFixed(1)} M
          </div>
          <div className="text-[10px] text-slate-500">CS + PS + Tax Rev - DWL</div>
        </div>
      </div>

      {/* Policy Interactive Levers */}
      <div className="bg-[#0f172a] p-5 rounded-xl border border-[#c5a059]/30 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-[#c5a059]/20 pb-2">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#c5a059]" />
            <h3 className="font-serif font-bold text-sm text-[#f3e5ab] uppercase tracking-wider">
              FISCAL, MONETARY & INFRASTRUCTURE POLICY LEVERS
            </h3>
          </div>
          <span className="text-xs font-mono text-[#38bdf8]">
            [Live Welfare Distortion Recalculation]
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 text-xs font-mono">
          {/* Excise Tax / Tariff */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold text-slate-300">Unit Excise Tax / Tariff:</span>
              <span className="text-rose-400 font-bold text-sm">
                £{params.taxPerUnit}/unit
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              step="1"
              value={params.taxPerUnit}
              onChange={(e) =>
                onUpdateParams({ taxPerUnit: parseFloat(e.target.value) })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400">
              Shifts effective MC curve upward by tax amount, creating deadweight loss triangle.
            </div>
          </div>

          {/* Production Subsidy */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold text-slate-300">Unit Production Subsidy:</span>
              <span className="text-emerald-400 font-bold text-sm">
                £{params.subsidyPerUnit}/unit
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="40"
              step="1"
              value={params.subsidyPerUnit}
              onChange={(e) =>
                onUpdateParams({ subsidyPerUnit: parseFloat(e.target.value) })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400">
              Direct government subsidy shifting supply curve down to encourage production.
            </div>
          </div>

          {/* Central Bank Interest Rate */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold text-slate-300">Bank Rate Interest (%):</span>
              <span className="text-[#38bdf8] font-bold text-sm">
                {params.interestRate.toFixed(2)}%
              </span>
            </div>
            <input
              type="range"
              min="0.5"
              max="10.0"
              step="0.25"
              value={params.interestRate}
              onChange={(e) =>
                onUpdateParams({
                  interestRate: parseFloat(e.target.value),
                  capitalCostRate: parseFloat((parseFloat(e.target.value) + 1.25).toFixed(2)),
                })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400">
              Central bank base monetary rate dictating capital financing cost for firms.
            </div>
          </div>

          {/* Infrastructure Investment */}
          <div className="bg-[#141c2b] p-4 rounded-lg border border-slate-800 space-y-2">
            <div className="flex justify-between items-center text-slate-200">
              <span className="font-bold text-slate-300">Infrastructure CapEx Spending:</span>
              <span className="text-amber-400 font-bold text-sm">
                £{params.infrastructureInvestment} M
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="500"
              step="10"
              value={params.infrastructureInvestment}
              onChange={(e) =>
                onUpdateParams({
                  infrastructureInvestment: parseFloat(e.target.value),
                  maxCapacity: Math.round(150 + parseFloat(e.target.value) * 0.3),
                })
              }
              className="w-full accent-[#c5a059] cursor-pointer"
            />
            <div className="text-[10px] text-slate-400">
              Public investments in ports, clean energy grids, rail freight, and AI data centers.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
