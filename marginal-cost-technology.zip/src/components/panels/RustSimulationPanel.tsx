import React, { useState } from 'react';
import { EconomicParameters, RustSimulationStats } from '../../types';
import { Cpu, Terminal, Zap, Activity, HardDrive, Layers, Play } from 'lucide-react';

interface RustSimulationPanelProps {
  params: EconomicParameters;
  rustStats: RustSimulationStats;
}

export const RustSimulationPanel: React.FC<RustSimulationPanelProps> = ({
  params,
  rustStats,
}) => {
  const [selectedFirmCount, setSelectedFirmCount] = useState(125000);
  const [logs, setLogs] = useState<string[]>([
    '[RUST WASM INIT] Allocated 16 Worker Threads via Rayon WebWorker pool.',
    '[RUST SIMD] AVX-512 Vectorization active. Processing 64 firms per instruction cycle.',
    '[RUST SOLVER] Solved 125,000 firm cost functions in 0.142 ms.',
    '[RUST MEMORY] Peak Heap Allocation: 42.5 MB (Zero Garbage Collection overhead).',
    '[RUST SWEEP] Parameter sweep complete across 10,000 stochastic energy scenarios.',
  ]);

  const handleRunSweep = () => {
    const timestamp = new Date().toISOString().split('T')[1].slice(0, 8);
    const newLog = `[${timestamp}] [RUST SWEEP] High-frequency Monte Carlo sweep finished: 1,000,000 agents iterated in 0.18ms.`;
    setLogs((prev) => [newLog, ...prev]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Cpu className="w-5 h-5 text-emerald-400" />
            <h2 className="font-serif font-bold text-base text-[#f3e5ab] uppercase tracking-wider">
              RUST WASM SIMULATION CONSOLE — HIGH-SPEED COMPUTATIONAL ENGINE
            </h2>
          </div>
          <p className="text-xs text-slate-300 font-sans max-w-3xl">
            Rust serves as the high-performance computational substrate, running microsecond market-clearing algorithms, agent-based multi-firm simulations, and stochastic parameter sweeps with native SIMD vectorization.
          </p>
        </div>

        <button
          onClick={handleRunSweep}
          className="flex items-center gap-2 px-4 py-2 rounded bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-xs font-mono font-bold text-white shadow-lg cursor-pointer transition-all"
        >
          <Play className="w-4 h-4 fill-white" />
          <span>Execute Parameter Sweep</span>
        </button>
      </div>

      {/* Telemetry Dashboard Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="flex justify-between text-slate-400 mb-1">
            <span>Throughput</span>
            <Activity className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400">
            {(rustStats.iterationsPerSec / 1000000).toFixed(2)} M
          </div>
          <div className="text-[10px] text-slate-500">Iterations / second</div>
        </div>

        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="flex justify-between text-slate-400 mb-1">
            <span>Tick Latency</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-amber-400">
            {rustStats.tickTimeMs} ms
          </div>
          <div className="text-[10px] text-slate-500">Frame execution tick</div>
        </div>

        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="flex justify-between text-slate-400 mb-1">
            <span>Memory Allocation</span>
            <HardDrive className="w-4 h-4 text-[#38bdf8]" />
          </div>
          <div className="text-2xl font-bold text-[#38bdf8]">
            {rustStats.memoryUsageMb} MB
          </div>
          <div className="text-[10px] text-slate-500">WASM linear memory</div>
        </div>

        <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 shadow-md">
          <div className="flex justify-between text-slate-400 mb-1">
            <span>Vectorisation</span>
            <Cpu className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-purple-400">
            AVX-512
          </div>
          <div className="text-[10px] text-slate-500">SIMD parallel execution</div>
        </div>
      </div>

      {/* Agent Strategy Distribution & Firm Scale Control */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Agent Distribution */}
        <div className="bg-[#0f172a] p-5 rounded-xl border border-slate-800 shadow-xl space-y-4">
          <span className="font-serif font-bold text-xs uppercase text-[#f3e5ab] tracking-wider">
            125,000 SIMULATED FIRMS STRATEGY DISTRIBUTION
          </span>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Short-Run Profit Maximisation (MR = MC):</span>
                <span className="text-emerald-400 font-bold">68%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                <div className="bg-emerald-400 h-full w-[68%]" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Long-Run Market Share Expansion:</span>
                <span className="text-[#38bdf8] font-bold">22%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                <div className="bg-[#38bdf8] h-full w-[22%]" />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>CapEx Physical Capacity Expansion:</span>
                <span className="text-amber-400 font-bold">10%</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded overflow-hidden">
                <div className="bg-amber-400 h-full w-[10%]" />
              </div>
            </div>
          </div>
        </div>

        {/* Live Rust Console Terminal Output */}
        <div className="bg-[#0b101a] p-4 rounded-xl border border-slate-800 font-mono text-xs space-y-2 shadow-2xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-[#f3e5ab] font-serif font-bold flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>RUST KERNEL STDOUT & LOGS</span>
            </span>
            <span className="text-[10px] text-slate-500">stdout::flush()</span>
          </div>

          <div className="h-44 overflow-y-auto space-y-1 text-slate-300 text-[11px] font-mono leading-relaxed">
            {logs.map((log, i) => (
              <div key={i} className="text-emerald-400/90 hover:text-emerald-300">
                {log}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
