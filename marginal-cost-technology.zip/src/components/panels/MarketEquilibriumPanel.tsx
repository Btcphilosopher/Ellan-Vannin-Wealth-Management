import React from 'react';
import { EconomicParameters, EquilibriumResult } from '../../types';
import { DraggableSupplyDemandGraph } from '../DraggableSupplyDemandGraph';
import {
  Activity,
  Sliders,
  DollarSign,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  AlertTriangle,
  Info,
} from 'lucide-react';

interface MarketEquilibriumPanelProps {
  params: EconomicParameters;
  onUpdateParams: (newParams: Partial<EconomicParameters>) => void;
  equilibrium: EquilibriumResult;
}

export const MarketEquilibriumPanel: React.FC<MarketEquilibriumPanelProps> = ({
  params,
  onUpdateParams,
  equilibrium,
}) => {
  return (
    <div className="space-y-6">
      {/* Top Main Section: Interactive Graph + Quick Metric Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Graph (Cols 1-8) */}
        <div className="lg:col-span-8">
          <DraggableSupplyDemandGraph
            params={params}
            onUpdateParams={onUpdateParams}
            equilibrium={equilibrium}
          />
        </div>

        {/* Quick Metrics & Elasticity Cards (Cols 9-12) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Market Clearing Status Card */}
          <div className="bg-[#151921] p-4 rounded border border-[#C5A059]/30 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <span className="font-serif text-xs uppercase text-[#C5A059] tracking-[0.15em]">
                MARKET CLEARING STATUS
              </span>
              <span className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-[#0D1117] border border-[#C5A059]/40 text-[#C5A059]">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>PERFECT CLEARING</span>
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="bg-[#0D1117] p-3 rounded border border-[#C5A059]/20">
                <div className="text-[10px] font-mono text-[#F5F2ED]/50 uppercase">P* Equilibrium</div>
                <div className="text-xl font-bold font-mono text-[#F5F2ED]">
                  £{equilibrium.pEquilibrium.toFixed(2)}
                </div>
                <div className="text-[10px] text-[#F5F2ED]/40 mt-0.5">Per unit clearing</div>
              </div>

              <div className="bg-[#0D1117] p-3 rounded border border-[#C5A059]/20">
                <div className="text-[10px] font-mono text-[#F5F2ED]/50 uppercase">Q* Equilibrium</div>
                <div className="text-xl font-bold font-mono text-[#34d399]">
                  {equilibrium.qEquilibrium.toFixed(1)} <span className="text-xs">units</span>
                </div>
                <div className="text-[10px] text-[#F5F2ED]/40 mt-0.5">Physical throughput</div>
              </div>
            </div>

            {/* Consumer & Producer Surplus */}
            <div className="space-y-2 text-xs font-mono border-t border-[#C5A059]/20 pt-3">
              <div className="flex justify-between items-center">
                <span className="text-[#F5F2ED]/60">Consumer Surplus (CS):</span>
                <span className="text-emerald-400 font-bold">
                  £{equilibrium.consumerSurplus.toFixed(1)} M
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#F5F2ED]/60">Producer Surplus (PS):</span>
                <span className="text-[#38bdf8] font-bold">
                  £{equilibrium.producerSurplus.toFixed(1)} M
                </span>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-[#C5A059]/20 font-serif">
                <span className="text-[#C5A059] font-bold">Total Welfare (CS+PS):</span>
                <span className="text-[#C5A059] font-bold">
                  £{(equilibrium.consumerSurplus + equilibrium.producerSurplus).toFixed(1)} M
                </span>
              </div>
            </div>
          </div>

          {/* Elasticity Control & Display */}
          <div className="bg-[#151921] p-4 rounded border border-[#C5A059]/30 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-serif text-xs uppercase text-[#C5A059] tracking-[0.15em]">
                LIVE ELASTICITY COEFFICIENTS
              </span>
              <Activity className="w-4 h-4 text-[#C5A059]" />
            </div>

            <div className="space-y-3 text-xs font-mono">
              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-[#F5F2ED]/70">Price Elasticity of Demand (E_d):</span>
                  <span className="text-emerald-400 font-bold">
                    {equilibrium.elasticityDemandAtEquilibrium.toFixed(2)}
                  </span>
                </div>
                <div className="w-full bg-[#0D1117] h-1.5 rounded overflow-hidden">
                  <div
                    className="bg-emerald-400 h-full transition-all"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.abs(equilibrium.elasticityDemandAtEquilibrium) * 50
                      )}%`,
                    }}
                  />
                </div>
                <div className="text-[10px] text-[#F5F2ED]/40 mt-1">
                  {Math.abs(equilibrium.elasticityDemandAtEquilibrium) > 1
                    ? 'Elastic Demand (Consumers sensitive to price)'
                    : 'Inelastic Demand (Essential commodity response)'}
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-1">
                  <span className="text-[#F5F2ED]/70">Price Elasticity of Supply (E_s):</span>
                  <span className="text-[#38bdf8] font-bold">
                    {equilibrium.elasticitySupplyAtEquilibrium.toFixed(2)}
                  </span>
                </div>
                <div className="w-full bg-[#0D1117] h-1.5 rounded overflow-hidden">
                  <div
                    className="bg-[#38bdf8] h-full transition-all"
                    style={{
                      width: `${Math.min(
                        100,
                        equilibrium.elasticitySupplyAtEquilibrium * 50
                      )}%`,
                    }}
                  />
                </div>
                <div className="text-[10px] text-[#F5F2ED]/40 mt-1">
                  Driven by capacity tightness and variable cost structure
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Demand & Supply Parameter Interactive Controls */}
      <div className="bg-[#151921] p-5 rounded border border-[#C5A059]/30 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-[#C5A059]/20 pb-2">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#C5A059]" />
            <h3 className="font-serif text-xs uppercase tracking-[0.2em] text-[#C5A059]">
              DEMAND & MARKET PARAMETER INTERACTIVE LEVERS
            </h3>
          </div>
          <span className="text-[10px] font-mono text-[#F5F2ED]/50 uppercase tracking-wider">
            [Instant Recalculation]
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono">
          {/* Demand Intercept */}
          <div className="bg-[#0D1117] p-3 rounded border border-[#C5A059]/20 space-y-2">
            <div className="flex justify-between text-[#F5F2ED]/80">
              <span>Demand Willingness (A):</span>
              <span className="text-[#34d399] font-bold">£{params.demandIntercept}</span>
            </div>
            <input
              type="range"
              min="120"
              max="380"
              step="5"
              value={params.demandIntercept}
              onChange={(e) =>
                onUpdateParams({ demandIntercept: parseFloat(e.target.value) })
              }
              className="w-full accent-[#C5A059] cursor-pointer"
            />
            <div className="text-[10px] text-[#F5F2ED]/40">Shifts demand curve vertically</div>
          </div>

          {/* Income Index */}
          <div className="bg-[#0D1117] p-3 rounded border border-[#C5A059]/20 space-y-2">
            <div className="flex justify-between text-[#F5F2ED]/80">
              <span>Income Factor (Y):</span>
              <span className="text-[#34d399] font-bold">{params.incomeFactor} idx</span>
            </div>
            <input
              type="range"
              min="50"
              max="200"
              step="5"
              value={params.incomeFactor}
              onChange={(e) =>
                onUpdateParams({ incomeFactor: parseFloat(e.target.value) })
              }
              className="w-full accent-[#C5A059] cursor-pointer"
            />
            <div className="text-[10px] text-[#F5F2ED]/40">Macro purchasing power impact</div>
          </div>

          {/* Demand Slope */}
          <div className="bg-[#0D1117] p-3 rounded border border-[#C5A059]/20 space-y-2">
            <div className="flex justify-between text-[#F5F2ED]/80">
              <span>Demand Slope (b):</span>
              <span className="text-[#34d399] font-bold">{params.demandSlope.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.4"
              max="2.5"
              step="0.1"
              value={params.demandSlope}
              onChange={(e) =>
                onUpdateParams({ demandSlope: parseFloat(e.target.value) })
              }
              className="w-full accent-[#C5A059] cursor-pointer"
            />
            <div className="text-[10px] text-[#F5F2ED]/40">Price sensitivity of buyers</div>
          </div>

          {/* Expected Future Price */}
          <div className="bg-[#0D1117] p-3 rounded border border-[#C5A059]/20 space-y-2">
            <div className="flex justify-between text-[#F5F2ED]/80">
              <span>Expected Future Price:</span>
              <span className="text-[#38bdf8] font-bold">£{params.expectedFuturePrice}</span>
            </div>
            <input
              type="range"
              min="50"
              max="220"
              step="5"
              value={params.expectedFuturePrice}
              onChange={(e) =>
                onUpdateParams({ expectedFuturePrice: parseFloat(e.target.value) })
              }
              className="w-full accent-[#C5A059] cursor-pointer"
            />
            <div className="text-[10px] text-[#F5F2ED]/40">Speculative producer holding effect</div>
          </div>
        </div>
      </div>
    </div>
  );
};
