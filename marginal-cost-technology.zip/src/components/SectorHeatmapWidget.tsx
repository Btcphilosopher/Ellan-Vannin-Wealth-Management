import React from 'react';
import { SectorData } from '../types';
import { Zap, Cpu, Server, Truck, Factory, Building2, Sprout, Dna, Activity, TrendingUp, TrendingDown } from 'lucide-react';

interface SectorHeatmapWidgetProps {
  sectors: SectorData[];
}

export const SectorHeatmapWidget: React.FC<SectorHeatmapWidgetProps> = ({ sectors }) => {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Zap': return Zap;
      case 'Cpu': return Cpu;
      case 'Server': return Server;
      case 'Truck': return Truck;
      case 'Factory': return Factory;
      case 'Building2': return Building2;
      case 'Sprout': return Sprout;
      case 'Dna': return Dna;
      default: return Activity;
    }
  };

  return (
    <div className="bg-[#151921] p-5 rounded border border-[#C5A059]/30 shadow-xl space-y-4">
      <div className="flex items-center justify-between border-b border-[#C5A059]/20 pb-2">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-[#C5A059]" />
          <h3 className="font-serif text-xs uppercase tracking-[0.2em] text-[#C5A059]">
            SOVEREIGN INDUSTRIAL SECTOR MARGINAL COST HEATMAP
          </h3>
        </div>
        <span className="text-[10px] font-mono text-[#F5F2ED]/50 uppercase tracking-widest">
          [8 INDUSTRIAL SECTORS]
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
        {sectors.map((sec) => {
          const Icon = getIcon(sec.iconName);
          const isDeflating = sec.costTrendPct < 0;

          return (
            <div
              key={sec.id}
              className="p-3.5 rounded bg-[#0D1117] border border-[#C5A059]/20 hover:border-[#C5A059]/50 transition-all flex flex-col justify-between space-y-2 shadow"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Icon className="w-4 h-4 text-[#C5A059]" />
                  <span className="font-serif font-bold text-xs text-[#F5F2ED] truncate max-w-[120px]">
                    {sec.name}
                  </span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#151921] text-[#C5A059] border border-[#C5A059]/30">
                  {sec.techIntensity}
                </span>
              </div>

              <div>
                <div className="text-[10px] text-[#F5F2ED]/50 uppercase tracking-wider">Marginal Cost:</div>
                <div className="flex items-baseline justify-between mt-0.5">
                  <span className="text-base font-bold text-[#F5F2ED]">
                    £{sec.marginalCost.toFixed(1)}/u
                  </span>
                  <span
                    className={`flex items-center gap-0.5 text-[11px] font-bold ${
                      isDeflating ? 'text-[#34d399]' : 'text-amber-400'
                    }`}
                  >
                    {isDeflating ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
                    {sec.costTrendPct > 0 ? '+' : ''}
                    {sec.costTrendPct.toFixed(1)}%
                  </span>
                </div>
              </div>

              {/* Utilisation Bar */}
              <div className="pt-1">
                <div className="flex justify-between text-[10px] text-[#F5F2ED]/50 mb-1">
                  <span>Capacity Util:</span>
                  <span className={sec.capacityUtilisation > 90 ? 'text-amber-400' : 'text-emerald-400'}>
                    {sec.capacityUtilisation.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-[#151921] h-1.5 rounded overflow-hidden">
                  <div
                    className={`h-full ${
                      sec.capacityUtilisation > 90 ? 'bg-amber-400' : 'bg-[#C5A059]'
                    }`}
                    style={{ width: `${Math.min(100, sec.capacityUtilisation)}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
