import React, { useState, useRef } from 'react';
import { EconomicParameters, EquilibriumResult } from '../types';
import {
  generateCurvePoints,
  calculateDemandPrice,
  calculateMarginalCost,
  calculateATC,
  calculateAVC,
  calculateMarginalRevenue,
} from '../engine/economicEngine';
import { Layers, Eye, EyeOff, Sparkles, Move, Info } from 'lucide-react';

interface DraggableGraphProps {
  params: EconomicParameters;
  onUpdateParams: (newParams: Partial<EconomicParameters>) => void;
  equilibrium: EquilibriumResult;
}

export const DraggableSupplyDemandGraph: React.FC<DraggableGraphProps> = ({
  params,
  onUpdateParams,
  equilibrium,
}) => {
  const [showATC, setShowATC] = useState(true);
  const [showAVC, setShowAVC] = useState(false);
  const [showMR, setShowMR] = useState(false);
  const [showSurplusShading, setShowSurplusShading] = useState(true);
  const [hoveredPoint, setHoveredPoint] = useState<{ q: number; p: number } | null>(null);

  const svgRef = useRef<SVGSVGElement | null>(null);
  const [isDraggingDemand, setIsDraggingDemand] = useState(false);
  const [isDraggingSupply, setIsDraggingSupply] = useState(false);

  // Graph Canvas Dimensions
  const width = 720;
  const height = 440;
  const margin = { top: 30, right: 40, bottom: 50, left: 60 };
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;

  const maxQ = params.maxCapacity * 1.15;
  const maxP = 280;

  // Scale functions
  const scaleX = (q: number) => margin.left + (q / maxQ) * innerWidth;
  const scaleY = (p: number) =>
    margin.top + innerHeight - (Math.min(maxP, Math.max(0, p)) / maxP) * innerHeight;

  const invertX = (pixelX: number) => {
    const relativeX = pixelX - margin.left;
    return Math.max(0, Math.min(maxQ, (relativeX / innerWidth) * maxQ));
  };

  const invertY = (pixelY: number) => {
    const relativeY = margin.top + innerHeight - pixelY;
    return Math.max(0, Math.min(maxP, (relativeY / innerHeight) * maxP));
  };

  const curvePoints = generateCurvePoints(params, 80);

  // SVG Path Generators
  const generatePath = (getValue: (q: number) => number) => {
    let path = '';
    const steps = 80;
    for (let i = 1; i <= steps; i++) {
      const q = (i / steps) * maxQ;
      const p = getValue(q);
      const x = scaleX(q);
      const y = scaleY(p);
      if (i === 1) {
        path += `M ${x} ${y}`;
      } else {
        path += ` L ${x} ${y}`;
      }
    }
    return path;
  };

  const demandPath = generatePath((q) => calculateDemandPrice(q, params));
  const mcPath = generatePath((q) => calculateMarginalCost(q, params));
  const atcPath = generatePath((q) => calculateATC(q, params));
  const avcPath = generatePath((q) => calculateAVC(q, params));
  const mrPath = generatePath((q) => calculateMarginalRevenue(q, params));

  // Shaded Polygon for Consumer Surplus (CS)
  const generateCSPolygon = () => {
    const { qEquilibrium, pEquilibrium } = equilibrium;
    const steps = 40;
    let pointsStr = `${scaleX(0)},${scaleY(pEquilibrium)} `;
    for (let i = 0; i <= steps; i++) {
      const q = (i / steps) * qEquilibrium;
      const p = calculateDemandPrice(q, params);
      pointsStr += `${scaleX(q)},${scaleY(p)} `;
    }
    pointsStr += `${scaleX(qEquilibrium)},${scaleY(pEquilibrium)}`;
    return pointsStr;
  };

  // Shaded Polygon for Producer Surplus (PS)
  const generatePSPolygon = () => {
    const { qEquilibrium, pEquilibrium } = equilibrium;
    const steps = 40;
    let pointsStr = `${scaleX(0)},${scaleY(pEquilibrium)} `;
    for (let i = 0; i <= steps; i++) {
      const q = (i / steps) * qEquilibrium;
      const p = calculateMarginalCost(q, params);
      pointsStr += `${scaleX(q)},${scaleY(p)} `;
    }
    pointsStr += `${scaleX(qEquilibrium)},${scaleY(pEquilibrium)}`;
    return pointsStr;
  };

  // Mouse drag handlers for direct curve manipulation
  const handleMouseDownDemand = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDraggingDemand(true);
  };

  const handleMouseDownSupply = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDraggingSupply(true);
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const qVal = invertX(mouseX);
    const pVal = invertY(mouseY);

    setHoveredPoint({ q: qVal, p: pVal });

    if (isDraggingDemand) {
      // Adjust demand intercept based on mouse Y offset
      const newIntercept = Math.max(120, Math.min(380, pVal + params.demandSlope * qVal));
      onUpdateParams({ demandIntercept: newIntercept });
    } else if (isDraggingSupply) {
      // Adjust productivity tau based on mouse Y offset
      const newTau = Math.max(0.4, Math.min(2.5, 80 / Math.max(10, pVal)));
      onUpdateParams({ productivityFactor: newTau });
    }
  };

  const handleMouseUp = () => {
    setIsDraggingDemand(false);
    setIsDraggingSupply(false);
  };

  const eqX = scaleX(equilibrium.qEquilibrium);
  const eqY = scaleY(equilibrium.pEquilibrium);

  return (
    <div className="bg-[#0f172a] p-4 rounded-xl border border-[#c5a059]/40 shadow-2xl relative">
      {/* Top Graph Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2 border-b border-[#c5a059]/20">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#c5a059] shadow-gold" />
          <h3 className="font-serif font-bold text-sm text-[#f3e5ab] uppercase tracking-wider">
            REACTIVE S × D × MC EQUILIBRIUM OBSERVATORY
          </h3>
          <span className="text-[11px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
            [Direct Curve Dragging Enabled]
          </span>
        </div>

        {/* Visibility Toggles */}
        <div className="flex items-center gap-2 text-xs font-mono">
          <button
            onClick={() => setShowATC(!showATC)}
            className={`px-2 py-1 rounded border transition-all cursor-pointer ${
              showATC
                ? 'bg-amber-950/60 border-amber-500/60 text-amber-300'
                : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            ATC (Average Total)
          </button>
          <button
            onClick={() => setShowAVC(!showAVC)}
            className={`px-2 py-1 rounded border transition-all cursor-pointer ${
              showAVC
                ? 'bg-purple-950/60 border-purple-500/60 text-purple-300'
                : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            AVC (Average Variable)
          </button>
          <button
            onClick={() => setShowMR(!showMR)}
            className={`px-2 py-1 rounded border transition-all cursor-pointer ${
              showMR
                ? 'bg-rose-950/60 border-rose-500/60 text-rose-300'
                : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            MR (Marginal Revenue)
          </button>
          <button
            onClick={() => setShowSurplusShading(!showSurplusShading)}
            className={`px-2 py-1 rounded border transition-all cursor-pointer ${
              showSurplusShading
                ? 'bg-[#c5a059]/20 border-[#c5a059] text-[#f3e5ab]'
                : 'bg-slate-800/60 border-slate-700 text-slate-400'
            }`}
          >
            Surplus Areas
          </button>
        </div>
      </div>

      {/* Main Interactive SVG Canvas */}
      <div className="relative w-full overflow-hidden rounded bg-[#0b101a] border border-[#c5a059]/20 shadow-inner">
        <svg
          ref={svgRef}
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto cursor-crosshair select-none"
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => {
            handleMouseUp();
            setHoveredPoint(null);
          }}
        >
          {/* Background Grid Lines */}
          <g className="opacity-15">
            {[0.25, 0.5, 0.75, 1.0].map((ratio) => {
              const x = margin.left + ratio * innerWidth;
              const y = margin.top + ratio * innerHeight;
              return (
                <g key={ratio}>
                  <line
                    x1={x}
                    y1={margin.top}
                    x2={x}
                    y2={margin.top + innerHeight}
                    stroke="#c5a059"
                    strokeWidth="1"
                    strokeDasharray="4 4"
                  />
                  <line
                    x1={margin.left}
                    y1={y}
                    x2={margin.left + innerWidth}
                    y2={y}
                    stroke="#c5a059"
                    strokeWidth="1"
                    strokeDasharray="4 4"
                  />
                </g>
              );
            })}
          </g>

          {/* Shaded Surplus Areas */}
          {showSurplusShading && (
            <g className="transition-opacity duration-300">
              {/* Consumer Surplus CS (Green) */}
              <polygon
                points={generateCSPolygon()}
                fill="#34d399"
                fillOpacity="0.15"
                stroke="#34d399"
                strokeWidth="1"
                strokeDasharray="2 2"
              />
              {/* Producer Surplus PS (Blue) */}
              <polygon
                points={generatePSPolygon()}
                fill="#38bdf8"
                fillOpacity="0.15"
                stroke="#38bdf8"
                strokeWidth="1"
                strokeDasharray="2 2"
              />
            </g>
          )}

          {/* Axes */}
          <line
            x1={margin.left}
            y1={margin.top + innerHeight}
            x2={margin.left + innerWidth}
            y2={margin.top + innerHeight}
            stroke="#c5a059"
            strokeWidth="2"
          />
          <line
            x1={margin.left}
            y1={margin.top}
            x2={margin.left}
            y2={margin.top + innerHeight}
            stroke="#c5a059"
            strokeWidth="2"
          />

          {/* Axis Labels */}
          <text
            x={margin.left + innerWidth / 2}
            y={height - 12}
            fill="#f3e5ab"
            fontSize="12"
            fontFamily="Cinzel, serif"
            textAnchor="middle"
            fontWeight="bold"
          >
            QUANTITY PRODUCED & DEMANDED (Q)
          </text>
          <text
            x={18}
            y={margin.top + innerHeight / 2}
            fill="#f3e5ab"
            fontSize="12"
            fontFamily="Cinzel, serif"
            textAnchor="middle"
            fontWeight="bold"
            transform={`rotate(-90 18 ${margin.top + innerHeight / 2})`}
          >
            PRICE / UNIT COST (£/unit)
          </text>

          {/* Optional Curves: ATC, AVC, MR */}
          {showATC && (
            <path
              d={atcPath}
              fill="none"
              stroke="#f59e0b"
              strokeWidth="2"
              strokeDasharray="5 3"
              className="opacity-80 hover:opacity-100 transition-opacity"
            />
          )}

          {showAVC && (
            <path
              d={avcPath}
              fill="none"
              stroke="#c084fc"
              strokeWidth="2"
              strokeDasharray="4 4"
              className="opacity-80"
            />
          )}

          {showMR && (
            <path
              d={mrPath}
              fill="none"
              stroke="#f43f5e"
              strokeWidth="2"
              strokeDasharray="2 2"
              className="opacity-80"
            />
          )}

          {/* DEMAND CURVE (Draggable) */}
          <g onMouseDown={handleMouseDownDemand} className="cursor-grab active:cursor-grabbing">
            <path
              d={demandPath}
              fill="none"
              stroke="#34d399"
              strokeWidth="3.5"
              className="hover:stroke-emerald-300 transition-all filter drop-shadow-[0_0_8px_rgba(52,211,153,0.5)]"
            />
            {/* Demand Label */}
            <text
              x={scaleX(params.maxCapacity * 0.82)}
              y={scaleY(calculateDemandPrice(params.maxCapacity * 0.82, params)) - 10}
              fill="#34d399"
              fontSize="12"
              fontWeight="bold"
              fontFamily="JetBrains Mono, monospace"
            >
              DEMAND (D)
            </text>
          </g>

          {/* SUPPLY / MARGINAL COST CURVE (Draggable) */}
          <g onMouseDown={handleMouseDownSupply} className="cursor-grab active:cursor-grabbing">
            <path
              d={mcPath}
              fill="none"
              stroke="#38bdf8"
              strokeWidth="3.5"
              className="hover:stroke-sky-300 transition-all filter drop-shadow-[0_0_8px_rgba(56,189,248,0.5)]"
            />
            {/* MC Label */}
            <text
              x={scaleX(params.maxCapacity * 0.72)}
              y={scaleY(calculateMarginalCost(params.maxCapacity * 0.72, params)) - 10}
              fill="#38bdf8"
              fontSize="12"
              fontWeight="bold"
              fontFamily="JetBrains Mono, monospace"
            >
              SUPPLY = MC
            </text>
          </g>

          {/* EQUILIBRIUM CROSSHAIR & ANNOTATIONS */}
          <g>
            {/* Horizontal line to P* */}
            <line
              x1={margin.left}
              y1={eqY}
              x2={eqX}
              y2={eqY}
              stroke="#c5a059"
              strokeWidth="1.5"
              strokeDasharray="3 3"
            />
            {/* Vertical line to Q* */}
            <line
              x1={eqX}
              y1={eqY}
              x2={eqX}
              y2={margin.top + innerHeight}
              stroke="#c5a059"
              strokeWidth="1.5"
              strokeDasharray="3 3"
            />

            {/* P* Axis Label */}
            <rect
              x={margin.left - 52}
              y={eqY - 10}
              width="48"
              height="20"
              rx="3"
              fill="#1e293b"
              stroke="#c5a059"
              strokeWidth="1"
            />
            <text
              x={margin.left - 28}
              y={eqY + 4}
              fill="#f3e5ab"
              fontSize="10"
              fontWeight="bold"
              fontFamily="JetBrains Mono, monospace"
              textAnchor="middle"
            >
              £{equilibrium.pEquilibrium.toFixed(1)}
            </text>

            {/* Q* Axis Label */}
            <rect
              x={eqX - 25}
              y={margin.top + innerHeight + 4}
              width="50"
              height="20"
              rx="3"
              fill="#1e293b"
              stroke="#c5a059"
              strokeWidth="1"
            />
            <text
              x={eqX}
              y={margin.top + innerHeight + 18}
              fill="#f3e5ab"
              fontSize="10"
              fontWeight="bold"
              fontFamily="JetBrains Mono, monospace"
              textAnchor="middle"
            >
              {equilibrium.qEquilibrium.toFixed(1)}u
            </text>

            {/* Pulsing Equilibrium Node */}
            <circle
              cx={eqX}
              cy={eqY}
              r="8"
              fill="#c5a059"
              className="animate-ping opacity-75"
            />
            <circle
              cx={eqX}
              cy={eqY}
              r="6"
              fill="#d4af37"
              stroke="#0b101a"
              strokeWidth="2"
            />

            {/* Callout Box */}
            <g transform={`translate(${Math.min(width - 180, eqX + 15)}, ${Math.max(margin.top + 20, eqY - 45)})`}>
              <rect
                width="165"
                height="45"
                rx="6"
                fill="#141c2b"
                fillOpacity="0.95"
                stroke="#c5a059"
                strokeWidth="1.5"
                className="filter drop-shadow-lg"
              />
              <text
                x="8"
                y="16"
                fill="#f3e5ab"
                fontSize="11"
                fontWeight="bold"
                fontFamily="Cinzel, serif"
              >
                EQUILIBRIUM POINT E*
              </text>
              <text
                x="8"
                y="32"
                fill="#38bdf8"
                fontSize="10"
                fontFamily="JetBrains Mono, monospace"
              >
                P* = £{equilibrium.pEquilibrium.toFixed(2)} | Q* = {equilibrium.qEquilibrium.toFixed(1)}u
              </text>
            </g>
          </g>

          {/* Interactive Hover Point Cursor */}
          {hoveredPoint && (
            <g>
              <circle
                cx={scaleX(hoveredPoint.q)}
                cy={scaleY(hoveredPoint.p)}
                r="4"
                fill="#38bdf8"
              />
            </g>
          )}
        </svg>

        {/* Floating Tooltip info on hover */}
        {hoveredPoint && (
          <div className="absolute top-3 left-3 bg-[#141c2b]/90 border border-[#c5a059]/40 backdrop-blur px-3 py-1.5 rounded text-xs font-mono text-slate-200 shadow-xl pointer-events-none">
            <div>
              Cursor: Q = <span className="text-[#34d399] font-bold">{hoveredPoint.q.toFixed(1)}</span>, P = <span className="text-[#38bdf8] font-bold">£{hoveredPoint.p.toFixed(2)}</span>
            </div>
            <div className="text-[10px] text-slate-400">
              Demand(Q): £{calculateDemandPrice(hoveredPoint.q, params).toFixed(2)} | MC(Q): £{calculateMarginalCost(hoveredPoint.q, params).toFixed(2)}
            </div>
          </div>
        )}
      </div>

      {/* Graph Legend & Instructions */}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-slate-400">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-1 rounded bg-[#34d399]" />
            <span>Demand (Green)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-1 rounded bg-[#38bdf8]" />
            <span>Supply / MC (Blue)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-1 rounded bg-[#f59e0b]" />
            <span>ATC (Gold)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-3.5 rounded bg-[#34d399]/20 border border-[#34d399]/40" />
            <span>CS (Consumer Surplus)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-3.5 rounded bg-[#38bdf8]/20 border border-[#38bdf8]/40" />
            <span>PS (Producer Surplus)</span>
          </div>
        </div>
        <div className="text-[11px] text-[#f3e5ab]/80 font-serif italic">
          💡 Click and drag the Demand or Supply line directly to shift economic conditions.
        </div>
      </div>
    </div>
  );
};
