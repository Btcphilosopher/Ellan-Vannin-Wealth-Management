import React from 'react';
import { X, Workflow, Cpu, Code2, ArrowRightLeft, Layers, Zap, HardDrive } from 'lucide-react';

interface RustRArchDiagramProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RustRArchitectureDiagram: React.FC<RustRArchDiagramProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#0D1117]/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#0D1117] border border-[#C5A059] rounded-none max-w-4xl w-full p-6 shadow-2xl space-y-6 relative max-h-[90vh] overflow-y-auto text-[#F5F2ED]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded bg-[#151921] hover:bg-[#C5A059] hover:text-black text-[#C5A059] border border-[#C5A059]/30 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 border-b border-[#C5A059]/30 pb-4">
          <div className="p-2.5 bg-[#151921] border border-[#C5A059] text-[#C5A059]">
            <Workflow className="w-6 h-6 text-[#C5A059]" />
          </div>
          <div>
            <h2 className="font-serif font-light text-lg text-[#C5A059] uppercase tracking-[0.2em]">
              DUAL COMPUTATIONAL ENGINE ARCHITECTURE: RUST &times; R
            </h2>
            <p className="text-xs text-[#F5F2ED]/70 font-sans tracking-wide">
              Boundary mapping high-speed WASM execution with analytical R statistical models.
            </p>
          </div>
        </div>

        {/* Architecture Flow Diagram */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          {/* Box 1: Rust Engine */}
          <div className="bg-[#151921] p-4 rounded border border-[#C5A059]/30 shadow-lg space-y-3">
            <div className="flex items-center justify-between border-b border-[#C5A059]/20 pb-2">
              <span className="font-serif font-bold text-[#C5A059] flex items-center gap-1.5">
                <Cpu className="w-4 h-4" />
                <span>1. RUST ENGINE (WASM)</span>
              </span>
              <span className="text-[10px] text-[#C5A059] px-2 py-0.5 rounded bg-[#0D1117] border border-[#C5A059]/30">
                0.14 ms / tick
              </span>
            </div>

            <p className="text-[11px] text-[#F5F2ED]/80 font-sans leading-relaxed">
              High-performance simulation substrate written in Rust. Compiles to WebAssembly with SIMD AVX-512 instructions.
            </p>

            <ul className="space-y-1.5 text-[11px] text-[#F5F2ED]/70 list-disc list-inside font-mono">
              <li>125,000 Firm Agent Simulations</li>
              <li>Microsecond Equilibrium Solver</li>
              <li>Parameter Sweep Engine</li>
              <li>Zero Garbage Collection Overhead</li>
            </ul>
          </div>

          {/* Box 2: Shared Memory & Reactive Bus */}
          <div className="bg-[#151921] p-4 rounded border border-[#C5A059]/40 shadow-lg space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-[#C5A059]/20 pb-2">
                <span className="font-serif font-bold text-[#C5A059] flex items-center gap-1.5">
                  <ArrowRightLeft className="w-4 h-4 text-[#C5A059]" />
                  <span>2. SHARED BUS & STATE</span>
                </span>
                <span className="text-[10px] text-black px-2 py-0.5 rounded bg-[#C5A059] font-bold">
                  ArrayBuffer
                </span>
              </div>

              <p className="text-[11px] text-[#F5F2ED]/80 font-sans leading-relaxed my-2">
                Zero-copy SharedArrayBuffer memory bridge transferring parameter deltas between Rust worker threads and React UI state.
              </p>
            </div>

            <div className="p-2.5 rounded bg-[#0D1117] border border-[#C5A059]/20 text-[10px] text-[#38bdf8]">
              [Rust Thread Pool] &harr; [Float64 ArrayBuffer] &harr; [R Workstation Engine]
            </div>
          </div>

          {/* Box 3: R Econometrics Workspace */}
          <div className="bg-[#151921] p-4 rounded border border-[#C5A059]/30 shadow-lg space-y-3">
            <div className="flex items-center justify-between border-b border-[#C5A059]/20 pb-2">
              <span className="font-serif font-bold text-[#C5A059] flex items-center gap-1.5">
                <Code2 className="w-4 h-4" />
                <span>3. R WORKSPACE</span>
              </span>
              <span className="text-[10px] text-[#C5A059] px-2 py-0.5 rounded bg-[#0D1117] border border-[#C5A059]/30">
                R stats::lm()
              </span>
            </div>

            <p className="text-[11px] text-[#F5F2ED]/80 font-sans leading-relaxed">
              Analytical and econometric layer executing log-linear regression models, elasticity estimations, and ARIMA forecasts.
            </p>

            <ul className="space-y-1.5 text-[11px] text-[#F5F2ED]/70 list-disc list-inside font-mono">
              <li>OLS &amp; IV Regressions</li>
              <li>Confidence Intervals &amp; t-stats</li>
              <li>ARIMA Time-Series Forecasts</li>
              <li>Monte Carlo Risk Distributions</li>
            </ul>
          </div>
        </div>

        {/* Footer info */}
        <div className="pt-3 border-t border-[#C5A059]/30 flex justify-between items-center text-xs font-mono text-[#F5F2ED]/60">
          <span className="uppercase tracking-widest text-[10px]">SOVEREIGN ECONOMIC COMPUTATION UNIT</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-[#C5A059] text-black font-bold hover:bg-[#d4af37] cursor-pointer transition-all uppercase tracking-wider text-[11px]"
          >
            Close Diagram
          </button>
        </div>
      </div>
    </div>
  );
};
