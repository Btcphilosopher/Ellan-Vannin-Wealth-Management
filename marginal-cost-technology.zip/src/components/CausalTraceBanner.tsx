import React, { useState } from 'react';
import { CausalTraceStep } from '../types';
import {
  ArrowRight,
  GitCommit,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Zap,
  CheckCircle2,
  AlertCircle,
  Binary,
} from 'lucide-react';

interface CausalTraceBannerProps {
  steps: CausalTraceStep[];
}

export const CausalTraceBanner: React.FC<CausalTraceBannerProps> = ({
  steps,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-[#151921] border-b border-[#C5A059]/30 text-[#F5F2ED] px-4 py-2.5 shadow-lg">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Header Label */}
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 border border-[#C5A059] flex items-center justify-center text-[#C5A059]">
              <GitCommit className="w-3 h-3 text-[#C5A059]" />
            </div>
            <span className="font-serif text-xs uppercase tracking-[0.15em] text-[#C5A059]">
              CAUSAL PATHWAY TRACE:
            </span>
            <span className="text-[10px] text-[#F5F2ED]/50 font-mono tracking-wider hidden sm:inline uppercase">
              [REACTIVE TRANSMISSION]
            </span>
          </div>

          {/* Inline Step Sequence */}
          <div className="flex-1 flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1">
            {steps.map((step, idx) => {
              const isUp = step.direction === 'up';
              const isDown = step.direction === 'down';
              return (
                <React.Fragment key={step.id}>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#0D1117] border border-[#C5A059]/20 whitespace-nowrap text-xs font-mono shadow-sm">
                    <span className="text-[#F5F2ED] font-semibold">
                      {step.variable}
                    </span>
                    <span
                      className={`font-bold ${
                        isUp
                          ? 'text-amber-400'
                          : isDown
                          ? 'text-[#38bdf8]'
                          : 'text-emerald-400'
                      }`}
                    >
                      {step.changeText}
                    </span>
                  </div>
                  {idx < steps.length - 1 && (
                    <ArrowRight className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                  )}
                </React.Fragment>
              );
            })}
          </div>

          {/* Expand Toggle */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1 text-xs font-mono text-[#C5A059] hover:bg-[#C5A059]/10 bg-[#0D1117] px-3 py-1 rounded border border-[#C5A059]/40 transition-all cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>Why Did This Change?</span>
            {isExpanded ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5" />
            )}
          </button>
        </div>

        {/* Expanded Detailed Trace View */}
        {isExpanded && (
          <div className="mt-3 pt-3 border-t border-[#C5A059]/20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 animate-fadeIn">
            {steps.map((step, idx) => (
              <div
                key={step.id}
                className="bg-[#0D1117] p-3 rounded border border-[#C5A059]/25 shadow-md flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-[10px] font-mono text-[#C5A059] px-1.5 py-0.5 rounded bg-[#C5A059]/10 border border-[#C5A059]/30">
                      STAGE 0{idx + 1}
                    </span>
                    <span className="text-xs font-mono text-[#F5F2ED]/60">
                      {step.impactValue}
                    </span>
                  </div>
                  <h4 className="font-serif font-bold text-sm text-[#C5A059] mb-1">
                    {step.variable}
                  </h4>
                  <p className="text-xs text-[#F5F2ED]/80 leading-relaxed mb-2 font-sans">
                    {step.explanation}
                  </p>
                </div>

                {step.equationText && (
                  <div className="mt-2 p-2 rounded bg-[#151921] border border-[#C5A059]/20 font-mono text-[11px] text-[#38bdf8] flex items-center gap-2">
                    <Binary className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                    <span>{step.equationText}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
