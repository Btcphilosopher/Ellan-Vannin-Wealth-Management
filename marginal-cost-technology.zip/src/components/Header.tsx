import React from 'react';
import {
  EquilibriumResult,
  RustSimulationStats,
  ScenarioPreset,
} from '../types';
import {
  Cpu,
  BarChart3,
  RotateCcw,
  Volume2,
  VolumeX,
  Layers,
  Sparkles,
  ShieldAlert,
  ArrowRightLeft,
  Activity,
  Code2,
  Workflow,
  Compass,
} from 'lucide-react';

interface HeaderProps {
  equilibrium: EquilibriumResult;
  rustStats: RustSimulationStats;
  activeScenario: ScenarioPreset | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onResetBaseline: () => void;
  audioEnabled: boolean;
  setAudioEnabled: (val: boolean) => void;
  onOpenArchDiagram: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  equilibrium,
  rustStats,
  activeScenario,
  activeTab,
  setActiveTab,
  onResetBaseline,
  audioEnabled,
  setAudioEnabled,
  onOpenArchDiagram,
}) => {
  const tabs = [
    { id: 'equilibrium', label: '1. Market Equilibrium', icon: Activity },
    { id: 'mc-engine', label: '2. Marginal Cost Engine', icon: BarChart3 },
    { id: 'tech-frontier', label: '3. Technology Frontier', icon: Sparkles },
    { id: 'supply-chain', label: '4. Supply Chain Matrix', icon: Layers },
    { id: 'capacity', label: '5. Capacity & Utilisation', icon: Cpu },
    { id: 'price-discovery', label: '6. Price Discovery', icon: ArrowRightLeft },
    { id: 'r-econometrics', label: '7. Econometrics (R)', icon: BarChart3 },
    { id: 'rust-sim', label: '8. Simulation (Rust)', icon: Cpu },
    { id: 'scenarios', label: '9. Scenario Laboratory', icon: ShieldAlert },
    { id: 'policy', label: '10. Policy & Welfare', icon: Compass },
  ];

  return (
    <header className="bg-[#0D1117] border-b border-[#C5A059]/30 text-[#F5F2ED] sticky top-0 z-40 shadow-2xl">
      {/* Top Sovereign Bar */}
      <div className="max-w-7xl mx-auto px-6 py-3 flex flex-wrap items-center justify-between gap-4 border-b border-[#C5A059]/15">
        {/* Left: Crest & Title */}
        <div className="flex items-center space-x-4">
          <div className="w-8 h-8 border-2 border-[#C5A059] rotate-45 flex items-center justify-center shrink-0">
            <div className="w-4 h-4 bg-[#C5A059]"></div>
          </div>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="font-serif text-xl sm:text-2xl font-light tracking-[0.2em] text-[#C5A059] uppercase">
                MARGINAL COST TECHNOLOGY
              </h1>
              <span className="text-[10px] tracking-[0.2em] px-2 py-0.5 rounded bg-[#C5A059]/15 border border-[#C5A059]/30 text-[#C5A059] font-mono uppercase">
                SOVEREIGN LAB
              </span>
            </div>
            <p className="text-[10px] text-[#F5F2ED]/60 font-sans tracking-[0.2em] uppercase mt-0.5">
              ECONOMIC COMPUTING LABORATORY &bull; RUST WASM &times; R WORKSTATION
            </p>
          </div>
        </div>

        {/* Middle: Live Market Ticker */}
        <div className="flex items-center gap-4 bg-[#151921] px-4 py-2 rounded border border-[#C5A059]/30 font-mono text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-[#C5A059]/70 text-[11px] tracking-wider">P* EQ:</span>
            <span className="text-[#F5F2ED] font-bold text-sm">
              £{equilibrium.pEquilibrium.toFixed(2)}
            </span>
          </div>
          <div className="h-4 w-px bg-[#C5A059]/20" />
          <div className="flex items-center gap-1.5">
            <span className="text-[#C5A059]/70 text-[11px] tracking-wider">Q* EQ:</span>
            <span className="text-[#34d399] font-bold text-sm">
              {equilibrium.qEquilibrium.toFixed(1)} u
            </span>
          </div>
          <div className="h-4 w-px bg-[#C5A059]/20" />
          <div className="flex items-center gap-1.5">
            <span className="text-[#C5A059]/70 text-[11px] tracking-wider">UTIL:</span>
            <span
              className={`font-bold text-sm ${
                equilibrium.capacityUtilisation > 90
                  ? 'text-amber-400'
                  : 'text-emerald-400'
              }`}
            >
              {equilibrium.capacityUtilisation.toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Right: Engine Telemetry & Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenArchDiagram}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#151921] hover:bg-[#C5A059]/10 border border-[#C5A059]/30 text-xs font-mono text-[#C5A059] transition-all cursor-pointer"
            title="View Rust WASM x R Econometrics Architecture"
          >
            <Workflow className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>RUST &times; R ARCH</span>
          </button>

          {/* Rust Status */}
          <div className="flex items-center gap-1.5 text-xs font-mono px-3 py-1.5 rounded bg-[#151921] border border-[#C5A059]/20">
            <span className="w-2 h-2 rounded-full bg-[#C5A059] animate-pulse" />
            <span className="text-[#C5A059]/70">COMPUTE:</span>
            <span className="text-[#F5F2ED] font-bold">
              {(rustStats.iterationsPerSec / 1000000).toFixed(2)}M op/s
            </span>
          </div>

          {/* Reset Baseline */}
          <button
            onClick={onResetBaseline}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#151921] hover:bg-[#C5A059]/10 border border-[#C5A059]/30 text-xs text-[#F5F2ED] font-mono transition-all cursor-pointer"
            title="Reset parameters to baseline"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#C5A059]" />
            <span>RESET</span>
          </button>

          {/* Audio toggle */}
          <button
            onClick={() => setAudioEnabled(!audioEnabled)}
            className="p-1.5 rounded bg-[#151921] hover:bg-[#C5A059]/10 border border-[#C5A059]/30 text-[#F5F2ED] cursor-pointer"
            title="Toggle audio"
          >
            {audioEnabled ? (
              <Volume2 className="w-4 h-4 text-[#C5A059]" />
            ) : (
              <VolumeX className="w-4 h-4 text-[#C5A059]/40" />
            )}
          </button>
        </div>
      </div>

      {/* Scenario Active Banner (if any) */}
      {activeScenario && (
        <div className="bg-[#151921] px-6 py-2 border-b border-[#C5A059]/40 text-xs text-[#F5F2ED] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#C5A059] animate-spin" />
            <span className="font-bold uppercase tracking-[0.15em] font-serif text-[#C5A059]">
              ACTIVE SCENARIO: {activeScenario.title}
            </span>
            <span className="text-[#F5F2ED]/70 font-sans italic">
              &mdash; {activeScenario.storyline}
            </span>
          </div>
          <button
            onClick={onResetBaseline}
            className="text-[11px] uppercase tracking-widest text-[#C5A059] hover:underline font-mono cursor-pointer"
          >
            Clear Scenario
          </button>
        </div>
      )}

      {/* Bottom Panel Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 overflow-x-auto scrollbar-none py-2 flex items-center gap-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded text-[11px] font-mono tracking-wider uppercase whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#C5A059] text-black font-semibold shadow-md'
                  : 'bg-[#151921] border border-[#C5A059]/30 text-[#F5F2ED]/80 hover:bg-[#C5A059]/10 hover:text-[#F5F2ED]'
              }`}
            >
              <Icon
                className={`w-3.5 h-3.5 ${
                  isActive ? 'text-black' : 'text-[#C5A059]'
                }`}
              />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
