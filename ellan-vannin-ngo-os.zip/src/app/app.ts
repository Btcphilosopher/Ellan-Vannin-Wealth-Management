import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { NGOStateService } from './core/services/ngo-state.service';
import { NGOUserRole, CurrencyCode } from './core/models/ngo-domain';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  state = inject(NGOStateService);

  roles: NGOUserRole[] = [
    'CEO',
    'CFO',
    'ProgrammeDirector',
    'FieldOfficer',
    'Auditor',
    'BoardMember',
    'Donor',
    'ExternalPartner',
  ];

  currencies: CurrencyCode[] = ['USD', 'GBP', 'EUR', 'CHF', 'JPY'];

  changeRole(event: Event) {
    const val = (event.target as HTMLSelectElement).value as NGOUserRole;
    this.state.activeRole.set(val);
  }

  changeCurrency(event: Event) {
    const val = (event.target as HTMLSelectElement).value as CurrencyCode;
    this.state.activeCurrency.set(val);
  }
}
