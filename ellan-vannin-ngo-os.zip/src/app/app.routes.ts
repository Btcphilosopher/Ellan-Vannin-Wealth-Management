import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'command-centre',
    pathMatch: 'full',
  },
  {
    path: 'command-centre',
    loadComponent: () =>
      import('./features/command-centre/command-centre').then(
        (m) => m.CommandCentreComponent
      ),
  },
  {
    path: 'cfo-terminal',
    loadComponent: () =>
      import('./features/cfo-terminal/cfo-terminal').then(
        (m) => m.CfoTerminalComponent
      ),
  },
  {
    path: 'ceo-terminal',
    loadComponent: () =>
      import('./features/ceo-strategy/ceo-strategy').then(
        (m) => m.CeoStrategyComponent
      ),
  },
  {
    path: 'programme-terminal',
    loadComponent: () =>
      import('./features/programme-terminal/programme-terminal').then(
        (m) => m.ProgrammeTerminalComponent
      ),
  },
  {
    path: 'board-terminal',
    loadComponent: () =>
      import('./features/board-terminal/board-terminal').then(
        (m) => m.BoardTerminalComponent
      ),
  },
  {
    path: 'donor-portal',
    loadComponent: () =>
      import('./features/donor-portal/donor-portal').then(
        (m) => m.DonorPortalComponent
      ),
  },
  {
    path: 'partner-portal',
    loadComponent: () =>
      import('./features/partner-portal/partner-portal').then(
        (m) => m.PartnerPortalComponent
      ),
  },
  {
    path: 'field-operations',
    loadComponent: () =>
      import('./features/field-operations/field-operations').then(
        (m) => m.FieldOperationsComponent
      ),
  },
  {
    path: 'logistics-procurement',
    loadComponent: () =>
      import('./features/logistics-procurement/logistics-procurement').then(
        (m) => m.LogisticsProcurementComponent
      ),
  },
  {
    path: 'safeguarding-risk',
    loadComponent: () =>
      import('./features/safeguarding-risk/safeguarding-risk').then(
        (m) => m.SafeguardingRiskComponent
      ),
  },
  {
    path: 'ai-intelligence',
    loadComponent: () =>
      import('./features/ai-intelligence/ai-intelligence').then(
        (m) => m.AiIntelligenceComponent
      ),
  },
  {
    path: 'audit-config',
    loadComponent: () =>
      import('./features/audit-config/audit-config').then(
        (m) => m.AuditConfigComponent
      ),
  },
  {
    path: '**',
    redirectTo: 'command-centre',
  },
];
