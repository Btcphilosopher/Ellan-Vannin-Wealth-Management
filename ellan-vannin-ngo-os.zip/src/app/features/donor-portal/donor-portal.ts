import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NGOStateService } from '../../core/services/ngo-state.service';

export interface ProposalAnalysisResult {
  feasibilityScore?: number;
  strategicAlignment?: string;
  financialRiskAssessment?: string;
  recommendation?: string;
}

@Component({
  selector: 'app-donor-portal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Donor Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded">
              INSTITUTIONAL DONOR PORTAL
            </span>
            <span class="text-xs text-slate-400 font-mono">ROLE: GRANTOR / DONOR REPRESENTATIVE</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Grant Capital Provenance & Evidence Verification Portal
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            Audit-grade transparency for Institutional Donors • Real-time Restricted Fund Balances
          </p>
        </div>

        <button (click)="openProposalModal()" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs rounded shadow-xs transition flex items-center gap-1.5">
          <span class="material-icons text-sm">auto_awesome</span>
          AI Proposal Evaluator
        </button>
      </div>

      <!-- Donors & Grants Table -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
          <span class="material-icons text-indigo-600 text-base">request_quote</span>
          Active Grant Portfolio & Capital Provenance
        </h3>

        <div class="overflow-x-auto mt-4">
          <table class="w-full text-left text-xs text-slate-700">
            <thead class="bg-slate-50 border-y border-slate-200 font-mono text-[11px] uppercase text-slate-500">
              <tr>
                <th class="p-2.5">Grant Code & Title</th>
                <th class="p-2.5">Donor Name</th>
                <th class="p-2.5">Status</th>
                <th class="p-2.5 text-right">Award Amount</th>
                <th class="p-2.5 text-right">Currency</th>
                <th class="p-2.5">Reporting Status</th>
                <th class="p-2.5">Next Report Due</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (g of state.grants(); track g.id) {
                <tr class="hover:bg-slate-50/80">
                  <td class="p-2.5">
                    <div class="font-bold text-slate-900">{{ g.title }}</div>
                    <div class="font-mono text-[10px] text-slate-400">{{ g.code }} • {{ g.startDate }} to {{ g.endDate }}</div>
                  </td>
                  <td class="p-2.5 font-medium text-slate-800">{{ g.donorName }}</td>
                  <td class="p-2.5">
                    <span class="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold text-[10px] rounded">{{ g.status }}</span>
                  </td>
                  <td class="p-2.5 text-right font-mono font-bold text-slate-900">\${{ g.amount.toLocaleString() }}</td>
                  <td class="p-2.5 text-right font-mono text-slate-600">{{ g.currency }}</td>
                  <td class="p-2.5">
                    <span class="px-2 py-0.5 bg-indigo-100 text-indigo-800 font-bold text-[10px] rounded">{{ g.reportingStatus }}</span>
                  </td>
                  <td class="p-2.5 font-mono text-slate-600 text-[11px]">{{ g.nextReportDue }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- AI Proposal Evaluator Modal -->
    @if (showProposalModal()) {
      <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
        <div class="bg-white border border-slate-300 rounded-xl shadow-xl max-w-xl w-full p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-200 pb-3">
            <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
              <span class="material-icons text-indigo-600">auto_awesome</span>
              AI Proposal & Concept Note Evaluator
            </h3>
            <button (click)="closeProposalModal()" class="text-slate-400 hover:text-slate-600">
              <span class="material-icons text-lg">close</span>
            </button>
          </div>

          <div class="space-y-3 text-xs">
            <div>
              <label for="propTitle" class="block font-medium text-slate-700">Proposal Title</label>
              <input id="propTitle" [(ngModel)]="propTitle" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label for="propSector" class="block font-medium text-slate-700">Target Sector</label>
                <input id="propSector" [(ngModel)]="propSector" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
              </div>
              <div>
                <label for="propBudget" class="block font-medium text-slate-700">Requested Budget (USD)</label>
                <input id="propBudget" type="number" [(ngModel)]="propBudget" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
              </div>
            </div>

            <div>
              <label for="propSummary" class="block font-medium text-slate-700">Proposal Concept & Theory of Change Summary</label>
              <textarea id="propSummary" [(ngModel)]="propSummary" rows="3" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs"></textarea>
            </div>

            @if (evaluating()) {
              <div class="p-3 bg-indigo-50 text-indigo-800 rounded font-mono text-xs flex items-center gap-2">
                <span class="material-icons animate-spin text-sm">sync</span>
                Running Gemini 3.8 Flash Institutional Proposal Analysis...
              </div>
            }

            @if (aiResult()) {
              <div class="p-4 bg-slate-900 text-slate-100 rounded-lg space-y-2 text-xs">
                <div class="flex justify-between items-center font-mono border-b border-slate-800 pb-2">
                  <span class="text-indigo-400 font-bold">ANALYSIS RESULTS</span>
                  <span class="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded">Feasibility: {{ aiResult()?.feasibilityScore }}/100</span>
                </div>
                <p><strong class="text-slate-300">Strategic Fit:</strong> {{ aiResult()?.strategicAlignment }}</p>
                <p><strong class="text-slate-300">Risk Assessment:</strong> {{ aiResult()?.financialRiskAssessment }}</p>
                <p><strong class="text-slate-300">Recommendation:</strong> {{ aiResult()?.recommendation }}</p>
              </div>
            }
          </div>

          <div class="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button (click)="closeProposalModal()" class="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium">Close</button>
            <button (click)="runAnalysis()" [disabled]="evaluating()" class="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded shadow-xs disabled:opacity-50">
              Evaluate Proposal
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class DonorPortalComponent {
  state = inject(NGOStateService);

  showProposalModal = signal(false);
  evaluating = signal(false);
  aiResult = signal<ProposalAnalysisResult | null>(null);

  propTitle = 'Solar-Powered Clean Water Expansion for Turkana County';
  propSector = 'WASH & Climate Resilience';
  propBudget = 1850000;
  propSummary = 'Installing 12 solar pumping boreholes with IoT flow telemetry across Pastoral communities to reduce water fetching time for women from 4 hours to 15 minutes.';

  openProposalModal() {
    this.showProposalModal.set(true);
    this.aiResult.set(null);
  }

  closeProposalModal() {
    this.showProposalModal.set(false);
  }

  runAnalysis() {
    this.evaluating.set(true);
    this.aiResult.set(null);

    this.state
      .analyzeProposal({
        proposalTitle: this.propTitle,
        sector: this.propSector,
        budgetUSD: Number(this.propBudget),
        summary: this.propSummary,
      })
      .subscribe({
        next: (res: { success: boolean; analysis: Record<string, unknown> }) => {
          this.evaluating.set(false);
          this.aiResult.set(res.analysis as ProposalAnalysisResult);
        },
        error: () => this.evaluating.set(false),
      });
  }
}
