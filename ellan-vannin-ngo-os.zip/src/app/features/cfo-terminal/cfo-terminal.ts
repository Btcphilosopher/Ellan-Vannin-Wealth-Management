import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NGOStateService } from '../../core/services/ngo-state.service';

export interface ScenarioModelOutput {
  scenario: {
    name: string;
    status: string;
    projectedRevenueUSD: number;
    projectedExpenditureUSD: number;
    netDeficitUSD: number;
    daysCashOnHand: number;
  };
}

@Component({
  selector: 'app-cfo-terminal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- CFO Header -->
      <div class="bg-slate-950 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded">
              FINANCIAL TERMINAL
            </span>
            <span class="text-xs text-slate-400 font-mono">ROLE: CFO / TREASURY DIRECTOR</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Consolidated Fund Accounting & Treasury Terminal
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            Double-Entry General Ledger • Restricted Fund Segregation • FX Exposure • Days Cash on Hand: {{ state.daysCashOnHand() }} Days
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button (click)="runScenarioStressTest()" class="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs rounded shadow-xs transition flex items-center gap-1.5">
            <span class="material-icons text-sm">insights</span>
            Simulate Scenario
          </button>
        </div>
      </div>

      <!-- Financial Statements Summary Bar -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Restricted Cash Escrow</span>
          <div class="text-xl font-mono font-bold text-slate-900 mt-1">\${{ (state.totalMoneyRestricted() / 1000000).toFixed(2) }}M</div>
          <div class="text-[11px] text-slate-500 mt-1">Donor Restricted Balance</div>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Unrestricted Core Reserves</span>
          <div class="text-xl font-mono font-bold text-purple-700 mt-1">\${{ (state.totalMoneyUnrestricted() / 1000000).toFixed(2) }}M</div>
          <div class="text-[11px] text-slate-500 mt-1">Available Liquidity Buffer</div>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Committed PO Obligations</span>
          <div class="text-xl font-mono font-bold text-amber-700 mt-1">\${{ (state.totalMoneyCommitted() / 1000000).toFixed(2) }}M</div>
          <div class="text-[11px] text-slate-500 mt-1">Contractual Accounts Payable</div>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span class="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Audit Invariant Check</span>
          <div class="text-xl font-mono font-bold text-emerald-700 mt-1">BALANCED</div>
          <div class="text-[11px] text-slate-500 mt-1">Debits = Credits ($61.5M)</div>
        </div>
      </div>

      <!-- Fund Accounting Ledger Table -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 class="text-sm font-bold text-slate-900 flex items-center gap-2">
            <span class="material-icons text-slate-700 text-base">account_balance</span>
            Restricted vs Unrestricted Fund Accounting Ledger
          </h3>
          <span class="text-xs text-slate-500 font-mono">{{ state.restrictedFunds().length }} Active Funds</span>
        </div>

        <div class="overflow-x-auto mt-4">
          <table class="w-full text-left text-xs text-slate-700">
            <thead class="bg-slate-50 border-y border-slate-200 font-mono text-[11px] uppercase text-slate-500">
              <tr>
                <th class="p-2.5">Fund Code & Name</th>
                <th class="p-2.5">Donor</th>
                <th class="p-2.5">Type</th>
                <th class="p-2.5 text-right">Awarded</th>
                <th class="p-2.5 text-right">Committed</th>
                <th class="p-2.5 text-right">Spent</th>
                <th class="p-2.5 text-right">Remaining</th>
                <th class="p-2.5">Expiry</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (fund of state.restrictedFunds(); track fund.id) {
                <tr class="hover:bg-slate-50/80">
                  <td class="p-2.5">
                    <div class="font-bold text-slate-900">{{ fund.name }}</div>
                    <div class="font-mono text-[10px] text-slate-400">{{ fund.code }} • {{ fund.restrictionsSummary }}</div>
                  </td>
                  <td class="p-2.5 font-medium text-slate-800">{{ fund.donorName }}</td>
                  <td class="p-2.5">
                    <span 
                      class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                      [ngClass]="{
                        'bg-purple-100 text-purple-800': fund.type === 'UNRESTRICTED',
                        'bg-indigo-100 text-indigo-800': fund.type === 'RESTRICTED',
                        'bg-amber-100 text-amber-800': fund.type === 'TEMP_RESTRICTED'
                      }"
                    >
                      {{ fund.type }}
                    </span>
                  </td>
                  <td class="p-2.5 text-right font-mono font-bold text-slate-900">\${{ fund.totalAwarded.toLocaleString() }}</td>
                  <td class="p-2.5 text-right font-mono text-amber-700">\${{ fund.committed.toLocaleString() }}</td>
                  <td class="p-2.5 text-right font-mono text-emerald-700">\${{ fund.spent.toLocaleString() }}</td>
                  <td class="p-2.5 text-right font-mono font-bold text-slate-900">\${{ fund.remaining.toLocaleString() }}</td>
                  <td class="p-2.5 font-mono text-slate-500 text-[11px]">{{ fund.expiryDate }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Chart of Accounts & Multi-Currency Treasury -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Chart of Accounts -->
        <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
            <span class="material-icons text-slate-700 text-base">list_alt</span>
            Chart of Accounts & General Ledger Balances
          </h3>

          <div class="divide-y divide-slate-100 mt-3 max-h-80 overflow-y-auto">
            @for (acc of state.ledgerAccounts(); track acc.accountCode) {
              <div class="py-2 flex items-center justify-between text-xs">
                <div>
                  <span class="font-mono font-bold text-slate-900">{{ acc.accountCode }}</span>
                  <span class="ml-2 text-slate-700 font-medium">{{ acc.accountName }}</span>
                </div>
                <div class="text-right font-mono">
                  <span class="font-bold text-slate-900">\${{ acc.balance.toLocaleString() }}</span>
                  <span class="ml-1 text-[10px] text-slate-400">({{ acc.type }})</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- FX & Scenario Model Results -->
        <div class="space-y-6">
          <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
              <span class="material-icons text-slate-700 text-base">currency_exchange</span>
              Treasury & FX Exposure Monitor
            </h3>

            <div class="space-y-2 mt-3 text-xs">
              <div class="p-3 bg-slate-50 rounded border border-slate-200 flex justify-between items-center">
                <div>
                  <div class="font-bold text-slate-900">GBP Pool (FCDO Grants)</div>
                  <div class="text-[11px] text-slate-500">Functional Rate: 1.28 USD / GBP</div>
                </div>
                <div class="text-right font-mono font-bold text-slate-900">£24,200,000</div>
              </div>

              <div class="p-3 bg-slate-50 rounded border border-slate-200 flex justify-between items-center">
                <div>
                  <div class="font-bold text-slate-900">EUR Pool (ECHO Grants)</div>
                  <div class="text-[11px] text-slate-500">Functional Rate: 1.09 USD / EUR</div>
                </div>
                <div class="text-right font-mono font-bold text-slate-900">€13,300,000</div>
              </div>

              <div class="p-3 bg-slate-50 rounded border border-slate-200 flex justify-between items-center">
                <div>
                  <div class="font-bold text-slate-900">UGX / SSP Field Floats</div>
                  <div class="text-[11px] text-slate-500">Local Currency Ops</div>
                </div>
                <div class="text-right font-mono font-bold text-slate-900">\${{ (450000).toLocaleString() }} USD Eq</div>
              </div>
            </div>
          </div>

          @if (scenarioResult()) {
            <div class="bg-indigo-950 border border-indigo-800 rounded-xl p-5 text-indigo-100 space-y-2">
              <div class="flex items-center justify-between font-mono text-xs text-indigo-300 border-b border-indigo-800 pb-2">
                <span>SCENARIO MODEL OUTPUT</span>
                <span class="font-bold text-emerald-400">{{ scenarioResult()?.scenario?.status }}</span>
              </div>
              <p class="font-bold text-sm text-white">{{ scenarioResult()?.scenario?.name }}</p>
              <div class="grid grid-cols-2 gap-2 text-xs font-mono pt-2">
                <div>Projected Rev: \${{ ((scenarioResult()?.scenario?.projectedRevenueUSD || 0) / 1000000).toFixed(2) }}M</div>
                <div>Projected Exp: \${{ ((scenarioResult()?.scenario?.projectedExpenditureUSD || 0) / 1000000).toFixed(2) }}M</div>
                <div>Net Deficit: \${{ ((scenarioResult()?.scenario?.netDeficitUSD || 0) / 1000000).toFixed(2) }}M</div>
                <div>Days Cash: {{ scenarioResult()?.scenario?.daysCashOnHand }} Days</div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class CfoTerminalComponent {
  state = inject(NGOStateService);
  scenarioResult = signal<ScenarioModelOutput | null>(null);

  runScenarioStressTest() {
    this.state
      .runScenario({
        fundingChangePct: -15,
        fxShockPct: -8,
        emergencyBudgetUSD: 3500000,
      })
      .subscribe((res: { success: boolean; scenario: Record<string, unknown> }) => {
        this.scenarioResult.set(res as unknown as ScenarioModelOutput);
      });
  }
}
