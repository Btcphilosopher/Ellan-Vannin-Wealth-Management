import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NGOStateService } from '../../core/services/ngo-state.service';

@Component({
  selector: 'app-command-centre',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Institutional Banner -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-sm">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-xs font-mono font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded">
              SOVEREIGN-GRADE ACTIVE
            </span>
            <span class="text-xs text-slate-400 font-mono">HQ: {{ state.tenantConfig().headquarters }}</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            {{ state.tenantConfig().organisationName }}
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            {{ state.tenantConfig().legalEntity }} • 14 Country Offices • 28 Field Sub-offices
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button (click)="openQuickJournalModal()" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded shadow-sm transition flex items-center gap-1.5">
            <span class="material-icons text-sm">account_balance_wallet</span>
            Post Ledger Voucher
          </button>
          <button (click)="triggerBoardResolution()" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs rounded transition flex items-center gap-1.5">
            <span class="material-icons text-sm">gavel</span>
            Board Resolution
          </button>
        </div>
      </div>

      <!-- Money Differentiation Matrix (Core Product Invariant) -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 text-slate-200">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div class="flex items-center gap-2">
            <span class="material-icons text-emerald-400 text-base">account_tree</span>
            <h2 class="text-xs font-bold uppercase tracking-wider text-slate-300">
              Institutional Money Provenance & Allocation Matrix
            </h2>
          </div>
          <span class="text-[11px] font-mono text-slate-400">Currency: USD Equivalent (Base)</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <div class="text-[10px] uppercase text-slate-400 font-semibold tracking-wider">1. Raised</div>
            <div class="text-base font-mono font-bold text-slate-100 mt-1">
              \${{ (state.totalMoneyRaised() / 1000000).toFixed(1) }}M
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Lifetime Donated</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <div class="text-[10px] uppercase text-amber-400 font-semibold tracking-wider">2. Committed</div>
            <div class="text-base font-mono font-bold text-amber-300 mt-1">
              \${{ (state.totalMoneyCommitted() / 1000000).toFixed(1) }}M
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Contractual POs</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <div class="text-[10px] uppercase text-indigo-400 font-semibold tracking-wider">3. Restricted</div>
            <div class="text-base font-mono font-bold text-indigo-300 mt-1">
              \${{ (state.totalMoneyRestricted() / 1000000).toFixed(1) }}M
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Donor Earmarked</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <div class="text-[10px] uppercase text-blue-400 font-semibold tracking-wider">4. Allocated</div>
            <div class="text-base font-mono font-bold text-blue-300 mt-1">
              \${{ (state.totalMoneyRemaining() / 1000000).toFixed(1) }}M
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Approved Budgets</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <div class="text-[10px] uppercase text-emerald-400 font-semibold tracking-wider">5. Spent</div>
            <div class="text-base font-mono font-bold text-emerald-300 mt-1">
              \${{ (state.totalMoneySpent() / 1000000).toFixed(1) }}M
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Audited Expenses</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80">
            <div class="text-[10px] uppercase text-purple-400 font-semibold tracking-wider">6. Unrestricted</div>
            <div class="text-base font-mono font-bold text-purple-300 mt-1">
              \${{ (state.totalMoneyUnrestricted() / 1000000).toFixed(1) }}M
            </div>
            <div class="text-[10px] text-slate-500 mt-0.5">Core Reserves</div>
          </div>

          <div class="bg-slate-950 p-3 rounded-lg border border-emerald-500/30">
            <div class="text-[10px] uppercase text-emerald-400 font-bold tracking-wider">7. Impact</div>
            <div class="text-base font-mono font-bold text-emerald-400 mt-1">
              {{ (state.totalVerifiedOutcomes() / 1000).toFixed(0) }}k
            </div>
            <div class="text-[10px] text-emerald-400/80 mt-0.5">Verified Outcomes</div>
          </div>
        </div>
      </div>

      <!-- 7 Canonical Positions Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- Financial Position -->
        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs hover:border-slate-300 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Financial Position</span>
            <span class="material-icons text-emerald-600 text-lg">account_balance</span>
          </div>
          <div class="mt-3">
            <div class="text-lg font-mono font-bold text-slate-900">\${{ (state.totalMoneyRemaining() / 1000000).toFixed(1) }}M Cash</div>
            <div class="text-xs text-slate-600 mt-1 font-medium">Days Cash on Hand: <span class="font-bold text-slate-900">{{ state.daysCashOnHand() }} Days</span></div>
          </div>
          <div class="mt-3 pt-3 border-t border-slate-100 flex justify-between text-[11px] text-slate-500">
            <span>Audit Status: <strong class="text-emerald-700">Clean Opinion</strong></span>
            <span>Unrestricted: <strong>\${{ (state.totalMoneyUnrestricted() / 1000000).toFixed(1) }}M</strong></span>
          </div>
        </div>

        <!-- Funding Position -->
        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs hover:border-slate-300 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Funding Position</span>
            <span class="material-icons text-indigo-600 text-lg">request_quote</span>
          </div>
          <div class="mt-3">
            <div class="text-lg font-mono font-bold text-slate-900">{{ state.grants().length }} Active Grants</div>
            <div class="text-xs text-slate-600 mt-1 font-medium">Restricted Funds: <span class="font-bold text-slate-900">\${{ (state.totalMoneyRestricted() / 1000000).toFixed(1) }}M</span></div>
          </div>
          <div class="mt-3 pt-3 border-t border-slate-100 flex justify-between text-[11px] text-slate-500">
            <span>Pipeline: <strong>$41.0M</strong></span>
            <span>Major Donors: <strong>5 Strategic</strong></span>
          </div>
        </div>

        <!-- Programme & Impact Position -->
        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs hover:border-slate-300 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Impact Position</span>
            <span class="material-icons text-emerald-600 text-lg">verified</span>
          </div>
          <div class="mt-3">
            <div class="text-lg font-mono font-bold text-slate-900">{{ (state.totalBeneficiariesReached() / 1000).toFixed(0) }}k Beneficiaries</div>
            <div class="text-xs text-slate-600 mt-1 font-medium">Evidence Proofs: <span class="font-bold text-slate-900">{{ state.evidenceItems().length }} Hashed Items</span></div>
          </div>
          <div class="mt-3 pt-3 border-t border-slate-100 flex justify-between text-[11px] text-slate-500">
            <span>Cost/Outcome: <strong>$19.40 avg</strong></span>
            <span>Target Achieved: <strong>91.4%</strong></span>
          </div>
        </div>

        <!-- Risk & Safeguarding Position -->
        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs hover:border-slate-300 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-slate-500 uppercase tracking-wider">Risk & Governance</span>
            <span class="material-icons text-amber-600 text-lg">security</span>
          </div>
          <div class="mt-3">
            <div class="text-lg font-mono font-bold text-slate-900">{{ state.criticalRisksCount() }} Critical Risks</div>
            <div class="text-xs text-slate-600 mt-1 font-medium">Safeguarding Cases: <span class="font-bold text-amber-700">{{ state.activeSafeguardingCasesCount() }} Confidential</span></div>
          </div>
          <div class="mt-3 pt-3 border-t border-slate-100 flex justify-between text-[11px] text-slate-500">
            <span>Anomalies: <strong class="text-red-600">{{ state.unresolvedAnomaliesCount() }} Pending</strong></span>
            <span>Resolutions: <strong>{{ state.boardResolutions().length }} Passed</strong></span>
          </div>
        </div>
      </div>

      <!-- Main Operational Dashboard Content Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Active Strategic Programmes (2 Cols) -->
        <div class="lg:col-span-2 space-y-6">
          <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span class="material-icons text-slate-700 text-base">public</span>
                Active Global Programmes & Country Portfolio
              </h3>
              <span class="text-xs font-mono text-slate-500">3 Core Sector Initiatives</span>
            </div>

            <div class="divide-y divide-slate-100 mt-3">
              @for (p of state.programmes(); track p.id) {
                <div class="py-3.5 first:pt-1 last:pb-1 space-y-2">
                  <div class="flex items-center justify-between">
                    <div>
                      <div class="flex items-center gap-2">
                        <span class="text-sm font-bold text-slate-900">{{ p.name }}</span>
                        <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-slate-100 text-slate-700 rounded">{{ p.code }}</span>
                      </div>
                      <p class="text-xs text-slate-500 mt-0.5">
                        Director: {{ p.leadDirector }} • Sector: {{ p.sector }} • Countries: {{ p.countries.join(', ') }}
                      </p>
                    </div>

                    <div class="text-right">
                      <div class="text-xs font-mono font-bold text-slate-900">\${{ (p.spentTotal / 1000000).toFixed(1) }}M / \${{ (p.budgetTotal / 1000000).toFixed(1) }}M</div>
                      <div class="text-[11px] text-slate-500">Budget Utilisation</div>
                    </div>
                  </div>

                  <!-- Progress Bar -->
                  <div class="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                    <div 
                      class="bg-emerald-600 h-full rounded-full transition-all duration-500"
                      [style.width.%]="(p.spentTotal / p.budgetTotal) * 100"
                    ></div>
                  </div>

                  <div class="flex items-center justify-between text-xs text-slate-600 pt-1">
                    <span>Beneficiaries: <strong class="text-slate-900">{{ p.reachedBeneficiaries.toLocaleString() }}</strong> / {{ p.targetBeneficiaries.toLocaleString() }}</span>
                    <span>Active Projects: <strong class="text-slate-900">{{ p.activeProjectsCount }}</strong></span>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Immutable Institutional Audit Stream -->
          <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 class="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span class="material-icons text-slate-700 text-base">history_edu</span>
                Canonical Audit Engine Log (Append-Only)
              </h3>
              <span class="text-xs font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold">
                SHA-256 Provenance Hashed
              </span>
            </div>

            <div class="space-y-3 mt-3">
              @for (log of state.auditLogs().slice(0, 4); track log.id) {
                <div class="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
                  <div class="flex items-center justify-between font-mono text-[11px] text-slate-500">
                    <span class="font-bold text-slate-800">{{ log.id }} • {{ log.eventType }}</span>
                    <span>{{ log.timestamp | date:'short' }}</span>
                  </div>
                  <p class="text-slate-800 font-medium">
                    Actor: <strong class="text-slate-900">{{ log.actor }}</strong> ({{ log.actorRole }}) • Jurisdiction: {{ log.jurisdiction }}
                  </p>
                  <p class="text-slate-600 font-mono text-[11px]">
                    {{ log.provenance }}
                  </p>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Right Side Panel: Deadlines, Anomaly Signals & Quick Actions -->
        <div class="space-y-6">
          <!-- Anomaly Detection Card -->
          <div class="bg-white border border-amber-200 rounded-xl p-5 shadow-xs">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <span class="material-icons text-amber-600 text-base">warning</span>
                Fraud & Anomaly Signals
              </h3>
              <span class="px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800 rounded">
                AI + Rule Engine
              </span>
            </div>

            <div class="space-y-3 mt-3">
              @for (sig of state.anomalySignals(); track sig.id) {
                <div class="p-3 bg-amber-50/50 border border-amber-200/80 rounded-lg text-xs space-y-1">
                  <div class="flex items-center justify-between font-bold text-amber-900">
                    <span>{{ sig.category }}</span>
                    <span class="text-[10px] px-1.5 py-0.5 bg-amber-200 text-amber-900 rounded font-mono">Risk: {{ sig.riskScore }}/100</span>
                  </div>
                  <p class="text-slate-700 text-[11px] leading-relaxed">{{ sig.detectedDetail }}</p>
                  <div class="flex items-center justify-between text-[10px] text-slate-500 pt-1 font-mono">
                    <span>Status: {{ sig.humanDecision }}</span>
                    <span>{{ sig.timestamp | date:'short' }}</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Board Resolutions & Deadlines -->
          <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 class="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <span class="material-icons text-indigo-600 text-base">gavel</span>
                Board Resolutions & Mandates
              </h3>
            </div>

            <div class="space-y-3 mt-3">
              @for (res of state.boardResolutions(); track res.id) {
                <div class="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
                  <div class="flex items-center justify-between font-bold text-slate-900">
                    <span>{{ res.resolutionNumber }}</span>
                    <span class="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[10px]">{{ res.status }}</span>
                  </div>
                  <p class="text-slate-800 font-semibold text-[11px]">{{ res.title }}</p>
                  <p class="text-slate-600 text-[11px]">{{ res.description }}</p>
                  <div class="text-[10px] text-slate-500 pt-1 font-mono">
                    Officer: {{ res.responsibleOfficer }} • Due: {{ res.actionDueDate }}
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal for Posting Journal Voucher -->
    @if (showJournalModal()) {
      <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
        <div class="bg-white border border-slate-300 rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-200 pb-3">
            <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
              <span class="material-icons text-emerald-600">account_balance_wallet</span>
              Post Double-Entry Journal Voucher
            </h3>
            <button (click)="closeJournalModal()" class="text-slate-400 hover:text-slate-600">
              <span class="material-icons text-lg">close</span>
            </button>
          </div>

          <div class="space-y-3 text-xs">
            <div>
              <label for="journalFundId" class="block font-medium text-slate-700">Restricted Fund</label>
              <select id="journalFundId" [(ngModel)]="journalFundId" class="w-full mt-1 p-2 border border-slate-300 rounded focus:ring-2 focus:ring-emerald-500 text-xs">
                @for (fund of state.restrictedFunds(); track fund.id) {
                  <option [value]="fund.id">{{ fund.name }} (Remaining: \${{ fund.remaining.toLocaleString() }} {{ fund.currency }})</option>
                }
              </select>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label for="journalDebit" class="block font-medium text-slate-700">Debit Account</label>
                <input id="journalDebit" [(ngModel)]="journalDebit" placeholder="e.g. 5010 - Field Operations" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
              </div>
              <div>
                <label for="journalCredit" class="block font-medium text-slate-700">Credit Account</label>
                <input id="journalCredit" [(ngModel)]="journalCredit" placeholder="e.g. 1010 - Cash Account" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
              </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label for="journalAmount" class="block font-medium text-slate-700">Amount (USD)</label>
                <input id="journalAmount" type="number" [(ngModel)]="journalAmount" placeholder="350000" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
              </div>
              <div>
                <label for="journalVoucher" class="block font-medium text-slate-700">Voucher Reference</label>
                <input id="journalVoucher" [(ngModel)]="journalVoucher" placeholder="JNL-2026-99" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
              </div>
            </div>

            <div>
              <label for="journalDesc" class="block font-medium text-slate-700">Description / Provenance Note</label>
              <textarea id="journalDesc" [(ngModel)]="journalDesc" rows="2" placeholder="Field operational expenditure for solar borehole drilling in Bentiu." class="w-full mt-1 p-2 border border-slate-300 rounded text-xs"></textarea>
            </div>

            @if (journalError()) {
              <div class="p-2.5 bg-red-50 border border-red-200 text-red-700 rounded text-xs font-mono">
                {{ journalError() }}
              </div>
            }
          </div>

          <div class="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button (click)="closeJournalModal()" class="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium">Cancel</button>
            <button (click)="submitJournalVoucher()" class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded shadow-xs">
              Commit Voucher
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class CommandCentreComponent {
  state = inject(NGOStateService);

  showJournalModal = signal(false);
  journalFundId = 'RF-GATES-2026-01';
  journalDebit = '5010 - Direct Programme Expenditure';
  journalCredit = '1020 - Restricted Bank Account';
  journalAmount = 250000;
  journalVoucher = 'JNL-2026-104';
  journalDesc = 'Solar equipment installation downpayment for Uganda Maternal Health Hubs.';
  journalError = signal<string | null>(null);

  openQuickJournalModal() {
    this.showJournalModal.set(true);
    this.journalError.set(null);
  }

  closeJournalModal() {
    this.showJournalModal.set(false);
  }

  submitJournalVoucher() {
    this.journalError.set(null);
    this.state
      .recordTransaction({
        voucherNo: this.journalVoucher,
        fundId: this.journalFundId,
        amount: Number(this.journalAmount),
        currency: 'USD',
        debitAccount: this.journalDebit,
        creditAccount: this.journalCredit,
        description: this.journalDesc,
        actor: 'Dr. Amina Al-Mansoor',
        country: 'Uganda',
      })
      .subscribe({
        next: () => {
          this.state.loadState();
          this.closeJournalModal();
        },
        error: (err: { error?: { error?: string } }) => {
          this.journalError.set(err.error?.error || 'Transaction failed constraint verification.');
        },
      });
  }

  triggerBoardResolution() {
    this.state
      .passBoardResolution({
        title: 'Emergency Allocations for East Africa Horn Response',
        committee: 'EXECUTIVE_BOARD',
        description: 'Authorized $1,500,000 drawdown from unrestricted reserves for rapid drought relief.',
        responsibleOfficer: 'CFO',
      })
      .subscribe(() => this.state.loadState());
  }
}
