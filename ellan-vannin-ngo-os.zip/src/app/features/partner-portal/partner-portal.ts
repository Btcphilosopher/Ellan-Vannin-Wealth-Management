import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NGOStateService } from '../../core/services/ngo-state.service';

@Component({
  selector: 'app-partner-portal',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded">
              LOCAL PARTNER OS
            </span>
            <span class="text-xs text-slate-400 font-mono font-semibold">PARTNER & SUBGRANT TERMINAL</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Local Implementing Partner & Subgrant Management
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            Capacity Assessments • Subgrant Disbursements • Liquidation Statements
          </p>
        </div>
      </div>

      <!-- Implementing Partners List -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div class="flex items-center justify-between">
            <span class="px-2 py-0.5 bg-blue-100 text-blue-800 font-mono font-bold text-[10px] rounded">PTR-UG-01</span>
            <span class="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold text-[10px] rounded">COMPLIANT (88%)</span>
          </div>
          <h3 class="text-sm font-bold text-slate-900 mt-2">Uganda Community Health Alliance (UCHA)</h3>
          <p class="text-xs text-slate-500 mt-1">Gulu & Arua District Operations • Local NGO Partner</p>

          <div class="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-100 text-xs font-mono">
            <div>Subgrant Award: <strong class="text-slate-900">$1,200,000</strong></div>
            <div>Liquidated: <strong class="text-emerald-700">$940,000</strong></div>
          </div>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div class="flex items-center justify-between">
            <span class="px-2 py-0.5 bg-blue-100 text-blue-800 font-mono font-bold text-[10px] rounded">PTR-SS-02</span>
            <span class="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold text-[10px] rounded">COMPLIANT (82%)</span>
          </div>
          <h3 class="text-sm font-bold text-slate-900 mt-2">South Sudan Rural Development Action</h3>
          <p class="text-xs text-slate-500 mt-1">Juba & Unity State Borehole Drilling Partner</p>

          <div class="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-100 text-xs font-mono">
            <div>Subgrant Award: <strong class="text-slate-900">$1,850,000</strong></div>
            <div>Liquidated: <strong class="text-emerald-700">$1,420,000</strong></div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PartnerPortalComponent {
  state = inject(NGOStateService);
}
