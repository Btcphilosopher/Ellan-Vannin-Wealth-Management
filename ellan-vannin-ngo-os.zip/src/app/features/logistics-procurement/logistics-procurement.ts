import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NGOStateService } from '../../core/services/ngo-state.service';

@Component({
  selector: 'app-logistics-procurement',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded">
              SUPPLY CHAIN & LOGISTICS
            </span>
            <span class="text-xs text-slate-400 font-mono">PROCUREMENT & WAREHOUSE ENGINE</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Institutional Procurement & Inventory Shipments
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            Restricted Fund PO Commitments • Customs Clearance Tracking • Cold-Chain Integrity
          </p>
        </div>
      </div>

      <!-- Purchase Orders Grid -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
          <span class="material-icons text-amber-600 text-base">shopping_cart</span>
          Contractual Purchase Orders (POs) Bound to Restricted Funds
        </h3>

        <div class="overflow-x-auto mt-4">
          <table class="w-full text-left text-xs text-slate-700">
            <thead class="bg-slate-50 border-y border-slate-200 font-mono text-[11px] uppercase text-slate-500">
              <tr>
                <th class="p-2.5">PO Number</th>
                <th class="p-2.5">Supplier Name</th>
                <th class="p-2.5">Grant Code</th>
                <th class="p-2.5 text-right">Amount (USD)</th>
                <th class="p-2.5">3-Way Match</th>
                <th class="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (po of state.purchaseOrders(); track po.id) {
                <tr class="hover:bg-slate-50/80">
                  <td class="p-2.5 font-mono font-bold text-slate-900">{{ po.poNumber }}</td>
                  <td class="p-2.5 font-medium text-slate-800">{{ po.supplierName }}</td>
                  <td class="p-2.5 font-mono text-[10px] text-slate-500">{{ po.grantCode }}</td>
                  <td class="p-2.5 text-right font-mono font-bold text-slate-900">\${{ po.amount.toLocaleString() }} {{ po.currency }}</td>
                  <td class="p-2.5">
                    <span 
                      class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                      [ngClass]="po.threeWayMatchVerified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'"
                    >
                      {{ po.threeWayMatchVerified ? 'VERIFIED' : 'PENDING' }}
                    </span>
                  </td>
                  <td class="p-2.5">
                    <span class="px-2 py-0.5 bg-indigo-100 text-indigo-800 font-bold text-[10px] rounded">{{ po.status }}</span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Inventory Shipments Grid -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
          <span class="material-icons text-blue-600 text-base">local_shipping</span>
          Global Supply Chain & Warehouse Shipments
        </h3>

        <div class="overflow-x-auto mt-4">
          <table class="w-full text-left text-xs text-slate-700">
            <thead class="bg-slate-50 border-y border-slate-200 font-mono text-[11px] uppercase text-slate-500">
              <tr>
                <th class="p-2.5">Tracking Number</th>
                <th class="p-2.5">Item Description</th>
                <th class="p-2.5 font-right">Units</th>
                <th class="p-2.5">Origin → Destination</th>
                <th class="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (sh of state.inventoryShipments(); track sh.id) {
                <tr class="hover:bg-slate-50/80">
                  <td class="p-2.5 font-mono font-bold text-slate-900">{{ sh.trackingNumber }}</td>
                  <td class="p-2.5 font-medium text-slate-800">{{ sh.description }}</td>
                  <td class="p-2.5 font-mono text-slate-900">{{ sh.quantityUnits }}</td>
                  <td class="p-2.5 text-slate-600">{{ sh.originWarehouse }} → {{ sh.destinationFieldOffice }}</td>
                  <td class="p-2.5">
                    <span class="px-2 py-0.5 bg-blue-100 text-blue-800 font-bold text-[10px] rounded">{{ sh.status }}</span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class LogisticsProcurementComponent {
  state = inject(NGOStateService);
}
