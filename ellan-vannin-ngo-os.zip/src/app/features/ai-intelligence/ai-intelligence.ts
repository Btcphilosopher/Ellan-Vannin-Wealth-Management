import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NGOStateService } from '../../core/services/ngo-state.service';

@Component({
  selector: 'app-ai-intelligence',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded">
              GEMINI 3.8 FLASH ENGINE
            </span>
            <span class="text-xs text-slate-400 font-mono">SERVER-SIDE AI ORCHESTRATION</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Institutional AI Intelligence & Fraud Anomaly Engine
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            AI Proposal Analysis • Board Briefing Automation • Anomaly Fraud Signals • Scenario Stress Tests
          </p>
        </div>
      </div>

      <!-- Anomaly Signals Panel -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 class="text-sm font-bold text-slate-900 flex items-center gap-2">
            <span class="material-icons text-amber-600 text-base">psychology</span>
            Active Fraud & Financial Anomaly Detection Queue
          </h3>
          <span class="text-xs font-mono text-slate-500 font-bold">{{ state.unresolvedAnomaliesCount() }} Pending Human Review</span>
        </div>

        <div class="space-y-4 mt-4">
          @for (sig of state.anomalySignals(); track sig.id) {
            <div class="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 bg-amber-100 text-amber-900 font-mono font-bold text-[10px] rounded">{{ sig.category }}</span>
                  <span class="text-xs font-mono font-bold text-slate-800">Risk Score: {{ sig.riskScore }}/100</span>
                </div>
                <span class="text-xs font-mono text-slate-500 font-bold">{{ sig.humanDecision }}</span>
              </div>

              <p class="text-xs text-slate-800 font-medium leading-relaxed">{{ sig.detectedDetail }}</p>

              <div class="pt-2 border-t border-slate-200 flex justify-between items-center text-[11px] text-slate-500">
                <span>Timestamp: {{ sig.timestamp | date:'medium' }}</span>
                <div class="flex gap-2">
                  <button (click)="markReviewed(sig.id, 'VERIFIED_GENUINE')" class="px-2.5 py-1 bg-emerald-600 text-white font-bold rounded text-[10px]">
                    Approve Variance
                  </button>
                  <button (click)="markReviewed(sig.id, 'BLOCKED_FRAUD')" class="px-2.5 py-1 bg-red-600 text-white font-bold rounded text-[10px]">
                    Escalate to Audit
                  </button>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class AiIntelligenceComponent {
  state = inject(NGOStateService);

  markReviewed(id: string, decision: 'PENDING_REVIEW' | 'VERIFIED_GENUINE' | 'BLOCKED_FRAUD' | 'EXPLAINED_VARIANCE') {
    const updated = this.state.anomalySignals().map((s) => {
      if (s.id === id) {
        return { ...s, humanDecision: decision };
      }
      return s;
    });
    this.state.anomalySignals.set(updated);
  }
}
