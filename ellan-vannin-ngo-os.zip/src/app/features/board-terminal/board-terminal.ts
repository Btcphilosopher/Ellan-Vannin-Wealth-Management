import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NGOStateService } from '../../core/services/ngo-state.service';

export interface BoardBriefingData {
  confidenceRating: string;
  executiveSummary: string;
  keyFinancialHighlights: string[];
  governanceActionItems: string[];
}

@Component({
  selector: 'app-board-terminal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Board Terminal Header -->
      <div class="bg-slate-950 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded">
              BOARD GOVERNANCE OS
            </span>
            <span class="text-xs text-slate-400 font-mono">ROLE: BOARD TRUSTEE / CHAIR</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Board Governance & Fiduciary Oversight Terminal
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            Board Packs • Committee Resolutions • Delegated Authority Matrix • Audit Integrity
          </p>
        </div>

        <button (click)="generateBoardPack()" class="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs rounded shadow-xs transition flex items-center gap-1.5">
          <span class="material-icons text-sm">auto_awesome</span>
          Generate AI Board Pack
        </button>
      </div>

      <!-- AI Board Pack Display -->
      @if (aiBriefing()) {
        <div class="bg-amber-950/40 border border-amber-800/80 rounded-xl p-5 text-amber-100 space-y-4">
          <div class="flex items-center justify-between border-b border-amber-800/60 pb-3">
            <div class="flex items-center gap-2">
              <span class="material-icons text-amber-400">gavel</span>
              <h3 class="text-sm font-bold text-amber-300">AI Executive Board Briefing (Server-Side Generated)</h3>
            </div>
            <span class="text-xs font-mono bg-amber-900/60 px-2 py-0.5 rounded text-amber-300">Confidence: {{ aiBriefing()?.confidenceRating }}</span>
          </div>

          <p class="text-xs leading-relaxed text-amber-200/90 font-medium">{{ aiBriefing()?.executiveSummary }}</p>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-2">
            <div>
              <h4 class="font-bold text-amber-300 mb-1 uppercase tracking-wider text-[10px]">Financial & Capital Highlights</h4>
              <ul class="list-disc list-inside space-y-1 text-amber-200/80">
                @for (item of aiBriefing()?.keyFinancialHighlights; track item) {
                  <li>{{ item }}</li>
                }
              </ul>
            </div>

            <div>
              <h4 class="font-bold text-amber-300 mb-1 uppercase tracking-wider text-[10px]">Governance Action Items</h4>
              <ul class="list-disc list-inside space-y-1 text-amber-200/80">
                @for (action of aiBriefing()?.governanceActionItems; track action) {
                  <li>{{ action }}</li>
                }
              </ul>
            </div>
          </div>
        </div>
      }

      <!-- Board Resolutions List -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 class="text-sm font-bold text-slate-900 flex items-center gap-2">
            <span class="material-icons text-slate-700 text-base">gavel</span>
            Formal Board Resolutions & Committee Mandates
          </h3>
        </div>

        <div class="divide-y divide-slate-100 mt-3">
          @for (res of state.boardResolutions(); track res.id) {
            <div class="py-4 space-y-2">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 bg-slate-100 text-slate-800 font-mono font-bold text-[10px] rounded">{{ res.resolutionNumber }}</span>
                  <span class="px-2 py-0.5 bg-amber-100 text-amber-900 font-mono font-bold text-[10px] rounded">{{ res.committee }}</span>
                  <h4 class="text-xs font-bold text-slate-900">{{ res.title }}</h4>
                </div>

                <span class="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold text-[10px] rounded">{{ res.status }}</span>
              </div>

              <p class="text-xs text-slate-600 leading-relaxed">{{ res.description }}</p>

              <div class="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-1">
                <span>Meeting: {{ res.meetingDate }} • Voting: <strong class="text-slate-800">{{ res.votingOutcome }}</strong></span>
                <span>Responsible Officer: <strong class="text-slate-800">{{ res.responsibleOfficer }}</strong> (Due: {{ res.actionDueDate }})</span>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class BoardTerminalComponent {
  state = inject(NGOStateService);
  aiBriefing = signal<BoardBriefingData | null>(null);

  generateBoardPack() {
    this.state.generateBoardPack().subscribe((res: { success: boolean; briefing: Record<string, unknown> }) => {
      if (res && res.briefing) {
        this.aiBriefing.set(res.briefing as unknown as BoardBriefingData);
      }
    });
  }
}
