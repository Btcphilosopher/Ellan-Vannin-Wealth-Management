import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NGOStateService } from '../../core/services/ngo-state.service';

@Component({
  selector: 'app-safeguarding-risk',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-red-500/20 text-red-400 border border-red-500/30 rounded">
              CONFIDENTIAL RISK ENGINE
            </span>
            <span class="text-xs text-slate-400 font-mono">SAFEGUARDING & RISK REGISTER</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Institutional Risk Register & Safeguarding Compliance
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            5x5 Risk Heatmap Matrix • Confidential Case Log • Whistleblower Integrity
          </p>
        </div>
      </div>

      <!-- Risk Register Table -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
          <span class="material-icons text-amber-600 text-base">warning</span>
          Active Enterprise Risk Heatmap Register
        </h3>

        <div class="overflow-x-auto mt-4">
          <table class="w-full text-left text-xs text-slate-700">
            <thead class="bg-slate-50 border-y border-slate-200 font-mono text-[11px] uppercase text-slate-500">
              <tr>
                <th class="p-2.5">Category & Code</th>
                <th class="p-2.5">Risk Description</th>
                <th class="p-2.5 text-center">Probability x Impact</th>
                <th class="p-2.5">Mitigation Strategy</th>
                <th class="p-2.5 text-center">Residual Score</th>
                <th class="p-2.5">Risk Owner</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (r of state.risks(); track r.id) {
                <tr class="hover:bg-slate-50/80">
                  <td class="p-2.5">
                    <div class="font-bold text-slate-900">{{ r.category }}</div>
                    <div class="font-mono text-[10px] text-slate-400">{{ r.code }}</div>
                  </td>
                  <td class="p-2.5 text-slate-800 font-medium max-w-xs">{{ r.description }}</td>
                  <td class="p-2.5 text-center font-mono text-slate-500">{{ r.probability }}x{{ r.impact }} ({{ r.probability * r.impact }})</td>
                  <td class="p-2.5 text-slate-600 text-[11px]">{{ r.mitigationStrategy }}</td>
                  <td class="p-2.5 text-center">
                    <span 
                      class="px-2 py-0.5 rounded font-mono font-bold text-[10px]"
                      [ngClass]="{
                        'bg-red-100 text-red-800': r.residualScore >= 12,
                        'bg-amber-100 text-amber-800': r.residualScore >= 8 && r.residualScore < 12,
                        'bg-emerald-100 text-emerald-800': r.residualScore < 8
                      }"
                    >
                      {{ r.residualScore }}/25
                    </span>
                  </td>
                  <td class="p-2.5 font-medium text-slate-800">{{ r.owner }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Safeguarding Register (Sanitized PII) -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
          <span class="material-icons text-red-600 text-base">privacy_tip</span>
          Confidential Safeguarding Cases (PII Masked)
        </h3>

        <div class="space-y-3 mt-4">
          @for (c of state.safeguardingCases(); track c.id) {
            <div class="p-3 bg-red-50/30 border border-red-200/60 rounded-lg text-xs space-y-1">
              <div class="flex items-center justify-between font-bold text-slate-900">
                <span>{{ c.referenceNo }} • Severity: {{ c.severity }}</span>
                <span class="px-2 py-0.5 bg-red-100 text-red-800 rounded font-mono text-[10px]">{{ c.status }}</span>
              </div>
              <p class="text-slate-700 font-mono text-[11px]">Type: {{ c.incidentType }} • Country: {{ c.country }} ({{ c.fieldOffice }})</p>
              <div class="text-[10px] text-slate-500 pt-1 font-mono">
                Reported: {{ c.reportDate }} • Confidential Investigator: {{ c.confidentialInvestigator }}
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class SafeguardingRiskComponent {
  state = inject(NGOStateService);
}
