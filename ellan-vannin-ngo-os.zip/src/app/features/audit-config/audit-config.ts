import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NGOStateService } from '../../core/services/ngo-state.service';

@Component({
  selector: 'app-audit-config',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-slate-700 text-slate-200 border border-slate-600 rounded">
              TENANT & AUDIT OS
            </span>
            <span class="text-xs text-slate-400 font-mono">WHITE-LABEL & PROVENANCE ENGINE</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Audit Provenance Engine & White-Label Customization
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            Cryptographic Action Log • Multi-jurisdiction Compliance • Organization Identity
          </p>
        </div>
      </div>

      <!-- White-Label Customization Form -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
          <span class="material-icons text-slate-700 text-base">palette</span>
          Sovereign Tenant Branding & Legal Identity
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 text-xs">
          <div>
            <label for="orgName" class="block font-medium text-slate-700">Organisation Name</label>
            <input id="orgName" [(ngModel)]="orgName" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
          </div>

          <div>
            <label for="legalEntity" class="block font-medium text-slate-700">Legal Entity Registration</label>
            <input id="legalEntity" [(ngModel)]="legalEntity" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
          </div>

          <div>
            <label for="hq" class="block font-medium text-slate-700">Headquarters Jurisdiction</label>
            <input id="hq" [(ngModel)]="hq" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
          </div>

          <div class="flex items-end">
            <button (click)="saveWhiteLabel()" class="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded shadow-xs text-xs">
              Save Sovereign Branding Config
            </button>
          </div>
        </div>
      </div>

      <!-- Audit Logs Table -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
          <span class="material-icons text-slate-700 text-base">history_edu</span>
          Immutable Audit Engine Records
        </h3>

        <div class="overflow-x-auto mt-4">
          <table class="w-full text-left text-xs text-slate-700">
            <thead class="bg-slate-50 border-y border-slate-200 font-mono text-[11px] uppercase text-slate-500">
              <tr>
                <th class="p-2.5">Audit ID</th>
                <th class="p-2.5">Event Type</th>
                <th class="p-2.5">Actor & Role</th>
                <th class="p-2.5">Jurisdiction</th>
                <th class="p-2.5">SHA-256 Provenance Hash</th>
                <th class="p-2.5">Timestamp</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (log of state.auditLogs(); track log.id) {
                <tr class="hover:bg-slate-50/80 font-mono">
                  <td class="p-2.5 font-bold text-slate-900">{{ log.id }}</td>
                  <td class="p-2.5 font-bold text-indigo-700">{{ log.eventType }}</td>
                  <td class="p-2.5 text-slate-800">{{ log.actor }} ({{ log.actorRole }})</td>
                  <td class="p-2.5 text-slate-600">{{ log.jurisdiction }}</td>
                  <td class="p-2.5 text-[10px] text-slate-500 max-w-xs truncate">{{ log.provenance }}</td>
                  <td class="p-2.5 text-slate-500 text-[11px]">{{ log.timestamp | date:'short' }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class AuditConfigComponent {
  state = inject(NGOStateService);

  orgName = this.state.tenantConfig().organisationName;
  legalEntity = this.state.tenantConfig().legalEntity;
  hq = this.state.tenantConfig().headquarters;

  saveWhiteLabel() {
    this.state
      .updateWhiteLabel({
        organisationName: this.orgName,
        legalEntity: this.legalEntity,
        headquarters: this.hq,
      })
      .subscribe(() => {
        this.state.loadState();
      });
  }
}
