import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NGOStateService } from '../../core/services/ngo-state.service';

@Component({
  selector: 'app-field-operations',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Field Operations Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded">
              OFFLINE-FIRST FIELD ENGINE
            </span>
            <span class="text-xs text-slate-400 font-mono">ROLE: FIELD OFFICER / MONITOR</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Field Operations & Offline Synchronization Gateway
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            Encrypted SQLite Local Queue • Conflict Resolution • Satellite Sync
          </p>
        </div>

        <button (click)="syncNow()" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded shadow-xs transition flex items-center gap-1.5">
          <span class="material-icons text-sm" [ngClass]="{'animate-spin': syncing()}">sync</span>
          Sync Pending Queue ({{ pendingQueue().length }})
        </button>
      </div>

      <!-- Sync Status & Beneficiaries -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span class="text-[11px] font-bold text-slate-500 uppercase">Local Queue Records</span>
          <div class="text-xl font-mono font-bold text-slate-900 mt-1">{{ pendingQueue().length }} Batched</div>
          <div class="text-[11px] text-slate-500 mt-1">Biometric Hash Secured</div>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span class="text-[11px] font-bold text-slate-500 uppercase">Last Network Handshake</span>
          <div class="text-xl font-mono font-bold text-emerald-700 mt-1">Online (Sat-Link)</div>
          <div class="text-[11px] text-slate-500 mt-1">Latency: 140ms • Bandwidth: 1.2Mbps</div>
        </div>

        <div class="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <span class="text-[11px] font-bold text-slate-500 uppercase">Conflict Resolution</span>
          <div class="text-xl font-mono font-bold text-slate-900 mt-1">Auto-Merge</div>
          <div class="text-[11px] text-slate-500 mt-1">Server Authoritative Integrity</div>
        </div>
      </div>

      <!-- Beneficiary Cases Table -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
          <span class="material-icons text-slate-700 text-base">people</span>
          Verified Beneficiary Registration Cases
        </h3>

        <div class="overflow-x-auto mt-4">
          <table class="w-full text-left text-xs text-slate-700">
            <thead class="bg-slate-50 border-y border-slate-200 font-mono text-[11px] uppercase text-slate-500">
              <tr>
                <th class="p-2.5">Case Reference</th>
                <th class="p-2.5">Pseudonym Identity</th>
                <th class="p-2.5">Country & Field Office</th>
                <th class="p-2.5">Category</th>
                <th class="p-2.5">Confidentiality</th>
                <th class="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              @for (c of state.beneficiaryCases(); track c.id) {
                <tr class="hover:bg-slate-50/80">
                  <td class="p-2.5 font-mono font-bold text-slate-900">{{ c.caseNumber }}</td>
                  <td class="p-2.5 font-medium text-slate-800">{{ c.pseudonym }}</td>
                  <td class="p-2.5 text-slate-600">{{ c.country }} • {{ c.fieldOffice }}</td>
                  <td class="p-2.5">
                    <span class="px-2 py-0.5 bg-indigo-100 text-indigo-800 font-mono font-bold text-[10px] rounded">{{ c.category }}</span>
                  </td>
                  <td class="p-2.5 font-mono text-[10px] text-slate-500">{{ c.confidentialityLevel }}</td>
                  <td class="p-2.5 font-bold text-emerald-700 text-[10px]">{{ c.status }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class FieldOperationsComponent {
  state = inject(NGOStateService);
  syncing = signal(false);

  pendingQueue = signal([
    { type: 'BENEFICIARY_REGISTRATION', location: 'Bentiu Camp 2', hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' },
    { type: 'DISTRIBUTION_VOUCHER', location: 'Gulu Market', hash: 'f2ca1bb6c7e907d06dafe4687e579fce76b37e4e93b7605022da52e6ccc26fd2' },
  ]);

  syncNow() {
    this.syncing.set(true);
    this.state
      .syncFieldData({
        records: this.pendingQueue(),
        deviceMac: 'FC-88-99-A1-22-33',
        officerId: 'FO-UG-99',
      })
      .subscribe(() => {
        this.syncing.set(false);
        this.pendingQueue.set([]);
        this.state.loadState();
      });
  }
}
