import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NGOStateService } from '../../core/services/ngo-state.service';

@Component({
  selector: 'app-programme-terminal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded">
              PROGRAMME & EVIDENCE ENGINE
            </span>
            <span class="text-xs text-slate-400 font-mono">ROLE: PROGRAMME DIRECTOR</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Programmatic Operations & Evidence Provenance Chain
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            Theory of Change • Activity Execution • Cryptographic Evidence Verification
          </p>
        </div>

        <button (click)="openEvidenceModal()" class="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded shadow-xs transition flex items-center gap-1.5">
          <span class="material-icons text-sm">verified</span>
          Upload Hashed Evidence
        </button>
      </div>

      <!-- Evidence Provenance Stream -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 class="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100 flex items-center gap-2">
          <span class="material-icons text-emerald-600 text-base">verified</span>
          Verified Evidence Provenance Items
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          @for (ev of state.evidenceItems(); track ev.id) {
            <div class="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div class="flex items-center justify-between">
                <span class="font-bold text-slate-900 text-xs">{{ ev.title }}</span>
                <span class="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-mono font-bold text-[10px] rounded">{{ ev.verificationStatus }}</span>
              </div>
              <p class="text-xs text-slate-600 leading-relaxed">{{ ev.summary }}</p>
              <div class="pt-2 border-t border-slate-200 flex justify-between items-center text-[10px] font-mono text-slate-500">
                <span>Location: {{ ev.location }}</span>
                <span class="text-slate-400 truncate max-w-[180px]">{{ ev.fileHash }}</span>
              </div>
            </div>
          }
        </div>
      </div>
    </div>

    <!-- Upload Evidence Modal -->
    @if (showEvidenceModal()) {
      <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
        <div class="bg-white border border-slate-300 rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-200 pb-3">
            <h3 class="text-base font-bold text-slate-900 flex items-center gap-2">
              <span class="material-icons text-emerald-600">verified</span>
              Submit Cryptographic Evidence Item
            </h3>
            <button (click)="closeEvidenceModal()" class="text-slate-400 hover:text-slate-600">
              <span class="material-icons text-lg">close</span>
            </button>
          </div>

          <div class="space-y-3 text-xs">
            <div>
              <label for="evTitle" class="block font-medium text-slate-700">Evidence Title</label>
              <input id="evTitle" [(ngModel)]="evTitle" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
            </div>

            <div>
              <label for="evLocation" class="block font-medium text-slate-700">Field Location / GPS Bounds</label>
              <input id="evLocation" [(ngModel)]="evLocation" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs" />
            </div>

            <div>
              <label for="evSummary" class="block font-medium text-slate-700">Observation Summary & Impact Proof</label>
              <textarea id="evSummary" [(ngModel)]="evSummary" rows="3" class="w-full mt-1 p-2 border border-slate-300 rounded text-xs"></textarea>
            </div>
          </div>

          <div class="flex justify-end gap-2 pt-2 border-t border-slate-200">
            <button (click)="closeEvidenceModal()" class="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium">Cancel</button>
            <button (click)="submitEvidence()" class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded shadow-xs">
              Calculate Hash & Submit
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class ProgrammeTerminalComponent {
  state = inject(NGOStateService);

  showEvidenceModal = signal(false);
  evTitle = 'Solar Pump Inspection Report & IoT Calibration Logs';
  evLocation = 'Turkana Sector 4 (-1.283, 36.816)';
  evSummary = 'IoT Flow meters confirmed 12,400 Litres/day clean water output matching baseline metrics.';

  openEvidenceModal() {
    this.showEvidenceModal.set(true);
  }

  closeEvidenceModal() {
    this.showEvidenceModal.set(false);
  }

  submitEvidence() {
    this.state
      .uploadEvidence({
        title: this.evTitle,
        location: this.evLocation,
        summary: this.evSummary,
        creator: 'Field Officer Mark',
      })
      .subscribe(() => {
        this.state.loadState();
        this.closeEvidenceModal();
      });
  }
}
