import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NGOStateService } from '../../core/services/ngo-state.service';

@Component({
  selector: 'app-ceo-strategy',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- CEO Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 text-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 text-[10px] font-mono font-bold bg-purple-500/20 text-purple-400 border border-purple-500/30 rounded">
              EXECUTIVE & STRATEGY OS
            </span>
            <span class="text-xs text-slate-400 font-mono">ROLE: CHIEF EXECUTIVE OFFICER</span>
          </div>
          <h1 class="text-xl font-bold tracking-tight text-white mt-1">
            Institutional Mission & Theory of Change Strategy Terminal
          </h1>
          <p class="text-xs text-slate-400 mt-0.5">
            Mission → Strategic Objectives → Theory of Change → Impact Verification Traceability
          </p>
        </div>
      </div>

      <!-- Strategic Objectives Grid -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 class="text-sm font-bold text-slate-900 flex items-center gap-2">
            <span class="material-icons text-purple-600 text-base">flag</span>
            Institutional 2030 Strategic Priorities & Progress
          </h3>
          <span class="text-xs font-mono text-slate-500">{{ state.strategicObjectives().length }} Core Strategic Pillars</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
          @for (so of state.strategicObjectives(); track so.id) {
            <div class="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div class="flex items-center justify-between">
                <span class="px-2 py-0.5 bg-purple-100 text-purple-800 font-mono font-bold text-[10px] rounded">{{ so.code }}</span>
                <span class="text-xs font-mono font-bold text-slate-700">Target Year: {{ so.targetYear }}</span>
              </div>

              <div>
                <h4 class="text-xs font-bold text-slate-900">{{ so.title }}</h4>
                <p class="text-[11px] text-slate-600 mt-1 leading-relaxed">{{ so.description }}</p>
              </div>

              <div class="space-y-1">
                <div class="flex justify-between text-[11px] text-slate-600 font-medium">
                  <span>Strategy Progress</span>
                  <span class="font-bold text-purple-800">{{ so.progressPct }}%</span>
                </div>
                <div class="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div class="bg-purple-600 h-full rounded-full" [style.width.%]="so.progressPct"></div>
                </div>
              </div>

              <div class="pt-2 border-t border-slate-200 text-[11px] space-y-1 text-slate-600">
                <div>Target: <strong class="text-slate-900">{{ so.kpiTarget }}</strong></div>
                <div>Current: <strong class="text-emerald-700">{{ so.kpiCurrent }}</strong></div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Theory of Change Dependency Graph View -->
      <div class="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div class="flex items-center justify-between pb-3 border-b border-slate-100">
          <h3 class="text-sm font-bold text-slate-900 flex items-center gap-2">
            <span class="material-icons text-indigo-600 text-base">schema</span>
            Theory of Change Causal Engine (Inputs → Activities → Outputs → Outcomes → Impact)
          </h3>
          <span class="text-xs font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold">Evidence Hashed</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-5 gap-3 mt-4 text-center">
          <!-- Step 1: Capital Inputs -->
          <div class="p-3 bg-slate-900 text-slate-100 rounded-lg border border-slate-800">
            <div class="text-[10px] uppercase text-indigo-400 font-mono font-bold">1. Inputs</div>
            <div class="text-sm font-bold mt-1">\${{ (state.totalMoneyRaised() / 1000000).toFixed(1) }}M</div>
            <div class="text-[10px] text-slate-400 mt-0.5">Grants & Capital</div>
          </div>

          <!-- Step 2: Activities -->
          <div class="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <div class="text-[10px] uppercase text-slate-500 font-mono font-bold">2. Activities</div>
            <div class="text-sm font-bold text-slate-900 mt-1">{{ state.activities().length }} Field Ops</div>
            <div class="text-[10px] text-slate-500 mt-0.5">Solar, Clinics, Water</div>
          </div>

          <!-- Step 3: Outputs -->
          <div class="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <div class="text-[10px] uppercase text-slate-500 font-mono font-bold">3. Outputs</div>
            <div class="text-sm font-bold text-slate-900 mt-1">14 Clinics / 8 Boreholes</div>
            <div class="text-[10px] text-slate-500 mt-0.5">Physical Deliverables</div>
          </div>

          <!-- Step 4: Intermediate Outcomes -->
          <div class="p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <div class="text-[10px] uppercase text-slate-500 font-mono font-bold">4. Outcomes</div>
            <div class="text-sm font-bold text-emerald-700 mt-1">674,000 Reached</div>
            <div class="text-[10px] text-slate-500 mt-0.5">22.4L/day Potable Water</div>
          </div>

          <!-- Step 5: Verified Impact -->
          <div class="p-3 bg-emerald-950 text-emerald-100 rounded-lg border border-emerald-800">
            <div class="text-[10px] uppercase text-emerald-400 font-mono font-bold">5. Impact</div>
            <div class="text-sm font-bold text-white mt-1">40% Mortality Drop</div>
            <div class="text-[10px] text-emerald-300/80 mt-0.5">External Evaluation</div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class CeoStrategyComponent {
  state = inject(NGOStateService);
}
