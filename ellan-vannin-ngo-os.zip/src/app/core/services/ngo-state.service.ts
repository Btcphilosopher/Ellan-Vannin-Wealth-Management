import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  NGOUserRole,
  CurrencyCode,
  Donor,
  RestrictedFund,
  Grant,
  Programme,
  StrategicObjective,
  ProjectActivity,
  EvidenceItem,
  IndicatorMetric,
  LedgerAccount,
  PurchaseOrder,
  InventoryShipment,
  BeneficiaryCase,
  RiskItem,
  SafeguardingCase,
  BoardResolution,
  AnomalySignal,
  AuditEvent,
} from '../models/ngo-domain';

export interface StateResponse {
  tenantConfig?: {
    organisationName: string;
    legalEntity: string;
    headquarters: string;
    defaultCurrency: CurrencyCode;
    activeCountriesCount: number;
    fieldOfficesCount: number;
    branding: { primaryColor: string; accentColor: string };
  };
  donors?: Donor[];
  restrictedFunds?: RestrictedFund[];
  grants?: Grant[];
  programmes?: Programme[];
  strategicObjectives?: StrategicObjective[];
  activities?: ProjectActivity[];
  evidenceItems?: EvidenceItem[];
  indicators?: IndicatorMetric[];
  ledgerAccounts?: LedgerAccount[];
  purchaseOrders?: PurchaseOrder[];
  inventoryShipments?: InventoryShipment[];
  beneficiaryCases?: BeneficiaryCase[];
  risks?: RiskItem[];
  safeguardingCases?: SafeguardingCase[];
  boardResolutions?: BoardResolution[];
  anomalySignals?: AnomalySignal[];
  auditLogs?: AuditEvent[];
}

@Injectable({
  providedIn: 'root',
})
export class NGOStateService {
  private http = inject(HttpClient);

  // Active Context
  activeRole = signal<NGOUserRole>('CEO');
  activeCurrency = signal<CurrencyCode>('USD');

  // Tenant Config
  tenantConfig = signal<{
    organisationName: string;
    legalEntity: string;
    headquarters: string;
    defaultCurrency: CurrencyCode;
    activeCountriesCount: number;
    fieldOfficesCount: number;
    branding: { primaryColor: string; accentColor: string };
  }>({
    organisationName: 'ELLAN VANNIN GLOBAL INITIATIVE',
    legalEntity: 'Ellan Vannin International Foundation (#1109482)',
    headquarters: 'Douglas, Isle of Man & London, UK',
    defaultCurrency: 'USD',
    activeCountriesCount: 14,
    fieldOfficesCount: 28,
    branding: { primaryColor: '#0f172a', accentColor: '#059669' },
  });

  // Domain Collections
  donors = signal<Donor[]>([]);
  restrictedFunds = signal<RestrictedFund[]>([]);
  grants = signal<Grant[]>([]);
  programmes = signal<Programme[]>([]);
  strategicObjectives = signal<StrategicObjective[]>([]);
  activities = signal<ProjectActivity[]>([]);
  evidenceItems = signal<EvidenceItem[]>([]);
  indicators = signal<IndicatorMetric[]>([]);
  ledgerAccounts = signal<LedgerAccount[]>([]);
  purchaseOrders = signal<PurchaseOrder[]>([]);
  inventoryShipments = signal<InventoryShipment[]>([]);
  beneficiaryCases = signal<BeneficiaryCase[]>([]);
  risks = signal<RiskItem[]>([]);
  safeguardingCases = signal<SafeguardingCase[]>([]);
  boardResolutions = signal<BoardResolution[]>([]);
  anomalySignals = signal<AnomalySignal[]>([]);
  auditLogs = signal<AuditEvent[]>([]);

  // Computed Financial Integrity Metrics
  totalMoneyRaised = computed(() => {
    return this.donors().reduce((sum, d) => sum + d.lifetimeGiving, 0);
  });

  totalMoneyCommitted = computed(() => {
    return this.restrictedFunds().reduce((sum, f) => sum + f.committed, 0);
  });

  totalMoneyRestricted = computed(() => {
    return this.restrictedFunds()
      .filter((f) => f.type !== 'UNRESTRICTED')
      .reduce((sum, f) => sum + f.remaining, 0);
  });

  totalMoneyUnrestricted = computed(() => {
    const unres = this.restrictedFunds().find((f) => f.type === 'UNRESTRICTED');
    return unres ? unres.remaining : 8700000;
  });

  totalMoneySpent = computed(() => {
    return this.restrictedFunds().reduce((sum, f) => sum + f.spent, 0);
  });

  totalMoneyRemaining = computed(() => {
    return this.restrictedFunds().reduce((sum, f) => sum + f.remaining, 0);
  });

  totalBeneficiariesReached = computed(() => {
    return this.programmes().reduce((sum, p) => sum + p.reachedBeneficiaries, 0);
  });

  totalVerifiedOutcomes = computed(() => {
    return this.indicators().reduce((sum, i) => sum + i.actual, 0);
  });

  daysCashOnHand = computed(() => 142);

  unresolvedAnomaliesCount = computed(() => {
    return this.anomalySignals().filter((s) => s.humanDecision === 'PENDING_REVIEW').length;
  });

  criticalRisksCount = computed(() => {
    return this.risks().filter((r) => r.residualScore >= 15).length;
  });

  activeSafeguardingCasesCount = computed(() => {
    return this.safeguardingCases().filter((c) => c.status !== 'CLOSED').length;
  });

  constructor() {
    this.loadState();
  }

  loadState() {
    this.http.get<StateResponse>('/api/ngo/state').subscribe({
      next: (data: StateResponse) => {
        if (data.tenantConfig) this.tenantConfig.set(data.tenantConfig);
        if (data.donors) this.donors.set(data.donors);
        if (data.restrictedFunds) this.restrictedFunds.set(data.restrictedFunds);
        if (data.grants) this.grants.set(data.grants);
        if (data.programmes) this.programmes.set(data.programmes);
        if (data.strategicObjectives) this.strategicObjectives.set(data.strategicObjectives);
        if (data.activities) this.activities.set(data.activities);
        if (data.evidenceItems) this.evidenceItems.set(data.evidenceItems);
        if (data.indicators) this.indicators.set(data.indicators);
        if (data.ledgerAccounts) this.ledgerAccounts.set(data.ledgerAccounts);
        if (data.purchaseOrders) this.purchaseOrders.set(data.purchaseOrders);
        if (data.inventoryShipments) this.inventoryShipments.set(data.inventoryShipments);
        if (data.beneficiaryCases) this.beneficiaryCases.set(data.beneficiaryCases);
        if (data.risks) this.risks.set(data.risks);
        if (data.safeguardingCases) this.safeguardingCases.set(data.safeguardingCases);
        if (data.boardResolutions) this.boardResolutions.set(data.boardResolutions);
        if (data.anomalySignals) this.anomalySignals.set(data.anomalySignals);
        if (data.auditLogs) this.auditLogs.set(data.auditLogs);
      },
      error: (err: unknown) => console.error('Failed to load NGO state:', err),
    });
  }

  recordTransaction(payload: Record<string, unknown>) {
    return this.http.post<{ success: boolean; message: string; audit: AuditEvent }>('/api/ngo/transaction', {
      ...payload,
      actorRole: this.activeRole(),
    });
  }

  passBoardResolution(payload: Record<string, unknown>) {
    return this.http.post<{ success: boolean; resolution: BoardResolution; audit: AuditEvent }>('/api/ngo/board-resolution', payload);
  }

  uploadEvidence(payload: Record<string, unknown>) {
    return this.http.post<{ success: boolean; evidence: EvidenceItem; audit: AuditEvent }>('/api/ngo/evidence-upload', payload);
  }

  syncFieldData(payload: Record<string, unknown>) {
    return this.http.post<{ success: boolean; syncedCount: number; audit: AuditEvent }>('/api/ngo/field-sync', payload);
  }

  analyzeProposal(payload: Record<string, unknown>) {
    return this.http.post<{ success: boolean; analysis: Record<string, unknown> }>('/api/ngo/ai-proposal-analysis', payload);
  }

  generateBoardPack() {
    return this.http.post<{ success: boolean; briefing: Record<string, unknown> }>('/api/ngo/ai-board-briefing', {});
  }

  runScenario(payload: Record<string, unknown>) {
    return this.http.post<{ success: boolean; scenario: Record<string, unknown> }>('/api/ngo/scenario-model', payload);
  }

  updateWhiteLabel(payload: Record<string, unknown>) {
    return this.http.post<{ success: boolean; tenantConfig: Record<string, unknown> }>('/api/ngo/white-label', payload);
  }
}
