export type NGOUserRole = 
  | 'CEO'
  | 'CFO'
  | 'COO'
  | 'ProgrammeDirector'
  | 'CountryDirector'
  | 'FinanceDirector'
  | 'FundraisingDirector'
  | 'GrantManager'
  | 'ProjectManager'
  | 'FieldOfficer'
  | 'SafeguardingOfficer'
  | 'ComplianceOfficer'
  | 'Auditor'
  | 'BoardMember'
  | 'Treasurer'
  | 'Donor'
  | 'ExternalPartner'
  | 'Volunteer';

export type CurrencyCode = 'USD' | 'GBP' | 'EUR' | 'CHF' | 'JPY' | 'KES' | 'UGX' | 'MMK' | 'SYP';

export type FundType = 'UNRESTRICTED' | 'RESTRICTED' | 'TEMP_RESTRICTED' | 'PERM_RESTRICTED';

export type GrantStatus = 'PIPELINE' | 'PROPOSAL_SUBMITTED' | 'AWARDED' | 'ACTIVE' | 'DISBURSED' | 'CLOSEOUT' | 'AUDITED';

export type ShipmentStatus = 'PLANNED' | 'PROCURED' | 'DISPATCHED' | 'IN_TRANSIT' | 'ARRIVED' | 'DISTRIBUTED' | 'CLOSED';

export type RiskSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type MetricType = 'INPUT' | 'ACTIVITY' | 'OUTPUT' | 'OUTCOME' | 'IMPACT';

export type VerificationConfidence = 'OBSERVED' | 'ESTIMATED' | 'MODELLED' | 'SELF_REPORTED' | 'EXTERNALLY_EVALUATED';

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor: string;
  actorRole: NGOUserRole;
  eventType: string;
  objectType: string;
  objectId: string;
  jurisdiction: string;
  beforeState?: string;
  afterState?: string;
  approvalAuthority?: string;
  evidenceHash?: string;
  provenance: string;
}

export interface Donor {
  id: string;
  name: string;
  type: 'GOVERNMENT' | 'FOUNDATION' | 'CORPORATE' | 'MULTILATERAL' | 'INDIVIDUAL_MAJOR';
  country: string;
  lifetimeGiving: number;
  annualGiving: number;
  committedGiving: number;
  pipeline: number;
  renewalProbability: number;
  restrictedRatio: number;
  currency: CurrencyCode;
  lastContact: string;
  stewardshipTier: 'STRATEGIC' | 'MAJOR' | 'STANDARD';
}

export interface RestrictedFund {
  id: string;
  code: string;
  name: string;
  donorId: string;
  donorName: string;
  type: FundType;
  totalAwarded: number;
  committed: number;
  allocated: number;
  spent: number;
  remaining: number;
  currency: CurrencyCode;
  expiryDate: string;
  restrictionsSummary: string;
  programmeId: string;
}

export interface Grant {
  id: string;
  code: string;
  title: string;
  donorId: string;
  donorName: string;
  fundId: string;
  amount: number;
  currency: CurrencyCode;
  startDate: string;
  endDate: string;
  status: GrantStatus;
  programmeId: string;
  country: string;
  matchRequirementPct: number;
  overheadAllowedPct: number;
  nextReportDue: string;
  reportingStatus: 'UP_TO_DATE' | 'DUE_SOON' | 'OVERDUE';
}

export interface Programme {
  id: string;
  code: string;
  name: string;
  sector: 'HUMANITARIAN' | 'HEALTH' | 'EDUCATION' | 'ENVIRONMENT' | 'GOVERNANCE' | 'PEACEBUILDING';
  leadDirector: string;
  countries: string[];
  budgetTotal: number;
  spentTotal: number;
  activeProjectsCount: number;
  targetBeneficiaries: number;
  reachedBeneficiaries: number;
  strategicObjectiveId: string;
  status: 'ACTIVE' | 'SCALING' | 'UNDER_REVIEW' | 'COMPLETED';
}

export interface StrategicObjective {
  id: string;
  code: string;
  title: string;
  description: string;
  targetYear: number;
  progressPct: number;
  alignedProgrammes: string[];
  kpiTarget: string;
  kpiCurrent: string;
  risksCount: number;
}

export interface ProjectActivity {
  id: string;
  projectId: string;
  projectName: string;
  programmeId: string;
  title: string;
  country: string;
  fieldOffice: string;
  budgetAllocated: number;
  budgetSpent: number;
  beneficiaryCount: number;
  startDate: string;
  endDate: string;
  status: 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED' | 'SUSPENDED';
  outputTarget: string;
  outputActual: string;
  evidenceCount: number;
}

export interface EvidenceItem {
  id: string;
  code: string;
  title: string;
  type: 'FIELD_REPORT' | 'SURVEY_DATA' | 'GEOSPATIAL_PHOTO' | 'THIRD_PARTY_EVAL' | 'FINANCIAL_AUDIT' | 'INTERVIEW';
  programmeId: string;
  activityId?: string;
  timestamp: string;
  creator: string;
  location: string;
  fileHash: string;
  confidence: VerificationConfidence;
  verificationStatus: 'VERIFIED' | 'PENDING' | 'FLAGGED';
  verifiedBy?: string;
  summary: string;
}

export interface IndicatorMetric {
  id: string;
  programmeId: string;
  programmeName: string;
  name: string;
  type: MetricType;
  baseline: number;
  target: number;
  actual: number;
  unit: string;
  confidence: VerificationConfidence;
  costPerOutcome: number;
  currency: CurrencyCode;
  evidenceIds: string[];
}

export interface LedgerAccount {
  accountCode: string;
  accountName: string;
  type: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  balance: number;
  fundType: FundType;
  currency: CurrencyCode;
}

export interface JournalTransaction {
  id: string;
  voucherNo: string;
  date: string;
  fundId: string;
  programmeId: string;
  grantId: string;
  country: string;
  amount: number;
  currency: CurrencyCode;
  debitAccount: string;
  creditAccount: string;
  description: string;
  postedBy: string;
  approvedBy: string;
  status: 'POSTED' | 'PENDING_APPROVAL' | 'REJECTED';
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierName: string;
  supplierTaxId: string;
  requesterName: string;
  department: string;
  country: string;
  amount: number;
  currency: CurrencyCode;
  itemsSummary: string;
  grantCode: string;
  status: 'REQUISITION' | 'PENDING_APPROVAL' | 'APPROVED' | 'DISPATCHED' | 'DELIVERED' | 'PAID';
  threeWayMatchVerified: boolean;
  sanctionsCleared: boolean;
}

export interface InventoryShipment {
  id: string;
  trackingNumber: string;
  description: string;
  originWarehouse: string;
  destinationFieldOffice: string;
  itemCategory: 'MEDICAL_SUPPLIES' | 'FOOD_RATIONS' | 'SHELTER_KITS' | 'WATER_PURIFICATION' | 'SOLAR_EQUIPMENT';
  quantityUnits: number;
  estimatedValueUSD: number;
  status: ShipmentStatus;
  dispatchedDate: string;
  estimatedArrival: string;
  custodianOfficer: string;
}

export interface BeneficiaryCase {
  id: string;
  caseNumber: string;
  pseudonym: string;
  country: string;
  fieldOffice: string;
  programmeId: string;
  category: 'DISPLACED_FAMILY' | 'MALNUTRITION_CARE' | 'EDUCATION_GRANT' | 'PROTECTION_SUPPORT' | 'LIVELIHOOD_AID';
  status: 'INTAKE' | 'ASSESSMENT' | 'ACTIVE_SUPPORT' | 'REFERRED' | 'CLOSED';
  intakeDate: string;
  confidentialityLevel: 'STANDARD' | 'RESTRICTED' | 'HIGHLY_CONFIDENTIAL';
  assignedOfficer: string;
  lastActivity: string;
}

export interface RiskItem {
  id: string;
  code: string;
  category: 'FINANCIAL' | 'OPERATIONAL' | 'POLITICAL' | 'SAFEGUARDING' | 'CYBERSECURITY' | 'CURRENCY' | 'LEGAL' | 'CLIMATE';
  description: string;
  country: string;
  probability: 1 | 2 | 3 | 4 | 5;
  impact: 1 | 2 | 3 | 4 | 5;
  residualScore: number;
  exposureUSD: number;
  mitigationStrategy: string;
  owner: string;
  reviewDate: string;
  status: 'MONITORED' | 'ESCALATED' | 'MITIGATED';
}

export interface SafeguardingCase {
  id: string;
  referenceNo: string;
  country: string;
  fieldOffice: string;
  incidentType: 'CODE_OF_CONDUCT' | 'EXPLOITATION' | 'CHILD_PROTECTION' | 'FINANCIAL_CORRUPTION' | 'HARASSMENT';
  severity: RiskSeverity;
  status: 'REPORTED' | 'UNDER_INVESTIGATION' | 'BOARD_ESCALATED' | 'ACTION_TAKEN' | 'CLOSED';
  reportDate: string;
  confidentialInvestigator: string;
  mandatoryReportingDone: boolean;
}

export interface BoardResolution {
  id: string;
  resolutionNumber: string;
  meetingDate: string;
  committee: 'EXECUTIVE_BOARD' | 'AUDIT_RISK_COMMITTEE' | 'FINANCE_GOVERNANCE' | 'PROGRAMME_IMPACT';
  title: string;
  description: string;
  status: 'PROPOSED' | 'APPROVED' | 'EXECUTION_IN_PROGRESS' | 'COMPLETED';
  votingOutcome: string;
  responsibleOfficer: string;
  actionDueDate: string;
}

export interface AnomalySignal {
  id: string;
  timestamp: string;
  category: 'DUPLICATE_INVOICE' | 'EXPENDITURE_SPIKE' | 'UNAUTHORIZED_SUPPLIER' | 'BUDGET_OVERRUN_RISK' | 'BENEFICIARY_DUPLICATION';
  entityType: string;
  entityId: string;
  riskScore: number;
  detectedDetail: string;
  humanDecision: 'PENDING_REVIEW' | 'VERIFIED_GENUINE' | 'BLOCKED_FRAUD' | 'EXPLAINED_VARIANCE';
  reviewedBy?: string;
}

export interface ScenarioParams {
  name: string;
  fundingChangePct: number;
  fxShockPct: number;
  inflationPct: number;
  emergencyBudgetUSD: number;
  projectedRevenueUSD: number;
  projectedExpenditureUSD: number;
  netDeficitUSD: number;
  daysCashOnHand: number;
  programmesAtRisk: string[];
}
