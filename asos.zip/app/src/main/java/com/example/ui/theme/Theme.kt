package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AsosWhite,
    secondary = AsosAccentLime,
    tertiary = AsosMutedGold,
    background = AsosBlack,
    surface = AsosCharcoal,
    onPrimary = AsosBlack,
    onSecondary = AsosBlack,
    onBackground = AsosWhite,
    onSurface = AsosWhite,
    outline = AsosGray
)

private val LightColorScheme = lightColorScheme(
    primary = AsosBlack,
    secondary = AsosBlack,
    tertiary = AsosCharcoal,
    background = AsosOffWhite,
    surface = AsosWhite,
    onPrimary = AsosWhite,
    onSecondary = AsosWhite,
    onBackground = AsosBlack,
    onSurface = AsosBlack,
    outline = AsosLightGray
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // We default to false to protect our highly curated ASOS brand visual identity
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
