package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.*
import com.example.ui.components.PremiumButton
import com.example.ui.components.PremiumOutlinedButton
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StyleStudioScreen(
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    val activeTop by viewModel.activeTop.collectAsState()
    val activeTrouser by viewModel.activeTrouser.collectAsState()
    val activeShoes by viewModel.activeShoes.collectAsState()
    val activeOuter by viewModel.activeOuter.collectAsState()
    val savedOutfits by viewModel.savedOutfits.collectAsState()

    val products by viewModel.products.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Outfit price calculations
    val outfitPrice = remember(activeTop, activeTrouser, activeShoes, activeOuter) {
        var total = 0.0
        activeTop?.let { total += it.price }
        activeTrouser?.let { total += it.price }
        activeShoes?.let { total += it.price }
        activeOuter?.let { total += it.price }
        total
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                Text(
                    text = "STYLE STUDIO",
                    style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "VISUAL WARDROBE CANVAS — DRAG & COMBINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = AsosGray
                )
            }

            // The Canvas container box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .background(AsosBlack)
                    .padding(20.dp)
                    .testTag("style_studio_canvas")
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Headline total
                    Text(
                        text = "OUTFIT TOTAL: £${"%.2f".format(outfitPrice)}",
                        style = MaterialTheme.typography.titleLarge,
                        color = AsosAccentLime,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    // Grid layout of layers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Col 1: Outers & Tops
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            OutfitCanvasSlot(
                                label = "OUTERWEAR LAYER",
                                product = activeOuter,
                                onCycle = {
                                    val outers = products.filter { it.subcategory == Subcategory.OUTERWEAR }
                                    if (outers.isNotEmpty()) {
                                        val curIdx = outers.indexOf(activeOuter)
                                        viewModel.activeOuter.value = outers[(curIdx + 1) % outers.size]
                                    }
                                },
                                onClear = { viewModel.activeOuter.value = null }
                            )

                            OutfitCanvasSlot(
                                label = "TOP / BLAZER",
                                product = activeTop,
                                onCycle = {
                                    val tops = products.filter { it.subcategory == Subcategory.TAILORING || it.subcategory == Subcategory.KNITWEAR || it.subcategory == Subcategory.ACTIVEWEAR }
                                    if (tops.isNotEmpty()) {
                                        val curIdx = tops.indexOf(activeTop)
                                        viewModel.activeTop.value = tops[(curIdx + 1) % tops.size]
                                    }
                                },
                                onClear = { viewModel.activeTop.value = null }
                            )
                        }

                        // Col 2: Trousers & Footwear
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            OutfitCanvasSlot(
                                label = "TROUSER / DENIM",
                                product = activeTrouser,
                                onCycle = {
                                    val bottoms = products.filter { it.subcategory == Subcategory.DENIM }
                                    if (bottoms.isNotEmpty()) {
                                        val curIdx = bottoms.indexOf(activeTrouser)
                                        viewModel.activeTrouser.value = bottoms[(curIdx + 1) % bottoms.size]
                                    }
                                },
                                onClear = { viewModel.activeTrouser.value = null }
                            )

                            OutfitCanvasSlot(
                                label = "FOOTWEAR",
                                product = activeShoes,
                                onCycle = {
                                    val shoes = products.filter { it.subcategory == Subcategory.RETRO_TRAINERS }
                                    if (shoes.isNotEmpty()) {
                                        val curIdx = shoes.indexOf(activeShoes)
                                        viewModel.activeShoes.value = shoes[(curIdx + 1) % shoes.size]
                                    }
                                },
                                onClear = { viewModel.activeShoes.value = null }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Studio Command Actions
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Shop all
                PremiumButton(
                    text = "SHOP ALL ITEMS (£${"%.2f".format(outfitPrice)})",
                    onClick = {
                        activeOuter?.let { viewModel.addToCart(it, "M", it.color) }
                        activeTop?.let { viewModel.addToCart(it, "M", it.color) }
                        activeTrouser?.let { viewModel.addToCart(it, "M", it.color) }
                        activeShoes?.let { viewModel.addToCart(it, "9", it.color) }
                        scope.launch {
                            snackbarHostState.showSnackbar("All styled canvas components were loaded into your shopping bag!")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "studio_shop_all"
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Save Outfit
                    PremiumOutlinedButton(
                        text = "SAVE OUTFIT",
                        onClick = {
                            viewModel.saveOutfit()
                            scope.launch {
                                snackbarHostState.showSnackbar("Outfit successfully saved to your style boards!")
                            }
                        },
                        modifier = Modifier.weight(1f),
                        testTag = "studio_save_outfit"
                    )

                    // Find alternatives (scrambles them)
                    PremiumOutlinedButton(
                        text = "ALTERNATIVE MIX",
                        onClick = {
                            // Scramble randomly
                            val allOuters = products.filter { it.subcategory == Subcategory.OUTERWEAR }
                            val allTops = products.filter { it.subcategory == Subcategory.TAILORING || it.subcategory == Subcategory.KNITWEAR }
                            val allBottoms = products.filter { it.subcategory == Subcategory.DENIM }
                            val allShoes = products.filter { it.subcategory == Subcategory.RETRO_TRAINERS }

                            if (allOuters.isNotEmpty()) viewModel.activeOuter.value = allOuters.random()
                            if (allTops.isNotEmpty()) viewModel.activeTop.value = allTops.random()
                            if (allBottoms.isNotEmpty()) viewModel.activeTrouser.value = allBottoms.random()
                            if (allShoes.isNotEmpty()) viewModel.activeShoes.value = allShoes.random()
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Display Saved Outfits section
            if (savedOutfits.isNotEmpty()) {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Text(
                        text = "SAVED COMBINATIONS",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    savedOutfits.forEachIndexed { index, outfit ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .border(1.dp, AsosLightGray)
                                .background(AsosOffWhite)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "COMBO #${index + 1}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                outfit.forEach { item ->
                                    Box(modifier = Modifier.size(36.dp)) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(LocalContext.current)
                                                .data(item.imagePrimary)
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = item.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            IconButton(
                                onClick = {
                                    // Load back to canvas
                                    outfit.find { it.subcategory == Subcategory.OUTERWEAR }?.let { viewModel.activeOuter.value = it }
                                    outfit.find { it.subcategory == Subcategory.TAILORING || it.subcategory == Subcategory.KNITWEAR }?.let { viewModel.activeTop.value = it }
                                    outfit.find { it.subcategory == Subcategory.DENIM }?.let { viewModel.activeTrouser.value = it }
                                    outfit.find { it.subcategory == Subcategory.RETRO_TRAINERS }?.let { viewModel.activeShoes.value = it }
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Loaded Combo #${index + 1} back onto the Style Canvas.")
                                    }
                                }
                            ) {
                                Icon(imageVector = Icons.Filled.Autorenew, contentDescription = "Load back")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(36.dp))
        }
    }
}

@Composable
fun OutfitCanvasSlot(
    label: String,
    product: Product?,
    onCycle: () -> Unit,
    onClear: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(AsosCharcoal)
            .border(1.dp, AsosGray.copy(alpha = 0.5f))
            .padding(10.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = AsosWhite.copy(alpha = 0.5f),
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (product != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.85f)
                    .background(AsosBlack)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(product.imagePrimary)
                        .crossfade(true)
                        .build(),
                    contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Hover Action overlays
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.6f))
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    IconButton(onClick = onCycle, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Filled.Autorenew, contentDescription = "Cycle", tint = AsosWhite, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onClear, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Remove", tint = AsosWhite, modifier = Modifier.size(16.dp))
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = product.brand,
                style = MaterialTheme.typography.labelSmall,
                color = AsosWhite.copy(alpha = 0.5f),
                maxLines = 1
            )
            Text(
                text = product.name,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = AsosWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "£${product.price}",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Black,
                color = AsosAccentLime
            )
        } else {
            // Empty Slot layout
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.85f)
                    .background(AsosBlack)
                    .clickable { onCycle() },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Filled.Add, contentDescription = "Add", tint = AsosWhite)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "TAP TO ADD",
                        color = AsosWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}
