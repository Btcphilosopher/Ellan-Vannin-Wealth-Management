package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.*
import com.example.ui.components.PremiumButton
import com.example.ui.components.PremiumOutlinedButton
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountAndProfileScreen(
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    val userStyle by viewModel.userStyleProfile.collectAsState()
    val savedItems by viewModel.savedItems.collectAsState()
    val orders by viewModel.orders.collectAsState()

    var showProfileQuiz by remember { mutableStateOf(false) }

    // Quiz inputs inside modal state
    var selectedSize by remember { mutableStateOf(userStyle.usualSize) }
    var selectedFit by remember { mutableStateOf(userStyle.preferredFit) }
    var selectedColors by remember { mutableStateOf(userStyle.favoriteColors.toMutableList()) }
    var selectedBrands by remember { mutableStateOf(userStyle.favoriteBrands.toMutableList()) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateHome() }) {
                Icon(
                    imageVector = Icons.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = AsosBlack
                )
            }
            Text(
                text = "MY ASOS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black
            )
        }

        Divider(color = AsosLightGray)

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Profile Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(AsosBlack, shape = CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = "User avatar",
                        tint = AsosWhite,
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "TOM HARRISON",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Member since October 2026",
                        style = MaterialTheme.typography.bodySmall,
                        color = AsosGray
                    )
                }
            }

            // STYLE RECALIBRATION CARD
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AsosBlack)
                    .clickable { showProfileQuiz = true }
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        "MY STYLE PROFILE",
                        color = AsosWhite,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Set your fit parameters (e.g. $selectedFit), colors and brands. We recalibrate feeds instantly based on your preferences.",
                        color = AsosWhite.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "RE-CALIBRATE STYLE ALGORITHM →",
                        color = AsosAccentLime,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Options List
            Text("LOGISTICS & SYSTEM ACTIONS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
            Spacer(modifier = Modifier.height(10.dp))

            AccountOptionItem(
                label = "MY PURCHASES",
                sublabel = "${orders.size} historical orders logged",
                onClick = { viewModel.navigateTo(AppScreen.OrderHistory) }
            )
            AccountOptionItem(
                label = "RETURNS HUB",
                sublabel = "Register returns or scan drop-off passes",
                onClick = { viewModel.navigateTo(AppScreen.ReturnWizard) }
            )
            AccountOptionItem(
                label = "SAVED WISHLISTS",
                sublabel = "${savedItems.size} items bookmarked across boards",
                onClick = { viewModel.navigateTo(AppScreen.Saved) }
            )
            AccountOptionItem(
                label = "SYSTEM NOTIFICATIONS",
                sublabel = "View price drops and in-stock alert logs",
                onClick = { viewModel.navigateTo(AppScreen.Notifications) }
            )
            AccountOptionItem(
                label = "OUTFIT BUILDER STUDIO",
                sublabel = "Launch visual clothes layering canvas",
                onClick = { viewModel.navigateTo(AppScreen.StyleStudio) }
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // PROFILE QUIZ QUESTIONNAIRE MODAL
    if (showProfileQuiz) {
        ModalBottomSheet(
            onDismissRequest = { showProfileQuiz = false },
            containerColor = AsosWhite,
            shape = RoundedCornerShape(0.dp),
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "RE-CALIBRATE ALGORITHM",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Personalize your feeds dynamically",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AsosGray
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Q1: Usual Size
                Text("YOUR STANDARD SIZE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    listOf("XS", "S", "M", "L", "XL").forEach { sz ->
                        Box(
                            modifier = Modifier
                                .border(1.dp, if (selectedSize == sz) AsosBlack else AsosLightGray)
                                .background(if (selectedSize == sz) AsosBlack else AsosWhite)
                                .clickable { selectedSize = sz }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(sz, color = if (selectedSize == sz) AsosWhite else AsosBlack, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Q2: Fit Preferred
                Text("YOUR PREFERRED FIT", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    listOf("Slim", "Regular", "Oversized").forEach { fit ->
                        Box(
                            modifier = Modifier
                                .border(1.dp, if (selectedFit == fit) AsosBlack else AsosLightGray)
                                .background(if (selectedFit == fit) AsosBlack else AsosWhite)
                                .clickable { selectedFit = fit }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(fit, color = if (selectedFit == fit) AsosWhite else AsosBlack, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Q3: Favorite Colors
                Text("FAVORITE PALETTES", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    listOf("Black", "Off-White", "Charcoal", "Beige", "Grey", "Blue", "Gold").forEach { color ->
                        val isSelected = selectedColors.contains(color)
                        Box(
                            modifier = Modifier
                                .border(1.dp, if (isSelected) AsosBlack else AsosLightGray)
                                .background(if (isSelected) AsosBlack else AsosWhite)
                                .clickable {
                                    if (isSelected) {
                                        selectedColors.remove(color)
                                    } else {
                                        selectedColors.add(color)
                                    }
                                    // Trigger recompose
                                    selectedColors = selectedColors.toMutableList()
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(color, color = if (isSelected) AsosWhite else AsosBlack, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Q4: Favorite Brands
                Text("FAVORITE BRANDS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    listOf("ASOS DESIGN", "adidas", "Nike", "COLLUSION").forEach { brand ->
                        val isSelected = selectedBrands.contains(brand)
                        Box(
                            modifier = Modifier
                                .border(1.dp, if (isSelected) AsosBlack else AsosLightGray)
                                .background(if (isSelected) AsosBlack else AsosWhite)
                                .clickable {
                                    if (isSelected) {
                                        selectedBrands.remove(brand)
                                    } else {
                                        selectedBrands.add(brand)
                                    }
                                    // Trigger recompose
                                    selectedBrands = selectedBrands.toMutableList()
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(brand, color = if (isSelected) AsosWhite else AsosBlack, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                PremiumButton(
                    text = "SAVE & RE-CALIBRATE FEEDS",
                    onClick = {
                        viewModel.updateStyleProfile(
                            UserProfile(
                                height = userStyle.height,
                                bodyShape = userStyle.bodyShape,
                                usualSize = selectedSize,
                                preferredFit = selectedFit,
                                favoriteColors = selectedColors,
                                favoriteBrands = selectedBrands
                            )
                        )
                        showProfileQuiz = false
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "save_profile_recal"
                )
            }
        }
    }
}

@Composable
fun AccountOptionItem(
    label: String,
    sublabel: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp)
            .border(bottom = BorderStroke(1.dp, AsosLightGray))
            .padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = sublabel,
                style = MaterialTheme.typography.bodySmall,
                color = AsosGray
            )
        }
        Icon(
            imageVector = Icons.Filled.ChevronRight,
            contentDescription = "Navigate option",
            tint = AsosBlack
        )
    }
}
