package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    val navStack by viewModel.navigationStack.collectAsState()
    val currentScreen = viewModel.currentScreen

    val cartItems by viewModel.cartItems.collectAsState()
    val savedItems by viewModel.savedItems.collectAsState()

    val totalCartItems = cartItems.sumOf { it.quantity }
    val totalSavedItems = savedItems.size

    // Bind system back button to popping navigation stack
    BackHandler(enabled = navStack.size > 1) {
        viewModel.navigateBack()
    }

    Scaffold(
        topBar = {
            // Curated brand bar, omitted on full-screen detail views if desired
            if (currentScreen == AppScreen.Home || currentScreen == AppScreen.Discover || currentScreen == AppScreen.Saved || currentScreen == AppScreen.Bag) {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = "ASOS",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 4.sp,
                            color = AsosBlack
                        )
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.navigateTo(AppScreen.Account) },
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .background(AsosBlack, shape = CircleShape)
                                .size(34.dp)
                                .testTag("top_bar_account_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = "Account profile",
                                tint = AsosWhite,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = AsosWhite
                    )
                )
            }
        },
        bottomBar = {
            // Persistent Obtrusive minimal Bottom Nav
            NavigationBar(
                containerColor = AsosWhite,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .testTag("app_bottom_nav_bar")
            ) {
                // HOME Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.Home,
                    onClick = { viewModel.navigateHome() },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == AppScreen.Home) Icons.Outlined.Home else Icons.Outlined.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = { Text("HOME", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AsosBlack,
                        unselectedIconColor = AsosGray,
                        selectedTextColor = AsosBlack,
                        unselectedTextColor = AsosGray,
                        indicatorColor = AsosLightGray
                    ),
                    modifier = Modifier.testTag("nav_home_tab")
                )

                // DISCOVER Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.Discover,
                    onClick = { viewModel.navigateTo(AppScreen.Discover) },
                    icon = {
                        Icon(
                            imageVector = Icons.Outlined.AutoAwesome,
                            contentDescription = "Discover"
                        )
                    },
                    label = { Text("DISCOVER", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AsosBlack,
                        unselectedIconColor = AsosGray,
                        selectedTextColor = AsosBlack,
                        unselectedTextColor = AsosGray,
                        indicatorColor = AsosLightGray
                    ),
                    modifier = Modifier.testTag("nav_discover_tab")
                )

                // SEARCH Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.Search || currentScreen is AppScreen.SearchResults,
                    onClick = { viewModel.navigateTo(AppScreen.Search) },
                    icon = {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = "Search"
                        )
                    },
                    label = { Text("SEARCH", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AsosBlack,
                        unselectedIconColor = AsosGray,
                        selectedTextColor = AsosBlack,
                        unselectedTextColor = AsosGray,
                        indicatorColor = AsosLightGray
                    ),
                    modifier = Modifier.testTag("nav_search_tab")
                )

                // SAVED Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.Saved,
                    onClick = { viewModel.navigateTo(AppScreen.Saved) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (totalSavedItems > 0) {
                                    Badge(containerColor = AsosBlack, contentColor = AsosAccentLime) {
                                        Text("$totalSavedItems")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.FavoriteBorder,
                                contentDescription = "Saved"
                            )
                        }
                    },
                    label = { Text("SAVED", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AsosBlack,
                        unselectedIconColor = AsosGray,
                        selectedTextColor = AsosBlack,
                        unselectedTextColor = AsosGray,
                        indicatorColor = AsosLightGray
                    ),
                    modifier = Modifier.testTag("nav_saved_tab")
                )

                // BAG Tab
                NavigationBarItem(
                    selected = currentScreen == AppScreen.Bag,
                    onClick = { viewModel.navigateTo(AppScreen.Bag) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (totalCartItems > 0) {
                                    Badge(containerColor = AsosOrange, contentColor = AsosWhite) {
                                        Text("$totalCartItems")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ShoppingBag,
                                contentDescription = "Bag"
                            )
                        }
                    },
                    label = { Text("BAG", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = AsosBlack,
                        unselectedIconColor = AsosGray,
                        selectedTextColor = AsosBlack,
                        unselectedTextColor = AsosGray,
                        indicatorColor = AsosLightGray
                    ),
                    modifier = Modifier.testTag("nav_bag_tab")
                )
            }
        }
    ) { innerPadding ->
        // Animated switch transitions between screens for fluid tactile UX
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                is AppScreen.Home -> HomeScreen(viewModel)
                is AppScreen.Discover -> DiscoverScreen(viewModel)
                is AppScreen.Search -> SearchScreen(viewModel)
                is AppScreen.Saved -> SavedAndBoardsScreen(viewModel)
                is AppScreen.Bag -> BagAndCheckoutScreen(viewModel)
                is AppScreen.Account -> AccountAndProfileScreen(viewModel)
                is AppScreen.StyleStudio -> StyleStudioScreen(viewModel)
                is AppScreen.Notifications -> NotificationsScreen(viewModel)

                is AppScreen.ProductDetails -> {
                    ProductDetailsScreen(
                        product = (currentScreen as AppScreen.ProductDetails).product,
                        viewModel = viewModel
                    )
                }

                is AppScreen.SearchResults -> {
                    val searchArgs = currentScreen as AppScreen.SearchResults
                    SearchResultsScreen(
                        query = searchArgs.query,
                        categoryFilter = searchArgs.categoryFilter,
                        brandFilter = searchArgs.brandFilter,
                        viewModel = viewModel
                    )
                }

                is AppScreen.OrderHistory -> {
                    OrdersAndReturnsScreen(viewModel)
                }

                is AppScreen.ReturnWizard -> {
                    OrdersAndReturnsScreen(viewModel)
                }

                else -> HomeScreen(viewModel)
            }
        }
    }
}
