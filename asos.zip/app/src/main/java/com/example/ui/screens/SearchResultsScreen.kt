package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.components.PremiumButton
import com.example.ui.components.PremiumOutlinedButton
import com.example.ui.components.ProductCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchResultsScreen(
    query: String?,
    categoryFilter: Category?,
    brandFilter: String?,
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsState()
    val savedItems by viewModel.savedItems.collectAsState()

    // Filter flows from state
    val filterCat by viewModel.filterCategory.collectAsState()
    val filterBr by viewModel.filterBrand.collectAsState()
    val filterSz by viewModel.filterSize.collectAsState()
    val filterCol by viewModel.filterColor.collectAsState()
    val filterPriceM by viewModel.filterPriceMax.collectAsState()
    val filterSub by viewModel.filterSubcategory.collectAsState()
    val sortOpt by viewModel.sortOption.collectAsState()

    // Screen states
    var showFilterDrawer by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }

    // Sync initial filters with navigate arguments
    LaunchedEffect(categoryFilter, brandFilter) {
        if (categoryFilter != null) {
            viewModel.filterCategory.value = categoryFilter
        }
        if (brandFilter != null) {
            viewModel.filterBrand.value = brandFilter
        }
    }

    // Dynamic Filter Engine
    val filteredProducts = remember(products, query, filterCat, filterBr, filterSz, filterCol, filterPriceM, filterSub, sortOpt) {
        var list = products.filter { prod ->
            // Text query match
            val matchesQuery = if (query != null) {
                prod.name.contains(query, ignoreCase = true) ||
                prod.brand.contains(query, ignoreCase = true) ||
                prod.color.contains(query, ignoreCase = true) ||
                prod.subcategory.name.contains(query, ignoreCase = true)
            } else true

            // State filter matches
            val matchesCat = if (filterCat != null) prod.category == filterCat else true
            val matchesBr = if (filterBr != null) prod.brand.equals(filterBr, ignoreCase = true) else true
            val matchesSz = if (filterSz != null) prod.sizes.contains(filterSz) else true
            val matchesCol = if (filterCol != null) prod.color.contains(filterCol!!, ignoreCase = true) else true
            val matchesPrice = prod.price <= filterPriceM
            val matchesSub = if (filterSub != null) prod.subcategory == filterSub else true

            matchesQuery && matchesCat && matchesBr && matchesSz && matchesCol && matchesPrice && matchesSub
        }

        // Sorting Engine
        when (sortOpt) {
            "NEW IN" -> list = list.sortedBy { it.badge != ProductBadge.NEW_IN }
            "BESTSELLERS" -> list = list.sortedBy { it.badge != ProductBadge.BESTSELLER }
            "PRICE LOW → HIGH" -> list = list.sortedBy { it.price }
            "PRICE HIGH → LOW" -> list = list.sortedByDescending { it.price }
            "RATING" -> list = list.sortedByDescending { it.rating }
            "TRENDING" -> list = list.sortedBy { it.badge != ProductBadge.TRENDING }
        }

        list
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App bar top
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(
                    imageVector = Icons.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = AsosBlack
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = when {
                        query != null -> "SEARCH: \"$query\""
                        categoryFilter != null -> categoryFilter.name
                        brandFilter != null -> brandFilter.uppercase()
                        else -> "ALL APPAREL"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Text(
                    text = "${filteredProducts.size} results",
                    style = MaterialTheme.typography.bodySmall,
                    color = AsosGray
                )
            }
        }

        Divider(color = AsosLightGray)

        // Sorters & Filters Actions Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .background(AsosWhite)
                .border(bottom = BorderStroke(1.dp, AsosLightGray)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sorting Selector Trigger
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable { showSortMenu = true }
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.SwapVert,
                        contentDescription = "Sort",
                        modifier = Modifier.size(16.dp),
                        tint = AsosBlack
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = sortOpt,
                        style = MaterialTheme.typography.labelSmall,
                        color = AsosBlack
                    )
                }

                // Sorting Menu
                DropdownMenu(
                    expanded = showSortMenu,
                    onDismissRequest = { showSortMenu = false },
                    modifier = Modifier.background(AsosWhite)
                ) {
                    listOf("RECOMMENDED", "NEW IN", "BESTSELLERS", "PRICE LOW → HIGH", "PRICE HIGH → LOW", "RATING", "TRENDING").forEach { opt ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = opt,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (opt == sortOpt) FontWeight.Bold else FontWeight.Normal,
                                    color = if (opt == sortOpt) AsosBlack else AsosGray
                                )
                            },
                            onClick = {
                                viewModel.sortOption.value = opt
                                showSortMenu = false
                            }
                        )
                    }
                }
            }

            VerticalDivider(color = AsosLightGray)

            // Filter Selector Trigger
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable { showFilterDrawer = true }
                    .padding(horizontal = 12.dp)
                    .testTag("filter_drawer_trigger"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.FilterList,
                        contentDescription = "Filters",
                        modifier = Modifier.size(16.dp),
                        tint = AsosBlack
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    val hasActiveFilters = filterCat != null || filterBr != null || filterSz != null || filterCol != null || filterPriceM < 200f || filterSub != null
                    Text(
                        text = if (hasActiveFilters) "FILTERS (ACTIVE)" else "FILTERS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (hasActiveFilters) FontWeight.Black else FontWeight.Bold,
                        color = if (hasActiveFilters) AsosOrange else AsosBlack
                    )
                }
            }
        }

        // Active filter pill alerts
        AnimatedVisibility(visible = filterCat != null || filterBr != null || filterSz != null || filterCol != null || filterSub != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AsosOffWhite)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CLEAR ALL",
                    style = MaterialTheme.typography.labelSmall,
                    color = AsosGray,
                    modifier = Modifier
                        .clickable { viewModel.resetFilters() }
                        .padding(end = 8.dp)
                )

                filterCat?.let {
                    FilterPill(text = it.name) { viewModel.filterCategory.value = null }
                }
                filterBr?.let {
                    FilterPill(text = it) { viewModel.filterBrand.value = null }
                }
                filterSz?.let {
                    FilterPill(text = "SIZE: $it") { viewModel.filterSize.value = null }
                }
                filterCol?.let {
                    FilterPill(text = "COLOR: $it") { viewModel.filterColor.value = null }
                }
                filterSub?.let {
                    FilterPill(text = it.name) { viewModel.filterSubcategory.value = null }
                }
            }
        }

        // Product Grid
        if (filteredProducts.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "NO MATCHES FOUND",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "We couldn't find any clothing matching your criteria. Try loosening your price threshold or selecting alternative sizes.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AsosGray,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                PremiumButton(
                    text = "RESET ALL FILTERS",
                    onClick = { viewModel.resetFilters() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(bottom = 32.dp),
                horizontalArrangement = Arrangement.spacedBy(1.dp),
                verticalArrangement = Arrangement.spacedBy(1.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .background(AsosLightGray)
                    .testTag("search_results_grid")
            ) {
                items(filteredProducts) { product ->
                    ProductCard(
                        product = product,
                        isSaved = viewModel.isProductSaved(product),
                        onProductClick = { viewModel.navigateTo(AppScreen.ProductDetails(product)) },
                        onSaveToggle = { viewModel.toggleSaveProduct(product) }
                    )
                }
            }
        }
    }

    // Sophisticated slide-up bottom sheet filter drawer
    if (showFilterDrawer) {
        ModalBottomSheet(
            onDismissRequest = { showFilterDrawer = false },
            containerColor = AsosWhite,
            shape = RoundedCornerShape(0.dp),
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header Drawer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "FILTERS",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "CLEAR ALL",
                        style = MaterialTheme.typography.labelSmall,
                        color = AsosOrange,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { viewModel.resetFilters() }
                            .padding(8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // FILTER SECTION: CATEGORY
                Text(
                    text = "GENDER CATEGORY",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = AsosGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Category.WOMEN, Category.MEN, Category.ACCESSORIES, Category.BEAUTY).forEach { cat ->
                        FilterSelectorItem(
                            text = cat.name,
                            isSelected = filterCat == cat,
                            onClick = {
                                viewModel.filterCategory.value = if (filterCat == cat) null else cat
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // FILTER SECTION: SIZE
                Text(
                    text = "SIZE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = AsosGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("XS", "S", "M", "L", "XL", "10").forEach { sz ->
                        FilterSelectorItem(
                            text = sz,
                            isSelected = filterSz == sz,
                            onClick = {
                                viewModel.filterSize.value = if (filterSz == sz) null else sz
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // FILTER SECTION: PRICE SLIDER
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "PRICE LIMIT",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = AsosGray
                    )
                    Text(
                        text = "UNDER £${filterPriceM.toInt()}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = AsosBlack
                    )
                }
                Slider(
                    value = filterPriceM,
                    onValueChange = { viewModel.filterPriceMax.value = it },
                    valueRange = 10f..200f,
                    colors = SliderDefaults.colors(
                        thumbColor = AsosBlack,
                        activeTrackColor = AsosBlack,
                        inactiveTrackColor = AsosLightGray
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                // FILTER SECTION: BRANDS
                Text(
                    text = "BRANDS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = AsosGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("ASOS DESIGN", "adidas", "Nike", "COLLUSION").forEach { brand ->
                        FilterSelectorItem(
                            text = brand,
                            isSelected = filterBr.equals(brand, ignoreCase = true),
                            onClick = {
                                viewModel.filterBrand.value = if (filterBr == brand) null else brand
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // FILTER SECTION: COLOR
                Text(
                    text = "COLOR",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = AsosGray
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Black", "White", "Beige", "Charcoal", "Grey", "Blue").forEach { color ->
                        FilterSelectorItem(
                            text = color.uppercase(),
                            isSelected = filterCol.equals(color, ignoreCase = true),
                            onClick = {
                                viewModel.filterColor.value = if (filterCol == color) null else color
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                PremiumButton(
                    text = "APPLY FILTERS (${filteredProducts.size} ITEMS)",
                    onClick = { showFilterDrawer = false },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "apply_filters_btn"
                )
            }
        }
    }
}

@Composable
fun FilterPill(
    text: String,
    onRemove: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(AsosBlack)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = text.uppercase(),
                color = AsosWhite,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Remove",
                tint = AsosWhite,
                modifier = Modifier
                    .size(12.dp)
                    .clickable { onRemove() }
            )
        }
    }
}

@Composable
fun FilterSelectorItem(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .border(
                BorderStroke(
                    width = 1.5.dp,
                    color = if (isSelected) AsosBlack else AsosLightGray
                )
            )
            .background(if (isSelected) AsosBlack else AsosWhite)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = text,
            color = if (isSelected) AsosWhite else AsosBlack,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold
        )
    }
}
