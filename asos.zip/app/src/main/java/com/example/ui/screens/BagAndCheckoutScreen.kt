package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.*
import com.example.ui.components.PremiumButton
import com.example.ui.components.PremiumOutlinedButton
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BagAndCheckoutScreen(
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    val cartItems by viewModel.cartItems.collectAsState()
    val orders by viewModel.orders.collectAsState()

    var showCheckoutSheet by remember { mutableStateOf(false) }
    var checkoutStep by remember { mutableStateOf(1) } // 1: Delivery, 2: Payment, 3: Review

    // Checkout Data States (Simulated)
    var fullName by remember { mutableStateOf("Tom Harrison") }
    var addressLine by remember { mutableStateOf("88 Fashion Street") }
    var cityLine by remember { mutableStateOf("London") }
    var postcodeLine by remember { mutableStateOf("E1 6BD") }
    var selectedPaymentMethod by remember { mutableStateOf("Apple Pay") } // Apple Pay, Google Pay, PayPal, Credit Card

    var showConfirmationScreen by remember { mutableStateOf(false) }
    var confirmedOrderNumber by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    // Render Confirmation Screen if order was just placed
    if (showConfirmationScreen) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(AsosBlack)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.CheckCircle,
                contentDescription = "Success",
                tint = AsosAccentLime,
                modifier = Modifier.size(80.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "ORDER CONFIRMED",
                color = AsosWhite,
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "ORDER #$confirmedOrderNumber",
                color = AsosWhite,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "ESTIMATED DELIVERY\nTHURSDAY",
                color = AsosAccentLime,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(32.dp))

            PremiumButton(
                text = "TRACK ORDER",
                onClick = {
                    showConfirmationScreen = false
                    viewModel.navigateTo(AppScreen.OrderHistory)
                },
                backgroundColor = AsosWhite,
                contentColor = AsosBlack,
                modifier = Modifier.fillMaxWidth(),
                testTag = "track_confirmed_order"
            )
            Spacer(modifier = Modifier.height(10.dp))
            PremiumOutlinedButton(
                text = "CONTINUE SHOPPING",
                onClick = {
                    showConfirmationScreen = false
                    viewModel.navigateHome()
                },
                borderColor = AsosWhite,
                contentColor = AsosWhite,
                modifier = Modifier.fillMaxWidth()
            )
        }
        return
    }

    // Main Bag Listing
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 20.dp)
        ) {
            Text(
                text = "BAG",
                style = MaterialTheme.typography.displayLarge,
                fontWeight = FontWeight.Black
            )
            Text(
                text = "${cartItems.sumOf { it.quantity }} ITEMS ADDED",
                style = MaterialTheme.typography.labelSmall,
                color = AsosGray
            )
        }

        Divider(color = AsosLightGray)

        if (cartItems.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.ShoppingBag,
                    contentDescription = "Empty Bag",
                    tint = AsosGray,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "YOUR BAG IS EMPTY",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Let's find something you'll love in our fresh seasonal collections.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AsosGray,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                PremiumButton(
                    text = "SHOP NEW IN →",
                    onClick = { viewModel.navigateHome() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            // Cart List & Summary
            Column(modifier = Modifier.weight(1f)) {
                // Cart Products Scrollable
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(cartItems) { item ->
                        CartLineItem(
                            item = item,
                            onQuantityChange = { delta ->
                                viewModel.updateCartQuantity(item.product, item.size, item.color, delta)
                            },
                            onRemove = {
                                viewModel.removeFromCart(item.product, item.size, item.color)
                            },
                            onSaveLater = {
                                viewModel.toggleSaveProduct(item.product, "WISHLIST")
                                viewModel.removeFromCart(item.product, item.size, item.color)
                            }
                        )
                    }
                }

                // Summary block bottom fixed
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AsosWhite)
                        .border(top = BorderStroke(1.dp, AsosLightGray))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("SUBTOTAL", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        Text("£${"%.2f".format(viewModel.subtotal)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Black)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("DELIVERY", style = MaterialTheme.typography.bodyMedium, color = AsosGray)
                        Text(
                            text = if (viewModel.shippingCost == 0.0) "FREE" else "£${"%.2f".format(viewModel.shippingCost)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (viewModel.shippingCost == 0.0) AsosAccentLime else AsosBlack,
                            modifier = Modifier.background(if (viewModel.shippingCost == 0.0) AsosBlack else Color.Transparent).padding(horizontal = 4.dp)
                        )
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp), color = AsosLightGray)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("TOTAL AMOUNT", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        Text("£${"%.2f".format(viewModel.totalAmount)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    PremiumButton(
                        text = "CHECKOUT",
                        onClick = {
                            checkoutStep = 1
                            showCheckoutSheet = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "checkout_trigger"
                    )
                }
            }
        }
    }

    // MULTI-STEP CHECKOUT DIALOG
    if (showCheckoutSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCheckoutSheet = false },
            containerColor = AsosWhite,
            shape = RoundedCornerShape(0.dp),
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp)
                    .padding(horizontal = 16.dp)
            ) {
                // Header Drawer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CHECKOUT (STEP $checkoutStep OF 3)",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                    IconButton(onClick = { showCheckoutSheet = false }) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                // Simple horizontal progression dots
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    repeat(3) { idx ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(4.dp)
                                .background(if (checkoutStep > idx) AsosBlack else AsosLightGray)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Content panels
                when (checkoutStep) {
                    1 -> {
                        // DELIVERY INFO
                        Text("DELIVERY ADDRESS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = fullName,
                            onValueChange = { fullName = it },
                            label = { Text("Full Name") },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AsosBlack),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = addressLine,
                            onValueChange = { addressLine = it },
                            label = { Text("Address Line") },
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AsosBlack),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = cityLine,
                                onValueChange = { cityLine = it },
                                label = { Text("City") },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AsosBlack),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = postcodeLine,
                                onValueChange = { postcodeLine = it },
                                label = { Text("Postcode") },
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AsosBlack),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    2 -> {
                        // PAYMENT SELECTION (Clearly Mocked)
                        Text("PAYMENT METHOD", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "This is a demonstration client. Real payment details are never processed.",
                            fontSize = 11.sp,
                            color = AsosOrange,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        listOf("Apple Pay", "Google Pay", "PayPal", "Mock Visa Ending *4242").forEach { method ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedPaymentMethod = method }
                                    .border(1.dp, if (selectedPaymentMethod == method) AsosBlack else AsosLightGray)
                                    .background(if (selectedPaymentMethod == method) AsosOffWhite else AsosWhite)
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = method,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (selectedPaymentMethod == method) FontWeight.Black else FontWeight.Normal
                                )
                                if (selectedPaymentMethod == method) {
                                    Icon(imageVector = Icons.Filled.Check, contentDescription = "Selected", tint = AsosBlack)
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }

                    3 -> {
                        // FINAL REVIEW
                        Text("REVIEW YOUR ORDER", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                        Spacer(modifier = Modifier.height(12.dp))

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, AsosLightGray)
                                .background(AsosOffWhite)
                                .padding(16.dp)
                        ) {
                            Text("SHIPPING TO:", style = MaterialTheme.typography.labelSmall, color = AsosGray)
                            Text("$fullName\n$addressLine, $cityLine\n$postcodeLine", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)

                            Spacer(modifier = Modifier.height(12.dp))

                            Text("PAYMENT METHOD:", style = MaterialTheme.typography.labelSmall, color = AsosGray)
                            Text(selectedPaymentMethod, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)

                            Spacer(modifier = Modifier.height(12.dp))

                            Text("ORDER SUMMARY:", style = MaterialTheme.typography.labelSmall, color = AsosGray)
                            Text("${cartItems.sumOf { it.quantity }} items", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("Total Amount: £${"%.2f".format(viewModel.totalAmount)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                // Bottom actions
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (checkoutStep > 1) {
                        PremiumOutlinedButton(
                            text = "BACK",
                            onClick = { checkoutStep-- },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    PremiumButton(
                        text = if (checkoutStep == 3) "PLACE ORDER" else "CONTINUE",
                        onClick = {
                            if (checkoutStep < 3) {
                                checkoutStep++
                            } else {
                                // Finalize order placement
                                viewModel.placeOrder(selectedPaymentMethod)
                                confirmedOrderNumber = viewModel.orders.value.firstOrNull()?.id ?: "AS123456"
                                showCheckoutSheet = false
                                showConfirmationScreen = true
                            }
                        },
                        modifier = Modifier.weight(2.0f),
                        testTag = "checkout_action_btn"
                    )
                }
            }
        }
    }
}

@Composable
fun CartLineItem(
    item: CartItem,
    onQuantityChange: (Int) -> Unit,
    onRemove: () -> Unit,
    onSaveLater: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(AsosWhite)
            .border(1.dp, AsosLightGray)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail Image
        Box(
            modifier = Modifier
                .size(90.dp)
                .background(AsosOffWhite)
        ) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(item.product.imagePrimary)
                    .crossfade(true)
                    .build(),
                contentDescription = item.product.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        // Text & Quantities Info Column
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.product.brand,
                style = MaterialTheme.typography.labelSmall,
                color = AsosGray
            )
            Text(
                text = item.product.name,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row {
                Text("SIZE: ${item.size}", fontSize = 11.sp, color = AsosGray)
                Spacer(modifier = Modifier.width(8.dp))
                Text("COLOUR: ${item.color}", fontSize = 11.sp, color = AsosGray)
            }
            Spacer(modifier = Modifier.height(6.dp))

            // Price Line
            Text(
                text = "£${"%.2f".format(item.product.price * item.quantity)}",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Black
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Action triggers row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Save for later
                Text(
                    text = "SAVE FOR LATER",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    color = AsosGray,
                    modifier = Modifier.clickable { onSaveLater() }
                )

                // Remove
                Text(
                    text = "REMOVE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    color = AsosOrange,
                    modifier = Modifier.clickable { onRemove() }
                )
            }
        }

        // Quantity adjustments
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            IconButton(onClick = { onQuantityChange(1) }, modifier = Modifier.size(32.dp)) {
                Text("+", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                text = "${item.quantity}",
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.bodyLarge
            )
            IconButton(onClick = { onQuantityChange(-1) }, modifier = Modifier.size(32.dp)) {
                Text("-", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
