package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.*
import com.example.ui.components.PremiumButton
import com.example.ui.components.PremiumOutlinedButton
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersAndReturnsScreen(
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.orders.collectAsState()
    val returns by viewModel.returns.collectAsState()

    var activeSection by remember { mutableStateOf("ORDERS") } // ORDERS, RETURNS

    // Returns wizard state machine
    var showReturnWizard by remember { mutableStateOf(false) }
    var wizardOrderSelected by remember { mutableStateOf<Order?>(null) }
    var wizardProductSelected by remember { mutableStateOf<CartItem?>(null) }
    var wizardReasonSelected by remember { mutableStateOf<ReturnReason?>(null) }
    var wizardMethodSelected by remember { mutableStateOf("Drop-off Station") } // Drop-off Station, Home Collection

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateHome() }) {
                Icon(
                    imageVector = Icons.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = AsosBlack
                )
            }
            Text(
                text = "LOGISTICS CENTRE",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black
            )
        }

        Divider(color = AsosLightGray)

        // Section Toggles
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .background(AsosWhite)
                .border(bottom = BorderStroke(1.dp, AsosLightGray))
        ) {
            listOf("ORDERS", "RETURNS").forEach { section ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { activeSection = section }
                        .border(
                            bottom = BorderStroke(
                                width = if (activeSection == section) 3.dp else 0.dp,
                                color = if (activeSection == section) AsosBlack else Color.Transparent
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (section == "ORDERS") "MY PURCHASES" else "RETURNS PORTAL",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (activeSection == section) FontWeight.Black else FontWeight.Bold,
                        color = if (activeSection == section) AsosBlack else AsosGray
                    )
                }
            }
        }

        // Active content scrollable body
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            if (activeSection == "ORDERS") {
                if (orders.isEmpty()) {
                    Text(
                        "No purchases recorded yet.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = AsosGray,
                        modifier = Modifier.padding(vertical = 32.dp),
                        textAlign = TextAlign.Center
                    )
                } else {
                    orders.forEach { order ->
                        OrderCard(
                            order = order,
                            onReturnTrigger = {
                                wizardOrderSelected = order
                                wizardProductSelected = null
                                wizardReasonSelected = null
                                showReturnWizard = true
                            }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            } else {
                // RETURNS
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Register return trigger banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AsosBlack)
                            .clickable {
                                if (orders.isNotEmpty()) {
                                    wizardOrderSelected = orders.first()
                                    wizardProductSelected = null
                                    wizardReasonSelected = null
                                    showReturnWizard = true
                                }
                            }
                            .padding(20.dp)
                    ) {
                        Column {
                            Text("REGISTER A NEW RETURN", color = AsosWhite, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Select an eligible order placed in the last 28 days to create a return drop-off QR code.", color = AsosWhite.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("START RETURN PROCESS →", color = AsosAccentLime, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text("RETURN REQUEST LOGS", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(12.dp))

                    if (returns.isEmpty()) {
                        Text(
                            text = "No active returns registered.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AsosGray,
                            modifier = Modifier.padding(vertical = 16.dp)
                        )
                    } else {
                        returns.forEach { ret ->
                            ReturnLogCard(ret)
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }
                }
            }
        }
    }

    // RETURNS REGISTER DIALOG WIZARD
    if (showReturnWizard) {
        ModalBottomSheet(
            onDismissRequest = { showReturnWizard = false },
            containerColor = AsosWhite,
            shape = RoundedCornerShape(0.dp),
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp)
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("RETURNS WIZARD", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    IconButton(onClick = { showReturnWizard = false }) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Phase 1: Order selection
                Text("1. SELECT ORDER", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                Spacer(modifier = Modifier.height(8.dp))
                orders.forEach { o ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { wizardOrderSelected = o; wizardProductSelected = null }
                            .border(1.dp, if (wizardOrderSelected?.id == o.id) AsosBlack else AsosLightGray)
                            .background(if (wizardOrderSelected?.id == o.id) AsosOffWhite else AsosWhite)
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ORDER #${o.id}", fontWeight = FontWeight.Bold)
                        Text("${o.items.size} ITEMS - £${o.total}")
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Phase 2: Product selection
                wizardOrderSelected?.let { order ->
                    Text("2. SELECT GARMENT TO RETURN", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                    Spacer(modifier = Modifier.height(8.dp))
                    order.items.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { wizardProductSelected = item }
                                .border(1.dp, if (wizardProductSelected?.product?.id == item.product.id) AsosBlack else AsosLightGray)
                                .background(if (wizardProductSelected?.product?.id == item.product.id) AsosOffWhite else AsosWhite)
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.size(36.dp)) {
                                AsyncImage(
                                    model = ImageRequest.Builder(LocalContext.current).data(item.product.imagePrimary).build(),
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(item.product.name, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Phase 3: Reason selection
                wizardProductSelected?.let {
                    Text("3. REASON FOR RETURN", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReturnReason.values().forEach { r ->
                            Box(
                                modifier = Modifier
                                    .border(1.dp, if (wizardReasonSelected == r) AsosBlack else AsosLightGray)
                                    .background(if (wizardReasonSelected == r) AsosBlack else AsosWhite)
                                    .clickable { wizardReasonSelected = r }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(r.label, color = if (wizardReasonSelected == r) AsosWhite else AsosBlack, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Phase 4: Method selection
                wizardReasonSelected?.let {
                    Text("4. CHOOSE METHOD", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
                    Spacer(modifier = Modifier.height(8.dp))
                    listOf("Drop-off Station", "Home Collection courier").forEach { m ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { wizardMethodSelected = m }
                                .border(1.dp, if (wizardMethodSelected == m) AsosBlack else AsosLightGray)
                                .background(if (wizardMethodSelected == m) AsosOffWhite else AsosWhite)
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(m, fontWeight = FontWeight.Bold)
                            if (wizardMethodSelected == m) {
                                Icon(imageVector = Icons.Filled.Check, contentDescription = null)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                PremiumButton(
                    text = "REGISTER RETURN",
                    isEnabled = wizardOrderSelected != null && wizardProductSelected != null && wizardReasonSelected != null,
                    onClick = {
                        val order = wizardOrderSelected!!
                        val item = wizardProductSelected!!
                        viewModel.submitReturn(
                            orderId = order.id,
                            product = item.product,
                            size = item.size,
                            reason = wizardReasonSelected!!,
                            method = wizardMethodSelected
                        )
                        showReturnWizard = false
                        activeSection = "RETURNS"
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "submit_return_btn"
                )
            }
        }
    }
}

@Composable
fun OrderCard(order: Order, onReturnTrigger: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AsosLightGray)
            .background(AsosWhite)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("ORDER #${order.id}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                Text("Date ordered: ${order.dateOrdered}", style = MaterialTheme.typography.bodySmall, color = AsosGray)
            }

            Box(
                modifier = Modifier
                    .background(if (order.status == OrderStatus.DELIVERED) AsosAccentLime else AsosBlack)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = order.status.name,
                    color = if (order.status == OrderStatus.DELIVERED) AsosBlack else AsosWhite,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Order line items thumbs
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            order.items.forEach { line ->
                Box(modifier = Modifier.size(60.dp)) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current).data(line.product.imagePrimary).build(),
                        contentDescription = line.product.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active timeline tracker
        Text("TRACKING TIMELINE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = AsosGray)
        Spacer(modifier = Modifier.height(8.dp))

        Column {
            OrderStatus.values().forEach { stateVal ->
                val record = order.trackingTimeline.find { it.first == stateVal }
                val isDone = record != null
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(if (isDone) AsosBlack else AsosLightGray, shape = RoundedCornerShape(5.dp))
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = stateVal.name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (order.status == stateVal) FontWeight.Black else FontWeight.Normal,
                        color = if (isDone) AsosBlack else AsosGray
                    )
                    if (record != null) {
                        Spacer(modifier = Modifier.weight(1f))
                        Text(record.second, style = MaterialTheme.typography.bodySmall, color = AsosGray)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PremiumOutlinedButton(
                text = "REQUEST A RETURN",
                onClick = onReturnTrigger,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun ReturnLogCard(request: ReturnRequest) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AsosLightGray)
            .background(AsosWhite)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("RETURN #${request.id}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                Text("Ordered reference: #${request.orderId}", fontSize = 11.sp, color = AsosGray)
            }

            Box(modifier = Modifier.background(AsosAccentLime).padding(horizontal = 6.dp, vertical = 3.dp)) {
                Text(request.status.uppercase(), color = AsosBlack, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(54.dp)) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current).data(request.product.imagePrimary).build(),
                    contentDescription = request.product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(request.product.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("Size returned: ${request.size}", fontSize = 11.sp, color = AsosGray)
                Text("Reason: ${request.reason.label}", fontSize = 11.sp, color = AsosGray)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Large printed return drop off QR code!
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(AsosOffWhite)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("DROP-OFF PASS SCANCODE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .background(AsosWhite)
                    .border(2.dp, AsosBlack)
                    .padding(8.dp)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(request.qrCodeUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = "Drop Off scan pass QR",
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Scan this ticket at your chosen ${request.method} depot for instantaneous processing.", fontSize = 10.sp, color = AsosGray, textAlign = TextAlign.Center)
        }
    }
}
