package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.*
import com.example.ui.components.PremiumButton
import com.example.ui.components.ProductCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedAndBoardsScreen(
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    val savedItems by viewModel.savedItems.collectAsState()
    val boards by viewModel.boards.collectAsState()
    val savedOutfits by viewModel.savedOutfits.collectAsState()

    var activeTab by remember { mutableStateOf("ALL") } // ALL, BOARDS, OUTFITS
    var selectedBoardName by remember { mutableStateOf<String?>(null) }

    var showCreateBoardDialog by remember { mutableStateOf(false) }
    var newBoardName by remember { mutableStateOf("") }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Screen Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SAVED",
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "YOUR WISHLISTS & STYLE INSPIRATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = AsosGray
                    )
                }

                // Add button for Boards
                if (activeTab == "BOARDS") {
                    IconButton(
                        onClick = { showCreateBoardDialog = true },
                        modifier = Modifier
                            .background(AsosBlack, shape = RoundedCornerShape(2.dp))
                            .size(36.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.Add, contentDescription = "Add Board", tint = AsosWhite)
                    }
                }
            }

            // Tabs toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .background(AsosWhite)
                    .border(bottom = BorderStroke(1.dp, AsosLightGray))
            ) {
                listOf("ALL", "BOARDS", "OUTFITS").forEach { tab ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable {
                                activeTab = tab
                                selectedBoardName = null // Reset board filter
                            }
                            .border(
                                bottom = BorderStroke(
                                    width = if (activeTab == tab) 3.dp else 0.dp,
                                    color = if (activeTab == tab) AsosBlack else Color.Transparent
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (activeTab == tab) FontWeight.Black else FontWeight.Bold,
                            color = if (activeTab == tab) AsosBlack else AsosGray
                        )
                    }
                }
            }

            // Selected Board Alert banner
            AnimatedVisibility(visible = selectedBoardName != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AsosBlack)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BOARD: ${selectedBoardName?.uppercase()}",
                        color = AsosWhite,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Black
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                // Simulate sharing
                                val shareTxt = "Check out my ASOS style Board: $selectedBoardName!"
                                scope.launch {
                                    snackbarHostState.showSnackbar("Board link copied to clipboard for sharing!")
                                }
                            }
                        ) {
                            Icon(imageVector = Icons.Filled.Share, contentDescription = "Share", tint = AsosAccentLime)
                        }
                        IconButton(onClick = { selectedBoardName = null }) {
                            Icon(imageVector = Icons.Filled.Close, contentDescription = "Close", tint = AsosWhite)
                        }
                    }
                }
            }

            // Body
            when (activeTab) {
                "ALL" -> {
                    val displayedItems = remember(savedItems, selectedBoardName) {
                        if (selectedBoardName != null) {
                            savedItems.filter { it.boardName == selectedBoardName }
                        } else savedItems
                    }

                    if (displayedItems.isEmpty()) {
                        EmptySavedState { viewModel.navigateHome() }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(1.dp),
                            verticalArrangement = Arrangement.spacedBy(1.dp),
                            modifier = Modifier
                                .fillMaxSize()
                                .background(AsosLightGray)
                                .testTag("saved_items_grid")
                        ) {
                            items(displayedItems) { saved ->
                                val prod = saved.product
                                Column {
                                    ProductCard(
                                        product = prod,
                                        isSaved = true,
                                        onProductClick = { viewModel.navigateTo(AppScreen.ProductDetails(prod)) },
                                        onSaveToggle = { viewModel.toggleSaveProduct(prod) }
                                    )

                                    // Custom Board badge mapping helper
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(AsosWhite)
                                            .padding(horizontal = 8.dp, vertical = 6.dp)
                                            .border(1.dp, AsosLightGray)
                                            .clickable {
                                                // Change board allocation
                                                val nextBoard = boards
                                                    .map { it.name }
                                                    .firstOrNull { it != saved.boardName }
                                                viewModel.toggleSaveProduct(prod)
                                                viewModel.toggleSaveProduct(prod, nextBoard)
                                            },
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "BOARD: ${saved.boardName ?: "NONE"}",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AsosGray
                                        )
                                        Text(
                                            text = "CHANGE",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black,
                                            color = AsosBlack
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                "BOARDS" -> {
                    if (boards.isEmpty()) {
                        EmptySavedState { viewModel.navigateHome() }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            contentPadding = PaddingValues(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(boards) { board ->
                                val count = savedItems.count { it.boardName == board.name }
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                        .clickable {
                                            selectedBoardName = board.name
                                            activeTab = "ALL"
                                        },
                                    shape = RoundedCornerShape(0.dp)
                                ) {
                                    Box(modifier = Modifier.fillMaxSize()) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(LocalContext.current)
                                                .data(board.coverImage)
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = board.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color.Black.copy(alpha = 0.4f))
                                        )
                                        Column(
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .padding(12.dp)
                                        ) {
                                            Text(
                                                text = board.name.uppercase(),
                                                color = AsosWhite,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Black
                                            )
                                            Text(
                                                text = "$count items",
                                                color = AsosWhite.copy(alpha = 0.7f),
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "OUTFITS" -> {
                    if (savedOutfits.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                "NO OUTFITS YET",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Design your style boards, select visual layers, and save gorgeous matches inside our canvas studio.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = AsosGray,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                            PremiumButton(
                                text = "LAUNCH STYLE STUDIO",
                                onClick = { viewModel.navigateTo(AppScreen.StyleStudio) }
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        ) {
                            savedOutfits.forEachIndexed { idx, outfit ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp)
                                        .clickable {
                                            viewModel.navigateTo(AppScreen.StyleStudio)
                                        },
                                    shape = RoundedCornerShape(0.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(AsosCharcoal)
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("OUTFIT COMBO #${idx + 1}", color = AsosWhite, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text("${outfit.size} garments assembled", color = AsosAccentLime, style = MaterialTheme.typography.labelSmall)
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            outfit.forEach { prod ->
                                                Box(modifier = Modifier.size(40.dp)) {
                                                    AsyncImage(
                                                        model = ImageRequest.Builder(LocalContext.current)
                                                            .data(prod.imagePrimary)
                                                            .crossfade(true)
                                                            .build(),
                                                        contentDescription = prod.name,
                                                        contentScale = ContentScale.Crop,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // CREATE BOARD DIALOG
    if (showCreateBoardDialog) {
        AlertDialog(
            onDismissRequest = { showCreateBoardDialog = false },
            containerColor = AsosWhite,
            shape = RoundedCornerShape(0.dp),
            title = {
                Text("CREATE NEW BOARD", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            },
            text = {
                Column {
                    Text("Assemble garments for specific seasons or occasions like weddings, flat hunting, or festivals.", style = MaterialTheme.typography.bodyMedium, color = AsosGray)
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = newBoardName,
                        onValueChange = { newBoardName = it },
                        placeholder = { Text("Board Name (e.g. WEDDING 2026)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AsosBlack,
                            unfocusedBorderColor = AsosLightGray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                PremiumButton(
                    text = "CREATE",
                    isEnabled = newBoardName.trim().isNotEmpty(),
                    onClick = {
                        viewModel.createBoard(
                            name = newBoardName.trim(),
                            coverImage = "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=300"
                        )
                        newBoardName = ""
                        showCreateBoardDialog = false
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { showCreateBoardDialog = false }) {
                    Text("CANCEL", color = AsosBlack, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun EmptySavedState(onDiscover: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "YOUR SAVED ITEMS IS EMPTY",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Tap the heart icons overlaying products on our lists to save items here.",
            style = MaterialTheme.typography.bodyMedium,
            color = AsosGray,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(24.dp))
        PremiumButton(
            text = "START DISCOVERING →",
            onClick = onDiscover,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
