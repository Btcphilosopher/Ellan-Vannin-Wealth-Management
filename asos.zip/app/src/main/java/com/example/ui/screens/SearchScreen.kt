package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.components.PremiumButton
import com.example.ui.components.PremiumOutlinedButton
import com.example.ui.components.ProductCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateFlowOf("") }
    val recentSearches by viewModel.recentSearches.collectAsState()
    val styleMatchState by viewModel.styleMatchState.collectAsState()
    val keyboardController = LocalSoftwareKeyboardController.current

    var showStyleMatchSheet by remember { mutableStateOf(false) }

    val trendingSearches = listOf(
        "wool coats", "retro trainers", "party dresses", "wide-leg jeans", "activewear", "makeup essentials"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Search Header / Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        "What are you looking for?",
                        style = MaterialTheme.typography.bodyMedium,
                        color = AsosGray
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Search",
                        tint = AsosBlack
                    )
                },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "Clear text",
                                    tint = AsosBlack
                                )
                            }
                        }
                        // Flagship Style Match Trigger
                        IconButton(
                            onClick = {
                                showStyleMatchSheet = true
                                viewModel.resetStyleMatch()
                            },
                            modifier = Modifier.testTag("style_match_camera_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CameraAlt,
                                contentDescription = "Style Match Camera",
                                tint = AsosBlack
                            )
                        }
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    if (searchQuery.trim().isNotEmpty()) {
                        viewModel.addRecentSearch(searchQuery)
                        viewModel.navigateTo(AppScreen.SearchResults(query = searchQuery))
                        keyboardController?.hide()
                    }
                }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AsosBlack,
                    unfocusedBorderColor = AsosLightGray,
                    focusedContainerColor = AsosWhite,
                    unfocusedContainerColor = AsosWhite
                ),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("search_command_input")
            )
        }

        Divider(color = AsosLightGray)

        // Contents
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Recent Searches section
            if (recentSearches.isNotEmpty()) {
                Text(
                    text = "RECENT SEARCHES",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                )
                Spacer(modifier = Modifier.height(8.dp))
                recentSearches.forEach { search ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.addRecentSearch(search)
                                viewModel.navigateTo(AppScreen.SearchResults(query = search))
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.History,
                            contentDescription = "History",
                            tint = AsosGray,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = search,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            // Trending Searches section
            Text(
                text = "TRENDING SEARCHES",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(12.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                trendingSearches.forEach { trending ->
                    Box(
                        modifier = Modifier
                            .background(AsosOffWhite, shape = RoundedCornerShape(2.dp))
                            .border(1.dp, AsosLightGray, shape = RoundedCornerShape(2.dp))
                            .clickable {
                                viewModel.addRecentSearch(trending)
                                viewModel.navigateTo(AppScreen.SearchResults(query = trending))
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.TrendingUp,
                                contentDescription = "Trending",
                                tint = AsosBlack,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = trending.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = AsosBlack,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Style Match quick highlight card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AsosBlack)
                    .clickable {
                        showStyleMatchSheet = true
                        viewModel.resetStyleMatch()
                    }
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        "STYLE MATCH",
                        color = AsosWhite,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Upload a screenshot or snap a photo of any outfit to find identical matches on our platform instantly.",
                        color = AsosWhite.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "LAUNCH STYLE SCANNER →",
                        color = AsosAccentLime,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }

    // Flagship STYLE MATCH Interactive Bottom Sheet modal
    if (showStyleMatchSheet) {
        ModalBottomSheet(
            onDismissRequest = { showStyleMatchSheet = false },
            containerColor = AsosWhite,
            shape = RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp), // Minimalist brutalist
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp)
                    .padding(horizontal = 16.dp)
            ) {
                // Sheet title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "STYLE MATCH",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                    IconButton(onClick = { showStyleMatchSheet = false }) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                when (styleMatchState) {
                    is FashionViewModel.StyleMatchStatus.Idle -> {
                        Text(
                            text = "Find items matching any style. Upload a reference screenshot or capture a picture of clothing.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AsosGray
                        )
                        Spacer(modifier = Modifier.height(24.dp))

                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            PremiumButton(
                                text = "TAKE PHOTO",
                                onClick = { viewModel.startStyleMatchAnalysis() },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "style_match_take_photo"
                            )
                            PremiumOutlinedButton(
                                text = "UPLOAD PHOTO",
                                onClick = { viewModel.startStyleMatchAnalysis() },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "style_match_upload_photo"
                            )
                            PremiumOutlinedButton(
                                text = "USE SCREENSHOT",
                                onClick = { viewModel.startStyleMatchAnalysis() },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "style_match_screenshot"
                            )
                        }
                    }

                    is FashionViewModel.StyleMatchStatus.Analyzing -> {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = AsosBlack, strokeWidth = 4.dp)
                            Spacer(modifier = Modifier.height(24.dp))
                            Text(
                                text = "ANALYSING STYLE...",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Scanning patterns, stitching, and color overlays",
                                style = MaterialTheme.typography.bodyMedium,
                                color = AsosGray
                            )
                        }
                    }

                    is FashionViewModel.StyleMatchStatus.Success -> {
                        val successState = styleMatchState as FashionViewModel.StyleMatchStatus.Success
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "ANALYSIS COMPLETE",
                                style = MaterialTheme.typography.labelSmall,
                                color = AsosAccentLime,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier
                                    .background(AsosBlack)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))

                            // Breakdown overlays
                            Text(
                                text = "SCROLL DOWN TO EXPLORE MATCHING STYLES:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            // Overlaps bars
                            StyleMatchIndicator(label = "JACKET MATCH", percentage = successState.jacketMatch)
                            StyleMatchIndicator(label = "TROUSERS MATCH", percentage = successState.trousersMatch)
                            StyleMatchIndicator(label = "SHOES MATCH", percentage = successState.shoesMatch)

                            Spacer(modifier = Modifier.height(20.dp))

                            Text(
                                text = "IDENTIFIED MATCHING CATALOG PRODUCTS:",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Matching product row list
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                successState.results.forEach { matchedProduct ->
                                    ProductCard(
                                        product = matchedProduct,
                                        isSaved = viewModel.isProductSaved(matchedProduct),
                                        onProductClick = {
                                            showStyleMatchSheet = false
                                            viewModel.navigateTo(AppScreen.ProductDetails(matchedProduct))
                                        },
                                        onSaveToggle = { viewModel.toggleSaveProduct(matchedProduct) },
                                        modifier = Modifier.width(140.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            PremiumButton(
                                text = "RESET STYLE SCANNER",
                                onClick = { viewModel.resetStyleMatch() },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StyleMatchIndicator(label: String, percentage: Int) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            Text("$percentage%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = percentage / 100f,
            color = AsosBlack,
            trackColor = AsosLightGray,
            modifier = Modifier.fillMaxWidth().height(6.dp)
        )
    }
}
