package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AsosBlack = Color(0xFF000000)
val AsosWhite = Color(0xFFFFFFFF)
val AsosOffWhite = Color(0xFFF9F9FB)
val AsosCharcoal = Color(0xFF121212)
val AsosGray = Color(0xFF8E8E93)
val AsosLightGray = Color(0xFFE5E5EA)
val AsosAccentLime = Color(0xFFE0FF00) // Premium fashion neon lime
val AsosOrange = Color(0xFFFF3B30) // Clean badge orange/sale red
val AsosMutedGold = Color(0xFFD4AF37)
