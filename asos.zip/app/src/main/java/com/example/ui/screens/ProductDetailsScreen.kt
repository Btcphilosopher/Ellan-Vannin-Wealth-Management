package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.*
import com.example.ui.components.PremiumButton
import com.example.ui.components.PremiumOutlinedButton
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailsScreen(
    product: Product,
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    val savedItems by viewModel.savedItems.collectAsState()
    val isSaved = viewModel.isProductSaved(product)

    var selectedSize by remember { mutableStateOf("") }
    var expandedInfoSection by remember { mutableStateOf<String?>(null) }

    // Dialog sheets states
    var showSizeIntelDialog by remember { mutableStateOf(false) }
    var showTryOnDialog by remember { mutableStateOf(false) }

    val tryOnState by viewModel.tryOnState.collectAsState()
    val sizeRecommendation by viewModel.sizeRecommendation.collectAsState()

    // Find My Size Quiz Answers
    var heightAns by remember { mutableStateOf(175f) }
    var bodyShapeAns by remember { mutableStateOf("Average") }
    var usualSizeAns by remember { mutableStateOf("M") }
    var preferredFitAns by remember { mutableStateOf("Oversized") }

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = AsosBlack
                    )
                }
                Text(
                    text = product.brand.uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black
                )
                IconButton(onClick = { viewModel.toggleSaveProduct(product) }) {
                    Icon(
                        imageVector = if (isSaved) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Save",
                        tint = if (isSaved) AsosOrange else AsosBlack
                    )
                }
            }

            // Image Carousel (Vertical/Horizontal Swipe simulation)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(440.dp)
                    .background(AsosOffWhite)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(product.imagePrimary)
                        .crossfade(true)
                        .build(),
                    contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Swipe Dots Indicator Row
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    repeat(3) { index ->
                        Box(
                            modifier = Modifier
                                .size(if (index == 0) 8.dp else 6.dp)
                                .background(
                                    if (index == 0) AsosBlack else AsosGray,
                                    shape = CircleShape
                                )
                        )
                    }
                }
            }

            // Text Info Blocks
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = product.brand.uppercase(),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "£${"%.2f".format(product.price)}",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Black,
                        color = if (product.isOnSale) AsosOrange else MaterialTheme.colorScheme.onSurface
                    )
                    if (product.isOnSale && product.originalPrice != null) {
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "£${"%.2f".format(product.originalPrice)}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                            textDecoration = TextDecoration.LineThrough
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "COLOUR: ${product.color.uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = AsosGray
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Flagship sizing helpers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SELECT SIZE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )

                    // Find My Size trigger
                    Text(
                        text = if (sizeRecommendation != null) "RECOMMENDED SIZE: $sizeRecommendation" else "FIND MY SIZE",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (sizeRecommendation != null) AsosAccentLime else AsosBlack,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .background(if (sizeRecommendation != null) AsosBlack else Color.Transparent)
                            .clickable { showSizeIntelDialog = true }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                            .testTag("find_my_size_trigger")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Sizing row selection pills
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    product.sizes.forEach { size ->
                        val isRec = size == sizeRecommendation
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .border(
                                    BorderStroke(
                                        width = if (selectedSize == size) 2.dp else 1.dp,
                                        color = if (selectedSize == size) AsosBlack else if (isRec) AsosAccentLime else AsosLightGray
                                    )
                                )
                                .background(if (selectedSize == size) AsosBlack else if (isRec) AsosAccentLime.copy(alpha = 0.15f) else AsosWhite)
                                .clickable { selectedSize = size }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = size,
                                    color = if (selectedSize == size) AsosWhite else AsosBlack,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                if (isRec) {
                                    Text(
                                        "REC",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AsosBlack
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Premium action buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Try On trigger
                    PremiumOutlinedButton(
                        text = "VIRTUAL TRY-ON",
                        onClick = {
                            viewModel.resetVirtualTryOn()
                            showTryOnDialog = true
                        },
                        modifier = Modifier.weight(1f),
                        testTag = "try_on_btn"
                    )

                    // Add to bag
                    PremiumButton(
                        text = if (selectedSize.isEmpty()) "CHOOSE A SIZE" else "ADD TO BAG",
                        isEnabled = selectedSize.isNotEmpty(),
                        onClick = {
                            viewModel.addToCart(product, selectedSize, product.color)
                            scope.launch {
                                snackbarHostState.showSnackbar("Added '${product.name}' in size $selectedSize to your bag.")
                            }
                        },
                        modifier = Modifier.weight(1.3f),
                        testTag = "add_to_bag_btn"
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))

                // Expandable details lists
                ParameterDropdown(
                    title = "PRODUCT DETAILS",
                    isExpanded = expandedInfoSection == "DETAILS",
                    onClick = {
                        expandedInfoSection = if (expandedInfoSection == "DETAILS") null else "DETAILS"
                    }
                ) {
                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                        Text(product.description, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        product.details.forEach { detail ->
                            Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                Text("• ", fontWeight = FontWeight.Bold)
                                Text(detail, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }

                ParameterDropdown(
                    title = "MATERIAL & CARE",
                    isExpanded = expandedInfoSection == "MATERIAL",
                    onClick = {
                        expandedInfoSection = if (expandedInfoSection == "MATERIAL") null else "MATERIAL"
                    }
                ) {
                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                        Text("COMPOSITION: ${product.material}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("CARE: ${product.care}", style = MaterialTheme.typography.bodyMedium)
                    }
                }

                ParameterDropdown(
                    title = "DELIVERY & FREE RETURNS",
                    isExpanded = expandedInfoSection == "DELIVERY",
                    onClick = {
                        expandedInfoSection = if (expandedInfoSection == "DELIVERY") null else "DELIVERY"
                    }
                ) {
                    Text(
                        text = product.deliveryInfo,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(28.dp))

                // COMPLETE THE LOOK Combo List
                Text(
                    text = "COMPLETE THE LOOK",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Combine with these handpicked styling components:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AsosGray
                )
                Spacer(modifier = Modifier.height(16.dp))

                val lookItems = MockData.products.filter { it.id != product.id }.take(3)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    lookItems.forEach { lookProd ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(AsosOffWhite)
                                .clickable { viewModel.navigateTo(AppScreen.ProductDetails(lookProd)) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.size(54.dp)) {
                                AsyncImage(
                                    model = ImageRequest.Builder(LocalContext.current)
                                        .data(lookProd.imagePrimary)
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = lookProd.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(lookProd.brand, style = MaterialTheme.typography.labelSmall, color = AsosGray)
                                Text(lookProd.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("£${lookProd.price}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Black)
                            }
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = "Active Look Style Component",
                                tint = AsosBlack,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    PremiumButton(
                        text = "SHOP THE WHOLE LOOK",
                        onClick = {
                            lookItems.forEach { viewModel.addToCart(it, "M", it.color) }
                            viewModel.addToCart(product, selectedSize.ifEmpty { "M" }, product.color)
                            scope.launch {
                                snackbarHostState.showSnackbar("Added the entire completed look combination to your bag.")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "shop_the_look_btn"
                    )
                }

                Spacer(modifier = Modifier.height(36.dp))
            }
        }
    }

    // SIZE INTELLIGENCE DIALOG (Find My Size)
    if (showSizeIntelDialog) {
        AlertDialog(
            onDismissRequest = { showSizeIntelDialog = false },
            containerColor = AsosWhite,
            shape = RoundedCornerShape(0.dp),
            title = {
                Text(
                    "SIZE INTELLIGENCE",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Answer a few simple questions to dynamically calculate your custom ASOS recommended fit.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = AsosGray
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Q1: Height
                    Text("YOUR HEIGHT: ${heightAns.toInt()} cm", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Slider(
                        value = heightAns,
                        onValueChange = { heightAns = it },
                        valueRange = 150f..210f,
                        colors = SliderDefaults.colors(thumbColor = AsosBlack, activeTrackColor = AsosBlack)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Q2: Usual Size
                    Text("YOUR USUAL SIZE: $usualSizeAns", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        listOf("XS", "S", "M", "L", "XL").forEach { sz ->
                            Box(
                                modifier = Modifier
                                    .border(1.dp, if (usualSizeAns == sz) AsosBlack else AsosLightGray)
                                    .background(if (usualSizeAns == sz) AsosBlack else AsosWhite)
                                    .clickable { usualSizeAns = sz }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(sz, color = if (usualSizeAns == sz) AsosWhite else AsosBlack, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Q3: Fit Prefer
                    Text("FIT PREFERENCE: ${preferredFitAns.uppercase()}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        listOf("Slim", "Regular", "Oversized").forEach { ft ->
                            Box(
                                modifier = Modifier
                                    .border(1.dp, if (preferredFitAns == ft) AsosBlack else AsosLightGray)
                                    .background(if (preferredFitAns == ft) AsosBlack else AsosWhite)
                                    .clickable { preferredFitAns = ft }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(ft, color = if (preferredFitAns == ft) AsosWhite else AsosBlack, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    if (sizeRecommendation != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(AsosAccentLime)
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = "RECOMMENDED SIZE: $sizeRecommendation",
                                    fontWeight = FontWeight.Black,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = AsosBlack
                                )
                                Text(
                                    text = "Our calculations suggest this fits TRUE TO SIZE based on similar customer orders.",
                                    fontSize = 11.sp,
                                    color = AsosBlack.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                PremiumButton(
                    text = if (sizeRecommendation != null) "CLOSE" else "CALCULATE SIZE",
                    onClick = {
                        if (sizeRecommendation != null) {
                            showSizeIntelDialog = false
                        } else {
                            viewModel.calculateRecommendedSize(heightAns.toInt(), bodyShapeAns, usualSizeAns, preferredFitAns)
                        }
                    }
                )
            },
            dismissButton = {
                if (sizeRecommendation != null) {
                    TextButton(onClick = { viewModel.clearSizeRecommendation() }) {
                        Text("RESET", color = AsosBlack, fontWeight = FontWeight.Bold)
                    }
                }
            }
        )
    }

    // FLAGSHIP VIRTUAL TRY-ON DIALOG
    if (showTryOnDialog) {
        AlertDialog(
            onDismissRequest = { showTryOnDialog = false },
            containerColor = AsosWhite,
            shape = RoundedCornerShape(0.dp),
            title = {
                Text(
                    text = "VIRTUAL TRY-ON",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    when (tryOnState) {
                        is FashionViewModel.TryOnStatus.Idle -> {
                            Text(
                                text = "Experience real-time interactive dressing. Select an avatar profile size, or upload a portrait photo to generate a high-fashion fit preview.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = AsosGray
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            PremiumButton(
                                text = "UPLOAD PROFILES PICTURE",
                                onClick = { viewModel.startVirtualTryOn(product) },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            PremiumOutlinedButton(
                                text = "USE STANDARD MODEL (SIZE M)",
                                onClick = { viewModel.startVirtualTryOn(product) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        is FashionViewModel.TryOnStatus.Preparing -> {
                            Column(
                                modifier = Modifier.padding(vertical = 24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = AsosBlack)
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    "PREPARING TRY-ON...",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Analyzing garment drape parameters...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AsosGray
                                )
                            }
                        }

                        is FashionViewModel.TryOnStatus.Generating -> {
                            Column(
                                modifier = Modifier.padding(vertical = 24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(color = AsosAccentLime)
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    "GENERATING PREVIEW...",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Stitching textures over avatar silhouette",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AsosGray
                                )
                            }
                        }

                        is FashionViewModel.TryOnStatus.Success -> {
                            val successUrl = (tryOnState as FashionViewModel.TryOnStatus.Success).imagePreviewUrl
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(240.dp)
                                        .background(AsosOffWhite)
                                ) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(LocalContext.current)
                                            .data(successUrl)
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = "Try On output",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Visual preview only. Fit, colour and proportions may differ from the final manufactured product.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AsosGray,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (tryOnState is FashionViewModel.TryOnStatus.Success) {
                    PremiumButton(
                        text = "ADD TO BAG",
                        onClick = {
                            viewModel.addToCart(product, selectedSize.ifEmpty { "M" }, product.color)
                            showTryOnDialog = false
                        }
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showTryOnDialog = false }) {
                    Text("CLOSE", color = AsosBlack, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun ParameterDropdown(
    title: String,
    isExpanded: Boolean,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .border(bottom = BorderStroke(1.dp, AsosLightGray))
            .clickable { onClick() }
            .padding(vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Icon(
                imageVector = if (isExpanded) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                contentDescription = "Toggle",
                tint = AsosBlack
            )
        }
        AnimatedVisibility(visible = isExpanded) {
            Box(modifier = Modifier.padding(top = 10.dp)) {
                content()
            }
        }
    }
}
