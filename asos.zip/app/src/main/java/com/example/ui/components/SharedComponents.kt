package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.Product
import com.example.data.ProductBadge
import com.example.ui.theme.*

@Composable
fun ProductCard(
    product: Product,
    isSaved: Boolean,
    onProductClick: () -> Unit,
    onSaveToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface)
            .clickable { onProductClick() }
            .padding(bottom = 12.dp)
            .testTag("product_card_${product.id}")
    ) {
        // Image & Heart Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.75f) // High fashion portrait aspect ratio (3:4)
                .background(AsosOffWhite)
        ) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(product.imagePrimary)
                    .crossfade(true)
                    .build(),
                contentDescription = product.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Restricted Small Badges
            product.badge?.let { badge ->
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .background(
                            when (badge) {
                                ProductBadge.SALE -> AsosOrange
                                ProductBadge.TRENDING -> AsosBlack
                                ProductBadge.NEW_IN -> AsosAccentLime
                                ProductBadge.LOW_STOCK -> AsosOrange
                                ProductBadge.EDITORS_PICK -> AsosWhite
                                ProductBadge.BESTSELLER -> AsosBlack
                            },
                            shape = RoundedCornerShape(2.dp)
                        )
                        .border(
                            width = 1.dp,
                            color = if (badge == ProductBadge.EDITORS_PICK) AsosBlack else Color.Transparent,
                            shape = RoundedCornerShape(2.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                        .align(Alignment.TopStart)
                ) {
                    Text(
                        text = badge.name.replace("_", " "),
                        color = when (badge) {
                            ProductBadge.NEW_IN -> AsosBlack
                            ProductBadge.EDITORS_PICK -> AsosBlack
                            else -> AsosWhite
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Save Toggle Button
            val favoriteColor by animateColorAsState(
                targetValue = if (isSaved) AsosOrange else AsosBlack,
                animationSpec = spring()
            )

            IconButton(
                onClick = onSaveToggle,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(AsosWhite, shape = CircleShape)
                    .size(36.dp)
                    .testTag("save_button_${product.id}")
            ) {
                Icon(
                    imageVector = if (isSaved) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Save Item",
                    tint = favoriteColor,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Product Details
        Column(modifier = Modifier.padding(horizontal = 4.dp)) {
            Text(
                text = product.brand.uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = product.name,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "£${"%.2f".format(product.price)}",
                    style = MaterialTheme.typography.titleMedium,
                    color = if (product.isOnSale) AsosOrange else MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Black
                )

                if (product.isOnSale && product.originalPrice != null) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "£${"%.2f".format(product.originalPrice)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                        textDecoration = TextDecoration.LineThrough
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = product.color.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                fontSize = 9.sp
            )
        }
    }
}

@Composable
fun PremiumButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    backgroundColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.onPrimary,
    isEnabled: Boolean = true,
    testTag: String = "premium_btn"
) {
    Button(
        onClick = onClick,
        enabled = isEnabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor,
            contentColor = contentColor,
            disabledContainerColor = AsosLightGray,
            disabledContentColor = AsosGray
        ),
        shape = RoundedCornerShape(0.dp), // Strict high fashion brutalist square corners
        modifier = modifier
            .height(52.dp)
            .testTag(testTag),
        contentPadding = PaddingValues(horizontal = 24.dp)
    ) {
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelLarge,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp
        )
    }
}

@Composable
fun PremiumOutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    borderColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.primary,
    isEnabled: Boolean = true,
    testTag: String = "premium_outline_btn"
) {
    OutlinedButton(
        onClick = onClick,
        enabled = isEnabled,
        border = BorderStroke(1.5.dp, borderColor),
        shape = RoundedCornerShape(0.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = contentColor
        ),
        modifier = modifier
            .height(52.dp)
            .testTag(testTag)
    ) {
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelLarge,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
        )
    }
}

@Composable
fun FashionSkeletonCard(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface)
            .padding(bottom = 12.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.75f)
                .background(AsosLightGray)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth(0.5f)
                .height(14.dp)
                .background(AsosLightGray)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(16.dp)
                .background(AsosLightGray)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth(0.3f)
                .height(16.dp)
                .background(AsosLightGray)
        )
    }
}
