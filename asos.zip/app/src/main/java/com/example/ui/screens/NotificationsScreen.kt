package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.*
import com.example.ui.components.PremiumButton
import com.example.ui.theme.*

@Composable
fun NotificationsScreen(
    viewModel: FashionViewModel,
    modifier: Modifier = Modifier
) {
    val notifications by viewModel.notifications.collectAsState()
    val products by viewModel.products.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateHome() }) {
                Icon(
                    imageVector = Icons.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = AsosBlack
                )
            }
            Text(
                text = "INBOX",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black
            )
        }

        Divider(color = AsosLightGray)

        if (notifications.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.NotificationsActive,
                    contentDescription = "Empty Inbox",
                    tint = AsosGray,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "YOUR INBOX IS EMPTY",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Save products to receive back-in-stock notifications, price drops, and tracking alerts.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AsosGray,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                notifications.forEach { notif ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .border(1.dp, AsosLightGray)
                            .background(AsosWhite)
                            .clickable {
                                notif.linkedProductId?.let { pId ->
                                    products.find { it.id == pId }?.let { prod ->
                                        viewModel.navigateTo(AppScreen.ProductDetails(prod))
                                    }
                                }
                            }
                            .padding(16.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Type Icon / Indicator
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(
                                    when (notif.type) {
                                        NotificationType.BACK_IN_STOCK -> AsosAccentLime
                                        NotificationType.PRICE_DROP -> AsosOrange
                                        NotificationType.ORDER_UPDATE -> AsosBlack
                                        NotificationType.RETURN_UPDATE -> AsosMutedGold
                                        else -> AsosBlack
                                    },
                                    shape = CircleShape
                                )
                                .padding(top = 4.dp)
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        // Text content
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = notif.title,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Black,
                                    color = AsosBlack
                                )
                                Text(
                                    text = notif.timestamp,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AsosGray,
                                    fontSize = 10.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = notif.body,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                lineHeight = 18.sp
                            )

                            // Action Hint if linked
                            if (notif.linkedProductId != null) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "SHOP THIS ITEM NOW →",
                                    color = AsosBlack,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
