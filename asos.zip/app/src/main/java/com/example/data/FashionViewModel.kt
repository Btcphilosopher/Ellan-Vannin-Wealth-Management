package com.example.data

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.UUID

sealed class AppScreen {
    object Home : AppScreen()
    object Discover : AppScreen()
    object Search : AppScreen()
    object Saved : AppScreen()
    object Bag : AppScreen()
    object Account : AppScreen()
    data class ProductDetails(val product: Product) : AppScreen()
    data class SearchResults(val query: String? = null, val categoryFilter: Category? = null, val brandFilter: String? = null) : AppScreen()
    object StyleStudio : AppScreen()
    object OrderHistory : AppScreen()
    object ReturnWizard : AppScreen()
    object Notifications : AppScreen()
    object StyleProfileQuiz : AppScreen()
}

class FashionViewModel : ViewModel() {

    // Navigation Stack (Simulating back stack via a custom list)
    private val _navigationStack = MutableStateFlow<List<AppScreen>>(listOf(AppScreen.Home))
    val navigationStack: StateFlow<List<AppScreen>> = _navigationStack.asStateFlow()

    val currentScreen: AppScreen get() = _navigationStack.value.lastOrNull() ?: AppScreen.Home

    fun navigateTo(screen: AppScreen) {
        val current = _navigationStack.value.toMutableList()
        // Avoid duplicate adjacent screens
        if (current.lastOrNull() == screen) return
        current.add(screen)
        _navigationStack.value = current
    }

    fun navigateBack(): Boolean {
        val current = _navigationStack.value.toMutableList()
        if (current.size > 1) {
            current.removeAt(current.size - 1)
            _navigationStack.value = current
            return true
        }
        return false
    }

    fun navigateHome() {
        _navigationStack.value = listOf(AppScreen.Home)
    }

    // Products Data
    private val _products = MutableStateFlow<List<Product>>(MockData.products)
    val products = _products.asStateFlow()

    // Saved Items & Boards
    private val _savedItems = MutableStateFlow<List<SavedItem>>(MockData.initialSavedItems)
    val savedItems = _savedItems.asStateFlow()

    private val _boards = MutableStateFlow<List<Board>>(MockData.initialBoards)
    val boards = _boards.asStateFlow()

    fun toggleSaveProduct(product: Product, boardName: String? = null) {
        val current = _savedItems.value.toMutableList()
        val existing = current.find { it.product.id == product.id }
        if (existing != null) {
            current.remove(existing)
        } else {
            current.add(SavedItem(product = product, boardName = boardName))
        }
        _savedItems.value = current
    }

    fun isProductSaved(product: Product): Boolean {
        return _savedItems.value.any { it.product.id == product.id }
    }

    fun createBoard(name: String, coverImage: String) {
        val current = _boards.value.toMutableList()
        if (!current.any { it.name.equals(name, ignoreCase = true) }) {
            current.add(Board(name = name, coverImage = coverImage))
            _boards.value = current
        }
    }

    // Shopping Bag (Cart)
    private val _cartItems = MutableStateFlow<List<CartItem>>(MockData.initialCart)
    val cartItems = _cartItems.asStateFlow()

    val subtotal: Double get() = _cartItems.value.sumOf { it.product.price * it.quantity }
    val shippingCost: Double get() = if (subtotal > 50.00 || subtotal == 0.0) 0.0 else 3.95
    val totalAmount: Double get() = subtotal + shippingCost

    fun addToCart(product: Product, size: String, color: String) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id && it.size == size && it.color == color }
        if (index >= 0) {
            current[index] = current[index].copy(quantity = current[index].quantity + 1)
        } else {
            current.add(CartItem(product, size, color, 1))
        }
        _cartItems.value = current

        // Trigger notification simulation for selling fast occasionally
        if (product.badge == ProductBadge.LOW_STOCK) {
            addNotification(
                NotificationType.PERSONALISED_PICK,
                "EXCELLENT CHOICE",
                "You added '${product.name}' to your bag. This item is selling fast and has low stock!",
                product.id
            )
        }
    }

    fun updateCartQuantity(product: Product, size: String, color: String, delta: Int) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id && it.size == size && it.color == color }
        if (index >= 0) {
            val newQty = current[index].quantity + delta
            if (newQty <= 0) {
                current.removeAt(index)
            } else {
                current[index] = current[index].copy(quantity = newQty)
            }
        }
        _cartItems.value = current
    }

    fun removeFromCart(product: Product, size: String, color: String) {
        val current = _cartItems.value.toMutableList()
        current.removeAll { it.product.id == product.id && it.size == size && it.color == color }
        _cartItems.value = current
    }

    fun clearCart() {
        _cartItems.value = emptyList()
    }

    // Orders History
    private val _orders = MutableStateFlow<List<Order>>(MockData.orders)
    val orders = _orders.asStateFlow()

    fun placeOrder(paymentMethod: String) {
        if (_cartItems.value.isEmpty()) return
        val newOrder = Order(
            id = "AS${(100000 + (Math.random() * 900000).toInt())}",
            items = _cartItems.value,
            subtotal = subtotal,
            shippingCost = shippingCost,
            total = totalAmount,
            status = OrderStatus.ORDERED,
            dateOrdered = "2026-10-06",
            trackingTimeline = listOf(
                OrderStatus.ORDERED to "2026-10-06 07:25"
            )
        )
        val list = _orders.value.toMutableList()
        list.add(0, newOrder)
        _orders.value = list
        clearCart()

        // Schedule return wizard possibility & add order dispatch notification
        addNotification(
            NotificationType.ORDER_UPDATE,
            "ORDER CONFIRMED: ${newOrder.id}",
            "Your payment via $paymentMethod was successful. We are preparing your order and will notify you when it's dispatched.",
            null
        )
    }

    // Return requests
    private val _returns = MutableStateFlow<List<ReturnRequest>>(emptyList())
    val returns = _returns.asStateFlow()

    fun submitReturn(orderId: String, product: Product, size: String, reason: ReturnReason, method: String) {
        val newReturn = ReturnRequest(
            id = "RET${(10000 + (Math.random() * 90000).toInt())}",
            orderId = orderId,
            product = product,
            size = size,
            reason = reason,
            method = method,
            status = "Initiated",
            dateRequested = "2026-10-06"
        )
        val list = _returns.value.toMutableList()
        list.add(0, newReturn)
        _returns.value = list

        addNotification(
            NotificationType.RETURN_UPDATE,
            "RETURN REGISTERED: ${newReturn.id}",
            "We have generated a return drop-off QR code for your ${product.brand} item. Drop it off at your nearest station.",
            null
        )
    }

    // Filter drawer & Sorting
    val filterCategory = MutableStateFlow<Category?>(null)
    val filterBrand = MutableStateFlow<String?>(null)
    val filterSize = MutableStateFlow<String?>(null)
    val filterColor = MutableStateFlow<String?>(null)
    val filterPriceMax = MutableStateFlow<Float>(200f)
    val filterSubcategory = MutableStateFlow<Subcategory?>(null)
    val sortOption = MutableStateFlow("RECOMMENDED")

    fun resetFilters() {
        filterCategory.value = null
        filterBrand.value = null
        filterSize.value = null
        filterColor.value = null
        filterPriceMax.value = 200f
        filterSubcategory.value = null
        sortOption.value = "RECOMMENDED"
    }

    // Search Centre
    private val _recentSearches = MutableStateFlow(listOf("black leather jacket", "wide leg jeans", "adidas spezial", "autumn coats"))
    val recentSearches = _recentSearches.asStateFlow()

    fun addRecentSearch(query: String) {
        val current = _recentSearches.value.toMutableList()
        current.remove(query)
        current.add(0, query)
        _recentSearches.value = current.take(5)
    }

    // Flagship Style Match Visual Search Simulation
    private val _styleMatchState = MutableStateFlow<StyleMatchStatus>(StyleMatchStatus.Idle)
    val styleMatchState = _styleMatchState.asStateFlow()

    sealed class StyleMatchStatus {
        object Idle : StyleMatchStatus()
        object Analyzing : StyleMatchStatus()
        data class Success(
            val jacketMatch: Int,
            val trousersMatch: Int,
            val shoesMatch: Int,
            val results: List<Product>
        ) : StyleMatchStatus()
    }

    fun startStyleMatchAnalysis() {
        _styleMatchState.value = StyleMatchStatus.Analyzing
        // We simulate a 2-second premium computer vision style scan
        // Then produce structured fashion percentage overlaps
        kotlinx.coroutines.GlobalScope.launch {
            delay(2000)
            _styleMatchState.value = StyleMatchStatus.Success(
                jacketMatch = (80..98).random(),
                trousersMatch = (70..90).random(),
                shoesMatch = (85..99).random(),
                results = listOf(MockData.products[1], MockData.products[3], MockData.products[2])
            )
        }
    }

    fun resetStyleMatch() {
        _styleMatchState.value = StyleMatchStatus.Idle
    }

    // Flagship Virtual Try-On Simulation
    private val _tryOnState = MutableStateFlow<TryOnStatus>(TryOnStatus.Idle)
    val tryOnState = _tryOnState.asStateFlow()

    sealed class TryOnStatus {
        object Idle : TryOnStatus()
        object Preparing : TryOnStatus()
        object Generating : TryOnStatus()
        data class Success(val imagePreviewUrl: String) : TryOnStatus()
    }

    fun startVirtualTryOn(product: Product) {
        _tryOnState.value = TryOnStatus.Preparing
        kotlinx.coroutines.GlobalScope.launch {
            delay(1200)
            _tryOnState.value = TryOnStatus.Generating
            delay(1500)
            // Show the product's primary image as the customized body preview
            _tryOnState.value = TryOnStatus.Success(product.imagePrimary)
        }
    }

    fun resetVirtualTryOn() {
        _tryOnState.value = TryOnStatus.Idle
    }

    // Size Intelligence: Find My Size questionnaire
    private val _sizeRecommendation = MutableStateFlow<String?>(null)
    val sizeRecommendation = _sizeRecommendation.asStateFlow()

    fun calculateRecommendedSize(height: Int, shape: String, usualSize: String, preferredFit: String) {
        // Simple logic to output sizing
        val rec = when (usualSize) {
            "XS" -> if (preferredFit == "Oversized") "S" else "XS"
            "S" -> if (preferredFit == "Oversized") "M" else "S"
            "M" -> if (preferredFit == "Oversized") "L" else "M"
            "L" -> if (preferredFit == "Oversized") "XL" else "L"
            "XL" -> "XL"
            else -> "M"
        }
        _sizeRecommendation.value = rec
    }

    fun clearSizeRecommendation() {
        _sizeRecommendation.value = null
    }

    // Flagship Style Studio Outfit Builder / Canvas
    private val _outfitTops = MutableStateFlow<List<Product>>(listOf(MockData.products[1], MockData.products[5], MockData.products[7]))
    private val _outfitTrousers = MutableStateFlow<List<Product>>(listOf(MockData.products[3], MockData.products[8]))
    private val _outfitShoes = MutableStateFlow<List<Product>>(listOf(MockData.products[2], MockData.products[9]))

    // Active layered elements on outfit builder canvas
    val activeTop = MutableStateFlow<Product?>(null)
    val activeTrouser = MutableStateFlow<Product?>(null)
    val activeShoes = MutableStateFlow<Product?>(null)
    val activeOuter = MutableStateFlow<Product?>(null)

    init {
        // Pre-populate with a cool combo
        activeTop.value = MockData.products[5]
        activeTrouser.value = MockData.products[3]
        activeShoes.value = MockData.products[2]
        activeOuter.value = MockData.products[0]
    }

    private val _savedOutfits = MutableStateFlow<List<List<Product>>>(emptyList())
    val savedOutfits = _savedOutfits.asStateFlow()

    fun saveOutfit() {
        val list = mutableListOf<Product>()
        activeTop.value?.let { list.add(it) }
        activeTrouser.value?.let { list.add(it) }
        activeShoes.value?.let { list.add(it) }
        activeOuter.value?.let { list.add(it) }

        if (list.isNotEmpty()) {
            val current = _savedOutfits.value.toMutableList()
            current.add(0, list)
            _savedOutfits.value = current

            addNotification(
                NotificationType.PERSONALISED_PICK,
                "STUDIO OUTFIT SAVED",
                "Your style studio canvas outfit consisting of ${list.size} pieces has been saved to your profile outfits.",
                null
            )
        }
    }

    // Notifications state
    private val _notifications = MutableStateFlow<List<NotificationItem>>(MockData.notifications)
    val notifications = _notifications.asStateFlow()

    fun addNotification(type: NotificationType, title: String, body: String, linkedProductId: String? = null) {
        val newItem = NotificationItem(
            type = type,
            title = title,
            body = body,
            timestamp = "Just now",
            linkedProductId = linkedProductId
        )
        val current = _notifications.value.toMutableList()
        current.add(0, newItem)
        _notifications.value = current
    }

    // Style profile quiz
    val userStyleProfile = MutableStateFlow(UserProfile())

    fun updateStyleProfile(profile: UserProfile) {
        userStyleProfile.value = profile
        // Add personalized drops immediately based on preferences!
        addNotification(
            NotificationType.PERSONALISED_PICK,
            "STYLE PROFILE UPDATED",
            "We have recalibrated your feeds to highlight '${profile.preferredFit}' shapes in ${profile.favoriteColors.joinToString()} from ${profile.favoriteBrands.joinToString()}.",
            null
        )
    }
}
