package com.example.data

object MockData {
    val products = listOf(
        Product(
            id = "p1",
            brand = "ASOS DESIGN",
            name = "Oversized Wool Blend Trench Coat",
            price = 95.00,
            originalPrice = 120.00,
            color = "Charcoal Melange",
            rating = 4.8f,
            category = Category.MEN,
            subcategory = Subcategory.OUTERWEAR,
            imagePrimary = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=600",
            images = listOf(
                "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=600",
                "https://images.unsplash.com/photo-1483389127117-b6a2102724ae?auto=format&fit=crop&q=80&w=600",
                "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=600"
            ),
            badge = ProductBadge.SALE,
            description = "Heavyweight wool-blend outer with double-breasted button placket and adjustable waist tie. Relaxed aesthetic with structured dropped shoulders.",
            details = listOf(
                "Dropped shoulders",
                "Wide notch lapels",
                "Functional side pockets",
                "70% Wool, 30% Recycled Fibres"
            )
        ),
        Product(
            id = "p2",
            brand = "ASOS DESIGN",
            name = "Distressed Leather Biker Jacket",
            price = 145.00,
            originalPrice = null,
            color = "Faded Black",
            rating = 4.7f,
            category = Category.WOMEN,
            subcategory = Subcategory.OUTERWEAR,
            imagePrimary = "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=600",
            images = listOf(
                "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=600"
            ),
            badge = ProductBadge.TRENDING,
            description = "Supple distressed real leather with heavy metal zip details. Relaxed silhouette for retro layering.",
            details = listOf(
                "100% Real Leather",
                "Zip closure",
                "Classic collar style",
                "Vintage wash finish"
            )
        ),
        Product(
            id = "p3",
            brand = "adidas",
            name = "Spezial Retro Trainers",
            price = 85.00,
            originalPrice = null,
            color = "Core Black / Cloud White",
            rating = 4.9f,
            category = Category.MEN,
            subcategory = Subcategory.RETRO_TRAINERS,
            imagePrimary = "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=600",
            images = listOf(
                "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=600"
            ),
            badge = ProductBadge.BESTSELLER,
            description = "An iconic silhouette from the indoor court legacy. Premium suede upper with metallic gold branding accents.",
            details = listOf(
                "Soft suede upper",
                "Contrast 3-stripes",
                "Gum rubber cupsole",
                "Lace closure"
            )
        ),
        Product(
            id = "p4",
            brand = "COLLUSION",
            name = "Wide-Leg Skater Jeans",
            price = 38.00,
            originalPrice = null,
            color = "Light Wash Blue",
            rating = 4.4f,
            category = Category.WOMEN,
            subcategory = Subcategory.DENIM,
            imagePrimary = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=600",
            images = listOf(
                "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=600"
            ),
            badge = ProductBadge.NEW_IN,
            description = "Baggy wide-leg denim. Sits low on the waist, flowing into a dramatic pool hem for ultimate skater aesthetics.",
            details = listOf(
                "100% Cotton durable denim",
                "Classic 5 pocket styling",
                "Wide pool-hem drape",
                "Zip fly"
            )
        ),
        Product(
            id = "p5",
            brand = "ASOS DESIGN",
            name = "Loose-Knit Minimalist Cardigan",
            price = 45.00,
            originalPrice = 55.00,
            color = "Sand Beige",
            rating = 4.6f,
            category = Category.WOMEN,
            subcategory = Subcategory.KNITWEAR,
            imagePrimary = "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&q=80&w=600",
            images = listOf(
                "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&q=80&w=600"
            ),
            badge = ProductBadge.SALE,
            description = "Lightweight textured open-front sweater. Layered over simple tees for an elevated minimal style.",
            details = listOf(
                "Loose gauge waffle stitch",
                "Ribbed cuffs and hem",
                "Dropped shoulder line",
                "Soft-touch wool blend"
            )
        ),
        Product(
            id = "p6",
            brand = "Nike",
            name = "Phoenix Fleece Oversized Hoody",
            price = 62.00,
            originalPrice = null,
            color = "Heather Grey",
            rating = 4.8f,
            category = Category.ACTIVE,
            subcategory = Subcategory.ACTIVEWEAR,
            imagePrimary = "https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&q=80&w=600",
            images = listOf(
                "https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&q=80&w=600"
            ),
            badge = ProductBadge.EDITORS_PICK,
            description = "Elevated basics in heavy brushed fleece. Keeps structure while giving an effortless cozy comfort.",
            details = listOf(
                "Oversized spacious hood",
                "Exaggerated rib detailing",
                "Kangaroo front pouch",
                "Brushed interior fleece"
            )
        ),
        Product(
            id = "p7",
            brand = "Fenty Beauty",
            name = "Gloss Bomb Universal Lip Luminizer",
            price = 18.00,
            originalPrice = null,
            color = "Fenty Glow",
            rating = 4.9f,
            category = Category.BEAUTY,
            subcategory = Subcategory.MAKEUP,
            imagePrimary = "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&q=80&w=600",
            images = listOf(
                "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&q=80&w=600"
            ),
            badge = ProductBadge.TRENDING,
            description = "The stop-everything, give-it-to-me gloss that feels as good as it looks. Explosive shine, conditioning properties.",
            details = listOf(
                "Universal shade",
                "Shea butter enriched formula",
                "Addictive peach-vanilla scent",
                "Cruelty-free"
            )
        ),
        Product(
            id = "p8",
            brand = "ASOS EDITION",
            name = "Minimalist Double-Breasted Blazer",
            price = 110.00,
            originalPrice = null,
            color = "Camel Cream",
            rating = 4.5f,
            category = Category.WOMEN,
            subcategory = Subcategory.TAILORING,
            imagePrimary = "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=600",
            images = listOf(
                "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=600"
            ),
            badge = ProductBadge.NEW_IN,
            description = "Sharp tailoring with modern oversized proportions. Structured shoulder padding and fully satin lined.",
            details = listOf(
                "Slightly boxy fit",
                "Internal chest pockets",
                "Signature peak lapels",
                "Sartorial finish"
            )
        ),
        Product(
            id = "p9",
            brand = "ASOS DESIGN",
            name = "Straight Leg Selvedge Jeans",
            price = 42.00,
            originalPrice = null,
            color = "Raw Indigo",
            rating = 4.3f,
            category = Category.MEN,
            subcategory = Subcategory.DENIM,
            imagePrimary = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=600",
            images = listOf("https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=600"),
            badge = null
        ),
        Product(
            id = "p10",
            brand = "ASOS DESIGN",
            name = "Leather Square-Toe Loafers",
            price = 65.00,
            originalPrice = null,
            color = "Polished Black",
            rating = 4.6f,
            category = Category.MEN,
            subcategory = Subcategory.RETRO_TRAINERS,
            imagePrimary = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=600",
            images = listOf("https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=600"),
            badge = null
        ),
        Product(
            id = "p11",
            brand = "ASOS DESIGN",
            name = "Leather Crossbody Sling Bag",
            price = 28.00,
            originalPrice = 35.00,
            color = "Matte Black",
            rating = 4.5f,
            category = Category.ACCESSORIES,
            subcategory = Subcategory.SUNGLASSES,
            imagePrimary = "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=600",
            images = listOf("https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=600"),
            badge = ProductBadge.SALE
        )
    )

    val brands = listOf(
        Brand(
            name = "ASOS DESIGN",
            campaignImage = "https://images.unsplash.com/photo-1483389127117-b6a2102724ae?auto=format&fit=crop&q=80&w=600",
            description = "Our flagship collection, bringing you fresh, cutting-edge style. Designed in London, styled by you."
        ),
        Brand(
            name = "adidas",
            campaignImage = "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=600",
            description = "The brand with the three stripes. Celebrating sportswear history merged with timeless street culture."
        ),
        Brand(
            name = "Nike",
            campaignImage = "https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&q=80&w=600",
            description = "Innovative sportswear and streetwear staples. Just Do It."
        ),
        Brand(
            name = "COLLUSION",
            campaignImage = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&q=80&w=600",
            description = "A brand for the coming generation that believes in full inclusivity and self-expression."
        )
    )

    val editorialStories = listOf(
        EditorialStory(
            id = "s1",
            title = "THE NEW BRITISH WORKWEAR",
            subtitle = "AUTUMN 2026 EDIT",
            category = "AUTUMN 2026",
            copy = "Structured utilitarian jackets, heavyweight raw indigo denim, and chunky leather loafers. Discover tailored comfort and weatherproof materials crafted for modern cultural shifts and premium workwear layers.",
            mainImage = "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=800",
            products = listOf(products[0], products[7], products[8])
        ),
        EditorialStory(
            id = "s2",
            title = "STREET COUTURE: SNEAKERS & LAYERS",
            subtitle = "RETRO FUTURE",
            category = "TREND REPORT",
            copy = "Where active comfort meets tailored lines. Elevate retro Spezial trainers with oversized tailored blazers and faded distressed leather biker jackets to challenge seasonal norms.",
            mainImage = "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=800",
            products = listOf(products[2], products[1], products[5])
        )
    )

    val initialSavedItems = listOf(
        SavedItem(products[0], boardName = "AUTUMN"),
        SavedItem(products[2], boardName = "AUTUMN"),
        SavedItem(products[4], boardName = "HOLIDAY")
    )

    val initialBoards = listOf(
        Board(name = "AUTUMN", coverImage = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=300"),
        Board(name = "HOLIDAY", coverImage = "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?auto=format&fit=crop&q=80&w=300"),
        Board(name = "WISHLIST", coverImage = "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=300")
    )

    val initialCart = listOf(
        CartItem(products[1], "M", "Faded Black", 1),
        CartItem(products[3], "S", "Light Wash Blue", 1)
    )

    val orders = listOf(
        Order(
            id = "AS123456",
            items = listOf(
                CartItem(products[0], "M", "Charcoal Melange", 1),
                CartItem(products[2], "10", "Core Black", 1)
            ),
            subtotal = 180.00,
            shippingCost = 0.00,
            total = 180.00,
            status = OrderStatus.DISPATCHED,
            dateOrdered = "2026-10-04",
            trackingTimeline = listOf(
                OrderStatus.ORDERED to "2026-10-04 09:12",
                OrderStatus.PROCESSED to "2026-10-04 14:30",
                OrderStatus.DISPATCHED to "2026-10-05 10:15"
            )
        ),
        Order(
            id = "AS987654",
            items = listOf(
                CartItem(products[5], "M", "Heather Grey", 1)
            ),
            subtotal = 62.00,
            shippingCost = 3.95,
            total = 65.95,
            status = OrderStatus.DELIVERED,
            dateOrdered = "2026-09-28",
            trackingTimeline = listOf(
                OrderStatus.ORDERED to "2026-09-28 11:00",
                OrderStatus.PROCESSED to "2026-09-28 15:45",
                OrderStatus.DISPATCHED to "2026-09-29 08:20",
                OrderStatus.OUT_FOR_DELIVERY to "2026-09-30 09:00",
                OrderStatus.DELIVERED to "2026-09-30 13:42"
            )
        )
    )

    val notifications = listOf(
        NotificationItem(
            type = NotificationType.BACK_IN_STOCK,
            title = "BACK IN STOCK: SPEZIAL RETRO",
            body = "The adidas Spezial Retro Trainers in Core Black / Cloud White are back in your size M. Get them before they disappear again!",
            timestamp = "2 hours ago",
            linkedProductId = "p3"
        ),
        NotificationItem(
            type = NotificationType.PRICE_DROP,
            title = "PRICE DROP ALERT",
            body = "Your saved 'Oversized Wool Blend Trench Coat' has dropped from £120.00 to £95.00! Double-breasted warmth at a reduction.",
            timestamp = "1 day ago",
            linkedProductId = "p1"
        ),
        NotificationItem(
            type = NotificationType.ORDER_UPDATE,
            title = "ORDER DISPATCHED",
            body = "Great news! Your Order #AS123456 has been dispatched from our London hub and is on its way. Delivery estimate: Thursday.",
            timestamp = "1 day ago"
        ),
        NotificationItem(
            type = NotificationType.NEW_DROP,
            title = "COLLUSION: DROP 04",
            body = "Collusion Drop 04 has landed with raw hemlines, pooling wide leg skater denim, and digital jersey prints. Check it out now.",
            timestamp = "3 days ago"
        )
    )
}
