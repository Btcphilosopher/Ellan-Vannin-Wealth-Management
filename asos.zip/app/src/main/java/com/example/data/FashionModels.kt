package com.example.data

import java.util.UUID

enum class Category {
    WOMEN, MEN, ACCESSORIES, BEAUTY, ACTIVE
}

enum class Subcategory {
    OUTERWEAR, DENIM, RETRO_TRAINERS, ACTIVEWEAR, KNITWEAR, TAILORING, PARTY, MAKEUP, SKINCARE, FRAGRANCE, SUNGLASSES
}

enum class ProductBadge {
    NEW_IN, SALE, LOW_STOCK, TRENDING, EDITORS_PICK, BESTSELLER
}

data class Product(
    val id: String = UUID.randomUUID().toString(),
    val brand: String,
    val name: String,
    val price: Double,
    val originalPrice: Double? = null,
    val color: String,
    val rating: Float = 4.5f,
    val sizes: List<String> = listOf("XS", "S", "M", "L", "XL"),
    val category: Category,
    val subcategory: Subcategory,
    val imagePrimary: String, // High-res portrait photo
    val images: List<String>, // Grid carousel images
    val badge: ProductBadge? = null,
    val description: String = "Structured silhouette with premium finish. Perfect modern addition to your rotation.",
    val details: List<String> = listOf("Oversized fit", "Premium heavyweight material", "Fully lined for comfort", "Designed in London"),
    val material: String = "70% Wool, 30% Polyester",
    val care: String = "Dry clean only. Do not iron.",
    val deliveryInfo: String = "Standard delivery (3-5 days): £3.95 (Free on orders over £50). Express Next-Day: £5.95."
) {
    val isOnSale: Boolean get() = originalPrice != null
}

data class Brand(
    val name: String,
    val logoUrl: String? = null,
    val campaignImage: String,
    val description: String,
    var isFollowed: Boolean = false
)

data class SavedItem(
    val product: Product,
    val savedAt: Long = System.currentTimeMillis(),
    val boardName: String? = null // Associated Board name (e.g., "AUTUMN", "WORK")
)

data class Board(
    val name: String,
    val coverImage: String,
    val isShared: Boolean = false
)

data class CartItem(
    val product: Product,
    val size: String,
    val color: String,
    val quantity: Int = 1
)

enum class OrderStatus {
    ORDERED, PROCESSED, DISPATCHED, OUT_FOR_DELIVERY, DELIVERED
}

data class Order(
    val id: String,
    val items: List<CartItem>,
    val subtotal: Double,
    val shippingCost: Double,
    val total: Double,
    val status: OrderStatus,
    val dateOrdered: String,
    val trackingTimeline: List<Pair<OrderStatus, String>> // Status to date string
)

enum class ReturnReason(val label: String) {
    TOO_SMALL("Too small"),
    TOO_LARGE("Too large"),
    NOT_AS_PICTURED("Not as pictured"),
    CHANGED_MIND("Changed mind"),
    FAULTY("Faulty / Damaged")
}

data class ReturnRequest(
    val id: String,
    val orderId: String,
    val product: Product,
    val size: String,
    val reason: ReturnReason,
    val method: String, // e.g., "Drop-off", "Collection"
    val status: String, // "Initiated", "In Transit", "Processed", "Refunded"
    val dateRequested: String,
    val qrCodeUrl: String = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=RETURN_${id}"
)

enum class NotificationType {
    BACK_IN_STOCK, PRICE_DROP, ORDER_UPDATE, RETURN_UPDATE, NEW_DROP, BRAND_UPDATE, PERSONALISED_PICK
}

data class NotificationItem(
    val id: String = UUID.randomUUID().toString(),
    val type: NotificationType,
    val title: String,
    val body: String,
    val timestamp: String,
    val isRead: Boolean = false,
    val linkedProductId: String? = null
)

data class UserProfile(
    var height: Int = 178, // in cm
    var bodyShape: String = "Average", // Slim, Athletic, Average, Full
    var usualSize: String = "M",
    var preferredFit: String = "Oversized", // Slim, Regular, Oversized
    var favoriteColors: List<String> = listOf("Black", "Off-White", "Charcoal"),
    var favoriteBrands: List<String> = listOf("ASOS DESIGN", "adidas", "Nike")
)

data class EditorialStory(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String, // "AUTUMN 2026", "TREND REPORT", "CULTURE"
    val copy: String,
    val mainImage: String,
    val products: List<Product>
)
