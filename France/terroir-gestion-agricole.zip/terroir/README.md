# TERROIR — Gestion agricole

Suite logicielle en français pour gérer une exploitation agricole et ses sites : parcelles, cultures, animaux,
équipements, stocks, équipes, achats, ventes et analyses économiques, reliés par des données communes et traçables.

Parcours principal : **planifier → approvisionner → intervenir → observer → récolter → stocker → vendre → analyser**.

> Version 0.1 — démonstration fonctionnelle sur une exploitation **fictive** (Ferme des Trois Vallées) et des
> données **synthétiques**. Terroir n'est ni un outil de télédéclaration, ni une comptabilité réglementaire, ni un
> outil de prescription : voir [l'état fonctionnel](docs/ETAT_FONCTIONNEL.md).

## Contenu

| Dossier | Contenu |
|---|---|
| `backend/` | API Python 3.13 / FastAPI (monolithe modulaire), modèles SQLAlchemy + GeoAlchemy2, migrations Alembic, travailleur, démonstration, tests |
| `frontend/` | Interface Next.js / React / TypeScript, mode terrain hors connexion (service worker + IndexedDB) |
| `docs/` | Architecture, API, état fonctionnel, sécurité, analyses, sources et licences, démonstration, résultats, captures |
| `deploy/` | Configuration du stockage objet (SeaweedFS) |
| `scripts/` | Démonstration locale, génération de la documentation API, régénération de migration (développement) |
| `docker-compose.yml` | Base PostGIS, stockage S3 privé, API, travailleur, interface, outils (démo, sauvegarde) |

## Démarrage rapide (Docker)

Prérequis : Docker avec Compose v2.

```bash
cp .env.example .env        # puis changez les mots de passe et clés
```

```bash
docker compose up -d --build
```

```bash
docker compose --profile outils run --rm demo
```

- Interface : http://localhost:3000 (comptes dans [docs/DEMO.md](docs/DEMO.md), mot de passe de démonstration `Terroir-Demo-2026!`)
- API : http://localhost:8000/api/docs (Swagger) — [référence API](docs/API.md)
- Le port PostgreSQL et le stockage S3 ne sont pas exposés hors du réseau Compose.

Tests dans les conteneurs :

```bash
docker compose run --rm api python -m pytest -q
```

Sauvegarde :

```bash
docker compose --profile outils run --rm sauvegarde
```

## Installation sans Docker (développement)

Prérequis : Python 3.12+, Node.js 22+, PostgreSQL 16 avec PostGIS 3, `pg_dump`/`pg_restore`.

```bash
createuser -s terroir && psql -c "ALTER USER terroir PASSWORD 'terroir'" && createdb -O terroir terroir
```

```bash
cd backend && pip install -r requirements-dev.txt && alembic upgrade head
```

```bash
cd backend && uvicorn app.main:app --reload --port 8000
```

```bash
cd backend && python -m app.worker
```

```bash
cd frontend && npm install && npm run dev
```

```bash
./scripts/demo_locale.sh
```

```bash
cd backend && python -m pytest -q
```

Configuration : variables `TERROIR_*` (voir `backend/app/core/config.py`), notamment `TERROIR_DATABASE_URL`,
`TERROIR_STOCKAGE_BACKEND` (`local` ou `s3`), `TERROIR_COOKIE_SECURE`, `TERROIR_TOLERANCE_ECART_SURFACE_PCT`.
Les tests utilisent la base `terroir_test` (recréée à chaque session) ou `TERROIR_TEST_DATABASE_URL`.

## Aperçu

| Tableau de bord | Parcelles | Intervention et vérification | Terrain hors connexion |
|---|---|---|---|
| ![](docs/captures/02-tableau-de-bord.png) | ![](docs/captures/03-parcelles-carte.png) | ![](docs/captures/05-travaux-intervention-verification.png) | ![](docs/captures/08-terrain-hors-connexion-telephone.png) |

## Résultats obtenus (28/11/2026)

- Backend : **51/51 tests** (hôte), 50/50 dans Docker (restauration testée sur l'hôte).
- Démonstration : **38/38 vérifications**, sur l'hôte et dans la pile Docker Compose avec stockage S3.
- Interface : `tsc` sans erreur, `next build` réussi, **parcours Playwright 45/45** (hôte et pile Docker complète).
- Détails et écarts : [docs/RESULTATS_TESTS.md](docs/RESULTATS_TESTS.md).

## Documentation

- [Architecture](docs/ARCHITECTURE.md) — modules, principes, hors connexion, tâches de fond
- [Référence de l'API](docs/API.md) et [`openapi.json`](docs/openapi.json)
- [État fonctionnel](docs/ETAT_FONCTIONNEL.md) — implémenté / simulé / intégré / reporté
- [Sécurité](docs/SECURITE.md) — rôles, sessions, audit, fichiers, sauvegarde et restauration
- [Analyses](docs/ANALYSES.md) — règles de calcul des coûts, marges, trésorerie, prévisions
- [Sources et licences](docs/SOURCES.md) — dépendances, données officielles, conditions d'intégration
- [Démonstration](docs/DEMO.md) et [résultats obtenus](docs/RESULTATS_DEMO.md)
- [Résultats des tests](docs/RESULTATS_TESTS.md)
- [Interface](frontend/README.md)

## Garde-fous

- Aucune dose, association, autorisation ou délai réglementaire n'est inventé : les contrôles s'appuient sur un
  référentiel importé avec sa source et sa date d'effet ; les contrôles non couverts sont listés ; une validation
  professionnelle est requise. Un enregistrement complet n'est pas une preuve de conformité.
- Aucune commande n'est envoyée à une pompe, une vanne ou une machine. Aucun traitement n'est déclenché.
- Les surfaces déclarées ne sont jamais écrasées par les surfaces calculées.
- La traçabilité signale les maillons manquants au lieu de les reconstituer.
- Les exports ne sont présentés ni comme une déclaration PAC, ni comme une transmission officielle, ni comme un FEC.
