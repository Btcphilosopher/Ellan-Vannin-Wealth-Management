"""Sauvegarde et restauration : base PostgreSQL (pg_dump format custom) + objets stockés.

    python -m app.outils.sauvegarde sauvegarder --dossier ./sauvegardes
    python -m app.outils.sauvegarde restaurer --archive ./sauvegardes/terroir-AAAAMMJJ-HHMMSS.tar --cible postgresql://…
    python -m app.outils.sauvegarde verifier --archive …

L'archive .tar contient : base.dump, objets/ (fichiers du stockage), manifeste.json
(sommes SHA-256 et nombre de lignes par table, utilisés pour vérifier la restauration).
"""
import argparse
import hashlib
import io
import json
import os
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import create_engine, inspect, text

from app.core.config import get_settings
from app.core.stockage import stockage


def _url_libpq(url: str) -> str:
    return url.replace("postgresql+psycopg://", "postgresql://")


def comptages(url: str) -> dict:
    eng = create_engine(url)
    with eng.connect() as c:
        tables = [t for t in inspect(c).get_table_names() if t not in ("spatial_ref_sys",)]
        res = {t: c.execute(text(f'SELECT count(*) FROM "{t}"')).scalar() for t in sorted(tables)}
        res["_somme_mouvements"] = str(c.execute(text("SELECT coalesce(sum(quantite),0) FROM mouvement_stock")).scalar()) if "mouvement_stock" in tables else None
    eng.dispose()
    return res


def sauvegarder(dossier: Path, url: str | None = None) -> Path:
    url = url or get_settings().database_url
    dossier.mkdir(parents=True, exist_ok=True)
    horo = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    archive = dossier / f"terroir-{horo}.tar"
    dump = subprocess.run(["pg_dump", "--format=custom", "--no-owner", "--no-privileges", _url_libpq(url)],
                          check=True, capture_output=True).stdout
    manifeste = {"cree_le": horo, "base": {"sha256": hashlib.sha256(dump).hexdigest(), "taille": len(dump)},
                 "comptages": comptages(url), "objets": {}}
    with tarfile.open(archive, "w") as tar:
        def ajouter(nom, contenu: bytes):
            info = tarfile.TarInfo(nom)
            info.size = len(contenu)
            tar.addfile(info, io.BytesIO(contenu))

        ajouter("base.dump", dump)
        st = stockage()
        for cle in st.lister():
            contenu = st.lire(cle)
            manifeste["objets"][cle] = hashlib.sha256(contenu).hexdigest()
            ajouter(f"objets/{cle}", contenu)
        ajouter("manifeste.json", json.dumps(manifeste, indent=2).encode())
    os.chmod(archive, 0o600)
    return archive


def restaurer(archive: Path, url_cible: str, restaurer_objets: bool = True) -> dict:
    with tarfile.open(archive) as tar:
        manifeste = json.loads(tar.extractfile("manifeste.json").read())
        dump = tar.extractfile("base.dump").read()
        if hashlib.sha256(dump).hexdigest() != manifeste["base"]["sha256"]:
            raise RuntimeError("Archive corrompue : empreinte de la base différente du manifeste.")
        subprocess.run(["pg_restore", "--no-owner", "--no-privileges", "--clean", "--if-exists", "-d", _url_libpq(url_cible)],
                       input=dump, check=True, capture_output=True)
        objets_ok = 0
        if restaurer_objets:
            st = stockage()
            for m in tar.getmembers():
                if m.name.startswith("objets/"):
                    contenu = tar.extractfile(m).read()
                    cle = m.name[len("objets/"):]
                    if hashlib.sha256(contenu).hexdigest() != manifeste["objets"].get(cle):
                        raise RuntimeError(f"Objet corrompu : {cle}")
                    st.ecrire(cle, contenu, "application/octet-stream")
                    objets_ok += 1
    apres = comptages(url_cible)
    ecarts = {t: (n, apres.get(t)) for t, n in manifeste["comptages"].items() if apres.get(t) != n}
    return {"comptages_identiques": not ecarts, "ecarts": ecarts, "objets_restaures": objets_ok,
            "tables": len(manifeste["comptages"])}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Sauvegarde / restauration Terroir")
    sp = ap.add_subparsers(dest="cmd", required=True)
    s = sp.add_parser("sauvegarder")
    s.add_argument("--dossier", default="./sauvegardes")
    r = sp.add_parser("restaurer")
    r.add_argument("--archive", required=True)
    r.add_argument("--cible", required=True)
    a = ap.parse_args()
    if a.cmd == "sauvegarder":
        print(f"Archive créée : {sauvegarder(Path(a.dossier))}")
    else:
        print(json.dumps(restaurer(Path(a.archive), a.cible), indent=2, ensure_ascii=False))
