"""Adaptateurs d'intégration.

Chaque intégration externe passe par une interface. En première version,
seuls des simulateurs sont actifs. Les adaptateurs « officiels » déclarent
explicitement leur statut : aucun accès à un système propriétaire ou
administratif n'est simulé comme s'il était réel.
"""
import hashlib
import math
import random
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal


class Adaptateur:
    nom = ""
    domaine = ""
    statut = "simule"  # simule | non_integre | integre
    description = ""
    documentation = None

    def info(self) -> dict:
        return {"nom": self.nom, "domaine": self.domaine, "statut": self.statut,
                "libelle_statut": {"simule": "Simulateur (données fictives)", "non_integre": "Non intégré",
                                   "integre": "Intégré"}[self.statut],
                "description": self.description, "documentation": self.documentation}


class MeteoSimulee(Adaptateur):
    nom = "Simulateur météo Terroir"
    domaine = "meteo"
    description = ("Génère des observations et prévisions déterministes (graine = nom du site + date). "
                   "Valeurs fictives, marquées « simulées ».")

    def releves(self, site_id, du: date, au: date, aujourd_hui: date | None = None, trous: set[date] = frozenset(), graine: str | None = None):
        aujourd_hui = aujourd_hui or date.today()
        j = du
        while j <= au:
            if j not in trous:
                g = int(hashlib.sha256(f"{graine or site_id}{j}".encode()).hexdigest()[:8], 16)
                rnd = random.Random(g)
                jour_an = j.timetuple().tm_yday
                saison = math.sin((jour_an - 105) / 365 * 2 * math.pi)
                tmax = 17 + 9 * saison + rnd.uniform(-3, 3)
                tmin = tmax - rnd.uniform(6, 11)
                pluie = max(0.0, rnd.gauss(1.2, 4)) if rnd.random() < 0.35 else 0.0
                et0 = max(0.3, 2.4 + 2.2 * saison + rnd.uniform(-0.6, 0.6))
                nature = "observee" if j < aujourd_hui else "prevue"
                yield {"site_id": site_id, "nature": nature, "source": self.nom, "pour_date": j,
                       "emis_le": datetime.now(timezone.utc) if nature == "prevue" else None,
                       "temperature_min_c": Decimal(f"{tmin:.1f}"), "temperature_max_c": Decimal(f"{tmax:.1f}"),
                       "pluie_mm": Decimal(f"{pluie:.1f}"), "vent_moyen_kmh": Decimal(f"{rnd.uniform(4, 22):.0f}"),
                       "rafales_kmh": Decimal(f"{rnd.uniform(15, 45):.0f}"), "humidite_relative_pct": Decimal(f"{rnd.uniform(55, 95):.0f}"),
                       "et0_mm": Decimal(f"{et0:.1f}"), "simulee": True}
            j += timedelta(days=1)


class MeteoFrance(Adaptateur):
    nom = "Météo-France — portail des API"
    domaine = "meteo"
    statut = "non_integre"
    description = ("Prévu : observations et prévisions AROME/ARPEGE. Nécessite un compte, un abonnement par API et une clé ; "
                   "quotas par compte. Non activé : aucune donnée n'est récupérée.")
    documentation = "https://portail-api.meteofrance.fr/"


class CartoImport(Adaptateur):
    nom = "Import GeoJSON (relevé, export SIG)"
    domaine = "cartographie"
    statut = "integre"
    description = "Import de limites en GeoJSON avec déclaration du système de coordonnées (EPSG:4326, 2154…)."


class CadastreIGN(Adaptateur):
    nom = "IGN Géoplateforme — Parcellaire Express / API Carto"
    domaine = "cartographie"
    statut = "non_integre"
    description = "Prévu : récupération des références et géométries cadastrales. Conditions de licence à confirmer avant activation."
    documentation = "https://apicarto.ign.fr/api/doc/"


class MachineSimulee(Adaptateur):
    nom = "Simulateur de télémétrie machine"
    domaine = "machines"
    description = "Fournit heures moteur et quantités appliquées fictives, toujours étiquetées « télémétrie simulée ». Aucune commande n'est envoyée."

    def heures_moteur(self, base: float, heures: float) -> dict:
        return {"heures_moteur": round(base + heures, 1), "source": "telemetrie_simulee"}


class BalanceSimulee(Adaptateur):
    nom = "Simulateur de pont-bascule"
    domaine = "balances"
    description = "Retourne une pesée fictive (brut − tare) pour la démonstration."

    def peser(self, attendu_kg: float, graine: str) -> dict:
        rnd = random.Random(graine)
        net = attendu_kg * rnd.uniform(0.97, 1.03)
        tare = 14200.0
        return {"brut_kg": round(net + tare), "tare_kg": tare, "net_kg": round(net), "source": "balance_simulee"}


class ExportComptable(Adaptateur):
    nom = "Export comptable CSV"
    domaine = "comptabilite"
    statut = "integre"
    description = ("Export des ventes, achats et paiements au format CSV pour le cabinet comptable. "
                   "Ce n'est pas un fichier des écritures comptables (FEC) et il ne remplace pas une comptabilité réglementaire.")


class Telepac(Adaptateur):
    nom = "Telepac (PAC)"
    domaine = "services_officiels"
    statut = "non_integre"
    description = ("Aucune API publique de télédéclaration identifiée pour les éditeurs. Terroir prépare des dossiers internes ; "
                   "la déclaration se fait sur Telepac.")
    documentation = "https://www.telepac.agriculture.gouv.fr/"


class IdentificationAnimale(Adaptateur):
    nom = "EdE / BDNI — notifications de mouvements"
    domaine = "services_officiels"
    statut = "non_integre"
    description = "Intégration soumise aux cahiers des charges des EdE (TRACIND pour les ovins) et à un partenariat. Non disponible."


class EPhy(Adaptateur):
    nom = "E-Phy (Anses) — données ouvertes"
    domaine = "services_officiels"
    statut = "non_integre"
    description = ("Import prévu du jeu de données ouvert (CSV/XML, mise à jour hebdomadaire, Licence Ouverte). "
                   "Le format des colonnes doit être validé sur le dictionnaire de données avant activation. "
                   "La démonstration utilise un référentiel FICTIF.")
    documentation = "https://www.data.gouv.fr/ (jeu « Données ouvertes du catalogue E-Phy »)"


class ClassificationPhotos(Adaptateur):
    nom = "Classification d'images (non installée)"
    domaine = "apprentissage"
    statut = "non_integre"
    description = "Aucun modèle validé n'est installé. Aucune suggestion n'est produite."

    def suggerer(self, photos) -> dict:
        return {"statut": "non_disponible", "message": "Aucun modèle de classification validé n'est installé : aucune suggestion.",
                "avertissement": "Une suggestion issue d'une photographie ne serait jamais un diagnostic confirmé "
                                 "et ne déclencherait aucun traitement."}


_ADAPTATEURS = {
    "meteo": MeteoSimulee(), "meteo_france": MeteoFrance(), "carto": CartoImport(), "cadastre": CadastreIGN(),
    "machines": MachineSimulee(), "balance": BalanceSimulee(), "comptabilite": ExportComptable(),
    "telepac": Telepac(), "identification_animale": IdentificationAnimale(), "ephy": EPhy(),
    "classification": ClassificationPhotos(),
}


def adaptateur(cle: str):
    return _ADAPTATEURS[cle]


def tous() -> list[dict]:
    return [a.info() | {"cle": k} for k, a in _ADAPTATEURS.items()]
