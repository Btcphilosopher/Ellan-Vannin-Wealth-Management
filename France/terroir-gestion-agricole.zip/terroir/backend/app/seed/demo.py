"""Démonstration reproductible : Ferme des Trois Vallées (exploitation fictive).

    python -m app.seed.demo [--sortie ./demo_sortie]

Le script réinitialise les données de l'exploitation de démonstration puis
exécute le parcours complet via l'API (client HTTP en processus) :
planifier → approvisionner → intervenir → observer → récolter → stocker →
vendre → analyser, avec les incidents prévus (machine indisponible, rupture
de stock, météo manquante, conflit de synchronisation).
Il écrit un journal `RESULTATS_DEMO.md` et les rapports exportés.
"""
import argparse
import base64
import json
import sys
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from fastapi.testclient import TestClient
from sqlalchemy import delete, select, text

from app.core.db import SessionLocal, maintenant
from app.core.format_fr import court, euros
from app.core.securite import hacher_mot_de_passe
from app.core.taches import executer_en_attente
from app.seed.geometries import PARCELLES, R01

PARIS = ZoneInfo("Europe/Paris")
MDP = "Terroir-Demo-2026!"
NOM_EXPLOITATION = "EARL Ferme des Trois Vallées"
UTILISATEURS = [
    ("claire.martin@trois-vallees.example", "Claire Martin", "gerant"),
    ("julien.roche@trois-vallees.example", "Julien Roche", "chef_culture"),
    ("sofia.benali@trois-vallees.example", "Sofia Benali", "operateur"),
    ("marc.dubois@trois-vallees.example", "Marc Dubois", "eleveur"),
    ("agnes.leroy@conseil.example", "Agnès Leroy", "conseiller"),
    ("dr.perrin@veto.example", "Dr Hélène Perrin", "veterinaire"),
    ("lucie.garnier@compta.example", "Lucie Garnier", "comptable"),
]


def n(v, d=3):
    return court(v, d)


def eur(v):
    return euros(v)


def h(j: date, heure: int, minute: int = 0) -> str:
    return datetime(j.year, j.month, j.day, heure, minute, tzinfo=PARIS).isoformat()


class Journal:
    def __init__(self):
        self.lignes = ["# Résultats de la démonstration — Ferme des Trois Vallées", "",
                       f"Exécutée le {datetime.now(PARIS).strftime('%d/%m/%Y à %H:%M')} (heure de Paris).", "",
                       "Toutes les données sont fictives. Chaque étape appelle l'API réelle ; les incidents sont provoqués volontairement.", ""]
        self.etape_n = 0
        self.verifications = []

    def etape(self, titre):
        self.etape_n += 1
        print(f"\n=== Étape {self.etape_n} : {titre}")
        self.lignes += ["", f"## Étape {self.etape_n} — {titre}", ""]

    def note(self, texte):
        print("  •", texte)
        self.lignes.append(f"- {texte}")

    def verifier(self, condition, libelle):
        etat = "OK" if condition else "ÉCHEC"
        self.verifications.append((libelle, condition))
        self.note(f"[{etat}] {libelle}")
        if not condition:
            raise SystemExit(f"Vérification échouée : {libelle}")


class Api:
    def __init__(self, client, jeton, exp_id, journal):
        self.c, self.j, self.e = client, journal, exp_id
        self.h = {"Authorization": f"Bearer {jeton}"}

    def _url(self, chemin):
        return f"/api/v1/exploitations/{self.e}{chemin}" if not chemin.startswith("/api") else chemin

    def get(self, chemin, attendu=200, **params):
        r = self.c.get(self._url(chemin), headers=self.h, params=params)
        if r.status_code != attendu:
            raise SystemExit(f"GET {chemin} → {r.status_code} {r.text[:500]}")
        return r.json() if "json" in r.headers.get("content-type", "") else r.content

    def post(self, chemin, donnees=None, attendu=(200, 201, 202), **kw):
        r = self.c.post(self._url(chemin), headers=self.h, json=donnees, **kw)
        attendu = attendu if isinstance(attendu, tuple) else (attendu,)
        if r.status_code not in attendu:
            raise SystemExit(f"POST {chemin} → {r.status_code} {r.text[:800]}")
        return r.json()

    def erreur(self, chemin, donnees, statut):
        r = self.c.post(self._url(chemin), headers=self.h, json=donnees)
        if r.status_code != statut:
            raise SystemExit(f"POST {chemin} : erreur {statut} attendue, obtenu {r.status_code} {r.text[:400]}")
        return r.json()

    def patch(self, chemin, donnees):
        r = self.c.patch(self._url(chemin), headers=self.h, json=donnees)
        if r.status_code != 200:
            raise SystemExit(f"PATCH {chemin} → {r.status_code} {r.text[:400]}")
        return r.json()


def reinitialiser(db):
    from app.modules.identite.models import Adhesion, Exploitation, Utilisateur

    e = db.scalar(select(Exploitation).where(Exploitation.raison_sociale == NOM_EXPLOITATION))
    if e:
        db.execute(text("ALTER TABLE mouvement_stock DISABLE TRIGGER tr_mouvement_immuable"))
        db.execute(delete(Exploitation).where(Exploitation.id == e.id))
        db.execute(text("ALTER TABLE mouvement_stock ENABLE TRIGGER tr_mouvement_immuable"))
    for c, _, _ in UTILISATEURS:
        db.execute(delete(Utilisateur).where(Utilisateur.courriel == c))
    db.commit()


def creer_socle(db) -> uuid.UUID:
    from app.modules.identite.models import Adhesion, Exploitation, Utilisateur

    e = Exploitation(raison_sociale=NOM_EXPLOITATION, forme_juridique="EARL (fictive)", siret="DEMO-000000000",
                     adresse="Lieu-dit fictif, 00000 Saint-Aubin-des-Trois-Vallées",
                     modules_actifs=["grandes_cultures", "maraichage", "elevage", "vergers_viticulture"], fictive=True)
    db.add(e)
    db.flush()
    h_mdp = hacher_mot_de_passe(MDP)
    for courriel, nom, role in UTILISATEURS:
        u = Utilisateur(courriel=courriel, nom_affiche=nom, mot_de_passe_hash=h_mdp)
        db.add(u)
        db.flush()
        db.add(Adhesion(utilisateur_id=u.id, exploitation_id=e.id, role=role))
    db.commit()
    return e.id


def connexion(client, courriel):
    r = client.post("/api/v1/auth/connexion", json={"courriel": courriel, "mot_de_passe": MDP})
    r.raise_for_status()
    return r.json()["jeton"]


def historique(db, exp_id, parcelles, articles):
    """Campagnes passées (saisie de reprise d'historique, sans mouvements de stock)."""
    from app.modules.cultures.models import Campagne, CycleCultural
    from app.modules.stocks.models import LotStock

    hist = {
        "2022-2023": {"P01": ("Colza", "Brassicacées", 3.4), "P02": ("Blé tendre", "Poacées", 7.6), "P03": ("Blé tendre", "Poacées", 7.9)},
        "2023-2024": {"P01": ("Blé tendre", "Poacées", 6.9), "P02": ("Orge d'hiver", "Poacées", 6.8), "P03": ("Colza", "Brassicacées", 3.1)},
        "2024-2025": {"P01": ("Orge d'hiver", "Poacées", 7.2), "P02": ("Blé tendre", "Poacées", 8.1), "P03": ("Orge d'hiver", "Poacées", 6.6)},
    }
    article_recolte = {"Blé tendre": "REC-BT", "Orge d'hiver": "REC-ORGE", "Colza": "REC-COLZA"}
    for lib, cycles in hist.items():
        a0 = int(lib[:4])
        camp = Campagne(exploitation_id=exp_id, libelle=lib, date_debut=date(a0, 9, 1), date_fin=date(a0 + 1, 8, 31), statut="close")
        db.add(camp)
        db.flush()
        for code, (culture, famille, rdt) in cycles.items():
            p = parcelles[code]
            surf = p["surface_calculee_ha"]
            c = CycleCultural(exploitation_id=exp_id, campagne_id=camp.id, parcelle_id=uuid.UUID(p["id"]), culture=culture,
                              famille_botanique=famille, surface_prevue_ha=surf, statut="clos",
                              notes="Reprise d'historique (données fictives)")
            db.add(c)
            db.flush()
            art = articles[article_recolte[culture]]
            db.add(LotStock(exploitation_id=exp_id, article_id=uuid.UUID(art["id"]), numero=f"HIST-{lib}-{code}", origine="recolte",
                            parcelle_id=uuid.UUID(p["id"]), cycle_id=c.id, culture=culture, date_recolte=date(a0 + 1, 7, 10),
                            quantite_initiale=round(rdt * surf, 2), unite="t", statut="epuise",
                            qualite_observee={"note": "historique repris"}))
    db.commit()


def main(sortie: Path):
    from app.main import app

    sortie.mkdir(parents=True, exist_ok=True)
    J = Journal()
    db = SessionLocal()
    reinitialiser(db)
    exp_id = creer_socle(db)
    client = TestClient(app)
    api = {role: Api(client, connexion(client, c), exp_id, J) for c, _, role in UTILISATEURS}
    G, CH, OP, EL, CO, VE, CP = (api[r] for r in ("gerant", "chef_culture", "operateur", "eleveur", "conseiller", "veterinaire", "comptable"))

    # ------------------------------------------------------------------ 1
    J.etape("Création des sites et des parcelles")
    sites = {}
    for cle, nom, commune, fuseau in [("VH", "Vallée haute — siège", "Saint-Aubin-des-Trois-Vallées (fictive)", "Europe/Paris"),
                                      ("VL", "Vallée du Lys", "Lys-sur-Brenne (fictive)", "Europe/Paris"),
                                      ("VB", "Vallée basse — maraîchage", "Saint-Aubin-des-Trois-Vallées (fictive)", "Europe/Paris"),
                                      ("RE", "Station d'essai Bras-Creux (La Réunion)", "Commune fictive (974)", "Indian/Reunion")]:
        sites[cle] = G.post("/sites", {"nom": nom, "commune": commune, "fuseau_horaire": fuseau})
    J.note("4 sites créés, dont un en La Réunion (fuseau Indian/Reunion) pour exercer les fuseaux propres à chaque site.")
    sols = {
        "P01": {"texture": "limon argileux", "ph": 6.8, "mo_pct": 2.1, "profondeur_cm": 90, "ru_mm": 140, "source": "Analyse de terre fictive LAB-DEMO-2023-117", "date_analyse": "2023-03-14"},
        "P06": {"texture": "limon sableux", "ph": 6.4, "mo_pct": 1.8, "profondeur_cm": 70, "ru_mm": 95, "source": "Analyse de terre fictive LAB-DEMO-2024-044", "date_analyse": "2024-02-02"},
    }
    restrictions = {
        "P02": [{"type": "captage", "libelle": "Périmètre de protection rapprochée de captage (fictif)", "source": "Arrêté fictif n° DEMO-2019-12"}],
        "P04": [{"type": "cours_eau", "libelle": "Bordure de cours d'eau au nord : bande enherbée de 5 m maintenue", "source": "Constat exploitation"}],
    }
    parcelles = {}
    for code, nom, site, geom, srid, decl in PARCELLES + [R01]:
        d = {"site_id": sites[site]["id"], "code": code, "nom": nom, "surface_declaree_ha": decl,
             "source_surface_declaree": "Surface admissible déclarée (dossier fictif)",
             "mode_faire_valoir": "fermage" if code in ("P02", "P04") else "propriete",
             "proprietaire": "GFA fictif des Coteaux" if code in ("P02", "P04") else None,
             "bail_echeance": "2027-10-31" if code == "P02" else None,
             "acces": "Chemin rural n° 4, portail côté est" if code == "P01" else None,
             "sol": sols.get(code), "restrictions": restrictions.get(code, []), "irrigable": code in ("P06", "P07", "R01"),
             "geometrie": {"geojson": geom, "srid": srid, "source": "Relevé GNSS fictif" if srid == 2154 else "Dessin sur fond de plan (fictif)",
                           "methode": "relevé RTK" if srid == 2154 else "numérisation", "date_acquisition": "2025-06-12", "precision_m": 0.05 if srid == 2154 else 2.0}}
        parcelles[code] = G.post("/parcelles", d)
    p01 = parcelles["P01"]
    J.note(f"{len(parcelles)} parcelles créées ; P01 calculée à {n(p01['surface_calculee_ha'], 2)} ha pour {n(p01['surface_declaree_ha'], 2)} ha déclarés.")
    J.verifier(p01["ecart_surface"]["signale"] and p01["surface_declaree_ha"] == 12.10,
               "Écart de surface signalé sur P01 sans modification de la surface déclarée")
    J.verifier(parcelles["R01"]["provenance_geometrie"]["srid_origine"] == 4326 and p01["srid_origine"] == 2154,
               "Systèmes de coordonnées d'origine conservés (EPSG:2154 et EPSG:4326)")
    G.post(f"/parcelles/{p01['id']}/cadastre", {"code_insee": "00001", "section": "ZA", "numero": "0012", "surface_cadastrale_ha": 8.2, "surface_exploitee_ha": 8.2, "source": "Relevé de propriété fictif"})
    G.post(f"/parcelles/{p01['id']}/cadastre", {"code_insee": "00001", "section": "ZA", "numero": "0013", "surface_cadastrale_ha": 4.05, "surface_exploitee_ha": 3.95, "source": "Relevé de propriété fictif"})
    zone = G.post(f"/parcelles/{parcelles['P06']['id']}/zones", {"nom": "Zone de ressuyage lent", "nature": "temporaire", "motif": "Hydromorphie observée au printemps",
                                                                 "date_debut": "2026-03-01", "date_fin": "2026-06-30",
                                                                 "geometrie": {"geojson": {"type": "Polygon", "coordinates": [[[512600, 6689100], [512660, 6689100], [512660, 6689140], [512600, 6689140], [512600, 6689100]]]}, "srid": 2154, "source": "Observation terrain"}})
    J.note(f"Références cadastrales (distinctes de la limite opérationnelle) et zone temporaire « {zone['nom']} » ({n(zone['surface_calculee_ha'], 2)} ha) ajoutées.")
    hors = G.erreur(f"/parcelles/{parcelles['P07']['id']}/zones", {"nom": "Zone erronée", "geometrie": {"geojson": {"type": "Polygon", "coordinates": [[[512600, 6689100], [512660, 6689100], [512660, 6689140], [512600, 6689140], [512600, 6689100]]]}, "srid": 2154, "source": "test"}}, 422)
    J.verifier(hors["code"] == "zone_hors_parcelle", f"Zone hors parcelle refusée : « {hors['message']} »")
    eq_irr = G.post("/equipements-irrigation", {"parcelle_id": parcelles["P06"]["id"], "nom": "Enrouleur 90 mm", "type": "enrouleur", "debit_nominal": 35, "unite_debit": "m3/h",
                                                "efficience_pct": 75, "source_efficience": "Valeur indicative saisie par l'exploitant (fictive)", "compteur_numero": "CPT-DEMO-01", "point_prelevement": "Forage fictif F1"})

    # ------------------------------------------------------------------ référentiels
    fournisseurs = {n: G.post("/fournisseurs", {"nom": n, "type": t}) for n, t in [
        ("Coopérative fictive du Val", "cooperative"), ("Négoce Agri-Fictif", "fournisseur"), ("Semences Démo SA", "fournisseur"), ("ETA des Coteaux (fictive)", "prestataire")]}
    clients = {n: G.post("/clients", {"nom": n, "type": t}) for n, t in [
        ("Coopérative fictive du Val — collecte", "cooperative"), ("Épicerie fictive Le Panier", "professionnel"), ("Restaurant scolaire fictif", "professionnel")]}
    empl = {}
    for code, nom, site, type_, cout in [("MAG-01", "Magasin intrants", "VH", "magasin", None), ("PHY-01", "Local phytosanitaire", "VH", "local_phyto", None),
                                          ("CUV-01", "Cuve GNR 3 000 L", "VH", "cuve", None), ("CEL-01", "Cellule de stockage 1", "VH", "cellule", 1.20),
                                          ("CEL-02", "Cellule de stockage 2", "VH", "cellule", 1.20), ("FRI-01", "Chambre froide", "VB", "chambre_froide", 4.50),
                                          ("QUAI", "Quai de conditionnement", "VB", "quai", None), ("BERG", "Bergerie — aliments", "VL", "batiment", None)]:
        empl[code] = G.post("/emplacements", {"site_id": sites[site]["id"], "code": code, "nom": nom, "type": type_, "cout_stockage_eur_t_mois": cout,
                                              "source_cout_stockage": "Tarif interne fictif" if cout else None})
    # Référentiel réglementaire FICTIF
    from app.modules.intrants.models import ProduitReferentiel, SourceReferentiel, UsageReferentiel
    src = SourceReferentiel(nom="Référentiel de démonstration Terroir (FICTIF)", editeur="Terroir — jeu d'essai", version="demo-1",
                            date_effet=date(2025, 9, 1), importe_le=maintenant(), officielle=False, licence="Données fictives",
                            avertissement="Valeurs inventées pour la démonstration. Ne jamais les utiliser pour un traitement réel.")
    db.add(src)
    db.flush()
    pr = ProduitReferentiel(source_id=src.id, numero_amm="DEMO-0001", nom_commercial="Fongicide DEMO-F1 (fictif)", titulaire="Titulaire fictif",
                            etat_autorisation="Autorisé", substances=[{"nom": "substance fictive A"}])
    db.add(pr)
    db.flush()
    db.add(UsageReferentiel(produit_id=pr.id, culture="Blé tendre", cible="Maladies foliaires (démonstration)", dose_max=1.0, unite_dose="L/ha",
                            nombre_applications_max=2, delai_avant_recolte_jours=35, etat_usage="Autorisé (fictif)"))
    db.commit()
    arts = {}
    for code, lib, cat, u, regl, seuil, extra in [
        ("SEM-BT", "Semence blé tendre « Aubade » (variété fictive)", "semence", "kg", False, None, {}),
        ("SEM-PDT", "Plants de pommes de terre « Belle des Vallées » (fictive)", "semence", "kg", False, None, {}),
        ("ENG-AMMO", "Ammonitrate 27 %", "engrais", "kg", False, 1000, {}),
        ("ENG-NPK", "Engrais NPK 15-15-15", "engrais", "kg", False, None, {}),
        ("PHY-F1", "Fongicide DEMO-F1 (produit fictif)", "phytopharmaceutique", "L", True, None, {"produit_referentiel_id": str(pr.id), "numero_amm_saisi": "DEMO-0001"}),
        ("PHY-H2", "Herbicide DEMO-H2 (produit fictif, hors référentiel)", "phytopharmaceutique", "L", True, None, {}),
        ("GNR", "Gazole non routier", "carburant", "L", False, 500, {}),
        ("PIE-FH", "Filtre à huile tracteur", "piece_detachee", "u", False, 2, {}),
        ("ALI-AGN", "Aliment agneaux (granulés)", "aliment_animal", "kg", False, 200, {}),
        ("REC-BT", "Blé tendre récolté", "produit_recolte", "t", False, None, {"culture": "Blé tendre"}),
        ("REC-ORGE", "Orge d'hiver récoltée", "produit_recolte", "t", False, None, {"culture": "Orge d'hiver"}),
        ("REC-COLZA", "Colza récolté", "produit_recolte", "t", False, None, {"culture": "Colza"}),
        ("REC-PDT", "Pommes de terre de conservation (vrac)", "produit_recolte", "kg", False, None, {"culture": "Pomme de terre"}),
        ("EMB-SAC10", "Sac kraft 10 kg", "emballage", "u", False, 100, {}),
        ("PF-PDT10", "Pommes de terre — sac de 10 kg", "produit_fini", "u", False, None, {}),
    ]:
        arts[code] = G.post("/articles", {"code": code, "libelle": lib, "categorie": cat, "unite_stock": u, "reglemente": regl, "seuil_alerte": seuil} | extra)
    prix = [("SEM-BT", "achat", 0.62, "kg", "2025-07-01"), ("SEM-PDT", "achat", 0.55, "kg", "2026-01-01"), ("ENG-AMMO", "achat", 0.41, "kg", "2025-07-01"),
            ("ENG-AMMO", "achat", 0.46, "kg", "2026-02-01"), ("PHY-F1", "achat", 38.0, "L", "2025-07-01"), ("GNR", "achat", 0.98, "L", "2025-07-01"),
            ("GNR", "achat", 1.06, "L", "2026-03-01"), ("ALI-AGN", "achat", 0.39, "kg", "2025-07-01"), ("EMB-SAC10", "achat", 0.32, "u", "2025-07-01"),
            ("REC-BT", "valorisation", 205.0, "t", "2026-07-01"), ("REC-PDT", "valorisation", 0.28, "kg", "2026-09-01"), ("PF-PDT10", "valorisation", 6.5, "u", "2026-09-01"),
            ("ENG-NPK", "achat", 0.52, "kg", "2025-07-01")]
    for code, nat, p, u, du in prix:
        G.post("/prix", {"article_id": arts[code]["id"], "nature": nat, "prix_unitaire_eur": p, "unite": u, "valide_du": du, "source": "Barème fictif de démonstration"})
    J.note("Prix versionnés saisis (ex. ammonitrate v1 0,41 €/kg puis v2 0,46 €/kg au 01/02/2026).")
    for code, q, u, e_, cu in [("SEM-BT", 2400, "kg", "MAG-01", 0.62), ("ENG-AMMO", 800, "kg", "MAG-01", 0.41), ("PHY-F1", 20, "L", "PHY-01", 38.0),
                               ("GNR", 2600, "L", "CUV-01", 0.98), ("PIE-FH", 3, "u", "MAG-01", 18.0), ("ALI-AGN", 1200, "kg", "BERG", 0.39),
                               ("EMB-SAC10", 300, "u", "QUAI", 0.32), ("SEM-PDT", 4000, "kg", "MAG-01", 0.55), ("ENG-NPK", 1500, "kg", "MAG-01", 0.52)]:
        G.post("/stocks/entrees", {"article_id": arts[code]["id"], "emplacement_id": empl[e_]["id"], "quantite": q, "unite": u, "cout_unitaire": cu,
                                   "motif": "Stock d'ouverture (inventaire au 01/09/2025)", "date_peremption": "2027-06-30" if code == "PHY-F1" else None})
    # Équipe
    membres = {}
    for cle, prenom, nom, statut, fonction, entreprise in [
        ("claire", "Claire", "Martin", "associe", "Gérante", None), ("julien", "Julien", "Roche", "salarie", "Chef de culture", None),
        ("sofia", "Sofia", "Benali", "salarie", "Tractoriste", None), ("marc", "Marc", "Dubois", "salarie", "Berger", None),
        ("thomas", "Thomas", "Petit", "saisonnier", "Ouvrier agricole", None), ("eta", "Équipe", "ETA des Coteaux", "prestataire", "Récolte", "ETA des Coteaux (fictive)")]:
        membres[cle] = G.post("/membres", {"prenom": prenom, "nom": nom, "statut": statut, "fonction": fonction, "entreprise": entreprise})
    for cle, t, lib, ref, du, au in [("julien", "certiphyto_decideur", "Certiphyto décideur en entreprise soumise à agrément (fictif)", "DEMO-CP-0001", "2022-05-01", "2027-04-30"),
                                     ("sofia", "certiphyto_operateur", "Certiphyto opérateur (fictif)", "DEMO-CP-0002", "2023-09-01", "2028-08-31"),
                                     ("sofia", "conduite_tracteur", "Habilitation conduite d'engins", None, None, None)]:
        G.post(f"/membres/{membres[cle]['id']}/competences", {"type": t, "libelle": lib, "reference": ref, "valide_du": du, "valide_au": au})
    for cle, tarif in [("claire", 28), ("julien", 26), ("sofia", 22), ("marc", 22), ("thomas", 18), ("eta", 55)]:
        G.post("/tarifs", {"ressource_type": "membre", "ressource_id": membres[cle]["id"], "cout_horaire_eur": tarif, "valide_du": "2025-01-01", "source": "Coût employeur fictif"})
    # Matériel
    mats = {}
    for code, lib, cat, debit, conso, tarif, tele in [
        ("TR-01", "Tracteur 140 ch", "tracteur", None, 14, 32, "simulateur"), ("TR-02", "Tracteur 100 ch", "tracteur", None, 10, 24, None),
        ("PUL-01", "Pulvérisateur traîné 24 m", "pulverisateur", 6, None, 12, None), ("SEM-01", "Semoir à céréales 4 m", "semoir", 2.5, None, 10, None),
        ("EPA-01", "Distributeur d'engrais 24 m", "epandeur", 8, None, 6, None), ("MB-01", "Moissonneuse-batteuse (CUMA)", "moissonneuse", 2, 25, 95, None),
        ("PLT-01", "Planteuse 2 rangs", "outil_sol", 0.6, None, 15, None)]:
        mats[code] = G.post("/materiels", {"code": code, "libelle": lib, "categorie": cat, "marque": "Marque générique", "debit_chantier_ha_h": debit,
                                           "consommation_reference_l_h": conso, "site_id": sites["VH"]["id"], "source_telemetrie": tele,
                                           "propriete": "cuma" if code == "MB-01" else "propre"})
        G.post("/tarifs", {"ressource_type": "materiel", "ressource_id": mats[code]["id"], "cout_horaire_eur": tarif, "valide_du": "2025-01-01", "source": "Barème d'entraide fictif"})
    G.post(f"/materiels/{mats['PUL-01']['id']}/maintenances", {"type": "controle_reglementaire", "libelle": "Contrôle périodique du pulvérisateur et remplacement des buses",
                                                              "immobilise_du": h(date(2026, 4, 7), 8), "immobilise_au": h(date(2026, 4, 12), 18), "prestataire": "Atelier fictif"})
    J.note("Référentiels créés : 4 fournisseurs, 3 clients, 8 emplacements, 15 articles, 6 membres d'équipe, 7 matériels, référentiel phytopharmaceutique FICTIF.")
    historique(db, exp_id, parcelles, arts)
    J.note("Historique cultural 2022-2025 repris pour P01–P03 (rotations et rendements passés).")
    # Météo simulée (traitement en arrière-plan), avec des jours manquants volontaires
    trous = ["2026-02-20", "2026-08-05", "2026-08-06"]
    G.post(f"/taches/import_meteo", {"site_id": sites["VH"]["id"], "du": "2025-09-01", "au": "2026-12-12", "trous": trous})
    G.post(f"/taches/import_meteo", {"site_id": sites["VB"]["id"], "du": "2026-03-01", "au": "2026-12-12", "trous": trous})
    nb_taches = executer_en_attente()
    taches = G.get("/taches")
    J.verifier(nb_taches == 2 and all(t["statut"] == "terminee" for t in taches), f"{nb_taches} tâches d'import météo exécutées par le travailleur en arrière-plan")
    J.note(f"Données météo absentes volontairement les {', '.join(date.fromisoformat(x).strftime('%d/%m/%Y') for x in trous)}.")

    # ------------------------------------------------------------------ 2
    J.etape("Planification de la campagne 2025-2026")
    camp = G.post("/campagnes", {"libelle": "2025-2026", "date_debut": "2025-09-01", "date_fin": "2026-08-31", "statut": "en_cours"})
    G.post("/regles-rotation", {"libelle": "Délai de retour de l'orge d'hiver : 2 campagnes", "type": "delai_retour_culture", "culture": "Orge d'hiver", "delai_min_campagnes": 2, "source": "Choix agronomique de l'exploitation"})
    r_bt = G.post("/regles-rotation", {"libelle": "Pas de blé tendre deux campagnes de suite", "type": "delai_retour_culture", "culture": "Blé tendre", "delai_min_campagnes": 2, "source": "Choix agronomique de l'exploitation"})
    CO.post(f"/regles-rotation/{r_bt['id']}/validation", {"qualification": "Conseillère agronomique (qualification fictive)"})
    cycles = {}
    for code, culture, famille, variete, module, semis, rec_d, rec_f, rdt, dest in [
        ("P01", "Blé tendre", "Poacées", "Aubade (fictive)", "grandes_cultures", "2025-10-15", "2026-07-10", "2026-07-25", 7.8, "Collecte coopérative"),
        ("P02", "Colza", "Brassicacées", "Variété fictive C1", "grandes_cultures", "2025-08-28", "2026-07-01", "2026-07-10", 3.5, "Collecte coopérative"),
        ("P03", "Orge d'hiver", "Poacées", "Variété fictive O2", "grandes_cultures", "2025-10-10", "2026-06-25", "2026-07-05", 7.0, "Collecte coopérative"),
        ("P05", "Prairie permanente", "Prairie", None, "polyculture_elevage", None, None, None, None, "Pâturage ovin"),
        ("P06", "Pomme de terre", "Solanacées", "Belle des Vallées (fictive)", "maraichage", "2026-04-10", "2026-09-10", "2026-09-20", 28, "Vente directe et restauration"),
        ("P08", "Pommier", "Rosacées", "Variété fictive", "vergers_viticulture", None, "2026-09-15", "2026-10-15", None, "Vente directe")]:
        cycles[code] = CH.post("/cycles", {"campagne_id": camp["id"], "parcelle_id": parcelles[code]["id"], "culture": culture, "famille_botanique": famille,
                                           "variete": variete, "module": module, "surface_prevue_ha": parcelles[code]["surface_calculee_ha"],
                                           "date_semis_prevue": semis, "date_recolte_debut_prevue": rec_d, "date_recolte_fin_prevue": rec_f,
                                           "rendement_previsionnel": rdt, "unite_rendement": "t/ha",
                                           "source_rendement_previsionnel": "Moyenne de l'exploitation ajustée (prévision)" if rdt else None, "destination_prevue": dest})
    iti = CH.post("/itineraires", {"libelle": "Blé tendre d'hiver — itinéraire de l'exploitation (doses saisies, fictives)", "culture": "Blé tendre",
                                  "source": "Saisi par le chef de culture — non validé comme recommandation", "redige_par": "Julien Roche",
                                  "etapes": [
                                      {"type": "travail_sol", "libelle": "Déchaumage", "decalage_jours": -10, "duree_h_par_ha": 0.5},
                                      {"type": "semis", "libelle": "Semis combiné", "decalage_jours": 0, "duree_h_par_ha": 0.4, "produits": [{"article_code": "SEM-BT", "dose": 160, "unite_dose": "kg/ha"}]},
                                      {"type": "fertilisation", "libelle": "Apport d'azote — sortie d'hiver", "decalage_jours": 128, "duree_h_par_ha": 0.15, "produits": [{"article_code": "ENG-AMMO", "dose": 150, "unite_dose": "kg/ha"}]},
                                      {"type": "traitement_phyto", "libelle": "Protection fongicide (produit fictif)", "decalage_jours": 177, "duree_h_par_ha": 0.2, "competence_requise": "certiphyto", "produits": [{"article_code": "PHY-F1", "dose": 0.8, "unite_dose": "L/ha"}]},
                                      {"type": "recolte", "libelle": "Moisson", "decalage_jours": 268, "duree_h_par_ha": 0.5}]})
    gen = CH.post(f"/cycles/{cycles['P01']['id']}/itineraire/{iti['id']}")
    J.note(f"6 cycles planifiés (grandes cultures, maraîchage, prairie, verger) ; itinéraire appliqué à P01 : {', '.join(gen['interventions_creees'])}.")
    rot = CH.get("/rotations")
    alertes = [a for pr_ in rot["parcelles"] for cas in pr_["campagnes"].values() for c in cas for a in c["alertes"]]
    J.verifier(any("orge" in a["libelle"].lower() and not a["validee"] for a in alertes),
               "Rotation : P03 (orge sur orge) signalée, règle affichée « non validée par un professionnel »")
    J.note(f"Indicateur de rotation : {n(rot['indicateur']['valeur_pct'], 1)} % — {rot['indicateur']['avertissement']}")

    # ------------------------------------------------------------------ 3
    J.etape("Calcul des besoins et rupture de stock")
    b = CH.get(f"/campagnes/{camp['id']}/besoins")
    ammo = next(x for x in b["intrants"] if x["code"] == "ENG-AMMO")
    J.note(f"Ammonitrate : besoin {n(ammo['besoin'], 0)} kg, disponible {n(ammo['disponible'], 0)} kg, manque {n(ammo['manque'], 0)} kg.")
    J.verifier(ammo["statut"] == "rupture", "Rupture de stock prévisionnelle détectée sur l'ammonitrate")
    its = CH.get("/interventions", cycle_id=cycles["P01"]["id"])
    it_ferti = next(i for i in its if i["type"] == "fertilisation")
    res = CH.post(f"/interventions/{it_ferti['id']}/reservations")
    J.verifier(res["ruptures"] and res["ruptures"][0]["statut"] == "rupture", f"Réservation refusée faute de stock : « {res['ruptures'][0]['message']} »")
    da = CH.post("/demandes-achat", {"motif": "Couverture du besoin d'azote (calcul de campagne)", "origine": "calcul_besoins",
                                     "lines" if False else "lignes": [{"article_id": ammo["article_id"], "quantite": 1200, "unite": "kg", "date_besoin": "2026-02-15"}]})
    G.post(f"/demandes-achat/{da['id']}/approbation")
    cf = G.post("/commandes-fournisseurs", {"fournisseur_id": fournisseurs["Coopérative fictive du Val"]["id"], "demande_id": da["id"], "date_commande": "2026-01-20",
                                            "date_livraison_prevue": "2026-02-05", "lignes": [{"article_id": ammo["article_id"], "quantite": 1.2, "unite": "t", "prix_unitaire_eur": 455.0}]})
    st = CH.get("/stocks")
    a_ammo = next(x for x in st["articles"] if x["code"] == "ENG-AMMO")
    J.verifier(a_ammo["attendu"] == 1200, f"Demande d'achat {da['numero']} → commande {cf['numero']} : 1 200 kg « attendus » (physique {n(a_ammo['physique'], 0)} kg)")

    # ------------------------------------------------------------------ 4
    J.etape("Réception des fournitures")
    ligne = cf["lignes"][0]
    rec = G.post(f"/commandes-fournisseurs/{cf['id']}/receptions", {"date_reception": h(date(2026, 2, 4), 10), "bon_livraison": "BL-DEMO-5521",
                                                                    "lignes": [{"ligne_commande_id": ligne["id"], "quantite": 1200, "unite": "kg", "emplacement_id": empl["MAG-01"]["id"], "numero_lot_fournisseur": "COOP-AMMO-26-118"}]})
    G.post("/factures-fournisseurs", {"fournisseur_id": fournisseurs["Coopérative fictive du Val"]["id"], "commande_id": cf["id"], "numero_fournisseur": "FV-2026-00871",
                                      "date_facture": "2026-02-05", "montant_ht_eur": 546.0, "montant_tva_eur": 109.2, "categorie_charge": "intrants", "date_paiement": "2026-03-05"})
    J.verifier(rec["statut_commande"] == "recue", f"Réception {rec['lignes'][0]['lot']} enregistrée (lot fournisseur COOP-AMMO-26-118) ; commande soldée ; facture FV-2026-00871 référencée")
    res = CH.post(f"/interventions/{it_ferti['id']}/reservations")
    J.verifier(not res["ruptures"], "Réservation de l'ammonitrate désormais possible")

    # ------------------------------------------------------------------ 5
    J.etape("Affectation du matériel et des personnes")
    it_semis = next(i for i in its if i["type"] == "semis")
    it_phyto = next(i for i in its if i["type"] == "traitement_phyto")
    it_rec = next(i for i in its if i["type"] == "recolte")
    it_sol = next(i for i in its if i["type"] == "travail_sol")
    CH.post(f"/interventions/{it_ferti['id']}/affectations", {"ressource_type": "materiel", "ressource_id": mats["TR-01"]["id"], "debut": h(date(2026, 2, 20), 8), "fin": h(date(2026, 2, 20), 11)})
    CH.post(f"/interventions/{it_ferti['id']}/affectations", {"ressource_type": "materiel", "ressource_id": mats["EPA-01"]["id"], "debut": h(date(2026, 2, 20), 8), "fin": h(date(2026, 2, 20), 11)})
    CH.post(f"/interventions/{it_ferti['id']}/affectations", {"ressource_type": "membre", "ressource_id": membres["sofia"]["id"], "debut": h(date(2026, 2, 20), 8), "fin": h(date(2026, 2, 20), 11)})
    # Intervention concurrente sur P02 qui veut le même tracteur
    it_p02 = CH.post("/interventions", {"parcelle_id": parcelles["P02"]["id"], "cycle_id": cycles["P02"]["id"], "type": "fertilisation", "libelle": "Apport NPK colza",
                                        "date_prevue": "2026-02-20", "produits": [{"article_id": arts["ENG-NPK"]["id"], "dose_prevue": 120, "unite_dose": "kg/ha"}]})
    err = CH.erreur(f"/interventions/{it_p02['id']}/affectations", {"ressource_type": "materiel", "ressource_id": mats["TR-01"]["id"], "debut": h(date(2026, 2, 20), 10), "fin": h(date(2026, 2, 20), 12)}, 409)
    J.verifier(err["code"] == "conflit_affectation", f"Double affectation refusée : « {err['message']} »")
    err = CH.erreur(f"/interventions/{it_phyto['id']}/affectations", {"ressource_type": "materiel", "ressource_id": mats["PUL-01"]["id"], "debut": h(date(2026, 4, 10), 8), "fin": h(date(2026, 4, 10), 12)}, 409)
    J.verifier(err["code"] == "materiel_indisponible", f"Machine indisponible : « {err['message']} »")
    err = CH.erreur(f"/interventions/{it_phyto['id']}/affectations", {"ressource_type": "membre", "ressource_id": membres["thomas"]["id"], "debut": h(date(2026, 4, 14), 8), "fin": h(date(2026, 4, 14), 12)}, 409)
    J.verifier(err["code"] == "competence_manquante", f"Compétence contrôlée : « {err['message']} »")
    CH.post(f"/interventions/{it_phyto['id']}/affectations", {"ressource_type": "materiel", "ressource_id": mats["PUL-01"]["id"], "debut": h(date(2026, 4, 14), 8), "fin": h(date(2026, 4, 14), 12)})
    CH.post(f"/interventions/{it_phyto['id']}/affectations", {"ressource_type": "materiel", "ressource_id": mats["TR-01"]["id"], "debut": h(date(2026, 4, 14), 8), "fin": h(date(2026, 4, 14), 12)})
    CH.post(f"/interventions/{it_phyto['id']}/affectations", {"ressource_type": "membre", "ressource_id": membres["sofia"]["id"], "debut": h(date(2026, 4, 14), 8), "fin": h(date(2026, 4, 14), 12)})
    J.note("Traitement fongicide replanifié au 14/04/2026, après l'immobilisation du pulvérisateur (07–12/04/2026), avec une opératrice titulaire du Certiphyto.")
    pl = CH.get("/planning", du="2026-04-01", au="2026-04-30")
    J.verifier(any(r["materiel"] == "Pulvérisateur traîné 24 m" for r in pl["restrictions_materiel"]), "Restriction de maintenance visible dans le planning d'avril")

    # ------------------------------------------------------------------ 6
    J.etape("Enregistrement des interventions")
    for it_, jour, mat, h_deb, h_fin, quant in [(it_sol, date(2025, 10, 5), "TR-01", 8, 15, None), (it_semis, date(2025, 10, 15), "TR-01", 8, 14, 1985)]:
        CH.post(f"/interventions/{it_['id']}/affectations", {"ressource_type": "materiel", "ressource_id": mats[mat]["id"], "debut": h(jour, h_deb), "fin": h(jour, h_fin)})
        if it_["type"] == "semis":
            CH.post(f"/interventions/{it_['id']}/affectations", {"ressource_type": "materiel", "ressource_id": mats["SEM-01"]["id"], "debut": h(jour, h_deb), "fin": h(jour, h_fin)})
        d_it = CH.get(f"/interventions/{it_['id']}")
        CH.post(f"/interventions/{it_['id']}/realisation", {"debut_reel": h(jour, h_deb), "fin_reelle": h(jour, h_fin), "surface_realisee_ha": parcelles["P01"]["surface_calculee_ha"],
                                                            "produits": [{"intervention_produit_id": p["id"], "quantite_mesuree": quant, "methode_mesure": "pesee"} for p in d_it["produits"]],
                                                            "temps": [{"membre_id": membres["sofia"]["id"], "heures": h_fin - h_deb}]})
    d_f = CH.get(f"/interventions/{it_ferti['id']}")
    J.verifier(d_f["meteo_disponible"]["nature"] == "indisponible", "Météo manquante le 20/02/2026 : signalée « indisponible », sans valeur inventée")
    surf = parcelles["P01"]["surface_calculee_ha"]
    cr = CH.post(f"/interventions/{it_ferti['id']}/realisation", {
        "version": d_f["version"], "debut_reel": h(date(2026, 2, 20), 8, 15), "fin_reelle": h(date(2026, 2, 20), 10, 40), "surface_realisee_ha": surf,
        "produits": [{"intervention_produit_id": d_f["produits"][0]["id"], "quantite_mesuree": 1842, "methode_mesure": "pesee",
                      "consigne_machine": 150, "unite_consigne": "kg/ha", "source_consigne": "saisie"}],
        "temps": [{"membre_id": membres["sofia"]["id"], "heures": 2.5}], "heures_materiel": [{"materiel_id": mats["TR-01"]["id"], "heures_moteur_fin": 3412.5, "source": "telemetrie_simulee"}],
        "meteo_saisie": {"conditions": "Ciel couvert, sol ressuyé, vent faible (constat de l'opératrice)"}, "notes": "Trémie pesée avant et après."})
    p_ = cr["produits"][0]
    J.verifier(p_["quantite_prevue"] != p_["quantite_mesuree"] and p_["consigne_machine"] == 150,
               f"Prévu {n(p_['quantite_prevue'], 0)} kg / consigne machine {n(p_['consigne_machine'], 0)} kg/ha / mesuré {n(p_['quantite_mesuree'], 0)} kg : trois valeurs distinctes conservées")
    # Phytopharmaceutique : vérification et validation professionnelle
    err = CH.erreur(f"/interventions/{it_phyto['id']}/demarrage", None, 409)
    J.verifier("validation professionnelle" in err["message"], "Démarrage du traitement bloqué tant qu'aucune validation professionnelle n'est enregistrée")
    v = CH.post(f"/interventions/{it_phyto['id']}/verification")
    J.note(f"Vérification : {len(v['controles'])} contrôles, {v['nombre_alertes']} alerte(s), {v['nombre_non_disponibles']} non disponible(s), "
           f"{len(v['controles_non_couverts'])} contrôles déclarés non couverts. Source : {v['sources'][0]['nom']}.")
    J.verifier(all(c["statut"] != "alerte" for c in v["controles"]) and v["sources"][0]["officielle"] is False,
               "Contrôles couverts conformes à la source fictive ; source signalée comme non officielle")
    CO.post(f"/interventions/{it_phyto['id']}/validation-professionnelle", {"decision": "validee", "qualification": "Conseillère — Certiphyto conseil (fictif)",
                                                                           "commentaire": "Validé pour la démonstration (référentiel fictif)."})
    d_p = OP.get(f"/interventions/{it_phyto['id']}")
    OP.post(f"/interventions/{it_phyto['id']}/demarrage")
    cr_p = OP.post(f"/interventions/{it_phyto['id']}/realisation", {
        "debut_reel": h(date(2026, 4, 14), 8, 30), "fin_reelle": h(date(2026, 4, 14), 10, 45), "surface_realisee_ha": surf,
        "produits": [{"intervention_produit_id": d_p["produits"][0]["id"], "quantite_mesuree": 9.7, "methode_mesure": "jauge", "consigne_machine": 0.8, "unite_consigne": "L/ha", "source_consigne": "saisie"}],
        "temps": [{"membre_id": membres["sofia"]["id"], "heures": 2.25}]})
    J.verifier(cr_p["statut"] == "realisee" and "preuve de conformité" in cr_p["verification_reglementaire"]["avertissement"],
               "Traitement enregistré ; l'avertissement « pas une preuve de conformité » accompagne le registre")
    # Plein de carburant
    OP.post(f"/materiels/{mats['TR-01']['id']}/pleins", {"litres": 180, "article_carburant_id": arts["GNR"]["id"], "heures_compteur": 3415, "horodatage": h(date(2026, 4, 14), 11), "intervention_id": it_phyto["id"]})

    # ------------------------------------------------------------------ 7
    J.etape("Synchronisation d'une observation saisie hors connexion")
    obs_id = str(uuid.uuid4())
    photo = base64.b64encode(b"\xff\xd8\xff\xe0" + b"photo-de-demonstration" * 10).decode()
    lot_sync = {"terminal_id": "tablette-sofia", "operations": [
        {"id": str(uuid.uuid4()), "type": "observation", "entite_id": obs_id, "saisi_le": h(date(2026, 5, 6), 7, 42),
         "contenu": {"parcelle_id": parcelles["P01"]["id"], "cycle_id": cycles["P01"]["id"], "categorie": "maladie", "stade": "Dernière feuille étalée",
                     "description": "Taches sur F3, faible fréquence (observation hors connexion)", "intensite": "faible"}},
        {"id": str(uuid.uuid4()), "type": "photo", "saisi_le": h(date(2026, 5, 6), 7, 43),
         "contenu": {"nom_fichier": "p01-f3.jpg", "titre": "Feuille F3 — P01", "donnees_base64": photo, "entite_type": "observation_culturale", "entite_id": obs_id}},
    ]}
    r1 = OP.post("/sync/envoi", lot_sync)
    r2 = OP.post("/sync/envoi", lot_sync)
    J.verifier(all(x["statut"] == "acceptee" for x in r1["resultats"]) and all(x["doublon"] for x in r2["resultats"]),
               "Observation et photo synchronisées ; un second envoi identique est sans effet (identifiants stables)")
    # Conflit : modification serveur puis modification terrain sur une version périmée
    db.expire_all()
    from app.modules.terrain.models import ObservationCulturale
    o = db.get(ObservationCulturale, uuid.UUID(obs_id))
    version_terminal = o.version
    o.description += " — confirmé au bureau : septoriose probable (à confirmer)"
    o.version += 1
    db.commit()
    r3 = OP.post("/sync/envoi", {"terminal_id": "tablette-sofia", "operations": [
        {"id": str(uuid.uuid4()), "type": "modification_observation", "entite_id": obs_id, "version_base": version_terminal, "saisi_le": h(date(2026, 5, 6), 9, 10),
         "contenu": {"intensite": "moyenne", "description": "Taches sur F3 et F2, fréquence moyenne"}}]})
    J.verifier(r3["resultats"][0]["statut"] == "conflit", f"Conflit de synchronisation détecté : « {r3['resultats'][0]['message']} »")
    conflit = CH.get("/sync/conflits")[0]
    CH.post(f"/sync/conflits/{conflit['id']}/resolution", {"resolution": "fusion", "valeurs_fusion": {
        "intensite": "moyenne", "description": "Taches sur F3 et F2, fréquence moyenne — septoriose probable, à confirmer par un conseiller"}})
    J.note(f"Conflit résolu par fusion explicite (champs en conflit : {', '.join(conflit['champs_en_conflit'])}).")
    # Compte rendu proposé hors connexion : en attente de validation serveur
    it_irr = CH.post("/interventions", {"parcelle_id": parcelles["P06"]["id"], "cycle_id": cycles["P06"]["id"], "type": "plantation", "libelle": "Plantation pommes de terre",
                                        "date_prevue": "2026-04-10", "produits": [{"article_id": arts["SEM-PDT"]["id"], "dose_prevue": 2000, "unite_dose": "kg/ha"}]})
    r4 = OP.post("/sync/envoi", {"terminal_id": "tablette-sofia", "operations": [
        {"id": str(uuid.uuid4()), "type": "compte_rendu", "entite_id": it_irr["id"], "saisi_le": h(date(2026, 4, 10), 18),
         "contenu": {"debut_reel": h(date(2026, 4, 10), 8), "fin_reelle": h(date(2026, 4, 10), 16), "surface_realisee_ha": parcelles["P06"]["surface_calculee_ha"],
                     "produits": [{"intervention_produit_id": it_irr["produits"][0]["id"], "quantite_mesuree": 3550, "methode_mesure": "pesee"}],
                     "temps": [{"membre_id": membres["sofia"]["id"], "heures": 8}, {"membre_id": membres["thomas"]["id"], "heures": 8}]}}]})
    stock_avant = next(x for x in CH.get("/stocks")["articles"] if x["code"] == "SEM-PDT")["physique"]
    J.verifier(r4["resultats"][0]["statut"] == "en_attente_validation" and stock_avant == 4000,
               "Compte rendu terrain mis en attente : aucun stock consommé avant validation serveur")
    CH.post(f"/sync/operations/{r4['resultats'][0]['id']}/validation")
    stock_apres = next(x for x in CH.get("/stocks")["articles"] if x["code"] == "SEM-PDT")["physique"]
    J.verifier(stock_apres == 450, f"Après validation par le chef de culture : stock de plants {n(stock_avant, 0)} → {n(stock_apres, 0)} kg")

    # ------------------------------------------------------------------ 8
    J.etape("Création d'un lot récolté")
    from app.adapters.registre import adaptateur
    pesee = adaptateur("balance").peser(98000, "demo-bt-p01")
    CH.post(f"/interventions/{it_rec['id']}/affectations", {"ressource_type": "materiel", "ressource_id": mats["MB-01"]["id"], "debut": h(date(2026, 7, 16), 9), "fin": h(date(2026, 7, 16), 16)})
    d_r = CH.get(f"/interventions/{it_rec['id']}")
    CH.post(f"/interventions/{it_rec['id']}/realisation", {"debut_reel": h(date(2026, 7, 16), 9), "fin_reelle": h(date(2026, 7, 16), 16), "surface_realisee_ha": surf,
                                                         "temps": [{"membre_id": membres["eta"]["id"], "heures": 7}, {"membre_id": membres["julien"]["id"], "heures": 7}]})
    recolte = CH.post("/recoltes", {"intervention_id": it_rec["id"], "article_id": arts["REC-BT"]["id"], "quantite": pesee["net_kg"], "unite": "kg",
                                    "emplacement_id": empl["CEL-01"]["id"], "date_recolte": "2026-07-16", "numero": "BT-2026-P01",
                                    "qualite_observee": {"humidite_pct": 14.6, "poids_specifique_kg_hl": 77.5, "proteines_pct": 11.4, "mesure_par": "Analyseur fictif de la coopérative", "pesee": pesee}})
    lot_bt = recolte["lot"]
    J.verifier(lot_bt["parcelle_id"] == parcelles["P01"]["id"] and lot_bt["apte_vente"] is False and lot_bt["statut"] == "en_attente_controle",
               f"Lot {lot_bt['numero']} : {n(lot_bt['quantite_initiale'], 3)} t (pont-bascule simulé), rattaché à P01, en attente de contrôle, non apte à la vente par défaut")
    # Pommes de terre : récolte, classement, pertes, conditionnement
    it_pdt = CH.post("/interventions", {"parcelle_id": parcelles["P06"]["id"], "cycle_id": cycles["P06"]["id"], "type": "recolte", "libelle": "Arrachage", "date_prevue": "2026-09-14"})
    CH.post(f"/interventions/{it_pdt['id']}/realisation", {"debut_reel": h(date(2026, 9, 14), 8), "fin_reelle": h(date(2026, 9, 14), 17), "temps": [{"membre_id": membres["thomas"]["id"], "heures": 9}]})
    lot_pdt = CH.post("/recoltes", {"intervention_id": it_pdt["id"], "article_id": arts["REC-PDT"]["id"], "quantite": 51.6, "unite": "t", "emplacement_id": empl["FRI-01"]["id"],
                                    "date_recolte": "2026-09-14", "numero": "PDT-2026-P06", "statut": "libre", "qualite_observee": {"calibre": "35-75 mm", "notes": "Quelques coups de pioche"}})["lot"]
    enfants = CH.post(f"/lots/{lot_pdt['id']}/division", {"emplacement_source_id": empl["FRI-01"]["id"], "type": "classement", "parts": [
        {"quantite": 44000, "unite": "kg", "classement": "Calibre 40-70 mm", "numero": "PDT-2026-P06-A"},
        {"quantite": 5600, "unite": "kg", "classement": "Déclassé (transformation)", "numero": "PDT-2026-P06-B"},
        {"quantite": 2000, "unite": "kg", "perte": True, "motif": "Tri : tubercules blessés ou verts"}]})
    J.note(f"Classement du lot PDT-2026-P06 : {', '.join(e['numero'] + ' (' + e['classement'] + ')' for e in enfants)} + 2 000 kg de pertes au tri.")

    # ------------------------------------------------------------------ 9
    J.etape("Mise en stockage et surveillance")
    for jour, t_, hr, hp in [(date(2026, 7, 20), 22.5, 61, 14.6), (date(2026, 8, 20), 17.8, 58, 14.3), (date(2026, 10, 20), 11.2, 64, 14.2)]:
        CH.post("/observations-stockage", {"emplacement_id": empl["CEL-01"]["id"], "lot_id": lot_bt["id"], "horodatage": h(jour, 9), "temperature_c": t_,
                                           "humidite_relative_pct": hr, "humidite_produit_pct": hp, "qualite": "Odeur saine, pas d'insectes observés", "source": "saisie"})
    lots = CH.get("/lots", article_id=arts["REC-BT"]["id"])
    J.verifier(next(l for l in lots if l["id"] == lot_bt["id"])["apte_vente"] is False, "Les relevés de conservation ne rendent pas le lot apte à la vente automatiquement")
    err = OP.erreur(f"/lots/{lot_bt['id']}/decision-vente", {"apte_vente": True, "motif": "test"}, 403)
    J.verifier(err["code"] == "acces_refuse", "Une opératrice ne peut pas déclarer un lot apte à la vente (permission stocks:liberer)")
    G.post(f"/lots/{lot_bt['id']}/statut", {"statut": "libre", "motif": "Analyses de la coopérative reçues (fictives)"})
    G.post(f"/lots/{lot_bt['id']}/decision-vente", {"apte_vente": True, "motif": "Humidité 14,2 %, PS 77,5 — conforme au cahier des charges client (fictif)"})
    J.note("La gérante libère le lot et le déclare apte à la vente, avec motif et horodatage (journal d'audit).")
    # Regroupement : orge P03 + reliquat d'orge 2025 (lot d'inventaire)
    it_o = next(i for i in CH.get("/interventions", cycle_id=cycles["P03"]["id"]) if i["type"] == "recolte") if any(
        i["type"] == "recolte" for i in CH.get("/interventions", cycle_id=cycles["P03"]["id"])) else CH.post("/interventions", {
        "parcelle_id": parcelles["P03"]["id"], "cycle_id": cycles["P03"]["id"], "type": "recolte", "libelle": "Moisson orge", "date_prevue": "2026-06-30"})
    CH.post(f"/interventions/{it_o['id']}/realisation", {"debut_reel": h(date(2026, 6, 30), 10), "fin_reelle": h(date(2026, 6, 30), 15)})
    lot_o = CH.post("/recoltes", {"intervention_id": it_o["id"], "article_id": arts["REC-ORGE"]["id"], "quantite": 49.8, "unite": "t", "emplacement_id": empl["CEL-02"]["id"],
                                  "date_recolte": "2026-06-30", "numero": "OR-2026-P03", "statut": "libre", "qualite_observee": {"humidite_pct": 13.9}})["lot"]
    reliquat = G.post("/stocks/entrees", {"article_id": arts["REC-ORGE"]["id"], "emplacement_id": empl["CEL-02"]["id"], "quantite": 6.0, "unite": "t",
                                          "motif": "Reliquat d'orge 2025 retrouvé à l'inventaire (origine non documentée)"})["lot"]
    regroupe = CH.post("/lots/regroupement", {"emplacement_id": empl["CEL-02"]["id"], "numero": "OR-2026-MELANGE", "sources": [
        {"lot_id": lot_o["id"], "emplacement_id": empl["CEL-02"]["id"], "quantite": 49.8, "unite": "t"},
        {"lot_id": reliquat["id"], "emplacement_id": empl["CEL-02"]["id"], "quantite": 6.0, "unite": "t"}]})
    t_reg = CH.get(f"/tracabilite/lots/{regroupe['id']}")
    J.verifier(len(t_reg["ascendants"]) == 2 and not t_reg["complete_jusqua_parcelle"],
               f"Regroupement {regroupe['numero']} : 2 parents conservés ; traçabilité déclarée incomplète (« {t_reg['conclusion']} »)")

    # ------------------------------------------------------------------ 10
    J.etape("Expédition partielle")
    cc = G.post("/commandes-clients", {"client_id": clients["Coopérative fictive du Val — collecte"]["id"], "date_commande": "2026-10-28",
                                       "lignes": [{"article_id": arts["REC-BT"]["id"], "quantite": 60, "unite": "t", "prix_unitaire_eur": 212.0}]})
    cc = G.post(f"/commandes-clients/{cc['id']}/allocations", {"lignes": [{"ligne_id": cc["lignes"][0]["id"], "lot_id": lot_bt["id"], "emplacement_id": empl["CEL-01"]["id"], "quantite": 60}]})
    alloc = cc["lignes"][0]["allocations"][0]
    ex = G.post(f"/commandes-clients/{cc['id']}/expeditions", {"lignes": [{"allocation_id": alloc["id"], "quantite": 30}], "transporteur": "Transports fictifs Moreau", "horodatage": h(date(2026, 11, 5), 7, 30)})
    J.verifier(ex["statut_commande"] == "partiellement_expediee", f"Expédition {ex['numero']} : 30 t sur 60 t commandées (commande partiellement expédiée)")
    st_bt = next(x for x in G.get("/stocks")["articles"] if x["code"] == "REC-BT")
    J.note(f"Blé tendre : physique {n(st_bt['physique'], 3)} t, réservé {n(st_bt['reserve'], 3)} t, disponible {n(st_bt['disponible'], 3)} t.")
    fac = CP.post(f"/commandes-clients/{cc['id']}/factures", {"date_facture": "2026-11-06", "taux_tva_pct": 5.5})
    CP.post(f"/factures/{fac['id']}/paiements", {"date_paiement": "2026-11-20", "montant_eur": fac["montant_ttc_eur"], "mode": "virement", "reference": "VIR-DEMO-778"})
    J.note(f"Facture {fac['numero']} : {eur(fac['montant_ht_eur'])} HT (TVA saisie 5,5 %) ; paiement enregistré le 20/11/2026.")
    # Pommes de terre : conditionnement et vente directe
    sacs = CH.post(f"/lots/{enfants[0]['id']}/conditionnement", {"emplacement_source_id": empl["FRI-01"]["id"], "quantite_source": 2000, "unite_source": "kg",
                                                                  "article_fini_id": arts["PF-PDT10"]["id"], "nombre_unites": 200, "emplacement_destination_id": empl["QUAI"]["id"],
                                                                  "emballage_article_id": arts["EMB-SAC10"]["id"], "numero": "PF-PDT10-2026-01"})
    G.post(f"/lots/{sacs['id']}/statut", {"statut": "libre", "motif": "Contrôle visuel conforme"})
    G.post(f"/lots/{sacs['id']}/decision-vente", {"apte_vente": True, "motif": "Contrôle visuel et étiquetage conformes"})
    cc2 = G.post("/commandes-clients", {"client_id": clients["Épicerie fictive Le Panier"]["id"], "date_commande": "2026-11-10",
                                        "lignes": [{"article_id": arts["PF-PDT10"]["id"], "quantite": 120, "unite": "u", "prix_unitaire_eur": 7.9}]})
    cc2 = G.post(f"/commandes-clients/{cc2['id']}/allocations", {"lignes": [{"ligne_id": cc2["lignes"][0]["id"], "lot_id": sacs["id"], "emplacement_id": empl["QUAI"]["id"], "quantite": 120}]})
    ex2 = G.post(f"/commandes-clients/{cc2['id']}/expeditions", {"lignes": [{"allocation_id": cc2["lignes"][0]["allocations"][0]["id"], "quantite": 80}], "horodatage": h(date(2026, 11, 12), 9)})
    J.note(f"Conditionnement de 2 000 kg en 200 sacs ({sacs['numero']}, 200 sacs kraft consommés) ; expédition {ex2['numero']} de 80 sacs sur 120.")

    # ------------------------------------------------------------------ 11
    J.etape("Traçabilité jusqu'à la parcelle")
    t_ex = G.get(f"/tracabilite/expeditions/{ex['id']}")
    t_lot = t_ex["lots"][0]
    J.verifier(t_lot["complete_jusqua_parcelle"] and t_lot["parcelles_origine"][0]["code"] == "P01",
               f"Expédition {ex['numero']} → lot {t_lot['lot']['numero']} → stockage {', '.join(t_lot['lot']['emplacements_historiques'])} → parcelle {t_lot['parcelles_origine'][0]['code']} ({t_lot['parcelles_origine'][0]['nom']})")
    t_ex2 = G.get(f"/tracabilite/expeditions/{ex2['id']}")["lots"][0]
    chaine = " ← ".join(a["numero"] for a in sorted(t_ex2["ascendants"], key=lambda x: -len(x["numero"])))
    J.verifier(t_ex2["complete_jusqua_parcelle"] and t_ex2["parcelles_origine"][0]["code"] == "P06",
               f"Sacs {t_ex2['lot']['numero']} ← {chaine} ← parcelle P06 (conditionnement et classement conservés)")

    # ------------------------------------------------------------------ 12
    J.etape("Activité d'élevage (démonstration ovine)")
    lot_br = EL.post("/lots-animaux", {"code": "OV-BR", "nom": "Brebis Vallée du Lys", "espece": "ovin", "finalite": "reproduction"})
    lot_ag = EL.post("/lots-animaux", {"code": "OV-AG26", "nom": "Agneaux 2026", "espece": "ovin", "finalite": "engraissement"})
    meres = []
    for i in range(1, 13):
        meres.append(EL.post("/animaux", {"identifiant": f"DEMO-OV-{i:04d}", "espece": "ovin", "race": "Race fictive", "sexe": "F", "date_naissance": f"{2020 + i % 4}-03-0{1 + i % 8}",
                                          "origine": "achat" if i <= 4 else "naissance", "date_entree": "2024-09-15", "lot_animaux_id": lot_br["id"]}))
    agneaux = []
    for i in range(1, 9):
        agneaux.append(EL.post("/animaux", {"identifiant": f"DEMO-OV-1{i:03d}", "espece": "ovin", "race": "Race fictive", "sexe": "M" if i % 2 else "F",
                                            "date_naissance": "2026-03-12", "mere_id": meres[i - 1]["id"], "origine": "naissance", "lot_animaux_id": lot_ag["id"]}))
    EL.post(f"/lots-animaux/{lot_br['id']}/localisation", {"parcelle_id": parcelles["P05"]["id"], "du": h(date(2026, 4, 2), 9)})
    for a in agneaux[:4]:
        EL.post("/evenements-elevage", {"type": "pesee", "animal_id": a["id"], "horodatage": h(date(2026, 4, 12), 10), "valeurs": {"poids_kg": 12.4}})
        EL.post("/evenements-elevage", {"type": "pesee", "animal_id": a["id"], "horodatage": h(date(2026, 5, 12), 10), "valeurs": {"poids_kg": 21.1}})
    EL.post("/evenements-elevage", {"type": "alimentation", "lot_animaux_id": lot_ag["id"], "horodatage": h(date(2026, 5, 15), 8),
                                    "valeurs": {"article_id": arts["ALI-AGN"]["id"], "quantite": 160, "unite": "kg"}, "notes": "Distribution collective — ration de démonstration"})
    EL.post("/evenements-elevage", {"type": "observation", "lot_animaux_id": lot_br["id"], "horodatage": h(date(2026, 5, 20), 18), "valeurs": {"etat_corporel_moyen": 3.0}, "notes": "Observation collective du lot"})
    err = OP.erreur("/traitements-animaux", {"lot_animaux_id": lot_ag["id"], "medicament": "Antiparasitaire (fictif)"}, 403)
    J.verifier(err["code"] == "acces_refuse", "Saisie d'un traitement refusée à une opératrice (personnes autorisées uniquement)")
    t = VE.post("/traitements-animaux", {"lot_animaux_id": lot_ag["id"], "horodatage": h(date(2026, 6, 2), 9), "medicament": "Antiparasitaire DEMO (médicament fictif)",
                                         "numero_ordonnance": "ORD-DEMO-2026-031", "prescripteur": "Dr Hélène Perrin (fictive)", "posologie_saisie": "Selon ordonnance",
                                         "voie": "orale", "delai_attente_viande_saisi": "Tel que mentionné sur l'ordonnance fictive : 28 jours", "date_fin_attente_saisie": "2026-06-30"})
    J.verifier("ne le calcule ni ne le vérifie" in t["avertissement"], "Traitement saisi par la vétérinaire ; délai d'attente recopié, ni calculé ni vérifié par Terroir")
    EL.post("/evenements-elevage", {"type": "vente", "animal_id": agneaux[0]["id"], "horodatage": h(date(2026, 7, 8), 7), "notes": "Vendu à un négociant fictif"})
    EL.post("/evenements-elevage", {"type": "mortalite", "animal_id": agneaux[7]["id"], "horodatage": h(date(2026, 4, 3), 6), "notes": "Mortalité néonatale"})
    croiss = EL.get(f"/animaux/{agneaux[1]['id']}/croissance")
    decl = EL.get("/declarations-a-preparer")
    J.note(f"GMQ agneau {croiss['animal']} : {croiss['gmq'][0]['gmq_g_j']} g/j ({croiss['methode']})")
    J.verifier(len(decl["evenements"]) > 0 and "Aucune notification n'est transmise" in decl["avertissement"],
               f"{len(decl['evenements'])} événements « à déclarer » listés pour préparation, sans transmission officielle")

    # ------------------------------------------------------------------ 13
    J.etape("Analyse des coûts")
    G.post("/temps-travail", {"membre_id": membres["marc"]["id"], "date": "2026-05-15", "heures": 6, "activite": "elevage", "lot_animaux_id": lot_ag["id"]})
    from app.modules.analyses.models import ChargeIndirecte, RegleAllocation
    regle = RegleAllocation(exploitation_id=exp_id, libelle="Répartition des charges de structure au prorata des surfaces", cle="surface",
                            description="Fermages, assurances et frais de gestion répartis entre cycles au prorata de la surface prévue.", valide_du=date(2025, 9, 1))
    db.add(regle)
    db.flush()
    db.add(ChargeIndirecte(exploitation_id=exp_id, campagne_id=uuid.UUID(camp["id"]), libelle="Charges de structure 2025-2026 (fictives)", montant_eur=18500, regle_id=regle.id,
                           source="Budget prévisionnel fictif"))
    db.commit()
    a = CP.get("/analyses/couts", campagne_id=camp["id"])
    c01 = next(c for c in a["cycles"] if c["parcelle"].startswith("P01"))
    J.note(f"P01 blé : charges opérationnelles {eur(c01['charges_operationnelles_eur'])}, produit {eur(c01['produit_eur'])}, "
           f"marge brute {eur(c01['marge_brute_eur'])} ({eur(c01['marge_brute_eur_ha'])}/ha), résultat après allocation {eur(c01['resultat_apres_allocation_eur'])}.")
    J.note(f"Coût supplémentaire estimé : {eur(c01['cout_supplementaire']['par_ha_eur'])}/ha, {eur(c01['cout_supplementaire']['par_t_eur'])}/t — {c01['cout_supplementaire']['hypothese']}")
    J.note(f"Trésorerie sur la période de campagne (01/09/2025–31/08/2026) : encaissements {eur(a['tresorerie']['encaissements_eur'])}, "
           f"décaissements {eur(a['tresorerie']['decaissements_eur'])} ; depuis le début de campagne jusqu'à aujourd'hui : "
           f"encaissements {eur(a['tresorerie_a_date']['encaissements_eur'])}, solde {eur(a['tresorerie_a_date']['solde_eur'])}.")
    J.verifier(all(c01["charges"][k] > 0 for k in ("intrants", "main_oeuvre", "materiel", "carburant", "indirectes")) and c01["charges"]["prestataires"] > 0,
               "Coûts ventilés par catégorie (intrants, main-d'œuvre, matériel, carburant, prestataires, charges indirectes)")
    J.note("Données manquantes signalées : " + ("; ".join(a["donnees_manquantes"][:4]) if a["donnees_manquantes"] else "aucune (tous les prix et tarifs nécessaires sont saisis)"))
    prev = CP.get("/analyses/previsions", campagne_id=camp["id"])
    rbt = next(r for r in prev["rendements"] if r["culture"] == "Blé tendre")
    J.note(f"Scénarios de rendement blé : {rbt['methode']} → médian {n(rbt['scenarios']['median']['rendement_t_ha'], 2)} t/ha.")
    calc = CH.post("/irrigation/calcul", {"parcelle_id": parcelles["P06"]["id"], "kc": 1.05, "source_kc": "Coefficient saisi par l'exploitant (fictif)", "du": "2026-08-01", "au": "2026-08-10"})
    J.verifier(calc["calcul_possible"] is False and any("05/08/2026" in m for m in calc["donnees_manquantes"]),
               "Calcul d'irrigation déclaré impossible faute d'ET0 les 05–06/08/2026 (pas de valeur par défaut)")
    calc = CH.post("/irrigation/calcul", {"parcelle_id": parcelles["P06"]["id"], "kc": 1.05, "source_kc": "Coefficient saisi par l'exploitant (fictif)", "du": "2026-08-08", "au": "2026-08-14"})
    J.note(f"Irrigation P06 du 08 au 14/08/2026 (consultatif) : besoin net {n(calc['besoin_net_mm'], 1)} mm, dose brute {n(calc['dose_brute_mm'], 1)} mm, {n(calc['volume_m3'], 0)} m³ (efficience {n(calc['hypotheses']['systeme']['efficience_pct'], 0)} %).")

    # ------------------------------------------------------------------ 14
    J.etape("Export des rapports")
    pdf = G.get(f"/rapports/tracabilite/{lot_bt['id']}", format="pdf")
    csv_ = G.get(f"/rapports/tracabilite/{lot_bt['id']}", format="csv")
    couts_csv = CP.get("/rapports/couts", campagne_id=camp["id"], format="csv")
    export = G.get("/exports/comptable", du="2025-09-01", au="2026-12-31")
    (sortie / "tracabilite-BT-2026-P01.pdf").write_bytes(pdf)
    (sortie / "tracabilite-BT-2026-P01.csv").write_bytes(csv_ if isinstance(csv_, bytes) else csv_.encode())
    (sortie / "couts-2025-2026.csv").write_bytes(couts_csv if isinstance(couts_csv, bytes) else couts_csv.encode())
    (sortie / "export-gestion-comptable.csv").write_bytes(export if isinstance(export, bytes) else export.encode())
    J.verifier(pdf[:5] == b"%PDF-", f"Rapport de traçabilité PDF ({len(pdf)} octets), CSV de traçabilité, CSV des coûts et export de gestion comptable écrits dans {sortie}")

    # ------------------------------------------------------------------ campagne suivante
    J.etape("Campagne 2026-2027 en préparation")
    camp2 = G.post("/campagnes", {"libelle": "2026-2027", "date_debut": "2026-09-01", "date_fin": "2027-08-31"})
    c2 = CH.post("/cycles", {"campagne_id": camp2["id"], "parcelle_id": parcelles["P02"]["id"], "culture": "Blé tendre", "famille_botanique": "Poacées", "variete": "Aubade (fictive)",
                             "surface_prevue_ha": parcelles["P02"]["surface_calculee_ha"], "date_semis_prevue": "2026-10-20", "date_recolte_debut_prevue": "2027-07-12", "rendement_previsionnel": 8.0})
    CH.post("/cycles", {"campagne_id": camp2["id"], "parcelle_id": parcelles["P01"]["id"], "culture": "Blé tendre", "famille_botanique": "Poacées", "surface_prevue_ha": parcelles["P01"]["surface_calculee_ha"], "rendement_previsionnel": 7.5})
    CH.post("/interventions", {"parcelle_id": parcelles["P02"]["id"], "cycle_id": c2["id"], "type": "fertilisation", "date_prevue": "2027-02-25", "duree_prevue_h": 3,
                               "produits": [{"article_id": arts["ENG-AMMO"]["id"], "dose_prevue": 160, "unite_dose": "kg/ha"}]})
    OP.post(f"/materiels/{mats['TR-02']['id']}/defauts", {"gravite": "bloquant", "description": "Fuite hydraulique sur le relevage arrière", "constate_le": h(date(2026, 11, 20), 16)})
    tdb = G.get("/tableau-de-bord")
    types = {a_["type"] for a_ in tdb["alertes"]}
    b2 = CH.get(f"/campagnes/{camp2['id']}/besoins")
    J.verifier("materiel" in types and any(x["statut"] == "rupture" for x in b2["intrants"]),
               "Tableau de bord : matériel indisponible (TR-02, défaut bloquant) et rupture prévisionnelle d'ammonitrate pour 2026-2027")
    rot2 = CH.get("/rotations")
    J.verifier(any(a_["libelle"].startswith("Pas de blé") and a_["validee"] for p_ in rot2["parcelles"] for cas in p_["campagnes"].values() for c in cas for a_ in c["alertes"]),
               "Blé sur blé en P01 (2026-2027) signalé par une règle validée par la conseillère")
    audit = G.get("/audit", limite=1000)
    J.note(f"Journal d'audit : {len(audit)} entrées enregistrées pendant la démonstration.")

    J.lignes += ["", "## Synthèse des vérifications", "", f"{sum(1 for _, ok in J.verifications if ok)} / {len(J.verifications)} vérifications réussies.", ""]
    J.lignes += [f"- {'✅' if ok else '❌'} {lib}" for lib, ok in J.verifications]
    J.lignes += ["", "## Comptes de démonstration", "", f"Mot de passe commun (démonstration uniquement) : `{MDP}`", ""]
    J.lignes += [f"- `{c}` — {n} ({r})" for c, n, r in UTILISATEURS]
    (sortie / "RESULTATS_DEMO.md").write_text("\n".join(J.lignes) + "\n", encoding="utf-8")
    print(f"\nDémonstration terminée : {sum(1 for _, ok in J.verifications if ok)}/{len(J.verifications)} vérifications réussies. Journal : {sortie / 'RESULTATS_DEMO.md'}")
    db.close()
    return J


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Démonstration Ferme des Trois Vallées")
    ap.add_argument("--sortie", default="./demo_sortie")
    a = ap.parse_args()
    main(Path(a.sortie))
