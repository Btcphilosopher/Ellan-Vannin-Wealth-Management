"""Géométries fictives de la Ferme des Trois Vallées.

Les limites sont des polygones synthétiques. Une partie est fournie en
Lambert-93 (EPSG:2154), une partie en WGS 84 (EPSG:4326), pour exercer la
conservation du système de coordonnées d'origine.
"""


def rectangle_l93(x0, y0, largeur, hauteur, biseau=0.0):
    """Quadrilatère en mètres Lambert-93 ; `biseau` décale un coin pour éviter des rectangles parfaits."""
    return {"type": "Polygon", "coordinates": [[
        [x0, y0], [x0 + largeur, y0], [x0 + largeur + biseau, y0 + hauteur], [x0, y0 + hauteur], [x0, y0]]]}


# Origine fictive en Lambert-93 (zone rurale du centre-ouest).
X, Y = 512000.0, 6690000.0

PARCELLES = [
    # code, nom, site, géométrie, srid, surface déclarée (ha)
    ("P01", "Les Grands Champs", "VH", rectangle_l93(X, Y, 400, 310), 2154, 12.10),
    ("P02", "La Pièce du Moulin", "VH", rectangle_l93(X + 420, Y, 350, 260), 2154, 9.10),
    ("P03", "Le Clos Bertin", "VH", rectangle_l93(X, Y + 330, 300, 250), 2154, 7.45),
    ("P04", "Champ de la Croix", "VL", rectangle_l93(X + 1500, Y + 200, 280, 200), 2154, 5.60),
    ("P05", "Le Pré Long", "VL", rectangle_l93(X + 1500, Y + 420, 260, 180), 2154, 4.70),
    ("P06", "Les Terres Basses", "VB", rectangle_l93(X + 600, Y - 900, 150, 120), 2154, 1.80),
    ("P07", "Jardin du Lys", "VB", rectangle_l93(X + 780, Y - 900, 100, 80), 2154, 0.80),
    ("P08", "Verger des Coteaux", "VL", rectangle_l93(X + 1820, Y + 200, 200, 150), 2154, 3.00),
]

# Parcelle d'essai en La Réunion, saisie en WGS 84 (fuseau Indian/Reunion).
R01 = ("R01", "Parcelle d'essai Bras-Creux", "RE", {"type": "Polygon", "coordinates": [[
    [55.47410, -21.31200], [55.47487, -21.31200], [55.47487, -21.31155], [55.47410, -21.31155], [55.47410, -21.31200]]]}, 4326, 0.40)
