"""Import de tous les modèles (pour Alembic et les tests)."""
from app.modules.identite.models import *  # noqa
from app.modules.foncier.models import *  # noqa
from app.modules.cultures.models import *  # noqa
from app.modules.interventions.models import *  # noqa
from app.modules.intrants.models import *  # noqa
from app.modules.stocks.models import *  # noqa
from app.modules.tracabilite.models import *  # noqa
from app.modules.elevage.models import *  # noqa
from app.modules.materiel.models import *  # noqa
from app.modules.equipe.models import *  # noqa
from app.modules.commercial.models import *  # noqa
from app.modules.analyses.models import *  # noqa
from app.modules.documents.models import *  # noqa
from app.modules.terrain.models import *  # noqa
from app.modules.sync.models import *  # noqa
from app.core.db import Base  # noqa
