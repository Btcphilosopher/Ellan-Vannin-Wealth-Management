"""Gestionnaires des traitements en arrière-plan."""
import uuid
from datetime import date, timedelta

from sqlalchemy import select

from app.adapters.registre import adaptateur
from app.core.db import maintenant
from app.core.taches import tache
from app.modules.foncier.models import Parcelle
from app.modules.terrain.models import ReleveMeteo


@tache("import_meteo")
def import_meteo(db, t):
    p = t.parametres
    site = uuid.UUID(p["site_id"])
    du, au = date.fromisoformat(p["du"]), date.fromisoformat(p["au"])
    trous = {date.fromisoformat(x) for x in p.get("trous", [])}
    from app.modules.foncier.models import Site

    n = 0
    nom = db.get(Site, site).nom
    for r in adaptateur("meteo").releves(site, du, au, trous=trous, graine=nom):
        db.add(ReleveMeteo(recu_le=maintenant(), **r))
        n += 1
    db.commit()
    return {"releves_importes": n, "source": adaptateur("meteo").nom, "jours_sans_donnee": sorted(x.isoformat() for x in trous)}


@tache("recalcul_surfaces")
def recalcul_surfaces(db, t):
    """Recalcule les surfaces géodésiques via PostGIS (contrôle de cohérence)."""
    from sqlalchemy import text

    rows = db.execute(text("UPDATE parcelle SET surface_calculee_ha = round((ST_Area(geometrie::geography)/10000)::numeric, 4) "
                           "WHERE exploitation_id = :e AND geometrie IS NOT NULL RETURNING id"), {"e": t.exploitation_id}).all()
    db.commit()
    return {"parcelles_recalculees": len(rows)}


@tache("export_donnees")
def export_donnees(db, t):
    from app.core.stockage import enregistrer_objet
    from app.modules.documents.models import Document
    from app.modules.identite.router import export_complet

    contenu = export_complet(db, t.exploitation_id)
    cle, sha = enregistrer_objet(t.exploitation_id, contenu, "application/zip")
    d = Document(exploitation_id=t.exploitation_id, categorie="autre", titre=f"Export complet du {date.today().strftime('%d/%m/%Y')}",
                 nom_fichier="export.zip", cle_stockage=cle, type_mime="application/zip", taille_octets=len(contenu),
                 sha256=sha, confidentiel=True, ajoute_par=t.demandee_par)
    db.add(d)
    db.commit()
    return {"document_id": str(d.id), "taille_octets": len(contenu)}


@tache("controle_echeances")
def controle_echeances(db, t):
    from app.modules.documents.models import Document

    limite = date.today() + timedelta(days=30)
    docs = db.scalars(select(Document).where(Document.exploitation_id == t.exploitation_id, Document.echeance.is_not(None),
                                             Document.echeance <= limite)).all()
    return {"echeances_proches": [{"titre": d.titre, "echeance": d.echeance.isoformat()} for d in docs]}
