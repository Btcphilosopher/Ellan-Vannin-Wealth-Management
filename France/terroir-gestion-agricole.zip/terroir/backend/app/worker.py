"""Point d'entrée du travailleur : python -m app.worker"""
import logging

from app.core.taches import boucle

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    boucle()
