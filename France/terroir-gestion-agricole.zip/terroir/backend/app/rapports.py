"""Rapports exportables (PDF via ReportLab, CSV séparateur « ; » et virgule décimale)."""
import csv
import io

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.core.db import maintenant
from app.core.format_fr import court, date_fr, date_heure_fr, euros, nombre
from app.i18n.fr import libelle
from app.modules.identite.models import Exploitation

VERT = colors.HexColor("#1F4D2B")
BLE = colors.HexColor("#E3B23C")


def _doc(titre, ctx):
    buf = io.BytesIO()
    expl = ctx.db.get(Exploitation, ctx.exploitation_id)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle("Petit", parent=styles["Normal"], fontSize=8, leading=10))
    styles["Title"].textColor = VERT
    elements = [Paragraph(titre, styles["Title"]),
                Paragraph(f"{expl.raison_sociale}{' — exploitation fictive, données de démonstration' if expl.fictive else ''}", styles["Normal"]),
                Paragraph(f"Édité le {date_heure_fr(maintenant())} par {ctx.utilisateur.nom_affiche}", styles["Petit"]),
                Spacer(1, 5 * mm)]
    return buf, styles, elements


def _pdf(x) -> str:
    """Les polices PDF standard n'ont pas l'espace fine insécable (U+202F) : espace insécable classique."""
    return str(x).replace("\u202f", "\u00a0").replace("\u2212", "-")


def _table(data, largeurs=None):
    data = [[_pdf(c) for c in ligne] for ligne in data]
    if len(data) == 1:
        data = data + [["Aucun"] + [""] * (len(data[0]) - 1)]
    t = Table(data, colWidths=largeurs, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), VERT), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 8), ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#B8B8A8")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F6F3EA")]), ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return t


def pdf_tracabilite(r: dict, ctx) -> bytes:
    buf, st, el = _doc(f"Rapport de traçabilité — lot {r['lot']['numero']}", ctx)
    l = r["lot"]
    el.append(Paragraph(f"<b>Conclusion :</b> {r['conclusion']}", st["Normal"]))
    el.append(Spacer(1, 3 * mm))
    el.append(_table([["Article", "Culture / variété", "Origine", "Quantité initiale", "Statut"],
                      [l["article"], f"{l['culture'] or '—'} / {l['variete'] or '—'}", libelle("origine_lot", l["origine"]),
                       f"{court(l['quantite_initiale'])} {l['unite']}", libelle("statut_lot", l["statut"]) + (" — apte à la vente" if l["apte_vente"] else " — non déclaré apte à la vente")]]))
    if l["intervention"]:
        el.append(Spacer(1, 2 * mm))
        el.append(Paragraph(f"Récolte : intervention {l['intervention']['numero']} du {date_fr(l['intervention']['date'])}"
                            f"{' — parcelle ' + l['parcelle']['code'] + ' ' + l['parcelle']['nom'] if l['parcelle'] else ''}.", st["Normal"]))
    el.append(Spacer(1, 4 * mm))
    el.append(Paragraph("Parcelles d'origine", st["Heading3"]))
    if r["parcelles_origine"]:
        el.append(_table([["Code", "Nom"]] + [[p["code"], p["nom"]] for p in r["parcelles_origine"]]))
    else:
        el.append(Paragraph("Aucune parcelle d'origine identifiée.", st["Normal"]))
    el.append(Paragraph("Lots amont (ascendants)", st["Heading3"]))
    el.append(_table([["Lot", "Article", "Origine", "Parcelle", "Récolte", "Intervention"]] +
                     [[a["numero"], a["article"], libelle("origine_lot", a["origine"]), a["parcelle"]["code"] if a["parcelle"] else "—",
                       date_fr(a["date_recolte"]), a["intervention"]["numero"] if a["intervention"] else "—"] for a in r["ascendants"]]
))
    el.append(Paragraph("Liens entre lots", st["Heading3"]))
    el.append(_table([["Parent", "Enfant", "Type", "Quantité", "Date"]] +
                     [[x["parent"], x["enfant"], libelle("origine_lot", x["type"]), f"{court(x['quantite'])} {x['unite']}", date_fr(x["date"])] for x in r["liens"]]))
    el.append(Paragraph("Lots aval et stockage", st["Heading3"]))
    el.append(_table([["Lot", "Article", "Emplacements (historique)", "Statut"]] +
                     [[d["numero"], d["article"], ", ".join(d["emplacements_historiques"]) or "—", libelle("statut_lot", d["statut"])] for d in [l] + r["descendants"]]))
    el.append(Paragraph("Expéditions", st["Heading3"]))
    el.append(_table([["Expédition", "Date", "Commande", "Client", "Quantité"]] +
                     [[e["numero"], date_fr(e["date"]), e["commande"], e["client"], court(e["quantite"])] for e in r["expeditions"]]))
    el.append(Paragraph("Données manquantes signalées", st["Heading3"]))
    if r["donnees_manquantes"]:
        el.append(_table([["Lot", "Donnée manquante"]] + [[m["lot"], m["manque"]] for m in r["donnees_manquantes"]]))
    else:
        el.append(Paragraph("Aucune donnée manquante détectée par les contrôles de Terroir.", st["Normal"]))
    el.append(Spacer(1, 5 * mm))
    el.append(Paragraph("Ce rapport reflète les données enregistrées dans Terroir. Il ne constitue pas une certification.", st["Petit"]))
    SimpleDocTemplate(buf, pagesize=A4, title=f"Traçabilité {l['numero']}", leftMargin=15 * mm, rightMargin=15 * mm).build(el)
    return buf.getvalue()


def csv_tracabilite(r: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["role", "lot", "article", "origine", "culture", "variete", "parcelle", "date_recolte", "quantite_initiale", "unite", "statut", "donnees_manquantes"])
    for role, lots in (("lot", [r["lot"]]), ("ascendant", r["ascendants"]), ("descendant", r["descendants"])):
        for l in lots:
            w.writerow([role, l["numero"], l["article"], l["origine"], l["culture"] or "", l["variete"] or "",
                        l["parcelle"]["code"] if l["parcelle"] else "", date_fr(l["date_recolte"]) if l["date_recolte"] else "",
                        nombre(l["quantite_initiale"], 3) if l["quantite_initiale"] is not None else "", l["unite"], l["statut"],
                        " | ".join(l["donnees_manquantes"])])
    w.writerow([])
    w.writerow(["expedition", "date", "commande", "client", "quantite"])
    for e in r["expeditions"]:
        w.writerow([e["numero"], date_fr(e["date"]), e["commande"], e["client"], nombre(e["quantite"], 3)])
    w.writerow([])
    w.writerow(["conclusion", r["conclusion"]])
    return "﻿" + buf.getvalue()


def csv_couts(a: dict) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    cats = ["intrants", "main_oeuvre", "materiel", "carburant", "prestataires", "stockage", "emballages", "indirectes"]
    w.writerow(["# " + a["avertissement"]])
    w.writerow(["parcelle", "culture", "surface_ha"] + cats + ["produit_eur", "marge_brute_eur", "resultat_apres_allocation_eur", "cout_supplementaire_eur_ha"])
    for c in a["cycles"]:
        w.writerow([c["parcelle"], c["culture"], nombre(c["surface_ha"], 2)] + [nombre(c["charges"][k]) for k in cats] +
                   [nombre(c["produit_eur"]), nombre(c["marge_brute_eur"]), nombre(c["resultat_apres_allocation_eur"]),
                    nombre(c["cout_supplementaire"]["par_ha_eur"])])
    w.writerow([])
    w.writerow(["allocation", "montant_eur", "cle", "regle", "description"])
    for al in a["allocations"]:
        w.writerow([al["charge"], nombre(al["montant_eur"]), al["cle"], f"{al['regle']} v{al['version']}", al["description"]])
    return "﻿" + buf.getvalue()


def pdf_couts(a: dict, ctx) -> bytes:
    buf, st, el = _doc(f"Analyse des coûts — campagne {a['campagne']['libelle']}", ctx)
    el.append(_table([["Parcelle", "Culture", "Charges op.", "Produit", "Marge brute", "Résultat alloué"]] +
                     [[c["parcelle"], c["culture"], euros(c["charges_operationnelles_eur"]), euros(c["produit_eur"]),
                       euros(c["marge_brute_eur"]), euros(c["resultat_apres_allocation_eur"])] for c in a["cycles"]]))
    el.append(Spacer(1, 4 * mm))
    noms = {"marge_brute": "Marge brute", "resultat_apres_allocation": "Résultat après allocation", "tresorerie": "Trésorerie",
            "cout_supplementaire": "Coût supplémentaire", "produit": "Produit"}
    for k, v in a["definitions"].items():
        el.append(Paragraph(_pdf(f"<b>{noms.get(k, k)}</b> : {v}"), st["Petit"]))
    if a["donnees_manquantes"]:
        el.append(Paragraph(_pdf("<b>Données manquantes</b> : " + " ; ".join(a["donnees_manquantes"])), st["Petit"]))
    el.append(Paragraph(a["avertissement"], st["Petit"]))
    SimpleDocTemplate(buf, pagesize=A4, title="Analyse des coûts").build(el)
    return buf.getvalue()
