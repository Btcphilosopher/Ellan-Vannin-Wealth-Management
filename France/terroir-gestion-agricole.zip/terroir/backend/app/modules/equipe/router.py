import uuid
from datetime import date

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import select

from app.core.audit import instantane, journaliser
from app.core.crud import obtenir
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.modules.equipe.models import Competence, MembreEquipe, TarifRessource, TempsTravail

router = APIRouter(tags=["Équipe"])
E = "/exploitations/{exploitation_id}"


class MembreEntree(Entree):
    prenom: str
    nom: str
    statut: str
    entreprise: str | None = None
    fonction: str | None = None
    telephone: str | None = None


class CompetenceEntree(Entree):
    type: str
    libelle: str
    reference: str | None = None
    valide_du: date | None = None
    valide_au: date | None = None


class TempsEntree(Entree):
    membre_id: uuid.UUID
    date: date
    heures: float
    activite: str
    intervention_id: uuid.UUID | None = None
    lot_animaux_id: uuid.UUID | None = None
    cycle_id: uuid.UUID | None = None
    notes: str | None = None


class TarifEntree(Entree):
    ressource_type: str
    ressource_id: uuid.UUID
    cout_horaire_eur: float
    valide_du: date
    source: str | None = None


@router.get(E + "/membres")
def lister_membres(ctx: Contexte = Depends(autoriser("equipe:lire"))):
    res = []
    for m in ctx.db.scalars(select(MembreEquipe).where(MembreEquipe.exploitation_id == ctx.exploitation_id).order_by(MembreEquipe.nom)):
        comps = ctx.db.scalars(select(Competence).where(Competence.membre_id == m.id)).all()
        res.append(en_dict(m, competences=[en_dict(c, valide=(c.valide_au is None or c.valide_au >= date.today())) for c in comps]))
    return res


@router.post(E + "/membres", status_code=201)
def creer_membre(e: MembreEntree, ctx: Contexte = Depends(autoriser("equipe:ecrire"))):
    m = MembreEquipe(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(m)
    ctx.db.flush()
    journaliser(ctx, "creation", "membre_equipe", m.id, apres=instantane(m))
    ctx.db.commit()
    return en_dict(m)


@router.post(E + "/membres/{membre_id}/competences", status_code=201)
def ajouter_competence(membre_id: uuid.UUID, e: CompetenceEntree, ctx: Contexte = Depends(autoriser("equipe:ecrire"))):
    m = obtenir(ctx, MembreEquipe, membre_id, "Membre")
    c = Competence(membre_id=m.id, **e.model_dump())
    ctx.db.add(c)
    ctx.db.flush()
    journaliser(ctx, "creation", "competence", c.id, apres=instantane(c))
    ctx.db.commit()
    return en_dict(c)


@router.get(E + "/temps-travail")
def lister_temps(ctx: Contexte = Depends(autoriser("equipe:lire")), du: date | None = None, au: date | None = None):
    q = select(TempsTravail).where(TempsTravail.exploitation_id == ctx.exploitation_id)
    if du:
        q = q.where(TempsTravail.date >= du)
    if au:
        q = q.where(TempsTravail.date <= au)
    return liste(ctx.db.scalars(q.order_by(TempsTravail.date.desc())))


@router.post(E + "/temps-travail", status_code=201)
def saisir_temps(e: TempsEntree, ctx: Contexte = Depends(autoriser("interventions:realiser"))):
    obtenir(ctx, MembreEquipe, e.membre_id, "Membre")
    t = TempsTravail(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(t)
    ctx.db.flush()
    journaliser(ctx, "creation", "temps_travail", t.id, apres=instantane(t))
    ctx.db.commit()
    return en_dict(t)


@router.get(E + "/tarifs")
def lister_tarifs(ctx: Contexte = Depends(autoriser("equipe:lire"))):
    return liste(ctx.db.scalars(select(TarifRessource).where(TarifRessource.exploitation_id == ctx.exploitation_id).order_by(TarifRessource.valide_du)))


@router.post(E + "/tarifs", status_code=201)
def creer_tarif(e: TarifEntree, ctx: Contexte = Depends(autoriser("equipe:ecrire"))):
    from datetime import timedelta

    prec = ctx.db.scalar(select(TarifRessource).where(TarifRessource.ressource_id == e.ressource_id, TarifRessource.valide_au.is_(None)))
    version = 1
    if prec:
        prec.valide_au = e.valide_du - timedelta(days=1)
        version = prec.version + 1
    t = TarifRessource(exploitation_id=ctx.exploitation_id, version=version, **e.model_dump())
    ctx.db.add(t)
    ctx.db.flush()
    journaliser(ctx, "creation", "tarif_ressource", t.id, apres=instantane(t))
    ctx.db.commit()
    return en_dict(t)
