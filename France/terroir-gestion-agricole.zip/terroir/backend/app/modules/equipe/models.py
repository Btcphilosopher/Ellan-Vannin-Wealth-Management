import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin


class MembreEquipe(IdMixin, HorodatageMixin, Base):
    __tablename__ = "membre_equipe"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    prenom: Mapped[str] = mapped_column(String(80))
    nom: Mapped[str] = mapped_column(String(80))
    statut: Mapped[str] = mapped_column(String(20))  # associe|salarie|saisonnier|apprenti|prestataire
    entreprise: Mapped[str | None] = mapped_column(String(200))  # pour un prestataire
    fonction: Mapped[str | None] = mapped_column(String(120))
    telephone: Mapped[str | None] = mapped_column(String(30))
    actif: Mapped[bool] = mapped_column(default=True)


class Competence(IdMixin, HorodatageMixin, Base):
    __tablename__ = "competence"
    membre_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("membre_equipe.id", ondelete="CASCADE"), index=True)
    type: Mapped[str] = mapped_column(String(60))  # certiphyto_decideur|certiphyto_operateur|caces|permis_c|conduite_tracteur|soins_animaux
    libelle: Mapped[str] = mapped_column(String(200))
    reference: Mapped[str | None] = mapped_column(String(80))
    valide_du: Mapped[date | None]
    valide_au: Mapped[date | None]
    document_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("document.id", ondelete="SET NULL"))


class TempsTravail(IdMixin, HorodatageMixin, Base):
    __tablename__ = "temps_travail"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    membre_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("membre_equipe.id"), index=True)
    date: Mapped[date]
    heures: Mapped[Decimal]
    activite: Mapped[str] = mapped_column(String(60))  # intervention|elevage|entretien|administratif|commercial|stockage
    intervention_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("intervention.id", ondelete="SET NULL"))
    lot_animaux_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("lot_animaux.id", ondelete="SET NULL"))
    cycle_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("cycle_cultural.id", ondelete="SET NULL"))
    source: Mapped[str] = mapped_column(String(20), default="saisie")
    notes: Mapped[str | None] = mapped_column(Text)


class TarifRessource(IdMixin, HorodatageMixin, Base):
    """Coût horaire versionné d'une personne ou d'un matériel (hors carburant)."""

    __tablename__ = "tarif_ressource"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    ressource_type: Mapped[str] = mapped_column(String(20))  # membre | materiel
    ressource_id: Mapped[uuid.UUID] = mapped_column(index=True)
    cout_horaire_eur: Mapped[Decimal]
    valide_du: Mapped[date]
    valide_au: Mapped[date | None]
    source: Mapped[str | None] = mapped_column(String(200))
    version: Mapped[int] = mapped_column(default=1)
