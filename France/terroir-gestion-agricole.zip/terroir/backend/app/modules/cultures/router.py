import uuid
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import select

from app.core.audit import instantane, journaliser
from app.core.format_fr import court
from app.core.crud import appliquer, obtenir, verifier_version
from app.core.db import maintenant
from app.core.erreurs import ErreurMetier
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.modules.cultures import service as CS
from app.modules.cultures.models import Campagne, CycleCultural, ItineraireTechnique, RegleRotation
from app.modules.foncier.models import Parcelle
from app.modules.interventions.router import InterventionEntree, ProduitEntree, creer_intervention
from app.modules.stocks.models import Article

router = APIRouter(tags=["Cultures : campagnes, cycles, rotations, besoins"])
E = "/exploitations/{exploitation_id}"


class CampagneEntree(Entree):
    libelle: str
    date_debut: date
    date_fin: date
    statut: str = "en_preparation"


class CycleEntree(Entree):
    campagne_id: uuid.UUID
    parcelle_id: uuid.UUID
    zone_id: uuid.UUID | None = None
    module: str = "grandes_cultures"
    culture: str
    famille_botanique: str | None = None
    variete: str | None = None
    surface_prevue_ha: float
    date_semis_prevue: date | None = None
    date_recolte_debut_prevue: date | None = None
    date_recolte_fin_prevue: date | None = None
    rendement_previsionnel: float | None = None
    unite_rendement: str = "t/ha"
    source_rendement_previsionnel: str | None = None
    destination_prevue: str | None = None
    notes: str | None = None


class CycleMaj(Entree):
    version: int
    variete: str | None = None
    surface_prevue_ha: float | None = None
    date_semis_prevue: date | None = None
    date_recolte_debut_prevue: date | None = None
    date_recolte_fin_prevue: date | None = None
    rendement_previsionnel: float | None = None
    source_rendement_previsionnel: str | None = None
    destination_prevue: str | None = None
    statut: str | None = None
    notes: str | None = None


class RegleEntree(Entree):
    libelle: str
    type: str
    culture: str | None = None
    famille: str | None = None
    precedent: str | None = None
    delai_min_campagnes: int | None = None
    severite: str = "avertissement"
    source: str | None = None


class ValidationRegle(Entree):
    qualification: str


class ItineraireEntree(Entree):
    libelle: str
    culture: str
    etapes: list
    source: str | None = None
    redige_par: str | None = None


@router.get(E + "/campagnes")
def lister_campagnes(ctx: Contexte = Depends(autoriser("cultures:lire"))):
    return liste(ctx.db.scalars(select(Campagne).where(Campagne.exploitation_id == ctx.exploitation_id).order_by(Campagne.date_debut.desc())))


@router.post(E + "/campagnes", status_code=201)
def creer_campagne(e: CampagneEntree, ctx: Contexte = Depends(autoriser("cultures:ecrire"))):
    if e.date_fin <= e.date_debut:
        raise ErreurMetier("donnee_invalide", detail="la fin de campagne doit suivre son début")
    c = Campagne(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(c)
    ctx.db.flush()
    journaliser(ctx, "creation", "campagne", c.id, apres=instantane(c))
    ctx.db.commit()
    return en_dict(c)


@router.get(E + "/cycles")
def lister_cycles(ctx: Contexte = Depends(autoriser("cultures:lire")), campagne_id: uuid.UUID | None = None,
                  parcelle_id: uuid.UUID | None = None):
    q = select(CycleCultural, Parcelle).join(Parcelle).where(CycleCultural.exploitation_id == ctx.exploitation_id)
    if campagne_id:
        q = q.where(CycleCultural.campagne_id == campagne_id)
    if parcelle_id:
        q = q.where(CycleCultural.parcelle_id == parcelle_id)
    return [en_dict(c, parcelle={"code": p.code, "nom": p.nom}, realise=CS.rendement_realise(ctx.db, c))
            for c, p in ctx.db.execute(q.order_by(Parcelle.code))]


@router.post(E + "/cycles", status_code=201)
def creer_cycle(e: CycleEntree, ctx: Contexte = Depends(autoriser("cultures:ecrire"))):
    obtenir(ctx, Campagne, e.campagne_id, "Campagne")
    p = obtenir(ctx, Parcelle, e.parcelle_id, "Parcelle")
    surf_ref = p.surface_calculee_ha or p.surface_declaree_ha
    avertissements = []
    if surf_ref and Decimal(str(e.surface_prevue_ha)) > Decimal(surf_ref) * Decimal("1.001"):
        avertissements.append(f"Surface prévue supérieure à la surface de la parcelle ({court(surf_ref, 2)} ha).")
    c = CycleCultural(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(c)
    ctx.db.flush()
    journaliser(ctx, "creation", "cycle_cultural", c.id, apres=instantane(c))
    ctx.db.commit()
    return en_dict(c, avertissements=avertissements)


@router.get(E + "/cycles/{cycle_id}")
def lire_cycle(cycle_id: uuid.UUID, ctx: Contexte = Depends(autoriser("cultures:lire"))):
    c = obtenir(ctx, CycleCultural, cycle_id, "Cycle cultural")
    from app.modules.interventions.router import lister as lister_it

    return en_dict(c, realise=CS.rendement_realise(ctx.db, c),
                   prevision={"rendement": float(c.rendement_previsionnel) if c.rendement_previsionnel else None,
                              "unite": c.unite_rendement, "source": c.source_rendement_previsionnel, "nature": "prévision"},
                   interventions=lister_it(ctx=ctx, cycle_id=c.id))


@router.patch(E + "/cycles/{cycle_id}")
def modifier_cycle(cycle_id: uuid.UUID, e: CycleMaj, ctx: Contexte = Depends(autoriser("cultures:ecrire"))):
    c = obtenir(ctx, CycleCultural, cycle_id, "Cycle cultural")
    verifier_version(c, e.version)
    avant = instantane(c)
    appliquer(c, e.model_dump(exclude_unset=True, exclude={"version"}))
    journaliser(ctx, "modification", "cycle_cultural", c.id, avant=avant, apres=instantane(c))
    ctx.db.commit()
    return en_dict(c)


@router.get(E + "/rotations")
def rotations(ctx: Contexte = Depends(autoriser("cultures:lire"))):
    return CS.analyse_rotation(ctx.db, ctx.exploitation_id)


@router.get(E + "/regles-rotation")
def lister_regles(ctx: Contexte = Depends(autoriser("cultures:lire"))):
    return liste(ctx.db.scalars(select(RegleRotation).where(RegleRotation.exploitation_id == ctx.exploitation_id)))


@router.post(E + "/regles-rotation", status_code=201)
def creer_regle(e: RegleEntree, ctx: Contexte = Depends(autoriser("cultures:ecrire"))):
    if e.type not in ("delai_retour_culture", "delai_retour_famille", "succession_interdite"):
        raise ErreurMetier("donnee_invalide", detail="type de règle inconnu")
    r = RegleRotation(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(r)
    ctx.db.flush()
    journaliser(ctx, "creation", "regle_rotation", r.id, apres=instantane(r))
    ctx.db.commit()
    return en_dict(r)


@router.post(E + "/regles-rotation/{regle_id}/validation")
def valider_regle(regle_id: uuid.UUID, e: ValidationRegle, ctx: Contexte = Depends(autoriser("phyto:valider"))):
    r = obtenir(ctx, RegleRotation, regle_id, "Règle de rotation")
    r.validee_par = ctx.utilisateur.nom_affiche
    r.qualification_validateur = e.qualification
    r.validee_le = date.today()
    journaliser(ctx, "validation_professionnelle", "regle_rotation", r.id, apres=instantane(r))
    ctx.db.commit()
    return en_dict(r)


@router.get(E + "/itineraires")
def lister_itineraires(ctx: Contexte = Depends(autoriser("cultures:lire"))):
    return liste(ctx.db.scalars(select(ItineraireTechnique).where(ItineraireTechnique.exploitation_id == ctx.exploitation_id)))


@router.post(E + "/itineraires", status_code=201)
def creer_itineraire(e: ItineraireEntree, ctx: Contexte = Depends(autoriser("cultures:ecrire"))):
    i = ItineraireTechnique(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(i)
    ctx.db.flush()
    journaliser(ctx, "creation", "itineraire_technique", i.id, apres=instantane(i))
    ctx.db.commit()
    return en_dict(i)


@router.post(E + "/cycles/{cycle_id}/itineraire/{itineraire_id}")
def appliquer_itineraire(cycle_id: uuid.UUID, itineraire_id: uuid.UUID, ctx: Contexte = Depends(autoriser("cultures:ecrire"))):
    """Génère les interventions planifiées d'un cycle à partir d'un itinéraire saisi."""
    c = obtenir(ctx, CycleCultural, cycle_id, "Cycle cultural")
    it = obtenir(ctx, ItineraireTechnique, itineraire_id, "Itinéraire technique")
    if not c.date_semis_prevue:
        raise ErreurMetier("donnee_invalide", detail="date de semis prévue requise pour positionner les étapes")
    articles = {a.code: a for a in ctx.db.scalars(select(Article).where(Article.exploitation_id == ctx.exploitation_id))}
    creees, manquants = [], []
    for et in it.etapes:
        jour = c.date_semis_prevue + timedelta(days=int(et.get("decalage_jours", 0)))
        produits = []
        for pr in et.get("produits", []):
            a = articles.get(pr["article_code"])
            if not a:
                manquants.append(pr["article_code"])
                continue
            produits.append(ProduitEntree(article_id=a.id, dose_prevue=pr.get("dose"), unite_dose=pr.get("unite_dose")))
        duree = Decimal(str(et.get("duree_h_par_ha", 0))) * Decimal(c.surface_prevue_ha)
        debut = datetime(jour.year, jour.month, jour.day, 8, 0, tzinfo=timezone.utc)
        e = InterventionEntree(parcelle_id=c.parcelle_id, cycle_id=c.id, type=et["type"], libelle=et.get("libelle"),
                               date_prevue=jour, debut_prevu=debut, fin_prevue=debut + timedelta(hours=max(float(duree), 1)),
                               surface_prevue_ha=float(c.surface_prevue_ha), duree_prevue_h=float(duree),
                               competence_requise=et.get("competence_requise"), produits=produits)
        creees.append(creer_intervention(ctx, e, origine="itineraire").numero)
    ctx.db.commit()
    return {"interventions_creees": creees, "articles_introuvables": sorted(set(manquants))}


@router.get(E + "/campagnes/{campagne_id}/besoins")
def besoins(campagne_id: uuid.UUID, ctx: Contexte = Depends(autoriser("cultures:lire"))):
    obtenir(ctx, Campagne, campagne_id, "Campagne")
    return CS.besoins_campagne(ctx.db, ctx.exploitation_id, campagne_id)
