import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin, VersionMixin


class Campagne(IdMixin, HorodatageMixin, Base):
    __tablename__ = "campagne"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    libelle: Mapped[str] = mapped_column(String(40))  # ex. « 2026-2027 »
    date_debut: Mapped[date]
    date_fin: Mapped[date]
    statut: Mapped[str] = mapped_column(String(20), default="en_preparation")  # en_preparation|en_cours|close


class CycleCultural(IdMixin, HorodatageMixin, VersionMixin, Base):
    """Une culture sur une parcelle (ou zone) pour une campagne.

    Les champs *_prevu(e) sont des prévisions ; les réalisations sont
    issues des interventions et des lots récoltés, jamais saisies ici.
    """

    __tablename__ = "cycle_cultural"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    campagne_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("campagne.id"))
    parcelle_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("parcelle.id"), index=True)
    zone_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("zone_gestion.id", ondelete="SET NULL"))
    module: Mapped[str] = mapped_column(String(30), default="grandes_cultures")
    culture: Mapped[str] = mapped_column(String(80))
    famille_botanique: Mapped[str | None] = mapped_column(String(80))
    variete: Mapped[str | None] = mapped_column(String(80))
    surface_prevue_ha: Mapped[Decimal]
    date_semis_prevue: Mapped[date | None]
    date_recolte_debut_prevue: Mapped[date | None]
    date_recolte_fin_prevue: Mapped[date | None]
    rendement_previsionnel: Mapped[Decimal | None]
    unite_rendement: Mapped[str] = mapped_column(String(10), default="t/ha")
    source_rendement_previsionnel: Mapped[str | None] = mapped_column(String(200))
    destination_prevue: Mapped[str | None] = mapped_column(String(120))
    statut: Mapped[str] = mapped_column(String(20), default="prevu")  # prevu|en_cours|recolte|clos|abandonne
    notes: Mapped[str | None] = mapped_column(Text)


class RegleRotation(IdMixin, HorodatageMixin, Base):
    """Contrainte de rotation configurable. Une règle non validée par un
    professionnel compétent est affichée comme « non validée »."""

    __tablename__ = "regle_rotation"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    libelle: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(30))  # delai_retour_culture|delai_retour_famille|succession_interdite
    culture: Mapped[str | None] = mapped_column(String(80))
    famille: Mapped[str | None] = mapped_column(String(80))
    precedent: Mapped[str | None] = mapped_column(String(80))
    delai_min_campagnes: Mapped[int | None]
    severite: Mapped[str] = mapped_column(String(20), default="avertissement")  # information|avertissement
    source: Mapped[str | None] = mapped_column(String(300))
    validee_par: Mapped[str | None] = mapped_column(String(200))
    qualification_validateur: Mapped[str | None] = mapped_column(String(200))
    validee_le: Mapped[date | None]
    active: Mapped[bool] = mapped_column(default=True)


class ItineraireTechnique(IdMixin, HorodatageMixin, Base):
    """Modèle d'itinéraire saisi par l'exploitation (pas une recommandation).

    etapes = [{type, libelle, decalage_jours, duree_h_par_ha, competence_requise,
               categorie_materiel, produits: [{article_code, dose, unite_dose}]}]
    """

    __tablename__ = "itineraire_technique"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    libelle: Mapped[str] = mapped_column(String(200))
    culture: Mapped[str] = mapped_column(String(80))
    etapes: Mapped[list] = mapped_column(default=list)
    source: Mapped[str | None] = mapped_column(String(300))
    redige_par: Mapped[str | None] = mapped_column(String(200))
    valide_par: Mapped[str | None] = mapped_column(String(200))
    valide_le: Mapped[datetime | None]
