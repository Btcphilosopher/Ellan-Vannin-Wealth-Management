"""Rotations et calcul des besoins d'une campagne."""
from collections import defaultdict
from datetime import timedelta
from decimal import Decimal

from sqlalchemy import select

from app.core.unites import arrondi, convertir
from app.modules.cultures.models import Campagne, CycleCultural, RegleRotation
from app.modules.foncier.models import Parcelle
from app.modules.interventions.models import Intervention, InterventionProduit
from app.modules.stocks import service as S
from app.modules.stocks.models import Article, LotStock, Reservation

AVERTISSEMENT_ROTATION = ("Cet indicateur mesure uniquement le respect des règles de rotation saisies. "
                          "Il ne constitue ni une mesure ni une preuve de la bonne santé du sol.")


def analyse_rotation(db, exploitation_id) -> dict:
    campagnes = db.scalars(select(Campagne).where(Campagne.exploitation_id == exploitation_id).order_by(Campagne.date_debut)).all()
    idx = {c.id: i for i, c in enumerate(campagnes)}
    regles = db.scalars(select(RegleRotation).where(RegleRotation.exploitation_id == exploitation_id, RegleRotation.active.is_(True))).all()
    parcelles = db.scalars(select(Parcelle).where(Parcelle.exploitation_id == exploitation_id, Parcelle.active.is_(True)).order_by(Parcelle.code)).all()
    cycles = db.scalars(select(CycleCultural).where(CycleCultural.exploitation_id == exploitation_id,
                                                    CycleCultural.statut != "abandonne")).all()
    par_parcelle = defaultdict(list)
    for c in cycles:
        par_parcelle[c.parcelle_id].append(c)
    lignes, n_total, n_alerte = [], 0, 0
    for p in parcelles:
        cases = {}
        hist = sorted(par_parcelle.get(p.id, []), key=lambda c: idx[c.campagne_id])
        for c in hist:
            n_total += 1
            alertes = []
            i = idx[c.campagne_id]
            precedents = [h for h in hist if idx[h.campagne_id] < i]
            for r in regles:
                if r.type == "delai_retour_culture" and r.culture and c.culture.lower() == r.culture.lower():
                    proches = [h for h in precedents if h.culture.lower() == c.culture.lower()
                               and i - idx[h.campagne_id] < (r.delai_min_campagnes or 0)]
                    if proches:
                        alertes.append(r)
                elif r.type == "delai_retour_famille" and r.famille and (c.famille_botanique or "").lower() == r.famille.lower():
                    proches = [h for h in precedents if (h.famille_botanique or "").lower() == r.famille.lower()
                               and i - idx[h.campagne_id] < (r.delai_min_campagnes or 0)]
                    if proches:
                        alertes.append(r)
                elif r.type == "succession_interdite" and r.precedent and r.culture:
                    prev = [h for h in precedents if idx[h.campagne_id] == i - 1]
                    if c.culture.lower() == r.culture.lower() and any(h.culture.lower() == r.precedent.lower() for h in prev):
                        alertes.append(r)
            if alertes:
                n_alerte += 1
            cases.setdefault(str(c.campagne_id), []).append({
                "cycle_id": str(c.id), "culture": c.culture, "variete": c.variete, "famille": c.famille_botanique,
                "statut": c.statut,
                "alertes": [{"regle_id": str(r.id), "libelle": r.libelle, "severite": r.severite,
                             "validee": bool(r.validee_par), "validee_par": r.validee_par,
                             "etat_regle": "règle validée" if r.validee_par else "règle non validée par un professionnel"}
                            for r in alertes],
            })
        lignes.append({"parcelle_id": str(p.id), "code": p.code, "nom": p.nom, "campagnes": cases})
    return {
        "campagnes": [{"id": str(c.id), "libelle": c.libelle} for c in campagnes],
        "parcelles": lignes,
        "regles": [{"id": str(r.id), "libelle": r.libelle, "type": r.type, "validee_par": r.validee_par,
                    "qualification_validateur": r.qualification_validateur,
                    "validee_le": r.validee_le.isoformat() if r.validee_le else None, "source": r.source} for r in regles],
        "indicateur": {
            "libelle": "Part des cycles sans alerte de rotation",
            "valeur_pct": round(100 * (n_total - n_alerte) / n_total, 1) if n_total else None,
            "cycles_evalues": n_total, "cycles_en_alerte": n_alerte,
            "regles_non_validees": sum(1 for r in regles if not r.validee_par),
            "avertissement": AVERTISSEMENT_ROTATION,
        },
    }


def besoins_campagne(db, exploitation_id, campagne_id) -> dict:
    """Agrège les besoins prévus (interventions planifiées non réalisées)."""
    rows = db.execute(
        select(InterventionProduit, Intervention, CycleCultural)
        .join(Intervention, Intervention.id == InterventionProduit.intervention_id)
        .join(CycleCultural, CycleCultural.id == Intervention.cycle_id)
        .where(CycleCultural.campagne_id == campagne_id, Intervention.exploitation_id == exploitation_id,
               Intervention.statut.in_(["planifiee", "en_cours"]))).all()
    par_article = defaultdict(lambda: {"besoin": Decimal(0), "reserve_pour_campagne": Decimal(0), "interventions": []})
    for ip, it, cyc in rows:
        if ip.quantite_prevue is None:
            continue
        a = db.get(Article, ip.article_id)
        q = S.en_unite_stock(a, ip.quantite_prevue, ip.unite_quantite)
        e = par_article[a.id]
        e["besoin"] += q
        if ip.reservation_id:
            r = db.get(Reservation, ip.reservation_id)
            if r and r.statut == "active":
                e["reserve_pour_campagne"] += Decimal(r.quantite)
        e["interventions"].append({"numero": it.numero, "date_prevue": it.date_prevue.isoformat() if it.date_prevue else None,
                                   "culture": cyc.culture, "quantite": arrondi(q)})
    intrants = []
    for aid, e in par_article.items():
        a = db.get(Article, aid)
        etat = S.etat_article(db, exploitation_id, a)
        reste_a_couvrir = e["besoin"] - e["reserve_pour_campagne"]
        couverture = Decimal(str(etat["disponible"])) + Decimal(str(etat["attendu"]))
        manque = max(reste_a_couvrir - couverture, Decimal(0))
        intrants.append({
            "article_id": str(a.id), "code": a.code, "libelle": a.libelle, "categorie": a.categorie, "unite": a.unite_stock,
            "besoin": arrondi(e["besoin"]), "deja_reserve": arrondi(e["reserve_pour_campagne"]),
            "disponible": etat["disponible"], "attendu": etat["attendu"], "manque": arrondi(manque),
            "statut": "rupture" if manque > 0 else "couvert", "interventions": e["interventions"],
        })
    # Charge de travail et matériel par semaine ISO
    charge = defaultdict(lambda: {"heures_main_oeuvre": Decimal(0), "interventions": 0})
    for it, cyc in db.execute(select(Intervention, CycleCultural).join(CycleCultural, CycleCultural.id == Intervention.cycle_id)
                              .where(CycleCultural.campagne_id == campagne_id, Intervention.statut.in_(["planifiee", "en_cours"]))):
        if not it.date_prevue:
            continue
        annee, sem, _ = it.date_prevue.isocalendar()
        cle = f"{annee}-S{sem:02d}"
        charge[cle]["heures_main_oeuvre"] += Decimal(it.duree_prevue_h or 0)
        charge[cle]["interventions"] += 1
    return {
        "campagne_id": str(campagne_id),
        "methode": "Somme des quantités prévues des interventions planifiées ; manque = besoin − déjà réservé − (disponible + attendu).",
        "intrants": sorted(intrants, key=lambda x: (x["statut"] != "rupture", x["libelle"])),
        "charge_travail": [{"semaine": k, "heures": arrondi(v["heures_main_oeuvre"], 1), "interventions": v["interventions"]}
                           for k, v in sorted(charge.items())],
    }


def rendement_realise(db, cycle: CycleCultural) -> dict:
    lots = db.scalars(select(LotStock).where(LotStock.cycle_id == cycle.id, LotStock.origine == "recolte")).all()
    total_t = Decimal(0)
    for l in lots:
        if l.quantite_initiale is not None:
            try:
                total_t += convertir(l.quantite_initiale, l.unite, "t")
            except Exception:  # noqa: BLE001 unités non massiques (ex. bottes)
                pass
    surf = Decimal(cycle.surface_prevue_ha or 0)
    return {"quantite_recoltee_t": arrondi(total_t), "lots": len(lots),
            "rendement_t_ha": arrondi(total_t / surf, 2) if surf and lots else None,
            "nature": "observé (lots récoltés enregistrés)"}
