import uuid
from datetime import datetime

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, IdMixin


class OperationSync(IdMixin, Base):
    """Opération reçue d'un terminal. `id` = identifiant généré par le
    terminal : renvoyer la même opération est sans effet (idempotence)."""

    __tablename__ = "operation_sync"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    utilisateur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    terminal_id: Mapped[str] = mapped_column(String(80))
    type: Mapped[str] = mapped_column(String(40))  # observation|note|photo|compte_rendu|modification_observation
    entite_id: Mapped[uuid.UUID | None]
    version_base: Mapped[int | None]
    contenu: Mapped[dict]
    saisi_le: Mapped[datetime]
    recue_le: Mapped[datetime]
    statut: Mapped[str] = mapped_column(String(30))  # acceptee|en_attente_validation|conflit|rejetee|validee
    message: Mapped[str | None] = mapped_column(Text)


class ConflitSync(IdMixin, Base):
    __tablename__ = "conflit_sync"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    operation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("operation_sync.id", ondelete="CASCADE"))
    entite: Mapped[str] = mapped_column(String(40))
    entite_id: Mapped[uuid.UUID]
    version_serveur: Mapped[dict]
    version_terminal: Mapped[dict]
    champs_en_conflit: Mapped[list] = mapped_column(default=list)
    statut: Mapped[str] = mapped_column(String(20), default="ouvert")  # ouvert|resolu
    resolution: Mapped[str | None] = mapped_column(String(30))  # garder_serveur|garder_terminal|fusion
    resolu_par: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    resolu_le: Mapped[datetime | None]
    cree_le: Mapped[datetime]
