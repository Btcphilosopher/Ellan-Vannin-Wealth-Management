"""Synchronisation des saisies hors connexion.

Pris en charge : brouillons d'observations, notes, photographies et
comptes rendus d'intervention proposés. Les comptes rendus touchent des
stocks et ressources partagés : ils restent « en attente de validation »
jusqu'à validation explicite sur le serveur.

Conflits : chaque modification hors connexion porte la version de base de
l'enregistrement. Si le serveur a évolué entre-temps, un conflit est créé
avec les deux versions ; il est résolu explicitement (garder serveur,
garder terminal ou fusion champ par champ).
"""
import base64
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import select

from app.core.audit import instantane, journaliser
from app.core.crud import obtenir
from app.core.db import maintenant
from app.core.erreurs import Conflit, ErreurMetier
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.modules.cultures.models import CycleCultural
from app.modules.foncier.models import Parcelle
from app.modules.interventions.models import Intervention
from app.modules.stocks.models import Article
from app.modules.sync.models import ConflitSync, OperationSync
from app.modules.terrain.models import ObservationCulturale

router = APIRouter(tags=["Terrain : hors connexion et synchronisation"])
E = "/exploitations/{exploitation_id}"
TYPES = {"observation", "modification_observation", "note", "photo", "compte_rendu"}
CHAMPS_OBS = ("categorie", "stade", "description", "intensite", "photos", "position")


class OperationEntree(Entree):
    id: uuid.UUID  # généré par le terminal, stable
    type: str
    entite_id: uuid.UUID | None = None
    version_base: int | None = None
    saisi_le: datetime
    contenu: dict


class Lot(Entree):
    terminal_id: str
    operations: list[OperationEntree]


class Resolution(Entree):
    resolution: str  # garder_serveur | garder_terminal | fusion
    valeurs_fusion: dict | None = None


def _traiter(ctx: Contexte, op: OperationEntree, terminal_id: str) -> OperationSync:
    from app.modules.terrain.router import ObservationEntree, creer_observation

    db = ctx.db
    rec = OperationSync(id=op.id, exploitation_id=ctx.exploitation_id, utilisateur_id=ctx.utilisateur.id,
                        terminal_id=terminal_id, type=op.type, entite_id=op.entite_id, version_base=op.version_base,
                        contenu=op.contenu, saisi_le=op.saisi_le, recue_le=maintenant(), statut="acceptee")
    db.add(rec)
    db.flush()
    if op.type not in TYPES:
        rec.statut, rec.message = "rejetee", f"Type non pris en charge hors connexion : {op.type}"
        return rec
    try:
        with db.begin_nested():
            if op.type == "observation":
                c = op.contenu
                if db.get(ObservationCulturale, op.entite_id or op.id):
                    rec.message = "Déjà présente (renvoi idempotent)."
                else:
                    o = creer_observation(ctx, ObservationEntree(id=op.entite_id or op.id, observe_le=op.saisi_le, **c), origine="terrain")
                    o.synchronise_le = maintenant()
                    rec.entite_id = o.id
            elif op.type == "note":
                c = op.contenu
                o = creer_observation(ctx, ObservationEntree(id=op.entite_id or op.id, observe_le=op.saisi_le,
                                                             parcelle_id=c["parcelle_id"], categorie="autre",
                                                             description=c["texte"]), origine="terrain")
                rec.entite_id = o.id
            elif op.type == "photo":
                from app.modules.documents.router import creer_document

                contenu = base64.b64decode(op.contenu["donnees_base64"])
                d = creer_document(ctx, op.contenu.get("nom_fichier", "photo.jpg"), contenu, "photo",
                                   op.contenu.get("titre") or "Photo de terrain", entite_type=op.contenu.get("entite_type"),
                                   entite_id=op.contenu.get("entite_id"))
                rec.entite_id = d.id
                rec.contenu = {k: v for k, v in op.contenu.items() if k != "donnees_base64"} | {"taille": len(contenu)}
            elif op.type == "modification_observation":
                o = obtenir(ctx, ObservationCulturale, op.entite_id, "Observation")
                if op.version_base is not None and o.version != op.version_base:
                    serveur = {k: getattr(o, k) for k in CHAMPS_OBS} | {"version": o.version}
                    terminal = {k: op.contenu.get(k) for k in CHAMPS_OBS if k in op.contenu}
                    champs = [k for k, v in terminal.items() if serveur.get(k) != v]
                    db.add(ConflitSync(exploitation_id=ctx.exploitation_id, operation_id=op.id, entite="observation_culturale",
                                       entite_id=o.id, version_serveur=serveur, version_terminal=terminal,
                                       champs_en_conflit=champs, cree_le=maintenant()))
                    rec.statut, rec.message = "conflit", "L'observation a été modifiée sur le serveur depuis votre dernière synchronisation."
                else:
                    avant = instantane(o)
                    for k in CHAMPS_OBS:
                        if k in op.contenu:
                            setattr(o, k, op.contenu[k])
                    o.version += 1
                    journaliser(ctx, "modification", "observation_culturale", o.id, avant=avant, apres=instantane(o))
            elif op.type == "compte_rendu":
                c = op.contenu
                it = obtenir(ctx, Intervention, op.entite_id, "Intervention") if op.entite_id else None
                if it and it.statut in ("planifiee", "en_cours"):
                    rec.statut = "en_attente_validation"
                    rec.message = ("Compte rendu reçu. Il touche des stocks et des ressources partagés : "
                                   "il sera appliqué après validation par un responsable.")
                elif it:
                    rec.statut, rec.message = "conflit", f"L'intervention est déjà « {it.statut} » sur le serveur."
                    db.add(ConflitSync(exploitation_id=ctx.exploitation_id, operation_id=op.id, entite="intervention",
                                       entite_id=it.id, version_serveur={"statut": it.statut, "version": it.version},
                                       version_terminal=c, champs_en_conflit=["statut"], cree_le=maintenant()))
                else:
                    rec.statut = "en_attente_validation"
                    rec.message = "Proposition d'intervention non planifiée : à valider."
    except ErreurMetier as e:
        rec.statut, rec.message = "rejetee", e.message
    return rec


@router.post(E + "/sync/envoi")
def envoyer(lot: Lot, ctx: Contexte = Depends(autoriser("terrain:saisir"))):
    ctx.origine = "terrain"
    resultats = []
    for op in sorted(lot.operations, key=lambda o: o.saisi_le):
        existant = ctx.db.get(OperationSync, op.id)
        if existant:
            resultats.append({"id": str(op.id), "statut": existant.statut, "message": "Déjà reçue (aucun effet).",
                              "entite_id": str(existant.entite_id) if existant.entite_id else None, "doublon": True})
            continue
        rec = _traiter(ctx, op, lot.terminal_id)
        ctx.db.flush()
        resultats.append({"id": str(op.id), "statut": rec.statut, "message": rec.message,
                          "entite_id": str(rec.entite_id) if rec.entite_id else None, "doublon": False})
    ctx.db.commit()
    return {"recu_le": maintenant().isoformat(), "resultats": resultats}


@router.get(E + "/sync/donnees")
def donnees_hors_connexion(ctx: Contexte = Depends(autoriser("terrain:saisir"))):
    """Sous-ensemble autorisé, mis en cache sur le terminal (lecture seule)."""
    from app.modules.interventions.router import detail

    parcelles = [{"id": str(p.id), "code": p.code, "nom": p.nom, "site_id": str(p.site_id),
                  "surface_ha": float(p.surface_calculee_ha or p.surface_declaree_ha or 0)}
                 for p in ctx.db.scalars(select(Parcelle).where(Parcelle.exploitation_id == ctx.exploitation_id, Parcelle.active.is_(True)))]
    cycles = [{"id": str(c.id), "parcelle_id": str(c.parcelle_id), "culture": c.culture, "variete": c.variete}
              for c in ctx.db.scalars(select(CycleCultural).where(CycleCultural.exploitation_id == ctx.exploitation_id,
                                                                  CycleCultural.statut.in_(["prevu", "en_cours"])))]
    its = [detail(ctx, i) for i in ctx.db.scalars(select(Intervention).where(
        Intervention.exploitation_id == ctx.exploitation_id, Intervention.statut.in_(["planifiee", "en_cours"]))
        .order_by(Intervention.date_prevue).limit(100))]
    obs = [en_dict(o) for o in ctx.db.scalars(select(ObservationCulturale).where(
        ObservationCulturale.exploitation_id == ctx.exploitation_id).order_by(ObservationCulturale.observe_le.desc()).limit(50))]
    return {"genere_le": maintenant().isoformat(), "parcelles": parcelles, "cycles": cycles, "interventions": its,
            "observations": obs, "perimetre": "Parcelles, cycles en cours, interventions planifiées (100 max), 50 dernières observations."}


@router.get(E + "/sync/operations")
def operations(ctx: Contexte = Depends(autoriser("interventions:lire")), statut: str | None = None):
    q = select(OperationSync).where(OperationSync.exploitation_id == ctx.exploitation_id)
    if statut:
        q = q.where(OperationSync.statut == statut)
    return liste(ctx.db.scalars(q.order_by(OperationSync.recue_le.desc()).limit(200)))


@router.post(E + "/sync/operations/{operation_id}/validation")
def valider_compte_rendu(operation_id: uuid.UUID, ctx: Contexte = Depends(autoriser("interventions:ecrire"))):
    """Applique un compte rendu terrain après validation serveur (stocks, temps, matériel)."""
    from app.modules.interventions.router import CompteRendu, realiser_intervention

    op = obtenir(ctx, OperationSync, operation_id, "Opération")
    if op.statut != "en_attente_validation" or op.type != "compte_rendu":
        raise Conflit("donnee_invalide", detail="opération non validable")
    it = obtenir(ctx, Intervention, op.entite_id, "Intervention")
    cr = CompteRendu(**op.contenu)
    realiser_intervention(ctx, it, cr)
    op.statut, op.message = "validee", f"Validée par {ctx.utilisateur.nom_affiche}"
    ctx.db.commit()
    return en_dict(op)


@router.get(E + "/sync/conflits")
def lister_conflits(ctx: Contexte = Depends(autoriser("terrain:saisir")), statut: str = "ouvert"):
    return liste(ctx.db.scalars(select(ConflitSync).where(ConflitSync.exploitation_id == ctx.exploitation_id,
                                                          ConflitSync.statut == statut).order_by(ConflitSync.cree_le.desc())))


@router.post(E + "/sync/conflits/{conflit_id}/resolution")
def resoudre(conflit_id: uuid.UUID, e: Resolution, ctx: Contexte = Depends(autoriser("sync:resoudre"))):
    c = obtenir(ctx, ConflitSync, conflit_id, "Conflit")
    if c.statut != "ouvert":
        raise Conflit("conflit_deja_resolu")
    if e.resolution not in ("garder_serveur", "garder_terminal", "fusion"):
        raise ErreurMetier("donnee_invalide", detail="résolution inconnue")
    if c.entite == "observation_culturale" and e.resolution != "garder_serveur":
        o = ctx.db.get(ObservationCulturale, c.entite_id)
        avant = instantane(o)
        valeurs = c.version_terminal if e.resolution == "garder_terminal" else (e.valeurs_fusion or {})
        for k, v in valeurs.items():
            if k in CHAMPS_OBS:
                setattr(o, k, v)
        o.version += 1
        journaliser(ctx, "resolution_conflit", "observation_culturale", o.id, avant=avant, apres=instantane(o))
    c.statut, c.resolution, c.resolu_par, c.resolu_le = "resolu", e.resolution, ctx.utilisateur.id, maintenant()
    op = ctx.db.get(OperationSync, c.operation_id)
    op.statut = "acceptee" if e.resolution != "garder_serveur" else "rejetee"
    op.message = f"Conflit résolu : {e.resolution}"
    ctx.db.commit()
    return en_dict(c)
