import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin, VersionMixin


class ObservationCulturale(IdMixin, HorodatageMixin, VersionMixin, Base):
    """L'identifiant peut être généré par le terminal (UUID stable hors connexion)."""

    __tablename__ = "observation_culturale"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    parcelle_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("parcelle.id"), index=True)
    cycle_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("cycle_cultural.id"))
    observe_le: Mapped[datetime]
    auteur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    categorie: Mapped[str] = mapped_column(String(30))  # stade|ravageur|maladie|adventice|carence|degat|etat_general|autre
    stade: Mapped[str | None] = mapped_column(String(80))
    description: Mapped[str] = mapped_column(Text)
    intensite: Mapped[str | None] = mapped_column(String(20))  # faible|moyenne|forte
    photos: Mapped[list] = mapped_column(default=list)  # ids de documents
    position: Mapped[dict | None]  # {lat, lon, precision_m}
    origine: Mapped[str] = mapped_column(String(20), default="web")  # web|terrain
    synchronise_le: Mapped[datetime | None]
    suggestion_automatique: Mapped[dict | None]  # hypothèse, jamais un diagnostic
    confirmee_par: Mapped[str | None] = mapped_column(String(200))


class ReleveMeteo(IdMixin, Base):
    __tablename__ = "releve_meteo"
    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id", ondelete="CASCADE"), index=True)
    nature: Mapped[str] = mapped_column(String(10))  # observee | prevue
    source: Mapped[str] = mapped_column(String(80))
    pour_date: Mapped[date] = mapped_column(index=True)
    emis_le: Mapped[datetime | None]  # date d'émission de la prévision
    recu_le: Mapped[datetime]
    temperature_min_c: Mapped[Decimal | None]
    temperature_max_c: Mapped[Decimal | None]
    pluie_mm: Mapped[Decimal | None]
    vent_moyen_kmh: Mapped[Decimal | None]
    rafales_kmh: Mapped[Decimal | None]
    humidite_relative_pct: Mapped[Decimal | None]
    et0_mm: Mapped[Decimal | None]
    simulee: Mapped[bool] = mapped_column(default=False)


class ReleveCompteurEau(IdMixin, Base):
    __tablename__ = "releve_compteur_eau"
    equipement_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("equipement_irrigation.id", ondelete="CASCADE"), index=True)
    horodatage: Mapped[datetime]
    index_m3: Mapped[Decimal]
    source: Mapped[str] = mapped_column(String(30), default="saisie")
    auteur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))


class MesureHumiditeSol(IdMixin, Base):
    __tablename__ = "mesure_humidite_sol"
    parcelle_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("parcelle.id", ondelete="CASCADE"), index=True)
    horodatage: Mapped[datetime]
    profondeur_cm: Mapped[int]
    valeur: Mapped[Decimal]
    unite: Mapped[str] = mapped_column(String(10))  # %vol | kPa
    capteur: Mapped[str | None] = mapped_column(String(80))
    source: Mapped[str] = mapped_column(String(30), default="saisie")


class ProgrammeIrrigation(IdMixin, HorodatageMixin, Base):
    """Programme consultatif : Terroir ne pilote aucune pompe ni vanne."""

    __tablename__ = "programme_irrigation"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    parcelle_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("parcelle.id"))
    cycle_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("cycle_cultural.id"))
    equipement_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("equipement_irrigation.id"))
    debut: Mapped[date]
    fin: Mapped[date]
    dose_mm: Mapped[Decimal]
    frequence_jours: Mapped[int]
    statut: Mapped[str] = mapped_column(String(20), default="propose")  # propose|retenu|termine
    hypotheses: Mapped[dict | None]
    notes: Mapped[str | None] = mapped_column(Text)
