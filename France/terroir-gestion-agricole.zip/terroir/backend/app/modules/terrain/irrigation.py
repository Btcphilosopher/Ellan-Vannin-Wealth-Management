"""Calcul consultatif des besoins d'irrigation (bilan hydrique simplifié).

Besoin net (mm) = Σ (ET0 × Kc) − Σ (pluie × coefficient de pluie efficace)
Dose brute (mm) = besoin net / efficience du système
Volume (m³)     = dose brute × 10 × surface (ha)

Toutes les hypothèses sont retournées. Le calcul ne commande aucun
équipement. Si une donnée manque, le calcul est déclaré impossible plutôt
que complété par une valeur par défaut.
"""
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import select

from app.modules.foncier.models import EquipementIrrigation, Parcelle
from app.modules.terrain.models import ReleveMeteo


def calculer(db, parcelle: Parcelle, *, kc: float, source_kc: str, du: date, au: date, surface_ha: float | None = None,
             coefficient_pluie_efficace: float = 0.8, equipement_id=None) -> dict:
    manques, jours = [], []
    sol = parcelle.sol or {}
    eq = db.get(EquipementIrrigation, equipement_id) if equipement_id else None
    if eq is None:
        eq = db.scalar(select(EquipementIrrigation).where(EquipementIrrigation.parcelle_id == parcelle.id))
    if not eq or eq.efficience_pct is None:
        manques.append("Efficience du système d'irrigation non renseignée")
    j = du
    while j <= au:
        rs = db.scalars(select(ReleveMeteo).where(ReleveMeteo.site_id == parcelle.site_id, ReleveMeteo.pour_date == j)
                        .order_by(ReleveMeteo.recu_le.desc())).all()
        r = next((x for x in rs if x.nature == "observee"), None) or next((x for x in rs if x.nature == "prevue"), None)
        if not r or r.et0_mm is None:
            manques.append(f"ET0 indisponible le {j.strftime('%d/%m/%Y')}")
            jours.append({"date": j.isoformat(), "nature": "indisponible"})
        else:
            jours.append({"date": j.isoformat(), "nature": r.nature, "source": r.source, "simulee": r.simulee,
                          "et0_mm": float(r.et0_mm), "pluie_mm": float(r.pluie_mm or 0),
                          "etc_mm": round(float(r.et0_mm) * kc, 2)})
        j += timedelta(days=1)
    surface = Decimal(str(surface_ha or parcelle.surface_calculee_ha or parcelle.surface_declaree_ha or 0))
    hypotheses = {
        "sol": {"texture": sol.get("texture"), "reserve_utile_mm": sol.get("ru_mm"), "source": sol.get("source"),
                "note": "La réserve utile est affichée pour contexte ; elle n'entre pas dans ce bilan simplifié (stock initial non mesuré)."},
        "culture": {"kc": kc, "source_kc": source_kc},
        "meteo": {"jours": len(jours), "jours_observes": sum(1 for x in jours if x["nature"] == "observee"),
                  "jours_prevus": sum(1 for x in jours if x["nature"] == "prevue"),
                  "jours_indisponibles": sum(1 for x in jours if x["nature"] == "indisponible")},
        "pluie_efficace": {"coefficient": coefficient_pluie_efficace, "note": "Hypothèse saisie, à adapter au sol et à l'intensité des pluies."},
        "systeme": {"equipement": eq.nom if eq else None, "type": eq.type if eq else None,
                    "efficience_pct": float(eq.efficience_pct) if eq and eq.efficience_pct is not None else None,
                    "source": eq.source_efficience if eq else None},
        "surface_ha": float(surface),
    }
    base = {"parcelle": parcelle.code, "du": du.isoformat(), "au": au.isoformat(), "hypotheses": hypotheses,
            "detail_journalier": jours, "consultatif": True,
            "avertissement": "Estimation consultative. Terroir ne commande ni pompe, ni vanne, ni machine."}
    if manques:
        return base | {"calcul_possible": False, "donnees_manquantes": manques}
    etc = sum(Decimal(str(x["etc_mm"])) for x in jours)
    pluie = sum(Decimal(str(x["pluie_mm"])) for x in jours) * Decimal(str(coefficient_pluie_efficace))
    net = max(etc - pluie, Decimal(0))
    brute = net / (Decimal(eq.efficience_pct) / 100)
    return base | {"calcul_possible": True, "etc_mm": float(round(etc, 1)), "pluie_efficace_mm": float(round(pluie, 1)),
                   "besoin_net_mm": float(round(net, 1)), "dose_brute_mm": float(round(brute, 1)),
                   "volume_m3": float(round(brute * 10 * surface, 0)),
                   "part_prevision_pct": round(100 * hypotheses["meteo"]["jours_prevus"] / len(jours), 0) if jours else 0}
