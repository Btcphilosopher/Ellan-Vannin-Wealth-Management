import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import select

from app.adapters.registre import adaptateur
from app.core.audit import instantane, journaliser
from app.core.crud import obtenir
from app.core.db import maintenant
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.modules.foncier.models import EquipementIrrigation, Parcelle, Site
from app.modules.terrain import irrigation
from app.modules.terrain.models import (MesureHumiditeSol, ObservationCulturale, ProgrammeIrrigation, ReleveCompteurEau,
                                        ReleveMeteo)

router = APIRouter(tags=["Observations, météo et irrigation"])
E = "/exploitations/{exploitation_id}"


class ObservationEntree(Entree):
    id: uuid.UUID | None = None
    parcelle_id: uuid.UUID
    cycle_id: uuid.UUID | None = None
    observe_le: datetime | None = None
    categorie: str
    stade: str | None = None
    description: str
    intensite: str | None = None
    photos: list[str] = []
    position: dict | None = None


class MeteoEntree(Entree):
    site_id: uuid.UUID
    nature: str
    source: str
    pour_date: date
    emis_le: datetime | None = None
    temperature_min_c: float | None = None
    temperature_max_c: float | None = None
    pluie_mm: float | None = None
    vent_moyen_kmh: float | None = None
    rafales_kmh: float | None = None
    humidite_relative_pct: float | None = None
    et0_mm: float | None = None


class CompteurEntree(Entree):
    equipement_id: uuid.UUID
    horodatage: datetime | None = None
    index_m3: float
    source: str = "saisie"


class HumiditeEntree(Entree):
    parcelle_id: uuid.UUID
    horodatage: datetime | None = None
    profondeur_cm: int
    valeur: float
    unite: str
    capteur: str | None = None
    source: str = "saisie"


class CalculIrrigation(Entree):
    parcelle_id: uuid.UUID
    kc: float
    source_kc: str
    du: date
    au: date
    coefficient_pluie_efficace: float = 0.8
    equipement_id: uuid.UUID | None = None
    surface_ha: float | None = None


class ProgrammeEntree(Entree):
    parcelle_id: uuid.UUID
    cycle_id: uuid.UUID | None = None
    equipement_id: uuid.UUID | None = None
    debut: date
    fin: date
    dose_mm: float
    frequence_jours: int
    hypotheses: dict | None = None
    notes: str | None = None


def creer_observation(ctx, e: ObservationEntree, origine="web") -> ObservationCulturale:
    obtenir(ctx, Parcelle, e.parcelle_id, "Parcelle")
    o = ObservationCulturale(exploitation_id=ctx.exploitation_id, auteur_id=ctx.utilisateur.id, origine=origine,
                             **(e.model_dump(exclude={"id"}) | {"observe_le": e.observe_le or maintenant()}))
    if e.id:
        o.id = e.id
    if e.photos:
        o.suggestion_automatique = adaptateur("classification").suggerer(e.photos)
    ctx.db.add(o)
    ctx.db.flush()
    journaliser(ctx, "creation", "observation_culturale", o.id, apres=instantane(o))
    return o


@router.get(E + "/observations")
def lister_observations(ctx: Contexte = Depends(autoriser("cultures:lire")), parcelle_id: uuid.UUID | None = None):
    q = select(ObservationCulturale).where(ObservationCulturale.exploitation_id == ctx.exploitation_id)
    if parcelle_id:
        q = q.where(ObservationCulturale.parcelle_id == parcelle_id)
    return liste(ctx.db.scalars(q.order_by(ObservationCulturale.observe_le.desc()).limit(300)))


@router.post(E + "/observations", status_code=201)
def observer(e: ObservationEntree, ctx: Contexte = Depends(autoriser("terrain:saisir"))):
    o = creer_observation(ctx, e)
    ctx.db.commit()
    return en_dict(o)


@router.get(E + "/meteo")
def lister_meteo(site_id: uuid.UUID, du: date, au: date, ctx: Contexte = Depends(autoriser("cultures:lire"))):
    obtenir(ctx, Site, site_id, "Site")
    rows = ctx.db.scalars(select(ReleveMeteo).where(ReleveMeteo.site_id == site_id, ReleveMeteo.pour_date >= du,
                                                    ReleveMeteo.pour_date <= au).order_by(ReleveMeteo.pour_date, ReleveMeteo.nature)).all()
    par_jour = {}
    for r in rows:
        par_jour.setdefault(r.pour_date.isoformat(), {})[r.nature] = en_dict(r)
    jours = []
    j = du
    while j <= au:
        k = j.isoformat()
        jours.append({"date": k, "observee": par_jour.get(k, {}).get("observee"), "prevue": par_jour.get(k, {}).get("prevue"),
                      "etat": "observee" if par_jour.get(k, {}).get("observee") else "prevue" if par_jour.get(k, {}).get("prevue") else "manquante"})
        j += timedelta(days=1)
    return {"site_id": str(site_id), "jours": jours, "jours_manquants": [x["date"] for x in jours if x["etat"] == "manquante"]}


@router.post(E + "/meteo", status_code=201)
def saisir_meteo(e: MeteoEntree, ctx: Contexte = Depends(autoriser("cultures:ecrire"))):
    obtenir(ctx, Site, e.site_id, "Site")
    r = ReleveMeteo(recu_le=maintenant(), simulee=False, **e.model_dump())
    ctx.db.add(r)
    ctx.db.commit()
    return en_dict(r)


@router.post(E + "/meteo/import-simulateur")
def importer_meteo(site_id: uuid.UUID, du: date, au: date, ctx: Contexte = Depends(autoriser("cultures:ecrire"))):
    from app.core.taches import mettre_en_file

    obtenir(ctx, Site, site_id, "Site")
    t = mettre_en_file(ctx.db, "import_meteo", {"site_id": str(site_id), "du": du.isoformat(), "au": au.isoformat()},
                       ctx.exploitation_id, ctx.utilisateur.id)
    ctx.db.commit()
    return {"tache_id": str(t.id), "statut": t.statut}


@router.get(E + "/irrigation/compteurs/{equipement_id}")
def volumes(equipement_id: uuid.UUID, ctx: Contexte = Depends(autoriser("cultures:lire"))):
    eq = obtenir(ctx, EquipementIrrigation, equipement_id, "Équipement")
    rs = ctx.db.scalars(select(ReleveCompteurEau).where(ReleveCompteurEau.equipement_id == eq.id).order_by(ReleveCompteurEau.horodatage)).all()
    periodes = [{"du": a.horodatage.isoformat(), "au": b.horodatage.isoformat(), "volume_m3": float(Decimal(b.index_m3) - Decimal(a.index_m3)),
                 "anomalie": "index en baisse : vérifier le relevé ou un changement de compteur" if b.index_m3 < a.index_m3 else None}
                for a, b in zip(rs, rs[1:])]
    return {"equipement": eq.nom, "compteur": eq.compteur_numero, "releves": liste(rs), "periodes": periodes,
            "volume_total_m3": sum(p["volume_m3"] for p in periodes if p["volume_m3"] >= 0)}


@router.post(E + "/irrigation/compteurs", status_code=201)
def relever_compteur(e: CompteurEntree, ctx: Contexte = Depends(autoriser("terrain:saisir"))):
    obtenir(ctx, EquipementIrrigation, e.equipement_id, "Équipement")
    r = ReleveCompteurEau(auteur_id=ctx.utilisateur.id, **(e.model_dump() | {"horodatage": e.horodatage or maintenant()}))
    ctx.db.add(r)
    ctx.db.commit()
    return en_dict(r)


@router.post(E + "/irrigation/humidite-sol", status_code=201)
def mesurer_humidite(e: HumiditeEntree, ctx: Contexte = Depends(autoriser("terrain:saisir"))):
    obtenir(ctx, Parcelle, e.parcelle_id, "Parcelle")
    m = MesureHumiditeSol(**(e.model_dump() | {"horodatage": e.horodatage or maintenant()}))
    ctx.db.add(m)
    ctx.db.commit()
    return en_dict(m)


@router.get(E + "/irrigation/humidite-sol")
def lister_humidite(parcelle_id: uuid.UUID, ctx: Contexte = Depends(autoriser("cultures:lire"))):
    obtenir(ctx, Parcelle, parcelle_id, "Parcelle")
    return liste(ctx.db.scalars(select(MesureHumiditeSol).where(MesureHumiditeSol.parcelle_id == parcelle_id).order_by(MesureHumiditeSol.horodatage)))


@router.post(E + "/irrigation/calcul")
def calcul_irrigation(e: CalculIrrigation, ctx: Contexte = Depends(autoriser("cultures:lire"))):
    p = obtenir(ctx, Parcelle, e.parcelle_id, "Parcelle")
    return irrigation.calculer(ctx.db, p, kc=e.kc, source_kc=e.source_kc, du=e.du, au=e.au, surface_ha=e.surface_ha,
                               coefficient_pluie_efficace=e.coefficient_pluie_efficace, equipement_id=e.equipement_id)


@router.get(E + "/irrigation/programmes")
def lister_programmes(ctx: Contexte = Depends(autoriser("cultures:lire"))):
    return liste(ctx.db.scalars(select(ProgrammeIrrigation).where(ProgrammeIrrigation.exploitation_id == ctx.exploitation_id)))


@router.post(E + "/irrigation/programmes", status_code=201)
def creer_programme(e: ProgrammeEntree, ctx: Contexte = Depends(autoriser("cultures:ecrire"))):
    obtenir(ctx, Parcelle, e.parcelle_id, "Parcelle")
    p = ProgrammeIrrigation(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(p)
    ctx.db.flush()
    journaliser(ctx, "creation", "programme_irrigation", p.id, apres=instantane(p))
    ctx.db.commit()
    return en_dict(p, avertissement="Programme consultatif : aucune commande n'est envoyée aux équipements.")
