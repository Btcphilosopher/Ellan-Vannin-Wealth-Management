"""Météo pour une date et un site : observée en priorité, sinon prévue,
sinon « indisponible ». La source et la fraîcheur sont toujours exposées."""
from datetime import date

from sqlalchemy import select

from app.core.db import maintenant
from app.core.serial import en_dict
from app.modules.terrain.models import ReleveMeteo


def meteo_du_jour(db, site_id, jour: date) -> dict:
    releves = db.scalars(select(ReleveMeteo).where(ReleveMeteo.site_id == site_id, ReleveMeteo.pour_date == jour)
                         .order_by(ReleveMeteo.recu_le.desc())).all()
    obs = next((r for r in releves if r.nature == "observee"), None)
    prev = next((r for r in releves if r.nature == "prevue"), None)
    r = obs or prev
    if not r:
        return {"nature": "indisponible", "pour_date": jour.isoformat(),
                "message": "Aucune donnée météo observée ni prévue pour ce site et cette date. "
                           "Saisissez les conditions constatées si elles sont connues."}
    fraicheur_h = round((maintenant() - r.recu_le).total_seconds() / 3600, 1)
    d = en_dict(r)
    return {"nature": r.nature, "source": r.source, "simulee": r.simulee, "pour_date": jour.isoformat(),
            "emis_le": d["emis_le"], "recu_le": d["recu_le"], "fraicheur_h": fraicheur_h,
            "valeurs": {k: d[k] for k in ("temperature_min_c", "temperature_max_c", "pluie_mm", "vent_moyen_kmh",
                                           "rafales_kmh", "humidite_relative_pct", "et0_mm")},
            "message": ("Météo observée" if r.nature == "observee" else "Prévision (non observée)")
                       + f" — source : {r.source}" + (" (simulateur)" if r.simulee else "")}
