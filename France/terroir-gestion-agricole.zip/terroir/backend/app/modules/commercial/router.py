import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import select

from app.core.audit import instantane, journaliser
from app.core.crud import obtenir
from app.core.db import maintenant
from app.core.erreurs import Conflit, ErreurMetier
from app.core.numerotation import numero_formate
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.core.unites import arrondi, convertir
from app.modules.commercial.models import (Allocation, Client, CommandeClient, CommandeFournisseur, DemandeAchat,
                                           Expedition, Facture, FactureFournisseur, Fournisseur, LigneCommandeClient,
                                           LigneCommandeFournisseur, Paiement, PrixArticle, Reception)
from app.modules.stocks import service as S
from app.modules.stocks.models import Article, LotStock, Reservation

router = APIRouter(tags=["Achats et ventes"])
E = "/exploitations/{exploitation_id}"


class TiersEntree(Entree):
    nom: str
    type: str | None = None
    contact: str | None = None


class PrixEntree(Entree):
    article_id: uuid.UUID
    nature: str
    prix_unitaire_eur: float
    unite: str
    valide_du: date
    source: str | None = None


class LigneDemande(Entree):
    article_id: uuid.UUID
    quantite: float
    unite: str
    date_besoin: date | None = None


class DemandeEntree(Entree):
    motif: str | None = None
    lignes: list[LigneDemande]
    origine: str = "manuel"


class LigneCommandeF(Entree):
    article_id: uuid.UUID
    quantite: float
    unite: str
    prix_unitaire_eur: float | None = None


class CommandeFEntree(Entree):
    fournisseur_id: uuid.UUID
    demande_id: uuid.UUID | None = None
    date_commande: date
    date_livraison_prevue: date | None = None
    lignes: list[LigneCommandeF]


class LigneReception(Entree):
    ligne_commande_id: uuid.UUID
    quantite: float
    unite: str
    emplacement_id: uuid.UUID
    numero_lot_fournisseur: str | None = None
    date_peremption: date | None = None


class ReceptionEntree(Entree):
    date_reception: datetime | None = None
    bon_livraison: str | None = None
    lignes: list[LigneReception]
    reserves: str | None = None


class FactureFEntree(Entree):
    fournisseur_id: uuid.UUID
    commande_id: uuid.UUID | None = None
    numero_fournisseur: str
    date_facture: date
    montant_ht_eur: float
    montant_tva_eur: float = 0
    categorie_charge: str = "intrants"
    imputation_type: str | None = None
    imputation_id: uuid.UUID | None = None
    date_paiement: date | None = None


class LigneCommandeC(Entree):
    article_id: uuid.UUID
    quantite: float
    unite: str
    prix_unitaire_eur: float


class CommandeCEntree(Entree):
    client_id: uuid.UUID
    date_commande: date
    date_livraison_souhaitee: date | None = None
    lignes: list[LigneCommandeC]


class AllocationLigne(Entree):
    ligne_id: uuid.UUID
    lot_id: uuid.UUID
    emplacement_id: uuid.UUID
    quantite: float


class AllocationEntree(Entree):
    lignes: list[AllocationLigne]


class ExpeditionLigne(Entree):
    allocation_id: uuid.UUID
    quantite: float


class ExpeditionEntree(Entree):
    lignes: list[ExpeditionLigne]
    transporteur: str | None = None
    horodatage: datetime | None = None
    notes: str | None = None


class FactureEntree(Entree):
    date_facture: date
    taux_tva_pct: float


class PaiementEntree(Entree):
    date_paiement: date
    montant_eur: float
    mode: str
    reference: str | None = None


def _creer(ctx, modele, nom_entite, **data):
    o = modele(exploitation_id=ctx.exploitation_id, **data)
    ctx.db.add(o)
    ctx.db.flush()
    journaliser(ctx, "creation", nom_entite, o.id, apres=instantane(o))
    return o


# ---- Tiers ----
@router.get(E + "/fournisseurs")
def lister_fournisseurs(ctx: Contexte = Depends(autoriser("achats:lire"))):
    return liste(ctx.db.scalars(select(Fournisseur).where(Fournisseur.exploitation_id == ctx.exploitation_id).order_by(Fournisseur.nom)))


@router.post(E + "/fournisseurs", status_code=201)
def creer_fournisseur(e: TiersEntree, ctx: Contexte = Depends(autoriser("achats:ecrire"))):
    o = _creer(ctx, Fournisseur, "fournisseur", **e.model_dump(exclude_none=True))
    ctx.db.commit()
    return en_dict(o)


@router.get(E + "/clients")
def lister_clients(ctx: Contexte = Depends(autoriser("ventes:lire"))):
    return liste(ctx.db.scalars(select(Client).where(Client.exploitation_id == ctx.exploitation_id).order_by(Client.nom)))


@router.post(E + "/clients", status_code=201)
def creer_client(e: TiersEntree, ctx: Contexte = Depends(autoriser("ventes:ecrire"))):
    o = _creer(ctx, Client, "client", **e.model_dump(exclude_none=True))
    ctx.db.commit()
    return en_dict(o)


# ---- Prix versionnés ----
@router.get(E + "/prix")
def lister_prix(ctx: Contexte = Depends(autoriser("achats:lire")), article_id: uuid.UUID | None = None):
    q = select(PrixArticle).where(PrixArticle.exploitation_id == ctx.exploitation_id)
    if article_id:
        q = q.where(PrixArticle.article_id == article_id)
    return liste(ctx.db.scalars(q.order_by(PrixArticle.article_id, PrixArticle.nature, PrixArticle.version)))


def nouvelle_version_prix(ctx, e: PrixEntree) -> PrixArticle:
    precedent = ctx.db.scalar(select(PrixArticle).where(
        PrixArticle.article_id == e.article_id, PrixArticle.nature == e.nature, PrixArticle.valide_au.is_(None))
        .order_by(PrixArticle.version.desc()))
    version = 1
    if precedent:
        if e.valide_du <= precedent.valide_du:
            raise ErreurMetier("donnee_invalide", detail="la nouvelle version doit commencer après la précédente")
        precedent.valide_au = e.valide_du - timedelta(days=1)
        version = precedent.version + 1
    return _creer(ctx, PrixArticle, "prix_article", version=version, **e.model_dump())


@router.post(E + "/prix", status_code=201)
def creer_prix(e: PrixEntree, ctx: Contexte = Depends(autoriser("achats:ecrire"))):
    obtenir(ctx, Article, e.article_id, "Article")
    p = nouvelle_version_prix(ctx, e)
    ctx.db.commit()
    return en_dict(p)


def prix_a_date(db, article_id, nature, jour: date) -> PrixArticle | None:
    return db.scalar(select(PrixArticle).where(
        PrixArticle.article_id == article_id, PrixArticle.nature == nature, PrixArticle.valide_du <= jour,
        (PrixArticle.valide_au.is_(None)) | (PrixArticle.valide_au >= jour)).order_by(PrixArticle.version.desc()))


# ---- Achats ----
@router.get(E + "/demandes-achat")
def lister_demandes(ctx: Contexte = Depends(autoriser("achats:lire"))):
    return liste(ctx.db.scalars(select(DemandeAchat).where(DemandeAchat.exploitation_id == ctx.exploitation_id).order_by(DemandeAchat.cree_le.desc())))


@router.post(E + "/demandes-achat", status_code=201)
def creer_demande(e: DemandeEntree, ctx: Contexte = Depends(autoriser("achats:ecrire"))):
    d = _creer(ctx, DemandeAchat, "demande_achat", numero=numero_formate(ctx.db, ctx.exploitation_id, "DA", date.today().year),
               motif=e.motif, demandeur_id=ctx.utilisateur.id, origine=e.origine,
               lignes=[{k: (str(v) if isinstance(v, (uuid.UUID, date)) else v) for k, v in l.model_dump().items()} for l in e.lignes])
    ctx.db.commit()
    return en_dict(d)


@router.post(E + "/demandes-achat/{demande_id}/approbation")
def approuver_demande(demande_id: uuid.UUID, ctx: Contexte = Depends(autoriser("achats:ecrire"))):
    d = obtenir(ctx, DemandeAchat, demande_id, "Demande d'achat")
    if d.statut != "soumise":
        raise Conflit("commande_statut", statut=d.statut)
    d.statut = "approuvee"
    journaliser(ctx, "approbation", "demande_achat", d.id)
    ctx.db.commit()
    return en_dict(d)


def detail_commande_f(ctx, c: CommandeFournisseur) -> dict:
    lignes = []
    for l in ctx.db.scalars(select(LigneCommandeFournisseur).where(LigneCommandeFournisseur.commande_id == c.id)):
        a = ctx.db.get(Article, l.article_id)
        lignes.append(en_dict(l, article=a.libelle, reste_a_recevoir=float(Decimal(l.quantite) - Decimal(l.quantite_recue))))
    f = ctx.db.get(Fournisseur, c.fournisseur_id)
    recs = liste(ctx.db.scalars(select(Reception).where(Reception.commande_id == c.id)))
    facts = liste(ctx.db.scalars(select(FactureFournisseur).where(FactureFournisseur.commande_id == c.id)))
    return en_dict(c, fournisseur=f.nom, lignes=lignes, receptions=recs, factures=facts,
                   montant_ht_eur=float(sum(Decimal(l["quantite"]) * Decimal(str(l["prix_unitaire_eur"] or 0)) for l in lignes)))


@router.get(E + "/commandes-fournisseurs")
def lister_commandes_f(ctx: Contexte = Depends(autoriser("achats:lire"))):
    return [detail_commande_f(ctx, c) for c in ctx.db.scalars(select(CommandeFournisseur).where(
        CommandeFournisseur.exploitation_id == ctx.exploitation_id).order_by(CommandeFournisseur.date_commande.desc()))]


@router.post(E + "/commandes-fournisseurs", status_code=201)
def creer_commande_f(e: CommandeFEntree, ctx: Contexte = Depends(autoriser("achats:ecrire"))):
    obtenir(ctx, Fournisseur, e.fournisseur_id, "Fournisseur")
    if e.demande_id:
        d = obtenir(ctx, DemandeAchat, e.demande_id, "Demande d'achat")
        if d.statut not in ("approuvee", "soumise"):
            raise Conflit("commande_statut", statut=d.statut)
        d.statut = "commandee"
    c = _creer(ctx, CommandeFournisseur, "commande_fournisseur",
               numero=numero_formate(ctx.db, ctx.exploitation_id, "CF", e.date_commande.year),
               fournisseur_id=e.fournisseur_id, demande_id=e.demande_id, date_commande=e.date_commande,
               date_livraison_prevue=e.date_livraison_prevue)
    for l in e.lignes:
        obtenir(ctx, Article, l.article_id, "Article")
        ctx.db.add(LigneCommandeFournisseur(commande_id=c.id, **l.model_dump()))
    ctx.db.commit()
    return detail_commande_f(ctx, c)


@router.post(E + "/commandes-fournisseurs/{commande_id}/receptions", status_code=201)
def receptionner(commande_id: uuid.UUID, e: ReceptionEntree, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    c = obtenir(ctx, CommandeFournisseur, commande_id, "Commande fournisseur")
    if c.statut not in ("envoyee", "partiellement_recue"):
        raise Conflit("commande_statut", statut=c.statut)
    quand = e.date_reception or maintenant()
    lignes_rec = []
    for lr in e.lignes:
        lc = ctx.db.get(LigneCommandeFournisseur, lr.ligne_commande_id)
        if not lc or lc.commande_id != c.id:
            raise ErreurMetier("donnee_invalide", detail="ligne de commande inconnue")
        a = ctx.db.get(Article, lc.article_id)
        S.verifier_emplacement(ctx, lr.emplacement_id)
        q = S.en_unite_stock(a, lr.quantite, lr.unite)
        cout = None
        if lc.prix_unitaire_eur is not None:
            cout = Decimal(lc.prix_unitaire_eur) / convertir(1, lc.unite, a.unite_stock)
        lot = S.creer_lot(ctx, a, origine="achat", fournisseur_id=c.fournisseur_id, date_entree=quand.date(),
                          numero_lot_fournisseur=lr.numero_lot_fournisseur, date_peremption=lr.date_peremption,
                          quantite_initiale=q, cout_unitaire=cout, statut="libre")
        m = S.enregistrer_mouvement(ctx, "reception", lot, lr.emplacement_id, q, unite_saisie=lr.unite,
                                    quantite_saisie=Decimal(str(lr.quantite)), reference_type="commande_fournisseur",
                                    reference_id=c.id, motif=f"Réception {c.numero}", horodatage=quand, cout_unitaire=cout)
        lc.quantite_recue = Decimal(lc.quantite_recue or 0) + convertir(lr.quantite, lr.unite, lc.unite)
        lignes_rec.append({"ligne_commande_id": str(lc.id), "lot_id": str(lot.id), "lot": lot.numero,
                           "mouvement_id": str(m.id), "quantite": float(q), "unite": a.unite_stock})
    ctx.db.flush()
    toutes = ctx.db.scalars(select(LigneCommandeFournisseur).where(LigneCommandeFournisseur.commande_id == c.id)).all()
    c.statut = "recue" if all(Decimal(l.quantite_recue) >= Decimal(l.quantite) for l in toutes) else "partiellement_recue"
    c.version += 1
    r = _creer(ctx, Reception, "reception", commande_id=c.id, date_reception=quand, bon_livraison=e.bon_livraison,
               recu_par=ctx.utilisateur.id, lignes=lignes_rec, reserves=e.reserves)
    ctx.db.commit()
    return en_dict(r, statut_commande=c.statut)


@router.get(E + "/factures-fournisseurs")
def lister_factures_f(ctx: Contexte = Depends(autoriser("achats:lire"))):
    return liste(ctx.db.scalars(select(FactureFournisseur).where(FactureFournisseur.exploitation_id == ctx.exploitation_id).order_by(FactureFournisseur.date_facture.desc())))


@router.post(E + "/factures-fournisseurs", status_code=201)
def creer_facture_f(e: FactureFEntree, ctx: Contexte = Depends(autoriser("achats:ecrire"))):
    obtenir(ctx, Fournisseur, e.fournisseur_id, "Fournisseur")
    f = _creer(ctx, FactureFournisseur, "facture_fournisseur", **e.model_dump())
    ctx.db.commit()
    return en_dict(f)


# ---- Ventes ----
def detail_commande_c(ctx, c: CommandeClient) -> dict:
    lignes = []
    for l in ctx.db.scalars(select(LigneCommandeClient).where(LigneCommandeClient.commande_id == c.id)):
        a = ctx.db.get(Article, l.article_id)
        allocs = []
        for al in ctx.db.scalars(select(Allocation).where(Allocation.ligne_id == l.id)):
            lot = ctx.db.get(LotStock, al.lot_id)
            allocs.append(en_dict(al, lot=lot.numero))
        alloue = sum(Decimal(str(x["quantite"])) for x in allocs)
        lignes.append(en_dict(l, article=a.libelle, allocations=allocs, quantite_allouee=float(alloue),
                              reste_a_expedier=float(Decimal(l.quantite) - Decimal(l.quantite_expediee))))
    cl = ctx.db.get(Client, c.client_id)
    exps = liste(ctx.db.scalars(select(Expedition).where(Expedition.commande_id == c.id).order_by(Expedition.horodatage)))
    facts = []
    for f in ctx.db.scalars(select(Facture).where(Facture.commande_id == c.id)):
        payes = sum(Decimal(p.montant_eur) for p in ctx.db.scalars(select(Paiement).where(Paiement.facture_id == f.id)))
        facts.append(en_dict(f, montant_paye_eur=float(payes), reste_du_eur=float(Decimal(f.montant_ttc_eur) - payes)))
    return en_dict(c, client=cl.nom, lignes=lignes, expeditions=exps, factures=facts,
                   montant_ht_eur=float(sum(Decimal(str(l["quantite"])) * Decimal(str(l["prix_unitaire_eur"])) for l in lignes)))


@router.get(E + "/commandes-clients")
def lister_commandes_c(ctx: Contexte = Depends(autoriser("ventes:lire"))):
    return [detail_commande_c(ctx, c) for c in ctx.db.scalars(select(CommandeClient).where(
        CommandeClient.exploitation_id == ctx.exploitation_id).order_by(CommandeClient.date_commande.desc()))]


@router.get(E + "/commandes-clients/{commande_id}")
def lire_commande_c(commande_id: uuid.UUID, ctx: Contexte = Depends(autoriser("ventes:lire"))):
    return detail_commande_c(ctx, obtenir(ctx, CommandeClient, commande_id, "Commande client"))


@router.post(E + "/commandes-clients", status_code=201)
def creer_commande_c(e: CommandeCEntree, ctx: Contexte = Depends(autoriser("ventes:ecrire"))):
    obtenir(ctx, Client, e.client_id, "Client")
    c = _creer(ctx, CommandeClient, "commande_client", numero=numero_formate(ctx.db, ctx.exploitation_id, "CC", e.date_commande.year),
               client_id=e.client_id, date_commande=e.date_commande, date_livraison_souhaitee=e.date_livraison_souhaitee)
    for l in e.lignes:
        obtenir(ctx, Article, l.article_id, "Article")
        ctx.db.add(LigneCommandeClient(commande_id=c.id, **l.model_dump()))
    ctx.db.commit()
    return detail_commande_c(ctx, c)


@router.post(E + "/commandes-clients/{commande_id}/allocations", status_code=201)
def allouer(commande_id: uuid.UUID, e: AllocationEntree, ctx: Contexte = Depends(autoriser("ventes:ecrire"))):
    c = obtenir(ctx, CommandeClient, commande_id, "Commande client")
    if c.statut not in ("confirmee", "allouee", "partiellement_expediee"):
        raise Conflit("commande_statut", statut=c.statut)
    for al in e.lignes:
        l = ctx.db.get(LigneCommandeClient, al.ligne_id)
        if not l or l.commande_id != c.id:
            raise ErreurMetier("donnee_invalide", detail="ligne de commande inconnue")
        lot = obtenir(ctx, LotStock, al.lot_id, "Lot")
        if lot.article_id != l.article_id:
            raise ErreurMetier("donnee_invalide", detail="le lot ne correspond pas à l'article commandé")
        if not lot.apte_vente:
            raise Conflit("donnee_invalide", detail=f"le lot {lot.numero} n'a pas été déclaré apte à la vente")
        a = ctx.db.get(Article, l.article_id)
        r = S.reserver(ctx, a.id, al.quantite, l.unite, "commande_client", c.id, lot_id=lot.id, emplacement_id=al.emplacement_id)
        ctx.db.add(Allocation(ligne_id=l.id, lot_id=lot.id, emplacement_id=al.emplacement_id, quantite=r.quantite, reservation_id=r.id))
    c.statut = "allouee"
    c.version += 1
    ctx.db.commit()
    return detail_commande_c(ctx, c)


@router.post(E + "/commandes-clients/{commande_id}/expeditions", status_code=201)
def expedier(commande_id: uuid.UUID, e: ExpeditionEntree, ctx: Contexte = Depends(autoriser("ventes:ecrire"))):
    c = obtenir(ctx, CommandeClient, commande_id, "Commande client")
    if c.statut not in ("allouee", "partiellement_expediee"):
        raise Conflit("commande_statut", statut=c.statut)
    numero = numero_formate(ctx.db, ctx.exploitation_id, "EXP", date.today().year)
    quand = e.horodatage or maintenant()
    ex_id = uuid.uuid4()
    lignes = []
    for el in e.lignes:
        al = ctx.db.get(Allocation, el.allocation_id)
        l = ctx.db.get(LigneCommandeClient, al.ligne_id) if al else None
        if not al or l.commande_id != c.id:
            raise ErreurMetier("donnee_invalide", detail="allocation inconnue")
        q = Decimal(str(el.quantite))
        reste = Decimal(al.quantite) - Decimal(al.quantite_expediee)
        if q > reste:
            raise ErreurMetier("expedition_excessive")
        res = ctx.db.get(Reservation, al.reservation_id) if al.reservation_id else None
        a = ctx.db.get(Article, l.article_id)
        mvts = S.consommer(ctx, a.id, q, a.unite_stock, reservation=res, lot_id=al.lot_id, emplacement_id=al.emplacement_id,
                           reference_type="expedition", reference_id=ex_id, motif=f"Expédition {numero} ({c.numero})", horodatage=quand,
                           type_="expedition")
        if res:
            restant = Decimal(res.quantite) - q
            if restant > 0:
                res.statut, res.quantite = "active", restant
        al.quantite_expediee = Decimal(al.quantite_expediee) + q
        l.quantite_expediee = Decimal(l.quantite_expediee) + convertir(q, a.unite_stock, l.unite)
        lignes.append({"allocation_id": str(al.id), "lot_id": str(al.lot_id), "quantite": float(q), "unite": a.unite_stock,
                       "mouvement_id": str(mvts[0].id)})
    ex = _creer(ctx, Expedition, "expedition", id=ex_id, numero=numero, commande_id=c.id, horodatage=quand,
                transporteur=e.transporteur, lignes=lignes, notes=e.notes)
    toutes = ctx.db.scalars(select(LigneCommandeClient).where(LigneCommandeClient.commande_id == c.id)).all()
    c.statut = "expediee" if all(Decimal(x.quantite_expediee) >= Decimal(x.quantite) for x in toutes) else "partiellement_expediee"
    c.version += 1
    ctx.db.commit()
    return en_dict(ex, statut_commande=c.statut)


@router.post(E + "/commandes-clients/{commande_id}/factures", status_code=201)
def facturer(commande_id: uuid.UUID, e: FactureEntree, ctx: Contexte = Depends(autoriser("ventes:ecrire"))):
    c = obtenir(ctx, CommandeClient, commande_id, "Commande client")
    deja = set()
    for f in ctx.db.scalars(select(Facture).where(Facture.commande_id == c.id)):
        deja |= set(f.expedition_ids)
    exps = [x for x in ctx.db.scalars(select(Expedition).where(Expedition.commande_id == c.id)) if str(x.id) not in deja]
    if not exps:
        raise Conflit("donnee_invalide", detail="aucune expédition non facturée")
    ht = Decimal(0)
    for ex in exps:
        for li in ex.lignes:
            al = ctx.db.get(Allocation, uuid.UUID(li["allocation_id"]))
            l = ctx.db.get(LigneCommandeClient, al.ligne_id)
            a = ctx.db.get(Article, l.article_id)
            ht += convertir(li["quantite"], a.unite_stock, l.unite) * Decimal(l.prix_unitaire_eur)
    ht = ht.quantize(Decimal("0.01"))
    tva = (ht * Decimal(str(e.taux_tva_pct)) / 100).quantize(Decimal("0.01"))
    f = _creer(ctx, Facture, "facture", numero=numero_formate(ctx.db, ctx.exploitation_id, "FAC", e.date_facture.year),
               commande_id=c.id, expedition_ids=[str(x.id) for x in exps], date_facture=e.date_facture,
               montant_ht_eur=ht, taux_tva_pct=Decimal(str(e.taux_tva_pct)), montant_ttc_eur=ht + tva)
    if c.statut == "expediee":
        c.statut = "facturee"
    ctx.db.commit()
    return en_dict(f, avertissement="Pièce de gestion émise par Terroir. Le taux de TVA est celui saisi ; la conformité fiscale relève de votre outil comptable.")


@router.post(E + "/factures/{facture_id}/paiements", status_code=201)
def payer(facture_id: uuid.UUID, e: PaiementEntree, ctx: Contexte = Depends(autoriser("ventes:ecrire"))):
    f = obtenir(ctx, Facture, facture_id, "Facture")
    p = _creer(ctx, Paiement, "paiement", facture_id=f.id, **e.model_dump())
    ctx.db.flush()
    total = sum(Decimal(x.montant_eur) for x in ctx.db.scalars(select(Paiement).where(Paiement.facture_id == f.id)))
    f.statut = "payee" if total >= Decimal(f.montant_ttc_eur) else "partiellement_payee"
    c = ctx.db.get(CommandeClient, f.commande_id)
    if f.statut == "payee" and c.statut == "facturee":
        c.statut = "payee"
    ctx.db.commit()
    return en_dict(p, statut_facture=f.statut)


@router.get(E + "/factures")
def lister_factures(ctx: Contexte = Depends(autoriser("ventes:lire"))):
    return liste(ctx.db.scalars(select(Facture).where(Facture.exploitation_id == ctx.exploitation_id).order_by(Facture.date_facture.desc())))
