import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin, VersionMixin


class Fournisseur(IdMixin, HorodatageMixin, Base):
    __tablename__ = "fournisseur"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    nom: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(30), default="fournisseur")  # fournisseur|prestataire|cooperative
    contact: Mapped[str | None] = mapped_column(Text)


class Client(IdMixin, HorodatageMixin, Base):
    __tablename__ = "client"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    nom: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(30), default="professionnel")  # professionnel|particulier|cooperative|negoce
    contact: Mapped[str | None] = mapped_column(Text)


class PrixArticle(IdMixin, HorodatageMixin, Base):
    """Prix versionné : chaque changement crée une nouvelle version datée."""

    __tablename__ = "prix_article"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    article_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("article.id"), index=True)
    nature: Mapped[str] = mapped_column(String(20))  # achat|vente|valorisation
    prix_unitaire_eur: Mapped[Decimal]
    unite: Mapped[str] = mapped_column(String(10))
    valide_du: Mapped[date]
    valide_au: Mapped[date | None]
    version: Mapped[int] = mapped_column(default=1)
    source: Mapped[str | None] = mapped_column(String(200))


class DemandeAchat(IdMixin, HorodatageMixin, Base):
    __tablename__ = "demande_achat"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    numero: Mapped[str] = mapped_column(String(30))
    motif: Mapped[str | None] = mapped_column(Text)
    demandeur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    statut: Mapped[str] = mapped_column(String(20), default="soumise")  # soumise|approuvee|refusee|commandee
    lignes: Mapped[list] = mapped_column(default=list)  # [{article_id, quantite, unite, date_besoin}]
    origine: Mapped[str | None] = mapped_column(String(40))  # manuel | calcul_besoins


class CommandeFournisseur(IdMixin, HorodatageMixin, VersionMixin, Base):
    __tablename__ = "commande_fournisseur"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    numero: Mapped[str] = mapped_column(String(30))
    fournisseur_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("fournisseur.id"))
    demande_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("demande_achat.id", ondelete="SET NULL"))
    date_commande: Mapped[date]
    date_livraison_prevue: Mapped[date | None]
    statut: Mapped[str] = mapped_column(String(25), default="envoyee")  # brouillon|envoyee|partiellement_recue|recue|annulee


class LigneCommandeFournisseur(IdMixin, Base):
    __tablename__ = "ligne_commande_fournisseur"
    commande_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("commande_fournisseur.id", ondelete="CASCADE"), index=True)
    article_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("article.id"))
    quantite: Mapped[Decimal]
    unite: Mapped[str] = mapped_column(String(10))
    prix_unitaire_eur: Mapped[Decimal | None]
    quantite_recue: Mapped[Decimal] = mapped_column(default=0)


class Reception(IdMixin, HorodatageMixin, Base):
    __tablename__ = "reception"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    commande_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("commande_fournisseur.id"))
    date_reception: Mapped[datetime]
    bon_livraison: Mapped[str | None] = mapped_column(String(60))
    recu_par: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    lignes: Mapped[list] = mapped_column(default=list)  # [{ligne_commande_id, lot_id, mouvement_id, quantite}]
    reserves: Mapped[str | None] = mapped_column(Text)


class FactureFournisseur(IdMixin, HorodatageMixin, Base):
    """Référence d'une facture fournisseur ou prestataire (pièce comptable tenue ailleurs)."""

    __tablename__ = "facture_fournisseur"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    fournisseur_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("fournisseur.id"))
    commande_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("commande_fournisseur.id"))
    numero_fournisseur: Mapped[str] = mapped_column(String(60))
    date_facture: Mapped[date]
    montant_ht_eur: Mapped[Decimal]
    montant_tva_eur: Mapped[Decimal] = mapped_column(default=0)
    categorie_charge: Mapped[str] = mapped_column(String(30), default="intrants")  # intrants|prestataires|materiel|carburant|stockage|emballages|indirectes
    imputation_type: Mapped[str | None] = mapped_column(String(30))  # cycle|parcelle|lot_animaux|activite
    imputation_id: Mapped[uuid.UUID | None]
    document_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("document.id", ondelete="SET NULL"))
    date_paiement: Mapped[date | None]


class CommandeClient(IdMixin, HorodatageMixin, VersionMixin, Base):
    __tablename__ = "commande_client"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    numero: Mapped[str] = mapped_column(String(30))
    client_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("client.id"))
    date_commande: Mapped[date]
    date_livraison_souhaitee: Mapped[date | None]
    statut: Mapped[str] = mapped_column(String(25), default="confirmee")  # confirmee|allouee|partiellement_expediee|expediee|facturee|payee|annulee


class LigneCommandeClient(IdMixin, Base):
    __tablename__ = "ligne_commande_client"
    commande_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("commande_client.id", ondelete="CASCADE"), index=True)
    article_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("article.id"))
    quantite: Mapped[Decimal]
    unite: Mapped[str] = mapped_column(String(10))
    prix_unitaire_eur: Mapped[Decimal]
    quantite_expediee: Mapped[Decimal] = mapped_column(default=0)


class Allocation(IdMixin, HorodatageMixin, Base):
    __tablename__ = "allocation"
    ligne_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("ligne_commande_client.id", ondelete="CASCADE"), index=True)
    lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lot_stock.id"))
    emplacement_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("emplacement.id"))
    quantite: Mapped[Decimal]
    quantite_expediee: Mapped[Decimal] = mapped_column(default=0)
    reservation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("reservation.id", ondelete="SET NULL"))


class Expedition(IdMixin, HorodatageMixin, Base):
    __tablename__ = "expedition"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    numero: Mapped[str] = mapped_column(String(30))
    commande_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("commande_client.id"))
    horodatage: Mapped[datetime]
    transporteur: Mapped[str | None] = mapped_column(String(200))
    lignes: Mapped[list] = mapped_column(default=list)  # [{allocation_id, lot_id, quantite, unite, mouvement_id}]
    notes: Mapped[str | None] = mapped_column(Text)


class Facture(IdMixin, HorodatageMixin, Base):
    """Facture de vente émise depuis Terroir (pièce de gestion ; la
    conformité fiscale relève de l'outil comptable validé)."""

    __tablename__ = "facture"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    numero: Mapped[str] = mapped_column(String(30))
    commande_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("commande_client.id"))
    expedition_ids: Mapped[list] = mapped_column(default=list)
    date_facture: Mapped[date]
    montant_ht_eur: Mapped[Decimal]
    taux_tva_pct: Mapped[Decimal]
    montant_ttc_eur: Mapped[Decimal]
    statut: Mapped[str] = mapped_column(String(20), default="emise")  # emise|partiellement_payee|payee


class Paiement(IdMixin, HorodatageMixin, Base):
    __tablename__ = "paiement"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    facture_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("facture.id"))
    date_paiement: Mapped[date]
    montant_eur: Mapped[Decimal]
    mode: Mapped[str] = mapped_column(String(20))  # virement|cheque|especes|prelevement
    reference: Mapped[str | None] = mapped_column(String(80))
