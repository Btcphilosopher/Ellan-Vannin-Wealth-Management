import uuid
from datetime import date

from fastapi import APIRouter, Depends
from pydantic import Field
from app.core.schemas import Entree
from sqlalchemy import func, select, text

from app.core.audit import instantane, journaliser
from app.core.config import get_settings
from app.core.crud import appliquer, obtenir, verifier_version
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.modules.cultures.models import Campagne, CycleCultural
from app.modules.foncier import geometrie as geo
from app.modules.foncier.models import EquipementIrrigation, Parcelle, ReferenceCadastrale, Site, ZoneGestion

router = APIRouter(tags=["Foncier : sites, parcelles, zones"])


class SiteEntree(Entree):
    nom: str
    commune: str | None = None
    code_insee: str | None = None
    fuseau_horaire: str = "Europe/Paris"
    adresse: str | None = None


class GeometrieEntree(Entree):
    geojson: dict = Field(description="Polygon ou MultiPolygon GeoJSON (ou Feature)")
    srid: int = Field(4326, description="Code EPSG du système de coordonnées des coordonnées fournies")
    source: str = Field(description="Provenance : relevé GPS, import RPG, dessin sur orthophoto…")
    methode: str | None = None
    date_acquisition: date | None = None
    precision_m: float | None = None


class ParcelleEntree(Entree):
    site_id: uuid.UUID
    code: str
    nom: str
    surface_declaree_ha: float | None = None
    source_surface_declaree: str | None = None
    mode_faire_valoir: str = "propriete"
    proprietaire: str | None = None
    bail_echeance: date | None = None
    acces: str | None = None
    sol: dict | None = None
    restrictions: list = []
    irrigable: bool = False
    notes: str | None = None
    geometrie: GeometrieEntree | None = None


class ParcelleMaj(Entree):
    version: int
    nom: str | None = None
    surface_declaree_ha: float | None = None
    source_surface_declaree: str | None = None
    mode_faire_valoir: str | None = None
    proprietaire: str | None = None
    bail_echeance: date | None = None
    acces: str | None = None
    sol: dict | None = None
    restrictions: list | None = None
    irrigable: bool | None = None
    notes: str | None = None


class CadastreEntree(Entree):
    code_insee: str
    prefixe: str = "000"
    section: str
    numero: str
    surface_cadastrale_ha: float | None = None
    surface_exploitee_ha: float | None = None
    source: str | None = None


class ZoneEntree(Entree):
    nom: str
    nature: str = "temporaire"
    motif: str | None = None
    date_debut: date | None = None
    date_fin: date | None = None
    geometrie: GeometrieEntree


class EquipementEntree(Entree):
    parcelle_id: uuid.UUID | None = None
    nom: str
    type: str
    debit_nominal: float | None = None
    unite_debit: str = "m3/h"
    efficience_pct: float | None = None
    source_efficience: str | None = None
    compteur_numero: str | None = None
    point_prelevement: str | None = None


def appliquer_geometrie(obj, g: GeometrieEntree, auteur: str):
    mp, wkt = geo.lire_geometrie(g.geojson, g.srid)
    obj.geometrie = geo.vers_db(mp)
    obj.surface_calculee_ha = geo.surface_geodesique_ha(mp)
    if hasattr(obj, "geometrie_origine_wkt"):
        obj.geometrie_origine_wkt = wkt
        obj.srid_origine = g.srid
    obj.provenance_geometrie = {
        "source": g.source, "methode": g.methode, "srid_origine": g.srid,
        "systeme": geo.SRID_ACCEPTES[g.srid],
        "date_acquisition": g.date_acquisition.isoformat() if g.date_acquisition else None,
        "precision_m": g.precision_m, "saisie_par": auteur,
    }
    return mp


def parcelle_detaillee(ctx: Contexte, p: Parcelle) -> dict:
    d = en_dict(p, exclure=("geometrie_origine_wkt",))
    d["ecart_surface"] = geo.ecart_surface(p.surface_declaree_ha, p.surface_calculee_ha,
                                           get_settings().tolerance_ecart_surface_pct)
    return d


@router.get("/exploitations/{exploitation_id}/sites")
def lister_sites(ctx: Contexte = Depends(autoriser("foncier:lire"))):
    return liste(ctx.db.scalars(select(Site).where(Site.exploitation_id == ctx.exploitation_id).order_by(Site.nom)))


@router.post("/exploitations/{exploitation_id}/sites", status_code=201)
def creer_site(e: SiteEntree, ctx: Contexte = Depends(autoriser("foncier:ecrire"))):
    from zoneinfo import ZoneInfo

    ZoneInfo(e.fuseau_horaire)  # lève une erreur si le fuseau est inconnu
    s = Site(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(s)
    ctx.db.flush()
    journaliser(ctx, "creation", "site", s.id, apres=instantane(s))
    ctx.db.commit()
    return en_dict(s)


@router.get("/exploitations/{exploitation_id}/parcelles")
def lister_parcelles(ctx: Contexte = Depends(autoriser("foncier:lire")), site_id: uuid.UUID | None = None):
    q = select(Parcelle).where(Parcelle.exploitation_id == ctx.exploitation_id, Parcelle.active.is_(True))
    if site_id:
        q = q.where(Parcelle.site_id == site_id)
    return [parcelle_detaillee(ctx, p) for p in ctx.db.scalars(q.order_by(Parcelle.code))]


@router.post("/exploitations/{exploitation_id}/parcelles", status_code=201)
def creer_parcelle(e: ParcelleEntree, ctx: Contexte = Depends(autoriser("foncier:ecrire"))):
    obtenir(ctx, Site, e.site_id, "Site")
    d = e.model_dump(exclude={"geometrie"})
    p = Parcelle(exploitation_id=ctx.exploitation_id, **d)
    if e.geometrie:
        appliquer_geometrie(p, e.geometrie, ctx.utilisateur.nom_affiche)
    ctx.db.add(p)
    ctx.db.flush()
    journaliser(ctx, "creation", "parcelle", p.id, apres=instantane(p))
    ctx.db.commit()
    return parcelle_detaillee(ctx, p) | {"chevauchements": chevauchements(ctx, p.id)}


@router.get("/exploitations/{exploitation_id}/parcelles/{parcelle_id}")
def detail_parcelle(parcelle_id: uuid.UUID, ctx: Contexte = Depends(autoriser("foncier:lire"))):
    p = obtenir(ctx, Parcelle, parcelle_id, "Parcelle")
    d = parcelle_detaillee(ctx, p)
    d["references_cadastrales"] = liste(ctx.db.scalars(select(ReferenceCadastrale).where(ReferenceCadastrale.parcelle_id == p.id)), exclure=("geometrie",))
    d["zones"] = liste(ctx.db.scalars(select(ZoneGestion).where(ZoneGestion.parcelle_id == p.id)))
    d["equipements_irrigation"] = liste(ctx.db.scalars(select(EquipementIrrigation).where(EquipementIrrigation.parcelle_id == p.id)))
    d["historique_cultural"] = historique_cultural(ctx, p.id)
    d["chevauchements"] = chevauchements(ctx, p.id)
    total_cad = sum(float(r["surface_exploitee_ha"] or r["surface_cadastrale_ha"] or 0) for r in d["references_cadastrales"])
    d["comparaison_cadastre"] = {
        "surface_cadastrale_exploitee_ha": round(total_cad, 4) if d["references_cadastrales"] else None,
        "note": "Les références cadastrales sont administratives ; la limite opérationnelle peut légitimement différer.",
    }
    return d


@router.patch("/exploitations/{exploitation_id}/parcelles/{parcelle_id}")
def modifier_parcelle(parcelle_id: uuid.UUID, e: ParcelleMaj, ctx: Contexte = Depends(autoriser("foncier:ecrire"))):
    p = obtenir(ctx, Parcelle, parcelle_id, "Parcelle")
    verifier_version(p, e.version)
    avant = instantane(p)
    appliquer(p, e.model_dump(exclude_unset=True, exclude={"version"}))
    journaliser(ctx, "modification", "parcelle", p.id, avant=avant, apres=instantane(p))
    ctx.db.commit()
    return parcelle_detaillee(ctx, p)


@router.put("/exploitations/{exploitation_id}/parcelles/{parcelle_id}/geometrie")
def remplacer_geometrie(parcelle_id: uuid.UUID, g: GeometrieEntree, ctx: Contexte = Depends(autoriser("foncier:ecrire"))):
    p = obtenir(ctx, Parcelle, parcelle_id, "Parcelle")
    avant = {"provenance": p.provenance_geometrie, "surface_calculee_ha": p.surface_calculee_ha,
             "wkt_origine": p.geometrie_origine_wkt, "srid_origine": p.srid_origine}
    appliquer_geometrie(p, g, ctx.utilisateur.nom_affiche)
    p.version += 1
    journaliser(ctx, "modification_geometrie", "parcelle", p.id, avant=avant,
                apres={"provenance": p.provenance_geometrie, "surface_calculee_ha": p.surface_calculee_ha})
    ctx.db.commit()
    return parcelle_detaillee(ctx, p) | {"chevauchements": chevauchements(ctx, p.id)}


def chevauchements(ctx: Contexte, parcelle_id) -> list[dict]:
    rows = ctx.db.execute(text("""
        SELECT o.id, o.code, o.nom,
               ST_Area(ST_Intersection(p.geometrie, o.geometrie)::geography) / 10000 AS surface_ha
        FROM parcelle p JOIN parcelle o
          ON o.exploitation_id = p.exploitation_id AND o.id <> p.id AND o.active
         AND ST_Intersects(p.geometrie, o.geometrie)
        WHERE p.id = :id
    """), {"id": parcelle_id}).mappings()
    return [{"parcelle_id": str(r["id"]), "code": r["code"], "nom": r["nom"],
             "surface_ha": round(float(r["surface_ha"]), 4)} for r in rows if r["surface_ha"] > 0.0001]


def historique_cultural(ctx: Contexte, parcelle_id) -> list[dict]:
    rows = ctx.db.execute(select(CycleCultural, Campagne).join(Campagne, Campagne.id == CycleCultural.campagne_id)
                          .where(CycleCultural.parcelle_id == parcelle_id).order_by(Campagne.date_debut)).all()
    return [en_dict(c, campagne=camp.libelle) for c, camp in rows]


@router.post("/exploitations/{exploitation_id}/parcelles/{parcelle_id}/cadastre", status_code=201)
def ajouter_reference_cadastrale(parcelle_id: uuid.UUID, e: CadastreEntree, ctx: Contexte = Depends(autoriser("foncier:ecrire"))):
    obtenir(ctx, Parcelle, parcelle_id, "Parcelle")
    r = ReferenceCadastrale(parcelle_id=parcelle_id, **e.model_dump())
    ctx.db.add(r)
    ctx.db.flush()
    journaliser(ctx, "creation", "reference_cadastrale", r.id, apres=instantane(r))
    ctx.db.commit()
    return en_dict(r, exclure=("geometrie",))


@router.post("/exploitations/{exploitation_id}/parcelles/{parcelle_id}/zones", status_code=201)
def creer_zone(parcelle_id: uuid.UUID, e: ZoneEntree, ctx: Contexte = Depends(autoriser("foncier:ecrire"))):
    from app.core.erreurs import ErreurMetier

    p = obtenir(ctx, Parcelle, parcelle_id, "Parcelle")
    z = ZoneGestion(parcelle_id=p.id, **e.model_dump(exclude={"geometrie"}))
    appliquer_geometrie(z, e.geometrie, ctx.utilisateur.nom_affiche)
    ctx.db.add(z)
    ctx.db.flush()
    if p.geometrie is not None:
        hors = ctx.db.scalar(text("SELECT ST_Area(ST_Difference(z.geometrie, p.geometrie)::geography) FROM zone_gestion z, parcelle p WHERE z.id=:z AND p.id=:p"), {"z": z.id, "p": p.id})
        if hors and hors > 1.0:  # tolérance 1 m²
            ctx.db.rollback()
            raise ErreurMetier("zone_hors_parcelle")
    journaliser(ctx, "creation", "zone_gestion", z.id, apres=instantane(z))
    ctx.db.commit()
    return en_dict(z)


@router.get("/exploitations/{exploitation_id}/equipements-irrigation")
def lister_equipements(ctx: Contexte = Depends(autoriser("foncier:lire"))):
    return liste(ctx.db.scalars(select(EquipementIrrigation).where(EquipementIrrigation.exploitation_id == ctx.exploitation_id)))


@router.post("/exploitations/{exploitation_id}/equipements-irrigation", status_code=201)
def creer_equipement(e: EquipementEntree, ctx: Contexte = Depends(autoriser("foncier:ecrire"))):
    q = EquipementIrrigation(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(q)
    ctx.db.flush()
    journaliser(ctx, "creation", "equipement_irrigation", q.id, apres=instantane(q))
    ctx.db.commit()
    return en_dict(q)


@router.get("/exploitations/{exploitation_id}/carte")
def carte(ctx: Contexte = Depends(autoriser("foncier:lire")), campagne_id: uuid.UUID | None = None):
    """FeatureCollection des parcelles (WGS 84) avec la culture de la campagne."""
    cultures = {}
    if campagne_id:
        for c in ctx.db.scalars(select(CycleCultural).where(CycleCultural.campagne_id == campagne_id)):
            cultures.setdefault(str(c.parcelle_id), []).append(c.culture)
    feats = []
    for p in ctx.db.scalars(select(Parcelle).where(Parcelle.exploitation_id == ctx.exploitation_id, Parcelle.active.is_(True))):
        if p.geometrie is None:
            continue
        d = parcelle_detaillee(ctx, p)
        feats.append({"type": "Feature", "geometry": d.pop("geometrie"), "properties": {
            "id": d["id"], "code": d["code"], "nom": d["nom"], "site_id": d["site_id"],
            "surface_calculee_ha": d["surface_calculee_ha"], "surface_declaree_ha": d["surface_declaree_ha"],
            "ecart_signale": d["ecart_surface"]["signale"], "cultures": cultures.get(d["id"], []),
            "restrictions": d["restrictions"], "mode_faire_valoir": d["mode_faire_valoir"]}})
    zones = []
    for z, p in ctx.db.execute(select(ZoneGestion, Parcelle).join(Parcelle).where(Parcelle.exploitation_id == ctx.exploitation_id)):
        if z.geometrie is not None:
            zd = en_dict(z)
            zones.append({"type": "Feature", "geometry": zd.pop("geometrie"), "properties": zd})
    return {"type": "FeatureCollection", "features": feats, "zones": {"type": "FeatureCollection", "features": zones},
            "crs_note": "Coordonnées WGS 84 (EPSG:4326). Géométries d'origine conservées avec leur système."}
