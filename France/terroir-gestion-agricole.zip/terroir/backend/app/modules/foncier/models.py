import uuid
from datetime import date
from decimal import Decimal

from geoalchemy2 import Geometry
from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin, VersionMixin


class Site(IdMixin, HorodatageMixin, Base):
    __tablename__ = "site"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    nom: Mapped[str] = mapped_column(String(120))
    commune: Mapped[str | None] = mapped_column(String(120))
    code_insee: Mapped[str | None] = mapped_column(String(5))
    fuseau_horaire: Mapped[str] = mapped_column(String(64), default="Europe/Paris")
    adresse: Mapped[str | None] = mapped_column(Text)
    position = mapped_column(Geometry("POINT", srid=4326), nullable=True)


class Parcelle(IdMixin, HorodatageMixin, VersionMixin, Base):
    """Limite opérationnelle (îlot / parcelle culturale gérée par l'exploitation).

    La surface déclarée (administrative) n'est jamais écrasée par la
    surface calculée à partir de la géométrie : l'écart est signalé.
    """

    __tablename__ = "parcelle"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"))
    code: Mapped[str] = mapped_column(String(30))
    nom: Mapped[str] = mapped_column(String(120))
    surface_declaree_ha: Mapped[Decimal | None]
    source_surface_declaree: Mapped[str | None] = mapped_column(String(200))
    surface_calculee_ha: Mapped[Decimal | None]
    geometrie = mapped_column(Geometry("MULTIPOLYGON", srid=4326), nullable=True)
    # Géométrie telle que reçue, dans son système d'origine (traçabilité).
    geometrie_origine_wkt: Mapped[str | None] = mapped_column(Text)
    srid_origine: Mapped[int | None]
    provenance_geometrie: Mapped[dict | None]  # {source, methode, date, precision_m, auteur}
    mode_faire_valoir: Mapped[str] = mapped_column(String(30), default="propriete")  # propriete|fermage|metayage|mise_a_disposition|autre
    proprietaire: Mapped[str | None] = mapped_column(String(200))
    bail_document_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("document.id", ondelete="SET NULL"))
    bail_echeance: Mapped[date | None]
    acces: Mapped[str | None] = mapped_column(Text)
    sol: Mapped[dict | None]  # {texture, ph, mo_pct, profondeur_cm, ru_mm, source, date_analyse}
    restrictions: Mapped[list] = mapped_column(default=list)  # [{type, libelle, source, date}]
    irrigable: Mapped[bool] = mapped_column(default=False)
    active: Mapped[bool] = mapped_column(default=True)
    notes: Mapped[str | None] = mapped_column(Text)


class ReferenceCadastrale(IdMixin, HorodatageMixin, Base):
    """Référence administrative du cadastre (distincte de la limite opérationnelle)."""

    __tablename__ = "reference_cadastrale"
    parcelle_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("parcelle.id", ondelete="CASCADE"), index=True)
    code_insee: Mapped[str] = mapped_column(String(5))
    prefixe: Mapped[str] = mapped_column(String(3), default="000")
    section: Mapped[str] = mapped_column(String(2))
    numero: Mapped[str] = mapped_column(String(4))
    surface_cadastrale_ha: Mapped[Decimal | None]
    surface_exploitee_ha: Mapped[Decimal | None]
    source: Mapped[str | None] = mapped_column(String(200))
    geometrie = mapped_column(Geometry("MULTIPOLYGON", srid=4326), nullable=True)


class ZoneGestion(IdMixin, HorodatageMixin, Base):
    """Zone opérationnelle permanente ou temporaire à l'intérieur d'une parcelle."""

    __tablename__ = "zone_gestion"
    parcelle_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("parcelle.id", ondelete="CASCADE"), index=True)
    nom: Mapped[str] = mapped_column(String(120))
    nature: Mapped[str] = mapped_column(String(20), default="temporaire")  # permanente | temporaire
    motif: Mapped[str | None] = mapped_column(Text)
    date_debut: Mapped[date | None]
    date_fin: Mapped[date | None]
    geometrie = mapped_column(Geometry("MULTIPOLYGON", srid=4326), nullable=True)
    surface_calculee_ha: Mapped[Decimal | None]
    provenance_geometrie: Mapped[dict | None]


class EquipementIrrigation(IdMixin, HorodatageMixin, Base):
    __tablename__ = "equipement_irrigation"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    parcelle_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("parcelle.id", ondelete="SET NULL"))
    nom: Mapped[str] = mapped_column(String(120))
    type: Mapped[str] = mapped_column(String(40))  # goutte_a_goutte | aspersion | enrouleur | pivot | micro_aspersion
    debit_nominal: Mapped[Decimal | None]
    unite_debit: Mapped[str] = mapped_column(String(10), default="m3/h")
    efficience_pct: Mapped[Decimal | None]
    source_efficience: Mapped[str | None] = mapped_column(String(200))
    compteur_numero: Mapped[str | None] = mapped_column(String(60))
    point_prelevement: Mapped[str | None] = mapped_column(String(200))
