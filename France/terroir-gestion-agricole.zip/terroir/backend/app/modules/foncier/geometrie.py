"""Géométries parcellaires : validation, reprojection, surfaces, écarts."""
from decimal import Decimal

from geoalchemy2.shape import from_shape
from pyproj import CRS, Geod, Transformer
from shapely.geometry import MultiPolygon, Polygon, shape
import numpy as np
import shapely
from shapely.validation import explain_validity

from app.core.erreurs import ErreurMetier
from app.core.format_fr import court

SRID_ACCEPTES = {4326: "WGS 84", 2154: "RGF93 v1 / Lambert-93", 3857: "Web Mercator (déconseillé pour les surfaces)",
                 2975: "RGR92 / UTM 40S (La Réunion)", 32740: "WGS 84 / UTM 40S", 4171: "RGF93 géographique"}
_GEOD = Geod(ellps="WGS84")


def lire_geometrie(geojson: dict, srid: int = 4326) -> tuple[MultiPolygon, str]:
    """Retourne (multipolygone WGS 84, WKT d'origine). Refuse les géométries invalides
    au lieu de les « réparer » silencieusement."""
    if srid not in SRID_ACCEPTES:
        raise ErreurMetier("srid_non_pris_en_charge", srid=srid)
    try:
        g = shape(geojson.get("geometry", geojson))
    except Exception as e:  # noqa: BLE001
        raise ErreurMetier("geometrie_invalide", raison=f"GeoJSON illisible ({e})")
    if isinstance(g, Polygon):
        g = MultiPolygon([g])
    if not isinstance(g, MultiPolygon):
        raise ErreurMetier("geometrie_type")
    if g.is_empty:
        raise ErreurMetier("geometrie_invalide", raison="géométrie vide")
    if not g.is_valid:
        raise ErreurMetier("geometrie_invalide", raison=traduire_validite(explain_validity(g)))
    wkt_origine = g.wkt
    if srid != 4326:
        tr = Transformer.from_crs(CRS.from_epsg(srid), CRS.from_epsg(4326), always_xy=True)
        g = shapely.transform(g, lambda c: np.column_stack(tr.transform(c[:, 0], c[:, 1])))
    minx, miny, maxx, maxy = g.bounds
    if not (-180 <= minx <= 180 and -90 <= miny <= 90 and -180 <= maxx <= 180 and -90 <= maxy <= 90):
        raise ErreurMetier("geometrie_invalide", raison="coordonnées hors limites : vérifiez le système de coordonnées déclaré")
    return g, wkt_origine


def traduire_validite(raison: str) -> str:
    if "Self-intersection" in raison:
        return "la limite se recoupe elle-même (auto-intersection)"
    if "Ring Self-intersection" in raison:
        return "un anneau se recoupe"
    if "Too few points" in raison:
        return "nombre de sommets insuffisant"
    if "Hole lies outside shell" in raison:
        return "un trou est situé hors du contour"
    return raison


def surface_geodesique_ha(g_wgs84) -> Decimal:
    """Surface ellipsoïdale (WGS 84), indépendante de toute projection."""
    aire, _ = _GEOD.geometry_area_perimeter(g_wgs84)
    return Decimal(str(round(abs(aire) / 10000, 4)))


def vers_db(g_wgs84):
    return from_shape(g_wgs84, srid=4326)


def ecart_surface(declaree, calculee, tolerance_pct: float) -> dict:
    if declaree is None or calculee is None:
        return {"signale": False, "message": "Comparaison impossible : surface déclarée ou géométrie manquante.",
                "declaree_ha": float(declaree) if declaree is not None else None,
                "calculee_ha": float(calculee) if calculee is not None else None}
    d, c = Decimal(str(declaree)), Decimal(str(calculee))
    ecart = c - d
    pct = float(ecart / d * 100) if d else None
    signale = pct is None or abs(pct) > tolerance_pct
    return {
        "declaree_ha": float(d), "calculee_ha": float(c), "ecart_ha": float(round(ecart, 4)),
        "ecart_pct": round(pct, 2) if pct is not None else None, "tolerance_pct": tolerance_pct,
        "signale": signale,
        "message": (f"Écart de {court(abs(pct), 1)}\u00a0% entre la surface déclarée et la surface calculée : "
                    "à vérifier. La surface déclarée n'a pas été modifiée.") if signale and pct is not None
        else "Écart dans la tolérance.",
    }
