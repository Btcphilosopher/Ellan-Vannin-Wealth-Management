import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin


class LotAnimaux(IdMixin, HorodatageMixin, Base):
    __tablename__ = "lot_animaux"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    code: Mapped[str] = mapped_column(String(30))
    nom: Mapped[str] = mapped_column(String(120))
    espece: Mapped[str] = mapped_column(String(20))  # ovin|bovin|caprin
    finalite: Mapped[str | None] = mapped_column(String(60))  # reproduction|engraissement|renouvellement
    actif: Mapped[bool] = mapped_column(default=True)


class Animal(IdMixin, HorodatageMixin, Base):
    __tablename__ = "animal"
    __table_args__ = (UniqueConstraint("exploitation_id", "identifiant"),)
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    identifiant: Mapped[str] = mapped_column(String(30))  # fictif en démonstration (préfixe DEMO)
    nom_usage: Mapped[str | None] = mapped_column(String(60))
    espece: Mapped[str] = mapped_column(String(20))
    race: Mapped[str | None] = mapped_column(String(60))
    sexe: Mapped[str] = mapped_column(String(1))  # F | M
    date_naissance: Mapped[date | None]
    mere_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("animal.id"))
    origine: Mapped[str] = mapped_column(String(20))  # naissance|achat
    date_entree: Mapped[date | None]
    statut: Mapped[str] = mapped_column(String(20), default="present")  # present|vendu|mort|sorti
    date_sortie: Mapped[date | None]
    motif_sortie: Mapped[str | None] = mapped_column(String(200))


class AppartenanceLot(IdMixin, Base):
    __tablename__ = "appartenance_lot"
    animal_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("animal.id", ondelete="CASCADE"), index=True)
    lot_animaux_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lot_animaux.id", ondelete="CASCADE"), index=True)
    du: Mapped[date]
    au: Mapped[date | None]


class LocalisationLot(IdMixin, Base):
    __tablename__ = "localisation_lot"
    lot_animaux_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lot_animaux.id", ondelete="CASCADE"), index=True)
    parcelle_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("parcelle.id"))
    batiment: Mapped[str | None] = mapped_column(String(120))
    du: Mapped[datetime]
    au: Mapped[datetime | None]


class EvenementElevage(IdMixin, HorodatageMixin, Base):
    """Événement individuel (animal_id) ou collectif (lot_animaux_id + effectif)."""

    __tablename__ = "evenement_elevage"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    type: Mapped[str] = mapped_column(String(30))  # naissance|achat|mouvement|alimentation|pesee|sanitaire|traitement|vente|mortalite|observation
    portee: Mapped[str] = mapped_column(String(15))  # individuelle | collective
    animal_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("animal.id"), index=True)
    lot_animaux_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("lot_animaux.id"), index=True)
    effectif_concerne: Mapped[int | None]
    horodatage: Mapped[datetime]
    valeurs: Mapped[dict] = mapped_column(default=dict)  # {poids_kg} {article_id, quantite, unite} {observations}
    notes: Mapped[str | None] = mapped_column(Text)
    auteur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    mouvement_stock_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("mouvement_stock.id", ondelete="SET NULL"))
    a_declarer: Mapped[bool] = mapped_column(default=False)
    statut_declaration: Mapped[str] = mapped_column(String(40), default="non_applicable")  # non_applicable|a_preparer|preparee_hors_ligne


class TraitementAnimal(IdMixin, HorodatageMixin, Base):
    """Saisie d'un traitement tel que prescrit. Terroir ne prescrit rien et
    ne calcule aucun délai d'attente : le délai est recopié depuis l'ordonnance."""

    __tablename__ = "traitement_animal"
    evenement_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("evenement_elevage.id", ondelete="CASCADE"), unique=True)
    medicament: Mapped[str] = mapped_column(String(200))
    numero_ordonnance: Mapped[str | None] = mapped_column(String(60))
    prescripteur: Mapped[str | None] = mapped_column(String(200))
    posologie_saisie: Mapped[str | None] = mapped_column(Text)
    voie: Mapped[str | None] = mapped_column(String(60))
    numero_lot_medicament: Mapped[str | None] = mapped_column(String(60))
    delai_attente_viande_saisi: Mapped[str | None] = mapped_column(String(120))
    delai_attente_lait_saisi: Mapped[str | None] = mapped_column(String(120))
    date_fin_attente_saisie: Mapped[date | None]
    saisi_par_role: Mapped[str] = mapped_column(String(40))
