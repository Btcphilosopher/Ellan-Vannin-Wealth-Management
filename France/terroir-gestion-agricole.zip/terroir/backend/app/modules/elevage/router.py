"""Module d'élevage (démonstration ovine/bovine limitée).

Terroir ne prescrit aucun traitement et ne calcule aucun délai d'attente.
Les déclarations officielles (EdE/BDNI) ne sont pas transmises : les
événements concernés sont marqués « à déclarer » et peuvent être exportés
pour une saisie dans un outil agréé.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import func, select

from app.core.audit import instantane, journaliser
from app.core.crud import obtenir
from app.core.db import maintenant
from app.core.erreurs import AccesRefuse, ErreurMetier
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.modules.elevage.models import (Animal, AppartenanceLot, EvenementElevage, LocalisationLot, LotAnimaux,
                                        TraitementAnimal)
from app.modules.stocks import service as S

router = APIRouter(tags=["Élevage"])
E = "/exploitations/{exploitation_id}"
A_DECLARER = {"naissance", "achat", "vente", "mortalite", "mouvement"}


class LotAnimauxEntree(Entree):
    code: str
    nom: str
    espece: str
    finalite: str | None = None


class AnimalEntree(Entree):
    identifiant: str
    nom_usage: str | None = None
    espece: str
    race: str | None = None
    sexe: str
    date_naissance: date | None = None
    mere_id: uuid.UUID | None = None
    origine: str
    date_entree: date | None = None
    lot_animaux_id: uuid.UUID | None = None


class LocalisationEntree(Entree):
    parcelle_id: uuid.UUID | None = None
    batiment: str | None = None
    du: datetime


class EvenementEntree(Entree):
    type: str
    animal_id: uuid.UUID | None = None
    lot_animaux_id: uuid.UUID | None = None
    effectif_concerne: int | None = None
    horodatage: datetime | None = None
    valeurs: dict = {}
    notes: str | None = None


class TraitementEntree(Entree):
    animal_id: uuid.UUID | None = None
    lot_animaux_id: uuid.UUID | None = None
    effectif_concerne: int | None = None
    horodatage: datetime | None = None
    medicament: str
    numero_ordonnance: str | None = None
    prescripteur: str | None = None
    posologie_saisie: str | None = None
    voie: str | None = None
    numero_lot_medicament: str | None = None
    delai_attente_viande_saisi: str | None = None
    delai_attente_lait_saisi: str | None = None
    date_fin_attente_saisie: date | None = None
    notes: str | None = None


def effectif(db, lot_id) -> int:
    return db.scalar(select(func.count()).select_from(AppartenanceLot).join(Animal, Animal.id == AppartenanceLot.animal_id)
                     .where(AppartenanceLot.lot_animaux_id == lot_id, AppartenanceLot.au.is_(None), Animal.statut == "present"))


@router.get(E + "/lots-animaux")
def lister_lots(ctx: Contexte = Depends(autoriser("elevage:lire"))):
    res = []
    for l in ctx.db.scalars(select(LotAnimaux).where(LotAnimaux.exploitation_id == ctx.exploitation_id).order_by(LotAnimaux.code)):
        loc = ctx.db.scalar(select(LocalisationLot).where(LocalisationLot.lot_animaux_id == l.id, LocalisationLot.au.is_(None)))
        res.append(en_dict(l, effectif=effectif(ctx.db, l.id), localisation=en_dict(loc) if loc else None))
    return res


@router.post(E + "/lots-animaux", status_code=201)
def creer_lot(e: LotAnimauxEntree, ctx: Contexte = Depends(autoriser("elevage:ecrire"))):
    l = LotAnimaux(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(l)
    ctx.db.flush()
    journaliser(ctx, "creation", "lot_animaux", l.id, apres=instantane(l))
    ctx.db.commit()
    return en_dict(l)


@router.post(E + "/lots-animaux/{lot_id}/localisation", status_code=201)
def deplacer_lot(lot_id: uuid.UUID, e: LocalisationEntree, ctx: Contexte = Depends(autoriser("elevage:ecrire"))):
    l = obtenir(ctx, LotAnimaux, lot_id, "Lot d'animaux")
    for anc in ctx.db.scalars(select(LocalisationLot).where(LocalisationLot.lot_animaux_id == l.id, LocalisationLot.au.is_(None))):
        anc.au = e.du
    loc = LocalisationLot(lot_animaux_id=l.id, **e.model_dump())
    ctx.db.add(loc)
    ev = EvenementElevage(exploitation_id=ctx.exploitation_id, type="mouvement", portee="collective", lot_animaux_id=l.id,
                          effectif_concerne=effectif(ctx.db, l.id), horodatage=e.du, auteur_id=ctx.utilisateur.id,
                          valeurs={"parcelle_id": str(e.parcelle_id) if e.parcelle_id else None, "batiment": e.batiment,
                                   "interne_exploitation": True})
    ctx.db.add(ev)
    ctx.db.flush()
    journaliser(ctx, "deplacement", "lot_animaux", l.id, apres=instantane(loc))
    ctx.db.commit()
    return en_dict(loc)


@router.get(E + "/animaux")
def lister_animaux(ctx: Contexte = Depends(autoriser("elevage:lire")), lot_animaux_id: uuid.UUID | None = None,
                   statut: str | None = None):
    q = select(Animal).where(Animal.exploitation_id == ctx.exploitation_id)
    if statut:
        q = q.where(Animal.statut == statut)
    if lot_animaux_id:
        q = q.join(AppartenanceLot, AppartenanceLot.animal_id == Animal.id).where(
            AppartenanceLot.lot_animaux_id == lot_animaux_id, AppartenanceLot.au.is_(None))
    res = []
    for a in ctx.db.scalars(q.order_by(Animal.identifiant)):
        der = ctx.db.scalar(select(EvenementElevage).where(EvenementElevage.animal_id == a.id, EvenementElevage.type == "pesee")
                            .order_by(EvenementElevage.horodatage.desc()))
        res.append(en_dict(a, derniere_pesee=en_dict(der) if der else None))
    return res


@router.post(E + "/animaux", status_code=201)
def creer_animal(e: AnimalEntree, ctx: Contexte = Depends(autoriser("elevage:ecrire"))):
    if e.origine not in ("naissance", "achat"):
        raise ErreurMetier("donnee_invalide", detail="origine : naissance ou achat")
    a = Animal(exploitation_id=ctx.exploitation_id, **e.model_dump(exclude={"lot_animaux_id"}))
    ctx.db.add(a)
    ctx.db.flush()
    jour = e.date_entree or e.date_naissance or date.today()
    if e.lot_animaux_id:
        obtenir(ctx, LotAnimaux, e.lot_animaux_id, "Lot d'animaux")
        ctx.db.add(AppartenanceLot(animal_id=a.id, lot_animaux_id=e.lot_animaux_id, du=jour))
    ctx.db.add(EvenementElevage(exploitation_id=ctx.exploitation_id, type=e.origine, portee="individuelle", animal_id=a.id,
                                horodatage=datetime.combine(jour, datetime.min.time()).astimezone(), auteur_id=ctx.utilisateur.id,
                                a_declarer=True, statut_declaration="a_preparer"))
    journaliser(ctx, "creation", "animal", a.id, apres=instantane(a))
    ctx.db.commit()
    return en_dict(a)


@router.post(E + "/evenements-elevage", status_code=201)
def creer_evenement(e: EvenementEntree, ctx: Contexte = Depends(autoriser("elevage:ecrire"))):
    if e.type == "traitement":
        raise ErreurMetier("donnee_invalide", detail="utilisez la saisie de traitement dédiée")
    if bool(e.animal_id) == bool(e.lot_animaux_id):
        raise ErreurMetier("donnee_invalide", detail="indiquez soit un animal (individuel), soit un lot (collectif)")
    portee = "individuelle" if e.animal_id else "collective"
    if e.animal_id:
        animal = obtenir(ctx, Animal, e.animal_id, "Animal")
    else:
        obtenir(ctx, LotAnimaux, e.lot_animaux_id, "Lot d'animaux")
    quand = e.horodatage or maintenant()
    ev = EvenementElevage(exploitation_id=ctx.exploitation_id, type=e.type, portee=portee, animal_id=e.animal_id,
                          lot_animaux_id=e.lot_animaux_id, horodatage=quand, valeurs=e.valeurs, notes=e.notes,
                          auteur_id=ctx.utilisateur.id,
                          effectif_concerne=e.effectif_concerne or (effectif(ctx.db, e.lot_animaux_id) if e.lot_animaux_id else 1),
                          a_declarer=e.type in A_DECLARER and not e.valeurs.get("interne_exploitation"),
                          statut_declaration="a_preparer" if e.type in A_DECLARER else "non_applicable")
    ctx.db.add(ev)
    ctx.db.flush()
    if e.type == "alimentation":
        if not e.valeurs.get("article_id") or not e.valeurs.get("quantite"):
            raise ErreurMetier("donnee_invalide", detail="article et quantité d'aliment requis")
        mvts = S.consommer(ctx, uuid.UUID(e.valeurs["article_id"]), e.valeurs["quantite"], e.valeurs.get("unite"),
                           reference_type="evenement_elevage", reference_id=ev.id, motif="Distribution d'aliment", horodatage=quand)
        ev.mouvement_stock_id = mvts[0].id
    if e.type == "pesee" and e.animal_id and "poids_kg" not in e.valeurs:
        raise ErreurMetier("donnee_invalide", detail="poids_kg requis pour une pesée")
    if e.type in ("vente", "mortalite") and e.animal_id:
        animal.statut = "vendu" if e.type == "vente" else "mort"
        animal.date_sortie = quand.date()
        animal.motif_sortie = e.notes
        for ap in ctx.db.scalars(select(AppartenanceLot).where(AppartenanceLot.animal_id == animal.id, AppartenanceLot.au.is_(None))):
            ap.au = quand.date()
    journaliser(ctx, f"evenement_{e.type}", "evenement_elevage", ev.id, apres=instantane(ev))
    ctx.db.commit()
    return en_dict(ev)


@router.post(E + "/traitements-animaux", status_code=201)
def saisir_traitement(e: TraitementEntree, ctx: Contexte = Depends(autoriser("elevage:lire"))):
    if not ctx.peut("elevage:traitement"):
        raise AccesRefuse("elevage:traitement")
    if bool(e.animal_id) == bool(e.lot_animaux_id):
        raise ErreurMetier("donnee_invalide", detail="indiquez soit un animal, soit un lot")
    if e.animal_id:
        obtenir(ctx, Animal, e.animal_id, "Animal")
    else:
        obtenir(ctx, LotAnimaux, e.lot_animaux_id, "Lot d'animaux")
    ev = EvenementElevage(exploitation_id=ctx.exploitation_id, type="traitement",
                          portee="individuelle" if e.animal_id else "collective", animal_id=e.animal_id,
                          lot_animaux_id=e.lot_animaux_id, horodatage=e.horodatage or maintenant(),
                          effectif_concerne=e.effectif_concerne or (1 if e.animal_id else effectif(ctx.db, e.lot_animaux_id)),
                          notes=e.notes, auteur_id=ctx.utilisateur.id)
    ctx.db.add(ev)
    ctx.db.flush()
    t = TraitementAnimal(evenement_id=ev.id, saisi_par_role=ctx.role,
                         **e.model_dump(exclude={"animal_id", "lot_animaux_id", "effectif_concerne", "horodatage", "notes"}))
    ctx.db.add(t)
    ctx.db.flush()
    journaliser(ctx, "saisie_traitement", "traitement_animal", t.id, apres=instantane(t))
    ctx.db.commit()
    return en_dict(t, evenement=en_dict(ev),
                   avertissement="Traitement enregistré tel que prescrit. Le délai d'attente est celui recopié de l'ordonnance ; "
                                 "Terroir ne le calcule ni ne le vérifie.")


@router.get(E + "/evenements-elevage")
def lister_evenements(ctx: Contexte = Depends(autoriser("elevage:lire")), animal_id: uuid.UUID | None = None,
                      lot_animaux_id: uuid.UUID | None = None, type: str | None = None):
    q = select(EvenementElevage).where(EvenementElevage.exploitation_id == ctx.exploitation_id)
    if animal_id:
        q = q.where(EvenementElevage.animal_id == animal_id)
    if lot_animaux_id:
        q = q.where(EvenementElevage.lot_animaux_id == lot_animaux_id)
    if type:
        q = q.where(EvenementElevage.type == type)
    res = []
    for ev in ctx.db.scalars(q.order_by(EvenementElevage.horodatage.desc()).limit(300)):
        t = ctx.db.scalar(select(TraitementAnimal).where(TraitementAnimal.evenement_id == ev.id))
        res.append(en_dict(ev, traitement=en_dict(t) if t else None))
    return res


@router.get(E + "/animaux/{animal_id}/croissance")
def croissance(animal_id: uuid.UUID, ctx: Contexte = Depends(autoriser("elevage:lire"))):
    """GMQ entre pesées successives (calcul transparent)."""
    a = obtenir(ctx, Animal, animal_id, "Animal")
    pesees = ctx.db.scalars(select(EvenementElevage).where(EvenementElevage.animal_id == a.id, EvenementElevage.type == "pesee")
                            .order_by(EvenementElevage.horodatage)).all()
    points, gmq = [], []
    for i, p in enumerate(pesees):
        points.append({"date": p.horodatage.date().isoformat(), "poids_kg": p.valeurs.get("poids_kg")})
        if i:
            j = (p.horodatage - pesees[i - 1].horodatage).days
            if j > 0:
                gmq.append({"du": pesees[i - 1].horodatage.date().isoformat(), "au": p.horodatage.date().isoformat(),
                            "gmq_g_j": round((p.valeurs["poids_kg"] - pesees[i - 1].valeurs["poids_kg"]) * 1000 / j)})
    return {"animal": a.identifiant, "pesees": points, "gmq": gmq,
            "methode": "GMQ = (poids final − poids initial) / nombre de jours entre deux pesées individuelles."}


@router.get(E + "/declarations-a-preparer")
def declarations(ctx: Contexte = Depends(autoriser("elevage:lire"))):
    evs = ctx.db.scalars(select(EvenementElevage).where(EvenementElevage.exploitation_id == ctx.exploitation_id,
                                                        EvenementElevage.a_declarer.is_(True))
                         .order_by(EvenementElevage.horodatage)).all()
    return {"avertissement": "Liste de préparation interne. Aucune notification n'est transmise à l'EdE ou à la BDNI : "
                             "la déclaration doit être faite via un outil ou un service agréé.",
            "integration": "non intégrée (voir docs/SOURCES.md : cahiers des charges EdE / TRACIND)",
            "evenements": liste(evs)}
