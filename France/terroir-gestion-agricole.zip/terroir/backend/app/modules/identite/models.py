import uuid
from datetime import datetime

from sqlalchemy import Boolean, ForeignKey, Index, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin


class Exploitation(IdMixin, HorodatageMixin, Base):
    """Entreprise agricole (unité de cloisonnement des données)."""

    __tablename__ = "exploitation"
    raison_sociale: Mapped[str] = mapped_column(String(200))
    forme_juridique: Mapped[str | None] = mapped_column(String(50))
    siret: Mapped[str | None] = mapped_column(String(20))  # fictif en démonstration
    adresse: Mapped[str | None] = mapped_column(Text)
    modules_actifs: Mapped[list] = mapped_column(default=list)
    fictive: Mapped[bool] = mapped_column(Boolean, default=False)


class Utilisateur(IdMixin, HorodatageMixin, Base):
    __tablename__ = "utilisateur"
    courriel: Mapped[str] = mapped_column(String(200), unique=True)
    nom_affiche: Mapped[str] = mapped_column(String(120))
    mot_de_passe_hash: Mapped[str] = mapped_column(String(200))
    actif: Mapped[bool] = mapped_column(Boolean, default=True)
    echecs_connexion: Mapped[int] = mapped_column(default=0)
    bloque_jusqua: Mapped[datetime | None]


class Adhesion(IdMixin, HorodatageMixin, Base):
    """Rôle d'un utilisateur dans une exploitation."""

    __tablename__ = "adhesion"
    __table_args__ = (UniqueConstraint("utilisateur_id", "exploitation_id"),)
    utilisateur_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("utilisateur.id", ondelete="CASCADE"))
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"))
    role: Mapped[str] = mapped_column(String(40))
    membre_equipe_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("membre_equipe.id"))


class SessionUtilisateur(IdMixin, Base):
    """Session serveur : seul le condensé SHA-256 du jeton est stocké."""

    __tablename__ = "session_utilisateur"
    utilisateur_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("utilisateur.id", ondelete="CASCADE"))
    jeton_hash: Mapped[str] = mapped_column(String(64), unique=True)
    cree_le: Mapped[datetime]
    expire_le: Mapped[datetime]
    revoquee: Mapped[bool] = mapped_column(Boolean, default=False)
    agent: Mapped[str | None] = mapped_column(String(300))


class JournalAudit(IdMixin, Base):
    __tablename__ = "journal_audit"
    __table_args__ = (Index("ix_audit_entite", "entite", "entite_id"),)
    exploitation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("exploitation.id", ondelete="SET NULL"))
    utilisateur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    horodatage: Mapped[datetime]
    action: Mapped[str] = mapped_column(String(60))
    entite: Mapped[str] = mapped_column(String(60))
    entite_id: Mapped[str | None] = mapped_column(String(64))
    avant: Mapped[dict | None]
    apres: Mapped[dict | None]
    origine: Mapped[str] = mapped_column(String(30), default="web")  # web | terrain | tache | demo


class Tache(IdMixin, Base):
    """File de traitements en arrière-plan (PostgreSQL, SKIP LOCKED)."""

    __tablename__ = "tache_fond"
    exploitation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"))
    type: Mapped[str] = mapped_column(String(60))
    parametres: Mapped[dict] = mapped_column(default=dict)
    statut: Mapped[str] = mapped_column(String(20), default="en_attente")  # en_attente|en_cours|terminee|echec
    resultat: Mapped[dict | None]
    erreur: Mapped[str | None] = mapped_column(Text)
    tentatives: Mapped[int] = mapped_column(default=0)
    cree_le: Mapped[datetime]
    demarree_le: Mapped[datetime | None]
    terminee_le: Mapped[datetime | None]
    demandee_par: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))


class Compteur(Base):
    """Numérotation séquentielle par exploitation (factures, interventions…)."""

    __tablename__ = "compteur"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), primary_key=True)
    cle: Mapped[str] = mapped_column(String(40), primary_key=True)
    valeur: Mapped[int] = mapped_column(default=0)
