import io
import json
import uuid
import zipfile

from fastapi import APIRouter, Depends, Request, Response
from app.core.schemas import Entree
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.audit import instantane, journaliser
from app.core.config import get_settings
from app.core.crud import obtenir
from app.core.db import Base, get_db, maintenant
from app.core.erreurs import ErreurMetier
from app.core.permissions import ROLES, permissions_du_role
from app.core.securite import (Contexte, authentifier, autoriser, hacher_mot_de_passe, ouvrir_session, revoquer_session,
                               utilisateur_courant)
from app.core.serial import en_dict, liste, valeur_json
from app.modules.identite.models import Adhesion, Exploitation, JournalAudit, Tache, Utilisateur

router = APIRouter(tags=["Identité, sécurité, administration"])
E = "/exploitations/{exploitation_id}"
MODULES = {
    "grandes_cultures": {"libelle": "Grandes cultures", "etat": "disponible"},
    "maraichage": {"libelle": "Maraîchage", "etat": "disponible (fonctions de base)"},
    "vergers_viticulture": {"libelle": "Vergers et viticulture", "etat": "socle commun seulement — fonctions spécialisées à développer"},
    "elevage": {"libelle": "Élevage", "etat": "démonstration limitée (ovins, bovins)"},
    "polyculture_elevage": {"libelle": "Polyculture-élevage", "etat": "combinaison des modules ; liens fourrages/effluents à développer"},
}


class Connexion(Entree):
    courriel: str
    mot_de_passe: str


class ModulesEntree(Entree):
    modules_actifs: list[str]


class UtilisateurEntree(Entree):
    courriel: str
    nom_affiche: str
    mot_de_passe: str
    role: str
    membre_equipe_id: uuid.UUID | None = None


def _profil(db, u: Utilisateur) -> dict:
    adh = []
    for a, e in db.execute(select(Adhesion, Exploitation).join(Exploitation).where(Adhesion.utilisateur_id == u.id)):
        adh.append({"exploitation_id": str(e.id), "raison_sociale": e.raison_sociale, "role": a.role,
                    "libelle_role": ROLES[a.role]["libelle"], "permissions": sorted(permissions_du_role(a.role)),
                    "modules_actifs": e.modules_actifs, "fictive": e.fictive,
                    "membre_equipe_id": str(a.membre_equipe_id) if a.membre_equipe_id else None})
    return {"id": str(u.id), "courriel": u.courriel, "nom_affiche": u.nom_affiche, "adhesions": adh}


@router.post("/auth/connexion")
def connexion(e: Connexion, request: Request, response: Response, db: Session = Depends(get_db)):
    u = authentifier(db, e.courriel, e.mot_de_passe)
    jeton = ouvrir_session(db, u, request.headers.get("user-agent"))
    db.add(JournalAudit(utilisateur_id=u.id, horodatage=maintenant(), action="connexion", entite="utilisateur", entite_id=str(u.id)))
    db.commit()
    cfg = get_settings()
    response.set_cookie(cfg.cookie_nom, jeton, httponly=True, secure=cfg.cookie_secure, samesite="lax",
                        max_age=cfg.session_duree_heures * 3600, path="/")
    return _profil(db, u) | {"jeton": jeton}


@router.post("/auth/deconnexion")
def deconnexion(request: Request, response: Response, db: Session = Depends(get_db)):
    revoquer_session(db, request)
    response.delete_cookie(get_settings().cookie_nom, path="/")
    return {"ok": True}


@router.get("/auth/moi")
def moi(u: Utilisateur = Depends(utilisateur_courant), db: Session = Depends(get_db)):
    return _profil(db, u)


@router.get("/roles")
def roles():
    return {k: {"libelle": v["libelle"], "permissions": sorted(v["permissions"])} for k, v in ROLES.items()}


@router.get(E)
def lire_exploitation(ctx: Contexte = Depends(autoriser())):
    e = ctx.db.get(Exploitation, ctx.exploitation_id)
    from app.modules.foncier.models import Site

    return en_dict(e, modules_disponibles=MODULES,
                   sites=liste(ctx.db.scalars(select(Site).where(Site.exploitation_id == e.id))))


@router.put(E + "/modules")
def modifier_modules(m: ModulesEntree, ctx: Contexte = Depends(autoriser("parametres:ecrire"))):
    inconnus = set(m.modules_actifs) - set(MODULES)
    if inconnus:
        raise ErreurMetier("donnee_invalide", detail=f"modules inconnus : {', '.join(inconnus)}")
    e = ctx.db.get(Exploitation, ctx.exploitation_id)
    avant = {"modules_actifs": e.modules_actifs}
    e.modules_actifs = m.modules_actifs
    journaliser(ctx, "modification_modules", "exploitation", e.id, avant=avant, apres={"modules_actifs": m.modules_actifs})
    ctx.db.commit()
    return en_dict(e)


@router.get(E + "/utilisateurs")
def lister_utilisateurs(ctx: Contexte = Depends(autoriser("parametres:ecrire"))):
    res = []
    for a, u in ctx.db.execute(select(Adhesion, Utilisateur).join(Utilisateur).where(Adhesion.exploitation_id == ctx.exploitation_id)):
        res.append({"id": str(u.id), "courriel": u.courriel, "nom_affiche": u.nom_affiche, "role": a.role,
                    "libelle_role": ROLES[a.role]["libelle"], "actif": u.actif})
    return res


@router.post(E + "/utilisateurs", status_code=201)
def creer_utilisateur(e: UtilisateurEntree, ctx: Contexte = Depends(autoriser("parametres:ecrire"))):
    if e.role not in ROLES:
        raise ErreurMetier("donnee_invalide", detail="rôle inconnu")
    if len(e.mot_de_passe) < 12:
        raise ErreurMetier("donnee_invalide", detail="le mot de passe doit comporter au moins 12 caractères")
    u = ctx.db.scalar(select(Utilisateur).where(Utilisateur.courriel == e.courriel.lower()))
    if not u:
        u = Utilisateur(courriel=e.courriel.lower(), nom_affiche=e.nom_affiche, mot_de_passe_hash=hacher_mot_de_passe(e.mot_de_passe))
        ctx.db.add(u)
        ctx.db.flush()
    ctx.db.add(Adhesion(utilisateur_id=u.id, exploitation_id=ctx.exploitation_id, role=e.role, membre_equipe_id=e.membre_equipe_id))
    journaliser(ctx, "ajout_utilisateur", "utilisateur", u.id, apres={"courriel": u.courriel, "role": e.role})
    ctx.db.commit()
    return {"id": str(u.id), "courriel": u.courriel, "role": e.role}


@router.get(E + "/audit")
def journal_audit(ctx: Contexte = Depends(autoriser("audit:lire")), entite: str | None = None, entite_id: str | None = None,
                  limite: int = 200):
    q = select(JournalAudit, Utilisateur).outerjoin(Utilisateur, Utilisateur.id == JournalAudit.utilisateur_id).where(
        JournalAudit.exploitation_id == ctx.exploitation_id)
    if entite:
        q = q.where(JournalAudit.entite == entite)
    if entite_id:
        q = q.where(JournalAudit.entite_id == entite_id)
    return [en_dict(j, auteur=u.nom_affiche if u else None) for j, u in ctx.db.execute(q.order_by(JournalAudit.horodatage.desc()).limit(limite))]


def export_complet(db, exploitation_id) -> bytes:
    """Export de toutes les tables portant exploitation_id (+ tables filles directes)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        manifeste = {"exploitation_id": str(exploitation_id), "genere_le": maintenant().isoformat(), "tables": {}}
        for nom, table in Base.metadata.tables.items():
            if nom in ("session_utilisateur", "utilisateur", "compteur"):
                continue
            if "exploitation_id" in table.c:
                rows = db.execute(table.select().where(table.c.exploitation_id == exploitation_id)).mappings().all()
            elif nom == "exploitation":
                rows = db.execute(table.select().where(table.c.id == exploitation_id)).mappings().all()
            else:
                continue
            # Les géométries sont exportées en GeoJSON (WGS 84) via valeur_json.
            data = [{k: valeur_json(v) for k, v in r.items()} for r in rows]
            z.writestr(f"{nom}.json", json.dumps(data, ensure_ascii=False, indent=1))
            manifeste["tables"][nom] = len(data)
        z.writestr("manifeste.json", json.dumps(manifeste, ensure_ascii=False, indent=2))
    return buf.getvalue()


@router.get(E + "/export-donnees")
def exporter_donnees(ctx: Contexte = Depends(autoriser("donnees:exporter"))):
    contenu = export_complet(ctx.db, ctx.exploitation_id)
    journaliser(ctx, "export_donnees", "exploitation", ctx.exploitation_id, apres={"taille_octets": len(contenu)})
    ctx.db.commit()
    return Response(contenu, media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="terroir-export-{ctx.exploitation_id}.zip"'})


@router.get(E + "/taches")
def lister_taches(ctx: Contexte = Depends(autoriser())):
    return liste(ctx.db.scalars(select(Tache).where(Tache.exploitation_id == ctx.exploitation_id).order_by(Tache.cree_le.desc()).limit(50)))


@router.post(E + "/taches/{type_tache}", status_code=202)
def lancer_tache(type_tache: str, parametres: dict | None = None, ctx: Contexte = Depends(autoriser("parametres:ecrire"))):
    from app.core.taches import GESTIONNAIRES, mettre_en_file
    import app.taches_metier  # noqa: F401

    if type_tache not in GESTIONNAIRES:
        raise ErreurMetier("donnee_invalide", detail="tâche inconnue")
    t = mettre_en_file(ctx.db, type_tache, parametres or {}, ctx.exploitation_id, ctx.utilisateur.id)
    ctx.db.commit()
    return en_dict(t)
