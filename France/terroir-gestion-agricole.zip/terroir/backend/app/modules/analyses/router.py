import csv
import io
import uuid
from datetime import date, timedelta

from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy import func, select

from app.adapters.registre import tous as tous_adaptateurs
from app.core.audit import journaliser
from app.core.crud import obtenir
from app.core.format_fr import court
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.modules.analyses import couts, previsions
from app.modules.analyses.models import ChargeIndirecte, RegleAllocation
from app.modules.cultures.models import Campagne, CycleCultural
from app.modules.cultures.service import besoins_campagne

router = APIRouter(tags=["Analyses, prévisions, rapports"])
E = "/exploitations/{exploitation_id}"


@router.get(E + "/analyses/couts")
def analyse_couts(campagne_id: uuid.UUID, ctx: Contexte = Depends(autoriser("analyses:lire"))):
    obtenir(ctx, Campagne, campagne_id, "Campagne")
    return couts.analyse_campagne(ctx.db, ctx.exploitation_id, campagne_id)


@router.get(E + "/analyses/previsions")
def analyse_previsions(campagne_id: uuid.UUID, variation_pct: float = 10.0, ecart_scenario_pct: float = 15.0,
                       ctx: Contexte = Depends(autoriser("analyses:lire"))):
    obtenir(ctx, Campagne, campagne_id, "Campagne")
    a = couts.analyse_campagne(ctx.db, ctx.exploitation_id, campagne_id)
    b = besoins_campagne(ctx.db, ctx.exploitation_id, campagne_id)
    return {"rendements": previsions.scenarios_rendement(ctx.db, ctx.exploitation_id, campagne_id, ecart_scenario_pct),
            "besoins_intrants": b["intrants"], "charge_travail": b["charge_travail"],
            "sensibilite_couts": previsions.sensibilite(a, variation_pct),
            "apprentissage_automatique": previsions.CRITERES_ML}


@router.get(E + "/regles-allocation")
def regles(ctx: Contexte = Depends(autoriser("analyses:lire"))):
    return {"regles": liste(ctx.db.scalars(select(RegleAllocation).where(RegleAllocation.exploitation_id == ctx.exploitation_id))),
            "charges": liste(ctx.db.scalars(select(ChargeIndirecte).where(ChargeIndirecte.exploitation_id == ctx.exploitation_id)))}


@router.get(E + "/adaptateurs")
def adaptateurs(ctx: Contexte = Depends(autoriser())):
    return tous_adaptateurs()


@router.get(E + "/tableau-de-bord")
def tableau_de_bord(ctx: Contexte = Depends(autoriser())):
    from app.modules.documents.router import echeances
    from app.modules.foncier.models import Parcelle
    from app.modules.interventions.models import Intervention
    from app.modules.materiel.router import lister as lister_materiel
    from app.modules.stocks.models import Article
    from app.modules.stocks.service import etat_article
    from app.modules.sync.models import ConflitSync, OperationSync
    from app.core.config import get_settings
    from app.modules.foncier.geometrie import ecart_surface

    db, e = ctx.db, ctx.exploitation_id
    aujourd = date.today()
    d = {"alertes": []}
    if ctx.peut("interventions:lire"):
        its = db.scalars(select(Intervention).where(Intervention.exploitation_id == e, Intervention.statut.in_(["planifiee", "en_cours", "proposee"]),
                                                    Intervention.date_prevue <= aujourd + timedelta(days=14)).order_by(Intervention.date_prevue)).all()
        from app.modules.interventions.router import detail

        d["travaux_a_venir"] = [detail(ctx, i) for i in its[:12]]
        retard = [i for i in its if i.date_prevue and i.date_prevue < aujourd and i.statut == "planifiee"]
        for i in retard:
            d["alertes"].append({"niveau": "avertissement", "type": "retard", "message": f"Intervention {i.numero} prévue le {i.date_prevue.strftime('%d/%m/%Y')} non réalisée."})
    if ctx.peut("stocks:lire"):
        for a in db.scalars(select(Article).where(Article.exploitation_id == e, Article.actif.is_(True))):
            st = etat_article(db, e, a)
            if st["alerte"] == "rupture" and (a.seuil_alerte is not None or st["reserve"] > 0):
                d["alertes"].append({"niveau": "critique", "type": "rupture", "message": f"Rupture : {a.libelle} (disponible {court(st['disponible'])} {a.unite_stock}, attendu {court(st['attendu'])})."})
            elif st["alerte"] == "sous_seuil":
                d["alertes"].append({"niveau": "avertissement", "type": "stock_bas", "message": f"Stock bas : {a.libelle} ({court(st['disponible'])} {a.unite_stock})."})
    if ctx.peut("materiel:lire"):
        for m in lister_materiel(ctx=ctx):
            if not m["disponibilite"]["disponible"]:
                d["alertes"].append({"niveau": "avertissement", "type": "materiel", "message": f"Matériel indisponible : {m['libelle']} — {'; '.join(m['disponibilite']['motifs'])}."})
    if ctx.peut("foncier:lire"):
        for p in db.scalars(select(Parcelle).where(Parcelle.exploitation_id == e, Parcelle.active.is_(True))):
            ec = ecart_surface(p.surface_declaree_ha, p.surface_calculee_ha, get_settings().tolerance_ecart_surface_pct)
            if ec["signale"] and ec.get("ecart_pct") is not None:
                d["alertes"].append({"niveau": "information", "type": "surface", "message": f"Parcelle {p.code} : {ec['message']}"})
        d["surface_totale_ha"] = float(db.scalar(select(func.sum(Parcelle.surface_calculee_ha)).where(Parcelle.exploitation_id == e, Parcelle.active.is_(True))) or 0)
        d["nombre_parcelles"] = db.scalar(select(func.count()).select_from(Parcelle).where(Parcelle.exploitation_id == e, Parcelle.active.is_(True)))
    n_conf = db.scalar(select(func.count()).select_from(ConflitSync).where(ConflitSync.exploitation_id == e, ConflitSync.statut == "ouvert"))
    n_att = db.scalar(select(func.count()).select_from(OperationSync).where(OperationSync.exploitation_id == e, OperationSync.statut == "en_attente_validation"))
    if n_conf:
        d["alertes"].append({"niveau": "avertissement", "type": "sync", "message": f"{n_conf} conflit(s) de synchronisation à résoudre."})
    if n_att:
        d["alertes"].append({"niveau": "information", "type": "sync", "message": f"{n_att} compte(s) rendu(s) de terrain en attente de validation."})
    if ctx.peut("documents:lire"):
        ech = [x for x in echeances(ctx=ctx, horizon_jours=60)]
        d["echeances"] = ech[:10]
        for x in ech:
            if x["etat"] == "echue":
                d["alertes"].append({"niveau": "avertissement", "type": "echeance", "message": f"Échéance dépassée : {x['libelle']}."})
    ordre = {"critique": 0, "avertissement": 1, "information": 2}
    d["alertes"].sort(key=lambda a: ordre[a["niveau"]])
    return d


@router.get(E + "/rapports/tracabilite/{lot_id}")
def rapport_tracabilite(lot_id: uuid.UUID, format: str = "pdf", ctx: Contexte = Depends(autoriser("stocks:lire"))):
    from app.modules.stocks.models import LotStock
    from app.modules.tracabilite.service import rapport_lot
    from app.rapports import csv_tracabilite, pdf_tracabilite

    obtenir(ctx, LotStock, lot_id, "Lot")
    r = rapport_lot(ctx.db, lot_id)
    journaliser(ctx, "export_rapport", "lot_stock", lot_id, apres={"format": format})
    ctx.db.commit()
    if format == "csv":
        return Response(csv_tracabilite(r), media_type="text/csv; charset=utf-8",
                        headers={"Content-Disposition": f'attachment; filename="tracabilite-{r["lot"]["numero"]}.csv"'})
    if format == "json":
        return r
    return Response(pdf_tracabilite(r, ctx), media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="tracabilite-{r["lot"]["numero"]}.pdf"'})


@router.get(E + "/rapports/couts")
def rapport_couts(campagne_id: uuid.UUID, format: str = "csv", ctx: Contexte = Depends(autoriser("analyses:lire"))):
    from app.rapports import csv_couts, pdf_couts

    a = couts.analyse_campagne(ctx.db, ctx.exploitation_id, campagne_id)
    journaliser(ctx, "export_rapport", "campagne", campagne_id, apres={"format": format, "rapport": "couts"})
    ctx.db.commit()
    if format == "pdf":
        return Response(pdf_couts(a, ctx), media_type="application/pdf",
                        headers={"Content-Disposition": f'attachment; filename="couts-{a["campagne"]["libelle"]}.pdf"'})
    return Response(csv_couts(a), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="couts-{a["campagne"]["libelle"]}.csv"'})


@router.get(E + "/exports/comptable")
def export_comptable(du: date, au: date, ctx: Contexte = Depends(autoriser("donnees:exporter"))):
    from app.modules.commercial.models import Client, CommandeClient, Facture, FactureFournisseur, Fournisseur, Paiement

    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["# Export de gestion Terroir — à destination du cabinet comptable. Ce fichier n'est pas un FEC et ne remplace pas une comptabilité réglementaire."])
    w.writerow(["journal", "date", "piece", "tiers", "libelle", "montant_ht", "tva", "montant_ttc", "categorie"])
    for f in ctx.db.scalars(select(Facture).where(Facture.exploitation_id == ctx.exploitation_id, Facture.date_facture.between(du, au))):
        cmd = ctx.db.get(CommandeClient, f.commande_id)
        w.writerow(["VENTES", f.date_facture.strftime("%d/%m/%Y"), f.numero, ctx.db.get(Client, cmd.client_id).nom, f"Commande {cmd.numero}",
                    f"{f.montant_ht_eur:.2f}".replace(".", ","), f"{f.montant_ttc_eur - f.montant_ht_eur:.2f}".replace(".", ","),
                    f"{f.montant_ttc_eur:.2f}".replace(".", ","), "ventes"])
    for f in ctx.db.scalars(select(FactureFournisseur).where(FactureFournisseur.exploitation_id == ctx.exploitation_id, FactureFournisseur.date_facture.between(du, au))):
        w.writerow(["ACHATS", f.date_facture.strftime("%d/%m/%Y"), f.numero_fournisseur, ctx.db.get(Fournisseur, f.fournisseur_id).nom, "Facture fournisseur",
                    f"{f.montant_ht_eur:.2f}".replace(".", ","), f"{f.montant_tva_eur:.2f}".replace(".", ","),
                    f"{f.montant_ht_eur + f.montant_tva_eur:.2f}".replace(".", ","), f.categorie_charge])
    for p in ctx.db.scalars(select(Paiement).where(Paiement.exploitation_id == ctx.exploitation_id, Paiement.date_paiement.between(du, au))):
        f = ctx.db.get(Facture, p.facture_id)
        w.writerow(["BANQUE", p.date_paiement.strftime("%d/%m/%Y"), p.reference or "", "", f"Règlement {f.numero} ({p.mode})",
                    "", "", f"{p.montant_eur:.2f}".replace(".", ","), "encaissement"])
    journaliser(ctx, "export_comptable", "exploitation", ctx.exploitation_id, apres={"du": du.isoformat(), "au": au.isoformat()})
    ctx.db.commit()
    return Response("﻿" + buf.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="export-gestion-{du}-{au}.csv"'})
