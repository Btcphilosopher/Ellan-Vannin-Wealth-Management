"""Analyse économique : coûts par cycle, parcelle, campagne, groupe d'animaux et activité.

Définitions (documentées dans docs/ANALYSES.md) :
- charges opérationnelles = intrants + emballages + prestataires + stockage ;
- marge brute = produit − charges opérationnelles ;
- résultat après allocation = marge brute − main-d'œuvre − matériel − carburant − charges indirectes allouées ;
- trésorerie = encaissements − décaissements enregistrés sur la période (vue de caisse, distincte du résultat) ;
- coût supplémentaire (marginal) d'un hectare ou d'une tonne de plus = charges variables par unité
  (intrants, carburant, prestataires, emballages, heures de main-d'œuvre et de matériel), hors charges fixes.
Les prix utilisés sont versionnés (prix à la date du mouvement) ; un prix manquant est signalé, jamais supposé.
"""
from collections import defaultdict
from datetime import date
from decimal import Decimal

from sqlalchemy import select

from app.core.format_fr import court
from app.core.unites import convertir
from app.modules.analyses.models import ChargeIndirecte, RegleAllocation
from app.modules.commercial.models import (Allocation, CommandeClient, Expedition, FactureFournisseur, LigneCommandeClient,
                                           Paiement, PrixArticle)
from app.modules.cultures.models import Campagne, CycleCultural
from app.modules.elevage.models import EvenementElevage, LotAnimaux
from app.modules.equipe.models import MembreEquipe, TarifRessource, TempsTravail
from app.modules.foncier.models import Parcelle
from app.modules.interventions.models import Affectation, Intervention
from app.modules.materiel.models import PleinCarburant
from app.modules.stocks.models import Article, Emplacement, LotStock, MouvementStock

CATEGORIES = ["intrants", "main_oeuvre", "materiel", "carburant", "prestataires", "stockage", "emballages", "indirectes"]
LIBELLES = {"intrants": "Intrants", "main_oeuvre": "Main-d'œuvre", "materiel": "Matériel", "carburant": "Carburant",
            "prestataires": "Prestataires", "stockage": "Stockage", "emballages": "Emballages", "indirectes": "Charges indirectes"}
OPERATIONNELLES = ("intrants", "emballages", "prestataires", "stockage")
VARIABLES = ("intrants", "carburant", "prestataires", "emballages", "main_oeuvre", "materiel")
D0 = Decimal(0)


def prix_a_date(db, article_id, nature, jour):
    return db.scalar(select(PrixArticle).where(
        PrixArticle.article_id == article_id, PrixArticle.nature == nature, PrixArticle.valide_du <= jour,
        (PrixArticle.valide_au.is_(None)) | (PrixArticle.valide_au >= jour)).order_by(PrixArticle.version.desc()))


def tarif_a_date(db, ressource_id, jour):
    return db.scalar(select(TarifRessource).where(
        TarifRessource.ressource_id == ressource_id, TarifRessource.valide_du <= jour,
        (TarifRessource.valide_au.is_(None)) | (TarifRessource.valide_au >= jour)).order_by(TarifRessource.version.desc()))


class Ventilation:
    def __init__(self):
        self.montants = defaultdict(lambda: D0)
        self.details = defaultdict(list)
        self.manques = []

    def ajouter(self, cat, montant, detail):
        self.montants[cat] += Decimal(montant)
        self.details[cat].append(detail | {"montant_eur": float(round(Decimal(montant), 2))})

    def total(self, cats=CATEGORIES):
        return sum((self.montants[c] for c in cats), D0)


def cout_mouvement(db, m: MouvementStock, v: Ventilation, libelle_ref: str):
    a = db.get(Article, m.article_id)
    q = -Decimal(m.quantite)  # sortie = quantité négative ; une correction positive réduit le coût
    cu, source = m.cout_unitaire, "coût du lot acheté"
    if cu is None:
        p = prix_a_date(db, a.id, "achat", m.horodatage.date())
        if p:
            cu = Decimal(p.prix_unitaire_eur) / convertir(1, p.unite, a.unite_stock)
            source = f"prix d'achat v{p.version} au {m.horodatage.date().strftime('%d/%m/%Y')}"
    if cu is None:
        v.manques.append(f"Prix manquant pour « {a.libelle} » (mouvement n° {m.numero})")
        return
    cat = "emballages" if a.categorie == "emballage" else "carburant" if a.categorie == "carburant" else "intrants"
    v.ajouter(cat, q * Decimal(cu), {"libelle": f"{a.libelle} — {libelle_ref}", "quantite": float(q), "unite": a.unite_stock,
                                     "cout_unitaire_eur": float(round(Decimal(cu), 4)), "source_prix": source})


def ventiler_interventions(db, interventions: list[Intervention], v: Ventilation, membres_prestataires: set):
    ids = [i.id for i in interventions]
    if not ids:
        return {"heures_main_oeuvre": D0, "heures_materiel": D0}
    par_id = {i.id: i for i in interventions}
    for m in db.scalars(select(MouvementStock).where(MouvementStock.reference_type == "intervention",
                                                     MouvementStock.reference_id.in_(ids),
                                                     MouvementStock.type.in_(["consommation", "correction"]))):
        cout_mouvement(db, m, v, par_id[m.reference_id].numero)
    h_mo = D0
    for t in db.scalars(select(TempsTravail).where(TempsTravail.intervention_id.in_(ids))):
        h_mo += Decimal(t.heures)
        tr = tarif_a_date(db, t.membre_id, t.date)
        if not tr:
            v.manques.append(f"Tarif horaire manquant pour un membre de l'équipe au {t.date.strftime('%d/%m/%Y')}")
            continue
        cat = "prestataires" if t.membre_id in membres_prestataires else "main_oeuvre"
        v.ajouter(cat, Decimal(t.heures) * Decimal(tr.cout_horaire_eur),
                  {"libelle": f"{court(t.heures)} h — {par_id[t.intervention_id].numero}", "tarif_version": tr.version})
    h_mat = D0
    for a in db.scalars(select(Affectation).where(Affectation.intervention_id.in_(ids), Affectation.ressource_type == "materiel",
                                                  Affectation.active.is_(True))):
        it = par_id[a.intervention_id]
        if it.statut != "realisee" or not it.debut_reel or not it.fin_reelle:
            continue
        h = Decimal(str((it.fin_reelle - it.debut_reel).total_seconds() / 3600))
        h_mat += h
        tr = tarif_a_date(db, a.ressource_id, it.debut_reel.date())
        if not tr:
            v.manques.append(f"Tarif horaire matériel manquant ({it.numero})")
            continue
        v.ajouter("materiel", h * Decimal(tr.cout_horaire_eur), {"libelle": f"{court(h, 1)} h matériel — {it.numero}", "tarif_version": tr.version})
    for p in db.scalars(select(PleinCarburant).where(PleinCarburant.intervention_id.in_(ids))):
        if p.mouvement_stock_id:
            cout_mouvement(db, db.get(MouvementStock, p.mouvement_stock_id), v, f"plein {par_id[p.intervention_id].numero}")
    return {"heures_main_oeuvre": h_mo, "heures_materiel": h_mat}


def produit_des_lots(db, lots: list[LotStock], v_produit: list, manques: list) -> Decimal:
    """Produit = expéditions valorisées au prix de la commande + stock restant valorisé (prix de valorisation)."""
    from app.modules.stocks.service import physique_par_lot

    total = D0
    ids = {str(l.id) for l in lots}
    for ex in db.scalars(select(Expedition)):
        for li in ex.lignes:
            if li["lot_id"] in ids:
                al = db.get(Allocation, li["allocation_id"])
                lc = db.get(LigneCommandeClient, al.ligne_id)
                a = db.get(Article, lc.article_id)
                montant = convertir(li["quantite"], a.unite_stock, lc.unite) * Decimal(lc.prix_unitaire_eur)
                total += montant
                v_produit.append({"libelle": f"Expédition {ex.numero}", "nature": "vendu", "montant_eur": float(round(montant, 2))})
    for l in lots:
        reste = sum(physique_par_lot(db, l.exploitation_id, lot_id=l.id).values(), D0)
        if reste > 0:
            p = prix_a_date(db, l.article_id, "valorisation", date.today())
            if p:
                a = db.get(Article, l.article_id)
                m = reste * Decimal(p.prix_unitaire_eur) / convertir(1, p.unite, a.unite_stock)
                total += m
                v_produit.append({"libelle": f"Stock restant {l.numero}", "nature": "stock valorisé (estimation)",
                                  "montant_eur": float(round(m, 2))})
            else:
                manques.append(f"Prix de valorisation manquant pour le stock du lot {l.numero}")
    return total


def lots_du_cycle(db, cycle_id) -> list[LotStock]:
    return db.scalars(select(LotStock).where(LotStock.cycle_id == cycle_id)).all()


def cout_stockage(db, lots, v: Ventilation):
    from app.modules.stocks.service import physique_par_lot

    for l in lots:
        if l.origine != "recolte":
            continue
        for (lid, eid), q in physique_par_lot(db, l.exploitation_id, lot_id=l.id).items():
            e = db.get(Emplacement, eid)
            if q <= 0 or not e.cout_stockage_eur_t_mois:
                continue
            mois = Decimal(max((date.today() - (l.date_entree or date.today())).days, 0)) / Decimal(30)
            t = convertir(q, l.unite, "t") if l.unite in ("kg", "t", "q") else D0
            v.ajouter("stockage", t * mois * Decimal(e.cout_stockage_eur_t_mois),
                      {"libelle": f"{l.numero} — {e.nom} ({court(t, 2)} t × {court(mois, 1)} mois)",
                       "regle": "quantité présente × durée depuis l'entrée × tarif de l'emplacement"})


def analyse_campagne(db, exploitation_id, campagne_id) -> dict:
    camp = db.get(Campagne, campagne_id)
    cycles = db.scalars(select(CycleCultural).where(CycleCultural.campagne_id == campagne_id)).all()
    prestataires = {m.id for m in db.scalars(select(MembreEquipe).where(MembreEquipe.exploitation_id == exploitation_id,
                                                                         MembreEquipe.statut == "prestataire"))}
    res_cycles = []
    for c in cycles:
        v = Ventilation()
        its = db.scalars(select(Intervention).where(Intervention.cycle_id == c.id)).all()
        heures = ventiler_interventions(db, its, v, prestataires)
        lots = lots_du_cycle(db, c.id)
        lots_ids = [l.id for l in lots]
        if lots_ids:
            for m in db.scalars(select(MouvementStock).where(MouvementStock.reference_type == "lot", MouvementStock.reference_id.in_(lots_ids))):
                cout_mouvement(db, m, v, "conditionnement")
        cout_stockage(db, lots, v)
        for f in db.scalars(select(FactureFournisseur).where(FactureFournisseur.imputation_type == "cycle",
                                                             FactureFournisseur.imputation_id == c.id)):
            v.ajouter(f.categorie_charge if f.categorie_charge in CATEGORIES else "prestataires", f.montant_ht_eur,
                      {"libelle": f"Facture {f.numero_fournisseur}"})
        detail_produit = []
        produit = produit_des_lots(db, [l for l in lots], detail_produit, v.manques)
        quantite_t = sum((convertir(l.quantite_initiale, l.unite, "t") for l in lots if l.origine == "recolte" and l.quantite_initiale is not None and l.unite in ("kg", "t", "q")), D0)
        res_cycles.append({"cycle": c, "v": v, "produit": produit, "detail_produit": detail_produit, "heures": heures, "quantite_t": quantite_t})
    # Charges indirectes : allocation documentée
    allocations = []
    for ch in db.scalars(select(ChargeIndirecte).where(ChargeIndirecte.campagne_id == campagne_id)):
        r = db.get(RegleAllocation, ch.regle_id)
        if r.cle == "surface":
            poids = {x["cycle"].id: Decimal(x["cycle"].surface_prevue_ha) for x in res_cycles}
        elif r.cle == "heures_travail":
            poids = {x["cycle"].id: x["heures"]["heures_main_oeuvre"] for x in res_cycles}
        else:
            poids = {x["cycle"].id: x["produit"] for x in res_cycles}
        tot = sum(poids.values(), D0)
        for x in res_cycles:
            part = poids[x["cycle"].id] / tot if tot else D0
            x["v"].ajouter("indirectes", Decimal(ch.montant_eur) * part,
                           {"libelle": ch.libelle, "regle": f"{r.libelle} (v{r.version}, clé : {r.cle})", "part_pct": float(round(part * 100, 1))})
        allocations.append({"charge": ch.libelle, "montant_eur": float(ch.montant_eur), "regle": r.libelle, "cle": r.cle,
                            "version": r.version, "description": r.description})
    sortie, totaux = [], defaultdict(lambda: D0)
    par_parcelle, par_activite = defaultdict(lambda: defaultdict(lambda: D0)), defaultdict(lambda: defaultdict(lambda: D0))
    manques = []
    for x in res_cycles:
        c, v = x["cycle"], x["v"]
        p = db.get(Parcelle, c.parcelle_id)
        surf = Decimal(c.surface_prevue_ha)
        ops = v.total(OPERATIONNELLES)
        marge = x["produit"] - ops
        resultat = marge - v.total(("main_oeuvre", "materiel", "carburant", "indirectes"))
        variables = v.total(VARIABLES)
        ligne = {
            "cycle_id": str(c.id), "parcelle": f"{p.code} — {p.nom}", "parcelle_id": str(p.id), "culture": c.culture,
            "module": c.module, "surface_ha": float(surf),
            "charges": {k: float(round(v.montants[k], 2)) for k in CATEGORIES},
            "details": {k: v.details[k] for k in CATEGORIES if v.details[k]},
            "produit_eur": float(round(x["produit"], 2)), "detail_produit": x["detail_produit"],
            "charges_operationnelles_eur": float(round(ops, 2)),
            "marge_brute_eur": float(round(marge, 2)),
            "marge_brute_eur_ha": float(round(marge / surf, 2)) if surf else None,
            "resultat_apres_allocation_eur": float(round(resultat, 2)),
            "quantite_recoltee_t": float(round(x["quantite_t"], 3)),
            "cout_supplementaire": {
                "par_ha_eur": float(round(variables / surf, 2)) if surf else None,
                "par_t_eur": float(round(variables / x["quantite_t"], 2)) if x["quantite_t"] else None,
                "hypothese": "Charges variables observées rapportées à la surface ou au tonnage ; hors charges indirectes et fixes, "
                             "capacité de matériel et de main-d'œuvre supposée disponible.",
            },
            "donnees_manquantes": v.manques,
        }
        manques += v.manques
        sortie.append(ligne)
        for k in CATEGORIES:
            totaux[k] += v.montants[k]
            par_parcelle[ligne["parcelle"]][k] += v.montants[k]
            par_activite[c.module][k] += v.montants[k]
        totaux["produit"] += x["produit"]
        par_parcelle[ligne["parcelle"]]["produit"] += x["produit"]
        par_activite[c.module]["produit"] += x["produit"]
    # Groupes d'animaux
    groupes = []
    for l in db.scalars(select(LotAnimaux).where(LotAnimaux.exploitation_id == exploitation_id)):
        v = Ventilation()
        for ev in db.scalars(select(EvenementElevage).where(EvenementElevage.lot_animaux_id == l.id, EvenementElevage.mouvement_stock_id.is_not(None),
                                                            EvenementElevage.horodatage >= camp.date_debut, EvenementElevage.horodatage <= camp.date_fin)):
            cout_mouvement(db, db.get(MouvementStock, ev.mouvement_stock_id), v, "alimentation")
        for t in db.scalars(select(TempsTravail).where(TempsTravail.lot_animaux_id == l.id, TempsTravail.date >= camp.date_debut, TempsTravail.date <= camp.date_fin)):
            tr = tarif_a_date(db, t.membre_id, t.date)
            if tr:
                v.ajouter("main_oeuvre", Decimal(t.heures) * Decimal(tr.cout_horaire_eur), {"libelle": f"{court(t.heures)} h"})
            else:
                v.manques.append("Tarif horaire manquant (élevage)")
        groupes.append({"lot": l.nom, "code": l.code, "charges": {k: float(round(v.montants[k], 2)) for k in CATEGORIES},
                        "total_eur": float(round(v.total(), 2)), "details": {k: v.details[k] for k in CATEGORIES if v.details[k]},
                        "donnees_manquantes": v.manques})
        for k in CATEGORIES:
            par_activite["elevage"][k] += v.montants[k]
        manques += v.manques

    def fmt(d):
        r = {k: float(round(d[k], 2)) for k in CATEGORIES}
        r["produit_eur"] = float(round(d["produit"], 2))
        ops = sum((d[k] for k in OPERATIONNELLES), D0)
        r["marge_brute_eur"] = float(round(d["produit"] - ops, 2))
        r["resultat_apres_allocation_eur"] = float(round(d["produit"] - sum((d[k] for k in CATEGORIES), D0), 2))
        return r

    tresorerie = tresorerie_periode(db, exploitation_id, camp.date_debut, camp.date_fin)
    tresorerie_a_date = tresorerie_periode(db, exploitation_id, camp.date_debut, max(date.today(), camp.date_fin))
    return {
        "campagne": {"id": str(camp.id), "libelle": camp.libelle},
        "definitions": {
            "marge_brute": "Produit − charges opérationnelles (intrants, emballages, prestataires, stockage).",
            "resultat_apres_allocation": "Marge brute − main-d'œuvre − matériel − carburant − charges indirectes allouées.",
            "tresorerie": "Encaissements − décaissements enregistrés sur la période (indépendant du résultat).",
            "cout_supplementaire": "Coût variable d'un hectare ou d'une tonne supplémentaire, hors charges fixes.",
            "produit": "Ventes expédiées au prix de commande + stock restant valorisé (estimation, prix de valorisation versionné).",
        },
        "cycles": sortie, "groupes_animaux": groupes,
        "par_parcelle": {k: fmt(v) for k, v in par_parcelle.items()},
        "par_activite": {k: fmt(v) for k, v in par_activite.items()},
        "total": fmt(totaux), "allocations": allocations, "tresorerie": tresorerie, "tresorerie_a_date": tresorerie_a_date,
        "donnees_manquantes": sorted(set(manques)),
        "avertissement": "Analyse de gestion. Elle ne remplace pas une comptabilité réglementaire validée.",
    }


def tresorerie_periode(db, exploitation_id, du, au) -> dict:
    enc = sum((Decimal(p.montant_eur) for p in db.scalars(select(Paiement).where(
        Paiement.exploitation_id == exploitation_id, Paiement.date_paiement >= du, Paiement.date_paiement <= au))), D0)
    dec_rows = db.scalars(select(FactureFournisseur).where(FactureFournisseur.exploitation_id == exploitation_id,
                                                           FactureFournisseur.date_paiement.is_not(None),
                                                           FactureFournisseur.date_paiement >= du, FactureFournisseur.date_paiement <= au)).all()
    dec = sum((Decimal(f.montant_ht_eur) + Decimal(f.montant_tva_eur) for f in dec_rows), D0)
    a_payer = sum((Decimal(f.montant_ht_eur) + Decimal(f.montant_tva_eur) for f in db.scalars(select(FactureFournisseur).where(
        FactureFournisseur.exploitation_id == exploitation_id, FactureFournisseur.date_paiement.is_(None)))), D0)
    return {"encaissements_eur": float(enc), "decaissements_eur": float(dec), "solde_eur": float(enc - dec),
            "factures_fournisseurs_non_payees_eur": float(a_payer),
            "note": "Seuls les paiements enregistrés sont comptés (TTC)."}
