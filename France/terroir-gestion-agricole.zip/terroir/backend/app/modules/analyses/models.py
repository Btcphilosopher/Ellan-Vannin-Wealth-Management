import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin


class RegleAllocation(IdMixin, HorodatageMixin, Base):
    """Règle documentée de répartition des charges indirectes."""

    __tablename__ = "regle_allocation"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    libelle: Mapped[str] = mapped_column(String(200))
    cle: Mapped[str] = mapped_column(String(30))  # surface | heures_travail | produit_brut
    perimetre: Mapped[str] = mapped_column(String(30), default="cycles")  # cycles | cycles_et_lots_animaux
    description: Mapped[str] = mapped_column(Text)
    version: Mapped[int] = mapped_column(default=1)
    valide_du: Mapped[date]
    valide_au: Mapped[date | None]


class ChargeIndirecte(IdMixin, HorodatageMixin, Base):
    __tablename__ = "charge_indirecte"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    campagne_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("campagne.id"))
    libelle: Mapped[str] = mapped_column(String(200))
    montant_eur: Mapped[Decimal]
    regle_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("regle_allocation.id"))
    source: Mapped[str | None] = mapped_column(String(200))
