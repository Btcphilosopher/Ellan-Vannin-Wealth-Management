"""Prévisions par méthodes transparentes (pas d'apprentissage automatique en V1)."""
import statistics
from decimal import Decimal

from sqlalchemy import select

from app.core.unites import convertir
from app.modules.cultures.models import Campagne, CycleCultural
from app.modules.stocks.models import LotStock

CRITERES_ML = {
    "statut": "non activé",
    "conditions_activation": [
        "Au moins 5 campagnes d'historique par culture et par type de sol pour la prévision de rendement.",
        "Jeu d'évaluation indépendant (campagnes ou exploitations non vues à l'entraînement).",
        "Estimation d'incertitude publiée avec chaque prévision (intervalle et couverture mesurée).",
        "Revue par un agronome avant mise en service ; suivi de dérive.",
    ],
    "usages_envisages": ["classement d'observations", "prévision de rendement", "détection d'anomalies",
                         "priorisation d'investigations de maintenance"],
    "interdits": ["présenter une maladie suggérée comme un diagnostic confirmé", "déclencher automatiquement un traitement"],
}


def historique_rendements(db, exploitation_id, culture: str, exclure_campagne=None) -> list[dict]:
    res = []
    q = select(CycleCultural, Campagne).join(Campagne).where(CycleCultural.exploitation_id == exploitation_id,
                                                             CycleCultural.culture.ilike(culture))
    for c, camp in db.execute(q):
        if exclure_campagne and camp.id == exclure_campagne:
            continue
        lots = db.scalars(select(LotStock).where(LotStock.cycle_id == c.id, LotStock.origine == "recolte")).all()
        t = sum((convertir(l.quantite_initiale, l.unite, "t") for l in lots if l.quantite_initiale is not None and l.unite in ("kg", "t", "q")), Decimal(0))
        if t > 0 and c.surface_prevue_ha:
            res.append({"campagne": camp.libelle, "parcelle_id": str(c.parcelle_id), "rendement_t_ha": float(t / Decimal(c.surface_prevue_ha))})
    return res


def scenarios_rendement(db, exploitation_id, campagne_id, ecart_pct: float = 15.0) -> list[dict]:
    res = []
    for c in db.scalars(select(CycleCultural).where(CycleCultural.campagne_id == campagne_id)):
        hist = historique_rendements(db, exploitation_id, c.culture, exclure_campagne=campagne_id)
        vals = sorted(h["rendement_t_ha"] for h in hist)
        surf = float(c.surface_prevue_ha)
        if len(vals) >= 3:
            bas, med, haut = vals[0], statistics.median(vals), vals[-1]
            methode = f"Historique de l'exploitation ({len(vals)} cycles) : minimum, médiane, maximum."
        elif c.rendement_previsionnel:
            med = float(c.rendement_previsionnel)
            bas, haut = med * (1 - ecart_pct / 100), med * (1 + ecart_pct / 100)
            methode = (f"Historique insuffisant ({len(vals)} cycle(s)) : rendement prévisionnel saisi ± {ecart_pct:g} % "
                       "(paramètre de scénario, non statistique).")
        else:
            res.append({"cycle_id": str(c.id), "culture": c.culture, "statut": "impossible",
                        "methode": "Ni historique suffisant ni rendement prévisionnel saisi."})
            continue
        res.append({"cycle_id": str(c.id), "culture": c.culture, "surface_ha": surf, "historique": hist,
                    "scenarios": {k: {"rendement_t_ha": round(v, 2), "production_t": round(v * surf, 1)}
                                  for k, v in (("pessimiste", bas), ("median", med), ("optimiste", haut))},
                    "methode": methode, "incertitude": "Les scénarios encadrent des valeurs passées ou saisies ; ils ne constituent pas un intervalle de confiance."})
    return res


def sensibilite(analyse: dict, variation_pct: float = 10.0) -> list[dict]:
    total = analyse["total"]
    base = total["resultat_apres_allocation_eur"]
    lignes = []
    for cat in ("intrants", "main_oeuvre", "materiel", "carburant", "prestataires", "stockage", "emballages", "indirectes"):
        delta = total[cat] * variation_pct / 100
        lignes.append({"poste": cat, "montant_eur": total[cat], "variation_pct": variation_pct,
                       "resultat_si_hausse_eur": round(base - delta, 2), "resultat_si_baisse_eur": round(base + delta, 2),
                       "impact_eur": round(delta, 2)})
    delta_p = total["produit_eur"] * variation_pct / 100
    lignes.append({"poste": "prix_de_vente", "montant_eur": total["produit_eur"], "variation_pct": variation_pct,
                   "resultat_si_hausse_eur": round(base + delta_p, 2), "resultat_si_baisse_eur": round(base - delta_p, 2),
                   "impact_eur": round(delta_p, 2)})
    return sorted(lignes, key=lambda l: -abs(l["impact_eur"]))
