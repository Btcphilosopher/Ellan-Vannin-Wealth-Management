"""Affectation des ressources et détection des conflits de planning."""
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.core.audit import instantane, journaliser
from app.core.erreurs import Conflit, ErreurMetier, Introuvable
from app.modules.equipe.models import Competence, MembreEquipe
from app.modules.interventions.models import Affectation, Intervention
from app.modules.materiel.models import Defaut, Maintenance, Materiel


def _fmt(d: datetime, fuseau: str = "Europe/Paris") -> str:
    from zoneinfo import ZoneInfo

    return d.astimezone(ZoneInfo(fuseau)).strftime("%d/%m/%Y %H:%M")


def fuseau_intervention(db, intervention) -> str:
    from app.modules.foncier.models import Parcelle, Site

    if intervention is None:
        return "Europe/Paris"
    p = db.get(Parcelle, intervention.parcelle_id)
    return db.get(Site, p.site_id).fuseau_horaire


def nom_ressource(db, type_, id_) -> str:
    if type_ == "materiel":
        m = db.get(Materiel, id_)
        return m.libelle if m else "Matériel"
    m = db.get(MembreEquipe, id_)
    return f"{m.prenom} {m.nom}" if m else "Personne"


def indisponibilites_materiel(db, materiel_id, debut: datetime, fin: datetime) -> list[dict]:
    res = []
    for m in db.scalars(select(Maintenance).where(
            Maintenance.materiel_id == materiel_id, Maintenance.statut.in_(["planifiee", "en_cours"]),
            Maintenance.immobilise_du.is_not(None), Maintenance.immobilise_du < fin,
            (Maintenance.immobilise_au.is_(None)) | (Maintenance.immobilise_au > debut))):
        res.append({"type": "maintenance", "motif": f"maintenance « {m.libelle} »", "du": m.immobilise_du.isoformat(),
                    "au": m.immobilise_au.isoformat() if m.immobilise_au else None, "id": str(m.id)})
    for d in db.scalars(select(Defaut).where(Defaut.materiel_id == materiel_id, Defaut.statut == "ouvert",
                                              Defaut.gravite == "bloquant", Defaut.constate_le < fin)):
        res.append({"type": "defaut", "motif": f"défaut bloquant : {d.description}", "du": d.constate_le.isoformat(),
                    "au": None, "id": str(d.id)})
    return res


def conflits(db, ressource_type, ressource_id, debut, fin, intervention: Intervention | None = None,
             ignorer_affectation=None) -> list[dict]:
    res = []
    tz = fuseau_intervention(db, intervention)
    q = select(Affectation, Intervention).join(Intervention).where(
        Affectation.ressource_id == ressource_id, Affectation.active.is_(True),
        Affectation.debut < fin, Affectation.fin > debut)
    if ignorer_affectation:
        q = q.where(Affectation.id != ignorer_affectation)
    for a, it in db.execute(q):
        res.append({"type": "chevauchement", "bloquant": True, "affectation_id": str(a.id),
                    "intervention": it.numero, "debut": a.debut.isoformat(), "fin": a.fin.isoformat(),
                    "message": f"Déjà affecté(e) à {it.numero} du {_fmt(a.debut, tz)} au {_fmt(a.fin, tz)}."})
    if ressource_type == "materiel":
        for i in indisponibilites_materiel(db, ressource_id, debut, fin):
            res.append({**i, "nature": i["type"], "type": "indisponibilite", "bloquant": True,
                        "message": f"Indisponible : {i['motif']}."})
    elif intervention is not None and intervention.competence_requise:
        jour = debut.date()
        ok = db.scalar(select(Competence.id).where(
            Competence.membre_id == ressource_id, Competence.type.like(intervention.competence_requise + "%"),
            (Competence.valide_du.is_(None)) | (Competence.valide_du <= jour),
            (Competence.valide_au.is_(None)) | (Competence.valide_au >= jour)).limit(1))
        if not ok:
            res.append({"type": "competence", "bloquant": True, "competence": intervention.competence_requise,
                        "message": f"Compétence requise absente ou échue : {intervention.competence_requise}."})
    return res


def affecter(ctx, intervention: Intervention, ressource_type: str, ressource_id, debut: datetime, fin: datetime,
             role: str | None = None) -> Affectation:
    db = ctx.db
    if ressource_type not in ("materiel", "membre"):
        raise ErreurMetier("donnee_invalide", detail="type de ressource inconnu")
    modele = Materiel if ressource_type == "materiel" else MembreEquipe
    r = db.get(modele, ressource_id)
    if not r or r.exploitation_id != ctx.exploitation_id:
        raise Introuvable("Ressource")
    if fin <= debut:
        raise ErreurMetier("donnee_invalide", detail="la fin doit être postérieure au début")
    nom = nom_ressource(db, ressource_type, ressource_id)
    tz = fuseau_intervention(db, intervention)
    for c in conflits(db, ressource_type, ressource_id, debut, fin, intervention):
        if c["type"] == "chevauchement":
            raise Conflit("conflit_affectation", ressource=nom, debut=_fmt(datetime.fromisoformat(c["debut"]), tz),
                          fin=_fmt(datetime.fromisoformat(c["fin"]), tz), motif=c["intervention"])
        if c["type"] == "indisponibilite":
            raise Conflit("materiel_indisponible", ressource=nom, motif=c["motif"])
        if c["type"] == "competence":
            raise Conflit("competence_manquante", ressource=nom, competence=c["competence"])
    a = Affectation(exploitation_id=ctx.exploitation_id, intervention_id=intervention.id, ressource_type=ressource_type,
                    ressource_id=ressource_id, debut=debut, fin=fin, role=role)
    db.add(a)
    try:
        with db.begin_nested():
            db.flush()
    except IntegrityError:
        # Garde-fou : contrainte d'exclusion PostgreSQL (affectations concurrentes)
        raise Conflit("conflit_affectation", ressource=nom, debut=_fmt(debut, tz), fin=_fmt(fin, tz), motif="affectation concurrente")
    journaliser(ctx, "affectation", "affectation", a.id, apres=instantane(a))
    return a
