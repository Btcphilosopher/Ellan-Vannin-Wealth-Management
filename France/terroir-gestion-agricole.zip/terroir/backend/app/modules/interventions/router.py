import uuid
from datetime import date, datetime
from decimal import Decimal

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import select

from app.core.audit import instantane, journaliser
from app.core.crud import obtenir, verifier_version
from app.core.db import maintenant
from app.core.erreurs import Conflit, ErreurMetier
from app.core.numerotation import numero_formate
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.core.unites import DOSE_VERS_QUANTITE, arrondi, convertir, quantite_depuis_dose, unite
from app.i18n.fr import LIBELLES
from app.modules.cultures.models import CycleCultural
from app.modules.equipe.models import TempsTravail
from app.modules.foncier.models import Parcelle
from app.modules.interventions import planning
from app.modules.interventions.models import (TYPES_INTERVENTION, Affectation, Intervention, InterventionProduit,
                                              ValidationProfessionnelle)
from app.modules.intrants.verification import verifier_intervention
from app.modules.materiel.models import Materiel, ReleveHeures
from app.modules.stocks import service as S
from app.modules.stocks.models import Article, Reservation
from app.modules.terrain.meteo import meteo_du_jour

router = APIRouter(tags=["Travaux : interventions et planning"])
E = "/exploitations/{exploitation_id}"

TRANSITIONS = {
    "proposee": {"realisee", "annulee"},
    "planifiee": {"en_cours", "realisee", "annulee"},
    "en_cours": {"realisee", "annulee"},
    "realisee": set(),
    "annulee": set(),
}
EXIGER_VALIDATION_PHYTO = True


class ProduitEntree(Entree):
    article_id: uuid.UUID
    dose_prevue: float | None = None
    unite_dose: str | None = None
    quantite_prevue: float | None = None
    unite_quantite: str | None = None
    lot_id: uuid.UUID | None = None
    emplacement_id: uuid.UUID | None = None


class InterventionEntree(Entree):
    parcelle_id: uuid.UUID
    cycle_id: uuid.UUID | None = None
    zone_id: uuid.UUID | None = None
    type: str
    libelle: str | None = None
    date_prevue: date | None = None
    debut_prevu: datetime | None = None
    fin_prevue: datetime | None = None
    surface_prevue_ha: float | None = None
    operateur_id: uuid.UUID | None = None
    duree_prevue_h: float | None = None
    competence_requise: str | None = None
    notes: str | None = None
    produits: list[ProduitEntree] = []


class AffectationEntree(Entree):
    ressource_type: str
    ressource_id: uuid.UUID
    debut: datetime
    fin: datetime
    role: str | None = None


class ProduitRealise(Entree):
    intervention_produit_id: uuid.UUID
    quantite_mesuree: float
    methode_mesure: str = "estimation"
    consigne_machine: float | None = None
    unite_consigne: str | None = None
    source_consigne: str | None = None
    lot_id: uuid.UUID | None = None


class TempsEntree(Entree):
    membre_id: uuid.UUID
    heures: float


class HeuresMateriel(Entree):
    materiel_id: uuid.UUID
    heures_moteur_fin: float
    source: str = "saisie"


class CompteRendu(Entree):
    version: int | None = None
    debut_reel: datetime
    fin_reelle: datetime
    surface_realisee_ha: float | None = None
    produits: list[ProduitRealise] = []
    temps: list[TempsEntree] = []
    heures_materiel: list[HeuresMateriel] = []
    meteo_saisie: dict | None = None  # conditions constatées si la source est indisponible
    notes: str | None = None


class ValidationEntree(Entree):
    decision: str  # validee | refusee | a_revoir
    qualification: str
    commentaire: str | None = None


def ligne_produit(ctx, it: Intervention, p: ProduitEntree) -> InterventionProduit:
    a = obtenir(ctx, Article, p.article_id, "Article")
    surface = Decimal(str(it.surface_prevue_ha or 0))
    q, uq = p.quantite_prevue, p.unite_quantite
    if p.dose_prevue is not None and p.unite_dose:
        qref, uref = quantite_depuis_dose(p.dose_prevue, p.unite_dose, surface)
        if q is None:
            q, uq = (convertir(qref, uref, a.unite_stock), a.unite_stock) if unite(a.unite_stock).grandeur == unite(uref).grandeur else (qref, uref)
    if uq:
        unite(uq)
    return InterventionProduit(intervention_id=it.id, article_id=a.id, dose_prevue=p.dose_prevue, unite_dose=p.unite_dose,
                               quantite_prevue=Decimal(str(q)) if q is not None else None,
                               unite_quantite=uq or a.unite_stock, lot_id=p.lot_id, emplacement_id=p.emplacement_id)


def detail(ctx, it: Intervention) -> dict:
    db = ctx.db
    produits = []
    for ip in db.scalars(select(InterventionProduit).where(InterventionProduit.intervention_id == it.id)):
        a = db.get(Article, ip.article_id)
        r = db.get(Reservation, ip.reservation_id) if ip.reservation_id else None
        produits.append(en_dict(ip, article=a.libelle, article_code=a.code, categorie=a.categorie,
                                reglemente=a.reglemente, reservation_statut=r.statut if r else None))
    aff = []
    for a in db.scalars(select(Affectation).where(Affectation.intervention_id == it.id, Affectation.active.is_(True))):
        aff.append(en_dict(a, nom=planning.nom_ressource(db, a.ressource_type, a.ressource_id)))
    p = db.get(Parcelle, it.parcelle_id)
    c = db.get(CycleCultural, it.cycle_id) if it.cycle_id else None
    return en_dict(it, libelle_type=LIBELLES["type_intervention"].get(it.type, it.type),
                   libelle_statut=LIBELLES["statut_intervention"].get(it.statut, it.statut),
                   parcelle={"id": p.id, "code": p.code, "nom": p.nom, "site_id": p.site_id},
                   cycle={"id": c.id, "culture": c.culture, "variete": c.variete} if c else None,
                   produits=produits, affectations=aff)


def creer_intervention(ctx, e: InterventionEntree, statut="planifiee", origine="web") -> Intervention:
    if e.type not in TYPES_INTERVENTION:
        raise ErreurMetier("donnee_invalide", detail=f"type d'intervention inconnu : {e.type}")
    p = obtenir(ctx, Parcelle, e.parcelle_id, "Parcelle")
    if e.cycle_id:
        c = obtenir(ctx, CycleCultural, e.cycle_id, "Cycle cultural")
        if c.parcelle_id != p.id:
            raise ErreurMetier("donnee_invalide", detail="le cycle n'appartient pas à cette parcelle")
    annee = (e.date_prevue or date.today()).year
    it = Intervention(exploitation_id=ctx.exploitation_id, numero=numero_formate(ctx.db, ctx.exploitation_id, "INT", annee),
                      statut=statut, origine=origine, cree_par=ctx.utilisateur.id,
                      **e.model_dump(exclude={"produits"}))
    if it.surface_prevue_ha is None:
        it.surface_prevue_ha = (c.surface_prevue_ha if e.cycle_id else None) or p.surface_calculee_ha or p.surface_declaree_ha
    else:
        it.surface_prevue_ha = Decimal(str(it.surface_prevue_ha))
    if e.type == "traitement_phyto" and not it.competence_requise:
        it.competence_requise = "certiphyto"
    ctx.db.add(it)
    ctx.db.flush()
    for pe in e.produits:
        ctx.db.add(ligne_produit(ctx, it, pe))
    ctx.db.flush()
    journaliser(ctx, "creation", "intervention", it.id, apres=instantane(it))
    return it


@router.get(E + "/interventions")
def lister(ctx: Contexte = Depends(autoriser("interventions:lire")), du: date | None = None, au: date | None = None,
           parcelle_id: uuid.UUID | None = None, statut: str | None = None, type: str | None = None,
           cycle_id: uuid.UUID | None = None):
    q = select(Intervention).where(Intervention.exploitation_id == ctx.exploitation_id)
    if du:
        q = q.where(Intervention.date_prevue >= du)
    if au:
        q = q.where(Intervention.date_prevue <= au)
    if parcelle_id:
        q = q.where(Intervention.parcelle_id == parcelle_id)
    if statut:
        q = q.where(Intervention.statut == statut)
    if type:
        q = q.where(Intervention.type == type)
    if cycle_id:
        q = q.where(Intervention.cycle_id == cycle_id)
    return [detail(ctx, it) for it in ctx.db.scalars(q.order_by(Intervention.date_prevue, Intervention.numero))]


@router.post(E + "/interventions", status_code=201)
def creer(e: InterventionEntree, ctx: Contexte = Depends(autoriser("interventions:ecrire"))):
    it = creer_intervention(ctx, e)
    ctx.db.commit()
    return detail(ctx, it)


@router.get(E + "/interventions/{intervention_id}")
def lire(intervention_id: uuid.UUID, ctx: Contexte = Depends(autoriser("interventions:lire"))):
    it = obtenir(ctx, Intervention, intervention_id, "Intervention")
    d = detail(ctx, it)
    p = ctx.db.get(Parcelle, it.parcelle_id)
    jour = it.date_prevue or date.today()
    d["meteo_disponible"] = meteo_du_jour(ctx.db, p.site_id, jour)
    return d


@router.post(E + "/interventions/{intervention_id}/produits", status_code=201)
def ajouter_produit(intervention_id: uuid.UUID, e: ProduitEntree, ctx: Contexte = Depends(autoriser("interventions:ecrire"))):
    it = obtenir(ctx, Intervention, intervention_id, "Intervention")
    if it.statut not in ("planifiee", "proposee"):
        raise ErreurMetier("intervention_statut", de=it.statut, vers="modification")
    ip = ligne_produit(ctx, it, e)
    ctx.db.add(ip)
    it.verification_reglementaire = None
    ctx.db.commit()
    return detail(ctx, it)


@router.post(E + "/interventions/{intervention_id}/reservations")
def reserver_intrants(intervention_id: uuid.UUID, ctx: Contexte = Depends(autoriser("interventions:ecrire"))):
    """Réserve chaque produit prévu. Les ruptures sont listées sans bloquer les autres lignes."""
    it = obtenir(ctx, Intervention, intervention_id, "Intervention")
    resultats = []
    for ip in ctx.db.scalars(select(InterventionProduit).where(InterventionProduit.intervention_id == it.id)):
        a = ctx.db.get(Article, ip.article_id)
        if ip.reservation_id and ctx.db.get(Reservation, ip.reservation_id).statut == "active":
            resultats.append({"article": a.libelle, "statut": "deja_reserve"})
            continue
        if ip.quantite_prevue is None:
            resultats.append({"article": a.libelle, "statut": "quantite_prevue_manquante"})
            continue
        try:
            with ctx.db.begin_nested():
                r = S.reserver(ctx, a.id, ip.quantite_prevue, ip.unite_quantite, "intervention", it.id,
                               lot_id=ip.lot_id, emplacement_id=ip.emplacement_id, date_besoin=it.date_prevue)
                ip.reservation_id = r.id
            resultats.append({"article": a.libelle, "statut": "reserve", "quantite": float(r.quantite), "unite": r.unite})
        except ErreurMetier as err:
            etat = S.etat_article(ctx.db, ctx.exploitation_id, a)
            resultats.append({"article": a.libelle, "article_id": str(a.id), "statut": "rupture", "message": err.message,
                              "disponible": etat["disponible"], "attendu": etat["attendu"],
                              "besoin": arrondi(S.en_unite_stock(a, ip.quantite_prevue, ip.unite_quantite)), "unite": a.unite_stock})
    ctx.db.commit()
    return {"intervention": it.numero, "lignes": resultats,
            "ruptures": [r for r in resultats if r["statut"] == "rupture"]}


@router.get(E + "/planning/conflits")
def verifier_conflits(ressource_type: str, ressource_id: uuid.UUID, debut: datetime, fin: datetime,
                      intervention_id: uuid.UUID | None = None, ctx: Contexte = Depends(autoriser("interventions:lire"))):
    it = obtenir(ctx, Intervention, intervention_id, "Intervention") if intervention_id else None
    return {"conflits": planning.conflits(ctx.db, ressource_type, ressource_id, debut, fin, it)}


@router.post(E + "/interventions/{intervention_id}/affectations", status_code=201)
def affecter(intervention_id: uuid.UUID, e: AffectationEntree, ctx: Contexte = Depends(autoriser("interventions:ecrire"))):
    it = obtenir(ctx, Intervention, intervention_id, "Intervention")
    a = planning.affecter(ctx, it, e.ressource_type, e.ressource_id, e.debut, e.fin, e.role)
    if e.ressource_type == "membre" and not it.operateur_id:
        it.operateur_id = e.ressource_id
    ctx.db.commit()
    return en_dict(a)


@router.delete(E + "/affectations/{affectation_id}")
def retirer_affectation(affectation_id: uuid.UUID, ctx: Contexte = Depends(autoriser("interventions:ecrire"))):
    a = obtenir(ctx, Affectation, affectation_id, "Affectation")
    a.active = False
    journaliser(ctx, "retrait_affectation", "affectation", a.id)
    ctx.db.commit()
    return {"ok": True}


@router.post(E + "/interventions/{intervention_id}/verification")
def verification(intervention_id: uuid.UUID, ctx: Contexte = Depends(autoriser("interventions:lire"))):
    it = obtenir(ctx, Intervention, intervention_id, "Intervention")
    it.verification_reglementaire = verifier_intervention(ctx.db, it)
    ctx.db.commit()
    return it.verification_reglementaire


@router.post(E + "/interventions/{intervention_id}/validation-professionnelle", status_code=201)
def valider(intervention_id: uuid.UUID, e: ValidationEntree, ctx: Contexte = Depends(autoriser("phyto:valider"))):
    it = obtenir(ctx, Intervention, intervention_id, "Intervention")
    if e.decision not in ("validee", "refusee", "a_revoir"):
        raise ErreurMetier("donnee_invalide", detail="décision inconnue")
    v = ValidationProfessionnelle(exploitation_id=ctx.exploitation_id, objet_type="intervention", objet_id=it.id,
                                  decision=e.decision, validee_par=ctx.utilisateur.id, qualification=e.qualification,
                                  commentaire=e.commentaire, horodatage=maintenant())
    ctx.db.add(v)
    ctx.db.flush()
    it.verification_reglementaire = verifier_intervention(ctx.db, it)
    journaliser(ctx, "validation_professionnelle", "intervention", it.id, apres=instantane(v))
    ctx.db.commit()
    return en_dict(v)


def _changer_statut(ctx, it: Intervention, vers: str):
    if vers not in TRANSITIONS.get(it.statut, set()):
        raise Conflit("intervention_statut", de=it.statut, vers=vers)
    if (EXIGER_VALIDATION_PHYTO and it.type == "traitement_phyto" and it.statut == "planifiee"
            and vers in ("en_cours", "realisee")):
        v = ctx.db.scalar(select(ValidationProfessionnelle).where(
            ValidationProfessionnelle.objet_type == "intervention", ValidationProfessionnelle.objet_id == it.id)
            .order_by(ValidationProfessionnelle.horodatage.desc()))
        if not v or v.decision != "validee":
            raise Conflit("donnee_invalide", detail="validation professionnelle requise avant de démarrer un traitement phytopharmaceutique planifié")
    avant = it.statut
    it.statut = vers
    it.version += 1
    journaliser(ctx, "changement_statut", "intervention", it.id, avant={"statut": avant}, apres={"statut": vers})


@router.post(E + "/interventions/{intervention_id}/demarrage")
def demarrer(intervention_id: uuid.UUID, ctx: Contexte = Depends(autoriser("interventions:realiser"))):
    it = obtenir(ctx, Intervention, intervention_id, "Intervention")
    _changer_statut(ctx, it, "en_cours")
    it.debut_reel = it.debut_reel or maintenant()
    ctx.db.commit()
    return detail(ctx, it)


def realiser_intervention(ctx, it: Intervention, cr: CompteRendu) -> Intervention:
    db = ctx.db
    verifier_version(it, cr.version)
    lignes = {ip.id: ip for ip in db.scalars(select(InterventionProduit).where(InterventionProduit.intervention_id == it.id))}
    saisies = {p.intervention_produit_id: p for p in cr.produits}
    for ip in lignes.values():
        if ip.id not in saisies:
            a = db.get(Article, ip.article_id)
            raise ErreurMetier("intervention_realisee_sans_quantite", produit=a.libelle)
    _changer_statut(ctx, it, "realisee")
    it.debut_reel, it.fin_reelle = cr.debut_reel, cr.fin_reelle
    it.surface_realisee_ha = Decimal(str(cr.surface_realisee_ha)) if cr.surface_realisee_ha is not None else it.surface_prevue_ha
    p = db.get(Parcelle, it.parcelle_id)
    meteo = meteo_du_jour(db, p.site_id, cr.debut_reel.date())
    if cr.meteo_saisie:
        meteo = meteo | {"constatee_par_operateur": cr.meteo_saisie}
    it.meteo = meteo
    if cr.notes:
        it.notes = ((it.notes + "\n") if it.notes else "") + cr.notes
    it.validee_par = ctx.utilisateur.id
    for sid, s in saisies.items():
        ip = lignes.get(sid)
        if not ip:
            raise ErreurMetier("donnee_invalide", detail="ligne produit inconnue")
        ip.quantite_mesuree = Decimal(str(s.quantite_mesuree))
        ip.methode_mesure = s.methode_mesure
        ip.consigne_machine = s.consigne_machine
        ip.unite_consigne = s.unite_consigne
        ip.source_consigne = s.source_consigne
        if s.lot_id:
            ip.lot_id = s.lot_id
        res = db.get(Reservation, ip.reservation_id) if ip.reservation_id else None
        if res and res.statut != "active":
            res = None
        if ip.quantite_mesuree > 0:
            mvts = S.consommer(ctx, ip.article_id, ip.quantite_mesuree, ip.unite_quantite, reservation=res,
                               lot_id=ip.lot_id, emplacement_id=ip.emplacement_id, reference_type="intervention",
                               reference_id=it.id, horodatage=cr.debut_reel, motif=f"Intervention {it.numero}")
            ip.mouvement_id = mvts[0].id
        elif res:
            S.annuler_reservation(ctx, res, "quantité mesurée nulle")
    for t in cr.temps:
        db.add(TempsTravail(exploitation_id=ctx.exploitation_id, membre_id=t.membre_id, date=cr.debut_reel.date(),
                            heures=Decimal(str(t.heures)), activite="intervention", intervention_id=it.id, cycle_id=it.cycle_id))
    for h in cr.heures_materiel:
        m = obtenir(ctx, Materiel, h.materiel_id, "Matériel")
        db.add(ReleveHeures(materiel_id=m.id, horodatage=cr.fin_reelle, heures_moteur=Decimal(str(h.heures_moteur_fin)),
                            source=h.source, auteur_id=ctx.utilisateur.id))
    db.flush()
    if it.type == "traitement_phyto" or any(db.get(Article, ip.article_id).reglemente for ip in lignes.values()):
        it.verification_reglementaire = verifier_intervention(db, it)
    journaliser(ctx, "compte_rendu", "intervention", it.id, apres=instantane(it))
    return it


@router.post(E + "/interventions/{intervention_id}/realisation")
def realiser(intervention_id: uuid.UUID, cr: CompteRendu, ctx: Contexte = Depends(autoriser("interventions:realiser"))):
    it = obtenir(ctx, Intervention, intervention_id, "Intervention")
    if it.statut == "proposee":
        ctx.exiger("interventions:ecrire")  # valider une proposition terrain
    realiser_intervention(ctx, it, cr)
    ctx.db.commit()
    return detail(ctx, it)


@router.post(E + "/interventions/{intervention_id}/annulation")
def annuler(intervention_id: uuid.UUID, ctx: Contexte = Depends(autoriser("interventions:ecrire"))):
    it = obtenir(ctx, Intervention, intervention_id, "Intervention")
    _changer_statut(ctx, it, "annulee")
    for ip in ctx.db.scalars(select(InterventionProduit).where(InterventionProduit.intervention_id == it.id)):
        r = ctx.db.get(Reservation, ip.reservation_id) if ip.reservation_id else None
        if r and r.statut == "active":
            S.annuler_reservation(ctx, r, "intervention annulée")
    for a in ctx.db.scalars(select(Affectation).where(Affectation.intervention_id == it.id)):
        a.active = False
    ctx.db.commit()
    return detail(ctx, it)


@router.get(E + "/planning")
def planning_vue(du: date, au: date, ctx: Contexte = Depends(autoriser("interventions:lire"))):
    """Vue planning : interventions, affectations et restrictions de maintenance."""
    from app.modules.materiel.models import Defaut, Maintenance

    its = lister(ctx=ctx, du=du, au=au)
    debut = datetime.combine(du, datetime.min.time()).astimezone()
    fin = datetime.combine(au, datetime.max.time()).astimezone()
    restrictions = []
    for m in ctx.db.scalars(select(Materiel).where(Materiel.exploitation_id == ctx.exploitation_id)):
        for i in planning.indisponibilites_materiel(ctx.db, m.id, debut, fin):
            restrictions.append({"materiel_id": str(m.id), "materiel": m.libelle, **i})
    return {"interventions": its, "restrictions_materiel": restrictions}
