import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import CheckConstraint, ForeignKey, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin, VersionMixin

TYPES_INTERVENTION = [
    "travail_sol", "semis", "plantation", "irrigation", "fertilisation", "traitement_phyto",
    "desherbage_mecanique", "taille", "recolte", "transport",
]
STATUTS = ["proposee", "planifiee", "en_cours", "realisee", "annulee"]


class Intervention(IdMixin, HorodatageMixin, VersionMixin, Base):
    __tablename__ = "intervention"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    numero: Mapped[str] = mapped_column(String(30))  # identifiant lisible, ex. INT-2027-0042
    parcelle_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("parcelle.id"), index=True)
    zone_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("zone_gestion.id", ondelete="SET NULL"))
    cycle_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("cycle_cultural.id"), index=True)
    type: Mapped[str] = mapped_column(String(30))
    libelle: Mapped[str | None] = mapped_column(String(200))
    date_prevue: Mapped[date | None]
    debut_prevu: Mapped[datetime | None]
    fin_prevue: Mapped[datetime | None]
    debut_reel: Mapped[datetime | None]
    fin_reelle: Mapped[datetime | None]
    surface_prevue_ha: Mapped[Decimal | None]
    surface_realisee_ha: Mapped[Decimal | None]
    operateur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("membre_equipe.id"))
    duree_prevue_h: Mapped[Decimal | None]
    competence_requise: Mapped[str | None] = mapped_column(String(60))
    meteo: Mapped[dict | None]  # {nature: observee|prevue|indisponible, source, horodatage, valeurs, fraicheur_h}
    notes: Mapped[str | None] = mapped_column(Text)
    statut: Mapped[str] = mapped_column(String(20), default="planifiee")
    origine: Mapped[str] = mapped_column(String(20), default="web")  # web|terrain|itineraire|demo
    verification_reglementaire: Mapped[dict | None]
    cree_par: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    validee_par: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))


class InterventionProduit(IdMixin, HorodatageMixin, Base):
    """Trois niveaux distincts : prévu / consigne machine / mesuré."""

    __tablename__ = "intervention_produit"
    intervention_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("intervention.id", ondelete="CASCADE"), index=True)
    article_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("article.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("lot_stock.id"))
    emplacement_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("emplacement.id"))
    # 1. Application prévue
    dose_prevue: Mapped[Decimal | None]
    unite_dose: Mapped[str | None] = mapped_column(String(15))
    quantite_prevue: Mapped[Decimal | None]
    unite_quantite: Mapped[str] = mapped_column(String(10))
    # 2. Consigne envoyée à une machine (déclarative ; aucune commande n'est envoyée par Terroir)
    consigne_machine: Mapped[Decimal | None]
    unite_consigne: Mapped[str | None] = mapped_column(String(15))
    source_consigne: Mapped[str | None] = mapped_column(String(40))  # saisie|telemetrie_simulee|fichier_tache
    # 3. Quantité effectivement mesurée
    quantite_mesuree: Mapped[Decimal | None]
    methode_mesure: Mapped[str | None] = mapped_column(String(40))  # pesee|compteur|jauge|telemetrie_simulee|estimation
    reservation_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("reservation.id", ondelete="SET NULL"))
    mouvement_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("mouvement_stock.id", ondelete="SET NULL"))


class Affectation(IdMixin, HorodatageMixin, Base):
    """Affectation d'une ressource (matériel ou personne) à une intervention.

    Une contrainte d'exclusion PostgreSQL (btree_gist) interdit deux
    affectations actives qui se chevauchent pour la même ressource.
    """

    __tablename__ = "affectation"
    __table_args__ = (
        CheckConstraint("fin > debut", name="periode_valide"),
        Index("ix_affectation_ressource", "ressource_id"),
    )
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    intervention_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("intervention.id", ondelete="CASCADE"), index=True)
    ressource_type: Mapped[str] = mapped_column(String(20))  # materiel | membre
    ressource_id: Mapped[uuid.UUID]
    debut: Mapped[datetime]
    fin: Mapped[datetime]
    active: Mapped[bool] = mapped_column(default=True)
    role: Mapped[str | None] = mapped_column(String(60))


class ValidationProfessionnelle(IdMixin, HorodatageMixin, Base):
    __tablename__ = "validation_professionnelle"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    objet_type: Mapped[str] = mapped_column(String(40))  # intervention | regle_rotation | itineraire
    objet_id: Mapped[uuid.UUID]
    decision: Mapped[str] = mapped_column(String(20))  # validee | refusee | a_revoir
    validee_par: Mapped[uuid.UUID] = mapped_column(ForeignKey("utilisateur.id"))
    qualification: Mapped[str | None] = mapped_column(String(200))
    commentaire: Mapped[str | None] = mapped_column(Text)
    horodatage: Mapped[datetime]
