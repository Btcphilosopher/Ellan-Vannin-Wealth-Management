import uuid
from datetime import date

from sqlalchemy import BigInteger, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin

CATEGORIES_DOCUMENT = [
    "bail_foncier", "fournisseur", "controle", "certificat_materiel", "qualite",
    "environnement", "facture", "photo", "analyse_sol", "ordonnance", "autre",
]


class Document(IdMixin, HorodatageMixin, Base):
    __tablename__ = "document"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    categorie: Mapped[str] = mapped_column(String(30))
    titre: Mapped[str] = mapped_column(String(200))
    nom_fichier: Mapped[str | None] = mapped_column(String(200))
    cle_stockage: Mapped[str | None] = mapped_column(String(200))
    type_mime: Mapped[str | None] = mapped_column(String(80))
    taille_octets: Mapped[int | None] = mapped_column(BigInteger)
    sha256: Mapped[str | None] = mapped_column(String(64))
    entite_type: Mapped[str | None] = mapped_column(String(40))
    entite_id: Mapped[uuid.UUID | None]
    echeance: Mapped[date | None]
    libelle_echeance: Mapped[str | None] = mapped_column(String(200))
    confidentiel: Mapped[bool] = mapped_column(default=False)
    notes: Mapped[str | None] = mapped_column(Text)
    ajoute_par: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))


class DossierPreparation(IdMixin, HorodatageMixin, Base):
    """Espace de préparation (PAC, certification, contrôle). Ne constitue
    jamais une déclaration ni une transmission officielle."""

    __tablename__ = "dossier_preparation"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    titre: Mapped[str] = mapped_column(String(200))
    type: Mapped[str] = mapped_column(String(30))  # pac|certification|controle|environnement
    campagne_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("campagne.id"))
    elements: Mapped[list] = mapped_column(default=list)  # [{libelle, fait, document_ids, commentaire}]
    statut: Mapped[str] = mapped_column(String(20), default="en_preparation")
    notes: Mapped[str | None] = mapped_column(Text)
