import io
import json
import uuid
import zipfile
from datetime import date, timedelta

from fastapi import APIRouter, Depends, File, Form, UploadFile
from fastapi.responses import Response
from app.core.schemas import Entree
from sqlalchemy import select

from app.core.audit import instantane, journaliser
from app.core.crud import obtenir
from app.core.erreurs import AccesRefuse, ErreurMetier
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.core.stockage import enregistrer_objet, nettoyer_nom, stockage, valider_fichier
from app.modules.documents.models import CATEGORIES_DOCUMENT, Document, DossierPreparation
from app.modules.equipe.models import Competence, MembreEquipe
from app.modules.foncier.models import Parcelle
from app.modules.materiel.models import Maintenance, Materiel

router = APIRouter(tags=["Documents et démarches"])
E = "/exploitations/{exploitation_id}"

MENTION_PREPARATION = ("DOCUMENT DE PRÉPARATION INTERNE — Cet export ne constitue ni une déclaration PAC, "
                       "ni une transmission officielle, ni un accusé de réception d'une administration. "
                       "Les démarches officielles se font sur les portails des administrations concernées (ex. Telepac).")


def creer_document(ctx, nom_fichier: str, contenu: bytes, categorie: str, titre: str, **meta) -> Document:
    if categorie not in CATEGORIES_DOCUMENT:
        raise ErreurMetier("donnee_invalide", detail=f"catégorie inconnue : {categorie}")
    nom = nettoyer_nom(nom_fichier)
    mime = valider_fichier(nom, contenu)
    cle, sha = enregistrer_objet(ctx.exploitation_id, contenu, mime)
    d = Document(exploitation_id=ctx.exploitation_id, categorie=categorie, titre=titre, nom_fichier=nom, cle_stockage=cle,
                 type_mime=mime, taille_octets=len(contenu), sha256=sha, ajoute_par=ctx.utilisateur.id, **meta)
    ctx.db.add(d)
    ctx.db.flush()
    journaliser(ctx, "depot_document", "document", d.id, apres=instantane(d))
    return d


@router.get(E + "/documents")
def lister(ctx: Contexte = Depends(autoriser("documents:lire")), categorie: str | None = None,
           entite_type: str | None = None, entite_id: uuid.UUID | None = None):
    q = select(Document).where(Document.exploitation_id == ctx.exploitation_id)
    if not ctx.peut("documents:confidentiels"):
        q = q.where(Document.confidentiel.is_(False))
    if categorie:
        q = q.where(Document.categorie == categorie)
    if entite_type:
        q = q.where(Document.entite_type == entite_type)
    if entite_id:
        q = q.where(Document.entite_id == entite_id)
    return liste(ctx.db.scalars(q.order_by(Document.cree_le.desc())), exclure=("cle_stockage",))


@router.post(E + "/documents", status_code=201)
async def deposer(fichier: UploadFile = File(...), categorie: str = Form(...), titre: str = Form(...),
                  entite_type: str | None = Form(None), entite_id: uuid.UUID | None = Form(None),
                  echeance: date | None = Form(None), libelle_echeance: str | None = Form(None),
                  confidentiel: bool = Form(False), ctx: Contexte = Depends(autoriser("documents:ecrire"))):
    contenu = await fichier.read()
    d = creer_document(ctx, fichier.filename, contenu, categorie, titre, entite_type=entite_type, entite_id=entite_id,
                       echeance=echeance, libelle_echeance=libelle_echeance, confidentiel=confidentiel)
    ctx.db.commit()
    return en_dict(d, exclure=("cle_stockage",))


@router.get(E + "/documents/{document_id}/contenu")
def telecharger(document_id: uuid.UUID, ctx: Contexte = Depends(autoriser("documents:lire"))):
    d = obtenir(ctx, Document, document_id, "Document")
    if d.confidentiel and not ctx.peut("documents:confidentiels"):
        raise AccesRefuse("documents:confidentiels")
    if not d.cle_stockage:
        raise ErreurMetier("donnee_invalide", detail="document sans fichier")
    contenu = stockage().lire(d.cle_stockage)
    journaliser(ctx, "consultation_document", "document", d.id)
    ctx.db.commit()
    return Response(contenu, media_type=d.type_mime, headers={
        "Content-Disposition": f'attachment; filename="{d.nom_fichier}"', "X-Content-Type-Options": "nosniff",
        "Cache-Control": "private, no-store"})


@router.get(E + "/echeances")
def echeances(ctx: Contexte = Depends(autoriser("documents:lire")), horizon_jours: int = 365):
    limite = date.today() + timedelta(days=horizon_jours)
    res = []
    for d in ctx.db.scalars(select(Document).where(Document.exploitation_id == ctx.exploitation_id, Document.echeance.is_not(None), Document.echeance <= limite)):
        res.append({"type": "document", "libelle": d.libelle_echeance or d.titre, "date": d.echeance, "lien": {"document_id": d.id}, "categorie": d.categorie})
    for p in ctx.db.scalars(select(Parcelle).where(Parcelle.exploitation_id == ctx.exploitation_id, Parcelle.bail_echeance.is_not(None), Parcelle.bail_echeance <= limite)):
        res.append({"type": "bail", "libelle": f"Échéance du bail — {p.code} {p.nom}", "date": p.bail_echeance, "lien": {"parcelle_id": p.id}, "categorie": "bail_foncier"})
    for c, m in ctx.db.execute(select(Competence, MembreEquipe).join(MembreEquipe).where(MembreEquipe.exploitation_id == ctx.exploitation_id, Competence.valide_au.is_not(None), Competence.valide_au <= limite)):
        res.append({"type": "competence", "libelle": f"{c.libelle} — {m.prenom} {m.nom}", "date": c.valide_au, "lien": {"membre_id": m.id}, "categorie": "controle"})
    for mt, ma in ctx.db.execute(select(Maintenance, Materiel).join(Materiel).where(Materiel.exploitation_id == ctx.exploitation_id, Maintenance.statut == "planifiee", Maintenance.immobilise_du.is_not(None))):
        if mt.immobilise_du.date() <= limite:
            res.append({"type": "maintenance", "libelle": f"{mt.libelle} — {ma.libelle}", "date": mt.immobilise_du.date(), "lien": {"materiel_id": ma.id}, "categorie": "controle"})
    aujourd = date.today()
    for r in res:
        r["etat"] = "echue" if r["date"] < aujourd else "proche" if r["date"] <= aujourd + timedelta(days=30) else "a_venir"
        r["libelle_etat"] = {"echue": "Échue", "proche": "Moins de 30 jours", "a_venir": "À venir"}[r["etat"]]
    from app.core.serial import valeur_json

    return valeur_json(sorted(res, key=lambda r: r["date"]))


class DossierEntree(Entree):
    titre: str
    type: str
    campagne_id: uuid.UUID | None = None
    elements: list = []
    notes: str | None = None


@router.get(E + "/dossiers")
def lister_dossiers(ctx: Contexte = Depends(autoriser("documents:lire"))):
    return [en_dict(d, mention=MENTION_PREPARATION) for d in ctx.db.scalars(select(DossierPreparation).where(DossierPreparation.exploitation_id == ctx.exploitation_id))]


@router.post(E + "/dossiers", status_code=201)
def creer_dossier(e: DossierEntree, ctx: Contexte = Depends(autoriser("documents:ecrire"))):
    d = DossierPreparation(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(d)
    ctx.db.flush()
    journaliser(ctx, "creation", "dossier_preparation", d.id, apres=instantane(d))
    ctx.db.commit()
    return en_dict(d, mention=MENTION_PREPARATION)


@router.get(E + "/dossiers/{dossier_id}/export")
def exporter_dossier(dossier_id: uuid.UUID, ctx: Contexte = Depends(autoriser("documents:lire"))):
    from app.modules.cultures.models import CycleCultural

    d = obtenir(ctx, DossierPreparation, dossier_id, "Dossier")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("LISEZMOI.txt", MENTION_PREPARATION + "\n")
        z.writestr("dossier.json", json.dumps(en_dict(d) | {"mention": MENTION_PREPARATION}, ensure_ascii=False, indent=2))
        if d.campagne_id:
            lignes = ["mention;" + MENTION_PREPARATION, "code_parcelle;nom;culture;variete;surface_prevue_ha;surface_declaree_ha;surface_calculee_ha"]
            for c, p in ctx.db.execute(select(CycleCultural, Parcelle).join(Parcelle).where(CycleCultural.campagne_id == d.campagne_id)):
                lignes.append(";".join(str(x if x is not None else "") for x in [p.code, p.nom, c.culture, c.variete,
                              str(c.surface_prevue_ha).replace(".", ","), str(p.surface_declaree_ha or "").replace(".", ","),
                              str(p.surface_calculee_ha or "").replace(".", ",")]))
            z.writestr("assolement_preparation.csv", "﻿" + "\n".join(lignes))
        for el in d.elements:
            for did in el.get("document_ids", []):
                doc = ctx.db.get(Document, uuid.UUID(did))
                if doc and doc.exploitation_id == ctx.exploitation_id and doc.cle_stockage and (not doc.confidentiel or ctx.peut("documents:confidentiels")):
                    z.writestr(f"pieces/{doc.nom_fichier}", stockage().lire(doc.cle_stockage))
    journaliser(ctx, "export_dossier", "dossier_preparation", d.id)
    ctx.db.commit()
    return Response(buf.getvalue(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="preparation-{d.type}-{d.id}.zip"'})
