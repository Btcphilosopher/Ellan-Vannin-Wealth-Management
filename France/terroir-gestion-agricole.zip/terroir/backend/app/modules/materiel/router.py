import uuid
from datetime import date, datetime, timedelta
from decimal import Decimal

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import select

from app.core.audit import instantane, journaliser
from app.core.crud import obtenir
from app.core.db import maintenant
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.modules.documents.models import Document
from app.modules.interventions.planning import indisponibilites_materiel
from app.modules.materiel.models import Defaut, Maintenance, Materiel, PleinCarburant, ReleveHeures
from app.modules.stocks import service as S

router = APIRouter(tags=["Matériel"])
E = "/exploitations/{exploitation_id}"


class MaterielEntree(Entree):
    code: str
    libelle: str
    categorie: str
    marque: str | None = None
    modele: str | None = None
    annee: int | None = None
    immatriculation: str | None = None
    site_id: uuid.UUID | None = None
    propriete: str = "propre"
    debit_chantier_ha_h: float | None = None
    consommation_reference_l_h: float | None = None
    source_telemetrie: str | None = None


class MaintenanceEntree(Entree):
    type: str
    libelle: str
    immobilise_du: datetime | None = None
    immobilise_au: datetime | None = None
    echeance_heures: float | None = None
    prestataire: str | None = None
    cout_eur: float | None = None


class DefautEntree(Entree):
    gravite: str
    description: str
    constate_le: datetime | None = None


class HeuresEntree(Entree):
    heures_moteur: float
    horodatage: datetime | None = None
    source: str = "saisie"


class PleinEntree(Entree):
    litres: float
    article_carburant_id: uuid.UUID
    emplacement_id: uuid.UUID | None = None
    heures_compteur: float | None = None
    horodatage: datetime | None = None
    intervention_id: uuid.UUID | None = None


def etat_materiel(ctx, m: Materiel) -> dict:
    now = maintenant()
    indispo = indisponibilites_materiel(ctx.db, m.id, now, now + timedelta(minutes=1))
    a_venir = indisponibilites_materiel(ctx.db, m.id, now, now + timedelta(days=30))
    der = ctx.db.scalar(select(ReleveHeures).where(ReleveHeures.materiel_id == m.id).order_by(ReleveHeures.horodatage.desc()))
    docs = ctx.db.scalars(select(Document).where(Document.entite_type == "materiel", Document.entite_id == m.id)).all()
    return en_dict(m, disponibilite={"disponible": not indispo,
                                     "libelle": "Disponible" if not indispo else "Indisponible",
                                     "motifs": [i["motif"] for i in indispo]},
                   restrictions_30_jours=a_venir,
                   heures_moteur=({"valeur": float(der.heures_moteur), "source": der.source,
                                   "libelle_source": "Télémétrie (simulée)" if der.source.startswith("telemetrie") else "Saisie manuelle",
                                   "le": der.horodatage.isoformat()} if der else None),
                   documents_controle=[{"id": str(d.id), "titre": d.titre, "echeance": d.echeance.isoformat() if d.echeance else None,
                                        "echu": bool(d.echeance and d.echeance < date.today())} for d in docs])


@router.get(E + "/materiels")
def lister(ctx: Contexte = Depends(autoriser("materiel:lire"))):
    return [etat_materiel(ctx, m) for m in ctx.db.scalars(select(Materiel).where(Materiel.exploitation_id == ctx.exploitation_id, Materiel.actif.is_(True)).order_by(Materiel.code))]


@router.post(E + "/materiels", status_code=201)
def creer(e: MaterielEntree, ctx: Contexte = Depends(autoriser("materiel:ecrire"))):
    m = Materiel(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(m)
    ctx.db.flush()
    journaliser(ctx, "creation", "materiel", m.id, apres=instantane(m))
    ctx.db.commit()
    return etat_materiel(ctx, m)


@router.get(E + "/materiels/{materiel_id}")
def lire(materiel_id: uuid.UUID, ctx: Contexte = Depends(autoriser("materiel:lire"))):
    m = obtenir(ctx, Materiel, materiel_id, "Matériel")
    d = etat_materiel(ctx, m)
    d["maintenances"] = liste(ctx.db.scalars(select(Maintenance).where(Maintenance.materiel_id == m.id).order_by(Maintenance.immobilise_du.desc().nullslast())))
    d["defauts"] = liste(ctx.db.scalars(select(Defaut).where(Defaut.materiel_id == m.id).order_by(Defaut.constate_le.desc())))
    d["releves_heures"] = liste(ctx.db.scalars(select(ReleveHeures).where(ReleveHeures.materiel_id == m.id).order_by(ReleveHeures.horodatage)))
    d["pleins"] = liste(ctx.db.scalars(select(PleinCarburant).where(PleinCarburant.materiel_id == m.id).order_by(PleinCarburant.horodatage)))
    d["consommation"] = analyse_consommation(ctx.db, m)
    return d


def analyse_consommation(db, m: Materiel) -> dict:
    """Consommation L/h entre pleins successifs et repérage statistique simple
    des valeurs atypiques (|z| > 2). Une valeur atypique est une piste
    d'investigation, pas un diagnostic de panne."""
    pleins = [p for p in db.scalars(select(PleinCarburant).where(PleinCarburant.materiel_id == m.id).order_by(PleinCarburant.horodatage)) if p.heures_compteur is not None]
    periodes = []
    for a, b in zip(pleins, pleins[1:]):
        h = Decimal(b.heures_compteur) - Decimal(a.heures_compteur)
        if h > 0:
            periodes.append({"du": a.horodatage.isoformat(), "au": b.horodatage.isoformat(), "heures": float(h),
                             "litres": float(b.litres), "l_h": round(float(Decimal(b.litres) / h), 2)})
    if len(periodes) >= 4:
        vals = [p["l_h"] for p in periodes]
        moy = sum(vals) / len(vals)
        et = (sum((v - moy) ** 2 for v in vals) / (len(vals) - 1)) ** 0.5
        for p in periodes:
            z = (p["l_h"] - moy) / et if et else 0
            p["z"] = round(z, 2)
            p["atypique"] = abs(z) > 2
        statut = "analyse"
    else:
        statut = "donnees_insuffisantes"
    return {"periodes": periodes, "statut": statut, "minimum_periodes": 4,
            "methode": "Litres du plein / heures moteur écoulées depuis le plein précédent ; écart-type sur l'historique.",
            "reference_constructeur_l_h": float(m.consommation_reference_l_h) if m.consommation_reference_l_h else None}


@router.post(E + "/materiels/{materiel_id}/maintenances", status_code=201)
def planifier_maintenance(materiel_id: uuid.UUID, e: MaintenanceEntree, ctx: Contexte = Depends(autoriser("materiel:ecrire"))):
    m = obtenir(ctx, Materiel, materiel_id, "Matériel")
    mt = Maintenance(materiel_id=m.id, **e.model_dump())
    ctx.db.add(mt)
    ctx.db.flush()
    journaliser(ctx, "creation", "maintenance", mt.id, apres=instantane(mt))
    ctx.db.commit()
    return en_dict(mt)


@router.post(E + "/maintenances/{maintenance_id}/realisation")
def realiser_maintenance(maintenance_id: uuid.UUID, ctx: Contexte = Depends(autoriser("materiel:ecrire"))):
    mt = ctx.db.get(Maintenance, maintenance_id)
    obtenir(ctx, Materiel, mt.materiel_id if mt else None, "Maintenance")
    mt.statut, mt.realisee_le = "realisee", date.today()
    journaliser(ctx, "realisation", "maintenance", mt.id)
    ctx.db.commit()
    return en_dict(mt)


@router.post(E + "/materiels/{materiel_id}/defauts", status_code=201)
def signaler_defaut(materiel_id: uuid.UUID, e: DefautEntree, ctx: Contexte = Depends(autoriser("interventions:realiser"))):
    m = obtenir(ctx, Materiel, materiel_id, "Matériel")
    d = Defaut(materiel_id=m.id, gravite=e.gravite, description=e.description, constate_le=e.constate_le or maintenant(),
               signale_par=ctx.utilisateur.id)
    ctx.db.add(d)
    ctx.db.flush()
    journaliser(ctx, "signalement_defaut", "defaut_materiel", d.id, apres=instantane(d))
    ctx.db.commit()
    return en_dict(d)


@router.post(E + "/defauts/{defaut_id}/resolution")
def resoudre_defaut(defaut_id: uuid.UUID, ctx: Contexte = Depends(autoriser("materiel:ecrire"))):
    d = ctx.db.get(Defaut, defaut_id)
    obtenir(ctx, Materiel, d.materiel_id if d else None, "Défaut")
    d.statut, d.resolu_le = "resolu", maintenant()
    journaliser(ctx, "resolution_defaut", "defaut_materiel", d.id)
    ctx.db.commit()
    return en_dict(d)


@router.post(E + "/materiels/{materiel_id}/heures", status_code=201)
def saisir_heures(materiel_id: uuid.UUID, e: HeuresEntree, ctx: Contexte = Depends(autoriser("interventions:realiser"))):
    m = obtenir(ctx, Materiel, materiel_id, "Matériel")
    r = ReleveHeures(materiel_id=m.id, horodatage=e.horodatage or maintenant(), heures_moteur=Decimal(str(e.heures_moteur)),
                     source=e.source, auteur_id=ctx.utilisateur.id)
    ctx.db.add(r)
    ctx.db.commit()
    return en_dict(r)


@router.post(E + "/materiels/{materiel_id}/pleins", status_code=201)
def faire_plein(materiel_id: uuid.UUID, e: PleinEntree, ctx: Contexte = Depends(autoriser("interventions:realiser"))):
    m = obtenir(ctx, Materiel, materiel_id, "Matériel")
    quand = e.horodatage or maintenant()
    p = PleinCarburant(materiel_id=m.id, horodatage=quand, litres=Decimal(str(e.litres)),
                       heures_compteur=Decimal(str(e.heures_compteur)) if e.heures_compteur is not None else None,
                       intervention_id=e.intervention_id)
    ctx.db.add(p)
    ctx.db.flush()
    mv = S.consommer(ctx, e.article_carburant_id, e.litres, "L", emplacement_id=e.emplacement_id, reference_type="plein",
                     reference_id=p.id, motif=f"Plein {m.libelle}", horodatage=quand)
    p.mouvement_stock_id = mv[0].id
    if e.heures_compteur is not None:
        ctx.db.add(ReleveHeures(materiel_id=m.id, horodatage=quand, heures_moteur=Decimal(str(e.heures_compteur)),
                                source="saisie", auteur_id=ctx.utilisateur.id))
    ctx.db.commit()
    return en_dict(p)
