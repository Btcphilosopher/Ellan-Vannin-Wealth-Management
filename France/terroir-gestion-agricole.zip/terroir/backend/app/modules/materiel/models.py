import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin


class Materiel(IdMixin, HorodatageMixin, Base):
    __tablename__ = "materiel"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    code: Mapped[str] = mapped_column(String(30))
    libelle: Mapped[str] = mapped_column(String(200))
    categorie: Mapped[str] = mapped_column(String(40))  # tracteur|pulverisateur|semoir|moissonneuse|remorque|outil_sol|epandeur|irrigation|vehicule|autre
    marque: Mapped[str | None] = mapped_column(String(80))
    modele: Mapped[str | None] = mapped_column(String(80))
    annee: Mapped[int | None]
    immatriculation: Mapped[str | None] = mapped_column(String(20))
    site_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("site.id"))
    propriete: Mapped[str] = mapped_column(String(20), default="propre")  # propre|cuma|location|prestataire
    debit_chantier_ha_h: Mapped[Decimal | None]
    consommation_reference_l_h: Mapped[Decimal | None]
    source_telemetrie: Mapped[str | None] = mapped_column(String(40))  # None = saisie manuelle uniquement ; simulateur
    actif: Mapped[bool] = mapped_column(default=True)


class ReleveHeures(IdMixin, Base):
    __tablename__ = "releve_heures"
    materiel_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("materiel.id", ondelete="CASCADE"), index=True)
    horodatage: Mapped[datetime]
    heures_moteur: Mapped[Decimal]
    source: Mapped[str] = mapped_column(String(30))  # saisie | telemetrie_simulee
    auteur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))


class Maintenance(IdMixin, HorodatageMixin, Base):
    __tablename__ = "maintenance"
    materiel_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("materiel.id", ondelete="CASCADE"), index=True)
    type: Mapped[str] = mapped_column(String(30))  # preventive|corrective|controle_reglementaire
    libelle: Mapped[str] = mapped_column(String(200))
    immobilise_du: Mapped[datetime | None]
    immobilise_au: Mapped[datetime | None]
    echeance_heures: Mapped[Decimal | None]
    realisee_le: Mapped[date | None]
    cout_eur: Mapped[Decimal | None]
    prestataire: Mapped[str | None] = mapped_column(String(200))
    statut: Mapped[str] = mapped_column(String(20), default="planifiee")  # planifiee|en_cours|realisee|annulee


class Defaut(IdMixin, HorodatageMixin, Base):
    __tablename__ = "defaut_materiel"
    materiel_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("materiel.id", ondelete="CASCADE"), index=True)
    constate_le: Mapped[datetime]
    gravite: Mapped[str] = mapped_column(String(20))  # bloquant|limitant|mineur
    description: Mapped[str] = mapped_column(Text)
    statut: Mapped[str] = mapped_column(String(20), default="ouvert")  # ouvert|resolu
    resolu_le: Mapped[datetime | None]
    signale_par: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))


class PleinCarburant(IdMixin, Base):
    __tablename__ = "plein_carburant"
    materiel_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("materiel.id", ondelete="CASCADE"), index=True)
    horodatage: Mapped[datetime]
    litres: Mapped[Decimal]
    heures_compteur: Mapped[Decimal | None]
    mouvement_stock_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("mouvement_stock.id", ondelete="SET NULL"))
    intervention_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("intervention.id", ondelete="SET NULL"))
    source: Mapped[str] = mapped_column(String(30), default="saisie")
