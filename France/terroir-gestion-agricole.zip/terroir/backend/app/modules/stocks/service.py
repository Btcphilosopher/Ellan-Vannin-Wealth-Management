"""Journal des mouvements, quantités et réservations.

Règles :
- le stock physique est la somme des mouvements (journal immuable) ;
- bloqué = physique des lots dont le statut n'est pas « libre » ;
- disponible = physique libre − réservations actives ;
- attendu = commandes fournisseurs non encore reçues ;
- toute opération qui diminue le disponible verrouille la ligne de
  l'article (SELECT … FOR UPDATE) : deux réservations concurrentes ne
  peuvent pas consommer le même disponible.
"""
import uuid
from dataclasses import dataclass, field
from decimal import Decimal

from sqlalchemy import func, select

from app.core.audit import instantane, journaliser
from app.core.db import maintenant
from app.core.erreurs import ErreurMetier, Introuvable
from app.core.numerotation import prochain_numero
from app.core.format_fr import court
from app.core.unites import arrondi, convertir
from app.modules.stocks.models import Article, Emplacement, LotStock, MouvementStock, Reservation

SORTIES = {"consommation", "transfert_sortie", "expedition", "perte", "sortie_lot"}
ENTREES = {"reception", "transfert_entree", "production", "entree_lot"}


def verrouiller_article(db, article_id) -> Article:
    a = db.scalar(select(Article).where(Article.id == article_id).with_for_update())
    if not a:
        raise Introuvable("Article")
    return a


def en_unite_stock(article: Article, quantite, unite: str | None) -> Decimal:
    q = Decimal(str(quantite))
    if unite is None or unite == article.unite_stock:
        return q
    return convertir(q, unite, article.unite_stock)


def physique_par_lot(db, exploitation_id, article_id=None, lot_id=None, emplacement_id=None):
    q = (select(MouvementStock.lot_id, MouvementStock.emplacement_id, func.sum(MouvementStock.quantite))
         .where(MouvementStock.exploitation_id == exploitation_id)
         .group_by(MouvementStock.lot_id, MouvementStock.emplacement_id))
    if article_id:
        q = q.where(MouvementStock.article_id == article_id)
    if lot_id:
        q = q.where(MouvementStock.lot_id == lot_id)
    if emplacement_id:
        q = q.where(MouvementStock.emplacement_id == emplacement_id)
    return {(l, e): Decimal(s or 0) for l, e, s in db.execute(q)}


def reserve_actif(db, exploitation_id, article_id, lot_id=None, emplacement_id=None, sauf_reservation=None) -> Decimal:
    q = select(func.coalesce(func.sum(Reservation.quantite), 0)).where(
        Reservation.exploitation_id == exploitation_id, Reservation.article_id == article_id,
        Reservation.statut == "active")
    if lot_id:
        q = q.where((Reservation.lot_id == lot_id) | Reservation.lot_id.is_(None))
    if emplacement_id:
        q = q.where((Reservation.emplacement_id == emplacement_id) | Reservation.emplacement_id.is_(None))
    if sauf_reservation:
        q = q.where(Reservation.id != sauf_reservation)
    return Decimal(db.scalar(q) or 0)


def disponible(db, exploitation_id, article_id, lot_id=None, emplacement_id=None, sauf_reservation=None) -> Decimal:
    phys = physique_par_lot(db, exploitation_id, article_id, lot_id, emplacement_id)
    statuts = dict(db.execute(select(LotStock.id, LotStock.statut).where(LotStock.article_id == article_id)).all())
    libre = sum((q for (l, _), q in phys.items() if statuts.get(l) == "libre"), Decimal(0))
    return libre - reserve_actif(db, exploitation_id, article_id, lot_id, emplacement_id, sauf_reservation)


def etat_article(db, exploitation_id, article: Article) -> dict:
    from app.modules.commercial.models import CommandeFournisseur, LigneCommandeFournisseur

    phys = physique_par_lot(db, exploitation_id, article.id)
    lots = {l.id: l for l in db.scalars(select(LotStock).where(LotStock.article_id == article.id))}
    physique = sum(phys.values(), Decimal(0))
    bloque = sum((q for (l, _), q in phys.items() if lots.get(l) and lots[l].statut != "libre"), Decimal(0))
    reserve = reserve_actif(db, exploitation_id, article.id)
    attendu = Decimal(0)
    for lc, cmd in db.execute(select(LigneCommandeFournisseur, CommandeFournisseur).join(CommandeFournisseur)
                              .where(LigneCommandeFournisseur.article_id == article.id,
                                     CommandeFournisseur.statut.in_(["envoyee", "partiellement_recue"]))):
        reste = Decimal(lc.quantite) - Decimal(lc.quantite_recue or 0)
        if reste > 0:
            attendu += en_unite_stock(article, reste, lc.unite)
    dispo = physique - bloque - reserve
    return {
        "article_id": str(article.id), "code": article.code, "libelle": article.libelle,
        "categorie": article.categorie, "unite": article.unite_stock,
        "physique": arrondi(physique), "bloque": arrondi(bloque), "reserve": arrondi(reserve),
        "disponible": arrondi(dispo), "attendu": arrondi(attendu),
        "seuil_alerte": float(article.seuil_alerte) if article.seuil_alerte is not None else None,
        "alerte": ("rupture" if dispo <= 0 else
                   "sous_seuil" if article.seuil_alerte is not None and dispo < article.seuil_alerte else None),
        "par_lot": [
            {"lot_id": str(l), "numero": lots[l].numero if l in lots else None, "emplacement_id": str(e),
             "quantite": arrondi(q), "statut": lots[l].statut if l in lots else None,
             "date_peremption": lots[l].date_peremption.isoformat() if l in lots and lots[l].date_peremption else None,
             "apte_vente": lots[l].apte_vente if l in lots else None}
            for (l, e), q in phys.items() if q != 0
        ],
    }


def enregistrer_mouvement(ctx, type_: str, lot: LotStock, emplacement_id, quantite: Decimal, *,
                          unite_saisie=None, quantite_saisie=None, motif=None, reference_type=None,
                          reference_id=None, corrige=None, transfert_id=None, horodatage=None,
                          controle_physique=True, cout_unitaire=None) -> MouvementStock:
    """quantite : valeur absolue dans l'unité de stock ; le signe dépend du type."""
    db = ctx.db
    if quantite <= 0 and type_ not in ("correction", "inventaire"):
        raise ErreurMetier("quantite_positive")
    article = db.get(Article, lot.article_id)
    signe = Decimal(-1) if type_ in SORTIES else Decimal(1)
    q = quantite * signe if type_ not in ("correction", "inventaire") else quantite
    if q < 0 and controle_physique:
        phys = physique_par_lot(db, ctx.exploitation_id, lot_id=lot.id, emplacement_id=emplacement_id)
        en_stock = phys.get((lot.id, emplacement_id), Decimal(0))
        if en_stock + q < 0:
            raise ErreurMetier("stock_insuffisant", article=article.libelle, disponible=court(en_stock),
                               demande=court(-q), unite=article.unite_stock)
    m = MouvementStock(
        exploitation_id=ctx.exploitation_id, numero=prochain_numero(db, ctx.exploitation_id, "MVT"),
        type=type_, article_id=lot.article_id, lot_id=lot.id, emplacement_id=emplacement_id, quantite=q,
        unite=article.unite_stock, quantite_saisie=quantite_saisie, unite_saisie=unite_saisie,
        horodatage=horodatage or maintenant(), enregistre_le=maintenant(), auteur_id=ctx.utilisateur.id,
        motif=motif, reference_type=reference_type, reference_id=reference_id,
        corrige_mouvement_id=corrige, transfert_id=transfert_id, cout_unitaire=cout_unitaire,
    )
    db.add(m)
    db.flush()
    journaliser(ctx, f"mouvement_{type_}", "mouvement_stock", m.id, apres=instantane(m))
    return m


def reserver(ctx, article_id, quantite, unite, pour_type, pour_id, lot_id=None, emplacement_id=None,
             date_besoin=None) -> Reservation:
    db = ctx.db
    article = verrouiller_article(db, article_id)
    q = en_unite_stock(article, quantite, unite)
    if q <= 0:
        raise ErreurMetier("quantite_positive")
    dispo = disponible(db, ctx.exploitation_id, article.id, lot_id, emplacement_id)
    if dispo < q:
        raise ErreurMetier("stock_insuffisant", statut_http=409, article=article.libelle,
                           disponible=court(max(dispo, 0)), demande=court(q), unite=article.unite_stock)
    r = Reservation(exploitation_id=ctx.exploitation_id, article_id=article.id, lot_id=lot_id,
                    emplacement_id=emplacement_id, quantite=q, unite=article.unite_stock, pour_type=pour_type,
                    pour_id=pour_id, date_besoin=date_besoin, auteur_id=ctx.utilisateur.id)
    db.add(r)
    db.flush()
    journaliser(ctx, "reservation", "reservation", r.id, apres=instantane(r))
    return r


def annuler_reservation(ctx, r: Reservation, motif="annulation"):
    if r.statut != "active":
        raise ErreurMetier("reservation_inactive")
    r.statut = "annulee"
    journaliser(ctx, "annulation_reservation", "reservation", r.id, apres={"motif": motif})


@dataclass
class Prelevement:
    lot: LotStock
    emplacement_id: uuid.UUID
    quantite: Decimal
    mouvements: list = field(default_factory=list)


def choisir_lots(ctx, article: Article, quantite: Decimal, emplacement_id=None, lot_id=None) -> list[Prelevement]:
    """Premier périmé, premier sorti ; seuls les lots libres sont utilisables."""
    phys = physique_par_lot(ctx.db, ctx.exploitation_id, article.id, lot_id, emplacement_id)
    lots = {l.id: l for l in ctx.db.scalars(select(LotStock).where(LotStock.article_id == article.id))}
    if lot_id and lots.get(lot_id) and lots[lot_id].statut != "libre":
        raise ErreurMetier("lot_bloque", lot=lots[lot_id].numero, statut=lots[lot_id].statut)
    candidats = sorted(
        [(lots[l], e, q) for (l, e), q in phys.items() if q > 0 and lots[l].statut == "libre"],
        key=lambda t: (t[0].date_peremption or __import__("datetime").date.max, t[0].date_entree or __import__("datetime").date.min),
    )
    reste, res = quantite, []
    for lot, e, q in candidats:
        if reste <= 0:
            break
        pris = min(q, reste)
        res.append(Prelevement(lot, e, pris))
        reste -= pris
    if reste > 0:
        total = sum((p.quantite for p in res), Decimal(0))
        raise ErreurMetier("stock_insuffisant", statut_http=409, article=article.libelle, disponible=court(total),
                           demande=court(quantite), unite=article.unite_stock)
    return res


def consommer(ctx, article_id, quantite, unite, *, reservation: Reservation | None = None, lot_id=None,
              emplacement_id=None, reference_type=None, reference_id=None, motif=None, horodatage=None,
              type_="consommation") -> list[MouvementStock]:
    db = ctx.db
    article = verrouiller_article(db, article_id)
    q = en_unite_stock(article, quantite, unite)
    if q <= 0:
        raise ErreurMetier("quantite_positive")
    lot_demande = db.get(LotStock, lot_id) if lot_id else None
    if lot_demande and lot_demande.statut != "libre":
        raise ErreurMetier("lot_bloque", statut_http=409, lot=lot_demande.numero, statut=lot_demande.statut)
    # Le disponible inclut la réservation que l'on consomme.
    dispo = disponible(db, ctx.exploitation_id, article.id, lot_id, emplacement_id,
                       sauf_reservation=reservation.id if reservation else None)
    if dispo < q:
        raise ErreurMetier("stock_insuffisant", statut_http=409, article=article.libelle,
                           disponible=court(max(dispo, 0)), demande=court(q), unite=article.unite_stock)
    lot_id = lot_id or (reservation.lot_id if reservation else None)
    emplacement_id = emplacement_id or (reservation.emplacement_id if reservation else None)
    mvts = []
    for p in choisir_lots(ctx, article, q, emplacement_id, lot_id):
        mvts.append(enregistrer_mouvement(ctx, type_, p.lot, p.emplacement_id, p.quantite,
                                          unite_saisie=unite, quantite_saisie=Decimal(str(quantite)), motif=motif,
                                          reference_type=reference_type, reference_id=reference_id,
                                          horodatage=horodatage, cout_unitaire=p.lot.cout_unitaire))
    if reservation and reservation.statut == "active":
        reservation.statut = "consommee"
    return mvts


def transferer(ctx, lot: LotStock, de_id, vers_id, quantite, unite, motif=None) -> list[MouvementStock]:
    article = verrouiller_article(ctx.db, lot.article_id)
    q = en_unite_stock(article, quantite, unite)
    tid = uuid.uuid4()
    s = enregistrer_mouvement(ctx, "transfert_sortie", lot, de_id, q, motif=motif, transfert_id=tid)
    e = enregistrer_mouvement(ctx, "transfert_entree", lot, vers_id, q, motif=motif, transfert_id=tid)
    return [s, e]


def corriger(ctx, mouvement_id, quantite_correcte, motif: str) -> MouvementStock:
    """Crée un mouvement de correction lié ; le mouvement d'origine reste intact."""
    db = ctx.db
    m = db.get(MouvementStock, mouvement_id)
    if not m or m.exploitation_id != ctx.exploitation_id:
        raise Introuvable("Mouvement")
    if db.scalar(select(MouvementStock.id).where(MouvementStock.corrige_mouvement_id == m.id)):
        raise ErreurMetier("correction_deja", statut_http=409)
    verrouiller_article(db, m.article_id)
    signe = Decimal(1) if m.quantite > 0 else Decimal(-1)
    cible = Decimal(str(quantite_correcte)) * signe
    delta = cible - m.quantite
    if delta == 0:
        raise ErreurMetier("donnee_invalide", detail="la correction ne change pas la quantité")
    lot = db.get(LotStock, m.lot_id)
    if delta < 0:
        phys = physique_par_lot(db, ctx.exploitation_id, lot_id=lot.id, emplacement_id=m.emplacement_id)
        if phys.get((lot.id, m.emplacement_id), Decimal(0)) + delta < 0:
            article = db.get(Article, m.article_id)
            raise ErreurMetier("stock_insuffisant", article=article.libelle, disponible=arrondi(phys.get((lot.id, m.emplacement_id), 0)),
                               demande=court(-delta), unite=m.unite)
    return enregistrer_mouvement(ctx, "correction", lot, m.emplacement_id, delta, motif=motif, corrige=m.id,
                                 reference_type=m.reference_type, reference_id=m.reference_id,
                                 horodatage=m.horodatage, controle_physique=False)


def creer_lot(ctx, article: Article, numero: str | None = None, **champs) -> LotStock:
    from app.core.numerotation import numero_formate

    lot = LotStock(exploitation_id=ctx.exploitation_id, article_id=article.id,
                   numero=numero or numero_formate(ctx.db, ctx.exploitation_id, "LOT", maintenant().year),
                   unite=article.unite_stock, **champs)
    ctx.db.add(lot)
    ctx.db.flush()
    journaliser(ctx, "creation", "lot_stock", lot.id, apres=instantane(lot))
    return lot


def verifier_emplacement(ctx, emplacement_id):
    e = ctx.db.get(Emplacement, emplacement_id)
    if not e or e.exploitation_id != ctx.exploitation_id:
        raise Introuvable("Emplacement")
    return e
