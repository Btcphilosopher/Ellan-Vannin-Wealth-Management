import uuid
from datetime import date, datetime

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import select

from app.core.audit import instantane, journaliser
from app.core.crud import obtenir
from app.core.db import maintenant
from app.core.erreurs import ErreurMetier
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.i18n.fr import LIBELLES
from app.modules.stocks import service as S
from app.modules.stocks.models import Article, Emplacement, LotStock, MouvementStock, ObservationStockage, Reservation

router = APIRouter(tags=["Stocks et stockage"])
E = "/exploitations/{exploitation_id}"


class ArticleEntree(Entree):
    code: str
    libelle: str
    categorie: str
    unite_stock: str
    reglemente: bool = False
    produit_referentiel_id: uuid.UUID | None = None
    numero_amm_saisi: str | None = None
    fournisseur_habituel_id: uuid.UUID | None = None
    seuil_alerte: float | None = None
    culture: str | None = None


class EmplacementEntree(Entree):
    site_id: uuid.UUID
    code: str
    nom: str
    type: str
    capacite: float | None = None
    unite_capacite: str | None = None
    cout_stockage_eur_t_mois: float | None = None
    source_cout_stockage: str | None = None


class EntreeDirecte(Entree):
    article_id: uuid.UUID
    emplacement_id: uuid.UUID
    quantite: float
    unite: str
    numero_lot_fournisseur: str | None = None
    date_peremption: date | None = None
    motif: str = "Entrée hors commande (inventaire initial)"
    cout_unitaire: float | None = None


class Sortie(Entree):
    article_id: uuid.UUID
    quantite: float
    unite: str
    lot_id: uuid.UUID | None = None
    emplacement_id: uuid.UUID | None = None
    motif: str | None = None


class Transfert(Entree):
    lot_id: uuid.UUID
    de_emplacement_id: uuid.UUID
    vers_emplacement_id: uuid.UUID
    quantite: float
    unite: str
    motif: str | None = None


class Correction(Entree):
    quantite_correcte: float
    motif: str


class ReservationEntree(Entree):
    article_id: uuid.UUID
    quantite: float
    unite: str
    pour_type: str
    pour_id: uuid.UUID
    lot_id: uuid.UUID | None = None
    emplacement_id: uuid.UUID | None = None
    date_besoin: date | None = None


class StatutLot(Entree):
    statut: str  # libre|bloque|quarantaine|en_attente_controle
    motif: str
    version: int | None = None


class DecisionVente(Entree):
    apte_vente: bool
    motif: str


class ObservationEntree(Entree):
    emplacement_id: uuid.UUID
    lot_id: uuid.UUID | None = None
    horodatage: datetime | None = None
    temperature_c: float | None = None
    humidite_relative_pct: float | None = None
    humidite_produit_pct: float | None = None
    qualite: str | None = None
    source: str = "saisie"


@router.get(E + "/articles")
def lister_articles(ctx: Contexte = Depends(autoriser("stocks:lire")), categorie: str | None = None):
    q = select(Article).where(Article.exploitation_id == ctx.exploitation_id, Article.actif.is_(True))
    if categorie:
        q = q.where(Article.categorie == categorie)
    return liste(ctx.db.scalars(q.order_by(Article.categorie, Article.libelle)))


@router.post(E + "/articles", status_code=201)
def creer_article(e: ArticleEntree, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    from app.core.unites import unite

    unite(e.unite_stock)
    a = Article(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(a)
    ctx.db.flush()
    journaliser(ctx, "creation", "article", a.id, apres=instantane(a))
    ctx.db.commit()
    return en_dict(a)


@router.get(E + "/emplacements")
def lister_emplacements(ctx: Contexte = Depends(autoriser("stocks:lire"))):
    return liste(ctx.db.scalars(select(Emplacement).where(Emplacement.exploitation_id == ctx.exploitation_id).order_by(Emplacement.code)))


@router.post(E + "/emplacements", status_code=201)
def creer_emplacement(e: EmplacementEntree, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    m = Emplacement(exploitation_id=ctx.exploitation_id, **e.model_dump())
    ctx.db.add(m)
    ctx.db.flush()
    journaliser(ctx, "creation", "emplacement", m.id, apres=instantane(m))
    ctx.db.commit()
    return en_dict(m)


@router.get(E + "/stocks")
def etat_stocks(ctx: Contexte = Depends(autoriser("stocks:lire")), categorie: str | None = None):
    q = select(Article).where(Article.exploitation_id == ctx.exploitation_id, Article.actif.is_(True))
    if categorie:
        q = q.where(Article.categorie == categorie)
    return {
        "definitions": {
            "physique": "Somme des mouvements enregistrés (présent dans les emplacements).",
            "bloque": "Part du physique dont le lot n'est pas libre (blocage, quarantaine, contrôle).",
            "reserve": "Réservations actives (interventions, commandes clients).",
            "disponible": "Physique − bloqué − réservé.",
            "attendu": "Quantités commandées aux fournisseurs non encore reçues.",
        },
        "articles": [S.etat_article(ctx.db, ctx.exploitation_id, a) for a in ctx.db.scalars(q.order_by(Article.categorie, Article.libelle))],
    }


@router.get(E + "/lots")
def lister_lots(ctx: Contexte = Depends(autoriser("stocks:lire")), article_id: uuid.UUID | None = None,
                origine: str | None = None):
    q = select(LotStock).where(LotStock.exploitation_id == ctx.exploitation_id)
    if article_id:
        q = q.where(LotStock.article_id == article_id)
    if origine:
        q = q.where(LotStock.origine == origine)
    res = []
    for l in ctx.db.scalars(q.order_by(LotStock.cree_le.desc())):
        phys = S.physique_par_lot(ctx.db, ctx.exploitation_id, lot_id=l.id)
        res.append(en_dict(l, quantite_actuelle=float(sum(phys.values())) if phys else 0.0))
    return res


@router.get(E + "/mouvements")
def journal(ctx: Contexte = Depends(autoriser("stocks:lire")), article_id: uuid.UUID | None = None,
            lot_id: uuid.UUID | None = None, limite: int = 200):
    q = select(MouvementStock).where(MouvementStock.exploitation_id == ctx.exploitation_id)
    if article_id:
        q = q.where(MouvementStock.article_id == article_id)
    if lot_id:
        q = q.where(MouvementStock.lot_id == lot_id)
    mvts = ctx.db.scalars(q.order_by(MouvementStock.numero.desc()).limit(limite)).all()
    corriges = {m.corrige_mouvement_id for m in mvts if m.corrige_mouvement_id}
    return [en_dict(m, libelle_type=LIBELLES["type_mouvement"].get(m.type, m.type), est_corrige=m.id in corriges) for m in mvts]


@router.post(E + "/stocks/entrees", status_code=201)
def entree_directe(e: EntreeDirecte, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    a = obtenir(ctx, Article, e.article_id, "Article")
    S.verifier_emplacement(ctx, e.emplacement_id)
    lot = S.creer_lot(ctx, a, origine="inventaire", date_entree=date.today(), date_peremption=e.date_peremption,
                      numero_lot_fournisseur=e.numero_lot_fournisseur, cout_unitaire=e.cout_unitaire)
    q = S.en_unite_stock(a, e.quantite, e.unite)
    lot.quantite_initiale = q
    m = S.enregistrer_mouvement(ctx, "reception", lot, e.emplacement_id, q, unite_saisie=e.unite,
                                quantite_saisie=e.quantite, motif=e.motif, cout_unitaire=e.cout_unitaire)
    ctx.db.commit()
    return {"lot": en_dict(lot), "mouvement": en_dict(m)}


@router.post(E + "/stocks/consommations", status_code=201)
def consommation(e: Sortie, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    obtenir(ctx, Article, e.article_id, "Article")
    m = S.consommer(ctx, e.article_id, e.quantite, e.unite, lot_id=e.lot_id, emplacement_id=e.emplacement_id, motif=e.motif)
    ctx.db.commit()
    return liste(m)


@router.post(E + "/stocks/pertes", status_code=201)
def perte(e: Sortie, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    if not e.motif:
        raise ErreurMetier("donnee_invalide", detail="le motif de la perte est obligatoire")
    obtenir(ctx, Article, e.article_id, "Article")
    m = S.consommer(ctx, e.article_id, e.quantite, e.unite, lot_id=e.lot_id, emplacement_id=e.emplacement_id,
                    motif=e.motif, type_="perte")
    ctx.db.commit()
    return liste(m)


@router.post(E + "/stocks/transferts", status_code=201)
def transfert(e: Transfert, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    lot = obtenir(ctx, LotStock, e.lot_id, "Lot")
    S.verifier_emplacement(ctx, e.vers_emplacement_id)
    m = S.transferer(ctx, lot, e.de_emplacement_id, e.vers_emplacement_id, e.quantite, e.unite, e.motif)
    ctx.db.commit()
    return liste(m)


@router.post(E + "/mouvements/{mouvement_id}/correction", status_code=201)
def correction(mouvement_id: uuid.UUID, e: Correction, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    m = S.corriger(ctx, mouvement_id, e.quantite_correcte, e.motif)
    ctx.db.commit()
    return en_dict(m)


@router.get(E + "/reservations")
def lister_reservations(ctx: Contexte = Depends(autoriser("stocks:lire")), statut: str = "active"):
    return liste(ctx.db.scalars(select(Reservation).where(Reservation.exploitation_id == ctx.exploitation_id,
                                                          Reservation.statut == statut)))


@router.post(E + "/reservations", status_code=201)
def creer_reservation(e: ReservationEntree, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    obtenir(ctx, Article, e.article_id, "Article")
    r = S.reserver(ctx, **e.model_dump())
    ctx.db.commit()
    return en_dict(r)


@router.post(E + "/reservations/{reservation_id}/annulation")
def annuler(reservation_id: uuid.UUID, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    r = obtenir(ctx, Reservation, reservation_id, "Réservation")
    S.annuler_reservation(ctx, r)
    ctx.db.commit()
    return en_dict(r)


@router.post(E + "/lots/{lot_id}/statut")
def changer_statut_lot(lot_id: uuid.UUID, e: StatutLot, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    from app.core.crud import verifier_version

    lot = obtenir(ctx, LotStock, lot_id, "Lot")
    verifier_version(lot, e.version)
    if e.statut not in ("libre", "bloque", "quarantaine", "en_attente_controle"):
        raise ErreurMetier("donnee_invalide", detail="statut inconnu")
    avant = {"statut": lot.statut, "motif": lot.motif_statut}
    lot.statut, lot.motif_statut = e.statut, e.motif
    lot.version += 1
    journaliser(ctx, "changement_statut", "lot_stock", lot.id, avant=avant, apres={"statut": e.statut, "motif": e.motif})
    ctx.db.commit()
    return en_dict(lot)


@router.post(E + "/lots/{lot_id}/decision-vente")
def decision_vente(lot_id: uuid.UUID, e: DecisionVente, ctx: Contexte = Depends(autoriser("stocks:liberer"))):
    """Décision humaine explicite : les relevés de conservation ne suffisent jamais."""
    lot = obtenir(ctx, LotStock, lot_id, "Lot")
    avant = {"apte_vente": lot.apte_vente}
    lot.apte_vente = e.apte_vente
    lot.apte_vente_decision = {"par": ctx.utilisateur.nom_affiche, "le": maintenant().isoformat(), "motif": e.motif}
    lot.version += 1
    journaliser(ctx, "decision_aptitude_vente", "lot_stock", lot.id, avant=avant, apres=lot.apte_vente_decision | {"apte_vente": e.apte_vente})
    ctx.db.commit()
    return en_dict(lot)


@router.get(E + "/observations-stockage")
def lister_observations(ctx: Contexte = Depends(autoriser("stocks:lire")), emplacement_id: uuid.UUID | None = None):
    q = select(ObservationStockage).where(ObservationStockage.exploitation_id == ctx.exploitation_id)
    if emplacement_id:
        q = q.where(ObservationStockage.emplacement_id == emplacement_id)
    return liste(ctx.db.scalars(q.order_by(ObservationStockage.horodatage.desc()).limit(300)))


@router.post(E + "/observations-stockage", status_code=201)
def creer_observation(e: ObservationEntree, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    S.verifier_emplacement(ctx, e.emplacement_id)
    o = ObservationStockage(exploitation_id=ctx.exploitation_id, auteur_id=ctx.utilisateur.id,
                            **(e.model_dump() | {"horodatage": e.horodatage or maintenant()}))
    ctx.db.add(o)
    ctx.db.flush()
    journaliser(ctx, "creation", "observation_stockage", o.id, apres=instantane(o))
    ctx.db.commit()
    return en_dict(o, avertissement="Relevé enregistré. Il ne rend pas le lot apte à la vente : une décision explicite est nécessaire.")
