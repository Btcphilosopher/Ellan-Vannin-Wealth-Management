import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import CheckConstraint, ForeignKey, Index, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin, VersionMixin

CATEGORIES_ARTICLE = [
    "semence", "engrais", "amendement", "substrat", "phytopharmaceutique", "biocontrole",
    "carburant", "piece_detachee", "aliment_animal", "produit_recolte", "emballage",
    "produit_fini", "fourniture",
]


class Article(IdMixin, HorodatageMixin, Base):
    __tablename__ = "article"
    __table_args__ = (UniqueConstraint("exploitation_id", "code"),)
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    code: Mapped[str] = mapped_column(String(40))
    libelle: Mapped[str] = mapped_column(String(200))
    categorie: Mapped[str] = mapped_column(String(30))
    unite_stock: Mapped[str] = mapped_column(String(10))
    reglemente: Mapped[bool] = mapped_column(default=False)
    produit_referentiel_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("produit_referentiel.id", ondelete="SET NULL"))
    numero_amm_saisi: Mapped[str | None] = mapped_column(String(30))
    fournisseur_habituel_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("fournisseur.id", ondelete="SET NULL"))
    seuil_alerte: Mapped[Decimal | None]
    culture: Mapped[str | None] = mapped_column(String(80))  # pour les produits récoltés
    actif: Mapped[bool] = mapped_column(default=True)


class Emplacement(IdMixin, HorodatageMixin, Base):
    __tablename__ = "emplacement"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    site_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("site.id"))
    code: Mapped[str] = mapped_column(String(30))
    nom: Mapped[str] = mapped_column(String(120))
    type: Mapped[str] = mapped_column(String(30))  # magasin|local_phyto|silo|cellule|chambre_froide|cuve|batiment|quai
    capacite: Mapped[Decimal | None]
    unite_capacite: Mapped[str | None] = mapped_column(String(10))
    cout_stockage_eur_t_mois: Mapped[Decimal | None]
    source_cout_stockage: Mapped[str | None] = mapped_column(String(200))


class LotStock(IdMixin, HorodatageMixin, VersionMixin, Base):
    __tablename__ = "lot_stock"
    __table_args__ = (UniqueConstraint("exploitation_id", "numero"),)
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    article_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("article.id"), index=True)
    numero: Mapped[str] = mapped_column(String(60))
    numero_lot_fournisseur: Mapped[str | None] = mapped_column(String(60))
    fournisseur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("fournisseur.id", ondelete="SET NULL"))
    origine: Mapped[str] = mapped_column(String(30))  # achat|recolte|division|regroupement|classement|conditionnement|transformation|inventaire|naissance
    date_entree: Mapped[date | None]
    date_peremption: Mapped[date | None]
    statut: Mapped[str] = mapped_column(String(30), default="libre")  # libre|bloque|quarantaine|en_attente_controle|epuise
    motif_statut: Mapped[str | None] = mapped_column(Text)
    # Récolte
    parcelle_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("parcelle.id"))
    cycle_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("cycle_cultural.id"))
    intervention_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("intervention.id"))
    culture: Mapped[str | None] = mapped_column(String(80))
    variete: Mapped[str | None] = mapped_column(String(80))
    date_recolte: Mapped[date | None]
    quantite_initiale: Mapped[Decimal | None]
    unite: Mapped[str] = mapped_column(String(10))
    qualite_observee: Mapped[dict | None]  # {humidite_pct, poids_specifique, calibre, notes, mesure_par}
    classement: Mapped[str | None] = mapped_column(String(60))
    # Décision humaine explicite : jamais positionnée automatiquement.
    apte_vente: Mapped[bool] = mapped_column(default=False)
    apte_vente_decision: Mapped[dict | None]  # {par, le, motif}
    cout_unitaire: Mapped[Decimal | None]  # coût d'acquisition (achats)
    documents: Mapped[list] = mapped_column(default=list)


class MouvementStock(IdMixin, Base):
    """Journal immuable. Une erreur se corrige par un mouvement de correction lié."""

    __tablename__ = "mouvement_stock"
    __table_args__ = (
        Index("ix_mvt_lot_empl", "lot_id", "emplacement_id"),
        CheckConstraint("quantite <> 0", name="quantite_non_nulle"),
    )
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    numero: Mapped[int] = mapped_column(index=True)
    type: Mapped[str] = mapped_column(String(30))
    article_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("article.id"), index=True)
    lot_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lot_stock.id"))
    emplacement_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("emplacement.id"))
    quantite: Mapped[Decimal]  # signée, dans l'unité de stock de l'article
    unite: Mapped[str] = mapped_column(String(10))
    quantite_saisie: Mapped[Decimal | None]
    unite_saisie: Mapped[str | None] = mapped_column(String(10))
    horodatage: Mapped[datetime]
    enregistre_le: Mapped[datetime]
    auteur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    motif: Mapped[str | None] = mapped_column(Text)
    corrige_mouvement_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("mouvement_stock.id"))
    transfert_id: Mapped[uuid.UUID | None]
    reference_type: Mapped[str | None] = mapped_column(String(40))  # intervention|reception|expedition|evenement_elevage|plein
    reference_id: Mapped[uuid.UUID | None]
    cout_unitaire: Mapped[Decimal | None]


class Reservation(IdMixin, HorodatageMixin, Base):
    __tablename__ = "reservation"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    article_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("article.id"), index=True)
    lot_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("lot_stock.id"))
    emplacement_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("emplacement.id"))
    quantite: Mapped[Decimal]
    unite: Mapped[str] = mapped_column(String(10))
    statut: Mapped[str] = mapped_column(String(20), default="active")  # active|consommee|annulee
    pour_type: Mapped[str] = mapped_column(String(40))  # intervention|commande_client|evenement_elevage
    pour_id: Mapped[uuid.UUID]
    date_besoin: Mapped[date | None]
    auteur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))


class ObservationStockage(IdMixin, Base):
    """Relevé de conservation. N'entraîne jamais l'aptitude à la vente."""

    __tablename__ = "observation_stockage"
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    emplacement_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("emplacement.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("lot_stock.id"))
    horodatage: Mapped[datetime]
    temperature_c: Mapped[Decimal | None]
    humidite_relative_pct: Mapped[Decimal | None]
    humidite_produit_pct: Mapped[Decimal | None]
    qualite: Mapped[str | None] = mapped_column(Text)
    source: Mapped[str] = mapped_column(String(40), default="saisie")  # saisie|capteur_simule
    auteur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
