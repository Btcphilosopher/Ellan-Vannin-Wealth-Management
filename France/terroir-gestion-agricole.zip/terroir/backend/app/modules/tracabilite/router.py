import uuid
from datetime import date

from fastapi import APIRouter, Depends
from app.core.schemas import Entree
from sqlalchemy import select

from app.core.crud import obtenir
from app.core.securite import Contexte, autoriser
from app.core.serial import en_dict, liste
from app.modules.cultures.models import CycleCultural
from app.modules.stocks.models import LotStock
from app.modules.tracabilite import service as T

router = APIRouter(tags=["Récoltes et traçabilité"])
E = "/exploitations/{exploitation_id}"


class RecolteEntree(Entree):
    intervention_id: uuid.UUID
    article_id: uuid.UUID
    quantite: float
    unite: str
    emplacement_id: uuid.UUID
    date_recolte: date
    qualite_observee: dict | None = None
    variete: str | None = None
    numero: str | None = None
    statut: str = "en_attente_controle"
    client_prevu: str | None = None


class Part(Entree):
    quantite: float
    unite: str | None = None
    emplacement_id: uuid.UUID | None = None
    classement: str | None = None
    numero: str | None = None
    perte: bool = False
    motif: str | None = None


class DivisionEntree(Entree):
    emplacement_source_id: uuid.UUID
    parts: list[Part]
    type: str = "division"  # division | classement


class SourceRegroupement(Entree):
    lot_id: uuid.UUID
    emplacement_id: uuid.UUID
    quantite: float
    unite: str | None = None


class RegroupementEntree(Entree):
    sources: list[SourceRegroupement]
    emplacement_id: uuid.UUID
    numero: str | None = None


class ConditionnementEntree(Entree):
    emplacement_source_id: uuid.UUID
    quantite_source: float
    unite_source: str
    article_fini_id: uuid.UUID
    nombre_unites: float
    emplacement_destination_id: uuid.UUID
    emballage_article_id: uuid.UUID | None = None
    emballages_par_unite: float = 1
    numero: str | None = None


@router.post(E + "/recoltes", status_code=201)
def recolter(e: RecolteEntree, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    lot, m = T.enregistrer_recolte(ctx, **e.model_dump())
    ctx.db.commit()
    return {"lot": en_dict(lot), "mouvement": en_dict(m)}


@router.post(E + "/lots/{lot_id}/division", status_code=201)
def diviser(lot_id: uuid.UUID, e: DivisionEntree, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    lot = obtenir(ctx, LotStock, lot_id, "Lot")
    parts = [p.model_dump() | {"emplacement_id": p.emplacement_id or e.emplacement_source_id} for p in e.parts]
    enfants = T.diviser(ctx, lot, e.emplacement_source_id, parts, e.type)
    ctx.db.commit()
    return liste(enfants)


@router.post(E + "/lots/regroupement", status_code=201)
def regrouper(e: RegroupementEntree, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    lot = T.regrouper(ctx, [s.model_dump() for s in e.sources], e.emplacement_id, e.numero)
    ctx.db.commit()
    return en_dict(lot)


@router.post(E + "/lots/{lot_id}/conditionnement", status_code=201)
def conditionner(lot_id: uuid.UUID, e: ConditionnementEntree, ctx: Contexte = Depends(autoriser("stocks:ecrire"))):
    lot = obtenir(ctx, LotStock, lot_id, "Lot")
    enfant = T.conditionner(ctx, lot, e.emplacement_source_id, e.quantite_source, e.unite_source, e.article_fini_id,
                            e.nombre_unites, e.emplacement_destination_id, e.emballage_article_id,
                            e.emballages_par_unite, e.numero)
    ctx.db.commit()
    return en_dict(enfant)


@router.get(E + "/tracabilite/lots/{lot_id}")
def tracabilite_lot(lot_id: uuid.UUID, ctx: Contexte = Depends(autoriser("stocks:lire"))):
    obtenir(ctx, LotStock, lot_id, "Lot")
    return T.rapport_lot(ctx.db, lot_id)


@router.get(E + "/tracabilite/parcelles/{parcelle_id}")
def tracabilite_parcelle(parcelle_id: uuid.UUID, ctx: Contexte = Depends(autoriser("stocks:lire")),
                         campagne_id: uuid.UUID | None = None):
    from app.modules.foncier.models import Parcelle

    obtenir(ctx, Parcelle, parcelle_id, "Parcelle")
    q = select(LotStock).where(LotStock.parcelle_id == parcelle_id, LotStock.origine == "recolte")
    if campagne_id:
        q = q.join(CycleCultural, CycleCultural.id == LotStock.cycle_id).where(CycleCultural.campagne_id == campagne_id)
    return [T.rapport_lot(ctx.db, l.id) for l in ctx.db.scalars(q)]


@router.get(E + "/tracabilite/expeditions/{expedition_id}")
def tracabilite_expedition(expedition_id: uuid.UUID, ctx: Contexte = Depends(autoriser("stocks:lire"))):
    from app.modules.commercial.models import Expedition

    ex = obtenir(ctx, Expedition, expedition_id, "Expédition")
    lots = sorted({l["lot_id"] for l in ex.lignes})
    return {"expedition": en_dict(ex), "lots": [T.rapport_lot(ctx.db, uuid.UUID(l)) for l in lots]}
