import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import CheckConstraint, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, IdMixin


class LienLot(IdMixin, Base):
    """Généalogie des lots (graphe orienté acyclique).

    division : un parent → plusieurs enfants ; regroupement : plusieurs
    parents → un enfant (les relations aux parents sont toutes conservées).
    """

    __tablename__ = "lien_lot"
    __table_args__ = (CheckConstraint("parent_id <> enfant_id", name="pas_auto_lien"),)
    exploitation_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("exploitation.id", ondelete="CASCADE"), index=True)
    parent_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lot_stock.id"), index=True)
    enfant_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("lot_stock.id"), index=True)
    type: Mapped[str] = mapped_column(String(30))  # division|regroupement|classement|conditionnement|transformation
    quantite: Mapped[Decimal]
    unite: Mapped[str] = mapped_column(String(10))
    horodatage: Mapped[datetime]
    auteur_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("utilisateur.id", ondelete="SET NULL"))
    notes: Mapped[str | None] = mapped_column(Text)
