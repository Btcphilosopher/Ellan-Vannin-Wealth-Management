"""Récoltes, généalogie des lots et traçabilité.

Parcelle → lot récolté → stockage → transformation/conditionnement → expédition.
Les maillons manquants sont signalés ; aucune donnée n'est inventée pour
compléter une chaîne.
"""
import uuid
from decimal import Decimal

from sqlalchemy import select, text

from app.core.audit import instantane, journaliser
from app.core.db import maintenant
from app.core.erreurs import ErreurMetier, Introuvable
from app.core.unites import arrondi
from app.modules.commercial.models import Client, CommandeClient, Expedition
from app.modules.cultures.models import CycleCultural
from app.modules.foncier.models import Parcelle
from app.modules.interventions.models import Intervention
from app.modules.stocks import service as S
from app.modules.stocks.models import Article, Emplacement, LotStock, MouvementStock
from app.modules.tracabilite.models import LienLot


def creer_lien(ctx, parent: LotStock, enfant: LotStock, type_: str, quantite: Decimal, unite: str, notes=None) -> LienLot:
    if parent.id == enfant.id or parent.id in descendants_ids(ctx.db, enfant.id):
        raise ErreurMetier("lien_cycle")
    lien = LienLot(exploitation_id=ctx.exploitation_id, parent_id=parent.id, enfant_id=enfant.id, type=type_,
                   quantite=quantite, unite=unite, horodatage=maintenant(), auteur_id=ctx.utilisateur.id, notes=notes)
    ctx.db.add(lien)
    ctx.db.flush()
    journaliser(ctx, f"lien_{type_}", "lien_lot", lien.id, apres=instantane(lien))
    return lien


def ascendants_ids(db, lot_id) -> set:
    rows = db.execute(text("""
        WITH RECURSIVE a(id) AS (
          SELECT parent_id FROM lien_lot WHERE enfant_id = :id
          UNION SELECT l.parent_id FROM lien_lot l JOIN a ON l.enfant_id = a.id)
        SELECT id FROM a"""), {"id": lot_id}).scalars()
    return set(rows)


def descendants_ids(db, lot_id) -> set:
    rows = db.execute(text("""
        WITH RECURSIVE d(id) AS (
          SELECT enfant_id FROM lien_lot WHERE parent_id = :id
          UNION SELECT l.enfant_id FROM lien_lot l JOIN d ON l.parent_id = d.id)
        SELECT id FROM d"""), {"id": lot_id}).scalars()
    return set(rows)


def enregistrer_recolte(ctx, *, intervention_id, article_id, quantite, unite, emplacement_id, date_recolte,
                        qualite_observee=None, variete=None, numero=None, statut="en_attente_controle",
                        client_prevu=None) -> tuple[LotStock, MouvementStock]:
    db = ctx.db
    it = db.get(Intervention, intervention_id)
    if not it or it.exploitation_id != ctx.exploitation_id:
        raise Introuvable("Intervention de récolte")
    if it.type != "recolte":
        raise ErreurMetier("donnee_invalide", detail="l'intervention doit être de type récolte")
    a = db.get(Article, article_id)
    if not a or a.exploitation_id != ctx.exploitation_id:
        raise Introuvable("Article")
    S.verifier_emplacement(ctx, emplacement_id)
    cycle = db.get(CycleCultural, it.cycle_id) if it.cycle_id else None
    q = S.en_unite_stock(a, quantite, unite)
    qualite = dict(qualite_observee or {})
    if client_prevu:
        qualite["client_destinataire_prevu"] = client_prevu
    lot = S.creer_lot(ctx, a, numero=numero, origine="recolte", date_entree=date_recolte, parcelle_id=it.parcelle_id,
                      cycle_id=it.cycle_id, intervention_id=it.id, culture=cycle.culture if cycle else a.culture,
                      variete=variete or (cycle.variete if cycle else None), date_recolte=date_recolte,
                      quantite_initiale=q, qualite_observee=qualite or None, statut=statut,
                      motif_statut="Contrôle qualité à réaliser avant libération" if statut != "libre" else None)
    m = S.enregistrer_mouvement(ctx, "production", lot, emplacement_id, q, unite_saisie=unite,
                                quantite_saisie=Decimal(str(quantite)), reference_type="intervention",
                                reference_id=it.id, motif=f"Récolte {it.numero}")
    if cycle and cycle.statut in ("prevu", "en_cours"):
        cycle.statut = "recolte"
    return lot, m


def diviser(ctx, lot: LotStock, emplacement_source, parts: list[dict], type_="division") -> list[LotStock]:
    """parts = [{quantite, unite, emplacement_id, classement?, numero?, article_id?}] ; part « perte » possible."""
    db = ctx.db
    a = S.verrouiller_article(db, lot.article_id)
    enfants = []
    total = sum((S.en_unite_stock(a, p["quantite"], p.get("unite")) for p in parts), Decimal(0))
    phys = S.physique_par_lot(db, ctx.exploitation_id, lot_id=lot.id, emplacement_id=emplacement_source).get((lot.id, emplacement_source), Decimal(0))
    if total > phys:
        raise ErreurMetier("quantite_lien_excessive")
    for p in parts:
        q = S.en_unite_stock(a, p["quantite"], p.get("unite"))
        if p.get("perte"):
            S.enregistrer_mouvement(ctx, "perte", lot, emplacement_source, q, motif=p.get("motif") or "Perte au tri")
            continue
        S.enregistrer_mouvement(ctx, "sortie_lot", lot, emplacement_source, q, motif=f"{type_} du lot {lot.numero}")
        enfant = S.creer_lot(ctx, a, numero=p.get("numero"), origine=type_, date_entree=maintenant().date(),
                             parcelle_id=lot.parcelle_id, cycle_id=lot.cycle_id, intervention_id=lot.intervention_id,
                             culture=lot.culture, variete=lot.variete, date_recolte=lot.date_recolte, quantite_initiale=q,
                             classement=p.get("classement"), qualite_observee=lot.qualite_observee,
                             statut=lot.statut, motif_statut=lot.motif_statut)
        S.enregistrer_mouvement(ctx, "entree_lot", enfant, p["emplacement_id"], q, motif=f"Issu du lot {lot.numero}")
        creer_lien(ctx, lot, enfant, type_, q, a.unite_stock)
        enfants.append(enfant)
    return enfants


def regrouper(ctx, sources: list[dict], emplacement_id, numero=None) -> LotStock:
    """sources = [{lot_id, emplacement_id, quantite, unite}] → un lot unique, toutes relations conservées."""
    db = ctx.db
    lots = []
    for s in sources:
        l = db.get(LotStock, s["lot_id"])
        if not l or l.exploitation_id != ctx.exploitation_id:
            raise Introuvable("Lot")
        lots.append((l, s))
    articles = {l.article_id for l, _ in lots}
    if len(articles) != 1:
        raise ErreurMetier("donnee_invalide", detail="un regroupement ne peut associer que des lots du même article")
    a = S.verrouiller_article(db, lots[0][0].article_id)
    total = Decimal(0)
    for l, s in lots:
        if l.statut not in ("libre", "en_attente_controle"):
            raise ErreurMetier("lot_bloque", lot=l.numero, statut=l.statut)
        q = S.en_unite_stock(a, s["quantite"], s.get("unite"))
        S.enregistrer_mouvement(ctx, "sortie_lot", l, s["emplacement_id"], q, motif="Regroupement")
        total += q
    cultures = {l.culture for l, _ in lots}
    varietes = {l.variete for l, _ in lots}
    pire_statut = "en_attente_controle" if any(l.statut != "libre" for l, _ in lots) else "libre"
    enfant = S.creer_lot(ctx, a, numero=numero, origine="regroupement", date_entree=maintenant().date(),
                         culture=cultures.pop() if len(cultures) == 1 else "mélange",
                         variete=varietes.pop() if len(varietes) == 1 else "mélange de variétés",
                         quantite_initiale=total, statut=pire_statut)
    S.enregistrer_mouvement(ctx, "entree_lot", enfant, emplacement_id, total, motif="Regroupement de lots")
    for l, s in lots:
        creer_lien(ctx, l, enfant, "regroupement", S.en_unite_stock(a, s["quantite"], s.get("unite")), a.unite_stock)
    return enfant


def conditionner(ctx, lot: LotStock, emplacement_source, quantite_source, unite_source, article_fini_id,
                 nombre_unites, emplacement_destination, emballage_article_id=None, emballages_par_unite=1,
                 numero=None) -> LotStock:
    db = ctx.db
    a = S.verrouiller_article(db, lot.article_id)
    fini = db.get(Article, article_fini_id)
    if not fini or fini.exploitation_id != ctx.exploitation_id:
        raise Introuvable("Article conditionné")
    q = S.en_unite_stock(a, quantite_source, unite_source)
    S.enregistrer_mouvement(ctx, "sortie_lot", lot, emplacement_source, q, motif=f"Conditionnement en {fini.libelle}")
    enfant = S.creer_lot(ctx, fini, numero=numero, origine="conditionnement", date_entree=maintenant().date(),
                         parcelle_id=lot.parcelle_id, cycle_id=lot.cycle_id, culture=lot.culture, variete=lot.variete,
                         date_recolte=lot.date_recolte, quantite_initiale=Decimal(str(nombre_unites)), statut=lot.statut,
                         motif_statut=lot.motif_statut, apte_vente=False)
    S.enregistrer_mouvement(ctx, "entree_lot", enfant, emplacement_destination, Decimal(str(nombre_unites)),
                            motif=f"Conditionné depuis {lot.numero}")
    creer_lien(ctx, lot, enfant, "conditionnement", q, a.unite_stock,
               notes=f"{q} {a.unite_stock} → {nombre_unites} {fini.unite_stock}")
    if emballage_article_id:
        S.consommer(ctx, emballage_article_id, Decimal(str(nombre_unites)) * Decimal(str(emballages_par_unite)), None,
                    reference_type="lot", reference_id=enfant.id, motif=f"Emballage du lot {enfant.numero}")
    return enfant


def _resume_lot(db, l: LotStock) -> dict:
    a = db.get(Article, l.article_id)
    empl = []
    for (lid, eid), q in S.physique_par_lot(db, l.exploitation_id, lot_id=l.id).items():
        e = db.get(Emplacement, eid)
        if q != 0:
            empl.append({"emplacement": e.nom, "code": e.code, "quantite": arrondi(q)})
    historique_empl = sorted({db.get(Emplacement, eid).nom for eid in db.scalars(
        select(MouvementStock.emplacement_id).where(MouvementStock.lot_id == l.id))})
    p = db.get(Parcelle, l.parcelle_id) if l.parcelle_id else None
    it = db.get(Intervention, l.intervention_id) if l.intervention_id else None
    manques = []
    if l.origine == "recolte":
        if not p:
            manques.append("Parcelle d'origine non renseignée")
        if not it:
            manques.append("Intervention de récolte non rattachée")
        if not l.qualite_observee:
            manques.append("Qualité à la récolte non observée")
    elif l.origine == "achat":
        if not l.numero_lot_fournisseur:
            manques.append("Numéro de lot fournisseur absent")
    elif l.origine == "inventaire":
        manques.append("Origine non documentée (entrée d'inventaire)")
    if not historique_empl:
        manques.append("Aucun emplacement de stockage enregistré")
    return {
        "id": str(l.id), "numero": l.numero, "article": a.libelle, "categorie": a.categorie, "origine": l.origine,
        "culture": l.culture, "variete": l.variete, "classement": l.classement,
        "date_recolte": l.date_recolte.isoformat() if l.date_recolte else None,
        "quantite_initiale": float(l.quantite_initiale) if l.quantite_initiale is not None else None, "unite": l.unite,
        "statut": l.statut, "apte_vente": l.apte_vente,
        "parcelle": {"id": str(p.id), "code": p.code, "nom": p.nom} if p else None,
        "intervention": {"id": str(it.id), "numero": it.numero, "date": (it.debut_reel or it.date_prevue).isoformat() if (it.debut_reel or it.date_prevue) else None} if it else None,
        "emplacements_actuels": empl, "emplacements_historiques": historique_empl, "donnees_manquantes": manques,
    }


def expeditions_du_lot(db, lot_id) -> list[dict]:
    res = []
    for ex in db.scalars(select(Expedition).where(Expedition.lignes.op("@>")([{"lot_id": str(lot_id)}]))):
        cmd = db.get(CommandeClient, ex.commande_id)
        cl = db.get(Client, cmd.client_id)
        q = sum(Decimal(str(l["quantite"])) for l in ex.lignes if l["lot_id"] == str(lot_id))
        res.append({"expedition_id": str(ex.id), "numero": ex.numero, "date": ex.horodatage.isoformat(),
                    "commande": cmd.numero, "client": cl.nom, "quantite": float(q)})
    return res


def rapport_lot(db, lot_id) -> dict:
    lot = db.get(LotStock, lot_id)
    if not lot:
        raise Introuvable("Lot")
    asc = ascendants_ids(db, lot.id)
    desc = descendants_ids(db, lot.id)
    tous = {lot.id} | asc | desc
    liens = db.scalars(select(LienLot).where(LienLot.parent_id.in_(tous), LienLot.enfant_id.in_(tous))).all()
    lots = {i: db.get(LotStock, i) for i in tous}
    noeuds = {str(i): _resume_lot(db, l) for i, l in lots.items()}
    for i in tous:
        noeuds[str(i)]["expeditions"] = expeditions_du_lot(db, i)
    racines = [str(i) for i in ({lot.id} | asc) if not any(li.enfant_id == i for li in liens)]
    parcelles = {}
    for r in racines:
        n = noeuds[r]
        if n["parcelle"]:
            parcelles[n["parcelle"]["id"]] = n["parcelle"]
    manques = [{"lot": noeuds[k]["numero"], "manque": m} for k, n in noeuds.items() for m in n["donnees_manquantes"]]
    racines_incompletes = [noeuds[r]["numero"] for r in racines if not noeuds[r]["parcelle"]]
    return {
        "lot": noeuds[str(lot.id)],
        "parcelles_origine": list(parcelles.values()),
        "ascendants": [noeuds[str(i)] for i in asc],
        "descendants": [noeuds[str(i)] for i in desc],
        "liens": [{"parent": noeuds[str(l.parent_id)]["numero"], "enfant": noeuds[str(l.enfant_id)]["numero"],
                   "type": l.type, "quantite": float(l.quantite), "unite": l.unite, "date": l.horodatage.isoformat()}
                  for l in liens],
        "expeditions": [e for i in tous for e in noeuds[str(i)]["expeditions"]],
        "donnees_manquantes": manques,
        "complete_jusqua_parcelle": not racines_incompletes,
        "conclusion": ("Chaîne reliée jusqu'à la (aux) parcelle(s) d'origine." if not racines_incompletes else
                       f"Traçabilité incomplète : origine parcellaire inconnue pour {', '.join(racines_incompletes)}."),
    }
