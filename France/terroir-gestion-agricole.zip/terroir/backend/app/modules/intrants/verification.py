"""Vérifications réglementaires limitées aux règles réellement couvertes.

Terroir ne contient aucune dose, aucun délai ni aucune autorisation codés
en dur : il compare l'intervention aux données d'un référentiel importé,
avec sa source et sa date d'effet. Tout contrôle sans donnée source est
déclaré « non disponible ». Le résultat n'est jamais une preuve de
conformité et appelle une validation professionnelle.
"""
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import func, select

from app.core.format_fr import court, date_fr
from app.core.unites import compatibles, convertir
from app.modules.cultures.models import CycleCultural
from app.modules.equipe.models import Competence
from app.modules.interventions.models import Intervention, InterventionProduit, ValidationProfessionnelle
from app.modules.intrants.models import ProduitReferentiel, SourceReferentiel, UsageReferentiel
from app.modules.stocks.models import Article

NON_COUVERTS = [
    "Compatibilité des mélanges de produits (aucune règle de mélange n'est intégrée).",
    "Zones de non-traitement (points d'eau, riverains) : distances non calculées.",
    "Conditions météorologiques réglementaires au moment de l'application (vent, température).",
    "Délai de rentrée sur la parcelle après traitement.",
    "Équipements de protection individuelle.",
    "Restrictions locales (arrêtés préfectoraux, captages) non importées.",
]

AVERTISSEMENT = ("Vérification partielle, limitée aux contrôles listés et aux données de la source citée. "
                 "Un enregistrement complet ne constitue pas une preuve de conformité. "
                 "Une validation par une personne compétente est requise.")


def _c(code, libelle, statut, detail, source=None):
    # statut : conforme_source | alerte | non_disponible | information
    return {"code": code, "libelle": libelle, "statut": statut, "detail": detail, "source": source}


def verifier_intervention(db, it: Intervention) -> dict:
    jour = it.date_prevue or (it.debut_reel.date() if it.debut_reel else date.today())
    cycle = db.get(CycleCultural, it.cycle_id) if it.cycle_id else None
    controles, sources = [], {}
    lignes = db.scalars(select(InterventionProduit).where(InterventionProduit.intervention_id == it.id)).all()
    for ligne in lignes:
        a = db.get(Article, ligne.article_id)
        if not a.reglemente:
            continue
        nom = a.libelle
        ref = db.get(ProduitReferentiel, a.produit_referentiel_id) if a.produit_referentiel_id else None
        if not ref:
            controles.append(_c("produit_reference", f"{nom} : identification dans un référentiel", "non_disponible",
                                "Produit non relié à un référentiel importé : aucun contrôle d'autorisation possible."))
            continue
        src = db.get(SourceReferentiel, ref.source_id)
        s = {"nom": src.nom, "version": src.version, "date_effet": src.date_effet.isoformat() if src.date_effet else None,
             "officielle": src.officielle, "avertissement": src.avertissement}
        sources[str(src.id)] = s
        # 1. État d'autorisation
        if ref.date_fin_utilisation and jour > ref.date_fin_utilisation:
            controles.append(_c("autorisation", f"{nom} : date limite d'utilisation", "alerte",
                                f"Date limite d'utilisation publiée : {date_fr(ref.date_fin_utilisation)}.", s))
        elif ref.etat_autorisation:
            st = "conforme_source" if ref.etat_autorisation.lower() in ("autorise", "autorisé") else "alerte"
            controles.append(_c("autorisation", f"{nom} : état d'autorisation (AMM {ref.numero_amm})", st,
                                f"État publié par la source : « {ref.etat_autorisation} ».", s))
        else:
            controles.append(_c("autorisation", f"{nom} : état d'autorisation", "non_disponible",
                                "État non renseigné dans la source.", s))
        # 2. Usage pour la culture
        if not cycle:
            controles.append(_c("usage", f"{nom} : usage sur la culture", "non_disponible",
                                "Intervention non rattachée à un cycle cultural : culture inconnue.", s))
            continue
        usages = db.scalars(select(UsageReferentiel).where(UsageReferentiel.produit_id == ref.id,
                                                           func.lower(UsageReferentiel.culture) == cycle.culture.lower())).all()
        if not usages:
            controles.append(_c("usage", f"{nom} : usage sur « {cycle.culture} »", "alerte",
                                "Aucun usage trouvé pour cette culture dans la source importée.", s))
            continue
        u = usages[0]
        controles.append(_c("usage", f"{nom} : usage sur « {cycle.culture} »", "conforme_source",
                            f"Usage publié : {u.culture} — {u.cible or 'cible non précisée'} ({u.etat_usage or 'état non précisé'}).", s))
        # 3. Dose
        if u.dose_max is None or not u.unite_dose:
            controles.append(_c("dose", f"{nom} : dose", "non_disponible", "Dose maximale non publiée dans la source importée.", s))
        elif ligne.dose_prevue is None or not ligne.unite_dose:
            controles.append(_c("dose", f"{nom} : dose", "non_disponible", "Dose prévue non saisie.", s))
        elif not compatibles(ligne.unite_dose, u.unite_dose):
            controles.append(_c("dose", f"{nom} : dose", "non_disponible",
                                f"Unités non comparables ({ligne.unite_dose} / {u.unite_dose}).", s))
        else:
            d = convertir(ligne.dose_prevue, ligne.unite_dose, u.unite_dose)
            ok = d <= u.dose_max
            controles.append(_c("dose", f"{nom} : dose prévue {court(d)} {u.unite_dose}",
                                "conforme_source" if ok else "alerte",
                                f"Dose maximale publiée : {court(u.dose_max)} {u.unite_dose}.", s))
            if ligne.quantite_mesuree is not None and it.surface_realisee_ha:
                from app.core.unites import DOSE_VERS_QUANTITE, unite as U
                ref_q = DOSE_VERS_QUANTITE.get(U(u.unite_dose).grandeur)
                if ref_q and compatibles(ligne.unite_quantite, ref_q):
                    reel = convertir(ligne.quantite_mesuree, ligne.unite_quantite, ref_q) / Decimal(str(it.surface_realisee_ha))
                    reel = convertir(reel, {"kg": "kg/ha", "L": "L/ha", "u": "u/ha"}[ref_q], u.unite_dose)
                    controles.append(_c("dose_reelle", f"{nom} : dose réellement appliquée {court(reel)} {u.unite_dose}",
                                        "conforme_source" if reel <= u.dose_max else "alerte",
                                        "Calculée à partir de la quantité mesurée et de la surface réalisée.", s))
        # 4. Délai avant récolte
        if u.delai_avant_recolte_jours is None:
            controles.append(_c("dar", f"{nom} : délai avant récolte", "non_disponible", "Délai non publié dans la source importée.", s))
        elif not cycle.date_recolte_debut_prevue:
            controles.append(_c("dar", f"{nom} : délai avant récolte", "non_disponible", "Date de récolte prévue non renseignée.", s))
        else:
            limite = jour + timedelta(days=u.delai_avant_recolte_jours)
            ok = limite <= cycle.date_recolte_debut_prevue
            controles.append(_c("dar", f"{nom} : délai avant récolte ({u.delai_avant_recolte_jours} j)",
                                "conforme_source" if ok else "alerte",
                                f"Récolte possible au plus tôt le {date_fr(limite)} ; début de récolte prévu le "
                                f"{date_fr(cycle.date_recolte_debut_prevue)}.", s))
        # 5. Nombre d'applications
        if u.nombre_applications_max is None:
            controles.append(_c("nb_applications", f"{nom} : nombre d'applications", "non_disponible",
                                "Nombre maximal non publié dans la source importée.", s))
        else:
            n = db.scalar(select(func.count(func.distinct(Intervention.id))).join(InterventionProduit)
                          .where(Intervention.cycle_id == cycle.id, InterventionProduit.article_id == a.id,
                                 Intervention.statut.in_(["planifiee", "en_cours", "realisee"])))
            controles.append(_c("nb_applications", f"{nom} : {n} application(s) sur le cycle",
                                "conforme_source" if n <= u.nombre_applications_max else "alerte",
                                f"Maximum publié : {u.nombre_applications_max}.", s))
    # Contrôles fondés sur les données de l'exploitation
    if it.operateur_id:
        ok = db.scalar(select(func.count()).select_from(Competence).where(
            Competence.membre_id == it.operateur_id, Competence.type.like("certiphyto%"),
            (Competence.valide_au.is_(None)) | (Competence.valide_au >= jour)))
        controles.append(_c("certiphyto", "Certificat individuel de l'opérateur saisi et en cours de validité",
                            "conforme_source" if ok else "alerte",
                            "D'après les compétences saisies dans Terroir (non vérifiées auprès de l'administration)."))
    else:
        controles.append(_c("certiphyto", "Certificat individuel de l'opérateur", "non_disponible", "Aucun opérateur désigné."))
    validation = db.scalar(select(ValidationProfessionnelle).where(
        ValidationProfessionnelle.objet_type == "intervention", ValidationProfessionnelle.objet_id == it.id)
        .order_by(ValidationProfessionnelle.horodatage.desc()))
    return {
        "verifie_le": date.today().isoformat(),
        "controles": controles,
        "controles_non_couverts": NON_COUVERTS,
        "sources": list(sources.values()),
        "nombre_alertes": sum(1 for c in controles if c["statut"] == "alerte"),
        "nombre_non_disponibles": sum(1 for c in controles if c["statut"] == "non_disponible"),
        "validation_professionnelle": ({"decision": validation.decision, "qualification": validation.qualification,
                                        "commentaire": validation.commentaire, "le": validation.horodatage.isoformat()}
                                       if validation else None),
        "avertissement": AVERTISSEMENT,
    }
