import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base, HorodatageMixin, IdMixin


class SourceReferentiel(IdMixin, HorodatageMixin, Base):
    """Provenance d'un référentiel réglementaire importé (ex. E-Phy)."""

    __tablename__ = "source_referentiel"
    nom: Mapped[str] = mapped_column(String(200))
    editeur: Mapped[str | None] = mapped_column(String(200))
    url: Mapped[str | None] = mapped_column(String(500))
    licence: Mapped[str | None] = mapped_column(String(200))
    version: Mapped[str | None] = mapped_column(String(60))
    date_effet: Mapped[date | None]
    importe_le: Mapped[datetime]
    officielle: Mapped[bool] = mapped_column(default=False)
    avertissement: Mapped[str | None] = mapped_column(Text)


class ProduitReferentiel(IdMixin, HorodatageMixin, Base):
    __tablename__ = "produit_referentiel"
    source_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("source_referentiel.id", ondelete="CASCADE"), index=True)
    numero_amm: Mapped[str] = mapped_column(String(30), index=True)
    nom_commercial: Mapped[str] = mapped_column(String(200))
    titulaire: Mapped[str | None] = mapped_column(String(200))
    etat_autorisation: Mapped[str | None] = mapped_column(String(60))
    date_fin_distribution: Mapped[date | None]
    date_fin_utilisation: Mapped[date | None]
    substances: Mapped[list] = mapped_column(default=list)


class UsageReferentiel(IdMixin, Base):
    """Usage autorisé tel que publié par la source. Aucune valeur n'est
    déduite : un champ vide signifie « non couvert par la source importée »."""

    __tablename__ = "usage_referentiel"
    produit_id: Mapped[uuid.UUID] = mapped_column(ForeignKey("produit_referentiel.id", ondelete="CASCADE"), index=True)
    culture: Mapped[str] = mapped_column(String(120))
    cible: Mapped[str | None] = mapped_column(String(200))
    dose_max: Mapped[Decimal | None]
    unite_dose: Mapped[str | None] = mapped_column(String(15))
    nombre_applications_max: Mapped[int | None]
    delai_avant_recolte_jours: Mapped[int | None]
    znt_aquatique_m: Mapped[Decimal | None]
    etat_usage: Mapped[str | None] = mapped_column(String(60))
    commentaire_source: Mapped[str | None] = mapped_column(Text)
