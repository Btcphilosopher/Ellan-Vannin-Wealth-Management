"""Sérialisation générique des objets ORM vers JSON."""
import uuid
from datetime import date, datetime
from decimal import Decimal

from geoalchemy2.elements import WKBElement, WKTElement
from geoalchemy2.shape import to_shape
from shapely.geometry import mapping
from sqlalchemy import inspect


def valeur_json(v):
    if v is None:
        return None
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, uuid.UUID):
        return str(v)
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    if isinstance(v, (WKBElement, WKTElement)):
        return mapping(to_shape(v))
    if isinstance(v, dict):
        return {k: valeur_json(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [valeur_json(x) for x in v]
    return v


def en_dict(obj, exclure: tuple[str, ...] = (), **extra) -> dict:
    if obj is None:
        return None
    d = {}
    for col in inspect(obj).mapper.column_attrs:
        if col.key in exclure:
            continue
        d[col.key] = valeur_json(getattr(obj, col.key))
    for k, v in extra.items():
        d[k] = valeur_json(v)
    return d


def liste(objs, **kw) -> list[dict]:
    return [en_dict(o, **kw) for o in objs]
