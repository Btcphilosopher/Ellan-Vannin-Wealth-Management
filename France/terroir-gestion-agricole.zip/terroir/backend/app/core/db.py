"""Connexion PostgreSQL/PostGIS et classes de base ORM."""
import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import DateTime, Integer, MetaData, Numeric, create_engine, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker

from app.core.config import get_settings

CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=CONVENTION)
    type_annotation_map = {
        dict: JSONB,
        list: JSONB,
        Decimal: Numeric(16, 4),
        uuid.UUID: UUID(as_uuid=True),
        datetime: DateTime(timezone=True),
    }


def maintenant() -> datetime:
    return datetime.now(timezone.utc)


class IdMixin:
    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)


class HorodatageMixin:
    cree_le: Mapped[datetime] = mapped_column(server_default=func.now(), default=maintenant)
    modifie_le: Mapped[datetime] = mapped_column(
        server_default=func.now(), default=maintenant, onupdate=maintenant
    )


class VersionMixin:
    """Verrouillage optimiste : chaque mise à jour incrémente `version`."""

    version: Mapped[int] = mapped_column(Integer, default=1, server_default="1")


_engine = None
_SessionLocal = None


def get_engine():
    global _engine, _SessionLocal
    if _engine is None:
        _engine = create_engine(get_settings().database_url, pool_pre_ping=True, future=True)
        _SessionLocal = sessionmaker(bind=_engine, expire_on_commit=False)
    return _engine


def reset_engine(url: str | None = None):
    """Utilisé par les tests pour pointer vers une autre base."""
    global _engine, _SessionLocal
    if _engine is not None:
        _engine.dispose()
    _engine = None
    _SessionLocal = None
    if url:
        get_settings.cache_clear()
        import os

        os.environ["TERROIR_DATABASE_URL"] = url
    get_engine()


def SessionLocal() -> Session:
    get_engine()
    return _SessionLocal()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
