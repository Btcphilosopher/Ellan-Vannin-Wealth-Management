from pydantic import BaseModel, ConfigDict


class Entree(BaseModel):
    """Schéma d'entrée strict : un champ inconnu est refusé au lieu d'être ignoré."""

    model_config = ConfigDict(extra="forbid")
