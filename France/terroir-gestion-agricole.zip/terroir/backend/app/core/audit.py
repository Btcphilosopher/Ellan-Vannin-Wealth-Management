from app.core.db import maintenant
from app.core.serial import en_dict, valeur_json
from app.modules.identite.models import JournalAudit

CHAMPS_SENSIBLES = {"mot_de_passe_hash", "jeton_hash", "geometrie", "geometrie_origine_wkt"}


def instantane(obj) -> dict | None:
    if obj is None:
        return None
    return en_dict(obj, exclure=tuple(CHAMPS_SENSIBLES))


def journaliser(ctx, action: str, entite: str, entite_id=None, avant: dict | None = None,
                apres: dict | None = None):
    """Ajoute une entrée au journal d'audit (dans la même transaction)."""
    if avant and apres:
        diff_avant = {k: v for k, v in avant.items() if apres.get(k) != v}
        diff_apres = {k: apres.get(k) for k in diff_avant}
        avant, apres = diff_avant, diff_apres
    ctx.db.add(JournalAudit(
        exploitation_id=ctx.exploitation_id, utilisateur_id=ctx.utilisateur.id if ctx.utilisateur else None,
        horodatage=maintenant(), action=action, entite=entite,
        entite_id=str(entite_id) if entite_id else None, avant=valeur_json(avant), apres=valeur_json(apres),
        origine=getattr(ctx, "origine", "web"),
    ))
