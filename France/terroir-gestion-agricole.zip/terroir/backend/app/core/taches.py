"""Traitements en arrière-plan : file d'attente dans PostgreSQL.

Le processus `python -m app.worker` réserve les tâches avec
`FOR UPDATE SKIP LOCKED`, ce qui permet plusieurs travailleurs sans
courtier supplémentaire.
"""
import logging
import time
import traceback

from sqlalchemy import select

from app.core.db import SessionLocal, maintenant
from app.modules.identite.models import Tache

log = logging.getLogger("terroir.taches")
GESTIONNAIRES: dict = {}


def tache(nom: str):
    def deco(fn):
        GESTIONNAIRES[nom] = fn
        return fn

    return deco


def mettre_en_file(db, type_: str, parametres: dict, exploitation_id=None, demandee_par=None) -> Tache:
    t = Tache(type=type_, parametres=parametres, exploitation_id=exploitation_id, cree_le=maintenant(),
              demandee_par=demandee_par, statut="en_attente")
    db.add(t)
    db.flush()
    return t


def executer_une(db) -> Tache | None:
    t = db.scalar(select(Tache).where(Tache.statut == "en_attente").order_by(Tache.cree_le)
                  .with_for_update(skip_locked=True).limit(1))
    if not t:
        return None
    t.statut = "en_cours"
    t.demarree_le = maintenant()
    t.tentatives += 1
    db.commit()
    try:
        fn = GESTIONNAIRES[t.type]
        t.resultat = fn(db, t)
        t.statut = "terminee"
    except Exception as e:  # noqa: BLE001
        db.rollback()
        t = db.get(Tache, t.id)
        t.statut = "echec" if t.tentatives >= 3 else "en_attente"
        t.erreur = f"{e}\n{traceback.format_exc()[-2000:]}"
        log.exception("Échec de la tâche %s", t.type)
    t.terminee_le = maintenant()
    db.commit()
    return t


def executer_en_attente(max_taches: int = 50) -> int:
    """Exécute les tâches en attente (utilisé par les tests et la démo)."""
    n = 0
    db = SessionLocal()
    try:
        while n < max_taches and executer_une(db):
            n += 1
    finally:
        db.close()
    return n


def boucle(intervalle_s: float = 2.0):
    import app.taches_metier  # noqa: F401 enregistre les gestionnaires

    log.info("Travailleur Terroir démarré")
    while True:
        if executer_en_attente() == 0:
            time.sleep(intervalle_s)
