"""Formats français pour les exports (nombres, dates, euros)."""
from datetime import date, datetime
from zoneinfo import ZoneInfo


def nombre(v, decimales: int = 2) -> str:
    if v is None:
        return "—"
    s = f"{float(v):,.{decimales}f}"
    return s.replace(",", " ").replace(".", ",")


def euros(v) -> str:
    return "—" if v is None else f"{nombre(v, 2)} €"


def date_fr(v) -> str:
    if not v:
        return "—"
    if isinstance(v, str):
        v = datetime.fromisoformat(v) if "T" in v else date.fromisoformat(v)
    return v.strftime("%d/%m/%Y")


def date_heure_fr(v, fuseau: str = "Europe/Paris") -> str:
    if not v:
        return "—"
    if isinstance(v, str):
        v = datetime.fromisoformat(v)
    if v.tzinfo:
        v = v.astimezone(ZoneInfo(fuseau))
    return v.strftime("%d/%m/%Y %H:%M")


def court(v, max_decimales: int = 3) -> str:
    """Nombre au format français sans zéros inutiles : 1842 → « 1 842 », 9.70 → « 9,7 »."""
    if v is None:
        return "—"
    s = nombre(v, max_decimales)
    if "," in s:
        s = s.rstrip("0").rstrip(",")
    return s
