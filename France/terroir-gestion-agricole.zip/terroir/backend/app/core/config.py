"""Configuration de l'application (variables d'environnement préfixées TERROIR_)."""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TERROIR_", env_file=".env", extra="ignore")

    database_url: str = "postgresql+psycopg://terroir:terroir@localhost:5432/terroir"
    environnement: str = "developpement"  # developpement | production | test

    # Sessions
    session_duree_heures: int = 12
    cookie_secure: bool = False  # True en production (HTTPS)
    cookie_nom: str = "terroir_session"
    connexion_max_echecs: int = 5
    connexion_blocage_minutes: int = 15

    # Stockage objet
    stockage_backend: str = "local"  # local | s3
    stockage_chemin: str = "./data/objets"
    s3_endpoint: str | None = None
    s3_bucket: str = "terroir-documents"
    s3_access_key: str | None = None
    s3_secret_key: str | None = None
    s3_region: str = "us-east-1"

    fichier_taille_max_mo: int = 15

    # Règles métier paramétrables
    tolerance_ecart_surface_pct: float = 2.0

    cors_origines: str = "http://localhost:3000"


@lru_cache
def get_settings() -> Settings:
    return Settings()
