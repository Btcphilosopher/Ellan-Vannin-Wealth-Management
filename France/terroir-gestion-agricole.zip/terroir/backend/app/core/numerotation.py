from sqlalchemy import text


def prochain_numero(db, exploitation_id, cle: str) -> int:
    """Compteur transactionnel sans trou (verrou de ligne via UPSERT)."""
    return db.execute(text(
        "INSERT INTO compteur (exploitation_id, cle, valeur) VALUES (:e, :c, 1) "
        "ON CONFLICT (exploitation_id, cle) DO UPDATE SET valeur = compteur.valeur + 1 RETURNING valeur"
    ), {"e": exploitation_id, "c": cle}).scalar_one()


def numero_formate(db, exploitation_id, prefixe: str, annee: int | None = None, largeur: int = 4) -> str:
    cle = f"{prefixe}-{annee}" if annee else prefixe
    n = prochain_numero(db, exploitation_id, cle)
    return f"{cle}-{n:0{largeur}d}"
