from fastapi import Request
from fastapi.responses import JSONResponse

from app.i18n.fr import message


class ErreurMetier(Exception):
    """Erreur fonctionnelle identifiée par un code ; message résolu par le catalogue."""

    statut_http = 422

    def __init__(self, code: str, statut_http: int | None = None, **params):
        self.code = code
        self.params = {k: (str(v) if v is not None else "") for k, v in params.items()}
        if statut_http:
            self.statut_http = statut_http
        super().__init__(message(code, **self.params))

    @property
    def message(self) -> str:
        return message(self.code, **self.params)


class Introuvable(ErreurMetier):
    statut_http = 404

    def __init__(self, entite: str):
        super().__init__("introuvable", entite=entite)


class AccesRefuse(ErreurMetier):
    statut_http = 403

    def __init__(self, permission: str):
        super().__init__("acces_refuse", permission=permission)


class NonAuthentifie(ErreurMetier):
    statut_http = 401

    def __init__(self, code: str = "non_authentifie"):
        super().__init__(code)


class Conflit(ErreurMetier):
    statut_http = 409


async def gestionnaire_erreur_metier(_: Request, exc: ErreurMetier):
    return JSONResponse(
        status_code=exc.statut_http,
        content={"code": exc.code, "message": exc.message, "parametres": exc.params},
    )
