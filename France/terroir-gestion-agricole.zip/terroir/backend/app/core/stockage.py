"""Stockage objet protégé.

Les fichiers ne sont jamais servis directement : le téléchargement passe
par l'API, qui vérifie la permission puis diffuse le contenu. Deux
implémentations : système de fichiers local (volume privé) et S3
compatible (SeaweedFS dans Docker Compose), bucket privé.
"""
import hashlib
import json
import os
import re
import uuid
from pathlib import Path

from app.core.config import get_settings
from app.core.erreurs import ErreurMetier

SIGNATURES = {
    "application/pdf": [b"%PDF-"],
    "image/png": [b"\x89PNG\r\n\x1a\n"],
    "image/jpeg": [b"\xff\xd8\xff"],
    "image/webp": [b"RIFF"],
}
EXTENSIONS = {
    ".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".webp": "image/webp", ".csv": "text/csv", ".txt": "text/plain", ".geojson": "application/geo+json",
    ".json": "application/json",
}


def nettoyer_nom(nom: str) -> str:
    nom = os.path.basename(nom or "fichier")
    nom = re.sub(r"[^\w.\- ]", "_", nom, flags=re.UNICODE).strip(" .")
    return (nom or "fichier")[:150]


def valider_fichier(nom: str, contenu: bytes) -> str:
    """Retourne le type MIME vérifié, ou lève une erreur métier."""
    cfg = get_settings()
    if len(contenu) > cfg.fichier_taille_max_mo * 1024 * 1024:
        raise ErreurMetier("fichier_trop_gros", statut_http=413, max=cfg.fichier_taille_max_mo)
    ext = Path(nom).suffix.lower()
    mime = EXTENSIONS.get(ext)
    if not mime:
        raise ErreurMetier("fichier_type", statut_http=415, type=ext or "inconnu")
    if mime in SIGNATURES:
        if not any(contenu.startswith(s) for s in SIGNATURES[mime]):
            raise ErreurMetier("fichier_contenu", statut_http=415)
        if mime == "image/webp" and contenu[8:12] != b"WEBP":
            raise ErreurMetier("fichier_contenu", statut_http=415)
    else:
        try:
            texte = contenu.decode("utf-8")
        except UnicodeDecodeError:
            raise ErreurMetier("fichier_contenu", statut_http=415)
        if "\x00" in texte:
            raise ErreurMetier("fichier_contenu", statut_http=415)
        if mime in ("application/json", "application/geo+json"):
            try:
                json.loads(texte)
            except ValueError:
                raise ErreurMetier("fichier_contenu", statut_http=415)
    return mime


class StockageLocal:
    def __init__(self, racine: str):
        self.racine = Path(racine)
        self.racine.mkdir(parents=True, exist_ok=True)

    def _chemin(self, cle: str) -> Path:
        if not re.fullmatch(r"[0-9a-f\-]+/[0-9a-f\-]+", cle):
            raise ValueError("clé invalide")
        return self.racine / cle

    def ecrire(self, cle: str, contenu: bytes, mime: str):
        p = self._chemin(cle)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(contenu)
        os.chmod(p, 0o600)

    def lire(self, cle: str) -> bytes:
        return self._chemin(cle).read_bytes()

    def supprimer(self, cle: str):
        self._chemin(cle).unlink(missing_ok=True)

    def lister(self):
        for p in self.racine.rglob("*"):
            if p.is_file():
                yield str(p.relative_to(self.racine))


class StockageS3:
    def __init__(self):
        import boto3  # import tardif : dépendance optionnelle

        cfg = get_settings()
        self.bucket = cfg.s3_bucket
        self.client = boto3.client("s3", endpoint_url=cfg.s3_endpoint, aws_access_key_id=cfg.s3_access_key,
                                   aws_secret_access_key=cfg.s3_secret_key, region_name=cfg.s3_region)
        try:
            self.client.head_bucket(Bucket=self.bucket)
        except Exception:
            self.client.create_bucket(Bucket=self.bucket)

    def ecrire(self, cle, contenu, mime):
        self.client.put_object(Bucket=self.bucket, Key=cle, Body=contenu, ContentType=mime)

    def lire(self, cle):
        return self.client.get_object(Bucket=self.bucket, Key=cle)["Body"].read()

    def supprimer(self, cle):
        self.client.delete_object(Bucket=self.bucket, Key=cle)

    def lister(self):
        pag = self.client.get_paginator("list_objects_v2")
        for page in pag.paginate(Bucket=self.bucket):
            for o in page.get("Contents", []):
                yield o["Key"]


_stockage = None


def stockage():
    global _stockage
    if _stockage is None:
        cfg = get_settings()
        _stockage = StockageS3() if cfg.stockage_backend == "s3" else StockageLocal(cfg.stockage_chemin)
    return _stockage


def reinitialiser_stockage():
    global _stockage
    _stockage = None


def enregistrer_objet(exploitation_id, contenu: bytes, mime: str) -> tuple[str, str]:
    cle = f"{exploitation_id}/{uuid.uuid4()}"
    stockage().ecrire(cle, contenu, mime)
    return cle, hashlib.sha256(contenu).hexdigest()
