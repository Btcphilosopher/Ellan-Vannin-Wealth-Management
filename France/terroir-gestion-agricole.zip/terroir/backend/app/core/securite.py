"""Sessions sécurisées, mots de passe, contexte d'autorisation."""
import hashlib
import secrets
import uuid
from dataclasses import dataclass
from datetime import timedelta

import bcrypt
from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.db import get_db, maintenant
from app.core.erreurs import AccesRefuse, ErreurMetier, NonAuthentifie
from app.core.permissions import permissions_du_role
from app.modules.identite.models import Adhesion, SessionUtilisateur, Utilisateur


def hacher_mot_de_passe(mdp: str) -> str:
    return bcrypt.hashpw(mdp.encode(), bcrypt.gensalt(rounds=12)).decode()


def verifier_mot_de_passe(mdp: str, h: str) -> bool:
    try:
        return bcrypt.checkpw(mdp.encode(), h.encode())
    except ValueError:
        return False


def _hash_jeton(jeton: str) -> str:
    return hashlib.sha256(jeton.encode()).hexdigest()


def ouvrir_session(db: Session, utilisateur: Utilisateur, agent: str | None) -> str:
    jeton = secrets.token_urlsafe(32)
    s = SessionUtilisateur(
        utilisateur_id=utilisateur.id, jeton_hash=_hash_jeton(jeton), cree_le=maintenant(),
        expire_le=maintenant() + timedelta(hours=get_settings().session_duree_heures), agent=(agent or "")[:300],
    )
    db.add(s)
    return jeton


def authentifier(db: Session, courriel: str, mdp: str) -> Utilisateur:
    cfg = get_settings()
    u = db.scalar(select(Utilisateur).where(Utilisateur.courriel == courriel.lower().strip()))
    if u and u.bloque_jusqua and u.bloque_jusqua > maintenant():
        raise ErreurMetier("compte_bloque", statut_http=429, minutes=cfg.connexion_blocage_minutes)
    if not u or not u.actif or not verifier_mot_de_passe(mdp, u.mot_de_passe_hash):
        if u:
            u.echecs_connexion += 1
            if u.echecs_connexion >= cfg.connexion_max_echecs:
                u.bloque_jusqua = maintenant() + timedelta(minutes=cfg.connexion_blocage_minutes)
                u.echecs_connexion = 0
            db.commit()
        # Même temps de réponse approximatif si l'utilisateur n'existe pas
        if not u:
            bcrypt.checkpw(b"x", bcrypt.hashpw(b"y", bcrypt.gensalt(rounds=4)))
        raise NonAuthentifie("identifiants_invalides")
    u.echecs_connexion = 0
    u.bloque_jusqua = None
    return u


def jeton_de_la_requete(request: Request) -> str | None:
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return request.cookies.get(get_settings().cookie_nom)


def utilisateur_courant(request: Request, db: Session = Depends(get_db)) -> Utilisateur:
    jeton = jeton_de_la_requete(request)
    if not jeton:
        raise NonAuthentifie()
    s = db.scalar(select(SessionUtilisateur).where(SessionUtilisateur.jeton_hash == _hash_jeton(jeton)))
    if not s or s.revoquee:
        raise NonAuthentifie()
    if s.expire_le < maintenant():
        raise NonAuthentifie("session_expiree")
    u = db.get(Utilisateur, s.utilisateur_id)
    if not u or not u.actif:
        raise NonAuthentifie()
    request.state.session_id = s.id
    return u


def revoquer_session(db: Session, request: Request):
    jeton = jeton_de_la_requete(request)
    if jeton:
        s = db.scalar(select(SessionUtilisateur).where(SessionUtilisateur.jeton_hash == _hash_jeton(jeton)))
        if s:
            s.revoquee = True
            db.commit()


@dataclass
class Contexte:
    db: Session
    utilisateur: Utilisateur
    exploitation_id: uuid.UUID
    role: str
    permissions: set[str]
    membre_equipe_id: uuid.UUID | None = None
    origine: str = "web"

    def exiger(self, permission: str):
        if permission not in self.permissions:
            raise AccesRefuse(permission)

    def peut(self, permission: str) -> bool:
        return permission in self.permissions


def charger_contexte(db: Session, utilisateur: Utilisateur, exploitation_id: uuid.UUID) -> Contexte:
    a = db.scalar(select(Adhesion).where(Adhesion.utilisateur_id == utilisateur.id,
                                         Adhesion.exploitation_id == exploitation_id))
    if not a:
        raise AccesRefuse("exploitation")
    return Contexte(db, utilisateur, exploitation_id, a.role, permissions_du_role(a.role), a.membre_equipe_id)


def autoriser(permission: str | None = None):
    def dependance(exploitation_id: uuid.UUID, db: Session = Depends(get_db),
                   utilisateur: Utilisateur = Depends(utilisateur_courant)) -> Contexte:
        ctx = charger_contexte(db, utilisateur, exploitation_id)
        if permission:
            ctx.exiger(permission)
        return ctx

    return dependance
