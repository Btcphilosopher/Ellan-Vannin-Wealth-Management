"""Unités explicites et conversions.

Chaque quantité est accompagnée de son unité. Les conversions ne sont
possibles qu'à l'intérieur d'une même grandeur (masse, volume, surface,
dose massique par hectare, etc.). Aucune conversion masse ↔ volume n'est
faite implicitement : elle exigerait une masse volumique documentée.
"""
from dataclasses import dataclass
from decimal import Decimal

from app.core.erreurs import ErreurMetier


@dataclass(frozen=True)
class Unite:
    code: str
    grandeur: str
    facteur: Decimal  # facteur vers l'unité de référence de la grandeur
    libelle: str


def _u(code, grandeur, facteur, libelle):
    return Unite(code, grandeur, Decimal(str(facteur)), libelle)


UNITES: dict[str, Unite] = {u.code: u for u in [
    # Masse (référence : kg)
    _u("g", "masse", "0.001", "gramme"),
    _u("kg", "masse", "1", "kilogramme"),
    _u("q", "masse", "100", "quintal"),
    _u("t", "masse", "1000", "tonne"),
    # Volume (référence : L)
    _u("mL", "volume", "0.001", "millilitre"),
    _u("L", "volume", "1", "litre"),
    _u("hL", "volume", "100", "hectolitre"),
    _u("m3", "volume", "1000", "mètre cube"),
    # Surface (référence : ha)
    _u("m2", "surface", "0.0001", "mètre carré"),
    _u("a", "surface", "0.01", "are"),
    _u("ha", "surface", "1", "hectare"),
    # Dénombrement
    _u("u", "nombre", "1", "unité"),
    _u("graines", "nombre", "1", "graine"),
    _u("plants", "nombre", "1", "plant"),
    _u("doses", "nombre", "1", "dose"),
    # Doses par hectare
    _u("g/ha", "dose_masse", "0.001", "gramme par hectare"),
    _u("kg/ha", "dose_masse", "1", "kilogramme par hectare"),
    _u("q/ha", "dose_masse", "100", "quintal par hectare"),
    _u("t/ha", "dose_masse", "1000", "tonne par hectare"),
    _u("mL/ha", "dose_volume", "0.001", "millilitre par hectare"),
    _u("L/ha", "dose_volume", "1", "litre par hectare"),
    _u("m3/ha", "dose_volume", "1000", "mètre cube par hectare"),
    _u("u/ha", "dose_nombre", "1", "unité par hectare"),
    _u("graines/m2", "dose_nombre", "10000", "graines par mètre carré"),
    _u("plants/ha", "dose_nombre", "1", "plants par hectare"),
    # Lame d'eau (1 mm = 10 m³/ha)
    _u("mm", "lame_eau", "1", "millimètre"),
    # Débits
    _u("L/h", "debit", "1", "litre par heure"),
    _u("L/min", "debit", "60", "litre par minute"),
    _u("m3/h", "debit", "1000", "mètre cube par heure"),
    # Débit de chantier
    _u("ha/h", "debit_chantier", "1", "hectare par heure"),
    # Temps
    _u("min", "temps", "0.0166666667", "minute"),
    _u("h", "temps", "1", "heure"),
    # Température / humidité
    _u("°C", "temperature", "1", "degré Celsius"),
    _u("%", "pourcentage", "1", "pour cent"),
    _u("%vol", "humidite_sol", "1", "pour cent volumique"),
    _u("kPa", "pression", "1", "kilopascal"),
]}

# Une dose par hectare multipliée par une surface en ha donne une quantité :
DOSE_VERS_QUANTITE = {"dose_masse": "kg", "dose_volume": "L", "dose_nombre": "u"}


def unite(code: str) -> Unite:
    try:
        return UNITES[code]
    except KeyError:
        raise ErreurMetier("unite_inconnue", unite=code)


def convertir(valeur, source: str, cible: str) -> Decimal:
    us, uc = unite(source), unite(cible)
    if us.grandeur != uc.grandeur:
        raise ErreurMetier("unites_incompatibles", source=source, cible=cible)
    if us.grandeur == "temperature":
        return Decimal(str(valeur))
    return Decimal(str(valeur)) * us.facteur / uc.facteur


def compatibles(a: str, b: str) -> bool:
    return unite(a).grandeur == unite(b).grandeur


def quantite_depuis_dose(dose, unite_dose: str, surface_ha) -> tuple[Decimal, str]:
    """Dose (par ha) × surface (ha) → quantité dans l'unité de référence."""
    u = unite(unite_dose)
    if u.grandeur not in DOSE_VERS_QUANTITE:
        raise ErreurMetier("unites_incompatibles", source=unite_dose, cible="dose par hectare")
    ref = DOSE_VERS_QUANTITE[u.grandeur]
    return Decimal(str(dose)) * u.facteur * Decimal(str(surface_ha)), ref


def lame_eau_vers_volume_m3(mm, surface_ha) -> Decimal:
    """1 mm sur 1 ha = 10 m³."""
    return Decimal(str(mm)) * Decimal("10") * Decimal(str(surface_ha))


def arrondi(valeur: Decimal | float, decimales: int = 3) -> float:
    return float(round(Decimal(str(valeur)), decimales))
