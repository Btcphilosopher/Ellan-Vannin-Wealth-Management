from app.core.erreurs import Conflit, Introuvable


def obtenir(ctx, modele, id_, libelle: str):
    obj = ctx.db.get(modele, id_) if id_ else None
    if obj is None:
        raise Introuvable(libelle)
    if hasattr(obj, "exploitation_id") and obj.exploitation_id != ctx.exploitation_id:
        raise Introuvable(libelle)  # cloisonnement : on ne révèle pas l'existence
    return obj


def verifier_version(obj, version_attendue: int | None):
    if version_attendue is not None and obj.version != version_attendue:
        raise Conflit("conflit_version", attendue=version_attendue, actuelle=obj.version)


def appliquer(obj, donnees: dict, ignorer=("id", "exploitation_id", "version")):
    for k, v in donnees.items():
        if k in ignorer:
            continue
        if hasattr(obj, k):
            setattr(obj, k, v)
    if hasattr(obj, "version"):
        obj.version = (obj.version or 0) + 1
