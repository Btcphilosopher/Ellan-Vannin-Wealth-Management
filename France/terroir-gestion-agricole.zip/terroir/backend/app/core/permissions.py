"""Rôles et permissions par exploitation."""

TOUTES = {
    "foncier:lire", "foncier:ecrire",
    "cultures:lire", "cultures:ecrire",
    "interventions:lire", "interventions:ecrire", "interventions:realiser",
    "phyto:valider",
    "stocks:lire", "stocks:ecrire", "stocks:liberer",
    "elevage:lire", "elevage:ecrire", "elevage:traitement",
    "materiel:lire", "materiel:ecrire",
    "equipe:lire", "equipe:ecrire",
    "achats:lire", "achats:ecrire",
    "ventes:lire", "ventes:ecrire",
    "documents:lire", "documents:ecrire", "documents:confidentiels",
    "analyses:lire",
    "parametres:ecrire", "audit:lire", "donnees:exporter", "sauvegarde:gerer",
    "terrain:saisir", "sync:resoudre",
}

LECTURE = {p for p in TOUTES if p.endswith(":lire")}

ROLES: dict[str, dict] = {
    "gerant": {"libelle": "Gérant·e de l'exploitation", "permissions": TOUTES},
    "chef_culture": {
        "libelle": "Chef·fe de culture",
        "permissions": LECTURE | {
            "foncier:ecrire", "cultures:ecrire", "interventions:ecrire", "interventions:realiser",
            "stocks:ecrire", "materiel:ecrire", "equipe:ecrire", "achats:ecrire", "documents:ecrire",
            "terrain:saisir", "sync:resoudre",
        },
    },
    "conseiller": {
        "libelle": "Conseiller·ère agronomique (validation professionnelle)",
        "permissions": {"foncier:lire", "cultures:lire", "interventions:lire", "stocks:lire",
                        "documents:lire", "analyses:lire", "phyto:valider", "cultures:ecrire"},
    },
    "operateur": {
        "libelle": "Opérateur·rice",
        "permissions": {"foncier:lire", "cultures:lire", "interventions:lire", "interventions:realiser",
                        "stocks:lire", "materiel:lire", "equipe:lire", "elevage:lire", "terrain:saisir",
                        "documents:lire"},
    },
    "eleveur": {
        "libelle": "Éleveur·se",
        "permissions": LECTURE - {"achats:lire", "analyses:lire"} | {
            "elevage:ecrire", "elevage:traitement", "stocks:ecrire", "terrain:saisir", "documents:ecrire",
        },
    },
    "veterinaire": {
        "libelle": "Vétérinaire (accès restreint)",
        "permissions": {"elevage:lire", "elevage:traitement", "documents:lire"},
    },
    "comptable": {
        "libelle": "Comptable",
        "permissions": LECTURE | {"achats:ecrire", "ventes:ecrire", "documents:ecrire", "donnees:exporter",
                                  "documents:confidentiels"},
    },
    "lecture": {"libelle": "Consultation", "permissions": LECTURE - {"audit:lire"}},
}


def permissions_du_role(role: str) -> set[str]:
    return set(ROLES.get(role, {}).get("permissions", set()))
