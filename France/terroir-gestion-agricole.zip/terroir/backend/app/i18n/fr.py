"""Catalogue des messages destinés aux utilisateurs (français).

La logique métier lève des erreurs identifiées par un *code* ; le texte
est résolu ici. Ajouter une langue = ajouter un catalogue, sans toucher
aux services.
"""

MESSAGES: dict[str, str] = {
    # Génériques
    "introuvable": "{entite} introuvable.",
    "acces_refuse": "Vous n'avez pas l'autorisation d'effectuer cette action ({permission}).",
    "non_authentifie": "Veuillez vous connecter.",
    "session_expiree": "Votre session a expiré. Veuillez vous reconnecter.",
    "identifiants_invalides": "Adresse électronique ou mot de passe incorrect.",
    "compte_bloque": "Trop de tentatives de connexion. Réessayez dans {minutes} minutes.",
    "csrf": "Requête refusée : en-tête de sécurité manquant.",
    "conflit_version": "Cet enregistrement a été modifié par quelqu'un d'autre (version {attendue} attendue, {actuelle} actuelle). Rechargez avant de modifier.",
    "donnee_invalide": "Donnée invalide : {detail}",
    # Unités
    "unite_inconnue": "Unité inconnue : « {unite} ».",
    "unites_incompatibles": "Impossible de convertir « {source} » en « {cible} » : grandeurs différentes.",
    # Géométrie
    "geometrie_invalide": "Limite parcellaire invalide : {raison}.",
    "geometrie_type": "Seuls les polygones et multipolygones sont acceptés pour une parcelle ou une zone.",
    "srid_non_pris_en_charge": "Système de coordonnées EPSG:{srid} non pris en charge.",
    "zone_hors_parcelle": "La zone de gestion dépasse les limites de la parcelle.",
    # Stocks
    "stock_insuffisant": "Stock disponible insuffisant pour « {article} » : {disponible} {unite} disponibles, {demande} {unite} demandés.",
    "lot_bloque": "Le lot {lot} est bloqué ({statut}) et ne peut pas être utilisé.",
    "quantite_positive": "La quantité doit être strictement positive.",
    "correction_deja": "Ce mouvement a déjà été corrigé.",
    "reservation_inactive": "Cette réservation n'est plus active.",
    # Planning
    "conflit_affectation": "{ressource} est déjà affecté(e) du {debut} au {fin} ({motif}).",
    "materiel_indisponible": "{ressource} est indisponible sur la période : {motif}.",
    "competence_manquante": "{ressource} ne dispose pas de la compétence requise valide : {competence}.",
    # Interventions
    "intervention_statut": "Transition d'état impossible : {de} → {vers}.",
    "intervention_realisee_sans_quantite": "Quantité observée manquante pour « {produit} » : saisissez la quantité réellement mesurée.",
    "traitement_non_autorise": "Seules les personnes autorisées (éleveur, vétérinaire) peuvent saisir un traitement.",
    # Traçabilité
    "lien_cycle": "Ce lien créerait une boucle dans la généalogie des lots.",
    "quantite_lien_excessive": "La quantité dépasse le stock du lot source.",
    # Ventes / achats
    "commande_statut": "Opération impossible : la commande est « {statut} ».",
    "expedition_excessive": "Quantité expédiée supérieure à la quantité allouée restante.",
    # Fichiers
    "fichier_trop_gros": "Fichier trop volumineux (maximum {max} Mo).",
    "fichier_type": "Type de fichier non autorisé ({type}). Formats acceptés : PDF, PNG, JPEG, WebP, CSV, texte, GeoJSON.",
    "fichier_contenu": "Le contenu du fichier ne correspond pas à son extension.",
    # Synchronisation
    "sync_type": "Type d'élément hors connexion non pris en charge : {type}.",
    "sync_conflit": "Conflit de synchronisation : l'élément a été modifié sur le serveur.",
    "conflit_deja_resolu": "Ce conflit est déjà résolu.",
}


LIBELLES: dict[str, dict[str, str]] = {
    "type_intervention": {
        "travail_sol": "Travail du sol",
        "semis": "Semis",
        "plantation": "Plantation",
        "irrigation": "Irrigation",
        "fertilisation": "Fertilisation",
        "traitement_phyto": "Traitement phytopharmaceutique",
        "desherbage_mecanique": "Désherbage mécanique",
        "taille": "Taille",
        "recolte": "Récolte",
        "transport": "Transport",
    },
    "statut_intervention": {
        "planifiee": "Planifiée",
        "en_cours": "En cours",
        "realisee": "Réalisée",
        "annulee": "Annulée",
        "proposee": "Proposée (terrain, à valider)",
    },
    "type_mouvement": {
        "reception": "Réception",
        "consommation": "Consommation",
        "transfert_sortie": "Transfert (sortie)",
        "transfert_entree": "Transfert (entrée)",
        "expedition": "Expédition",
        "perte": "Perte",
        "correction": "Correction",
        "production": "Entrée de production",
        "inventaire": "Ajustement d'inventaire",
        "sortie_lot": "Sortie vers lot dérivé",
        "entree_lot": "Entrée depuis lot(s) source",
    },
}


LIBELLES["origine_lot"] = {
    "achat": "Achat", "recolte": "Récolte", "division": "Division", "regroupement": "Regroupement",
    "classement": "Classement", "conditionnement": "Conditionnement", "transformation": "Transformation",
    "inventaire": "Entrée d'inventaire", "naissance": "Naissance",
}
LIBELLES["statut_lot"] = {
    "libre": "Libre", "bloque": "Bloqué", "quarantaine": "Quarantaine", "en_attente_controle": "En attente de contrôle",
    "epuise": "Épuisé",
}


def libelle(groupe: str, code: str | None) -> str:
    if code is None:
        return "—"
    return LIBELLES.get(groupe, {}).get(code, code)


def message(code: str, **params) -> str:
    modele = MESSAGES.get(code, code)
    try:
        return modele.format(**params)
    except (KeyError, IndexError):
        return modele
