"""Terroir — Gestion agricole : application FastAPI (monolithe modulaire)."""
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import logging

from sqlalchemy import text
from sqlalchemy.exc import DataError, IntegrityError

from app.core.config import get_settings
from app.core.db import get_engine
from app.core.erreurs import ErreurMetier, gestionnaire_erreur_metier
from app.modules.analyses.router import router as r_analyses
from app.modules.commercial.router import router as r_commercial
from app.modules.cultures.router import router as r_cultures
from app.modules.documents.router import router as r_documents
from app.modules.elevage.router import router as r_elevage
from app.modules.equipe.router import router as r_equipe
from app.modules.foncier.router import router as r_foncier
from app.modules.identite.router import router as r_identite
from app.modules.interventions.router import router as r_interventions
from app.modules.materiel.router import router as r_materiel
from app.modules.stocks.router import router as r_stocks
from app.modules.sync.router import router as r_sync
from app.modules.terrain.router import router as r_terrain
from app.modules.tracabilite.router import router as r_tracabilite
import app.taches_metier  # noqa: F401  enregistre les tâches

DESCRIPTION = """
API de **Terroir — Gestion agricole**.

Toutes les routes métier sont cloisonnées par exploitation :
`/api/v1/exploitations/{exploitation_id}/…`. L'authentification se fait par
session (cookie `terroir_session`, httpOnly) ou par jeton `Authorization: Bearer`.
Les requêtes qui modifient des données envoyées avec le cookie doivent porter
l'en-tête `X-Terroir-Requete: 1` (protection CSRF).

Les erreurs fonctionnelles ont la forme `{"code", "message", "parametres"}`,
avec un message en français.
"""

log = logging.getLogger("terroir")
app = FastAPI(title="Terroir — Gestion agricole", version="0.1.0", description=DESCRIPTION,
              docs_url="/api/docs", redoc_url="/api/redoc", openapi_url="/api/openapi.json")
cfg = get_settings()
app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in cfg.cors_origines.split(",")], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])
app.add_exception_handler(ErreurMetier, gestionnaire_erreur_metier)

METHODES_MODIF = {"POST", "PUT", "PATCH", "DELETE"}


@app.middleware("http")
async def securite(request: Request, call_next):
    if (request.method in METHODES_MODIF and request.url.path.startswith("/api/v1/")
            and request.url.path != "/api/v1/auth/connexion"
            and not request.headers.get("authorization", "").lower().startswith("bearer ")
            and request.headers.get("x-terroir-requete") != "1"):
        return JSONResponse(status_code=403, content={"code": "csrf", "message": "Requête refusée : en-tête de sécurité manquant."})
    reponse = await call_next(request)
    reponse.headers["X-Content-Type-Options"] = "nosniff"
    reponse.headers["X-Frame-Options"] = "DENY"
    reponse.headers["Referrer-Policy"] = "same-origin"
    if request.url.path.startswith("/api/v1/"):
        reponse.headers.setdefault("Cache-Control", "no-store")
    return reponse


@app.exception_handler(RequestValidationError)
async def validation(_: Request, exc: RequestValidationError):
    details = [{"champ": ".".join(str(x) for x in e["loc"][1:]), "message": e["msg"]} for e in exc.errors()]
    return JSONResponse(status_code=422, content={"code": "donnee_invalide",
                                                  "message": "Certaines données sont invalides ou manquantes.",
                                                  "details": details})


@app.exception_handler(IntegrityError)
async def integrite(_: Request, exc: IntegrityError):
    log.warning("Violation d'intégrité : %s", exc.orig)
    return JSONResponse(status_code=409, content={"code": "integrite", "message":
                        "Opération refusée : elle entre en conflit avec des données existantes (doublon ou référence invalide)."})


@app.exception_handler(DataError)
async def donnee(_: Request, exc: DataError):
    return JSONResponse(status_code=422, content={"code": "donnee_invalide", "message": "Une valeur saisie est trop longue ou mal formée."})


for r in (r_identite, r_foncier, r_cultures, r_interventions, r_stocks, r_tracabilite, r_commercial, r_elevage,
          r_materiel, r_equipe, r_documents, r_terrain, r_sync, r_analyses):
    app.include_router(r, prefix="/api/v1")


@app.get("/api/sante", tags=["Supervision"])
def sante():
    with get_engine().connect() as c:
        pg = c.execute(text("SELECT postgis_version()")).scalar()
    return {"statut": "ok", "postgis": pg}
