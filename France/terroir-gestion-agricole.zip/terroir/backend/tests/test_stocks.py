import threading
import uuid
from decimal import Decimal

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from app.core.db import SessionLocal
from app.core.erreurs import ErreurMetier
from app.core.securite import Contexte
from app.modules.identite.models import Utilisateur
from app.modules.stocks import service as S
from tests.conftest import entree_stock


def test_quantites_physique_bloque_reserve_disponible_attendu(ferme):
    G, e, a = ferme["api"]["gerant"], ferme["emplacement"], ferme["engrais"]
    l1 = entree_stock(G, a, e, 1000)["lot"]
    l2 = entree_stock(G, a, e, 500)["lot"]
    G.ok("post", f"/lots/{l2['id']}/statut", {"statut": "quarantaine", "motif": "Contrôle"})
    G.ok("post", "/reservations", {"article_id": a["id"], "quantite": 0.2, "unite": "t", "pour_type": "intervention", "pour_id": str(uuid.uuid4())})
    f = G.ok("post", "/fournisseurs", {"nom": "F"})
    G.ok("post", "/commandes-fournisseurs", {"fournisseur_id": f["id"], "date_commande": "2026-01-02",
                                             "lignes": [{"article_id": a["id"], "quantite": 2, "unite": "t", "prix_unitaire_eur": 400}]})
    st = next(x for x in G.ok("get", "/stocks")["articles"] if x["code"] == "ENG")
    assert (st["physique"], st["bloque"], st["reserve"], st["disponible"], st["attendu"]) == (1500, 500, 200, 800, 2000)
    # Un lot bloqué ne peut pas être consommé
    r = G.post("/stocks/consommations", {"article_id": a["id"], "quantite": 10, "unite": "kg", "lot_id": l2["id"]})
    assert r.status_code == 409 and r.json()["code"] == "lot_bloque" and "bloqué" in r.json()["message"]


def test_correction_liee_et_journal_immuable(ferme, db):
    G, e, a = ferme["api"]["gerant"], ferme["emplacement"], ferme["engrais"]
    m = entree_stock(G, a, e, 100)["mouvement"]
    c = G.ok("post", f"/mouvements/{m['id']}/correction", {"quantite_correcte": 90, "motif": "Erreur de saisie au bon de livraison"})
    assert c["corrige_mouvement_id"] == m["id"] and c["quantite"] == -10 and c["auteur_id"]
    assert G.post(f"/mouvements/{m['id']}/correction", {"quantite_correcte": 80, "motif": "x"}).status_code == 409
    journal = G.ok("get", "/mouvements", article_id=a["id"])
    assert next(x for x in journal if x["id"] == m["id"])["est_corrige"] is True
    with pytest.raises(DBAPIError) as err:
        db.execute(text("UPDATE mouvement_stock SET quantite = 1 WHERE id = :i"), {"i": m["id"]})
    assert "immuable" in str(err.value)
    db.rollback()
    with pytest.raises(DBAPIError):
        db.execute(text("DELETE FROM mouvement_stock WHERE id = :i"), {"i": m["id"]})
    db.rollback()


def test_conversion_unite_saisie(ferme):
    G, e, a = ferme["api"]["gerant"], ferme["emplacement"], ferme["engrais"]
    r = entree_stock(G, a, e, 1.25, unite="t")
    assert r["mouvement"]["quantite"] == 1250 and r["mouvement"]["unite_saisie"] == "t"
    assert G.post("/stocks/entrees", {"article_id": a["id"], "emplacement_id": e["id"], "quantite": 5, "unite": "L"}).status_code == 422


def _ctx(session, exp_id, uid):
    u = session.get(Utilisateur, uid)
    return Contexte(session, u, exp_id, "gerant", {"stocks:ecrire"})


def test_reservations_concurrentes(ferme, db):
    """Deux réservations simultanées de 60 kg sur 100 kg disponibles : une seule réussit."""
    G, e, a = ferme["api"]["gerant"], ferme["emplacement"], ferme["engrais"]
    entree_stock(G, a, e, 100)
    exp_id = ferme["api"]["_id"]
    uid = db.execute(text("SELECT id FROM utilisateur WHERE courriel = :c"), {"c": ferme["api"]["_courriels"]["gerant"]}).scalar()
    barriere = threading.Barrier(2)
    resultats = []

    def reserver():
        s = SessionLocal()
        try:
            ctx = _ctx(s, exp_id, uid)
            barriere.wait()
            S.reserver(ctx, uuid.UUID(a["id"]), 60, "kg", "intervention", uuid.uuid4())
            # Maintient le verrou un instant pour forcer le chevauchement
            s.execute(text("SELECT pg_sleep(0.3)"))
            s.commit()
            resultats.append("ok")
        except ErreurMetier as err:
            s.rollback()
            resultats.append(err.code)
        finally:
            s.close()

    fils = [threading.Thread(target=reserver) for _ in range(2)]
    [f.start() for f in fils]
    [f.join() for f in fils]
    assert sorted(resultats) == ["ok", "stock_insuffisant"]
    st = next(x for x in G.ok("get", "/stocks")["articles"] if x["code"] == "ENG")
    assert st["reserve"] == 60 and st["disponible"] == 40


def test_consommation_respecte_reservations_et_fefo(ferme):
    G, e, a = ferme["api"]["gerant"], ferme["emplacement"], ferme["engrais"]
    tard = G.ok("post", "/stocks/entrees", {"article_id": a["id"], "emplacement_id": e["id"], "quantite": 50, "unite": "kg", "date_peremption": "2028-01-01"})["lot"]
    tot = G.ok("post", "/stocks/entrees", {"article_id": a["id"], "emplacement_id": e["id"], "quantite": 50, "unite": "kg", "date_peremption": "2026-12-01"})["lot"]
    G.ok("post", "/reservations", {"article_id": a["id"], "quantite": 70, "unite": "kg", "pour_type": "intervention", "pour_id": str(uuid.uuid4())})
    r = G.post("/stocks/consommations", {"article_id": a["id"], "quantite": 40, "unite": "kg"})
    assert r.status_code == 409  # 100 − 70 réservés = 30 disponibles
    m = G.ok("post", "/stocks/consommations", {"article_id": a["id"], "quantite": 30, "unite": "kg"})
    assert m[0]["lot_id"] == tot["id"]  # premier périmé, premier sorti


def test_observation_stockage_ne_libere_pas(ferme):
    G, O = ferme["api"]["gerant"], ferme["api"]["operateur"]
    lot = entree_stock(G, ferme["recolte"], ferme["emplacement"], 5, "t")["lot"]
    o = G.ok("post", "/observations-stockage", {"emplacement_id": ferme["emplacement"]["id"], "lot_id": lot["id"], "temperature_c": 12, "humidite_produit_pct": 14})
    assert "ne rend pas le lot apte" in o["avertissement"]
    assert next(l for l in G.ok("get", "/lots") if l["id"] == lot["id"])["apte_vente"] is False
    assert O.post(f"/lots/{lot['id']}/decision-vente", {"apte_vente": True, "motif": "x"}).status_code == 403
    d = G.ok("post", f"/lots/{lot['id']}/decision-vente", {"apte_vente": True, "motif": "Analyse conforme"})
    assert d["apte_vente"] and d["apte_vente_decision"]["motif"] == "Analyse conforme"
