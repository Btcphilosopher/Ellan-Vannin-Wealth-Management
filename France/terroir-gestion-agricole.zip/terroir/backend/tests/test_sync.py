import base64
import uuid

from tests.conftest import entree_stock


def _obs(f, oid, desc="Pucerons en bordure"):
    return {"id": str(uuid.uuid4()), "type": "observation", "entite_id": oid, "saisi_le": "2026-05-02T07:30:00+02:00",
            "contenu": {"parcelle_id": f["parcelle"]["id"], "categorie": "ravageur", "description": desc, "intensite": "faible"}}


def test_envoi_idempotent_et_horodatage_terrain(ferme):
    O = ferme["api"]["operateur"]
    oid = str(uuid.uuid4())
    lot = {"terminal_id": "t1", "operations": [_obs(ferme, oid)]}
    r1 = O.ok("post", "/sync/envoi", lot)
    r2 = O.ok("post", "/sync/envoi", lot)
    assert r1["resultats"][0]["statut"] == "acceptee" and r1["resultats"][0]["entite_id"] == oid
    assert r2["resultats"][0]["doublon"] is True
    obs = [o for o in O.ok("get", "/observations") if o["id"] == oid]
    assert len(obs) == 1 and obs[0]["origine"] == "terrain" and obs[0]["observe_le"].startswith("2026-05-02T05:30")


def test_photo_validee(ferme):
    O = ferme["api"]["operateur"]
    bon = base64.b64encode(b"\x89PNG\r\n\x1a\n" + b"0" * 20).decode()
    mauvais = base64.b64encode(b"pas une image").decode()
    r = O.ok("post", "/sync/envoi", {"terminal_id": "t1", "operations": [
        {"id": str(uuid.uuid4()), "type": "photo", "saisi_le": "2026-05-02T08:00:00+02:00", "contenu": {"nom_fichier": "a.png", "donnees_base64": bon}},
        {"id": str(uuid.uuid4()), "type": "photo", "saisi_le": "2026-05-02T08:01:00+02:00", "contenu": {"nom_fichier": "b.png", "donnees_base64": mauvais}}]})
    assert [x["statut"] for x in r["resultats"]] == ["acceptee", "rejetee"]


def test_conflit_detecte_puis_resolu(ferme, db):
    from app.modules.terrain.models import ObservationCulturale

    O, CH = ferme["api"]["operateur"], ferme["api"]["chef_culture"]
    oid = str(uuid.uuid4())
    O.ok("post", "/sync/envoi", {"terminal_id": "t1", "operations": [_obs(ferme, oid)]})
    o = db.get(ObservationCulturale, uuid.UUID(oid))
    base = o.version
    o.description, o.version = "Modifié au bureau", o.version + 1
    db.commit()
    modif = {"id": str(uuid.uuid4()), "type": "modification_observation", "entite_id": oid, "version_base": base,
             "saisi_le": "2026-05-02T09:00:00+02:00", "contenu": {"description": "Modifié sur le terrain", "intensite": "forte"}}
    r = O.ok("post", "/sync/envoi", {"terminal_id": "t1", "operations": [modif]})
    assert r["resultats"][0]["statut"] == "conflit"
    c = CH.ok("get", "/sync/conflits")[0]
    assert set(c["champs_en_conflit"]) == {"description", "intensite"}
    assert c["version_serveur"]["description"] == "Modifié au bureau"
    assert O.post(f"/sync/conflits/{c['id']}/resolution", {"resolution": "garder_terminal"}).status_code == 403
    CH.ok("post", f"/sync/conflits/{c['id']}/resolution", {"resolution": "garder_terminal"})
    db.expire_all()
    assert db.get(ObservationCulturale, uuid.UUID(oid)).description == "Modifié sur le terrain"
    assert CH.post(f"/sync/conflits/{c['id']}/resolution", {"resolution": "fusion"}).status_code == 409


def test_compte_rendu_en_attente_jusqua_validation(ferme):
    O, CH, G = ferme["api"]["operateur"], ferme["api"]["chef_culture"], ferme["api"]["gerant"]
    entree_stock(G, ferme["engrais"], ferme["emplacement"], 1000)
    it = CH.ok("post", "/interventions", {"parcelle_id": ferme["parcelle"]["id"], "cycle_id": ferme["cycle"]["id"], "type": "fertilisation",
                                          "date_prevue": "2026-03-01", "produits": [{"article_id": ferme["engrais"]["id"], "quantite_prevue": 300, "unite_quantite": "kg"}]})
    cr = {"debut_reel": "2026-03-01T08:00:00+01:00", "fin_reelle": "2026-03-01T09:00:00+01:00",
          "produits": [{"intervention_produit_id": it["produits"][0]["id"], "quantite_mesuree": 290}]}
    r = O.ok("post", "/sync/envoi", {"terminal_id": "t1", "operations": [
        {"id": str(uuid.uuid4()), "type": "compte_rendu", "entite_id": it["id"], "saisi_le": "2026-03-01T10:00:00+01:00", "contenu": cr}]})
    op = r["resultats"][0]
    assert op["statut"] == "en_attente_validation"
    phys = lambda: next(x for x in G.ok("get", "/stocks")["articles"] if x["code"] == "ENG")["physique"]  # noqa: E731
    assert phys() == 1000
    assert O.post(f"/sync/operations/{op['id']}/validation").status_code == 403
    CH.ok("post", f"/sync/operations/{op['id']}/validation")
    assert phys() == 710
    # Un second compte rendu sur une intervention déjà réalisée → conflit explicite
    r = O.ok("post", "/sync/envoi", {"terminal_id": "t2", "operations": [
        {"id": str(uuid.uuid4()), "type": "compte_rendu", "entite_id": it["id"], "saisi_le": "2026-03-01T11:00:00+01:00", "contenu": cr}]})
    assert r["resultats"][0]["statut"] == "conflit"


def test_donnees_hors_connexion_perimetre(ferme):
    d = ferme["api"]["operateur"].ok("get", "/sync/donnees")
    assert d["parcelles"] and "perimetre" in d
    assert ferme["api"]["comptable"].get("/sync/donnees").status_code == 403
