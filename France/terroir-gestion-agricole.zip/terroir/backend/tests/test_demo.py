"""La démonstration complète doit s'exécuter sans erreur (toutes les vérifications réussies)."""


def test_demonstration_complete(tmp_path):
    from app.seed.demo import main

    j = main(tmp_path)
    assert j.verifications and all(ok for _, ok in j.verifications)
    assert (tmp_path / "RESULTATS_DEMO.md").exists()
    assert (tmp_path / "tracabilite-BT-2026-P01.pdf").read_bytes()[:5] == b"%PDF-"
