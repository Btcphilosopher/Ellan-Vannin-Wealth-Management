import io

from tests.conftest import MDP, carre_l93


def test_role_operateur_restreint(ferme):
    O = ferme["api"]["operateur"]
    r = O.post("/parcelles", {"site_id": ferme["site"]["id"], "code": "X", "nom": "X"})
    assert r.status_code == 403 and r.json()["code"] == "acces_refuse" and "foncier:ecrire" in r.json()["message"]
    assert O.get("/parcelles").status_code == 200
    assert O.get("/analyses/couts", campagne_id=ferme["campagne"]["id"]).status_code == 403
    assert O.get("/audit").status_code == 403


def test_veterinaire_limite_a_l_elevage(ferme):
    V = ferme["api"]["veterinaire"]
    assert V.get("/parcelles").status_code == 403
    assert V.get("/lots-animaux").status_code == 200
    assert V.get("/stocks").status_code == 403


def test_cloisonnement_entre_exploitations(client, ferme, autre_exploitation):
    autre = autre_exploitation
    G_autre = autre["gerant"]
    # Accès à une autre exploitation par l'URL : refusé
    r = client.get(f"/api/v1/exploitations/{ferme['api']['_id']}/parcelles", headers=G_autre.h)
    assert r.status_code == 403
    # Référence croisée d'un objet d'une autre exploitation : introuvable
    site = G_autre.ok("post", "/sites", {"nom": "S"})
    r = G_autre.post("/cycles", {"campagne_id": ferme["campagne"]["id"], "parcelle_id": ferme["parcelle"]["id"], "culture": "Maïs", "surface_prevue_ha": 1})
    assert r.status_code == 404


def test_csrf_et_session_cookie(client, ferme):
    courriel = ferme["api"]["_courriels"]["gerant"]
    r = client.post("/api/v1/auth/connexion", json={"courriel": courriel, "mot_de_passe": MDP})
    assert r.status_code == 200
    cookie = r.cookies.get("terroir_session")
    assert cookie and "httponly" in r.headers["set-cookie"].lower() and "samesite=lax" in r.headers["set-cookie"].lower()
    e = ferme["api"]["_id"]
    client.cookies.set("terroir_session", cookie)
    r = client.post(f"/api/v1/exploitations/{e}/sites", json={"nom": "Sans en-tête"})
    assert r.status_code == 403 and r.json()["code"] == "csrf"
    r = client.post(f"/api/v1/exploitations/{e}/sites", json={"nom": "Avec en-tête"}, headers={"X-Terroir-Requete": "1"})
    assert r.status_code == 201
    client.post("/api/v1/auth/deconnexion", headers={"X-Terroir-Requete": "1"})
    client.cookies.set("terroir_session", cookie)
    assert client.get("/api/v1/auth/moi").status_code == 401  # session révoquée côté serveur
    client.cookies.clear()


def test_blocage_apres_echecs(client, ferme):
    courriel = ferme["api"]["_courriels"]["lecture"]
    for _ in range(5):
        assert client.post("/api/v1/auth/connexion", json={"courriel": courriel, "mot_de_passe": "faux"}).status_code == 401
    r = client.post("/api/v1/auth/connexion", json={"courriel": courriel, "mot_de_passe": MDP})
    assert r.status_code == 429 and "Trop de tentatives" in r.json()["message"]


def test_mot_de_passe_jamais_expose(ferme, db):
    from sqlalchemy import text

    G = ferme["api"]["gerant"]
    assert "mot_de_passe" not in str(G.ok("get", "/api/v1/auth/moi"))
    h = db.execute(text("SELECT mot_de_passe_hash FROM utilisateur LIMIT 1")).scalar()
    assert h.startswith("$2b$") and MDP not in h
    assert db.execute(text("SELECT count(*) FROM session_utilisateur WHERE length(jeton_hash) <> 64")).scalar() == 0


def test_journal_audit(ferme):
    G = ferme["api"]["gerant"]
    a = G.ok("get", "/audit", entite="parcelle")
    assert a and a[-1]["action"] == "creation" and a[-1]["auteur"]


def test_documents_valides_et_proteges(client, ferme):
    G, O, L = ferme["api"]["gerant"], ferme["api"]["operateur"], ferme["api"]["lecture"]
    pdf = b"%PDF-1.4\n% test\n"
    r = G.post("/documents", files={"fichier": ("bail.pdf", pdf, "application/pdf")}, data={"categorie": "bail_foncier", "titre": "Bail", "confidentiel": "true"})
    assert r.status_code == 201, r.text
    doc = r.json()
    assert "cle_stockage" not in doc and len(doc["sha256"]) == 64
    faux = G.post("/documents", files={"fichier": ("faux.pdf", b"MZ\x90\x00exe", "application/pdf")}, data={"categorie": "autre", "titre": "x"})
    assert faux.status_code == 415 and faux.json()["code"] == "fichier_contenu"
    exe = G.post("/documents", files={"fichier": ("outil.exe", b"MZ", "application/octet-stream")}, data={"categorie": "autre", "titre": "x"})
    assert exe.status_code == 415
    gros = G.post("/documents", files={"fichier": ("gros.txt", b"a" * (16 * 1024 * 1024), "text/plain")}, data={"categorie": "autre", "titre": "x"})
    assert gros.status_code == 413
    nom = G.post("/documents", files={"fichier": ("../../etc/passwd.txt", b"bonjour", "text/plain")}, data={"categorie": "autre", "titre": "x"})
    assert nom.json()["nom_fichier"] == "passwd.txt"
    assert G.get(f"/documents/{doc['id']}/contenu").content == pdf
    assert L.get(f"/documents/{doc['id']}/contenu").status_code == 403  # confidentiel
    assert all(d["id"] != doc["id"] for d in L.ok("get", "/documents"))
    client.cookies.clear()  # requête anonyme (aucune session)
    assert client.get(f"/api/v1/exploitations/{ferme['api']['_id']}/documents/{doc['id']}/contenu").status_code == 401
