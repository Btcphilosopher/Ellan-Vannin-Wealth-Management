from decimal import Decimal

import pytest
from pyproj import Geod
from shapely.geometry import shape
from sqlalchemy import text

from app.core.erreurs import ErreurMetier
from app.modules.foncier.geometrie import ecart_surface, lire_geometrie, surface_geodesique_ha
from tests.conftest import carre_l93


def test_carre_lambert93_un_hectare():
    g, wkt = lire_geometrie(carre_l93(cote=100), 2154)
    s = surface_geodesique_ha(g)
    # Lambert-93 est conforme : l'altération linéaire locale reste < 0,1 % ici.
    assert abs(float(s) - 1.0) < 0.003
    assert wkt.startswith("MULTIPOLYGON (((500000 6700000")


def test_polygone_auto_intersecte_refuse():
    papillon = {"type": "Polygon", "coordinates": [[[0, 0], [1, 1], [1, 0], [0, 1], [0, 0]]]}
    with pytest.raises(ErreurMetier) as e:
        lire_geometrie(papillon, 4326)
    assert "auto-intersection" in e.value.message


def test_srid_non_pris_en_charge_et_type():
    with pytest.raises(ErreurMetier):
        lire_geometrie(carre_l93(), 27572)
    with pytest.raises(ErreurMetier) as e:
        lire_geometrie({"type": "LineString", "coordinates": [[0, 0], [1, 1]]}, 4326)
    assert e.value.code == "geometrie_type"


def test_systeme_mal_declare_detecte():
    # Coordonnées Lambert-93 déclarées en WGS 84 : hors limites → refus explicite
    with pytest.raises(ErreurMetier) as e:
        lire_geometrie(carre_l93(), 4326)
    assert "système de coordonnées" in e.value.message


def test_ecart_surface_signale_sans_ecraser():
    e = ecart_surface(Decimal("12.10"), Decimal("12.42"), 2.0)
    assert e["signale"] and e["ecart_pct"] == pytest.approx(2.64, abs=0.01)
    assert ecart_surface(10, Decimal("10.1"), 2.0)["signale"] is False
    assert ecart_surface(None, 3, 2.0)["signale"] is False


def test_api_parcelle_surface_postgis_et_provenance(ferme, db):
    p = ferme["parcelle"]
    assert p["srid_origine"] == 2154 and p["provenance_geometrie"]["source"] == "test"
    assert p["surface_declaree_ha"] == 10.0  # jamais écrasée
    pg = db.execute(text("SELECT ST_Area(geometrie::geography)/10000 FROM parcelle WHERE id=:i"), {"i": p["id"]}).scalar()
    assert abs(pg - p["surface_calculee_ha"]) < 0.001
    geod = Geod(ellps="WGS84")
    g = shape(p["geometrie"])
    assert abs(abs(geod.geometry_area_perimeter(g)[0]) / 10000 - pg) < 0.001


def test_chevauchement_et_zone_hors_parcelle(ferme):
    G = ferme["api"]["gerant"]
    p2 = G.ok("post", "/parcelles", {"site_id": ferme["site"]["id"], "code": "T02", "nom": "Voisine",
                                     "geometrie": {"geojson": carre_l93(x0=500300, cote=100), "srid": 2154, "source": "test"}})
    assert p2["chevauchements"] and p2["chevauchements"][0]["code"] == "T01"
    r = G.post(f"/parcelles/{ferme['parcelle']['id']}/zones", {"nom": "Hors", "geometrie": {"geojson": carre_l93(x0=499000, cote=50), "srid": 2154, "source": "t"}})
    assert r.status_code == 422 and r.json()["code"] == "zone_hors_parcelle"
    ok = G.post(f"/parcelles/{ferme['parcelle']['id']}/zones", {"nom": "Dedans", "geometrie": {"geojson": carre_l93(x0=500010, y0=6700010, cote=50), "srid": 2154, "source": "t"}})
    assert ok.status_code == 201 and abs(ok.json()["surface_calculee_ha"] - 0.25) < 0.002


def test_verrouillage_optimiste_parcelle(ferme):
    G = ferme["api"]["gerant"]
    p = ferme["parcelle"]
    r1 = G.c.patch(G.url(f"/parcelles/{p['id']}"), headers=G.h, json={"version": p["version"], "notes": "A"})
    assert r1.status_code == 200
    r2 = G.c.patch(G.url(f"/parcelles/{p['id']}"), headers=G.h, json={"version": p["version"], "notes": "B"})
    assert r2.status_code == 409 and r2.json()["code"] == "conflit_version"
