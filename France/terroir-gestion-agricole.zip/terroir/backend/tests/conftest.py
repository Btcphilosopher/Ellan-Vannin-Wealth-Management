"""Configuration des tests : base PostgreSQL/PostGIS dédiée, migrée par Alembic."""
import os
import subprocess
import tempfile
import uuid
from pathlib import Path

import pytest

BASE_TEST = os.environ.get("TERROIR_TEST_DATABASE_URL", "postgresql+psycopg://terroir:terroir@localhost:5432/terroir_test")
os.environ["TERROIR_DATABASE_URL"] = BASE_TEST
os.environ["TERROIR_STOCKAGE_CHEMIN"] = tempfile.mkdtemp(prefix="terroir-objets-test-")
os.environ["TERROIR_ENVIRONNEMENT"] = "test"
os.environ["TERROIR_STOCKAGE_BACKEND"] = "local"  # les tests utilisent un dossier temporaire

from sqlalchemy import create_engine, text  # noqa: E402

from app.core.config import get_settings  # noqa: E402

get_settings.cache_clear()
RACINE = Path(__file__).resolve().parents[1]


def _admin_url(url: str, base: str = "postgres") -> str:
    return url.rsplit("/", 1)[0] + "/" + base


@pytest.fixture(scope="session", autouse=True)
def base_de_test():
    nom = BASE_TEST.rsplit("/", 1)[1]
    eng = create_engine(_admin_url(BASE_TEST), isolation_level="AUTOCOMMIT")
    with eng.connect() as c:
        c.execute(text(f'DROP DATABASE IF EXISTS "{nom}" WITH (FORCE)'))
        c.execute(text(f'CREATE DATABASE "{nom}"'))
    eng.dispose()
    # La migration Alembic est elle-même testée ici.
    subprocess.run(["alembic", "upgrade", "head"], cwd=RACINE, check=True, env=os.environ | {"TERROIR_DATABASE_URL": BASE_TEST})
    from app.core.db import reset_engine

    reset_engine()
    yield


@pytest.fixture()
def client():
    from fastapi.testclient import TestClient

    from app.main import app

    return TestClient(app)


@pytest.fixture()
def db():
    from app.core.db import SessionLocal

    s = SessionLocal()
    yield s
    s.close()


class Api:
    def __init__(self, client, jeton, exp_id):
        self.c, self.e = client, exp_id
        self.h = {"Authorization": f"Bearer {jeton}"}

    def url(self, chemin):
        return chemin if chemin.startswith("/api") else f"/api/v1/exploitations/{self.e}{chemin}"

    def get(self, chemin, **params):
        return self.c.get(self.url(chemin), headers=self.h, params=params)

    def post(self, chemin, json=None, **kw):
        return self.c.post(self.url(chemin), headers=self.h, json=json, **kw)

    def ok(self, methode, chemin, json=None, **params):
        r = getattr(self, methode)(chemin, json=json) if methode == "post" else self.get(chemin, **params)
        assert r.status_code in (200, 201, 202), f"{methode.upper()} {chemin} → {r.status_code} {r.text[:500]}"
        return r.json()


MDP = "Mot-de-passe-test-12"


def _creer_exploitation(client, db):
    """Crée une exploitation isolée avec un utilisateur par rôle ; retourne {role: Api}."""
    from app.core.securite import hacher_mot_de_passe
    from app.modules.identite.models import Adhesion, Exploitation, Utilisateur

    e = Exploitation(raison_sociale=f"Ferme de test {uuid.uuid4().hex[:6]}", modules_actifs=["grandes_cultures"], fictive=True)
    db.add(e)
    db.flush()
    h = hacher_mot_de_passe(MDP)
    apis = {}
    for role in ("gerant", "chef_culture", "operateur", "eleveur", "conseiller", "veterinaire", "comptable", "lecture"):
        u = Utilisateur(courriel=f"{role}.{uuid.uuid4().hex[:8]}@test.example", nom_affiche=f"Test {role}", mot_de_passe_hash=h)
        db.add(u)
        db.flush()
        db.add(Adhesion(utilisateur_id=u.id, exploitation_id=e.id, role=role))
        apis[role] = u.courriel
    db.commit()
    res = {}
    for role, courriel in apis.items():
        r = client.post("/api/v1/auth/connexion", json={"courriel": courriel, "mot_de_passe": MDP})
        assert r.status_code == 200, r.text
        res[role] = Api(client, r.json()["jeton"], e.id)
    res["_id"] = e.id
    res["_courriels"] = apis
    return res


@pytest.fixture()
def exploitation(client, db):
    return _creer_exploitation(client, db)


@pytest.fixture()
def autre_exploitation(client, db):
    return _creer_exploitation(client, db)


def carre_l93(x0=500000, y0=6700000, cote=100.0):
    return {"type": "Polygon", "coordinates": [[[x0, y0], [x0 + cote, y0], [x0 + cote, y0 + cote], [x0, y0 + cote], [x0, y0]]]}


@pytest.fixture()
def ferme(exploitation):
    """Socle minimal : site, parcelle, campagne, cycle, articles, emplacement, membre, matériel."""
    G = exploitation["gerant"]
    site = G.ok("post", "/sites", {"nom": "Site test", "fuseau_horaire": "Europe/Paris"})
    p = G.ok("post", "/parcelles", {"site_id": site["id"], "code": "T01", "nom": "Parcelle test", "surface_declaree_ha": 10.0,
                                    "geometrie": {"geojson": carre_l93(cote=316.2278), "srid": 2154, "source": "test"}})
    camp = G.ok("post", "/campagnes", {"libelle": "2025-2026", "date_debut": "2025-09-01", "date_fin": "2026-08-31"})
    cyc = G.ok("post", "/cycles", {"campagne_id": camp["id"], "parcelle_id": p["id"], "culture": "Blé tendre", "surface_prevue_ha": 10.0,
                                   "date_recolte_debut_prevue": "2026-07-10"})
    empl = G.ok("post", "/emplacements", {"site_id": site["id"], "code": "MAG", "nom": "Magasin", "type": "magasin"})
    engrais = G.ok("post", "/articles", {"code": "ENG", "libelle": "Engrais test", "categorie": "engrais", "unite_stock": "kg"})
    recolte = G.ok("post", "/articles", {"code": "REC", "libelle": "Blé récolté", "categorie": "produit_recolte", "unite_stock": "t"})
    membre = G.ok("post", "/membres", {"prenom": "Alex", "nom": "Test", "statut": "salarie"})
    mat = G.ok("post", "/materiels", {"code": "TR", "libelle": "Tracteur test", "categorie": "tracteur"})
    return {"api": exploitation, "site": site, "parcelle": p, "campagne": camp, "cycle": cyc, "emplacement": empl,
            "engrais": engrais, "recolte": recolte, "membre": membre, "materiel": mat}


def entree_stock(G, article, emplacement, quantite, unite="kg", cout=None):
    return G.ok("post", "/stocks/entrees", {"article_id": article["id"], "emplacement_id": emplacement["id"], "quantite": quantite,
                                            "unite": unite, "cout_unitaire": cout})
