import uuid
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError


def _it(f, type_="fertilisation", **kw):
    return f["api"]["chef_culture"].ok("post", "/interventions", {"parcelle_id": f["parcelle"]["id"], "cycle_id": f["cycle"]["id"], "type": type_,
                                                                  "date_prevue": "2026-03-01"} | kw)


def test_chevauchement_refuse_et_adjacence_acceptee(ferme):
    CH = ferme["api"]["chef_culture"]
    a, b = _it(ferme), _it(ferme)
    m = ferme["materiel"]["id"]
    CH.ok("post", f"/interventions/{a['id']}/affectations", {"ressource_type": "materiel", "ressource_id": m, "debut": "2026-03-01T08:00:00+01:00", "fin": "2026-03-01T12:00:00+01:00"})
    r = CH.post(f"/interventions/{b['id']}/affectations", {"ressource_type": "materiel", "ressource_id": m, "debut": "2026-03-01T11:00:00+01:00", "fin": "2026-03-01T13:00:00+01:00"})
    assert r.status_code == 409 and r.json()["code"] == "conflit_affectation"
    assert "01/03/2026 08:00" in r.json()["message"]  # heure locale du site
    ok = CH.post(f"/interventions/{b['id']}/affectations", {"ressource_type": "materiel", "ressource_id": m, "debut": "2026-03-01T12:00:00+01:00", "fin": "2026-03-01T14:00:00+01:00"})
    assert ok.status_code == 201


def test_maintenance_et_defaut_bloquant(ferme):
    CH, G = ferme["api"]["chef_culture"], ferme["api"]["gerant"]
    m = ferme["materiel"]["id"]
    G.ok("post", f"/materiels/{m}/maintenances", {"type": "preventive", "libelle": "Vidange", "immobilise_du": "2026-03-10T08:00:00+01:00", "immobilise_au": "2026-03-11T18:00:00+01:00"})
    it = _it(ferme)
    r = CH.post(f"/interventions/{it['id']}/affectations", {"ressource_type": "materiel", "ressource_id": m, "debut": "2026-03-11T09:00:00+01:00", "fin": "2026-03-11T10:00:00+01:00"})
    assert r.status_code == 409 and r.json()["code"] == "materiel_indisponible"
    pl = CH.ok("get", "/planning", du="2026-03-01", au="2026-03-31")
    assert pl["restrictions_materiel"][0]["type"] == "maintenance"
    d = ferme["api"]["operateur"].ok("post", f"/materiels/{m}/defauts", {"gravite": "bloquant", "description": "Crevaison"})
    etat = next(x for x in CH.ok("get", "/materiels") if x["id"] == m)
    assert etat["disponibilite"]["disponible"] is False and etat["disponibilite"]["libelle"] == "Indisponible"
    G.ok("post", f"/defauts/{d['id']}/resolution")
    assert next(x for x in CH.ok("get", "/materiels") if x["id"] == m)["disponibilite"]["disponible"] is True


def test_competence_requise(ferme):
    CH, G = ferme["api"]["chef_culture"], ferme["api"]["gerant"]
    it = _it(ferme, "traitement_phyto")
    mb = ferme["membre"]["id"]
    body = {"ressource_type": "membre", "ressource_id": mb, "debut": "2026-04-01T08:00:00+02:00", "fin": "2026-04-01T10:00:00+02:00"}
    assert CH.post(f"/interventions/{it['id']}/affectations", body).json()["code"] == "competence_manquante"
    G.ok("post", f"/membres/{mb}/competences", {"type": "certiphyto_operateur", "libelle": "Certiphyto", "valide_au": "2026-03-01"})
    assert CH.post(f"/interventions/{it['id']}/affectations", body).status_code == 409  # échu
    G.ok("post", f"/membres/{mb}/competences", {"type": "certiphyto_operateur", "libelle": "Certiphyto", "valide_au": "2030-01-01"})
    assert CH.post(f"/interventions/{it['id']}/affectations", body).status_code == 201


def test_contrainte_exclusion_postgresql(ferme, db):
    """Garde-fou base de données, indépendant du code applicatif."""
    it = _it(ferme)
    rid = uuid.uuid4()
    t0 = datetime(2026, 5, 1, 8, tzinfo=timezone.utc)
    sql = text("INSERT INTO affectation (id, exploitation_id, intervention_id, ressource_type, ressource_id, debut, fin, active, cree_le, modifie_le) "
               "VALUES (:id, :e, :i, 'materiel', :r, :d, :f, true, now(), now())")
    db.execute(sql, {"id": uuid.uuid4(), "e": ferme["api"]["_id"], "i": it["id"], "r": rid, "d": t0, "f": t0 + timedelta(hours=2)})
    db.commit()
    with pytest.raises(IntegrityError):
        db.execute(sql, {"id": uuid.uuid4(), "e": ferme["api"]["_id"], "i": it["id"], "r": rid, "d": t0 + timedelta(hours=1), "f": t0 + timedelta(hours=3)})
        db.commit()
    db.rollback()


def test_validation_phyto_requise_et_verification(ferme, db):
    from app.modules.intrants.models import ProduitReferentiel, SourceReferentiel, UsageReferentiel
    from app.core.db import maintenant

    G, CH, CO = ferme["api"]["gerant"], ferme["api"]["chef_culture"], ferme["api"]["conseiller"]
    src = SourceReferentiel(nom="Référentiel de test (fictif)", importe_le=maintenant(), officielle=False)
    db.add(src)
    db.flush()
    pr = ProduitReferentiel(source_id=src.id, numero_amm="TEST-1", nom_commercial="Produit test", etat_autorisation="Autorisé")
    db.add(pr)
    db.flush()
    db.add(UsageReferentiel(produit_id=pr.id, culture="Blé tendre", dose_max=1.0, unite_dose="L/ha", delai_avant_recolte_jours=60))
    db.commit()
    a = G.ok("post", "/articles", {"code": "PHY", "libelle": "Produit test", "categorie": "phytopharmaceutique", "unite_stock": "L",
                                   "reglemente": True, "produit_referentiel_id": str(pr.id)})
    hors = G.ok("post", "/articles", {"code": "PHY2", "libelle": "Hors référentiel", "categorie": "phytopharmaceutique", "unite_stock": "L", "reglemente": True})
    it = _it(ferme, "traitement_phyto", date_prevue="2026-06-01",
             produits=[{"article_id": a["id"], "dose_prevue": 1.5, "unite_dose": "L/ha"}, {"article_id": hors["id"], "dose_prevue": 1, "unite_dose": "L/ha"}])
    v = CH.ok("post", f"/interventions/{it['id']}/verification")
    statuts = {c["code"]: c["statut"] for c in v["controles"] if "Produit test" in c["libelle"]}
    assert statuts["dose"] == "alerte"  # 1,5 > 1,0
    assert statuts["dar"] == "alerte"  # 01/06 + 60 j > 10/07
    assert statuts["nb_applications"] == "non_disponible"
    assert any(c["statut"] == "non_disponible" and "Hors référentiel" in c["libelle"] for c in v["controles"])
    assert v["controles_non_couverts"] and "preuve de conformité" in v["avertissement"]
    assert CH.post(f"/interventions/{it['id']}/demarrage").status_code == 409
    assert CH.post(f"/interventions/{it['id']}/validation-professionnelle", {"decision": "validee", "qualification": "x"}).status_code == 403
    CO.ok("post", f"/interventions/{it['id']}/validation-professionnelle", {"decision": "validee", "qualification": "Conseiller"})
    assert CH.post(f"/interventions/{it['id']}/demarrage").status_code == 200


def test_compte_rendu_exige_quantite_mesuree(ferme):
    from tests.conftest import entree_stock

    CH, G = ferme["api"]["chef_culture"], ferme["api"]["gerant"]
    entree_stock(G, ferme["engrais"], ferme["emplacement"], 3000)
    it = _it(ferme, produits=[{"article_id": ferme["engrais"]["id"], "dose_prevue": 150, "unite_dose": "kg/ha"}])
    assert it["produits"][0]["quantite_prevue"] == 1500
    r = CH.post(f"/interventions/{it['id']}/realisation", {"debut_reel": "2026-03-01T08:00:00+01:00", "fin_reelle": "2026-03-01T10:00:00+01:00"})
    assert r.json()["code"] == "intervention_realisee_sans_quantite"
    d = CH.ok("post", f"/interventions/{it['id']}/realisation", {"debut_reel": "2026-03-01T08:00:00+01:00", "fin_reelle": "2026-03-01T10:00:00+01:00",
                                                                  "produits": [{"intervention_produit_id": it["produits"][0]["id"], "quantite_mesuree": 1480, "methode_mesure": "pesee",
                                                                                "consigne_machine": 150, "unite_consigne": "kg/ha"}]})
    p = d["produits"][0]
    assert (p["quantite_prevue"], p["consigne_machine"], p["quantite_mesuree"]) == (1500, 150, 1480)
    assert d["meteo"]["nature"] == "indisponible"
    st = next(x for x in G.ok("get", "/stocks")["articles"] if x["code"] == "ENG")
    assert st["physique"] == 1520
