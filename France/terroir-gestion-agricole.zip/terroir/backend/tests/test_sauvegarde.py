"""Sauvegarde puis restauration dans une base vierge ; comparaison des contenus."""
import os
import shutil

import pytest
from sqlalchemy import create_engine, text

from tests.conftest import BASE_TEST, _admin_url, entree_stock


@pytest.mark.skipif(not shutil.which("pg_dump"), reason="pg_dump indisponible")
def test_sauvegarde_restauration(ferme, tmp_path):
    from app.outils.sauvegarde import restaurer, sauvegarder

    G = ferme["api"]["gerant"]
    entree_stock(G, ferme["engrais"], ferme["emplacement"], 123.4)
    G.post("/documents", files={"fichier": ("note.txt", "Données à protéger".encode(), "text/plain")}, data={"categorie": "autre", "titre": "Note"})
    archive = sauvegarder(tmp_path)
    assert archive.exists() and oct(archive.stat().st_mode)[-3:] == "600"
    cible_nom = "terroir_restauration_test"
    adm = create_engine(_admin_url(BASE_TEST), isolation_level="AUTOCOMMIT")
    with adm.connect() as c:
        c.execute(text(f"DROP DATABASE IF EXISTS {cible_nom} WITH (FORCE)"))
        c.execute(text(f"CREATE DATABASE {cible_nom}"))
    cible = BASE_TEST.rsplit("/", 1)[0] + "/" + cible_nom
    res = restaurer(archive, cible)
    assert res["comptages_identiques"], res["ecarts"]
    assert res["objets_restaures"] >= 1
    e = create_engine(cible)
    with e.connect() as c:
        assert c.execute(text("SELECT count(*) FROM parcelle WHERE code='T01'")).scalar() >= 1
        assert c.execute(text("SELECT postgis_version()")).scalar()
        # Les protections sont restaurées avec le schéma
        assert c.execute(text("SELECT count(*) FROM pg_trigger WHERE tgname='tr_mouvement_immuable'")).scalar() == 1
        assert c.execute(text("SELECT count(*) FROM pg_constraint WHERE conname='ex_affectation_chevauchement'")).scalar() == 1
    e.dispose()
    with adm.connect() as c:
        c.execute(text(f"DROP DATABASE IF EXISTS {cible_nom} WITH (FORCE)"))
    adm.dispose()


def test_export_donnees(ferme):
    import io
    import json
    import zipfile

    G = ferme["api"]["gerant"]
    r = G.get("/export-donnees")
    assert r.status_code == 200
    z = zipfile.ZipFile(io.BytesIO(r.content))
    man = json.loads(z.read("manifeste.json"))
    assert man["tables"]["parcelle"] == 1
    parcelles = json.loads(z.read("parcelle.json"))
    assert parcelles[0]["geometrie"]["type"] == "MultiPolygon"
    assert "utilisateur.json" not in z.namelist()
    assert ferme["api"]["operateur"].get("/export-donnees").status_code == 403
