from decimal import Decimal

import pytest

from app.core.erreurs import ErreurMetier
from app.core.format_fr import court, date_fr, euros, nombre
from app.core.unites import convertir, lame_eau_vers_volume_m3, quantite_depuis_dose


def test_conversions_masse_volume_surface():
    assert convertir(1.5, "t", "kg") == Decimal("1500")
    assert convertir(250, "kg", "q") == Decimal("2.5")
    assert convertir(2500, "mL", "L") == Decimal("2.5")
    assert convertir(15000, "m2", "ha") == Decimal("1.5")
    assert convertir(1, "m3", "L") == Decimal("1000")


def test_conversion_incompatible_refusee():
    with pytest.raises(ErreurMetier) as e:
        convertir(1, "kg", "L")
    assert e.value.code == "unites_incompatibles"
    assert "grandeurs différentes" in e.value.message


def test_unite_inconnue():
    with pytest.raises(ErreurMetier) as e:
        convertir(1, "boisseau", "kg")
    assert "boisseau" in e.value.message


def test_dose_par_hectare_vers_quantite():
    q, u = quantite_depuis_dose(150, "kg/ha", Decimal("12.4"))
    assert (q, u) == (Decimal("1860.0"), "kg")
    q, u = quantite_depuis_dose(800, "mL/ha", 10)
    assert (q, u) == (Decimal("8.000"), "L")
    with pytest.raises(ErreurMetier):
        quantite_depuis_dose(3, "kg", 1)


def test_doses_comparables():
    assert convertir(0.8, "L/ha", "mL/ha") == Decimal("800")
    assert convertir(35, "q/ha", "t/ha") == Decimal("3.5")


def test_lame_eau():
    assert lame_eau_vers_volume_m3(10, 2) == Decimal("200")


def test_formats_francais():
    assert nombre(1234.5, 2) == "1 234,50"
    assert euros(6360) == "6 360,00 €"
    assert court(9.70) == "9,7"
    assert court(1842) == "1 842"
    assert date_fr("2026-02-20") == "20/02/2026"
