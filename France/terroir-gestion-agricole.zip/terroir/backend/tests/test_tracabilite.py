import uuid

import pytest

from app.core.erreurs import ErreurMetier
from tests.conftest import entree_stock


def _recolte(f, quantite=40):
    CH = f["api"]["chef_culture"]
    it = CH.ok("post", "/interventions", {"parcelle_id": f["parcelle"]["id"], "cycle_id": f["cycle"]["id"], "type": "recolte", "date_prevue": "2026-07-15"})
    CH.ok("post", f"/interventions/{it['id']}/realisation", {"debut_reel": "2026-07-15T09:00:00+02:00", "fin_reelle": "2026-07-15T15:00:00+02:00"})
    return CH.ok("post", "/recoltes", {"intervention_id": it["id"], "article_id": f["recolte"]["id"], "quantite": quantite, "unite": "t",
                                       "emplacement_id": f["emplacement"]["id"], "date_recolte": "2026-07-15", "statut": "libre",
                                       "qualite_observee": {"humidite_pct": 14.5}})["lot"]


def test_recolte_rattachee_et_non_apte(ferme):
    lot = _recolte(ferme)
    assert lot["parcelle_id"] == ferme["parcelle"]["id"] and lot["cycle_id"] == ferme["cycle"]["id"] and lot["apte_vente"] is False
    t = ferme["api"]["gerant"].ok("get", f"/tracabilite/lots/{lot['id']}")
    assert t["complete_jusqua_parcelle"] and t["parcelles_origine"][0]["code"] == "T01"


def test_division_regroupement_conservent_les_liens(ferme):
    G = ferme["api"]["gerant"]
    e = ferme["emplacement"]["id"]
    lot = _recolte(ferme, 40)
    enfants = G.ok("post", f"/lots/{lot['id']}/division", {"emplacement_source_id": e, "type": "classement", "parts": [
        {"quantite": 25, "unite": "t", "classement": "Meunier"}, {"quantite": 14, "unite": "t", "classement": "Fourrager"},
        {"quantite": 1, "unite": "t", "perte": True, "motif": "Criblage"}]})
    assert len(enfants) == 2
    autre = entree_stock(G, ferme["recolte"], ferme["emplacement"], 10, "t")["lot"]  # origine non documentée
    reg = G.ok("post", "/lots/regroupement", {"emplacement_id": e, "sources": [
        {"lot_id": enfants[1]["id"], "emplacement_id": e, "quantite": 14, "unite": "t"},
        {"lot_id": autre["id"], "emplacement_id": e, "quantite": 10, "unite": "t"}]})
    t = G.ok("get", f"/tracabilite/lots/{reg['id']}")
    numeros = {a["numero"] for a in t["ascendants"]}
    assert {enfants[1]["numero"], autre["numero"], lot["numero"]} <= numeros
    assert t["complete_jusqua_parcelle"] is False
    assert any("Origine non documentée" in m["manque"] for m in t["donnees_manquantes"])
    # Le lot d'origine voit ses descendants
    t0 = G.ok("get", f"/tracabilite/lots/{lot['id']}")
    assert reg["numero"] in {d["numero"] for d in t0["descendants"]}
    # Quantités : 40 − 25 − 14 − 1 = 0 sur le lot d'origine
    assert next(l for l in G.ok("get", "/lots") if l["id"] == lot["id"])["quantite_actuelle"] == 0


def test_division_excessive_refusee(ferme):
    G = ferme["api"]["gerant"]
    lot = _recolte(ferme, 5)
    r = G.post(f"/lots/{lot['id']}/division", {"emplacement_source_id": ferme["emplacement"]["id"], "parts": [{"quantite": 6, "unite": "t"}]})
    assert r.status_code == 422 and r.json()["code"] == "quantite_lien_excessive"


def test_lien_cyclique_refuse(ferme, db):
    from app.core.securite import Contexte
    from app.modules.identite.models import Utilisateur
    from app.modules.stocks.models import LotStock
    from app.modules.tracabilite.service import creer_lien
    from sqlalchemy import select

    G = ferme["api"]["gerant"]
    lot = _recolte(ferme, 10)
    enfant = G.ok("post", f"/lots/{lot['id']}/division", {"emplacement_source_id": ferme["emplacement"]["id"], "parts": [{"quantite": 5, "unite": "t"}]})[0]
    u = db.scalar(select(Utilisateur).where(Utilisateur.courriel == ferme["api"]["_courriels"]["gerant"]))
    ctx = Contexte(db, u, ferme["api"]["_id"], "gerant", set())
    with pytest.raises(ErreurMetier) as e:
        creer_lien(ctx, db.get(LotStock, uuid.UUID(enfant["id"])), db.get(LotStock, uuid.UUID(lot["id"])), "regroupement", 1, "t")
    assert e.value.code == "lien_cycle"


def test_expedition_partielle_tracee_jusqua_parcelle(ferme):
    G = ferme["api"]["gerant"]
    lot = _recolte(ferme, 40)
    cl = G.ok("post", "/clients", {"nom": "Client test"})
    cc = G.ok("post", "/commandes-clients", {"client_id": cl["id"], "date_commande": "2026-10-01",
                                            "lignes": [{"article_id": ferme["recolte"]["id"], "quantite": 30, "unite": "t", "prix_unitaire_eur": 200}]})
    r = G.post(f"/commandes-clients/{cc['id']}/allocations", {"lignes": [{"ligne_id": cc["lignes"][0]["id"], "lot_id": lot["id"], "emplacement_id": ferme["emplacement"]["id"], "quantite": 30}]})
    assert r.status_code == 409 and "apte à la vente" in r.json()["message"]
    G.ok("post", f"/lots/{lot['id']}/decision-vente", {"apte_vente": True, "motif": "ok"})
    cc = G.ok("post", f"/commandes-clients/{cc['id']}/allocations", {"lignes": [{"ligne_id": cc["lignes"][0]["id"], "lot_id": lot["id"], "emplacement_id": ferme["emplacement"]["id"], "quantite": 30}]})
    al = cc["lignes"][0]["allocations"][0]
    ex = G.ok("post", f"/commandes-clients/{cc['id']}/expeditions", {"lignes": [{"allocation_id": al["id"], "quantite": 12}]})
    assert ex["statut_commande"] == "partiellement_expediee"
    assert G.post(f"/commandes-clients/{cc['id']}/expeditions", {"lignes": [{"allocation_id": al["id"], "quantite": 19}]}).status_code == 422
    st = next(x for x in G.ok("get", "/stocks")["articles"] if x["code"] == "REC")
    assert (st["physique"], st["reserve"], st["disponible"]) == (28, 18, 10)
    t = G.ok("get", f"/tracabilite/expeditions/{ex['id']}")
    assert t["lots"][0]["parcelles_origine"][0]["code"] == "T01"
    f = G.ok("post", f"/commandes-clients/{cc['id']}/factures", {"date_facture": "2026-10-05", "taux_tva_pct": 5.5})
    assert f["montant_ht_eur"] == 2400.0 and f["montant_ttc_eur"] == 2532.0
