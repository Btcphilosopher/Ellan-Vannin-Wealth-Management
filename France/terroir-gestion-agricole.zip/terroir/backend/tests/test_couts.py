"""Coûts : valeurs attendues calculées à la main."""
from tests.conftest import entree_stock


def test_ventilation_couts_et_allocation(ferme, db):
    from datetime import date

    from app.modules.analyses.models import ChargeIndirecte, RegleAllocation

    G, CH = ferme["api"]["gerant"], ferme["api"]["chef_culture"]
    f = ferme
    # Deuxième cycle pour l'allocation (surface 30 ha contre 10 ha)
    p2 = G.ok("post", "/parcelles", {"site_id": f["site"]["id"], "code": "T09", "nom": "Grande"})
    c2 = G.ok("post", "/cycles", {"campagne_id": f["campagne"]["id"], "parcelle_id": p2["id"], "culture": "Orge", "surface_prevue_ha": 30})
    # Prix versionné : 0,40 €/kg jusqu'au 31/01, 0,50 €/kg ensuite (lot sans coût d'achat)
    G.ok("post", "/prix", {"article_id": f["engrais"]["id"], "nature": "achat", "prix_unitaire_eur": 400, "unite": "t", "valide_du": "2025-09-01"})
    G.ok("post", "/prix", {"article_id": f["engrais"]["id"], "nature": "achat", "prix_unitaire_eur": 0.5, "unite": "kg", "valide_du": "2026-02-01"})
    entree_stock(G, f["engrais"], f["emplacement"], 1000)
    G.ok("post", "/tarifs", {"ressource_type": "membre", "ressource_id": f["membre"]["id"], "cout_horaire_eur": 20, "valide_du": "2025-01-01"})
    G.ok("post", "/tarifs", {"ressource_type": "materiel", "ressource_id": f["materiel"]["id"], "cout_horaire_eur": 30, "valide_du": "2025-01-01"})
    it = CH.ok("post", "/interventions", {"parcelle_id": f["parcelle"]["id"], "cycle_id": f["cycle"]["id"], "type": "fertilisation", "date_prevue": "2026-01-15",
                                          "produits": [{"article_id": f["engrais"]["id"], "quantite_prevue": 100, "unite_quantite": "kg"}]})
    CH.ok("post", f"/interventions/{it['id']}/affectations", {"ressource_type": "materiel", "ressource_id": f["materiel"]["id"],
                                                              "debut": "2026-01-15T08:00:00+01:00", "fin": "2026-01-15T11:00:00+01:00"})
    CH.ok("post", f"/interventions/{it['id']}/realisation", {"debut_reel": "2026-01-15T08:00:00+01:00", "fin_reelle": "2026-01-15T11:00:00+01:00",
                                                            "produits": [{"intervention_produit_id": it["produits"][0]["id"], "quantite_mesuree": 100}],
                                                            "temps": [{"membre_id": f["membre"]["id"], "heures": 2}]})
    regle = RegleAllocation(exploitation_id=f["api"]["_id"], libelle="Prorata surface", cle="surface", description="test", valide_du=date(2025, 9, 1))
    db.add(regle)
    db.flush()
    db.add(ChargeIndirecte(exploitation_id=f["api"]["_id"], campagne_id=f["campagne"]["id"], libelle="Structure", montant_eur=4000, regle_id=regle.id))
    db.commit()
    a = ferme["api"]["comptable"].ok("get", "/analyses/couts", campagne_id=f["campagne"]["id"])
    c = next(x for x in a["cycles"] if x["cycle_id"] == f["cycle"]["id"])
    assert c["charges"]["intrants"] == 40.0       # 100 kg × 0,40 €/kg (prix en vigueur le 15/01)
    assert c["charges"]["main_oeuvre"] == 40.0    # 2 h × 20 €
    assert c["charges"]["materiel"] == 90.0       # 3 h × 30 €
    assert c["charges"]["indirectes"] == 1000.0   # 4 000 € × 10/40 ha
    assert next(x for x in a["cycles"] if x["cycle_id"] == c2["id"])["charges"]["indirectes"] == 3000.0
    assert c["marge_brute_eur"] == -40.0 and c["resultat_apres_allocation_eur"] == -1170.0
    assert c["cout_supplementaire"]["par_ha_eur"] == 17.0  # (40 + 40 + 90) / 10 ha
    assert "v1" in c["details"]["intrants"][0]["source_prix"]
    # Correction d'une consommation : le coût suit
    mv = next(m for m in G.ok("get", "/mouvements") if m["type"] == "consommation")
    G.ok("post", f"/mouvements/{mv['id']}/correction", {"quantite_correcte": 80, "motif": "Pesée corrigée"})
    a2 = G.ok("get", "/analyses/couts", campagne_id=f["campagne"]["id"])
    assert next(x for x in a2["cycles"] if x["cycle_id"] == f["cycle"]["id"])["charges"]["intrants"] == 32.0


def test_prix_manquant_signale(ferme):
    G, CH = ferme["api"]["gerant"], ferme["api"]["chef_culture"]
    entree_stock(G, ferme["engrais"], ferme["emplacement"], 100)
    it = CH.ok("post", "/interventions", {"parcelle_id": ferme["parcelle"]["id"], "cycle_id": ferme["cycle"]["id"], "type": "fertilisation", "date_prevue": "2026-01-15",
                                          "produits": [{"article_id": ferme["engrais"]["id"], "quantite_prevue": 10, "unite_quantite": "kg"}]})
    CH.ok("post", f"/interventions/{it['id']}/realisation", {"debut_reel": "2026-01-15T08:00:00+01:00", "fin_reelle": "2026-01-15T09:00:00+01:00",
                                                            "produits": [{"intervention_produit_id": it["produits"][0]["id"], "quantite_mesuree": 10}]})
    a = G.ok("get", "/analyses/couts", campagne_id=ferme["campagne"]["id"])
    assert any("Prix manquant" in m for m in a["donnees_manquantes"])
    assert a["cycles"][0]["charges"]["intrants"] == 0.0


def test_irrigation_hypotheses_et_donnees_manquantes(ferme):
    G = ferme["api"]["gerant"]
    G.ok("post", "/equipements-irrigation", {"parcelle_id": ferme["parcelle"]["id"], "nom": "Goutte-à-goutte", "type": "goutte_a_goutte", "efficience_pct": 90})
    for j, et0, pluie in [("2026-07-01", 5.0, 0), ("2026-07-02", 6.0, 10)]:
        G.ok("post", "/meteo", {"site_id": ferme["site"]["id"], "nature": "observee", "source": "Station de test", "pour_date": j, "et0_mm": et0, "pluie_mm": pluie})
    r = G.ok("post", "/irrigation/calcul", {"parcelle_id": ferme["parcelle"]["id"], "kc": 1.0, "source_kc": "test", "du": "2026-07-01", "au": "2026-07-03"})
    assert r["calcul_possible"] is False and "03/07/2026" in r["donnees_manquantes"][0]
    r = G.ok("post", "/irrigation/calcul", {"parcelle_id": ferme["parcelle"]["id"], "kc": 1.0, "source_kc": "test", "du": "2026-07-01", "au": "2026-07-02",
                                           "coefficient_pluie_efficace": 0.8})
    # ETc 11 mm − pluie efficace 8 mm = 3 mm net ; / 0,9 = 3,3 mm brut ; × 10 × 10 ha ≈ 333 m³
    assert (r["besoin_net_mm"], r["dose_brute_mm"]) == (3.0, 3.3) and abs(r["volume_m3"] - 333) <= 1
    assert r["consultatif"] and r["hypotheses"]["systeme"]["efficience_pct"] == 90
