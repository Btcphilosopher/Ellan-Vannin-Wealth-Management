#!/usr/bin/env bash
# Recrée la base locale, applique les migrations et lance la démonstration.
set -euo pipefail
cd "$(dirname "$0")/../backend"
psql "${PG_URL:-postgresql://terroir:terroir@localhost}/postgres" -q -c "DROP DATABASE IF EXISTS terroir" -c "CREATE DATABASE terroir"
alembic upgrade head
python -m app.seed.demo --sortie "${SORTIE:-../demo_sortie}"
