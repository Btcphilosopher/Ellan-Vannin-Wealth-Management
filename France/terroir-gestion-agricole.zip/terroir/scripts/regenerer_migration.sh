#!/usr/bin/env bash
# Outil de développement : régénère la migration initiale à partir des modèles
# (à n'utiliser qu'avant la première mise en production).
set -euo pipefail
cd "$(dirname "$0")/../backend"
rm -f alembic/versions/0001_schema_initial.py
PG="${PG_URL:-postgresql://terroir:terroir@localhost}"
psql "$PG/postgres" -q -c "DROP DATABASE IF EXISTS terroir_gen" -c "CREATE DATABASE terroir_gen"
psql "$PG/terroir_gen" -q -c "CREATE EXTENSION postgis"
TERROIR_DATABASE_URL=postgresql+psycopg://terroir:terroir@localhost/terroir_gen alembic revision --autogenerate -m "schema initial" --rev-id 0001 >/dev/null
python - <<'PY'
p = "alembic/versions/0001_schema_initial.py"
s = open(p).read()
s = s.replace("def upgrade():\n", "def upgrade():\n    op.execute('CREATE EXTENSION IF NOT EXISTS postgis')\n    op.execute('CREATE EXTENSION IF NOT EXISTS btree_gist')\n", 1)
i = s.index("def downgrade():")
add = '''    # Interdit deux affectations actives qui se chevauchent pour une même ressource
    op.execute("""ALTER TABLE affectation ADD CONSTRAINT ex_affectation_chevauchement
        EXCLUDE USING gist (ressource_id WITH =, tstzrange(debut, fin) WITH &&) WHERE (active)""")
    # Journal des mouvements immuable : seules les insertions sont permises
    op.execute("""CREATE OR REPLACE FUNCTION terroir_mouvement_immuable() RETURNS trigger AS $$
        BEGIN RAISE EXCEPTION 'Le journal des mouvements est immuable : enregistrez une correction.'; END; $$ LANGUAGE plpgsql""")
    op.execute("""CREATE TRIGGER tr_mouvement_immuable BEFORE UPDATE OR DELETE ON mouvement_stock
        FOR EACH ROW EXECUTE FUNCTION terroir_mouvement_immuable()""")


'''
s = s[:i].rstrip() + "\n\n" + add + s[i:]
s = s.replace("def downgrade():\n", "def downgrade():\n    op.execute('DROP TRIGGER IF EXISTS tr_mouvement_immuable ON mouvement_stock')\n    op.execute('DROP FUNCTION IF EXISTS terroir_mouvement_immuable()')\n    op.execute('ALTER TABLE affectation DROP CONSTRAINT IF EXISTS ex_affectation_chevauchement')\n", 1)
open(p, "w").write(s)
PY
echo "Migration régénérée."
