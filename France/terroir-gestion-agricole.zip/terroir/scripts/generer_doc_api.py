"""Génère docs/openapi.json et docs/API.md à partir de l'application FastAPI."""
import json
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RACINE / "backend"))

from app.main import app  # noqa: E402

spec = app.openapi()
(RACINE / "docs" / "openapi.json").write_text(json.dumps(spec, ensure_ascii=False, indent=1), encoding="utf-8")
lignes = ["# Documentation de l'API Terroir", "",
          f"Version {spec['info']['version']} — {len(spec['paths'])} chemins. Générée depuis l'OpenAPI (`scripts/generer_doc_api.py`).",
          "Documentation interactive : `http://localhost:8000/api/docs` (Swagger) ou `/api/redoc`.", "",
          spec["info"]["description"].strip(), ""]
par_tag = {}
for chemin, ops in spec["paths"].items():
    for methode, op in ops.items():
        tag = (op.get("tags") or ["Autres"])[0]
        corps = ""
        rb = op.get("requestBody", {}).get("content", {})
        if "application/json" in rb:
            ref = rb["application/json"]["schema"].get("$ref", "")
            corps = ref.rsplit("/", 1)[-1]
        elif "multipart/form-data" in rb:
            corps = "multipart"
        par_tag.setdefault(tag, []).append((methode.upper(), chemin.replace("/api/v1/exploitations/{exploitation_id}", "…"), corps,
                                            (op.get("description") or op.get("summary") or "").split("\n")[0]))
for tag, ops in par_tag.items():
    lignes += [f"## {tag}", "", "| Méthode | Chemin | Corps | Description |", "|---|---|---|---|"]
    for m, c, b, d in ops:
        lignes.append(f"| {m} | `{c}` | {b} | {d} |")
    lignes.append("")
lignes += ["## Schémas d'entrée", "", "Les champs inconnus sont refusés (`extra = forbid`).", ""]
for nom, sch in sorted(spec["components"]["schemas"].items()):
    if nom.startswith(("HTTPValidationError", "ValidationError")) or "properties" not in sch:
        continue
    req = set(sch.get("required", []))
    champs = ", ".join(f"`{k}`{'*' if k in req else ''}" for k in sch["properties"])
    lignes.append(f"- **{nom}** : {champs}")
lignes += ["", "`*` : champ obligatoire. `…` = `/api/v1/exploitations/{exploitation_id}`."]
(RACINE / "docs" / "API.md").write_text("\n".join(lignes) + "\n", encoding="utf-8")
print(f"{len(spec['paths'])} chemins documentés")
