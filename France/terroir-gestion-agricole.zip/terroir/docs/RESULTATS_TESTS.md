# Résultats réellement obtenus

Exécutions du 28/11/2026 dans l'environnement de développement (Linux, Python 3.13, Node 22, PostgreSQL 16 + PostGIS 3.4
sur l'hôte ; PostGIS 3.5 dans Docker).

## Synthèse

| Vérification | Environnement | Résultat |
|---|---|---|
| Tests backend `pytest` (51 tests) | hôte | **51 réussis**, 0 échec (≈ 2 min 13 s) |
| Tests backend `pytest` | conteneur `api` (Docker Compose) | **50 réussis** ; le test de restauration a été exclu car l'image de test du bac à sable n'a pas `pg_dump` (voir « Écarts ») |
| Migration Alembic montée / descente / remontée | hôte | réussie ; la migration est rejouée sur une base vierge à chaque session de tests |
| Démonstration « Ferme des Trois Vallées » | hôte | **38/38 vérifications** |
| Démonstration | Docker Compose (stockage S3 SeaweedFS) | **38/38 vérifications** |
| `tsc --noEmit` (interface) | hôte | 0 erreur |
| `next build` (Next.js 16.4.6) | hôte et image Docker | réussi |
| Parcours Playwright de l'interface | hôte (API + `next` standalone) | **45/45 vérifications** |
| Parcours Playwright de l'interface | pile Docker Compose complète (db, stockage, api, worker, web) | **45/45 vérifications** |
| Stockage objet S3 (SeaweedFS 4.55) | Docker | écriture/lecture OK ; identifiants invalides refusés (`InvalidAccessKeyId`) ; lecture anonyme refusée (403) ; port S3 non exposé sur l'hôte |

## Tests backend par domaine

| Fichier | Tests |
|---|---|
| `test_couts.py` | test_ventilation_couts_et_allocation, test_prix_manquant_signale, test_irrigation_hypotheses_et_donnees_manquantes |
| `test_demo.py` | test_demonstration_complete |
| `test_geometrie.py` | test_carre_lambert93_un_hectare, test_polygone_auto_intersecte_refuse, test_srid_non_pris_en_charge_et_type, test_systeme_mal_declare_detecte, test_ecart_surface_signale_sans_ecraser, test_api_parcelle_surface_postgis_et_provenance, test_chevauchement_et_zone_hors_parcelle, test_verrouillage_optimiste_parcelle |
| `test_permissions.py` | test_role_operateur_restreint, test_veterinaire_limite_a_l_elevage, test_cloisonnement_entre_exploitations, test_csrf_et_session_cookie, test_blocage_apres_echecs, test_mot_de_passe_jamais_expose, test_journal_audit, test_documents_valides_et_proteges |
| `test_planning.py` | test_chevauchement_refuse_et_adjacence_acceptee, test_maintenance_et_defaut_bloquant, test_competence_requise, test_contrainte_exclusion_postgresql, test_validation_phyto_requise_et_verification, test_compte_rendu_exige_quantite_mesuree |
| `test_sauvegarde.py` | test_sauvegarde_restauration, test_export_donnees |
| `test_stocks.py` | test_quantites_physique_bloque_reserve_disponible_attendu, test_correction_liee_et_journal_immuable, test_conversion_unite_saisie, test_reservations_concurrentes, test_consommation_respecte_reservations_et_fefo, test_observation_stockage_ne_libere_pas |
| `test_sync.py` | test_envoi_idempotent_et_horodatage_terrain, test_photo_validee, test_conflit_detecte_puis_resolu, test_compte_rendu_en_attente_jusqua_validation, test_donnees_hors_connexion_perimetre |
| `test_tracabilite.py` | test_recolte_rattachee_et_non_apte, test_division_regroupement_conservent_les_liens, test_division_excessive_refusee, test_lien_cyclique_refuse, test_expedition_partielle_tracee_jusqua_parcelle |
| `test_unites.py` | test_conversions_masse_volume_surface, test_conversion_incompatible_refusee, test_unite_inconnue, test_dose_par_hectare_vers_quantite, test_doses_comparables, test_lame_eau, test_formats_francais |

Points couverts explicitement demandés : unités (`test_unites`), géométries (`test_geometrie`), réservations concurrentes
(`test_stocks::test_reservations_concurrentes` : deux fils, une seule réservation acceptée), liens entre lots
(`test_tracabilite`), conflits de planning (`test_planning`, y compris la contrainte d'exclusion PostgreSQL),
permissions (`test_permissions`), synchronisation (`test_sync`), coûts (`test_couts`, valeurs calculées à la main),
restauration (`test_sauvegarde::test_sauvegarde_restauration` : restauration dans une base vierge, comptages identiques,
PostGIS, déclencheur et contrainte présents).

## Parcours de l'interface (Playwright, `frontend/tests/e2e.cjs`)

- ✅  Tableau de bord affiché avec les alertes
- ✅  Alertes avec libellé texte (pas uniquement une couleur)
- ✅  Page /parcelles chargée (« Parcelles »)
- ✅  Carte : parcelles tracées en SVG
- ✅  Carte : légende textuelle des hachures d'écart
- ✅  Page /cultures chargée (« Cultures »)
- ✅  Rotations : règle non validée signalée
- ✅  Rotations : avertissement « pas une preuve de santé du sol »
- ✅  Page /elevage chargée (« Élevage »)
- ✅  Élevage : déclarations sans transmission officielle
- ✅  Page /travaux chargée (« Travaux »)
- ✅  Page /materiel chargée (« Matériel »)
- ✅  Page /stocks chargée (« Stocks »)
- ✅  Stocks : journal des mouvements affiché
- ✅  Page /achats chargée (« Achats »)
- ✅  Page /ventes chargée (« Ventes »)
- ✅  Page /equipe chargée (« Équipe »)
- ✅  Page /documents chargée (« Documents »)
- ✅  Page /analyses chargée (« Analyses »)
- ✅  Analyses : marges affichées
- ✅  Page /parametres chargée (« Paramètres »)
- ✅  Paramètres : export complet proposé à la gérante
- ✅  Intervention : contrôles non couverts listés
- ✅  Intervention : source réglementaire signalée non officielle
- ✅  Intervention : prévu / consigne / mesuré distincts
- ✅  Intervention : météo manquante affichée « indisponible »
- ✅  Traçabilité : lot BT-2026-P01 relié à la parcelle
- ✅  Rapport PDF de traçabilité téléchargeable
- ✅  Traçabilité : regroupement incomplet signalé
- ✅  Parcelle : écart signalé sans écrasement
- ✅  Matériel : TR-02 indisponible avec motif
- ✅  Affectation refusée : message de conflit (matériel indisponible) affiché
- ✅  Opératrice : onglet Utilisateurs masqué
- ✅  Opératrice : journal d'audit masqué
- ✅  Opératrice : export complet verrouillé
- ✅  Opératrice : création de parcelle verrouillée (🔒)
- ✅  Service worker actif sur /terrain
- ✅  Bandeau hors connexion affiché
- ✅  Rechargement de /terrain hors connexion (cache du service worker + IndexedDB)
- ✅  Saisie hors connexion en file IndexedDB « En attente » (observation, photo)
- ✅  Libellé « En attente » et heure de saisie affichés
- ✅  Après synchronisation : 2 élément(s) « Accepté »
- ✅  Observation présente côté serveur (origine terrain)
- ✅  Photo déposée dans le stockage protégé
- ✅  Aucune erreur console ni requête en échec (0)

Le test échoue sur toute erreur console, toute requête en échec ou toute réponse HTTP ≥ 400, sauf la réponse 409
provoquée volontairement et les erreurs réseau pendant la phase hors connexion.

## Écarts et limites des vérifications

- **Images Docker construites avec une variante de bac à sable** : l'environnement de développement impose un proxy HTTPS
  et bloque `deb.debian.org`. Les images de test ont été construites avec une copie des Dockerfiles ajoutant le certificat
  du proxy et **omettant l'installation apt de `postgresql-client`** dans l'image backend. Les Dockerfiles livrés n'ont pas
  été construits tels quels ici ; seule cette ligne apt n'a pas été exécutée. Conséquence : le service `sauvegarde` de
  Compose n'a pas été exécuté dans Docker ; la sauvegarde/restauration a été testée sur l'hôte.
- Les captures d'écran (`docs/captures/`) proviennent du parcours sur l'hôte.
- Aucun test de charge ni audit d'accessibilité outillé (contrastes vérifiés visuellement, états toujours libellés).
