# Documentation de l'API Terroir

Version 0.1.0 — 125 chemins. Générée depuis l'OpenAPI (`scripts/generer_doc_api.py`).
Documentation interactive : `http://localhost:8000/api/docs` (Swagger) ou `/api/redoc`.

API de **Terroir — Gestion agricole**.

Toutes les routes métier sont cloisonnées par exploitation :
`/api/v1/exploitations/{exploitation_id}/…`. L'authentification se fait par
session (cookie `terroir_session`, httpOnly) ou par jeton `Authorization: Bearer`.
Les requêtes qui modifient des données envoyées avec le cookie doivent porter
l'en-tête `X-Terroir-Requete: 1` (protection CSRF).

Les erreurs fonctionnelles ont la forme `{"code", "message", "parametres"}`,
avec un message en français.

## Identité, sécurité, administration

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| POST | `/api/v1/auth/connexion` | Connexion | Connexion |
| POST | `/api/v1/auth/deconnexion` |  | Deconnexion |
| GET | `/api/v1/auth/moi` |  | Moi |
| GET | `/api/v1/roles` |  | Roles |
| GET | `…` |  | Lire Exploitation |
| PUT | `…/modules` | ModulesEntree | Modifier Modules |
| GET | `…/utilisateurs` |  | Lister Utilisateurs |
| POST | `…/utilisateurs` | UtilisateurEntree | Creer Utilisateur |
| GET | `…/audit` |  | Journal Audit |
| GET | `…/export-donnees` |  | Exporter Donnees |
| GET | `…/taches` |  | Lister Taches |
| POST | `…/taches/{type_tache}` |  | Lancer Tache |

## Foncier : sites, parcelles, zones

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/sites` |  | Lister Sites |
| POST | `…/sites` | SiteEntree | Creer Site |
| GET | `…/parcelles` |  | Lister Parcelles |
| POST | `…/parcelles` | ParcelleEntree | Creer Parcelle |
| GET | `…/parcelles/{parcelle_id}` |  | Detail Parcelle |
| PATCH | `…/parcelles/{parcelle_id}` | ParcelleMaj | Modifier Parcelle |
| PUT | `…/parcelles/{parcelle_id}/geometrie` | GeometrieEntree | Remplacer Geometrie |
| POST | `…/parcelles/{parcelle_id}/cadastre` | CadastreEntree | Ajouter Reference Cadastrale |
| POST | `…/parcelles/{parcelle_id}/zones` | ZoneEntree | Creer Zone |
| GET | `…/equipements-irrigation` |  | Lister Equipements |
| POST | `…/equipements-irrigation` | EquipementEntree | Creer Equipement |
| GET | `…/carte` |  | FeatureCollection des parcelles (WGS 84) avec la culture de la campagne. |

## Cultures : campagnes, cycles, rotations, besoins

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/campagnes` |  | Lister Campagnes |
| POST | `…/campagnes` | CampagneEntree | Creer Campagne |
| GET | `…/cycles` |  | Lister Cycles |
| POST | `…/cycles` | CycleEntree | Creer Cycle |
| GET | `…/cycles/{cycle_id}` |  | Lire Cycle |
| PATCH | `…/cycles/{cycle_id}` | CycleMaj | Modifier Cycle |
| GET | `…/rotations` |  | Rotations |
| GET | `…/regles-rotation` |  | Lister Regles |
| POST | `…/regles-rotation` | RegleEntree | Creer Regle |
| POST | `…/regles-rotation/{regle_id}/validation` | ValidationRegle | Valider Regle |
| GET | `…/itineraires` |  | Lister Itineraires |
| POST | `…/itineraires` | ItineraireEntree | Creer Itineraire |
| POST | `…/cycles/{cycle_id}/itineraire/{itineraire_id}` |  | Génère les interventions planifiées d'un cycle à partir d'un itinéraire saisi. |
| GET | `…/campagnes/{campagne_id}/besoins` |  | Besoins |

## Travaux : interventions et planning

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/interventions` |  | Lister |
| POST | `…/interventions` | InterventionEntree | Creer |
| GET | `…/interventions/{intervention_id}` |  | Lire |
| POST | `…/interventions/{intervention_id}/produits` | ProduitEntree | Ajouter Produit |
| POST | `…/interventions/{intervention_id}/reservations` |  | Réserve chaque produit prévu. Les ruptures sont listées sans bloquer les autres lignes. |
| GET | `…/planning/conflits` |  | Verifier Conflits |
| POST | `…/interventions/{intervention_id}/affectations` | AffectationEntree | Affecter |
| DELETE | `…/affectations/{affectation_id}` |  | Retirer Affectation |
| POST | `…/interventions/{intervention_id}/verification` |  | Verification |
| POST | `…/interventions/{intervention_id}/validation-professionnelle` | ValidationEntree | Valider |
| POST | `…/interventions/{intervention_id}/demarrage` |  | Demarrer |
| POST | `…/interventions/{intervention_id}/realisation` | CompteRendu | Realiser |
| POST | `…/interventions/{intervention_id}/annulation` |  | Annuler |
| GET | `…/planning` |  | Vue planning : interventions, affectations et restrictions de maintenance. |

## Stocks et stockage

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/articles` |  | Lister Articles |
| POST | `…/articles` | ArticleEntree | Creer Article |
| GET | `…/emplacements` |  | Lister Emplacements |
| POST | `…/emplacements` | EmplacementEntree | Creer Emplacement |
| GET | `…/stocks` |  | Etat Stocks |
| GET | `…/lots` |  | Lister Lots |
| GET | `…/mouvements` |  | Journal |
| POST | `…/stocks/entrees` | EntreeDirecte | Entree Directe |
| POST | `…/stocks/consommations` | Sortie | Consommation |
| POST | `…/stocks/pertes` | Sortie | Perte |
| POST | `…/stocks/transferts` | Transfert | Transfert |
| POST | `…/mouvements/{mouvement_id}/correction` | Correction | Correction |
| GET | `…/reservations` |  | Lister Reservations |
| POST | `…/reservations` | ReservationEntree | Creer Reservation |
| POST | `…/reservations/{reservation_id}/annulation` |  | Annuler |
| POST | `…/lots/{lot_id}/statut` | StatutLot | Changer Statut Lot |
| POST | `…/lots/{lot_id}/decision-vente` | DecisionVente | Décision humaine explicite : les relevés de conservation ne suffisent jamais. |
| GET | `…/observations-stockage` |  | Lister Observations |
| POST | `…/observations-stockage` | app__modules__stocks__router__ObservationEntree | Creer Observation |

## Récoltes et traçabilité

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| POST | `…/recoltes` | RecolteEntree | Recolter |
| POST | `…/lots/{lot_id}/division` | DivisionEntree | Diviser |
| POST | `…/lots/regroupement` | RegroupementEntree | Regrouper |
| POST | `…/lots/{lot_id}/conditionnement` | ConditionnementEntree | Conditionner |
| GET | `…/tracabilite/lots/{lot_id}` |  | Tracabilite Lot |
| GET | `…/tracabilite/parcelles/{parcelle_id}` |  | Tracabilite Parcelle |
| GET | `…/tracabilite/expeditions/{expedition_id}` |  | Tracabilite Expedition |

## Achats et ventes

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/fournisseurs` |  | Lister Fournisseurs |
| POST | `…/fournisseurs` | TiersEntree | Creer Fournisseur |
| GET | `…/clients` |  | Lister Clients |
| POST | `…/clients` | TiersEntree | Creer Client |
| GET | `…/prix` |  | Lister Prix |
| POST | `…/prix` | PrixEntree | Creer Prix |
| GET | `…/demandes-achat` |  | Lister Demandes |
| POST | `…/demandes-achat` | DemandeEntree | Creer Demande |
| POST | `…/demandes-achat/{demande_id}/approbation` |  | Approuver Demande |
| GET | `…/commandes-fournisseurs` |  | Lister Commandes F |
| POST | `…/commandes-fournisseurs` | CommandeFEntree | Creer Commande F |
| POST | `…/commandes-fournisseurs/{commande_id}/receptions` | ReceptionEntree | Receptionner |
| GET | `…/factures-fournisseurs` |  | Lister Factures F |
| POST | `…/factures-fournisseurs` | FactureFEntree | Creer Facture F |
| GET | `…/commandes-clients` |  | Lister Commandes C |
| POST | `…/commandes-clients` | CommandeCEntree | Creer Commande C |
| GET | `…/commandes-clients/{commande_id}` |  | Lire Commande C |
| POST | `…/commandes-clients/{commande_id}/allocations` | AllocationEntree | Allouer |
| POST | `…/commandes-clients/{commande_id}/expeditions` | ExpeditionEntree | Expedier |
| POST | `…/commandes-clients/{commande_id}/factures` | FactureEntree | Facturer |
| POST | `…/factures/{facture_id}/paiements` | PaiementEntree | Payer |
| GET | `…/factures` |  | Lister Factures |

## Élevage

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/lots-animaux` |  | Lister Lots |
| POST | `…/lots-animaux` | LotAnimauxEntree | Creer Lot |
| POST | `…/lots-animaux/{lot_id}/localisation` | LocalisationEntree | Deplacer Lot |
| GET | `…/animaux` |  | Lister Animaux |
| POST | `…/animaux` | AnimalEntree | Creer Animal |
| POST | `…/evenements-elevage` | EvenementEntree | Creer Evenement |
| GET | `…/evenements-elevage` |  | Lister Evenements |
| POST | `…/traitements-animaux` | TraitementEntree | Saisir Traitement |
| GET | `…/animaux/{animal_id}/croissance` |  | GMQ entre pesées successives (calcul transparent). |
| GET | `…/declarations-a-preparer` |  | Declarations |

## Matériel

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/materiels` |  | Lister |
| POST | `…/materiels` | MaterielEntree | Creer |
| GET | `…/materiels/{materiel_id}` |  | Lire |
| POST | `…/materiels/{materiel_id}/maintenances` | MaintenanceEntree | Planifier Maintenance |
| POST | `…/maintenances/{maintenance_id}/realisation` |  | Realiser Maintenance |
| POST | `…/materiels/{materiel_id}/defauts` | DefautEntree | Signaler Defaut |
| POST | `…/defauts/{defaut_id}/resolution` |  | Resoudre Defaut |
| POST | `…/materiels/{materiel_id}/heures` | HeuresEntree | Saisir Heures |
| POST | `…/materiels/{materiel_id}/pleins` | PleinEntree | Faire Plein |

## Équipe

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/membres` |  | Lister Membres |
| POST | `…/membres` | MembreEntree | Creer Membre |
| POST | `…/membres/{membre_id}/competences` | CompetenceEntree | Ajouter Competence |
| GET | `…/temps-travail` |  | Lister Temps |
| POST | `…/temps-travail` | app__modules__equipe__router__TempsEntree | Saisir Temps |
| GET | `…/tarifs` |  | Lister Tarifs |
| POST | `…/tarifs` | TarifEntree | Creer Tarif |

## Documents et démarches

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/documents` |  | Lister |
| POST | `…/documents` | multipart | Deposer |
| GET | `…/documents/{document_id}/contenu` |  | Telecharger |
| GET | `…/echeances` |  | Echeances |
| GET | `…/dossiers` |  | Lister Dossiers |
| POST | `…/dossiers` | DossierEntree | Creer Dossier |
| GET | `…/dossiers/{dossier_id}/export` |  | Exporter Dossier |

## Observations, météo et irrigation

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/observations` |  | Lister Observations |
| POST | `…/observations` | app__modules__terrain__router__ObservationEntree | Observer |
| GET | `…/meteo` |  | Lister Meteo |
| POST | `…/meteo` | MeteoEntree | Saisir Meteo |
| POST | `…/meteo/import-simulateur` |  | Importer Meteo |
| GET | `…/irrigation/compteurs/{equipement_id}` |  | Volumes |
| POST | `…/irrigation/compteurs` | CompteurEntree | Relever Compteur |
| POST | `…/irrigation/humidite-sol` | HumiditeEntree | Mesurer Humidite |
| GET | `…/irrigation/humidite-sol` |  | Lister Humidite |
| POST | `…/irrigation/calcul` | CalculIrrigation | Calcul Irrigation |
| GET | `…/irrigation/programmes` |  | Lister Programmes |
| POST | `…/irrigation/programmes` | ProgrammeEntree | Creer Programme |

## Terrain : hors connexion et synchronisation

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| POST | `…/sync/envoi` | Lot | Envoyer |
| GET | `…/sync/donnees` |  | Sous-ensemble autorisé, mis en cache sur le terminal (lecture seule). |
| GET | `…/sync/operations` |  | Operations |
| POST | `…/sync/operations/{operation_id}/validation` |  | Applique un compte rendu terrain après validation serveur (stocks, temps, matériel). |
| GET | `…/sync/conflits` |  | Lister Conflits |
| POST | `…/sync/conflits/{conflit_id}/resolution` | Resolution | Resoudre |

## Analyses, prévisions, rapports

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `…/analyses/couts` |  | Analyse Couts |
| GET | `…/analyses/previsions` |  | Analyse Previsions |
| GET | `…/regles-allocation` |  | Regles |
| GET | `…/adaptateurs` |  | Adaptateurs |
| GET | `…/tableau-de-bord` |  | Tableau De Bord |
| GET | `…/rapports/tracabilite/{lot_id}` |  | Rapport Tracabilite |
| GET | `…/rapports/couts` |  | Rapport Couts |
| GET | `…/exports/comptable` |  | Export Comptable |

## Supervision

| Méthode | Chemin | Corps | Description |
|---|---|---|---|
| GET | `/api/sante` |  | Sante |

## Schémas d'entrée

Les champs inconnus sont refusés (`extra = forbid`).

- **AffectationEntree** : `ressource_type`*, `ressource_id`*, `debut`*, `fin`*, `role`
- **AllocationEntree** : `lignes`*
- **AllocationLigne** : `ligne_id`*, `lot_id`*, `emplacement_id`*, `quantite`*
- **AnimalEntree** : `identifiant`*, `nom_usage`, `espece`*, `race`, `sexe`*, `date_naissance`, `mere_id`, `origine`*, `date_entree`, `lot_animaux_id`
- **ArticleEntree** : `code`*, `libelle`*, `categorie`*, `unite_stock`*, `reglemente`, `produit_referentiel_id`, `numero_amm_saisi`, `fournisseur_habituel_id`, `seuil_alerte`, `culture`
- **Body_deposer_api_v1_exploitations__exploitation_id__documents_post** : `fichier`*, `categorie`*, `titre`*, `entite_type`, `entite_id`, `echeance`, `libelle_echeance`, `confidentiel`
- **CadastreEntree** : `code_insee`*, `prefixe`, `section`*, `numero`*, `surface_cadastrale_ha`, `surface_exploitee_ha`, `source`
- **CalculIrrigation** : `parcelle_id`*, `kc`*, `source_kc`*, `du`*, `au`*, `coefficient_pluie_efficace`, `equipement_id`, `surface_ha`
- **CampagneEntree** : `libelle`*, `date_debut`*, `date_fin`*, `statut`
- **CommandeCEntree** : `client_id`*, `date_commande`*, `date_livraison_souhaitee`, `lignes`*
- **CommandeFEntree** : `fournisseur_id`*, `demande_id`, `date_commande`*, `date_livraison_prevue`, `lignes`*
- **CompetenceEntree** : `type`*, `libelle`*, `reference`, `valide_du`, `valide_au`
- **CompteRendu** : `version`, `debut_reel`*, `fin_reelle`*, `surface_realisee_ha`, `produits`, `temps`, `heures_materiel`, `meteo_saisie`, `notes`
- **CompteurEntree** : `equipement_id`*, `horodatage`, `index_m3`*, `source`
- **ConditionnementEntree** : `emplacement_source_id`*, `quantite_source`*, `unite_source`*, `article_fini_id`*, `nombre_unites`*, `emplacement_destination_id`*, `emballage_article_id`, `emballages_par_unite`, `numero`
- **Connexion** : `courriel`*, `mot_de_passe`*
- **Correction** : `quantite_correcte`*, `motif`*
- **CycleEntree** : `campagne_id`*, `parcelle_id`*, `zone_id`, `module`, `culture`*, `famille_botanique`, `variete`, `surface_prevue_ha`*, `date_semis_prevue`, `date_recolte_debut_prevue`, `date_recolte_fin_prevue`, `rendement_previsionnel`, `unite_rendement`, `source_rendement_previsionnel`, `destination_prevue`, `notes`
- **CycleMaj** : `version`*, `variete`, `surface_prevue_ha`, `date_semis_prevue`, `date_recolte_debut_prevue`, `date_recolte_fin_prevue`, `rendement_previsionnel`, `source_rendement_previsionnel`, `destination_prevue`, `statut`, `notes`
- **DecisionVente** : `apte_vente`*, `motif`*
- **DefautEntree** : `gravite`*, `description`*, `constate_le`
- **DemandeEntree** : `motif`, `lignes`*, `origine`
- **DivisionEntree** : `emplacement_source_id`*, `parts`*, `type`
- **DossierEntree** : `titre`*, `type`*, `campagne_id`, `elements`, `notes`
- **EmplacementEntree** : `site_id`*, `code`*, `nom`*, `type`*, `capacite`, `unite_capacite`, `cout_stockage_eur_t_mois`, `source_cout_stockage`
- **EntreeDirecte** : `article_id`*, `emplacement_id`*, `quantite`*, `unite`*, `numero_lot_fournisseur`, `date_peremption`, `motif`, `cout_unitaire`
- **EquipementEntree** : `parcelle_id`, `nom`*, `type`*, `debit_nominal`, `unite_debit`, `efficience_pct`, `source_efficience`, `compteur_numero`, `point_prelevement`
- **EvenementEntree** : `type`*, `animal_id`, `lot_animaux_id`, `effectif_concerne`, `horodatage`, `valeurs`, `notes`
- **ExpeditionEntree** : `lignes`*, `transporteur`, `horodatage`, `notes`
- **ExpeditionLigne** : `allocation_id`*, `quantite`*
- **FactureEntree** : `date_facture`*, `taux_tva_pct`*
- **FactureFEntree** : `fournisseur_id`*, `commande_id`, `numero_fournisseur`*, `date_facture`*, `montant_ht_eur`*, `montant_tva_eur`, `categorie_charge`, `imputation_type`, `imputation_id`, `date_paiement`
- **GeometrieEntree** : `geojson`*, `srid`, `source`*, `methode`, `date_acquisition`, `precision_m`
- **HeuresEntree** : `heures_moteur`*, `horodatage`, `source`
- **HeuresMateriel** : `materiel_id`*, `heures_moteur_fin`*, `source`
- **HumiditeEntree** : `parcelle_id`*, `horodatage`, `profondeur_cm`*, `valeur`*, `unite`*, `capteur`, `source`
- **InterventionEntree** : `parcelle_id`*, `cycle_id`, `zone_id`, `type`*, `libelle`, `date_prevue`, `debut_prevu`, `fin_prevue`, `surface_prevue_ha`, `operateur_id`, `duree_prevue_h`, `competence_requise`, `notes`, `produits`
- **ItineraireEntree** : `libelle`*, `culture`*, `etapes`*, `source`, `redige_par`
- **LigneCommandeC** : `article_id`*, `quantite`*, `unite`*, `prix_unitaire_eur`*
- **LigneCommandeF** : `article_id`*, `quantite`*, `unite`*, `prix_unitaire_eur`
- **LigneDemande** : `article_id`*, `quantite`*, `unite`*, `date_besoin`
- **LigneReception** : `ligne_commande_id`*, `quantite`*, `unite`*, `emplacement_id`*, `numero_lot_fournisseur`, `date_peremption`
- **LocalisationEntree** : `parcelle_id`, `batiment`, `du`*
- **Lot** : `terminal_id`*, `operations`*
- **LotAnimauxEntree** : `code`*, `nom`*, `espece`*, `finalite`
- **MaintenanceEntree** : `type`*, `libelle`*, `immobilise_du`, `immobilise_au`, `echeance_heures`, `prestataire`, `cout_eur`
- **MaterielEntree** : `code`*, `libelle`*, `categorie`*, `marque`, `modele`, `annee`, `immatriculation`, `site_id`, `propriete`, `debit_chantier_ha_h`, `consommation_reference_l_h`, `source_telemetrie`
- **MembreEntree** : `prenom`*, `nom`*, `statut`*, `entreprise`, `fonction`, `telephone`
- **MeteoEntree** : `site_id`*, `nature`*, `source`*, `pour_date`*, `emis_le`, `temperature_min_c`, `temperature_max_c`, `pluie_mm`, `vent_moyen_kmh`, `rafales_kmh`, `humidite_relative_pct`, `et0_mm`
- **ModulesEntree** : `modules_actifs`*
- **OperationEntree** : `id`*, `type`*, `entite_id`, `version_base`, `saisi_le`*, `contenu`*
- **PaiementEntree** : `date_paiement`*, `montant_eur`*, `mode`*, `reference`
- **ParcelleEntree** : `site_id`*, `code`*, `nom`*, `surface_declaree_ha`, `source_surface_declaree`, `mode_faire_valoir`, `proprietaire`, `bail_echeance`, `acces`, `sol`, `restrictions`, `irrigable`, `notes`, `geometrie`
- **ParcelleMaj** : `version`*, `nom`, `surface_declaree_ha`, `source_surface_declaree`, `mode_faire_valoir`, `proprietaire`, `bail_echeance`, `acces`, `sol`, `restrictions`, `irrigable`, `notes`
- **Part** : `quantite`*, `unite`, `emplacement_id`, `classement`, `numero`, `perte`, `motif`
- **PleinEntree** : `litres`*, `article_carburant_id`*, `emplacement_id`, `heures_compteur`, `horodatage`, `intervention_id`
- **PrixEntree** : `article_id`*, `nature`*, `prix_unitaire_eur`*, `unite`*, `valide_du`*, `source`
- **ProduitEntree** : `article_id`*, `dose_prevue`, `unite_dose`, `quantite_prevue`, `unite_quantite`, `lot_id`, `emplacement_id`
- **ProduitRealise** : `intervention_produit_id`*, `quantite_mesuree`*, `methode_mesure`, `consigne_machine`, `unite_consigne`, `source_consigne`, `lot_id`
- **ProgrammeEntree** : `parcelle_id`*, `cycle_id`, `equipement_id`, `debut`*, `fin`*, `dose_mm`*, `frequence_jours`*, `hypotheses`, `notes`
- **ReceptionEntree** : `date_reception`, `bon_livraison`, `lignes`*, `reserves`
- **RecolteEntree** : `intervention_id`*, `article_id`*, `quantite`*, `unite`*, `emplacement_id`*, `date_recolte`*, `qualite_observee`, `variete`, `numero`, `statut`, `client_prevu`
- **RegleEntree** : `libelle`*, `type`*, `culture`, `famille`, `precedent`, `delai_min_campagnes`, `severite`, `source`
- **RegroupementEntree** : `sources`*, `emplacement_id`*, `numero`
- **ReservationEntree** : `article_id`*, `quantite`*, `unite`*, `pour_type`*, `pour_id`*, `lot_id`, `emplacement_id`, `date_besoin`
- **Resolution** : `resolution`*, `valeurs_fusion`
- **SiteEntree** : `nom`*, `commune`, `code_insee`, `fuseau_horaire`, `adresse`
- **Sortie** : `article_id`*, `quantite`*, `unite`*, `lot_id`, `emplacement_id`, `motif`
- **SourceRegroupement** : `lot_id`*, `emplacement_id`*, `quantite`*, `unite`
- **StatutLot** : `statut`*, `motif`*, `version`
- **TarifEntree** : `ressource_type`*, `ressource_id`*, `cout_horaire_eur`*, `valide_du`*, `source`
- **TiersEntree** : `nom`*, `type`, `contact`
- **TraitementEntree** : `animal_id`, `lot_animaux_id`, `effectif_concerne`, `horodatage`, `medicament`*, `numero_ordonnance`, `prescripteur`, `posologie_saisie`, `voie`, `numero_lot_medicament`, `delai_attente_viande_saisi`, `delai_attente_lait_saisi`, `date_fin_attente_saisie`, `notes`
- **Transfert** : `lot_id`*, `de_emplacement_id`*, `vers_emplacement_id`*, `quantite`*, `unite`*, `motif`
- **UtilisateurEntree** : `courriel`*, `nom_affiche`*, `mot_de_passe`*, `role`*, `membre_equipe_id`
- **ValidationEntree** : `decision`*, `qualification`*, `commentaire`
- **ValidationRegle** : `qualification`*
- **ZoneEntree** : `nom`*, `nature`, `motif`, `date_debut`, `date_fin`, `geometrie`*
- **app__modules__equipe__router__TempsEntree** : `membre_id`*, `date`*, `heures`*, `activite`*, `intervention_id`, `lot_animaux_id`, `cycle_id`, `notes`
- **app__modules__interventions__router__TempsEntree** : `membre_id`*, `heures`*
- **app__modules__stocks__router__ObservationEntree** : `emplacement_id`*, `lot_id`, `horodatage`, `temperature_c`, `humidite_relative_pct`, `humidite_produit_pct`, `qualite`, `source`
- **app__modules__terrain__router__ObservationEntree** : `id`, `parcelle_id`*, `cycle_id`, `observe_le`, `categorie`*, `stade`, `description`*, `intensite`, `photos`, `position`

`*` : champ obligatoire. `…` = `/api/v1/exploitations/{exploitation_id}`.
