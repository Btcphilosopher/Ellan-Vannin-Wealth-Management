# Résultats de la démonstration — Ferme des Trois Vallées

Exécutée le 28/11/2026 à 11:45 (heure de Paris).

Toutes les données sont fictives. Chaque étape appelle l'API réelle ; les incidents sont provoqués volontairement.


## Étape 1 — Création des sites et des parcelles

- 4 sites créés, dont un en La Réunion (fuseau Indian/Reunion) pour exercer les fuseaux propres à chaque site.
- 9 parcelles créées ; P01 calculée à 12,42 ha pour 12,1 ha déclarés.
- [OK] Écart de surface signalé sur P01 sans modification de la surface déclarée
- [OK] Systèmes de coordonnées d'origine conservés (EPSG:2154 et EPSG:4326)
- Références cadastrales (distinctes de la limite opérationnelle) et zone temporaire « Zone de ressuyage lent » (0,24 ha) ajoutées.
- [OK] Zone hors parcelle refusée : « La zone de gestion dépasse les limites de la parcelle. »
- Prix versionnés saisis (ex. ammonitrate v1 0,41 €/kg puis v2 0,46 €/kg au 01/02/2026).
- Référentiels créés : 4 fournisseurs, 3 clients, 8 emplacements, 15 articles, 6 membres d'équipe, 7 matériels, référentiel phytopharmaceutique FICTIF.
- Historique cultural 2022-2025 repris pour P01–P03 (rotations et rendements passés).
- [OK] 2 tâches d'import météo exécutées par le travailleur en arrière-plan
- Données météo absentes volontairement les 20/02/2026, 05/08/2026, 06/08/2026.

## Étape 2 — Planification de la campagne 2025-2026

- 6 cycles planifiés (grandes cultures, maraîchage, prairie, verger) ; itinéraire appliqué à P01 : INT-2025-0001, INT-2025-0002, INT-2026-0001, INT-2026-0002, INT-2026-0003.
- [OK] Rotation : P03 (orge sur orge) signalée, règle affichée « non validée par un professionnel »
- Indicateur de rotation : 93,3 % — Cet indicateur mesure uniquement le respect des règles de rotation saisies. Il ne constitue ni une mesure ni une preuve de la bonne santé du sol.

## Étape 3 — Calcul des besoins et rupture de stock

- Ammonitrate : besoin 1 863 kg, disponible 800 kg, manque 1 063 kg.
- [OK] Rupture de stock prévisionnelle détectée sur l'ammonitrate
- [OK] Réservation refusée faute de stock : « Stock disponible insuffisant pour « Ammonitrate 27 % » : 800 kg disponibles, 1 863,195 kg demandés. »
- [OK] Demande d'achat DA-2026-0001 → commande CF-2026-0001 : 1 200 kg « attendus » (physique 800 kg)

## Étape 4 — Réception des fournitures

- [OK] Réception LOT-2026-0010 enregistrée (lot fournisseur COOP-AMMO-26-118) ; commande soldée ; facture FV-2026-00871 référencée
- [OK] Réservation de l'ammonitrate désormais possible

## Étape 5 — Affectation du matériel et des personnes

- [OK] Double affectation refusée : « Tracteur 140 ch est déjà affecté(e) du 20/02/2026 08:00 au 20/02/2026 11:00 (INT-2026-0001). »
- [OK] Machine indisponible : « Pulvérisateur traîné 24 m est indisponible sur la période : maintenance « Contrôle périodique du pulvérisateur et remplacement des buses ». »
- [OK] Compétence contrôlée : « Thomas Petit ne dispose pas de la compétence requise valide : certiphyto. »
- Traitement fongicide replanifié au 14/04/2026, après l'immobilisation du pulvérisateur (07–12/04/2026), avec une opératrice titulaire du Certiphyto.
- [OK] Restriction de maintenance visible dans le planning d'avril

## Étape 6 — Enregistrement des interventions

- [OK] Météo manquante le 20/02/2026 : signalée « indisponible », sans valeur inventée
- [OK] Prévu 1 863 kg / consigne machine 150 kg/ha / mesuré 1 842 kg : trois valeurs distinctes conservées
- [OK] Démarrage du traitement bloqué tant qu'aucune validation professionnelle n'est enregistrée
- Vérification : 6 contrôles, 0 alerte(s), 0 non disponible(s), 6 contrôles déclarés non couverts. Source : Référentiel de démonstration Terroir (FICTIF).
- [OK] Contrôles couverts conformes à la source fictive ; source signalée comme non officielle
- [OK] Traitement enregistré ; l'avertissement « pas une preuve de conformité » accompagne le registre

## Étape 7 — Synchronisation d'une observation saisie hors connexion

- [OK] Observation et photo synchronisées ; un second envoi identique est sans effet (identifiants stables)
- [OK] Conflit de synchronisation détecté : « L'observation a été modifiée sur le serveur depuis votre dernière synchronisation. »
- Conflit résolu par fusion explicite (champs en conflit : description, intensite).
- [OK] Compte rendu terrain mis en attente : aucun stock consommé avant validation serveur
- [OK] Après validation par le chef de culture : stock de plants 4 000 → 450 kg

## Étape 8 — Création d'un lot récolté

- [OK] Lot BT-2026-P01 : 95,277 t (pont-bascule simulé), rattaché à P01, en attente de contrôle, non apte à la vente par défaut
- Classement du lot PDT-2026-P06 : PDT-2026-P06-A (Calibre 40-70 mm), PDT-2026-P06-B (Déclassé (transformation)) + 2 000 kg de pertes au tri.

## Étape 9 — Mise en stockage et surveillance

- [OK] Les relevés de conservation ne rendent pas le lot apte à la vente automatiquement
- [OK] Une opératrice ne peut pas déclarer un lot apte à la vente (permission stocks:liberer)
- La gérante libère le lot et le déclare apte à la vente, avec motif et horodatage (journal d'audit).
- [OK] Regroupement OR-2026-MELANGE : 2 parents conservés ; traçabilité déclarée incomplète (« Traçabilité incomplète : origine parcellaire inconnue pour LOT-2026-0011. »)

## Étape 10 — Expédition partielle

- [OK] Expédition EXP-2026-0001 : 30 t sur 60 t commandées (commande partiellement expédiée)
- Blé tendre : physique 65,277 t, réservé 30 t, disponible 35,277 t.
- Facture FAC-2026-0001 : 6 360,00 € HT (TVA saisie 5,5 %) ; paiement enregistré le 20/11/2026.
- Conditionnement de 2 000 kg en 200 sacs (PF-PDT10-2026-01, 200 sacs kraft consommés) ; expédition EXP-2026-0002 de 80 sacs sur 120.

## Étape 11 — Traçabilité jusqu'à la parcelle

- [OK] Expédition EXP-2026-0001 → lot BT-2026-P01 → stockage Cellule de stockage 1 → parcelle P01 (Les Grands Champs)
- [OK] Sacs PF-PDT10-2026-01 ← PDT-2026-P06-A ← PDT-2026-P06 ← parcelle P06 (conditionnement et classement conservés)

## Étape 12 — Activité d'élevage (démonstration ovine)

- [OK] Saisie d'un traitement refusée à une opératrice (personnes autorisées uniquement)
- [OK] Traitement saisi par la vétérinaire ; délai d'attente recopié, ni calculé ni vérifié par Terroir
- GMQ agneau DEMO-OV-1002 : 290 g/j (GMQ = (poids final − poids initial) / nombre de jours entre deux pesées individuelles.)
- [OK] 22 événements « à déclarer » listés pour préparation, sans transmission officielle

## Étape 13 — Analyse des coûts

- P01 blé : charges opérationnelles 3 146,02 €, produit 19 741,78 €, marge brute 16 595,77 € (1 336,07 €/ha), résultat après allocation 8 553,51 €.
- Coût supplémentaire estimé : 392,41 €/ha, 51,16 €/t — Charges variables observées rapportées à la surface ou au tonnage ; hors charges indirectes et fixes, capacité de matériel et de main-d'œuvre supposée disponible.
- Trésorerie sur la période de campagne (01/09/2025–31/08/2026) : encaissements 0,00 €, décaissements 655,20 € ; depuis le début de campagne jusqu'à aujourd'hui : encaissements 6 709,80 €, solde 6 054,60 €.
- [OK] Coûts ventilés par catégorie (intrants, main-d'œuvre, matériel, carburant, prestataires, charges indirectes)
- Données manquantes signalées : aucune (tous les prix et tarifs nécessaires sont saisis)
- Scénarios de rendement blé : Historique de l'exploitation (4 cycles) : minimum, médiane, maximum. → médian 7,75 t/ha.
- [OK] Calcul d'irrigation déclaré impossible faute d'ET0 les 05–06/08/2026 (pas de valeur par défaut)
- Irrigation P06 du 08 au 14/08/2026 (consultatif) : besoin net 30,2 mm, dose brute 40,3 mm, 726 m³ (efficience 75 %).

## Étape 14 — Export des rapports

- [OK] Rapport de traçabilité PDF (3732 octets), CSV de traçabilité, CSV des coûts et export de gestion comptable écrits dans /tmp/claude-0/demo_sortie

## Étape 15 — Campagne 2026-2027 en préparation

- [OK] Tableau de bord : matériel indisponible (TR-02, défaut bloquant) et rupture prévisionnelle d'ammonitrate pour 2026-2027
- [OK] Blé sur blé en P01 (2026-2027) signalé par une règle validée par la conseillère
- Journal d'audit : 265 entrées enregistrées pendant la démonstration.

## Synthèse des vérifications

38 / 38 vérifications réussies.

- ✅ Écart de surface signalé sur P01 sans modification de la surface déclarée
- ✅ Systèmes de coordonnées d'origine conservés (EPSG:2154 et EPSG:4326)
- ✅ Zone hors parcelle refusée : « La zone de gestion dépasse les limites de la parcelle. »
- ✅ 2 tâches d'import météo exécutées par le travailleur en arrière-plan
- ✅ Rotation : P03 (orge sur orge) signalée, règle affichée « non validée par un professionnel »
- ✅ Rupture de stock prévisionnelle détectée sur l'ammonitrate
- ✅ Réservation refusée faute de stock : « Stock disponible insuffisant pour « Ammonitrate 27 % » : 800 kg disponibles, 1 863,195 kg demandés. »
- ✅ Demande d'achat DA-2026-0001 → commande CF-2026-0001 : 1 200 kg « attendus » (physique 800 kg)
- ✅ Réception LOT-2026-0010 enregistrée (lot fournisseur COOP-AMMO-26-118) ; commande soldée ; facture FV-2026-00871 référencée
- ✅ Réservation de l'ammonitrate désormais possible
- ✅ Double affectation refusée : « Tracteur 140 ch est déjà affecté(e) du 20/02/2026 08:00 au 20/02/2026 11:00 (INT-2026-0001). »
- ✅ Machine indisponible : « Pulvérisateur traîné 24 m est indisponible sur la période : maintenance « Contrôle périodique du pulvérisateur et remplacement des buses ». »
- ✅ Compétence contrôlée : « Thomas Petit ne dispose pas de la compétence requise valide : certiphyto. »
- ✅ Restriction de maintenance visible dans le planning d'avril
- ✅ Météo manquante le 20/02/2026 : signalée « indisponible », sans valeur inventée
- ✅ Prévu 1 863 kg / consigne machine 150 kg/ha / mesuré 1 842 kg : trois valeurs distinctes conservées
- ✅ Démarrage du traitement bloqué tant qu'aucune validation professionnelle n'est enregistrée
- ✅ Contrôles couverts conformes à la source fictive ; source signalée comme non officielle
- ✅ Traitement enregistré ; l'avertissement « pas une preuve de conformité » accompagne le registre
- ✅ Observation et photo synchronisées ; un second envoi identique est sans effet (identifiants stables)
- ✅ Conflit de synchronisation détecté : « L'observation a été modifiée sur le serveur depuis votre dernière synchronisation. »
- ✅ Compte rendu terrain mis en attente : aucun stock consommé avant validation serveur
- ✅ Après validation par le chef de culture : stock de plants 4 000 → 450 kg
- ✅ Lot BT-2026-P01 : 95,277 t (pont-bascule simulé), rattaché à P01, en attente de contrôle, non apte à la vente par défaut
- ✅ Les relevés de conservation ne rendent pas le lot apte à la vente automatiquement
- ✅ Une opératrice ne peut pas déclarer un lot apte à la vente (permission stocks:liberer)
- ✅ Regroupement OR-2026-MELANGE : 2 parents conservés ; traçabilité déclarée incomplète (« Traçabilité incomplète : origine parcellaire inconnue pour LOT-2026-0011. »)
- ✅ Expédition EXP-2026-0001 : 30 t sur 60 t commandées (commande partiellement expédiée)
- ✅ Expédition EXP-2026-0001 → lot BT-2026-P01 → stockage Cellule de stockage 1 → parcelle P01 (Les Grands Champs)
- ✅ Sacs PF-PDT10-2026-01 ← PDT-2026-P06-A ← PDT-2026-P06 ← parcelle P06 (conditionnement et classement conservés)
- ✅ Saisie d'un traitement refusée à une opératrice (personnes autorisées uniquement)
- ✅ Traitement saisi par la vétérinaire ; délai d'attente recopié, ni calculé ni vérifié par Terroir
- ✅ 22 événements « à déclarer » listés pour préparation, sans transmission officielle
- ✅ Coûts ventilés par catégorie (intrants, main-d'œuvre, matériel, carburant, prestataires, charges indirectes)
- ✅ Calcul d'irrigation déclaré impossible faute d'ET0 les 05–06/08/2026 (pas de valeur par défaut)
- ✅ Rapport de traçabilité PDF (3732 octets), CSV de traçabilité, CSV des coûts et export de gestion comptable écrits dans /tmp/claude-0/demo_sortie
- ✅ Tableau de bord : matériel indisponible (TR-02, défaut bloquant) et rupture prévisionnelle d'ammonitrate pour 2026-2027
- ✅ Blé sur blé en P01 (2026-2027) signalé par une règle validée par la conseillère

## Comptes de démonstration

Mot de passe commun (démonstration uniquement) : `Terroir-Demo-2026!`

- `claire.martin@trois-vallees.example` — Claire Martin (gerant)
- `julien.roche@trois-vallees.example` — Julien Roche (chef_culture)
- `sofia.benali@trois-vallees.example` — Sofia Benali (operateur)
- `marc.dubois@trois-vallees.example` — Marc Dubois (eleveur)
- `agnes.leroy@conseil.example` — Agnès Leroy (conseiller)
- `dr.perrin@veto.example` — Dr Hélène Perrin (veterinaire)
- `lucie.garnier@compta.example` — Lucie Garnier (comptable)
