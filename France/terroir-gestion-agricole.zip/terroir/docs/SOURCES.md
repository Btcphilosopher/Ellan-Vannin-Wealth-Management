# Dépendances, licences et conditions d'intégration

Vérification réalisée le **28/11/2026**. Méthode : registres npm et PyPI, API Docker Hub et dépôts GitHub
consultés directement ; pour les sites institutionnels inaccessibles depuis l'environnement de développement
(data.gouv.fr, eur-lex.europa.eu, postgresql.org, postgis.net, portail-api.meteofrance.fr, geoservices.ign.fr,
cartes.gouv.fr, apicarto.ign.fr, legifrance.gouv.fr, operations.osmfoundation.org), les informations proviennent
d'extraits de recherche limités à ces domaines officiels et sont marquées **« vérifié indirectement »**.
**Elles doivent être relues sur la page officielle avant toute mise en production ou intégration.**

## A. Logiciels

| Composant | Version relevée | Version utilisée | Licence | Source |
|---|---|---|---|---|
| Next.js | 16.4.6 | voir `frontend/package.json` | MIT | registry.npmjs.org/next |
| React | 19.3.1 | voir `frontend/package.json` | MIT | registry.npmjs.org/react |
| idb (IndexedDB) | 8.0.4 | 8.x | ISC | registry.npmjs.org/idb |
| FastAPI | 0.165.0 | 0.165.0 | MIT | pypi.org/project/fastapi |
| SQLAlchemy | 2.1.9 | 2.1.9 | MIT | pypi.org/project/SQLAlchemy |
| Alembic | 1.20.1 | 1.20.1 | MIT | pypi.org/project/alembic |
| GeoAlchemy2 | 0.21.0 | 0.21.0 | MIT | pypi.org/project/GeoAlchemy2 |
| psycopg 3 | 3.3.9 | 3.3.9 | **LGPL-3.0** (usage comme bibliothèque possible ; une version modifiée de psycopg doit rester LGPL) | pypi.org/project/psycopg |
| Shapely | 2.2.0 | 2.2.0 | BSD-3-Clause | pypi.org/project/shapely |
| pyproj | 3.8.0 | 3.8.0 | MIT | pypi.org/project/pyproj |
| ReportLab | 5.1.2 | ≥ 4.2 (5.0.1 testé) | BSD | pypi.org/project/reportlab |
| bcrypt | — | 5.0.0 | Apache-2.0 | pypi.org/project/bcrypt |
| boto3 (client S3) | — | ≥ 1.35 | Apache-2.0 | pypi.org/project/boto3 |
| PostGIS | 3.7.0 (30/10/2026, PG 14–19) — vérifié indirectement | image `postgis/postgis:16-3.5` (tests locaux : 3.4) | **GPL-2.0+** (vérifié sur LICENSE.TXT) | postgis.net, github.com/postgis/postgis |
| PostgreSQL | 19 (19/11/2026) ; 16 supporté jusqu'au 09/11/2028 — vérifié indirectement | 16 | PostgreSQL License (non vérifiée dans cette session) | postgresql.org/support/versioning |

Images Docker vérifiées sur Docker Hub : `postgis/postgis` (étiquettes `16-3.4` à `16-3.7`, `17-3.4` à `17-3.7`, `18-*`, `19-3.7`).

### Stockage objet : choix de SeaweedFS

- **MinIO édition communautaire** : dépôt GitHub archivé le 25/04/2026 (« no longer maintained ») ; plus de binaires
  précompilés pour l'édition communautaire ; image `minio/minio` introuvable sur Docker Hub au 28/11/2026 ; console
  d'administration réduite depuis juin 2025 ; licence AGPLv3. **Écarté.**
- **SeaweedFS** : Apache-2.0, image officielle `chrislusf/seaweedfs` (étiquette `4.55` du 23/11/2026), API S3
  compatible. **Retenu** et testé : écriture/lecture depuis l'API, refus des identifiants invalides et de la lecture anonyme.
- **Garage** (Deuxfleurs) : AGPLv3, image `dxflrs/garage` v2.6.0 — alternative possible.

Le code n'utilise que l'API S3 standard (boto3) : tout service compatible peut être substitué.

## B. Données et services officiels français

| Sujet | Statut constaté | Conditions | Traitement dans Terroir | Source |
|---|---|---|---|---|
| **E-Phy (Anses)** — catalogue des produits phytopharmaceutiques, MFSC, adjuvants | Jeu « Données ouvertes du catalogue E-Phy… » ; CSV (UTF-8 et Windows-1252) et XML ; mise à jour hebdomadaire (nuit du mardi au mercredi) ; fichiers `produits`, `usages_des_produits_autorises`, `produits_usages`. Pas d'API E-Phy dédiée identifiée (non vérifié). | Licence Ouverte (Etalab) ; citer « Données E-Phy - Anses » et la date. Colonnes exactes (dose, DAR, ZNT) **non vérifiées** : lire le dictionnaire de données. | Modèle `source_referentiel` / `produit_referentiel` / `usage_referentiel` avec source et date d'effet. **Import non activé** tant que le format n'est pas validé. La démonstration utilise un référentiel **fictif**, marqué non officiel. | data.gouv.fr (vérifié indirectement) |
| **Registre électronique des usages phytopharmaceutiques** | Règlement d'exécution (UE) 2023/564 : registres électroniques lisibles par machine, applicable depuis le 01/01/2026, conversion sous 30 jours si tenu sur un autre support. Règlement d'exécution (UE) 2025/2203 (en vigueur le 23/11/2025) : option de ne pas exiger la conversion pour les utilisations antérieures au 01/01/2027. Choix français **non vérifié**. | — | Les interventions phytopharmaceutiques sont enregistrées de façon structurée et exportables (JSON/CSV). Terroir **ne prétend pas** à la conformité du registre : avertissement systématique. | eur-lex.europa.eu (vérifié indirectement ; texte de l'art. 3 modifié à relire) |
| **Météo-France — portail des API** | AROME, ARPEGE, observations, climatologie, paquets modèles. | Compte gratuit, abonnement par API, jeton/clé ; quota 100 requêtes/min par API et par compte ; données publiques sous Licence Ouverte Etalab 2.0 ; CGU par API non vérifiées. | Adaptateur `meteo_france` déclaré **non intégré** ; simulateur météo actif, valeurs marquées « simulées ». | portail-api.meteofrance.fr (vérifié indirectement) |
| **IGN Géoplateforme — cadastre** | WFS `CADASTRALPARCELS.PARCELLAIRE_EXPRESS:parcelle` (data.geopf.fr/wfs) ; API Carto module cadastre (500 objets max par réponse, clé non requise d'après une documentation ancienne). Licence PCI **non vérifiée**. | — | Références cadastrales saisies (distinctes des limites opérationnelles). Adaptateur `cadastre` **non intégré**. | apicarto.ign.fr, geoservices.ign.fr (vérifié indirectement) |
| **RPG** (registre parcellaire graphique) | Millésime 2025 publié ; Licence Ouverte Etalab 2.0 ; WMS/WMTS/WFS (`RPG.LATEST:parcelles_graphiques`). | — | Import GeoJSON générique avec déclaration du système de coordonnées ; pas d'appel automatique. | cartes.gouv.fr (vérifié indirectement) |
| **PAC / Telepac** | Télédéclaration sur le portail Telepac (ASP). Aucune API publique destinée aux éditeurs identifiée (absence probable, non vérifiée formellement). | — | Espace de **préparation** de dossiers ; chaque export porte la mention « ne constitue ni une déclaration PAC ni une transmission officielle ». | asp.gouv.fr, telepac.agriculture.gouv.fr |
| **Identification et mouvements des animaux** (BDNI, EdE) | Notification à l'EdE sous 7 jours (bovins, ovins/caprins) via logiciel conforme aux cahiers des charges (TRACIND pour les échanges XML ovins) ou interface de l'EdE ; pas d'API ouverte. Procédure d'agrément actuelle non vérifiée. | Partenariat EdE, conformité aux cahiers des charges, accord de l'éleveur. | Événements « à déclarer » listés pour préparation ; **aucune transmission**. Identifiants de démonstration préfixés `DEMO-`. | idele.fr, agriculture.gouv.fr (vérifié indirectement) |
| **FEC** (fichier des écritures comptables) | Art. A47 A-1 du LPF ; 18 champs (engagement) ; pas de certification administrative du FEC (inférence non vérifiée) ; outil « Test Compta Demat » de la DGFiP. | — | L'export comptable de Terroir est un **CSV de gestion**, explicitement « pas un FEC ». | legifrance.gouv.fr, impots.gouv.fr (vérifié indirectement) |
| **Certiphyto** | Certificat individuel obligatoire (5 catégories, validité 5 ans). | — | Compétence saisie et contrôlée à l'affectation ; mention « non vérifiée auprès de l'administration ». | mesdemarches.agriculture.gouv.fr (vérifié indirectement) |
| **Tuiles OpenStreetMap** | Attribution, User-Agent identifiable, respect du cache, pas de téléchargement massif ni d'usage hors ligne. | — | **Non utilisées** : la carte est dessinée en SVG à partir des géométries de l'exploitation. Un fond (Plan IGN, orthophotos) reste à intégrer. | operations.osmfoundation.org (vérifié indirectement) |

## Points à relire avant publication ou intégration

- Texte exact de l'article 3 du règlement 2023/564 modifié par le 2025/2203, et choix de la France.
- Licence du Parcellaire Express (PCI) et conditions d'usage de l'API Carto.
- Conditions générales propres à chaque API Météo-France.
- Procédure d'agrément actuelle des logiciels auprès des EdE.
- Dictionnaire de données E-Phy (colonnes dose, unité, DAR, ZNT, état d'usage).
