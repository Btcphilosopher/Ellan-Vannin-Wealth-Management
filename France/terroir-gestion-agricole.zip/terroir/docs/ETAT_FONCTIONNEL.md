# État fonctionnel : implémenté, simulé, intégré, reporté

Légende :
- **Implémenté** : fonctionne dans le code livré, couvert par l'API (et l'interface quand indiqué) et testé.
- **Simulé** : comportement réel, données fictives produites par un simulateur clairement étiqueté.
- **Intégré** : échange réel avec un format ou service externe.
- **Reporté** : identifié, non développé.

## Socle

| Fonction | État | Remarques |
|---|---|---|
| Monolithe modulaire FastAPI (15 modules métier), PostgreSQL 16 + PostGIS | Implémenté | `backend/app/modules/*` |
| Migrations Alembic (schéma, contrainte d'exclusion, déclencheur d'immuabilité) | Implémenté | `alembic/versions/0001_schema_initial.py`, testée à chaque lancement des tests |
| Traitements en arrière-plan (file PostgreSQL `SKIP LOCKED`) | Implémenté | import météo, recalcul de surfaces, export, échéances |
| Stockage objet protégé (S3 privé SeaweedFS ou volume local) | Implémenté / intégré (S3) | testé contre SeaweedFS 4.55 |
| Traductions séparées de la logique (`app/i18n/fr.py`, `frontend/src/i18n`) | Implémenté | messages d'erreur par code |
| Formats français, euro, unités explicites, fuseau horaire par site | Implémenté | conversions dimensionnelles refusant masse ↔ volume |
| Modules activables par exploitation | Implémenté | grandes cultures, maraîchage, vergers et viticulture, élevage, polyculture-élevage |

## Parcours principal (production végétale) — cycle complet

| Étape | État | Détails |
|---|---|---|
| Exploitation, sites, parcelles, zones, cadastre, irrigation, sol, restrictions, faire-valoir | Implémenté | référence cadastrale ≠ limite opérationnelle ≠ zone temporaire |
| Géométries : système d'origine conservé, provenance, validation, surfaces géodésiques, chevauchements | Implémenté | écart déclaré/calculé signalé, jamais écrasé |
| Campagnes, cycles, rotations, règles configurables validées par un professionnel | Implémenté | indicateur avec avertissement « pas une preuve de santé du sol » |
| Itinéraires techniques saisis → interventions planifiées | Implémenté | doses saisies par l'exploitation, jamais proposées par Terroir |
| Calcul des besoins (intrants, charge de travail) et ruptures | Implémenté | |
| Achats : demande → commande → réception (lots) → référence de facture | Implémenté | |
| Affectations matériel/personnes, conflits, maintenance, compétences | Implémenté | double protection applicative + PostgreSQL |
| Interventions (10 types), prévu / consigne machine / mesuré, météo avec source et fraîcheur | Implémenté | aucune commande n'est envoyée aux machines |
| Vérification phytopharmaceutique limitée aux règles couvertes + validation professionnelle | Implémenté | référentiel de démonstration **fictif** ; contrôles non couverts listés |
| Observations culturales, photos, humidité du sol, compteurs d'eau | Implémenté | |
| Calcul d'irrigation consultatif avec hypothèses exposées | Implémenté | refuse de calculer si une donnée manque |
| Récolte → lot → stockage → division / classement / regroupement / conditionnement → expédition | Implémenté | généalogie des lots conservée, maillons manquants signalés |
| Stocks : journal immuable, corrections liées, physique / bloqué / réservé / disponible / attendu | Implémenté | réservations verrouillées (testé en concurrence) |
| Observations de conservation sans libération automatique | Implémenté | décision humaine explicite et tracée |
| Ventes : commande → allocation → expédition partielle → facture → paiement | Implémenté | |
| Rapport de traçabilité PDF/CSV | Implémenté | |

## Élevage (démonstration limitée)

| Fonction | État |
|---|---|
| Animaux, lots, appartenances, localisation, naissances, achats, mouvements internes, alimentation (consommation de stock), pesées et GMQ, observations, ventes, mortalité | Implémenté |
| Distinction individuel / collectif | Implémenté |
| Traitements saisis par des personnes autorisées, délai d'attente recopié de l'ordonnance (ni calculé, ni vérifié) | Implémenté |
| Déclarations EdE / BDNI | **Reporté** (préparation interne seulement, aucune transmission) |
| Reproduction (luttes, échographies, mises bas détaillées), lait, plan sanitaire | Reporté |

## Analyses et prévisions

| Fonction | État |
|---|---|
| Coûts par cycle, parcelle, campagne, groupe d'animaux, activité ; 8 catégories | Implémenté |
| Marge brute, résultat après allocation, trésorerie, coût supplémentaire | Implémenté |
| Prix et tarifs versionnés, règles d'allocation documentées | Implémenté |
| Scénarios de rendement, besoins, charge de travail, sensibilité | Implémenté (méthodes transparentes) |
| Repérage statistique de consommations atypiques (z-score) | Implémenté (piste d'investigation, pas un diagnostic) |
| Apprentissage automatique (classification de photos, prévision de rendement, anomalies, maintenance) | **Reporté** — critères d'activation documentés ; l'adaptateur de classification répond « aucun modèle validé » |
| Export comptable CSV de gestion | Intégré (format CSV) — **n'est pas un FEC** |

## Hors connexion

| Fonction | État |
|---|---|
| Données autorisées en cache, brouillons d'observations, photos, notes, comptes rendus proposés | Implémenté (service worker + IndexedDB côté interface ; API `/sync`) |
| Identifiants stables, idempotence, horodatage de saisie, états de synchronisation | Implémenté |
| Conflits explicites et résolution (serveur / terminal / fusion) | Implémenté |
| Opérations sur stocks et ressources partagées en attente de validation serveur | Implémenté |

## Sécurité

| Fonction | État |
|---|---|
| Permissions par exploitation et rôle (8 rôles), cloisonnement des données | Implémenté |
| Sessions serveur (jeton haché, cookie httpOnly/SameSite, révocation), anti-CSRF, blocage après échecs | Implémenté |
| Journal d'audit (créations, modifications, décisions, exports, consultations de documents) | Implémenté |
| Validation des fichiers (extension + signature + taille), documents confidentiels | Implémenté |
| Sauvegarde / restauration testées, export complet des données | Implémenté |
| Authentification forte (TOTP, SSO), chiffrement applicatif des documents, rotation des secrets | Reporté |

## Adaptateurs

| Domaine | Adaptateur | État |
|---|---|---|
| Cartographie | Import GeoJSON multi-SRID | Intégré (format) |
| Cartographie | IGN Géoplateforme (cadastre, fonds de plan) | Reporté |
| Météo | Simulateur | Simulé |
| Météo | Météo-France | Reporté (compte et clé nécessaires) |
| Machines | Télémétrie simulée (heures moteur) | Simulé — étiqueté « télémétrie simulée » |
| Machines | ISOBUS / ISO-XML, API constructeurs | Reporté |
| Balances | Pont-bascule simulé | Simulé |
| Comptabilité | Export CSV | Intégré (format) |
| Services officiels | Telepac, EdE/BDNI, E-Phy | Reporté (voir SOURCES.md) |

## Fonctionnalités spécialisées restant à développer

- **Maraîchage** : planification par séries et planches, plans de culture, rendement par planche, paniers, récoltes échelonnées.
- **Vergers et viticulture** : blocs, rangs, cépages/porte-greffes, comptages, taille par rang, maturité, vendanges, cuverie et traçabilité vin (registres de cave), calendrier gel/grêle.
- **Grandes cultures** : modulation intra-parcellaire, cartes de préconisation (lecture seule d'abord), plans de fumure validés, contrats de collecte.
- **Élevage** : reproduction, production laitière, rations calculées, plan d'épandage des effluents, intégration EdE.
- **Polyculture-élevage** : bilans fourragers, liens cultures ↔ alimentation ↔ effluents.
- **Cartographie** : fonds de plan IGN, édition de géométries dans l'interface, import RPG/Telepac (fichiers), mesures sur carte.
- **Conformité** : import validé du référentiel E-Phy, export du registre phytosanitaire au format attendu, zones de non-traitement calculées.

## Interface web et mobile

| Fonction | État |
|---|---|
| 13 rubriques de navigation + page Terrain, connexion, pages de détail (parcelle, intervention, lot, matériel) | Implémenté |
| Carte SVG des parcelles par site (limites, hachures « écart de surface », zones en pointillés, restrictions, échelle, légende écrite) | Implémenté — sans fond de carte externe |
| Actions principales (affectations, réservations, comptes rendus, validations, réceptions, ventes, décisions de lot, documents, synchronisation) | Implémenté |
| Formulaires pour toutes les routes de l'API (zones, cadastre, itinéraires, règles d'allocation…) | **Partiel** — disponibles par l'API, pas encore dans l'interface |
| Mode terrain hors connexion (service worker limité à /terrain, IndexedDB) | Implémenté |
| Saisie des dates de maintenance dans le fuseau du site | Partiel (heure du navigateur) |
