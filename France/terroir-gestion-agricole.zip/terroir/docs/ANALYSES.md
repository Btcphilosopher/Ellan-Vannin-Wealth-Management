# Analyses économiques et prévisions : règles de calcul

Toutes les analyses sont **des analyses de gestion**. Elles ne remplacent pas une comptabilité réglementaire validée.

## Sources des montants

| Catégorie | Origine des données | Prix utilisé |
|---|---|---|
| Intrants | Mouvements de consommation liés aux interventions (et leurs corrections) | coût du lot acheté, sinon prix d'achat versionné en vigueur à la date du mouvement |
| Emballages | Consommations liées aux lots conditionnés | idem |
| Carburant | Pleins liés aux interventions | idem |
| Main-d'œuvre | Temps de travail saisis | tarif horaire versionné du membre à la date |
| Prestataires | Temps des membres de statut « prestataire », factures fournisseurs imputées au cycle | tarif / montant HT |
| Matériel | Affectations des interventions réalisées × durée réelle | tarif horaire versionné du matériel (hors carburant) |
| Stockage | Lots récoltés présents × durée depuis l'entrée × tarif de l'emplacement (€/t/mois) | tarif saisi sur l'emplacement |
| Charges indirectes | Charges de la campagne réparties par une **règle d'allocation** documentée et versionnée (clé : surface, heures de travail ou produit brut) | montant saisi |

Un prix ou un tarif manquant n'est jamais supposé : la ligne est exclue et signalée dans `donnees_manquantes`.

## Indicateurs

- **Produit** = ventes expédiées valorisées au prix de la commande + stock restant valorisé au prix de valorisation (estimation, indiquée comme telle).
- **Charges opérationnelles** = intrants + emballages + prestataires + stockage.
- **Marge brute** = produit − charges opérationnelles.
- **Résultat après allocation** = marge brute − main-d'œuvre − matériel − carburant − charges indirectes allouées.
- **Trésorerie** = encaissements (paiements clients enregistrés, TTC) − décaissements (factures fournisseurs payées, TTC) sur la période ; indépendante du résultat. Deux périodes sont fournies : la campagne, et du début de campagne à aujourd'hui.
- **Coût supplémentaire (marginal)** = charges variables observées (intrants, carburant, prestataires, emballages, main-d'œuvre, matériel) rapportées à l'hectare ou à la tonne ; hors charges fixes et indirectes ; suppose la capacité disponible.

## Prévisions (méthodes transparentes)

- **Rendement** : si au moins 3 cycles historiques de la même culture existent sur l'exploitation, scénarios pessimiste / médian / optimiste = minimum / médiane / maximum. Sinon, rendement prévisionnel saisi ± un écart paramétrable (15 % par défaut), présenté comme un paramètre de scénario et non comme une statistique.
- **Besoins en intrants et stocks nécessaires** : somme des quantités prévues des interventions planifiées ; manque = besoin − déjà réservé − (disponible + attendu).
- **Charge de travail** : heures prévues des interventions par semaine ISO.
- **Sensibilité** : impact sur le résultat d'une variation de ±X % de chaque poste et du prix de vente.
- **Irrigation** : bilan simplifié ET0 × Kc − pluie efficace, divisé par l'efficience ; hypothèses (sol, Kc et sa source, météo observée/prévue, efficience et sa source) retournées avec le résultat ; calcul refusé si une donnée manque.

## Apprentissage automatique (reporté)

Conditions d'activation : au moins 5 campagnes d'historique par culture et type de sol, évaluation sur un jeu
indépendant, estimation d'incertitude publiée avec chaque prévision, revue agronomique, suivi de dérive.
Interdits : présenter une maladie suggérée par photo comme un diagnostic ; déclencher un traitement automatiquement.
