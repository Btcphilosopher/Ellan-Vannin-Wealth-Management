# Architecture

## Vue d'ensemble

```
 Navigateur (bureau, tablette, téléphone)
   │  Next.js / React / TypeScript — service worker + IndexedDB (terrain hors connexion)
   │  /api/* relayé par Next (même origine → cookie httpOnly, pas de CORS côté navigateur)
   ▼
 API FastAPI « monolithe modulaire » ───────────────► Stockage objet privé (S3 : SeaweedFS)
   │  modules : identité · foncier · cultures · interventions · intrants · stocks ·
   │            traçabilité · élevage · matériel · équipe · commercial · documents ·
   │            terrain · synchronisation · analyses       + adaptateurs (simulateurs)
   ▼
 PostgreSQL 16 + PostGIS  ◄──── Travailleur (python -m app.worker) : file de tâches SKIP LOCKED
```

Un seul déploiement, une seule base, des modules séparés par dossier (`models.py`, `router.py`, `service.py`).
Les dépendances entre modules passent par des fonctions de service explicites (par exemple les interventions
appellent `stocks.service.consommer`, la traçabilité appelle `stocks.service.enregistrer_mouvement`), jamais
par un accès direct aux tables d'un autre module depuis une route. Le découpage en services séparés reste possible
plus tard sans changer le modèle de données.

## Modules et données principales

| Module | Tables | Rôle |
|---|---|---|
| identité | exploitation, utilisateur, adhesion, session_utilisateur, journal_audit, tache_fond, compteur | cloisonnement, rôles, sessions, audit, numérotation, tâches |
| foncier | site, parcelle, reference_cadastrale, zone_gestion, equipement_irrigation | foncier, géométries (EPSG:4326 + géométrie d'origine), surfaces |
| cultures | campagne, cycle_cultural, regle_rotation, itineraire_technique | planification, rotations, besoins |
| interventions | intervention, intervention_produit, affectation, validation_professionnelle | travaux, planning, conflits, validations |
| intrants | source_referentiel, produit_referentiel, usage_referentiel | référentiels réglementaires importés avec source et date d'effet |
| stocks | article, emplacement, lot_stock, mouvement_stock, reservation, observation_stockage | journal immuable, réservations, conservation |
| traçabilité | lien_lot | généalogie des lots (graphe orienté acyclique, CTE récursives) |
| élevage | lot_animaux, animal, appartenance_lot, localisation_lot, evenement_elevage, traitement_animal | individuel / collectif |
| matériel | materiel, releve_heures, maintenance, defaut_materiel, plein_carburant | disponibilité, télémétrie vs saisie |
| équipe | membre_equipe, competence, temps_travail, tarif_ressource | compétences, temps, coûts horaires versionnés |
| commercial | fournisseur, client, prix_article, demande_achat, commande_fournisseur (+ lignes), reception, facture_fournisseur, commande_client (+ lignes), allocation, expedition, facture, paiement | achats et ventes |
| documents | document, dossier_preparation | pièces protégées, échéances, préparation de dossiers |
| terrain | observation_culturale, releve_meteo, releve_compteur_eau, mesure_humidite_sol, programme_irrigation | observations, météo, irrigation consultative |
| synchronisation | operation_sync, conflit_sync | saisies hors connexion |
| analyses | regle_allocation, charge_indirecte | coûts, allocation documentée |

## Principes de conception

- **Prévision ≠ observation ≠ réalisation** : champs `*_prevu(e)` sur les cycles et interventions ; réalisations issues
  des comptes rendus et des lots ; météo `observee` / `prevue` / `indisponible` avec source et fraîcheur ;
  produits avec trois niveaux (prévu, consigne machine, mesuré).
- **Aucune donnée réglementaire inventée** : les contrôles phytopharmaceutiques ne portent que sur les champs présents dans
  un référentiel importé, avec sa source ; les autres contrôles sont listés comme « non couverts ».
- **Aucune action automatique sur le monde physique** : pas de commande de pompe, vanne ou machine ; pas de traitement déclenché.
- **Les données administratives ne sont jamais écrasées** : surface déclarée conservée, écart signalé.
- **Traçabilité honnête** : un maillon manquant est signalé (« origine non documentée »), jamais reconstitué.
- **Corrections attribuées** : journal de stock immuable (déclencheur), corrections liées au mouvement corrigé.
- **Concurrence** : verrou de ligne sur l'article pour les réservations ; contrainte d'exclusion pour les affectations ;
  verrouillage optimiste (`version`) pour les éditions concurrentes ; conflits explicites pour la synchronisation.
- **Temps** : horodatages stockés en UTC (`timestamptz`), affichés dans le fuseau du site concerné.
- **Langue** : messages d'erreur résolus par code dans `app/i18n/fr.py` ; libellés de l'interface dans `frontend/src/i18n`.

## Hors connexion (périmètre explicite)

Pris en charge : lecture d'un sous-ensemble autorisé (`GET /sync/donnees` : parcelles, cycles en cours, interventions
planifiées, dernières observations) ; saisie de brouillons d'observations, photos, notes et comptes rendus proposés.
Chaque saisie porte un UUID généré par le terminal, l'heure de saisie et un état de synchronisation.
`POST /sync/envoi` est idempotent (renvoyer la même opération est sans effet). Les comptes rendus, qui consomment des
stocks et engagent des ressources partagées, sont placés « en attente de validation » et appliqués seulement après
`POST /sync/operations/{id}/validation`. Une modification hors connexion fondée sur une version périmée crée un conflit
(`conflit_sync`) avec les deux versions et la liste des champs divergents ; résolution : garder le serveur, garder le
terminal ou fusionner champ par champ.

Non pris en charge hors connexion : stocks, ventes, achats, planning, documents administratifs.

## Traitements en arrière-plan

Table `tache_fond` ; le travailleur réserve une tâche avec `FOR UPDATE SKIP LOCKED` (plusieurs travailleurs possibles,
sans courtier). Trois tentatives au maximum, erreur conservée. Tâches : `import_meteo`, `recalcul_surfaces`,
`export_donnees`, `controle_echeances`.

## Déploiement

`docker-compose.yml` : `db` (postgis/postgis:16-3.5), `stockage` (SeaweedFS 4.55, S3 privé), `api` (migrations puis
uvicorn), `worker`, `web` (Next.js), et en profil `outils` : `demo`, `sauvegarde`.
