# Démonstration : Ferme des Trois Vallées

Exploitation **fictive** (EARL Ferme des Trois Vallées, SIRET « DEMO-000000000 ») : 4 sites dont une station d'essai
en La Réunion (fuseau `Indian/Reunion`), 9 parcelles (grandes cultures, maraîchage, prairie, verger), 7 matériels,
6 membres d'équipe dont un prestataire, un troupeau ovin, 15 articles, 8 emplacements de stockage, un référentiel
phytopharmaceutique **fictif** marqué non officiel. Toutes les géométries, identifiants d'animaux (`DEMO-OV-…`),
numéros AMM (`DEMO-0001`), noms et montants sont synthétiques.

## Lancer

```bash
docker compose up -d --build
docker compose --profile outils run --rm demo
```

Sans Docker (PostgreSQL 16 + PostGIS locaux, rôle `terroir`/`terroir` superutilisateur) :

```bash
./scripts/demo_locale.sh
```

Le script **réinitialise** l'exploitation de démonstration puis exécute le parcours via l'API (client HTTP en
processus, mêmes contrôles de permissions que l'interface). Il écrit `RESULTATS_DEMO.md` et les rapports exportés.

## Parcours démontré

| # | Étape | Incident volontaire |
|---|---|---|
| 1 | Création des sites et parcelles (Lambert-93 et WGS 84), cadastre, zone temporaire, irrigation | écart de surface signalé ; zone hors parcelle refusée |
| 2 | Planification 2025-2026 : 6 cycles, itinéraire appliqué, rotations | orge sur orge signalée (règle non validée) |
| 3 | Calcul des besoins | **rupture de stock** d'ammonitrate → demande d'achat → commande |
| 4 | Réception des fournitures, lot fournisseur, référence de facture | — |
| 5 | Affectation du matériel et des personnes | double affectation refusée ; **machine indisponible** (pulvérisateur en contrôle) ; Certiphyto manquant |
| 6 | Interventions : travail du sol, semis, fertilisation, traitement fongicide | **météo manquante** le 20/02/2026 ; validation professionnelle exigée avant traitement |
| 7 | Synchronisation hors connexion : observation + photo, renvoi idempotent, compte rendu en attente de validation | **conflit de synchronisation** résolu par fusion |
| 8 | Lot récolté (pont-bascule simulé), classement des pommes de terre avec pertes | — |
| 9 | Stockage, relevés de conservation, libération et aptitude à la vente, regroupement | traçabilité déclarée incomplète (reliquat d'origine non documentée) |
| 10 | Expédition partielle (30 t sur 60 t), facture, paiement ; conditionnement en sacs et vente directe | — |
| 11 | Traçabilité expédition → lot → stockage → parcelle | — |
| 12 | Élevage ovin : lots, naissances, pesées, alimentation, traitement par la vétérinaire, vente, mortalité | traitement refusé à une opératrice |
| 13 | Analyse des coûts, prévisions, irrigation consultative | calcul d'irrigation refusé faute d'ET0 |
| 14 | Export des rapports (PDF et CSV de traçabilité, coûts, export comptable) | — |
| 15 | Campagne 2026-2027 : tableau de bord | tracteur avec défaut bloquant ; nouvelle rupture prévisionnelle |

Le résultat réellement obtenu est dans [`RESULTATS_DEMO.md`](RESULTATS_DEMO.md) ; les exports produits sont dans
[`exemples/`](exemples/).

## Comptes

Mot de passe commun **de démonstration uniquement** : `Terroir-Demo-2026!`

| Courriel | Personne | Rôle |
|---|---|---|
| claire.martin@trois-vallees.example | Claire Martin | gérante |
| julien.roche@trois-vallees.example | Julien Roche | chef de culture |
| sofia.benali@trois-vallees.example | Sofia Benali | opératrice |
| marc.dubois@trois-vallees.example | Marc Dubois | éleveur |
| agnes.leroy@conseil.example | Agnès Leroy | conseillère (validation professionnelle) |
| dr.perrin@veto.example | Dr Hélène Perrin | vétérinaire |
| lucie.garnier@compta.example | Lucie Garnier | comptable |
