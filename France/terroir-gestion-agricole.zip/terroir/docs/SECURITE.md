# Sécurité

## Authentification et sessions
- Mots de passe hachés avec **bcrypt** (coût 12) ; 12 caractères minimum à la création d'un compte.
- Session **côté serveur** : jeton aléatoire de 256 bits ; seul son condensé SHA-256 est stocké (`session_utilisateur`).
- Cookie `terroir_session` : `HttpOnly`, `SameSite=Lax`, `Secure` activable (`TERROIR_COOKIE_SECURE=true` derrière HTTPS), durée 12 h, révocation à la déconnexion.
- Jeton `Authorization: Bearer` accepté pour les clients d'API (non soumis au CSRF car non ambiant).
- **Anti-CSRF** : toute requête modifiante authentifiée par cookie doit porter `X-Terroir-Requete: 1` (un site tiers ne peut pas l'ajouter sans autorisation CORS).
- **Blocage** : 5 échecs → compte bloqué 15 minutes ; temps de réponse homogène si le compte n'existe pas.
- En-têtes : `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: same-origin`, `Cache-Control: no-store` sur l'API.

## Permissions par exploitation et rôle
Chaque route métier est sous `/exploitations/{id}/…` et exige une adhésion de l'utilisateur à cette exploitation.
Les objets référencés sont contrôlés : un identifiant d'une autre exploitation répond « introuvable ».

| Permission | gerant | chef_culture | conseiller | operateur | eleveur | veterinaire | comptable | lecture |
|---|---|---|---|---|---|---|---|---|
| `achats:ecrire` | ✓ | ✓ | — | — | — | — | ✓ | — |
| `achats:lire` | ✓ | ✓ | — | — | — | — | ✓ | ✓ |
| `analyses:lire` | ✓ | ✓ | ✓ | — | — | — | ✓ | ✓ |
| `audit:lire` | ✓ | ✓ | — | — | ✓ | — | ✓ | — |
| `cultures:ecrire` | ✓ | ✓ | ✓ | — | — | — | — | — |
| `cultures:lire` | ✓ | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ |
| `documents:confidentiels` | ✓ | — | — | — | — | — | ✓ | — |
| `documents:ecrire` | ✓ | ✓ | — | — | ✓ | — | ✓ | — |
| `documents:lire` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| `donnees:exporter` | ✓ | — | — | — | — | — | ✓ | — |
| `elevage:ecrire` | ✓ | — | — | — | ✓ | — | — | — |
| `elevage:lire` | ✓ | ✓ | — | ✓ | ✓ | ✓ | ✓ | ✓ |
| `elevage:traitement` | ✓ | — | — | — | ✓ | ✓ | — | — |
| `equipe:ecrire` | ✓ | ✓ | — | — | — | — | — | — |
| `equipe:lire` | ✓ | ✓ | — | ✓ | ✓ | — | ✓ | ✓ |
| `foncier:ecrire` | ✓ | ✓ | — | — | — | — | — | — |
| `foncier:lire` | ✓ | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ |
| `interventions:ecrire` | ✓ | ✓ | — | — | — | — | — | — |
| `interventions:lire` | ✓ | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ |
| `interventions:realiser` | ✓ | ✓ | — | ✓ | — | — | — | — |
| `materiel:ecrire` | ✓ | ✓ | — | — | — | — | — | — |
| `materiel:lire` | ✓ | ✓ | — | ✓ | ✓ | — | ✓ | ✓ |
| `parametres:ecrire` | ✓ | — | — | — | — | — | — | — |
| `phyto:valider` | ✓ | — | ✓ | — | — | — | — | — |
| `sauvegarde:gerer` | ✓ | — | — | — | — | — | — | — |
| `stocks:ecrire` | ✓ | ✓ | — | — | ✓ | — | — | — |
| `stocks:liberer` | ✓ | — | — | — | — | — | — | — |
| `stocks:lire` | ✓ | ✓ | ✓ | ✓ | ✓ | — | ✓ | ✓ |
| `sync:resoudre` | ✓ | ✓ | — | — | — | — | — | — |
| `terrain:saisir` | ✓ | ✓ | — | ✓ | ✓ | — | — | — |
| `ventes:ecrire` | ✓ | — | — | — | — | — | ✓ | — |
| `ventes:lire` | ✓ | ✓ | — | — | ✓ | — | ✓ | ✓ |

## Journal d'audit
Table `journal_audit` : auteur, horodatage, action, entité, identifiant, différences avant/après (champs sensibles exclus),
origine (web, terrain, tâche). Sont journalisés : créations et modifications, mouvements de stock, réservations,
changements de statut, décisions d'aptitude à la vente, validations professionnelles, connexions, consultations et
exports de documents, exports de données, résolutions de conflits.

## Intégrité des données
- Journal des mouvements de stock **immuable** (déclencheur PostgreSQL refusant UPDATE/DELETE) ; corrections par mouvements liés et attribués.
- **Contrainte d'exclusion** PostgreSQL (btree_gist) interdisant deux affectations actives qui se chevauchent pour une même ressource.
- **Verrouillage optimiste** (`version`) sur parcelles, cycles, interventions, lots, commandes, observations.
- Réservations sérialisées par verrou de ligne sur l'article (`SELECT … FOR UPDATE`).

## Documents et fichiers
- Stockage objet privé (S3 SeaweedFS non exposé hors du réseau Compose, ou volume local en `0600`) ; téléchargement uniquement via l'API, après contrôle de permission, avec `Content-Disposition: attachment`.
- Validation : liste blanche d'extensions, **signature binaire** vérifiée (PDF, PNG, JPEG, WebP), UTF-8 pour CSV/texte/GeoJSON, taille maximale (15 Mo par défaut), nom de fichier assaini, empreinte SHA-256.
- Documents **confidentiels** visibles seulement avec `documents:confidentiels`.

## Secrets et identifiants
- Aucun secret dans le code ; configuration par variables `TERROIR_*` et fichier `.env` (modèle `.env.example`).
- Les identifiants S3 de `deploy/seaweedfs/s3.json` et le mot de passe PostgreSQL de démonstration **doivent être changés**.
- Les comptes de démonstration partagent un mot de passe public : ne jamais les créer sur une instance réelle.

## Sauvegarde et restauration
```bash
python -m app.outils.sauvegarde sauvegarder --dossier ./sauvegardes
python -m app.outils.sauvegarde restaurer --archive ./sauvegardes/terroir-AAAAMMJJ-HHMMSS.tar --cible postgresql://…/terroir_restauree
```
L'archive (`0600`) contient `pg_dump` (format custom), les objets stockés et un manifeste (SHA-256, nombre de lignes par table).
La restauration vérifie les empreintes puis compare les comptages : le test `tests/test_sauvegarde.py` restaure dans une base
vierge et contrôle les comptages, la présence de PostGIS, du déclencheur d'immuabilité et de la contrainte d'exclusion.
Avec Docker : `docker compose --profile outils run --rm sauvegarde`.

## Export des données
`GET /exploitations/{id}/export-donnees` (permission `donnees:exporter`) : archive ZIP de toutes les tables de l'exploitation
en JSON (géométries en GeoJSON), sans comptes ni sessions.

## Limites connues
- Pas encore d'authentification multifacteur ni de SSO.
- Pas de limitation de débit globale (seulement le blocage de connexion).
- Le chiffrement au repos dépend de l'infrastructure (disques, SeaweedFS) ; pas de chiffrement applicatif des documents.
