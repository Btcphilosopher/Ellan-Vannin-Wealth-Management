/*
 * Service worker de Terroir — périmètre volontairement limité à la saisie terrain.
 * - Enregistré avec la portée /terrain : seules les pages /terrain sont contrôlées.
 * - Met en cache l'enveloppe de /terrain et ses ressources statiques (/_next/static).
 * - Ne met JAMAIS en cache les appels /api (les données hors connexion sont dans IndexedDB)
 *   et ne rejoue aucune requête de modification.
 */
const CACHE = "terroir-terrain-v1";
const ENVELOPPE = ["/terrain", "/manifest.webmanifest", "/icone.svg"];

self.addEventListener("install", (e) => {
  e.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll(ENVELOPPE);
    // Ressources statiques référencées par la page /terrain
    try {
      const html = await (await fetch("/terrain", { credentials: "same-origin" })).text();
      const urls = [...new Set([...html.matchAll(/\/_next\/static\/[^"'\s)]+/g)].map((m) => m[0].replace(/\\u0026/g, "&")))];
      await Promise.all(urls.map((u) => cache.add(u).catch(() => undefined)));
    } catch (_) { /* hors ligne pendant l'installation */ }
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== CACHE) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return; // aucune mise en cache des modifications
  const url = new URL(req.url);
  if (url.origin !== self.location.origin || url.pathname.startsWith("/api/")) return;
  if (url.pathname.startsWith("/_next/static/") || ENVELOPPE.includes(url.pathname)) {
    if (req.mode === "navigate" || url.pathname === "/terrain") {
      // Réseau d'abord pour la page, cache en secours hors connexion
      e.respondWith(fetch(req).then((r) => { const c = r.clone(); caches.open(CACHE).then((x) => x.put("/terrain", c)); return r; })
        .catch(() => caches.match("/terrain")));
      return;
    }
    e.respondWith(caches.match(req).then((hit) => hit || fetch(req).then((r) => {
      if (r.ok) { const c = r.clone(); caches.open(CACHE).then((x) => x.put(req, c)); }
      return r;
    })));
    return;
  }
  if (req.mode === "navigate" && url.pathname.startsWith("/terrain")) {
    e.respondWith(fetch(req).catch(() => caches.match("/terrain")));
  }
});
