"use client";

import { useMemo } from "react";
import { t } from "@/i18n/fr";

type Position = number[];
type Geom = { type: string; coordinates: any };
export type Entite = { type: "Feature"; geometry: Geom; properties: Record<string, any> };

function anneaux(g: Geom): Position[][] {
  if (g.type === "Polygon") return g.coordinates as Position[][];
  if (g.type === "MultiPolygon") return (g.coordinates as Position[][][]).flat();
  return [];
}

/**
 * Carte SVG autonome (aucun fond de carte tiers) : projection équirectangulaire
 * locale, corrigée du cosinus de la latitude, suffisante à l'échelle d'un site.
 */
export function CarteParcelles({ parcelles, zones = [], selection, surSelection, titre, legende = true }: {
  parcelles: Entite[]; zones?: Entite[]; selection?: string | null; surSelection?: (id: string) => void; titre: string; legende?: boolean;
}) {
  const vue = useMemo(() => {
    const pts = [...parcelles, ...zones].flatMap((f) => anneaux(f.geometry).flat());
    if (!pts.length) return null;
    const lons = pts.map((p) => p[0]); const lats = pts.map((p) => p[1]);
    const [minLon, maxLon, minLat, maxLat] = [Math.min(...lons), Math.max(...lons), Math.min(...lats), Math.max(...lats)];
    const k = Math.cos(((minLat + maxLat) / 2) * Math.PI / 180);
    const larg = Math.max((maxLon - minLon) * k, 1e-6); const haut = Math.max(maxLat - minLat, 1e-6);
    const L = 1000; const marge = 40; const echelle = (L - 2 * marge) / Math.max(larg, haut);
    const H = haut * echelle + 2 * marge; const W = larg * echelle + 2 * marge;
    const proj = (p: Position) => [marge + (p[0] - minLon) * k * echelle, marge + (maxLat - p[1]) * echelle];
    // Barre d'échelle : 1° de latitude ≈ 111 320 m
    const metresParUnite = 111320 / echelle;
    const choix = [50, 100, 200, 250, 500, 1000, 2000, 5000].find((m) => m / metresParUnite > 80) ?? 5000;
    return { proj, W, H, barre: { metres: choix, px: choix / metresParUnite } };
  }, [parcelles, zones]);
  if (!vue) return <p className="vide">Aucune géométrie à afficher.</p>;
  const chemin = (g: Geom) => anneaux(g).map((r) => "M" + r.map((p) => vue.proj(p).map((v) => v.toFixed(1)).join(",")).join("L") + "Z").join(" ");
  const centre = (g: Geom) => {
    const r = anneaux(g)[0].slice(0, -1).map(vue.proj);
    return [r.reduce((s, p) => s + p[0], 0) / r.length, r.reduce((s, p) => s + p[1], 0) / r.length];
  };
  return (
    <figure style={{ margin: 0 }}>
      <svg className="carte-svg" viewBox={`0 0 ${vue.W.toFixed(0)} ${vue.H.toFixed(0)}`} role="img" aria-label={titre}>
        <defs>
          <pattern id="hachures" width="10" height="10" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
            <rect width="10" height="10" fill="#e7f0d8" />
            <line x1="0" y1="0" x2="0" y2="10" stroke="#8a5a00" strokeWidth="3" />
          </pattern>
        </defs>
        {parcelles.map((f) => {
          const p = f.properties; const [cx, cy] = centre(f.geometry);
          return (
            <g key={p.id}>
              <path d={chemin(f.geometry)} className={`parcelle-forme ${selection === p.id ? "selectionnee" : ""}`}
                fill={p.ecart_signale ? "url(#hachures)" : "#dcebc9"} fillRule="evenodd"
                onClick={() => surSelection?.(p.id)} tabIndex={0} role="button"
                aria-label={`${p.code} ${p.nom}${p.ecart_signale ? " — écart de surface à vérifier" : ""}`}
                onKeyDown={(e) => { if (e.key === "Enter") surSelection?.(p.id); }}>
                <title>{`${p.code} — ${p.nom}${p.cultures?.length ? " — " + p.cultures.join(", ") : ""}`}</title>
              </path>
              <text x={cx} y={cy} textAnchor="middle" className="parcelle-etiquette" fontSize="44">{p.code}</text>
              {p.cultures?.length > 0 && <text x={cx} y={cy + 36} textAnchor="middle" className="parcelle-etiquette" fontSize="28">{p.cultures.join(", ")}</text>}
              {p.restrictions?.length > 0 && <text x={cx} y={cy - 46} textAnchor="middle" className="parcelle-etiquette" fontSize="28">◆ restriction</text>}
            </g>
          );
        })}
        {zones.map((z) => <path key={z.properties.id} d={chemin(z.geometry)} className="zone-forme"><title>{z.properties.nom}</title></path>)}
        <g transform={`translate(20, ${vue.H - 18})`}>
          <line x1="0" y1="0" x2={vue.barre.px} y2="0" stroke="#1b1f1a" strokeWidth="4" />
          <text x="0" y="-10" fontSize="26">{vue.barre.metres >= 1000 ? `${vue.barre.metres / 1000} km` : `${vue.barre.metres} m`}</text>
        </g>
        <text x={vue.W - 20} y="30" textAnchor="end" fontSize="30" fontWeight="700">N ↑</text>
      </svg>
      {legende && <Legende />}
    </figure>
  );
}

export function Legende() {
  return (
    <figcaption className="legende">
        <span><svg width="26" height="16" aria-hidden="true"><rect x="1" y="1" width="24" height="14" fill="#dcebc9" stroke="#163a20" strokeWidth="2.5" /></svg>{t("parcelles.legendeContour")}</span>
        <span><svg width="26" height="16" aria-hidden="true"><rect x="1" y="1" width="24" height="14" fill="url(#hachures)" stroke="#163a20" strokeWidth="2.5" /></svg>{t("parcelles.legendeEcart")}</span>
        <span><svg width="26" height="16" aria-hidden="true"><rect x="1" y="1" width="24" height="14" fill="none" stroke="#1f4e79" strokeWidth="2.5" strokeDasharray="5 3" /></svg>{t("parcelles.legendeZone")}</span>
        <span>◆ {t("parcelles.legendeRestriction")}</span>
    </figcaption>
  );
}
