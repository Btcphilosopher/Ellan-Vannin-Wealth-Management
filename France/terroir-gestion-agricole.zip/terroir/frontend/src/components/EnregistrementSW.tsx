"use client";

import { useEffect } from "react";

/**
 * Le service worker ne prend en charge que la saisie terrain hors connexion :
 * il est enregistré uniquement depuis /terrain, avec la portée /terrain.
 */
export function EnregistrementSW() {
  useEffect(() => {
    if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      navigator.serviceWorker.register("/sw.js", { scope: "/terrain" }).catch(() => undefined);
    }
  }, []);
  return null;
}
