"use client";

import { useState } from "react";
import type { ReactNode } from "react";
import { ErreurApi } from "@/lib/api";
import type { Etat } from "@/lib/session";
import { useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

/* ---------- Badges : toujours une icône ET un libellé (jamais la couleur seule) ---------- */

export type Ton = "ok" | "alerte" | "critique" | "info" | "neutre" | "attente";
const ICONES: Record<Ton, string> = { ok: "✓", alerte: "⚠", critique: "⛔", info: "ℹ", neutre: "•", attente: "⏳" };

export function Badge({ ton = "neutre", icone, children, titre }: { ton?: Ton; icone?: string; children: ReactNode; titre?: string }) {
  return (
    <span className={`badge badge-${ton}`} title={titre}>
      <span aria-hidden="true" className="badge-icone">{icone ?? ICONES[ton]}</span>
      <span>{children}</span>
    </span>
  );
}

export function BadgeNiveau({ niveau }: { niveau: string }) {
  const ton: Ton = niveau === "critique" ? "critique" : niveau === "avertissement" ? "alerte" : "info";
  return <Badge ton={ton}>{t(`niveau.${niveau}`)}</Badge>;
}

export function BadgeStatutIntervention({ statut }: { statut: string }) {
  const ton: Ton = statut === "realisee" ? "ok" : statut === "annulee" ? "neutre" : statut === "proposee" ? "attente" : statut === "en_cours" ? "info" : "attente";
  const icone = statut === "planifiee" ? "🗓" : statut === "en_cours" ? "▶" : undefined;
  return <Badge ton={ton} icone={icone}>{lib("statutIntervention", statut)}</Badge>;
}

export function BadgeControle({ statut }: { statut: string }) {
  const ton: Ton = statut === "conforme_source" ? "ok" : statut === "alerte" ? "critique" : statut === "non_disponible" ? "neutre" : "info";
  const icone = statut === "non_disponible" ? "?" : undefined;
  return <Badge ton={ton} icone={icone}>{lib("controle", statut)}</Badge>;
}

export function BadgeLot({ statut, apte }: { statut: string; apte?: boolean }) {
  const ton: Ton = statut === "libre" ? "ok" : statut === "epuise" ? "neutre" : statut === "en_attente_controle" ? "attente" : "critique";
  return (
    <span className="badges">
      <Badge ton={ton}>{lib("statutLot", statut)}</Badge>
      {apte !== undefined && (apte ? <Badge ton="ok" icone="€">Apte à la vente</Badge> : <Badge ton="neutre" icone="✗">Non déclaré apte à la vente</Badge>)}
    </span>
  );
}

export function BadgeCommande({ statut }: { statut: string }) {
  const ton: Ton = ["recue", "expediee", "payee", "approuvee", "commandee", "facturee"].includes(statut) ? "ok"
    : ["annulee", "refusee"].includes(statut) ? "neutre" : "attente";
  return <Badge ton={ton}>{lib("commande", statut)}</Badge>;
}

export function BadgeSync({ statut }: { statut: string }) {
  const ton: Ton = statut === "acceptee" || statut === "validee" ? "ok" : statut === "conflit" ? "critique" : statut === "rejetee" ? "critique" : statut === "envoye" ? "info" : "attente";
  const icone = statut === "rejetee" ? "✗" : statut === "conflit" ? "⇄" : undefined;
  return <Badge ton={ton} icone={icone}>{lib("sync", statut)}</Badge>;
}

/* ---------- Mise en page ---------- */

export function Entete({ titre, sousTitre, actions }: { titre: string; sousTitre?: ReactNode; actions?: ReactNode }) {
  return (
    <header className="entete-page">
      <div>
        <h1>{titre}</h1>
        {sousTitre && <p className="sous-titre">{sousTitre}</p>}
      </div>
      {actions && <div className="actions">{actions}</div>}
    </header>
  );
}

export function Section({ titre, actions, children, id, className }: { titre?: ReactNode; actions?: ReactNode; children: ReactNode; id?: string; className?: string }) {
  return (
    <section className={`carte ${className ?? ""}`} id={id}>
      {(titre || actions) && (
        <div className="carte-entete">
          {titre && <h2>{titre}</h2>}
          {actions && <div className="actions">{actions}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

export function Avertissement({ children, ton = "alerte", titre }: { children: ReactNode; ton?: Ton; titre?: string }) {
  const libelle = titre ?? (ton === "critique" ? "Attention" : ton === "info" ? "À savoir" : "Avertissement");
  return (
    <div className={`avertissement avertissement-${ton}`} role="note">
      <strong><span aria-hidden="true">{ICONES[ton]} </span>{libelle} :</strong> {children}
    </div>
  );
}

export function Message({ erreur, succes }: { erreur?: string | null; succes?: string | null }) {
  if (erreur) return <div className="message message-erreur" role="alert"><strong>⛔ Erreur :</strong> {erreur}</div>;
  if (succes) return <div className="message message-succes" role="status"><strong>✓</strong> {succes}</div>;
  return null;
}

export function Charge<T>({ etat, children, vide }: { etat: Etat<T>; children: (d: T) => ReactNode; vide?: (d: T) => boolean }) {
  if (etat.chargement && !etat.donnees) return <p className="chargement" aria-live="polite">⏳ {t("app.chargement")}</p>;
  if (etat.erreur && !etat.donnees)
    return (
      <div className="message message-erreur" role="alert">
        <strong>⛔ {t("app.erreur")} :</strong> {etat.erreur.message}{" "}
        <button className="bouton bouton-petit" onClick={etat.recharger}>{t("app.reessayer")}</button>
      </div>
    );
  if (!etat.donnees) return null;
  if (vide && vide(etat.donnees)) return <p className="vide">{t("app.aucunElement")}</p>;
  return <>{children(etat.donnees)}</>;
}

export function Tableau({ entetes, children, legende }: { entetes: ReactNode[]; children: ReactNode; legende?: string }) {
  return (
    <div className="tableau-conteneur">
      <table className="tableau">
        {legende && <caption>{legende}</caption>}
        <thead><tr>{entetes.map((e, i) => <th key={i} scope="col">{e}</th>)}</tr></thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

export function Onglets({ onglets, actif, surChange }: { onglets: { cle: string; libelle: string }[]; actif: string; surChange: (c: string) => void }) {
  return (
    <div className="onglets" role="tablist">
      {onglets.map((o) => (
        <button key={o.cle} role="tab" aria-selected={actif === o.cle} className={`onglet ${actif === o.cle ? "actif" : ""}`} onClick={() => surChange(o.cle)}>
          {actif === o.cle && <span aria-hidden="true">▸ </span>}{o.libelle}
        </button>
      ))}
    </div>
  );
}

export function Champ({ libelle, children, aide }: { libelle: string; children: ReactNode; aide?: string }) {
  return (
    <label className="champ">
      <span className="champ-libelle">{libelle}</span>
      {children}
      {aide && <span className="champ-aide">{aide}</span>}
    </label>
  );
}

export function Grille({ children }: { children: ReactNode }) {
  return <div className="grille-champs">{children}</div>;
}

export function Valeurs({ items }: { items: [string, ReactNode][] }) {
  return (
    <dl className="valeurs">
      {items.map(([k, v]) => (
        <div key={k}><dt>{k}</dt><dd>{v ?? "—"}</dd></div>
      ))}
    </dl>
  );
}

/** Bouton soumis à une permission : désactivé et explicité si le rôle ne l'a pas. */
export function BoutonPermis({ permission, children, className = "bouton", ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { permission: string }) {
  const { peut } = useSession();
  if (!peut(permission)) {
    return (
      <button {...props} className={`${className} desactive`} disabled title={`${t("app.permissionManquante")} (${permission})`} aria-disabled="true">
        🔒 {children}
      </button>
    );
  }
  return <button {...props} className={className}>{children}</button>;
}

/** Exécution d'une action avec gestion des messages. */
export function useAction() {
  const [enCours, setEnCours] = useState(false);
  const [erreur, setErreur] = useState<string | null>(null);
  const [succes, setSucces] = useState<string | null>(null);
  async function executer<T>(fn: () => Promise<T>, messageSucces: string = t("app.succes")): Promise<T | undefined> {
    setEnCours(true);
    setErreur(null);
    setSucces(null);
    try {
      const r = await fn();
      setSucces(messageSucces);
      return r;
    } catch (e) {
      setErreur(e instanceof ErreurApi ? e.message : String(e));
      return undefined;
    } finally {
      setEnCours(false);
    }
  }
  return { executer, enCours, erreur, succes, setErreur, setSucces };
}

/** Panneau dépliable (formulaires secondaires). */
export function Depliable({ titre, children, ouvert = false }: { titre: string; children: ReactNode; ouvert?: boolean }) {
  return (
    <details className="depliable" open={ouvert}>
      <summary>{titre}</summary>
      <div className="depliable-contenu">{children}</div>
    </details>
  );
}

export function Lien({ href, children, telechargement }: { href: string; children: ReactNode; telechargement?: boolean }) {
  return <a className="bouton bouton-secondaire" href={href} download={telechargement ? "" : undefined}>{telechargement && <span aria-hidden="true">⬇ </span>}{children}</a>;
}
