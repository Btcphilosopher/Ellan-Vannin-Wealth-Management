"use client";

import { Badge } from "@/components/ui";
import { dateHeure, quantite } from "@/lib/format";

export function BadgeDispo({ d }: { d: any }) {
  return d.disponible ? <Badge ton="ok">Disponible</Badge> : <Badge ton="critique">Indisponible</Badge>;
}

export function SourceHeures({ h }: { h: any }) {
  if (!h) return <span className="discret">aucun relevé</span>;
  return <>{quantite(h.valeur, "h", 1)} <Badge ton={h.source.startsWith("telemetrie") ? "info" : "neutre"} icone={h.source.startsWith("telemetrie") ? "📡" : "✍"}>{h.libelle_source}</Badge><div className="discret">le {dateHeure(h.le)}</div></>;
}

