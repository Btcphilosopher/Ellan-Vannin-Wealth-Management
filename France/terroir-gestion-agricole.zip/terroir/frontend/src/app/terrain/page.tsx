"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { EnregistrementSW } from "@/components/EnregistrementSW";
import { Avertissement, Badge, BadgeSync, Champ, Grille, Message } from "@/components/ui";
import { api, ErreurApi } from "@/lib/api";
import { dateHeure, quantite } from "@/lib/format";
import {
  ajouterALaFile, enregistrerDonnees, identifiantTerminal, lireDonnees, lireEnBase64, lireFile, majElement, supprimerElement,
  type DonneesLocales, type ElementFile,
} from "@/lib/horsligne";
import { CLE_PROFIL, type Profil } from "@/lib/session";
import { lib, libelles, t } from "@/i18n/fr";

function useEnLigne() {
  const [enLigne, setEnLigne] = useState(true);
  useEffect(() => {
    setEnLigne(navigator.onLine);
    const on = () => setEnLigne(true);
    const off = () => setEnLigne(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);
  return enLigne;
}

export default function PageTerrain() {
  const enLigne = useEnLigne();
  const [profil, setProfil] = useState<Profil | null>(null);
  const [sansProfil, setSansProfil] = useState(false);
  const [donnees, setDonnees] = useState<DonneesLocales | null>(null);
  const [file, setFile] = useState<ElementFile[]>([]);
  const [message, setMessage] = useState<{ erreur?: string; succes?: string }>({});
  const [envoi, setEnvoi] = useState(false);
  const adh = profil?.adhesions[0];
  const exp = adh?.exploitation_id;
  const peut = (p: string) => !!adh?.permissions.includes(p);

  // Profil : en ligne via /auth/moi, sinon copie locale (lecture seule) conservée lors de la dernière connexion.
  useEffect(() => {
    let local: Profil | null = null;
    try { const s = localStorage.getItem(CLE_PROFIL); if (s) local = JSON.parse(s); } catch { /* ignoré */ }
    if (navigator.onLine) {
      api.get<Profil>("/auth/moi").then((p) => { setProfil(p); try { localStorage.setItem(CLE_PROFIL, JSON.stringify(p)); } catch { /* ignoré */ } })
        .catch((e) => { if (e instanceof ErreurApi && e.statut === 401) { window.location.href = "/connexion"; } else if (local) setProfil(local); else setSansProfil(true); });
    } else if (local) setProfil(local);
    else setSansProfil(true);
  }, []);

  const rafraichirFile = useCallback(async () => { if (exp) setFile(await lireFile(exp)); }, [exp]);

  const preparer = useCallback(async () => {
    if (!exp) return;
    try {
      const d = await api.get(`/exploitations/${exp}/sync/donnees`);
      const loc: DonneesLocales = { ...d, exploitation_id: exp, telecharge_le: new Date().toISOString() };
      await enregistrerDonnees(loc);
      setDonnees(loc);
    } catch (e) {
      setMessage({ erreur: e instanceof ErreurApi ? e.message : String(e) });
    }
  }, [exp]);

  useEffect(() => {
    if (!exp) return;
    lireDonnees(exp).then((d) => { if (d) setDonnees(d); });
    rafraichirFile();
    if (navigator.onLine) preparer();
  }, [exp, preparer, rafraichirFile]);

  async function synchroniser() {
    if (!exp) return;
    const aEnvoyer = file.filter((e) => e.etat === "en_attente" || e.etat === "envoye");
    if (!aEnvoyer.length) { setMessage({ succes: "Rien à synchroniser." }); return; }
    setEnvoi(true);
    setMessage({});
    const maintenant = new Date().toISOString();
    for (const e of aEnvoyer) await majElement(e.id, { etat: "envoye", envoye_le: maintenant });
    await rafraichirFile();
    try {
      const r = await api.post(`/exploitations/${exp}/sync/envoi`, {
        terminal_id: identifiantTerminal(),
        operations: aEnvoyer.map((e) => ({ id: e.id, type: e.type, entite_id: e.entite_id, version_base: e.version_base, saisi_le: e.saisi_le, contenu: e.contenu })),
      });
      for (const res of r.resultats) await majElement(res.id, { etat: res.statut, message: res.message });
      const n = (s: string) => r.resultats.filter((x: any) => x.statut === s).length;
      setMessage({ succes: `Synchronisation terminée : ${n("acceptee")} accepté(s), ${n("en_attente_validation")} en attente de validation, ${n("conflit")} conflit(s), ${n("rejetee")} rejeté(s).` });
      preparer();
    } catch (e) {
      // Échec réseau : les éléments restent dans la file pour un nouvel essai (identifiants stables, renvoi sans doublon).
      setMessage({ erreur: `${e instanceof ErreurApi ? e.message : String(e)} Les saisies restent sur l'appareil.` });
    } finally {
      setEnvoi(false);
      await rafraichirFile();
    }
  }

  if (sansProfil) return (
    <main className="terrain"><h1>{t("terrain.titre")}</h1>
      <Avertissement ton="critique" titre="Appareil non préparé">{t("terrain.aucuneDonnee")} <a href="/connexion">{t("connexion.titre")}</a></Avertissement></main>
  );
  if (!profil || !exp) return <main className="terrain"><p className="chargement">⏳ {t("app.chargement")}</p></main>;

  return (
    <>
      <EnregistrementSW />
      <div className={`etat-reseau ${enLigne ? "en-ligne" : "hors-ligne"}`} role="status" aria-live="polite">
        {enLigne ? <>✓ {t("terrain.enLigne")}</> : <>⛔ {t("terrain.horsLigne")}</>}
      </div>
      <main className="terrain">
        <div className="entete-page">
          <div><h1>📱 {t("terrain.titre")}</h1><p className="sous-titre">{profil.nom_affiche} — {adh?.libelle_role}</p></div>
          <Link className="bouton bouton-secondaire" href="/" prefetch={false}>{t("nav.tableau")}</Link>
        </div>
        <Message erreur={message.erreur} succes={message.succes} />
        <section className="carte">
          {donnees ? <p>{t("terrain.donneesDu")} <strong>{dateHeure(donnees.telecharge_le)}</strong> : {donnees.parcelles.length} parcelles, {donnees.interventions.length} interventions planifiées. <span className="discret">{donnees.perimetre}</span></p>
            : <p>{t("terrain.aucuneDonnee")}</p>}
          <button className="bouton bouton-secondaire" disabled={!enLigne} onClick={preparer}>⬇ {t("terrain.preparer")}</button>
        </section>
        {donnees && peut("terrain:saisir") && <Saisies donnees={donnees} exp={exp} surAjout={rafraichirFile} />}
        {!peut("terrain:saisir") && <Avertissement>Votre rôle ne permet pas la saisie terrain.</Avertissement>}
        <section className="carte">
          <div className="carte-entete"><h2>{t("terrain.file")} ({file.filter((e) => ["en_attente", "envoye"].includes(e.etat)).length} à envoyer)</h2>
            <button className="bouton bouton-accent" disabled={!enLigne || envoi} onClick={synchroniser}>⇅ {t("terrain.synchroniser")}</button></div>
          <Avertissement ton="info">{t("terrain.attenteValidation")}</Avertissement>
          {file.length === 0 ? <p className="vide">Aucune saisie sur cet appareil.</p> : file.slice().reverse().map((e) => (
            <div key={e.id} className="file-item" data-etat={e.etat} data-id={e.id}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: ".5rem", flexWrap: "wrap" }}>
                <strong>{e.libelle}</strong><BadgeSync statut={e.etat} />
              </div>
              <div className="discret">{t("terrain.saisiLe")} {dateHeure(e.saisi_le)} · identifiant <span className="code">{e.id.slice(0, 8)}</span></div>
              {e.message && <div>{e.message}</div>}
              {["acceptee", "validee", "rejetee"].includes(e.etat) && <button className="bouton bouton-petit bouton-secondaire" onClick={async () => { await supprimerElement(e.id); rafraichirFile(); }}>Retirer de l'appareil</button>}
            </div>
          ))}
        </section>
        {enLigne && <Conflits exp={exp} peutResoudre={peut("sync:resoudre")} />}
      </main>
    </>
  );
}

function Saisies({ donnees, exp, surAjout }: { donnees: DonneesLocales; exp: string; surAjout: () => void }) {
  const [mode, setMode] = useState<"observation" | "note" | "compte_rendu">("observation");
  const [f, setF] = useState<Record<string, string>>({ categorie: "etat_general", intensite: "" });
  const [photo, setPhoto] = useState<File | null>(null);
  const [cleFichier, setCleFichier] = useState(0);
  const [ok, setOk] = useState<string | null>(null);
  const cycles = useMemo(() => donnees.cycles.filter((c) => c.parcelle_id === f.parcelle_id), [donnees, f.parcelle_id]);
  const intervention = donnees.interventions.find((i) => i.id === f.intervention_id);
  const [cr, setCr] = useState<Record<string, string>>({});
  const maj = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const parcelle = (id?: string) => donnees.parcelles.find((p) => p.id === id);

  async function ajouter() {
    const saisi_le = new Date().toISOString();
    if (mode === "observation") {
      if (!f.parcelle_id || !f.description) return;
      const obsId = crypto.randomUUID();
      await ajouterALaFile({ id: crypto.randomUUID(), exploitation_id: exp, type: "observation", entite_id: obsId, version_base: null, saisi_le, etat: "en_attente",
        libelle: `Observation ${lib("observation", f.categorie)} — ${parcelle(f.parcelle_id)?.code}`,
        contenu: { parcelle_id: f.parcelle_id, cycle_id: f.cycle_id || null, categorie: f.categorie, stade: f.stade || null, description: f.description, intensite: f.intensite || null } });
      if (photo) {
        const ext = photo.type === "image/png" ? "png" : photo.type === "image/webp" ? "webp" : "jpg";
        await ajouterALaFile({ id: crypto.randomUUID(), exploitation_id: exp, type: "photo", entite_id: null, version_base: null, saisi_le, etat: "en_attente",
          libelle: `Photo — ${parcelle(f.parcelle_id)?.code}`,
          contenu: { nom_fichier: `terrain-${obsId.slice(0, 8)}.${ext}`, titre: `Photo de terrain — ${parcelle(f.parcelle_id)?.code}`, donnees_base64: await lireEnBase64(photo), entite_type: "observation_culturale", entite_id: obsId } });
      }
    } else if (mode === "note") {
      if (!f.parcelle_id || !f.texte) return;
      await ajouterALaFile({ id: crypto.randomUUID(), exploitation_id: exp, type: "note", entite_id: crypto.randomUUID(), version_base: null, saisi_le, etat: "en_attente",
        libelle: `Note — ${parcelle(f.parcelle_id)?.code}`, contenu: { parcelle_id: f.parcelle_id, texte: f.texte } });
    } else {
      if (!intervention || !cr.debut || !cr.fin) return;
      const n = (v?: string) => (v ? Number(v.replace(",", ".")) : 0);
      await ajouterALaFile({ id: crypto.randomUUID(), exploitation_id: exp, type: "compte_rendu", entite_id: intervention.id, version_base: intervention.version, saisi_le, etat: "en_attente",
        libelle: `Compte rendu proposé — ${intervention.numero}`,
        contenu: { debut_reel: new Date(cr.debut).toISOString(), fin_reelle: new Date(cr.fin).toISOString(), surface_realisee_ha: cr.surface ? n(cr.surface) : null,
          produits: intervention.produits.map((p: any) => ({ intervention_produit_id: p.id, quantite_mesuree: n(cr[`q_${p.id}`]), methode_mesure: "estimation" })),
          temps: [], notes: cr.notes || null } });
    }
    setOk("Saisie enregistrée sur l'appareil (« En attente »).");
    setF({ categorie: "etat_general", intensite: "" });
    setPhoto(null);
    setCleFichier((k) => k + 1);
    setCr({});
    surAjout();
  }

  return (
    <section className="carte">
      <div className="onglets" role="tablist">
        {([["observation", t("terrain.nouvelleObservation")], ["note", t("terrain.nouvelleNote")], ["compte_rendu", t("terrain.compteRendu")]] as const).map(([k, l]) => (
          <button key={k} role="tab" aria-selected={mode === k} className={`onglet ${mode === k ? "actif" : ""}`} onClick={() => { setMode(k); setOk(null); }}>{l}</button>
        ))}
      </div>
      {mode !== "compte_rendu" && (
        <Champ libelle="Parcelle"><select value={f.parcelle_id ?? ""} onChange={maj("parcelle_id")}><option value="">—</option>{donnees.parcelles.map((p) => <option key={p.id} value={p.id}>{p.code} — {p.nom}</option>)}</select></Champ>
      )}
      {mode === "observation" && (
        <>
          <Grille>
            <Champ libelle="Culture"><select value={f.cycle_id ?? ""} onChange={maj("cycle_id")}><option value="">—</option>{cycles.map((c) => <option key={c.id} value={c.id}>{c.culture}</option>)}</select></Champ>
            <Champ libelle="Catégorie"><select value={f.categorie} onChange={maj("categorie")}>{Object.entries(libelles.observation).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>
            <Champ libelle="Stade"><input value={f.stade ?? ""} onChange={maj("stade")} /></Champ>
            <Champ libelle="Intensité"><select value={f.intensite} onChange={maj("intensite")}><option value="">—</option><option value="faible">Faible</option><option value="moyenne">Moyenne</option><option value="forte">Forte</option></select></Champ>
          </Grille>
          <Champ libelle="Description"><textarea value={f.description ?? ""} onChange={maj("description")} /></Champ>
          <Champ libelle={t("terrain.photo")} aide="La photo est jointe à l'observation. Aucune suggestion automatique n'est un diagnostic.">
            <input key={cleFichier} type="file" accept="image/*" capture="environment" onChange={(e) => setPhoto(e.target.files?.[0] ?? null)} />
          </Champ>
        </>
      )}
      {mode === "note" && <Champ libelle="Note"><textarea value={f.texte ?? ""} onChange={maj("texte")} /></Champ>}
      {mode === "compte_rendu" && (
        <>
          <Champ libelle="Intervention planifiée"><select value={f.intervention_id ?? ""} onChange={maj("intervention_id")}><option value="">—</option>
            {donnees.interventions.map((i) => <option key={i.id} value={i.id}>{i.numero} — {lib("typeIntervention", i.type)} — {i.parcelle.code}</option>)}</select></Champ>
          {intervention && (
            <>
              <Grille>
                <Champ libelle="Début"><input type="datetime-local" value={cr.debut ?? ""} onChange={(e) => setCr({ ...cr, debut: e.target.value })} /></Champ>
                <Champ libelle="Fin"><input type="datetime-local" value={cr.fin ?? ""} onChange={(e) => setCr({ ...cr, fin: e.target.value })} /></Champ>
                <Champ libelle="Surface réalisée (ha)"><input inputMode="decimal" value={cr.surface ?? ""} onChange={(e) => setCr({ ...cr, surface: e.target.value })} /></Champ>
                {intervention.produits.map((p: any) => (
                  <Champ key={p.id} libelle={`${p.article} — quantité mesurée (${p.unite_quantite})`} aide={`Prévu : ${quantite(p.quantite_prevue, p.unite_quantite)}`}>
                    <input inputMode="decimal" value={cr[`q_${p.id}`] ?? ""} onChange={(e) => setCr({ ...cr, [`q_${p.id}`]: e.target.value })} />
                  </Champ>
                ))}
              </Grille>
              <Champ libelle="Notes"><textarea value={cr.notes ?? ""} onChange={(e) => setCr({ ...cr, notes: e.target.value })} /></Champ>
              <Avertissement ton="info">Ce compte rendu sera mis « en attente de validation » : aucun stock n'est consommé tant qu'un responsable ne l'a pas validé sur le serveur.</Avertissement>
            </>
          )}
        </>
      )}
      <Message succes={ok} />
      <button className="bouton" onClick={ajouter}>💾 Enregistrer sur l'appareil</button>
    </section>
  );
}

function Conflits({ exp, peutResoudre }: { exp: string; peutResoudre: boolean }) {
  const [liste, setListe] = useState<any[] | null>(null);
  const [erreur, setErreur] = useState<string | null>(null);
  const charger = useCallback(() => { api.get(`/exploitations/${exp}/sync/conflits`).then(setListe).catch((e) => setErreur(e.message)); }, [exp]);
  useEffect(charger, [charger]);
  if (!liste?.length) return null;
  async function resoudre(id: string, resolution: string, terminal: any) {
    try {
      await api.post(`/exploitations/${exp}/sync/conflits/${id}/resolution`, { resolution, valeurs_fusion: resolution === "fusion" ? terminal : null });
      charger();
    } catch (e) { setErreur(e instanceof ErreurApi ? e.message : String(e)); }
  }
  return (
    <section className="carte">
      <h2>⇄ {t("terrain.conflits")}</h2>
      <Message erreur={erreur} />
      {liste.map((c) => (
        <div key={c.id} className="file-item">
          <Badge ton="critique" icone="⇄">Conflit</Badge> {c.entite} — champs : {c.champs_en_conflit.join(", ")}
          <Grille>
            <div><strong>Serveur</strong><pre style={{ whiteSpace: "pre-wrap", fontSize: ".8rem" }}>{JSON.stringify(Object.fromEntries(c.champs_en_conflit.map((k: string) => [k, c.version_serveur[k]])), null, 1)}</pre></div>
            <div><strong>Terminal</strong><pre style={{ whiteSpace: "pre-wrap", fontSize: ".8rem" }}>{JSON.stringify(c.version_terminal, null, 1)}</pre></div>
          </Grille>
          {peutResoudre ? (
            <div className="actions">
              <button className="bouton bouton-secondaire" onClick={() => resoudre(c.id, "garder_serveur", null)}>{t("terrain.garderServeur")}</button>
              <button className="bouton bouton-secondaire" onClick={() => resoudre(c.id, "garder_terminal", null)}>{t("terrain.garderTerminal")}</button>
              <button className="bouton" onClick={() => resoudre(c.id, "fusion", { ...Object.fromEntries(c.champs_en_conflit.map((k: string) => [k, c.version_serveur[k]])), ...c.version_terminal })}>{t("terrain.fusion")}</button>
            </div>
          ) : <p className="discret">🔒 La résolution est réservée aux personnes autorisées (chef de culture, gérant).</p>}
        </div>
      ))}
    </section>
  );
}
