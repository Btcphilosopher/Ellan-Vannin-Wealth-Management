import type { Metadata } from "next";

export const metadata: Metadata = { title: "Saisie terrain" };

export default function LayoutTerrain({ children }: { children: React.ReactNode }) {
  return children;
}
