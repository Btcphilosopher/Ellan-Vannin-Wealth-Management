"use client";

import { useEffect, useState } from "react";
import { Avertissement, Badge, Champ, Charge, Entete, Lien, Onglets, Section, Tableau } from "@/components/ui";
import { euros, nombre, quantite, surface } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

const CATS = ["intrants", "main_oeuvre", "materiel", "carburant", "prestataires", "stockage", "emballages", "indirectes"];

export default function PageAnalyses() {
  const { ex } = useSession();
  const campagnes = useEx<any[]>("/campagnes");
  const [c, setC] = useState("");
  const [onglet, setOnglet] = useState("couts");
  useEffect(() => { if (!c && campagnes.donnees?.length) setC((campagnes.donnees.find((x) => x.statut === "en_cours") ?? campagnes.donnees[0]).id); }, [campagnes.donnees, c]);
  return (
    <>
      <Entete titre={t("nav.analyses")} sousTitre="Coûts, marges, trésorerie et prévisions transparentes"
        actions={<>
          <Champ libelle={t("cultures.campagne")}><select value={c} onChange={(e) => setC(e.target.value)}>{(campagnes.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.libelle}</option>)}</select></Champ>
          {c && <Lien href={`/api/v1${ex(`/rapports/couts?campagne_id=${c}&format=csv`)}`} telechargement>{t("analyses.exportCsv")}</Lien>}
          {c && <Lien href={`/api/v1${ex(`/rapports/couts?campagne_id=${c}&format=pdf`)}`} telechargement>{t("analyses.exportPdf")}</Lien>}
        </>} />
      <Onglets actif={onglet} surChange={setOnglet} onglets={[{ cle: "couts", libelle: t("analyses.couts") }, { cle: "synthese", libelle: `${t("analyses.activites")} · ${t("analyses.tresorerie")}` }, { cle: "previsions", libelle: t("analyses.previsions") }]} />
      {c && onglet === "couts" && <Couts campagne={c} />}
      {c && onglet === "synthese" && <Synthese campagne={c} />}
      {c && onglet === "previsions" && <Previsions campagne={c} />}
    </>
  );
}

function Couts({ campagne }: { campagne: string }) {
  const a = useEx(`/analyses/couts?campagne_id=${campagne}`);
  const [ouvert, setOuvert] = useState<string | null>(null);
  return (
    <Charge etat={a}>
      {(d: any) => (
        <>
          <Avertissement ton="info" titre="Analyse de gestion">{d.avertissement}</Avertissement>
          <Section titre="Définitions utilisées"><dl className="valeurs">{Object.entries(d.definitions).map(([k, v]) => <div key={k}><dt>{k.replace(/_/g, " ")}</dt><dd style={{ fontWeight: 400 }}>{v as string}</dd></div>)}</dl></Section>
          {d.donnees_manquantes.length > 0 && <Avertissement titre={t("analyses.manquantes")}>{d.donnees_manquantes.join(" ; ")}</Avertissement>}
          <Section titre={t("analyses.couts")}>
            <Tableau entetes={["Parcelle / culture", "Surface", ...CATS.map((k) => lib("categorieCharge", k)), "Produit", "Marge brute", "Résultat après allocation", "Coût supplémentaire", ""]}>
              {d.cycles.map((cy: any) => (
                <tr key={cy.cycle_id}>
                  <td><strong>{cy.parcelle}</strong><div className="discret">{cy.culture} · {lib("module", cy.module)}</div></td>
                  <td className="num">{surface(cy.surface_ha)}</td>
                  {CATS.map((k) => <td key={k} className="num">{euros(cy.charges[k])}</td>)}
                  <td className="num">{euros(cy.produit_eur)}</td>
                  <td className="num"><strong>{euros(cy.marge_brute_eur)}</strong>{cy.marge_brute_eur_ha !== null && <div className="discret">{euros(cy.marge_brute_eur_ha)}/ha</div>}</td>
                  <td className="num">{euros(cy.resultat_apres_allocation_eur)}</td>
                  <td className="num">{cy.cout_supplementaire.par_ha_eur !== null ? `${euros(cy.cout_supplementaire.par_ha_eur)}/ha` : "—"}{cy.cout_supplementaire.par_t_eur !== null && <div className="discret">{euros(cy.cout_supplementaire.par_t_eur)}/t</div>}</td>
                  <td><button className="bouton bouton-petit bouton-secondaire" onClick={() => setOuvert(ouvert === cy.cycle_id ? null : cy.cycle_id)}>{ouvert === cy.cycle_id ? "Masquer" : t("app.details")}</button></td>
                </tr>
              ))}
            </Tableau>
            {d.cycles.filter((cy: any) => cy.cycle_id === ouvert).map((cy: any) => (
              <div className="carte" key={cy.cycle_id}>
                <h3>Détail — {cy.parcelle} ({cy.culture})</h3>
                <p className="discret">Hypothèse du coût supplémentaire : {cy.cout_supplementaire.hypothese}</p>
                {Object.entries(cy.details).map(([k, lignes]: any) => (
                  <div key={k}><h3>{lib("categorieCharge", k)}</h3>
                    <Tableau entetes={["Poste", "Montant", "Règle / source"]}>{lignes.map((l: any, i: number) => <tr key={i}><td>{l.libelle}</td><td className="num">{euros(l.montant_eur)}</td><td className="discret">{l.source_prix ?? l.regle ?? (l.tarif_version ? `tarif v${l.tarif_version}` : "")}</td></tr>)}</Tableau>
                  </div>
                ))}
                <h3>Produit</h3>
                <Tableau entetes={["Origine", "Nature", "Montant"]}>{cy.detail_produit.map((p: any, i: number) => <tr key={i}><td>{p.libelle}</td><td>{p.nature === "vendu" ? <Badge ton="ok">Vendu</Badge> : <Badge ton="attente" icone="≈">Stock valorisé (estimation)</Badge>}</td><td className="num">{euros(p.montant_eur)}</td></tr>)}</Tableau>
              </div>
            ))}
          </Section>
          <Section titre="Groupes d'animaux">
            <Tableau entetes={["Lot", ...CATS.map((k) => lib("categorieCharge", k)), "Total"]}>
              {d.groupes_animaux.map((g: any) => <tr key={g.code}><td>{g.lot}</td>{CATS.map((k) => <td key={k} className="num">{euros(g.charges[k])}</td>)}<td className="num"><strong>{euros(g.total_eur)}</strong></td></tr>)}
            </Tableau>
          </Section>
          <Section titre={t("analyses.allocations")}>
            <Tableau entetes={["Charge", "Montant", "Règle", "Clé", "Version", "Description"]}>
              {d.allocations.map((al: any, i: number) => <tr key={i}><td>{al.charge}</td><td className="num">{euros(al.montant_eur)}</td><td>{al.regle}</td><td>{al.cle}</td><td>v{al.version}</td><td className="discret">{al.description}</td></tr>)}
            </Tableau>
          </Section>
        </>
      )}
    </Charge>
  );
}

function Synthese({ campagne }: { campagne: string }) {
  const a = useEx(`/analyses/couts?campagne_id=${campagne}`);
  const { ex } = useSession();
  const ligne = (nom: string, v: any) => (
    <tr key={nom}><td><strong>{nom}</strong></td>{CATS.map((k) => <td key={k} className="num">{euros(v[k])}</td>)}<td className="num">{euros(v.produit_eur)}</td><td className="num">{euros(v.marge_brute_eur)}</td><td className="num">{euros(v.resultat_apres_allocation_eur)}</td></tr>
  );
  return (
    <Charge etat={a}>
      {(d: any) => (
        <>
          <Section titre={t("analyses.activites")}>
            <Tableau entetes={["Activité", ...CATS.map((k) => lib("categorieCharge", k)), "Produit", "Marge brute", "Résultat alloué"]}>
              {Object.entries(d.par_activite).map(([k, v]) => ligne(lib("module", k), v))}
              {ligne("Total de la campagne", d.total)}
            </Tableau>
          </Section>
          <Section titre={t("analyses.parcelles")}>
            <Tableau entetes={["Parcelle", ...CATS.map((k) => lib("categorieCharge", k)), "Produit", "Marge brute", "Résultat alloué"]}>
              {Object.entries(d.par_parcelle).map(([k, v]) => ligne(k, v))}
            </Tableau>
          </Section>
          <div className="grille-2">
            {[["Sur la période de la campagne", d.tresorerie], ["Depuis le début de campagne jusqu'à aujourd'hui", d.tresorerie_a_date]].filter(([, v]) => v).map(([titre, tr]: any) => (
              <Section key={titre} titre={`${t("analyses.tresorerie")} — ${titre}`}>
                <dl className="valeurs">
                  <div><dt>Encaissements</dt><dd>{euros(tr.encaissements_eur)}</dd></div>
                  <div><dt>Décaissements</dt><dd>{euros(tr.decaissements_eur)}</dd></div>
                  <div><dt>Solde</dt><dd>{euros(tr.solde_eur)}</dd></div>
                  <div><dt>Factures fournisseurs non payées</dt><dd>{euros(tr.factures_fournisseurs_non_payees_eur)}</dd></div>
                </dl>
                <p className="discret">{tr.note} La trésorerie est distincte du résultat.</p>
              </Section>
            ))}
          </div>
          <Section titre={t("analyses.exportComptable")}>
            <p className="discret">Ce fichier n'est pas un fichier des écritures comptables (FEC) et ne remplace pas une comptabilité réglementaire.</p>
            <Lien href={`/api/v1${ex("/exports/comptable?du=2025-09-01&au=2026-12-31")}`} telechargement>Télécharger (01/09/2025 → 31/12/2026)</Lien>
          </Section>
        </>
      )}
    </Charge>
  );
}

function Previsions({ campagne }: { campagne: string }) {
  const p = useEx(`/analyses/previsions?campagne_id=${campagne}`);
  return (
    <Charge etat={p}>
      {(d: any) => (
        <>
          <Section titre="Scénarios de rendement">
            <Tableau entetes={["Culture", "Surface", "Pessimiste", "Médian", "Optimiste", "Méthode"]}>
              {d.rendements.map((r: any) => r.statut === "impossible" ? <tr key={r.cycle_id}><td>{r.culture}</td><td colSpan={4}><Badge ton="neutre" icone="∅">Scénario impossible</Badge></td><td>{r.methode}</td></tr> : (
                <tr key={r.cycle_id}><td>{r.culture}</td><td className="num">{surface(r.surface_ha)}</td>
                  {["pessimiste", "median", "optimiste"].map((k) => <td key={k} className="num">{nombre(r.scenarios[k].rendement_t_ha, 2)} t/ha<div className="discret">{quantite(r.scenarios[k].production_t, "t", 1)}</div></td>)}
                  <td className="discret">{r.methode} {r.incertitude}</td></tr>
              ))}
            </Tableau>
          </Section>
          <Section titre={t("analyses.sensibilite")}>
            <Tableau entetes={["Poste", "Montant actuel", "Variation", "Résultat si hausse", "Résultat si baisse", "Impact"]}>
              {d.sensibilite_couts.map((s: any) => <tr key={s.poste}><td>{lib("categorieCharge", s.poste)}</td><td className="num">{euros(s.montant_eur)}</td><td className="num">± {nombre(s.variation_pct, 0)} %</td><td className="num">{euros(s.resultat_si_hausse_eur)}</td><td className="num">{euros(s.resultat_si_baisse_eur)}</td><td className="num">{euros(s.impact_eur)}</td></tr>)}
            </Tableau>
          </Section>
          <div className="grille-2">
            <Section titre="Besoins en intrants">
              <Tableau entetes={["Article", "Besoin", "Manque", ""]}>
                {d.besoins_intrants.map((b: any) => <tr key={b.article_id}><td>{b.libelle}</td><td className="num">{quantite(b.besoin, b.unite)}</td><td className="num">{quantite(b.manque, b.unite)}</td><td>{b.statut === "rupture" ? <Badge ton="critique" icone="⚠">Rupture</Badge> : <Badge ton="ok">Couvert</Badge>}</td></tr>)}
              </Tableau>
            </Section>
            <Section titre="Charge de travail">
              <Tableau entetes={["Semaine", "Interventions", "Heures"]}>{d.charge_travail.map((c: any) => <tr key={c.semaine}><td>{c.semaine}</td><td className="num">{c.interventions}</td><td className="num">{quantite(c.heures, "h", 1)}</td></tr>)}</Tableau>
            </Section>
          </div>
          <Section titre={t("analyses.ml")}>
            <p><Badge ton="neutre" icone="⏸">{d.apprentissage_automatique.statut}</Badge></p>
            <h3>Conditions d'activation</h3><ul>{d.apprentissage_automatique.conditions_activation.map((c: string, i: number) => <li key={i}>{c}</li>)}</ul>
            <h3>Usages envisagés</h3><ul>{d.apprentissage_automatique.usages_envisages.map((c: string, i: number) => <li key={i}>{c}</li>)}</ul>
            <h3>Interdits</h3><ul>{d.apprentissage_automatique.interdits.map((c: string, i: number) => <li key={i}>⛔ {c}</li>)}</ul>
          </Section>
        </>
      )}
    </Charge>
  );
}
