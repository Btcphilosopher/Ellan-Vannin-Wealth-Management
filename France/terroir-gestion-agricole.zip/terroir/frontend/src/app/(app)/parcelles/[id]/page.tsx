"use client";

import { use } from "react";
import Link from "next/link";
import { CarteParcelles } from "@/components/CarteParcelles";
import { Avertissement, Badge, Charge, Entete, Section, Tableau, Valeurs } from "@/components/ui";
import { date, dateHeure, libelleFuseau, nombre, quantite, surface } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

export default function DetailParcelle({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const etat = useEx(`/parcelles/${id}`);
  const { sites } = useSession();
  return (
    <Charge etat={etat}>
      {(p: any) => {
        const site = sites.find((s) => s.id === p.site_id);
        const ec = p.ecart_surface;
        return (
          <>
            <Entete titre={`${p.code} — ${p.nom}`} sousTitre={<>{site?.nom} · {site && libelleFuseau(site.fuseau_horaire)} · <Link href="/parcelles">{t("app.retour")}</Link></>} />
            <div className="grille-2">
              <Section titre="Surfaces">
                <Valeurs items={[
                  [t("parcelles.surfaceDeclaree"), <>{surface(p.surface_declaree_ha)} <span className="discret">({p.source_surface_declaree ?? "source non renseignée"})</span></>],
                  [t("parcelles.surfaceCalculee"), <>{surface(p.surface_calculee_ha)} <span className="discret">(calcul géodésique)</span></>],
                  [t("parcelles.ecart"), ec.ecart_ha !== undefined && ec.ecart_ha !== null ? `${nombre(ec.ecart_ha, 4)} ha (${nombre(ec.ecart_pct, 2)} %) — tolérance ${nombre(ec.tolerance_pct, 1)} %` : "—"],
                ]} />
                {ec.signale ? <Avertissement>{ec.message}</Avertissement> : <Badge ton="ok">{ec.message}</Badge>}
                {p.comparaison_cadastre.surface_cadastrale_exploitee_ha !== null && (
                  <p className="discret">Surface exploitée d'après les références cadastrales : {surface(p.comparaison_cadastre.surface_cadastrale_exploitee_ha)}. {p.comparaison_cadastre.note}</p>
                )}
              </Section>
              <Section titre="Limite">
                {p.geometrie ? <CarteParcelles titre={`Limite de ${p.code}`} parcelles={[{ type: "Feature", geometry: p.geometrie, properties: { id: p.id, code: p.code, nom: p.nom, ecart_signale: ec.signale, restrictions: p.restrictions } }]}
                  zones={p.zones.filter((z: any) => z.geometrie).map((z: any) => ({ type: "Feature", geometry: z.geometrie, properties: z }))} /> : <p className="vide">Pas de géométrie.</p>}
                <h3>{t("parcelles.provenance")}</h3>
                {p.provenance_geometrie ? <Valeurs items={[
                  ["Source", p.provenance_geometrie.source], ["Méthode", p.provenance_geometrie.methode],
                  [t("parcelles.systeme"), `EPSG:${p.provenance_geometrie.srid_origine} — ${p.provenance_geometrie.systeme}`],
                  ["Date d'acquisition", date(p.provenance_geometrie.date_acquisition)],
                  ["Précision annoncée", p.provenance_geometrie.precision_m !== null ? `${nombre(p.provenance_geometrie.precision_m, 2)} m` : "—"],
                  ["Saisie par", p.provenance_geometrie.saisie_par],
                ]} /> : <p className="vide">—</p>}
              </Section>
            </div>
            <div className="grille-2">
              <Section titre="Foncier et accès">
                <Valeurs items={[[t("parcelles.faireValoir"), lib("faireValoir", p.mode_faire_valoir)], ["Propriétaire", p.proprietaire ?? "—"],
                  ["Échéance du bail", date(p.bail_echeance)], [t("parcelles.acces"), p.acces ?? "—"], ["Irrigable", p.irrigable ? "Oui" : "Non"]]} />
              </Section>
              <Section titre={t("parcelles.restrictions")}>
                {p.restrictions.length === 0 ? <p className="vide">Aucune restriction connue saisie.</p> : (
                  <ul>{p.restrictions.map((r: any, i: number) => <li key={i}><Badge ton="alerte" icone="◆">{r.type}</Badge> {r.libelle} <span className="discret">— source : {r.source ?? "non renseignée"}</span></li>)}</ul>
                )}
                {p.chevauchements.length > 0 && <Avertissement>{t("parcelles.chevauchements")} : {p.chevauchements.map((c: any) => `${c.code} (${nombre(c.surface_ha, 4)} ha)`).join(", ")}</Avertissement>}
              </Section>
            </div>
            <Section titre={t("parcelles.sol")}>
              {p.sol ? <Valeurs items={[["Texture", p.sol.texture], ["pH", nombre(p.sol.ph, 1)], ["Matière organique", p.sol.mo_pct !== undefined ? `${nombre(p.sol.mo_pct, 1)} %` : "—"],
                ["Profondeur", p.sol.profondeur_cm ? `${p.sol.profondeur_cm} cm` : "—"], ["Réserve utile", p.sol.ru_mm ? quantite(p.sol.ru_mm, "mm", 0) : "—"],
                ["Source", p.sol.source], ["Date d'analyse", date(p.sol.date_analyse)]]} /> : <p className="vide">Aucune caractéristique documentée.</p>}
            </Section>
            <div className="grille-2">
              <Section titre={t("parcelles.cadastre")}>
                <p className="discret">{t("parcelles.cadastreNote")}</p>
                <Tableau entetes={["Commune (INSEE)", "Section", "N°", "Surface cadastrale", "Surface exploitée", "Source"]}>
                  {p.references_cadastrales.map((r: any) => <tr key={r.id}><td>{r.code_insee}</td><td>{r.section}</td><td>{r.numero}</td>
                    <td className="num">{surface(r.surface_cadastrale_ha)}</td><td className="num">{surface(r.surface_exploitee_ha)}</td><td>{r.source}</td></tr>)}
                </Tableau>
              </Section>
              <Section titre={t("parcelles.zones")}>
                <Tableau entetes={["Zone", "Nature", "Période", "Surface", "Motif"]}>
                  {p.zones.map((z: any) => <tr key={z.id}><td>{z.nom}</td><td><Badge ton={z.nature === "temporaire" ? "attente" : "info"}>{z.nature === "temporaire" ? "Temporaire" : "Permanente"}</Badge></td>
                    <td>{date(z.date_debut)} → {date(z.date_fin)}</td><td className="num">{surface(z.surface_calculee_ha)}</td><td>{z.motif}</td></tr>)}
                </Tableau>
              </Section>
            </div>
            <div className="grille-2">
              <Section titre={t("parcelles.irrigation")}>
                <Tableau entetes={["Équipement", "Type", "Débit nominal", "Efficience", "Compteur"]}>
                  {p.equipements_irrigation.map((e: any) => <tr key={e.id}><td>{e.nom}</td><td>{e.type}</td><td className="num">{quantite(e.debit_nominal, e.unite_debit, 1)}</td>
                    <td>{e.efficience_pct !== null ? `${nombre(e.efficience_pct, 0)} %` : "—"} <span className="discret">{e.source_efficience}</span></td><td>{e.compteur_numero}</td></tr>)}
                </Tableau>
              </Section>
              <Section titre={t("parcelles.historique")}>
                <Tableau entetes={["Campagne", "Culture", "Variété", "Surface", "État"]}>
                  {p.historique_cultural.map((c: any) => <tr key={c.id}><td>{c.campagne}</td><td>{c.culture}</td><td>{c.variete ?? "—"}</td><td className="num">{surface(c.surface_prevue_ha)}</td><td>{c.statut}</td></tr>)}
                </Tableau>
              </Section>
            </div>
            <p className="discret">Fiche mise à jour le {dateHeure(p.modifie_le, site?.fuseau_horaire)} — version {p.version}.</p>
          </>
        );
      }}
    </Charge>
  );
}
