"use client";

import { useState } from "react";
import Link from "next/link";
import { CarteParcelles, Entite, Legende } from "@/components/CarteParcelles";
import { Avertissement, Badge, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Section, Tableau, useAction } from "@/components/ui";
import { api } from "@/lib/api";
import { libelleFuseau, surface } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

export default function PageParcelles() {
  const { sites, ex } = useSession();
  const campagnes = useEx<any[]>("/campagnes");
  const [campagne, setCampagne] = useState<string>("");
  const carte = useEx(`/carte${campagne ? `?campagne_id=${campagne}` : ""}`);
  const liste = useEx<any[]>("/parcelles");
  const [selection, setSelection] = useState<string | null>(null);

  return (
    <>
      <Entete titre={t("nav.parcelles")} sousTitre="Limites opérationnelles, surfaces, foncier et restrictions"
        actions={<Champ libelle={t("cultures.campagne")}>
          <select value={campagne} onChange={(e) => setCampagne(e.target.value)}>
            <option value="">— sans culture affichée —</option>
            {(campagnes.donnees ?? []).map((c) => <option key={c.id} value={c.id}>{c.libelle}</option>)}
          </select></Champ>} />
      <Charge etat={carte}>
        {(fc: any) => (
          <div className="grille-2">
            {sites.filter((s) => fc.features.some((f: Entite) => f.properties.site_id === s.id)).map((s) => (
              <Section key={s.id} titre={`${t("parcelles.site")} : ${s.nom}`} actions={<Badge ton="info" icone="🕒">{libelleFuseau(s.fuseau_horaire)}</Badge>}>
                <CarteParcelles legende={false} titre={`Carte des parcelles du site ${s.nom}`} selection={selection} surSelection={setSelection}
                  parcelles={fc.features.filter((f: Entite) => f.properties.site_id === s.id)}
                  zones={fc.zones.features.filter((z: Entite) => fc.features.some((f: Entite) => f.properties.site_id === s.id && f.properties.id === z.properties.parcelle_id))} />
              </Section>
            ))}
          </div>
        )}
      </Charge>
      <Section titre={t("parcelles.legende")}><Legende /></Section>
      <p className="discret">Coordonnées affichées en WGS 84 (EPSG:4326) ; la géométrie d'origine et son système sont conservés pour chaque parcelle. Aucun fond de carte externe n'est chargé.</p>
      <Section titre={t("parcelles.liste")}>
        <Charge etat={liste} vide={(d) => d.length === 0}>
          {(ps) => (
            <Tableau entetes={["Code", "Nom", "Site", t("parcelles.surfaceDeclaree"), t("parcelles.surfaceCalculee"), "Écart", t("parcelles.faireValoir"), "Restrictions"]}>
              {ps.map((p) => (
                <tr key={p.id} style={selection === p.id ? { outline: "3px solid var(--ble)" } : undefined}>
                  <td><Link href={`/parcelles/${p.id}`}><strong>{p.code}</strong></Link></td>
                  <td>{p.nom}</td>
                  <td>{sites.find((s) => s.id === p.site_id)?.nom ?? "—"}</td>
                  <td className="num">{surface(p.surface_declaree_ha)}</td>
                  <td className="num">{surface(p.surface_calculee_ha)}</td>
                  <td>{p.ecart_surface.signale && p.ecart_surface.ecart_pct !== null
                    ? <Badge ton="alerte">À vérifier ({p.ecart_surface.ecart_pct.toLocaleString("fr-FR")} %)</Badge>
                    : p.ecart_surface.ecart_pct === undefined || p.ecart_surface.ecart_pct === null ? <Badge ton="neutre" icone="?">Non comparable</Badge> : <Badge ton="ok">Dans la tolérance</Badge>}</td>
                  <td>{lib("faireValoir", p.mode_faire_valoir)}</td>
                  <td>{p.restrictions.length ? <Badge ton="alerte" icone="◆">{p.restrictions.length} restriction(s)</Badge> : "—"}</td>
                </tr>
              ))}
            </Tableau>
          )}
        </Charge>
      </Section>
      <NouvelleParcelle surCreation={() => { liste.recharger(); carte.recharger(); }} />
    </>
  );
}

function NouvelleParcelle({ surCreation }: { surCreation: () => void }) {
  const { sites, ex } = useSession();
  const a = useAction();
  const [f, setF] = useState({ site_id: "", code: "", nom: "", surface_declaree_ha: "", mode_faire_valoir: "propriete", geojson: "", srid: "2154", source: "" });
  const maj = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  async function creer() {
    const r = await a.executer(async () => {
      let geometrie;
      if (f.geojson.trim()) {
        let g;
        try { g = JSON.parse(f.geojson); } catch { throw new Error("Le GeoJSON n'est pas lisible."); }
        geometrie = { geojson: g, srid: Number(f.srid), source: f.source || "Saisie manuelle" };
      }
      return api.post(ex("/parcelles"), {
        site_id: f.site_id, code: f.code, nom: f.nom, mode_faire_valoir: f.mode_faire_valoir,
        surface_declaree_ha: f.surface_declaree_ha ? Number(f.surface_declaree_ha.replace(",", ".")) : null, geometrie,
      });
    }, "Parcelle créée.");
    if (r) surCreation();
  }
  return (
    <Depliable titre="➕ Créer une parcelle">
      <Grille>
        <Champ libelle="Site"><select value={f.site_id} onChange={maj("site_id")}><option value="">—</option>{sites.map((s) => <option key={s.id} value={s.id}>{s.nom}</option>)}</select></Champ>
        <Champ libelle="Code"><input value={f.code} onChange={maj("code")} /></Champ>
        <Champ libelle="Nom"><input value={f.nom} onChange={maj("nom")} /></Champ>
        <Champ libelle="Surface déclarée (ha)" aide="Valeur administrative : elle ne sera jamais remplacée par la surface calculée."><input inputMode="decimal" value={f.surface_declaree_ha} onChange={maj("surface_declaree_ha")} /></Champ>
        <Champ libelle={t("parcelles.faireValoir")}><select value={f.mode_faire_valoir} onChange={maj("mode_faire_valoir")}>{["propriete", "fermage", "metayage", "mise_a_disposition", "autre"].map((m) => <option key={m} value={m}>{lib("faireValoir", m)}</option>)}</select></Champ>
        <Champ libelle="Système de coordonnées (EPSG)"><select value={f.srid} onChange={maj("srid")}><option value="2154">2154 — Lambert-93</option><option value="4326">4326 — WGS 84</option><option value="2975">2975 — RGR92 / UTM 40S (La Réunion)</option></select></Champ>
        <Champ libelle="Provenance de la géométrie"><input value={f.source} onChange={maj("source")} placeholder="Relevé GNSS, export SIG…" /></Champ>
      </Grille>
      <Champ libelle="Limite (GeoJSON Polygon ou MultiPolygon)"><textarea value={f.geojson} onChange={maj("geojson")} placeholder='{"type":"Polygon","coordinates":[[[x,y],…]]}' /></Champ>
      <Message erreur={a.erreur} succes={a.succes} />
      <BoutonPermis permission="foncier:ecrire" onClick={creer} disabled={a.enCours}>{t("app.enregistrer")}</BoutonPermis>
      <Avertissement ton="info">Les géométries invalides (auto-intersection, trous hors contour…) sont refusées avec une explication plutôt que corrigées automatiquement.</Avertissement>
    </Depliable>
  );
}
