"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Badge, BadgeStatutIntervention, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Onglets, Section, Tableau, useAction } from "@/components/ui";
import { api, qs } from "@/lib/api";
import { ajouterJours, date, dateHeure, heure, isoJour, jourSemaine, lundi, surface } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { libelles, lib, t } from "@/i18n/fr";

export default function PageTravaux() {
  const [onglet, setOnglet] = useState("semaine");
  return (
    <>
      <Entete titre={t("nav.travaux")} sousTitre="Planning, interventions et comptes rendus" />
      <Onglets actif={onglet} surChange={setOnglet} onglets={[{ cle: "semaine", libelle: t("travaux.calendrier") }, { cle: "liste", libelle: t("travaux.liste") }]} />
      {onglet === "semaine" ? <Semaine /> : <Liste />}
      <NouvelleIntervention />
    </>
  );
}

function Semaine() {
  const { fuseau } = useSession();
  const [debut, setDebut] = useState(() => lundi(new Date()));
  const fin = ajouterJours(debut, 6);
  const p = useEx(`/planning${qs({ du: isoJour(debut), au: isoJour(fin) })}`);
  const jours = useMemo(() => Array.from({ length: 7 }, (_, i) => ajouterJours(debut, i)), [debut]);
  const aujourdhui = isoJour(new Date());
  return (
    <Section titre={`Semaine du ${date(isoJour(debut))} au ${date(isoJour(fin))}`} actions={<>
      <button className="bouton bouton-secondaire" onClick={() => setDebut(ajouterJours(debut, -7))}>◀ {t("travaux.semainePrecedente")}</button>
      <button className="bouton bouton-secondaire" onClick={() => setDebut(lundi(new Date()))}>Aujourd'hui</button>
      <button className="bouton bouton-secondaire" onClick={() => setDebut(ajouterJours(debut, 7))}>{t("travaux.semaineSuivante")} ▶</button>
      <input type="date" aria-label="Aller à la semaine du" onChange={(e) => e.target.value && setDebut(lundi(new Date(e.target.value + "T12:00:00Z")))} style={{ width: "auto" }} />
    </>}>
      <Charge etat={p}>
        {(d: any) => (
          <>
            <div className="semaine">
              {jours.map((j) => {
                const k = isoJour(j);
                const its = d.interventions.filter((i: any) => i.date_prevue === k);
                const restr = d.restrictions_materiel.filter((r: any) => r.du.slice(0, 10) <= k && (!r.au || r.au.slice(0, 10) >= k));
                return (
                  <div key={k} className={`jour ${k === aujourdhui ? "aujourdhui" : ""}`}>
                    <h3>{jourSemaine(j)}{k === aujourdhui ? " — aujourd'hui" : ""}</h3>
                    {its.map((i: any) => (
                      <Link key={i.id} className="tuile" href={`/travaux/${i.id}`}>
                        <strong>{i.numero}</strong> · {lib("typeIntervention", i.type)}<br />
                        {i.parcelle.code}{i.affectations[0] ? ` · ${heure(i.affectations[0].debut, fuseau(i.parcelle.site_id))}` : ""}<br />
                        <BadgeStatutIntervention statut={i.statut} />
                      </Link>
                    ))}
                    {restr.map((r: any) => <div key={r.id + k} className="tuile restriction">⛔ <strong>{r.materiel}</strong><br />{r.motif}</div>)}
                  </div>
                );
              })}
            </div>
            {d.interventions.length === 0 && <p className="vide">{t("travaux.aucuneIntervention")}</p>}
            {d.restrictions_materiel.length > 0 && <p className="discret">⛔ Les cases « restriction » signalent un matériel immobilisé (maintenance) ou bloqué (défaut) : il ne peut pas être affecté.</p>}
          </>
        )}
      </Charge>
    </Section>
  );
}

function Liste() {
  const [filtres, setFiltres] = useState({ statut: "", type: "", du: "", au: "" });
  const its = useEx<any[]>(`/interventions${qs(filtres)}`);
  return (
    <Section titre={t("travaux.liste")}>
      <Grille>
        <Champ libelle="État"><select value={filtres.statut} onChange={(e) => setFiltres({ ...filtres, statut: e.target.value })}><option value="">Tous</option>{Object.entries(libelles.statutIntervention).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>
        <Champ libelle="Type"><select value={filtres.type} onChange={(e) => setFiltres({ ...filtres, type: e.target.value })}><option value="">Tous</option>{Object.entries(libelles.typeIntervention).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>
        <Champ libelle="Du"><input type="date" value={filtres.du} onChange={(e) => setFiltres({ ...filtres, du: e.target.value })} /></Champ>
        <Champ libelle="Au"><input type="date" value={filtres.au} onChange={(e) => setFiltres({ ...filtres, au: e.target.value })} /></Champ>
      </Grille>
      <Charge etat={its} vide={(d) => d.length === 0}>
        {(l) => (
          <Tableau entetes={["N°", "Date prévue", "Type", "Parcelle", "Culture", "Surface", "Origine", "État"]}>
            {l.map((i) => (
              <tr key={i.id}>
                <td><Link href={`/travaux/${i.id}`}><strong>{i.numero}</strong></Link></td>
                <td>{date(i.date_prevue)}</td>
                <td>{lib("typeIntervention", i.type)}{i.libelle && <div className="discret">{i.libelle}</div>}</td>
                <td>{i.parcelle.code} {i.parcelle.nom}</td>
                <td>{i.cycle?.culture ?? "—"}</td>
                <td className="num">{surface(i.surface_prevue_ha)}</td>
                <td>{i.origine === "terrain" ? <Badge ton="info" icone="📱">Terrain</Badge> : lib("origine", i.origine)}</td>
                <td><BadgeStatutIntervention statut={i.statut} /></td>
              </tr>
            ))}
          </Tableau>
        )}
      </Charge>
    </Section>
  );
}

function NouvelleIntervention() {
  const { ex } = useSession();
  const parcelles = useEx<any[]>("/parcelles");
  const articles = useEx<any[]>("/articles");
  const [f, setF] = useState<Record<string, string>>({ type: "travail_sol" });
  const cycles = useEx<any[]>(f.parcelle_id ? `/cycles?parcelle_id=${f.parcelle_id}` : null);
  const a = useAction();
  const maj = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  async function creer() {
    const r = await a.executer(() => api.post(ex("/interventions"), {
      parcelle_id: f.parcelle_id, cycle_id: f.cycle_id || null, type: f.type, libelle: f.libelle || null, date_prevue: f.date_prevue || null,
      duree_prevue_h: f.duree ? Number(f.duree.replace(",", ".")) : null,
      produits: f.article_id ? [{ article_id: f.article_id, dose_prevue: Number((f.dose ?? "0").replace(",", ".")), unite_dose: f.unite_dose || "kg/ha" }] : [],
    }), "Intervention planifiée.");
    if (r) window.location.href = `/travaux/${r.id}`;
  }
  return (
    <Depliable titre={`➕ ${t("travaux.nouvelle")}`}>
      <Grille>
        <Champ libelle="Parcelle"><select value={f.parcelle_id ?? ""} onChange={maj("parcelle_id")}><option value="">—</option>{(parcelles.donnees ?? []).map((p) => <option key={p.id} value={p.id}>{p.code} {p.nom}</option>)}</select></Champ>
        <Champ libelle="Cycle cultural"><select value={f.cycle_id ?? ""} onChange={maj("cycle_id")}><option value="">— aucun —</option>{(cycles.donnees ?? []).map((c) => <option key={c.id} value={c.id}>{c.culture} ({c.campagne_id.slice(0, 4)}…)</option>)}</select></Champ>
        <Champ libelle="Type"><select value={f.type} onChange={maj("type")}>{Object.entries(libelles.typeIntervention).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>
        <Champ libelle="Libellé"><input value={f.libelle ?? ""} onChange={maj("libelle")} /></Champ>
        <Champ libelle="Date prévue"><input type="date" value={f.date_prevue ?? ""} onChange={maj("date_prevue")} /></Champ>
        <Champ libelle="Durée prévue (h)"><input inputMode="decimal" value={f.duree ?? ""} onChange={maj("duree")} /></Champ>
        <Champ libelle="Produit prévu (facultatif)"><select value={f.article_id ?? ""} onChange={maj("article_id")}><option value="">—</option>{(articles.donnees ?? []).filter((x) => !["produit_recolte", "produit_fini"].includes(x.categorie)).map((x) => <option key={x.id} value={x.id}>{x.libelle}</option>)}</select></Champ>
        <Champ libelle="Dose prévue"><input inputMode="decimal" value={f.dose ?? ""} onChange={maj("dose")} /></Champ>
        <Champ libelle="Unité de dose"><select value={f.unite_dose ?? "kg/ha"} onChange={maj("unite_dose")}>{["kg/ha", "g/ha", "t/ha", "L/ha", "mL/ha", "u/ha", "plants/ha"].map((u) => <option key={u}>{u}</option>)}</select></Champ>
      </Grille>
      <Message erreur={a.erreur} succes={a.succes} />
      <BoutonPermis permission="interventions:ecrire" onClick={creer} disabled={a.enCours}>{t("app.enregistrer")}</BoutonPermis>
    </Depliable>
  );
}
