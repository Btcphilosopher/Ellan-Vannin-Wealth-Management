"use client";

import { use, useState } from "react";
import Link from "next/link";
import { Avertissement, Badge, BadgeControle, BadgeStatutIntervention, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Section, Tableau, Valeurs, useAction } from "@/components/ui";
import { api } from "@/lib/api";
import { date, dateHeure, dose, libelleFuseau, nombre, quantite, surface, versIso, versLocal } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

export default function DetailIntervention({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const etat = useEx(`/interventions/${id}`);
  const { fuseau, ex } = useSession();
  const a = useAction();
  return (
    <Charge etat={etat}>
      {(it: any) => {
        const tz = fuseau(it.parcelle.site_id);
        const action = async (chemin: string, msg: string, corps?: unknown) => { if (await a.executer(() => api.post(ex(`/interventions/${id}${chemin}`), corps), msg)) etat.recharger(); };
        return (
          <>
            <Entete titre={`${it.numero} — ${it.libelle_type}`} sousTitre={<>{it.libelle ?? ""} · Parcelle <Link href={`/parcelles/${it.parcelle.id}`}>{it.parcelle.code} {it.parcelle.nom}</Link>{it.cycle ? ` · ${it.cycle.culture}${it.cycle.variete ? " (" + it.cycle.variete + ")" : ""}` : ""} · horaires en {libelleFuseau(tz)} · <Link href="/travaux">{t("app.retour")}</Link></>}
              actions={<>
                <BadgeStatutIntervention statut={it.statut} />
                {["planifiee"].includes(it.statut) && <BoutonPermis permission="interventions:ecrire" className="bouton bouton-secondaire" onClick={async () => {
                  const r = await a.executer(() => api.post(ex(`/interventions/${id}/reservations`)), "");
                  if (r) {
                    const txt = r.lignes.map((l: any) => `${l.article} : ${l.statut === "reserve" ? "réservé" : l.statut === "deja_reserve" ? "déjà réservé" : l.statut === "rupture" ? "⚠ RUPTURE — " + l.message : "quantité prévue manquante"}`).join(" · ");
                    if (r.ruptures.length) a.setErreur(txt); else a.setSucces(txt);
                    etat.recharger();
                  }
                }}>{t("travaux.reserver")}</BoutonPermis>}
                {it.statut === "planifiee" && <BoutonPermis permission="interventions:realiser" onClick={() => action("/demarrage", "Intervention démarrée.")}>▶ {t("travaux.demarrer")}</BoutonPermis>}
                {["planifiee", "en_cours", "proposee"].includes(it.statut) && <BoutonPermis permission="interventions:ecrire" className="bouton bouton-danger" onClick={() => { if (window.confirm("Annuler cette intervention ? Les réservations et affectations seront libérées.")) action("/annulation", "Intervention annulée."); }}>✗ {t("travaux.annulerIntervention")}</BoutonPermis>}
              </>} />
            <Message erreur={a.erreur} succes={a.succes} />
            <div className="grille-2">
              <Section titre="Planification et réalisation">
                <Valeurs items={[
                  ["Identifiant", <span className="code">{it.numero}</span>], ["Type", it.libelle_type], ["Date prévue", date(it.date_prevue)],
                  ["Début réel", dateHeure(it.debut_reel, tz)], ["Fin réelle", dateHeure(it.fin_reelle, tz)],
                  ["Surface prévue", surface(it.surface_prevue_ha)], ["Surface réalisée", surface(it.surface_realisee_ha)],
                  ["Durée prévue", it.duree_prevue_h !== null ? quantite(it.duree_prevue_h, "h", 1) : "—"], ["Compétence requise", it.competence_requise ?? "—"],
                  ["Origine", lib("origine", it.origine)], ["Version de l'enregistrement", it.version],
                ]} />
                {it.notes && <><h3>Notes</h3><p style={{ whiteSpace: "pre-wrap" }}>{it.notes}</p></>}
              </Section>
              <Meteo it={it} tz={tz} />
            </div>
            <Section titre={t("travaux.produits")}>
              <p className="discret">Trois valeurs distinctes : l'application <strong>prévue</strong>, la <strong>consigne</strong> déclarée pour la machine (Terroir n'envoie aucune commande) et la quantité <strong>effectivement mesurée</strong>.</p>
              {it.produits.length === 0 ? <p className="vide">Aucun produit.</p> : (
                <Tableau entetes={["Produit", "Dose prévue", `${t("travaux.prevu")} (quantité)`, t("travaux.consigne"), t("travaux.mesure"), "Réservation"]}>
                  {it.produits.map((p: any) => (
                    <tr key={p.id}>
                      <td>{p.article}{p.reglemente && <> <Badge ton="info" icone="§">Réglementé</Badge></>}</td>
                      <td className="num">{dose(p.dose_prevue, p.unite_dose)}</td>
                      <td className="num">{quantite(p.quantite_prevue, p.unite_quantite)}</td>
                      <td className="num">{p.consigne_machine !== null ? <>{dose(p.consigne_machine, p.unite_consigne)}<div className="discret">{p.source_consigne === "telemetrie_simulee" ? "télémétrie simulée" : p.source_consigne ?? ""}</div></> : "—"}</td>
                      <td className="num">{p.quantite_mesuree !== null ? <>{quantite(p.quantite_mesuree, p.unite_quantite)}<div className="discret">{p.methode_mesure}</div></> : <span className="discret">non mesuré</span>}</td>
                      <td>{p.reservation_statut ? <Badge ton={p.reservation_statut === "active" ? "info" : p.reservation_statut === "consommee" ? "ok" : "neutre"}>{p.reservation_statut === "active" ? "Réservé" : p.reservation_statut === "consommee" ? "Consommé" : "Annulée"}</Badge> : <Badge ton="neutre" icone="○">Non réservé</Badge>}</td>
                    </tr>
                  ))}
                </Tableau>
              )}
            </Section>
            <Affectations it={it} tz={tz} surChange={etat.recharger} />
            {(it.type === "traitement_phyto" || it.produits.some((p: any) => p.reglemente)) && <Verification it={it} surChange={etat.recharger} />}
            {["planifiee", "en_cours", "proposee"].includes(it.statut) && <CompteRendu it={it} tz={tz} surFin={etat.recharger} />}
          </>
        );
      }}
    </Charge>
  );
}

function Meteo({ it, tz }: { it: any; tz: string }) {
  const m = it.meteo ?? it.meteo_disponible;
  const enregistree = !!it.meteo;
  return (
    <Section titre={`${t("travaux.meteo")} ${enregistree ? "(enregistrée avec le compte rendu)" : "(données disponibles)"}`}>
      {!m ? <p className="vide">—</p> : (
        <>
          <Badge ton={m.nature === "observee" ? "ok" : m.nature === "prevue" ? "attente" : "critique"} icone={m.nature === "indisponible" ? "∅" : m.nature === "prevue" ? "≈" : "☁"}>{lib("meteo", m.nature)}</Badge>
          {m.message && <p>{m.message}</p>}
          {m.valeurs && <Valeurs items={[
            ["Température", `${nombre(m.valeurs.temperature_min_c, 1)} à ${nombre(m.valeurs.temperature_max_c, 1)} °C`], ["Pluie", quantite(m.valeurs.pluie_mm, "mm", 1)],
            ["Vent moyen", quantite(m.valeurs.vent_moyen_kmh, "km/h", 0)], ["Rafales", quantite(m.valeurs.rafales_kmh, "km/h", 0)],
            ["Humidité relative", m.valeurs.humidite_relative_pct !== null ? `${nombre(m.valeurs.humidite_relative_pct, 0)} %` : "—"], ["ET0", quantite(m.valeurs.et0_mm, "mm", 1)],
          ]} />}
          {m.source && <p className="discret">Source : {m.source}{m.simulee ? " — données simulées" : ""} · reçu le {dateHeure(m.recu_le, tz)} · fraîcheur {nombre(m.fraicheur_h, 1)} h{m.emis_le ? ` · prévision émise le ${dateHeure(m.emis_le, tz)}` : ""}</p>}
          {m.constatee_par_operateur && <Avertissement ton="info" titre="Conditions constatées par l'opérateur">{m.constatee_par_operateur.conditions}</Avertissement>}
        </>
      )}
    </Section>
  );
}

function Affectations({ it, tz, surChange }: { it: any; tz: string; surChange: () => void }) {
  const { ex } = useSession();
  const materiels = useEx<any[]>("/materiels");
  const membres = useEx<any[]>("/membres");
  const a = useAction();
  const jour = it.date_prevue ?? new Date().toISOString().slice(0, 10);
  const [f, setF] = useState({ ressource_type: "materiel", ressource_id: "", debut: `${jour}T08:00`, fin: `${jour}T12:00` });
  const options = f.ressource_type === "materiel" ? (materiels.donnees ?? []).map((m) => [m.id, `${m.libelle} ${m.disponibilite.disponible ? "" : "— ⛔ indisponible"}`]) : (membres.donnees ?? []).map((m) => [m.id, `${m.prenom} ${m.nom} (${m.statut})`]);
  async function affecter() {
    const r = await a.executer(() => api.post(ex(`/interventions/${it.id}/affectations`), { ...f, debut: versIso(f.debut, tz), fin: versIso(f.fin, tz) }), "Ressource affectée.");
    if (r) surChange();
  }
  return (
    <Section titre={t("travaux.affectations")}>
      {it.affectations.length === 0 ? <p className="vide">Aucune ressource affectée.</p> : (
        <Tableau entetes={["Ressource", "Nature", "Début", "Fin", ""]}>
          {it.affectations.map((af: any) => (
            <tr key={af.id}><td>{af.nom}</td><td>{af.ressource_type === "materiel" ? "🚜 Matériel" : "👤 Personne"}</td><td>{dateHeure(af.debut, tz)}</td><td>{dateHeure(af.fin, tz)}</td>
              <td>{it.statut !== "realisee" && <BoutonPermis permission="interventions:ecrire" className="bouton bouton-petit bouton-secondaire" onClick={async () => { if (await a.executer(() => api.del(ex(`/affectations/${af.id}`)), "Affectation retirée.")) surChange(); }}>Retirer</BoutonPermis>}</td></tr>
          ))}
        </Tableau>
      )}
      {it.statut !== "realisee" && it.statut !== "annulee" && (
        <Depliable titre={`➕ ${t("travaux.affecter")}`}>
          <Grille>
            <Champ libelle="Nature"><select value={f.ressource_type} onChange={(e) => setF({ ...f, ressource_type: e.target.value, ressource_id: "" })}><option value="materiel">Matériel</option><option value="membre">Personne</option></select></Champ>
            <Champ libelle="Ressource"><select value={f.ressource_id} onChange={(e) => setF({ ...f, ressource_id: e.target.value })}><option value="">—</option>{options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Champ>
            <Champ libelle={`Début (${libelleFuseau(tz)})`}><input type="datetime-local" value={f.debut} onChange={(e) => setF({ ...f, debut: e.target.value })} /></Champ>
            <Champ libelle={`Fin (${libelleFuseau(tz)})`}><input type="datetime-local" value={f.fin} onChange={(e) => setF({ ...f, fin: e.target.value })} /></Champ>
          </Grille>
          <p className="discret">Terroir refuse les affectations simultanées d'une même ressource, le matériel immobilisé ou en défaut bloquant et les personnes sans compétence valide requise.</p>
          <BoutonPermis permission="interventions:ecrire" onClick={affecter} disabled={a.enCours || !f.ressource_id}>Affecter</BoutonPermis>
        </Depliable>
      )}
      <Message erreur={a.erreur} succes={a.succes} />
    </Section>
  );
}

function Verification({ it, surChange }: { it: any; surChange: () => void }) {
  const { ex } = useSession();
  const a = useAction();
  const v = it.verification_reglementaire;
  const [val, setVal] = useState({ decision: "validee", qualification: "", commentaire: "" });
  return (
    <Section titre={t("travaux.verification")} actions={<BoutonPermis permission="interventions:lire" className="bouton bouton-secondaire" onClick={async () => { if (await a.executer(() => api.post(ex(`/interventions/${it.id}/verification`)), "Vérification effectuée.")) surChange(); }}>🔎 {t("travaux.lancerVerification")}</BoutonPermis>}>
      <Message erreur={a.erreur} succes={a.succes} />
      {!v ? <p className="vide">Aucune vérification enregistrée pour l'instant.</p> : (
        <>
          <Avertissement ton="alerte" titre="Portée de la vérification">{v.avertissement}</Avertissement>
          {v.sources.map((s: any, i: number) => (
            <p key={i}>Source : <strong>{s.nom}</strong> (version {s.version ?? "—"}, date d'effet {date(s.date_effet)}) {s.officielle ? <Badge ton="ok">{t("travaux.sourceOfficielle")}</Badge> : <Badge ton="critique" icone="!">{t("travaux.sourceNonOfficielle")}</Badge>}
              {s.avertissement && <><br /><span className="discret">{s.avertissement}</span></>}</p>
          ))}
          <Tableau entetes={["Contrôle", "Résultat", "Détail"]}>
            {v.controles.map((c: any, i: number) => <tr key={i}><td>{c.libelle}</td><td><BadgeControle statut={c.statut} /></td><td>{c.detail}</td></tr>)}
          </Tableau>
          <p><Badge ton={v.nombre_alertes ? "critique" : "ok"}>{v.nombre_alertes} alerte(s)</Badge> <Badge ton="neutre" icone="?">{v.nombre_non_disponibles} contrôle(s) non disponible(s)</Badge> <span className="discret">vérifié le {date(v.verifie_le)}</span></p>
          <h3>{t("travaux.nonCouverts")}</h3>
          <ul>{v.controles_non_couverts.map((c: string, i: number) => <li key={i}>✗ {c}</li>)}</ul>
          <h3>{t("travaux.validationPro")}</h3>
          {v.validation_professionnelle ? (
            <p><Badge ton={v.validation_professionnelle.decision === "validee" ? "ok" : "critique"}>{v.validation_professionnelle.decision === "validee" ? "Validée" : v.validation_professionnelle.decision === "refusee" ? "Refusée" : "À revoir"}</Badge> le {date(v.validation_professionnelle.le)} — {v.validation_professionnelle.qualification}{v.validation_professionnelle.commentaire ? ` : « ${v.validation_professionnelle.commentaire} »` : ""}</p>
          ) : <Badge ton="attente">En attente de validation professionnelle</Badge>}
        </>
      )}
      <Depliable titre={t("travaux.valider")}>
        <Grille>
          <Champ libelle="Décision"><select value={val.decision} onChange={(e) => setVal({ ...val, decision: e.target.value })}><option value="validee">Valider</option><option value="a_revoir">À revoir</option><option value="refusee">Refuser</option></select></Champ>
          <Champ libelle="Qualification"><input value={val.qualification} onChange={(e) => setVal({ ...val, qualification: e.target.value })} placeholder="Ex. conseiller titulaire du Certiphyto conseil" /></Champ>
          <Champ libelle="Commentaire"><input value={val.commentaire} onChange={(e) => setVal({ ...val, commentaire: e.target.value })} /></Champ>
        </Grille>
        <BoutonPermis permission="phyto:valider" disabled={a.enCours || !val.qualification} onClick={async () => { if (await a.executer(() => api.post(ex(`/interventions/${it.id}/validation-professionnelle`), val), "Validation enregistrée.")) surChange(); }}>Enregistrer la décision</BoutonPermis>
      </Depliable>
    </Section>
  );
}

function CompteRendu({ it, tz, surFin }: { it: any; tz: string; surFin: () => void }) {
  const { ex, adhesion } = useSession();
  const membres = useEx<any[]>("/membres");
  const a = useAction();
  const jour = it.date_prevue ?? new Date().toISOString().slice(0, 10);
  const [f, setF] = useState<any>({
    debut: versLocal(it.debut_reel, tz) || `${jour}T08:00`, fin: `${jour}T12:00`, surface: it.surface_prevue_ha ?? "", notes: "", conditions: "",
    produits: Object.fromEntries(it.produits.map((p: any) => [p.id, { quantite: p.quantite_prevue ?? "", methode: "pesee", consigne: p.dose_prevue ?? "" }])),
    membre: adhesion.membre_equipe_id ?? "", heures: "",
  });
  const n = (v: any) => (v === "" || v === null || v === undefined ? null : Number(String(v).replace(",", ".")));
  async function envoyer() {
    const corps = {
      version: it.version, debut_reel: versIso(f.debut, tz), fin_reelle: versIso(f.fin, tz), surface_realisee_ha: n(f.surface),
      produits: it.produits.map((p: any) => ({ intervention_produit_id: p.id, quantite_mesuree: n(f.produits[p.id].quantite) ?? 0, methode_mesure: f.produits[p.id].methode,
        consigne_machine: n(f.produits[p.id].consigne), unite_consigne: p.unite_dose, source_consigne: "saisie" })),
      temps: f.membre && n(f.heures) ? [{ membre_id: f.membre, heures: n(f.heures) }] : [],
      meteo_saisie: f.conditions ? { conditions: f.conditions } : null, notes: f.notes || null,
    };
    if (await a.executer(() => api.post(ex(`/interventions/${it.id}/realisation`), corps), "Compte rendu enregistré ; les stocks ont été mis à jour.")) surFin();
  }
  return (
    <Section titre={t("travaux.compteRendu")}>
      <Grille>
        <Champ libelle={`Début réel (${libelleFuseau(tz)})`}><input type="datetime-local" value={f.debut} onChange={(e) => setF({ ...f, debut: e.target.value })} /></Champ>
        <Champ libelle={`Fin réelle (${libelleFuseau(tz)})`}><input type="datetime-local" value={f.fin} onChange={(e) => setF({ ...f, fin: e.target.value })} /></Champ>
        <Champ libelle="Surface réalisée (ha)"><input inputMode="decimal" value={f.surface} onChange={(e) => setF({ ...f, surface: e.target.value })} /></Champ>
        <Champ libelle="Personne"><select value={f.membre} onChange={(e) => setF({ ...f, membre: e.target.value })}><option value="">—</option>{(membres.donnees ?? []).map((m) => <option key={m.id} value={m.id}>{m.prenom} {m.nom}</option>)}</select></Champ>
        <Champ libelle="Heures travaillées"><input inputMode="decimal" value={f.heures} onChange={(e) => setF({ ...f, heures: e.target.value })} /></Champ>
      </Grille>
      {it.produits.map((p: any) => (
        <fieldset key={p.id} style={{ border: "1px solid var(--trait)", borderRadius: 8, marginBottom: ".5rem" }}>
          <legend><strong>{p.article}</strong> — prévu {quantite(p.quantite_prevue, p.unite_quantite)}</legend>
          <Grille>
            <Champ libelle={`Quantité mesurée (${p.unite_quantite})`}><input inputMode="decimal" value={f.produits[p.id].quantite} onChange={(e) => setF({ ...f, produits: { ...f.produits, [p.id]: { ...f.produits[p.id], quantite: e.target.value } } })} /></Champ>
            <Champ libelle="Méthode de mesure"><select value={f.produits[p.id].methode} onChange={(e) => setF({ ...f, produits: { ...f.produits, [p.id]: { ...f.produits[p.id], methode: e.target.value } } })}>
              {[["pesee", "Pesée"], ["compteur", "Compteur"], ["jauge", "Jauge"], ["estimation", "Estimation"]].map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Champ>
            <Champ libelle={`Consigne machine (${p.unite_dose ?? "—"})`} aide="Valeur réglée sur la machine, déclarée par l'opérateur."><input inputMode="decimal" value={f.produits[p.id].consigne} onChange={(e) => setF({ ...f, produits: { ...f.produits, [p.id]: { ...f.produits[p.id], consigne: e.target.value } } })} /></Champ>
          </Grille>
        </fieldset>
      ))}
      <Champ libelle="Conditions météo constatées (si la source est indisponible)"><input value={f.conditions} onChange={(e) => setF({ ...f, conditions: e.target.value })} /></Champ>
      <Champ libelle="Notes"><textarea value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Champ>
      <Message erreur={a.erreur} succes={a.succes} />
      <BoutonPermis permission={it.statut === "proposee" ? "interventions:ecrire" : "interventions:realiser"} onClick={envoyer} disabled={a.enCours}>✓ Enregistrer la réalisation</BoutonPermis>
    </Section>
  );
}
