"use client";

import { useState } from "react";
import { Avertissement, BadgeCommande, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Onglets, Section, Tableau, useAction } from "@/components/ui";
import { api } from "@/lib/api";
import { date, euros, quantite } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

const n = (v?: string) => (v ? Number(v.replace(",", ".")) : null);

export default function PageAchats() {
  const [onglet, setOnglet] = useState("commandes");
  return (
    <>
      <Entete titre={t("nav.achats")} sousTitre="Demande d'achat → commande → réception → référence de facture fournisseur" />
      <Onglets actif={onglet} surChange={setOnglet} onglets={[{ cle: "demandes", libelle: t("achats.demandes") }, { cle: "commandes", libelle: t("achats.commandes") }, { cle: "factures", libelle: t("achats.factures") }]} />
      {onglet === "demandes" && <Demandes />}
      {onglet === "commandes" && <Commandes />}
      {onglet === "factures" && <Factures />}
    </>
  );
}

function Demandes() {
  const { ex } = useSession();
  const d = useEx<any[]>("/demandes-achat");
  const articles = useEx<any[]>("/articles");
  const fournisseurs = useEx<any[]>("/fournisseurs");
  const a = useAction();
  const [f, setF] = useState<Record<string, string>>({ unite: "kg" });
  const [cmd, setCmd] = useState<Record<string, string>>({});
  const art = (id: string) => articles.donnees?.find((x) => x.id === id);
  return (
    <Section titre={t("achats.demandes")}>
      <Message erreur={a.erreur} succes={a.succes} />
      <Charge etat={d} vide={(x) => x.length === 0}>
        {(ds) => (
          <Tableau entetes={["N°", "Motif", "Lignes", "Origine", "État", ""]}>
            {ds.map((x) => (
              <tr key={x.id}>
                <td><strong>{x.numero}</strong><div className="discret">{date(x.cree_le)}</div></td><td>{x.motif ?? "—"}</td>
                <td>{x.lignes.map((l: any, i: number) => <div key={i}>{art(l.article_id)?.libelle ?? "…"} : {quantite(l.quantite, l.unite)}{l.date_besoin ? ` pour le ${date(l.date_besoin)}` : ""}</div>)}</td>
                <td>{x.origine === "calcul_besoins" ? "Calcul des besoins" : "Manuelle"}</td>
                <td><BadgeCommande statut={x.statut} /></td>
                <td>
                  {x.statut === "soumise" && <BoutonPermis permission="achats:ecrire" className="bouton bouton-petit" onClick={async () => { if (await a.executer(() => api.post(ex(`/demandes-achat/${x.id}/approbation`)), "Demande approuvée.")) d.recharger(); }}>{t("achats.approuver")}</BoutonPermis>}
                  {["soumise", "approuvee"].includes(x.statut) && (
                    <Depliable titre={t("achats.commander")}>
                      <Champ libelle="Fournisseur"><select value={cmd.f ?? ""} onChange={(e) => setCmd({ ...cmd, f: e.target.value })}><option value="">—</option>{(fournisseurs.donnees ?? []).map((fo) => <option key={fo.id} value={fo.id}>{fo.nom}</option>)}</select></Champ>
                      <Champ libelle="Prix unitaire (€ HT par unité commandée)"><input inputMode="decimal" value={cmd.p ?? ""} onChange={(e) => setCmd({ ...cmd, p: e.target.value })} /></Champ>
                      <BoutonPermis permission="achats:ecrire" disabled={!cmd.f} onClick={async () => {
                        if (await a.executer(() => api.post(ex("/commandes-fournisseurs"), { fournisseur_id: cmd.f, demande_id: x.id, date_commande: new Date().toISOString().slice(0, 10), lignes: x.lignes.map((l: any) => ({ article_id: l.article_id, quantite: l.quantite, unite: l.unite, prix_unitaire_eur: n(cmd.p) })) }), "Commande passée.")) d.recharger();
                      }}>Créer la commande</BoutonPermis>
                    </Depliable>
                  )}
                </td>
              </tr>
            ))}
          </Tableau>
        )}
      </Charge>
      <Depliable titre={`➕ ${t("achats.nouvelleDemande")}`}>
        <Grille>
          <Champ libelle="Article"><select value={f.article_id ?? ""} onChange={(e) => setF({ ...f, article_id: e.target.value, unite: art(e.target.value)?.unite_stock ?? "kg" })}><option value="">—</option>{(articles.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.libelle}</option>)}</select></Champ>
          <Champ libelle="Quantité"><input inputMode="decimal" value={f.q ?? ""} onChange={(e) => setF({ ...f, q: e.target.value })} /></Champ>
          <Champ libelle="Unité"><select value={f.unite} onChange={(e) => setF({ ...f, unite: e.target.value })}>{["kg", "t", "q", "L", "hL", "u"].map((u) => <option key={u}>{u}</option>)}</select></Champ>
          <Champ libelle="Date de besoin"><input type="date" value={f.date ?? ""} onChange={(e) => setF({ ...f, date: e.target.value })} /></Champ>
          <Champ libelle="Motif"><input value={f.motif ?? ""} onChange={(e) => setF({ ...f, motif: e.target.value })} /></Champ>
        </Grille>
        <BoutonPermis permission="achats:ecrire" disabled={!f.article_id || !f.q} onClick={async () => {
          if (await a.executer(() => api.post(ex("/demandes-achat"), { motif: f.motif || null, lignes: [{ article_id: f.article_id, quantite: n(f.q), unite: f.unite, date_besoin: f.date || null }] }), "Demande créée.")) d.recharger();
        }}>{t("app.enregistrer")}</BoutonPermis>
      </Depliable>
    </Section>
  );
}

function Commandes() {
  const c = useEx<any[]>("/commandes-fournisseurs");
  return (
    <Section titre={t("achats.commandes")}>
      <Charge etat={c} vide={(x) => x.length === 0}>
        {(cs) => <>{cs.map((x) => <Commande key={x.id} c={x} surChange={c.recharger} />)}</>}
      </Charge>
    </Section>
  );
}

function Commande({ c, surChange }: { c: any; surChange: () => void }) {
  const { ex } = useSession();
  const empl = useEx<any[]>("/emplacements");
  const a = useAction();
  const [rec, setRec] = useState<Record<string, Record<string, string>>>({});
  const [bl, setBl] = useState("");
  return (
    <div className="carte">
      <div className="carte-entete"><h3 style={{ margin: 0 }}>{c.numero} — {c.fournisseur}</h3><BadgeCommande statut={c.statut} /></div>
      <p className="discret">Commandée le {date(c.date_commande)} · livraison prévue {date(c.date_livraison_prevue)} · montant {euros(c.montant_ht_eur)} HT</p>
      <Tableau entetes={["Article", "Commandé", "Reçu", "Reste à recevoir", "Prix unitaire HT"]}>
        {c.lignes.map((l: any) => <tr key={l.id}><td>{l.article}</td><td className="num">{quantite(l.quantite, l.unite)}</td><td className="num">{quantite(l.quantite_recue, l.unite)}</td><td className="num">{quantite(l.reste_a_recevoir, l.unite)}</td><td className="num">{euros(l.prix_unitaire_eur)}</td></tr>)}
      </Tableau>
      {c.receptions.map((r: any) => <p key={r.id}>📦 Réception du {date(r.date_reception)} (BL {r.bon_livraison ?? "—"}) : {r.lignes.map((l: any) => `${l.lot} — ${quantite(l.quantite, l.unite)}`).join(", ")}</p>)}
      {c.factures.map((f: any) => <p key={f.id}>🧾 Facture fournisseur {f.numero_fournisseur} du {date(f.date_facture)} : {euros(f.montant_ht_eur)} HT</p>)}
      {["envoyee", "partiellement_recue"].includes(c.statut) && (
        <Depliable titre={`📦 ${t("achats.receptionner")}`}>
          <Champ libelle="N° de bon de livraison"><input value={bl} onChange={(e) => setBl(e.target.value)} /></Champ>
          {c.lignes.filter((l: any) => l.reste_a_recevoir > 0).map((l: any) => {
            const v = rec[l.id] ?? { q: String(l.reste_a_recevoir), u: l.unite };
            const m = (k: string, val: string) => setRec({ ...rec, [l.id]: { ...v, [k]: val } });
            return (
              <fieldset key={l.id} style={{ border: "1px solid var(--trait)", borderRadius: 8 }}><legend>{l.article}</legend>
                <Grille>
                  <Champ libelle="Quantité reçue"><input inputMode="decimal" value={v.q} onChange={(e) => m("q", e.target.value)} /></Champ>
                  <Champ libelle="Unité"><select value={v.u} onChange={(e) => m("u", e.target.value)}>{["kg", "t", "q", "L", "hL", "u"].map((u) => <option key={u}>{u}</option>)}</select></Champ>
                  <Champ libelle="Emplacement"><select value={v.e ?? ""} onChange={(e) => m("e", e.target.value)}><option value="">—</option>{(empl.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.code} — {x.nom}</option>)}</select></Champ>
                  <Champ libelle="N° de lot fournisseur"><input value={v.lf ?? ""} onChange={(e) => m("lf", e.target.value)} /></Champ>
                  <Champ libelle="Péremption"><input type="date" value={v.p ?? ""} onChange={(e) => m("p", e.target.value)} /></Champ>
                </Grille>
              </fieldset>
            );
          })}
          <Message erreur={a.erreur} succes={a.succes} />
          <BoutonPermis permission="stocks:ecrire" onClick={async () => {
            const lignes = c.lignes.filter((l: any) => l.reste_a_recevoir > 0).map((l: any) => { const v = rec[l.id] ?? { q: String(l.reste_a_recevoir), u: l.unite };
              return { ligne_commande_id: l.id, quantite: n(v.q), unite: v.u, emplacement_id: v.e, numero_lot_fournisseur: v.lf || null, date_peremption: v.p || null }; });
            if (await a.executer(() => api.post(ex(`/commandes-fournisseurs/${c.id}/receptions`), { bon_livraison: bl || null, lignes }), "Réception enregistrée : lots créés et stock mis à jour.")) surChange();
          }}>Enregistrer la réception</BoutonPermis>
        </Depliable>
      )}
    </div>
  );
}

function Factures() {
  const { ex } = useSession();
  const f = useEx<any[]>("/factures-fournisseurs");
  const fournisseurs = useEx<any[]>("/fournisseurs");
  const a = useAction();
  const [x, setX] = useState<Record<string, string>>({ categorie: "intrants" });
  return (
    <Section titre={t("achats.factures")}>
      <Avertissement ton="info">Terroir conserve la référence des factures fournisseurs pour les coûts et la trésorerie. La pièce comptable reste tenue dans votre comptabilité.</Avertissement>
      <Charge etat={f} vide={(d) => d.length === 0}>
        {(fs) => (
          <Tableau entetes={["N° fournisseur", "Fournisseur", "Date", "HT", "TVA", "Catégorie de charge", "Payée le"]}>
            {fs.map((y) => <tr key={y.id}><td>{y.numero_fournisseur}</td><td>{fournisseurs.donnees?.find((z) => z.id === y.fournisseur_id)?.nom ?? "…"}</td><td>{date(y.date_facture)}</td>
              <td className="num">{euros(y.montant_ht_eur)}</td><td className="num">{euros(y.montant_tva_eur)}</td><td>{lib("categorieCharge", y.categorie_charge)}</td><td>{y.date_paiement ? date(y.date_paiement) : "non payée"}</td></tr>)}
          </Tableau>
        )}
      </Charge>
      <Depliable titre="➕ Référencer une facture">
        <Grille>
          <Champ libelle="Fournisseur"><select value={x.f ?? ""} onChange={(e) => setX({ ...x, f: e.target.value })}><option value="">—</option>{(fournisseurs.donnees ?? []).map((z) => <option key={z.id} value={z.id}>{z.nom}</option>)}</select></Champ>
          <Champ libelle="N° de facture"><input value={x.num ?? ""} onChange={(e) => setX({ ...x, num: e.target.value })} /></Champ>
          <Champ libelle="Date"><input type="date" value={x.d ?? ""} onChange={(e) => setX({ ...x, d: e.target.value })} /></Champ>
          <Champ libelle="Montant HT (€)"><input inputMode="decimal" value={x.ht ?? ""} onChange={(e) => setX({ ...x, ht: e.target.value })} /></Champ>
          <Champ libelle="TVA (€)"><input inputMode="decimal" value={x.tva ?? ""} onChange={(e) => setX({ ...x, tva: e.target.value })} /></Champ>
          <Champ libelle="Catégorie"><select value={x.categorie} onChange={(e) => setX({ ...x, categorie: e.target.value })}>{["intrants", "prestataires", "materiel", "carburant", "stockage", "emballages", "indirectes"].map((c) => <option key={c} value={c}>{lib("categorieCharge", c)}</option>)}</select></Champ>
        </Grille>
        <Message erreur={a.erreur} succes={a.succes} />
        <BoutonPermis permission="achats:ecrire" disabled={!x.f || !x.num || !x.d} onClick={async () => {
          if (await a.executer(() => api.post(ex("/factures-fournisseurs"), { fournisseur_id: x.f, numero_fournisseur: x.num, date_facture: x.d, montant_ht_eur: n(x.ht) ?? 0, montant_tva_eur: n(x.tva) ?? 0, categorie_charge: x.categorie }), "Facture référencée.")) f.recharger();
        }}>{t("app.enregistrer")}</BoutonPermis>
      </Depliable>
    </Section>
  );
}
