"use client";

import Link from "next/link";
import { Badge, BadgeNiveau, BadgeStatutIntervention, Charge, Entete, Section, Tableau } from "@/components/ui";
import { date, nombre, surface } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

export default function TableauDeBord() {
  const { profil, adhesion } = useSession();
  const etat = useEx("/tableau-de-bord");
  return (
    <>
      <Entete titre={t("nav.tableau")} sousTitre={`${adhesion.raison_sociale} — bonjour ${profil.nom_affiche}`} />
      <Charge etat={etat}>
        {(d: any) => (
          <>
            {d.surface_totale_ha !== undefined && (
              <div className="grille-3">
                <Section><div className="chiffre">{surface(d.surface_totale_ha)}</div><div className="chiffre-libelle">{t("tableau.surface")}</div></Section>
                <Section><div className="chiffre">{nombre(d.nombre_parcelles, 0)}</div><div className="chiffre-libelle">{t("tableau.parcelles")}</div></Section>
                <Section><div className="chiffre">{nombre(d.alertes.length, 0)}</div><div className="chiffre-libelle">{t("tableau.alertes")}</div></Section>
              </div>
            )}
            <Section titre={t("tableau.alertes")}>
              {d.alertes.length === 0 ? <p>{t("tableau.aucuneAlerte")}</p> : (
                <ul className="liste-alertes" style={{ listStyle: "none", padding: 0, margin: 0 }}>
                  {d.alertes.map((a: any, i: number) => (
                    <li key={i} style={{ display: "flex", gap: ".6rem", alignItems: "baseline", padding: ".4rem 0", borderBottom: "1px solid var(--trait)" }}>
                      <BadgeNiveau niveau={a.niveau} /><span>{a.message}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Section>
            <div className="grille-2">
              {d.travaux_a_venir && (
                <Section titre={t("tableau.travaux")} actions={<Link className="bouton bouton-secondaire bouton-petit" href="/travaux">{t("nav.travaux")}</Link>}>
                  <Tableau entetes={["N°", "Date prévue", "Intervention", "Parcelle", "État"]}>
                    {d.travaux_a_venir.map((i: any) => (
                      <tr key={i.id}>
                        <td><Link href={`/travaux/${i.id}`}>{i.numero}</Link></td>
                        <td>{date(i.date_prevue)}</td>
                        <td>{lib("typeIntervention", i.type)}{i.libelle ? ` — ${i.libelle}` : ""}</td>
                        <td>{i.parcelle.code} {i.parcelle.nom}</td>
                        <td><BadgeStatutIntervention statut={i.statut} /></td>
                      </tr>
                    ))}
                  </Tableau>
                </Section>
              )}
              {d.echeances && (
                <Section titre={t("tableau.echeances")} actions={<Link className="bouton bouton-secondaire bouton-petit" href="/documents">{t("nav.documents")}</Link>}>
                  {d.echeances.length === 0 ? <p className="vide">{t("app.aucunElement")}</p> : (
                    <Tableau entetes={["Date", "Échéance", "État"]}>
                      {d.echeances.map((e: any, i: number) => (
                        <tr key={i}><td>{date(e.date)}</td><td>{e.libelle}</td>
                          <td><Badge ton={e.etat === "echue" ? "critique" : e.etat === "proche" ? "alerte" : "info"}>{e.libelle_etat}</Badge></td></tr>
                      ))}
                    </Tableau>
                  )}
                </Section>
              )}
            </div>
          </>
        )}
      </Charge>
    </>
  );
}
