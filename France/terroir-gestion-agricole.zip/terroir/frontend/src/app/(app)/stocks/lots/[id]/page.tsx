"use client";

import { use, useState } from "react";
import Link from "next/link";
import { Avertissement, Badge, BadgeLot, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Lien, Message, Section, Tableau, Valeurs, useAction } from "@/components/ui";
import { api } from "@/lib/api";
import { date, dateHeure, quantite } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

function CarteLot({ l, courant }: { l: any; courant?: boolean }) {
  return (
    <div className="carte" style={{ borderWidth: courant ? 3 : 1, borderColor: courant ? "var(--ble)" : undefined, marginBottom: ".5rem" }}>
      <div><Link href={`/stocks/lots/${l.id}`}><strong>{l.numero}</strong></Link> — {l.article} {courant && <Badge ton="info" icone="◉">Lot consulté</Badge>}</div>
      <div className="discret">{lib("origineLot", l.origine)} · {quantite(l.quantite_initiale, l.unite)}{l.classement ? ` · ${l.classement}` : ""}</div>
      {l.parcelle && <div>⬚ Parcelle <Link href={`/parcelles/${l.parcelle.id}`}>{l.parcelle.code} {l.parcelle.nom}</Link>{l.intervention && <> · récolte <Link href={`/travaux/${l.intervention.id}`}>{l.intervention.numero}</Link> du {date(l.intervention.date)}</>}</div>}
      {l.emplacements_historiques.length > 0 && <div>📦 Stockage : {l.emplacements_historiques.join(", ")}</div>}
      <BadgeLot statut={l.statut} apte={l.apte_vente} />
      {l.donnees_manquantes.map((m: string, i: number) => <div key={i}><Badge ton="alerte" icone="∅">Manquant</Badge> {m}</div>)}
    </div>
  );
}

export default function DetailLot({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const tr = useEx(`/tracabilite/lots/${id}`);
  const { ex } = useSession();
  const a = useAction();
  const [motif, setMotif] = useState("");
  const [statut, setStatut] = useState("libre");
  return (
    <Charge etat={tr}>
      {(r: any) => (
        <>
          <Entete titre={`${t("stocks.tracabilite")} — lot ${r.lot.numero}`} sousTitre={<Link href="/stocks">{t("app.retour")}</Link>}
            actions={<><Lien href={`/api/v1${ex(`/rapports/tracabilite/${id}?format=pdf`)}`} telechargement>{t("stocks.rapportPdf")}</Lien><Lien href={`/api/v1${ex(`/rapports/tracabilite/${id}?format=csv`)}`} telechargement>{t("stocks.rapportCsv")}</Lien></>} />
          <Avertissement ton={r.complete_jusqua_parcelle ? "ok" : "critique"} titre={t("stocks.conclusion")}>{r.conclusion}</Avertissement>
          <div className="grille-3">
            <Section titre={`⬆ ${t("stocks.ascendants")}`}>{r.ascendants.length ? r.ascendants.map((l: any) => <CarteLot key={l.id} l={l} />) : <p className="vide">Aucun (lot d'origine).</p>}</Section>
            <Section titre="◉ Lot"><CarteLot l={r.lot} courant />
              <h3>{t("stocks.parcellesOrigine")}</h3>
              {r.parcelles_origine.length ? <ul>{r.parcelles_origine.map((p: any) => <li key={p.id}><Link href={`/parcelles/${p.id}`}>{p.code} — {p.nom}</Link></li>)}</ul> : <Badge ton="critique" icone="∅">Aucune parcelle d'origine identifiée</Badge>}
            </Section>
            <Section titre={`⬇ ${t("stocks.descendants")}`}>{r.descendants.length ? r.descendants.map((l: any) => <CarteLot key={l.id} l={l} />) : <p className="vide">Aucun lot dérivé.</p>}</Section>
          </div>
          <div className="grille-2">
            <Section titre="Liens entre lots">
              <Tableau entetes={["Parent", "Enfant", "Type", "Quantité", "Date"]}>
                {r.liens.map((l: any, i: number) => <tr key={i}><td>{l.parent}</td><td>{l.enfant}</td><td>{lib("origineLot", l.type)}</td><td className="num">{quantite(l.quantite, l.unite)}</td><td>{date(l.date)}</td></tr>)}
              </Tableau>
            </Section>
            <Section titre={`🚚 ${t("stocks.expeditions")}`}>
              <Tableau entetes={["Expédition", "Date", "Commande", "Client", "Quantité"]}>
                {r.expeditions.map((e: any, i: number) => <tr key={i}><td>{e.numero}</td><td>{dateHeure(e.date)}</td><td>{e.commande}</td><td>{e.client}</td><td className="num">{quantite(e.quantite, r.lot.unite)}</td></tr>)}
              </Tableau>
            </Section>
          </div>
          <Section titre={t("stocks.manquantes")}>
            {r.donnees_manquantes.length ? <ul>{r.donnees_manquantes.map((m: any, i: number) => <li key={i}><Badge ton="alerte" icone="∅">{m.lot}</Badge> {m.manque}</li>)}</ul> : <p>Aucune donnée manquante détectée par les contrôles de Terroir.</p>}
          </Section>
          <Section titre={`${t("stocks.decisionVente")} et statut du lot`}>
            <Valeurs items={[["Statut", <BadgeLot statut={r.lot.statut} apte={r.lot.apte_vente} />]]} />
            <Message erreur={a.erreur} succes={a.succes} />
            <Champ libelle="Motif de la décision (obligatoire)"><input value={motif} onChange={(e) => setMotif(e.target.value)} /></Champ>
            <div className="actions">
              <BoutonPermis permission="stocks:liberer" disabled={!motif} onClick={async () => { if (await a.executer(() => api.post(ex(`/lots/${id}/decision-vente`), { apte_vente: !r.lot.apte_vente, motif }), "Décision enregistrée et journalisée.")) tr.recharger(); }}>
                {r.lot.apte_vente ? "Retirer l'aptitude à la vente" : "Déclarer apte à la vente"}
              </BoutonPermis>
              <select value={statut} onChange={(e) => setStatut(e.target.value)} style={{ width: "auto" }} aria-label="Nouveau statut">
                {["libre", "bloque", "quarantaine", "en_attente_controle"].map((s) => <option key={s} value={s}>{lib("statutLot", s)}</option>)}
              </select>
              <BoutonPermis permission="stocks:ecrire" className="bouton bouton-secondaire" disabled={!motif} onClick={async () => { if (await a.executer(() => api.post(ex(`/lots/${id}/statut`), { statut, motif }), "Statut modifié.")) tr.recharger(); }}>Changer le statut</BoutonPermis>
            </div>
            <p className="discret">L'aptitude à la vente est une décision humaine explicite ; elle n'est jamais déduite des relevés de conservation.</p>
          </Section>
        </>
      )}
    </Charge>
  );
}
