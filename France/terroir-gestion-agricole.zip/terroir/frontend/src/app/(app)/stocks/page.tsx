"use client";

import { useState } from "react";
import Link from "next/link";
import { Badge, BadgeLot, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Onglets, Section, Tableau, useAction } from "@/components/ui";
import { api, qs } from "@/lib/api";
import { date, dateHeure, nombre, quantite } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, libelles, t } from "@/i18n/fr";

export default function PageStocks() {
  const [onglet, setOnglet] = useState("etat");
  return (
    <>
      <Entete titre={t("nav.stocks")} sousTitre="Intrants, carburants, aliments, récoltes, emballages et produits finis" />
      <Onglets actif={onglet} surChange={setOnglet} onglets={[{ cle: "etat", libelle: t("stocks.etat") }, { cle: "lots", libelle: t("stocks.lots") }, { cle: "journal", libelle: t("stocks.journal") }, { cle: "obs", libelle: t("stocks.observations") }]} />
      {onglet === "etat" && <EtatStocks />}
      {onglet === "lots" && <Lots />}
      {onglet === "journal" && <Journal />}
      {onglet === "obs" && <Observations />}
    </>
  );
}

function EtatStocks() {
  const [cat, setCat] = useState("");
  const s = useEx(`/stocks${qs({ categorie: cat })}`);
  return (
    <Section titre={t("stocks.etat")} actions={<Champ libelle="Catégorie"><select value={cat} onChange={(e) => setCat(e.target.value)}><option value="">Toutes</option>{Object.entries(libelles.categorieArticle).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>}>
      <Charge etat={s}>
        {(d: any) => (
          <>
            <dl className="valeurs">{Object.entries(d.definitions).map(([k, v]) => <div key={k}><dt>{k}</dt><dd style={{ fontWeight: 400 }}>{v as string}</dd></div>)}</dl>
            <Tableau entetes={["Article", "Catégorie", "Physique", "Bloqué", "Réservé", "Disponible", "Attendu", "Alerte"]}>
              {d.articles.map((a: any) => (
                <tr key={a.article_id}>
                  <td><strong>{a.libelle}</strong><div className="discret code">{a.code}</div></td>
                  <td>{lib("categorieArticle", a.categorie)}</td>
                  <td className="num">{quantite(a.physique, a.unite)}</td><td className="num">{quantite(a.bloque, a.unite)}</td>
                  <td className="num">{quantite(a.reserve, a.unite)}</td><td className="num"><strong>{quantite(a.disponible, a.unite)}</strong></td>
                  <td className="num">{quantite(a.attendu, a.unite)}</td>
                  <td>{a.alerte === "rupture" ? <Badge ton="critique" icone="⚠">Rupture</Badge> : a.alerte === "sous_seuil" ? <Badge ton="alerte">Sous le seuil ({quantite(a.seuil_alerte, a.unite)})</Badge> : <Badge ton="ok">Correct</Badge>}</td>
                </tr>
              ))}
            </Tableau>
          </>
        )}
      </Charge>
    </Section>
  );
}

function Lots() {
  const [origine, setOrigine] = useState("");
  const l = useEx<any[]>(`/lots${qs({ origine })}`);
  const articles = useEx<any[]>("/articles");
  const nomArticle = (id: string) => articles.donnees?.find((a) => a.id === id)?.libelle ?? "…";
  return (
    <Section titre={t("stocks.lots")} actions={<Champ libelle="Origine"><select value={origine} onChange={(e) => setOrigine(e.target.value)}><option value="">Toutes</option>{Object.entries(libelles.origineLot).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>}>
      <Charge etat={l} vide={(d) => d.length === 0}>
        {(lots) => (
          <Tableau entetes={["Lot", "Article", "Origine", "Culture / variété", "Récolte / entrée", "Quantité actuelle", "Péremption", "État"]}>
            {lots.map((x) => (
              <tr key={x.id}>
                <td><Link href={`/stocks/lots/${x.id}`}><strong>{x.numero}</strong></Link>{x.numero_lot_fournisseur && <div className="discret">fourn. {x.numero_lot_fournisseur}</div>}</td>
                <td>{nomArticle(x.article_id)}</td><td>{lib("origineLot", x.origine)}</td>
                <td>{x.culture ?? "—"}{x.variete ? ` / ${x.variete}` : ""}{x.classement && <div className="discret">{x.classement}</div>}</td>
                <td>{date(x.date_recolte ?? x.date_entree)}</td>
                <td className="num">{quantite(x.quantite_actuelle, x.unite)}</td>
                <td>{date(x.date_peremption)}</td>
                <td><BadgeLot statut={x.statut} apte={["produit_recolte", "produit_fini"].includes(articles.donnees?.find((a) => a.id === x.article_id)?.categorie) ? x.apte_vente : undefined} /></td>
              </tr>
            ))}
          </Tableau>
        )}
      </Charge>
    </Section>
  );
}

function Journal() {
  const { ex } = useSession();
  const j = useEx<any[]>("/mouvements?limite=300");
  const articles = useEx<any[]>("/articles");
  const a = useAction();
  const [corr, setCorr] = useState<{ id: string; numero: number; q: string; motif: string } | null>(null);
  const nom = (id: string) => articles.donnees?.find((x) => x.id === id)?.libelle ?? "…";
  return (
    <Section titre={t("stocks.journal")}>
      <p className="discret">Journal immuable : une erreur se corrige par un mouvement de correction lié, attribué et horodaté ; le mouvement d'origine reste visible.</p>
      <Message erreur={a.erreur} succes={a.succes} />
      {corr && (
        <div className="carte" style={{ borderColor: "var(--ble)" }}>
          <h3>Corriger le mouvement n° {corr.numero}</h3>
          <Grille>
            <Champ libelle="Quantité correcte (valeur absolue)"><input inputMode="decimal" value={corr.q} onChange={(e) => setCorr({ ...corr, q: e.target.value })} /></Champ>
            <Champ libelle="Motif (obligatoire)"><input value={corr.motif} onChange={(e) => setCorr({ ...corr, motif: e.target.value })} /></Champ>
          </Grille>
          <div className="actions">
            <BoutonPermis permission="stocks:ecrire" disabled={!corr.motif || !corr.q} onClick={async () => {
              if (await a.executer(() => api.post(ex(`/mouvements/${corr.id}/correction`), { quantite_correcte: Number(corr.q.replace(",", ".")), motif: corr.motif }), "Correction enregistrée.")) { setCorr(null); j.recharger(); }
            }}>Enregistrer la correction</BoutonPermis>
            <button className="bouton bouton-secondaire" onClick={() => setCorr(null)}>{t("app.annuler")}</button>
          </div>
        </div>
      )}
      <Charge etat={j} vide={(d) => d.length === 0}>
        {(ms) => (
          <Tableau entetes={["N°", "Date", "Type", "Article", "Quantité", "Motif", "Lien", ""]}>
            {ms.map((m) => (
              <tr key={m.id}>
                <td className="num">{m.numero}</td><td>{dateHeure(m.horodatage)}</td>
                <td>{m.libelle_type}</td><td>{nom(m.article_id)}</td>
                <td className="num">{m.quantite > 0 ? "+" : ""}{quantite(m.quantite, m.unite)}{m.unite_saisie && m.unite_saisie !== m.unite && <div className="discret">saisi : {quantite(m.quantite_saisie, m.unite_saisie)}</div>}</td>
                <td>{m.motif ?? "—"}</td>
                <td>{m.corrige_mouvement_id && <Badge ton="info" icone="↺">{t("stocks.correctionDe")} {ms.find((x) => x.id === m.corrige_mouvement_id)?.numero ?? "…"}</Badge>}
                  {m.est_corrige && <Badge ton="alerte" icone="✎">{t("stocks.corrige")}</Badge>}</td>
                <td>{!m.est_corrige && m.type !== "correction" && <BoutonPermis permission="stocks:ecrire" className="bouton bouton-petit bouton-secondaire" onClick={() => setCorr({ id: m.id, numero: m.numero, q: String(Math.abs(m.quantite)), motif: "" })}>{t("stocks.corriger")}</BoutonPermis>}</td>
              </tr>
            ))}
          </Tableau>
        )}
      </Charge>
    </Section>
  );
}

function Observations() {
  const { ex } = useSession();
  const obs = useEx<any[]>("/observations-stockage");
  const empl = useEx<any[]>("/emplacements");
  const a = useAction();
  const [f, setF] = useState<Record<string, string>>({});
  const n = (v?: string) => (v ? Number(v.replace(",", ".")) : null);
  return (
    <Section titre={t("stocks.observations")}>
      <p className="discret">Les relevés de température, d'humidité et de qualité sont conservés pour le suivi. Ils ne rendent jamais un lot apte à la vente : cette décision est explicite (fiche du lot).</p>
      <Depliable titre="➕ Nouveau relevé">
        <Grille>
          <Champ libelle="Emplacement"><select value={f.emplacement_id ?? ""} onChange={(e) => setF({ ...f, emplacement_id: e.target.value })}><option value="">—</option>{(empl.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.code} — {x.nom}</option>)}</select></Champ>
          <Champ libelle="Température (°C)"><input inputMode="decimal" value={f.t ?? ""} onChange={(e) => setF({ ...f, t: e.target.value })} /></Champ>
          <Champ libelle="Humidité relative de l'air (%)"><input inputMode="decimal" value={f.hr ?? ""} onChange={(e) => setF({ ...f, hr: e.target.value })} /></Champ>
          <Champ libelle="Humidité du produit (%)"><input inputMode="decimal" value={f.hp ?? ""} onChange={(e) => setF({ ...f, hp: e.target.value })} /></Champ>
          <Champ libelle="Qualité observée"><input value={f.q ?? ""} onChange={(e) => setF({ ...f, q: e.target.value })} /></Champ>
        </Grille>
        <Message erreur={a.erreur} succes={a.succes} />
        <BoutonPermis permission="stocks:ecrire" disabled={!f.emplacement_id} onClick={async () => {
          if (await a.executer(() => api.post(ex("/observations-stockage"), { emplacement_id: f.emplacement_id, temperature_c: n(f.t), humidite_relative_pct: n(f.hr), humidite_produit_pct: n(f.hp), qualite: f.q || null }), "Relevé enregistré (sans effet sur l'aptitude à la vente).")) obs.recharger();
        }}>{t("app.enregistrer")}</BoutonPermis>
      </Depliable>
      <Charge etat={obs} vide={(d) => d.length === 0}>
        {(os) => (
          <Tableau entetes={["Date", "Emplacement", "Température", "Humidité air", "Humidité produit", "Qualité", "Source"]}>
            {os.map((o) => (
              <tr key={o.id}><td>{dateHeure(o.horodatage)}</td><td>{empl.donnees?.find((x) => x.id === o.emplacement_id)?.nom ?? "…"}</td>
                <td className="num">{o.temperature_c !== null ? `${nombre(o.temperature_c, 1)} °C` : "—"}</td>
                <td className="num">{o.humidite_relative_pct !== null ? `${nombre(o.humidite_relative_pct, 0)} %` : "—"}</td>
                <td className="num">{o.humidite_produit_pct !== null ? `${nombre(o.humidite_produit_pct, 1)} %` : "—"}</td>
                <td>{o.qualite ?? "—"}</td><td>{o.source === "capteur_simule" ? <Badge ton="info" icone="📡">Capteur simulé</Badge> : <Badge ton="neutre" icone="✍">Saisie</Badge>}</td></tr>
            ))}
          </Tableau>
        )}
      </Charge>
    </Section>
  );
}
