"use client";

import { useState } from "react";
import { Avertissement, Badge, BadgeCommande, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Section, Tableau, useAction } from "@/components/ui";
import { api } from "@/lib/api";
import { date, dateHeure, euros, quantite } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { t } from "@/i18n/fr";

const n = (v?: string) => (v ? Number(v.replace(",", ".")) : null);

export default function PageVentes() {
  const c = useEx<any[]>("/commandes-clients");
  return (
    <>
      <Entete titre={t("nav.ventes")} sousTitre="Commande client → allocation → expédition → facture → paiement enregistré" />
      <Charge etat={c} vide={(x) => x.length === 0}>
        {(cs) => <>{cs.map((x) => <Commande key={x.id} c={x} surChange={c.recharger} />)}</>}
      </Charge>
      <NouvelleCommande surCreation={c.recharger} />
    </>
  );
}

function Commande({ c, surChange }: { c: any; surChange: () => void }) {
  const { ex } = useSession();
  const empl = useEx<any[]>("/emplacements");
  const a = useAction();
  const [alloc, setAlloc] = useState<Record<string, string>>({});
  const [exped, setExped] = useState<Record<string, string>>({});
  const [tva, setTva] = useState("");
  const [paie, setPaie] = useState<Record<string, string>>({ mode: "virement" });
  const ligneSel = c.lignes.find((l: any) => l.id === alloc.ligne) ?? c.lignes[0];
  const lots = useEx<any[]>(ligneSel ? `/lots?article_id=${ligneSel.article_id}` : null);
  const allocations = c.lignes.flatMap((l: any) => l.allocations.map((al: any) => ({ ...al, article: l.article, unite: l.unite })));
  return (
    <Section titre={`${c.numero} — ${c.client}`} actions={<BadgeCommande statut={c.statut} />}>
      <p className="discret">Commande du {date(c.date_commande)} · {euros(c.montant_ht_eur)} HT</p>
      <Message erreur={a.erreur} succes={a.succes} />
      <Tableau entetes={["Article", "Commandé", "Alloué", "Expédié", "Reste à expédier", "Prix unitaire HT", "Lots alloués"]}>
        {c.lignes.map((l: any) => <tr key={l.id}><td>{l.article}</td><td className="num">{quantite(l.quantite, l.unite)}</td><td className="num">{quantite(l.quantite_allouee, l.unite)}</td><td className="num">{quantite(l.quantite_expediee, l.unite)}</td><td className="num"><strong>{quantite(l.reste_a_expedier, l.unite)}</strong></td><td className="num">{euros(l.prix_unitaire_eur)}</td>
          <td>{l.allocations.map((al: any) => <div key={al.id}>{al.lot} : {quantite(al.quantite, l.unite)} (expédié {quantite(al.quantite_expediee, l.unite)})</div>)}</td></tr>)}
      </Tableau>
      {c.expeditions.length > 0 && <><h3>Expéditions</h3><ul>{c.expeditions.map((e: any) => <li key={e.id}>🚚 {e.numero} le {dateHeure(e.horodatage)}{e.transporteur ? ` — ${e.transporteur}` : ""} : {e.lignes.map((l: any) => quantite(l.quantite, l.unite)).join(", ")}</li>)}</ul></>}
      {c.factures.length > 0 && <><h3>{t("ventes.factures")}</h3><Tableau entetes={["N°", "Date", "HT", "TVA (taux saisi)", "TTC", "Payé", "Reste dû", "État", ""]}>
        {c.factures.map((f: any) => <tr key={f.id}><td>{f.numero}</td><td>{date(f.date_facture)}</td><td className="num">{euros(f.montant_ht_eur)}</td><td className="num">{f.taux_tva_pct.toLocaleString("fr-FR")} %</td><td className="num">{euros(f.montant_ttc_eur)}</td><td className="num">{euros(f.montant_paye_eur)}</td><td className="num">{euros(f.reste_du_eur)}</td><td><BadgeCommande statut={f.statut} /></td>
          <td>{f.reste_du_eur > 0 && <Depliable titre={t("ventes.payer")}><Grille>
            <Champ libelle="Date"><input type="date" value={paie.d ?? ""} onChange={(e) => setPaie({ ...paie, d: e.target.value })} /></Champ>
            <Champ libelle="Montant (€)"><input inputMode="decimal" value={paie.m ?? String(f.reste_du_eur)} onChange={(e) => setPaie({ ...paie, m: e.target.value })} /></Champ>
            <Champ libelle="Mode"><select value={paie.mode} onChange={(e) => setPaie({ ...paie, mode: e.target.value })}><option value="virement">Virement</option><option value="cheque">Chèque</option><option value="prelevement">Prélèvement</option><option value="especes">Espèces</option></select></Champ>
            <Champ libelle="Référence"><input value={paie.r ?? ""} onChange={(e) => setPaie({ ...paie, r: e.target.value })} /></Champ></Grille>
            <BoutonPermis permission="ventes:ecrire" disabled={!paie.d} onClick={async () => { if (await a.executer(() => api.post(ex(`/factures/${f.id}/paiements`), { date_paiement: paie.d, montant_eur: n(paie.m ?? String(f.reste_du_eur)), mode: paie.mode, reference: paie.r || null }), "Paiement enregistré.")) surChange(); }}>Enregistrer</BoutonPermis>
          </Depliable>}</td></tr>)}
      </Tableau></>}
      {["confirmee", "allouee", "partiellement_expediee"].includes(c.statut) && (
        <Depliable titre={`🔗 ${t("ventes.allouer")}`}>
          <Grille>
            <Champ libelle="Ligne"><select value={alloc.ligne ?? ligneSel?.id} onChange={(e) => setAlloc({ ...alloc, ligne: e.target.value, lot: "" })}>{c.lignes.map((l: any) => <option key={l.id} value={l.id}>{l.article}</option>)}</select></Champ>
            <Champ libelle="Lot (seuls les lots déclarés aptes à la vente sont proposés)"><select value={alloc.lot ?? ""} onChange={(e) => setAlloc({ ...alloc, lot: e.target.value })}><option value="">—</option>
              {(lots.donnees ?? []).filter((l) => l.apte_vente && l.statut === "libre" && l.quantite_actuelle > 0).map((l) => <option key={l.id} value={l.id}>{l.numero} — {quantite(l.quantite_actuelle, l.unite)}</option>)}</select></Champ>
            <Champ libelle="Emplacement"><select value={alloc.e ?? ""} onChange={(e) => setAlloc({ ...alloc, e: e.target.value })}><option value="">—</option>{(empl.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.code} — {x.nom}</option>)}</select></Champ>
            <Champ libelle={`Quantité (${ligneSel?.unite ?? ""})`}><input inputMode="decimal" value={alloc.q ?? ""} onChange={(e) => setAlloc({ ...alloc, q: e.target.value })} /></Champ>
          </Grille>
          <BoutonPermis permission="ventes:ecrire" disabled={!alloc.lot || !alloc.e || !alloc.q} onClick={async () => {
            if (await a.executer(() => api.post(ex(`/commandes-clients/${c.id}/allocations`), { lignes: [{ ligne_id: alloc.ligne ?? ligneSel.id, lot_id: alloc.lot, emplacement_id: alloc.e, quantite: n(alloc.q) }] }), "Lot alloué et réservé.")) surChange();
          }}>Allouer</BoutonPermis>
        </Depliable>
      )}
      {["allouee", "partiellement_expediee"].includes(c.statut) && allocations.some((al: any) => al.quantite > al.quantite_expediee) && (
        <Depliable titre={`🚚 ${t("ventes.expedier")} (expédition partielle possible)`}>
          <Grille>
            {allocations.filter((al: any) => al.quantite > al.quantite_expediee).map((al: any) => (
              <Champ key={al.id} libelle={`${al.article} — lot ${al.lot} (reste ${quantite(al.quantite - al.quantite_expediee, al.unite)})`}>
                <input inputMode="decimal" value={exped[al.id] ?? ""} onChange={(e) => setExped({ ...exped, [al.id]: e.target.value })} placeholder="Quantité expédiée" />
              </Champ>
            ))}
            <Champ libelle="Transporteur"><input value={exped.transporteur ?? ""} onChange={(e) => setExped({ ...exped, transporteur: e.target.value })} /></Champ>
          </Grille>
          <BoutonPermis permission="ventes:ecrire" onClick={async () => {
            const lignes = allocations.filter((al: any) => n(exped[al.id])).map((al: any) => ({ allocation_id: al.id, quantite: n(exped[al.id]) }));
            if (await a.executer(() => api.post(ex(`/commandes-clients/${c.id}/expeditions`), { lignes, transporteur: exped.transporteur || null }), "Expédition enregistrée.")) surChange();
          }}>Enregistrer l'expédition</BoutonPermis>
        </Depliable>
      )}
      {c.expeditions.length > 0 && (
        <Depliable titre={`🧾 ${t("ventes.facturer")}`}>
          <Avertissement ton="info">Pièce de gestion émise par Terroir. Saisissez le taux de TVA applicable ; la conformité fiscale relève de votre outil comptable.</Avertissement>
          <Champ libelle="Taux de TVA (%)"><input inputMode="decimal" value={tva} onChange={(e) => setTva(e.target.value)} /></Champ>
          <BoutonPermis permission="ventes:ecrire" disabled={!tva} onClick={async () => { if (await a.executer(() => api.post(ex(`/commandes-clients/${c.id}/factures`), { date_facture: new Date().toISOString().slice(0, 10), taux_tva_pct: n(tva) }), "Facture émise.")) surChange(); }}>Facturer</BoutonPermis>
        </Depliable>
      )}
    </Section>
  );
}

function NouvelleCommande({ surCreation }: { surCreation: () => void }) {
  const { ex } = useSession();
  const clients = useEx<any[]>("/clients");
  const articles = useEx<any[]>("/articles");
  const a = useAction();
  const [f, setF] = useState<Record<string, string>>({});
  const art = articles.donnees?.find((x) => x.id === f.article);
  return (
    <Depliable titre={`➕ ${t("ventes.nouvelle")}`}>
      <Grille>
        <Champ libelle="Client"><select value={f.client ?? ""} onChange={(e) => setF({ ...f, client: e.target.value })}><option value="">—</option>{(clients.donnees ?? []).map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}</select></Champ>
        <Champ libelle="Article"><select value={f.article ?? ""} onChange={(e) => setF({ ...f, article: e.target.value })}><option value="">—</option>{(articles.donnees ?? []).filter((x) => ["produit_recolte", "produit_fini"].includes(x.categorie)).map((x) => <option key={x.id} value={x.id}>{x.libelle}</option>)}</select></Champ>
        <Champ libelle={`Quantité (${art?.unite_stock ?? ""})`}><input inputMode="decimal" value={f.q ?? ""} onChange={(e) => setF({ ...f, q: e.target.value })} /></Champ>
        <Champ libelle="Prix unitaire HT (€)"><input inputMode="decimal" value={f.p ?? ""} onChange={(e) => setF({ ...f, p: e.target.value })} /></Champ>
      </Grille>
      <Message erreur={a.erreur} succes={a.succes} />
      <BoutonPermis permission="ventes:ecrire" disabled={!f.client || !f.article || !f.q || !f.p} onClick={async () => {
        if (await a.executer(() => api.post(ex("/commandes-clients"), { client_id: f.client, date_commande: new Date().toISOString().slice(0, 10), lignes: [{ article_id: f.article, quantite: n(f.q), unite: art?.unite_stock, prix_unitaire_eur: n(f.p) }] }), "Commande créée.")) surCreation();
      }}>{t("app.enregistrer")}</BoutonPermis>
    </Depliable>
  );
}
