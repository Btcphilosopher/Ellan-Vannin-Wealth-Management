"use client";

import { useEffect, useState } from "react";
import { Avertissement, Badge, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Onglets, Section, Tableau, useAction } from "@/components/ui";
import { api } from "@/lib/api";
import { date, nombre, quantite, surface } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

export default function PageCultures() {
  const campagnes = useEx<any[]>("/campagnes");
  const [campagne, setCampagne] = useState("");
  const [onglet, setOnglet] = useState("cycles");
  useEffect(() => {
    if (!campagne && campagnes.donnees?.length) {
      const enCours = campagnes.donnees.find((c) => c.statut === "en_cours") ?? campagnes.donnees[0];
      setCampagne(enCours.id);
    }
  }, [campagnes.donnees, campagne]);
  return (
    <>
      <Entete titre={t("nav.cultures")} sousTitre="Planification des campagnes, rotations et besoins"
        actions={<Champ libelle={t("cultures.campagne")}><select value={campagne} onChange={(e) => setCampagne(e.target.value)}>
          {(campagnes.donnees ?? []).map((c) => <option key={c.id} value={c.id}>{c.libelle} ({c.statut === "close" ? "close" : c.statut === "en_cours" ? "en cours" : "en préparation"})</option>)}
        </select></Champ>} />
      <Onglets actif={onglet} surChange={setOnglet} onglets={[{ cle: "cycles", libelle: t("cultures.cycles") }, { cle: "rotation", libelle: t("cultures.rotation") }, { cle: "besoins", libelle: t("cultures.besoins") }]} />
      {onglet === "cycles" && campagne && <Cycles campagne={campagne} />}
      {onglet === "rotation" && <Rotation />}
      {onglet === "besoins" && campagne && <Besoins campagne={campagne} />}
      <NouvelleCampagne surCreation={campagnes.recharger} />
    </>
  );
}

function Cycles({ campagne }: { campagne: string }) {
  const cycles = useEx<any[]>(`/cycles?campagne_id=${campagne}`);
  return (
    <Section titre={t("cultures.cycles")}>
      <p className="discret">Les colonnes « {t("cultures.prevision")} » sont des intentions ; les colonnes « {t("cultures.realise")} » proviennent des lots récoltés enregistrés.</p>
      <Charge etat={cycles} vide={(d) => d.length === 0}>
        {(cs) => (
          <Tableau entetes={["Parcelle", "Culture / variété", "Activité", "Surface prévue", `Semis — ${t("cultures.prevision")}`, `Récolte — ${t("cultures.prevision")}`, t("cultures.rendementPrev"), `${t("cultures.realise")}`, "Destination", "État"]}>
            {cs.map((c) => (
              <tr key={c.id}>
                <td><strong>{c.parcelle.code}</strong> {c.parcelle.nom}</td>
                <td>{c.culture}{c.variete ? <><br /><span className="discret">{c.variete}</span></> : null}</td>
                <td>{lib("module", c.module)}</td>
                <td className="num">{surface(c.surface_prevue_ha)}</td>
                <td>{date(c.date_semis_prevue)}</td>
                <td>{c.date_recolte_debut_prevue ? `${date(c.date_recolte_debut_prevue)} → ${date(c.date_recolte_fin_prevue)}` : "—"}</td>
                <td className="num"><Badge ton="info" icone="≈">{c.rendement_previsionnel !== null ? `${nombre(c.rendement_previsionnel, 2)} ${c.unite_rendement}` : "—"}</Badge>
                  {c.source_rendement_previsionnel && <div className="discret">{c.source_rendement_previsionnel}</div>}</td>
                <td className="num">{c.realise.lots ? <Badge ton="ok" icone="⚖">{quantite(c.realise.quantite_recoltee_t, "t")} · {c.realise.rendement_t_ha !== null ? `${nombre(c.realise.rendement_t_ha, 2)} t/ha` : "—"}</Badge> : <span className="discret">pas encore de lot</span>}</td>
                <td>{c.destination_prevue ?? "—"}</td>
                <td>{c.statut}</td>
              </tr>
            ))}
          </Tableau>
        )}
      </Charge>
      <NouveauCycle campagne={campagne} surCreation={cycles.recharger} />
    </Section>
  );
}

function NouveauCycle({ campagne, surCreation }: { campagne: string; surCreation: () => void }) {
  const { ex } = useSession();
  const parcelles = useEx<any[]>("/parcelles");
  const a = useAction();
  const [f, setF] = useState<Record<string, string>>({ module: "grandes_cultures" });
  const maj = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const num = (v?: string) => (v ? Number(v.replace(",", ".")) : null);
  async function creer() {
    const r = await a.executer(() => api.post(ex("/cycles"), {
      campagne_id: campagne, parcelle_id: f.parcelle_id, culture: f.culture, variete: f.variete || null, module: f.module,
      famille_botanique: f.famille || null, surface_prevue_ha: num(f.surface), date_semis_prevue: f.semis || null,
      date_recolte_debut_prevue: f.recolte || null, rendement_previsionnel: num(f.rendement), source_rendement_previsionnel: f.source || null,
      destination_prevue: f.destination || null,
    }), "Cycle planifié.");
    if (r) { if (r.avertissements?.length) a.setErreur(r.avertissements.join(" ")); surCreation(); }
  }
  return (
    <Depliable titre={`➕ ${t("cultures.nouveauCycle")}`}>
      <Grille>
        <Champ libelle="Parcelle"><select value={f.parcelle_id ?? ""} onChange={(e) => {
          const p = parcelles.donnees?.find((x) => x.id === e.target.value);
          setF({ ...f, parcelle_id: e.target.value, surface: p ? String(p.surface_calculee_ha ?? p.surface_declaree_ha ?? "") : "" });
        }}><option value="">—</option>{(parcelles.donnees ?? []).map((p) => <option key={p.id} value={p.id}>{p.code} {p.nom}</option>)}</select></Champ>
        <Champ libelle="Culture"><input value={f.culture ?? ""} onChange={maj("culture")} /></Champ>
        <Champ libelle="Variété"><input value={f.variete ?? ""} onChange={maj("variete")} /></Champ>
        <Champ libelle="Famille botanique"><input value={f.famille ?? ""} onChange={maj("famille")} /></Champ>
        <Champ libelle="Activité"><select value={f.module} onChange={maj("module")}>{["grandes_cultures", "maraichage", "vergers_viticulture", "polyculture_elevage"].map((m) => <option key={m} value={m}>{lib("module", m)}</option>)}</select></Champ>
        <Champ libelle="Surface prévue (ha)"><input inputMode="decimal" value={f.surface ?? ""} onChange={maj("surface")} /></Champ>
        <Champ libelle="Semis ou plantation prévu"><input type="date" value={f.semis ?? ""} onChange={maj("semis")} /></Champ>
        <Champ libelle="Début de récolte estimé"><input type="date" value={f.recolte ?? ""} onChange={maj("recolte")} /></Champ>
        <Champ libelle="Rendement prévisionnel (t/ha)"><input inputMode="decimal" value={f.rendement ?? ""} onChange={maj("rendement")} /></Champ>
        <Champ libelle="Source de la prévision"><input value={f.source ?? ""} onChange={maj("source")} /></Champ>
        <Champ libelle="Destination prévue"><input value={f.destination ?? ""} onChange={maj("destination")} /></Champ>
      </Grille>
      <Message erreur={a.erreur} succes={a.succes} />
      <BoutonPermis permission="cultures:ecrire" onClick={creer} disabled={a.enCours}>{t("app.enregistrer")}</BoutonPermis>
    </Depliable>
  );
}

function Rotation() {
  const r = useEx("/rotations");
  const { ex } = useSession();
  const a = useAction();
  return (
    <Charge etat={r}>
      {(d: any) => (
        <>
          <Section titre={t("cultures.indicateur")}>
            <div className="chiffre">{d.indicateur.valeur_pct !== null ? `${nombre(d.indicateur.valeur_pct, 1)} %` : "—"}</div>
            <div className="chiffre-libelle">{d.indicateur.libelle} — {d.indicateur.cycles_en_alerte} cycle(s) en alerte sur {d.indicateur.cycles_evalues} ; {d.indicateur.regles_non_validees} règle(s) non validée(s)</div>
            <Avertissement ton="info" titre="Portée de l'indicateur">{d.indicateur.avertissement}</Avertissement>
          </Section>
          <Section titre="Historique et rotations prévues">
            <div className="tableau-conteneur">
              <table className="tableau rotation">
                <thead><tr><th>Parcelle</th>{d.campagnes.map((c: any) => <th key={c.id}>{c.libelle}</th>)}</tr></thead>
                <tbody>
                  {d.parcelles.map((p: any) => (
                    <tr key={p.parcelle_id}>
                      <th scope="row" style={{ textAlign: "left" }}>{p.code}<br /><span className="discret">{p.nom}</span></th>
                      {d.campagnes.map((c: any) => (
                        <td key={c.id}>{(p.campagnes[c.id] ?? []).map((cy: any) => (
                          <div key={cy.cycle_id} className={`case-culture ${cy.alertes.length ? "en-alerte" : ""}`}>
                            <strong>{cy.culture}</strong>{cy.famille && <span className="discret"> · {cy.famille}</span>}
                            {cy.alertes.map((al: any) => (
                              <div key={al.regle_id}><Badge ton="alerte">{al.libelle}</Badge> <span className="discret">({al.validee ? `✓ ${t("cultures.regleValidee")}` : `✗ ${t("cultures.regleNonValidee")}`})</span></div>
                            ))}
                          </div>
                        ))}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>
          <Section titre={t("cultures.regles")}>
            <Message erreur={a.erreur} succes={a.succes} />
            <Tableau entetes={["Règle", "Type", "Source", "Validation professionnelle", ""]}>
              {d.regles.map((rg: any) => (
                <tr key={rg.id}>
                  <td>{rg.libelle}</td><td>{rg.type}</td><td>{rg.source ?? "—"}</td>
                  <td>{rg.validee_par ? <Badge ton="ok">Validée par {rg.validee_par} le {date(rg.validee_le)}{rg.qualification_validateur ? ` (${rg.qualification_validateur})` : ""}</Badge> : <Badge ton="alerte" icone="✗">Non validée</Badge>}</td>
                  <td>{!rg.validee_par && <BoutonPermis permission="phyto:valider" className="bouton bouton-petit" onClick={async () => {
                    const q = window.prompt("Votre qualification professionnelle :");
                    if (q) { await a.executer(() => api.post(ex(`/regles-rotation/${rg.id}/validation`), { qualification: q }), "Règle validée."); r.recharger(); }
                  }}>Valider</BoutonPermis>}</td>
                </tr>
              ))}
            </Tableau>
          </Section>
        </>
      )}
    </Charge>
  );
}

function Besoins({ campagne }: { campagne: string }) {
  const b = useEx(`/campagnes/${campagne}/besoins`);
  return (
    <Charge etat={b}>
      {(d: any) => (
        <>
          <Section titre="Intrants nécessaires">
            <p className="discret">{t("cultures.methode")} : {d.methode}</p>
            {d.intrants.length === 0 ? <p className="vide">Aucune intervention planifiée avec des produits sur cette campagne.</p> : (
              <Tableau entetes={["Article", "Besoin", "Déjà réservé", "Disponible", "Attendu", "Manque", "Couverture"]}>
                {d.intrants.map((x: any) => (
                  <tr key={x.article_id}>
                    <td>{x.libelle}<div className="discret">{lib("categorieArticle", x.categorie)}</div></td>
                    <td className="num">{quantite(x.besoin, x.unite)}</td><td className="num">{quantite(x.deja_reserve, x.unite)}</td>
                    <td className="num">{quantite(x.disponible, x.unite)}</td><td className="num">{quantite(x.attendu, x.unite)}</td>
                    <td className="num"><strong>{quantite(x.manque, x.unite)}</strong></td>
                    <td>{x.statut === "rupture" ? <Badge ton="critique" icone="⚠">Rupture prévisionnelle</Badge> : <Badge ton="ok">Couvert</Badge>}</td>
                  </tr>
                ))}
              </Tableau>
            )}
          </Section>
          <Section titre={t("cultures.chargeTravail")}>
            <Tableau entetes={["Semaine", "Interventions", "Heures de main-d'œuvre prévues"]}>
              {d.charge_travail.map((c: any) => <tr key={c.semaine}><td>{c.semaine}</td><td className="num">{c.interventions}</td><td className="num">{quantite(c.heures, "h", 1)}</td></tr>)}
            </Tableau>
          </Section>
        </>
      )}
    </Charge>
  );
}

function NouvelleCampagne({ surCreation }: { surCreation: () => void }) {
  const { ex } = useSession();
  const a = useAction();
  const [f, setF] = useState({ libelle: "", date_debut: "", date_fin: "" });
  return (
    <Depliable titre={`➕ ${t("cultures.nouvelleCampagne")}`}>
      <Grille>
        <Champ libelle="Libellé"><input value={f.libelle} placeholder="2027-2028" onChange={(e) => setF({ ...f, libelle: e.target.value })} /></Champ>
        <Champ libelle="Début"><input type="date" value={f.date_debut} onChange={(e) => setF({ ...f, date_debut: e.target.value })} /></Champ>
        <Champ libelle="Fin"><input type="date" value={f.date_fin} onChange={(e) => setF({ ...f, date_fin: e.target.value })} /></Champ>
      </Grille>
      <Message erreur={a.erreur} succes={a.succes} />
      <BoutonPermis permission="cultures:ecrire" disabled={a.enCours} onClick={async () => { if (await a.executer(() => api.post(ex("/campagnes"), f), "Campagne créée.")) surCreation(); }}>{t("app.enregistrer")}</BoutonPermis>
    </Depliable>
  );
}
