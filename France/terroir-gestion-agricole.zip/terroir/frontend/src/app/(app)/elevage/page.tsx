"use client";

import { useState } from "react";
import { Avertissement, Badge, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Onglets, Section, Tableau, useAction } from "@/components/ui";
import { api, qs } from "@/lib/api";
import { date, dateHeure, nombre, quantite } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, libelles, t } from "@/i18n/fr";

export default function PageElevage() {
  const [onglet, setOnglet] = useState("lots");
  const { adhesion } = useSession();
  return (
    <>
      <Entete titre={t("nav.elevage")} sousTitre="Démonstration limitée (ovins, bovins) — Terroir ne prescrit aucun traitement" />
      {!adhesion.modules_actifs.includes("elevage") && <Avertissement ton="info">Le module Élevage n'est pas activé pour cette exploitation (Paramètres).</Avertissement>}
      <Onglets actif={onglet} surChange={setOnglet} onglets={[{ cle: "lots", libelle: t("elevage.lots") }, { cle: "animaux", libelle: t("elevage.animaux") }, { cle: "evenements", libelle: t("elevage.evenements") }, { cle: "declarations", libelle: t("elevage.declarations") }]} />
      {onglet === "lots" && <Lots />}
      {onglet === "animaux" && <Animaux />}
      {onglet === "evenements" && <Evenements />}
      {onglet === "declarations" && <Declarations />}
    </>
  );
}

function Lots() {
  const l = useEx<any[]>("/lots-animaux");
  const parcelles = useEx<any[]>("/parcelles");
  return (
    <Section titre={t("elevage.lots")}>
      <Charge etat={l} vide={(d) => d.length === 0}>
        {(ls) => (
          <Tableau entetes={["Code", "Lot", "Espèce", "Finalité", "Effectif présent", "Localisation actuelle"]}>
            {ls.map((x) => <tr key={x.id}><td><strong>{x.code}</strong></td><td>{x.nom}</td><td>{x.espece}</td><td>{x.finalite ?? "—"}</td><td className="num">{nombre(x.effectif, 0)}</td>
              <td>{x.localisation ? <>{x.localisation.parcelle_id ? `Parcelle ${parcelles.donnees?.find((p) => p.id === x.localisation.parcelle_id)?.code ?? "…"}` : x.localisation.batiment} <span className="discret">depuis le {date(x.localisation.du)}</span></> : "—"}</td></tr>)}
          </Tableau>
        )}
      </Charge>
    </Section>
  );
}

function Animaux() {
  const lots = useEx<any[]>("/lots-animaux");
  const [lot, setLot] = useState("");
  const a = useEx<any[]>(`/animaux${qs({ lot_animaux_id: lot })}`);
  const [sel, setSel] = useState<string | null>(null);
  const c = useEx(sel ? `/animaux/${sel}/croissance` : null);
  return (
    <Section titre={t("elevage.animaux")} actions={<Champ libelle="Lot"><select value={lot} onChange={(e) => setLot(e.target.value)}><option value="">Tous</option>{(lots.donnees ?? []).map((l) => <option key={l.id} value={l.id}>{l.nom}</option>)}</select></Champ>}>
      <Charge etat={a} vide={(d) => d.length === 0}>
        {(as) => (
          <Tableau entetes={["Identifiant", "Espèce / race", "Sexe", "Naissance", "Origine", "Dernière pesée", "État", ""]}>
            {as.map((x) => <tr key={x.id}><td className="code">{x.identifiant}</td><td>{x.espece} {x.race ? `/ ${x.race}` : ""}</td><td>{x.sexe === "F" ? "Femelle" : "Mâle"}</td><td>{date(x.date_naissance)}</td><td>{x.origine === "achat" ? "Achat" : "Naissance"}</td>
              <td>{x.derniere_pesee ? `${quantite(x.derniere_pesee.valeurs.poids_kg, "kg", 1)} le ${date(x.derniere_pesee.horodatage)}` : "—"}</td>
              <td>{x.statut === "present" ? <Badge ton="ok">Présent</Badge> : x.statut === "vendu" ? <Badge ton="neutre" icone="€">Vendu</Badge> : <Badge ton="neutre" icone="✝">Mort</Badge>}</td>
              <td>{x.derniere_pesee && <button className="bouton bouton-petit bouton-secondaire" onClick={() => setSel(x.id)}>Croissance</button>}</td></tr>)}
          </Tableau>
        )}
      </Charge>
      {sel && <Charge etat={c}>{(d: any) => (
        <div className="carte"><h3>Croissance de {d.animal}</h3>
          <Tableau entetes={["Du", "Au", "GMQ"]}>{d.gmq.map((g: any, i: number) => <tr key={i}><td>{date(g.du)}</td><td>{date(g.au)}</td><td className="num">{nombre(g.gmq_g_j, 0)} g/j</td></tr>)}</Tableau>
          <p className="discret">Méthode : {d.methode}</p></div>)}</Charge>}
    </Section>
  );
}

function Evenements() {
  const { ex, peut, fuseau } = useSession();
  const ev = useEx<any[]>("/evenements-elevage");
  const lots = useEx<any[]>("/lots-animaux");
  const animaux = useEx<any[]>("/animaux?statut=present");
  const articles = useEx<any[]>("/articles?categorie=aliment_animal");
  const a = useAction();
  const [f, setF] = useState<Record<string, string>>({ type: "pesee", portee: "individuelle" });
  const [tr, setTr] = useState<Record<string, string>>({ portee: "collective" });
  const [avertTraitement, setAvert] = useState<string | null>(null);
  const n = (v?: string) => (v ? Number(v.replace(",", ".")) : undefined);
  return (
    <Section titre={t("elevage.evenements")}>
      <Message erreur={a.erreur} succes={a.succes} />
      {avertTraitement && <Avertissement>{avertTraitement}</Avertissement>}
      <Depliable titre={`➕ ${t("elevage.nouvelEvenement")}`}>
        <Grille>
          <Champ libelle="Type"><select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}>{["pesee", "alimentation", "observation", "sanitaire", "vente", "mortalite"].map((x) => <option key={x} value={x}>{lib("evenement", x)}</option>)}</select></Champ>
          <Champ libelle="Portée"><select value={f.portee} onChange={(e) => setF({ ...f, portee: e.target.value })}><option value="individuelle">Individuelle (un animal)</option><option value="collective">Collective (un lot)</option></select></Champ>
          {f.portee === "individuelle" ? <Champ libelle="Animal"><select value={f.animal ?? ""} onChange={(e) => setF({ ...f, animal: e.target.value })}><option value="">—</option>{(animaux.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.identifiant}</option>)}</select></Champ>
            : <Champ libelle="Lot"><select value={f.lot ?? ""} onChange={(e) => setF({ ...f, lot: e.target.value })}><option value="">—</option>{(lots.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.nom}</option>)}</select></Champ>}
          {f.type === "pesee" && <Champ libelle="Poids (kg)"><input inputMode="decimal" value={f.poids ?? ""} onChange={(e) => setF({ ...f, poids: e.target.value })} /></Champ>}
          {f.type === "alimentation" && <>
            <Champ libelle="Aliment"><select value={f.article ?? ""} onChange={(e) => setF({ ...f, article: e.target.value })}><option value="">—</option>{(articles.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.libelle}</option>)}</select></Champ>
            <Champ libelle="Quantité distribuée (kg)"><input inputMode="decimal" value={f.q ?? ""} onChange={(e) => setF({ ...f, q: e.target.value })} /></Champ></>}
          <Champ libelle="Notes"><input value={f.notes ?? ""} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Champ>
        </Grille>
        <BoutonPermis permission="elevage:ecrire" onClick={async () => {
          const valeurs: Record<string, unknown> = {};
          if (f.type === "pesee") valeurs.poids_kg = n(f.poids);
          if (f.type === "alimentation") Object.assign(valeurs, { article_id: f.article, quantite: n(f.q), unite: "kg" });
          if (await a.executer(() => api.post(ex("/evenements-elevage"), { type: f.type, animal_id: f.portee === "individuelle" ? f.animal : null, lot_animaux_id: f.portee === "collective" ? f.lot : null, valeurs, notes: f.notes || null }), "Événement enregistré.")) ev.recharger();
        }}>{t("app.enregistrer")}</BoutonPermis>
      </Depliable>
      {peut("elevage:traitement") ? (
        <Depliable titre={`💊 ${t("elevage.traitement")}`}>
          <Avertissement ton="info">Saisie réservée aux personnes autorisées. Recopiez les informations de l'ordonnance : Terroir ne prescrit rien et ne calcule aucun délai d'attente.</Avertissement>
          <Grille>
            <Champ libelle="Portée"><select value={tr.portee} onChange={(e) => setTr({ ...tr, portee: e.target.value })}><option value="individuelle">Un animal</option><option value="collective">Un lot</option></select></Champ>
            {tr.portee === "individuelle" ? <Champ libelle="Animal"><select value={tr.animal ?? ""} onChange={(e) => setTr({ ...tr, animal: e.target.value })}><option value="">—</option>{(animaux.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.identifiant}</option>)}</select></Champ>
              : <Champ libelle="Lot"><select value={tr.lot ?? ""} onChange={(e) => setTr({ ...tr, lot: e.target.value })}><option value="">—</option>{(lots.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.nom}</option>)}</select></Champ>}
            <Champ libelle="Médicament"><input value={tr.med ?? ""} onChange={(e) => setTr({ ...tr, med: e.target.value })} /></Champ>
            <Champ libelle="N° d'ordonnance"><input value={tr.ord ?? ""} onChange={(e) => setTr({ ...tr, ord: e.target.value })} /></Champ>
            <Champ libelle="Prescripteur"><input value={tr.pres ?? ""} onChange={(e) => setTr({ ...tr, pres: e.target.value })} /></Champ>
            <Champ libelle="Délai d'attente viande (recopié de l'ordonnance)"><input value={tr.dav ?? ""} onChange={(e) => setTr({ ...tr, dav: e.target.value })} /></Champ>
            <Champ libelle="Délai d'attente lait (recopié)"><input value={tr.dal ?? ""} onChange={(e) => setTr({ ...tr, dal: e.target.value })} /></Champ>
            <Champ libelle="Fin d'attente indiquée"><input type="date" value={tr.fin ?? ""} onChange={(e) => setTr({ ...tr, fin: e.target.value })} /></Champ>
          </Grille>
          <BoutonPermis permission="elevage:traitement" disabled={!tr.med} onClick={async () => {
            const r = await a.executer(() => api.post(ex("/traitements-animaux"), { animal_id: tr.portee === "individuelle" ? tr.animal : null, lot_animaux_id: tr.portee === "collective" ? tr.lot : null, medicament: tr.med, numero_ordonnance: tr.ord || null, prescripteur: tr.pres || null, delai_attente_viande_saisi: tr.dav || null, delai_attente_lait_saisi: tr.dal || null, date_fin_attente_saisie: tr.fin || null }), "Traitement enregistré.");
            if (r) { setAvert(r.avertissement); ev.recharger(); }
          }}>{t("app.enregistrer")}</BoutonPermis>
        </Depliable>
      ) : <p className="discret">🔒 La saisie des traitements est réservée aux éleveurs et vétérinaires autorisés.</p>}
      <Charge etat={ev} vide={(d) => d.length === 0}>
        {(es) => (
          <Tableau entetes={["Date", "Type", "Portée", "Concerne", "Détail", "Déclaration"]}>
            {es.map((x) => <tr key={x.id}><td>{dateHeure(x.horodatage)}</td><td>{lib("evenement", x.type)}</td>
              <td>{x.portee === "individuelle" ? <Badge ton="info" icone="👤">{t("elevage.individuel")}</Badge> : <Badge ton="neutre" icone="👥">{t("elevage.collectif")} ({x.effectif_concerne ?? "?"})</Badge>}</td>
              <td>{x.animal_id ? animaux.donnees?.find((y) => y.id === x.animal_id)?.identifiant ?? "animal sorti" : lots.donnees?.find((y) => y.id === x.lot_animaux_id)?.nom ?? "…"}</td>
              <td>{x.valeurs?.poids_kg !== undefined && `${quantite(x.valeurs.poids_kg, "kg", 1)} `}{x.valeurs?.quantite !== undefined && `${quantite(x.valeurs.quantite, x.valeurs.unite ?? "kg")} distribués `}
                {x.traitement && <><strong>{x.traitement.medicament}</strong> — ordonnance {x.traitement.numero_ordonnance ?? "—"} · attente viande : {x.traitement.delai_attente_viande_saisi ?? "—"} <Badge ton="neutre" icone="✍">recopié, non vérifié</Badge></>}
                {x.notes && <div className="discret">{x.notes}</div>}</td>
              <td>{x.a_declarer ? <Badge ton="attente">À préparer</Badge> : "—"}</td></tr>)}
          </Tableau>
        )}
      </Charge>
    </Section>
  );
}

function Declarations() {
  const d = useEx("/declarations-a-preparer");
  return (
    <Section titre={t("elevage.declarations")}>
      <Charge etat={d}>{(x: any) => (
        <>
          <Avertissement ton="critique" titre="Aucune transmission officielle">{x.avertissement}</Avertissement>
          <p className="discret">Intégration : {x.integration}</p>
          <Tableau entetes={["Date", "Type", "Portée", "État"]}>
            {x.evenements.map((e: any) => <tr key={e.id}><td>{date(e.horodatage)}</td><td>{lib("evenement", e.type)}</td><td>{e.portee}</td><td><Badge ton="attente">À préparer hors Terroir</Badge></td></tr>)}
          </Tableau>
        </>
      )}</Charge>
    </Section>
  );
}
