"use client";

import { useState } from "react";
import { Avertissement, Badge, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Lien, Message, Onglets, Section, Tableau, useAction } from "@/components/ui";
import { requete } from "@/lib/api";
import { api } from "@/lib/api";
import { date, octets } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, libelles, t } from "@/i18n/fr";

export default function PageDocuments() {
  const [onglet, setOnglet] = useState("liste");
  return (
    <>
      <Entete titre={t("nav.documents")} sousTitre="Baux, documents fournisseurs, contrôles, certificats, démarches et échéances" />
      <Onglets actif={onglet} surChange={setOnglet} onglets={[{ cle: "liste", libelle: t("documents.liste") }, { cle: "echeances", libelle: t("documents.echeances") }, { cle: "dossiers", libelle: t("documents.dossiers") }]} />
      {onglet === "liste" && <Liste />}
      {onglet === "echeances" && <Echeances />}
      {onglet === "dossiers" && <Dossiers />}
    </>
  );
}

function Liste() {
  const { ex } = useSession();
  const [cat, setCat] = useState("");
  const d = useEx<any[]>(`/documents${cat ? `?categorie=${cat}` : ""}`);
  const a = useAction();
  const [f, setF] = useState<Record<string, string>>({ categorie: "autre" });
  const [fichier, setFichier] = useState<File | null>(null);
  async function deposer() {
    if (!fichier) return;
    const fd = new FormData();
    fd.append("fichier", fichier);
    fd.append("categorie", f.categorie);
    fd.append("titre", f.titre || fichier.name);
    if (f.echeance) fd.append("echeance", f.echeance);
    if (f.libelle_echeance) fd.append("libelle_echeance", f.libelle_echeance);
    fd.append("confidentiel", f.confidentiel === "1" ? "true" : "false");
    if (await a.executer(() => requete("POST", ex("/documents"), fd), "Document déposé dans le stockage protégé.")) d.recharger();
  }
  return (
    <Section titre={t("documents.liste")} actions={<Champ libelle="Catégorie"><select value={cat} onChange={(e) => setCat(e.target.value)}><option value="">Toutes</option>{Object.entries(libelles.categorieDocument).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>}>
      <Message erreur={a.erreur} succes={a.succes} />
      <Depliable titre={`⬆ ${t("documents.deposer")}`}>
        <Grille>
          <Champ libelle="Fichier" aide="PDF, PNG, JPEG, WebP, CSV, texte ou GeoJSON — contenu vérifié, 15 Mo maximum."><input type="file" accept=".pdf,.png,.jpg,.jpeg,.webp,.csv,.txt,.geojson,.json" onChange={(e) => setFichier(e.target.files?.[0] ?? null)} /></Champ>
          <Champ libelle="Titre"><input value={f.titre ?? ""} onChange={(e) => setF({ ...f, titre: e.target.value })} /></Champ>
          <Champ libelle="Catégorie"><select value={f.categorie} onChange={(e) => setF({ ...f, categorie: e.target.value })}>{Object.entries(libelles.categorieDocument).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>
          <Champ libelle="Échéance"><input type="date" value={f.echeance ?? ""} onChange={(e) => setF({ ...f, echeance: e.target.value })} /></Champ>
          <Champ libelle="Libellé de l'échéance"><input value={f.libelle_echeance ?? ""} onChange={(e) => setF({ ...f, libelle_echeance: e.target.value })} /></Champ>
          <Champ libelle="Confidentiel"><select value={f.confidentiel ?? "0"} onChange={(e) => setF({ ...f, confidentiel: e.target.value })}><option value="0">Non</option><option value="1">Oui (accès restreint)</option></select></Champ>
        </Grille>
        <BoutonPermis permission="documents:ecrire" disabled={!fichier || a.enCours} onClick={deposer}>Déposer</BoutonPermis>
      </Depliable>
      <Charge etat={d} vide={(x) => x.length === 0}>
        {(ds) => (
          <Tableau entetes={["Titre", "Catégorie", "Fichier", "Taille", "Échéance", "Déposé le", ""]}>
            {ds.map((x) => <tr key={x.id}><td>{x.titre} {x.confidentiel && <Badge ton="alerte" icone="🔒">Confidentiel</Badge>}</td><td>{lib("categorieDocument", x.categorie)}</td><td className="code">{x.nom_fichier ?? "—"}</td><td className="num">{octets(x.taille_octets)}</td>
              <td>{date(x.echeance)}</td><td>{date(x.cree_le)}</td><td>{x.nom_fichier && <Lien href={`/api/v1${ex(`/documents/${x.id}/contenu`)}`} telechargement>{t("app.telecharger")}</Lien>}</td></tr>)}
          </Tableau>
        )}
      </Charge>
    </Section>
  );
}

function Echeances() {
  const e = useEx<any[]>("/echeances");
  return (
    <Section titre={t("documents.echeances")}>
      <Charge etat={e} vide={(x) => x.length === 0}>
        {(es) => (
          <Tableau entetes={["Date", "Échéance", "Origine", "État"]}>
            {es.map((x, i) => <tr key={i}><td>{date(x.date)}</td><td>{x.libelle}</td><td>{x.type}</td><td><Badge ton={x.etat === "echue" ? "critique" : x.etat === "proche" ? "alerte" : "info"}>{x.libelle_etat}</Badge></td></tr>)}
          </Tableau>
        )}
      </Charge>
    </Section>
  );
}

function Dossiers() {
  const { ex } = useSession();
  const d = useEx<any[]>("/dossiers");
  const camp = useEx<any[]>("/campagnes");
  const a = useAction();
  const [f, setF] = useState<Record<string, string>>({ type: "pac" });
  return (
    <Section titre={t("documents.dossiers")}>
      <Avertissement ton="critique" titre="Préparation interne uniquement">Un export de dossier ne constitue ni une déclaration PAC acceptée, ni une transmission officielle. Les démarches se font sur les portails des administrations (par exemple Telepac).</Avertissement>
      <Message erreur={a.erreur} succes={a.succes} />
      <Charge etat={d} vide={(x) => x.length === 0}>
        {(ds) => <>{ds.map((x) => (
          <div className="carte" key={x.id}>
            <div className="carte-entete"><h3 style={{ margin: 0 }}>{x.titre}</h3><Badge ton="attente">En préparation</Badge></div>
            <p className="discret">{x.mention}</p>
            {x.elements.length > 0 && <ul>{x.elements.map((el: any, i: number) => <li key={i}>{el.fait ? "☑" : "☐"} {el.libelle}</li>)}</ul>}
            <Lien href={`/api/v1${ex(`/dossiers/${x.id}/export`)}`} telechargement>{t("documents.exporter")}</Lien>
          </div>
        ))}</>}
      </Charge>
      <Depliable titre="➕ Nouveau dossier de préparation">
        <Grille>
          <Champ libelle="Titre"><input value={f.titre ?? ""} onChange={(e) => setF({ ...f, titre: e.target.value })} /></Champ>
          <Champ libelle="Type"><select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option value="pac">Préparation PAC</option><option value="certification">Certification</option><option value="controle">Contrôle</option><option value="environnement">Environnement</option></select></Champ>
          <Champ libelle="Campagne"><select value={f.camp ?? ""} onChange={(e) => setF({ ...f, camp: e.target.value })}><option value="">—</option>{(camp.donnees ?? []).map((c) => <option key={c.id} value={c.id}>{c.libelle}</option>)}</select></Champ>
        </Grille>
        <Champ libelle="Éléments à réunir (un par ligne)"><textarea value={f.el ?? ""} onChange={(e) => setF({ ...f, el: e.target.value })} /></Champ>
        <BoutonPermis permission="documents:ecrire" disabled={!f.titre} onClick={async () => {
          if (await a.executer(() => api.post(ex("/dossiers"), { titre: f.titre, type: f.type, campagne_id: f.camp || null, elements: (f.el ?? "").split("\n").filter(Boolean).map((l) => ({ libelle: l, fait: false, document_ids: [] })) }), "Dossier créé.")) d.recharger();
        }}>{t("app.enregistrer")}</BoutonPermis>
      </Depliable>
    </Section>
  );
}
