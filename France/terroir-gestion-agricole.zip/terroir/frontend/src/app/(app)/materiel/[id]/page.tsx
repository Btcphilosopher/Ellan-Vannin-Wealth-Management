"use client";

import { use, useState } from "react";
import Link from "next/link";
import { BadgeDispo, SourceHeures } from "@/components/metier";
import { Avertissement, Badge, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Section, Tableau, Valeurs, useAction } from "@/components/ui";
import { api } from "@/lib/api";
import { date, dateHeure, euros, nombre, quantite } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { t } from "@/i18n/fr";

export default function DetailMateriel({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const etat = useEx(`/materiels/${id}`);
  const { ex } = useSession();
  const a = useAction();
  const [defaut, setDefaut] = useState({ gravite: "bloquant", description: "" });
  const [maint, setMaint] = useState({ type: "preventive", libelle: "", immobilise_du: "", immobilise_au: "" });
  return (
    <Charge etat={etat}>
      {(m: any) => (
        <>
          <Entete titre={`${m.code} — ${m.libelle}`} sousTitre={<Link href="/materiel">{t("app.retour")}</Link>} actions={<BadgeDispo d={m.disponibilite} />} />
          <Message erreur={a.erreur} succes={a.succes} />
          {!m.disponibilite.disponible && <Avertissement ton="critique" titre="Matériel indisponible">{m.disponibilite.motifs.join(" ; ")}</Avertissement>}
          <div className="grille-2">
            <Section titre="Fiche">
              <Valeurs items={[["Catégorie", m.categorie], ["Marque / modèle", `${m.marque ?? "—"} ${m.modele ?? ""}`], ["Propriété", m.propriete],
                ["Débit de chantier", m.debit_chantier_ha_h ? `${nombre(m.debit_chantier_ha_h, 1)} ha/h` : "—"],
                ["Consommation de référence", m.consommation_reference_l_h ? `${nombre(m.consommation_reference_l_h, 1)} L/h` : "—"],
                [t("materiel.heures"), <SourceHeures h={m.heures_moteur} />]]} />
            </Section>
            <Section titre={t("materiel.consommation")}>
              <p className="discret">{m.consommation.methode}</p>
              {m.consommation.statut === "donnees_insuffisantes" && <Avertissement ton="info" titre="Données insuffisantes">au moins {m.consommation.minimum_periodes} périodes entre pleins sont nécessaires pour repérer des valeurs atypiques ({m.consommation.periodes.length} disponible(s)).</Avertissement>}
              <Tableau entetes={["Du", "Au", "Heures", "Litres", "L/h", ""]}>
                {m.consommation.periodes.map((p: any, i: number) => <tr key={i}><td>{date(p.du)}</td><td>{date(p.au)}</td><td className="num">{nombre(p.heures, 1)}</td><td className="num">{nombre(p.litres, 0)}</td><td className="num">{nombre(p.l_h, 2)}</td><td>{p.atypique ? <Badge ton="alerte">Atypique — à investiguer</Badge> : ""}</td></tr>)}
              </Tableau>
            </Section>
          </div>
          <Section titre={t("materiel.maintenances")}>
            <Tableau entetes={["Libellé", "Type", "Immobilisation", "État", ""]}>
              {m.maintenances.map((x: any) => <tr key={x.id}><td>{x.libelle}</td><td>{x.type}</td><td>{x.immobilise_du ? `${dateHeure(x.immobilise_du)} → ${dateHeure(x.immobilise_au)}` : "—"}</td>
                <td><Badge ton={x.statut === "realisee" ? "ok" : "attente"}>{x.statut === "realisee" ? `Réalisée le ${date(x.realisee_le)}` : "Planifiée"}</Badge></td>
                <td>{x.statut !== "realisee" && <BoutonPermis permission="materiel:ecrire" className="bouton bouton-petit" onClick={async () => { if (await a.executer(() => api.post(ex(`/maintenances/${x.id}/realisation`)), "Maintenance réalisée.")) etat.recharger(); }}>Marquer réalisée</BoutonPermis>}</td></tr>)}
            </Tableau>
            <Depliable titre="➕ Planifier une maintenance">
              <Grille>
                <Champ libelle="Type"><select value={maint.type} onChange={(e) => setMaint({ ...maint, type: e.target.value })}><option value="preventive">Préventive</option><option value="corrective">Corrective</option><option value="controle_reglementaire">Contrôle réglementaire</option></select></Champ>
                <Champ libelle="Libellé"><input value={maint.libelle} onChange={(e) => setMaint({ ...maint, libelle: e.target.value })} /></Champ>
                <Champ libelle="Immobilisé du"><input type="datetime-local" value={maint.immobilise_du} onChange={(e) => setMaint({ ...maint, immobilise_du: e.target.value })} /></Champ>
                <Champ libelle="au"><input type="datetime-local" value={maint.immobilise_au} onChange={(e) => setMaint({ ...maint, immobilise_au: e.target.value })} /></Champ>
              </Grille>
              <BoutonPermis permission="materiel:ecrire" onClick={async () => { if (await a.executer(() => api.post(ex(`/materiels/${id}/maintenances`), { ...maint, immobilise_du: maint.immobilise_du ? new Date(maint.immobilise_du).toISOString() : null, immobilise_au: maint.immobilise_au ? new Date(maint.immobilise_au).toISOString() : null }), "Maintenance planifiée : elle apparaît dans le planning.")) etat.recharger(); }}>{t("app.enregistrer")}</BoutonPermis>
            </Depliable>
          </Section>
          <Section titre={t("materiel.defauts")}>
            <Tableau entetes={["Constaté le", "Gravité", "Description", "État", ""]}>
              {m.defauts.map((d: any) => <tr key={d.id}><td>{dateHeure(d.constate_le)}</td><td><Badge ton={d.gravite === "bloquant" ? "critique" : "alerte"}>{d.gravite === "bloquant" ? "Bloquant" : d.gravite === "limitant" ? "Limitant" : "Mineur"}</Badge></td><td>{d.description}</td>
                <td>{d.statut === "resolu" ? <Badge ton="ok">Résolu</Badge> : <Badge ton="alerte">Ouvert</Badge>}</td>
                <td>{d.statut !== "resolu" && <BoutonPermis permission="materiel:ecrire" className="bouton bouton-petit" onClick={async () => { if (await a.executer(() => api.post(ex(`/defauts/${d.id}/resolution`)), "Défaut résolu.")) etat.recharger(); }}>Résolu</BoutonPermis>}</td></tr>)}
            </Tableau>
            <Depliable titre={`⚠ ${t("materiel.signalerDefaut")}`}>
              <Grille>
                <Champ libelle="Gravité"><select value={defaut.gravite} onChange={(e) => setDefaut({ ...defaut, gravite: e.target.value })}><option value="bloquant">Bloquant (matériel indisponible)</option><option value="limitant">Limitant</option><option value="mineur">Mineur</option></select></Champ>
                <Champ libelle="Description"><input value={defaut.description} onChange={(e) => setDefaut({ ...defaut, description: e.target.value })} /></Champ>
              </Grille>
              <BoutonPermis permission="interventions:realiser" disabled={!defaut.description} onClick={async () => { if (await a.executer(() => api.post(ex(`/materiels/${id}/defauts`), defaut), "Défaut signalé.")) etat.recharger(); }}>Signaler</BoutonPermis>
            </Depliable>
          </Section>
          <div className="grille-2">
            <Section titre={t("materiel.pleins")}>
              <Tableau entetes={["Date", "Litres", "Compteur", "Source"]}>
                {m.pleins.map((p: any) => <tr key={p.id}><td>{dateHeure(p.horodatage)}</td><td className="num">{quantite(p.litres, "L", 0)}</td><td className="num">{p.heures_compteur ? quantite(p.heures_compteur, "h", 1) : "—"}</td><td>{p.source}</td></tr>)}
              </Tableau>
            </Section>
            <Section titre="Relevés d'heures moteur">
              <Tableau entetes={["Date", "Heures", "Source"]}>
                {m.releves_heures.map((r: any) => <tr key={r.id}><td>{dateHeure(r.horodatage)}</td><td className="num">{nombre(r.heures_moteur, 1)}</td><td>{r.source.startsWith("telemetrie") ? <Badge ton="info" icone="📡">Télémétrie (simulée)</Badge> : <Badge ton="neutre" icone="✍">Saisie manuelle</Badge>}</td></tr>)}
              </Tableau>
            </Section>
          </div>
        </>
      )}
    </Charge>
  );
}
