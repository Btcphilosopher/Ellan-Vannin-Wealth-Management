"use client";

import Link from "next/link";
import { Badge, Charge, Entete, Section, Tableau } from "@/components/ui";
import { BadgeDispo, SourceHeures } from "@/components/metier";
import { date, dateHeure, nombre, quantite } from "@/lib/format";
import { useEx } from "@/lib/session";
import { t } from "@/i18n/fr";

export default function PageMateriel() {
  const l = useEx<any[]>("/materiels");
  return (
    <>
      <Entete titre={t("nav.materiel")} sousTitre="Parc, disponibilité, maintenance et consommation" />
      <Section>
        <Charge etat={l} vide={(d) => d.length === 0}>
          {(ms) => (
            <Tableau entetes={["Code", "Matériel", "Catégorie", t("materiel.disponibilite"), t("materiel.restrictions"), t("materiel.heures"), "Contrôles"]}>
              {ms.map((m) => (
                <tr key={m.id}>
                  <td><Link href={`/materiel/${m.id}`}><strong>{m.code}</strong></Link></td>
                  <td>{m.libelle}<div className="discret">{m.marque} {m.modele ?? ""} · {m.propriete === "cuma" ? "CUMA" : m.propriete}</div></td>
                  <td>{m.categorie}</td>
                  <td><BadgeDispo d={m.disponibilite} />{m.disponibilite.motifs.map((x: string, i: number) => <div key={i} className="discret">⛔ {x}</div>)}</td>
                  <td>{m.restrictions_30_jours.length ? m.restrictions_30_jours.map((r: any, i: number) => <div key={i}><Badge ton="alerte">{r.type === "maintenance" ? "Maintenance" : "Défaut"}</Badge> <span className="discret">{date(r.du)}{r.au ? ` → ${date(r.au)}` : ""}</span></div>) : "—"}</td>
                  <td><SourceHeures h={m.heures_moteur} /></td>
                  <td>{m.documents_controle.length ? m.documents_controle.map((d: any) => <div key={d.id}>{d.echu ? <Badge ton="critique">Échu</Badge> : <Badge ton="ok">Valide</Badge>} {d.titre}</div>) : <span className="discret">aucun document</span>}</td>
                </tr>
              ))}
            </Tableau>
          )}
        </Charge>
      </Section>
      <p className="discret">📡 Télémétrie (simulée) : valeurs fournies par un simulateur, distinctes des saisies manuelles (✍). Terroir ne commande aucune machine.</p>
    </>
  );
}
