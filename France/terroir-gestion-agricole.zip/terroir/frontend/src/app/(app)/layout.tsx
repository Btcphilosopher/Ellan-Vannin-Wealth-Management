"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { api, ErreurApi } from "@/lib/api";
import { CLE_PROFIL, FournisseurSession, Profil } from "@/lib/session";
import { t } from "@/i18n/fr";

const NAV: [string, string, string][] = [
  ["/", "tableau", "▦"], ["/parcelles", "parcelles", "⬚"], ["/cultures", "cultures", "🌱"], ["/elevage", "elevage", "🐑"],
  ["/travaux", "travaux", "🚜"], ["/materiel", "materiel", "🔧"], ["/stocks", "stocks", "📦"], ["/achats", "achats", "🛒"],
  ["/ventes", "ventes", "🚚"], ["/equipe", "equipe", "👥"], ["/documents", "documents", "📄"], ["/analyses", "analyses", "📊"],
  ["/parametres", "parametres", "⚙"],
];

export default function CoquilleApp({ children }: { children: React.ReactNode }) {
  const [profil, setProfil] = useState<Profil | null>(null);
  const [erreur, setErreur] = useState<string | null>(null);
  const [ouverte, setOuverte] = useState(false);
  const chemin = usePathname();
  const routeur = useRouter();

  useEffect(() => {
    api.get<Profil>("/auth/moi")
      .then((p) => {
        if (!p.adhesions.length) { setErreur("Votre compte n'est rattaché à aucune exploitation."); return; }
        setProfil(p);
        try { localStorage.setItem(CLE_PROFIL, JSON.stringify(p)); } catch { /* ignoré */ }
      })
      .catch((e) => {
        if (e instanceof ErreurApi && e.statut === 401) routeur.replace("/connexion");
        else setErreur(e instanceof ErreurApi ? e.message : String(e));
      });
  }, [routeur]);

  useEffect(() => setOuverte(false), [chemin]);

  async function deconnecter() {
    await api.post("/auth/deconnexion").catch(() => undefined);
    try { localStorage.removeItem(CLE_PROFIL); } catch { /* ignoré */ }
    routeur.replace("/connexion");
  }

  if (erreur) return <main className="contenu"><div className="message message-erreur">⛔ {erreur} <a href="/connexion">{t("connexion.titre")}</a></div></main>;
  if (!profil) return <main className="contenu"><p className="chargement">⏳ {t("app.chargement")}</p></main>;
  const a = profil.adhesions[0];
  const actif = (href: string) => (href === "/" ? chemin === "/" : chemin.startsWith(href));

  return (
    <FournisseurSession profil={profil}>
      <div className="barre-mobile">
        <button className="bouton bouton-petit" onClick={() => setOuverte(true)} aria-expanded={ouverte} aria-controls="navigation">☰ {t("app.menu")}</button>
        <strong>🌾 {t("app.nom")}</strong>
        <Link className="bouton bouton-petit" href="/terrain">📱 {t("nav.terrain")}</Link>
      </div>
      <div className="coquille">
        <nav id="navigation" className={`nav ${ouverte ? "ouverte" : ""}`} aria-label="Navigation principale">
          <Link href="/" className="nav-marque"><span aria-hidden="true">🌾</span><span>{t("app.nom")}<small>{t("app.sousTitre")}</small></span></Link>
          <ul>
            {NAV.map(([href, cle, icone]) => (
              <li key={href}>
                <Link className="nav-lien" href={href} aria-current={actif(href) ? "page" : undefined}>
                  <span className="nav-icone" aria-hidden="true">{icone}</span>{t(`nav.${cle}`)}
                </Link>
              </li>
            ))}
            <li><Link className="nav-lien" href="/terrain"><span className="nav-icone" aria-hidden="true">📱</span>{t("nav.terrain")}</Link></li>
          </ul>
          <div className="nav-pied">
            <div><strong>{profil.nom_affiche}</strong></div>
            <div>{a.libelle_role}</div>
            <div>{a.raison_sociale}</div>
            <button className="bouton bouton-petit bouton-accent" onClick={deconnecter}>{t("app.deconnexion")}</button>
          </div>
        </nav>
        <div>
          {a.fictive && <div className="bandeau-demo" role="note">🧪 {t("app.demo")}</div>}
          <main className="contenu">{children}</main>
        </div>
      </div>
    </FournisseurSession>
  );
}
