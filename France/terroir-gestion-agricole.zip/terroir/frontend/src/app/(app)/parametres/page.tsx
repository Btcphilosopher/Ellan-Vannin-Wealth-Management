"use client";

import { useEffect, useState } from "react";
import { Avertissement, Badge, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Lien, Message, Onglets, Section, Tableau, useAction } from "@/components/ui";
import { api } from "@/lib/api";
import { dateHeure } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

export default function PageParametres() {
  const { peut } = useSession();
  const [onglet, setOnglet] = useState("modules");
  const onglets = [{ cle: "modules", libelle: t("parametres.modules") }, { cle: "adaptateurs", libelle: t("parametres.adaptateurs") }];
  if (peut("parametres:ecrire")) onglets.splice(1, 0, { cle: "utilisateurs", libelle: t("parametres.utilisateurs") });
  if (peut("audit:lire")) onglets.push({ cle: "audit", libelle: t("parametres.audit") });
  onglets.push({ cle: "donnees", libelle: t("parametres.export") });
  return (
    <>
      <Entete titre={t("nav.parametres")} sousTitre="Modules, accès, intégrations, audit et données" />
      <Onglets actif={onglet} surChange={setOnglet} onglets={onglets} />
      {onglet === "modules" && <Modules />}
      {onglet === "utilisateurs" && <Utilisateurs />}
      {onglet === "adaptateurs" && <Adaptateurs />}
      {onglet === "audit" && <Audit />}
      {onglet === "donnees" && <Donnees />}
    </>
  );
}

function Modules() {
  const { ex } = useSession();
  const e = useEx("");
  const a = useAction();
  const [actifs, setActifs] = useState<string[] | null>(null);
  useEffect(() => { if (e.donnees && actifs === null) setActifs(e.donnees.modules_actifs); }, [e.donnees, actifs]);
  return (
    <Section titre={t("parametres.modules")}>
      <Charge etat={e}>
        {(d: any) => (
          <>
            <Tableau entetes={["Activé", "Module", "État de développement"]}>
              {Object.entries(d.modules_disponibles).map(([k, m]: any) => (
                <tr key={k}><td><input type="checkbox" aria-label={m.libelle} checked={actifs?.includes(k) ?? false} onChange={(ev) => setActifs(ev.target.checked ? [...(actifs ?? []), k] : (actifs ?? []).filter((x) => x !== k))} /></td>
                  <td>{m.libelle} {actifs?.includes(k) ? <Badge ton="ok">Activé</Badge> : <Badge ton="neutre" icone="○">Désactivé</Badge>}</td><td>{m.etat}</td></tr>
              ))}
            </Tableau>
            <Message erreur={a.erreur} succes={a.succes} />
            <BoutonPermis permission="parametres:ecrire" onClick={() => a.executer(() => api.put(ex("/modules"), { modules_actifs: actifs }), "Modules enregistrés (rechargez la page pour mettre à jour la session).")}>{t("app.enregistrer")}</BoutonPermis>
          </>
        )}
      </Charge>
    </Section>
  );
}

function Utilisateurs() {
  const { ex } = useSession();
  const u = useEx<any[]>("/utilisateurs");
  const rolesData = useRoles();
  const a = useAction();
  const [f, setF] = useState<Record<string, string>>({ role: "lecture" });
  return (
    <Section titre={t("parametres.utilisateurs")}>
      <Charge etat={u}>{(us) => (
        <Tableau entetes={["Nom", "Courriel", "Rôle", "État"]}>
          {us.map((x) => <tr key={x.id}><td>{x.nom_affiche}</td><td>{x.courriel}</td><td>{x.libelle_role}</td><td>{x.actif ? <Badge ton="ok">Actif</Badge> : <Badge ton="neutre">Désactivé</Badge>}</td></tr>)}
        </Tableau>
      )}</Charge>
      <Depliable titre="➕ Ajouter un utilisateur">
        <Grille>
          <Champ libelle="Nom affiché"><input value={f.nom ?? ""} onChange={(e) => setF({ ...f, nom: e.target.value })} /></Champ>
          <Champ libelle="Courriel"><input type="email" value={f.c ?? ""} onChange={(e) => setF({ ...f, c: e.target.value })} /></Champ>
          <Champ libelle="Mot de passe initial" aide="12 caractères minimum."><input type="password" value={f.m ?? ""} onChange={(e) => setF({ ...f, m: e.target.value })} /></Champ>
          <Champ libelle="Rôle"><select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}>{Object.entries(rolesData ?? {}).map(([k, v]: any) => <option key={k} value={k}>{v.libelle}</option>)}</select></Champ>
        </Grille>
        <Message erreur={a.erreur} succes={a.succes} />
        <BoutonPermis permission="parametres:ecrire" onClick={async () => { if (await a.executer(() => api.post(ex("/utilisateurs"), { courriel: f.c, nom_affiche: f.nom, mot_de_passe: f.m, role: f.role }), "Utilisateur ajouté.")) u.recharger(); }}>{t("app.enregistrer")}</BoutonPermis>
      </Depliable>
      {rolesData && (
        <Depliable titre="Permissions par rôle">
          <Tableau entetes={["Rôle", "Permissions"]}>{Object.entries(rolesData).map(([k, v]: any) => <tr key={k}><td>{v.libelle}</td><td className="discret">{v.permissions.join(", ")}</td></tr>)}</Tableau>
        </Depliable>
      )}
    </Section>
  );
}

function useRoles() {
  const [r, setR] = useState<any>(null);
  useEffect(() => { api.get("/roles").then(setR).catch(() => setR(null)); }, []);
  return r;
}

function Adaptateurs() {
  const a = useEx<any[]>("/adaptateurs");
  return (
    <Section titre={t("parametres.adaptateurs")}>
      <Avertissement ton="info">La première version n'utilise que des simulateurs et des imports de fichiers. Aucun accès à un système propriétaire ou administratif n'est simulé comme s'il était réel.</Avertissement>
      <Charge etat={a}>{(as) => (
        <Tableau entetes={["Domaine", "Adaptateur", "Statut", "Description"]}>
          {as.map((x) => <tr key={x.cle}><td>{x.domaine}</td><td>{x.nom}</td>
            <td>{x.statut === "integre" ? <Badge ton="ok">{lib("adaptateur", x.statut)}</Badge> : x.statut === "simule" ? <Badge ton="info" icone="🧪">{lib("adaptateur", x.statut)}</Badge> : <Badge ton="neutre" icone="✗">{lib("adaptateur", x.statut)}</Badge>}</td>
            <td>{x.description}{x.documentation && <div className="discret">{x.documentation}</div>}</td></tr>)}
        </Tableau>
      )}</Charge>
    </Section>
  );
}

function Audit() {
  const a = useEx<any[]>("/audit?limite=200");
  return (
    <Section titre={t("parametres.audit")}>
      <Charge etat={a}>{(es) => (
        <Tableau entetes={["Horodatage", "Auteur", "Action", "Entité", "Origine", "Modification"]}>
          {es.map((x) => <tr key={x.id}><td>{dateHeure(x.horodatage)}</td><td>{x.auteur ?? "—"}</td><td>{x.action}</td><td>{x.entite} <span className="discret code">{x.entite_id?.slice(0, 8)}</span></td><td>{x.origine}</td>
            <td className="discret" style={{ maxWidth: 360, overflowWrap: "anywhere" }}>{x.apres ? JSON.stringify(x.apres).slice(0, 160) : "—"}</td></tr>)}
        </Tableau>
      )}</Charge>
    </Section>
  );
}

function Donnees() {
  const { ex, peut } = useSession();
  const taches = useEx<any[]>("/taches");
  const a = useAction();
  return (
    <>
      <Section titre={t("parametres.export")}>
        <p>Export de toutes les données de l'exploitation (une table par fichier JSON, géométries en GeoJSON, manifeste).</p>
        {peut("donnees:exporter") ? <Lien href={`/api/v1${ex("/export-donnees")}`} telechargement>{t("parametres.exporter")}</Lien> : <button className="bouton desactive" disabled>🔒 {t("parametres.exporter")}</button>}
        <Message erreur={a.erreur} succes={a.succes} />
        <BoutonPermis permission="parametres:ecrire" className="bouton bouton-secondaire" onClick={async () => { if (await a.executer(() => api.post(ex("/taches/export_donnees"), {}), "Export mis en file : il sera rangé dans les documents confidentiels.")) taches.recharger(); }}>Lancer l'export en arrière-plan</BoutonPermis>
      </Section>
      <Section titre={t("parametres.taches")}>
        <Charge etat={taches}>{(ts) => (
          <Tableau entetes={["Créée le", "Type", "État", "Résultat"]}>
            {ts.map((x) => <tr key={x.id}><td>{dateHeure(x.cree_le)}</td><td>{x.type}</td><td>{x.statut === "terminee" ? <Badge ton="ok">Terminée</Badge> : x.statut === "echec" ? <Badge ton="critique">Échec</Badge> : <Badge ton="attente">{x.statut === "en_cours" ? "En cours" : "En attente"}</Badge>}</td><td className="discret">{x.resultat ? JSON.stringify(x.resultat).slice(0, 120) : x.erreur?.slice(0, 120) ?? "—"}</td></tr>)}
          </Tableau>
        )}</Charge>
      </Section>
    </>
  );
}
