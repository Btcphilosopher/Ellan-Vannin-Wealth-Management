"use client";

import { useState } from "react";
import { Badge, BoutonPermis, Champ, Charge, Depliable, Entete, Grille, Message, Section, Tableau, useAction } from "@/components/ui";
import { api } from "@/lib/api";
import { date, euros, quantite } from "@/lib/format";
import { useEx, useSession } from "@/lib/session";
import { lib, t } from "@/i18n/fr";

export default function PageEquipe() {
  const { ex } = useSession();
  const m = useEx<any[]>("/membres");
  const tps = useEx<any[]>("/temps-travail");
  const tarifs = useEx<any[]>("/tarifs");
  const a = useAction();
  const [f, setF] = useState<Record<string, string>>({ activite: "intervention" });
  const [c, setC] = useState<Record<string, string>>({});
  const nom = (id: string) => { const x = m.donnees?.find((y) => y.id === id); return x ? `${x.prenom} ${x.nom}` : "…"; };
  const aujourd = new Date().toISOString().slice(0, 10);
  return (
    <>
      <Entete titre={t("nav.equipe")} sousTitre="Personnes, prestataires, compétences, affectations et temps de travail" />
      <Message erreur={a.erreur} succes={a.succes} />
      <Section titre={t("equipe.membres")}>
        <Charge etat={m} vide={(d) => d.length === 0}>
          {(ms) => (
            <Tableau entetes={["Nom", "Statut", "Fonction", t("equipe.competences"), "Coût horaire en vigueur"]}>
              {ms.map((x) => {
                const tarif = tarifs.donnees?.filter((y) => y.ressource_id === x.id && !y.valide_au).at(-1);
                return (
                  <tr key={x.id}><td><strong>{x.prenom} {x.nom}</strong>{x.entreprise && <div className="discret">{x.entreprise}</div>}</td><td>{x.statut === "prestataire" ? <Badge ton="info" icone="🏢">Prestataire</Badge> : x.statut}</td><td>{x.fonction ?? "—"}</td>
                    <td>{x.competences.length ? x.competences.map((co: any) => <div key={co.id}>{co.valide ? <Badge ton="ok">Valide</Badge> : <Badge ton="critique">Échue</Badge>} {co.libelle} <span className="discret">{co.valide_au ? `jusqu'au ${date(co.valide_au)}` : "sans échéance"}</span></div>) : "—"}</td>
                    <td className="num">{tarif ? <>{euros(tarif.cout_horaire_eur)}/h <span className="discret">v{tarif.version} depuis le {date(tarif.valide_du)}</span></> : "—"}</td></tr>
                );
              })}
            </Tableau>
          )}
        </Charge>
        <Depliable titre="➕ Ajouter une compétence">
          <Grille>
            <Champ libelle="Personne"><select value={c.m ?? ""} onChange={(e) => setC({ ...c, m: e.target.value })}><option value="">—</option>{(m.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.prenom} {x.nom}</option>)}</select></Champ>
            <Champ libelle="Type"><select value={c.type ?? ""} onChange={(e) => setC({ ...c, type: e.target.value })}><option value="">—</option>{[["certiphyto_operateur", "Certiphyto opérateur"], ["certiphyto_decideur", "Certiphyto décideur"], ["conduite_tracteur", "Conduite d'engins"], ["caces", "CACES"], ["soins_animaux", "Soins aux animaux"]].map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>
            <Champ libelle="Libellé"><input value={c.lib ?? ""} onChange={(e) => setC({ ...c, lib: e.target.value })} /></Champ>
            <Champ libelle="Valide jusqu'au"><input type="date" value={c.au ?? ""} onChange={(e) => setC({ ...c, au: e.target.value })} /></Champ>
          </Grille>
          <BoutonPermis permission="equipe:ecrire" disabled={!c.m || !c.type || !c.lib} onClick={async () => { if (await a.executer(() => api.post(ex(`/membres/${c.m}/competences`), { type: c.type, libelle: c.lib, valide_au: c.au || null }), "Compétence ajoutée.")) m.recharger(); }}>{t("app.enregistrer")}</BoutonPermis>
        </Depliable>
      </Section>
      <Section titre={t("equipe.temps")}>
        <Depliable titre={`➕ ${t("equipe.saisirTemps")}`}>
          <Grille>
            <Champ libelle="Personne"><select value={f.m ?? ""} onChange={(e) => setF({ ...f, m: e.target.value })}><option value="">—</option>{(m.donnees ?? []).map((x) => <option key={x.id} value={x.id}>{x.prenom} {x.nom}</option>)}</select></Champ>
            <Champ libelle="Date"><input type="date" value={f.d ?? aujourd} onChange={(e) => setF({ ...f, d: e.target.value })} /></Champ>
            <Champ libelle="Heures"><input inputMode="decimal" value={f.h ?? ""} onChange={(e) => setF({ ...f, h: e.target.value })} /></Champ>
            <Champ libelle="Activité"><select value={f.activite} onChange={(e) => setF({ ...f, activite: e.target.value })}>{[["intervention", "Intervention"], ["elevage", "Élevage"], ["entretien", "Entretien"], ["administratif", "Administratif"], ["commercial", "Commercial"], ["stockage", "Stockage"]].map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Champ>
          </Grille>
          <BoutonPermis permission="interventions:realiser" disabled={!f.m || !f.h} onClick={async () => { if (await a.executer(() => api.post(ex("/temps-travail"), { membre_id: f.m, date: f.d ?? aujourd, heures: Number(f.h.replace(",", ".")), activite: f.activite }), "Temps enregistré.")) tps.recharger(); }}>{t("app.enregistrer")}</BoutonPermis>
        </Depliable>
        <Charge etat={tps} vide={(d) => d.length === 0}>
          {(ts) => (
            <Tableau entetes={["Date", "Personne", "Activité", "Heures", "Source"]}>
              {ts.slice(0, 100).map((x) => <tr key={x.id}><td>{date(x.date)}</td><td>{nom(x.membre_id)}</td><td>{x.activite}</td><td className="num">{quantite(x.heures, "h", 2)}</td><td>{x.source === "saisie" ? "Saisie manuelle" : x.source}</td></tr>)}
            </Tableau>
          )}
        </Charge>
      </Section>
    </>
  );
}
