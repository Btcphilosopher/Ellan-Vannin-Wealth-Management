"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api, ErreurApi } from "@/lib/api";
import { CLE_PROFIL } from "@/lib/session";
import { Message } from "@/components/ui";
import { t } from "@/i18n/fr";

const MDP_DEMO = "Terroir-Demo-2026!";
const COMPTES = [
  ["claire.martin@trois-vallees.example", "Claire Martin", "Gérante"],
  ["julien.roche@trois-vallees.example", "Julien Roche", "Chef de culture"],
  ["sofia.benali@trois-vallees.example", "Sofia Benali", "Opératrice"],
  ["marc.dubois@trois-vallees.example", "Marc Dubois", "Éleveur"],
  ["agnes.leroy@conseil.example", "Agnès Leroy", "Conseillère"],
  ["dr.perrin@veto.example", "Dr Hélène Perrin", "Vétérinaire"],
  ["lucie.garnier@compta.example", "Lucie Garnier", "Comptable"],
];

export default function PageConnexion() {
  const routeur = useRouter();
  const [courriel, setCourriel] = useState("");
  const [mdp, setMdp] = useState("");
  const [erreur, setErreur] = useState<string | null>(null);
  const [enCours, setEnCours] = useState(false);

  async function connecter(c = courriel, m = mdp) {
    setEnCours(true);
    setErreur(null);
    try {
      const profil = await api.post("/auth/connexion", { courriel: c, mot_de_passe: m });
      delete profil.jeton; // le cookie httpOnly porte la session ; le jeton n'est pas conservé côté navigateur
      try { localStorage.setItem(CLE_PROFIL, JSON.stringify(profil)); } catch { /* stockage indisponible */ }
      routeur.push("/");
    } catch (e) {
      setErreur(e instanceof ErreurApi ? e.message : String(e));
    } finally {
      setEnCours(false);
    }
  }

  return (
    <main className="connexion">
      <div>
        <div className="marque-grande">
          <h1>🌾 {t("app.nom")}</h1>
          <p>{t("app.sousTitre")}</p>
        </div>
        <section className="carte">
          <h2>{t("connexion.titre")}</h2>
          <form onSubmit={(e) => { e.preventDefault(); connecter(); }}>
            <label className="champ"><span className="champ-libelle">{t("connexion.courriel")}</span>
              <input type="email" autoComplete="username" required value={courriel} onChange={(e) => setCourriel(e.target.value)} />
            </label>
            <label className="champ"><span className="champ-libelle">{t("connexion.motDePasse")}</span>
              <input type="password" autoComplete="current-password" required value={mdp} onChange={(e) => setMdp(e.target.value)} />
            </label>
            <Message erreur={erreur} />
            <button className="bouton" type="submit" disabled={enCours}>{enCours ? t("connexion.enCours") : t("connexion.seConnecter")}</button>
          </form>
          <h3>🧪 {t("connexion.comptesDemo")}</h3>
          <p className="discret">{t("connexion.explicationDemo")} <code className="code">{MDP_DEMO}</code></p>
          <ul className="liste-comptes">
            {COMPTES.map(([c, nom, role]) => (
              <li key={c}>
                <button className="bouton bouton-secondaire" type="button" disabled={enCours} onClick={() => { setCourriel(c); setMdp(MDP_DEMO); connecter(c, MDP_DEMO); }}>
                  <span><strong>{nom}</strong> — {role}</span><span className="discret">{c}</span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </main>
  );
}
