import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Terroir — Gestion agricole", template: "%s · Terroir" },
  description: "Gestion d'exploitation agricole : parcelles, cultures, travaux, stocks, traçabilité, élevage et analyses.",
  manifest: "/manifest.webmanifest",
};

export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#1f4d2b" };

export default function RacineLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>
        {children}
      </body>
    </html>
  );
}
