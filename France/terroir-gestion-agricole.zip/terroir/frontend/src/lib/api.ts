/** Client HTTP de l'API Terroir (même origine, proxifiée par Next.js). */

export class ErreurApi extends Error {
  constructor(public statut: number, public code: string, message: string, public details?: unknown) {
    super(message);
  }
}

async function lireErreur(r: Response): Promise<ErreurApi> {
  try {
    const j = await r.json();
    let message = j.message ?? j.detail ?? `Erreur ${r.status}`;
    if (Array.isArray(j.details) && j.details.length) {
      message += " " + j.details.map((d: { champ: string; message: string }) => `${d.champ} : ${d.message}`).join(" ; ");
    }
    return new ErreurApi(r.status, j.code ?? "erreur", message, j.details);
  } catch {
    return new ErreurApi(r.status, "erreur", r.status >= 500 ? "Le serveur ne répond pas correctement. Réessayez plus tard." : `Erreur ${r.status}`);
  }
}

export async function requete<T = unknown>(methode: string, chemin: string, corps?: unknown, brut = false): Promise<T> {
  const url = chemin.startsWith("/api/") ? chemin : `/api/v1${chemin}`;
  const entetes: Record<string, string> = {};
  let body: BodyInit | undefined;
  if (methode !== "GET") entetes["X-Terroir-Requete"] = "1";
  if (corps instanceof FormData) body = corps;
  else if (corps !== undefined) {
    entetes["Content-Type"] = "application/json";
    body = JSON.stringify(corps);
  }
  let r: Response;
  try {
    r = await fetch(url, { method: methode, headers: entetes, body, credentials: "same-origin" });
  } catch {
    throw new ErreurApi(0, "reseau", "Connexion au serveur impossible (réseau indisponible ?).");
  }
  if (!r.ok) throw await lireErreur(r);
  if (brut) return r as unknown as T;
  if (r.status === 204) return undefined as T;
  const type = r.headers.get("content-type") ?? "";
  return (type.includes("json") ? r.json() : r.text()) as Promise<T>;
}

export const api = {
  get: <T = any>(c: string) => requete<T>("GET", c),
  post: <T = any>(c: string, corps?: unknown) => requete<T>("POST", c, corps),
  put: <T = any>(c: string, corps?: unknown) => requete<T>("PUT", c, corps),
  patch: <T = any>(c: string, corps?: unknown) => requete<T>("PATCH", c, corps),
  del: <T = any>(c: string) => requete<T>("DELETE", c),
};

/** Construit une chaîne de requête en ignorant les valeurs vides. */
export function qs(params: Record<string, string | number | boolean | null | undefined>): string {
  const p = Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== "");
  return p.length ? "?" + p.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`).join("&") : "";
}
