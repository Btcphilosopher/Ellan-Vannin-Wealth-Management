"use client";

import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api, ErreurApi } from "./api";
import { FUSEAU_DEFAUT } from "./format";

export type Adhesion = {
  exploitation_id: string;
  raison_sociale: string;
  role: string;
  libelle_role: string;
  permissions: string[];
  modules_actifs: string[];
  fictive: boolean;
  membre_equipe_id: string | null;
};
export type Profil = { id: string; courriel: string; nom_affiche: string; adhesions: Adhesion[] };
export type Site = { id: string; nom: string; fuseau_horaire: string; commune?: string };

type Ctx = {
  profil: Profil;
  adhesion: Adhesion;
  sites: Site[];
  peut: (permission: string) => boolean;
  /** Chemin d'API relatif à l'exploitation courante. */
  ex: (chemin: string) => string;
  fuseau: (siteId?: string | null) => string;
  rechargerSites: () => void;
};

const SessionContexte = createContext<Ctx | null>(null);
export const CLE_PROFIL = "terroir.profil";

export function FournisseurSession({ profil, children }: { profil: Profil; children: React.ReactNode }) {
  const adhesion = profil.adhesions[0];
  const [sites, setSites] = useState<Site[]>([]);
  const ex = useCallback((c: string) => `/exploitations/${adhesion.exploitation_id}${c}`, [adhesion.exploitation_id]);
  const charger = useCallback(() => {
    if (!adhesion.permissions.includes("foncier:lire")) return;
    api.get<Site[]>(ex("/sites")).then(setSites).catch(() => setSites([]));
  }, [ex, adhesion.permissions]);
  useEffect(charger, [charger]);
  const valeur: Ctx = {
    profil,
    adhesion,
    sites,
    peut: (p) => adhesion.permissions.includes(p),
    ex,
    fuseau: (siteId) => sites.find((s) => s.id === siteId)?.fuseau_horaire ?? FUSEAU_DEFAUT,
    rechargerSites: charger,
  };
  return <SessionContexte.Provider value={valeur}>{children}</SessionContexte.Provider>;
}

export function useSession(): Ctx {
  const c = useContext(SessionContexte);
  if (!c) throw new Error("Session absente");
  return c;
}

export type Etat<T> = { donnees: T | null; erreur: ErreurApi | null; chargement: boolean; recharger: () => void };

/** Charge une ressource de l'API ; `chemin` à null suspend le chargement. */
export function useDonnees<T = any>(chemin: string | null): Etat<T> {
  const [donnees, setDonnees] = useState<T | null>(null);
  const [erreur, setErreur] = useState<ErreurApi | null>(null);
  const [chargement, setChargement] = useState<boolean>(!!chemin);
  const [jeton, setJeton] = useState(0);
  useEffect(() => {
    if (!chemin) return;
    let actif = true;
    setChargement(true);
    api.get<T>(chemin)
      .then((d) => { if (actif) { setDonnees(d); setErreur(null); } })
      .catch((e) => { if (actif) setErreur(e instanceof ErreurApi ? e : new ErreurApi(0, "erreur", String(e))); })
      .finally(() => { if (actif) setChargement(false); });
    return () => { actif = false; };
  }, [chemin, jeton]);
  return { donnees, erreur, chargement, recharger: () => setJeton((j) => j + 1) };
}

/** Données de l'exploitation courante. */
export function useEx<T = any>(chemin: string | null): Etat<T> {
  const { ex } = useSession();
  return useDonnees<T>(chemin === null ? null : ex(chemin));
}
