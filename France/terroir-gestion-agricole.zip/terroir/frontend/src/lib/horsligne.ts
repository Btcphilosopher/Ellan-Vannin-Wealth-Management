/**
 * Stockage local pour la saisie terrain (IndexedDB via `idb`).
 * Périmètre pris en charge hors connexion : lecture d'un jeu de données
 * autorisé + file de brouillons (observations, photos, notes, comptes rendus
 * proposés). Rien d'autre n'est modifiable hors connexion.
 */
import { openDB, type DBSchema, type IDBPDatabase } from "idb";

export type EtatSync = "en_attente" | "envoye" | "acceptee" | "en_attente_validation" | "conflit" | "rejetee" | "validee";

export type ElementFile = {
  id: string; // identifiant stable généré sur l'appareil
  exploitation_id: string;
  type: "observation" | "note" | "photo" | "compte_rendu" | "modification_observation";
  entite_id: string | null;
  version_base: number | null;
  saisi_le: string;
  contenu: Record<string, unknown>;
  libelle: string;
  etat: EtatSync;
  message?: string | null;
  envoye_le?: string | null;
};

export type DonneesLocales = {
  exploitation_id: string;
  genere_le: string;
  telecharge_le: string;
  parcelles: { id: string; code: string; nom: string; site_id: string; surface_ha: number }[];
  cycles: { id: string; parcelle_id: string; culture: string; variete: string | null }[];
  interventions: any[];
  observations: any[];
  perimetre: string;
};

interface Schema extends DBSchema {
  donnees: { key: string; value: DonneesLocales };
  file: { key: string; value: ElementFile; indexes: { par_exploitation: string } };
}

let promesse: Promise<IDBPDatabase<Schema>> | null = null;
function base() {
  if (!promesse) {
    promesse = openDB<Schema>("terroir-terrain", 1, {
      upgrade(db) {
        db.createObjectStore("donnees", { keyPath: "exploitation_id" });
        const f = db.createObjectStore("file", { keyPath: "id" });
        f.createIndex("par_exploitation", "exploitation_id");
      },
    });
  }
  return promesse;
}

export async function enregistrerDonnees(d: DonneesLocales) {
  await (await base()).put("donnees", d);
}
export async function lireDonnees(exploitationId: string) {
  return (await base()).get("donnees", exploitationId);
}
export async function ajouterALaFile(e: ElementFile) {
  await (await base()).put("file", e);
}
export async function lireFile(exploitationId: string): Promise<ElementFile[]> {
  const l = await (await base()).getAllFromIndex("file", "par_exploitation", exploitationId);
  return l.sort((a, b) => a.saisi_le.localeCompare(b.saisi_le));
}
export async function majElement(id: string, champs: Partial<ElementFile>) {
  const db = await base();
  const e = await db.get("file", id);
  if (e) await db.put("file", { ...e, ...champs });
}
export async function supprimerElement(id: string) {
  await (await base()).delete("file", id);
}

export function identifiantTerminal(): string {
  const cle = "terroir.terminal";
  try {
    let v = localStorage.getItem(cle);
    if (!v) { v = `navigateur-${crypto.randomUUID().slice(0, 8)}`; localStorage.setItem(cle, v); }
    return v;
  } catch {
    return "navigateur-inconnu";
  }
}

export function lireEnBase64(f: File): Promise<string> {
  return new Promise((ok, ko) => {
    const r = new FileReader();
    r.onload = () => ok(String(r.result).split(",")[1] ?? "");
    r.onerror = () => ko(r.error);
    r.readAsDataURL(f);
  });
}
