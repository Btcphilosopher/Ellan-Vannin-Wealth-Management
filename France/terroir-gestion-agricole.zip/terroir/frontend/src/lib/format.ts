/** Formats français (fr-FR) : nombres, euros, unités, dates dans le fuseau du site. */

const LOCALE = "fr-FR";
export const FUSEAU_DEFAUT = "Europe/Paris";

export function nombre(v: number | null | undefined, maxDecimales = 2, minDecimales = 0): string {
  if (v === null || v === undefined || Number.isNaN(v)) return "—";
  return new Intl.NumberFormat(LOCALE, { maximumFractionDigits: maxDecimales, minimumFractionDigits: minDecimales }).format(v);
}

export function euros(v: number | null | undefined): string {
  if (v === null || v === undefined) return "—";
  return new Intl.NumberFormat(LOCALE, { style: "currency", currency: "EUR" }).format(v);
}

export function pourcent(v: number | null | undefined, dec = 1): string {
  return v === null || v === undefined ? "—" : `${nombre(v, dec)} %`;
}

/** Libellés d'unités explicites. */
const UNITES: Record<string, string> = {
  m3: "m³", m2: "m²", "m3/h": "m³/h", "m3/ha": "m³/ha", "graines/m2": "graines/m²", u: "u.", "%vol": "% vol.",
};
export function unite(u: string | null | undefined): string {
  if (!u) return "";
  return UNITES[u] ?? u;
}

export function quantite(v: number | null | undefined, u?: string | null, dec = 3): string {
  if (v === null || v === undefined) return "—";
  return `${nombre(v, dec)} ${unite(u)}`.trim();
}

export function surface(v: number | null | undefined): string {
  return v === null || v === undefined ? "—" : `${nombre(v, 2, 2)} ha`;
}

/** Dose avec unité explicite (ex. « 150 kg/ha »). */
export function dose(v: number | null | undefined, u?: string | null): string {
  return quantite(v, u, 3);
}

function enDate(v: string | Date): Date {
  if (v instanceof Date) return v;
  // Une date seule (AAAA-MM-JJ) est interprétée comme date civile, sans décalage.
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) {
    const [a, m, j] = v.split("-").map(Number);
    return new Date(Date.UTC(a, m - 1, j, 12));
  }
  return new Date(v);
}

export function date(v: string | Date | null | undefined): string {
  if (!v) return "—";
  const d = enDate(v);
  const civile = typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v);
  return new Intl.DateTimeFormat(LOCALE, { day: "2-digit", month: "2-digit", year: "numeric", timeZone: civile ? "UTC" : FUSEAU_DEFAUT }).format(d);
}

export function dateHeure(v: string | Date | null | undefined, fuseau: string = FUSEAU_DEFAUT, avecFuseau = false): string {
  if (!v) return "—";
  const s = new Intl.DateTimeFormat(LOCALE, {
    day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: fuseau,
  }).format(enDate(v));
  return avecFuseau ? `${s} (${libelleFuseau(fuseau)})` : s;
}

export function heure(v: string | Date | null | undefined, fuseau: string = FUSEAU_DEFAUT): string {
  if (!v) return "—";
  return new Intl.DateTimeFormat(LOCALE, { hour: "2-digit", minute: "2-digit", timeZone: fuseau }).format(enDate(v));
}

export function libelleFuseau(fuseau: string): string {
  if (fuseau === "Europe/Paris") return "heure de Paris";
  if (fuseau === "Indian/Reunion") return "heure de La Réunion";
  return fuseau;
}

export function jourSemaine(v: Date): string {
  return new Intl.DateTimeFormat(LOCALE, { weekday: "long", day: "numeric", month: "long", timeZone: "UTC" }).format(v);
}

/** Date ISO AAAA-MM-JJ (civile) d'un objet Date en UTC. */
export function isoJour(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export function lundi(d: Date): Date {
  const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 12));
  const j = (x.getUTCDay() + 6) % 7;
  x.setUTCDate(x.getUTCDate() - j);
  return x;
}

export function ajouterJours(d: Date, n: number): Date {
  const x = new Date(d);
  x.setUTCDate(x.getUTCDate() + n);
  return x;
}

export function octets(n: number | null | undefined): string {
  if (!n && n !== 0) return "—";
  if (n < 1024) return `${n} o`;
  if (n < 1024 * 1024) return `${nombre(n / 1024, 1)} Ko`;
  return `${nombre(n / 1024 / 1024, 1)} Mo`;
}

/** Décalage (minutes) d'un fuseau à un instant donné. */
function decalage(instant: Date, fuseau: string): number {
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-US", {
    timeZone: fuseau, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit",
  }).formatToParts(instant).map((x) => [x.type, x.value]));
  const local = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second);
  return Math.round((local - instant.getTime()) / 60000);
}

/** Convertit une saisie « datetime-local » exprimée dans le fuseau du site en ISO 8601 avec décalage. */
export function versIso(local: string, fuseau: string = FUSEAU_DEFAUT): string {
  const [d, h = "00:00"] = local.split("T");
  const [a, m, j] = d.split("-").map(Number);
  const [hh, mm] = h.split(":").map(Number);
  const naif = Date.UTC(a, m - 1, j, hh, mm);
  const off = decalage(new Date(naif - decalage(new Date(naif), fuseau) * 60000), fuseau);
  const signe = off >= 0 ? "+" : "-";
  const abs = Math.abs(off);
  return `${d}T${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}:00${signe}${String(Math.floor(abs / 60)).padStart(2, "0")}:${String(abs % 60).padStart(2, "0")}`;
}

/** Valeur « datetime-local » (dans le fuseau du site) pour un instant ISO. */
export function versLocal(iso: string | null | undefined, fuseau: string = FUSEAU_DEFAUT): string {
  if (!iso) return "";
  const p = Object.fromEntries(new Intl.DateTimeFormat("en-CA", {
    timeZone: fuseau, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
  }).formatToParts(new Date(iso)).map((x) => [x.type, x.value]));
  return `${p.year}-${p.month}-${p.day}T${p.hour}:${p.minute}`;
}
