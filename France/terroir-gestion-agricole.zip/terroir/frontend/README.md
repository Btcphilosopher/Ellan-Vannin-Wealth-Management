# Terroir — interface web et mobile

Interface Next.js (App Router) + React + TypeScript, entièrement en français.
Dépendances d'exécution : `next`, `react`, `react-dom`, `idb` (IndexedDB). Aucun kit d'interface : CSS écrite à la main avec des jetons de conception (`src/app/globals.css`).

## Lancer

```bash
npm install
npm run build
npm start            # http://localhost:3000
```

En développement : `npm run dev`. L'API FastAPI doit tourner (par défaut `http://localhost:8000`) ;
le navigateur appelle `/api/...` sur la même origine et Next.js relaie vers `TERROIR_API_URL`
(voir `next.config.mjs`). La sortie `standalone` est utilisée par le `Dockerfile`
(`node .next/standalone/server.js`).

Vérifications : `npx tsc --noEmit`, `npm run build`, puis le parcours Playwright :

```bash
BASE=http://localhost:3000 node tests/e2e.cjs   # données de démonstration requises
```

## Structure

```
src/
  i18n/fr.ts            Catalogue des textes (t("nav.parcelles")) et libellés des codes de l'API (lib("statutLot", …))
  lib/format.ts         Formats fr-FR : nombres, euros, ha, kg/t, L, doses (kg/ha, L/ha), dates jj/mm/aaaa,
                        heures dans le fuseau du site (Europe/Paris, Indian/Reunion…), conversion datetime-local ↔ ISO
  lib/api.ts            Client HTTP (cookie de session httpOnly, en-tête CSRF X-Terroir-Requete, erreurs {code, message})
  lib/session.tsx       Contexte de session : exploitation, rôle, permissions, sites et fuseaux ; hooks de chargement
  lib/horsligne.ts      IndexedDB (idb) : jeu de données autorisé + file des saisies terrain
  components/ui.tsx     Badges (icône + libellé, jamais la couleur seule), sections, tableaux, champs, bouton soumis à permission
  components/CarteParcelles.tsx  Carte SVG autonome (aucun fond de carte tiers), hachures et pointillés légendés
  app/connexion         Connexion (comptes de démonstration)
  app/(app)/…           Tableau de bord, Parcelles, Cultures, Élevage, Travaux, Matériel, Stocks, Achats, Ventes,
                        Équipe, Documents, Analyses, Paramètres (+ pages de détail)
  app/terrain           Saisie terrain mobile, fonctionnant hors connexion
public/sw.js            Service worker (portée /terrain uniquement)
tests/e2e.cjs           Parcours Playwright (toutes les pages, hors connexion, permissions)
```

La logique métier reste dans l'API ; l'interface ne fait que présenter, saisir et formater.
Les textes sont séparés des composants : ajouter une langue revient à fournir un autre catalogue.

## Accessibilité et terrain

- Contrastes élevés, police de base 17–18 px, cibles tactiles ≥ 44 px, navigation latérale repliable sur téléphone.
- Tout état est donné par une icône **et** un libellé (« ⚠ Rupture », « ⛔ Indisponible », « ✓ Disponible »…).
- Les actions non permises par le rôle sont masquées ou affichées verrouillées (🔒) avec la permission manquante.

## Hors connexion : périmètre pris en charge

Seule la page **/terrain** fonctionne hors connexion :

- lecture d'un jeu de données autorisé (`GET /exploitations/{id}/sync/donnees`) conservé dans IndexedDB ;
- saisie de brouillons : observations (avec photo), notes, comptes rendus d'intervention proposés ;
- chaque saisie porte un identifiant stable (UUID généré sur l'appareil), l'heure de saisie et un état
  (En attente, Envoyé, Accepté, En attente de validation, Conflit, Rejeté) ;
- l'envoi (`POST /sync/envoi`) est idempotent : renvoyer une saisie ne crée pas de doublon ;
- les comptes rendus touchant des stocks ou des ressources partagées restent « en attente de validation »
  jusqu'à leur validation sur le serveur ;
- les conflits sont affichés et résolus explicitement (garder serveur, garder terminal, fusion) par les rôles autorisés.

Le service worker est enregistré uniquement depuis /terrain (portée `/terrain`). Il met en cache l'enveloppe
de la page et ses ressources statiques, ne met jamais en cache les appels `/api` et ne rejoue aucune modification.
Le reste de l'application nécessite une connexion.
