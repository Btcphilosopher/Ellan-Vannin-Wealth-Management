/*
 * Vérification de bout en bout de l'interface (Playwright).
 *   BASE=http://localhost:3000 CAPTURES=../docs/captures node tests/e2e.cjs
 * Échoue en cas d'erreur console, de requête en échec ou de vérification non satisfaite.
 */
const { chromium, devices } = require("playwright");
const path = require("path");
const fs = require("fs");

const BASE = process.env.BASE || "http://localhost:3000";
const CAPTURES = path.resolve(process.env.CAPTURES || path.join(__dirname, "../../docs/captures"));
const MDP = "Terroir-Demo-2026!";
fs.mkdirSync(CAPTURES, { recursive: true });

const resultats = [];
function verifier(cond, libelle) {
  resultats.push([!!cond, libelle]);
  console.log(`${cond ? "OK   " : "ÉCHEC"} ${libelle}`);
}

function surveiller(page, nom) {
  const erreurs = [];
  page.on("console", (m) => { if (m.type() === "error" && !page.__erreursAttendues && !(page.__horsLigne && m.text().includes("ERR_INTERNET_DISCONNECTED"))) erreurs.push(`[${nom}] console : ${m.text()}`); });
  page.on("pageerror", (e) => erreurs.push(`[${nom}] exception : ${e.message}`));
  page.on("requestfailed", (r) => { if (!r.url().includes("_rsc") && !page.__horsLigne) erreurs.push(`[${nom}] requête en échec : ${r.url()} ${r.failure()?.errorText}`); });
  page.on("response", (r) => { if (r.status() >= 400 && !page.__erreursAttendues) erreurs.push(`[${nom}] HTTP ${r.status()} : ${r.url()}`); });
  return erreurs;
}

async function connexion(page, courriel) {
  await page.goto(`${BASE}/connexion`);
  await page.fill('input[type="email"]', courriel);
  await page.fill('input[type="password"]', MDP);
  await page.click('button[type="submit"]');
  await page.waitForURL(`${BASE}/`);
  await page.waitForSelector("h1");
}

async function attendreChargement(page) {
  await page.waitForLoadState("networkidle");
  await page.waitForFunction(() => !document.querySelector(".chargement"), null, { timeout: 15000 }).catch(() => undefined);
}

(async () => {
  const navigateur = await chromium.launch();
  // ---------- Gérante : toutes les pages ----------
  const ctx = await navigateur.newContext({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 2, locale: "fr-FR", timezoneId: "Europe/Paris" });
  const page = await ctx.newPage();
  const erreurs = surveiller(page, "gérante");
  await page.goto(`${BASE}/connexion`);
  await page.screenshot({ path: path.join(CAPTURES, "01-connexion.png") });
  await connexion(page, "claire.martin@trois-vallees.example");
  await attendreChargement(page);
  verifier(await page.locator("text=Alertes").first().isVisible(), "Tableau de bord affiché avec les alertes");
  verifier(await page.locator(".badge", { hasText: "Avertissement" }).count() > 0, "Alertes avec libellé texte (pas uniquement une couleur)");
  await page.screenshot({ path: path.join(CAPTURES, "02-tableau-de-bord.png"), fullPage: true });

  const moi = await (await page.request.get(`${BASE}/api/v1/auth/moi`)).json();
  const E = moi.adhesions[0].exploitation_id;
  const get = async (c) => (await page.request.get(`${BASE}/api/v1/exploitations/${E}${c}`)).json();

  const pages = ["/parcelles", "/cultures", "/elevage", "/travaux", "/materiel", "/stocks", "/achats", "/ventes", "/equipe", "/documents", "/analyses", "/parametres"];
  for (const p of pages) {
    await page.goto(`${BASE}${p}`);
    await attendreChargement(page);
    const titre = await page.locator("h1").first().textContent();
    const erreurAffichee = await page.locator(".message-erreur").count();
    verifier(titre && erreurAffichee === 0, `Page ${p} chargée (« ${titre?.trim()} »)`);
    if (p === "/parcelles") {
      verifier(await page.locator("svg.carte-svg path.parcelle-forme").count() >= 9, "Carte : parcelles tracées en SVG");
      verifier(await page.locator("text=écart entre surface déclarée").count() > 0, "Carte : légende textuelle des hachures d'écart");
      await page.screenshot({ path: path.join(CAPTURES, "03-parcelles-carte.png"), fullPage: true });
    }
    if (p === "/cultures") {
      await page.click("button[role=tab]:has-text('Rotations')");
      await attendreChargement(page);
      verifier(await page.locator("text=règle non validée").count() > 0, "Rotations : règle non validée signalée");
      verifier(await page.locator("text=ne constitue ni une mesure ni une preuve").count() > 0, "Rotations : avertissement « pas une preuve de santé du sol »");
      await page.screenshot({ path: path.join(CAPTURES, "04-cultures-rotations.png"), fullPage: true });
      await page.click("button[role=tab]:has-text('Besoins')");
      await attendreChargement(page);
    }
    if (p === "/analyses") {
      verifier(await page.locator("text=Marge brute").count() > 0, "Analyses : marges affichées");
      await page.screenshot({ path: path.join(CAPTURES, "07-analyses-couts.png"), fullPage: false });
      for (const o of ["Par activité", "Prévisions"]) { await page.click(`button[role=tab]:has-text('${o}')`); await attendreChargement(page); }
    }
    if (p === "/parametres") {
      for (const o of ["Utilisateurs", "Adaptateurs", "Journal d'audit", "Export complet"]) { await page.click(`button[role=tab]:has-text("${o}")`); await attendreChargement(page); }
      verifier(await page.locator("text=Télécharger l'export").count() > 0, "Paramètres : export complet proposé à la gérante");
    }
    if (p === "/stocks") {
      for (const o of ["Lots", "Journal des mouvements", "Observations de stockage"]) { await page.click(`button[role=tab]:has-text("${o}")`); await attendreChargement(page); }
      verifier(await page.locator("text=corrigé").count() >= 0, "Stocks : journal des mouvements affiché");
    }
    if (p === "/elevage") {
      for (const o of ["Animaux", "Événements", "Déclarations"]) { await page.click(`button[role=tab]:has-text("${o}")`); await attendreChargement(page); }
      verifier(await page.locator("text=Aucune transmission officielle").count() > 0, "Élevage : déclarations sans transmission officielle");
    }
    if (p === "/documents") {
      for (const o of ["Échéances", "Préparation"]) { await page.click(`button[role=tab]:has-text("${o}")`); await attendreChargement(page); }
    }
    if (p === "/achats") {
      for (const o of ["Demandes", "Factures"]) { await page.click(`button[role=tab]:has-text("${o}")`); await attendreChargement(page); }
    }
    if (p === "/travaux") {
      await page.click("button[role=tab]:has-text('Interventions')");
      await attendreChargement(page);
    }
  }

  // Détails
  const its = await get("/interventions?type=traitement_phyto");
  const phyto = its.find((i) => i.statut === "realisee") || its[0];
  await page.goto(`${BASE}/travaux/${phyto.id}`);
  await attendreChargement(page);
  verifier(await page.locator("text=Contrôles non couverts").count() > 0, "Intervention : contrôles non couverts listés");
  verifier(await page.locator("text=Source non officielle").count() > 0, "Intervention : source réglementaire signalée non officielle");
  verifier(await page.locator("th", { hasText: "Consigne machine" }).count() > 0 && await page.locator("th", { hasText: "Mesuré" }).count() > 0, "Intervention : prévu / consigne / mesuré distincts");
  await page.screenshot({ path: path.join(CAPTURES, "05-travaux-intervention-verification.png"), fullPage: true });
  const ferti = (await get("/interventions?type=fertilisation")).find((i) => i.statut === "realisee");
  await page.goto(`${BASE}/travaux/${ferti.id}`);
  await attendreChargement(page);
  verifier(await page.locator("text=Météo indisponible").count() > 0, "Intervention : météo manquante affichée « indisponible »");

  const lots = await get("/lots?origine=recolte");
  const bt = lots.find((l) => l.numero === "BT-2026-P01");
  await page.goto(`${BASE}/stocks/lots/${bt.id}`);
  await attendreChargement(page);
  verifier(await page.locator("text=Chaîne reliée jusqu'à la (aux) parcelle(s) d'origine").count() > 0, "Traçabilité : lot BT-2026-P01 relié à la parcelle");
  await page.screenshot({ path: path.join(CAPTURES, "06-stocks-tracabilite.png"), fullPage: true });
  const pdf = await page.request.get(`${BASE}/api/v1/exploitations/${E}/rapports/tracabilite/${bt.id}?format=pdf`);
  verifier(pdf.status() === 200 && (await pdf.body()).subarray(0, 5).toString() === "%PDF-", "Rapport PDF de traçabilité téléchargeable");
  const melange = (await get("/lots")).find((l) => l.numero === "OR-2026-MELANGE");
  await page.goto(`${BASE}/stocks/lots/${melange.id}`);
  await attendreChargement(page);
  verifier(await page.locator("text=Traçabilité incomplète").count() > 0, "Traçabilité : regroupement incomplet signalé");

  const parcelles = await get("/parcelles");
  await page.goto(`${BASE}/parcelles/${parcelles.find((x) => x.code === "P01").id}`);
  await attendreChargement(page);
  verifier(await page.locator("text=La surface déclarée n'a pas été modifiée").count() > 0, "Parcelle : écart signalé sans écrasement");
  const mats = await get("/materiels");
  await page.goto(`${BASE}/materiel/${mats.find((m) => m.code === "TR-02").id}`);
  await attendreChargement(page);
  verifier(await page.locator("text=Matériel indisponible").count() > 0, "Matériel : TR-02 indisponible avec motif");

  // Conflit d'affectation (409) affiché
  page.__erreursAttendues = true;
  const planifiee = (await get("/interventions?statut=planifiee")).find((i) => i.date_prevue && i.date_prevue > new Date().toISOString().slice(0, 10));
  await page.goto(`${BASE}/travaux/${planifiee.id}`);
  await attendreChargement(page);
  await page.click("summary:has-text('Affecter une ressource')");
  const selRessource = page.locator("details[open] select").nth(1);
  const valeurTR02 = await selRessource.locator("option", { hasText: "Tracteur 100 ch" }).first().getAttribute("value");
  await selRessource.selectOption(valeurTR02);
  await page.click("button:has-text('Affecter')");
  await page.waitForSelector(".message-erreur", { timeout: 10000 });
  verifier((await page.locator(".message-erreur").textContent()).includes("indisponible"), "Affectation refusée : message de conflit (matériel indisponible) affiché");
  page.__erreursAttendues = false;
  await ctx.close();

  // ---------- Terrain : téléphone, hors connexion ----------
  const tel = await navigateur.newContext({ ...devices["Pixel 7"], locale: "fr-FR", timezoneId: "Europe/Paris" });
  const pt = await tel.newPage();
  const erreursTel = surveiller(pt, "terrain");
  await connexion(pt, "sofia.benali@trois-vallees.example");
  // Opératrice : actions d'administration masquées ou verrouillées
  await pt.goto(`${BASE}/parametres`);
  await attendreChargement(pt);
  verifier(await pt.locator("button[role=tab]:has-text('Utilisateurs')").count() === 0, "Opératrice : onglet Utilisateurs masqué");
  verifier(await pt.locator("button[role=tab]:has-text('Journal')").count() === 0, "Opératrice : journal d'audit masqué");
  await pt.click("button[role=tab]:has-text('Export complet')");
  verifier(await pt.locator("button[disabled]:has-text('Télécharger l')").count() === 1, "Opératrice : export complet verrouillé");
  await pt.goto(`${BASE}/parcelles`);
  await attendreChargement(pt);
  await pt.click("summary:has-text('Créer une parcelle')");
  verifier(await pt.locator("button[disabled]:has-text('🔒')").count() > 0, "Opératrice : création de parcelle verrouillée (🔒)");

  await pt.goto(`${BASE}/terrain`);
  await pt.waitForSelector("text=Données locales du", { timeout: 15000 });
  for (let i = 0; i < 40; i++) {
    if (await pt.evaluate(async () => { const r = await navigator.serviceWorker.getRegistration("/terrain"); return !!(r && r.active); })) break;
    await pt.waitForTimeout(500);
  }
  const swActif = await pt.evaluate(async () => { const r = await navigator.serviceWorker.getRegistration("/terrain"); return !!(r && r.active); });
  console.log("   registrations:", await pt.evaluate(async () => JSON.stringify((await navigator.serviceWorker.getRegistrations()).map((x) => [x.scope, !!x.active, !!x.installing]))));
  verifier(swActif, "Service worker actif sur /terrain");
  pt.__horsLigne = true;
  await tel.setOffline(true);
  await pt.waitForSelector(".etat-reseau.hors-ligne");
  verifier(await pt.locator("text=Hors connexion").count() > 0, "Bandeau hors connexion affiché");
  // Rechargement hors connexion : l'enveloppe vient du cache du service worker
  let rechargeOk = false;
  if (swActif) {
    try { await pt.reload({ waitUntil: "domcontentloaded" }); await pt.waitForSelector("text=Données locales du", { timeout: 15000 }); rechargeOk = true; } catch (e) { rechargeOk = false; }
  }
  verifier(rechargeOk, "Rechargement de /terrain hors connexion (cache du service worker + IndexedDB)");
  const parcelleOpt = await pt.locator("select").first().locator("option", { hasText: "P01" }).first().getAttribute("value");
  await pt.locator("select").first().selectOption(parcelleOpt);
  const description = `Pucerons sur bordure (test hors connexion ${Date.now()})`;
  await pt.fill("textarea", description);
  const jpeg = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.from("image-de-test-terrain".repeat(20))]);
  await pt.setInputFiles('input[type="file"]', { name: "photo.jpg", mimeType: "image/jpeg", buffer: jpeg });
  await pt.click("button:has-text('Enregistrer sur l')");
  await pt.waitForSelector(".file-item[data-etat='en_attente']");
  const enAttente = await pt.locator(".file-item[data-etat='en_attente']").count();
  const idb = await pt.evaluate(() => new Promise((ok) => {
    const r = indexedDB.open("terroir-terrain");
    r.onsuccess = () => { const tx = r.result.transaction("file", "readonly"); const g = tx.objectStore("file").getAll(); g.onsuccess = () => ok(g.result.filter((e) => e.etat === "en_attente").map((e) => e.type)); };
  }));
  verifier(enAttente === 2 && idb.includes("observation") && idb.includes("photo"), `Saisie hors connexion en file IndexedDB « En attente » (${idb.join(", ")})`);
  verifier(await pt.locator(".file-item .badge", { hasText: "En attente" }).count() === 2, "Libellé « En attente » et heure de saisie affichés");
  await pt.locator(".file-item").first().evaluate((e) => e.scrollIntoView({ block: "center" }));
  await pt.screenshot({ path: path.join(CAPTURES, "08-terrain-hors-connexion-telephone.png"), fullPage: false });
  await tel.setOffline(false);
  pt.__horsLigne = false;
  await pt.waitForSelector(".etat-reseau.en-ligne");
  await pt.click("button:has-text('Synchroniser maintenant')");
  await pt.waitForSelector("text=Synchronisation terminée", { timeout: 15000 });
  const acceptes = await pt.locator(".file-item[data-etat='acceptee']").count();
  verifier(acceptes >= 2, `Après synchronisation : ${acceptes} élément(s) « Accepté »`);
  await pt.locator(".file-item").first().evaluate((e) => e.scrollIntoView({ block: "center" }));
  await pt.screenshot({ path: path.join(CAPTURES, "09-terrain-synchronise-telephone.png"), fullPage: false });
  const obs = await (await pt.request.get(`${BASE}/api/v1/exploitations/${E}/observations`)).json();
  verifier(obs.some((o) => o.description === description && o.origine === "terrain"), "Observation présente côté serveur (origine terrain)");
  const docs = await (await pt.request.get(`${BASE}/api/v1/exploitations/${E}/documents?categorie=photo`)).json();
  verifier(docs.some((d) => d.nom_fichier && d.nom_fichier.startsWith("terrain-")), "Photo déposée dans le stockage protégé");
  await tel.close();
  await navigateur.close();

  const toutes = [...erreurs, ...erreursTel];
  for (const e of toutes) console.log("ERREUR", e);
  verifier(toutes.length === 0, `Aucune erreur console ni requête en échec (${toutes.length})`);
  const ok = resultats.filter(([c]) => c).length;
  console.log(`\nRésultat : ${ok}/${resultats.length} vérifications réussies.`);
  process.exit(ok === resultats.length ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(1); });
