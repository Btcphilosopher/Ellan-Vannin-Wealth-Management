# TGV Voyage REST API Documentation
**Version 1.0.0** — Production High-Speed Rail API Specification

All API requests must contain the base URL `/api/v1` and support standard HTTP methods.

---

## Authentication & Account

### 1. Register User
*   **Method:** `POST`
*   **Path:** `/auth/register`
*   **Headers:** `Content-Type: application/json`
*   **Request Body:**
    ```json
    {
      "email": "passenger@tgvvoyage.fr",
      "password": "SecurePassword123",
      "firstName": "Jean-Pierre",
      "lastName": "Moreau",
      "phoneNumber": "+33612345678"
    }
    ```
*   **Response (201 Created):**
    ```json
    {
      "id": 42,
      "email": "passenger@tgvvoyage.fr",
      "firstName": "Jean-Pierre",
      "lastName": "Moreau",
      "token": "eyJhbGciOiJIUzI1NiIsIn..."
    }
    ```

### 2. Login User
*   **Method:** `POST`
*   **Path:** `/auth/login`
*   **Request Body:**
    ```json
    {
      "email": "passenger@tgvvoyage.fr",
      "password": "SecurePassword123"
    }
    ```
*   **Response (200 OK):**
    ```json
    {
      "token": "eyJhbGciOiJIUzI1NiIsIn...",
      "user": {
        "id": 42,
        "email": "passenger@tgvvoyage.fr",
        "firstName": "Jean-Pierre",
        "lastName": "Moreau"
      }
    }
    ```

---

## Journey Planning

### 3. Search Journeys
*   **Method:** `GET`
*   **Path:** `/journeys/search`
*   **Query Parameters:**
    *   `from` (Station Code or ID, e.g., `FRLYO` or `1`)
    *   `to` (Station Code or ID, e.g., `FRMSH` or `5`)
    *   `date` (Date string in ISO `YYYY-MM-DD` format)
    *   `class` (Optional: `STANDARD`, `FIRST`, `BUSINESS`)
*   **Response (200 OK):**
    ```json
    [
      {
        "journeyId": 105,
        "trainNumber": "TGV INOUI 6119",
        "origin": "Paris Gare de Lyon",
        "destination": "Marseille Saint-Charles",
        "departureTime": "2026-07-15T08:14:00Z",
        "arrivalTime": "2026-07-15T11:34:00Z",
        "duration": "3h 20m",
        "priceStandard": 59.00,
        "priceFirst": 89.00,
        "priceBusiness": 119.00,
        "availableSeats": 128
      }
    ]
    ```

---

## Booking & Seating

### 4. Create Booking
*   **Method:** `POST`
*   **Path:** `/bookings`
*   **Headers:** `Authorization: Bearer <token>`
*   **Request Body:**
    ```json
    {
      "journeyId": 105,
      "classType": "BUSINESS",
      "passengers": [
        {
          "name": "Jean-Pierre Moreau",
          "passengerType": "ADULT",
          "coachNumber": 12,
          "seatNumber": "45"
        }
      ],
      "paymentMethod": "CREDIT_CARD"
    }
    ```
*   **Response (201 Created):**
    ```json
    {
      "bookingId": 8021,
      "bookingReference": "TGFZ42",
      "totalPrice": 119.00,
      "status": "CONFIRMED",
      "tickets": [
        {
          "ticketId": 99201,
          "passengerName": "Jean-Pierre Moreau",
          "coachNumber": 12,
          "seatNumber": "45",
          "classType": "BUSINESS",
          "qrCodePayload": "TGV-REF-TGFZ42-COACH12-SEAT45"
        }
      ]
    }
    ```

### 5. Cancel & Refund Booking
*   **Method:** `POST`
*   **Path:** `/bookings/{id}/refund`
*   **Headers:** `Authorization: Bearer <token>`
*   **Response (200 OK):**
    ```json
    {
      "bookingReference": "TGFZ42",
      "status": "REFUNDED",
      "refundAmount": 119.00,
      "message": "Refund processed successfully to original payment method."
    }
    ```

---

## Stations & Info

### 6. Get Station Details
*   **Method:** `GET`
*   **Path:** `/stations/{id}`
*   **Response (200 OK):**
    ```json
    {
      "id": 1,
      "name": "Paris Gare de Lyon",
      "code": "FRLYO",
      "address": "4 Place Louis-Armand, 75012 Paris",
      "hasParking": true,
      "hasTaxiStand": true,
      "hasWaitingLounge": true,
      "accessibilityInfo": "Elevators to all platforms, specialized assist boarding staff available upon request.",
      "public_transport": "Métro Lines 1, 14. RER Lines A, D. Bus Lines 24, 63, 87.",
      "shopsAndCafes": "Paul, Starbucks, Pret A Manger, FNAC, Sephora."
    }
    ```

---

## Loyalty Account

### 7. Get Loyalty Balance
*   **Method:** `GET`
*   **Path:** `/loyalty/status`
*   **Headers:** `Authorization: Bearer <token>`
*   **Response (200 OK):**
    ```json
    {
      "membershipNumber": "LOY-9428-1052",
      "pointsBalance": 2450,
      "tier": "GRAND_VOYAGEUR_PLUS",
      "nextTierPointsRequired": 1550,
      "benefits": [
        "Access to Grand Voyageur Station Lounges",
        "Free hot drink in the Bar carriage",
        "15% discount on onboard dining",
        "Priority boarding & dedicated Customer Desk"
      ]
    }
    ```
