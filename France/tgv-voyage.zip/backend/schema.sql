-- TGV Voyage PostgreSQL Database Schema
-- Production-ready database schema for France's high-speed rail network

-- Drop existing tables if they exist
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS tickets CASCADE;
DROP TABLE IF EXISTS bookings CASCADE;
DROP TABLE IF EXISTS seats CASCADE;
DROP TABLE IF EXISTS carriages CASCADE;
DROP TABLE IF EXISTS trains CASCADE;
DROP TABLE IF EXISTS routes CASCADE;
DROP TABLE IF EXISTS stations CASCADE;
DROP TABLE IF EXISTS loyalty_accounts CASCADE;
DROP TABLE IF EXISTS notifications CASCADE;
DROP TABLE IF EXISTS customer_support_cases CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- 1. Users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20),
    preferred_language VARCHAR(5) DEFAULT 'FR',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Stations table
CREATE TABLE stations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(10) UNIQUE NOT NULL, -- e.g., FRLYO for Gare de Lyon
    address VARCHAR(500) NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    has_parking BOOLEAN DEFAULT TRUE,
    has_taxi_stand BOOLEAN DEFAULT TRUE,
    has_waiting_lounge BOOLEAN DEFAULT TRUE,
    accessibility_info TEXT,
    public_transport TEXT,
    shops_and_cafes TEXT
);

-- 3. Routes table
CREATE TABLE routes (
    id SERIAL PRIMARY KEY,
    origin_station_id INTEGER REFERENCES stations(id) ON DELETE RESTRICT,
    destination_station_id INTEGER REFERENCES stations(id) ON DELETE RESTRICT,
    distance_km DOUBLE PRECISION NOT NULL,
    base_price NUMERIC(10, 2) NOT NULL,
    estimated_duration_minutes INTEGER NOT NULL,
    CONSTRAINT unique_route_pair UNIQUE (origin_station_id, destination_station_id)
);

-- 4. Trains table
CREATE TABLE trains (
    id SERIAL PRIMARY KEY,
    train_number VARCHAR(20) UNIQUE NOT NULL, -- e.g., TGV 9520
    model VARCHAR(100) NOT NULL, -- e.g., Alstom Euroduplex
    total_capacity INTEGER NOT NULL,
    status VARCHAR(50) DEFAULT 'ACTIVE' -- ACTIVE, MAINTENANCE, OUT_OF_SERVICE
);

-- 5. Carriages table
CREATE TABLE carriages (
    id SERIAL PRIMARY KEY,
    train_id INTEGER REFERENCES trains(id) ON DELETE CASCADE,
    carriage_number INTEGER NOT NULL,
    class_type VARCHAR(50) NOT NULL, -- STANDARD, FIRST, BUSINESS
    total_seats INTEGER NOT NULL,
    CONSTRAINT unique_carriage_per_train UNIQUE (train_id, carriage_number)
);

-- 6. Seats table
CREATE TABLE seats (
    id SERIAL PRIMARY KEY,
    carriage_id INTEGER REFERENCES carriages(id) ON DELETE CASCADE,
    seat_number VARCHAR(10) NOT NULL,
    placement VARCHAR(50) NOT NULL, -- WINDOW, AISLE, MIDDLE, DUO, CORRESPONDING
    is_available BOOLEAN DEFAULT TRUE,
    CONSTRAINT unique_seat_per_carriage UNIQUE (carriage_id, seat_number)
);

-- 7. Journeys (Scheduled Trips)
CREATE TABLE journeys (
    id SERIAL PRIMARY KEY,
    train_id INTEGER REFERENCES trains(id) ON DELETE RESTRICT,
    route_id INTEGER REFERENCES routes(id) ON DELETE RESTRICT,
    departure_time TIMESTAMP WITH TIME ZONE NOT NULL,
    arrival_time TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(50) DEFAULT 'SCHEDULED', -- SCHEDULED, BOARDING, DEPARTED, ARRIVED, DELAYED, CANCELLED
    delay_minutes INTEGER DEFAULT 0
);

-- 8. Bookings table
CREATE TABLE bookings (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    journey_id INTEGER REFERENCES journeys(id) ON DELETE RESTRICT,
    booking_reference VARCHAR(10) UNIQUE NOT NULL, -- PNR (e.g., TGFZ42)
    total_price NUMERIC(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'CONFIRMED', -- CONFIRMED, CANCELLED, REFUNDED
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. Tickets table
CREATE TABLE tickets (
    id SERIAL PRIMARY KEY,
    booking_id INTEGER REFERENCES bookings(id) ON DELETE CASCADE,
    passenger_name VARCHAR(200) NOT NULL,
    passenger_type VARCHAR(50) NOT NULL, -- ADULT, YOUTH, SENIOR, INFANT
    carriage_number INTEGER NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    class_type VARCHAR(50) NOT NULL,
    qr_code_payload VARCHAR(500) UNIQUE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 10. Payments table
CREATE TABLE payments (
    id SERIAL PRIMARY KEY,
    booking_id INTEGER REFERENCES bookings(id) ON DELETE CASCADE,
    transaction_reference VARCHAR(100) UNIQUE NOT NULL,
    amount NUMERIC(10, 2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL, -- CREDIT_CARD, PAYPAL, APPLE_PAY
    status VARCHAR(50) DEFAULT 'SUCCESSFUL', -- PENDING, SUCCESSFUL, FAILED, REFUNDED
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 11. Loyalty Accounts table
CREATE TABLE loyalty_accounts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    membership_number VARCHAR(50) UNIQUE NOT NULL,
    points_balance INTEGER DEFAULT 0,
    tier VARCHAR(50) DEFAULT 'VOYAGEUR', -- VOYAGEUR, GRAND_VOYAGEUR, GRAND_VOYAGEUR_PLUS, LE_CLUB
    joined_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 12. Notifications table
CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    notification_type VARCHAR(50) NOT NULL, -- BOOKING, LOYALTY, SERVICE, PROMOTION
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 13. Customer Support Cases table
CREATE TABLE customer_support_cases (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    subject VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'OPEN', -- OPEN, IN_PROGRESS, RESOLVED, CLOSED
    category VARCHAR(100) NOT NULL, -- BOOKING, REFUND, LOYALTY, LUGGAGE, DELAY
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for optimal performance
CREATE INDEX idx_journeys_route ON journeys(route_id);
CREATE INDEX idx_journeys_departure ON journeys(departure_time);
CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE INDEX idx_tickets_booking ON tickets(booking_id);
CREATE INDEX idx_seats_carriage ON seats(carriage_id);
CREATE INDEX idx_notifications_user_unread ON notifications(user_id) WHERE is_read = FALSE;
