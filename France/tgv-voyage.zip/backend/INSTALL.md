# TGV Voyage Backend & Stack Deployment Guide

This guide provides instructions to run the production-grade **TGV Voyage** backend service, relational database, and caching server locally or in a cloud environment using Docker.

---

## Prerequisites

Ensure you have the following installed on your machine:
1.  **Docker Desktop** (or Docker Engine with Docker Compose)
2.  **Java 17 JDK** (if compiling without Docker)
3.  **Gradle** (v8.0+)

---

## Deployment Steps

### 1. Build the Spring Boot application (Optional)
If you want to compile and package the Java jar file directly, run this from the backend directory:
```bash
./gradlew bootJar
```
This will compile the Kotlin code and output the executable jar at `build/libs/tgv-voyage-backend-0.0.1-SNAPSHOT.jar`.

### 2. Launch the Stack using Docker Compose
In the directory containing `docker-compose.yml`, execute:
```bash
docker compose up --build -d
```

This starts three isolated containers:
1.  **tgv-voyage-db**: Runs PostgreSQL 15, initializing the tables using `schema.sql` automatically.
2.  **tgv-voyage-cache**: Runs Redis 7 for high-speed journey planning search results.
3.  **tgv-voyage-api**: Runs the compiled Spring Boot service, exposing port `8080`.

### 3. Verify System Health
You can check that all services are healthy and running with:
```bash
docker compose ps
```

To view live backend logs:
```bash
docker compose logs -f tgv-backend
```

---

## Architecture Overview

*   **REST Controllers**: Expose `/api/v1` endpoints with standard JSON payloads.
*   **Security layer**: Utilizes JWT (JSON Web Tokens) to secure booking and account modification routes.
*   **Database Integration**: Spring Data JPA with PostgreSQL, using custom database indexes to optimize query retrieval under high passenger volumes.
*   **Redis Caching**: Configured to cache highly-demanded French rail schedules (e.g. Paris ➔ Lyon, Paris ➔ Marseille) with a 5-minute sliding TTL.
