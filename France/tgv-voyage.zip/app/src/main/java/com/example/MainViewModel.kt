package com.example

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class AppScreen {
    HOME,
    TICKETS,
    STATIONS,
    LOYALTY,
    SUPPORT,
    DEVELOPER
}

class MainViewModel(private val repository: TgvRepository) : ViewModel() {

    // --- APPLICATION STATE ---
    var currentScreen by mutableStateOf(AppScreen.HOME)
    var selectedLanguage by mutableStateOf("FR") // FR, EN, DE, ES, IT

    // Database Flows
    val userState: StateFlow<UserEntity?> = repository.userFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val ticketsState: StateFlow<List<TicketEntity>> = repository.allTicketsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentSearchesState: StateFlow<List<RecentSearchEntity>> = repository.recentSearchesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val supportMessagesState: StateFlow<List<SupportMessageEntity>> = repository.supportMessagesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val notificationsState: StateFlow<List<NotificationEntity>> = repository.notificationsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // --- SEARCH & PLANNER STATE ---
    var searchOrigin by mutableStateOf("Paris Gare de Lyon")
    var searchDestination by mutableStateOf("Lyon Part-Dieu")
    var travelDate by mutableStateOf("2026-07-15")
    var searchClass by mutableStateOf("Standard") // Standard, First, Business

    var isSearching by mutableStateOf(false)
    var showSearchResults by mutableStateOf(false)
    var searchResults = mutableStateOf<List<TrainConnection>>(emptyList())

    // --- SELECTION & BOOKING STATE ---
    var selectedConnection by mutableStateOf<TrainConnection?>(null)
    var bookingStep by mutableStateOf(1) // 1: Select Train, 2: Choose Seats, 3: Passenger Info, 4: Payment, 5: Confirmation
    var selectedSeat by mutableStateOf("12A")
    var selectedCoach by mutableStateOf("15")
    var passengerName by mutableStateOf("")
    var passengerEmail by mutableStateOf("")
    var promoCode by mutableStateOf("")

    // Admin & Metrics Simulated States
    var totalMockSales by mutableStateOf(145890.0)
    var activeRefundingTicket by mutableStateOf<TicketEntity?>(null)

    init {
        viewModelScope.launch {
            repository.initializeMockDataIfNeeded()
            val u = repository.getOrInitUser()
            selectedLanguage = u.preferredLanguage
            passengerName = u.name
            passengerEmail = u.email
        }
    }

    // Language Change
    fun setLanguage(lang: String) {
        selectedLanguage = lang
        viewModelScope.launch {
            val u = repository.getOrInitUser()
            repository.updateUser(u.copy(preferredLanguage = lang))
        }
    }

    suspend fun updateUser(user: UserEntity) {
        repository.updateUser(user)
    }

    // Search Execution
    fun executeSearch() {
        if (searchOrigin.isBlank() || searchDestination.isBlank()) return
        isSearching = true
        viewModelScope.launch {
            repository.insertRecentSearch(searchOrigin, searchDestination)
            // Generate mock connections based on origin/destination
            val originClean = searchOrigin.split(" ").firstOrNull() ?: "Paris"
            val destClean = searchDestination.split(" ").firstOrNull() ?: "Lyon"

            val durationStr = when {
                originClean.contains("Paris", true) && destClean.contains("Lyon", true) -> "1h 58m"
                originClean.contains("Paris", true) && destClean.contains("Marseille", true) -> "3h 20m"
                originClean.contains("Paris", true) && destClean.contains("Bordeaux", true) -> "2h 04m"
                originClean.contains("Paris", true) && destClean.contains("Brussels", true) -> "1h 22m"
                originClean.contains("Paris", true) && destClean.contains("London", true) -> "2h 17m"
                else -> "2h 30m"
            }

            searchResults.value = listOf(
                TrainConnection(
                    id = 1,
                    trainNumber = "TGV INOUI 6119",
                    departureTime = "08:14",
                    arrivalTime = "10:12",
                    duration = durationStr,
                    priceStandard = 49.00,
                    priceFirst = 79.00,
                    priceBusiness = 119.00,
                    operator = "TGV INOUI"
                ),
                TrainConnection(
                    id = 2,
                    trainNumber = "OUIGO 7602",
                    departureTime = "10:35",
                    arrivalTime = "12:33",
                    duration = durationStr,
                    priceStandard = 19.00,
                    priceFirst = 29.00, // OUIGO Plus
                    priceBusiness = 45.00,
                    operator = "OUIGO"
                ),
                TrainConnection(
                    id = 3,
                    trainNumber = "TGV INOUI 6131",
                    departureTime = "13:02",
                    arrivalTime = "15:00",
                    duration = durationStr,
                    priceStandard = 65.00,
                    priceFirst = 95.00,
                    priceBusiness = 145.00,
                    operator = "TGV INOUI"
                ),
                TrainConnection(
                    id = 4,
                    trainNumber = "ICE 9553",
                    departureTime = "16:45",
                    arrivalTime = "18:43",
                    duration = durationStr,
                    priceStandard = 55.00,
                    priceFirst = 85.00,
                    priceBusiness = 130.00,
                    operator = "ICE / Eurostar"
                )
            )
            isSearching = false
            showSearchResults = true
            bookingStep = 1
        }
    }

    // Select train and advance
    fun selectTrain(conn: TrainConnection) {
        selectedConnection = conn
        bookingStep = 2 // Move to Seat Selection
    }

    // Confirm Seats and advance
    fun confirmSeats(coach: String, seat: String) {
        selectedCoach = coach
        selectedSeat = seat
        bookingStep = 3 // Move to Passenger Info
    }

    // Confirm Passengers and advance
    fun confirmPassengers(name: String, email: String) {
        passengerName = name
        passengerEmail = email
        bookingStep = 4 // Move to Payment
    }

    // Confirm Payment & Book Ticket
    fun processSecureBooking() {
        val conn = selectedConnection ?: return
        val finalPrice = when (searchClass) {
            "First" -> conn.priceFirst
            "Business" -> conn.priceBusiness
            else -> conn.priceStandard
        }

        val ref = generateBookingRef()
        val ticket = TicketEntity(
            fromCity = searchOrigin,
            toCity = searchDestination,
            date = travelDate,
            departureTime = conn.departureTime,
            arrivalTime = conn.arrivalTime,
            duration = conn.duration,
            price = finalPrice,
            coach = selectedCoach,
            seat = selectedSeat,
            bookingRef = ref,
            classType = when (searchClass) {
                "First" -> "1ère Classe"
                "Business" -> "Business Première"
                else -> "Seconde Classe"
            },
            qrCode = "TGV-REF-$ref-COACH-$selectedCoach-SEAT-$selectedSeat"
        )

        viewModelScope.launch {
            repository.insertTicket(ticket)
            totalMockSales += finalPrice
            bookingStep = 5 // Go to Booking Confirmation Screen
        }
    }

    // Refund Ticket
    fun processRefund(ticket: TicketEntity) {
        viewModelScope.launch {
            repository.refundTicket(ticket)
        }
    }

    // Send Support Message
    fun sendSupportMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.insertSupportMessage("user", text)
            // Generate automated elegant French replies based on keywords
            val lower = text.lowercase()
            val replyText = when {
                lower.contains("remboursement") || lower.contains("refund") -> {
                    "Le remboursement d'un billet TGV INOUI est gratuit jusqu'à 6 jours avant le départ. Rendez-vous sur votre onglet 'Billets' pour effectuer l'annulation instantanément."
                }
                lower.contains("perdu") || lower.contains("lost") -> {
                    "Si vous avez égaré un bagage, vous pouvez remplir une déclaration de perte en ligne ou contacter nos agents en gare. Nos équipes inspectent chaque rame au terminus."
                }
                lower.contains("fidélité") || lower.contains("points") || lower.contains("loyalty") -> {
                    "Votre statut de fidélité s'incrémente automatiquement de 5 points pour chaque euro dépensé sur l'application. Vous pouvez échanger vos points contre des surclassements gratuits."
                }
                lower.contains("grève") || lower.contains("delay") || lower.contains("retard") -> {
                    "Le trafic ferroviaire est actuellement nominal. Si votre train subit un retard de plus de 30 minutes, vous bénéficiez de la Garantie G30 (remboursement partiel)."
                }
                else -> {
                    "Merci pour votre message. Nos agents du service TGV Voyage examinent votre requête. Nous vous répondrons sous les plus brefs délais."
                }
            }
            repository.insertSupportMessage("agent", replyText)
        }
    }

    // Generate PNR
    private fun generateBookingRef(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        val rand = Random()
        val sb = StringBuilder()
        for (i in 0..5) {
            sb.append(chars[rand.nextInt(chars.length)])
        }
        return sb.toString()
    }

    // --- TRANSLATION HELPER ---
    fun t(key: String): String {
        val strings = translations[key] ?: return key
        return strings[selectedLanguage] ?: strings["FR"] ?: key
    }

    // All Localizations fully contained in code for instant reactive switching
    private val translations = mapOf(
        "app_name" to mapOf(
            "FR" to "TGV Voyage", "EN" to "TGV Voyage", "DE" to "TGV Voyage", "ES" to "TGV Voyage", "IT" to "TGV Voyage"
        ),
        "nav_home" to mapOf(
            "FR" to "Accueil", "EN" to "Home", "DE" to "Start", "ES" to "Inicio", "IT" to "Home"
        ),
        "nav_tickets" to mapOf(
            "FR" to "Billets", "EN" to "Tickets", "DE" to "Tickets", "ES" to "Billetes", "IT" to "Biglietti"
        ),
        "nav_stations" to mapOf(
            "FR" to "Gares", "EN" to "Stations", "DE" to "Bahnhöfe", "ES" to "Estaciones", "IT" to "Stazioni"
        ),
        "nav_loyalty" to mapOf(
            "FR" to "Fidélité", "EN" to "Loyalty", "DE" to "Loyalität", "ES" to "Fidelidad", "IT" to "Fedeltà"
        ),
        "nav_support" to mapOf(
            "FR" to "Support", "EN" to "Support", "DE" to "Hilfe", "ES" to "Soporte", "IT" to "Supporto"
        ),
        "nav_admin" to mapOf(
            "FR" to "Backend", "EN" to "Backend", "DE" to "Backend", "ES" to "Backend", "IT" to "Backend"
        ),
        "search_title" to mapOf(
            "FR" to "Où désirez-vous voyager ?",
            "EN" to "Where would you like to travel?",
            "DE" to "Wohin möchten Sie reisen?",
            "ES" to "¿A dónde desea viajar?",
            "IT" to "Dove desideri viaggiare?"
        ),
        "from_city" to mapOf(
            "FR" to "Gare de départ", "EN" to "Origin Station", "DE" to "Abfahrtsbahnhof", "ES" to "Estación de origen", "IT" to "Stazione di partenza"
        ),
        "to_city" to mapOf(
            "FR" to "Gare d'arrivée", "EN" to "Destination Station", "DE" to "Ankunftsbahnhof", "ES" to "Estación de destino", "IT" to "Stazione di arrivo"
        ),
        "travel_date" to mapOf(
            "FR" to "Date de voyage", "EN" to "Travel Date", "DE" to "Reisedatum", "ES" to "Fecha de viaje", "IT" to "Data di viaggio"
        ),
        "search_btn" to mapOf(
            "FR" to "Rechercher des trajets", "EN" to "Search Journeys", "DE" to "Züge suchen", "ES" to "Buscar trayectos", "IT" to "Cerca treni"
        ),
        "loyalty_card_title" to mapOf(
            "FR" to "Carte Grand Voyageur", "EN" to "Grand Voyageur Club", "DE" to "Grand Voyageur Karte", "ES" to "Tarjeta Grand Voyageur", "IT" to "Carta Grand Voyageur"
        ),
        "loyalty_points" to mapOf(
            "FR" to "points cumulés", "EN" to "earned points", "DE" to "gesammelte Punkte", "ES" to "puntos acumulados", "IT" to "punti accumulati"
        ),
        "upcoming_trips" to mapOf(
            "FR" to "Mes Voyages à Venir", "EN" to "My Upcoming Journeys", "DE" to "Meine anstehenden Reisen", "ES" to "Mis Próximos Viajes", "IT" to "I miei prossimi viaggi"
        ),
        "no_trips" to mapOf(
            "FR" to "Aucun trajet actif planifié", "EN" to "No active journeys planned", "DE" to "Keine aktiven Reisen geplant", "ES" to "No hay viajes activos planificados", "IT" to "Nessun viaggio attivo pianificato"
        ),
        "recent_searches" to mapOf(
            "FR" to "Recherches Récentes", "EN" to "Recent Searches", "DE" to "Letzte Suchen", "ES" to "Búsquedas Recientes", "IT" to "Ricerche Recenti"
        ),
        "special_offers" to mapOf(
            "FR" to "Offres Exclusives", "EN" to "Exclusive Offers", "DE" to "Exklusive Angebote", "ES" to "Ofertas Exclusivas", "IT" to "Offerte Esclusive"
        ),
        "service_info" to mapOf(
            "FR" to "Statut du Réseau", "EN" to "Network Traffic Status", "DE" to "Netzwerkstatus", "ES" to "Estado de la Red", "IT" to "Stato della rete"
        ),
        "service_ok" to mapOf(
            "FR" to "Circulation nominale sur tout le réseau grande vitesse",
            "EN" to "Nominal service across the entire high-speed network",
            "DE" to "Normalbetrieb auf dem gesamten Hochgeschwindigkeitsnetz",
            "ES" to "Circulación normal en toda la red de alta velocidad",
            "IT" to "Servizio regolare su tutta la rete ad alta velocità"
        ),
        "class_standard" to mapOf(
            "FR" to "Seconde Classe", "EN" to "Standard Class", "DE" to "2. Klasse", "ES" to "Segunda Clase", "IT" to "Seconda Classe"
        ),
        "class_first" to mapOf(
            "FR" to "Première Classe", "EN" to "First Class", "DE" to "1. Klasse", "ES" to "Primera Clase", "IT" to "Prima Classe"
        ),
        "class_business" to mapOf(
            "FR" to "Business Première", "EN" to "Business Lounge Premium", "DE" to "Business Premium", "ES" to "Business Premium", "IT" to "Business Premium"
        ),
        "seat_selector" to mapOf(
            "FR" to "Choix du Siège", "EN" to "Seat Selection", "DE" to "Sitzplatz wählen", "ES" to "Selección de Asiento", "IT" to "Scelta del posto"
        ),
        "pay_securely" to mapOf(
            "FR" to "Payer en toute sécurité", "EN" to "Pay Securely", "DE" to "Sicher bezahlen", "ES" to "Pagar de forma segura", "IT" to "Paga in sicurezza"
        ),
        "passenger_details" to mapOf(
            "FR" to "Informations Passager", "EN" to "Passenger Details", "DE" to "Reisendendaten", "ES" to "Datos del Pasajero", "IT" to "Dati del passeggero"
        ),
        "book_success" to mapOf(
            "FR" to "Voyage réservé avec succès !", "EN" to "Journey successfully booked!", "DE" to "Reise erfolgreich gebucht!", "ES" to "¡Viaje reservado con éxito!", "IT" to "Viaggio prenotato con successo!"
        ),
        "coach" to mapOf(
            "FR" to "Voiture", "EN" to "Coach", "DE" to "Wagen", "ES" to "Coche", "IT" to "Carrozza"
        ),
        "seat" to mapOf(
            "FR" to "Place", "EN" to "Seat", "DE" to "Sitzplatz", "ES" to "Asiento", "IT" to "Posto"
        ),
        "booking_ref" to mapOf(
            "FR" to "Référence Dossier", "EN" to "Booking Code", "DE" to "Buchungscode", "ES" to "Código de Reserva", "IT" to "Codice prenotazione"
        ),
        "refund_ticket" to mapOf(
            "FR" to "Annuler & Rembourser", "EN" to "Cancel & Refund", "DE" to "Stornieren & Erstatten", "ES" to "Cancelar y Reembolsar", "IT" to "Annulla e rimborsa"
        ),
        "digital_boarding_pass" to mapOf(
            "FR" to "Billet Électronique TGV", "EN" to "Digital Boarding Pass", "DE" to "Digitales Ticket", "ES" to "Billete Electrónico", "IT" to "Biglietto Digitale"
        ),
        "faqs" to mapOf(
            "FR" to "Foire Aux Questions", "EN" to "Frequently Asked Questions", "DE" to "Häufige Fragen", "ES" to "Preguntas Frecuentes", "IT" to "Domande Frequenti"
        ),
        "support_chat" to mapOf(
            "FR" to "Messagerie d'Assistance", "EN" to "Assistance Chat", "DE" to "Hilfe-Chat", "ES" to "Chat de Soporte", "IT" to "Chat di assistenza"
        ),
        "station_facilities" to mapOf(
            "FR" to "Services en Gare", "EN" to "Station Facilities", "DE" to "Services am Bahnhof", "ES" to "Servicios en la Estación", "IT" to "Servizi in stazione"
        ),
        "loyalty_benefits" to mapOf(
            "FR" to "Mes Avantages Premium", "EN" to "My Premium Benefits", "DE" to "Meine Vorteile", "ES" to "Mis Ventajas", "IT" to "I miei vantaggi"
        )
    )
}

// Simple Helper Factories
class MainViewModelFactory(private val repository: TgvRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

// Data Classes for UI representation
data class TrainConnection(
    val id: Int,
    val trainNumber: String,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val priceStandard: Double,
    val priceFirst: Double,
    val priceBusiness: Double,
    val operator: String
)
