package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF64B5F6), // Sky Accent
    secondary = TgvDarkSecondary,
    tertiary = TgvGold,
    background = TgvDarkBg,
    surface = TgvDarkSurface,
    onPrimary = Color.Black,
    onSecondary = TgvDarkText,
    onTertiary = Color.Black,
    onBackground = TgvDarkText,
    onSurface = TgvDarkText
)

private val LightColorScheme = lightColorScheme(
    primary = TgvNavy,
    secondary = TgvBurgundy,
    tertiary = TgvAccentRed,
    background = Color(0xFFF8F9FA), // Clean utility grey background (#F8F9FA)
    surface = TgvWhite,
    onPrimary = TgvWhite,
    onSecondary = TgvWhite,
    onTertiary = TgvWhite,
    onBackground = Color(0xFF1A1C1E), // (#1A1C1E) text color
    onSurface = Color(0xFF1A1C1E)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        DarkColorScheme
    } else {
        LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
