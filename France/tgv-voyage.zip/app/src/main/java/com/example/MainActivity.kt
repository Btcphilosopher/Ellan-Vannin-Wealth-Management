package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.TgvDatabase
import com.example.data.TgvRepository
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        val database = TgvDatabase.getDatabase(applicationContext)
        val repository = TgvRepository(database.tgvDao())
        
        setContent {
            MyApplicationTheme {
                val viewModel = remember { MainViewModel(repository) }
                val currentScreen = viewModel.currentScreen
                val notifications by viewModel.notificationsState.collectAsState()
                val unreadCount = notifications.count { !it.isRead }
                
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        AppHeader(
                            viewModel = viewModel,
                            notificationsCount = unreadCount
                        )
                    },
                    bottomBar = {
                        AppBottomNavigation(
                            currentScreen = currentScreen,
                            onTabSelected = { screen ->
                                viewModel.currentScreen = screen
                            },
                            viewModel = viewModel
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        AnimatedContent(
                            targetState = currentScreen,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                            },
                            label = "ScreenTransition"
                        ) { screen ->
                            when (screen) {
                                AppScreen.HOME -> HomeScreen(viewModel = viewModel)
                                AppScreen.TICKETS -> TicketsScreen(viewModel = viewModel)
                                AppScreen.STATIONS -> StationsScreen(viewModel = viewModel)
                                AppScreen.LOYALTY -> LoyaltyScreen(viewModel = viewModel)
                                AppScreen.SUPPORT -> SupportScreen(viewModel = viewModel)
                                AppScreen.DEVELOPER -> DeveloperScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
