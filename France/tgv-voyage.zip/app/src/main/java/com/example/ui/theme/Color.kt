package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Mode French Premium Palette - UPDATED FOR CLEAN UTILITY / MINIMAL
val TgvNavy = Color(0xFF002147)      // Oxford Blue from Clean Utility HTML
val TgvBurgundy = Color(0xFF800020)  // Burgundy from Clean Utility HTML
val TgvAccentRed = Color(0xFFE30613)
val TgvWarmGrey = Color(0xFFF1F3F4)  // Modern slate border / light grey
val TgvMutedGrey = Color(0xFF808D9A)  // Elegant slate-tinted muted grey
val TgvWhite = Color(0xFFFFFFFF)
val TgvGold = Color(0xFFD4AF37)

// Dark Mode French Premium Palette
val TgvDarkBg = Color(0xFF090E17)
val TgvDarkSurface = Color(0xFF141C2B)
val TgvDarkPrimary = Color(0xFF1E3A60)
val TgvDarkSecondary = Color(0xFF2C3E50)
val TgvDarkText = Color(0xFFECEFF1)
val TgvDarkMuted = Color(0xFF90A4AE)
