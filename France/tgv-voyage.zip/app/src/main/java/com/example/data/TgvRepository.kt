package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class TgvRepository(private val tgvDao: TgvDao) {

    val userFlow: Flow<UserEntity?> = tgvDao.getUserFlow()
    val allTicketsFlow: Flow<List<TicketEntity>> = tgvDao.getAllTicketsFlow()
    val recentSearchesFlow: Flow<List<RecentSearchEntity>> = tgvDao.getRecentSearchesFlow()
    val supportMessagesFlow: Flow<List<SupportMessageEntity>> = tgvDao.getSupportMessagesFlow()
    val notificationsFlow: Flow<List<NotificationEntity>> = tgvDao.getNotificationsFlow()

    suspend fun getOrInitUser(): UserEntity {
        val existing = tgvDao.getUser()
        if (existing == null) {
            val newUser = UserEntity(
                email = "tom@ahyx.org",
                name = "Tom de l'Hérault",
                loyaltyPoints = 2450,
                loyaltyTier = "Grand Voyageur Plus",
                preferredLanguage = "FR"
            )
            tgvDao.insertUser(newUser)
            return newUser
        }
        return existing
    }

    suspend fun updateUser(user: UserEntity) {
        tgvDao.insertUser(user)
    }

    suspend fun insertTicket(ticket: TicketEntity) {
        tgvDao.insertTicket(ticket)
        // Award points based on ticket price: €1 = 5 Points!
        val currentUser = tgvDao.getUser() ?: getOrInitUser()
        val extraPoints = (ticket.price * 5).toInt()
        val updatedUser = currentUser.copy(
            loyaltyPoints = currentUser.loyaltyPoints + extraPoints
        )
        tgvDao.insertUser(updatedUser)

        // Generate dynamic ticket booked notification
        val notification = NotificationEntity(
            title = "Réservation Confirmée ! 🎫",
            content = "Votre voyage de ${ticket.fromCity} à ${ticket.toCity} le ${ticket.date} est réservé. Voiture ${ticket.coach}, Place ${ticket.seat}.",
            timestamp = System.currentTimeMillis()
        )
        tgvDao.insertNotification(notification)
    }

    suspend fun refundTicket(ticket: TicketEntity) {
        tgvDao.updateTicket(ticket.copy(isRefunded = true))
        // Deduct points or notify
        val notification = NotificationEntity(
            title = "Remboursement Traité 🔄",
            content = "Le remboursement pour votre voyage ${ticket.fromCity} ➔ ${ticket.toCity} d'un montant de €${"%.2f".format(ticket.price)} a été traité avec succès.",
            timestamp = System.currentTimeMillis()
        )
        tgvDao.insertNotification(notification)
    }

    suspend fun insertRecentSearch(fromCity: String, toCity: String) {
        tgvDao.insertRecentSearch(RecentSearchEntity(fromCity = fromCity, toCity = toCity))
    }

    suspend fun clearRecentSearches() {
        tgvDao.clearRecentSearches()
    }

    suspend fun insertSupportMessage(sender: String, text: String) {
        tgvDao.insertSupportMessage(SupportMessageEntity(sender = sender, text = text))
    }

    suspend fun insertNotification(title: String, content: String) {
        tgvDao.insertNotification(NotificationEntity(title = title, content = content))
    }

    suspend fun markNotificationAsRead(id: Int) {
        tgvDao.markNotificationAsRead(id)
    }

    suspend fun initializeMockDataIfNeeded() {
        val user = tgvDao.getUser()
        if (user == null) {
            getOrInitUser()
        }

        // Initialize with default notifications if empty
        val notifs = tgvDao.getNotificationsFlow().firstOrNull() ?: emptyList()
        if (notifs.isEmpty()) {
            tgvDao.insertNotification(NotificationEntity(
                title = "Bienvenue à bord de TGV Voyage 🚄",
                content = "Découvrez une toute nouvelle façon de voyager à grande vitesse. Profitez d'un confort premium de Paris à Marseille.",
                timestamp = System.currentTimeMillis() - 3600000
            ))
            tgvDao.insertNotification(NotificationEntity(
                title = "Statut Grand Voyageur Activé 🌟",
                content = "Félicitations ! Votre fidélité vous donne accès aux salons Grand Voyageur de la Gare de Lyon.",
                timestamp = System.currentTimeMillis() - 86400000
            ))
        }

        // Initialize with a default upcoming ticket if empty
        val tickets = tgvDao.getAllTicketsFlow().firstOrNull() ?: emptyList()
        if (tickets.isEmpty()) {
            tgvDao.insertTicket(TicketEntity(
                fromCity = "Paris Gare de Lyon",
                toCity = "Lyon Part-Dieu",
                date = "2026-07-15",
                departureTime = "08:14",
                arrivalTime = "10:12",
                duration = "1h 58m",
                price = 49.0,
                coach = "14",
                seat = "42 (Fenêtre)",
                bookingRef = "TGFZ42",
                classType = "Business Première",
                qrCode = "TGV-REF-TGFZ42-COACH14-SEAT42"
            ))
            tgvDao.insertTicket(TicketEntity(
                fromCity = "Marseille St-Charles",
                toCity = "Paris Gare de Lyon",
                date = "2026-06-20",
                departureTime = "14:02",
                arrivalTime = "17:22",
                duration = "3h 20m",
                price = 72.0,
                coach = "03",
                seat = "18 (Couloir)",
                bookingRef = "XJH9QY",
                classType = "Seconde Classe",
                qrCode = "TGV-REF-XJH9QY-COACH03-SEAT18"
            ))
        }

        // Initialize recent searches if empty
        val searches = tgvDao.getRecentSearchesFlow().firstOrNull() ?: emptyList()
        if (searches.isEmpty()) {
            tgvDao.insertRecentSearch(RecentSearchEntity(fromCity = "Paris", toCity = "Lyon"))
            tgvDao.insertRecentSearch(RecentSearchEntity(fromCity = "Paris", toCity = "Bordeaux"))
        }

        // Initialize chat messages if empty
        val chat = tgvDao.getSupportMessagesFlow().firstOrNull() ?: emptyList()
        if (chat.isEmpty()) {
            tgvDao.insertSupportMessage(SupportMessageEntity(sender = "agent", text = "Bonjour ! Bienvenue au support TGV Voyage. Comment puis-je vous aider aujourd'hui ? 🇫🇷"))
        }
    }
}
