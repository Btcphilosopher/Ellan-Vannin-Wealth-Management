package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AppScreen
import com.example.MainViewModel
import com.example.R
import com.example.TrainConnection
import com.example.data.NotificationEntity
import com.example.data.RecentSearchEntity
import com.example.data.TicketEntity
import com.example.ui.theme.*
import kotlinx.coroutines.launch

// --- REUSABLE UI COMPONENTS ---

@Composable
fun AppHeader(viewModel: MainViewModel, notificationsCount: Int) {
    var showLanguageDropdown by remember { mutableStateOf(false) }
    var showNotifDropdown by remember { mutableStateOf(false) }
    val notifications by viewModel.notificationsState.collectAsState()
    val user by viewModel.userState.collectAsState()

    // Extract initials for the profile circle (e.g., Tom de l'Hérault -> TH, or default JP)
    val initials = remember(user) {
        val name = user?.name ?: "Tom"
        val parts = name.split(" ").filter { it.isNotBlank() }
        if (parts.size >= 2) {
            "${parts[0].firstOrNull() ?: 'T'}${parts[1].firstOrNull() ?: 'H'}".uppercase()
        } else {
            "${name.firstOrNull() ?: 'T'}".uppercase()
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = TgvWarmGrey) // Subtle light bottom border
    ) {
        Column(
            modifier = Modifier
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // App Brand in Clean Utility Style
                Column {
                    Text(
                        text = "VOYAGEUR",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.secondary, // Burgundy accent
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "TGV VOYAGE",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif, // Serif font-family pairing
                        color = MaterialTheme.colorScheme.primary, // Oxford Blue
                        letterSpacing = (-0.5).sp
                    )
                }

                // Header Actions
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Notification Bell (styled to match minimal look)
                    Box {
                        IconButton(
                            onClick = { showNotifDropdown = !showNotifDropdown },
                            modifier = Modifier
                                .size(36.dp)
                                .background(TgvWarmGrey, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notifications",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        val unreadCount = notifications.count { !it.isRead }
                        if (unreadCount > 0) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .background(TgvAccentRed, CircleShape)
                                    .align(Alignment.TopEnd)
                                    .offset(x = 2.dp, y = (-2).dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = unreadCount.toString(),
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        // Notifications Dropdown Mock
                        if (showNotifDropdown) {
                            DropdownMenu(
                                expanded = showNotifDropdown,
                                onDismissRequest = { showNotifDropdown = false },
                                modifier = Modifier
                                    .width(300.dp)
                                    .background(MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "Notifications",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                    Divider()
                                    if (notifications.isEmpty()) {
                                        Text(
                                            text = "Aucune notification.",
                                            fontSize = 13.sp,
                                            modifier = Modifier.padding(vertical = 12.dp)
                                        )
                                    } else {
                                        notifications.take(4).forEach { notif ->
                                            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                                Text(
                                                    text = notif.title,
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 13.sp,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                                Text(
                                                    text = notif.content,
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Divider()
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Language Switcher Button (styled as clean utility circle button)
                    Box {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(TgvWarmGrey, CircleShape)
                                .clickable { showLanguageDropdown = !showLanguageDropdown },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = viewModel.selectedLanguage,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        DropdownMenu(
                            expanded = showLanguageDropdown,
                            onDismissRequest = { showLanguageDropdown = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("🇫🇷 Français") },
                                onClick = {
                                    viewModel.setLanguage("FR")
                                    showLanguageDropdown = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("🇬🇧 English") },
                                onClick = {
                                    viewModel.setLanguage("EN")
                                    showLanguageDropdown = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("🇩🇪 German") },
                                onClick = {
                                    viewModel.setLanguage("DE")
                                    showLanguageDropdown = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("🇪🇸 Spanish") },
                                onClick = {
                                    viewModel.setLanguage("ES")
                                    showLanguageDropdown = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("🇮🇹 Italian") },
                                onClick = {
                                    viewModel.setLanguage("IT")
                                    showLanguageDropdown = false
                                }
                            )
                        }
                    }

                    // User Profile initials badge
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initials,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppBottomNavigation(
    currentScreen: AppScreen,
    onTabSelected: (AppScreen) -> Unit,
    viewModel: MainViewModel
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = TgvWarmGrey) // Clean utility top border
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val items = listOf(
                Triple(AppScreen.HOME, Icons.Default.Search, viewModel.t("nav_home")),
                Triple(AppScreen.TICKETS, Icons.Default.ConfirmationNumber, viewModel.t("nav_tickets")),
                Triple(AppScreen.STATIONS, Icons.Default.LocationOn, viewModel.t("nav_stations")),
                Triple(AppScreen.LOYALTY, Icons.Default.CardMembership, viewModel.t("nav_loyalty")),
                Triple(AppScreen.SUPPORT, Icons.Default.SupportAgent, viewModel.t("nav_support")),
                Triple(AppScreen.DEVELOPER, Icons.Default.AdminPanelSettings, "Dev")
            )

            items.forEach { (screen, icon, label) ->
                val selected = currentScreen == screen
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = androidx.compose.material3.ripple(bounded = false, radius = 24.dp),
                            onClick = { onTabSelected(screen) }
                        )
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Small active dot indicators above to match the clean design HTML
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .background(
                                color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = CircleShape
                            )
                    )

                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (selected) MaterialTheme.colorScheme.primary else TgvMutedGrey,
                        modifier = Modifier
                            .size(20.dp)
                            .testTag("nav_${screen.name.lowercase()}_tab")
                    )

                    Text(
                        text = label,
                        fontSize = 9.sp,
                        fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
                        color = if (selected) MaterialTheme.colorScheme.primary else TgvMutedGrey,
                        letterSpacing = 0.5.sp,
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

// --- SCREEN 1: HOME SCREEN ---

@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val recentSearches by viewModel.recentSearchesState.collectAsState()
    val tickets by viewModel.ticketsState.collectAsState()
    val user by viewModel.userState.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Hero Photo & Gradient Overlay
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_tgv_hero),
                    contentDescription = "TGV Train Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)),
                                startY = 100f
                            )
                        )
                )
                // Welcome Phrase
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Bonjour, ${user?.name ?: "Tom"} 🚄",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = viewModel.t("search_title"),
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Live Network Alerts Bar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = TgvNavy.copy(alpha = 0.05f)),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFF4CAF50), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = viewModel.t("service_ok"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Search Planner Widget
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(28.dp),
                border = BorderStroke(1.dp, TgvWarmGrey),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "PLANIFICATEUR DE VOYAGES",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Origin Station Input
                    OutlinedTextField(
                        value = viewModel.searchOrigin,
                        onValueChange = { viewModel.searchOrigin = it },
                        label = { Text(viewModel.t("from_city")) },
                        leadingIcon = { Icon(Icons.Default.LocationOn, "Origin") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("origin_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = TgvWarmGrey,
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            unfocusedLabelColor = TgvMutedGrey
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Swap Locations Indicator
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        IconButton(
                            onClick = {
                                val tmp = viewModel.searchOrigin
                                viewModel.searchOrigin = viewModel.searchDestination
                                viewModel.searchDestination = tmp
                            },
                            modifier = Modifier.background(TgvNavy.copy(alpha = 0.05f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = "Swap cities",
                                tint = TgvNavy
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Destination Input
                    OutlinedTextField(
                        value = viewModel.searchDestination,
                        onValueChange = { viewModel.searchDestination = it },
                        label = { Text(viewModel.t("to_city")) },
                        leadingIcon = { Icon(Icons.Default.LocationOn, "Destination") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("destination_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = TgvWarmGrey,
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            unfocusedLabelColor = TgvMutedGrey
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Travel Date Input
                    OutlinedTextField(
                        value = viewModel.travelDate,
                        onValueChange = { viewModel.travelDate = it },
                        label = { Text(viewModel.t("travel_date")) },
                        leadingIcon = { Icon(Icons.Default.CalendarMonth, "Date") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = TgvWarmGrey,
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            unfocusedLabelColor = TgvMutedGrey
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Ticket Cabin Class Select
                    Text(
                        text = viewModel.t("select_class") + ":",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TgvMutedGrey,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Standard", "First", "Business").forEach { cls ->
                            val isSelected = viewModel.searchClass == cls
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else TgvWarmGrey,
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent,
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .clickable { viewModel.searchClass = cls }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = when (cls) {
                                        "First" -> viewModel.t("class_first")
                                        "Business" -> viewModel.t("class_business")
                                        else -> viewModel.t("class_standard")
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else TgvMutedGrey
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Search Button
                    Button(
                        onClick = { viewModel.executeSearch() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("search_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        if (viewModel.isSearching) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        } else {
                            Icon(Icons.Default.Search, "Search")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = viewModel.t("search_btn"), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Active Booking search results trigger
        if (viewModel.showSearchResults) {
            item {
                JourneySearchResultsWidget(viewModel)
            }
        }

        // Upcoming Journeys list
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = viewModel.t("upcoming_trips").uppercase(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                if (tickets.none { !it.isRefunded }) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = TgvWarmGrey)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.ConfirmationNumber,
                                contentDescription = "No tickets",
                                tint = TgvMutedGrey,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = viewModel.t("no_trips"),
                                fontSize = 13.sp,
                                color = TgvMutedGrey,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                } else {
                    tickets.filter { !it.isRefunded }.take(2).forEachIndexed { index, tkt ->
                        if (index == 0) {
                            // Premium French minimalist Departure Card
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                                    .clickable { viewModel.currentScreen = AppScreen.TICKETS },
                                shape = RoundedCornerShape(28.dp),
                                colors = CardDefaults.cardColors(containerColor = TgvNavy)
                            ) {
                                Column(modifier = Modifier.padding(24.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .background(Color.White.copy(alpha = 0.15f), CircleShape)
                                                .padding(horizontal = 12.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "PROCHAIN DÉPART",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                letterSpacing = 1.sp
                                            )
                                        }
                                        Text(
                                            text = "TGV INOUI ${6600 + tkt.id}",
                                            fontFamily = FontFamily.Monospace,
                                            color = Color.White.copy(alpha = 0.7f),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = tkt.fromCity.replace(" Gare", "").uppercase(),
                                                color = Color.White,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Serif
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = tkt.departureTime,
                                                color = Color.White,
                                                fontSize = 28.sp,
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                        }

                                        Icon(
                                            imageVector = Icons.Default.ArrowForward,
                                            contentDescription = "Arrow",
                                            tint = Color.White.copy(alpha = 0.6f),
                                            modifier = Modifier.padding(horizontal = 12.dp)
                                        )

                                        Column(
                                            modifier = Modifier.weight(1f),
                                            horizontalAlignment = Alignment.End
                                        ) {
                                            Text(
                                                text = tkt.toCity.replace(" Gare", "").uppercase(),
                                                color = Color.White,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Serif
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = tkt.arrivalTime,
                                                color = Color.White,
                                                fontSize = 28.sp,
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "VOITURE | PLACE",
                                                color = Color.White.copy(alpha = 0.6f),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                letterSpacing = 0.5.sp
                                            )
                                            Text(
                                                text = "Voie ${tkt.coach} | Siège ${tkt.seat}",
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "RÉFÉRENCE",
                                                color = Color.White.copy(alpha = 0.6f),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                letterSpacing = 0.5.sp
                                            )
                                            Text(
                                                text = tkt.bookingRef,
                                                color = TgvGold,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                letterSpacing = 1.sp
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    Button(
                                        onClick = { viewModel.currentScreen = AppScreen.TICKETS },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                        shape = RoundedCornerShape(20.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.QrCode,
                                            contentDescription = "Ticket QR",
                                            tint = TgvNavy,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Afficher le Billet QR",
                                            color = TgvNavy,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        } else {
                            // Secondary trip card
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 10.dp)
                                    .clickable { viewModel.currentScreen = AppScreen.TICKETS },
                                shape = RoundedCornerShape(24.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, TgvWarmGrey)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = tkt.classType,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.secondary,
                                            modifier = Modifier
                                                .background(
                                                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f),
                                                    RoundedCornerShape(4.dp)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                        Text(
                                            text = tkt.date,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TgvMutedGrey
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(text = tkt.fromCity, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text(text = tkt.departureTime, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                        }
                                        Icon(Icons.Default.ArrowForward, "to", tint = TgvAccentRed)
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(text = tkt.toCity, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text(text = tkt.arrivalTime, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${viewModel.t("coach")} ${tkt.coach} | ${viewModel.t("seat")} ${tkt.seat}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = TgvMutedGrey
                                        )
                                        Text(
                                            text = tkt.bookingRef,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.primary,
                                            letterSpacing = 1.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Recent Searches Widget
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = viewModel.t("recent_searches").uppercase(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    recentSearches.forEach { item ->
                        Card(
                            modifier = Modifier.clickable {
                                viewModel.searchOrigin = item.fromCity
                                viewModel.searchDestination = item.toCity
                                viewModel.executeSearch()
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, TgvWarmGrey)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, "search", tint = TgvMutedGrey, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${item.fromCity} ➔ ${item.toCity}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Loyalty Status Preview
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(130.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { viewModel.currentScreen = AppScreen.LOYALTY }
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_loyalty_card_bg),
                    contentDescription = "Loyalty BG",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)))
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = viewModel.t("loyalty_card_title").uppercase(),
                        color = TgvGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = user?.loyaltyTier ?: "Grand Voyageur Plus",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(text = "SOLDE DE POINTS", color = Color.White.copy(alpha = 0.7f), fontSize = 9.sp)
                            Text(text = "${user?.loyaltyPoints ?: 0} PTS", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }
                        Text(text = "MEMBRE PREMIUM", color = TgvGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Special Travel Offers
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = viewModel.t("special_offers").uppercase(),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                val offers = listOf(
                    Triple("Paris ➔ Bordeaux", "€29", "Offre escapade week-end"),
                    Triple("Paris ➔ Lyon", "€19", "Tarif spécial OUIGO"),
                    Triple("Paris ➔ Marseille", "€39", "Volez à 300 km/h vers le Sud")
                )

                offers.forEach { (route, price, desc) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clickable {
                                val split = route.split(" ➔ ")
                                viewModel.searchOrigin = split[0] + " Gare"
                                viewModel.searchDestination = split[1]
                                viewModel.executeSearch()
                            },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, TgvWarmGrey)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = route, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(text = desc, fontSize = 12.sp, color = TgvMutedGrey)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = price, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = TgvBurgundy)
                                Text(text = "aller simple", fontSize = 9.sp, color = TgvMutedGrey)
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- BOOKING FLOW & SEARCH RESULTS COMPONENT ---

@Composable
fun JourneySearchResultsWidget(viewModel: MainViewModel) {
    val results by viewModel.searchResults

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
            .border(1.dp, TgvWarmGrey, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TRAJETS TROUVÉS (${results.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary
            )
            IconButton(onClick = { viewModel.showSearchResults = false }) {
                Icon(Icons.Default.Close, "close", tint = TgvAccentRed)
            }
        }
        Divider(modifier = Modifier.padding(vertical = 12.dp))

        when (viewModel.bookingStep) {
            1 -> { // Search Results
                results.forEach { conn ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .clickable { viewModel.selectTrain(conn) },
                        colors = CardDefaults.cardColors(containerColor = TgvWarmGrey.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, TgvWarmGrey)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = conn.trainNumber, fontWeight = FontWeight.Bold, color = TgvNavy, fontSize = 13.sp)
                                Text(text = conn.operator, fontSize = 11.sp, color = TgvMutedGrey, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = conn.departureTime, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TgvNavy)
                                    Text(text = viewModel.searchOrigin.split(" ").first(), fontSize = 12.sp, color = TgvMutedGrey)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(text = conn.duration, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Divider(modifier = Modifier.width(60.dp), color = TgvAccentRed)
                                    Text(text = "Direct", fontSize = 10.sp, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = conn.arrivalTime, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TgvNavy)
                                    Text(text = viewModel.searchDestination.split(" ").first(), fontSize = 12.sp, color = TgvMutedGrey)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val currentPrice = when (viewModel.searchClass) {
                                    "First" -> conn.priceFirst
                                    "Business" -> conn.priceBusiness
                                    else -> conn.priceStandard
                                }
                                Text(
                                    text = when (viewModel.searchClass) {
                                        "First" -> viewModel.t("class_first")
                                        "Business" -> viewModel.t("class_business")
                                        else -> viewModel.t("class_standard")
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Text(
                                    text = "€${"%.2f".format(currentPrice)}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = TgvBurgundy
                                )
                            }
                        }
                    }
                }
            }

            2 -> { // Interactive Seat Selection
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = viewModel.t("seat_selector").uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Carriages selector Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("11", "12", "14", "15").forEach { coach ->
                            val isSel = viewModel.selectedCoach == coach
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        if (isSel) TgvBurgundy else TgvWarmGrey,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { viewModel.selectedCoach = coach }
                                    .padding(4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "V.$coach",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSel) Color.White else TgvNavy
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Simulated Train carriage seating layout
                    Text(text = "<- SENS DE LA MARCHE / TRAIN DIRECTION ->", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TgvMutedGrey)
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        border = BorderStroke(2.dp, TgvNavy),
                        colors = CardDefaults.cardColors(containerColor = TgvWhite),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Render rows of seats
                            val seats = listOf(
                                listOf("11A", "11B", "", "11C", "11D"),
                                listOf("12A", "12B", "", "12C", "12D"),
                                listOf("14A", "14B", "", "14C", "14D"),
                                listOf("15A", "15B", "", "15C", "15D")
                            )

                            seats.forEach { row ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    row.forEach { seatNum ->
                                        if (seatNum.isEmpty()) {
                                            Spacer(modifier = Modifier.width(20.dp)) // Aisle
                                        } else {
                                            val isOccupied = seatNum.contains("D") || seatNum.contains("15")
                                            val isSelected = viewModel.selectedSeat == seatNum
                                            val bgColor = when {
                                                isSelected -> TgvBurgundy
                                                isOccupied -> TgvMutedGrey.copy(alpha = 0.4f)
                                                else -> Color(0xFF4CAF50).copy(alpha = 0.2f)
                                            }
                                            val borderCol = when {
                                                isSelected -> TgvBurgundy
                                                else -> TgvMutedGrey
                                            }

                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .border(1.dp, borderCol, RoundedCornerShape(4.dp))
                                                    .background(bgColor, RoundedCornerShape(4.dp))
                                                    .clickable(enabled = !isOccupied) {
                                                        viewModel.selectedSeat = seatNum
                                                    }
                                                    .padding(2.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = seatNum,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isSelected) Color.White else TgvNavy
                                                )
                                            }
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "SIÈGE SÉLECTIONNÉ", fontSize = 10.sp, color = TgvMutedGrey, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${viewModel.t("coach")} ${viewModel.selectedCoach} | ${viewModel.t("seat")} ${viewModel.selectedSeat}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TgvNavy
                            )
                        }

                        Button(
                            onClick = { viewModel.confirmSeats(viewModel.selectedCoach, viewModel.selectedSeat) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "Suivant", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            3 -> { // Passenger Info Profile Form
                Column {
                    Text(
                        text = viewModel.t("passenger_details").uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = viewModel.passengerName,
                        onValueChange = { viewModel.passengerName = it },
                        label = { Text("Nom Complet") },
                        leadingIcon = { Icon(Icons.Default.Person, "name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = viewModel.passengerEmail,
                        onValueChange = { viewModel.passengerEmail = it },
                        label = { Text("Adresse Email") },
                        leadingIcon = { Icon(Icons.Default.Email, "email") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = viewModel.promoCode,
                        onValueChange = { viewModel.promoCode = it },
                        label = { Text("Code Promo / Carte Avantage") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.bookingStep = 2 },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "Retour")
                        }

                        Button(
                            onClick = { viewModel.confirmPassengers(viewModel.passengerName, viewModel.passengerEmail) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(text = "Suivant", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            4 -> { // Secure Credit Card Payment Simulator
                Column {
                    Text(
                        text = viewModel.t("pay_securely").uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Beautiful Simulated Visa Card layout with Gradient
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(TgvNavy, TgvBurgundy)
                                ),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "VISA PREMIUM", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Icon(Icons.Default.CreditCard, "visa", tint = Color.White)
                            }
                            Spacer(modifier = Modifier.height(20.dp))
                            Text(text = "••••  ••••  ••••  4200", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.weight(1f))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = viewModel.passengerName.uppercase(), color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(text = "12/29", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(text = "Transaction cryptée SSL 256-bit", fontSize = 11.sp, color = TgvMutedGrey, modifier = Modifier.align(Alignment.CenterHorizontally))

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val finalPrice = when (viewModel.searchClass) {
                            "First" -> viewModel.selectedConnection?.priceFirst ?: 0.0
                            "Business" -> viewModel.selectedConnection?.priceBusiness ?: 0.0
                            else -> viewModel.selectedConnection?.priceStandard ?: 0.0
                        }

                        Text(
                            text = "TOTAL: €${"%.2f".format(finalPrice)}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TgvNavy
                        )

                        Button(
                            onClick = { viewModel.processSecureBooking() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("pay_button")
                        ) {
                            Text(text = "Confirmer", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            5 -> { // Success & Confirmation
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = Color(0xFF4CAF50),
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = viewModel.t("book_success"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF4CAF50),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Votre billet est disponible dans l'onglet 'Billets' et accessible hors-ligne. Bon voyage à bord du TGV !",
                        fontSize = 12.sp,
                        color = TgvMutedGrey,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.showSearchResults = false
                            viewModel.currentScreen = AppScreen.TICKETS
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = "Consulter mes billets", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- SCREEN 2: DIGITAL TICKETS SCREEN ---

@Composable
fun TicketsScreen(viewModel: MainViewModel) {
    val tickets by viewModel.ticketsState.collectAsState()
    var selectedTicket by remember { mutableStateOf<TicketEntity?>(null) }
    var showRefundDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 80.dp)
    ) {
        item {
            Text(
                text = viewModel.t("nav_tickets").uppercase(),
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        if (tickets.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.ConfirmationNumber,
                            contentDescription = "No tickets",
                            tint = TgvMutedGrey,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Vous n'avez pas encore de billets réservés.",
                            fontSize = 14.sp,
                            color = TgvMutedGrey,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            items(tickets) { tkt ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .clickable { selectedTicket = tkt },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (tkt.isRefunded) TgvWarmGrey else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, if (tkt.isRefunded) Color.Transparent else TgvWarmGrey)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = tkt.classType.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (tkt.isRefunded) TgvMutedGrey else MaterialTheme.colorScheme.secondary,
                                modifier = Modifier
                                    .background(
                                        if (tkt.isRefunded) TgvMutedGrey.copy(alpha = 0.15f) else MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f),
                                        RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )

                            if (tkt.isRefunded) {
                                Text(
                                    text = "ANNULÉ / REMBOURSÉ",
                                    color = TgvAccentRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            } else {
                                Text(
                                    text = tkt.date,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TgvMutedGrey
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = tkt.fromCity, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    text = tkt.departureTime,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (tkt.isRefunded) TgvMutedGrey else MaterialTheme.colorScheme.primary
                                )
                            }
                            Icon(
                                Icons.Default.ArrowForward,
                                "to",
                                tint = if (tkt.isRefunded) TgvMutedGrey else TgvAccentRed
                            )
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = tkt.toCity, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    text = tkt.arrivalTime,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (tkt.isRefunded) TgvMutedGrey else MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Divider(modifier = Modifier.padding(vertical = 4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "DÉTAILS PLACEMENT", fontSize = 10.sp, color = TgvMutedGrey, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${viewModel.t("coach")} ${tkt.coach} | ${viewModel.t("seat")} ${tkt.seat}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TgvNavy
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = viewModel.t("booking_ref").uppercase(), fontSize = 10.sp, color = TgvMutedGrey, fontWeight = FontWeight.Bold)
                                Text(
                                    text = tkt.bookingRef,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary,
                                    letterSpacing = 1.sp
                                )
                            }
                        }

                        // Detailed expanded ticket section with QR
                        if (selectedTicket?.id == tkt.id) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Divider(modifier = Modifier.padding(bottom = 16.dp))

                                // QR Code Pass Simulator
                                Card(
                                    border = BorderStroke(1.dp, TgvNavy.copy(alpha = 0.2f)),
                                    colors = CardDefaults.cardColors(containerColor = TgvWhite),
                                    modifier = Modifier.size(150.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.QrCode,
                                            contentDescription = "Ticket QR",
                                            modifier = Modifier.size(100.dp),
                                            tint = TgvNavy
                                        )
                                        Text(text = tkt.bookingRef, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TgvNavy)
                                        Text(text = "SCANNEZ À L'ACCÈS", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = TgvAccentRed)
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                if (!tkt.isRefunded) {
                                    Button(
                                        onClick = { showRefundDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = TgvBurgundy),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, "Refund")
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = viewModel.t("refund_ticket"), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Refund Confirmation Dialog
    if (showRefundDialog && selectedTicket != null) {
        AlertDialog(
            onDismissRequest = { showRefundDialog = false },
            title = { Text(text = "Annuler la réservation ?") },
            text = { Text(text = "Êtes-vous sûr de vouloir annuler et rembourser intégralement votre billet d'un montant de €${"%.2f".format(selectedTicket!!.price)} ? L'opération est irréversible.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.processRefund(selectedTicket!!)
                        showRefundDialog = false
                        selectedTicket = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TgvAccentRed)
                ) {
                    Text(text = "Oui, Annuler", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRefundDialog = false }) {
                    Text(text = "Retour")
                }
            }
        )
    }
}

// --- SCREEN 3: STATIONS GUIDE SCREEN ---

data class StationInfo(
    val name: String,
    val address: String,
    val platformCount: Int,
    val transport: String,
    val facilities: String,
    val accessibility: String
)

@Composable
fun StationsScreen(viewModel: MainViewModel) {
    val stations = listOf(
        StationInfo(
            name = "Paris Gare de Lyon",
            address = "4 Place Louis-Armand, 75012 Paris",
            platformCount = 23,
            transport = "Métro Lignes 1, 14 | RER Lignes A, D | Bus 24, 63, 87",
            facilities = "Salons Grand Voyageur, Relay, Starbucks, Pret A Manger, FNAC",
            accessibility = "Rampes d'accès, personnel d'assistance dédié sur réservation, ascenseurs aux quais"
        ),
        StationInfo(
            name = "Lyon Part-Dieu",
            address = "5 Place Charles Béraudier, 69003 Lyon",
            platformCount = 11,
            transport = "Métro Ligne B | Tramways T1, T3, T4 | Navette Aéroport Rhône Express",
            facilities = "Relay, Paul, Monop'daily, Brasserie l'Est",
            accessibility = "Ascenseurs, rampes mobiles et service d'assistance voyageurs à mobilité réduite"
        ),
        StationInfo(
            name = "Marseille Saint-Charles",
            address = "Square Narvik, 13001 Marseille",
            platformCount = 16,
            transport = "Métro Lignes 1, 2 | Navettes Aéroport | Bus régionaux",
            facilities = "Relay, Starbucks, Brioche Dorée, Lounges",
            accessibility = "Guichets surbaissés, ascenseurs d'accès, bandes de guidage au sol"
        ),
        StationInfo(
            name = "Bordeaux Saint-Jean",
            address = "Rue Charles Domercq, 33800 Bordeaux",
            platformCount = 15,
            transport = "Tramway Lignes C, D | Bus directs aéroport | Vélos en libre-service",
            facilities = "Boutiques vins de Bordeaux, Relay, Paul, Starbucks",
            accessibility = "Rampes d'accès intégrées, escaliers mécaniques et ascenseurs sur tous les quais"
        )
    )

    var activeStationIndex by remember { mutableStateOf(0) }
    var activeSubTab by remember { mutableStateOf(0) } // 0: Infos, 1: Transports, 2: Services

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 80.dp)
    ) {
        item {
            Text(
                text = "GUIDE DES GARES",
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        // Stations list Selector Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                stations.forEachIndexed { idx, st ->
                    val isSel = activeStationIndex == idx
                    Box(
                        modifier = Modifier
                            .border(
                                width = 1.dp,
                                color = if (isSel) MaterialTheme.colorScheme.secondary else TgvWarmGrey,
                                shape = RoundedCornerShape(20.dp)
                            )
                            .background(
                                if (isSel) MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f) else Color.Transparent,
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable {
                                activeStationIndex = idx
                                activeSubTab = 0
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = st.name.replace("Gare de ", "").replace("Saint-", "St-"),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSel) MaterialTheme.colorScheme.secondary else TgvMutedGrey
                        )
                    }
                }
            }
        }

        val activeStation = stations[activeStationIndex]

        // Sub-tabs row
        item {
            TabRow(
                selectedTabIndex = activeSubTab,
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Tab(
                    selected = activeSubTab == 0,
                    onClick = { activeSubTab = 0 },
                    text = { Text("Général", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = activeSubTab == 1,
                    onClick = { activeSubTab = 1 },
                    text = { Text("Transports", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = activeSubTab == 2,
                    onClick = { activeSubTab = 2 },
                    text = { Text("Services & PMR", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
            }
        }

        // Selected station Details card
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, TgvWarmGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = activeStation.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    when (activeSubTab) {
                        0 -> { // General Info
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, "Address", tint = TgvAccentRed)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(text = "ADRESSE", fontSize = 10.sp, color = TgvMutedGrey, fontWeight = FontWeight.Bold)
                                    Text(text = activeStation.address, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Train, "Platforms", tint = MaterialTheme.colorScheme.secondary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(text = "NOMBRE DE QUAIS", fontSize = 10.sp, color = TgvMutedGrey, fontWeight = FontWeight.Bold)
                                    Text(text = "${activeStation.platformCount} Voies de raccordement grande vitesse", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }

                        1 -> { // Public Transport Connections
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.DirectionsBus, "Bus", tint = MaterialTheme.colorScheme.secondary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = "TRANSPORTS EN COMMUN", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = activeStation.transport,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp,
                                    modifier = Modifier.padding(start = 32.dp)
                                )
                            }
                        }

                        2 -> { // Facilities & PMR Accessibility
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Coffee, "Coffee", tint = TgvBurgundy)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = "BOUTIQUES & RESTAURATION", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = activeStation.facilities,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(start = 32.dp, bottom = 16.dp)
                                )

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Accessible, "Accessibility", tint = Color(0xFF4CAF50))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = "ACCESSIBILITÉ PMR", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = activeStation.accessibility,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp,
                                    modifier = Modifier.padding(start = 32.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SCREEN 4: LOYALTY CLUB SCREEN ---

@Composable
fun LoyaltyScreen(viewModel: MainViewModel) {
    val user by viewModel.userState.collectAsState()
    val scope = rememberCoroutineScope()
    var activeRewardSelected by remember { mutableStateOf<String?>(null) }
    var rewardStatusMessage by remember { mutableStateOf<String?>(null) }

    val rewards = listOf(
        Triple("Café & Croissant Offert", 500, "Un petit déjeuner premium en voiture bar"),
        Triple("Accès Salon Grand Voyageur", 1000, "Profitez des espaces d'attente VIP en gare"),
        Triple("Surclassement 1ère Classe", 1500, "Surclassez votre prochain voyage TGV InOui"),
        Triple("Bon d'achat de €15", 2000, "Voucher de réduction immédiate sur vos trajets")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 80.dp)
    ) {
        item {
            Text(
                text = "PROGRAMME FIDÉLITÉ",
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        // Luxury VIP Loyalty membership card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(24.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_loyalty_card_bg),
                    contentDescription = "Loyalty BG",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "SNCF VOYAGES", color = TgvGold, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
                        Icon(Icons.Default.Star, "VIP", tint = TgvGold)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = user?.name ?: "Tom de l'Hérault", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text(text = "N° MEMBRE: LOY-9428-${user?.loyaltyPoints ?: 120}", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)

                    Spacer(modifier = Modifier.weight(1f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(text = "SOLDE FIDÉLITÉ", color = Color.White.copy(alpha = 0.7f), fontSize = 9.sp)
                            Text(text = "${user?.loyaltyPoints ?: 0} POINTS", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        }
                        Text(
                            text = user?.loyaltyTier ?: "Grand Voyageur Plus",
                            color = TgvGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .border(1.dp, TgvGold, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Points Accumulation visual progress
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, TgvWarmGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "VOTRE PARCOURS FIDÉLITÉ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )

                    val currentPoints = user?.loyaltyPoints ?: 0
                    val goalPoints = 4000
                    val progress = (currentPoints.toFloat() / goalPoints).coerceIn(0f, 1f)

                    LinearProgressIndicator(
                        progress = progress,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = TgvBurgundy,
                        trackColor = TgvWarmGrey
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "$currentPoints PTS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(text = "Objectif Statut Le Club : $goalPoints PTS", color = TgvMutedGrey, fontSize = 11.sp)
                    }
                }
            }
        }

        // Reward redeem notification status
        rewardStatusMessage?.let { msg ->
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Check, "check", tint = Color(0xFF4CAF50))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = msg, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Loyalty points rewards shop
        item {
            Text(
                text = "BOUTIQUE DE RÉCOMPENSES",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        items(rewards) { (title, cost, desc) ->
            val hasEnoughPoints = (user?.loyaltyPoints ?: 0) >= cost
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, TgvWarmGrey)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = desc, fontSize = 12.sp, color = TgvMutedGrey)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "$cost POINTS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TgvBurgundy
                        )
                    }

                    Button(
                        onClick = {
                            if (hasEnoughPoints && user != null) {
                                val updated = user!!.copy(loyaltyPoints = user!!.loyaltyPoints - cost)
                                scope.launch {
                                    viewModel.updateUser(updated)
                                    viewModel.sendSupportMessage("Remboursement points boutique pour: $title")
                                    rewardStatusMessage = "Récompense '$title' activée avec succès !"
                                }
                            }
                        },
                        enabled = hasEnoughPoints,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            disabledContainerColor = TgvWarmGrey
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = "Échanger", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- SCREEN 5: SUPPORT CHAT & FAQ ---

@Composable
fun SupportScreen(viewModel: MainViewModel) {
    val messages by viewModel.supportMessagesState.collectAsState()
    var inputMessageText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 80.dp)
    ) {
        item {
            Text(
                text = "ASSISTANCE & AIDE",
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        // Live Help Chat Container
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, TgvWarmGrey),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Chat header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TgvNavy)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.SupportAgent, "Agent", tint = TgvGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = "Chat d'assistance en direct", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(text = "Agent SNCF en ligne", color = Color(0xFF4CAF50), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Chat bubble scroll area
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            messages.forEach { msg ->
                                val isUser = msg.sender == "user"
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (isUser) MaterialTheme.colorScheme.secondary else TgvWarmGrey,
                                                RoundedCornerShape(12.dp)
                                            )
                                            .padding(10.dp)
                                            .widthIn(max = 220.dp)
                                    ) {
                                        Text(
                                            text = msg.text,
                                            color = if (isUser) Color.White else TgvNavy,
                                            fontSize = 12.sp,
                                            lineHeight = 16.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Chat quick-reply triggers
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Remboursement ?", "Objet perdu ?", "Grève ?").forEach { qr ->
                            Box(
                                modifier = Modifier
                                    .background(TgvNavy.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                    .clickable { viewModel.sendSupportMessage(qr) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(text = qr, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TgvNavy)
                            }
                        }
                    }

                    // Input Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = inputMessageText,
                            onValueChange = { inputMessageText = it },
                            placeholder = { Text("Posez votre question...", fontSize = 12.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            singleLine = true,
                            shape = RoundedCornerShape(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (inputMessageText.isNotBlank()) {
                                    viewModel.sendSupportMessage(inputMessageText)
                                    inputMessageText = ""
                                }
                            },
                            modifier = Modifier.background(MaterialTheme.colorScheme.secondary, CircleShape)
                        ) {
                            Icon(Icons.Default.Send, "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        // Accordion Collapsible FAQs List
        item {
            Text(
                text = "QUESTIONS FRÉQUENTES (FAQ)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        val faqs = listOf(
            Pair("Comment annuler et rembourser mon billet ?", "Vous pouvez annuler sans frais votre billet TGV INOUI jusqu'à 6 jours avant l'heure de départ. Rendez-vous dans l'onglet 'Billets', sélectionnez votre voyage et cliquez sur le bouton 'Annuler & Rembourser'."),
            Pair("Puis-je voyager avec mon animal de compagnie ?", "Oui, les animaux de compagnie de petite taille dans un contenant ou tenus en laisse avec muselière sont autorisés moyennant un titre de transport forfaitaire de €7 accessible en gare."),
            Pair("Qu'est-ce que la garantie ponctualité G30 ?", "Si votre TGV subit un retard supérieur à 30 minutes à l'arrivée, vous bénéficiez d'une compensation de 25% à 75% du prix de votre billet, créditée sous forme de bon d'achat ou de remboursement direct.")
        )

        items(faqs) { (q, a) ->
            var expanded by remember { mutableStateOf(false) }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clickable { expanded = !expanded },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, TgvWarmGrey)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = q, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TgvNavy, modifier = Modifier.weight(1f))
                        Icon(
                            imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expand",
                            tint = TgvMutedGrey
                        )
                    }
                    if (expanded) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = a, fontSize = 12.sp, color = TgvMutedGrey, lineHeight = 16.sp)
                    }
                }
            }
        }
    }
}

// --- SCREEN 6: DEVELOPER & ADMIN PORTAL SCREEN ---

@Composable
fun DeveloperScreen(viewModel: MainViewModel) {
    val tickets by viewModel.ticketsState.collectAsState()
    val user by viewModel.userState.collectAsState()

    var activeDevSubTab by remember { mutableStateOf(0) } // 0: Admin Board, 1: REST API, 2: Backend Source Code
    var simulatedEndpointSelected by remember { mutableStateOf("GET /api/v1/loyalty/status") }
    var apiResponseText by remember { mutableStateOf("{\n  \"status\": \"Click 'Execute Call' to simulate backend response\"\n}") }

    // Backend Source Codes Dictionary
    val backendFiles = mapOf(
        "schema.sql" to """-- TGV Voyage PostgreSQL Database Schema
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL
);

CREATE TABLE bookings (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    booking_reference VARCHAR(10) UNIQUE NOT NULL,
    total_price NUMERIC(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'CONFIRMED'
);

CREATE TABLE tickets (
    id SERIAL PRIMARY KEY,
    booking_id INTEGER REFERENCES bookings(id),
    passenger_name VARCHAR(200) NOT NULL,
    coach_number INTEGER NOT NULL,
    seat_number VARCHAR(10) NOT NULL
);""",
        "TgvBackend.kt" to """package com.tgvvoyage.backend

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.web.bind.annotation.*
import org.springframework.http.ResponseEntity

@SpringBootApplication
class TgvVoyageBackendApplication

fun main(args: Array<String>) {
    runApplication<TgvVoyageBackendApplication>(*args)
}

@RestController
@RequestMapping("/api/v1")
class TgvBookingController {

    @GetMapping("/loyalty/status")
    fun getLoyaltyStatus(): ResponseEntity<Map<String, Any>> {
        val response = mapOf(
            "membershipNumber" to "LOY-9428-1052",
            "pointsBalance" to 2450,
            "tier" to "GRAND_VOYAGEUR_PLUS"
        )
        return ResponseEntity.ok(response)
    }

    @PostMapping("/bookings")
    fun createBooking(@RequestBody payload: BookingPayload): ResponseEntity<BookingResponse> {
        val response = BookingResponse(
            bookingId = 8021,
            bookingReference = "TGFZ42",
            totalPrice = payload.price
        )
        return ResponseEntity.ok(response)
    }
}""",
        "docker-compose.yml" to """version: '3.8'
services:
  tgv-backend:
    build: .
    ports:
      - "8080:8080"
    depends_on:
      - postgres-db
  postgres-db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=tgv_voyage
      - POSTGRES_USER=tgv_admin
      - POSTGRES_PASSWORD=tgv_secure_pass
    ports:
      - "5432:5432"
  redis-cache:
    image: redis:7-alpine
    ports:
      - "6379:6379""""
    )

    var activeSourceFileSelected by remember { mutableStateOf("schema.sql") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 80.dp)
    ) {
        item {
            Text(
                text = "SANDBOX DEVELOPPEUR & ADMIN",
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        // Selector Sub-tabs
        item {
            TabRow(
                selectedTabIndex = activeDevSubTab,
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Tab(
                    selected = activeDevSubTab == 0,
                    onClick = { activeDevSubTab = 0 },
                    text = { Text("Dashboard", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = activeDevSubTab == 1,
                    onClick = { activeDevSubTab = 1 },
                    text = { Text("REST Swagger", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
                Tab(
                    selected = activeDevSubTab == 2,
                    onClick = { activeDevSubTab = 2 },
                    text = { Text("Code Source", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
            }
        }

        when (activeDevSubTab) {
            0 -> { // Administrative Dashboard Operations & Live Stats
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, TgvWarmGrey)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "CONTRÔLE ADMINISTRATIF & STATISTIQUES", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Total Sales Progress Bar Simulation
                            Text(text = "Chiffre d'Affaires Cumulé (Simulé)", fontSize = 11.sp, color = TgvMutedGrey)
                            Text(text = "€${"%,.2f".format(viewModel.totalMockSales)}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = TgvBurgundy)
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = (viewModel.totalMockSales / 500000.0).toFloat().coerceIn(0f, 1f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Color(0xFF4CAF50),
                                trackColor = TgvWarmGrey
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Objectif trimestriel : €500 000,00", fontSize = 9.sp, color = TgvMutedGrey, modifier = Modifier.align(Alignment.End))
                        }
                    }
                }

                item {
                    Text(text = "RÉSERVE DES RÉSERVATIONS ACTIVES (" + tickets.size + ")", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TgvMutedGrey, modifier = Modifier.padding(bottom = 10.dp))
                }

                if (tickets.isEmpty()) {
                    item {
                        Text(text = "Aucune réservation en base de données.", fontSize = 12.sp, color = TgvMutedGrey, modifier = Modifier.padding(vertical = 12.dp))
                    }
                } else {
                    items(tickets) { tkt ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, TgvWarmGrey)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = user?.name ?: "Tom de l'Hérault", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(text = "${tkt.fromCity} ➔ ${tkt.toCity} | €${tkt.price}", fontSize = 11.sp, color = TgvMutedGrey)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (tkt.isRefunded) TgvAccentRed.copy(alpha = 0.15f) else Color(0xFF4CAF50).copy(alpha = 0.15f),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (tkt.isRefunded) "REFUNDED" else "PAID",
                                        color = if (tkt.isRefunded) TgvAccentRed else Color(0xFF2E7D32),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            1 -> { // Interactive REST API Endpoint Swagger Tester
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, TgvWarmGrey)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "SNCF PARTNER SWAGGER PLAYGROUND", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(12.dp))

                            // Selector
                            Text(text = "Sélectionner un Endpoint :", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TgvMutedGrey)
                            val endpoints = listOf(
                                "GET /api/v1/loyalty/status",
                                "GET /api/v1/stations/FRLYO",
                                "POST /api/v1/bookings"
                            )
                            endpoints.forEach { ep ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { simulatedEndpointSelected = ep }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = simulatedEndpointSelected == ep,
                                        onClick = { simulatedEndpointSelected = ep }
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = ep,
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = if (ep.startsWith("GET")) Color(0xFF1E88E5) else Color(0xFF43A047)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Execute Call button
                            Button(
                                onClick = {
                                    apiResponseText = when (simulatedEndpointSelected) {
                                        "GET /api/v1/loyalty/status" -> """{
  "membershipNumber": "LOY-9428-${user?.loyaltyPoints ?: 120}",
  "pointsBalance": ${user?.loyaltyPoints ?: 2450},
  "tier": "${user?.loyaltyTier ?: "GRAND_VOYAGEUR"}",
  "benefits": [
    "Access to Grand Voyageur Station Lounges",
    "Free hot drink in Bar carriage",
    "Priority boarding"
  ]
}"""
                                        "GET /api/v1/stations/FRLYO" -> """{
  "id": 1,
  "name": "Paris Gare de Lyon",
  "code": "FRLYO",
  "address": "4 Place Louis-Armand, 75012 Paris",
  "hasParking": true,
  "hasTaxiStand": true,
  "hasWaitingLounge": true
}"""
                                        "POST /api/v1/bookings" -> """{
  "bookingId": 8021,
  "bookingReference": "TGFZ42",
  "totalPrice": 119.00,
  "status": "CONFIRMED",
  "message": "Secure high-speed rail ticket purchased successfully."
}"""
                                        else -> "{}"
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(Icons.Default.PlayArrow, "Execute")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "Simuler l'appel API", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                item {
                    Text(text = "RÉPONSE JSON DU SERVEUR BACKEND (SPRING BOOT)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TgvMutedGrey, modifier = Modifier.padding(bottom = 10.dp))
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2838)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = apiResponseText,
                                color = Color(0xFF4CAF50),
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            2 -> { // Backend Source Code file viewer
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        backendFiles.keys.forEach { fname ->
                            val isS = activeSourceFileSelected == fname
                            Box(
                                modifier = Modifier
                                    .border(
                                        width = 1.dp,
                                        color = if (isS) MaterialTheme.colorScheme.secondary else TgvWarmGrey,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .background(
                                        if (isS) MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f) else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { activeSourceFileSelected = fname }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = fname,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isS) MaterialTheme.colorScheme.secondary else TgvMutedGrey
                                )
                            }
                        }
                    }
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2838)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = backendFiles[activeSourceFileSelected] ?: "",
                                color = Color(0xFFECEFF1),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
