import {ChangeDetectionStrategy, Component, computed, signal} from '@angular/core';
import {FormControl, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';

interface BrowserTab {
  id: string;
  title: string;
  url: string;
  workspaceId: string;
  icon: string;
}

interface BookmarkFolder {
  id: string;
  name: string;
  items: {title: string; url: string}[];
}

interface WorkspaceItem {
  id: string;
  name: string;
  icon: string;
}

interface ShortcutItem {
  id: string;
  title: string;
  url: string;
  icon: string;
}

interface DownloadItem {
  id: string;
  filename: string;
  source: string;
  destination: string;
  size: string;
  state: 'Terminé' | 'En cours' | 'En pause' | 'Annulé';
  progress: number;
}

interface HistoryRecord {
  id: string;
  title: string;
  url: string;
  visitedAt: string;
}

interface ParsedBarResult {
  kind: 'internal' | 'url' | 'search' | 'blocked' | 'unsupported';
  destination: string;
  message: string;
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
})
export class App {
  readonly activeProfile = signal<'Camille' | 'Travail' | 'Navigation privée'>('Camille');
  readonly isPrivate = computed(() => this.activeProfile() === 'Navigation privée');

  readonly workspaces = signal<WorkspaceItem[]>([
    {id: 'ws-personnel', name: 'Personnel', icon: 'person_outline'},
    {id: 'ws-recherche', name: 'Recherche', icon: 'search'},
    {id: 'ws-voyages', name: 'Voyages', icon: 'work_outline'},
  ]);
  readonly activeWorkspaceId = signal<string>('ws-recherche');

  readonly tabs = signal<BrowserTab[]>([
    {
      id: 'tab-1',
      title: 'Nouvel onglet',
      url: 'verriere://newtab',
      workspaceId: 'ws-recherche',
      icon: 'home',
    },
    {
      id: 'tab-2',
      title: 'Carnet de voyage',
      url: 'verriere://article/architecture-contemporaine',
      workspaceId: 'ws-voyages',
      icon: 'photo_library',
    },
    {
      id: 'tab-3',
      title: 'Architecture contemporaine',
      url: 'verriere://architecture',
      workspaceId: 'ws-recherche',
      icon: 'architecture',
    },
  ]);
  readonly activeTabId = signal<string>('tab-1');

  readonly activeTab = computed(() => {
    const found = this.tabs().find((t) => t.id === this.activeTabId());
    return found ?? this.tabs()[0];
  });

  readonly addressControl = new FormControl('', {nonNullable: true});
  readonly newtabSearchControl = new FormControl('', {nonNullable: true});
  readonly shortcutTitleControl = new FormControl('', {nonNullable: true});
  readonly shortcutUrlControl = new FormControl('', {nonNullable: true});
  readonly userNameControl = new FormControl('Camille', {nonNullable: true});
  readonly eclairControl = new FormControl('', {nonNullable: true});

  readonly openBookmarkFolderId = signal<string | null>(null);
  readonly showProfileMenu = signal(false);
  readonly showSecurityPopover = signal(false);
  readonly showShortcutModal = signal(false);
  readonly showWorkspaceDrawer = signal(false);
  readonly showClearDataModal = signal(false);

  readonly highContrast = signal(false);
  readonly reducedMotion = signal(false);
  readonly showBackground = signal(true);
  readonly showBookmarksBar = signal(true);
  readonly defaultSearchEngine = signal<'qwant' | 'duckduckgo' | 'startpage' | 'eclair'>('qwant');

  readonly statusNotice = signal<string | null>(null);

  readonly bookmarkFolders = signal<BookmarkFolder[]>([
    {
      id: 'f-journal',
      name: 'Le journal',
      items: [
        {title: 'Le Monde', url: 'https://www.lemonde.fr'},
        {title: 'France Culture', url: 'https://www.radiofrance.fr/franceculture'},
      ],
    },
    {
      id: 'f-culture',
      name: 'Culture',
      items: [
        {title: 'BnF — Gallica', url: 'https://gallica.bnf.fr'},
        {title: 'Centre Pompidou', url: 'https://www.centrepompidou.fr'},
      ],
    },
    {
      id: 'f-sciences',
      name: 'Sciences',
      items: [
        {title: 'CNRS Le Journal', url: 'https://lejournal.cnrs.fr'},
        {title: 'Wikipédia en français', url: 'https://fr.wikipedia.org'},
      ],
    },
    {
      id: 'f-voyages',
      name: 'Voyages',
      items: [{title: 'Construire la ville de demain', url: 'verriere://article/architecture-contemporaine'}],
    },
    {
      id: 'f-travail',
      name: 'Travail',
      items: [{title: 'Architecture & Tests PySide6', url: 'verriere://architecture'}],
    },
  ]);

  readonly shortcuts = signal<ShortcutItem[]>([
    {id: 'sc-1', title: 'Courrier', url: 'https://mail.proton.me', icon: 'mail_outline'},
    {id: 'sc-2', title: 'Agenda', url: 'https://framagenda.org', icon: 'calendar_today'},
    {id: 'sc-3', title: 'Actualités', url: 'https://www.lemonde.fr', icon: 'article'},
    {id: 'sc-4', title: 'Culture', url: 'https://gallica.bnf.fr', icon: 'account_balance'},
    {id: 'sc-5', title: 'Recherche', url: 'verriere://settings', icon: 'search'},
  ]);

  readonly historyEntries = signal<HistoryRecord[]>([
    {
      id: 'h-1',
      title: 'Construire la ville de demain — Dossier',
      url: 'verriere://article/architecture-contemporaine',
      visitedAt: '28 novembre 2026 à 14 h 12',
    },
    {
      id: 'h-2',
      title: 'Architecture PySide6 & Résultats pytest',
      url: 'verriere://architecture',
      visitedAt: '28 novembre 2026 à 13 h 48',
    },
  ]);

  readonly downloads = signal<DownloadItem[]>([
    {
      id: 'dl-1',
      filename: 'verriere-architecture-0.1.0.pdf',
      source: 'verriere://architecture',
      destination: '~/Téléchargements/verriere-architecture-0.1.0.pdf',
      size: '428 Ko',
      state: 'Terminé',
      progress: 100,
    },
  ]);

  readonly compatibilityRows = [
    {cap: 'Rendu Web & PDF intégré', status: 'Pris en charge', note: 'Qt WebEngine (Chromium maintenu) avec sandbox actif.'},
    {cap: 'Visioconférence WebRTC', status: 'Dépendant du moteur', note: 'Soumis aux permissions caméra/micro par origine.'},
    {cap: 'Extensions Chrome / WebExtensions', status: 'Non pris en charge', note: 'Aucune compatibilité revendiquée sans API dédiée.'},
    {cap: 'Streaming DRM Widevine', status: 'Non pris en charge', note: 'Modules CDM propriétaires non redistribués.'},
    {cap: 'Gestionnaire de mots de passe', status: 'Différé', note: 'Exclu de la version 0.1.0.'},
  ];

  readonly currentRouteHost = computed(() => {
    const url = this.activeTab()?.url ?? 'verriere://newtab';
    if (url.startsWith('verriere://')) {
      return url.replace('verriere://', '').split('/')[0].split('?')[0];
    }
    return 'external';
  });

  readonly greetingName = computed(() => this.userNameControl.value.trim() || 'Camille');

  selectTab(tabId: string): void {
    this.activeTabId.set(tabId);
    const tab = this.tabs().find((t) => t.id === tabId);
    if (tab) {
      this.addressControl.setValue(tab.url === 'verriere://newtab' ? '' : tab.url);
    }
    this.openBookmarkFolderId.set(null);
  }

  createNewTab(url = 'verriere://newtab', title = 'Nouvel onglet'): void {
    const id = `tab-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const next: BrowserTab = {
      id,
      title,
      url,
      workspaceId: this.activeWorkspaceId(),
      icon: url.startsWith('verriere://') ? 'home' : 'public',
    };
    this.tabs.update((list) => [...list, next]);
    this.selectTab(id);
  }

  closeTab(tabId: string, event: Event): void {
    event.stopPropagation();
    const list = this.tabs();
    if (list.length <= 1) {
      this.navigateTo('verriere://newtab', 'Nouvel onglet');
      return;
    }
    const idx = list.findIndex((t) => t.id === tabId);
    const updated = list.filter((t) => t.id !== tabId);
    this.tabs.set(updated);
    if (this.activeTabId() === tabId) {
      const next = updated[Math.min(idx, updated.length - 1)];
      this.selectTab(next.id);
    }
  }

  navigateTo(rawInput: string, explicitTitle?: string): void {
    this.statusNotice.set(null);
    this.openBookmarkFolderId.set(null);
    const parsed = this.parseAddress(rawInput);

    if (parsed.kind === 'blocked' || parsed.kind === 'unsupported') {
      this.statusNotice.set(parsed.message);
      return;
    }

    const title =
      explicitTitle ??
      (parsed.destination === 'verriere://newtab'
        ? 'Nouvel onglet'
        : parsed.destination === 'verriere://bookmarks'
          ? 'Favoris'
          : parsed.destination === 'verriere://history'
            ? 'Historique'
            : parsed.destination === 'verriere://downloads'
              ? 'Téléchargements'
              : parsed.destination === 'verriere://settings'
                ? 'Réglages'
                : parsed.destination === 'verriere://architecture'
                  ? 'Architecture & Tests'
                  : parsed.destination === 'verriere://article/architecture-contemporaine'
                    ? 'Construire la ville de demain'
                    : parsed.destination);

    const activeId = this.activeTabId();
    this.tabs.update((list) =>
      list.map((t) => (t.id === activeId ? {...t, url: parsed.destination, title} : t)),
    );
    this.addressControl.setValue(parsed.destination === 'verriere://newtab' ? '' : parsed.destination);

    if (!this.isPrivate() && parsed.destination !== 'verriere://newtab') {
      this.historyEntries.update((entries) => [
        {
          id: `h-${Date.now()}`,
          title,
          url: parsed.destination,
          visitedAt: 'À l’instant',
        },
        ...entries.slice(0, 19),
      ]);
    }
  }

  onAddressSubmit(event: Event): void {
    event.preventDefault();
    const val = this.addressControl.value.trim();
    if (val) {
      this.navigateTo(val);
    }
  }

  onNewtabSearchSubmit(event: Event): void {
    event.preventDefault();
    const q = this.newtabSearchControl.value.trim();
    if (!q) {
      return;
    }
    this.navigateTo(q);
    this.newtabSearchControl.setValue('');
  }

  parseAddress(raw: string): ParsedBarResult {
    const text = raw.trim();
    const lower = text.toLowerCase();
    for (const bad of ['javascript:', 'vbscript:', 'shell:', 'cmd:', 'data:']) {
      if (lower.startsWith(bad)) {
        return {
          kind: 'blocked',
          destination: '',
          message: `Le schéma « ${bad} » est bloqué par mesure de sécurité dans Verrière.`,
        };
      }
    }
    if (lower.startsWith('mailto:') || lower.startsWith('tel:')) {
      return {
        kind: 'unsupported',
        destination: '',
        message: `Le schéma « ${lower.split(':')[0]}: » n'est pas pris en charge directement et ne lance aucune commande locale.`,
      };
    }
    if (lower.startsWith('verriere://')) {
      return {kind: 'internal', destination: text, message: ''};
    }
    if (lower.startsWith('http://') || lower.startsWith('https://')) {
      return {kind: 'url', destination: text, message: ''};
    }
    if (!text.includes(' ') && text.includes('.')) {
      return {kind: 'url', destination: `https://${text}`, message: ''};
    }

    const engine = this.defaultSearchEngine();
    const encoded = encodeURIComponent(text);
    const url =
      engine === 'duckduckgo'
        ? `https://duckduckgo.com/?q=${encoded}&kl=fr-fr`
        : engine === 'startpage'
          ? `https://www.startpage.com/do/search?q=${encoded}`
          : engine === 'eclair' && this.eclairControl.value.includes('{query}')
            ? this.eclairControl.value.replace('{query}', encoded)
            : `https://www.qwant.com/?q=${encoded}&l=fr`;

    return {kind: 'search', destination: url, message: ''};
  }

  toggleBookmarkFolder(folderId: string): void {
    this.openBookmarkFolderId.update((cur) => (cur === folderId ? null : folderId));
  }

  switchWorkspace(wsId: string): void {
    this.activeWorkspaceId.set(wsId);
  }

  switchProfile(profile: 'Camille' | 'Travail' | 'Navigation privée'): void {
    this.activeProfile.set(profile);
    this.showProfileMenu.set(false);
    if (profile !== 'Navigation privée') {
      this.userNameControl.setValue(profile);
    }
    this.statusNotice.set(
      profile === 'Navigation privée'
        ? 'Session privée activée : aucune visite n’est ajoutée à l’historique local. Attention : la navigation privée ne masque pas votre trafic aux sites ou à votre FAI.'
        : `Profil actif : ${profile} (cookies, stockage et historique SQLite isolés).`,
    );
  }

  addShortcut(event: Event): void {
    event.preventDefault();
    const title = this.shortcutTitleControl.value.trim();
    const url = this.shortcutUrlControl.value.trim();
    if (!title || !url) {
      return;
    }
    const parsed = this.parseAddress(url);
    if (parsed.kind === 'blocked' || parsed.kind === 'unsupported') {
      this.statusNotice.set(parsed.message);
      return;
    }
    this.shortcuts.update((list) => [
      ...list,
      {id: `sc-${Date.now()}`, title, url: parsed.destination || url, icon: 'language'},
    ]);
    this.shortcutTitleControl.setValue('');
    this.shortcutUrlControl.setValue('');
    this.showShortcutModal.set(false);
  }

  removeShortcut(id: string, event: Event): void {
    event.stopPropagation();
    this.shortcuts.update((list) => list.filter((s) => s.id !== id));
  }

  clearBrowsingHistory(): void {
    this.historyEntries.set([]);
    this.showClearDataModal.set(false);
    this.statusNotice.set(
      'Historique local effacé. Les cookies et le stockage des sites ne sont modifiés que si vous cochez les options correspondantes dans le client PySide6.',
    );
  }

  setSearchEngine(engine: 'qwant' | 'duckduckgo' | 'startpage' | 'eclair'): void {
    this.defaultSearchEngine.set(engine);
  }
}
