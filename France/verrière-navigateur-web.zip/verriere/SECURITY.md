# Politique de sécurité — VERRIÈRE

## Signalement d'une vulnérabilité

- **Application Verrière** (chrome Qt, schéma `verriere://`, parseur d'URL, gestionnaire de téléchargements, stockage SQLite) : ouvrez un ticket privé ou écrivez à l'équipe de maintenance (`securite@verriere.example`) avec les étapes de reproduction, la version de Verrière et la version de Qt WebEngine affichées dans `verriere://settings`.
- **Moteur Chromium / Qt WebEngine** : les vulnérabilités du moteur de rendu, du réseau ou de V8 relèvent des avis de sécurité Qt Project / Chromium et sont traitées par mise à jour du paquet `PySide6` / Qt WebEngine.

## Garanties de sécurité intégrées

1. **Isolation moteur (Sandbox)** : Verrière ne désactive jamais le bac à sable Qt WebEngine.
2. **Séparation chrome / contenu Web** : le chrome du navigateur est entièrement rendu en widgets natifs Qt. Les pages internes `verriere://*` utilisent un jeton cryptographique de session vérifié côté Python et refusent tout appel issu d'une origine externe (`http://`, `https://`, `file://`).
3. **Gestion stricte des schémas et certificats** : `javascript:`, `vbscript:`, `shell:` et les schémas externes non pris en charge ne peuvent ni s'exécuter ni lancer de commande locale. Les erreurs de certificat TLS sont bloquées sans contournement automatique.
4. **Données privées** : les fenêtres privées s'appuient sur `QWebEngineProfile` en mode `off-the-record` et n'écrivent aucun onglet, historique ni permission persistante sur disque.
