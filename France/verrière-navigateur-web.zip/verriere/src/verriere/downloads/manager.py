"""Gestionnaire de téléchargements sécurisé pour Verrière."""

from __future__ import annotations

import os
import re
import shutil
import uuid
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from verriere.application.locale_fr import utc_now_iso
from verriere.application.storage import ProfileDatabase

_INVALID_CHARS_RE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


class DownloadState(str, Enum):
    IN_PROGRESS = "in_progress"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    INTERRUPTED = "interrupted"
    FAILED = "failed"


STATE_LABELS_FR = {
    DownloadState.IN_PROGRESS: "En cours",
    DownloadState.PAUSED: "En pause",
    DownloadState.COMPLETED: "Terminé",
    DownloadState.CANCELLED: "Annulé",
    DownloadState.INTERRUPTED: "Interrompu",
    DownloadState.FAILED: "Échec",
}

DOWNLOAD_SAFETY_NOTICE = (
    "Un téléchargement terminé garantit uniquement que le transfert s'est achevé ; "
    "il ne prouve pas que le fichier est sûr. Verrière n'exécute jamais automatiquement "
    "les fichiers téléchargés."
)


@dataclass
class DownloadRecord:
    id: str
    filename: str
    source_url: str
    destination_path: str
    total_bytes: int
    received_bytes: int
    state: DownloadState
    error_message: str = ""
    created_at: str = ""
    updated_at: str = ""


def sanitize_filename(raw_name: str, fallback: str = "telechargement") -> str:
    """Nettoie un nom de fichier distant pour empêcher toute traversée de répertoire."""
    base = os.path.basename(raw_name.replace("\\", "/")).strip()
    base = _INVALID_CHARS_RE.sub("_", base).strip(". ")
    if not base or base in (".", ".."):
        return fallback
    return base[:180]


def resolve_safe_destination(download_dir: Path, raw_filename: str) -> Path:
    """Résout un chemin strictement confiné dans ``download_dir`` sans collision."""
    base_dir = download_dir.resolve()
    base_dir.mkdir(parents=True, exist_ok=True)
    clean_name = sanitize_filename(raw_filename)

    stem = Path(clean_name).stem or "fichier"
    suffix = Path(clean_name).suffix
    candidate = (base_dir / clean_name).resolve()

    if not str(candidate).startswith(str(base_dir) + os.sep):
        raise ValueError("Chemin de destination refusé hors du dossier de téléchargements.")

    counter = 1
    while candidate.exists():
        numbered = f"{stem} ({counter}){suffix}"
        candidate = (base_dir / numbered).resolve()
        if not str(candidate).startswith(str(base_dir) + os.sep):
            raise ValueError("Chemin de destination refusé hors du dossier de téléchargements.")
        counter += 1
    return candidate


def check_disk_space(target_dir: Path, required_bytes: int) -> tuple[bool, str]:
    """Vérifie l'espace disque disponible avant d'accepter un téléchargement."""
    if required_bytes <= 0:
        return True, ""
    target_dir.mkdir(parents=True, exist_ok=True)
    usage = shutil.disk_usage(target_dir)
    if usage.free < required_bytes:
        return (
            False,
            f"Espace disque insuffisant ({usage.free} octets libres pour {required_bytes} requis).",
        )
    return True, ""


class DownloadManager:
    """Suivi des téléchargements (en mémoire pour sessions privées, SQLite pour profils normaux)."""

    def __init__(
        self,
        download_dir: Path,
        db: ProfileDatabase | None = None,
        is_private: bool = False,
    ) -> None:
        self.download_dir = Path(download_dir)
        self.download_dir.mkdir(parents=True, exist_ok=True)
        self._db = None if is_private else db
        self._is_private = is_private
        self._records: dict[str, DownloadRecord] = {}
        self._qt_requests: dict[str, Any] = {}
        if self._db is not None:
            self._load_existing()

    def _load_existing(self) -> None:
        assert self._db is not None
        rows = self._db.connection.execute(
            "SELECT id, filename, source_url, destination_path, total_bytes, received_bytes, "
            "state, error_message, created_at, updated_at FROM downloads ORDER BY created_at DESC"
        ).fetchall()
        for row in rows:
            state = DownloadState(row["state"])
            # Un téléchargement resté en cours lors d'une fermeture brutale est marqué interrompu
            if state in (DownloadState.IN_PROGRESS, DownloadState.PAUSED):
                state = DownloadState.INTERRUPTED
            self._records[row["id"]] = DownloadRecord(
                id=row["id"],
                filename=row["filename"],
                source_url=row["source_url"],
                destination_path=row["destination_path"],
                total_bytes=row["total_bytes"],
                received_bytes=row["received_bytes"],
                state=state,
                error_message=row["error_message"],
                created_at=row["created_at"],
                updated_at=row["updated_at"],
            )

    def _persist(self, rec: DownloadRecord) -> None:
        if self._is_private or self._db is None:
            return
        self._db.connection.execute(
            """
            INSERT OR REPLACE INTO downloads(
                id, filename, source_url, destination_path, total_bytes,
                received_bytes, state, error_message, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rec.id,
                rec.filename,
                rec.source_url,
                rec.destination_path,
                rec.total_bytes,
                rec.received_bytes,
                rec.state.value,
                rec.error_message,
                rec.created_at,
                rec.updated_at,
            ),
        )
        self._db.connection.commit()

    def list_downloads(self) -> list[DownloadRecord]:
        return sorted(self._records.values(), key=lambda r: r.created_at, reverse=True)

    def register_local_download(
        self,
        filename: str,
        source_url: str,
        total_bytes: int = -1,
    ) -> DownloadRecord:
        """Enregistre un téléchargement et prépare un chemin de destination sûr."""
        dest = resolve_safe_destination(self.download_dir, filename)
        ok, space_err = check_disk_space(self.download_dir, total_bytes)
        now = utc_now_iso()
        dl_id = f"dl-{uuid.uuid4().hex[:10]}"
        if not ok:
            rec = DownloadRecord(
                id=dl_id,
                filename=dest.name,
                source_url=source_url,
                destination_path=str(dest),
                total_bytes=total_bytes,
                received_bytes=0,
                state=DownloadState.FAILED,
                error_message=space_err,
                created_at=now,
                updated_at=now,
            )
            self._records[dl_id] = rec
            self._persist(rec)
            return rec

        rec = DownloadRecord(
            id=dl_id,
            filename=dest.name,
            source_url=source_url,
            destination_path=str(dest),
            total_bytes=total_bytes,
            received_bytes=0,
            state=DownloadState.IN_PROGRESS,
            created_at=now,
            updated_at=now,
        )
        self._records[dl_id] = rec
        self._persist(rec)
        return rec

    def handle_qt_download(self, request: Any, on_change: Any = None) -> DownloadRecord:
        """Connecte un QWebEngineDownloadRequest en validant le chemin et la taille."""
        suggested = request.downloadFileName() or "telechargement"
        total = int(request.totalBytes())
        source_url = request.url().toString()
        rec = self.register_local_download(suggested, source_url, total_bytes=total)

        if rec.state == DownloadState.FAILED:
            request.cancel()
            if on_change:
                on_change(rec)
            return rec

        dest_path = Path(rec.destination_path)
        request.setDownloadDirectory(str(dest_path.parent))
        request.setDownloadFileName(dest_path.name)
        self._qt_requests[rec.id] = request

        def _sync_progress() -> None:
            rec.received_bytes = int(request.receivedBytes())
            rec.total_bytes = int(request.totalBytes())
            rec.updated_at = utc_now_iso()
            self._persist(rec)
            if on_change:
                on_change(rec)

        def _sync_state() -> None:
            from PySide6.QtWebEngineCore import QWebEngineDownloadRequest

            st = request.state()
            if st == QWebEngineDownloadRequest.DownloadState.DownloadCompleted:
                rec.state = DownloadState.COMPLETED
                rec.received_bytes = max(rec.received_bytes, int(request.receivedBytes()))
            elif st == QWebEngineDownloadRequest.DownloadState.DownloadCancelled:
                rec.state = DownloadState.CANCELLED
            elif st == QWebEngineDownloadRequest.DownloadState.DownloadInterrupted:
                rec.state = DownloadState.INTERRUPTED
                rec.error_message = request.interruptReasonString() or "Transfert interrompu."
            elif request.isPaused():
                rec.state = DownloadState.PAUSED
            else:
                rec.state = DownloadState.IN_PROGRESS
            rec.updated_at = utc_now_iso()
            self._persist(rec)
            if on_change:
                on_change(rec)

        request.receivedBytesChanged.connect(_sync_progress)
        request.totalBytesChanged.connect(_sync_progress)
        request.stateChanged.connect(_sync_state)
        if hasattr(request, "isPausedChanged"):
            request.isPausedChanged.connect(_sync_state)
        request.accept()
        if on_change:
            on_change(rec)
        return rec

    def pause(self, download_id: str) -> bool:
        req = self._qt_requests.get(download_id)
        rec = self._records.get(download_id)
        if req is not None and rec is not None and hasattr(req, "pause"):
            req.pause()
            rec.state = DownloadState.PAUSED
            rec.updated_at = utc_now_iso()
            self._persist(rec)
            return True
        return False

    def resume(self, download_id: str) -> bool:
        req = self._qt_requests.get(download_id)
        rec = self._records.get(download_id)
        if req is not None and rec is not None and hasattr(req, "resume"):
            req.resume()
            rec.state = DownloadState.IN_PROGRESS
            rec.updated_at = utc_now_iso()
            self._persist(rec)
            return True
        return False

    def cancel(self, download_id: str) -> bool:
        req = self._qt_requests.get(download_id)
        rec = self._records.get(download_id)
        if rec is None:
            return False
        if req is not None:
            req.cancel()
        rec.state = DownloadState.CANCELLED
        rec.updated_at = utc_now_iso()
        self._persist(rec)
        return True

    def mark_completed(self, download_id: str, total_bytes: int) -> None:
        rec = self._records.get(download_id)
        if rec is None:
            return
        rec.total_bytes = total_bytes
        rec.received_bytes = total_bytes
        rec.state = DownloadState.COMPLETED
        rec.updated_at = utc_now_iso()
        self._persist(rec)

    def mark_failed(self, download_id: str, error_message: str) -> None:
        rec = self._records.get(download_id)
        if rec is None:
            return
        rec.state = DownloadState.FAILED
        rec.error_message = error_message
        rec.updated_at = utc_now_iso()
        self._persist(rec)

    def clear_completed(self) -> None:
        to_delete = [
            dl_id
            for dl_id, rec in self._records.items()
            if rec.state in (DownloadState.COMPLETED, DownloadState.CANCELLED, DownloadState.FAILED)
        ]
        for dl_id in to_delete:
            self._records.pop(dl_id, None)
            if self._db is not None:
                self._db.connection.execute("DELETE FROM downloads WHERE id = ?", (dl_id,))
        if self._db is not None:
            self._db.connection.commit()

    def parent_folder(self, download_id: str) -> Path | None:
        rec = self._records.get(download_id)
        if rec is None:
            return None
        return Path(rec.destination_path).parent
