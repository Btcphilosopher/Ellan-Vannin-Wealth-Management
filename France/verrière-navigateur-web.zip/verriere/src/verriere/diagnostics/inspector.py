"""Diagnostics moteur, versions et matrice honnête de compatibilité."""

from __future__ import annotations

import os
import platform
import sys
from dataclasses import dataclass

from verriere import __app_name__, __version__


@dataclass(frozen=True)
class CompatibilityRow:
    capability: str
    status: str  # "Pris en charge" | "Dépendant du moteur" | "Non pris en charge" | "Différé"
    detail: str


COMPATIBILITY_MATRIX: tuple[CompatibilityRow, ...] = (
    CompatibilityRow(
        "Lecture multimédia (HTML5 Audio/Vidéo)",
        "Dépendant du moteur",
        "Codecs libres intégrés à Qt WebEngine (VP8/VP9/Opus/Vorbis). Les codecs propriétaires H.264/AAC dépendent des options de compilation Qt.",
    ),
    CompatibilityRow(
        "Visioconférence WebRTC",
        "Dépendant du moteur",
        "Pris en charge par Chromium/Qt WebEngine sous réserve des permissions caméra/micro par origine et du pilote audio/vidéo système.",
    ),
    CompatibilityRow(
        "Visionneuse PDF intégrée",
        "Pris en charge",
        "Activée via QWebEngineSettings.PdfViewerEnabled dans Qt WebEngine.",
    ),
    CompatibilityRow(
        "Impression",
        "Pris en charge",
        "Export PDF et impression système via QWebEnginePage.printToPdf / QPrinter.",
    ),
    CompatibilityRow(
        "Fenêtres contextuelles (pop-ups)",
        "Pris en charge",
        "Ouvertes sous contrôle de Verrière dans un nouvel onglet via createWindow.",
    ),
    CompatibilityRow(
        "Envoi de fichiers (file upload)",
        "Pris en charge",
        "Sélecteur de fichiers natif Qt déclenché uniquement sur action utilisateur dans la page.",
    ),
    CompatibilityRow(
        "Accessibilité",
        "Pris en charge",
        "Libellés accessibles Qt, raccourcis clavier, zoom texte, mode contraste élevé et réduction des animations.",
    ),
    CompatibilityRow(
        "Gestionnaire de mots de passe",
        "Différé",
        "Volontairement exclu de la version 0.1 tant qu'une intégration auditée avec trousseau système n'est pas finalisée.",
    ),
    CompatibilityRow(
        "Extensions Chrome / WebExtensions",
        "Non pris en charge",
        "Qt WebEngine n'offre pas d'API WebExtensions compatible Chrome ; aucune compatibilité n'est revendiquée.",
    ),
    CompatibilityRow(
        "Streaming DRM commercial (Widevine)",
        "Non pris en charge",
        "Les modules CDM propriétaires Widevine ne sont ni redistribués ni activés dans le paquet standard.",
    ),
)


def collect_diagnostics() -> dict[str, str]:
    qt_ver = "Indisponible"
    pyside_ver = "Indisponible"
    chromium_ver = "Indisponible"
    try:
        import PySide6
        from PySide6.QtCore import qVersion
        from PySide6.QtWebEngineCore import qWebEngineChromiumVersion

        pyside_ver = PySide6.__version__
        qt_ver = qVersion()
        chromium_ver = qWebEngineChromiumVersion()
    except Exception:
        pass

    sandbox_disabled = os.environ.get("QTWEBENGINE_DISABLE_SANDBOX") == "1" or (
        "--no-sandbox" in os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "")
    )
    return {
        "application": f"{__app_name__} {__version__}",
        "python": platform.python_version(),
        "system": f"{platform.system()} {platform.release()} ({platform.machine()})",
        "pyside6": pyside_ver,
        "qt": qt_ver,
        "chromium": chromium_ver,
        "sandbox_status": "Désactivé via l'environnement (déconseillé)"
        if sandbox_disabled
        else "Actif (isolation moteur conservée)",
        "executable": sys.executable,
    }
