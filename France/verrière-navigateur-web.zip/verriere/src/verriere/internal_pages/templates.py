"""Générateurs HTML sécurisés pour les pages internes verriere://*."""

from __future__ import annotations

import html
from typing import Any

from verriere.application.locale_fr import (
    format_bytes_fr,
    format_datetime_fr,
    format_number_fr,
    format_percent_fr,
)
from verriere.bookmarks.manager import Bookmark, BookmarkFolder
from verriere.diagnostics.inspector import COMPATIBILITY_MATRIX, collect_diagnostics
from verriere.downloads.manager import DOWNLOAD_SAFETY_NOTICE, STATE_LABELS_FR, DownloadRecord
from verriere.history.manager import HistoryEntry
from verriere.permissions.manager import PERMISSION_LABELS_FR, OriginPermission
from verriere.search.providers import SearchProvider
from verriere.workspaces.manager import WORKSPACE_ISOLATION_NOTICE, Workspace

_SHORTCUT_ICONS = {
    "mail": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>',
    "calendar": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M8 2v4M16 2v4M3 10h18"/></svg>',
    "news": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h6v5H7zM15 8h2M15 12h2M7 16h10"/></svg>',
    "culture": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 9l9-5 9 5M5 9v9M9.5 9v9M14.5 9v9M19 9v9M3 20h18"/></svg>',
    "search": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
    "globe": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>',
    "plus": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 5v14M5 12h14"/></svg>',
}

_WORKSPACE_ICONS = {
    "person": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="8" r="4"/><path d="M4 20c1.5-4 14.5-4 16 0"/></svg>',
    "search": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
    "luggage": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="4" y="7" width="16" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/></svg>',
    "layers": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><polygon points="12 3 3 8 12 13 21 8"/><polyline points="3 13 12 18 21 13"/></svg>',
}


def _esc(val: Any) -> str:
    return html.escape(str(val), quote=True)


def _base_css(settings: dict[str, Any]) -> str:
    hc = bool(settings.get("high_contrast", False))
    rm = bool(settings.get("reduced_motion", False))
    bg_color = "#FFFFFF" if hc else "#F3F5F9"
    text_color = "#000000" if hc else "#0F172A"
    muted_color = "#1E293B" if hc else "#475569"
    border_color = "#0F172A" if hc else "rgba(15, 23, 42, 0.10)"
    transition = "none" if rm else "all 180ms cubic-bezier(0.16, 1, 0.3, 1)"
    return f"""
    :root {{
      --v-bg: {bg_color};
      --v-surface: rgba(255, 255, 255, 0.88);
      --v-surface-solid: #FFFFFF;
      --v-text: {text_color};
      --v-muted: {muted_color};
      --v-border: {border_color};
      --v-sapphire: #1246B8;
      --v-sapphire-dark: #0A369D;
      --v-vermilion: #D9482B;
      --v-transition: {transition};
    }}
    * {{ box-sizing: border-box; }}
    html, body {{
      margin: 0;
      padding: 0;
      min-height: 100%;
      font-family: "Plus Jakarta Sans", "DejaVu Sans", "Segoe UI", system-ui, sans-serif;
      color: var(--v-text);
      background: var(--v-bg);
      -webkit-font-smoothing: antialiased;
    }}
    a {{ color: var(--v-sapphire); text-decoration: none; }}
    a:hover {{ text-decoration: underline; }}
    button, input, select {{
      font-family: inherit;
      transition: var(--v-transition);
    }}
    button:focus-visible, input:focus-visible, select:focus-visible, a:focus-visible {{
      outline: 2px solid var(--v-sapphire);
      outline-offset: 2px;
    }}
    .serif {{
      font-family: "Cormorant Garamond", "Georgia", "Liberation Serif", serif;
    }}
    .page-shell {{
      max-width: 1040px;
      margin: 0 auto;
      padding: 36px 32px 64px;
    }}
    .kicker {{
      display: inline-flex;
      align-items: center;
      gap: 12px;
      font-size: 11px;
      letter-spacing: 0.18em;
      text-transform: uppercase;
      color: var(--v-muted);
      font-weight: 600;
    }}
    .kicker-dash {{
      width: 24px;
      height: 2px;
      background: var(--v-vermilion);
      display: inline-block;
    }}
    .card {{
      background: var(--v-surface-solid);
      border: 1px solid var(--v-border);
      border-radius: 16px;
      padding: 20px 24px;
      box-shadow: 0 4px 20px rgba(15, 23, 42, 0.04);
    }}
    .btn {{
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      border-radius: 10px;
      padding: 8px 15px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      border: 1px solid var(--v-border);
      background: #FFFFFF;
      color: var(--v-text);
    }}
    .btn:hover {{ background: #F1F5F9; }}
    .btn-primary {{
      background: linear-gradient(135deg, var(--v-sapphire-dark), var(--v-sapphire));
      color: #FFFFFF;
      border-color: transparent;
    }}
    .btn-primary:hover {{ filter: brightness(1.06); }}
    .btn-danger {{
      color: #B91C1C;
      border-color: rgba(185, 28, 28, 0.25);
      background: #FEF2F2;
    }}
    .btn-danger:hover {{ background: #FEE2E2; }}
    .input {{
      width: 100%;
      padding: 9px 13px;
      border-radius: 10px;
      border: 1px solid var(--v-border);
      background: #FFFFFF;
      color: var(--v-text);
      font-size: 13.5px;
    }}
    .notice {{
      background: #EFF6FF;
      border: 1px solid rgba(29, 78, 216, 0.22);
      border-radius: 12px;
      padding: 12px 16px;
      font-size: 13px;
      line-height: 1.5;
      color: #1E3A8A;
    }}
    .notice-warn {{
      background: #FFF7ED;
      border: 1px solid rgba(217, 72, 43, 0.28);
      color: #7C2D12;
    }}
    """


def render_newtab_page(
    *,
    nonce: str,
    settings: dict[str, Any],
    shortcuts: list[dict[str, str]],
    workspaces: list[Workspace],
    active_workspace_id: str,
    reading_items: list[dict[str, str]],
    default_provider: SearchProvider,
    is_private: bool = False,
) -> str:
    user_name = _esc(settings.get("user_name", "Camille"))
    raw_template = str(settings.get("greeting_template", "Bonjour, {name}."))
    greeting = _esc(raw_template.replace("{name}", str(settings.get("user_name", "Camille"))))
    subtitle = _esc(settings.get("subtitle", "Une nouvelle perspective sur le Web."))
    show_bg = bool(settings.get("show_newtab_background", True)) and not bool(
        settings.get("high_contrast", False)
    )

    bg_css = (
        'background-image: url("verriere://resources/images/pavillon-verriere.svg"); '
        "background-size: cover; background-position: center bottom;"
        if show_bg
        else "background: var(--v-bg);"
    )

    shortcut_cards = []
    for idx, sc in enumerate(shortcuts[:8]):
        icon_svg = _SHORTCUT_ICONS.get(sc.get("icon", "globe"), _SHORTCUT_ICONS["globe"])
        sc_id = _esc(sc["id"])
        sc_title = _esc(sc["title"])
        sc_url = _esc(sc["url"])
        shortcut_cards.append(
            f"""
            <div class="shortcut-wrap">
              <a class="shortcut-tile" href="{sc_url}" title="{sc_title} — {sc_url}">
                <span class="shortcut-icon">{icon_svg}</span>
                <span class="shortcut-label">{sc_title}</span>
              </a>
              <form method="GET" action="verriere://action" class="shortcut-del-form">
                <input type="hidden" name="op" value="delete_shortcut" />
                <input type="hidden" name="nonce" value="{_esc(nonce)}" />
                <input type="hidden" name="id" value="{sc_id}" />
                <button type="submit" class="shortcut-del" title="Supprimer {sc_title}" aria-label="Supprimer {sc_title}">×</button>
              </form>
            </div>
            """
        )

    ws_rows = []
    for ws in workspaces:
        is_active = ws.id == active_workspace_id
        icon_svg = _WORKSPACE_ICONS.get(ws.icon, _WORKSPACE_ICONS["layers"])
        active_cls = "ws-item active" if is_active else "ws-item"
        ws_rows.append(
            f"""
            <a class="{active_cls}" href="verriere://action?op=switch_workspace&id={_esc(ws.id)}&nonce={_esc(nonce)}">
              <span class="ws-left">
                <span class="ws-icon">{icon_svg}</span>
                <span>{_esc(ws.name)}</span>
              </span>
              <span class="ws-chevron">›</span>
            </a>
            """
        )

    reading_html = ""
    if reading_items:
        item = reading_items[0]
        reading_html = f"""
        <div class="card-divider"></div>
        <div class="card-section-title"><span class="kicker-dash"></span> Reprendre la lecture</div>
        <a class="reading-card" href="{_esc(item['url'])}">
          <img class="reading-thumb" src="verriere://resources/images/atrium-lecture.svg" alt="{_esc(item['title'])}" />
          <div class="reading-title serif">{_esc(item['title'])}</div>
          <div class="reading-meta">Élément enregistré localement</div>
          <div class="reading-open">↗ Ouvrir</div>
        </a>
        """

    private_banner = (
        '<div class="private-pill">Fenêtre privée · Les onglets et recherches de cette fenêtre ne sont pas enregistrés localement.</div>'
        if is_private
        else ""
    )

    provider_note = (
        f"Recherche via <strong>{_esc(default_provider.name)}</strong> ({_esc(default_provider.destination_origin)})"
        if default_provider.is_configured
        else "Éclair non configuré — bascule automatique vers Qwant ou saisie d'URL directe."
    )

    return f"""<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <title>Nouvel onglet — Verrière</title>
  <style>
    {_base_css(settings)}
    body {{
      {bg_css}
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      overflow-x: hidden;
    }}
    .hero-grid {{
      width: 100%;
      max-width: 1180px;
      margin: 0 auto;
      padding: 46px 48px 40px;
      display: grid;
      grid-template-columns: minmax(0, 1fr) 292px;
      gap: 40px;
      align-items: start;
    }}
    .hero-main {{
      padding-top: 8px;
    }}
    .greeting {{
      margin: 14px 0 6px;
      font-size: clamp(44px, 5.2vw, 66px);
      font-weight: 500;
      line-height: 1.04;
      letter-spacing: -0.02em;
      color: var(--v-text);
    }}
    .subtitle {{
      margin: 0 0 30px;
      font-size: 22px;
      font-style: italic;
      color: var(--v-muted);
    }}
    .search-pill {{
      max-width: 610px;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 7px 7px 7px 18px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.90);
      border: 1px solid rgba(255, 255, 255, 0.96);
      box-shadow: 0 10px 30px rgba(15, 23, 42, 0.08), inset 0 1px 0 rgba(255,255,255,0.9);
      backdrop-filter: blur(14px);
    }}
    .search-pill svg {{
      width: 18px;
      height: 18px;
      color: #64748B;
      flex-shrink: 0;
    }}
    .search-pill input {{
      flex: 1;
      border: none;
      background: transparent;
      font-size: 15px;
      color: var(--v-text);
      outline: none;
      min-width: 0;
    }}
    .search-pill button {{
      border: none;
      border-radius: 999px;
      padding: 11px 24px;
      font-size: 14px;
      font-weight: 600;
      color: #FFFFFF;
      cursor: pointer;
      background: linear-gradient(135deg, #0A369D, #1553D1);
      box-shadow: 0 4px 14px rgba(10, 54, 157, 0.28);
    }}
    .search-pill button:hover {{ filter: brightness(1.08); }}
    .provider-caption {{
      margin-top: 10px;
      margin-left: 16px;
      font-size: 12px;
      color: var(--v-muted);
    }}
    .shortcuts-row {{
      margin-top: 28px;
      display: flex;
      flex-wrap: wrap;
      gap: 14px;
      align-items: flex-start;
    }}
    .shortcut-wrap {{
      position: relative;
    }}
    .shortcut-tile {{
      width: 92px;
      height: 92px;
      border-radius: 18px;
      background: rgba(255, 255, 255, 0.86);
      border: 1px solid rgba(255, 255, 255, 0.95);
      box-shadow: 0 6px 20px rgba(15, 23, 42, 0.06);
      backdrop-filter: blur(12px);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 9px;
      color: var(--v-text);
      text-decoration: none;
      cursor: pointer;
    }}
    .shortcut-tile:hover {{
      transform: translateY(-2px);
      background: rgba(255, 255, 255, 0.98);
      text-decoration: none;
    }}
    .shortcut-icon {{
      width: 24px;
      height: 24px;
      color: #1E293B;
      display: flex;
    }}
    .shortcut-label {{
      font-size: 12.5px;
      font-weight: 500;
      max-width: 82px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }}
    .shortcut-del-form {{
      position: absolute;
      top: 4px;
      right: 4px;
      opacity: 0;
      transition: opacity 150ms ease;
    }}
    .shortcut-wrap:hover .shortcut-del-form {{ opacity: 1; }}
    .shortcut-del {{
      width: 20px;
      height: 20px;
      border-radius: 999px;
      border: none;
      background: rgba(15, 23, 42, 0.12);
      color: #0F172A;
      font-size: 13px;
      line-height: 1;
      cursor: pointer;
    }}
    .side-glass {{
      background: rgba(249, 250, 253, 0.88);
      border: 1px solid rgba(255, 255, 255, 0.95);
      border-radius: 20px;
      padding: 18px;
      box-shadow: 0 12px 32px rgba(15, 23, 42, 0.08);
      backdrop-filter: blur(18px);
    }}
    .card-section-title {{
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 15px;
      font-weight: 600;
      margin-bottom: 12px;
      color: var(--v-text);
    }}
    .ws-list {{
      display: flex;
      flex-direction: column;
      gap: 6px;
    }}
    .ws-item {{
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 9px 12px;
      border-radius: 10px;
      color: var(--v-text);
      font-size: 13.5px;
      font-weight: 500;
      border: 1px solid transparent;
    }}
    .ws-item:hover {{
      background: rgba(15, 23, 42, 0.04);
      text-decoration: none;
    }}
    .ws-item.active {{
      background: rgba(18, 70, 184, 0.09);
      border-color: rgba(18, 70, 184, 0.55);
      color: var(--v-sapphire-dark);
      font-weight: 600;
    }}
    .ws-left {{
      display: flex;
      align-items: center;
      gap: 10px;
    }}
    .ws-icon {{
      width: 17px;
      height: 17px;
      display: flex;
    }}
    .ws-chevron {{
      color: #64748B;
      font-size: 16px;
    }}
    .card-divider {{
      height: 1px;
      background: rgba(15, 23, 42, 0.08);
      margin: 16px 0;
    }}
    .reading-card {{
      display: block;
      color: var(--v-text);
    }}
    .reading-card:hover {{ text-decoration: none; }}
    .reading-thumb {{
      width: 100%;
      height: 112px;
      object-fit: cover;
      border-radius: 12px;
      margin-bottom: 10px;
      border: 1px solid rgba(15, 23, 42, 0.08);
    }}
    .reading-title {{
      font-size: 18px;
      font-weight: 600;
      line-height: 1.25;
      margin-bottom: 4px;
    }}
    .reading-meta {{
      font-size: 11.5px;
      color: var(--v-muted);
      margin-bottom: 6px;
    }}
    .reading-open {{
      font-size: 13px;
      font-weight: 600;
      color: var(--v-sapphire);
    }}
    .private-pill {{
      display: inline-block;
      margin-bottom: 16px;
      padding: 8px 14px;
      border-radius: 10px;
      background: #1E293B;
      color: #F8FAFC;
      font-size: 12.5px;
    }}
    .modal-backdrop {{
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(15, 23, 42, 0.35);
      align-items: center;
      justify-content: center;
      padding: 20px;
      z-index: 40;
    }}
    .modal-backdrop.open {{ display: flex; }}
    .modal-box {{
      width: 100%;
      max-width: 420px;
      background: #FFFFFF;
      border-radius: 16px;
      padding: 22px;
      box-shadow: 0 20px 50px rgba(15, 23, 42, 0.20);
    }}
    .footer-note {{
      padding: 10px 28px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
      color: var(--v-muted);
      background: rgba(244, 246, 250, 0.72);
      backdrop-filter: blur(8px);
      border-top: 1px solid rgba(15, 23, 42, 0.06);
    }}
  </style>
</head>
<body>
  <main class="hero-grid">
    <section class="hero-main">
      {private_banner}
      <div class="kicker"><span class="kicker-dash"></span> Votre espace, ouvert sur le monde</div>
      <h1 class="greeting serif">{greeting}</h1>
      <p class="subtitle serif">{subtitle}</p>

      <form class="search-pill" method="GET" action="verriere://action">
        <input type="hidden" name="op" value="search" />
        <input type="hidden" name="nonce" value="{_esc(nonce)}" />
        {_SHORTCUT_ICONS["search"]}
        <input
          id="newtab-search-input"
          name="q"
          type="search"
          placeholder="Que souhaitez-vous découvrir ?"
          aria-label="Que souhaitez-vous découvrir ?"
          autofocus
        />
        <button type="submit">Rechercher</button>
      </form>
      <div class="provider-caption">{provider_note}</div>

      <div class="shortcuts-row" aria-label="Raccourcis configurables">
        {"".join(shortcut_cards)}
        <div class="shortcut-wrap">
          <button
            type="button"
            class="shortcut-tile"
            onclick="document.getElementById('add-shortcut-modal').classList.add('open')"
          >
            <span class="shortcut-icon">{_SHORTCUT_ICONS["plus"]}</span>
            <span class="shortcut-label">Ajouter</span>
          </button>
        </div>
      </div>
    </section>

    <aside class="side-glass" aria-label="Panneau Mes espaces et lecture">
      <div class="card-section-title"><span class="kicker-dash"></span> Mes espaces</div>
      <div class="ws-list">
        {"".join(ws_rows)}
      </div>
      {reading_html}
    </aside>
  </main>

  <div id="add-shortcut-modal" class="modal-backdrop" role="dialog" aria-modal="true" aria-label="Ajouter un raccourci">
    <div class="modal-box">
      <h2 style="margin:0 0 12px; font-size:18px;">Ajouter un raccourci</h2>
      <form method="GET" action="verriere://action" style="display:flex; flex-direction:column; gap:10px;">
        <input type="hidden" name="op" value="add_shortcut" />
        <input type="hidden" name="nonce" value="{_esc(nonce)}" />
        <label style="font-size:13px; font-weight:600;">Nom
          <input class="input" name="title" required placeholder="Ex. Bibliothèque nationale" />
        </label>
        <label style="font-size:13px; font-weight:600;">Adresse Web
          <input class="input" name="url" required placeholder="https://www.bnf.fr" />
        </label>
        <label style="font-size:13px; font-weight:600;">Icône
          <select class="input" name="icon">
            <option value="globe">Globe</option>
            <option value="mail">Courrier</option>
            <option value="calendar">Agenda</option>
            <option value="news">Actualités</option>
            <option value="culture">Culture</option>
            <option value="search">Recherche</option>
          </select>
        </label>
        <div style="display:flex; justify-content:flex-end; gap:8px; margin-top:6px;">
          <button type="button" class="btn" onclick="document.getElementById('add-shortcut-modal').classList.remove('open')">Annuler</button>
          <button type="submit" class="btn btn-primary">Enregistrer</button>
        </div>
      </form>
    </div>
  </div>

  <footer class="footer-note">
    <span><em class="serif" style="font-size:14px; color:#0F172A;">Verrière</em> · Navigateur Web</span>
    <span>Français · Profil {user_name}</span>
  </footer>
</body>
</html>"""


def render_bookmarks_page(
    *,
    nonce: str,
    settings: dict[str, Any],
    folders: list[BookmarkFolder],
    bookmarks: list[Bookmark],
    query: str = "",
) -> str:
    folder_names = {f.id: f.name for f in folders}
    folder_options = "".join(
        f'<option value="{_esc(f.id)}">{_esc(f.name)}</option>' for f in folders
    )
    rows = []
    for bm in bookmarks:
        fname = folder_names.get(bm.folder_id or "", "Sans dossier")
        rows.append(
            f"""
            <tr>
              <td><a href="{_esc(bm.url)}" style="font-weight:600;">{_esc(bm.title)}</a><br/>
                <span style="font-size:12px; color:var(--v-muted);">{_esc(bm.url)}</span></td>
              <td style="font-size:13px; color:var(--v-muted);">{_esc(fname)}</td>
              <td style="text-align:right;">
                <a class="btn btn-danger" href="verriere://action?op=delete_bookmark&id={_esc(bm.id)}&nonce={_esc(nonce)}">Supprimer</a>
              </td>
            </tr>
            """
        )

    table_html = (
        f"""
        <table style="width:100%; border-collapse:collapse;">
          <thead>
            <tr style="text-align:left; border-bottom:1px solid var(--v-border); font-size:12px; color:var(--v-muted);">
              <th style="padding:10px 4px;">Page</th>
              <th style="padding:10px 4px;">Dossier</th>
              <th style="padding:10px 4px; text-align:right;">Action</th>
            </tr>
          </thead>
          <tbody>{''.join(rows)}</tbody>
        </table>
        """
        if rows
        else '<p style="color:var(--v-muted); font-size:14px;">Aucun favori ne correspond à votre recherche.</p>'
    )

    return f"""<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <title>Favoris — Verrière</title>
  <style>
    {_base_css(settings)}
    td {{ padding: 12px 4px; border-bottom: 1px solid rgba(15,23,42,0.06); vertical-align: middle; }}
  </style>
</head>
<body>
  <div class="page-shell">
    <div class="kicker"><span class="kicker-dash"></span> Bibliothèque</div>
    <h1 class="serif" style="font-size:40px; margin:8px 0 18px;">Favoris</h1>

    <div class="card" style="margin-bottom:20px;">
      <form method="GET" action="verriere://bookmarks" style="display:flex; gap:10px; margin-bottom:16px;">
        <input class="input" type="search" name="q" value="{_esc(query)}" placeholder="Rechercher dans les favoris..." />
        <button class="btn btn-primary" type="submit">Filtrer</button>
      </form>
      <form method="GET" action="verriere://action" style="display:grid; grid-template-columns:1fr 1.2fr 180px auto; gap:10px;">
        <input type="hidden" name="op" value="add_bookmark" />
        <input type="hidden" name="nonce" value="{_esc(nonce)}" />
        <input class="input" name="title" required placeholder="Titre du favori" />
        <input class="input" name="url" required placeholder="https://..." />
        <select class="input" name="folder_id">{folder_options}</select>
        <button class="btn btn-primary" type="submit">Ajouter</button>
      </form>
    </div>

    <div class="card">
      {table_html}
    </div>
  </div>
</body>
</html>"""


def render_history_page(
    *,
    nonce: str,
    settings: dict[str, Any],
    entries: list[HistoryEntry],
    query: str = "",
    date_filter: str = "all",
    is_private: bool = False,
) -> str:
    if is_private:
        body = """
        <div class="notice">
          Vous êtes dans une fenêtre privée. Aucun historique n'est enregistré ni affiché ici.
        </div>
        """
    else:
        rows = []
        for entry in entries:
            rows.append(
                f"""
                <tr>
                  <td><a href="{_esc(entry.url)}" style="font-weight:600;">{_esc(entry.title)}</a><br/>
                    <span style="font-size:12px; color:var(--v-muted);">{_esc(entry.url)}</span></td>
                  <td style="font-size:12.5px; color:var(--v-muted); white-space:nowrap;">{_esc(format_datetime_fr(entry.visited_at))}</td>
                  <td style="font-size:12.5px; text-align:center;">{format_number_fr(entry.visit_count)}</td>
                  <td style="text-align:right;">
                    <a class="btn btn-danger" href="verriere://action?op=delete_history_item&id={entry.id}&nonce={_esc(nonce)}">Retirer</a>
                  </td>
                </tr>
                """
            )
        table = (
            f"""
            <table style="width:100%; border-collapse:collapse;">
              <thead>
                <tr style="text-align:left; border-bottom:1px solid var(--v-border); font-size:12px; color:var(--v-muted);">
                  <th style="padding:10px 4px;">Page visitée</th>
                  <th style="padding:10px 4px;">Dernière visite</th>
                  <th style="padding:10px 4px; text-align:center;">Visites</th>
                  <th style="padding:10px 4px; text-align:right;">Action</th>
                </tr>
              </thead>
              <tbody>{''.join(rows)}</tbody>
            </table>
            """
            if rows
            else '<p style="color:var(--v-muted);">Aucune visite enregistrée pour cette période.</p>'
        )

        body = f"""
        <div class="card" style="margin-bottom:18px;">
          <form method="GET" action="verriere://history" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
            <input class="input" style="flex:1; min-width:220px;" type="search" name="q" value="{_esc(query)}" placeholder="Rechercher dans l'historique..." />
            <select class="input" style="width:190px;" name="period">
              <option value="all" {"selected" if date_filter == "all" else ""}>Tout l'historique</option>
              <option value="today" {"selected" if date_filter == "today" else ""}>Aujourd'hui</option>
              <option value="week" {"selected" if date_filter == "week" else ""}>7 derniers jours</option>
              <option value="month" {"selected" if date_filter == "month" else ""}>30 derniers jours</option>
            </select>
            <button class="btn btn-primary" type="submit">Filtrer</button>
            <a class="btn btn-danger" href="verriere://action?op=open_clear_data&nonce={_esc(nonce)}">Effacer les données de navigation</a>
          </form>
        </div>
        <div class="notice" style="margin-bottom:18px;">
          <strong>Différence importante :</strong> supprimer l'historique retire uniquement la liste des adresses visitées de votre base locale.
          Les cookies, le cache et le stockage local des sites restent en place tant que vous ne les effacez pas explicitement depuis <em>Effacer les données de navigation</em>.
        </div>
        <div class="card">{table}</div>
        """

    return f"""<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <title>Historique — Verrière</title>
  <style>
    {_base_css(settings)}
    td {{ padding: 12px 4px; border-bottom: 1px solid rgba(15,23,42,0.06); vertical-align: middle; }}
  </style>
</head>
<body>
  <div class="page-shell">
    <div class="kicker"><span class="kicker-dash"></span> Activité locale</div>
    <h1 class="serif" style="font-size:40px; margin:8px 0 18px;">Historique</h1>
    {body}
  </div>
</body>
</html>"""


def render_downloads_page(
    *,
    nonce: str,
    settings: dict[str, Any],
    downloads: list[DownloadRecord],
) -> str:
    rows = []
    for dl in downloads:
        state_lbl = STATE_LABELS_FR.get(dl.state, dl.state.value)
        total_txt = format_bytes_fr(dl.total_bytes) if dl.total_bytes >= 0 else "Taille inconnue"
        recv_txt = format_bytes_fr(dl.received_bytes)
        pct = (
            format_percent_fr((dl.received_bytes / dl.total_bytes) * 100.0)
            if dl.total_bytes > 0
            else "—"
        )
        err_html = (
            f'<div style="color:#B91C1C; font-size:12px; margin-top:4px;">{_esc(dl.error_message)}</div>'
            if dl.error_message
            else ""
        )
        actions = [
            f'<a class="btn" href="verriere://action?op=open_download_folder&id={_esc(dl.id)}&nonce={_esc(nonce)}">Ouvrir le dossier</a>'
        ]
        if dl.state.value == "in_progress":
            actions.append(
                f'<a class="btn" href="verriere://action?op=pause_download&id={_esc(dl.id)}&nonce={_esc(nonce)}">Pause</a>'
            )
            actions.append(
                f'<a class="btn btn-danger" href="verriere://action?op=cancel_download&id={_esc(dl.id)}&nonce={_esc(nonce)}">Annuler</a>'
            )
        elif dl.state.value == "paused":
            actions.append(
                f'<a class="btn btn-primary" href="verriere://action?op=resume_download&id={_esc(dl.id)}&nonce={_esc(nonce)}">Reprendre</a>'
            )
            actions.append(
                f'<a class="btn btn-danger" href="verriere://action?op=cancel_download&id={_esc(dl.id)}&nonce={_esc(nonce)}">Annuler</a>'
            )

        rows.append(
            f"""
            <div class="card" style="margin-bottom:12px; display:flex; justify-content:space-between; gap:16px; align-items:center;">
              <div style="min-width:0; flex:1;">
                <div style="font-weight:700; font-size:15px;">{_esc(dl.filename)}</div>
                <div style="font-size:12px; color:var(--v-muted); overflow:hidden; text-overflow:ellipsis;">Source : {_esc(dl.source_url)}</div>
                <div style="font-size:12px; color:var(--v-muted); overflow:hidden; text-overflow:ellipsis;">Destination : {_esc(dl.destination_path)}</div>
                <div style="font-size:12.5px; margin-top:6px;">
                  <strong>{_esc(state_lbl)}</strong> · {recv_txt} / {total_txt} ({pct})
                </div>
                {err_html}
              </div>
              <div style="display:flex; gap:8px; flex-shrink:0;">{"".join(actions)}</div>
            </div>
            """
        )

    content = "".join(rows) if rows else '<div class="card"><p style="margin:0; color:var(--v-muted);">Aucun téléchargement pour le moment.</p></div>'
    return f"""<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <title>Téléchargements — Verrière</title>
  <style>{_base_css(settings)}</style>
</head>
<body>
  <div class="page-shell">
    <div class="kicker"><span class="kicker-dash"></span> Transferts</div>
    <h1 class="serif" style="font-size:40px; margin:8px 0 18px;">Téléchargements</h1>
    <div class="notice notice-warn" style="margin-bottom:18px;">{_esc(DOWNLOAD_SAFETY_NOTICE)}</div>
    {content}
  </div>
</body>
</html>"""


def render_settings_page(
    *,
    nonce: str,
    settings: dict[str, Any],
    providers: list[SearchProvider],
    permissions: list[OriginPermission],
    keyring_status: tuple[bool, str],
) -> str:
    diag = collect_diagnostics()
    provider_options = "".join(
        f'<option value="{_esc(p.id)}" {"selected" if p.id == settings.get("default_search_provider_id") else ""}>'
        f'{_esc(p.name)} — {_esc(p.destination_origin)}</option>'
        for p in providers
    )
    perm_rows = "".join(
        f"""
        <tr>
          <td>{_esc(p.origin)}</td>
          <td>{_esc(PERMISSION_LABELS_FR.get(p.permission_type, p.permission_type))}</td>
          <td><strong>{"Autorisé" if p.decision.value == "allow" else "Refusé"}</strong></td>
          <td style="text-align:right;">
            <a class="btn" href="verriere://action?op=revoke_permission&origin={_esc(p.origin)}&ptype={_esc(p.permission_type)}&nonce={_esc(nonce)}">Révoquer</a>
          </td>
        </tr>
        """
        for p in permissions
    )
    compat_rows = "".join(
        f"""
        <tr>
          <td style="font-weight:600;">{_esc(row.capability)}</td>
          <td style="white-space:nowrap;">{_esc(row.status)}</td>
          <td style="font-size:12.5px; color:var(--v-muted);">{_esc(row.detail)}</td>
        </tr>
        """
        for row in COMPATIBILITY_MATRIX
    )
    kr_ok, kr_msg = keyring_status
    kr_text = f"Trousseau système actif ({kr_msg})" if kr_ok else f"Trousseau indisponible ({kr_msg})"

    return f"""<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <title>Réglages — Verrière</title>
  <style>
    {_base_css(settings)}
    td, th {{ padding: 10px 6px; border-bottom: 1px solid rgba(15,23,42,0.06); text-align:left; font-size:13px; }}
    .grid-2 {{ display:grid; grid-template-columns:1fr 1fr; gap:14px; }}
  </style>
</head>
<body>
  <div class="page-shell">
    <div class="kicker"><span class="kicker-dash"></span> Préférences &amp; Transparence</div>
    <h1 class="serif" style="font-size:40px; margin:8px 0 18px;">Réglages</h1>

    <form class="card" style="margin-bottom:18px;" method="GET" action="verriere://action">
      <input type="hidden" name="op" value="save_settings" />
      <input type="hidden" name="nonce" value="{_esc(nonce)}" />
      <h2 style="margin:0 0 14px; font-size:18px;">Accueil, Accessibilité &amp; Démarrage</h2>
      <div class="grid-2">
        <label style="font-size:13px; font-weight:600;">Prénom affiché
          <input class="input" name="user_name" value="{_esc(settings.get('user_name', 'Camille'))}" />
        </label>
        <label style="font-size:13px; font-weight:600;">Sous-titre d'accueil
          <input class="input" name="subtitle" value="{_esc(settings.get('subtitle', ''))}" />
        </label>
        <label style="font-size:13px; font-weight:600;">Moteur de recherche par défaut
          <select class="input" name="default_search_provider_id">{provider_options}</select>
        </label>
        <label style="font-size:13px; font-weight:600;">Point de terminaison Éclair (modèle {{query}})
          <input class="input" name="eclair_endpoint" value="{_esc(settings.get('eclair_endpoint', ''))}" placeholder="https://.../search?q={{query}}" />
        </label>
      </div>
      <div style="display:flex; flex-direction:column; gap:8px; margin-top:14px; font-size:13.5px;">
        <label><input type="checkbox" name="show_newtab_background" value="1" {"checked" if settings.get("show_newtab_background", True) else ""} /> Afficher l'arrière-plan architectural sur Nouvel onglet</label>
        <label><input type="checkbox" name="show_bookmarks_bar" value="1" {"checked" if settings.get("show_bookmarks_bar", True) else ""} /> Afficher la barre des favoris</label>
        <label><input type="checkbox" name="restore_session_on_startup" value="1" {"checked" if settings.get("restore_session_on_startup", True) else ""} /> Restaurer les onglets normaux au démarrage</label>
        <label><input type="checkbox" name="remote_suggestions_enabled" value="1" {"checked" if settings.get("remote_suggestions_enabled", False) else ""} /> Activer les suggestions de recherche distantes (transmet les frappes au fournisseur choisi)</label>
        <label><input type="checkbox" name="high_contrast" value="1" {"checked" if settings.get("high_contrast", False) else ""} /> Mode contraste élevé</label>
        <label><input type="checkbox" name="reduced_motion" value="1" {"checked" if settings.get("reduced_motion", False) else ""} /> Réduire les animations</label>
      </div>
      <div style="margin-top:14px;">
        <button class="btn btn-primary" type="submit">Enregistrer les réglages</button>
        <a class="btn btn-danger" style="margin-left:8px;" href="verriere://action?op=open_clear_data&nonce={_esc(nonce)}">Effacer les données de navigation…</a>
      </div>
    </form>

    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin:0 0 10px; font-size:18px;">Profils, Espaces &amp; Navigation privée</h2>
      <p style="font-size:13.5px; line-height:1.55; margin:0 0 10px;">{_esc(WORKSPACE_ISOLATION_NOTICE)}</p>
      <p style="font-size:13px; color:var(--v-muted); margin:0;">Trousseau système : <strong>{_esc(kr_text)}</strong></p>
    </div>

    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin:0 0 10px; font-size:18px;">Permissions par origine</h2>
      {
        f'<table style="width:100%; border-collapse:collapse;"><thead><tr><th>Origine</th><th>Capacité</th><th>Décision</th><th></th></tr></thead><tbody>{perm_rows}</tbody></table>'
        if perm_rows
        else '<p style="margin:0; font-size:13.5px; color:var(--v-muted);">Aucune permission enregistrée pour ce profil.</p>'
      }
    </div>

    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin:0 0 10px; font-size:18px;">Assistant de lecture optionnel</h2>
      <p style="font-size:13px; color:var(--v-muted); margin:0 0 12px;">Désactivé par défaut. Aucun contenu de page n'est envoyé sans clic explicite de votre part ni en navigation privée.</p>
      <form method="GET" action="verriere://action" style="display:flex; flex-direction:column; gap:10px;">
        <input type="hidden" name="op" value="save_assistant" />
        <input type="hidden" name="nonce" value="{_esc(nonce)}" />
        <label style="font-size:13.5px;"><input type="checkbox" name="assistant_enabled" value="1" {"checked" if settings.get("assistant_enabled", False) else ""} /> Activer le panneau latéral d'aide à la lecture</label>
        <div class="grid-2">
          <label style="font-size:13px; font-weight:600;">Point de terminaison HTTPS compatible OpenAI
            <input class="input" name="assistant_endpoint" value="{_esc(settings.get('assistant_endpoint', ''))}" placeholder="https://api.exemple.fr/v1/chat/completions" />
          </label>
          <label style="font-size:13px; font-weight:600;">Identifiant du modèle
            <input class="input" name="assistant_model" value="{_esc(settings.get('assistant_model', ''))}" placeholder="ex. mistral-small" />
          </label>
        </div>
        <div>
          <button class="btn btn-primary" type="submit">Mettre à jour l'assistant</button>
        </div>
      </form>
    </div>

    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin:0 0 10px; font-size:18px;">Compatibilité moteur &amp; Limites documentées</h2>
      <table style="width:100%; border-collapse:collapse;">
        <thead><tr><th>Capacité</th><th>Statut</th><th>Précisions techniques</th></tr></thead>
        <tbody>{compat_rows}</tbody>
      </table>
    </div>

    <div class="card">
      <h2 style="margin:0 0 10px; font-size:18px;">Diagnostics &amp; Mises à jour</h2>
      <p style="font-size:13px; line-height:1.55;">
        <strong>Application :</strong> {_esc(diag['application'])} ·
        <strong>PySide6 :</strong> {_esc(diag['pyside6'])} ·
        <strong>Qt :</strong> {_esc(diag['qt'])} ·
        <strong>Chromium (Qt WebEngine) :</strong> {_esc(diag['chromium'])}<br/>
        <strong>Isolation moteur (Sandbox) :</strong> {_esc(diag['sandbox_status'])}<br/>
        <strong>Mises à jour :</strong> les correctifs applicatifs de Verrière (vérifiés par manifeste signé) sont distincts des mises à jour de sécurité du moteur Chromium fournies via Qt WebEngine.
      </p>
    </div>
  </div>
</body>
</html>"""


def render_article_page(settings: dict[str, Any]) -> str:
    return f"""<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <title>Construire la ville de demain — Verrière</title>
  <style>{_base_css(settings)}</style>
</head>
<body>
  <article class="page-shell" style="max-width:780px;">
    <div class="kicker"><span class="kicker-dash"></span> Dossier enregistré localement</div>
    <h1 class="serif" style="font-size:48px; line-height:1.08; margin:12px 0 14px;">Construire la ville de demain</h1>
    <p class="serif" style="font-size:21px; font-style:italic; color:var(--v-muted); margin:0 0 24px;">
      Lumière naturelle, verrières contemporaines et réemploi de la pierre urbaine.
    </p>
    <img src="verriere://resources/images/atrium-lecture.svg" alt="Atrium architectural vitré" style="width:100%; border-radius:16px; margin-bottom:24px; border:1px solid var(--v-border);" />
    <div class="card" style="line-height:1.72; font-size:15.5px;">
      <p>Les grandes verrières contemporaines concilient transparence, inertie thermique et apport de lumière zénithale. Associées à la pierre de taille porteuse et au bois lamellé, elles prolongent l'héritage architectural parisien tout en réduisant l'empreinte carbone des équipements publics.</p>
      <p style="margin-bottom:0;">Cet article de démonstration est stocké localement dans les ressources de Verrière afin d'illustrer la carte « Reprendre la lecture » sans recourir à un flux d'actualités simulé.</p>
    </div>
  </article>
</body>
</html>"""


def render_error_page(
    *,
    settings: dict[str, Any],
    title: str,
    message: str,
    target_url: str,
    can_retry: bool = True,
) -> str:
    retry_btn = (
        f'<a class="btn btn-primary" href="{_esc(target_url)}">Réessayer</a>'
        if can_retry and target_url
        else ""
    )
    return f"""<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8" />
  <title>{_esc(title)} — Verrière</title>
  <style>{_base_css(settings)}</style>
</head>
<body>
  <div class="page-shell" style="max-width:680px; padding-top:72px;">
    <div class="kicker"><span class="kicker-dash"></span> Navigation interrompue</div>
    <h1 class="serif" style="font-size:38px; margin:12px 0 14px;">{_esc(title)}</h1>
    <div class="card">
      <p style="margin:0 0 12px; font-size:14.5px; line-height:1.6;">{_esc(message)}</p>
      <p style="margin:0 0 18px; font-size:12.5px; color:var(--v-muted); word-break:break-all;">Adresse concernée : {_esc(target_url)}</p>
      <div style="display:flex; gap:10px;">
        {retry_btn}
        <a class="btn" href="verriere://newtab">Retour à l'accueil</a>
      </div>
    </div>
  </div>
</body>
</html>"""
