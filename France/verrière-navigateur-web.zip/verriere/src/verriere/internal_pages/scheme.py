"""Enregistrement sécurisé du schéma verriere:// et gestionnaire QWebEngineUrlSchemeHandler."""

from __future__ import annotations

import mimetypes
import os
import secrets
from pathlib import Path
from typing import Callable
from urllib.parse import parse_qs, urlparse

from verriere.bookmarks.manager import BookmarkManager
from verriere.downloads.manager import DownloadManager
from verriere.history.manager import HistoryManager
from verriere.internal_pages import templates
from verriere.permissions.manager import PermissionManager
from verriere.profiles.manager import ProfileContext
from verriere.search.providers import SearchEngineManager
from verriere.settings.credentials import CredentialStore
from verriere.workspaces.manager import WorkspaceManager

RESOURCES_DIR = (Path(__file__).resolve().parents[3] / "resources").resolve()


def register_verriere_scheme() -> None:
    """Enregistre globalement le schéma ``verriere://`` AVANT l'instanciation de QApplication."""
    from PySide6.QtWebEngineCore import QWebEngineUrlScheme

    existing = QWebEngineUrlScheme.schemeByName(b"verriere")
    if existing.name() == b"verriere":
        return
    scheme = QWebEngineUrlScheme(b"verriere")
    scheme.setSyntax(QWebEngineUrlScheme.Syntax.Host)
    scheme.setFlags(
        QWebEngineUrlScheme.Flag.SecureScheme
        | QWebEngineUrlScheme.Flag.LocalAccessAllowed
    )
    QWebEngineUrlScheme.registerScheme(scheme)


class InternalPageRouter:
    """Routeur pur Python (testable sans GUI) pour les requêtes verriere://*."""

    def __init__(
        self,
        *,
        context: ProfileContext,
        bookmarks: BookmarkManager | None,
        history: HistoryManager,
        downloads: DownloadManager,
        workspaces: WorkspaceManager | None,
        permissions: PermissionManager,
        search_manager: SearchEngineManager | None,
        credentials: CredentialStore | None,
        on_action: Callable[[str, dict[str, list[str]]], str | None] | None = None,
    ) -> None:
        self.context = context
        self.bookmarks = bookmarks
        self.history = history
        self.downloads = downloads
        self.workspaces = workspaces
        self.permissions = permissions
        self.search_manager = search_manager
        self.credentials = credentials
        self.on_action = on_action
        self.session_nonce = secrets.token_urlsafe(24)

    def _settings(self) -> dict[str, object]:
        from verriere.application.storage import DEFAULT_SETTINGS

        if self.context.db is not None:
            try:
                return self.context.db.get_all_settings()
            except Exception:
                return dict(DEFAULT_SETTINGS)
        return dict(DEFAULT_SETTINGS)

    def resolve_request(
        self,
        url_str: str,
        initiator_url: str = "",
    ) -> tuple[int, str, bytes]:
        """Résout une URL ``verriere://`` en ``(status_code, mime_type, body_bytes)``."""
        parsed = urlparse(url_str)
        if parsed.scheme.lower() != "verriere":
            return 403, "text/plain; charset=utf-8", b"Schema interdit"

        host = (parsed.netloc or "newtab").lower()
        params = parse_qs(parsed.query)

        # Ressources statiques confinées dans resources/
        if host == "resources":
            rel_path = parsed.path.lstrip("/")
            candidate = (RESOURCES_DIR / rel_path).resolve()
            if not str(candidate).startswith(str(RESOURCES_DIR) + os.sep) or not candidate.is_file():
                return 404, "text/plain; charset=utf-8", b"Ressource introuvable"
            mime, _ = mimetypes.guess_type(str(candidate))
            return 200, mime or "application/octet-stream", candidate.read_bytes()

        # Actions privilégiées : requièrent l'initiateur verriere:// ET le jeton de session
        if host == "action":
            init_scheme = urlparse(initiator_url).scheme.lower() if initiator_url else "verriere"
            nonce_vals = params.get("nonce", [""])
            if init_scheme != "verriere" or not secrets.compare_digest(nonce_vals[0], self.session_nonce):
                return (
                    403,
                    "text/html; charset=utf-8",
                    templates.render_error_page(
                        settings=self._settings(),
                        title="Action interne refusée",
                        message="Les pages externes ne sont pas autorisées à déclencher des actions internes Verrière.",
                        target_url="",
                        can_retry=False,
                    ).encode("utf-8"),
                )
            op = params.get("op", [""])[0]
            redirect_url = self.on_action(op, params) if self.on_action else None
            target = redirect_url or "verriere://newtab"
            # Redirection propre côté HTML interne sans ouvrir à une origine externe
            if not target.startswith(("verriere://", "http://", "https://")):
                target = "verriere://newtab"
            return self.resolve_request(target, initiator_url="verriere://newtab") if target.startswith("verriere://") else (
                200,
                "text/html; charset=utf-8",
                f'<!doctype html><html><head><meta http-equiv="refresh" content="0;url={templates._esc(target)}"></head></html>'.encode("utf-8"),
            )

        settings = self._settings()
        if host == "newtab":
            shortcuts = []
            reading_items = []
            ws_list = self.workspaces.list_workspaces() if self.workspaces else []
            active_ws = self.workspaces.get_active_workspace_id() if self.workspaces else "ws-recherche"
            if self.context.db is not None:
                shortcuts = [
                    dict(r)
                    for r in self.context.db.connection.execute(
                        "SELECT id, title, url, icon FROM newtab_shortcuts ORDER BY position ASC"
                    ).fetchall()
                ]
                reading_items = [
                    dict(r)
                    for r in self.context.db.connection.execute(
                        "SELECT id, title, url, summary, preview_key FROM reading_items ORDER BY saved_at DESC"
                    ).fetchall()
                ]
            default_provider = (
                self.search_manager.get_default_provider()
                if self.search_manager is not None
                else SearchEngineManager.__new__(SearchEngineManager)
            )
            if self.search_manager is None:
                from verriere.search.providers import SearchProvider

                default_provider = SearchProvider(
                    id="qwant",
                    name="Qwant",
                    url_template="https://www.qwant.com/?q={query}&l=fr",
                    is_builtin=True,
                )
            html_out = templates.render_newtab_page(
                nonce=self.session_nonce,
                settings=settings,
                shortcuts=shortcuts,
                workspaces=ws_list,
                active_workspace_id=active_ws,
                reading_items=reading_items,
                default_provider=default_provider,
                is_private=self.context.is_private,
            )
            return 200, "text/html; charset=utf-8", html_out.encode("utf-8")

        if host == "bookmarks":
            q = params.get("q", [""])[0]
            folders = self.bookmarks.list_folders() if self.bookmarks else []
            bms = self.bookmarks.list_bookmarks(query=q) if self.bookmarks else []
            html_out = templates.render_bookmarks_page(
                nonce=self.session_nonce,
                settings=settings,
                folders=folders,
                bookmarks=bms,
                query=q,
            )
            return 200, "text/html; charset=utf-8", html_out.encode("utf-8")

        if host == "history":
            q = params.get("q", [""])[0]
            period = params.get("period", ["all"])[0]
            entries = self.history.search(query=q, date_filter=period)
            html_out = templates.render_history_page(
                nonce=self.session_nonce,
                settings=settings,
                entries=entries,
                query=q,
                date_filter=period,
                is_private=self.context.is_private,
            )
            return 200, "text/html; charset=utf-8", html_out.encode("utf-8")

        if host == "downloads":
            html_out = templates.render_downloads_page(
                nonce=self.session_nonce,
                settings=settings,
                downloads=self.downloads.list_downloads(),
            )
            return 200, "text/html; charset=utf-8", html_out.encode("utf-8")

        if host == "settings":
            providers = self.search_manager.list_providers() if self.search_manager else []
            perms = self.permissions.list_permissions()
            kr_status = (
                self.credentials.is_backend_available()
                if self.credentials is not None
                else (False, "Session privée")
            )
            html_out = templates.render_settings_page(
                nonce=self.session_nonce,
                settings=settings,
                providers=providers,
                permissions=perms,
                keyring_status=kr_status,
            )
            return 200, "text/html; charset=utf-8", html_out.encode("utf-8")

        if host == "article":
            return 200, "text/html; charset=utf-8", templates.render_article_page(settings).encode("utf-8")

        if host == "error":
            title = params.get("title", ["Page inaccessible"])[0]
            msg = params.get("message", ["Le chargement de la page a échoué."])[0]
            target = params.get("target", [""])[0]
            return 200, "text/html; charset=utf-8", templates.render_error_page(
                settings=settings,
                title=title,
                message=msg,
                target_url=target,
            ).encode("utf-8")

        return 404, "text/html; charset=utf-8", templates.render_error_page(
            settings=settings,
            title="Page interne introuvable",
            message=f"La page verriere://{host} n'existe pas.",
            target_url=url_str,
            can_retry=False,
        ).encode("utf-8")


def create_qt_scheme_handler(router: InternalPageRouter, parent: object = None) -> object:
    """Instancie le QWebEngineUrlSchemeHandler connecté au routeur interne."""
    from PySide6.QtCore import QBuffer, QIODevice
    from PySide6.QtWebEngineCore import QWebEngineUrlRequestJob, QWebEngineUrlSchemeHandler

    class _VerriereQtSchemeHandler(QWebEngineUrlSchemeHandler):
        def requestStarted(self, job: QWebEngineUrlRequestJob) -> None:
            url_str = job.requestUrl().toString()
            initiator = job.initiator().toString() if hasattr(job, "initiator") else ""
            status, mime, body = router.resolve_request(url_str, initiator_url=initiator)
            if status >= 400 and not mime.startswith("text/html"):
                job.fail(QWebEngineUrlRequestJob.Error.RequestDenied)
                return
            buf = QBuffer(parent=job)
            buf.setData(body)
            buf.open(QIODevice.OpenModeFlag.ReadOnly)
            job.reply(mime.split(";")[0].strip().encode("ascii"), buf)

    return _VerriereQtSchemeHandler(parent)
