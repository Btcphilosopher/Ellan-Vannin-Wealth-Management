"""Gestion des profils isolés (stockage Qt WebEngine + SQLite) et des sessions privées."""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from verriere.application.locale_fr import utc_now_iso
from verriere.application.storage import ProfileDatabase

PRIVATE_BROWSING_NOTICE = (
    "Navigation privée active : aucun onglet, historique, téléchargement ni cookie "
    "persistant n'est enregistré localement par Verrière. Attention : la navigation "
    "privée ne masque pas votre activité réseau aux sites visités, à votre fournisseur "
    "d'accès ou à l'administrateur de votre réseau."
)


@dataclass(frozen=True)
class ProfileInfo:
    id: str
    name: str
    storage_dir_name: str
    created_at: str


def _safe_slug(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug or "profil"


class ProfileRegistry:
    """Registre sur disque des profils utilisateurs Verrière."""

    def __init__(self, base_data_dir: Path | str) -> None:
        self.base_data_dir = Path(base_data_dir)
        self.profiles_root = self.base_data_dir / "profiles"
        self.profiles_root.mkdir(parents=True, exist_ok=True)
        self._registry_path = self.base_data_dir / "profiles.json"
        self._data: dict[str, Any] = self._load_or_init()

    def _load_or_init(self) -> dict[str, Any]:
        if self._registry_path.exists():
            try:
                loaded = json.loads(self._registry_path.read_text(encoding="utf-8"))
                if loaded.get("profiles"):
                    return loaded
            except (json.JSONDecodeError, OSError):
                pass
        default_profile = {
            "id": "camille",
            "name": "Camille",
            "storage_dir_name": "profile_camille",
            "created_at": utc_now_iso(),
        }
        data = {"active_profile_id": "camille", "profiles": [default_profile]}
        self._save(data)
        return data

    def _save(self, data: dict[str, Any]) -> None:
        self.base_data_dir.mkdir(parents=True, exist_ok=True)
        self._registry_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    def list_profiles(self) -> list[ProfileInfo]:
        return [
            ProfileInfo(
                id=item["id"],
                name=item["name"],
                storage_dir_name=item["storage_dir_name"],
                created_at=item["created_at"],
            )
            for item in self._data["profiles"]
        ]

    def get_profile(self, profile_id: str) -> ProfileInfo:
        for profile in self.list_profiles():
            if profile.id == profile_id:
                return profile
        return self.list_profiles()[0]

    def get_active_profile(self) -> ProfileInfo:
        return self.get_profile(self._data.get("active_profile_id", "camille"))

    def set_active_profile(self, profile_id: str) -> ProfileInfo:
        profile = self.get_profile(profile_id)
        self._data["active_profile_id"] = profile.id
        self._save(self._data)
        return profile

    def create_profile(self, name: str) -> ProfileInfo:
        clean_name = name.strip() or "Nouveau profil"
        profile_id = f"{_safe_slug(clean_name)}-{uuid.uuid4().hex[:6]}"
        storage_dir_name = f"profile_{profile_id}"
        entry = {
            "id": profile_id,
            "name": clean_name,
            "storage_dir_name": storage_dir_name,
            "created_at": utc_now_iso(),
        }
        self._data["profiles"].append(entry)
        self._save(self._data)
        return ProfileInfo(**entry)

    def profile_dir(self, profile_id: str) -> Path:
        profile = self.get_profile(profile_id)
        path = self.profiles_root / profile.storage_dir_name
        path.mkdir(parents=True, exist_ok=True)
        return path

    def open_profile_database(self, profile_id: str) -> ProfileDatabase:
        pdir = self.profile_dir(profile_id)
        db = ProfileDatabase(pdir / "verriere.sqlite3")
        profile = self.get_profile(profile_id)
        if db.get_setting("user_name") == "Camille" and profile.id != "camille":
            db.set_setting("user_name", profile.name)
        return db


class ProfileContext:
    """Contexte d'exécution d'une fenêtre (profil normal isolé OU session privée)."""

    def __init__(
        self,
        profile_info: ProfileInfo | None,
        storage_dir: Path | None,
        db: ProfileDatabase | None,
        is_private: bool = False,
    ) -> None:
        self.profile_info = profile_info
        self.storage_dir = storage_dir
        self.db = db
        self.is_private = is_private
        self.web_profile: Any = None  # QWebEngineProfile initialisé à la demande

    @property
    def display_name(self) -> str:
        if self.is_private:
            return "Navigation privée"
        return self.profile_info.name if self.profile_info else "Profil"

    def ensure_web_profile(self, parent: Any = None, scheme_handler: Any = None) -> Any:
        from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEngineSettings

        if self.web_profile is not None:
            return self.web_profile

        if self.is_private:
            # Constructeur sans nom de stockage -> profil off-the-record en mémoire uniquement
            qprofile = QWebEngineProfile(parent)
            qprofile.setPersistentCookiesPolicy(
                QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies
            )
            qprofile.setHttpCacheType(QWebEngineProfile.HttpCacheType.MemoryHttpCache)
        else:
            assert self.profile_info is not None and self.storage_dir is not None
            web_dir = self.storage_dir / "webengine"
            cache_dir = self.storage_dir / "cache"
            web_dir.mkdir(parents=True, exist_ok=True)
            cache_dir.mkdir(parents=True, exist_ok=True)
            qprofile = QWebEngineProfile(f"verriere_{self.profile_info.id}", parent)
            qprofile.setPersistentStoragePath(str(web_dir))
            qprofile.setCachePath(str(cache_dir))
            qprofile.setPersistentCookiesPolicy(
                QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies
            )

        settings = qprofile.settings()
        settings.setAttribute(QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.PdfViewerEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, False)
        settings.setAttribute(QWebEngineSettings.WebAttribute.PluginsEnabled, False)

        if scheme_handler is not None:
            qprofile.installUrlSchemeHandler(b"verriere", scheme_handler)

        self.web_profile = qprofile
        return qprofile

    def clear_browsing_data(
        self,
        clear_history: bool = False,
        clear_cookies: bool = False,
        clear_cache: bool = False,
        clear_site_storage: bool = False,
    ) -> None:
        if clear_history and not self.is_private and self.db is not None:
            self.db.connection.execute("DELETE FROM history_entries")
            self.db.connection.commit()

        if self.web_profile is not None:
            if clear_cookies:
                self.web_profile.cookieStore().deleteAllCookies()
            if clear_cache:
                self.web_profile.clearHttpCache()
            if clear_site_storage:
                self.web_profile.clearAllVisitedLinks()
                # Nettoyage des données de stockage local HTML5 via cache/storage si disponible
                if hasattr(self.web_profile, "clearHttpCache"):
                    self.web_profile.clearHttpCache()
