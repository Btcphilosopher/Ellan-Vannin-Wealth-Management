"""VERRIÈRE — Navigateur Web de bureau en français."""

__app_name__ = "Verrière"
__version__ = "0.1.0"
__organization__ = "Verrière"
