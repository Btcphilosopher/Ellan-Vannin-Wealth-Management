"""Gestion des permissions par origine et de l'état de sécurité TLS."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from urllib.parse import urlparse

from verriere.application.locale_fr import utc_now_iso
from verriere.application.storage import ProfileDatabase


class PermissionDecision(str, Enum):
    ASK = "ask"
    ALLOW = "allow"
    DENY = "deny"


PERMISSION_LABELS_FR = {
    "microphone": "Microphone",
    "camera": "Caméra",
    "geolocation": "Position géographique",
    "notifications": "Notifications",
    "clipboard": "Presse-papiers",
    "mouse_lock": "Verrouillage du pointeur",
}


@dataclass(frozen=True)
class OriginPermission:
    origin: str
    permission_type: str
    decision: PermissionDecision
    updated_at: str


@dataclass(frozen=True)
class SecurityStatus:
    origin: str
    scheme: str
    is_encrypted: bool
    is_internal: bool
    has_certificate_error: bool
    label_fr: str
    detail_fr: str


def extract_origin(url_str: str) -> str:
    parsed = urlparse(url_str.strip())
    scheme = parsed.scheme.lower()
    if scheme == "verriere":
        return f"verriere://{parsed.netloc or 'newtab'}"
    if scheme == "file":
        return "file://"
    if scheme in ("http", "https") and parsed.hostname:
        port = f":{parsed.port}" if parsed.port else ""
        return f"{scheme}://{parsed.hostname}{port}"
    return url_str


def describe_security_status(url_str: str, cert_error: str = "") -> SecurityStatus:
    """Fournit une description honnête de l'état de connexion (sans confondre chiffrement et confiance)."""
    parsed = urlparse(url_str.strip())
    scheme = parsed.scheme.lower()
    origin = extract_origin(url_str)

    if cert_error:
        return SecurityStatus(
            origin=origin,
            scheme=scheme,
            is_encrypted=False,
            is_internal=False,
            has_certificate_error=True,
            label_fr="Erreur de certificat",
            detail_fr=f"Le certificat de sécurité pour {origin} n'est pas valide : {cert_error}",
        )

    if scheme == "verriere":
        return SecurityStatus(
            origin=origin,
            scheme=scheme,
            is_encrypted=True,
            is_internal=True,
            has_certificate_error=False,
            label_fr="Page interne Verrière",
            detail_fr="Surface applicative interne isolée des sites Web externes.",
        )

    if scheme == "https":
        return SecurityStatus(
            origin=origin,
            scheme=scheme,
            is_encrypted=True,
            is_internal=False,
            has_certificate_error=False,
            label_fr="Connexion chiffrée (HTTPS)",
            detail_fr=(
                f"Les échanges avec {origin} sont chiffrés en transit. "
                "Cela ne garantit pas que l'éditeur du site soit digne de confiance."
            ),
        )

    if scheme == "http":
        return SecurityStatus(
            origin=origin,
            scheme=scheme,
            is_encrypted=False,
            is_internal=False,
            has_certificate_error=False,
            label_fr="Connexion non chiffrée (HTTP)",
            detail_fr=(
                f"Les échanges avec {origin} circulent en clair et peuvent être observés "
                "ou modifiés sur le réseau."
            ),
        )

    if scheme == "file":
        return SecurityStatus(
            origin="file://",
            scheme="file",
            is_encrypted=False,
            is_internal=False,
            has_certificate_error=False,
            label_fr="Fichier local",
            detail_fr="Document ouvert localement sans accès aux privilèges internes de Verrière.",
        )

    return SecurityStatus(
        origin=origin,
        scheme=scheme,
        is_encrypted=False,
        is_internal=False,
        has_certificate_error=False,
        label_fr="Destination locale",
        detail_fr=origin,
    )


class PermissionManager:
    """Stocke et applique les autorisations par origine exacte."""

    def __init__(self, db: ProfileDatabase | None = None, is_private: bool = False) -> None:
        self._db = None if is_private else db
        self._is_private = is_private
        self._ephemeral: dict[tuple[str, str], OriginPermission] = {}

    def get_decision(self, origin: str, permission_type: str) -> PermissionDecision:
        norm_origin = extract_origin(origin)
        if (norm_origin, permission_type) in self._ephemeral:
            return self._ephemeral[(norm_origin, permission_type)].decision
        if not self._is_private and self._db is not None:
            row = self._db.connection.execute(
                "SELECT decision FROM origin_permissions WHERE origin = ? AND permission_type = ?",
                (norm_origin, permission_type),
            ).fetchone()
            if row is not None:
                return PermissionDecision(row["decision"])
        return PermissionDecision.ASK

    def set_decision(
        self,
        origin: str,
        permission_type: str,
        decision: PermissionDecision,
        remember: bool = True,
    ) -> OriginPermission:
        norm_origin = extract_origin(origin)
        now = utc_now_iso()
        entry = OriginPermission(
            origin=norm_origin,
            permission_type=permission_type,
            decision=decision,
            updated_at=now,
        )
        # En session privée, ne jamais écrire dans SQLite
        if self._is_private or not remember or self._db is None:
            self._ephemeral[(norm_origin, permission_type)] = entry
            return entry

        self._db.connection.execute(
            "INSERT OR REPLACE INTO origin_permissions(origin, permission_type, decision, updated_at) "
            "VALUES (?, ?, ?, ?)",
            (norm_origin, permission_type, decision.value, now),
        )
        self._db.connection.commit()
        return entry

    def revoke_permission(self, origin: str, permission_type: str) -> None:
        norm_origin = extract_origin(origin)
        self._ephemeral.pop((norm_origin, permission_type), None)
        if not self._is_private and self._db is not None:
            self._db.connection.execute(
                "DELETE FROM origin_permissions WHERE origin = ? AND permission_type = ?",
                (norm_origin, permission_type),
            )
            self._db.connection.commit()

    def list_permissions(self, origin: str | None = None) -> list[OriginPermission]:
        results: dict[tuple[str, str], OriginPermission] = {}
        if not self._is_private and self._db is not None:
            if origin is not None:
                norm_origin = extract_origin(origin)
                rows = self._db.connection.execute(
                    "SELECT origin, permission_type, decision, updated_at FROM origin_permissions "
                    "WHERE origin = ? ORDER BY permission_type ASC",
                    (norm_origin,),
                ).fetchall()
            else:
                rows = self._db.connection.execute(
                    "SELECT origin, permission_type, decision, updated_at FROM origin_permissions "
                    "ORDER BY origin ASC, permission_type ASC"
                ).fetchall()
            for r in rows:
                results[(r["origin"], r["permission_type"])] = OriginPermission(
                    origin=r["origin"],
                    permission_type=r["permission_type"],
                    decision=PermissionDecision(r["decision"]),
                    updated_at=r["updated_at"],
                )

        for key, item in self._ephemeral.items():
            if origin is None or key[0] == extract_origin(origin):
                results[key] = item
        return list(results.values())
