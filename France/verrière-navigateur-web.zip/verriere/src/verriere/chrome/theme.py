"""Feuille de style QSS fidèle au design Verrière (perle, titane satiné, saphir, vermillon)."""

from __future__ import annotations


def build_stylesheet(high_contrast: bool = False, is_private: bool = False) -> str:
    if high_contrast:
        chrome_bg = "#FFFFFF"
        tab_strip_bg = "#F1F5F9"
        toolbar_bg = "#FFFFFF"
        border = "#0F172A"
        text = "#000000"
        muted = "#0F172A"
        sapphire = "#0A369D"
        input_bg = "#FFFFFF"
        active_sidebar_bg = "#DBEAFE"
    elif is_private:
        chrome_bg = "#EEF0F6"
        tab_strip_bg = "#DCE1EB"
        toolbar_bg = "#F4F6FA"
        border = "#CBD5E1"
        text = "#0F172A"
        muted = "#334155"
        sapphire = "#1246B8"
        input_bg = "#E8ECF4"
        active_sidebar_bg = "#DCE6FA"
    else:
        chrome_bg = "#F7F8FB"
        tab_strip_bg = "#EAEFF6"
        toolbar_bg = "#FAFBFD"
        border = "#DCE2EC"
        text = "#0F172A"
        muted = "#475569"
        sapphire = "#1246B8"
        input_bg = "#EFF2F7"
        active_sidebar_bg = "#E6EEFC"

    return f"""
    QMainWindow, QWidget#RootShell {{
      background-color: {chrome_bg};
      color: {text};
      font-family: "Plus Jakarta Sans", "DejaVu Sans", "Segoe UI", sans-serif;
    }}

    QWidget#TabStrip {{
      background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #F3F5F9, stop:1 {tab_strip_bg});
      border-bottom: 1px solid {border};
    }}

    QLabel#BrandWordmark {{
      font-size: 13px;
      font-weight: 600;
      letter-spacing: 3px;
      color: #162033;
      padding-left: 4px;
      padding-right: 8px;
    }}

    QFrame#HairlineV {{
      background-color: {border};
      max-width: 1px;
      min-width: 1px;
      margin-top: 8px;
      margin-bottom: 8px;
    }}

    QTabBar#BrowserTabBar {{
      background: transparent;
    }}
    QTabBar#BrowserTabBar::tab {{
      background: rgba(255, 255, 255, 0.56);
      color: {muted};
      border: 1px solid rgba(203, 213, 225, 0.7);
      border-bottom: none;
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
      padding: 7px 14px;
      margin-top: 5px;
      margin-right: 4px;
      min-width: 140px;
      max-width: 230px;
      font-size: 12.5px;
      font-weight: 500;
    }}
    QTabBar#BrowserTabBar::tab:selected {{
      background: {toolbar_bg};
      color: {text};
      border: 1px solid {border};
      border-bottom: 1px solid {toolbar_bg};
      font-weight: 600;
    }}
    QTabBar#BrowserTabBar::tab:hover:!selected {{
      background: rgba(255, 255, 255, 0.85);
    }}

    QToolButton#NewTabButton {{
      border: none;
      border-radius: 8px;
      padding: 5px 9px;
      font-size: 16px;
      font-weight: 500;
      color: {muted};
      background: transparent;
    }}
    QToolButton#NewTabButton:hover {{
      background: rgba(15, 23, 42, 0.08);
      color: {text};
    }}

    QWidget#NavToolbar {{
      background-color: {toolbar_bg};
      border-bottom: 1px solid {border};
    }}

    QToolButton.NavIconBtn {{
      border: 1px solid transparent;
      border-radius: 8px;
      padding: 6px;
      min-width: 30px;
      min-height: 30px;
      color: {text};
      background: transparent;
      font-size: 14px;
    }}
    QToolButton.NavIconBtn:hover {{
      background-color: rgba(15, 23, 42, 0.06);
    }}
    QToolButton.NavIconBtn:disabled {{
      color: #94A3B8;
    }}

    QFrame#AddressBox {{
      background-color: {input_bg};
      border: 1px solid {border};
      border-radius: 18px;
      min-height: 35px;
      max-height: 35px;
    }}
    QFrame#AddressBox:focus-within {{
      background-color: #FFFFFF;
      border: 1.5px solid {sapphire};
    }}

    QLineEdit#AddressInput {{
      border: none;
      background: transparent;
      color: {text};
      font-size: 13px;
      padding: 2px 6px;
      selection-background-color: #BFDBFE;
    }}

    QToolButton#SecurityChip {{
      border: none;
      border-radius: 13px;
      padding: 3px 8px;
      font-size: 12px;
      color: {muted};
      background: transparent;
    }}
    QToolButton#SecurityChip:hover {{
      background: rgba(15, 23, 42, 0.07);
    }}

    QProgressBar#LoadProgress {{
      border: none;
      background: transparent;
      max-height: 2px;
      min-height: 2px;
    }}
    QProgressBar#LoadProgress::chunk {{
      background-color: {sapphire};
    }}

    QWidget#BookmarksBar {{
      background-color: #FFFFFF;
      border-bottom: 1px solid {border};
    }}

    QToolButton.BookmarkFolderBtn {{
      border: none;
      border-radius: 7px;
      padding: 4px 10px;
      font-size: 12.5px;
      color: {text};
      background: transparent;
    }}
    QToolButton.BookmarkFolderBtn:hover {{
      background-color: #F1F5F9;
    }}

    QWidget#LeftSidebar {{
      background-color: #F4F6FA;
      border-right: 1px solid {border};
      min-width: 74px;
      max-width: 74px;
    }}

    QToolButton.SidebarItem {{
      border: none;
      border-radius: 12px;
      padding: 8px 4px;
      font-size: 11px;
      font-weight: 500;
      color: {muted};
      background: transparent;
    }}
    QToolButton.SidebarItem:hover {{
      background-color: rgba(15, 23, 42, 0.05);
      color: {text};
    }}
    QToolButton.SidebarItem[active="true"] {{
      background-color: {active_sidebar_bg};
      color: {sapphire};
      font-weight: 600;
      border-left: 3px solid {sapphire};
    }}

    QWidget#StatusFooter {{
      background-color: #F1F4F8;
      border-top: 1px solid {border};
      min-height: 28px;
      max-height: 28px;
    }}

    QWidget#SideDrawer {{
      background-color: #FAFBFD;
      border-left: 1px solid {border};
    }}

    QFrame#InlineBanner {{
      background-color: #EFF6FF;
      border-bottom: 1px solid #BFDBFE;
      padding: 6px 12px;
    }}
    QFrame#WarningBanner {{
      background-color: #FFF7ED;
      border-bottom: 1px solid #FED7AA;
      padding: 6px 12px;
    }}
    """
