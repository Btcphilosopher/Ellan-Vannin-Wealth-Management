"""Fenêtre principale de navigation Verrière (PySide6 + Qt WebEngine)."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import quote, urlparse

from PySide6.QtCore import QPoint, QSize, Qt, QUrl, Signal
from PySide6.QtGui import QAction, QDesktopServices, QIcon, QKeySequence, QPixmap, QShortcut
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineSettings
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFrame,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMenu,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QStackedWidget,
    QTabBar,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from verriere.application.locale_fr import format_percent_fr
from verriere.assistant.client import PageAssistantService
from verriere.bookmarks.manager import BookmarkManager
from verriere.chrome.dialogs import (
    AssistantSidebar,
    BookmarkEditDialog,
    ClearDataDialog,
    FindInPageBar,
    OriginSecurityDialog,
    WorkspaceDrawer,
)
from verriere.chrome.theme import build_stylesheet
from verriere.downloads.manager import DownloadManager
from verriere.history.manager import HistoryManager
from verriere.internal_pages.scheme import RESOURCES_DIR, InternalPageRouter, create_qt_scheme_handler
from verriere.internal_pages.templates import render_error_page
from verriere.navigation.suggestions import AddressSuggestion, SuggestionEngine
from verriere.navigation.url_parser import (
    BLOCKED_SCHEMES,
    InputKind,
    format_url_for_bar,
    parse_address_input,
)
from verriere.permissions.manager import (
    PERMISSION_LABELS_FR,
    PermissionDecision,
    PermissionManager,
    describe_security_status,
    extract_origin,
)
from verriere.profiles.manager import PRIVATE_BROWSING_NOTICE, ProfileContext
from verriere.search.providers import SearchEngineManager, validate_search_template
from verriere.settings.credentials import CredentialStore
from verriere.tabs.manager import TabManager, TabRecord
from verriere.workspaces.manager import WorkspaceManager

if TYPE_CHECKING:
    from verriere.application.browser_app import VerriereApplication

logger = logging.getLogger(__name__)


def _render_svg_icon(svg_path: Path, size: int = 20) -> QIcon:
    if not svg_path.exists():
        return QIcon()
    renderer = QSvgRenderer(str(svg_path))
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    from PySide6.QtGui import QPainter

    painter = QPainter(pixmap)
    renderer.render(painter)
    painter.end()
    return QIcon(pixmap)


class VerriereWebPage(QWebEnginePage):
    """Page Qt WebEngine durcie : filtrage des schémas, certificats et pop-ups."""

    blocked_navigation = Signal(str, str)  # url, reason
    cert_error_detected = Signal(str, str)  # url, description
    popup_requested = Signal(object)  # callback receiving created QWebEnginePage

    def __init__(self, profile: Any, view: QWebEngineView, window: VerriereWindow, tab_id: str) -> None:
        super().__init__(profile, view)
        self._window = window
        self.tab_id = tab_id
        self._composing = False

    def acceptNavigationRequest(
        self,
        url: QUrl,
        nav_type: QWebEnginePage.NavigationType,
        is_main_frame: bool,
    ) -> bool:
        url_str = url.toString()
        scheme = url.scheme().lower()

        if scheme in BLOCKED_SCHEMES:
            self.blocked_navigation.emit(
                url_str,
                f"Le schéma « {scheme}: » est bloqué pour empêcher l'exécution de scripts ou commandes non sûrs.",
            )
            return False

        # Empêcher les pages externes de déclencher une navigation file:// ou verriere://action
        current_scheme = self.url().scheme().lower()
        if scheme == "file" and current_scheme in ("http", "https"):
            self.blocked_navigation.emit(
                url_str,
                "Les sites Web externes ne peuvent pas ouvrir directement des fichiers locaux (file://).",
            )
            return False

        if scheme == "verriere" and url.host().lower() == "action" and current_scheme not in ("verriere", ""):
            self.blocked_navigation.emit(
                url_str,
                "Les sites Web externes ne peuvent pas invoquer les actions internes de Verrière.",
            )
            return False

        if scheme not in ("http", "https", "verriere", "file", "about", "blob"):
            self.blocked_navigation.emit(
                url_str,
                f"Le schéma « {scheme}: » n'est pas pris en charge et ne peut pas exécuter d'application locale.",
            )
            return False

        return super().acceptNavigationRequest(url, nav_type, is_main_frame)

    def certificateError(self, error: Any) -> bool:
        # Ne jamais contourner automatiquement une erreur de certificat
        try:
            error.rejectCertificate()
        except Exception:
            pass
        desc = error.description() if hasattr(error, "description") else "Certificat invalide"
        target = error.url().toString() if hasattr(error, "url") else self.url().toString()
        self.cert_error_detected.emit(target, desc)
        return False

    def createWindow(self, window_type: QWebEnginePage.WebWindowType) -> QWebEnginePage | None:
        # Ouvre les pop-ups / target=_blank dans un nouvel onglet géré par Verrière
        new_page = self._window.open_controlled_popup_tab()
        return new_page


class AddressLineEdit(QLineEdit):
    """Barre d'adresse respectant la composition IME française."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.is_composing = False

    def inputMethodEvent(self, event: Any) -> None:
        self.is_composing = bool(event.preeditString())
        super().inputMethodEvent(event)


class VerriereWindow(QMainWindow):
    """Fenêtre principale du navigateur Verrière."""

    def __init__(
        self,
        app_controller: VerriereApplication,
        context: ProfileContext,
        restore_tabs: bool = True,
    ) -> None:
        super().__init__()
        self.app_controller = app_controller
        self.context = context
        self._views: dict[str, QWebEngineView] = {}
        self._pending_cert_errors: dict[str, str] = {}
        self._pending_permission_obj: Any = None
        self._pending_fullscreen_req: Any = None
        self._force_close = False

        # Services métier du profil
        db = context.db
        self.bookmarks = BookmarkManager(db) if db is not None and not context.is_private else None
        self.history = HistoryManager(db, is_private=context.is_private)
        self.workspaces = WorkspaceManager(db) if db is not None and not context.is_private else None
        self.search_manager = (
            SearchEngineManager(db) if db is not None and not context.is_private else None
        )
        self.permissions = PermissionManager(db, is_private=context.is_private)
        dl_dir = (
            (context.storage_dir / "Téléchargements")
            if context.storage_dir is not None
            else (Path.home() / "Téléchargements")
        )
        self.downloads = DownloadManager(dl_dir, db=db, is_private=context.is_private)
        self.credentials = (
            CredentialStore(context.profile_info.id)
            if context.profile_info is not None and not context.is_private
            else None
        )
        self.assistant_service = PageAssistantService(db, self.credentials)
        self.tab_manager = TabManager(db, is_private=context.is_private)
        self.suggestions = SuggestionEngine(
            bookmarks=self.bookmarks,
            history=self.history,
            search_manager=self.search_manager,
            remote_enabled_getter=lambda: bool(self._get_setting("remote_suggestions_enabled", False)),
        )

        self.internal_router = InternalPageRouter(
            context=self.context,
            bookmarks=self.bookmarks,
            history=self.history,
            downloads=self.downloads,
            workspaces=self.workspaces,
            permissions=self.permissions,
            search_manager=self.search_manager,
            credentials=self.credentials,
            on_action=self._handle_internal_action,
        )
        self._scheme_handler = create_qt_scheme_handler(self.internal_router, parent=self)
        self.web_profile = self.context.ensure_web_profile(
            parent=self, scheme_handler=self._scheme_handler
        )
        self.web_profile.downloadRequested.connect(self._on_download_requested)

        self._build_ui()
        self._register_shortcuts()
        self._apply_theme_and_preferences()

        # Démarrage ou restauration des onglets normaux
        restored: list[TabRecord] = []
        if (
            restore_tabs
            and not context.is_private
            and bool(self._get_setting("restore_session_on_startup", True))
        ):
            restored = self.tab_manager.restore_session()

        if restored:
            for rec in restored:
                self._mount_tab_widget(rec)
            if self.tab_manager.active_tab_id:
                self._activate_tab(self.tab_manager.active_tab_id)
        else:
            self.new_tab("verriere://newtab")

    def _get_setting(self, key: str, default: Any = None) -> Any:
        if self.context.db is not None:
            return self.context.db.get_setting(key, default)
        return default

    # ------------------------------------------------------------------
    # Construction de l'interface native Qt (fidèle à l'image de référence)
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        title_suffix = " (Navigation privée)" if self.context.is_private else ""
        self.setWindowTitle(f"VERRIÈRE — Navigateur Web{title_suffix}")
        self.setWindowIcon(_render_svg_icon(RESOURCES_DIR / "icons" / "verriere-logo.svg", 32))
        self.resize(1340, 860)

        root = QWidget()
        root.setObjectName("RootShell")
        self.setCentralWidget(root)
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        # 1. Bandeau d'onglets
        tab_strip = QWidget()
        tab_strip.setObjectName("TabStrip")
        tab_strip.setFixedHeight(40)
        ts_layout = QHBoxLayout(tab_strip)
        ts_layout.setContentsMargins(12, 0, 12, 0)
        ts_layout.setSpacing(6)

        logo_lbl = QLabel()
        logo_lbl.setPixmap(_render_svg_icon(RESOURCES_DIR / "icons" / "verriere-logo.svg", 22).pixmap(22, 22))
        brand_lbl = QLabel("VERRIÈRE")
        brand_lbl.setObjectName("BrandWordmark")
        sep = QFrame()
        sep.setObjectName("HairlineV")

        self.tab_bar = QTabBar()
        self.tab_bar.setObjectName("BrowserTabBar")
        self.tab_bar.setDocumentMode(True)
        self.tab_bar.setTabsClosable(True)
        self.tab_bar.setMovable(True)
        self.tab_bar.setExpanding(False)
        self.tab_bar.setElideMode(Qt.TextElideMode.ElideRight)
        self.tab_bar.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tab_bar.currentChanged.connect(self._on_tab_bar_changed)
        self.tab_bar.tabCloseRequested.connect(self._on_tab_bar_close_requested)
        self.tab_bar.tabMoved.connect(self._on_tab_bar_moved)
        self.tab_bar.customContextMenuRequested.connect(self._on_tab_context_menu)

        self.btn_new_tab = QToolButton()
        self.btn_new_tab.setObjectName("NewTabButton")
        self.btn_new_tab.setText("+")
        self.btn_new_tab.setAccessibleName("Nouvel onglet")
        self.btn_new_tab.setToolTip("Nouvel onglet (Ctrl+T)")
        self.btn_new_tab.clicked.connect(lambda: self.new_tab("verriere://newtab"))

        ts_layout.addWidget(logo_lbl)
        ts_layout.addWidget(brand_lbl)
        ts_layout.addWidget(sep)
        ts_layout.addWidget(self.tab_bar, 1)
        ts_layout.addWidget(self.btn_new_tab)

        if self.context.is_private:
            priv_lbl = QLabel("Session privée")
            priv_lbl.setStyleSheet(
                "background:#1E293B; color:#FFFFFF; border-radius:8px; padding:3px 10px; font-size:11.5px; font-weight:600;"
            )
            ts_layout.addWidget(priv_lbl)

        root_layout.addWidget(tab_strip)

        # 2. Barre d'outils de navigation + barre d'adresse
        nav_bar = QWidget()
        nav_bar.setObjectName("NavToolbar")
        nav_bar.setFixedHeight(46)
        nav_layout = QHBoxLayout(nav_bar)
        nav_layout.setContentsMargins(10, 5, 12, 5)
        nav_layout.setSpacing(6)

        self.btn_back = self._make_nav_btn("←", "Précédent (Alt+Gauche)", self.go_back)
        self.btn_forward = self._make_nav_btn("→", "Suivant (Alt+Droite)", self.go_forward)
        self.btn_reload = self._make_nav_btn("↻", "Actualiser / Arrêter (Ctrl+R)", self.reload_or_stop)
        self.btn_home = self._make_nav_btn("⌂", "Accueil", lambda: self.navigate_active("verriere://newtab"))

        address_box = QFrame()
        address_box.setObjectName("AddressBox")
        addr_layout = QHBoxLayout(address_box)
        addr_layout.setContentsMargins(8, 0, 8, 0)
        addr_layout.setSpacing(4)

        self.btn_security = QToolButton()
        self.btn_security.setObjectName("SecurityChip")
        self.btn_security.setText("🛡")
        self.btn_security.setAccessibleName("Informations de sécurité du site")
        self.btn_security.clicked.connect(self._show_security_dialog)

        self.address_input = AddressLineEdit()
        self.address_input.setObjectName("AddressInput")
        self.address_input.setPlaceholderText("Rechercher ou saisir une adresse")
        self.address_input.setAccessibleName("Barre d'adresse et de recherche")
        self.address_input.returnPressed.connect(self._on_address_submitted)
        self.address_input.textEdited.connect(self._on_address_text_edited)

        self.btn_copy_url = QToolButton()
        self.btn_copy_url.setObjectName("SecurityChip")
        self.btn_copy_url.setText("⎘")
        self.btn_copy_url.setToolTip("Copier l'adresse de la page")
        self.btn_copy_url.setAccessibleName("Copier l'adresse")
        self.btn_copy_url.clicked.connect(self._copy_current_url)

        addr_layout.addWidget(self.btn_security)
        addr_layout.addWidget(self.address_input, 1)
        addr_layout.addWidget(self.btn_copy_url)

        self.btn_zoom = self._make_nav_btn("100 %", "Niveau de zoom (Ctrl+0 pour réinitialiser)", self._reset_zoom)
        self.btn_zoom.setMinimumWidth(52)
        self.btn_bookmark = self._make_nav_btn("☆", "Ajouter aux favoris (Ctrl+D)", self._open_bookmark_dialog)
        self.btn_downloads = self._make_nav_btn("↓", "Téléchargements (Ctrl+J)", lambda: self.new_tab("verriere://downloads"))
        self.btn_assistant = self._make_nav_btn("✦", "Assistant de lecture optionnel", self._toggle_assistant)

        self.btn_profile = QToolButton()
        self.btn_profile.setProperty("class", "NavIconBtn")
        self.btn_profile.setText(f"👤 {self.context.display_name} ⌄")
        self.btn_profile.setAccessibleName("Menu profil et navigation privée")
        self.btn_profile.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self._profile_menu = QMenu(self)
        self.btn_profile.setMenu(self._profile_menu)
        self._rebuild_profile_menu()

        nav_layout.addWidget(self.btn_back)
        nav_layout.addWidget(self.btn_forward)
        nav_layout.addWidget(self.btn_reload)
        nav_layout.addWidget(self.btn_home)
        nav_layout.addWidget(address_box, 1)
        nav_layout.addWidget(self.btn_zoom)
        nav_layout.addWidget(self.btn_bookmark)
        nav_layout.addWidget(self.btn_downloads)
        nav_layout.addWidget(self.btn_assistant)
        nav_layout.addWidget(self.btn_profile)
        root_layout.addWidget(nav_bar)

        self.load_progress = QProgressBar()
        self.load_progress.setObjectName("LoadProgress")
        self.load_progress.setRange(0, 100)
        self.load_progress.setTextVisible(False)
        self.load_progress.hide()
        root_layout.addWidget(self.load_progress)

        # 3. Barre des favoris
        self.bookmarks_bar = QWidget()
        self.bookmarks_bar.setObjectName("BookmarksBar")
        self.bookmarks_bar.setFixedHeight(32)
        self.bm_layout = QHBoxLayout(self.bookmarks_bar)
        self.bm_layout.setContentsMargins(12, 0, 12, 0)
        self.bm_layout.setSpacing(6)
        root_layout.addWidget(self.bookmarks_bar)
        self._rebuild_bookmarks_bar()

        # 4. Corps principal : barre latérale gauche + pile Web + tiroirs
        body = QWidget()
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)

        sidebar = QWidget()
        sidebar.setObjectName("LeftSidebar")
        sb_layout = QVBoxLayout(sidebar)
        sb_layout.setContentsMargins(6, 10, 6, 10)
        sb_layout.setSpacing(6)

        self.sb_accueil = self._make_sidebar_btn("⌂", "Accueil", lambda: self.navigate_active("verriere://newtab"), active=True)
        self.sb_onglets = self._make_sidebar_btn("❐", "Onglets", self._toggle_workspace_drawer)
        self.sb_espaces = self._make_sidebar_btn("◫", "Espaces", self._toggle_workspace_drawer)
        self.sb_favoris = self._make_sidebar_btn("☆", "Favoris", lambda: self.navigate_active("verriere://bookmarks"))
        self.sb_historique = self._make_sidebar_btn("◷", "Historique", lambda: self.navigate_active("verriere://history"))
        self.sb_reglages = self._make_sidebar_btn("⚙", "Réglages", lambda: self.navigate_active("verriere://settings"))

        for btn in (self.sb_accueil, self.sb_onglets, self.sb_espaces, self.sb_favoris, self.sb_historique):
            sb_layout.addWidget(btn)
        sb_layout.addStretch()
        sb_layout.addWidget(self.sb_reglages)
        body_layout.addWidget(sidebar)

        # Tiroir Espaces & Onglets (masqué par défaut)
        self.workspace_drawer = WorkspaceDrawer(self.workspaces, self)
        self.workspace_drawer.hide()
        self.workspace_drawer.workspace_selected.connect(self._switch_workspace)
        self.workspace_drawer.workspace_created.connect(self._create_workspace)
        self.workspace_drawer.tab_selected.connect(self._activate_tab)
        self.workspace_drawer.move_tab_to_new_window.connect(self._move_tab_to_new_window)
        body_layout.addWidget(self.workspace_drawer)

        # Colonne centrale : bannières contrôlées + WebEngineView stack
        center_col = QWidget()
        center_layout = QVBoxLayout(center_col)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(0)

        if self.context.is_private:
            priv_banner = QFrame()
            priv_banner.setObjectName("WarningBanner")
            pb_layout = QHBoxLayout(priv_banner)
            pb_layout.setContentsMargins(12, 5, 12, 5)
            pb_lbl = QLabel(PRIVATE_BROWSING_NOTICE)
            pb_lbl.setWordWrap(True)
            pb_lbl.setStyleSheet("font-size: 12px;")
            pb_layout.addWidget(pb_lbl)
            center_layout.addWidget(priv_banner)

        self.find_bar = FindInPageBar(self)
        self.find_bar.hide()
        self.find_bar.find_requested.connect(self._on_find_in_page)
        self.find_bar.closed.connect(self._clear_find_highlight)
        center_layout.addWidget(self.find_bar)

        # Bannière de permission par origine
        self.perm_banner = QFrame()
        self.perm_banner.setObjectName("InlineBanner")
        self.perm_banner.hide()
        perm_l = QHBoxLayout(self.perm_banner)
        perm_l.setContentsMargins(12, 6, 12, 6)
        self.perm_label = QLabel()
        self.perm_remember = QCheckBox("Mémoriser pour cette origine")
        self.perm_remember.setChecked(not self.context.is_private)
        self.perm_remember.setEnabled(not self.context.is_private)
        btn_allow = QPushButton("Autoriser")
        btn_deny = QPushButton("Refuser")
        btn_allow.clicked.connect(lambda: self._resolve_permission_prompt(True))
        btn_deny.clicked.connect(lambda: self._resolve_permission_prompt(False))
        perm_l.addWidget(self.perm_label, 1)
        perm_l.addWidget(self.perm_remember)
        perm_l.addWidget(btn_allow)
        perm_l.addWidget(btn_deny)
        center_layout.addWidget(self.perm_banner)

        # Bannière plein écran contrôlée
        self.fs_banner = QFrame()
        self.fs_banner.setObjectName("InlineBanner")
        self.fs_banner.hide()
        fs_l = QHBoxLayout(self.fs_banner)
        fs_l.setContentsMargins(12, 6, 12, 6)
        self.fs_label = QLabel()
        btn_fs_ok = QPushButton("Passer en plein écran")
        btn_fs_no = QPushButton("Refuser")
        btn_fs_ok.clicked.connect(lambda: self._resolve_fullscreen_prompt(True))
        btn_fs_no.clicked.connect(lambda: self._resolve_fullscreen_prompt(False))
        fs_l.addWidget(self.fs_label, 1)
        fs_l.addWidget(btn_fs_ok)
        fs_l.addWidget(btn_fs_no)
        center_layout.addWidget(self.fs_banner)

        # Bannière schéma non pris en charge
        self.scheme_banner = QFrame()
        self.scheme_banner.setObjectName("WarningBanner")
        self.scheme_banner.hide()
        sc_l = QHBoxLayout(self.scheme_banner)
        sc_l.setContentsMargins(12, 6, 12, 6)
        self.scheme_label = QLabel()
        self.scheme_label.setWordWrap(True)
        btn_sc_close = QPushButton("Fermer")
        btn_sc_close.clicked.connect(self.scheme_banner.hide)
        sc_l.addWidget(self.scheme_label, 1)
        sc_l.addWidget(btn_sc_close)
        center_layout.addWidget(self.scheme_banner)

        self.view_stack = QStackedWidget()
        center_layout.addWidget(self.view_stack, 1)
        body_layout.addWidget(center_col, 1)

        # Panneau latéral assistant optionnel (à droite)
        self.assistant_sidebar = AssistantSidebar(self.assistant_service, self)
        self.assistant_sidebar.hide()
        self.assistant_sidebar.request_page_extract.connect(self._extract_for_assistant)
        body_layout.addWidget(self.assistant_sidebar)

        root_layout.addWidget(body, 1)

        # 5. Pied de fenêtre discret
        footer = QWidget()
        footer.setObjectName("StatusFooter")
        f_layout = QHBoxLayout(footer)
        f_layout.setContentsMargins(14, 0, 14, 0)
        self.footer_left = QLabel("Verrière · Navigateur Web")
        self.footer_left.setStyleSheet("font-size: 11.5px; color: #475569;")
        self.footer_right = QLabel("Français")
        self.footer_right.setStyleSheet("font-size: 11.5px; color: #475569;")
        f_layout.addWidget(self.footer_left)
        f_layout.addStretch()
        f_layout.addWidget(self.footer_right)
        root_layout.addWidget(footer)

        # Popup des suggestions d'adresse
        self.suggestion_popup = QListWidget(self)
        self.suggestion_popup.setWindowFlags(Qt.WindowType.ToolTip)
        self.suggestion_popup.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.suggestion_popup.itemClicked.connect(self._on_suggestion_clicked)
        self.suggestion_popup.hide()

    def _make_nav_btn(self, text: str, tooltip: str, slot: Any) -> QToolButton:
        btn = QToolButton()
        btn.setProperty("class", "NavIconBtn")
        btn.setText(text)
        btn.setToolTip(tooltip)
        btn.setAccessibleName(tooltip)
        btn.clicked.connect(slot)
        return btn

    def _make_sidebar_btn(
        self, icon_txt: str, label: str, slot: Any, active: bool = False
    ) -> QToolButton:
        btn = QToolButton()
        btn.setProperty("class", "SidebarItem")
        btn.setProperty("active", "true" if active else "false")
        btn.setText(f"{icon_txt}\n{label}")
        btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
        btn.setFixedSize(62, 54)
        btn.setAccessibleName(label)
        btn.clicked.connect(slot)
        return btn

    def _set_active_sidebar(self, page_url: str) -> None:
        host = urlparse(page_url).netloc.lower() if page_url.startswith("verriere://") else ""
        mapping = {
            self.sb_accueil: host == "newtab",
            self.sb_favoris: host == "bookmarks",
            self.sb_historique: host == "history",
            self.sb_reglages: host == "settings",
            self.sb_onglets: self.workspace_drawer.isVisible(),
            self.sb_espaces: self.workspace_drawer.isVisible(),
        }
        for btn, is_act in mapping.items():
            btn.setProperty("active", "true" if is_act else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)

    def _register_shortcuts(self) -> None:
        bindings = [
            ("Ctrl+T", lambda: self.new_tab("verriere://newtab")),
            ("Ctrl+W", self.close_active_tab),
            ("Ctrl+Shift+T", self.reopen_closed_tab),
            ("Ctrl+L", self._focus_address_bar),
            ("Ctrl+R", self.reload_or_stop),
            ("F5", self.reload_or_stop),
            ("Ctrl+F", self.find_bar.open_and_focus),
            ("Ctrl++", lambda: self._adjust_zoom(0.1)),
            ("Ctrl+=", lambda: self._adjust_zoom(0.1)),
            ("Ctrl+-", lambda: self._adjust_zoom(-0.1)),
            ("Ctrl+0", self._reset_zoom),
            ("Ctrl+D", self._open_bookmark_dialog),
            ("Ctrl+H", lambda: self.new_tab("verriere://history")),
            ("Ctrl+J", lambda: self.new_tab("verriere://downloads")),
            ("Ctrl+Shift+N", self.app_controller.open_private_window),
            ("Alt+Left", self.go_back),
            ("Alt+Right", self.go_forward),
            ("F11", self._toggle_window_fullscreen),
            ("Escape", self._handle_escape),
        ]
        for seq, fn in bindings:
            sc = QShortcut(QKeySequence(seq), self)
            sc.activated.connect(fn)

    def _apply_theme_and_preferences(self) -> None:
        hc = bool(self._get_setting("high_contrast", False))
        self.setStyleSheet(build_stylesheet(high_contrast=hc, is_private=self.context.is_private))
        show_bm = bool(self._get_setting("show_bookmarks_bar", True))
        self.bookmarks_bar.setVisible(show_bm)
        self.assistant_sidebar.refresh_status()

    # ------------------------------------------------------------------
    # Menus : Profils & Barre des favoris
    # ------------------------------------------------------------------
    def _rebuild_profile_menu(self) -> None:
        self._profile_menu.clear()
        for prof in self.app_controller.registry.list_profiles():
            label = f"● {prof.name}" if (
                not self.context.is_private
                and self.context.profile_info
                and prof.id == self.context.profile_info.id
            ) else prof.name
            act = QAction(label, self)
            act.triggered.connect(lambda _=False, pid=prof.id: self.app_controller.open_profile_window(pid))
            self._profile_menu.addAction(act)

        self._profile_menu.addSeparator()
        act_new = QAction("Nouveau profil…", self)
        act_new.triggered.connect(self._create_new_profile_prompt)
        self._profile_menu.addAction(act_new)

        act_priv = QAction("Nouvelle fenêtre privée (Ctrl+Maj+N)", self)
        act_priv.triggered.connect(self.app_controller.open_private_window)
        self._profile_menu.addAction(act_priv)

        if not self.context.is_private:
            self._profile_menu.addSeparator()
            act_clear = QAction("Effacer les données de navigation…", self)
            act_clear.triggered.connect(self._open_clear_data_dialog)
            self._profile_menu.addAction(act_clear)

    def _create_new_profile_prompt(self) -> None:
        name, ok = QInputDialog.getText(
            self,
            "Nouveau profil",
            "Nom du profil (cookies, stockage et historique isolés) :",
        )
        if ok and name.strip():
            prof = self.app_controller.registry.create_profile(name.strip())
            self._rebuild_profile_menu()
            self.app_controller.open_profile_window(prof.id)

    def _rebuild_bookmarks_bar(self) -> None:
        while self.bm_layout.count():
            item = self.bm_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        lbl_fav = QPushButton("📁 Favoris")
        lbl_fav.setFlat(True)
        lbl_fav.setStyleSheet("border:none; font-size:12.5px; font-weight:600; padding:2px 6px;")
        lbl_fav.clicked.connect(lambda: self.navigate_active("verriere://bookmarks"))
        self.bm_layout.addWidget(lbl_fav)

        sep = QFrame()
        sep.setObjectName("HairlineV")
        self.bm_layout.addWidget(sep)

        if self.bookmarks is not None:
            for folder in self.bookmarks.list_folders(bar_only=True):
                btn = QToolButton()
                btn.setProperty("class", "BookmarkFolderBtn")
                btn.setText(f"📁 {folder.name}")
                btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
                menu = QMenu(btn)
                items = self.bookmarks.list_bookmarks(folder_id=folder.id)
                if not items:
                    empty_act = QAction("(Dossier vide)", menu)
                    empty_act.setEnabled(False)
                    menu.addAction(empty_act)
                else:
                    for bm in items:
                        act = QAction(bm.title, menu)
                        act.triggered.connect(lambda _=False, u=bm.url: self.navigate_active(u))
                        menu.addAction(act)
                btn.setMenu(menu)
                self.bm_layout.addWidget(btn)

        self.bm_layout.addStretch()

    # ------------------------------------------------------------------
    # Gestion des onglets avec identifiants stables
    # ------------------------------------------------------------------
    def new_tab(
        self,
        url: str = "verriere://newtab",
        workspace_id: str | None = None,
        activate: bool = True,
    ) -> TabRecord:
        ws_id = workspace_id or (
            self.workspaces.get_active_workspace_id() if self.workspaces else "private"
        )
        rec = self.tab_manager.create_tab(url=url, workspace_id=ws_id, activate=activate)
        self._mount_tab_widget(rec)
        if activate:
            self._activate_tab(rec.tab_id)
        return rec

    def _mount_tab_widget(self, rec: TabRecord) -> QWebEngineView:
        view = QWebEngineView(self)
        page = VerriereWebPage(self.web_profile, view, self, rec.tab_id)
        view.setPage(page)

        tab_id = rec.tab_id
        page.blocked_navigation.connect(
            lambda u, r, tid=tab_id: self._on_blocked_navigation(tid, u, r)
        )
        page.cert_error_detected.connect(
            lambda u, d, tid=tab_id: self._on_cert_error(tid, u, d)
        )
        page.fullScreenRequested.connect(
            lambda req, tid=tab_id: self._on_fullscreen_requested(tid, req)
        )
        if hasattr(page, "permissionRequested"):
            page.permissionRequested.connect(
                lambda perm, tid=tab_id: self._on_qt68_permission_requested(tid, perm)
            )
        page.featurePermissionRequested.connect(
            lambda origin, feat, tid=tab_id: self._on_legacy_permission_requested(tid, origin, feat)
        )
        page.renderProcessTerminated.connect(
            lambda status, code, tid=tab_id: self._on_render_crash(tid, status, code)
        )

        view.urlChanged.connect(lambda qurl, tid=tab_id: self._on_view_url_changed(tid, qurl))
        view.titleChanged.connect(lambda title, tid=tab_id: self._on_view_title_changed(tid, title))
        view.loadStarted.connect(lambda tid=tab_id: self._on_view_load_started(tid))
        view.loadProgress.connect(lambda p, tid=tab_id: self._on_view_load_progress(tid, p))
        view.loadFinished.connect(lambda ok, tid=tab_id: self._on_view_load_finished(tid, ok))

        self._views[tab_id] = view
        self.view_stack.addWidget(view)

        tab_idx = self.tab_bar.addTab(rec.title or "Nouvel onglet")
        self.tab_bar.setTabData(tab_idx, tab_id)
        self.tab_bar.setTabIcon(
            tab_idx,
            _render_svg_icon(RESOURCES_DIR / "icons" / "verriere-logo.svg", 16),
        )

        if rec.url:
            view.setUrl(QUrl(rec.url))
        self._refresh_workspace_drawer()
        return view

    def open_controlled_popup_tab(self) -> QWebEnginePage:
        rec = self.new_tab(url="", activate=True)
        return self._views[rec.tab_id].page()

    def _tab_index_by_id(self, tab_id: str) -> int:
        for i in range(self.tab_bar.count()):
            if self.tab_bar.tabData(i) == tab_id:
                return i
        return -1

    def _activate_tab(self, tab_id: str) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        self.tab_manager.set_active_tab(tab_id)
        idx = self._tab_index_by_id(tab_id)
        if idx >= 0 and self.tab_bar.currentIndex() != idx:
            self.tab_bar.setCurrentIndex(idx)
        view = self._views.get(tab_id)
        if view is not None:
            self.view_stack.setCurrentWidget(view)
        self._sync_chrome_from_active_tab()

    def _on_tab_bar_changed(self, index: int) -> None:
        if index < 0:
            return
        tab_id = self.tab_bar.tabData(index)
        if tab_id and self.tab_manager.has_tab(tab_id):
            self._activate_tab(str(tab_id))

    def _on_tab_bar_moved(self, from_idx: int, to_idx: int) -> None:
        self.tab_manager.reorder_tab(from_idx, to_idx)
        self._refresh_workspace_drawer()

    def _on_tab_bar_close_requested(self, index: int) -> None:
        tab_id = self.tab_bar.tabData(index)
        if tab_id:
            self.close_tab(str(tab_id))

    def close_active_tab(self) -> None:
        if self.tab_manager.active_tab_id:
            self.close_tab(self.tab_manager.active_tab_id)

    def close_tab(self, tab_id: str) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        if self.tab_manager.tab_count <= 1:
            # Garder une fenêtre fluide : réinitialiser vers Nouvel onglet plutôt que disparaître brutalement
            self.navigate_active("verriere://newtab")
            return
        next_id = self.tab_manager.close_tab(tab_id)
        idx = self._tab_index_by_id(tab_id)
        if idx >= 0:
            self.tab_bar.removeTab(idx)
        view = self._views.pop(tab_id, None)
        if view is not None:
            self.view_stack.removeWidget(view)
            view.deleteLater()
        if next_id:
            self._activate_tab(next_id)
        self._refresh_workspace_drawer()

    def reopen_closed_tab(self) -> None:
        rec = self.tab_manager.reopen_last_closed()
        if rec is not None:
            self._mount_tab_widget(rec)
            self._activate_tab(rec.tab_id)

    def _on_tab_context_menu(self, pos: QPoint) -> None:
        idx = self.tab_bar.tabAt(pos)
        if idx < 0:
            return
        tab_id = str(self.tab_bar.tabData(idx))
        menu = QMenu(self)
        act_dup = QAction("Dupliquer l'onglet", menu)
        act_dup.triggered.connect(lambda: self._duplicate_tab(tab_id))
        act_reopen = QAction("Rouvrir le dernier onglet fermé", menu)
        act_reopen.triggered.connect(self.reopen_closed_tab)
        act_move = QAction("Déplacer vers une nouvelle fenêtre", menu)
        act_move.triggered.connect(lambda: self._move_tab_to_new_window(tab_id))
        act_close = QAction("Fermer l'onglet", menu)
        act_close.triggered.connect(lambda: self.close_tab(tab_id))
        menu.addAction(act_dup)
        menu.addAction(act_reopen)
        menu.addAction(act_move)
        menu.addSeparator()
        menu.addAction(act_close)
        menu.exec(self.tab_bar.mapToGlobal(pos))

    def _duplicate_tab(self, tab_id: str) -> None:
        dup = self.tab_manager.duplicate_tab(tab_id)
        if dup is not None:
            self._mount_tab_widget(dup)
            self._activate_tab(dup.tab_id)

    def _move_tab_to_new_window(self, tab_id: str) -> None:
        snapshot = self.tab_manager.detach_tab(tab_id)
        if snapshot is None:
            return
        idx = self._tab_index_by_id(tab_id)
        if idx >= 0:
            self.tab_bar.removeTab(idx)
        view = self._views.pop(tab_id, None)
        if view is not None:
            self.view_stack.removeWidget(view)
            view.deleteLater()
        if self.tab_manager.tab_count == 0:
            self.new_tab("verriere://newtab")
        elif self.tab_manager.active_tab_id:
            self._activate_tab(self.tab_manager.active_tab_id)

        new_win = self.app_controller.create_window_for_context(self.context, restore_tabs=False)
        # Remplacer l'onglet initial vide par l'onglet déplacé
        initial_id = new_win.tab_manager.active_tab_id
        new_win.new_tab(snapshot.url, workspace_id=snapshot.workspace_id, activate=True)
        if initial_id:
            new_win.close_tab(initial_id)
        new_win.show()

    # ------------------------------------------------------------------
    # Navigation, barre d'adresse et suggestions
    # ------------------------------------------------------------------
    def _active_view(self) -> QWebEngineView | None:
        tid = self.tab_manager.active_tab_id
        return self._views.get(tid) if tid else None

    def _focus_address_bar(self) -> None:
        self.address_input.setFocus()
        self.address_input.selectAll()

    def navigate_active(self, raw_input: str, typed: bool = False) -> None:
        self.suggestion_popup.hide()
        self.scheme_banner.hide()
        parsed = parse_address_input(raw_input)

        if parsed.kind == InputKind.EMPTY:
            return
        if parsed.kind in (InputKind.BLOCKED_SCHEME, InputKind.UNSUPPORTED_SCHEME):
            self.scheme_label.setText(parsed.reason)
            self.scheme_banner.show()
            return

        target_url = parsed.normalized_url
        if parsed.kind == InputKind.SEARCH:
            if self.search_manager is not None:
                target_url, _ = self.search_manager.build_search_url(parsed.search_query)
            else:
                from verriere.search.providers import SearchProvider

                qwant = SearchProvider("qwant", "Qwant", "https://www.qwant.com/?q={query}&l=fr")
                target_url = qwant.build_search_url(parsed.search_query)

        view = self._active_view()
        if view is None:
            self.new_tab(target_url)
            return
        tid = self.tab_manager.active_tab_id
        if tid:
            self._pending_cert_errors.pop(tid, None)
            self.tab_manager.update_tab(tid, crashed=False, cert_error="")
        view.setUrl(QUrl(target_url))
        if typed and not self.context.is_private and parsed.kind in (InputKind.URL, InputKind.INTERNAL):
            self.history.record_visit(target_url, title=parsed.display_host or target_url, typed=True)

    def _on_address_submitted(self) -> None:
        self.suggestions.cancel_pending()
        self.navigate_active(self.address_input.text(), typed=True)

    def _on_address_text_edited(self, text: str) -> None:
        if self.address_input.is_composing:
            return
        if not text.strip():
            self.suggestions.cancel_pending()
            self.suggestion_popup.hide()
            return
        self.suggestions.request_suggestions(
            text,
            on_results=lambda qid, items: self._show_suggestions_if_current(qid, items),
            debounce_seconds=0.15,
        )

    def _show_suggestions_if_current(self, query_id: int, items: list[AddressSuggestion]) -> None:
        # Protège contre toute réponse obsolète
        if query_id != self.suggestions.current_query_id():
            return
        # Retour au thread GUI via QApplication.instance() si appelé depuis Timer
        from PySide6.QtCore import QTimer

        QTimer.singleShot(0, lambda: self._render_suggestions_popup(query_id, items))

    def _render_suggestions_popup(self, query_id: int, items: list[AddressSuggestion]) -> None:
        if query_id != self.suggestions.current_query_id() or not items:
            self.suggestion_popup.hide()
            return
        self.suggestion_popup.clear()
        for sug in items:
            item = QListWidgetItem(f"[{sug.source_label_fr}]  {sug.title} — {sug.url}")
            item.setData(Qt.ItemDataRole.UserRole, sug.url)
            self.suggestion_popup.addItem(item)
        box = self.address_input.parentWidget()
        if box is not None:
            pos = box.mapToGlobal(QPoint(0, box.height() + 2))
            self.suggestion_popup.setGeometry(pos.x(), pos.y(), box.width(), min(240, len(items) * 32 + 8))
            self.suggestion_popup.show()

    def _on_suggestion_clicked(self, item: QListWidgetItem) -> None:
        url = str(item.data(Qt.ItemDataRole.UserRole) or "")
        self.suggestion_popup.hide()
        if url:
            self.navigate_active(url, typed=True)

    def go_back(self) -> None:
        view = self._active_view()
        if view is not None and view.history().canGoBack():
            view.back()

    def go_forward(self) -> None:
        view = self._active_view()
        if view is not None and view.history().canGoForward():
            view.forward()

    def reload_or_stop(self) -> None:
        view = self._active_view()
        if view is None or not self.tab_manager.active_tab_id:
            return
        rec = self.tab_manager.get_tab(self.tab_manager.active_tab_id)
        if rec and rec.is_loading:
            view.stop()
        else:
            view.reload()

    def _adjust_zoom(self, delta: float) -> None:
        view = self._active_view()
        tid = self.tab_manager.active_tab_id
        if view is None or not tid:
            return
        new_zoom = max(0.25, min(3.0, round(view.zoomFactor() + delta, 2)))
        view.setZoomFactor(new_zoom)
        self.tab_manager.update_tab(tid, zoom_factor=new_zoom)
        self.btn_zoom.setText(format_percent_fr(new_zoom * 100.0))

    def _reset_zoom(self) -> None:
        view = self._active_view()
        tid = self.tab_manager.active_tab_id
        if view is None or not tid:
            return
        view.setZoomFactor(1.0)
        self.tab_manager.update_tab(tid, zoom_factor=1.0)
        self.btn_zoom.setText("100 %")

    def _copy_current_url(self) -> None:
        if not self.tab_manager.active_tab_id:
            return
        rec = self.tab_manager.get_tab(self.tab_manager.active_tab_id)
        if rec is not None:
            QApplication.clipboard().setText(rec.url)

    def _on_find_in_page(self, text: str, forward: bool) -> None:
        view = self._active_view()
        if view is None:
            return
        flags = QWebEnginePage.FindFlag(0) if forward else QWebEnginePage.FindFlag.FindBackward
        view.findText(text, flags)

    def _clear_find_highlight(self) -> None:
        view = self._active_view()
        if view is not None:
            view.findText("")

    # ------------------------------------------------------------------
    # Signaux de QWebEngineView avec vérification d'identifiant d'onglet
    # ------------------------------------------------------------------
    def _on_view_url_changed(self, tab_id: str, qurl: QUrl) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        url_str = qurl.toString()
        view = self._views.get(tab_id)
        can_back = view.history().canGoBack() if view else False
        can_fwd = view.history().canGoForward() if view else False
        self.tab_manager.update_tab(
            tab_id,
            url=url_str,
            can_go_back=can_back,
            can_go_forward=can_fwd,
        )
        if tab_id == self.tab_manager.active_tab_id:
            self._sync_chrome_from_active_tab()

    def _on_view_title_changed(self, tab_id: str, title: str) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        clean_title = title.strip() or "Nouvel onglet"
        self.tab_manager.update_tab(tab_id, title=clean_title)
        idx = self._tab_index_by_id(tab_id)
        if idx >= 0:
            self.tab_bar.setTabText(idx, clean_title)
        self._refresh_workspace_drawer()

    def _on_view_load_started(self, tab_id: str) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        self.tab_manager.update_tab(tab_id, is_loading=True, progress=10)
        if tab_id == self.tab_manager.active_tab_id:
            self._sync_chrome_from_active_tab()

    def _on_view_load_progress(self, tab_id: str, progress: int) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        self.tab_manager.update_tab(tab_id, progress=progress)
        if tab_id == self.tab_manager.active_tab_id:
            self.load_progress.setValue(progress)
            self.load_progress.setVisible(0 < progress < 100)

    def _on_view_load_finished(self, tab_id: str, ok: bool) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        view = self._views.get(tab_id)
        if view is None:
            return
        url_str = view.url().toString()
        title = view.title() or url_str
        can_back = view.history().canGoBack()
        can_fwd = view.history().canGoForward()
        self.tab_manager.update_tab(
            tab_id,
            url=url_str,
            title=title,
            is_loading=False,
            progress=100,
            can_go_back=can_back,
            can_go_forward=can_fwd,
        )
        if ok and not self.context.is_private and not url_str.startswith("verriere://error"):
            self.history.record_visit(url_str, title=title)
        elif not ok and tab_id not in self._pending_cert_errors and url_str not in ("", "about:blank"):
            err_url = (
                "verriere://error?"
                f"title={quote('Impossible de charger la page')}&"
                f"message={quote('La page demandée n’a pas pu être atteinte ou la connexion a été interrompue.')}&"
                f"target={quote(url_str)}"
            )
            view.setUrl(QUrl(err_url))

        if tab_id == self.tab_manager.active_tab_id:
            self._sync_chrome_from_active_tab()

    def _on_blocked_navigation(self, tab_id: str, target_url: str, reason: str) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        self.scheme_label.setText(f"{reason} ({target_url})")
        self.scheme_banner.show()

    def _on_cert_error(self, tab_id: str, target_url: str, description: str) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        self._pending_cert_errors[tab_id] = description
        self.tab_manager.update_tab(tab_id, cert_error=description)
        view = self._views.get(tab_id)
        if view is not None:
            msg = (
                f"Verrière refuse d'ouvrir cette adresse car le certificat de sécurité est invalide : "
                f"{description}. Aucune dérogation automatique n'est appliquée."
            )
            err_url = (
                "verriere://error?"
                f"title={quote('Connexion refusée : erreur de certificat')}&"
                f"message={quote(msg)}&"
                f"target={quote(target_url)}"
            )
            view.setUrl(QUrl(err_url))
        if tab_id == self.tab_manager.active_tab_id:
            self._sync_chrome_from_active_tab()

    def _on_render_crash(self, tab_id: str, _status: Any, exit_code: int) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        rec = self.tab_manager.get_tab(tab_id)
        target_url = rec.url if rec else "verriere://newtab"
        self.tab_manager.update_tab(tab_id, crashed=True, is_loading=False)
        view = self._views.get(tab_id)
        if view is not None:
            msg = (
                f"Le processus de rendu de cette page a été interrompu (code {exit_code}). "
                "Les autres onglets restent isolés et fonctionnels."
            )
            err_url = (
                "verriere://error?"
                f"title={quote('L’onglet s’est arrêté de façon inattendue')}&"
                f"message={quote(msg)}&"
                f"target={quote(target_url)}"
            )
            view.setUrl(QUrl(err_url))

    def _sync_chrome_from_active_tab(self) -> None:
        tid = self.tab_manager.active_tab_id
        rec = self.tab_manager.get_tab(tid) if tid else None
        if rec is None:
            return
        self.btn_back.setEnabled(rec.can_go_back)
        self.btn_forward.setEnabled(rec.can_go_forward)
        self.btn_reload.setText("✕" if rec.is_loading else "↻")
        self.load_progress.setVisible(rec.is_loading and 0 < rec.progress < 100)

        if not self.address_input.hasFocus():
            self.address_input.setText(format_url_for_bar(rec.url))

        sec = describe_security_status(rec.url, cert_error=rec.cert_error)
        if sec.has_certificate_error:
            self.btn_security.setText("⚠")
        elif sec.is_internal or sec.is_encrypted:
            self.btn_security.setText("🛡")
        else:
            self.btn_security.setText("ⓘ")
        self.btn_security.setToolTip(f"{sec.label_fr} — {sec.origin}")

        is_bm = self.bookmarks is not None and self.bookmarks.find_by_url(rec.url) is not None
        self.btn_bookmark.setText("★" if is_bm else "☆")
        self.btn_zoom.setText(format_percent_fr(rec.zoom_factor * 100.0))

        self._set_active_sidebar(rec.url)
        ws_name = "Navigation privée"
        if self.workspaces is not None:
            active_ws = self.workspaces.get_active_workspace_id()
            ws = next((w for w in self.workspaces.list_workspaces() if w.id == active_ws), None)
            if ws is not None:
                ws_name = f"Espace : {ws.name}"
        self.footer_left.setText(f"Verrière · {self.context.display_name} · {ws_name}")

    # ------------------------------------------------------------------
    # Permissions, Plein écran, Favoris & Téléchargements
    # ------------------------------------------------------------------
    def _on_qt68_permission_requested(self, tab_id: str, permission: Any) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        origin = extract_origin(permission.origin().toString())
        ptype = str(permission.permissionType().name).lower()
        decision = self.permissions.get_decision(origin, ptype)
        if decision == PermissionDecision.ALLOW:
            permission.grant()
            return
        if decision == PermissionDecision.DENY:
            permission.deny()
            return
        self._pending_permission_obj = ("qt68", origin, ptype, permission)
        lbl = PERMISSION_LABELS_FR.get(ptype, ptype)
        self.perm_label.setText(f"Le site {origin} demande l'accès à : {lbl}")
        self.perm_banner.show()

    def _on_legacy_permission_requested(self, tab_id: str, origin_url: QUrl, feature: Any) -> None:
        if not self.tab_manager.has_tab(tab_id):
            return
        origin = extract_origin(origin_url.toString())
        ptype = str(feature.name).lower()
        decision = self.permissions.get_decision(origin, ptype)
        view = self._views.get(tab_id)
        if view is None:
            return
        if decision == PermissionDecision.ALLOW:
            view.page().setFeaturePermission(
                origin_url, feature, QWebEnginePage.PermissionPolicy.PermissionGrantedByUser
            )
            return
        if decision == PermissionDecision.DENY:
            view.page().setFeaturePermission(
                origin_url, feature, QWebEnginePage.PermissionPolicy.PermissionDeniedByUser
            )
            return
        self._pending_permission_obj = ("legacy", origin, ptype, (view.page(), origin_url, feature))
        lbl = PERMISSION_LABELS_FR.get(ptype, ptype)
        self.perm_label.setText(f"Le site {origin} demande l'accès à : {lbl}")
        self.perm_banner.show()

    def _resolve_permission_prompt(self, allowed: bool) -> None:
        self.perm_banner.hide()
        pending = self._pending_permission_obj
        self._pending_permission_obj = None
        if not pending:
            return
        kind, origin, ptype, payload = pending
        decision = PermissionDecision.ALLOW if allowed else PermissionDecision.DENY
        self.permissions.set_decision(
            origin,
            ptype,
            decision,
            remember=self.perm_remember.isChecked() and not self.context.is_private,
        )
        if kind == "qt68":
            payload.grant() if allowed else payload.deny()
        else:
            page, origin_url, feature = payload
            policy = (
                QWebEnginePage.PermissionPolicy.PermissionGrantedByUser
                if allowed
                else QWebEnginePage.PermissionPolicy.PermissionDeniedByUser
            )
            page.setFeaturePermission(origin_url, feature, policy)

    def _on_fullscreen_requested(self, tab_id: str, request: Any) -> None:
        if not self.tab_manager.has_tab(tab_id):
            request.reject()
            return
        if not request.toggleOn():
            request.accept()
            self.fs_banner.hide()
            if self.isFullScreen():
                self.showNormal()
            return
        origin = extract_origin(request.origin().toString())
        self._pending_fullscreen_req = request
        self.fs_label.setText(f"Le site {origin} demande à afficher cette page en plein écran.")
        self.fs_banner.show()

    def _resolve_fullscreen_prompt(self, allowed: bool) -> None:
        self.fs_banner.hide()
        req = self._pending_fullscreen_req
        self._pending_fullscreen_req = None
        if req is None:
            return
        if allowed:
            req.accept()
            self.showFullScreen()
        else:
            req.reject()

    def _toggle_window_fullscreen(self) -> None:
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def _handle_escape(self) -> None:
        if self.suggestion_popup.isVisible():
            self.suggestion_popup.hide()
            return
        if self.find_bar.isVisible():
            self.find_bar._close()
            return
        if self.isFullScreen():
            self.showNormal()

    def _show_security_dialog(self) -> None:
        tid = self.tab_manager.active_tab_id
        rec = self.tab_manager.get_tab(tid) if tid else None
        if rec is None:
            return
        status = describe_security_status(rec.url, cert_error=rec.cert_error)
        dlg = OriginSecurityDialog(status, self.permissions, self)
        dlg.exec()

    def _open_bookmark_dialog(self) -> None:
        if self.bookmarks is None:
            QMessageBox.information(
                self,
                "Favoris en session privée",
                "L'enregistrement de nouveaux favoris n'est pas disponible depuis une fenêtre privée.",
            )
            return
        tid = self.tab_manager.active_tab_id
        rec = self.tab_manager.get_tab(tid) if tid else None
        if rec is None:
            return
        folders = [(f.id, f.name) for f in self.bookmarks.list_folders()]
        dlg = BookmarkEditDialog(rec.title, rec.url, folders, parent=self)
        if dlg.exec():
            try:
                self.bookmarks.add_bookmark(
                    dlg.title_input.text(),
                    dlg.url_input.text(),
                    folder_id=dlg.folder_combo.currentData(),
                )
                self._rebuild_bookmarks_bar()
                self._sync_chrome_from_active_tab()
            except ValueError as exc:
                QMessageBox.warning(self, "Favori invalide", str(exc))

    def _on_download_requested(self, request: Any) -> None:
        self.downloads.handle_qt_download(request)

    def _open_clear_data_dialog(self) -> None:
        dlg = ClearDataDialog(self)
        if dlg.exec():
            self.context.clear_browsing_data(
                clear_history=dlg.chk_history.isChecked(),
                clear_cookies=dlg.chk_cookies.isChecked(),
                clear_cache=dlg.chk_cache.isChecked(),
                clear_site_storage=dlg.chk_storage.isChecked(),
            )
            if self.tab_manager.active_tab_id:
                rec = self.tab_manager.get_tab(self.tab_manager.active_tab_id)
                if rec and rec.url.startswith("verriere://history"):
                    self.reload_or_stop()

    # ------------------------------------------------------------------
    # Espaces de travail & Assistant optionnel
    # ------------------------------------------------------------------
    def _toggle_workspace_drawer(self) -> None:
        visible = not self.workspace_drawer.isVisible()
        self.workspace_drawer.setVisible(visible)
        if visible:
            self._refresh_workspace_drawer()
        self._sync_chrome_from_active_tab()

    def _refresh_workspace_drawer(self) -> None:
        active_ws = self.workspaces.get_active_workspace_id() if self.workspaces else "private"
        tabs = [(t.tab_id, t.title, t.workspace_id) for t in self.tab_manager.list_tabs()]
        self.workspace_drawer.refresh(active_ws, tabs)

    def _switch_workspace(self, workspace_id: str) -> None:
        if self.workspaces is None:
            return
        self.workspaces.set_active_workspace(workspace_id)
        ws_tabs = self.tab_manager.list_tabs(workspace_id=workspace_id)
        if ws_tabs:
            self._activate_tab(ws_tabs[0].tab_id)
        else:
            self.new_tab("verriere://newtab", workspace_id=workspace_id)
        self._refresh_workspace_drawer()
        self._sync_chrome_from_active_tab()

    def _create_workspace(self, name: str) -> None:
        if self.workspaces is None:
            return
        ws = self.workspaces.create_workspace(name)
        self._switch_workspace(ws.id)

    def _toggle_assistant(self) -> None:
        self.assistant_sidebar.refresh_status()
        self.assistant_sidebar.setVisible(not self.assistant_sidebar.isVisible())

    def _extract_for_assistant(self, selection_only: bool) -> None:
        view = self._active_view()
        tid = self.tab_manager.active_tab_id
        rec = self.tab_manager.get_tab(tid) if tid else None
        if view is None or rec is None:
            return

        if selection_only:
            text = view.selectedText()
            preview = self.assistant_service.prepare_preview(
                page_url=rec.url,
                page_title=rec.title,
                extracted_text=text,
                selection_only=True,
                is_private_tab=self.context.is_private,
            )
            self.assistant_sidebar.set_preview(preview)
            return

        # Extraction contrôlée hors champs cachés et mots de passe
        js = (
            "(() => {"
            "const clone = document.body ? document.body.cloneNode(true) : null;"
            "if (!clone) return '';"
            "clone.querySelectorAll('input[type=\"password\"], input[type=\"hidden\"], script, style').forEach(el => el.remove());"
            "return (clone.innerText || '').trim();"
            "})()"
        )

        def _on_text(extracted: Any) -> None:
            preview = self.assistant_service.prepare_preview(
                page_url=rec.url,
                page_title=rec.title,
                extracted_text=str(extracted or ""),
                selection_only=False,
                is_private_tab=self.context.is_private,
            )
            self.assistant_sidebar.set_preview(preview)

        view.page().runJavaScript(js, _on_text)

    # ------------------------------------------------------------------
    # Actions internes authentifiées par nonce de session
    # ------------------------------------------------------------------
    def _handle_internal_action(self, op: str, params: dict[str, list[str]]) -> str | None:
        db = self.context.db
        if op == "search":
            q = params.get("q", [""])[0]
            if self.search_manager is not None and q.strip():
                url, _ = self.search_manager.build_search_url(q)
                return url
            return "verriere://newtab"

        if op == "switch_workspace":
            ws_id = params.get("id", [""])[0]
            if self.workspaces is not None and ws_id:
                self.workspaces.set_active_workspace(ws_id)
                self._refresh_workspace_drawer()
                self._sync_chrome_from_active_tab()
            return "verriere://newtab"

        if op == "add_shortcut" and db is not None:
            title = params.get("title", [""])[0].strip()
            url = params.get("url", [""])[0].strip()
            icon = params.get("icon", ["globe"])[0]
            parsed = parse_address_input(url)
            if title and parsed.kind in (InputKind.URL, InputKind.INTERNAL):
                import uuid

                pos = db.connection.execute(
                    "SELECT COALESCE(MAX(position), -1) FROM newtab_shortcuts"
                ).fetchone()[0]
                db.connection.execute(
                    "INSERT INTO newtab_shortcuts(id, title, url, icon, position) VALUES (?, ?, ?, ?, ?)",
                    (f"sc-{uuid.uuid4().hex[:8]}", title, parsed.normalized_url, icon, pos + 1),
                )
                db.connection.commit()
            return "verriere://newtab"

        if op == "delete_shortcut" and db is not None:
            sid = params.get("id", [""])[0]
            db.connection.execute("DELETE FROM newtab_shortcuts WHERE id = ?", (sid,))
            db.connection.commit()
            return "verriere://newtab"

        if op == "add_bookmark" and self.bookmarks is not None:
            title = params.get("title", [""])[0]
            url = params.get("url", [""])[0]
            fid = params.get("folder_id", [""])[0] or None
            try:
                self.bookmarks.add_bookmark(title, url, folder_id=fid)
                self._rebuild_bookmarks_bar()
            except ValueError:
                pass
            return "verriere://bookmarks"

        if op == "delete_bookmark" and self.bookmarks is not None:
            bid = params.get("id", [""])[0]
            self.bookmarks.delete_bookmark(bid)
            self._rebuild_bookmarks_bar()
            return "verriere://bookmarks"

        if op == "delete_history_item":
            raw_id = params.get("id", ["0"])[0]
            if raw_id.isdigit():
                self.history.delete_entries([int(raw_id)])
            return "verriere://history"

        if op == "open_clear_data":
            from PySide6.QtCore import QTimer

            QTimer.singleShot(0, self._open_clear_data_dialog)
            return "verriere://settings"

        if op == "open_download_folder":
            dl_id = params.get("id", [""])[0]
            folder = self.downloads.parent_folder(dl_id)
            if folder is not None and folder.exists():
                # Ouvre uniquement le dossier parent, n'exécute jamais le fichier téléchargé
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
            return "verriere://downloads"

        if op == "pause_download":
            self.downloads.pause(params.get("id", [""])[0])
            return "verriere://downloads"

        if op == "resume_download":
            self.downloads.resume(params.get("id", [""])[0])
            return "verriere://downloads"

        if op == "cancel_download":
            self.downloads.cancel(params.get("id", [""])[0])
            return "verriere://downloads"

        if op == "revoke_permission":
            origin = params.get("origin", [""])[0]
            ptype = params.get("ptype", [""])[0]
            if origin and ptype:
                self.permissions.revoke_permission(origin, ptype)
            return "verriere://settings"

        if op == "save_settings" and db is not None:
            db.set_setting("user_name", params.get("user_name", ["Camille"])[0].strip() or "Camille")
            db.set_setting("subtitle", params.get("subtitle", ["Une nouvelle perspective sur le Web."])[0])
            provider_id = params.get("default_search_provider_id", ["qwant"])[0]
            if self.search_manager is not None:
                eclair = params.get("eclair_endpoint", [""])[0].strip()
                ok, _ = validate_search_template(eclair)
                if ok:
                    self.search_manager.configure_eclair(eclair)
                self.search_manager.set_default_provider(provider_id)
            for chk_key in (
                "show_newtab_background",
                "show_bookmarks_bar",
                "restore_session_on_startup",
                "remote_suggestions_enabled",
                "high_contrast",
                "reduced_motion",
            ):
                db.set_setting(chk_key, params.get(chk_key, ["0"])[0] == "1")
            self._apply_theme_and_preferences()
            return "verriere://settings"

        if op == "save_assistant" and db is not None:
            enabled = params.get("assistant_enabled", ["0"])[0] == "1"
            endpoint = params.get("assistant_endpoint", [""])[0].strip()
            model = params.get("assistant_model", [""])[0].strip()
            if endpoint and not endpoint.startswith("https://"):
                endpoint = ""
            db.set_setting("assistant_enabled", enabled and bool(endpoint))
            db.set_setting("assistant_endpoint", endpoint)
            db.set_setting("assistant_model", model)
            self.assistant_sidebar.refresh_status()
            return "verriere://settings"

        return "verriere://newtab"

    # ------------------------------------------------------------------
    # Fermeture propre et confirmation
    # ------------------------------------------------------------------
    def closeEvent(self, event: Any) -> None:
        if not self._force_close:
            active_dl = any(
                d.state.value in ("in_progress", "paused") for d in self.downloads.list_downloads()
            )
            multi_tabs = self.tab_manager.tab_count > 1 and bool(
                self._get_setting("confirm_close_multiple_tabs", True)
            )
            if active_dl or multi_tabs:
                msg = (
                    "Des téléchargements sont encore en cours. Fermer cette fenêtre ?"
                    if active_dl
                    else f"Fermer cette fenêtre et ses {self.tab_manager.tab_count} onglets ?"
                )
                reply = QMessageBox.question(
                    self,
                    "Fermer la fenêtre Verrière",
                    msg,
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes,
                )
                if reply != QMessageBox.StandardButton.Yes:
                    event.ignore()
                    return

        self.tab_manager.save_session()
        for tid, view in list(self._views.items()):
            page = view.page()
            self.view_stack.removeWidget(view)
            view.stop()
            view.deleteLater()
            if page is not None:
                page.deleteLater()
        self._views.clear()
        QApplication.processEvents()
        self.app_controller.unregister_window(self)
        super().closeEvent(event)
