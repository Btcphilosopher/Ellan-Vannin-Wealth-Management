"""Boîtes de dialogue et panneaux natifs Qt pour Verrière."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from verriere.assistant.client import AssistantPreview, PageAssistantService
from verriere.permissions.manager import (
    PERMISSION_LABELS_FR,
    PermissionDecision,
    PermissionManager,
    SecurityStatus,
)
from verriere.workspaces.manager import WORKSPACE_ISOLATION_NOTICE, Workspace, WorkspaceManager


class ClearDataDialog(QDialog):
    """Dialogue de suppression sélective des données de navigation avec confirmation explicite."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Effacer les données de navigation")
        self.setModal(True)
        self.resize(470, 340)

        layout = QVBoxLayout(self)
        intro = QLabel(
            "Choisissez les catégories à effacer pour ce profil normal.\n"
            "• L'historique supprime uniquement la liste des pages visitées.\n"
            "• Les cookies déconnectent vos sessions Web.\n"
            "• Le cache et le stockage des sites effacent les ressources et données locales des sites."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        self.chk_history = QCheckBox("Historique de navigation (adresses visitées)")
        self.chk_history.setChecked(True)
        self.chk_cookies = QCheckBox("Cookies et données de connexion des sites")
        self.chk_cache = QCheckBox("Cache HTTP (images et fichiers temporaires)")
        self.chk_cache.setChecked(True)
        self.chk_storage = QCheckBox("Stockage local des sites et liens visités")

        for box in (self.chk_history, self.chk_cookies, self.chk_cache, self.chk_storage):
            layout.addWidget(box)

        buttons = QDialogButtonBox()
        btn_clear = buttons.addButton("Effacer les données sélectionnées", QDialogButtonBox.ButtonRole.AcceptRole)
        buttons.addButton("Annuler", QDialogButtonBox.ButtonRole.RejectRole)
        btn_clear.clicked.connect(self._confirm_and_accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _confirm_and_accept(self) -> None:
        if not any(
            [
                self.chk_history.isChecked(),
                self.chk_cookies.isChecked(),
                self.chk_cache.isChecked(),
                self.chk_storage.isChecked(),
            ]
        ):
            QMessageBox.information(
                self,
                "Aucune catégorie sélectionnée",
                "Sélectionnez au moins un type de données à effacer.",
            )
            return
        reply = QMessageBox.question(
            self,
            "Confirmer la suppression",
            "Cette action est irréversible pour les catégories sélectionnées. Continuer ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.accept()


class OriginSecurityDialog(QDialog):
    """Affiche l'état honnête de chiffrement et les permissions enregistrées pour l'origine."""

    def __init__(
        self,
        status: SecurityStatus,
        permissions: PermissionManager,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Sécurité et permissions du site")
        self.setModal(True)
        self.resize(460, 320)
        self._status = status
        self._permissions = permissions

        layout = QVBoxLayout(self)
        title = QLabel(f"<b>{status.label_fr}</b>")
        origin_lbl = QLabel(f"Origine : <code>{status.origin}</code>")
        origin_lbl.setTextFormat(Qt.TextFormat.RichText)
        detail = QLabel(status.detail_fr)
        detail.setWordWrap(True)

        layout.addWidget(title)
        layout.addWidget(origin_lbl)
        layout.addWidget(detail)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        layout.addWidget(sep)

        layout.addWidget(QLabel("<b>Permissions enregistrées pour cette origine :</b>"))
        self.perm_list = QListWidget()
        self._reload_perms()
        layout.addWidget(self.perm_list)

        row = QHBoxLayout()
        btn_revoke = QPushButton("Révoquer la permission sélectionnée")
        btn_revoke.clicked.connect(self._revoke_selected)
        btn_close = QPushButton("Fermer")
        btn_close.clicked.connect(self.accept)
        row.addWidget(btn_revoke)
        row.addStretch()
        row.addWidget(btn_close)
        layout.addLayout(row)

    def _reload_perms(self) -> None:
        self.perm_list.clear()
        items = self._permissions.list_permissions(self._status.origin)
        if not items:
            placeholder = QListWidgetItem("Aucune permission accordée ou refusée pour cette origine.")
            placeholder.setFlags(Qt.ItemFlag.NoItemFlags)
            self.perm_list.addItem(placeholder)
            return
        for perm in items:
            lbl = PERMISSION_LABELS_FR.get(perm.permission_type, perm.permission_type)
            dec = "Autorisé" if perm.decision == PermissionDecision.ALLOW else "Refusé"
            item = QListWidgetItem(f"{lbl} — {dec}")
            item.setData(Qt.ItemDataRole.UserRole, perm.permission_type)
            self.perm_list.addItem(item)

    def _revoke_selected(self) -> None:
        cur = self.perm_list.currentItem()
        if cur is None:
            return
        ptype = cur.data(Qt.ItemDataRole.UserRole)
        if ptype:
            self._permissions.revoke_permission(self._status.origin, str(ptype))
            self._reload_perms()


class FindInPageBar(QFrame):
    """Barre de recherche dans la page courante (Ctrl+F)."""

    find_requested = Signal(str, bool)
    closed = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("InlineBanner")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 4, 10, 4)

        self.input = QLineEdit()
        self.input.setPlaceholderText("Rechercher dans la page…")
        self.input.setAccessibleName("Rechercher dans la page")
        self.input.returnPressed.connect(lambda: self.find_requested.emit(self.input.text(), True))

        btn_prev = QPushButton("Précédent")
        btn_prev.clicked.connect(lambda: self.find_requested.emit(self.input.text(), False))
        btn_next = QPushButton("Suivant")
        btn_next.clicked.connect(lambda: self.find_requested.emit(self.input.text(), True))
        btn_close = QPushButton("Fermer")
        btn_close.clicked.connect(self._close)

        layout.addWidget(QLabel("Rechercher :"))
        layout.addWidget(self.input, 1)
        layout.addWidget(btn_prev)
        layout.addWidget(btn_next)
        layout.addWidget(btn_close)

    def open_and_focus(self) -> None:
        self.show()
        self.input.setFocus()
        self.input.selectAll()

    def _close(self) -> None:
        self.hide()
        self.closed.emit()


class WorkspaceDrawer(QWidget):
    """Panneau latéral de gestion des espaces et des onglets."""

    workspace_selected = Signal(str)
    workspace_created = Signal(str)
    tab_selected = Signal(str)
    move_tab_to_new_window = Signal(str)

    def __init__(self, workspaces: WorkspaceManager | None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("SideDrawer")
        self.setMinimumWidth(280)
        self.setMaximumWidth(320)
        self._workspaces = workspaces

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)

        header = QHBoxLayout()
        title = QLabel("<b>Mes espaces &amp; Onglets</b>")
        btn_close = QPushButton("×")
        btn_close.setFixedWidth(28)
        btn_close.setAccessibleName("Fermer le panneau des espaces")
        btn_close.clicked.connect(self.hide)
        header.addWidget(title)
        header.addStretch()
        header.addWidget(btn_close)
        layout.addLayout(header)

        notice = QLabel(WORKSPACE_ISOLATION_NOTICE)
        notice.setWordWrap(True)
        notice.setStyleSheet("font-size: 11.5px; color: #475569; padding: 4px 0 8px;")
        layout.addWidget(notice)

        self.ws_list = QListWidget()
        self.ws_list.itemClicked.connect(self._on_ws_clicked)
        layout.addWidget(self.ws_list, 1)

        add_row = QHBoxLayout()
        self.new_ws_input = QLineEdit()
        self.new_ws_input.setPlaceholderText("Nouvel espace…")
        btn_add = QPushButton("Créer")
        btn_add.clicked.connect(self._create_ws)
        add_row.addWidget(self.new_ws_input, 1)
        add_row.addWidget(btn_add)
        layout.addLayout(add_row)

        layout.addWidget(QLabel("<b>Onglets ouverts</b>"))
        self.tabs_list = QListWidget()
        self.tabs_list.itemClicked.connect(self._on_tab_clicked)
        layout.addWidget(self.tabs_list, 1)

        btn_move_win = QPushButton("Déplacer l'onglet actif vers une autre fenêtre")
        btn_move_win.clicked.connect(self._emit_move_tab)
        layout.addWidget(btn_move_win)

    def refresh(self, active_ws_id: str, tabs: list[tuple[str, str, str]]) -> None:
        self.ws_list.clear()
        if self._workspaces is not None:
            for ws in self._workspaces.list_workspaces():
                prefix = "● " if ws.id == active_ws_id else "○ "
                item = QListWidgetItem(f"{prefix}{ws.name}")
                item.setData(Qt.ItemDataRole.UserRole, ws.id)
                self.ws_list.addItem(item)
        else:
            item = QListWidgetItem("● Fenêtre privée")
            item.setData(Qt.ItemDataRole.UserRole, "private")
            self.ws_list.addItem(item)

        self.tabs_list.clear()
        for tid, title, ws_id in tabs:
            item = QListWidgetItem(title or "Nouvel onglet")
            item.setData(Qt.ItemDataRole.UserRole, tid)
            self.tabs_list.addItem(item)

    def _on_ws_clicked(self, item: QListWidgetItem) -> None:
        ws_id = item.data(Qt.ItemDataRole.UserRole)
        if ws_id and ws_id != "private":
            self.workspace_selected.emit(str(ws_id))

    def _create_ws(self) -> None:
        name = self.new_ws_input.text().strip()
        if name:
            self.new_ws_input.clear()
            self.workspace_created.emit(name)

    def _on_tab_clicked(self, item: QListWidgetItem) -> None:
        tid = item.data(Qt.ItemDataRole.UserRole)
        if tid:
            self.tab_selected.emit(str(tid))

    def _emit_move_tab(self) -> None:
        cur = self.tabs_list.currentItem()
        if cur is not None:
            self.move_tab_to_new_window.emit(str(cur.data(Qt.ItemDataRole.UserRole)))


class AssistantSidebar(QWidget):
    """Panneau latéral optionnel d'aide à la lecture (désactivé par défaut)."""

    request_page_extract = Signal(bool)  # selection_only

    def __init__(self, service: PageAssistantService, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("SideDrawer")
        self.setMinimumWidth(300)
        self.setMaximumWidth(350)
        self._service = service
        self._current_preview: AssistantPreview | None = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)

        header = QHBoxLayout()
        header.addWidget(QLabel("<b>Assistant de lecture</b>"))
        btn_close = QPushButton("×")
        btn_close.setFixedWidth(28)
        btn_close.clicked.connect(self.hide)
        header.addStretch()
        header.addWidget(btn_close)
        layout.addLayout(header)

        self.status_lbl = QLabel()
        self.status_lbl.setWordWrap(True)
        self.status_lbl.setStyleSheet("font-size: 12px; color: #475569;")
        layout.addWidget(self.status_lbl)

        btn_row = QHBoxLayout()
        self.btn_summarize = QPushButton("Préparer le résumé")
        self.btn_summarize.clicked.connect(lambda: self.request_page_extract.emit(False))
        self.btn_selection = QPushButton("Sur la sélection")
        self.btn_selection.clicked.connect(lambda: self.request_page_extract.emit(True))
        btn_row.addWidget(self.btn_summarize)
        btn_row.addWidget(self.btn_selection)
        layout.addLayout(btn_row)

        self.question_input = QLineEdit()
        self.question_input.setPlaceholderText("Question sur le texte extrait…")
        self.question_input.setText("Résume les points essentiels en français.")
        layout.addWidget(self.question_input)

        self.scope_lbl = QLabel("Aucun contenu préparé pour l'instant.")
        self.scope_lbl.setWordWrap(True)
        self.scope_lbl.setStyleSheet("font-size: 11.5px; color: #1E3A8A;")
        layout.addWidget(self.scope_lbl)

        self.btn_send = QPushButton("Envoyer au fournisseur configuré")
        self.btn_send.setEnabled(False)
        self.btn_send.clicked.connect(self._send_now)
        layout.addWidget(self.btn_send)

        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        self.output.setPlaceholderText("La réponse apparaîtra ici après votre validation explicite.")
        layout.addWidget(self.output, 1)
        self.refresh_status()

    def refresh_status(self) -> None:
        if self._service.is_configured():
            self.status_lbl.setText(
                "Prêt. Le contenu d'une page n'est transmis qu'après prévisualisation et confirmation."
            )
            self.btn_summarize.setEnabled(True)
            self.btn_selection.setEnabled(True)
        else:
            self.status_lbl.setText(
                "Désactivé : configurez un fournisseur HTTPS dans Réglages pour activer cette aide."
            )
            self.btn_summarize.setEnabled(False)
            self.btn_selection.setEnabled(False)
            self.btn_send.setEnabled(False)

    def set_preview(self, preview: AssistantPreview) -> None:
        self._current_preview = preview
        if preview.blocked_reason:
            self.scope_lbl.setText(preview.blocked_reason)
            self.btn_send.setEnabled(False)
            return
        self.scope_lbl.setText(
            f"Fournisseur : {preview.provider_label} ({preview.endpoint_origin})\n"
            f"Portée : {preview.scope_label_fr} ({preview.char_count} caractères)"
        )
        self.btn_send.setEnabled(True)

    def _send_now(self) -> None:
        if self._current_preview is None:
            return
        try:
            answer = self._service.send_explicit_request(
                self._current_preview, self.question_input.text()
            )
            self.output.setPlainText(answer)
        except Exception as exc:
            self.output.setPlainText(f"Erreur lors de l'appel au fournisseur : {exc}")


class BookmarkEditDialog(QDialog):
    """Dialogue rapide pour ajouter ou modifier un favori depuis la barre d'adresse."""

    def __init__(
        self,
        title: str,
        url: str,
        folders: list[tuple[str, str]],
        selected_folder_id: str | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Ajouter aux favoris")
        self.setModal(True)
        layout = QFormLayout(self)

        self.title_input = QLineEdit(title)
        self.url_input = QLineEdit(url)
        self.folder_combo = QComboBox()
        for fid, fname in folders:
            self.folder_combo.addItem(fname, fid)
        if selected_folder_id:
            idx = self.folder_combo.findData(selected_folder_id)
            if idx >= 0:
                self.folder_combo.setCurrentIndex(idx)

        layout.addRow("Nom :", self.title_input)
        layout.addRow("Adresse :", self.url_input)
        layout.addRow("Dossier :", self.folder_combo)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Enregistrer")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Annuler")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)
