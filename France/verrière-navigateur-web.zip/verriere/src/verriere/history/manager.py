"""Gestionnaire d'historique de navigation normal (jamais utilisé en navigation privée)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from verriere.application.locale_fr import utc_now_iso
from verriere.application.storage import ProfileDatabase


@dataclass(frozen=True)
class HistoryEntry:
    id: int
    url: str
    title: str
    visit_count: int
    visited_at: str
    typed: bool


class HistoryManager:
    """Enregistre et interroge l'historique des profils normaux uniquement."""

    def __init__(self, db: ProfileDatabase | None, is_private: bool = False) -> None:
        self._db = None if is_private else db
        self._is_private = is_private

    @property
    def is_recording_enabled(self) -> bool:
        return not self._is_private and self._db is not None

    def record_visit(self, url: str, title: str = "", typed: bool = False) -> None:
        """Enregistre une visite uniquement si la session n'est pas privée."""
        if not self.is_recording_enabled or self._db is None:
            return
        clean_url = url.strip()
        if not clean_url or clean_url == "about:blank":
            return
        clean_title = (title or clean_url).strip()
        now = utc_now_iso()
        existing = self._db.connection.execute(
            "SELECT id, visit_count FROM history_entries WHERE url = ? ORDER BY visited_at DESC LIMIT 1",
            (clean_url,),
        ).fetchone()
        if existing is not None:
            self._db.connection.execute(
                "UPDATE history_entries SET title = ?, visit_count = ?, visited_at = ?, typed = MAX(typed, ?) WHERE id = ?",
                (clean_title, existing["visit_count"] + 1, now, 1 if typed else 0, existing["id"]),
            )
        else:
            self._db.connection.execute(
                "INSERT INTO history_entries(url, title, visit_count, visited_at, typed) VALUES (?, ?, 1, ?, ?)",
                (clean_url, clean_title, now, 1 if typed else 0),
            )
        self._db.connection.commit()

    def search(
        self,
        query: str = "",
        date_filter: str = "all",
        limit: int = 200,
    ) -> list[HistoryEntry]:
        if not self.is_recording_enabled or self._db is None:
            return []
        clauses: list[str] = []
        params: list[object] = []

        if query.strip():
            like = f"%{query.strip()}%"
            clauses.append("(title LIKE ? OR url LIKE ?)")
            params.extend([like, like])

        cutoff = self._cutoff_for_filter(date_filter)
        if cutoff is not None:
            clauses.append("visited_at >= ?")
            params.append(cutoff)

        where = f"WHERE {' AND '.join(clauses)} " if clauses else ""
        params.append(limit)
        rows = self._db.connection.execute(
            f"SELECT id, url, title, visit_count, visited_at, typed FROM history_entries {where}"
            "ORDER BY visited_at DESC LIMIT ?",
            params,
        ).fetchall()
        return [
            HistoryEntry(
                id=row["id"],
                url=row["url"],
                title=row["title"],
                visit_count=row["visit_count"],
                visited_at=row["visited_at"],
                typed=bool(row["typed"]),
            )
            for row in rows
        ]

    def delete_entries(self, entry_ids: list[int]) -> int:
        if not self.is_recording_enabled or self._db is None or not entry_ids:
            return 0
        placeholders = ",".join("?" for _ in entry_ids)
        cur = self._db.connection.execute(
            f"DELETE FROM history_entries WHERE id IN ({placeholders})",
            entry_ids,
        )
        self._db.connection.commit()
        return cur.rowcount

    def clear_history(self, date_filter: str = "all") -> int:
        if not self.is_recording_enabled or self._db is None:
            return 0
        cutoff = self._cutoff_for_filter(date_filter)
        if cutoff is None:
            cur = self._db.connection.execute("DELETE FROM history_entries")
        else:
            cur = self._db.connection.execute(
                "DELETE FROM history_entries WHERE visited_at >= ?",
                (cutoff,),
            )
        self._db.connection.commit()
        return cur.rowcount

    @staticmethod
    def _cutoff_for_filter(date_filter: str) -> str | None:
        now = datetime.now(timezone.utc)
        if date_filter == "today":
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            return start.isoformat(timespec="seconds")
        if date_filter == "week":
            return (now - timedelta(days=7)).isoformat(timespec="seconds")
        if date_filter == "month":
            return (now - timedelta(days=30)).isoformat(timespec="seconds")
        return None
