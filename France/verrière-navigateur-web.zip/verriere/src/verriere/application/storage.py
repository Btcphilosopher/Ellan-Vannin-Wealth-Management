"""Couche de persistance SQLite dédiée aux données applicatives d'un profil Verrière."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from verriere.application.locale_fr import utc_now_iso

SCHEMA_VERSION = 1

DEFAULT_BOOKMARK_FOLDERS = [
    ("folder-journal", "Le journal", 0),
    ("folder-culture", "Culture", 1),
    ("folder-sciences", "Sciences", 2),
    ("folder-voyages", "Voyages", 3),
    ("folder-travail", "Travail", 4),
]

DEFAULT_BOOKMARKS = [
    ("bm-1", "folder-journal", "Le Monde", "https://www.lemonde.fr", 0),
    ("bm-2", "folder-journal", "France Culture", "https://www.radiofrance.fr/franceculture", 1),
    ("bm-3", "folder-culture", "BnF — Gallica", "https://gallica.bnf.fr", 0),
    ("bm-4", "folder-culture", "Centre Pompidou", "https://www.centrepompidou.fr", 1),
    ("bm-5", "folder-sciences", "CNRS Le Journal", "https://lejournal.cnrs.fr", 0),
    ("bm-6", "folder-sciences", "Wikipédia en français", "https://fr.wikipedia.org", 1),
    ("bm-7", "folder-voyages", "Architecture contemporaine", "verriere://article/architecture-contemporaine", 0),
    ("bm-8", "folder-travail", "Documentation Qt WebEngine", "https://doc.qt.io/qt-6/qtwebengine-index.html", 0),
]

DEFAULT_WORKSPACES = [
    ("ws-personnel", "Personnel", "person", 0),
    ("ws-recherche", "Recherche", "search", 1),
    ("ws-voyages", "Voyages", "luggage", 2),
]

DEFAULT_SHORTCUTS = [
    ("sc-courrier", "Courrier", "https://mail.proton.me", "mail", 0),
    ("sc-agenda", "Agenda", "https://framagenda.org", "calendar", 1),
    ("sc-actualites", "Actualités", "https://www.lemonde.fr", "news", 2),
    ("sc-culture", "Culture", "https://gallica.bnf.fr", "culture", 3),
    ("sc-recherche", "Recherche", "verriere://newtab#search", "search", 4),
]

DEFAULT_READING_ITEMS = [
    (
        "read-ville-demain",
        "Construire la ville de demain",
        "verriere://article/architecture-contemporaine",
        "Verrière — Dossier d'architecture enregistré localement",
        "atrium",
    )
]

DEFAULT_SETTINGS = {
    "user_name": "Camille",
    "greeting_template": "Bonjour, {name}.",
    "subtitle": "Une nouvelle perspective sur le Web.",
    "show_newtab_background": True,
    "show_bookmarks_bar": True,
    "restore_session_on_startup": True,
    "confirm_close_multiple_tabs": True,
    "default_search_provider_id": "qwant",
    "eclair_endpoint": "",
    "remote_suggestions_enabled": False,
    "high_contrast": False,
    "reduced_motion": False,
    "ui_scale": 100,
    "default_zoom": 100,
    "home_url": "verriere://newtab",
    "active_workspace_id": "ws-recherche",
    "assistant_enabled": False,
    "assistant_provider": "openai_compatible",
    "assistant_endpoint": "",
    "assistant_model": "",
}


class ProfileDatabase:
    """Base SQLite par profil normal (jamais créée ni écrite pour les sessions privées)."""

    def __init__(self, db_path: Path | str) -> None:
        self.db_path = Path(db_path)
        if str(self.db_path) != ":memory:":
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON;")
        self._conn.execute("PRAGMA journal_mode = WAL;")
        self._init_schema()
        self._seed_defaults_if_empty()

    @property
    def connection(self) -> sqlite3.Connection:
        return self._conn

    def close(self) -> None:
        self._conn.close()

    def _init_schema(self) -> None:
        self._conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS schema_meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value_json TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS bookmark_folders (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                position INTEGER NOT NULL DEFAULT 0,
                in_bar INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS bookmarks (
                id TEXT PRIMARY KEY,
                folder_id TEXT REFERENCES bookmark_folders(id) ON DELETE SET NULL,
                title TEXT NOT NULL,
                url TEXT NOT NULL,
                position INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS history_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL,
                title TEXT NOT NULL,
                visit_count INTEGER NOT NULL DEFAULT 1,
                visited_at TEXT NOT NULL,
                typed INTEGER NOT NULL DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_history_visited_at ON history_entries(visited_at DESC);
            CREATE INDEX IF NOT EXISTS idx_history_url ON history_entries(url);

            CREATE TABLE IF NOT EXISTS workspaces (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                icon TEXT NOT NULL DEFAULT 'layers',
                position INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS tab_sessions (
                tab_id TEXT PRIMARY KEY,
                workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
                url TEXT NOT NULL,
                title TEXT NOT NULL,
                position INTEGER NOT NULL DEFAULT 0,
                is_active INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS closed_tabs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workspace_id TEXT NOT NULL,
                url TEXT NOT NULL,
                title TEXT NOT NULL,
                closed_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS downloads (
                id TEXT PRIMARY KEY,
                filename TEXT NOT NULL,
                source_url TEXT NOT NULL,
                destination_path TEXT NOT NULL,
                total_bytes INTEGER NOT NULL DEFAULT -1,
                received_bytes INTEGER NOT NULL DEFAULT 0,
                state TEXT NOT NULL,
                error_message TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS origin_permissions (
                origin TEXT NOT NULL,
                permission_type TEXT NOT NULL,
                decision TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (origin, permission_type)
            );

            CREATE TABLE IF NOT EXISTS search_providers (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                url_template TEXT NOT NULL,
                suggest_url_template TEXT NOT NULL DEFAULT '',
                is_builtin INTEGER NOT NULL DEFAULT 0,
                enabled INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS newtab_shortcuts (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                url TEXT NOT NULL,
                icon TEXT NOT NULL DEFAULT 'globe',
                position INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS reading_items (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                url TEXT NOT NULL,
                summary TEXT NOT NULL,
                preview_key TEXT NOT NULL DEFAULT 'atrium',
                saved_at TEXT NOT NULL
            );
            """
        )
        self._conn.execute(
            "INSERT OR REPLACE INTO schema_meta(key, value) VALUES (?, ?)",
            ("schema_version", str(SCHEMA_VERSION)),
        )
        self._conn.commit()

    def _seed_defaults_if_empty(self) -> None:
        now = utc_now_iso()
        cur = self._conn.cursor()

        # Settings
        for key, value in DEFAULT_SETTINGS.items():
            cur.execute(
                "INSERT OR IGNORE INTO settings(key, value_json) VALUES (?, ?)",
                (key, json.dumps(value, ensure_ascii=False)),
            )

        # Bookmark folders & bookmarks (seulement si la table des dossiers est vierge)
        folder_count = cur.execute("SELECT COUNT(*) FROM bookmark_folders").fetchone()[0]
        if folder_count == 0:
            for fid, name, pos in DEFAULT_BOOKMARK_FOLDERS:
                cur.execute(
                    "INSERT INTO bookmark_folders(id, name, position, in_bar, created_at) VALUES (?, ?, ?, 1, ?)",
                    (fid, name, pos, now),
                )
            for bid, fid, title, url, pos in DEFAULT_BOOKMARKS:
                cur.execute(
                    "INSERT INTO bookmarks(id, folder_id, title, url, position, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (bid, fid, title, url, pos, now),
                )

        # Workspaces
        ws_count = cur.execute("SELECT COUNT(*) FROM workspaces").fetchone()[0]
        if ws_count == 0:
            for wid, name, icon, pos in DEFAULT_WORKSPACES:
                cur.execute(
                    "INSERT INTO workspaces(id, name, icon, position, created_at) VALUES (?, ?, ?, ?, ?)",
                    (wid, name, icon, pos, now),
                )

        # Shortcuts
        sc_count = cur.execute("SELECT COUNT(*) FROM newtab_shortcuts").fetchone()[0]
        if sc_count == 0:
            for sid, title, url, icon, pos in DEFAULT_SHORTCUTS:
                cur.execute(
                    "INSERT INTO newtab_shortcuts(id, title, url, icon, position) VALUES (?, ?, ?, ?, ?)",
                    (sid, title, url, icon, pos),
                )

        # Saved reading items
        ri_count = cur.execute("SELECT COUNT(*) FROM reading_items").fetchone()[0]
        if ri_count == 0:
            for rid, title, url, summary, preview_key in DEFAULT_READING_ITEMS:
                cur.execute(
                    "INSERT INTO reading_items(id, title, url, summary, preview_key, saved_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (rid, title, url, summary, preview_key, now),
                )

        # Search providers
        sp_count = cur.execute("SELECT COUNT(*) FROM search_providers").fetchone()[0]
        if sp_count == 0:
            builtins = [
                ("qwant", "Qwant", "https://www.qwant.com/?q={query}&l=fr", "", 1, 1),
                ("duckduckgo", "DuckDuckGo", "https://duckduckgo.com/?q={query}&kl=fr-fr", "", 1, 1),
                ("startpage", "Startpage", "https://www.startpage.com/do/search?q={query}", "", 1, 1),
                ("wikipedia_fr", "Wikipédia (FR)", "https://fr.wikipedia.org/w/index.php?search={query}", "", 1, 1),
                ("eclair", "Éclair (non configuré)", "", "", 1, 1),
            ]
            cur.executemany(
                "INSERT INTO search_providers(id, name, url_template, suggest_url_template, is_builtin, enabled) VALUES (?, ?, ?, ?, ?, ?)",
                builtins,
            )

        self._conn.commit()

    def get_setting(self, key: str, default: Any = None) -> Any:
        row = self._conn.execute("SELECT value_json FROM settings WHERE key = ?", (key,)).fetchone()
        if row is None:
            return default
        return json.loads(row["value_json"])

    def set_setting(self, key: str, value: Any) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO settings(key, value_json) VALUES (?, ?)",
            (key, json.dumps(value, ensure_ascii=False)),
        )
        self._conn.commit()

    def get_all_settings(self) -> dict[str, Any]:
        rows = self._conn.execute("SELECT key, value_json FROM settings").fetchall()
        merged = dict(DEFAULT_SETTINGS)
        for row in rows:
            merged[row["key"]] = json.loads(row["value_json"])
        return merged
