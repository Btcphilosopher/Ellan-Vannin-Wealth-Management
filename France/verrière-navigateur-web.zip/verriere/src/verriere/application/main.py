"""Point d'entrée principal de VERRIÈRE — Navigateur Web."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from verriere import __app_name__, __organization__, __version__
from verriere.internal_pages.scheme import register_verriere_scheme


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="verriere",
        description="VERRIÈRE — Navigateur Web en français (PySide6 + Qt WebEngine)",
    )
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=None,
        help="Répertoire de stockage des profils Verrière.",
    )
    parser.add_argument(
        "--private",
        action="store_true",
        help="Ouvrir directement dans une fenêtre de navigation privée.",
    )
    parser.add_argument(
        "--url",
        type=str,
        default=None,
        help="Ouvrir une adresse au démarrage.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"{__app_name__} {__version__}",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_arg_parser()
    args, qt_args = parser.parse_known_args(argv)

    # Obligatoire : enregistrer le schéma verriere:// AVANT la création de QApplication
    register_verriere_scheme()

    from PySide6.QtWidgets import QApplication

    app = QApplication([sys.argv[0], *qt_args])
    app.setApplicationName(__app_name__)
    app.setOrganizationName(__organization__)
    app.setApplicationVersion(__version__)

    from verriere.application.browser_app import VerriereApplication

    controller = VerriereApplication(data_dir=args.data_dir)
    if args.private:
        win = controller.open_private_window()
    else:
        win = controller.open_initial_window()

    if args.url:
        win.navigate_active(args.url, typed=True)

    code = app.exec()
    controller.shutdown()
    return code


if __name__ == "__main__":
    raise SystemExit(main())
