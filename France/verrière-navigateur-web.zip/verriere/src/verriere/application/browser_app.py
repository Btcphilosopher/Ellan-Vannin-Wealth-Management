"""Contrôleur applicatif multi-fenêtres et multi-profils de Verrière."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QStandardPaths

from verriere.chrome.browser_window import VerriereWindow
from verriere.profiles.manager import ProfileContext, ProfileRegistry


def default_data_dir() -> Path:
    base = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
    if base:
        return Path(base)
    return Path.home() / ".local" / "share" / "verriere"


class VerriereApplication:
    """Orchestre les fenêtres normales, multi-profils et les sessions privées."""

    def __init__(self, data_dir: Path | str | None = None) -> None:
        self.data_dir = Path(data_dir) if data_dir is not None else default_data_dir()
        self.registry = ProfileRegistry(self.data_dir)
        self._contexts: dict[str, ProfileContext] = {}
        self.windows: list[VerriereWindow] = []

    def get_or_open_profile_context(self, profile_id: str) -> ProfileContext:
        if profile_id not in self._contexts:
            info = self.registry.get_profile(profile_id)
            pdir = self.registry.profile_dir(profile_id)
            db = self.registry.open_profile_database(profile_id)
            self._contexts[profile_id] = ProfileContext(
                profile_info=info,
                storage_dir=pdir,
                db=db,
                is_private=False,
            )
        return self._contexts[profile_id]

    def create_window_for_context(
        self,
        context: ProfileContext,
        restore_tabs: bool = True,
    ) -> VerriereWindow:
        win = VerriereWindow(self, context, restore_tabs=restore_tabs)
        self.windows.append(win)
        return win

    def open_initial_window(self) -> VerriereWindow:
        active = self.registry.get_active_profile()
        ctx = self.get_or_open_profile_context(active.id)
        win = self.create_window_for_context(ctx, restore_tabs=True)
        win.show()
        return win

    def open_profile_window(self, profile_id: str) -> VerriereWindow:
        self.registry.set_active_profile(profile_id)
        ctx = self.get_or_open_profile_context(profile_id)
        win = self.create_window_for_context(ctx, restore_tabs=True)
        win.show()
        return win

    def open_private_window(self) -> VerriereWindow:
        private_ctx = ProfileContext(
            profile_info=None,
            storage_dir=None,
            db=None,
            is_private=True,
        )
        win = self.create_window_for_context(private_ctx, restore_tabs=False)
        win.show()
        return win

    def unregister_window(self, window: VerriereWindow) -> None:
        if window in self.windows:
            self.windows.remove(window)

    def shutdown(self) -> None:
        for ctx in self._contexts.values():
            if ctx.db is not None:
                ctx.db.close()
        self._contexts.clear()
