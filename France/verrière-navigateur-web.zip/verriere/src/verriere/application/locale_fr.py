"""Utilitaires de localisation et formatage français (dates, heures, nombres, tailles)."""

from __future__ import annotations

from datetime import datetime, timezone

FRENCH_MONTHS = (
    "",
    "janvier",
    "février",
    "mars",
    "avril",
    "mai",
    "juin",
    "juillet",
    "août",
    "septembre",
    "octobre",
    "novembre",
    "décembre",
)

FRENCH_WEEKDAYS = (
    "lundi",
    "mardi",
    "mercredi",
    "jeudi",
    "vendredi",
    "samedi",
    "dimanche",
)


def format_number_fr(value: int | float, decimals: int = 0) -> str:
    """Formate un nombre selon les conventions typographiques françaises."""
    if decimals <= 0:
        formatted = f"{int(round(value)):,}"
        return formatted.replace(",", "\u202f")
    formatted = f"{value:,.{decimals}f}"
    integer_part, frac_part = formatted.split(".")
    integer_part = integer_part.replace(",", "\u202f")
    return f"{integer_part},{frac_part}"


def format_percent_fr(ratio_or_percent: float, is_ratio: bool = False) -> str:
    """Formate un pourcentage en français (ex. '42,5 %')."""
    val = ratio_or_percent * 100.0 if is_ratio else ratio_or_percent
    if float(val).is_integer():
        return f"{format_number_fr(val, 0)}\u202f%"
    return f"{format_number_fr(val, 1)}\u202f%"


def format_bytes_fr(num_bytes: int) -> str:
    """Formate une taille en octets selon les unités françaises (o, Ko, Mo, Go)."""
    if num_bytes < 0:
        return "Taille inconnue"
    if num_bytes < 1024:
        return f"{format_number_fr(num_bytes)}\u202fo"
    units = ("Ko", "Mo", "Go", "To")
    value = float(num_bytes) / 1024.0
    for unit in units[:-1]:
        if value < 1024.0:
            decimals = 0 if value >= 100 else 1
            return f"{format_number_fr(value, decimals)}\u202f{unit}"
        value /= 1024.0
    return f"{format_number_fr(value, 1)}\u202f{units[-1]}"


def parse_iso_datetime(iso_str: str) -> datetime | None:
    """Analyse une chaîne ISO 8601 en datetime local."""
    if not iso_str:
        return None
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        if dt.tzinfo is not None:
            dt = dt.astimezone()
        return dt
    except ValueError:
        return None


def format_date_fr(dt: datetime | str) -> str:
    """Formate une date en français (ex. '28 novembre 2026')."""
    if isinstance(dt, str):
        parsed = parse_iso_datetime(dt)
        if parsed is None:
            return dt
        dt = parsed
    return f"{dt.day} {FRENCH_MONTHS[dt.month]} {dt.year}"


def format_time_fr(dt: datetime | str) -> str:
    """Formate une heure en français (ex. '14 h 30')."""
    if isinstance(dt, str):
        parsed = parse_iso_datetime(dt)
        if parsed is None:
            return dt
        dt = parsed
    return f"{dt.hour:02d}\u202fh\u202f{dt.minute:02d}"


def format_datetime_fr(dt: datetime | str) -> str:
    """Formate une date et heure complètes en français."""
    if isinstance(dt, str):
        parsed = parse_iso_datetime(dt)
        if parsed is None:
            return dt
        dt = parsed
    return f"{format_date_fr(dt)} à {format_time_fr(dt)}"


def utc_now_iso() -> str:
    """Retourne l'horodatage UTC courant au format ISO 8601."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
