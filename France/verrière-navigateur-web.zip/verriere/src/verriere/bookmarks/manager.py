"""Gestionnaire de favoris et dossiers pour Verrière (SQLite + import/export sécurisé)."""

from __future__ import annotations

import html
import json
import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

from verriere.application.locale_fr import utc_now_iso
from verriere.application.storage import ProfileDatabase

ALLOWED_BOOKMARK_SCHEMES = frozenset({"http", "https", "verriere", "file"})
_NETSCAPE_LINK_RE = re.compile(
    r'<A\s+[^>]*HREF=["\']([^"\']+)["\'][^>]*>(.*?)</A>',
    re.IGNORECASE | re.DOTALL,
)


@dataclass(frozen=True)
class BookmarkFolder:
    id: str
    name: str
    position: int
    in_bar: bool


@dataclass(frozen=True)
class Bookmark:
    id: str
    folder_id: str | None
    title: str
    url: str
    position: int
    created_at: str


def is_safe_bookmark_url(url: str) -> bool:
    parsed = urlparse(url.strip())
    return parsed.scheme.lower() in ALLOWED_BOOKMARK_SCHEMES and (
        bool(parsed.netloc) or parsed.scheme.lower() == "file"
    )


class BookmarkManager:
    """CRUD, recherche et import/export des favoris d'un profil normal."""

    def __init__(self, db: ProfileDatabase) -> None:
        self._db = db

    def list_folders(self, bar_only: bool = False) -> list[BookmarkFolder]:
        sql = "SELECT id, name, position, in_bar FROM bookmark_folders "
        if bar_only:
            sql += "WHERE in_bar = 1 "
        sql += "ORDER BY position ASC, name ASC"
        rows = self._db.connection.execute(sql).fetchall()
        return [
            BookmarkFolder(
                id=row["id"],
                name=row["name"],
                position=row["position"],
                in_bar=bool(row["in_bar"]),
            )
            for row in rows
        ]

    def create_folder(self, name: str, in_bar: bool = True) -> BookmarkFolder:
        clean_name = name.strip() or "Nouveau dossier"
        folder_id = f"folder-{uuid.uuid4().hex[:10]}"
        max_pos = self._db.connection.execute(
            "SELECT COALESCE(MAX(position), -1) FROM bookmark_folders"
        ).fetchone()[0]
        self._db.connection.execute(
            "INSERT INTO bookmark_folders(id, name, position, in_bar, created_at) VALUES (?, ?, ?, ?, ?)",
            (folder_id, clean_name, max_pos + 1, 1 if in_bar else 0, utc_now_iso()),
        )
        self._db.connection.commit()
        return BookmarkFolder(id=folder_id, name=clean_name, position=max_pos + 1, in_bar=in_bar)

    def rename_folder(self, folder_id: str, new_name: str) -> None:
        clean = new_name.strip()
        if not clean:
            raise ValueError("Le nom du dossier ne peut pas être vide.")
        self._db.connection.execute(
            "UPDATE bookmark_folders SET name = ? WHERE id = ?",
            (clean, folder_id),
        )
        self._db.connection.commit()

    def delete_folder(self, folder_id: str) -> None:
        self._db.connection.execute("DELETE FROM bookmark_folders WHERE id = ?", (folder_id,))
        self._db.connection.commit()

    def list_bookmarks(self, folder_id: str | None = None, query: str = "") -> list[Bookmark]:
        clauses: list[str] = []
        params: list[str] = []
        if folder_id is not None:
            clauses.append("folder_id = ?")
            params.append(folder_id)
        if query.strip():
            like = f"%{query.strip()}%"
            clauses.append("(title LIKE ? OR url LIKE ?)")
            params.extend([like, like])
        where = f"WHERE {' AND '.join(clauses)} " if clauses else ""
        rows = self._db.connection.execute(
            f"SELECT id, folder_id, title, url, position, created_at FROM bookmarks {where}"
            "ORDER BY position ASC, created_at DESC",
            params,
        ).fetchall()
        return [
            Bookmark(
                id=row["id"],
                folder_id=row["folder_id"],
                title=row["title"],
                url=row["url"],
                position=row["position"],
                created_at=row["created_at"],
            )
            for row in rows
        ]

    def find_by_url(self, url: str) -> Bookmark | None:
        row = self._db.connection.execute(
            "SELECT id, folder_id, title, url, position, created_at FROM bookmarks WHERE url = ? LIMIT 1",
            (url.strip(),),
        ).fetchone()
        if row is None:
            return None
        return Bookmark(
            id=row["id"],
            folder_id=row["folder_id"],
            title=row["title"],
            url=row["url"],
            position=row["position"],
            created_at=row["created_at"],
        )

    def add_bookmark(self, title: str, url: str, folder_id: str | None = None) -> Bookmark:
        clean_url = url.strip()
        if not is_safe_bookmark_url(clean_url):
            raise ValueError("Seules les adresses http://, https://, verriere:// ou file:// peuvent être ajoutées aux favoris.")
        clean_title = title.strip() or clean_url
        bookmark_id = f"bm-{uuid.uuid4().hex[:10]}"
        max_pos = self._db.connection.execute(
            "SELECT COALESCE(MAX(position), -1) FROM bookmarks"
        ).fetchone()[0]
        now = utc_now_iso()
        self._db.connection.execute(
            "INSERT INTO bookmarks(id, folder_id, title, url, position, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            (bookmark_id, folder_id, clean_title, clean_url, max_pos + 1, now),
        )
        self._db.connection.commit()
        return Bookmark(
            id=bookmark_id,
            folder_id=folder_id,
            title=clean_title,
            url=clean_url,
            position=max_pos + 1,
            created_at=now,
        )

    def update_bookmark(
        self,
        bookmark_id: str,
        title: str | None = None,
        url: str | None = None,
        folder_id: str | None = ...,  # type: ignore[assignment]
    ) -> None:
        row = self._db.connection.execute("SELECT * FROM bookmarks WHERE id = ?", (bookmark_id,)).fetchone()
        if row is None:
            raise ValueError(f"Favori introuvable : {bookmark_id}")
        new_title = title.strip() if title is not None else row["title"]
        new_url = url.strip() if url is not None else row["url"]
        if not is_safe_bookmark_url(new_url):
            raise ValueError("Adresse de favori non autorisée.")
        new_folder = row["folder_id"] if folder_id is ... else folder_id
        self._db.connection.execute(
            "UPDATE bookmarks SET title = ?, url = ?, folder_id = ? WHERE id = ?",
            (new_title or new_url, new_url, new_folder, bookmark_id),
        )
        self._db.connection.commit()

    def delete_bookmark(self, bookmark_id: str) -> None:
        self._db.connection.execute("DELETE FROM bookmarks WHERE id = ?", (bookmark_id,))
        self._db.connection.commit()

    def export_json(self, destination: Path) -> Path:
        payload = {
            "application": "Verrière",
            "version": 1,
            "exported_at": utc_now_iso(),
            "folders": [
                {"id": f.id, "name": f.name, "position": f.position, "in_bar": f.in_bar}
                for f in self.list_folders()
            ],
            "bookmarks": [
                {
                    "id": b.id,
                    "folder_id": b.folder_id,
                    "title": b.title,
                    "url": b.url,
                    "position": b.position,
                }
                for b in self.list_bookmarks()
            ],
        }
        destination.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        return destination

    def export_html(self, destination: Path) -> Path:
        folders = {f.id: f.name for f in self.list_folders()}
        bookmarks = self.list_bookmarks()
        lines = [
            "<!DOCTYPE NETSCAPE-Bookmark-file-1>",
            '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">',
            "<TITLE>Favoris Verrière</TITLE>",
            "<H1>Favoris Verrière</H1>",
            "<DL><p>",
        ]
        grouped: dict[str | None, list[Bookmark]] = {}
        for bm in bookmarks:
            grouped.setdefault(bm.folder_id, []).append(bm)
        for fid, items in grouped.items():
            if fid and fid in folders:
                lines.append(f"  <DT><H3>{html.escape(folders[fid])}</H3>")
                lines.append("  <DL><p>")
                for bm in items:
                    lines.append(
                        f'    <DT><A HREF="{html.escape(bm.url, quote=True)}">{html.escape(bm.title)}</A>'
                    )
                lines.append("  </DL><p>")
            else:
                for bm in items:
                    lines.append(
                        f'  <DT><A HREF="{html.escape(bm.url, quote=True)}">{html.escape(bm.title)}</A>'
                    )
        lines.append("</DL><p>")
        destination.write_text("\n".join(lines), encoding="utf-8")
        return destination

    def import_file(self, source: Path) -> int:
        content = source.read_text(encoding="utf-8")
        imported = 0
        if source.suffix.lower() == ".json":
            data = json.loads(content)
            folder_map: dict[str, str] = {}
            for folder in data.get("folders", []):
                created = self.create_folder(str(folder.get("name", "Importé")), in_bar=bool(folder.get("in_bar", True)))
                if folder.get("id"):
                    folder_map[str(folder["id"])] = created.id
            for bm in data.get("bookmarks", []):
                url = str(bm.get("url", "")).strip()
                if not is_safe_bookmark_url(url):
                    continue
                target_folder = folder_map.get(str(bm.get("folder_id", "")))
                self.add_bookmark(str(bm.get("title", url)), url, folder_id=target_folder)
                imported += 1
            return imported

        # Netscape HTML fallback
        folder = self.create_folder("Importation HTML", in_bar=False)
        for raw_href, raw_title in _NETSCAPE_LINK_RE.findall(content):
            url = html.unescape(raw_href).strip()
            if not is_safe_bookmark_url(url):
                continue
            title = re.sub(r"<[^>]+>", "", html.unescape(raw_title)).strip() or url
            self.add_bookmark(title, url, folder_id=folder.id)
            imported += 1
        return imported
