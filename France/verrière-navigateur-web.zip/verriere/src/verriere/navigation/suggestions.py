"""Suggestions de barre d'adresse locales et opt-in distant avec annulation."""

from __future__ import annotations

import json
import threading
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Callable

from verriere.bookmarks.manager import BookmarkManager
from verriere.history.manager import HistoryManager
from verriere.search.providers import SearchEngineManager


@dataclass(frozen=True)
class AddressSuggestion:
    title: str
    url: str
    source: str  # "bookmark" | "history" | "typed" | "internal" | "remote"
    source_label_fr: str


INTERNAL_PAGES_SUGGESTIONS = [
    ("Nouvel onglet — Verrière", "verriere://newtab"),
    ("Favoris — Verrière", "verriere://bookmarks"),
    ("Historique — Verrière", "verriere://history"),
    ("Téléchargements — Verrière", "verriere://downloads"),
    ("Réglages — Verrière", "verriere://settings"),
]


class SuggestionEngine:
    """Agrège les suggestions locales autorisées et, si activées, distantes sans course."""

    def __init__(
        self,
        bookmarks: BookmarkManager | None,
        history: HistoryManager,
        search_manager: SearchEngineManager | None,
        remote_enabled_getter: Callable[[], bool] | None = None,
    ) -> None:
        self._bookmarks = bookmarks
        self._history = history
        self._search_manager = search_manager
        self._remote_enabled_getter = remote_enabled_getter or (lambda: False)
        self._lock = threading.Lock()
        self._latest_query_id = 0
        self._active_timer: threading.Timer | None = None

    def current_query_id(self) -> int:
        with self._lock:
            return self._latest_query_id

    def cancel_pending(self) -> int:
        """Invalide toute requête précédente et annule le minuteur de debounce."""
        with self._lock:
            self._latest_query_id += 1
            if self._active_timer is not None:
                self._active_timer.cancel()
                self._active_timer = None
            return self._latest_query_id

    def query_local(self, raw_text: str, limit: int = 8) -> list[AddressSuggestion]:
        q = raw_text.strip().lower()
        if not q:
            return []

        results: list[AddressSuggestion] = []
        seen_urls: set[str] = set()

        # 1. Pages internes Verrière
        for title, url in INTERNAL_PAGES_SUGGESTIONS:
            if q in title.lower() or q in url.lower():
                results.append(
                    AddressSuggestion(
                        title=title,
                        url=url,
                        source="internal",
                        source_label_fr="Page Verrière",
                    )
                )
                seen_urls.add(url)

        # 2. Favoris locaux
        if self._bookmarks is not None:
            for bm in self._bookmarks.list_bookmarks(query=raw_text)[:limit]:
                if bm.url not in seen_urls:
                    results.append(
                        AddressSuggestion(
                            title=bm.title,
                            url=bm.url,
                            source="bookmark",
                            source_label_fr="Favori",
                        )
                    )
                    seen_urls.add(bm.url)

        # 3. Historique normal (vide automatiquement en session privée)
        for entry in self._history.search(query=raw_text, limit=limit):
            if entry.url not in seen_urls:
                src = "typed" if entry.typed else "history"
                lbl = "Adresse saisie" if entry.typed else "Historique"
                results.append(
                    AddressSuggestion(
                        title=entry.title,
                        url=entry.url,
                        source=src,
                        source_label_fr=lbl,
                    )
                )
                seen_urls.add(entry.url)

        return results[:limit]

    def request_suggestions(
        self,
        raw_text: str,
        on_results: Callable[[int, list[AddressSuggestion]], None],
        debounce_seconds: float = 0.15,
    ) -> int:
        """Déclenche une recherche de suggestions débouncée et annulable."""
        query_id = self.cancel_pending()
        text = raw_text.strip()
        if not text:
            on_results(query_id, [])
            return query_id

        def _execute() -> None:
            if query_id != self.current_query_id():
                return
            items = self.query_local(text)
            if query_id != self.current_query_id():
                return
            on_results(query_id, items)

            # Suggestions distantes strictement opt-in
            if self._remote_enabled_getter() and self._search_manager is not None:
                provider = self._search_manager.get_default_provider()
                if provider.suggest_url_template and "{query}" in provider.suggest_url_template:
                    remote = self._fetch_remote_sync(provider.suggest_url_template, text)
                    if query_id == self.current_query_id() and remote:
                        merged = items + remote
                        on_results(query_id, merged[:10])

        if debounce_seconds <= 0:
            _execute()
            return query_id

        timer = threading.Timer(debounce_seconds, _execute)
        timer.daemon = True
        with self._lock:
            self._active_timer = timer
        timer.start()
        return query_id

    @staticmethod
    def _fetch_remote_sync(suggest_template: str, query: str) -> list[AddressSuggestion]:
        url = suggest_template.replace("{query}", urllib.parse.quote_plus(query))
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Verriere/0.1"})
            with urllib.request.urlopen(req, timeout=1.5) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            if isinstance(data, list) and len(data) >= 2 and isinstance(data[1], list):
                return [
                    AddressSuggestion(
                        title=str(term),
                        url=str(term),
                        source="remote",
                        source_label_fr="Suggestion distante",
                    )
                    for term in data[1][:4]
                ]
        except Exception:
            return []
        return []
