"""Analyse et validation des adresses URL et requêtes de recherche pour Verrière.

Règles documentées de distinction URL / recherche :
1. Les schémas dangereux (``javascript:``, ``vbscript:``, ``data:text/html`` en navigation
   principale, ``shell:``, ``cmd:``, ``ms-msdt:``) sont explicitement bloqués.
2. Les schémas internes autorisés sont ``verriere://`` (pages propres de l'application)
   et ``about:blank``.
3. Les schémas réseau autorisés sont ``http://`` et ``https://``.
4. Le schéma ``file://`` est traité explicitement (autorisé uniquement en saisie
   utilisateur directe ou test local explicite, jamais depuis un lien web externe).
5. Une saisie sans schéma contenant des espaces ou ne ressemblant pas à un hôte
   valide (IP, ``localhost``, ou nom avec TLD/port) est interprétée comme une
   requête de recherche confiée au moteur configuré.
6. Les hôtes IDN/Unicode sont vérifiés contre les mélanges de scripts suspects ;
   la destination réelle (schéma + hôte + port) est toujours conservée intacte
   sans masquage trompeur.
"""

from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from enum import Enum
from urllib.parse import quote, unquote, urlparse

BLOCKED_SCHEMES = frozenset(
    {
        "javascript",
        "vbscript",
        "data",
        "shell",
        "cmd",
        "ms-msdt",
        "jscript",
        "livescript",
    }
)

SUPPORTED_WEB_SCHEMES = frozenset({"http", "https"})
SUPPORTED_INTERNAL_SCHEMES = frozenset({"verriere"})
SUPPORTED_SPECIAL_SCHEMES = frozenset({"file", "about"})

_HOST_PORT_RE = re.compile(
    r"^(?P<host>[A-Za-z0-9\-\.\[\]:\u00C0-\u024F]+?)(?::(?P<port>\d{1,5}))?(?P<path>/.*)?$"
)
_SCHEME_PREFIX_RE = re.compile(r"^([a-zA-Z][a-zA-Z0-9+\-.]*):(.*)$")


class InputKind(str, Enum):
    INTERNAL = "internal"
    URL = "url"
    LOCAL_FILE = "local_file"
    SEARCH = "search"
    BLOCKED_SCHEME = "blocked_scheme"
    UNSUPPORTED_SCHEME = "unsupported_scheme"
    EMPTY = "empty"


@dataclass(frozen=True)
class ParsedNavigation:
    raw_input: str
    kind: InputKind
    normalized_url: str
    display_host: str
    search_query: str = ""
    scheme: str = ""
    reason: str = ""
    has_mixed_script_warning: bool = False


def _is_ip_literal(host: str) -> bool:
    stripped = host.strip("[]")
    try:
        ipaddress.ip_address(stripped)
        return True
    except ValueError:
        return False


def _looks_like_domain_or_host(candidate: str) -> bool:
    if not candidate or " " in candidate:
        return False
    match = _HOST_PORT_RE.match(candidate)
    if not match:
        return False
    host = match.group("host")
    port_str = match.group("port")
    if port_str is not None:
        port = int(port_str)
        if port < 1 or port > 65535:
            return False
    if host.lower() == "localhost":
        return True
    if _is_ip_literal(host):
        return True
    if "." not in host or host.startswith(".") or host.endswith(".") or ".." in host:
        return False
    labels = host.split(".")
    tld = labels[-1]
    if len(tld) < 2 or not any(ch.isalpha() for ch in tld):
        return False
    return all(bool(label) and not label.startswith("-") and not label.endswith("-") for label in labels)


def _check_mixed_script_host(host: str) -> bool:
    """Détecte les mélanges suspects ASCII + non-latin ou punycode dans un nom d'hôte."""
    if "xn--" in host.lower():
        return True
    has_ascii_alpha = any("a" <= c.lower() <= "z" for c in host)
    has_non_latin = any(ord(c) > 0x024F for c in host)
    return has_ascii_alpha and has_non_latin


def format_origin_for_display(url_str: str) -> tuple[str, str, bool]:
    """Retourne (origine_lisible, hôte_réel, alerte_idn) sans masquer le véritable hôte."""
    parsed = urlparse(url_str)
    scheme = parsed.scheme.lower()
    if scheme == "verriere":
        host = parsed.netloc or "newtab"
        return f"verriere://{host}", host, False
    if scheme == "file":
        return "file://", "Fichier local", False
    if scheme in ("http", "https"):
        host = parsed.hostname or ""
        try:
            ascii_host = host.encode("idna").decode("ascii") if host else ""
        except UnicodeError:
            ascii_host = host
        port_part = f":{parsed.port}" if parsed.port else ""
        origin = f"{scheme}://{ascii_host}{port_part}"
        return origin, f"{ascii_host}{port_part}", _check_mixed_script_host(host)
    return url_str, parsed.netloc or scheme, False


def parse_address_input(raw_input: str) -> ParsedNavigation:
    """Analyse une saisie de barre d'adresse selon les règles documentées de Verrière."""
    text = raw_input.strip()
    if not text:
        return ParsedNavigation(
            raw_input=raw_input,
            kind=InputKind.EMPTY,
            normalized_url="",
            display_host="",
        )

    # Chemin absolu Unix/Windows saisi directement -> fichier local explicite
    if text.startswith("/") and not text.startswith("//"):
        return ParsedNavigation(
            raw_input=raw_input,
            kind=InputKind.LOCAL_FILE,
            normalized_url=f"file://{quote(text)}",
            display_host="Fichier local",
            scheme="file",
        )

    scheme_match = _SCHEME_PREFIX_RE.match(text)
    if scheme_match:
        scheme = scheme_match.group(1).lower()
        rest = scheme_match.group(2)

        # Cas particulier `localhost:3000` ou `127.0.0.1:8080` où `localhost` ressemble à un schéma
        if rest and not rest.startswith("//") and rest.split("/")[0].isdigit() and (
            scheme == "localhost" or "." in scheme
        ):
            normalized = f"http://{text}"
            _, host, warn = format_origin_for_display(normalized)
            return ParsedNavigation(
                raw_input=raw_input,
                kind=InputKind.URL,
                normalized_url=normalized,
                display_host=host,
                scheme="http",
                has_mixed_script_warning=warn,
            )

        if scheme in BLOCKED_SCHEMES:
            return ParsedNavigation(
                raw_input=raw_input,
                kind=InputKind.BLOCKED_SCHEME,
                normalized_url="",
                display_host="",
                scheme=scheme,
                reason=f"Le schéma « {scheme}: » est bloqué par mesure de sécurité.",
            )

        if scheme in SUPPORTED_INTERNAL_SCHEMES:
            parsed = urlparse(text)
            host = (parsed.netloc or parsed.path.lstrip("/") or "newtab").lower()
            path = parsed.path if parsed.netloc else ""
            query = f"?{parsed.query}" if parsed.query else ""
            frag = f"#{parsed.fragment}" if parsed.fragment else ""
            normalized = f"verriere://{host}{path}{query}{frag}"
            return ParsedNavigation(
                raw_input=raw_input,
                kind=InputKind.INTERNAL,
                normalized_url=normalized,
                display_host=f"verriere://{host}",
                scheme="verriere",
            )

        if scheme in SUPPORTED_WEB_SCHEMES:
            parsed = urlparse(text)
            if not parsed.hostname:
                return ParsedNavigation(
                    raw_input=raw_input,
                    kind=InputKind.UNSUPPORTED_SCHEME,
                    normalized_url="",
                    display_host="",
                    scheme=scheme,
                    reason="L'adresse Web saisie ne contient aucun nom d'hôte valide.",
                )
            _, host, warn = format_origin_for_display(text)
            return ParsedNavigation(
                raw_input=raw_input,
                kind=InputKind.URL,
                normalized_url=text,
                display_host=host,
                scheme=scheme,
                has_mixed_script_warning=warn,
            )

        if scheme == "file":
            return ParsedNavigation(
                raw_input=raw_input,
                kind=InputKind.LOCAL_FILE,
                normalized_url=text,
                display_host="Fichier local",
                scheme="file",
            )

        if scheme == "about" and rest.lower() == "blank":
            return ParsedNavigation(
                raw_input=raw_input,
                kind=InputKind.INTERNAL,
                normalized_url="about:blank",
                display_host="about:blank",
                scheme="about",
            )

        # Tout autre schéma (mailto:, tel:, custom:, etc.) est signalé explicitement
        return ParsedNavigation(
            raw_input=raw_input,
            kind=InputKind.UNSUPPORTED_SCHEME,
            normalized_url="",
            display_host="",
            scheme=scheme,
            reason=(
                f"Le schéma « {scheme}: » n'est pas pris en charge directement par Verrière "
                "et ne peut pas lancer de commande système externe."
            ),
        )

    # Pas de schéma explicite : vérifier si c'est un nom de domaine / hôte / IP
    if _looks_like_domain_or_host(text):
        host_only = text.split("/", 1)[0].split(":", 1)[0].lower()
        default_scheme = "http" if host_only == "localhost" or _is_ip_literal(host_only) else "https"
        normalized = f"{default_scheme}://{text}"
        _, display_host, warn = format_origin_for_display(normalized)
        return ParsedNavigation(
            raw_input=raw_input,
            kind=InputKind.URL,
            normalized_url=normalized,
            display_host=display_host,
            scheme=default_scheme,
            has_mixed_script_warning=warn,
        )

    # Sinon : requête de recherche
    return ParsedNavigation(
        raw_input=raw_input,
        kind=InputKind.SEARCH,
        normalized_url="",
        display_host="",
        search_query=text,
    )


def format_url_for_bar(url_str: str) -> str:
    """Formate une URL pour la barre d'adresse en préservant le véritable hôte."""
    if not url_str:
        return ""
    parsed = urlparse(url_str)
    if parsed.scheme in ("http", "https") and parsed.hostname:
        try:
            ascii_host = parsed.hostname.encode("idna").decode("ascii")
        except UnicodeError:
            ascii_host = parsed.hostname
        if ascii_host != parsed.hostname:
            # Conserve le nom punycode réel pour éviter le spoofing visuel
            netloc = ascii_host + (f":{parsed.port}" if parsed.port else "")
            return parsed._replace(netloc=netloc).geturl()
    return unquote(url_str) if parsed.scheme == "verriere" else url_str
