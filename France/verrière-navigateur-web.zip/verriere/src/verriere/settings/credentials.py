"""Stockage des identifiants via le trousseau du système d'exploitation (keyring)."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

KEYRING_SERVICE_PREFIX = "org.verriere.navigateur"


class CredentialStore:
    """Enveloppe sûre autour de ``keyring`` sans écriture en clair dans SQLite."""

    def __init__(self, profile_id: str) -> None:
        self._service = f"{KEYRING_SERVICE_PREFIX}.{profile_id}"

    def is_backend_available(self) -> tuple[bool, str]:
        try:
            import keyring
            from keyring.backends import fail

            backend = keyring.get_keyring()
            if isinstance(backend, fail.Keyring):
                return False, "Aucun trousseau système actif détecté (environnement sans session)."
            return True, type(backend).__name__
        except Exception as exc:
            return False, str(exc)

    def set_secret(self, key_name: str, secret_value: str) -> bool:
        try:
            import keyring

            ok, _ = self.is_backend_available()
            if not ok:
                return False
            if not secret_value:
                self.delete_secret(key_name)
                return True
            keyring.set_password(self._service, key_name, secret_value)
            return True
        except Exception as exc:
            logger.warning("Impossible d'enregistrer le secret dans le trousseau : %s", exc)
            return False

    def get_secret(self, key_name: str) -> str | None:
        try:
            import keyring

            ok, _ = self.is_backend_available()
            if not ok:
                return None
            return keyring.get_password(self._service, key_name)
        except Exception:
            return None

    def delete_secret(self, key_name: str) -> bool:
        try:
            import keyring

            ok, _ = self.is_backend_available()
            if not ok:
                return False
            keyring.delete_password(self._service, key_name)
            return True
        except Exception:
            return False
