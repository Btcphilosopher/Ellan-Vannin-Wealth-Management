"""Vérification de manifestes de mise à jour signés (sans exécution arbitraire)."""

from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class UpdateManifest:
    version: str
    channel: str
    release_date: str
    package_url: str
    sha256: str
    signature_hex: str
    notes_fr: str


def compute_canonical_payload(manifest: UpdateManifest) -> bytes:
    payload = {
        "version": manifest.version,
        "channel": manifest.channel,
        "release_date": manifest.release_date,
        "package_url": manifest.package_url,
        "sha256": manifest.sha256,
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def verify_manifest_hmac(manifest: UpdateManifest, verification_key: bytes) -> bool:
    """Vérifie l'intégrité d'un manifeste de mise à jour (signature requise avant tout téléchargement)."""
    if not manifest.package_url.startswith("https://"):
        return False
    expected = hmac.new(
        verification_key,
        compute_canonical_payload(manifest),
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, manifest.signature_hex.lower())


def verify_package_sha256(package_path: Path, expected_sha256: str) -> bool:
    """Vérifie le condensat SHA-256 d'une archive téléchargée avant installation."""
    digest = hashlib.sha256()
    with package_path.open("rb") as fh:
        while chunk := fh.read(65536):
            digest.update(chunk)
    return hmac.compare_digest(digest.hexdigest().lower(), expected_sha256.strip().lower())
