"""Gestion des espaces de travail (regroupement visuel d'onglets au sein d'un profil).

Note importante : les espaces de travail organisent les onglets par thème
(Personnel, Recherche, Voyages, etc.). Ils partagent le même profil moteur
et ne fournissent PAS d'isolation des cookies ni des identités.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass

from verriere.application.locale_fr import utc_now_iso
from verriere.application.storage import ProfileDatabase

WORKSPACE_ISOLATION_NOTICE = (
    "Les espaces organisent vos onglets par contexte au sein d'un même profil. "
    "Ils n'isolent ni les cookies ni le stockage des sites : utilisez un profil "
    "distinct ou une fenêtre privée pour séparer vos identités."
)


@dataclass(frozen=True)
class Workspace:
    id: str
    name: str
    icon: str
    position: int


class WorkspaceManager:
    """CRUD des espaces de travail d'un profil Verrière."""

    def __init__(self, db: ProfileDatabase) -> None:
        self._db = db

    def list_workspaces(self) -> list[Workspace]:
        rows = self._db.connection.execute(
            "SELECT id, name, icon, position FROM workspaces ORDER BY position ASC, created_at ASC"
        ).fetchall()
        return [
            Workspace(id=r["id"], name=r["name"], icon=r["icon"], position=r["position"])
            for r in rows
        ]

    def get_active_workspace_id(self) -> str:
        ws_id = str(self._db.get_setting("active_workspace_id", "ws-recherche"))
        workspaces = self.list_workspaces()
        if any(w.id == ws_id for w in workspaces):
            return ws_id
        return workspaces[0].id if workspaces else "ws-personnel"

    def set_active_workspace(self, workspace_id: str) -> None:
        self._db.set_setting("active_workspace_id", workspace_id)

    def create_workspace(self, name: str, icon: str = "layers") -> Workspace:
        clean_name = name.strip() or "Nouvel espace"
        ws_id = f"ws-{uuid.uuid4().hex[:8]}"
        max_pos = self._db.connection.execute(
            "SELECT COALESCE(MAX(position), -1) FROM workspaces"
        ).fetchone()[0]
        self._db.connection.execute(
            "INSERT INTO workspaces(id, name, icon, position, created_at) VALUES (?, ?, ?, ?, ?)",
            (ws_id, clean_name, icon, max_pos + 1, utc_now_iso()),
        )
        self._db.connection.commit()
        return Workspace(id=ws_id, name=clean_name, icon=icon, position=max_pos + 1)

    def rename_workspace(self, workspace_id: str, new_name: str) -> None:
        clean = new_name.strip()
        if not clean:
            raise ValueError("Le nom de l'espace ne peut pas être vide.")
        self._db.connection.execute(
            "UPDATE workspaces SET name = ? WHERE id = ?",
            (clean, workspace_id),
        )
        self._db.connection.commit()

    def delete_workspace(self, workspace_id: str) -> None:
        workspaces = self.list_workspaces()
        if len(workspaces) <= 1:
            raise ValueError("Au moins un espace doit rester actif dans le profil.")
        fallback = next(w.id for w in workspaces if w.id != workspace_id)
        self._db.connection.execute(
            "UPDATE tab_sessions SET workspace_id = ? WHERE workspace_id = ?",
            (fallback, workspace_id),
        )
        self._db.connection.execute("DELETE FROM workspaces WHERE id = ?", (workspace_id,))
        if self.get_active_workspace_id() == workspace_id:
            self.set_active_workspace(fallback)
        self._db.connection.commit()
