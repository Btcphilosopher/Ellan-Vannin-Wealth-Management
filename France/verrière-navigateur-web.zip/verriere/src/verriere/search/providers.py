"""Gestion des moteurs de recherche configurables (y compris l'adaptateur Éclair)."""

from __future__ import annotations

import os
from dataclasses import dataclass
from urllib.parse import quote_plus, urlparse

from verriere.application.storage import ProfileDatabase


@dataclass(frozen=True)
class SearchProvider:
    id: str
    name: str
    url_template: str
    suggest_url_template: str = ""
    is_builtin: bool = False
    enabled: bool = True

    @property
    def is_configured(self) -> bool:
        return bool(self.url_template and "{query}" in self.url_template)

    @property
    def destination_origin(self) -> str:
        if not self.is_configured:
            return "Non configuré"
        parsed = urlparse(self.url_template.replace("{query}", "test"))
        return f"{parsed.scheme}://{parsed.netloc}" if parsed.netloc else self.url_template

    def build_search_url(self, query: str) -> str:
        if not self.is_configured:
            raise ValueError(
                f"Le moteur « {self.name} » ne possède pas encore d'URL de recherche configurée."
            )
        encoded = quote_plus(query.strip())
        return self.url_template.replace("{query}", encoded)


def validate_search_template(template: str) -> tuple[bool, str]:
    """Vérifie qu'un modèle d'URL de recherche est sûr et valide."""
    t = template.strip()
    if not t:
        return True, ""
    if "{query}" not in t:
        return False, "Le modèle doit contenir le marqueur {query}."
    parsed = urlparse(t.replace("{query}", "exemple"))
    if parsed.scheme.lower() not in ("http", "https") or not parsed.netloc:
        return False, "L'URL du moteur de recherche doit utiliser http:// ou https:// avec un hôte valide."
    return True, ""


class SearchEngineManager:
    """Gère les fournisseurs de recherche du profil et l'adaptateur Éclair."""

    def __init__(self, db: ProfileDatabase) -> None:
        self._db = db
        self._sync_eclair_from_settings_or_env()

    def _sync_eclair_from_settings_or_env(self) -> None:
        endpoint = (
            self._db.get_setting("eclair_endpoint", "")
            or os.environ.get("VERRIERE_ECLAIR_ENDPOINT", "")
        ).strip()
        if endpoint:
            ok, _ = validate_search_template(endpoint)
            if ok:
                self._db.connection.execute(
                    "UPDATE search_providers SET name = ?, url_template = ? WHERE id = 'eclair'",
                    ("Éclair", endpoint),
                )
                self._db.connection.commit()

    def list_providers(self) -> list[SearchProvider]:
        rows = self._db.connection.execute(
            "SELECT id, name, url_template, suggest_url_template, is_builtin, enabled "
            "FROM search_providers ORDER BY is_builtin DESC, name ASC"
        ).fetchall()
        return [
            SearchProvider(
                id=row["id"],
                name=row["name"],
                url_template=row["url_template"],
                suggest_url_template=row["suggest_url_template"],
                is_builtin=bool(row["is_builtin"]),
                enabled=bool(row["enabled"]),
            )
            for row in rows
        ]

    def get_provider(self, provider_id: str) -> SearchProvider | None:
        row = self._db.connection.execute(
            "SELECT id, name, url_template, suggest_url_template, is_builtin, enabled "
            "FROM search_providers WHERE id = ?",
            (provider_id,),
        ).fetchone()
        if row is None:
            return None
        return SearchProvider(
            id=row["id"],
            name=row["name"],
            url_template=row["url_template"],
            suggest_url_template=row["suggest_url_template"],
            is_builtin=bool(row["is_builtin"]),
            enabled=bool(row["enabled"]),
        )

    def get_default_provider(self) -> SearchProvider:
        default_id = str(self._db.get_setting("default_search_provider_id", "qwant"))
        provider = self.get_provider(default_id)
        if provider is not None and provider.is_configured:
            return provider
        # Si le moteur par défaut (ex. Éclair non configuré) n'est pas prêt, préférer Qwant puis le premier prêt
        qwant = self.get_provider("qwant")
        if qwant is not None and qwant.is_configured:
            return qwant
        for candidate in self.list_providers():
            if candidate.is_configured:
                return candidate
        return SearchProvider(
            id="qwant",
            name="Qwant",
            url_template="https://www.qwant.com/?q={query}&l=fr",
            is_builtin=True,
        )

    def set_default_provider(self, provider_id: str) -> None:
        provider = self.get_provider(provider_id)
        if provider is None:
            raise ValueError(f"Moteur de recherche introuvable : {provider_id}")
        self._db.set_setting("default_search_provider_id", provider_id)

    def configure_eclair(self, endpoint_template: str) -> None:
        ok, error = validate_search_template(endpoint_template)
        if not ok:
            raise ValueError(error)
        cleaned = endpoint_template.strip()
        self._db.set_setting("eclair_endpoint", cleaned)
        name = "Éclair" if cleaned else "Éclair (non configuré)"
        self._db.connection.execute(
            "UPDATE search_providers SET name = ?, url_template = ? WHERE id = 'eclair'",
            (name, cleaned),
        )
        self._db.connection.commit()

    def add_custom_provider(self, provider_id: str, name: str, url_template: str) -> SearchProvider:
        ok, error = validate_search_template(url_template)
        if not ok or not url_template.strip():
            raise ValueError(error or "Le modèle d'URL ne peut pas être vide.")
        clean_id = "".join(c for c in provider_id.lower() if c.isalnum() or c in "-_") or "custom"
        clean_name = name.strip() or clean_id
        self._db.connection.execute(
            "INSERT OR REPLACE INTO search_providers(id, name, url_template, suggest_url_template, is_builtin, enabled) "
            "VALUES (?, ?, ?, '', 0, 1)",
            (clean_id, clean_name, url_template.strip()),
        )
        self._db.connection.commit()
        return self.get_provider(clean_id)  # type: ignore[return-value]

    def build_search_url(self, query: str, provider_id: str | None = None) -> tuple[str, SearchProvider]:
        provider = self.get_provider(provider_id) if provider_id else self.get_default_provider()
        if provider is None or not provider.is_configured:
            provider = self.get_default_provider()
        return provider.build_search_url(query), provider
