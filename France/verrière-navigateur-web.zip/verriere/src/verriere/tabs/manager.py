"""Gestionnaire d'onglets avec identifiants stables, réouverture et persistance de session."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field

from verriere.application.locale_fr import utc_now_iso
from verriere.application.storage import ProfileDatabase


@dataclass
class TabRecord:
    tab_id: str
    workspace_id: str
    url: str
    title: str = "Nouvel onglet"
    position: int = 0
    is_loading: bool = False
    progress: int = 0
    can_go_back: bool = False
    can_go_forward: bool = False
    zoom_factor: float = 1.0
    crashed: bool = False
    cert_error: str = ""
    favicon_key: str = "verriere"


@dataclass
class ClosedTabRecord:
    workspace_id: str
    url: str
    title: str
    closed_at: str = field(default_factory=utc_now_iso)


class TabManager:
    """Gère les onglets d'une fenêtre avec identifiants immuables et persistance normale."""

    def __init__(self, db: ProfileDatabase | None = None, is_private: bool = False) -> None:
        self._db = None if is_private else db
        self._is_private = is_private
        self._tabs: dict[str, TabRecord] = {}
        self._order: list[str] = []
        self._active_tab_id: str | None = None
        self._closed_stack: list[ClosedTabRecord] = []

    @property
    def active_tab_id(self) -> str | None:
        return self._active_tab_id

    @property
    def tab_count(self) -> int:
        return len(self._order)

    def has_tab(self, tab_id: str) -> bool:
        """Vérifie que l'identifiant d'onglet est toujours valide avant d'appliquer un événement différé."""
        return tab_id in self._tabs

    def get_tab(self, tab_id: str) -> TabRecord | None:
        return self._tabs.get(tab_id)

    def list_tabs(self, workspace_id: str | None = None) -> list[TabRecord]:
        tabs = [self._tabs[tid] for tid in self._order if tid in self._tabs]
        if workspace_id is not None:
            return [t for t in tabs if t.workspace_id == workspace_id]
        return tabs

    def create_tab(
        self,
        url: str = "verriere://newtab",
        workspace_id: str = "ws-recherche",
        title: str = "Nouvel onglet",
        activate: bool = True,
        insert_after: str | None = None,
    ) -> TabRecord:
        tab_id = f"tab-{uuid.uuid4().hex}"
        record = TabRecord(
            tab_id=tab_id,
            workspace_id=workspace_id,
            url=url,
            title=title,
            position=len(self._order),
        )
        self._tabs[tab_id] = record
        if insert_after and insert_after in self._order:
            idx = self._order.index(insert_after) + 1
            self._order.insert(idx, tab_id)
        else:
            self._order.append(tab_id)
        self._reindex()
        if activate or self._active_tab_id is None:
            self._active_tab_id = tab_id
        self.save_session()
        return record

    def set_active_tab(self, tab_id: str) -> TabRecord | None:
        if tab_id not in self._tabs:
            return None
        self._active_tab_id = tab_id
        self.save_session()
        return self._tabs[tab_id]

    def update_tab(
        self,
        tab_id: str,
        *,
        url: str | None = None,
        title: str | None = None,
        is_loading: bool | None = None,
        progress: int | None = None,
        can_go_back: bool | None = None,
        can_go_forward: bool | None = None,
        zoom_factor: float | None = None,
        crashed: bool | None = None,
        cert_error: str | None = None,
        workspace_id: str | None = None,
    ) -> bool:
        """Met à jour un onglet uniquement si son identifiant est toujours actif."""
        record = self._tabs.get(tab_id)
        if record is None:
            return False
        if url is not None:
            record.url = url
        if title is not None:
            record.title = title or url or "Nouvel onglet"
        if is_loading is not None:
            record.is_loading = is_loading
        if progress is not None:
            record.progress = progress
        if can_go_back is not None:
            record.can_go_back = can_go_back
        if can_go_forward is not None:
            record.can_go_forward = can_go_forward
        if zoom_factor is not None:
            record.zoom_factor = zoom_factor
        if crashed is not None:
            record.crashed = crashed
        if cert_error is not None:
            record.cert_error = cert_error
        if workspace_id is not None:
            record.workspace_id = workspace_id
        self.save_session()
        return True

    def reorder_tab(self, from_index: int, to_index: int) -> bool:
        if not (0 <= from_index < len(self._order)) or not (0 <= to_index < len(self._order)):
            return False
        if from_index == to_index:
            return True
        tid = self._order.pop(from_index)
        self._order.insert(to_index, tid)
        self._reindex()
        self.save_session()
        return True

    def duplicate_tab(self, tab_id: str) -> TabRecord | None:
        source = self._tabs.get(tab_id)
        if source is None:
            return None
        return self.create_tab(
            url=source.url,
            workspace_id=source.workspace_id,
            title=source.title,
            activate=True,
            insert_after=tab_id,
        )

    def close_tab(self, tab_id: str, record_closed: bool = True) -> str | None:
        """Ferme l'onglet et retourne le nouvel identifiant d'onglet actif."""
        if tab_id not in self._tabs:
            return self._active_tab_id
        idx = self._order.index(tab_id)
        tab = self._tabs.pop(tab_id)
        self._order.remove(tab_id)
        if record_closed and tab.url != "about:blank":
            closed = ClosedTabRecord(
                workspace_id=tab.workspace_id,
                url=tab.url,
                title=tab.title,
            )
            self._closed_stack.append(closed)
            if not self._is_private and self._db is not None:
                self._db.connection.execute(
                    "INSERT INTO closed_tabs(workspace_id, url, title, closed_at) VALUES (?, ?, ?, ?)",
                    (closed.workspace_id, closed.url, closed.title, closed.closed_at),
                )
                self._db.connection.commit()

        self._reindex()
        if self._active_tab_id == tab_id:
            if self._order:
                next_idx = min(idx, len(self._order) - 1)
                self._active_tab_id = self._order[next_idx]
            else:
                self._active_tab_id = None
        self.save_session()
        return self._active_tab_id

    def reopen_last_closed(self) -> TabRecord | None:
        if self._closed_stack:
            last = self._closed_stack.pop()
            return self.create_tab(
                url=last.url,
                workspace_id=last.workspace_id,
                title=last.title,
                activate=True,
            )
        if not self._is_private and self._db is not None:
            row = self._db.connection.execute(
                "SELECT id, workspace_id, url, title FROM closed_tabs ORDER BY id DESC LIMIT 1"
            ).fetchone()
            if row is not None:
                self._db.connection.execute("DELETE FROM closed_tabs WHERE id = ?", (row["id"],))
                self._db.connection.commit()
                return self.create_tab(
                    url=row["url"],
                    workspace_id=row["workspace_id"],
                    title=row["title"],
                    activate=True,
                )
        return None

    def detach_tab(self, tab_id: str) -> TabRecord | None:
        """Extrait un onglet pour le déplacer vers une autre fenêtre."""
        tab = self._tabs.get(tab_id)
        if tab is None:
            return None
        snapshot = TabRecord(
            tab_id=tab.tab_id,
            workspace_id=tab.workspace_id,
            url=tab.url,
            title=tab.title,
            zoom_factor=tab.zoom_factor,
        )
        self.close_tab(tab_id, record_closed=False)
        return snapshot

    def _reindex(self) -> None:
        for idx, tid in enumerate(self._order):
            if tid in self._tabs:
                self._tabs[tid].position = idx

    def save_session(self) -> None:
        """Persiste la session normale uniquement (jamais en navigation privée)."""
        if self._is_private or self._db is None:
            return
        cur = self._db.connection.cursor()
        cur.execute("DELETE FROM tab_sessions")
        now = utc_now_iso()
        for idx, tid in enumerate(self._order):
            tab = self._tabs[tid]
            cur.execute(
                "INSERT INTO tab_sessions(tab_id, workspace_id, url, title, position, is_active, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    tab.tab_id,
                    tab.workspace_id,
                    tab.url,
                    tab.title,
                    idx,
                    1 if tid == self._active_tab_id else 0,
                    now,
                ),
            )
        self._db.connection.commit()

    def restore_session(self) -> list[TabRecord]:
        """Restaure les onglets normaux après redémarrage."""
        if self._is_private or self._db is None:
            return []
        rows = self._db.connection.execute(
            "SELECT tab_id, workspace_id, url, title, position, is_active "
            "FROM tab_sessions ORDER BY position ASC"
        ).fetchall()
        self._tabs.clear()
        self._order.clear()
        self._active_tab_id = None
        for row in rows:
            tid = row["tab_id"]
            rec = TabRecord(
                tab_id=tid,
                workspace_id=row["workspace_id"],
                url=row["url"],
                title=row["title"],
                position=row["position"],
            )
            self._tabs[tid] = rec
            self._order.append(tid)
            if row["is_active"]:
                self._active_tab_id = tid
        if self._active_tab_id is None and self._order:
            self._active_tab_id = self._order[0]
        return self.list_tabs()
