# Limites de compatibilité — VERRIÈRE 0.1.0

| Capacité | Statut | Précisions |
| --- | --- | --- |
| Lecture multimédia HTML5 | Dépendant du moteur | Codecs libres intégrés à Qt WebEngine (VP8/VP9/Opus). Les codecs propriétaires H.264/AAC dépendent de la compilation Qt. |
| Visioconférence WebRTC | Dépendant du moteur | Pris en charge par Qt WebEngine avec invite de permission par origine pour caméra/microphone. |
| Visionneuse PDF | Pris en charge | Activée via `QWebEngineSettings.PdfViewerEnabled`. |
| Impression | Pris en charge | Impression système et export PDF via Qt WebEngine. |
| Fenêtres contextuelles (pop-ups) | Pris en charge | Redirigées vers de nouveaux onglets contrôlés via `createWindow`. |
| Envoi de fichiers (upload) | Pris en charge | Sélecteur natif déclenché uniquement par une interaction utilisateur dans la page. |
| Accessibilité | Pris en charge | Raccourcis clavier, libellés accessibles Qt, zoom texte, mode contraste élevé, réduction des animations. |
| Gestionnaire de mots de passe | Différé | Exclu de la version 0.1.0 en attendant une intégration auditée avec trousseau système. |
| Extensions Chrome / WebExtensions | Non pris en charge | Qt WebEngine ne fournit pas d'API WebExtensions compatible Chrome. |
| Streaming DRM commercial (Widevine) | Non pris en charge | Aucun module CDM propriétaire Widevine n'est distribué. |
