# Mises à jour applicatives et mises à jour du moteur

## Distinction essentielle

1. **Mises à jour de Verrière** : concernent l'interface Qt, les modules Python (`verriere`), les pages internes et les correctifs applicatifs.
2. **Mises à jour de sécurité du moteur Web (Qt WebEngine / Chromium)** : Qt WebEngine suit un cycle de publication indépendant calé sur les correctifs de sécurité Chromium (ex. `6.8.x` / `6.12.x`). Elles parviennent aux utilisateurs via :
   - la mise à jour de `PySide6` (`pip install --upgrade PySide6`) dans les installations Python ;
   - la publication d'un nouvel installeur ou paquet autonome Verrière intégrant le dernier runtime `PySide6` / Qt WebEngine.

## Vérification des mises à jour applicatives

`verriere.settings.updates` implémente la vérification cryptographique de manifestes (`UpdateManifest`) :
- Seules les URL HTTPS explicites sont acceptées.
- La signature du manifeste (`HMAC-SHA256` dans le prototype testable ou signature asymétrique Ed25519 en production) et le condensat `SHA-256` de l'archive sont vérifiés **avant** toute proposition d'installation.
- Verrière ne télécharge et n'exécute **jamais** d'URL arbitraire non signée.
- L'application des mises à jour du paquet système (`.deb`, AppImage ou environnement virtuel) reste une action explicite de l'utilisateur ou du gestionnaire de paquets du système.
