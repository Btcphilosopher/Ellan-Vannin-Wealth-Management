# Inventaire des dépendances et licences

| Composant | Rôle | Licence | Notes de redistribution |
| --- | --- | --- | --- |
| Code source Verrière | Interface, logique métier, pages internes | MIT | Code applicatif propre. |
| Python (CPython >= 3.11) | Langage d'exécution | PSF License 2.0 | Standard Python Software Foundation. |
| PySide6 / Qt for Python | Liaison Python vers Qt 6 | LGPLv3 / GPLv2 / Commercial | Liaison dynamique obligatoire pour redistribution LGPLv3 ; permettre le remplacement des bibliothèques Qt. |
| Qt WebEngine (Chromium) | Moteur de rendu Web | LGPLv3 + licences BSD/Apache tiers Chromium | Notices tierces Chromium incluses dans le paquet Qt WebEngine. |
| SQLite (via Python `sqlite3`) | Persistance locale par profil | Domaine public | Aucune restriction. |
| `keyring` | Accès au trousseau système | MIT | Utilisé pour les secrets optionnels (assistant). |
| `pytest` / `pytest-qt` (dev) | Tests unitaires et GUI | MIT | Dépendances de développement uniquement. |
