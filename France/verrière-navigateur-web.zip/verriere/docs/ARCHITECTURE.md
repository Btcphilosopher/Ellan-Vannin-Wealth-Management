# Architecture — VERRIÈRE

## Séparation des couches

- `chrome/` : Widgets natifs Qt (`QMainWindow`, `QTabBar`, `QLineEdit`, `QMenu`, `QDialog`). Aucun site Web ne possède d'accès à ces surfaces.
- `internal_pages/` : Schéma `verriere://` enregistré avant `QApplication` (`QWebEngineUrlScheme` avec `SecureScheme` et `LocalAccessAllowed`). Les actions applicatives exigent un initiateur `verriere://` et un jeton de session (`session_nonce`).
- `navigation/` : Parseur déterministe URL vs recherche, blocage des schémas dangereux, et moteur de suggestions débouncé à annulation par `query_id`.
- `tabs/` : Identifiants immuables (`tab_id`) empêchant tout signal tardif d'onglet fermé d'affecter un autre onglet.
- `profiles/` & `workspaces/` :
  - Un **Profil** isole le répertoire `QWebEngineProfile` (cookies, cache, stockage HTML5) et la base SQLite (`verriere.sqlite3`).
  - Un **Espace** regroupe visuellement les onglets au sein d'un profil sans isoler les cookies.
  - Une **Session privée** utilise un `QWebEngineProfile` off-the-record en mémoire sans base SQLite.
