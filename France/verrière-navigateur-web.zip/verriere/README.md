# VERRIÈRE — Navigateur Web

**VERRIÈRE** est un navigateur Web de bureau en français conçu avec **Python 3.11+**, **PySide6**, **Qt WebEngine** (moteur Chromium maintenu) et **SQLite**.

## Plateforme testée et support multiplateforme

- **Première version testée** : Linux x86_64 (Debian 12 / Ubuntu 22.04+, X11 / Xvfb, sandbox Qt WebEngine actif).
- **Autres plateformes documentées** : Windows 11 (x86_64) et macOS (Apple Silicon / Intel) sont pris en charge par l'architecture PySide6 + Qt WebEngine + `keyring`, mais nécessitent une campagne d'empaquetage et de signature dédiée (`.msi`/`.dmg`) avant diffusion.

## Fonctionnalités implémentées

- **Interface native PySide6 fidèle au design Verrière** : bandeau d'onglets perle, barre de navigation titane satiné, barre de favoris à dossiers, barre latérale gauche (`Accueil`, `Onglets`, `Espaces`, `Favoris`, `Historique`, `Réglages`), touches saphir et vermillon.
- **Navigation complète** : Précédent, Suivant, Actualiser/Arrêter, Accueil, saisie URL vs recherche documentée, progression, zoom (`25 %` à `300 %`), recherche dans la page (`Ctrl+F`), copie d'adresse, pop-ups contrôlés en onglets, demandes de plein écran par bannière.
- **Onglets & sessions** : identifiants stables (immuables contre les événements différés d'onglets fermés), réorganisation, duplication, réouverture (`Ctrl+Maj+T`), déplacement vers une nouvelle fenêtre, restauration des onglets normaux au démarrage, récupération sur plantage moteur.
- **Profils, espaces et navigation privée** : profils isolés (`QWebEngineProfile` + base SQLite distincts), espaces visuels (`Personnel`, `Recherche`, `Voyages`) avec avertissement explicite de non-isolation des cookies, fenêtres privées `off-the-record` sans écriture dans l'historique ou la base normale.
- **Favoris, historique & téléchargements** : dossiers, import/export JSON et Netscape HTML filtrés, filtrage par date, boîte `Effacer les données de navigation`, validation des chemins de téléchargement sans exécution automatique.
- **Pages internes isolées `verriere://*`** : `newtab`, `bookmarks`, `history`, `downloads`, `settings`, `article`, `error`, protégées par un jeton de session (`nonce`) inaccessible aux sites externes.
- **Moteurs de recherche & assistant optionnel** : Qwant, DuckDuckGo, Startpage, Wikipédia (FR), adaptateur **Éclair** configurable, et panneau d'aide à la lecture désactivé par défaut.

## Installation et lancement

```bash
cd verriere
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
verriere
```

## Exécution des tests

```bash
cd verriere
xvfb-run -a pytest -v
```

Voir également :
- `docs/ARCHITECTURE.md`
- `docs/COMPATIBILITY.md`
- `docs/LICENCES.md`
- `docs/UPDATES.md`
- `SECURITY.md`
