#!/usr/bin/env bash
set -euo pipefail

# Script d'empaquetage Linux (x86_64) pour VERRIÈRE — Navigateur Web
# Prérequis : environnement Python >= 3.11 avec PySide6 et PyInstaller installés.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"
python3 -m pip install --no-build-isolation ".[packaging]"
pyinstaller --noconfirm --clean packaging/verriere.spec

echo "Paquet autonome généré dans : $PROJECT_DIR/dist/verriere/"
echo "Note LGPLv3 : conservez les bibliothèques dynamiques Qt dans dist/verriere/_internal/PySide6/ afin que l'utilisateur puisse les remplacer."
