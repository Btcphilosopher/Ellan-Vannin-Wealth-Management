"""Tests GUI & moteur réel Qt WebEngine (exécutés sous Xvfb avec serveur HTTP local)."""

from __future__ import annotations

import functools
import http.server
import os
import threading
from pathlib import Path

import pytest
from PySide6.QtCore import QTimer, QUrl

from verriere.application.browser_app import VerriereApplication
from verriere.internal_pages.scheme import register_verriere_scheme
from verriere.permissions.manager import PermissionDecision


class _LocalTestHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args: object) -> None:
        return


@pytest.fixture(scope="module")
def local_site(tmp_path_factory: pytest.TempPathFactory):
    site_dir = tmp_path_factory.mktemp("local_site")
    (site_dir / "index.html").write_text(
        "<!doctype html><html lang='fr'><head><meta charset='utf-8'><title>Site Local Verrière</title></head>"
        "<body><h1>Bienvenue sur le site local</h1><p>Contenu de test déterministe.</p></body></html>",
        encoding="utf-8",
    )
    (site_dir / "search.html").write_text(
        "<!doctype html><html lang='fr'><head><meta charset='utf-8'><title>Résultats Éclair</title></head>"
        "<body><h1>Résultats locaux</h1></body></html>",
        encoding="utf-8",
    )
    (site_dir / "document.txt").write_text("Contenu de test Verrière téléchargé.", encoding="utf-8")

    handler = functools.partial(_LocalTestHandler, directory=str(site_dir))
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{port}"
    finally:
        server.shutdown()


def _wait_until(qtbot, predicate, timeout_ms: int = 8000) -> None:
    qtbot.waitUntil(predicate, timeout=timeout_ms)


@pytest.mark.gui
def test_full_browser_demonstration_workflow(qtbot, tmp_path: Path, local_site: str) -> None:
    # Vérifier que le bac à sable Qt WebEngine n'est pas désactivé dans les tests
    assert os.environ.get("QTWEBENGINE_DISABLE_SANDBOX") != "1"

    register_verriere_scheme()
    data_dir = tmp_path / "verriere_data"
    controller = VerriereApplication(data_dir=data_dir)
    win = controller.open_initial_window()
    qtbot.addWidget(win)
    win._force_close = True

    # 1. Lancement sur la page Nouvel onglet française
    _wait_until(
        qtbot,
        lambda: win.tab_manager.get_tab(win.tab_manager.active_tab_id).title.startswith("Nouvel onglet"),
    )

    # 2. Ouvrir un site Web local via la barre d'adresse
    win.address_input.setText(f"{local_site}/index.html")
    win._on_address_submitted()
    _wait_until(
        qtbot,
        lambda: "Site Local Verrière" in (win.tab_manager.get_tab(win.tab_manager.active_tab_id).title or ""),
    )

    # 3. Configurer Éclair localement et effectuer une recherche
    assert win.search_manager is not None
    win.search_manager.configure_eclair(f"{local_site}/search.html?q={{query}}")
    win.search_manager.set_default_provider("eclair")
    win.navigate_active("architecture bioclimatique", typed=True)
    _wait_until(
        qtbot,
        lambda: "Résultats Éclair" in (win.tab_manager.get_tab(win.tab_manager.active_tab_id).title or ""),
    )

    # 4. Ouvrir et réorganiser plusieurs onglets
    t_b = win.new_tab("verriere://bookmarks")
    t_h = win.new_tab("verriere://history")
    assert win.tab_manager.tab_count == 3
    assert win.tab_manager.reorder_tab(2, 0) is True
    assert win.tab_manager.list_tabs()[0].tab_id == t_h.tab_id

    # 5. Enregistrer un favori
    assert win.bookmarks is not None
    bm = win.bookmarks.add_bookmark("Site Local", f"{local_site}/index.html")
    assert win.bookmarks.find_by_url(f"{local_site}/index.html").id == bm.id

    # 6. Créer un espace de travail
    assert win.workspaces is not None
    ws = win.workspaces.create_workspace("Atelier")
    win._switch_workspace(ws.id)
    assert win.workspaces.get_active_workspace_id() == ws.id

    # 7. Télécharger un fichier de test local via le moteur Qt WebEngine
    dl_view = win._active_view()
    assert dl_view is not None
    dl_view.page().download(QUrl(f"{local_site}/document.txt"), "document.txt")
    _wait_until(
        qtbot,
        lambda: any(
            d.filename.startswith("document") and d.state.value == "completed"
            for d in win.downloads.list_downloads()
        ),
    )

    # 8. Examiner et révoquer une permission par origine
    win.permissions.set_decision(local_site, "geolocation", PermissionDecision.ALLOW)
    assert win.permissions.get_decision(local_site, "geolocation") == PermissionDecision.ALLOW
    win.permissions.revoke_permission(local_site, "geolocation")
    assert win.permissions.get_decision(local_site, "geolocation") == PermissionDecision.ASK

    # 9. Ouvrir une session privée (off-the-record) et vérifier la séparation
    priv_win = controller.open_private_window()
    qtbot.addWidget(priv_win)
    priv_win._force_close = True
    assert priv_win.web_profile.isOffTheRecord() is True
    priv_win.navigate_active(f"{local_site}/index.html", typed=True)
    _wait_until(
        qtbot,
        lambda: "Site Local Verrière" in (priv_win.tab_manager.get_tab(priv_win.tab_manager.active_tab_id).title or ""),
    )
    # L'historique privé ne doit jamais exister
    assert priv_win.history.search() == []
    priv_win.close()

    # 10. Vérifier la séparation des profils
    prof2 = controller.registry.create_profile("Second")
    win2 = controller.open_profile_window(prof2.id)
    qtbot.addWidget(win2)
    win2._force_close = True
    assert win2.web_profile.persistentStoragePath() != win.web_profile.persistentStoragePath()
    assert win2.bookmarks is not None and win2.bookmarks.find_by_url(f"{local_site}/index.html") is None
    win2.close()
    qtbot.wait(100)

    # 11. Restauration de la session normale après redémarrage (profil Camille)
    controller.registry.set_active_profile("camille")
    saved_urls = [t.url for t in win.tab_manager.list_tabs()]
    win.close()
    qtbot.wait(150)
    controller.shutdown()

    controller_restarted = VerriereApplication(data_dir=data_dir)
    win_restarted = controller_restarted.open_initial_window()
    qtbot.addWidget(win_restarted)
    win_restarted._force_close = True
    assert [t.url for t in win_restarted.tab_manager.list_tabs()] == saved_urls

    # 12. Récupération après échec de chargement (port local fermé) & simulation crash moteur
    win_restarted.navigate_active("http://127.0.0.1:1/inaccessible")
    _wait_until(
        qtbot,
        lambda: "verriere://error" in win_restarted._active_view().url().toString(),
    )
    active_tid = win_restarted.tab_manager.active_tab_id
    win_restarted._on_render_crash(active_tid, None, 11)
    assert win_restarted.tab_manager.get_tab(active_tid).crashed is True

    # 13. Effacer des données de navigation sélectionnées
    assert len(win_restarted.history.search()) >= 1
    win_restarted.context.clear_browsing_data(clear_history=True, clear_cache=True)
    assert win_restarted.history.search() == []

    win_restarted.close()
    qtbot.wait(150)
    controller_restarted.shutdown()
