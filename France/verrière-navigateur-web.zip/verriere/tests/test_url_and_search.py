"""Tests unitaires : analyse URL vs recherche, schémas, IDNA et moteurs (Éclair)."""

from __future__ import annotations

import pytest

from verriere.application.storage import ProfileDatabase
from verriere.navigation.url_parser import (
    InputKind,
    format_origin_for_display,
    format_url_for_bar,
    parse_address_input,
)
from verriere.search.providers import SearchEngineManager, validate_search_template


def test_parse_urls_and_internal_pages() -> None:
    p1 = parse_address_input("verriere://newtab")
    assert p1.kind == InputKind.INTERNAL
    assert p1.normalized_url == "verriere://newtab"

    p2 = parse_address_input("lemonde.fr/culture")
    assert p2.kind == InputKind.URL
    assert p2.normalized_url == "https://lemonde.fr/culture"
    assert p2.display_host == "lemonde.fr"

    p3 = parse_address_input("localhost:8080/test")
    assert p3.kind == InputKind.URL
    assert p3.normalized_url == "http://localhost:8080/test"

    p4 = parse_address_input("127.0.0.1:9000")
    assert p4.kind == InputKind.URL
    assert p4.normalized_url == "http://127.0.0.1:9000"


def test_parse_search_queries() -> None:
    q = parse_address_input("architecture contemporaine paris")
    assert q.kind == InputKind.SEARCH
    assert q.search_query == "architecture contemporaine paris"

    single_word = parse_address_input("verriere")
    assert single_word.kind == InputKind.SEARCH


def test_blocked_and_unsupported_schemes() -> None:
    for dangerous in ("javascript:alert(1)", "vbscript:msgbox(1)", "shell:calc", "cmd:whoami"):
        res = parse_address_input(dangerous)
        assert res.kind == InputKind.BLOCKED_SCHEME

    mailto = parse_address_input("mailto:camille@exemple.fr")
    assert mailto.kind == InputKind.UNSUPPORTED_SCHEME
    assert "commande" in mailto.reason.lower()


def test_idna_punycode_never_conceals_host() -> None:
    origin, host, warn = format_origin_for_display("https://xn--pple-43d.com/login")
    assert "xn--pple-43d.com" in origin
    assert "xn--pple-43d.com" in host
    assert warn is True

    bar_url = format_url_for_bar("https://café.example.fr/menu")
    assert "xn--caf-dma.example.fr" in bar_url


def test_search_manager_and_eclair_fallback(tmp_path) -> None:
    db = ProfileDatabase(tmp_path / "db.sqlite3")
    mgr = SearchEngineManager(db)

    # Éclair est listé mais non configuré par défaut -> bascule sûre
    mgr.set_default_provider("eclair")
    url, active = mgr.build_search_url("musée d'orsay")
    assert active.id != "eclair"
    assert "qwant.com" in url

    # Configuration explicite d'Éclair
    ok, _ = validate_search_template("https://eclair.exemple.fr/search?q={query}")
    assert ok
    mgr.configure_eclair("https://eclair.exemple.fr/search?q={query}")
    mgr.set_default_provider("eclair")
    url2, active2 = mgr.build_search_url("palais de tokyo")
    assert active2.id == "eclair"
    assert url2 == "https://eclair.exemple.fr/search?q=palais+de+tokyo"

    with pytest.raises(ValueError):
        mgr.add_custom_provider("bad", "Mauvais", "javascript:{query}")
    db.close()
