"""Tests unitaires : identifiants d'onglets stables, réorganisation et restauration de session."""

from __future__ import annotations

from verriere.application.storage import ProfileDatabase
from verriere.tabs.manager import TabManager


def test_stable_tab_ids_ignore_delayed_events_after_close(tmp_path) -> None:
    db = ProfileDatabase(tmp_path / "tabs.sqlite3")
    tm = TabManager(db, is_private=False)

    t1 = tm.create_tab("https://exemple.fr/un", title="Un")
    t2 = tm.create_tab("https://exemple.fr/deux", title="Deux")
    assert t1.tab_id != t2.tab_id

    tm.close_tab(t1.tab_id)
    assert tm.has_tab(t1.tab_id) is False

    # Événement différé de l'onglet fermé t1 : doit être ignoré sans toucher t2
    applied = tm.update_tab(t1.tab_id, title="Titre tardif malveillant", url="https://autre.fr")
    assert applied is False
    assert tm.get_tab(t2.tab_id).title == "Deux"
    assert tm.get_tab(t2.tab_id).url == "https://exemple.fr/deux"
    db.close()


def test_reorder_duplicate_reopen_and_session_restore(tmp_path) -> None:
    db_path = tmp_path / "session.sqlite3"
    db1 = ProfileDatabase(db_path)
    tm1 = TabManager(db1, is_private=False)

    t1 = tm1.create_tab("verriere://newtab", title="Nouvel onglet")
    t2 = tm1.create_tab("https://fr.wikipedia.org", title="Wikipédia")
    t3 = tm1.create_tab("https://gallica.bnf.fr", title="Gallica")

    assert tm1.reorder_tab(2, 0) is True
    assert [t.tab_id for t in tm1.list_tabs()] == [t3.tab_id, t1.tab_id, t2.tab_id]

    dup = tm1.duplicate_tab(t2.tab_id)
    assert dup is not None and dup.url == "https://fr.wikipedia.org"

    tm1.close_tab(dup.tab_id)
    reopened = tm1.reopen_last_closed()
    assert reopened is not None and reopened.url == "https://fr.wikipedia.org"
    db1.close()

    # Simulation d'un redémarrage : nouvelle instance sur la même base SQLite
    db2 = ProfileDatabase(db_path)
    tm2 = TabManager(db2, is_private=False)
    restored = tm2.restore_session()
    assert len(restored) == 4
    assert restored[0].url == "https://gallica.bnf.fr"
    db2.close()


def test_private_tab_manager_never_persists_to_db(tmp_path) -> None:
    db = ProfileDatabase(tmp_path / "normal.sqlite3")
    tm_priv = TabManager(db, is_private=True)
    tm_priv.create_tab("https://confidentiel.example.fr", title="Secret")

    # Aucune trace écrite dans tab_sessions ou closed_tabs de la base normale
    assert db.connection.execute("SELECT COUNT(*) FROM tab_sessions").fetchone()[0] == 0
    tm_priv.close_tab(tm_priv.list_tabs()[0].tab_id)
    assert db.connection.execute("SELECT COUNT(*) FROM closed_tabs").fetchone()[0] == 0
    db.close()
