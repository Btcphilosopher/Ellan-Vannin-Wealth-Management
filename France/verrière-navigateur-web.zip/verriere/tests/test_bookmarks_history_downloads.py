"""Tests unitaires : favoris, historique, formatage FR et validation des téléchargements."""

from __future__ import annotations

from pathlib import Path

from verriere.application.locale_fr import format_bytes_fr, format_date_fr, format_percent_fr
from verriere.application.storage import ProfileDatabase
from verriere.bookmarks.manager import BookmarkManager
from verriere.downloads.manager import (
    DownloadManager,
    DownloadState,
    resolve_safe_destination,
    sanitize_filename,
)
from verriere.history.manager import HistoryManager


def test_french_formatting() -> None:
    assert format_bytes_fr(1536) == "1,5\u202fKo"
    assert format_percent_fr(42.5) == "42,5\u202f%"
    assert format_date_fr("2026-11-28T14:30:00+00:00").endswith("2026")


def test_bookmarks_import_export_filters_unsafe_urls(tmp_path) -> None:
    db = ProfileDatabase(tmp_path / "bm.sqlite3")
    mgr = BookmarkManager(db)
    folder = mgr.create_folder("Essais")
    bm = mgr.add_bookmark("Site sûr", "https://exemple.fr", folder_id=folder.id)
    mgr.update_bookmark(bm.id, title="Site sûr modifié")
    assert mgr.find_by_url("https://exemple.fr").title == "Site sûr modifié"

    html_file = tmp_path / "export.html"
    mgr.export_html(html_file)
    assert "https://exemple.fr" in html_file.read_text(encoding="utf-8")

    # Import HTML contenant un lien javascript: malveillant -> doit être ignoré
    malicious_html = tmp_path / "mal.html"
    malicious_html.write_text(
        '<DL><DT><A HREF="javascript:alert(1)">Piège</A><DT><A HREF="https://bnf.fr">BnF</A></DL>',
        encoding="utf-8",
    )
    count = mgr.import_file(malicious_html)
    assert count == 1
    assert mgr.find_by_url("javascript:alert(1)") is None
    assert mgr.find_by_url("https://bnf.fr") is not None
    db.close()


def test_history_filtering_and_selective_deletion(tmp_path) -> None:
    db = ProfileDatabase(tmp_path / "hist.sqlite3")
    hm = HistoryManager(db, is_private=False)
    hm.record_visit("https://a.exemple.fr", "Article A")
    hm.record_visit("https://b.exemple.fr", "Article B")

    today = hm.search(date_filter="today")
    assert len(today) == 2

    target_id = next(e.id for e in today if "a.exemple.fr" in e.url)
    assert hm.delete_entries([target_id]) == 1
    remaining = hm.search()
    assert len(remaining) == 1 and "b.exemple.fr" in remaining[0].url
    db.close()


def test_download_path_confinement_and_collisions(tmp_path) -> None:
    dl_dir = tmp_path / "downloads"
    assert sanitize_filename("../../etc/passwd") == "passwd"
    assert sanitize_filename("..\\..\\evil.exe") == "evil.exe"

    p1 = resolve_safe_destination(dl_dir, "../../rapport.pdf")
    assert p1.parent == dl_dir.resolve()
    assert p1.name == "rapport.pdf"
    p1.write_bytes(b"ok")

    p2 = resolve_safe_destination(dl_dir, "rapport.pdf")
    assert p2.name == "rapport (1).pdf"

    db = ProfileDatabase(tmp_path / "dl.sqlite3")
    dm = DownloadManager(dl_dir, db=db, is_private=False)
    rec = dm.register_local_download("note.txt", "https://exemple.fr/note.txt", total_bytes=12)
    assert rec.state == DownloadState.IN_PROGRESS
    assert Path(rec.destination_path).parent == dl_dir.resolve()
    dm.mark_completed(rec.id, 12)
    assert dm.list_downloads()[0].state == DownloadState.COMPLETED
    db.close()
