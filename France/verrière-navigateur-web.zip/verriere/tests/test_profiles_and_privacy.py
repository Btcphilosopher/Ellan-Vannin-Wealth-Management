"""Tests unitaires : isolation des profils, espaces vs profils et exclusion privée."""

from __future__ import annotations

from verriere.bookmarks.manager import BookmarkManager
from verriere.history.manager import HistoryManager
from verriere.permissions.manager import PermissionDecision, PermissionManager
from verriere.profiles.manager import ProfileContext, ProfileRegistry
from verriere.workspaces.manager import WORKSPACE_ISOLATION_NOTICE, WorkspaceManager


def test_profile_isolation_and_workspace_distinction(tmp_path) -> None:
    reg = ProfileRegistry(tmp_path / "appdata")
    p_camille = reg.get_active_profile()
    p_travail = reg.create_profile("Travail")

    assert p_camille.id != p_travail.id
    assert reg.profile_dir(p_camille.id) != reg.profile_dir(p_travail.id)

    db_camille = reg.open_profile_database(p_camille.id)
    db_travail = reg.open_profile_database(p_travail.id)

    bm_camille = BookmarkManager(db_camille)
    bm_travail = BookmarkManager(db_travail)
    bm_camille.add_bookmark("Note perso", "https://perso.example.fr")

    assert len(bm_camille.list_bookmarks(query="Note perso")) == 1
    assert len(bm_travail.list_bookmarks(query="Note perso")) == 0

    ws_mgr = WorkspaceManager(db_camille)
    created_ws = ws_mgr.create_workspace("Architecture")
    assert any(w.id == created_ws.id for w in ws_mgr.list_workspaces())
    assert "cookies" in WORKSPACE_ISOLATION_NOTICE.lower()

    db_camille.close()
    db_travail.close()


def test_private_session_excludes_history_and_permissions_from_sqlite(tmp_path) -> None:
    reg = ProfileRegistry(tmp_path / "appdata")
    db = reg.open_profile_database(reg.get_active_profile().id)

    priv_history = HistoryManager(db, is_private=True)
    priv_history.record_visit("https://prive.exemple.fr", title="Page privée", typed=True)
    assert priv_history.search(query="prive") == []
    assert db.connection.execute("SELECT COUNT(*) FROM history_entries").fetchone()[0] == 0

    priv_perms = PermissionManager(db, is_private=True)
    priv_perms.set_decision("https://prive.exemple.fr", "microphone", PermissionDecision.ALLOW, remember=True)
    assert priv_perms.get_decision("https://prive.exemple.fr", "microphone") == PermissionDecision.ALLOW
    # Jamais enregistré dans SQLite
    assert db.connection.execute("SELECT COUNT(*) FROM origin_permissions").fetchone()[0] == 0

    ctx = ProfileContext(
        profile_info=reg.get_active_profile(),
        storage_dir=reg.profile_dir(reg.get_active_profile().id),
        db=db,
        is_private=False,
    )
    normal_hist = HistoryManager(db, is_private=False)
    normal_hist.record_visit("https://exemple.fr", title="Exemple")
    assert len(normal_hist.search()) == 1
    ctx.clear_browsing_data(clear_history=True)
    assert len(normal_hist.search()) == 0
    db.close()
