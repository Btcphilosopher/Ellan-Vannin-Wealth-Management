"""Tests de sécurité : frontières verriere://, suggestions sans course, assistant et mises à jour."""

from __future__ import annotations

import hashlib
import hmac
import time

from verriere.application.storage import ProfileDatabase
from verriere.assistant.client import PageAssistantService, sanitize_untrusted_page_text
from verriere.bookmarks.manager import BookmarkManager
from verriere.downloads.manager import DownloadManager
from verriere.history.manager import HistoryManager
from verriere.internal_pages.scheme import InternalPageRouter
from verriere.navigation.suggestions import SuggestionEngine
from verriere.permissions.manager import PermissionManager
from verriere.profiles.manager import ProfileContext
from verriere.search.providers import SearchEngineManager
from verriere.settings.updates import UpdateManifest, verify_manifest_hmac, verify_package_sha256
from verriere.workspaces.manager import WorkspaceManager


def _make_router(tmp_path):
    db = ProfileDatabase(tmp_path / "sec.sqlite3")
    ctx = ProfileContext(None, tmp_path, db, is_private=False)
    router = InternalPageRouter(
        context=ctx,
        bookmarks=BookmarkManager(db),
        history=HistoryManager(db, is_private=False),
        downloads=DownloadManager(tmp_path / "dl", db=db),
        workspaces=WorkspaceManager(db),
        permissions=PermissionManager(db),
        search_manager=SearchEngineManager(db),
        credentials=None,
    )
    return db, router


def test_internal_pages_origin_and_nonce_boundary(tmp_path) -> None:
    db, router = _make_router(tmp_path)

    status, mime, body = router.resolve_request("verriere://newtab")
    assert status == 200
    assert "text/html" in mime
    assert b"Bonjour, Camille." in body

    # Tentative de traversée de chemin sur verriere://resources/
    s_trav, _, _ = router.resolve_request("verriere://resources/../../pyproject.toml")
    assert s_trav == 404

    # Une origine externe ne peut pas déclencher verriere://action même avec un faux jeton
    s_ext, _, err_body = router.resolve_request(
        f"verriere://action?op=save_settings&nonce={router.session_nonce}",
        initiator_url="https://attaquant.exemple.com/",
    )
    assert s_ext == 403
    assert b"Action interne refus" in err_body

    # Sans jeton valide, même depuis verriere://, refusé
    s_bad_nonce, _, _ = router.resolve_request(
        "verriere://action?op=save_settings&nonce=invalide",
        initiator_url="verriere://settings",
    )
    assert s_bad_nonce == 403
    db.close()


def test_suggestions_cancel_superseded_queries(tmp_path) -> None:
    db = ProfileDatabase(tmp_path / "sug.sqlite3")
    bm = BookmarkManager(db)
    bm.add_bookmark("Architecture Paris", "https://archi.exemple.fr")
    bm.add_bookmark("Musique Baroque", "https://musique.exemple.fr")
    engine = SuggestionEngine(bm, HistoryManager(db), SearchEngineManager(db))

    received: list[tuple[int, list[str]]] = []
    q1 = engine.request_suggestions("archi", lambda qid, items: received.append((qid, [i.title for i in items])), debounce_seconds=0.08)
    # Une deuxième requête annule la première avant son exécution
    q2 = engine.request_suggestions("musique", lambda qid, items: received.append((qid, [i.title for i in items])), debounce_seconds=0.02)

    time.sleep(0.15)
    assert all(qid != q1 for qid, _ in received)
    assert any(qid == q2 and "Musique Baroque" in titles for qid, titles in received)
    db.close()


def test_assistant_disabled_by_default_and_blocks_private_pages(tmp_path) -> None:
    db = ProfileDatabase(tmp_path / "assist.sqlite3")
    svc = PageAssistantService(db, credentials=None)
    assert svc.is_configured() is False

    preview_disabled = svc.prepare_preview(
        page_url="https://exemple.fr",
        page_title="Exemple",
        extracted_text="Texte public",
        selection_only=False,
        is_private_tab=False,
    )
    assert preview_disabled.blocked_reason != ""

    db.set_setting("assistant_enabled", True)
    db.set_setting("assistant_endpoint", "https://api.exemple.fr/v1/chat/completions")
    db.set_setting("assistant_model", "modele-test")
    assert svc.is_configured() is True

    # Bloqué sur onglet privé
    preview_priv = svc.prepare_preview(
        page_url="https://secret.fr",
        page_title="Secret",
        extracted_text="Texte privé",
        selection_only=False,
        is_private_tab=True,
    )
    assert "privée" in preview_priv.blocked_reason.lower()

    sanitized = sanitize_untrusted_page_text("Bonjour password=supersecret token: abc123")
    assert "supersecret" not in sanitized
    db.close()


def test_signed_update_manifest_verification(tmp_path) -> None:
    pkg = tmp_path / "verriere-0.1.1.tar.gz"
    pkg.write_bytes(b"archive-verriere-test")
    sha = hashlib.sha256(pkg.read_bytes()).hexdigest()
    key = b"verriere-test-signing-key"

    manifest_unsigned = UpdateManifest(
        version="0.1.1",
        channel="stable",
        release_date="2026-11-28",
        package_url="https://telechargements.verriere.example/verriere-0.1.1.tar.gz",
        sha256=sha,
        signature_hex="",
        notes_fr="Correctif de stabilité.",
    )
    from verriere.settings.updates import compute_canonical_payload

    sig = hmac.new(key, compute_canonical_payload(manifest_unsigned), hashlib.sha256).hexdigest()
    manifest_signed = UpdateManifest(
        version=manifest_unsigned.version,
        channel=manifest_unsigned.channel,
        release_date=manifest_unsigned.release_date,
        package_url=manifest_unsigned.package_url,
        sha256=sha,
        signature_hex=sig,
        notes_fr=manifest_unsigned.notes_fr,
    )
    assert verify_manifest_hmac(manifest_signed, key) is True
    assert verify_package_sha256(pkg, sha) is True

    # Altération de l'URL ou HTTP non chiffré -> refusé
    tampered = UpdateManifest(
        version="0.1.1",
        channel="stable",
        release_date="2026-11-28",
        package_url="http://evil.example/payload.tar.gz",
        sha256=sha,
        signature_hex=sig,
        notes_fr="",
    )
    assert verify_manifest_hmac(tampered, key) is False
