#!/usr/bin/env bash
# Restauration dans une base VIDE (jamais par-dessus une base en service), puis contrôles d'intégrité.
# Usage : TARGET_DATABASE_URL=postgresql://user:pass@host/base_vide OBJECTS_DIR=./objets-restaures ./scripts/restore.sh backups/<horodatage>
set -euo pipefail
SRC="${1:?dossier de sauvegarde requis}"
: "${TARGET_DATABASE_URL:?TARGET_DATABASE_URL requis}"
(cd "$SRC" && sha256sum -c SHA256SUMS)
pg_restore --no-owner --exit-on-error --dbname "$TARGET_DATABASE_URL" "$SRC/intendance.dump"
if [ -f "$SRC/objects.tar.gz" ] && [ -n "${OBJECTS_DIR:-}" ]; then
  mkdir -p "$OBJECTS_DIR"
  tar -C "$OBJECTS_DIR" -xzf "$SRC/objects.tar.gz"
fi
psql "$TARGET_DATABASE_URL" -v ON_ERROR_STOP=1 \
  -c "SELECT count(*) AS mouvements FROM stock_movements;" \
  -c "SELECT count(*) AS soldes_incoherents FROM stock_balances WHERE reserved > quantity OR quantity < 0;"
echo "Restauration terminée. Le test automatisé backend/tests/test_backup_restore.py rejoue ce cycle et compare les bases."
