#!/usr/bin/env bash
# Sauvegarde : base PostgreSQL (format personnalisé) + objets documentaires + manifeste d'empreintes SHA-256.
# Usage :
#   DATABASE_URL=postgresql://user:pass@host/db OBJECTS_DIR=./backend/var/objects ./scripts/backup.sh [dossier]
#   (stockage S3/MinIO : S3_ALIAS=<alias mc configuré> au lieu d'OBJECTS_DIR)
set -euo pipefail
DEST="${1:-./backups}/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$DEST"
: "${DATABASE_URL:?DATABASE_URL requis (format postgresql://)}"
pg_dump --format=custom --no-owner --file "$DEST/intendance.dump" "$DATABASE_URL"
if [ -n "${OBJECTS_DIR:-}" ] && [ -d "$OBJECTS_DIR" ]; then
  tar -C "$OBJECTS_DIR" -czf "$DEST/objects.tar.gz" .
elif [ -n "${S3_ALIAS:-}" ]; then
  mc mirror --quiet "$S3_ALIAS/intendance-documents" "$DEST/objects"
  tar -C "$DEST" -czf "$DEST/objects.tar.gz" objects
fi
(cd "$DEST" && sha256sum intendance.dump objects.tar.gz 2>/dev/null > SHA256SUMS || sha256sum intendance.dump > SHA256SUMS)
echo "Sauvegarde écrite dans $DEST"
