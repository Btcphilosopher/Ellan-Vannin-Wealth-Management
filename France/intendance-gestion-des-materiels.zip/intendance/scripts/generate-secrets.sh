#!/usr/bin/env bash
# Génère des secrets aléatoires pour la pile Docker Compose (à exécuter une fois ; n'écrase rien).
set -euo pipefail
cd "$(dirname "$0")/../secrets"
umask 077
gen() { openssl rand -base64 48 | tr -d '\n/+=' | cut -c1-40; }
[ -f db_password.txt ] || gen > db_password.txt
[ -f minio_password.txt ] || gen > minio_password.txt
[ -f app_secret_key.txt ] || gen > app_secret_key.txt
printf 'db:5432:intendance:intendance:%s\n' "$(cat db_password.txt)" > pgpass
chmod 600 pgpass
echo "Secrets générés dans $(pwd)"
