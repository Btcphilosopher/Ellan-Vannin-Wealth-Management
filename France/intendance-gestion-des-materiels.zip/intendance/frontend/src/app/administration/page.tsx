"use client";
import { useState } from "react";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Loading, Pager, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost, apiSend } from "@/lib/api";
import { fmtDate, ROLE_LABELS } from "@/lib/labels";

export default function Administration() {
  const { can } = useSession();
  const tabs = [
    ["roles", "Rôles et permissions", true], ["users", "Utilisateurs", can("admin.users")], ["settings", "Règles et seuils", true],
    ["clock", "Horloge de démonstration", true], ["audit", "Journal d'audit", can("audit.read")], ["security", "Sécurité et résilience", true],
  ].filter(([, , ok]) => ok) as [string, string, boolean][];
  const [tab, setTab] = useState(can("admin.users") ? "users" : can("audit.read") ? "audit" : "roles");
  return (
    <PageTitle over="Gouvernance" title="Administration">
      <div className="onglets">{tabs.map(([k, l]) => <button key={k} className={tab === k ? "actif" : ""} onClick={() => setTab(k)}>{l}</button>)}</div>
      {tab === "users" && <Users />}
      {tab === "roles" && <Roles />}
      {tab === "settings" && <Settings />}
      {tab === "clock" && <Clock />}
      {tab === "audit" && <Audit />}
      {tab === "security" && <Security />}
    </PageTitle>
  );
}

function Users() {
  const { data, error, loading, reload } = useApi("/v1/admin/users");
  const orgs = useApi("/v1/organizations");
  const { depots } = useSession();
  const act = useAction();
  const [m, setM] = useState<any>(null);
  const [secret, setSecret] = useState<any>(null);
  if (loading && !data) return <Loading />;
  return (
    <>
      <ErrorBox error={error} />
      {act.feedback}
      {secret && <Alert tone="warn" title="Secret MFA (affiché une seule fois)"><span className="mono">{secret.secret}</span><div className="petit">{secret.provisioning_uri}</div></Alert>}
      {m && (
        <Card title={`Ajouter une appartenance — ${m.user.full_name}`}>
          <div className="grille g3">
            <Field label="Rôle"><select value={m.role} onChange={(e) => setM({ ...m, role: e.target.value })}>{Object.entries(ROLE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
            <Field label="Organisation"><select value={m.org} onChange={(e) => setM({ ...m, org: e.target.value })}>{(orgs.data ?? []).filter((o: any) => o.kind === "SUPPORT").map((o: any) => <option key={o.id} value={o.id}>{o.name}</option>)}</select></Field>
            <Field label="Dépôt (vide = tous les dépôts de l'organisation)"><select value={m.depot} onChange={(e) => setM({ ...m, depot: e.target.value })}><option value="">Tous</option>
              {depots.map((d) => <option key={d.id} value={d.id}>{d.code}</option>)}</select></Field>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button className="btn" onClick={() => act.run(async () => { await apiPost(`/v1/admin/users/${m.user.id}/memberships`, { role_code: m.role, organization_id: m.org, depot_id: m.depot || null }); setM(null); reload(); }, "Appartenance ajoutée.")}>Ajouter</button>
            <button className="btn sec" onClick={() => setM(null)}>Annuler</button></div>
        </Card>
      )}
      <Card flush>
        <table className="tableau"><thead><tr><th>Utilisateur</th><th>Organisation</th><th>Appartenances (rôle · périmètre)</th><th>MFA</th><th>État</th><th /></tr></thead>
          <tbody>{data.map((u: any) => (
            <tr key={u.id}><td>{u.full_name}<div className="mono muted">{u.username}</div></td><td className="petit">{u.organization.name}</td>
              <td className="petit">{u.memberships.map((x: any) => <div key={x.id}>{x.role_label} · {x.depot_code ?? "tous dépôts"}{" "}
                <button className="btn sec petit" onClick={() => act.run(async () => { await apiSend("DELETE", `/v1/admin/users/${u.id}/memberships/${x.id}`); reload(); }, "Appartenance retirée.")}>retirer</button></div>)}
                {u.memberships.length === 0 && <span className="muted">Aucune</span>}</td>
              <td>{u.mfa_enabled ? <Badge tone="ok" label="Activée" /> : <Badge tone="neutre" label="Non" />}</td>
              <td>{u.active ? <Badge tone="ok" label="Actif" /> : <Badge tone="neutre" label="Désactivé" />}</td>
              <td style={{ whiteSpace: "nowrap" }}>
                <button className="btn sec petit" onClick={() => setM({ user: u, role: "VIEWER", org: u.organization.id, depot: "" })}>+ rôle</button>{" "}
                <button className="btn sec petit" onClick={() => act.run(async () => { setSecret(await apiPost(`/v1/admin/users/${u.id}/mfa`)); reload(); })}>Enrôler MFA</button></td></tr>))}
          </tbody></table>
      </Card>
    </>
  );
}

function Roles() {
  const { data } = useApi("/v1/admin/roles");
  if (!data) return <Loading />;
  const perms: string[] = Array.from(new Set(data.flatMap((r: any) => r.permissions))).sort() as string[];
  return (
    <Card title="Matrice des permissions (contrôlée côté serveur)" flush>
      <div className="tableau-wrap"><table className="tableau">
        <thead><tr><th>Permission</th>{data.map((r: any) => <th key={r.code} title={r.description}>{r.label}</th>)}</tr></thead>
        <tbody>{perms.map((p) => <tr key={p}><td className="mono">{p}</td>{data.map((r: any) => <td key={r.code}>{r.permissions.includes(p) ? <Badge tone="ok" label="Oui" /> : <span className="muted">—</span>}</td>)}</tr>)}</tbody>
      </table></div>
    </Card>
  );
}

function Settings() {
  const { can } = useSession();
  const { data, reload } = useApi("/v1/admin/settings");
  const act = useAction();
  const [edit, setEdit] = useState<Record<string, any>>({});
  if (!data) return <Loading />;
  return (
    <>
      {act.feedback}
      <Card title="Séparation des tâches et seuils d'approbation" flush>
        <table className="tableau"><thead><tr><th>Règle</th><th>Description</th><th>Valeur</th><th>Défaut</th>{can("admin.settings") && <th>Modifier (motif requis)</th>}</tr></thead>
          <tbody>{data.map((s: any) => (
            <tr key={s.key}><td className="mono">{s.key}</td><td className="petit">{s.description}</td><td><strong>{String(s.value)}</strong></td><td className="muted">{String(s.default)}</td>
              {can("admin.settings") && <td style={{ whiteSpace: "nowrap" }}>
                {typeof s.default === "boolean"
                  ? <select className="mini" value={String(edit[s.key]?.value ?? s.value)} onChange={(e) => setEdit({ ...edit, [s.key]: { ...edit[s.key], value: e.target.value === "true" } })}><option value="true">vrai</option><option value="false">faux</option></select>
                  : <input className="mini" type="number" value={edit[s.key]?.value ?? s.value} onChange={(e) => setEdit({ ...edit, [s.key]: { ...edit[s.key], value: Number(e.target.value) } })} />}{" "}
                <input className="mini" placeholder="motif" value={edit[s.key]?.reason ?? ""} onChange={(e) => setEdit({ ...edit, [s.key]: { value: edit[s.key]?.value ?? s.value, reason: e.target.value } })} />{" "}
                <button className="btn sec petit" onClick={() => act.run(async () => { await apiSend("PATCH", `/v1/admin/settings/${s.key}`, edit[s.key]); reload(); }, "Paramètre modifié et journalisé.")}>OK</button></td>}</tr>))}</tbody></table>
      </Card>
    </>
  );
}

function Clock() {
  const { can, me, refreshMe } = useSession();
  const act = useAction();
  const [at, setAt] = useState("");
  const [days, setDays] = useState("1");
  const [reason, setReason] = useState("");
  const send = (body: any) => act.run(async () => { await apiPost("/v1/admin/clock", { ...body, reason: reason || "Démonstration" }); refreshMe(); }, "Horloge modifiée (action journalisée).");
  return (
    <Card title="Horloge de démonstration">
      <p>Heure métier actuelle : <strong>{fmtDate(me.clock.now)}</strong> — mode {me.clock.mode === "fixed" ? "figé (démonstration)" : "heure réelle"}.</p>
      <p className="petit muted">Les dates métier (mouvements, échéances, contrôles) suivent cette horloge afin que les données fictives restent cohérentes. Les horodatages techniques
        d'enregistrement restent en heure réelle.</p>
      {act.feedback}
      {can("admin.clock") ? (
        <div className="grille g3">
          <Field label="Motif"><input value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
          <Field label="Fixer à"><div style={{ display: "flex", gap: 6 }}><input type="datetime-local" value={at} onChange={(e) => setAt(e.target.value)} />
            <button className="btn sec petit" onClick={() => send({ at: at ? `${at}:00+01:00` : null })}>Fixer</button></div></Field>
          <Field label="Avancer de (jours)"><div style={{ display: "flex", gap: 6 }}><input type="number" value={days} onChange={(e) => setDays(e.target.value)} />
            <button className="btn sec petit" onClick={() => send({ advance_days: Number(days) })}>Avancer</button>
            <button className="btn sec petit" onClick={() => send({ real_time: true })}>Heure réelle</button></div></Field>
        </div>
      ) : <p className="petit muted">Modification réservée à l'administrateur.</p>}
    </Card>
  );
}

function Audit() {
  const [page, setPage] = useState(1);
  const [outcome, setOutcome] = useState("");
  const [action, setAction] = useState("");
  const [rid, setRid] = useState("");
  const { data, error, loading } = useApi("/v1/audit-events", { page, page_size: 40, outcome, action, request_id: rid });
  return (
    <>
      <div className="barre-outils">
        <Field label="Résultat"><select value={outcome} onChange={(e) => { setOutcome(e.target.value); setPage(1); }}><option value="">Tous</option>
          <option value="SUCCESS">Réussi</option><option value="DENIED">Refusé (accès)</option><option value="REFUSED">Refusé (règle métier)</option></select></Field>
        <Field label="Action (préfixe)"><input value={action} onChange={(e) => { setAction(e.target.value); setPage(1); }} placeholder="transfer., auth., …" /></Field>
        <Field label="Identifiant de requête"><input value={rid} onChange={(e) => { setRid(e.target.value); setPage(1); }} /></Field>
      </div>
      <ErrorBox error={error} />
      <Card flush>
        {loading && !data ? <Loading /> : (
          <div className="tableau-wrap"><table className="tableau">
            <thead><tr><th>N°</th><th>Date métier</th><th>Acteur</th><th>Action</th><th>Résultat</th><th>Objet</th><th>Motif</th><th>Requête</th></tr></thead>
            <tbody>{data?.items.map((e: any) => (
              <tr key={e.id}><td className="mono">{e.seq}</td><td className="petit">{fmtDate(e.occurred_at)}<div className="muted">enr. {fmtDate(e.recorded_at)}</div></td>
                <td className="petit">{e.actor_name ?? "—"}</td><td className="mono petit">{e.action}</td><td><Badge code={e.outcome} /></td>
                <td className="petit">{e.object_type} <span className="mono">{e.object_ref}</span></td><td className="petit">{e.reason}</td>
                <td className="mono petit" title={e.request_id}>{e.request_id?.slice(0, 12)}</td></tr>))}</tbody></table></div>)}
        {data && <Pager page={page} total={data.total} pageSize={40} onPage={setPage} />}
      </Card>
    </>
  );
}

function Security() {
  return (
    <Card title="Sécurité et résilience du prototype">
      <Alert tone="danger" title="Classification">Prototype de démonstration non apte au traitement d'informations classifiées. Données exclusivement fictives.</Alert>
      <ul>
        <li>Sessions serveur (jeton haché SHA-256), cookie <span className="mono">HttpOnly</span>, <span className="mono">SameSite=Strict</span>, <span className="mono">Secure</span> en production ; expiration absolue et d'inactivité ; protection CSRF.</li>
        <li>MFA via adaptateur (TOTP RFC 6238 opérationnel) ; obligatoire pour les rôles configurés ; verrouillage après échecs répétés.</li>
        <li>Authentification organisationnelle : adaptateur LOCAL opérationnel, adaptateur OIDC prévu (non branché).</li>
        <li>Permissions vérifiées côté serveur par organisation et dépôt ; séparation création / approbation / correction configurable.</li>
        <li>Journal des mouvements et journal d'audit non modifiables (déclencheurs PostgreSQL) ; refus d'accès et refus de règles journalisés avec identifiant de requête.</li>
        <li>Documents : liste blanche de types vérifiée sur le contenu, taille plafonnée, stockage objet hors application, empreinte vérifiée au téléchargement.</li>
        <li>Journaux applicatifs expurgés (mots de passe, jetons, cookies) ; secrets par variables d'environnement ou fichiers de secrets.</li>
        <li>Sauvegarde (pg_dump + objets) et restauration scriptées ; restauration vérifiée par un test automatisé.</li>
      </ul>
    </Card>
  );
}
