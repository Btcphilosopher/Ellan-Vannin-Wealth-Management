"use client";
import Link from "next/link";
import { Badge, Card, ErrorBox, Loading, PageTitle, useApi } from "@/components/ui";
import { fmtQty } from "@/lib/labels";

export default function Depots() {
  const { data, error, loading } = useApi("/v1/depots");
  if (loading && !data) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  return (
    <PageTitle over="Implantations" title="Dépôts">
      <div className="grille g2">
        {data.map((d: any) => (
          <Card key={d.id} title={d.name} num={d.code} right={<Badge tone={d.active ? "ok" : "neutre"} label={d.active ? "Actif" : "Inactif"} />}>
            <p className="petit muted" style={{ marginTop: 0 }}>{d.address}</p>
            <div className="grille g4" style={{ gap: 8, marginBottom: 12 }}>
              {[["Physique", d.totals.physical], ["Disponible", d.totals.available], ["Réservé", d.totals.reserved], ["Bloqué", d.totals.blocked]].map(([l, v]) => (
                <div key={l as string} className="carte" style={{ padding: "8px 10px" }}>
                  <div className="petit muted">{l}</div><div style={{ fontFamily: "var(--serif)", fontSize: 22 }}>{fmtQty(v as number)}</div>
                </div>
              ))}
            </div>
            <div className="petit" style={{ marginBottom: 8 }}>{fmtQty(d.totals.in_transit)} unité(s) en transit vers ce dépôt · {d.asset_count} exemplaire(s) sérialisé(s) présents</div>
            <table className="tableau">
              <thead><tr><th>Emplacement</th><th>Type</th><th>Étiquette</th><th /></tr></thead>
              <tbody>{d.locations.map((l: any) => (
                <tr key={l.id}><td className="mono">{l.code}<div className="petit muted" style={{ fontFamily: "var(--sans)" }}>{l.label}</div></td><td>{l.kind_label}</td>
                  <td className="mono">{l.internal_tag}</td>
                  <td style={{ whiteSpace: "nowrap" }}><Link className="btn sec petit" href={`/stocks?location=${l.id}&depot=${d.id}`}>Contenu</Link>{" "}
                    <a className="btn sec petit" href={`/v1/labels/locations/${l.id}.svg`} target="_blank" rel="noreferrer">Étiquette</a></td></tr>))}
              </tbody>
            </table>
          </Card>
        ))}
      </div>
    </PageTitle>
  );
}
