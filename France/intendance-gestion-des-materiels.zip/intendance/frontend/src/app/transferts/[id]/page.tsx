"use client";
import Link from "next/link";
import { use, useState } from "react";
import MovementsPanel from "@/components/MovementsPanel";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Flow, Loading, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { flowStep, TRANSFER_FLOW } from "@/lib/flows";
import { fmtDate, fmtQty } from "@/lib/labels";

export default function TransferPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { can } = useSession();
  const { data: t, error, loading, setData } = useApi(`/v1/transfers/${id}`);
  const act = useAction();
  const [comment, setComment] = useState("");
  const [carrier, setCarrier] = useState("");
  const [waybill, setWaybill] = useState("");
  const [arr, setArr] = useState<Record<string, any>>({});
  const [rec, setRec] = useState<Record<string, any>>({});
  const [assetState, setAssetState] = useState<Record<string, string>>({});
  if (loading && !t) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  const post = (path: string, body: any, msg: string) => act.run(async () => setData(await apiPost(`/v1/transfers/${id}/${path}`, { version: t.version, ...body })), msg);
  const gap = t.lines.reduce((a: number, l: any) => a + l.discrepancy_qty, 0);
  return (
    <PageTitle over={`Transfert · ${t.source_depot.code} → ${t.destination_depot.code}`} title={t.reference} actions={<Badge code={t.status} />}>
      <Flow steps={TRANSFER_FLOW} current={flowStep(t.status)} />
      <div className="grille g2" style={{ marginTop: 12 }}>
        <Card title="Suivi">
          <dl className="def">
            <dt>Motif</dt><dd>{t.reason}</dd>
            <dt>Demandé</dt><dd>{t.requested_by} — {fmtDate(t.requested_at)}</dd>
            <dt>Approuvé</dt><dd>{t.approved_by ? `${t.approved_by} — ${fmtDate(t.approved_at)}` : "—"}</dd>
            <dt>Expédié</dt><dd>{t.dispatched_by ? `${t.dispatched_by} — ${fmtDate(t.dispatched_at)}` : "—"} {t.carrier && <div className="petit">{t.carrier} · <span className="mono">{t.waybill_ref}</span></div>}</dd>
            <dt>Réceptionné</dt><dd>{t.received_by ? `${t.received_by} — ${fmtDate(t.received_at)}` : "—"}</dd>
            <dt>Rapproché</dt><dd>{t.reconciled_by ? `${t.reconciled_by} — ${fmtDate(t.reconciled_at)}` : "—"}</dd>
          </dl>
          {t.status === "IN_TRANSIT" && <Alert tone="warn" title="En transit">Quantités absentes des deux dépôts ; réception par le dépôt {t.destination_depot.code} uniquement.</Alert>}
          {t.status === "RECEIVED" && gap > 0 && <Alert tone="danger" title="Écart restant à traiter">{fmtQty(gap)} unité(s) expédiée(s) non constatée(s) à l'arrivée.</Alert>}
        </Card>
        <Card title="Actions métier">
          {act.feedback}
          {t.status === "REQUESTED" && can("transfer.approve", t.source_depot.id) && (<>
            <Field label="Commentaire"><input value={comment} onChange={(e) => setComment(e.target.value)} /></Field>
            <div style={{ display: "flex", gap: 8 }}><button className="btn" onClick={() => post("approval", { decision: "APPROVE", comment }, "Transfert approuvé.")}>Approuver</button>
              <button className="btn danger" onClick={() => post("approval", { decision: "REJECT", comment }, "Transfert rejeté.")}>Rejeter</button></div></>)}
          {t.status === "APPROVED" && can("transfer.dispatch", t.source_depot.id) && <button className="btn" onClick={() => post("reservation", {}, "Stock réservé au dépôt d'origine.")}>Réserver au dépôt d'origine</button>}
          {t.status === "RESERVED" && can("transfer.dispatch", t.source_depot.id) && (<>
            <div className="grille g2"><Field label="Transporteur"><input value={carrier} onChange={(e) => setCarrier(e.target.value)} /></Field>
              <Field label="N° de lettre de voiture"><input value={waybill} onChange={(e) => setWaybill(e.target.value)} /></Field></div>
            <button className="btn" onClick={() => post("dispatch", { carrier, waybill_ref: waybill }, "Expédition enregistrée : stock en transit.")}>Expédier</button></>)}
          {t.status === "IN_TRANSIT" && <p className="petit muted">Saisir les quantités constatées dans le tableau, puis confirmer la réception.</p>}
          {t.status === "RECEIVED" && <p className="petit muted">Pour chaque écart : « retrouvé » (entrée tardive) ou « perte » (justification + approbateur).</p>}
        </Card>
      </div>
      <div style={{ marginTop: 16 }}>
        <Card title="Lignes : quantités conservées séparément" flush>
          <div className="tableau-wrap"><table className="tableau">
            <thead><tr><th>#</th><th>Article</th><th className="n">Demandé</th><th className="n">Réservé</th><th className="n">Expédié</th><th className="n">Reçu</th>
              <th className="n">Endommagé</th><th className="n">Perte</th><th className="n">Écart restant</th><th>Saisie</th></tr></thead>
            <tbody>{t.lines.map((l: any) => {
              const a = arr[l.id] ?? { received_qty: l.in_transit_qty, damaged_qty: 0, note: "", missing: "", damaged_ids: "" };
              const r = rec[l.id] ?? { action: "FOUND", quantity: l.discrepancy_qty, justification: "" };
              return (
                <tr key={l.id}>
                  <td>{l.line_no}</td><td><span className="mono">{l.item_code}</span><div className="petit">{l.designation} {l.variant_label ?? ""}</div>
                    {l.assets.length > 0 && <div className="petit">{l.assets.map((x: any) => <span key={x.id}><Link href={`/equipements/${x.id}`}>{x.serial_number}</Link> <Badge code={x.lifecycle} /> </span>)}</div>}</td>
                  <td className="n">{fmtQty(l.requested_qty)}</td><td className="n">{fmtQty(l.reserved_qty)}</td><td className="n">{fmtQty(l.shipped_qty)}</td>
                  <td className="n">{fmtQty(l.received_qty)}</td><td className="n">{fmtQty(l.damaged_qty)}</td><td className="n">{fmtQty(l.written_off_qty)}</td>
                  <td className="n">{l.discrepancy_qty ? <Badge tone="danger" label={fmtQty(l.discrepancy_qty)} /> : l.in_transit_qty ? <Badge tone="warn" label={`${fmtQty(l.in_transit_qty)} en transit`} /> : "0"}
                    {l.discrepancy_note && <div className="petit muted">{l.discrepancy_note}</div>}</td>
                  <td>
                    {t.status === "IN_TRANSIT" && can("transfer.receive", t.destination_depot.id) && l.tracking !== "SERIAL" && (
                      <div style={{ display: "grid", gap: 4 }}>
                        <label className="petit">Bon état <input className="mini" type="number" min={0} value={a.received_qty} onChange={(e) => setArr({ ...arr, [l.id]: { ...a, received_qty: e.target.value } })} /></label>
                        <label className="petit">Endommagé <input className="mini" type="number" min={0} value={a.damaged_qty} onChange={(e) => setArr({ ...arr, [l.id]: { ...a, damaged_qty: e.target.value } })} /></label>
                        <input className="mini" placeholder="Constat" value={a.note} onChange={(e) => setArr({ ...arr, [l.id]: { ...a, note: e.target.value } })} />
                      </div>)}
                    {t.status === "IN_TRANSIT" && l.tracking === "SERIAL" && can("transfer.receive", t.destination_depot.id) && (
                      <div style={{ display: "grid", gap: 4 }}>{l.assets.map((x: any) => (
                        <label key={x.id} className="petit">{x.serial_number}{" "}
                          <select className="mini" value={assetState[x.id] ?? "OK"} onChange={(e) => setAssetState({ ...assetState, [x.id]: e.target.value })}>
                            <option value="OK">Reçu</option><option value="DAMAGED">Endommagé</option><option value="MISSING">Manquant</option></select></label>))}</div>)}
                    {t.status === "RECEIVED" && l.discrepancy_qty > 0 && l.tracking !== "SERIAL" && (
                      <div style={{ display: "grid", gap: 4 }}>
                        <select className="mini" value={r.action} onChange={(e) => setRec({ ...rec, [l.id]: { ...r, action: e.target.value } })}>
                          <option value="FOUND">Retrouvé (entrée tardive)</option><option value="WRITE_OFF">Perte (approbateur)</option></select>
                        <input className="mini" type="number" min={0} max={l.discrepancy_qty} value={r.quantity} onChange={(e) => setRec({ ...rec, [l.id]: { ...r, quantity: e.target.value } })} />
                        <input className="mini" placeholder="Justification (≥ 10 caractères)" value={r.justification} onChange={(e) => setRec({ ...rec, [l.id]: { ...r, justification: e.target.value } })} />
                      </div>)}
                  </td>
                </tr>);
            })}</tbody>
          </table></div>
        </Card>
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
        {t.status === "IN_TRANSIT" && can("transfer.receive", t.destination_depot.id) && <button className="btn laiton" disabled={act.busy} onClick={() => post("receipt", {
          lines: t.lines.map((l: any) => {
            if (l.tracking === "SERIAL") {
              const st = (x: any) => assetState[x.id] ?? "OK";
              return { line_id: l.id, received_qty: l.assets.filter((x: any) => st(x) === "OK").length,
                damaged_qty: l.assets.filter((x: any) => st(x) === "DAMAGED").length,
                damaged_asset_ids: l.assets.filter((x: any) => st(x) === "DAMAGED").map((x: any) => x.id),
                missing_asset_ids: l.assets.filter((x: any) => st(x) === "MISSING").map((x: any) => x.id) };
            }
            const a = arr[l.id] ?? { received_qty: l.in_transit_qty, damaged_qty: 0, note: "" };
            return { line_id: l.id, received_qty: Number(a.received_qty), damaged_qty: Number(a.damaged_qty), note: a.note };
          }) }, "Réception enregistrée au dépôt destinataire.")}>Confirmer la réception</button>}
        {t.status === "RECEIVED" && (can("transfer.receive", t.destination_depot.id) || can("transfer.reconcile", t.destination_depot.id) || can("transfer.writeoff_approve", t.destination_depot.id)) && <button className="btn laiton" disabled={act.busy} onClick={() => post("reconciliation", {
          lines: t.lines.filter((l: any) => l.discrepancy_qty > 0 && rec[l.id]).map((l: any) => ({ line_id: l.id, action: rec[l.id].action,
            quantity: Number(rec[l.id].quantity), justification: rec[l.id].justification })) }, "Rapprochement enregistré.")}>Rapprocher</button>}
      </div>
      <div style={{ marginTop: 16 }}><MovementsPanel sourceId={t.id} /></div>
    </PageTitle>
  );
}
