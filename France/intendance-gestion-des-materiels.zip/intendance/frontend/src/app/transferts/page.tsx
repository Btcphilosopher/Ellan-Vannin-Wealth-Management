"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import LinesEditor, { LineDraft } from "@/components/ItemPicker";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Flow, Loading, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { TRANSFER_FLOW } from "@/lib/flows";
import { fmtDate, fmtQty } from "@/lib/labels";

function Transferts() {
  const sp = useSearchParams();
  const { depotId, can } = useSession();
  const [status, setStatus] = useState(sp.get("status") ?? "");
  const [creating, setCreating] = useState(false);
  const { data, error, loading } = useApi("/v1/transfers", { depot_id: depotId || undefined, status, page_size: 50 });
  return (
    <PageTitle over="Flux inter-dépôts" title="Transferts"
               actions={can("transfer.create") && <button className="btn" onClick={() => setCreating(!creating)}>{creating ? "Fermer" : "Nouveau transfert"}</button>}>
      <Flow steps={TRANSFER_FLOW} />
      <Alert tone="info" title="En transit">Un matériel expédié n'est disponible dans aucun des deux dépôts jusqu'à sa réception, confirmée par un agent habilité du dépôt destinataire.</Alert>
      {creating && <NewTransfer />}
      <div className="barre-outils"><Field label="Statut"><select value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="">Tous</option><option value="REQUESTED,APPROVED,RESERVED,IN_TRANSIT,RECEIVED">En cours</option><option value="IN_TRANSIT">En transit</option>
        <option value="RECEIVED">Écart / rapprochement à faire</option><option value="RECONCILED">Rapprochés</option></select></Field></div>
      <ErrorBox error={error} />
      <Card flush>
        {loading && !data ? <Loading /> : (
          <div className="tableau-wrap"><table className="tableau">
            <thead><tr><th>Référence</th><th>Origine → destination</th><th>Statut</th><th className="n">Expédié</th><th className="n">Reçu</th><th className="n">Endommagé</th><th className="n">Perte</th><th>Transporteur</th><th>Expédié le</th></tr></thead>
            <tbody>{data?.items.map((t: any) => (
              <tr key={t.id}><td><Link className="mono" href={`/transferts/${t.id}`}>{t.reference}</Link></td><td>{t.source_depot.code} → {t.destination_depot.code}</td>
                <td><Badge code={t.status} /></td><td className="n">{fmtQty(t.totals.shipped_qty)}</td><td className="n">{fmtQty(t.totals.received_qty)}</td>
                <td className="n">{fmtQty(t.totals.damaged_qty)}</td><td className="n">{fmtQty(t.totals.written_off_qty)}</td>
                <td className="petit">{t.carrier ?? "—"}<div className="mono muted">{t.waybill_ref}</div></td><td className="petit">{fmtDate(t.dispatched_at)}</td></tr>))}
              {data?.items.length === 0 && <tr><td colSpan={9} className="vide">Aucun transfert.</td></tr>}
            </tbody></table></div>)}
      </Card>
    </PageTitle>
  );
}

function NewTransfer() {
  const router = useRouter();
  const { depots } = useSession();
  const [src, setSrc] = useState(depots[0]?.id ?? "");
  const [dst, setDst] = useState(depots[1]?.id ?? "");
  const [reason, setReason] = useState("");
  const [lines, setLines] = useState<LineDraft[]>([{ item_id: "", variant_id: "", unit: "", quantity: "" }]);
  const act = useAction();
  const submit = () => act.run(async () => {
    const t = await apiPost("/v1/transfers", { source_depot_id: src, destination_depot_id: dst, reason,
      lines: lines.filter((l) => l.item_id).map((l) => ({ item_id: l.item_id, variant_id: l.variant_id || null, unit: l.unit || null, quantity: Number(l.quantity) })) });
    router.push(`/transferts/${t.id}`);
  });
  return (
    <Card title="Nouveau transfert">
      <div className="grille g3">
        <Field label="Dépôt d'origine"><select value={src} onChange={(e) => setSrc(e.target.value)}>{depots.map((d) => <option key={d.id} value={d.id}>{d.code}</option>)}</select></Field>
        <Field label="Dépôt destinataire"><select value={dst} onChange={(e) => setDst(e.target.value)}>{depots.map((d) => <option key={d.id} value={d.id}>{d.code}</option>)}</select></Field>
        <Field label="Motif"><input value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
      </div>
      <p className="petit muted">Le dépôt destinataire doit figurer dans votre périmètre de lecture pour apparaître ici.</p>
      <LinesEditor lines={lines} setLines={setLines} />
      {act.feedback}
      <button className="btn" onClick={submit} disabled={act.busy}>Demander le transfert</button>
    </Card>
  );
}

export default function Page() {
  return <Suspense><Transferts /></Suspense>;
}
