"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import LinesEditor, { LineDraft } from "@/components/ItemPicker";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Flow, Loading, Pager, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { REQUEST_FLOW } from "@/lib/flows";
import { fmtDate, fmtQty } from "@/lib/labels";

function Dotations() {
  const sp = useSearchParams();
  const { depotId, can } = useSession();
  const [tab, setTab] = useState(sp.get("onglet") ?? "demandes");
  const [status, setStatus] = useState(sp.get("status") ?? "");
  const [page, setPage] = useState(1);
  const [creating, setCreating] = useState(false);
  const reqs = useApi(tab === "demandes" ? "/v1/requests" : null, { depot_id: depotId || undefined, status, page, page_size: 20 });
  const allocs = useApi(tab !== "demandes" ? "/v1/allocations" : null, { depot_id: depotId || undefined, loans_only: tab === "prets", overdue_only: tab === "retards" });
  return (
    <PageTitle over="Affectations" title="Demandes et dotations"
               actions={can("request.create") && <button className="btn" onClick={() => setCreating(!creating)}>{creating ? "Fermer" : "Nouvelle demande"}</button>}>
      <Flow steps={REQUEST_FLOW} />
      <Alert tone="info" title="Principes">Une réservation n'est pas une remise ; une remise n'est pas nécessairement une consommation. Les remises partielles sont autorisées.</Alert>
      {creating && <NewRequest />}
      <div className="onglets">
        {[["demandes", "Demandes"], ["dotations", "Remises effectuées"], ["prets", "Prêts"], ["retards", "Prêts échus"]].map(([k, l]) =>
          <button key={k} className={tab === k ? "actif" : ""} onClick={() => { setTab(k); setPage(1); }}>{l}</button>)}
      </div>
      {tab === "demandes" ? (
        <>
          <div className="barre-outils"><Field label="Statut"><select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
            <option value="">Tous</option><option value="SUBMITTED,REVIEWED,APPROVED">En attente</option><option value="REVIEWED">À approuver</option>
            <option value="RESERVED,IN_PREPARATION,PARTIALLY_ISSUED">En cours de remise</option><option value="ISSUED,CLOSED">Terminées</option></select></Field></div>
          <ErrorBox error={reqs.error} />
          <Card flush>
            {reqs.loading && !reqs.data ? <Loading /> : (
              <div className="tableau-wrap"><table className="tableau">
                <thead><tr><th>Référence</th><th>Bénéficiaire</th><th>Destination administrative</th><th>Responsable</th><th>Dépôt</th><th>Statut</th><th className="n">Demandé</th><th className="n">Remis</th><th>Créée</th></tr></thead>
                <tbody>{reqs.data?.items.map((r: any) => (
                  <tr key={r.id}><td><Link className="mono" href={`/dotations/${r.id}`}>{r.reference}</Link></td><td>{r.beneficiary.name}</td>
                    <td className="petit">{r.administrative_destination}</td><td className="petit">{r.responsible_name}</td><td>{r.depot.code}</td><td><Badge code={r.status} /></td>
                    <td className="n">{fmtQty(r.lines.reduce((a: number, l: any) => a + l.requested_qty, 0))}</td>
                    <td className="n">{fmtQty(r.lines.reduce((a: number, l: any) => a + l.issued_qty, 0))}</td><td className="petit">{fmtDate(r.submitted_at)}</td></tr>))}
                  {reqs.data?.items.length === 0 && <tr><td colSpan={9} className="vide">Aucune demande.</td></tr>}
                </tbody></table></div>)}
            {reqs.data && <Pager page={page} total={reqs.data.total} pageSize={20} onPage={setPage} />}
          </Card>
        </>
      ) : (
        <Card flush>
          {allocs.loading && !allocs.data ? <Loading /> : (
            <div className="tableau-wrap"><table className="tableau">
              <thead><tr><th>Remise</th><th>Demande</th><th>Bénéficiaire</th><th>Remis à</th><th>Justificatif</th><th>Lignes</th><th>Date</th></tr></thead>
              <tbody>{allocs.data?.items.map((a: any) => (
                <tr key={a.id}><td><Link className="mono" href={`/dotations/dotation/${a.id}`}>{a.reference}</Link></td>
                  <td><Link className="mono" href={`/dotations/${a.request_id}`}>{a.request_reference}</Link></td><td>{a.beneficiary.name}</td><td className="petit">{a.recipient_name}</td>
                  <td className="mono">{a.proof_reference}</td>
                  <td className="petit">{a.lines.map((l: any) => (
                    <div key={l.id}>{l.asset ? l.asset.serial_number : `${fmtQty(l.quantity)} × ${l.item_code} ${l.variant_label ?? ""}`}
                      {l.kind === "LOAN" && <> · échéance {fmtDate(l.due_date, false)} {l.overdue ? <Badge tone="danger" label="Échu" /> : l.outstanding_qty === 0 ? <Badge tone="ok" label="Rendu" /> : null}</>}</div>))}</td>
                  <td className="petit">{fmtDate(a.issued_at)}</td></tr>))}
                {allocs.data?.items.length === 0 && <tr><td colSpan={7} className="vide">Aucune remise.</td></tr>}
              </tbody></table></div>)}
        </Card>
      )}
    </PageTitle>
  );
}

function NewRequest() {
  const router = useRouter();
  const { depots, depotId } = useSession();
  const orgs = useApi("/v1/organizations", { kind: "BENEFICIARY" });
  const [f, setF] = useState({ depot_id: depotId || depots[0]?.id || "", beneficiary_org_id: "", responsible_name: "", administrative_destination: "", justification: "", needed_by: "" });
  const [lines, setLines] = useState<LineDraft[]>([{ item_id: "", variant_id: "", unit: "", quantity: "", kind: "ALLOCATION" }]);
  const act = useAction();
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  const submit = () => act.run(async () => {
    const r = await apiPost("/v1/requests", {
      ...f, needed_by: f.needed_by || null, submit: true,
      lines: lines.filter((l) => l.item_id).map((l) => ({ item_id: l.item_id, variant_id: l.variant_id || null, unit: l.unit || null, quantity: Number(l.quantity),
        kind: l.kind ?? "ALLOCATION", due_date: l.kind === "LOAN" ? l.due_date : null })),
    });
    router.push(`/dotations/${r.id}`);
  });
  return (
    <Card title="Nouvelle demande de dotation">
      <div className="grille g3">
        <Field label="Dépôt fournisseur"><select value={f.depot_id} onChange={set("depot_id")}>{depots.map((d) => <option key={d.id} value={d.id}>{d.code}</option>)}</select></Field>
        <Field label="Bénéficiaire organisationnel"><select value={f.beneficiary_org_id} onChange={set("beneficiary_org_id")}><option value="">—</option>
          {(orgs.data ?? []).map((o: any) => <option key={o.id} value={o.id}>{o.name}</option>)}</select></Field>
        <Field label="Responsable"><input value={f.responsible_name} onChange={set("responsible_name")} /></Field>
        <Field label="Destination administrative"><input value={f.administrative_destination} onChange={set("administrative_destination")} /></Field>
        <Field label="Besoin pour le"><input type="date" value={f.needed_by} onChange={set("needed_by")} /></Field>
        <Field label="Justification"><input value={f.justification} onChange={set("justification")} /></Field>
      </div>
      <LinesEditor lines={lines} setLines={setLines} withLoan />
      {act.feedback}
      <button className="btn" onClick={submit} disabled={act.busy}>Soumettre la demande</button>
    </Card>
  );
}

export default function Page() {
  return <Suspense><Dotations /></Suspense>;
}
