"use client";
import Link from "next/link";
import { use, useState } from "react";
import MovementsPanel from "@/components/MovementsPanel";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Flow, Loading, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { flowStep, REQUEST_FLOW } from "@/lib/flows";
import { fmtDate, fmtQty } from "@/lib/labels";

export default function RequestPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { can, me } = useSession();
  const { data: r, error, loading, setData, reload } = useApi(`/v1/requests/${id}`);
  const act = useAction();
  const [comment, setComment] = useState("");
  const [approved, setApproved] = useState<Record<string, string>>({});
  const [issue, setIssue] = useState<Record<string, string>>({});
  const [recipient, setRecipient] = useState("");
  const [proof, setProof] = useState("");
  if (loading && !r) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  const post = (path: string, body: any, msg: string) => act.run(async () => setData(await apiPost(`/v1/requests/${id}/${path}`, { version: r.version, ...body })), msg);
  const issueNow = () => act.run(async () => {
    await apiPost("/v1/allocations", {
      request_id: r.id, version: r.version, recipient_name: recipient, proof_reference: proof,
      lines: r.lines.map((l: any) => ({ request_line_id: l.id, quantity: Number(issue[l.id] ?? 0) })).filter((x: any) => x.quantity > 0),
    });
    setIssue({});
    await reload();
  }, "Remise enregistrée (justificatif référencé).");
  const ownRequest = r.created_by_id === me.id;

  return (
    <PageTitle over={`Demande · ${r.depot.name}`} title={r.reference} actions={<Badge code={r.status} />}>
      <Flow steps={REQUEST_FLOW} current={flowStep(r.status)} />
      <div className="grille g2" style={{ marginTop: 12 }}>
        <Card title="Demande">
          <dl className="def">
            <dt>Bénéficiaire organisationnel</dt><dd>{r.beneficiary.name}</dd>
            <dt>Responsable</dt><dd>{r.responsible_name}</dd>
            <dt>Destination administrative</dt><dd>{r.administrative_destination}</dd>
            <dt>Justification</dt><dd>{r.justification || "—"}</dd>
            <dt>Besoin pour le</dt><dd>{fmtDate(r.needed_by, false)}</dd>
            <dt>Créée par</dt><dd>{r.created_by} — {fmtDate(r.submitted_at)}</dd>
            <dt>Revue</dt><dd>{r.reviewed_by ? `${r.reviewed_by} — ${fmtDate(r.reviewed_at)} : ${r.review_comment}` : "—"}</dd>
            <dt>Décision</dt><dd>{r.decided_by ? `${r.decided_by} — ${fmtDate(r.decided_at)} : ${r.decision_comment}` : "—"}</dd>
          </dl>
        </Card>
        <Card title="Actions métier">
          {act.feedback}
          {r.status === "SUBMITTED" && can("request.review", r.depot.id) && (<>
            <Field label="Commentaire de revue"><input value={comment} onChange={(e) => setComment(e.target.value)} /></Field>
            <button className="btn" onClick={() => post("review", { comment }, "Revue enregistrée.")}>Valider la revue</button></>)}
          {r.status === "REVIEWED" && can("request.approve", r.depot.id) && (<>
            {ownRequest && <Alert tone="warn" title="Séparation des tâches">Vous êtes l'auteur de cette demande : l'approbation sera refusée.</Alert>}
            <Field label="Commentaire de décision"><input value={comment} onChange={(e) => setComment(e.target.value)} /></Field>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn" onClick={() => post("approval", { decision: "APPROVE", comment,
                lines: r.lines.map((l: any) => ({ line_id: l.id, approved_qty: Number(approved[l.id] ?? l.requested_qty) })) }, "Demande approuvée.")}>Approuver</button>
              <button className="btn danger" onClick={() => post("approval", { decision: "REJECT", comment }, "Demande rejetée.")}>Rejeter</button>
            </div></>)}
          {["APPROVED", "RESERVED"].includes(r.status) && can("request.reserve", r.depot.id) && r.lines.some((l: any) => l.reserved_open_qty + l.issued_qty < l.approved_qty) &&
            <button className="btn" onClick={() => post("reservation", { allow_partial: true }, "Réservation effectuée sur le stock disponible contrôlé.")}>Réserver le disponible</button>}
          {r.status === "RESERVED" && can("request.issue", r.depot.id) && <button className="btn sec" style={{ marginLeft: 8 }} onClick={() => post("preparation", {}, "Préparation lancée.")}>Lancer la préparation</button>}
          {["IN_PREPARATION", "PARTIALLY_ISSUED"].includes(r.status) && can("request.issue", r.depot.id) && (<>
            <p className="petit muted">Remise partielle autorisée : saisir les quantités effectivement remises.</p>
            <div className="grille g2">
              <Field label="Remis à (nom)"><input value={recipient} onChange={(e) => setRecipient(e.target.value)} /></Field>
              <Field label="Référence du justificatif signé"><input value={proof} onChange={(e) => setProof(e.target.value)} placeholder="JR-…" /></Field>
            </div>
          </>)}
          {!["CLOSED", "CANCELLED", "REJECTED"].includes(r.status) && can("request.close", r.depot.id) &&
            <div style={{ marginTop: 10 }}><button className="btn sec" onClick={() => post("close", { reason: comment || "Clôture" }, "Demande clôturée ; reliquats réservés libérés.")}>Clôturer (libère les reliquats)</button></div>}
        </Card>
      </div>

      <div style={{ marginTop: 16 }}>
        <Card title="Lignes" flush>
          <div className="tableau-wrap"><table className="tableau">
            <thead><tr><th>#</th><th>Article</th><th>Nature</th><th className="n">Demandé</th><th className="n">Approuvé</th><th className="n">Réservé (non remis)</th><th className="n">Remis</th><th className="n">Reste</th><th>Saisie</th></tr></thead>
            <tbody>{r.lines.map((l: any) => (
              <tr key={l.id}>
                <td>{l.line_no}</td><td><span className="mono">{l.item_code}</span><div className="petit">{l.designation}{l.variant_label && ` — ${l.variant_label}`}</div></td>
                <td><Badge code={l.kind} />{l.due_date && <div className="petit">échéance {fmtDate(l.due_date, false)}</div>}</td>
                <td className="n">{fmtQty(l.requested_qty, l.base_unit)}</td><td className="n">{fmtQty(l.approved_qty)}</td>
                <td className="n">{fmtQty(l.reserved_open_qty)}</td><td className="n">{fmtQty(l.issued_qty)}</td><td className="n">{fmtQty(l.remaining_to_issue)}</td>
                <td>{r.status === "REVIEWED" && can("request.approve", r.depot.id) &&
                  <input className="mini" type="number" min={0} max={l.requested_qty} value={approved[l.id] ?? l.requested_qty} aria-label="Quantité approuvée"
                         onChange={(e) => setApproved({ ...approved, [l.id]: e.target.value })} />}
                  {["IN_PREPARATION", "PARTIALLY_ISSUED"].includes(r.status) && can("request.issue", r.depot.id) && l.reserved_open_qty > 0 &&
                    <input className="mini" type="number" min={0} max={l.reserved_open_qty} placeholder={`≤ ${l.reserved_open_qty}`} aria-label="Quantité remise"
                           value={issue[l.id] ?? ""} onChange={(e) => setIssue({ ...issue, [l.id]: e.target.value })} />}</td>
              </tr>))}</tbody>
          </table></div>
        </Card>
      </div>
      {["IN_PREPARATION", "PARTIALLY_ISSUED"].includes(r.status) && can("request.issue", r.depot.id) &&
        <div style={{ marginTop: 10 }}><button className="btn laiton" disabled={act.busy} onClick={issueNow}>Enregistrer la remise</button></div>}

      <div className="grille g2" style={{ marginTop: 16 }}>
        <Card title="Remises effectuées" flush>
          <table className="tableau"><thead><tr><th>Remise</th><th>Date</th><th>Remis à</th><th>Justificatif</th><th>Contenu</th></tr></thead>
            <tbody>{r.allocations.map((a: any) => (
              <tr key={a.id}><td><Link className="mono" href={`/dotations/dotation/${a.id}`}>{a.reference}</Link></td><td className="petit">{fmtDate(a.issued_at)}</td>
                <td className="petit">{a.recipient_name}<div className="muted">par {a.issued_by}</div></td><td className="mono">{a.proof_reference}</td>
                <td className="petit">{a.lines.map((l: any) => <div key={l.id}>{l.asset ? <Link href={`/equipements/${l.asset.id}`}>{l.asset.serial_number}</Link> : `${fmtQty(l.quantity)} × ${l.item_code} ${l.variant_label ?? ""}`}</div>)}</td></tr>))}
              {r.allocations.length === 0 && <tr><td colSpan={5} className="vide">Aucune remise.</td></tr>}</tbody></table>
        </Card>
        <MovementsPanel sourceId={r.id} title="Réservations et libérations" />
      </div>
    </PageTitle>
  );
}
