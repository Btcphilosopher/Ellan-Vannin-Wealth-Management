"use client";
import Link from "next/link";
import { use, useState } from "react";
import DocumentsPanel from "@/components/DocumentsPanel";
import MovementsPanel from "@/components/MovementsPanel";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Loading, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { fmtDate, fmtQty } from "@/lib/labels";

export default function AllocationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { can } = useSession();
  const { data: a, error, loading, setData, reload } = useApi(`/v1/allocations/${id}`);
  const act = useAction();
  const [ret, setRet] = useState<any>(null);
  const [ext, setExt] = useState<any>(null);
  if (loading && !a) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  const doReturn = () => act.run(async () => {
    await apiPost("/v1/returns", { allocation_line_id: ret.line.id, asset_id: ret.line.asset?.id ?? null, quantity: Number(ret.quantity), condition: ret.condition,
      observed_condition: ret.observed, returned_by_name: ret.by, report_defect: ret.report, defect_description: ret.report ? ret.observed : null });
    setRet(null);
    await reload();
  }, "Retour enregistré : le matériel est bloqué jusqu'au contrôle (quarantaine s'il est endommagé).");
  const doExtend = () => act.run(async () => {
    setData(await apiPost(`/v1/allocation-lines/${ext.line.id}/extension`, { version: ext.line.version, new_due_date: ext.date, reason: ext.reason }));
    setExt(null);
  }, "Prolongation enregistrée.");
  return (
    <PageTitle over={`Dotation · demande ${a.request_reference}`} title={a.reference}>
      <div className="grille g2">
        <Card title="Remise">
          <dl className="def">
            <dt>Bénéficiaire</dt><dd>{a.beneficiary.name}</dd><dt>Remis à</dt><dd>{a.recipient_name}</dd>
            <dt>Responsable</dt><dd>{a.responsible_name}</dd><dt>Destination administrative</dt><dd>{a.administrative_destination}</dd>
            <dt>Justificatif de remise</dt><dd className="mono">{a.proof_reference}</dd><dt>Remis par</dt><dd>{a.issued_by} — {fmtDate(a.issued_at)}</dd>
            <dt>Demande</dt><dd><Link className="mono" href={`/dotations/${a.request_id}`}>{a.request_reference}</Link></dd>
          </dl>
        </Card>
        <Card title="Retours et prêts">
          {act.feedback}
          {ret && (<>
            <h3 style={{ margin: "0 0 8px", fontSize: 15 }}>Retour — {ret.line.asset?.serial_number ?? ret.line.item_code}</h3>
            <div className="grille g2">
              {!ret.line.asset && <Field label={`Quantité (≤ ${ret.line.outstanding_qty})`}><input type="number" value={ret.quantity} onChange={(e) => setRet({ ...ret, quantity: e.target.value })} /></Field>}
              <Field label="État constaté"><select value={ret.condition} onChange={(e) => setRet({ ...ret, condition: e.target.value })}>
                <option value="GOOD">Bon état (contrôle de retour requis)</option><option value="DAMAGED">Endommagé (quarantaine)</option><option value="INCOMPLETE">Incomplet (quarantaine)</option></select></Field>
              <Field label="Rendu par"><input value={ret.by} onChange={(e) => setRet({ ...ret, by: e.target.value })} /></Field>
              <Field label="Constat"><input value={ret.observed} onChange={(e) => setRet({ ...ret, observed: e.target.value })} /></Field>
            </div>
            {ret.line.asset && <label className="petit"><input type="checkbox" checked={ret.report} onChange={(e) => setRet({ ...ret, report: e.target.checked })} /> Signaler un défaut (ouvre un ordre de maintenance)</label>}
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}><button className="btn" onClick={doReturn} disabled={act.busy}>Enregistrer le retour</button><button className="btn sec" onClick={() => setRet(null)}>Annuler</button></div>
          </>)}
          {ext && (<>
            <h3 style={{ margin: "0 0 8px", fontSize: 15 }}>Prolongation — échéance actuelle {fmtDate(ext.line.due_date, false)}</h3>
            <div className="grille g2">
              <Field label="Nouvelle échéance"><input type="date" value={ext.date} onChange={(e) => setExt({ ...ext, date: e.target.value })} /></Field>
              <Field label="Motif"><input value={ext.reason} onChange={(e) => setExt({ ...ext, reason: e.target.value })} /></Field>
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}><button className="btn" onClick={doExtend} disabled={act.busy}>Prolonger</button><button className="btn sec" onClick={() => setExt(null)}>Annuler</button></div>
          </>)}
          {!ret && !ext && <p className="petit muted">Choisir une ligne ci-dessous pour enregistrer un retour ou une prolongation autorisée.</p>}
        </Card>
      </div>
      <div style={{ marginTop: 16 }}>
        <Card title="Lignes remises" flush>
          <table className="tableau">
            <thead><tr><th>Article / exemplaire</th><th>Nature</th><th className="n">Remis</th><th className="n">Retourné</th><th className="n">Consommé</th><th className="n">Détenu</th><th>Échéance</th><th /></tr></thead>
            <tbody>{a.lines.map((l: any) => (
              <tr key={l.id}>
                <td>{l.asset ? <Link href={`/equipements/${l.asset.id}`}>{l.asset.serial_number}</Link> : <span className="mono">{l.item_code}</span>}
                  <div className="petit">{l.designation} {l.variant_label ?? ""} {l.lot_number ? `· lot ${l.lot_number}` : ""}</div></td>
                <td><Badge code={l.kind} /></td><td className="n">{fmtQty(l.quantity)}</td><td className="n">{fmtQty(l.returned_qty)}</td><td className="n">{fmtQty(l.consumed_qty)}</td>
                <td className="n">{fmtQty(l.outstanding_qty)}</td>
                <td>{l.due_date ? fmtDate(l.due_date, false) : "—"} {l.overdue && <Badge tone="danger" label="Échéance dépassée" />}
                  {l.extensions_count > 0 && <div className="petit muted">{l.extensions_count} prolongation(s)</div>}</td>
                <td style={{ whiteSpace: "nowrap" }}>
                  {l.outstanding_qty > 0 && can("return.create") && <button className="btn sec petit" onClick={() => { setExt(null); setRet({ line: l, quantity: l.outstanding_qty, condition: "GOOD", by: "", observed: "", report: false }); }}>Retour</button>}{" "}
                  {l.kind === "LOAN" && l.outstanding_qty > 0 && can("loan.extend") && <button className="btn sec petit" onClick={() => { setRet(null); setExt({ line: l, date: "", reason: "" }); }}>Prolonger</button>}
                </td>
              </tr>))}</tbody>
          </table>
        </Card>
      </div>
      <Alert tone="info" title="Remise ≠ consommation">Les quantités remises restent détenues par le bénéficiaire jusqu'à leur retour ou leur déclaration de consommation (consommables uniquement).</Alert>
      <div className="grille g2" style={{ marginTop: 16 }}>
        <MovementsPanel sourceId={a.id} title="Mouvements de remise" />
        <DocumentsPanel ownerType="ALLOCATION" ownerId={a.id} defaultKind="HANDOVER_PROOF" />
      </div>
    </PageTitle>
  );
}
