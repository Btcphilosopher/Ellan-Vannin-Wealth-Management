"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Flow, Loading, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { MAINTENANCE_FLOW } from "@/lib/flows";
import { fmtDate, fmtMoney } from "@/lib/labels";

function Maintenance() {
  const sp = useSearchParams();
  const { depotId, can, me } = useSession();
  const today = me.clock.now.slice(0, 10);
  const [tab, setTab] = useState(sp.get("vue") ?? "ordres");
  const [status, setStatus] = useState("");
  const orders = useApi(tab === "ordres" ? "/v1/maintenance-orders" : null, { depot_id: depotId || undefined, status, page_size: 50 });
  const assets = useApi(tab === "a-controler" ? "/v1/assets" : null, { depot_id: depotId || undefined, page_size: 200 });
  const [signal, setSignal] = useState<any>(null);
  const act = useAction();
  const create = () => act.run(async () => {
    await apiPost("/v1/maintenance-orders", { asset_id: signal.asset_id, defect_description: signal.defect, priority: signal.priority, origin: "USER_REPORT" });
    setSignal(null);
    orders.reload();
  }, "Défaut signalé ; l'équipement est bloqué en quarantaine.");
  const toInspect = (assets.data?.items ?? []).filter((a: any) =>
    ["AWAITING_INSPECTION", "UNSERVICEABLE", "IN_MAINTENANCE"].includes(a.technical_state) || (a.next_inspection_due && a.next_inspection_due <= today));
  return (
    <PageTitle over="Maintien en condition" title="Maintenance"
               actions={can("maintenance.signal") && <button className="btn" onClick={() => setSignal(signal ? null : { asset_id: "", defect: "", priority: "NORMAL" })}>Signaler un défaut</button>}>
      <Flow steps={MAINTENANCE_FLOW} />
      <Alert tone="warn" title="Remise à disposition">Un ordre clôturé ne rend pas l'équipement apte : la remise à disposition est une décision explicite et attribuée, fondée sur un contrôle conforme.</Alert>
      {act.feedback}
      {signal && <SignalForm signal={signal} setSignal={setSignal} onSubmit={create} busy={act.busy} />}
      <div className="onglets">
        {[["ordres", "Ordres de travail"], ["a-controler", "Équipements à contrôler"]].map(([k, l]) => <button key={k} className={tab === k ? "actif" : ""} onClick={() => setTab(k)}>{l}</button>)}
      </div>
      {tab === "ordres" ? (
        <>
          <div className="barre-outils"><Field label="Statut"><select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">Tous</option>
            {MAINTENANCE_FLOW.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></Field></div>
          <ErrorBox error={orders.error} />
          <Card flush>
            {orders.loading && !orders.data ? <Loading /> : (
              <div className="tableau-wrap"><table className="tableau">
                <thead><tr><th>Ordre</th><th>Équipement</th><th>Défaut</th><th>Priorité</th><th>Statut</th><th>Échéance</th><th>Prestataire</th><th className="n">Coût</th><th>Décision</th></tr></thead>
                <tbody>{orders.data?.items.map((o: any) => (
                  <tr key={o.id}><td><Link className="mono" href={`/maintenance/${o.id}`}>{o.reference}</Link></td>
                    <td><Link href={`/equipements/${o.asset.id}`}>{o.asset.serial_number}</Link><div className="petit muted">{o.asset.designation}</div></td>
                    <td className="petit">{o.defect_description}</td><td><Badge tone={o.priority === "HIGH" || o.priority === "CRITICAL" ? "danger" : "neutre"} label={o.priority} /></td>
                    <td><Badge code={o.status} /></td><td className="petit">{fmtDate(o.due_date, false)} {o.overdue && <Badge tone="danger" label="Échue" />}</td>
                    <td className="petit">{o.provider?.name ?? "—"}</td><td className="n">{fmtMoney(o.costs.total)}</td>
                    <td>{o.release_decision ? <Badge code={o.release_decision.decision} /> : o.status === "CLOSED" ? <Badge tone="warn" label="Décision attendue" /> : "—"}</td></tr>))}
                  {orders.data?.items.length === 0 && <tr><td colSpan={9} className="vide">Aucun ordre.</td></tr>}
                </tbody></table></div>)}
          </Card>
        </>
      ) : (
        <Card flush>
          {assets.loading && !assets.data ? <Loading /> : (
            <table className="tableau"><thead><tr><th>Équipement</th><th>Position</th><th>État technique</th><th>Prochain contrôle</th></tr></thead>
              <tbody>{toInspect.map((a: any) => (
                <tr key={a.id}><td><Link href={`/equipements/${a.id}`}>{a.serial_number}</Link><div className="petit muted">{a.item.designation}</div></td>
                  <td>{a.location ? `${a.depot.code} · ${a.location.code}` : a.custody.organization?.name ?? "—"}</td><td><Badge code={a.technical_state} /></td>
                  <td>{fmtDate(a.next_inspection_due, false)}</td></tr>))}
                {toInspect.length === 0 && <tr><td colSpan={4} className="vide">Aucun équipement à contrôler.</td></tr>}</tbody></table>)}
        </Card>
      )}
    </PageTitle>
  );
}

function SignalForm({ signal, setSignal, onSubmit, busy }: any) {
  const { depotId } = useSession();
  const assets = useApi("/v1/assets", { depot_id: depotId || undefined, lifecycle: "IN_STOCK", page_size: 200 });
  return (
    <Card title="Signaler un défaut">
      <div className="grille g3">
        <Field label="Équipement (en stock)"><select value={signal.asset_id} onChange={(e) => setSignal({ ...signal, asset_id: e.target.value })}><option value="">—</option>
          {(assets.data?.items ?? []).map((a: any) => <option key={a.id} value={a.id}>{a.serial_number} — {a.item.designation}</option>)}</select></Field>
        <Field label="Priorité"><select value={signal.priority} onChange={(e) => setSignal({ ...signal, priority: e.target.value })}>
          <option value="LOW">Basse</option><option value="NORMAL">Normale</option><option value="HIGH">Haute</option><option value="CRITICAL">Critique</option></select></Field>
        <Field label="Défaut constaté"><input value={signal.defect} onChange={(e) => setSignal({ ...signal, defect: e.target.value })} /></Field>
      </div>
      <button className="btn" onClick={onSubmit} disabled={busy}>Signaler</button>
    </Card>
  );
}

export default function Page() {
  return <Suspense><Maintenance /></Suspense>;
}
