"use client";
import Link from "next/link";
import { use, useState } from "react";
import DocumentsPanel from "@/components/DocumentsPanel";
import MovementsPanel from "@/components/MovementsPanel";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Flow, Loading, PageTitle, useAction, useApi } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api";
import { flowStep, MAINTENANCE_FLOW } from "@/lib/flows";
import { fmtDate, fmtMoney, fmtQty } from "@/lib/labels";

export default function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { can, depots } = useSession();
  const { data: o, error, loading, setData } = useApi(`/v1/maintenance-orders/${id}`);
  const providers = useApi("/v1/providers");
  const items = useApi("/v1/items", { family: "PDR", page_size: 100 });
  const oils = useApi("/v1/items", { family: "FOU", page_size: 100 });
  const act = useAction();
  const [f, setF] = useState<any>({ diagnosis: "", estimated_cost: "", planned_start: "", provider_id: "", technician_name: "", hours: "", cost: "", labour_desc: "",
    part_item: "", part_qty: "", part_loc: "", work_result: "", insp_result: "PASS", findings: "", decision: "RETURN_TO_SERVICE", reason: "", to_loc: "" });
  if (loading && !o) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  const post = (path: string, body: any, msg: string, versioned = true) =>
    act.run(async () => setData(await apiPost(`/v1/maintenance-orders/${id}/${path}`, versioned ? { version: o.version, ...body } : body)), msg);
  const locs = depots.find((d) => d.id === o.depot_id)?.locations ?? [];
  const refresh = async () => setData(await apiGet(`/v1/maintenance-orders/${id}`));
  const lastInspection = o.inspections[o.inspections.length - 1];
  return (
    <PageTitle over="Ordre de maintenance" title={`${o.reference} — ${o.asset.serial_number}`} actions={<Badge code={o.status} />}>
      <Flow steps={MAINTENANCE_FLOW} current={flowStep(o.status)} />
      <div className="grille g2" style={{ marginTop: 12 }}>
        <Card title="Ordre de travail">
          <dl className="def">
            <dt>Équipement</dt><dd><Link href={`/equipements/${o.asset.id}`}>{o.asset.designation} n° {o.asset.serial_number}</Link> <span className="mono muted">{o.asset.internal_tag}</span></dd>
            <dt>État technique actuel</dt><dd><Badge code={o.asset.technical_state} /></dd>
            <dt>Origine / priorité</dt><dd>{o.origin} · {o.priority}</dd>
            <dt>Défaut</dt><dd>{o.defect_description}</dd>
            <dt>Diagnostic</dt><dd>{o.diagnosis || "—"} {o.estimated_cost !== null && <span className="petit muted">(estimé {fmtMoney(o.estimated_cost)})</span>}</dd>
            <dt>Échéance</dt><dd>{fmtDate(o.due_date, false)} {o.overdue && <Badge tone="danger" label="Échue" />}</dd>
            <dt>Planification</dt><dd>{o.planned_start ? `${fmtDate(o.planned_start, false)} — ${o.technician_name}` : "—"} {o.provider && <div className="petit">{o.provider.name}</div>}</dd>
            <dt>Résultat des travaux</dt><dd>{o.work_result || "—"}</dd>
            <dt>Signalé</dt><dd>{o.signaled_by} — {fmtDate(o.signaled_at)}</dd>
            <dt>Clôture</dt><dd>{o.closed_at ? `${o.closed_by} — ${fmtDate(o.closed_at)}` : "—"}</dd>
          </dl>
        </Card>
        <Card title="Coûts et temps">
          <div className="grille g2" style={{ gap: 8 }}>
            {[["Heures", fmtQty(o.costs.hours)], ["Main-d'œuvre", fmtMoney(o.costs.labour)], ["Pièces", fmtMoney(o.costs.parts)], ["Total", fmtMoney(o.costs.total)]].map(([l, v]) => (
              <div key={l} className="carte" style={{ padding: "8px 10px" }}><div className="petit muted">{l}</div><div style={{ fontFamily: "var(--serif)", fontSize: 20 }}>{v}</div></div>))}
          </div>
          <table className="tableau" style={{ marginTop: 10 }}><thead><tr><th>Temps</th><th className="n">h</th><th className="n">Coût</th></tr></thead>
            <tbody>{o.labour.map((l: any, i: number) => <tr key={i}><td className="petit">{fmtDate(l.performed_on, false)} — {l.technician_name}<div className="muted">{l.description}</div></td>
              <td className="n">{fmtQty(l.hours)}</td><td className="n">{fmtMoney(l.cost)}</td></tr>)}</tbody></table>
          <table className="tableau"><thead><tr><th>Pièces consommées</th><th className="n">Qté</th></tr></thead>
            <tbody>{o.parts.map((p: any, i: number) => <tr key={i}><td className="petit">{p.item_code} — {p.designation} {p.lot_number && `(lot ${p.lot_number})`}</td><td className="n">{fmtQty(p.quantity)}</td></tr>)}</tbody></table>
        </Card>
      </div>

      <div style={{ marginTop: 16 }}>
        <Card title="Actions">
          {act.feedback}
          {o.status === "SIGNALED" && can("maintenance.manage", o.depot_id) && (<div className="grille g3">
            <Field label="Diagnostic"><input value={f.diagnosis} onChange={set("diagnosis")} /></Field>
            <Field label="Coût estimé (€)"><input type="number" value={f.estimated_cost} onChange={set("estimated_cost")} /></Field>
            <div><button className="btn" onClick={() => post("assessment", { diagnosis: f.diagnosis, estimated_cost: f.estimated_cost ? Number(f.estimated_cost) : null }, "Évaluation enregistrée.")}>Évaluer</button></div></div>)}
          {o.status === "ASSESSED" && can("maintenance.manage", o.depot_id) && (<div className="grille g3">
            <Field label="Début prévu"><input type="date" value={f.planned_start} onChange={set("planned_start")} /></Field>
            <Field label="Prestataire (fictif)"><select value={f.provider_id} onChange={set("provider_id")}><option value="">Interne</option>
              {(providers.data ?? []).map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
            <Field label="Technicien"><input value={f.technician_name} onChange={set("technician_name")} /></Field>
            <div><button className="btn" onClick={() => post("planning", { planned_start: f.planned_start, provider_id: f.provider_id || null, technician_name: f.technician_name }, "Intervention planifiée.")}>Planifier</button></div></div>)}
          {o.status === "PLANNED" && can("maintenance.manage", o.depot_id) && <button className="btn" onClick={() => post("start", {}, "Intervention démarrée : équipement en atelier.")}>Démarrer l'intervention</button>}
          {o.status === "IN_PROGRESS" && can("maintenance.manage", o.depot_id) && (<>
            <div className="grille g3">
              <Field label="Heures"><input type="number" step="0.25" value={f.hours} onChange={set("hours")} /></Field>
              <Field label="Coût (€)"><input type="number" value={f.cost} onChange={set("cost")} /></Field>
              <Field label="Description"><input value={f.labour_desc} onChange={set("labour_desc")} /></Field>
            </div>
            <button className="btn sec" onClick={() => post("labour", { technician_name: o.technician_name ?? "Technicien", hours: Number(f.hours), cost: Number(f.cost), description: f.labour_desc }, "Temps enregistré.", false)}>Ajouter le temps</button>
            <div className="grille g3" style={{ marginTop: 10 }}>
              <Field label="Pièce / fourniture"><select value={f.part_item} onChange={set("part_item")}><option value="">—</option>
                {[...(items.data?.items ?? []), ...(oils.data?.items ?? [])].map((i: any) => <option key={i.id} value={i.id}>{i.code} — {i.designation}</option>)}</select></Field>
              <Field label="Emplacement de prélèvement"><select value={f.part_loc} onChange={set("part_loc")}><option value="">—</option>
                {locs.filter((l: any) => l.kind === "STORAGE").map((l: any) => <option key={l.id} value={l.id}>{l.code}</option>)}</select></Field>
              <Field label="Quantité"><input type="number" step="any" value={f.part_qty} onChange={set("part_qty")} /></Field>
            </div>
            <p className="petit muted">Les articles suivis par lot exigent le lot (prélevé via l'API) ; les pièces simples sont prélevées sur le stock utilisable non réservé.</p>
            <button className="btn sec" onClick={() => post("parts", { item_id: f.part_item, location_id: f.part_loc, quantity: Number(f.part_qty) }, "Consommation enregistrée au journal.", false)}>Consommer la pièce</button>
            <div className="grille g2" style={{ marginTop: 10 }}>
              <Field label="Résultat des travaux"><input value={f.work_result} onChange={set("work_result")} /></Field>
              <div><button className="btn" onClick={() => post("completion", { work_result: f.work_result }, "Travaux terminés : contrôle requis.")}>Terminer l'intervention</button></div>
            </div></>)}
          {o.status === "TO_INSPECT" && (<>
            <Alert tone="warn" title="Contrôle avant remise à disposition">Le contrôle est enregistré par la maintenance ; la décision sera prise par un responsable distinct.</Alert>
            {can("maintenance.inspect", o.depot_id) && <div className="grille g3">
              <Field label="Résultat"><select value={f.insp_result} onChange={set("insp_result")}><option value="PASS">Conforme</option><option value="FAIL">Non conforme</option></select></Field>
              <Field label="Constat"><input value={f.findings} onChange={set("findings")} /></Field>
              <div><button className="btn" onClick={() => act.run(async () => {
                await apiPost("/v1/inspections/asset", { asset_id: o.asset.id, kind: "PRE_RELEASE", result: f.insp_result, maintenance_order_id: o.id, findings: f.findings,
                  checklist: [{ point: "Essai fonctionnel", ok: f.insp_result === "PASS" }] });
                await refresh();
              }, "Contrôle enregistré.")}>Enregistrer le contrôle</button></div></div>}
            {can("maintenance.manage", o.depot_id) && <button className="btn sec" style={{ marginTop: 8 }} onClick={() => post("closure", {}, "Ordre clôturé (l'équipement reste en attente de décision).")}>Clôturer l'ordre</button>}
          </>)}
          {o.status === "CLOSED" && !o.release_decision && (<>
            <Alert tone="warn" title="Décision attendue">Ordre clôturé : l'équipement n'est pas apte tant qu'aucune décision explicite n'est prise.</Alert>
            {can("asset.release_decision", o.depot_id) ? <div className="grille g3">
              <Field label="Décision"><select value={f.decision} onChange={set("decision")}><option value="RETURN_TO_SERVICE">Remise à disposition</option>
                <option value="KEEP_UNSERVICEABLE">Maintien inapte</option><option value="CONDEMN">Réforme</option></select></Field>
              <Field label="Emplacement de remise en stock"><select value={f.to_loc} onChange={set("to_loc")}><option value="">—</option>
                {locs.filter((l: any) => l.kind === "STORAGE").map((l: any) => <option key={l.id} value={l.id}>{l.code}</option>)}</select></Field>
              <Field label="Motif"><input value={f.reason} onChange={set("reason")} /></Field>
              <div><button className="btn laiton" onClick={() => act.run(async () => {
                await apiPost(`/v1/assets/${o.asset.id}/release-decision`, { version: o.asset.version, decision: f.decision, inspection_id: lastInspection?.id ?? null,
                  reason: f.reason, to_location_id: f.to_loc || null });
                await refresh();
              }, "Décision enregistrée et attribuée.")}>Décider</button></div>
            </div> : <p className="petit muted">Décision réservée au responsable de dépôt.</p>}
          </>)}
          {o.release_decision && <Alert tone="ok" title={`Décision ${o.release_decision.reference}`}>
            <Badge code={o.release_decision.decision} /> — {o.release_decision.decided_by}, {fmtDate(o.release_decision.decided_at)} : {o.release_decision.reason}</Alert>}
        </Card>
      </div>

      <div style={{ marginTop: 16 }}>
        <Card title="Contrôles" flush>
          <table className="tableau"><thead><tr><th>Référence</th><th>Date</th><th>Contrôleur</th><th>Résultat</th><th>Constat</th></tr></thead>
            <tbody>{o.inspections.map((i: any) => <tr key={i.id}><td className="mono">{i.reference}</td><td className="petit">{fmtDate(i.performed_at)}</td><td>{i.inspector}</td>
              <td><Badge code={i.result} /></td><td className="petit">{i.findings}</td></tr>)}
              {o.inspections.length === 0 && <tr><td colSpan={5} className="vide">Aucun contrôle enregistré.</td></tr>}</tbody></table>
        </Card>
      </div>
      <div className="grille g2" style={{ marginTop: 16 }}>
        <MovementsPanel sourceId={o.id} />
        <DocumentsPanel ownerType="MAINTENANCE_ORDER" ownerId={o.id} defaultKind="MAINTENANCE_REPORT" />
      </div>
    </PageTitle>
  );
}
