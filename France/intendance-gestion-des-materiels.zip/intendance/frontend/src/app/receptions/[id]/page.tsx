"use client";
import { use, useState } from "react";
import DocumentsPanel from "@/components/DocumentsPanel";
import MovementsPanel from "@/components/MovementsPanel";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Flow, Loading, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { flowStep, RECEIPT_FLOW } from "@/lib/flows";
import { fmtDate, fmtQty, INSPECTION_LABELS } from "@/lib/labels";

export default function ReceiptPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { can, depots } = useSession();
  const { data: r, error, loading, setData } = useApi(`/v1/receipts/${id}`);
  const act = useAction();
  const [phys, setPhys] = useState<Record<string, any>>({});
  const [insp, setInsp] = useState<Record<string, any>>({});
  const [checks, setChecks] = useState<Record<string, boolean>>({});
  const [findings, setFindings] = useState("");
  const [put, setPut] = useState<Record<string, any>>({});
  if (loading && !r) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  const storage = depots.find((d) => d.id === r.depot.id)?.locations.filter((l) => l.kind === "STORAGE") ?? [];
  const post = (path: string, body: any, msg: string) => act.run(async () => setData(await apiPost(`/v1/receipts/${id}/${path}`, { version: r.version, ...body })), msg);
  const requirements: string[] = Array.from(new Set(r.lines.flatMap((l: any) => l.inspection_requirements)));

  return (
    <PageTitle over={`Réception · ${r.depot.name}`} title={r.reference} actions={<Badge code={r.status} />}>
      <Flow steps={RECEIPT_FLOW} current={flowStep(r.status)} />
      <div className="grille g2" style={{ marginTop: 12 }}>
        <Card title="En-tête">
          <dl className="def">
            <dt>Fournisseur (fictif)</dt><dd>{r.supplier.name}</dd>
            <dt>Référence documentaire</dt><dd className="mono">{r.supplier_document_ref}</dd>
            <dt>Créée par</dt><dd>{r.created_by}</dd>
            <dt>Reçue physiquement</dt><dd>{fmtDate(r.received_at)} {r.received_by && `— ${r.received_by}`}</dd>
            <dt>Dernier contrôle</dt><dd>{fmtDate(r.inspected_at)}</dd>
            <dt>Clôture</dt><dd>{fmtDate(r.closed_at)}</dd>
          </dl>
        </Card>
        <Card title="Quantités (unités de base)">
          <div className="grille g3" style={{ gap: 8 }}>
            {[["Attendue", r.totals.expected_qty], ["Reçue", r.totals.received_qty], ["Acceptée", r.totals.accepted_qty], ["Rejetée", r.totals.rejected_qty],
              ["En attente de contrôle", r.totals.pending_qty], ["Mise en stock", r.totals.put_away_qty]].map(([l, v]) => (
              <div key={l as string} className="carte" style={{ padding: "8px 10px" }}><div className="petit muted">{l}</div>
                <div style={{ fontFamily: "var(--serif)", fontSize: 22 }}>{fmtQty(v as number)}</div></div>))}
          </div>
          {r.totals.pending_qty > 0 && <Alert tone="warn" title="Matériel non contrôlé">Les quantités en attente de contrôle sont bloquées : elles ne peuvent être ni réservées ni remises.</Alert>}
          {r.totals.rejected_qty > 0 && <Alert tone="danger" title="Quarantaine">{fmtQty(r.totals.rejected_qty)} unité(s) rejetée(s) placée(s) en quarantaine.</Alert>}
        </Card>
      </div>

      {act.feedback}

      <div style={{ marginTop: 16 }}>
        <Card title="Lignes" flush>
          <div className="tableau-wrap">
            <table className="tableau">
              <thead><tr><th>#</th><th>Article</th><th>Saisie</th><th className="n">Attendu</th><th className="n">Reçu</th><th className="n">Accepté</th><th className="n">Rejeté</th>
                <th className="n">En attente</th><th className="n">En stock</th><th>Lot / séries</th><th>Constat / écart</th></tr></thead>
              <tbody>{r.lines.map((l: any) => (
                <tr key={l.id}>
                  <td>{l.line_no}</td><td><span className="mono">{l.item_code}</span><div className="petit">{l.designation}{l.variant_label && ` — ${l.variant_label}`}</div>
                    <div className="petit muted">Contrôle : {INSPECTION_LABELS[l.inspection_level]}</div></td>
                  <td className="petit">{fmtQty(l.expected_entered_qty)} {l.entered_unit}</td>
                  <td className="n">{fmtQty(l.expected_qty, l.base_unit)}</td><td className="n">{fmtQty(l.received_qty)}</td><td className="n">{fmtQty(l.accepted_qty)}</td>
                  <td className="n">{fmtQty(l.rejected_qty)}</td><td className="n">{l.pending_qty > 0 ? <Badge tone="warn" label={fmtQty(l.pending_qty)} /> : "0"}</td>
                  <td className="n">{fmtQty(l.put_away_qty)}</td>
                  <td className="petit">{l.lot_number && <div>Lot {l.lot_number}</div>}{l.serial_numbers.length > 0 && <div className="mono">{l.serial_numbers.join(", ")}</div>}</td>
                  <td className="petit">{l.observed_condition}{l.discrepancy_note && <div><Badge tone="warn" label={`Écart ${l.discrepancy_qty > 0 ? "+" : ""}${fmtQty(l.discrepancy_qty)}`} /> {l.discrepancy_note}</div>}</td>
                </tr>))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      {r.status === "SUBMITTED" && can("receipt.receive", r.depot.id) && (
        <div style={{ marginTop: 16 }}>
          <Card title="Réception physique" num="1">
            <p className="petit muted">Quantités saisies dans l'unité de la ligne ; tout entre au quai en statut « non contrôlé ». Un écart exige un motif.</p>
            <table className="tableau lignes-saisie">
              <thead><tr><th>Ligne</th><th>Reçu</th><th>Lot</th><th>Numéros de série (un par ligne)</th><th>État constaté</th><th>Motif d'écart</th></tr></thead>
              <tbody>{r.lines.map((l: any) => {
                const v = phys[l.id] ?? { received_quantity: l.expected_entered_qty, lot_number: l.lot_number ?? "", serials: "", observed_condition: "", discrepancy_note: "" };
                const set = (k: string, val: any) => setPhys({ ...phys, [l.id]: { ...v, [k]: val } });
                return (
                  <tr key={l.id}>
                    <td className="mono">{l.item_code} {l.variant_label ?? ""}</td>
                    <td><input className="mini" type="number" min={0} value={v.received_quantity} onChange={(e) => set("received_quantity", e.target.value)} /> {l.entered_unit}</td>
                    <td>{l.tracking === "LOT" ? <input className="mini" value={v.lot_number} onChange={(e) => set("lot_number", e.target.value)} /> : "—"}</td>
                    <td>{l.tracking === "SERIAL" ? <textarea value={v.serials} onChange={(e) => set("serials", e.target.value)} rows={3} /> : "—"}</td>
                    <td><input className="mini" value={v.observed_condition} onChange={(e) => set("observed_condition", e.target.value)} /></td>
                    <td><input className="mini" value={v.discrepancy_note} onChange={(e) => set("discrepancy_note", e.target.value)} /></td>
                  </tr>);
              })}</tbody>
            </table>
            <button className="btn" style={{ marginTop: 8 }} disabled={act.busy} onClick={() => post("physical-receipt", {
              lines: r.lines.map((l: any) => {
                const v = phys[l.id] ?? { received_quantity: l.expected_entered_qty, lot_number: l.lot_number ?? "", serials: "", observed_condition: "", discrepancy_note: "" };
                return { line_id: l.id, received_quantity: Number(v.received_quantity), lot_number: v.lot_number || null,
                  serial_numbers: String(v.serials || "").split(/\n|,/).map((s) => s.trim()).filter(Boolean), observed_condition: v.observed_condition, discrepancy_note: v.discrepancy_note };
              }),
            }, "Réception physique enregistrée.")}>Enregistrer la réception physique</button>
          </Card>
        </div>
      )}

      {["RECEIVED", "IN_INSPECTION"].includes(r.status) && can("receipt.inspect", r.depot.id) && (
        <div style={{ marginTop: 16 }}>
          <Card title="Contrôle de réception" num="2">
            <Alert tone="info" title="Séparation des tâches">Le contrôle est réalisé par une autre personne que l'agent ayant reçu la livraison (règle configurable).</Alert>
            <div className="grille g2">
              <div>
                <strong className="petit">Points de contrôle</strong>
                {requirements.map((q) => <div key={q}><label className="petit"><input type="checkbox" checked={!!checks[q]} onChange={(e) => setChecks({ ...checks, [q]: e.target.checked })} /> {q}</label></div>)}
              </div>
              <Field label="Constat général"><textarea value={findings} onChange={(e) => setFindings(e.target.value)} /></Field>
            </div>
            <table className="tableau lignes-saisie">
              <thead><tr><th>Ligne</th><th className="n">En attente</th><th>Accepté</th><th>Rejeté</th><th>N° de série rejetés</th><th>Constat</th></tr></thead>
              <tbody>{r.lines.filter((l: any) => l.pending_qty > 0).map((l: any) => {
                const v = insp[l.id] ?? { accepted_qty: l.pending_qty, rejected_qty: 0, rejected_serials: "", findings: "" };
                const set = (k: string, val: any) => setInsp({ ...insp, [l.id]: { ...v, [k]: val } });
                return (
                  <tr key={l.id}>
                    <td className="mono">{l.item_code} {l.variant_label ?? ""}</td><td className="n">{fmtQty(l.pending_qty)}</td>
                    <td><input className="mini" type="number" min={0} value={v.accepted_qty} onChange={(e) => set("accepted_qty", e.target.value)} /></td>
                    <td><input className="mini" type="number" min={0} value={v.rejected_qty} onChange={(e) => set("rejected_qty", e.target.value)} /></td>
                    <td>{l.tracking === "SERIAL" ? <input className="mini" value={v.rejected_serials} onChange={(e) => set("rejected_serials", e.target.value)} placeholder="séparés par des virgules" /> : "—"}</td>
                    <td><input className="mini" value={v.findings} onChange={(e) => set("findings", e.target.value)} /></td>
                  </tr>);
              })}</tbody>
            </table>
            <button className="btn" style={{ marginTop: 8 }} disabled={act.busy} onClick={() => post("inspection", {
              findings, checklist: requirements.map((q) => ({ point: q, ok: !!checks[q] })),
              lines: r.lines.filter((l: any) => l.pending_qty > 0).map((l: any) => {
                const v = insp[l.id] ?? { accepted_qty: l.pending_qty, rejected_qty: 0, rejected_serials: "", findings: "" };
                return { line_id: l.id, accepted_qty: Number(v.accepted_qty), rejected_qty: Number(v.rejected_qty), findings: v.findings,
                  rejected_serials: String(v.rejected_serials || "").split(",").map((s) => s.trim()).filter(Boolean) };
              }),
            }, "Contrôle enregistré : seules les quantités acceptées deviennent disponibles.")}>Enregistrer le contrôle</button>
          </Card>
        </div>
      )}

      {["IN_INSPECTION", "ACCEPTED", "PARTIALLY_ACCEPTED"].includes(r.status) && can("receipt.putaway", r.depot.id) && r.lines.some((l: any) => l.accepted_qty > l.put_away_qty) && (
        <div style={{ marginTop: 16 }}>
          <Card title="Mise en stock" num="3">
            <table className="tableau lignes-saisie">
              <thead><tr><th>Ligne</th><th className="n">À ranger</th><th>Emplacement</th><th>Quantité</th></tr></thead>
              <tbody>{r.lines.filter((l: any) => l.accepted_qty > l.put_away_qty).map((l: any) => {
                const v = put[l.id] ?? { location_id: storage[0]?.id ?? "", quantity: l.accepted_qty - l.put_away_qty };
                return (
                  <tr key={l.id}><td className="mono">{l.item_code} {l.variant_label ?? ""}</td><td className="n">{fmtQty(l.accepted_qty - l.put_away_qty)}</td>
                    <td><select className="mini" value={v.location_id} onChange={(e) => setPut({ ...put, [l.id]: { ...v, location_id: e.target.value } })}>
                      {storage.map((s) => <option key={s.id} value={s.id}>{s.code} — {s.label}</option>)}</select></td>
                    <td><input className="mini" type="number" min={0} value={v.quantity} onChange={(e) => setPut({ ...put, [l.id]: { ...v, quantity: e.target.value } })} /></td></tr>);
              })}</tbody>
            </table>
            <button className="btn" style={{ marginTop: 8 }} disabled={act.busy} onClick={() => post("putaway", {
              lines: r.lines.filter((l: any) => l.accepted_qty > l.put_away_qty).map((l: any) => {
                const v = put[l.id] ?? { location_id: storage[0]?.id ?? "", quantity: l.accepted_qty - l.put_away_qty };
                return { line_id: l.id, location_id: v.location_id, quantity: Number(v.quantity) };
              }).filter((x: any) => x.quantity > 0),
            }, "Mise en stock enregistrée.")}>Ranger</button>
          </Card>
        </div>
      )}

      <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
        {r.status === "DRAFT" && can("receipt.create", r.depot.id) && <button className="btn" onClick={() => post("submit", {}, "Réception soumise.")}>Soumettre</button>}
        {["ACCEPTED", "PARTIALLY_ACCEPTED", "REJECTED"].includes(r.status) && can("receipt.close", r.depot.id) &&
          <button className="btn laiton" onClick={() => post("close", {}, "Réception clôturée.")}>Clôturer la réception</button>}
      </div>

      {r.inspections.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <Card title="Procès-verbaux de contrôle" flush>
            <table className="tableau"><thead><tr><th>Référence</th><th>Date</th><th>Contrôleur</th><th>Résultat</th><th className="n">Accepté</th><th className="n">Rejeté</th><th>Constat</th></tr></thead>
              <tbody>{r.inspections.map((i: any) => <tr key={i.id}><td className="mono">{i.reference}</td><td className="petit">{fmtDate(i.performed_at)}</td><td>{i.inspector}</td>
                <td><Badge code={i.result} /></td><td className="n">{fmtQty(i.accepted_qty)}</td><td className="n">{fmtQty(i.rejected_qty)}</td><td className="petit">{i.findings}</td></tr>)}</tbody></table>
          </Card>
        </div>
      )}
      <div className="grille g2" style={{ marginTop: 16 }}>
        <MovementsPanel sourceId={r.id} />
        <DocumentsPanel ownerType="RECEIPT" ownerId={r.id} defaultKind="RECEIPT_NOTE" />
      </div>
    </PageTitle>
  );
}
