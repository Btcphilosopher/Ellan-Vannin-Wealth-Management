"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import LinesEditor, { LineDraft } from "@/components/ItemPicker";
import { useSession } from "@/components/Shell";
import { Badge, Card, ErrorBox, Field, Flow, Loading, Pager, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { RECEIPT_FLOW } from "@/lib/flows";
import { fmtDate, fmtQty } from "@/lib/labels";

function Receptions() {
  const sp = useSearchParams();
  const { depotId, can } = useSession();
  const [status, setStatus] = useState(sp.get("status") ?? "");
  const [page, setPage] = useState(1);
  const [creating, setCreating] = useState(sp.get("nouvelle") === "1");
  const { data, error, loading } = useApi("/v1/receipts", { depot_id: depotId || undefined, status, page, page_size: 20 });
  return (
    <PageTitle over="Entrées en stock" title="Réceptions et contrôles"
               actions={can("receipt.create") && <button className="btn" onClick={() => setCreating(!creating)}>{creating ? "Fermer" : "Nouvelle réception"}</button>}>
      <Flow steps={RECEIPT_FLOW} />
      {creating && <NewReceipt />}
      <div className="barre-outils" style={{ marginTop: 12 }}>
        <Field label="Statut"><select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">Tous</option><option value="SUBMITTED">Soumises</option><option value="RECEIVED,IN_INSPECTION">À contrôler</option>
          <option value="ACCEPTED,PARTIALLY_ACCEPTED,REJECTED">À clôturer</option><option value="CLOSED">Clôturées</option></select></Field>
      </div>
      <ErrorBox error={error} />
      <Card flush>
        {loading && !data ? <Loading /> : (
          <div className="tableau-wrap">
            <table className="tableau">
              <thead><tr><th>Référence</th><th>Dépôt</th><th>Fournisseur / document</th><th>Statut</th><th className="n">Attendu</th><th className="n">Reçu</th>
                <th className="n">Accepté</th><th className="n">Rejeté</th><th className="n">En attente</th><th>Reçue le</th></tr></thead>
              <tbody>{data?.items.map((r: any) => (
                <tr key={r.id}>
                  <td><Link className="mono" href={`/receptions/${r.id}`}>{r.reference}</Link></td><td>{r.depot.code}</td>
                  <td>{r.supplier.name}<div className="mono muted">{r.supplier_document_ref}</div></td><td><Badge code={r.status} /></td>
                  <td className="n">{fmtQty(r.totals.expected_qty)}</td><td className="n">{fmtQty(r.totals.received_qty)}</td><td className="n">{fmtQty(r.totals.accepted_qty)}</td>
                  <td className="n">{fmtQty(r.totals.rejected_qty)}</td>
                  <td className="n">{r.totals.pending_qty > 0 ? <Badge tone="warn" label={fmtQty(r.totals.pending_qty)} /> : "0"}</td>
                  <td className="petit">{fmtDate(r.received_at)}</td>
                </tr>))}
                {data?.items.length === 0 && <tr><td colSpan={10} className="vide">Aucune réception.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
        {data && <Pager page={page} total={data.total} pageSize={20} onPage={setPage} />}
      </Card>
    </PageTitle>
  );
}

function NewReceipt() {
  const router = useRouter();
  const { depots, depotId } = useSession();
  const suppliers = useApi("/v1/organizations", { kind: "SUPPLIER" });
  const [depot, setDepot] = useState(depotId || depots[0]?.id || "");
  const [supplier, setSupplier] = useState("");
  const [docRef, setDocRef] = useState("");
  const [lines, setLines] = useState<LineDraft[]>([{ item_id: "", variant_id: "", unit: "", quantity: "" }]);
  const act = useAction();
  const submit = () => act.run(async () => {
    const r = await apiPost("/v1/receipts", {
      depot_id: depot, supplier_id: supplier, supplier_document_ref: docRef, submit: true,
      lines: lines.filter((l) => l.item_id).map((l) => ({ item_id: l.item_id, variant_id: l.variant_id || null, unit: l.unit || null, expected_quantity: Number(l.quantity) })),
    });
    router.push(`/receptions/${r.id}`);
  });
  return (
    <div style={{ margin: "12px 0" }}>
      <Card title="Nouvelle réception (fournisseur fictif)">
        <div className="grille g3">
          <Field label="Dépôt"><select value={depot} onChange={(e) => setDepot(e.target.value)}>{depots.map((d) => <option key={d.id} value={d.id}>{d.code} — {d.name}</option>)}</select></Field>
          <Field label="Fournisseur"><select value={supplier} onChange={(e) => setSupplier(e.target.value)}><option value="">—</option>
            {(suppliers.data ?? []).map((o: any) => <option key={o.id} value={o.id}>{o.name}</option>)}</select></Field>
          <Field label="Référence documentaire (bon de livraison)"><input value={docRef} onChange={(e) => setDocRef(e.target.value)} placeholder="BL-…" /></Field>
        </div>
        <LinesEditor lines={lines} setLines={setLines} />
        {act.feedback}
        <button className="btn" onClick={submit} disabled={act.busy}>Créer et soumettre</button>
      </Card>
    </div>
  );
}

export default function Page() {
  return <Suspense><Receptions /></Suspense>;
}
