"use client";
import { FormEvent, Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Emblem from "@/components/Emblem";
import { ErrorBox, Field } from "@/components/ui";
import { apiPost } from "@/lib/api";

function Login() {
  const router = useRouter();
  const params = useSearchParams();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [mfa, setMfa] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const target = params.get("retour") || "/";

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (!mfa) {
        const r = await apiPost<{ mfa_required: boolean }>("/v1/auth/login", { username, password });
        if (r.mfa_required) { setMfa(true); return; }
      } else {
        await apiPost("/v1/auth/mfa", { code });
      }
      window.location.href = target.startsWith("/") ? target : "/";
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="connexion">
      <section className="carte">
        <div className="tricolore" />
        <header className="carte-entete" style={{ gap: 14 }}>
          <Emblem size={56} />
          <div>
            <h2 style={{ letterSpacing: "0.14em" }}>INTENDANCE</h2>
            <div className="petit muted">Gestion des matériels — accès authentifié</div>
          </div>
        </header>
        <form className="carte-corps formulaire" onSubmit={submit}>
          {!mfa ? (
            <>
              <Field label="Identifiant"><input autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} required /></Field>
              <Field label="Mot de passe"><input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required /></Field>
            </>
          ) : (
            <Field label="Code de vérification (application d'authentification)" help="Second facteur exigé pour ce profil.">
              <input inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" value={code} onChange={(e) => setCode(e.target.value)} required autoFocus />
            </Field>
          )}
          <ErrorBox error={error} />
          <button className="btn" disabled={busy}>{mfa ? "Vérifier" : "Se connecter"}</button>
          <p className="petit muted" style={{ margin: 0 }}>
            Démonstration : comptes fictifs listés dans le README (ex. <span className="mono">r.garnier</span>). Concept indépendant, sans affiliation
            officielle ; non apte au traitement d'informations classifiées.
          </p>
        </form>
      </section>
    </div>
  );
}

export default function Page() {
  return <Suspense><Login /></Suspense>;
}
