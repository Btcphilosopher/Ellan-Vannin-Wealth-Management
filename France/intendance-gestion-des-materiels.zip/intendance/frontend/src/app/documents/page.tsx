"use client";
import { useState } from "react";
import { Badge, Card, ErrorBox, Field, Loading, Pager, PageTitle, useApi } from "@/components/ui";
import { fmtDate } from "@/lib/labels";

const OWNER_LABELS: Record<string, string> = {
  ITEM: "Article", RECEIPT: "Réception", REQUEST: "Demande", ALLOCATION: "Dotation", TRANSFER: "Transfert", MAINTENANCE_ORDER: "Ordre de maintenance",
  ASSET: "Équipement", STOCKTAKE: "Inventaire", INSPECTION: "Contrôle", REPORT: "Rapport",
};
const OWNER_LINKS: Record<string, string> = {
  ITEM: "/catalogue/", RECEIPT: "/receptions/", REQUEST: "/dotations/", ALLOCATION: "/dotations/dotation/", TRANSFER: "/transferts/",
  MAINTENANCE_ORDER: "/maintenance/", ASSET: "/equipements/", STOCKTAKE: "/stocks/inventaires/",
};

export default function Documents() {
  const [kind, setKind] = useState("");
  const [page, setPage] = useState(1);
  const kinds = useApi("/v1/documents/kinds");
  const { data, error, loading } = useApi("/v1/documents", { kind, page, page_size: 25 });
  return (
    <PageTitle over="Pièces justificatives" title="Documents">
      <p className="petit muted">Chaque document conserve ses versions (auteur, date, empreinte SHA-256) et ses droits d'accès. Les fichiers sont stockés hors de l'application et
        servis uniquement après vérification des permissions. Pour attacher un document, ouvrez l'enregistrement concerné.</p>
      <div className="barre-outils"><Field label="Nature"><select value={kind} onChange={(e) => { setKind(e.target.value); setPage(1); }}><option value="">Toutes</option>
        {(kinds.data ?? []).map((k: any) => <option key={k.code} value={k.code}>{k.label}</option>)}</select></Field></div>
      <ErrorBox error={error} />
      <Card flush>
        {loading && !data ? <Loading /> : (
          <div className="tableau-wrap"><table className="tableau">
            <thead><tr><th>Référence</th><th>Titre</th><th>Nature</th><th>Rattachement</th><th>Accès</th><th className="n">Version</th><th>Dernière version</th><th>Empreinte</th><th /></tr></thead>
            <tbody>{data?.items.map((d: any) => {
              const v = d.versions[d.versions.length - 1];
              return (
                <tr key={d.id}><td className="mono">{d.reference}</td><td>{d.title}</td><td>{d.kind_label}</td>
                  <td>{OWNER_LINKS[d.owner_type] ? <a href={`${OWNER_LINKS[d.owner_type]}${d.owner_id}`}>{OWNER_LABELS[d.owner_type]}</a> : OWNER_LABELS[d.owner_type]}</td>
                  <td>{d.access_level === "RESTRICTED" ? <Badge tone="warn" label="Restreint" /> : <Badge tone="neutre" label="Interne" />}</td>
                  <td className="n">v{d.current_version}</td><td className="petit">{v?.author}<div className="muted">{fmtDate(v?.created_at)} · {v?.filename}</div></td>
                  <td className="mono petit" title={v?.sha256}>{v?.sha256.slice(0, 12)}…</td>
                  <td><a className="btn sec petit" href={`/v1/documents/${d.id}/versions/${d.current_version}/content`}>Télécharger</a></td></tr>);
            })}
              {data?.items.length === 0 && <tr><td colSpan={9} className="vide">Aucun document.</td></tr>}</tbody></table></div>)}
        {data && <Pager page={page} total={data.total} pageSize={25} onPage={setPage} />}
      </Card>
    </PageTitle>
  );
}
