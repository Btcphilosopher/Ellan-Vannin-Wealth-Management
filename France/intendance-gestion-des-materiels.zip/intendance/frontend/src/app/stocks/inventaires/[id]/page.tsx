"use client";
import { use, useState } from "react";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Flow, Loading, PageTitle, useAction, useApi } from "@/components/ui";
import { apiGet, apiPost } from "@/lib/api";
import { fmtDate, fmtQty } from "@/lib/labels";

export default function StocktakePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { can } = useSession();
  const { data: st, error, loading, setData } = useApi(`/v1/stocktakes/${id}`);
  const act = useAction();
  const [counts, setCounts] = useState<Record<string, string>>({});
  const [decisions, setDecisions] = useState<Record<string, { approve: boolean; justification: string }>>({});
  if (loading && !st) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  const refresh = async () => setData(await apiGet(`/v1/stocktakes/${id}`));
  const transition = (path: string, label: string) => act.run(async () => { setData(await apiPost(`/v1/stocktakes/${id}/${path}`, { version: st.version })); }, label);
  const saveCounts = () => act.run(async () => {
    const lines = Object.entries(counts).filter(([, v]) => v !== "").map(([line_id, v]) => ({ line_id, counted_qty: Number(v) }));
    setData(await apiPost(`/v1/stocktakes/${id}/counts`, { lines }));
    setCounts({});
  }, "Comptages enregistrés. Aucun solde n'a été modifié.");
  const decide = () => act.run(async () => {
    const list = Object.entries(decisions).map(([line_id, d]) => ({ line_id, ...d }));
    setData(await apiPost(`/v1/stocktakes/${id}/adjustments`, { version: st.version, decisions: list }));
    setDecisions({});
  }, "Décisions enregistrées ; ajustements approuvés passés au journal.");
  const toCount = st.lines.filter((l: any) => ["TO_COUNT", "RECOUNT_REQUIRED"].includes(l.status));
  return (
    <PageTitle over={`Inventaire physique · ${st.depot.name}`} title={`${st.reference} — ${st.name}`}
               actions={<>
                 {st.status === "DRAFT" && can("stocktake.manage", st.depot.id) && <button className="btn" onClick={() => transition("start", "Comptage ouvert, instantané pris.")}>Ouvrir le comptage</button>}
                 {st.status === "COUNTING" && can("stocktake.manage", st.depot.id) && <button className="btn" onClick={() => transition("review", "Écarts soumis à décision.")}>Passer en revue des écarts</button>}
                 {st.status === "REVIEW" && can("stocktake.manage", st.depot.id) && <button className="btn" onClick={() => transition("close", "Inventaire clôturé.")}>Clôturer</button>}
                 <button className="btn sec" onClick={refresh}>Actualiser</button>
               </>}>
      <Flow steps={[["DRAFT", "Préparation"], ["COUNTING", "Comptage"], ["REVIEW", "Écarts et approbations"], ["CLOSED", "Clôturé"]]} current={st.status} />
      <Alert tone="info" title="Règle appliquée">{st.policy}</Alert>
      {!st.expected_visible && <Alert tone="warn" title="Comptage à l'aveugle">Les quantités théoriques sont masquées pour votre profil pendant le comptage.</Alert>}
      {act.feedback}
      <Card title="Lignes de comptage" right={<span className="petit muted">Instantané : {fmtDate(st.snapshot_at)} · séquence {st.snapshot_seq ?? "—"}</span>} flush>
        <div className="tableau-wrap">
          <table className="tableau">
            <thead><tr><th>#</th><th>Emplacement</th><th>Article</th><th>Variante / lot</th><th className="n">Instantané</th><th>Comptages</th>
              <th className="n">Théorique au comptage</th><th className="n">Écart</th><th>Statut</th><th>Saisie / décision</th></tr></thead>
            <tbody>
              {st.lines.map((l: any) => (
                <tr key={l.id}>
                  <td>{l.line_no}</td><td className="mono">{l.location_code}</td><td><span className="mono">{l.item_code}</span><div className="petit">{l.designation}</div></td>
                  <td>{l.variant_label ?? l.lot_number ?? "—"}</td>
                  <td className="n">{l.snapshot_qty === null ? "masqué" : fmtQty(l.snapshot_qty)}</td>
                  <td className="petit">{l.counts.map((c: any) => <div key={c.round}>#{c.round} : {fmtQty(c.counted_qty)} — {c.counter}</div>)}</td>
                  <td className="n">{l.final_system_qty === null ? "—" : fmtQty(l.final_system_qty)}</td>
                  <td className="n">{l.variance_qty === null || l.variance_qty === undefined ? "—" : <strong>{l.variance_qty > 0 ? "+" : ""}{fmtQty(l.variance_qty)}</strong>}
                    {l.requires_approver && <div><Badge tone="danger" label="Approbateur requis" /></div>}</td>
                  <td><Badge code={l.status} />{l.justification && <div className="petit muted">{l.justification}</div>}</td>
                  <td>
                    {st.status === "COUNTING" && ["TO_COUNT", "RECOUNT_REQUIRED"].includes(l.status) && can("stocktake.count", st.depot.id) &&
                      <input className="mini" type="number" min={0} aria-label={`Quantité comptée ligne ${l.line_no}`} value={counts[l.id] ?? ""}
                             onChange={(e) => setCounts({ ...counts, [l.id]: e.target.value })} />}
                    {st.status === "REVIEW" && l.status === "VARIANCE_CONFIRMED" && (can("stocktake.approve_small", st.depot.id) || can("stocktake.approve_large", st.depot.id)) && (
                      <div style={{ display: "grid", gap: 4 }}>
                        <select className="mini" value={decisions[l.id]?.approve === false ? "non" : decisions[l.id] ? "oui" : ""}
                                onChange={(e) => setDecisions({ ...decisions, [l.id]: { approve: e.target.value === "oui", justification: decisions[l.id]?.justification ?? "" } })}>
                          <option value="">— décision —</option><option value="oui">Approuver l'ajustement</option><option value="non">Refuser</option>
                        </select>
                        <input className="mini" placeholder="Justification (obligatoire)" value={decisions[l.id]?.justification ?? ""}
                               onChange={(e) => setDecisions({ ...decisions, [l.id]: { approve: decisions[l.id]?.approve ?? true, justification: e.target.value } })} />
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        {st.status === "COUNTING" && toCount.length > 0 && can("stocktake.count", st.depot.id) && <button className="btn" onClick={saveCounts} disabled={act.busy}>Enregistrer les comptages</button>}
        {st.status === "REVIEW" && Object.keys(decisions).length > 0 && <button className="btn laiton" onClick={decide} disabled={act.busy}>Enregistrer les décisions</button>}
      </div>
    </PageTitle>
  );
}
