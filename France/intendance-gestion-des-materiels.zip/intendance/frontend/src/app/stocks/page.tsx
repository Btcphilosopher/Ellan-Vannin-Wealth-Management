"use client";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Field, Loading, Pager, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { fmtDate, fmtQty, MOVEMENT_LABELS, statusLabel } from "@/lib/labels";

function Stocks() {
  const sp = useSearchParams();
  const [tab, setTab] = useState(sp.get("onglet") ?? (sp.get("location") ? "positions" : "synthese"));
  return (
    <PageTitle over="Inventaire" title="Stocks">
      <div className="onglets" role="tablist">
        {[["synthese", "Synthèse"], ["positions", "Positions de stock"], ["mouvements", "Journal des mouvements"], ["inventaires", "Inventaires physiques"]].map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? "actif" : ""} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>
      {tab === "synthese" && <Synthese family={sp.get("famille") ?? ""} />}
      {tab === "positions" && <Positions initialLocation={sp.get("location") ?? ""} initialDepot={sp.get("depot") ?? ""} />}
      {tab === "mouvements" && <Mouvements />}
      {tab === "inventaires" && <Inventaires />}
    </PageTitle>
  );
}

export default function Page() {
  return <Suspense><Stocks /></Suspense>;
}

function Synthese({ family: initial }: { family: string }) {
  const { depotId } = useSession();
  const [q, setQ] = useState("");
  const [family, setFamily] = useState(initial);
  const families = useApi("/v1/families");
  const { data, error, loading } = useApi("/v1/stock", { depot_id: depotId || undefined, q, family });
  return (
    <>
      <Alert tone="info" title="Lecture des quantités">
        Physique = présent au dépôt (tous statuts) · Réservé = affecté à une demande ou un transfert, non remis · Disponible = utilisable et contrôlé, non réservé ·
        En transit = expédié vers le dépôt, absent des deux dépôts · Bloqué = non contrôlé, en quarantaine ou en maintenance.
      </Alert>
      <div className="barre-outils">
        <Field label="Recherche"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Code ou désignation" /></Field>
        <Field label="Famille"><select value={family} onChange={(e) => setFamily(e.target.value)}><option value="">Toutes</option>
          {(families.data ?? []).map((f: any) => <option key={f.code} value={f.code}>{f.label}</option>)}</select></Field>
      </div>
      <ErrorBox error={error} />
      <Card flush>
        {loading && !data ? <Loading /> : (
          <div className="tableau-wrap">
            <table className="tableau">
              <thead><tr><th>Dépôt</th><th>Article</th><th>Variante</th><th>Unité</th><th className="n">Physique</th><th className="n">Réservé</th>
                <th className="n">Disponible</th><th className="n">En transit</th><th className="n">Bloqué</th><th>Alerte</th></tr></thead>
              <tbody>
                {data?.items.map((r: any) => (
                  <tr key={r.depot_id + r.item_id + (r.variant_id ?? "")}>
                    <td>{r.depot_code}</td>
                    <td><Link href={`/catalogue/${r.item_id}`} className="mono">{r.item_code}</Link><div className="petit">{r.designation}</div></td>
                    <td>{r.variant_label ?? "—"}</td><td className="mono">{r.base_unit}</td>
                    <td className="n">{fmtQty(r.physical)}</td><td className="n">{fmtQty(r.reserved)}</td><td className="n"><strong>{fmtQty(r.available)}</strong></td>
                    <td className="n">{fmtQty(r.in_transit)}</td><td className="n">{fmtQty(r.blocked)}</td>
                    <td>{r.below_min ? <Badge tone="warn" label={`Sous le seuil (${fmtQty(r.min_stock)})`} /> : r.blocked > 0 ? <Badge tone="danger" label="Quantité bloquée" /> : ""}</td>
                  </tr>
                ))}
                {data?.items.length === 0 && <tr><td colSpan={10} className="vide">Aucun stock.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}

function Positions({ initialLocation, initialDepot }: { initialLocation: string; initialDepot: string }) {
  const { depotId, depots, can } = useSession();
  const depot = initialDepot || depotId || depots[0]?.id;
  const [location, setLocation] = useState(initialLocation);
  const { data, error, loading, reload } = useApi(depot ? "/v1/stock/positions" : null, { depot_id: depot, location_id: location || undefined });
  const locs = depots.find((d) => d.id === depot)?.locations ?? [];
  const [move, setMove] = useState<any>(null);
  const act = useAction();
  const relocate = () => act.run(async () => {
    await apiPost("/v1/stock/relocations", {
      from_location_id: move.location.id, to_location_id: move.to, item_id: move.item_id, variant_id: move.variant_id, lot_id: move.lot_id,
      quantity: Number(move.qty), reason: move.reason,
    });
    setMove(null);
    reload();
  }, "Déplacement enregistré au journal.");
  return (
    <>
      <div className="barre-outils">
        <Field label="Emplacement"><select value={location} onChange={(e) => setLocation(e.target.value)}><option value="">Tous</option>
          {locs.map((l) => <option key={l.id} value={l.id}>{l.code} — {l.kind_label}</option>)}</select></Field>
        <span className="petit muted">Dépôt : {depots.find((d) => d.id === depot)?.name ?? "—"} (sélecteur de périmètre dans le bandeau)</span>
      </div>
      <ErrorBox error={error} />
      {act.feedback}
      {move && (
        <Card title={`Déplacer ${move.item_code} depuis ${move.location.code}`}>
          <div className="grille g3">
            <Field label="Vers"><select value={move.to} onChange={(e) => setMove({ ...move, to: e.target.value })}><option value="">—</option>
              {locs.filter((l) => l.kind === "STORAGE" && l.id !== move.location.id).map((l) => <option key={l.id} value={l.id}>{l.code}</option>)}</select></Field>
            <Field label={`Quantité (disponible ${fmtQty(move.available)})`}><input type="number" min={0} value={move.qty} onChange={(e) => setMove({ ...move, qty: e.target.value })} /></Field>
            <Field label="Motif"><input value={move.reason} onChange={(e) => setMove({ ...move, reason: e.target.value })} /></Field>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button className="btn" onClick={relocate} disabled={act.busy}>Enregistrer le déplacement</button>
            <button className="btn sec" onClick={() => setMove(null)}>Annuler</button>
          </div>
        </Card>
      )}
      <Card flush>
        {loading && !data ? <Loading /> : (
          <div className="tableau-wrap">
            <table className="tableau">
              <thead><tr><th>Emplacement</th><th>Article</th><th>Variante / lot</th><th>Statut</th><th className="n">Quantité</th><th className="n">Réservé</th><th className="n">Disponible</th><th /></tr></thead>
              <tbody>
                {(data ?? []).map((p: any) => (
                  <tr key={p.id}>
                    <td><span className="mono">{p.location.code}</span><div className="petit muted">{p.location.kind_label}</div></td>
                    <td><span className="mono">{p.item_code}</span><div className="petit">{p.designation}</div></td>
                    <td>{p.variant_label ?? p.lot_number ?? "—"}</td><td><Badge code={p.status} /></td>
                    <td className="n">{fmtQty(p.quantity, p.base_unit)}</td><td className="n">{fmtQty(p.reserved)}</td><td className="n">{fmtQty(p.available)}</td>
                    <td>{can("stock.relocate") && p.status === "USABLE" && p.available > 0 &&
                      <button className="btn sec petit" onClick={() => setMove({ ...p, to: "", qty: p.available, reason: "" })}>Déplacer</button>}</td>
                  </tr>
                ))}
                {data?.length === 0 && <tr><td colSpan={8} className="vide">Aucune position.</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}

function Mouvements() {
  const { depotId, can, depots } = useSession();
  const [page, setPage] = useState(1);
  const [type, setType] = useState("");
  const { data, error, loading, reload } = useApi("/v1/movements", { depot_id: depotId || undefined, type, page, page_size: 30 });
  const [corr, setCorr] = useState<any>(null);
  const act = useAction();
  const locs = depots.flatMap((d) => d.locations.map((l) => ({ ...l, depot: d.code, depot_id: d.id })));
  const correct = () => act.run(async () => {
    await apiPost(`/v1/movements/${corr.id}/correction`, { reason: corr.reason, corrected_to_location_id: corr.to || null });
    setCorr(null);
    reload();
  }, "Correction enregistrée par mouvements liés ; le mouvement d'origine reste inchangé.");
  return (
    <>
      <Alert tone="info" title="Journal attribuable et non modifiable">
        Chaque mouvement est horodaté (horloge métier et heure d'enregistrement), attribué et relié à son origine. Une erreur se corrige par une
        contre-passation liée, jamais par réécriture.
      </Alert>
      <div className="barre-outils">
        <Field label="Type"><select value={type} onChange={(e) => { setType(e.target.value); setPage(1); }}><option value="">Tous</option>
          {Object.entries(MOVEMENT_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
      </div>
      <ErrorBox error={error} />
      {act.feedback}
      {corr && (
        <Card title={`Corriger ${corr.reference}`}>
          <div className="grille g2">
            <Field label="Motif (obligatoire)"><input value={corr.reason} onChange={(e) => setCorr({ ...corr, reason: e.target.value })} /></Field>
            <Field label="Emplacement correct (facultatif)"><select value={corr.to} onChange={(e) => setCorr({ ...corr, to: e.target.value })}><option value="">Contre-passation seule</option>
              {locs.filter((l) => l.depot === corr.depot_code && l.kind === "STORAGE").map((l) => <option key={l.id} value={l.id}>{l.code}</option>)}</select></Field>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button className="btn" onClick={correct} disabled={act.busy}>Enregistrer la correction</button>
            <button className="btn sec" onClick={() => setCorr(null)}>Annuler</button>
          </div>
        </Card>
      )}
      <Card flush>
        {loading && !data ? <Loading /> : (
          <div className="tableau-wrap">
            <table className="tableau">
              <thead><tr><th>Référence</th><th>Date métier</th><th>Type</th><th>Article / exemplaire</th><th className="n">Qté</th><th>De → vers</th><th>Statut</th><th>Acteur</th><th>Origine</th><th /></tr></thead>
              <tbody>
                {data?.items.map((m: any) => (
                  <tr key={m.id}>
                    <td className="mono">{m.reference}{m.corrects_movement_id && <div><Badge tone="warn" label="Correction liée" /></div>}</td>
                    <td className="petit">{fmtDate(m.occurred_at)}<div className="muted">enr. {fmtDate(m.recorded_at)}</div></td>
                    <td>{MOVEMENT_LABELS[m.type] ?? m.type}</td>
                    <td>{m.asset ? <Link href={`/equipements/${m.asset.id}`}>{m.asset.serial_number}</Link> : <span className="mono">{m.item.code}</span>}
                      <div className="petit muted">{m.variant_label ?? m.lot_number ?? ""}</div></td>
                    <td className="n">{m.reserved_delta && (m.type === "RESERVE" || m.type === "UNRESERVE") ? `(${fmtQty(m.quantity)})` : fmtQty(m.quantity, m.item.base_unit)}</td>
                    <td className="mono petit">{m.depot_code} · {m.from_location ?? "∅"} → {m.to_location ?? "∅"}</td>
                    <td className="petit">{m.from_status !== m.to_status ? `${statusLabel(m.from_status)} → ${statusLabel(m.to_status)}` : statusLabel(m.to_status)}</td>
                    <td className="petit">{m.actor}</td>
                    <td className="petit">{m.source_ref ?? m.source_type ?? "—"}{m.reason && <div className="muted">{m.reason}</div>}</td>
                    <td>{can("stock.correct") && ["PUTAWAY", "RELOCATION"].includes(m.type) &&
                      <button className="btn sec petit" onClick={() => setCorr({ ...m, reason: "", to: "" })}>Corriger</button>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {data && <Pager page={page} total={data.total} pageSize={30} onPage={setPage} />}
      </Card>
    </>
  );
}

function Inventaires() {
  const { depotId, depots, can } = useSession();
  const { data, reload } = useApi("/v1/stocktakes", { depot_id: depotId || undefined });
  const [form, setForm] = useState<any>(null);
  const act = useAction();
  const depot = depots.find((d) => d.id === (form?.depot_id ?? depotId)) ?? depots[0];
  const create = () => act.run(async () => {
    await apiPost("/v1/stocktakes", { depot_id: depot.id, name: form.name, location_ids: form.location ? [form.location] : [], blind: form.blind });
    setForm(null);
    reload();
  });
  return (
    <>
      <Alert tone="info" title="Règle de prise en compte des mouvements pendant le comptage">
        Les mouvements ne sont pas gelés. La quantité théorique d'un comptage = instantané d'ouverture + mouvements enregistrés après l'instantané et
        antérieurs à l'heure de comptage déclarée. Le premier comptage n'est jamais appliqué : tout écart impose un recomptage puis une approbation justifiée.
      </Alert>
      {can("stocktake.manage") && !form && <button className="btn" onClick={() => setForm({ name: "", location: "", blind: true, depot_id: depot?.id })}>Nouvelle campagne</button>}
      {form && depot && (
        <Card title="Nouvelle campagne de comptage">
          <div className="grille g3">
            <Field label="Nom"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="Dépôt"><select value={depot.id} onChange={(e) => setForm({ ...form, depot_id: e.target.value, location: "" })}>
              {depots.map((d) => <option key={d.id} value={d.id}>{d.code}</option>)}</select></Field>
            <Field label="Périmètre"><select value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })}><option value="">Tout le dépôt</option>
              {depot.locations.filter((l) => l.kind === "STORAGE").map((l) => <option key={l.id} value={l.id}>{l.code}</option>)}</select></Field>
          </div>
          <label className="petit"><input type="checkbox" checked={form.blind} onChange={(e) => setForm({ ...form, blind: e.target.checked })} /> Comptage à l'aveugle (quantités théoriques masquées aux compteurs)</label>
          {act.feedback}
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}><button className="btn" onClick={create} disabled={act.busy}>Créer</button>
            <button className="btn sec" onClick={() => setForm(null)}>Annuler</button></div>
        </Card>
      )}
      <div style={{ marginTop: 12 }}>
        <Card flush>
          <table className="tableau">
            <thead><tr><th>Référence</th><th>Campagne</th><th>Dépôt</th><th>Statut</th><th>Instantané</th><th>Lignes</th></tr></thead>
            <tbody>{(data?.items ?? []).map((s: any) => (
              <tr key={s.id}><td><Link className="mono" href={`/stocks/inventaires/${s.id}`}>{s.reference}</Link></td><td>{s.name}{s.blind && <div className="petit muted">À l'aveugle</div>}</td>
                <td>{s.depot.code}</td><td><Badge code={s.status} /></td><td className="petit">{fmtDate(s.snapshot_at)}</td>
                <td className="petit">{Object.entries(s.line_status_counts).map(([k, v]) => `${statusLabel(k)} : ${v}`).join(" · ") || "—"}</td></tr>))}
              {data?.items.length === 0 && <tr><td colSpan={6} className="vide">Aucune campagne.</td></tr>}
            </tbody>
          </table>
        </Card>
      </div>
    </>
  );
}
