"use client";
import Link from "next/link";
import { useState } from "react";
import { useSession } from "@/components/Shell";
import { Badge, Card, ErrorBox, Field, Loading, Pager, PageTitle, useAction, useApi } from "@/components/ui";
import { apiPost } from "@/lib/api";
import { INSPECTION_LABELS, TRACKING_LABELS } from "@/lib/labels";

export default function Catalogue() {
  const { can } = useSession();
  const [q, setQ] = useState("");
  const [family, setFamily] = useState("");
  const [page, setPage] = useState(1);
  const [creating, setCreating] = useState(false);
  const families = useApi("/v1/families");
  const { data, error, loading, reload } = useApi("/v1/items", { q, family, page, page_size: 25 });
  return (
    <PageTitle over="Référentiel" title="Catalogue des articles"
               actions={can("catalog.write") && <button className="btn" onClick={() => setCreating(!creating)}>{creating ? "Fermer" : "Nouvel article"}</button>}>
      {creating && <NewItem families={families.data ?? []} onDone={() => { setCreating(false); reload(); }} />}
      <div className="barre-outils">
        <Field label="Recherche"><input value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="Code ou désignation" /></Field>
        <Field label="Famille">
          <select value={family} onChange={(e) => { setFamily(e.target.value); setPage(1); }}>
            <option value="">Toutes</option>
            {(families.data ?? []).map((f: any) => <option key={f.code} value={f.code}>{f.label}</option>)}
          </select>
        </Field>
      </div>
      <ErrorBox error={error} />
      <Card flush>
        {loading && !data ? <Loading /> : (
          <div className="tableau-wrap">
            <table className="tableau">
              <thead><tr><th>Code</th><th>Désignation</th><th>Famille</th><th>Unité de base</th><th>Conditionnements</th><th>Suivi</th><th>Contrôle</th><th>État</th></tr></thead>
              <tbody>
                {data?.items.map((i: any) => (
                  <tr key={i.id}>
                    <td><Link className="mono" href={`/catalogue/${i.id}`}>{i.code}</Link></td>
                    <td>{i.designation}{i.variants.length > 0 && <div className="petit muted">Variantes : {i.variants.map((v: any) => v.code).join(", ")}</div>}</td>
                    <td>{i.family_label}</td><td className="mono">{i.base_unit}</td>
                    <td className="petit">{i.conversions.join(" · ") || "—"}</td>
                    <td>{TRACKING_LABELS[i.tracking]}</td><td className="petit">{INSPECTION_LABELS[i.inspection_level]}</td>
                    <td>{i.active ? <Badge tone="ok" label="Actif" /> : <Badge tone="neutre" label="Inactif" />}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {data && <Pager page={page} total={data.total} pageSize={25} onPage={setPage} />}
      </Card>
    </PageTitle>
  );
}

function NewItem({ families, onDone }: { families: any[]; onDone: () => void }) {
  const units = useApi("/v1/units");
  const act = useAction();
  const [f, setF] = useState<any>({ code: "", designation: "", family_code: "OUT", base_unit: "PCE", tracking: "QUANTITY", inspection_level: "VISUAL",
    description: "", loanable: false, consumable: false, packaging_unit: "", packaging_factor: "", variants: "" });
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const submit = () => act.run(async () => {
    await apiPost("/v1/items", {
      code: f.code, designation: f.designation, family_code: f.family_code, base_unit: f.base_unit, tracking: f.tracking,
      inspection_level: f.inspection_level, description: f.description, loanable: f.loanable, consumable: f.consumable,
      variants: f.variants ? f.variants.split(",").map((s: string) => s.trim()).filter(Boolean).map((c: string) => ({ code: c, label: `Taille ${c}` })) : [],
      packagings: f.packaging_unit ? [{ unit_code: f.packaging_unit, label: `${f.packaging_unit} de ${f.packaging_factor}`, factor: Number(f.packaging_factor) }] : [],
    });
    onDone();
  });
  return (
    <div style={{ marginBottom: 16 }}>
      <Card title="Nouvel article">
        <div className="grille g3">
          <Field label="Code (A-Z, 0-9, -)"><input value={f.code} onChange={set("code")} placeholder="OUT-XXX-00" /></Field>
          <Field label="Désignation"><input value={f.designation} onChange={set("designation")} /></Field>
          <Field label="Famille"><select value={f.family_code} onChange={set("family_code")}>{families.map((x) => <option key={x.code} value={x.code}>{x.label}</option>)}</select></Field>
          <Field label="Unité de base"><select value={f.base_unit} onChange={set("base_unit")}>
            {(units.data ?? []).filter((u: any) => u.dimension !== "PACKAGE").map((u: any) => <option key={u.code} value={u.code}>{u.label} ({u.code})</option>)}</select></Field>
          <Field label="Suivi"><select value={f.tracking} onChange={set("tracking")}>{Object.entries(TRACKING_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
          <Field label="Exigence de contrôle"><select value={f.inspection_level} onChange={set("inspection_level")}>{Object.entries(INSPECTION_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
          <Field label="Conditionnement (facultatif)" help="Seules les conversions déclarées seront acceptées.">
            <div style={{ display: "flex", gap: 6 }}>
              <select value={f.packaging_unit} onChange={set("packaging_unit")}><option value="">—</option>
                {(units.data ?? []).filter((u: any) => u.dimension === "PACKAGE").map((u: any) => <option key={u.code} value={u.code}>{u.label}</option>)}</select>
              <input type="number" min={1} value={f.packaging_factor} onChange={set("packaging_factor")} placeholder={`× ${f.base_unit}`} />
            </div>
          </Field>
          <Field label="Variantes (codes séparés par des virgules)"><input value={f.variants} onChange={set("variants")} placeholder="M, L, XL" /></Field>
          <Field label="Options">
            <label className="petit"><input type="checkbox" checked={f.loanable} onChange={set("loanable")} /> Prêtable</label>{" "}
            <label className="petit"><input type="checkbox" checked={f.consumable} onChange={set("consumable")} /> Consommable</label>
          </Field>
        </div>
        <Field label="Description"><textarea value={f.description} onChange={set("description")} /></Field>
        {act.feedback}
        <button className="btn" onClick={submit} disabled={act.busy}>Créer l'article</button>
      </Card>
    </div>
  );
}
