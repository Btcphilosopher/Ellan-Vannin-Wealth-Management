"use client";
import Link from "next/link";
import { use } from "react";
import DocumentsPanel from "@/components/DocumentsPanel";
import { Badge, Card, ErrorBox, Loading, PageTitle, useApi } from "@/components/ui";
import { fmtMoney, fmtQty, INSPECTION_LABELS, TRACKING_LABELS } from "@/lib/labels";

export default function ItemPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const item = useApi(`/v1/items/${id}`);
  const stock = useApi("/v1/stock", { item_id: id });
  const assets = useApi(item.data?.tracking === "SERIAL" ? "/v1/assets" : null, { item_id: id, page_size: 100 });
  if (item.loading && !item.data) return <Loading />;
  if (item.error) return <ErrorBox error={item.error} />;
  const i = item.data;
  return (
    <PageTitle over={`Catalogue · ${i.family_label}`} title={`${i.code} — ${i.designation}`}>
      <div className="grille g2">
        <Card title="Référence de catalogue">
          <dl className="def">
            <dt>Code</dt><dd className="mono">{i.code}</dd>
            <dt>Désignation</dt><dd>{i.designation}</dd>
            <dt>Famille</dt><dd>{i.family_label}</dd>
            <dt>Description</dt><dd>{i.description || "—"}</dd>
            <dt>Unité de base</dt><dd className="mono">{i.base_unit}</dd>
            <dt>Conditionnements</dt><dd>{i.packagings.length ? i.packagings.map((p: any) => <div key={p.unit_code}>{p.label} — <span className="mono">1 {p.unit_code} = {p.factor} {i.base_unit}</span></div>) : "Aucun"}</dd>
            <dt>Conversions autorisées</dt><dd>{i.conversions.length ? i.conversions.join(" ; ") : "Unité de base uniquement"} <span className="petit muted">(aucune autre conversion acceptée)</span></dd>
            <dt>Suivi</dt><dd>{TRACKING_LABELS[i.tracking]}</dd>
            <dt>Exigences de contrôle</dt><dd>{INSPECTION_LABELS[i.inspection_level]}<ul className="petit" style={{ margin: "4px 0 0", paddingLeft: 18 }}>{i.inspection_requirements.map((r: string) => <li key={r}>{r}</li>)}</ul></dd>
            <dt>Périodicité de contrôle</dt><dd>{i.maintenance_interval_days ? `${i.maintenance_interval_days} jours` : "—"}</dd>
            <dt>Variantes</dt><dd>{i.variants.map((v: any) => v.label).join(", ") || "—"}</dd>
            <dt>Prêtable / consommable</dt><dd>{i.loanable ? "Prêtable" : "Non prêtable"} · {i.consumable ? "Consommable" : "Non consommable"}</dd>
            <dt>Seuil / valeur indicative</dt><dd>{fmtQty(i.min_stock, i.base_unit)} · {fmtMoney(i.unit_value)} (fictive)</dd>
            <dt>État</dt><dd>{i.active ? <Badge tone="ok" label="Actif" /> : <Badge tone="neutre" label="Inactif" />} <span className="petit muted">version {i.version}</span></dd>
          </dl>
        </Card>
        <div className="grille" style={{ alignContent: "start" }}>
          <Card title="Stock par dépôt" flush>
            <table className="tableau">
              <thead><tr><th>Dépôt</th><th>Variante</th><th className="n">Physique</th><th className="n">Réservé</th><th className="n">Disponible</th><th className="n">Transit</th><th className="n">Bloqué</th></tr></thead>
              <tbody>{(stock.data?.items ?? []).map((r: any) => (
                <tr key={r.depot_id + (r.variant_id ?? "")}><td>{r.depot_code}</td><td>{r.variant_label ?? "—"}</td><td className="n">{fmtQty(r.physical)}</td>
                  <td className="n">{fmtQty(r.reserved)}</td><td className="n"><strong>{fmtQty(r.available)}</strong>{r.below_min && <> <Badge tone="warn" label="Sous le seuil" /></>}</td>
                  <td className="n">{fmtQty(r.in_transit)}</td><td className="n">{fmtQty(r.blocked)}</td></tr>))}
              </tbody>
            </table>
          </Card>
          {assets.data && (
            <Card title={`Exemplaires physiques (${assets.data.total})`} flush>
              <table className="tableau">
                <thead><tr><th>N° de série</th><th>Étiquette</th><th>Position</th><th>Cycle</th><th>État technique</th></tr></thead>
                <tbody>{assets.data.items.map((a: any) => (
                  <tr key={a.id}><td><Link href={`/equipements/${a.id}`}>{a.serial_number}</Link></td><td className="mono">{a.internal_tag}</td>
                    <td>{a.location ? `${a.depot.code} · ${a.location.code}` : a.custody.organization?.name ?? "—"}</td>
                    <td><Badge code={a.lifecycle} /></td><td><Badge code={a.technical_state} /></td></tr>))}
                </tbody>
              </table>
            </Card>
          )}
          <DocumentsPanel ownerType="ITEM" ownerId={i.id} />
        </div>
      </div>
    </PageTitle>
  );
}
