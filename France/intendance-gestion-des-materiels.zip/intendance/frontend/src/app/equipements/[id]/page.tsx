"use client";
import Link from "next/link";
import { use } from "react";
import DocumentsPanel from "@/components/DocumentsPanel";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Loading, PageTitle, useApi } from "@/components/ui";
import { downloadUrl } from "@/lib/api";
import { fmtDate, PHASE_LABELS } from "@/lib/labels";

const SOURCE_LINKS: Record<string, string> = {
  RECEIPT: "/receptions/", REQUEST: "/dotations/", ALLOCATION: "/dotations/dotation/", TRANSFER: "/transferts/", MAINTENANCE_ORDER: "/maintenance/",
  STOCKTAKE: "/stocks/inventaires/",
};

export default function AssetPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { can } = useSession();
  const { data: h, error, loading } = useApi(`/v1/assets/${id}/history`);
  const detail = useApi(`/v1/assets/${id}`);
  if (loading && !h) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  const a = h.asset;
  const phases = ["RECEPTION", "EMPLACEMENT", "AFFECTATION", "RETOUR", "MAINTENANCE", "ETAT"];
  return (
    <PageTitle over={`Traçabilité · ${a.item.code}`} title={`${a.item.designation} — n° ${a.serial_number}`}
               actions={<>
                 <a className="btn sec" href={`/v1/labels/assets/${a.id}.svg`} target="_blank" rel="noreferrer">Étiquette</a>
                 {can("report.export") && <a className="btn" href={downloadUrl("/v1/reports/asset-trace/download", { format: "pdf", asset_id: a.id })}>Exporter (PDF)</a>}
               </>}>
      <Alert tone={a.technical_state === "SERVICEABLE" ? "ok" : a.technical_state === "CONDEMNED" ? "info" : "warn"} title="Situation explicable">{h.explanation}</Alert>
      <div className="grille g3" style={{ marginTop: 12 }}>
        <Card title="Localisation"><dl className="def">
          <dt>Dépôt détenteur</dt><dd>{a.depot?.name}</dd>
          <dt>Emplacement</dt><dd>{a.location ? <><span className="mono">{a.location.code}</span> — {a.location.label}</> : "Hors emplacement"}</dd>
          <dt>Statut de stock</dt><dd>{a.stock_status ? <Badge code={a.stock_status} /> : "—"}</dd>
          <dt>Cycle de vie</dt><dd><Badge code={a.lifecycle} /></dd></dl></Card>
        <Card title="État technique"><dl className="def">
          <dt>État</dt><dd><Badge code={a.technical_state} /></dd>
          <dt>Prochain contrôle</dt><dd>{fmtDate(a.next_inspection_due, false)}</dd>
          <dt>Ordres ouverts</dt><dd>{(detail.data?.open_maintenance_orders ?? []).map((o: any) => <div key={o.id}><Link href={`/maintenance/${o.id}`}>{o.reference}</Link> <Badge code={o.status} /></div>)}
            {detail.data?.open_maintenance_orders?.length === 0 && "Aucun"}</dd></dl></Card>
        <Card title="Responsable de garde"><dl className="def">
          <dt>Garde</dt><dd>{{ DEPOT: "Dépôt", ORGANIZATION: "Organisation bénéficiaire", CARRIER: "Transporteur", NONE: "Aucune" }[a.custody.type as string]}</dd>
          <dt>Organisation</dt><dd>{a.custody.organization?.name ?? a.depot?.name}</dd>
          <dt>Responsable</dt><dd>{a.custody.person ?? "—"}</dd>
          <dt>Identifiants</dt><dd><span className="mono">{a.internal_tag}</span> · série <span className="mono">{a.serial_number}</span>{a.lot && <> · lot {a.lot.lot_number}</>}</dd></dl></Card>
      </div>
      <div style={{ marginTop: 16 }}>
        <Card title="Parcours : réception → emplacements → affectations → retours → maintenance → état actuel">
          <div className="frise">
            {phases.map((p, i) => {
              const n = h.phases.find((x: any) => x.code === p)?.count ?? 0;
              return <div key={p} className={`etape${n || p === "ETAT" ? " faite" : ""}`}><div className="pastille">{i + 1}</div>
                <div className="lib">{p === "ETAT" ? "État actuel" : PHASE_LABELS[p]}</div><div className="date">{p === "ETAT" ? "" : `${n} évén.`}</div></div>;
            })}
          </div>
        </Card>
      </div>
      <div className="grille g2" style={{ marginTop: 16 }}>
        <Card title="Chronologie complète">
          <ol className="chrono">
            {h.events.map((e: any, i: number) => (
              <li key={i}>
                <div className="quand">{fmtDate(e.at)} · {PHASE_LABELS[e.phase] ?? e.phase}</div>
                <div className="quoi">{e.title} <span className="mono muted">{e.reference}</span></div>
                <div className="petit">{e.detail}{e.status_change && <span className="muted"> · {e.status_change}</span>}</div>
                <div className="petit muted">{e.actor && <>par {e.actor}</>}{e.source_id && SOURCE_LINKS[e.source_type] && <> · <Link href={`${SOURCE_LINKS[e.source_type]}${e.source_id}`}>{e.source_ref ?? e.reference}</Link></>}
                  {e.reason && <> · {e.reason}</>}</div>
              </li>
            ))}
            <li><div className="quand">Aujourd'hui (horloge métier)</div><div className="quoi">État actuel</div><div className="petit">{h.explanation}</div></li>
          </ol>
        </Card>
        <div className="grille" style={{ alignContent: "start" }}>
          <DocumentsPanel ownerType="ASSET" ownerId={a.id} />
          <Alert tone="info" title="Rappel">Un scan identifie l'enregistrement ; il ne prouve ni l'état physique ni la réalisation d'un contrôle.</Alert>
        </div>
      </div>
    </PageTitle>
  );
}
