"use client";
import Link from "next/link";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, ErrorBox, Loading, useApi } from "@/components/ui";
import { fmtDate, fmtQty, MOVEMENT_LABELS, statusLabel } from "@/lib/labels";

type Kpi = { value: number; secondary: string; link: string };
type Family = { family_code: string; family_label: string; physical: number; reserved: number; available: number; in_transit: number; blocked: number };

export default function Dashboard() {
  const { depotId, me } = useSession();
  const { data, error, loading } = useApi("/v1/dashboard", { depot_id: depotId || undefined });
  if (loading && !data) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  const d = data!;
  const kpis: [string, Kpi][] = [
    ["Articles référencés", d.kpis.items], ["Demandes en attente", d.kpis.pending_requests],
    ["Équipements à contrôler", d.kpis.assets_to_inspect], ["Transferts en cours", d.kpis.transfers_in_progress],
  ];
  const max = Math.max(1, ...d.stock_state.by_family.map((f: Family) => f.physical + f.in_transit));
  return (
    <>
      <div className="titre-page">
        <div>
          <div className="surtitre">Vue d'ensemble · {me.organization.name}</div>
          <h1>Chaque matériel. Chaque mouvement.</h1>
        </div>
        <div className="actions">
          <Link className="btn sec" href="/scan">Scanner une étiquette</Link>
          <Link className="btn" href="/receptions?nouvelle=1">Nouvelle réception</Link>
        </div>
      </div>
      <div className="filet" />

      <div className="grille g4" style={{ marginBottom: 16 }}>
        {kpis.map(([label, k]) => (
          <Link key={label} href={k.link} className="carte kpi">
            <span className="lien">Ouvrir →</span>
            <div className="etiquette">{label}</div>
            <div className="valeur">{fmtQty(k.value)}</div>
            <div className="secondaire">{k.secondary}</div>
          </Link>
        ))}
      </div>

      <div className="grille g-dash">
        <div className="grille">
          <Card title="État des stocks" num="01" right={<Link href="/stocks">Détail par article →</Link>}>
            <div className="legende" style={{ marginBottom: 10 }}>
              <span><i className="s-dispo" />Disponible</span><span><i className="s-reserve" />Réservé</span>
              <span><i className="s-bloque" />Bloqué (non contrôlé, quarantaine, maintenance)</span><span><i className="s-transit" />En transit</span>
            </div>
            <div className="tableau-wrap">
              <table className="tableau">
                <thead><tr><th>Famille</th><th style={{ width: "34%" }}>Répartition</th><th className="n">Physique</th><th className="n">Réservé</th>
                  <th className="n">Disponible</th><th className="n">En transit</th><th className="n">Bloqué</th></tr></thead>
                <tbody>
                  {d.stock_state.by_family.map((f: Family) => (
                    <tr key={f.family_code}>
                      <td><Link href={`/stocks?famille=${f.family_code}`}>{f.family_label}</Link></td>
                      <td>
                        <div className="barre" title={`Disponible ${f.available} · Réservé ${f.reserved} · Bloqué ${f.blocked} · En transit ${f.in_transit}`}
                             style={{ width: `${Math.max(8, ((f.physical + f.in_transit) / max) * 100)}%` }}>
                          {[["s-dispo", f.available], ["s-reserve", f.reserved], ["s-bloque", f.blocked], ["s-transit", f.in_transit]].map(([c, v]) => (
                            <span key={c as string} className={c as string} style={{ width: `${((v as number) / Math.max(1, f.physical + f.in_transit)) * 100}%` }} />
                          ))}
                        </div>
                      </td>
                      <td className="n">{fmtQty(f.physical)}</td><td className="n">{fmtQty(f.reserved)}</td><td className="n"><strong>{fmtQty(f.available)}</strong></td>
                      <td className="n">{fmtQty(f.in_transit)}</td><td className="n">{f.blocked ? <Badge tone="danger" label={fmtQty(f.blocked)} /> : "0"}</td>
                    </tr>
                  ))}
                  {d.stock_state.by_family.length === 0 && <tr><td colSpan={7} className="vide">Aucun stock dans ce périmètre.</td></tr>}
                </tbody>
                <tfoot><tr><td>Total</td><td className="petit muted">Unités de base, toutes familles</td>
                  {["physical", "reserved", "available", "in_transit", "blocked"].map((k) => <td key={k} className="n">{fmtQty(d.stock_state.totals[k])}</td>)}</tr></tfoot>
              </table>
            </div>
          </Card>

          <Card title="Traçabilité d'un équipement" num="03"
                right={d.traceability && <Link href={`/equipements/${d.traceability.asset.id}`}>Fiche complète →</Link>}>
            {d.traceability ? (
              <>
                <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "baseline" }}>
                  <strong style={{ fontFamily: "var(--serif)", fontSize: 17 }}>{d.traceability.asset.item.designation}</strong>
                  <span className="mono">n° {d.traceability.asset.serial_number}</span>
                  <span className="mono muted">{d.traceability.asset.internal_tag}</span>
                  <Badge code={d.traceability.asset.technical_state} />
                </div>
                <div className="frise" style={{ marginTop: 14 }}>
                  {d.traceability.steps.map((s: any, i: number) => (
                    <div key={s.phase} className={`etape${s.count ? " faite" : ""}`}>
                      <div className="pastille">{i + 1}</div>
                      <div className="lib">{s.label}</div>
                      <div className="date">{s.phase === "ETAT" ? "" : s.last_at ? fmtDate(s.last_at, false) : "—"}</div>
                      <div className="date">{s.phase === "ETAT" ? "" : `${s.count} évén.`}</div>
                    </div>
                  ))}
                </div>
                <Alert tone="info" title="État actuel">{d.traceability.explanation}</Alert>
              </>
            ) : <div className="vide">Aucun équipement sérialisé.</div>}
          </Card>
        </div>

        <div className="grille" style={{ alignContent: "start" }}>
          <Card title="Actions prioritaires" num="02" right={<span className="muted">{d.priority_actions_total} au total</span>} flush>
            {d.priority_actions.length ? (
              <ul className="actions-liste">
                {d.priority_actions.map((a: any, i: number) => (
                  <li key={i}>
                    <div><Badge code={a.severity} /><div className="cat" style={{ marginTop: 4 }}>{a.category}</div></div>
                    <div><Link href={a.link}>{a.text}</Link>{a.at && <div className="petit muted">{fmtDate(a.at)}</div>}</div>
                  </li>
                ))}
              </ul>
            ) : <div className="vide">Aucune action en attente.</div>}
          </Card>

          <Card title="Derniers mouvements" num="04" right={<Link href="/stocks?onglet=mouvements">Journal →</Link>} flush>
            <div className="tableau-wrap">
              <table className="tableau">
                <thead><tr><th>Date</th><th>Mouvement</th><th>Article</th><th className="n">Qté</th></tr></thead>
                <tbody>
                  {d.recent_movements.map((m: any) => (
                    <tr key={m.id}>
                      <td className="petit">{fmtDate(m.occurred_at)}<div className="mono muted">{m.reference}</div></td>
                      <td>{MOVEMENT_LABELS[m.type] ?? m.type}<div className="petit muted">{[m.from_location, m.to_location].filter(Boolean).join(" → ") || statusLabel(m.to_status)}</div></td>
                      <td>{m.asset ? <Link href={`/equipements/${m.asset.id}`}>{m.asset.serial_number}</Link> : m.item.code}
                        <div className="petit muted">{m.variant_label ?? m.lot_number ?? m.item.designation}</div></td>
                      <td className="n">{fmtQty(m.quantity, m.item.base_unit)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
