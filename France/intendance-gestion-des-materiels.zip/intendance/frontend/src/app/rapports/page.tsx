"use client";
import { useState } from "react";
import { useSession } from "@/components/Shell";
import { Alert, Badge, Card, Field, PageTitle, useAction, useApi } from "@/components/ui";
import { apiGet, apiPost, downloadUrl } from "@/lib/api";
import { fmtDate } from "@/lib/labels";

export default function Rapports() {
  const { depotId, can } = useSession();
  const reports = useApi("/v1/reports");
  const assets = useApi("/v1/assets", { page_size: 200 });
  const stocktakes = useApi("/v1/stocktakes");
  const [params, setParams] = useState<Record<string, string>>({});
  const [jobs, setJobs] = useState<any[]>([]);
  const act = useAction();
  const paramsFor = (kind: string) => ({
    ...(kind === "asset-trace" ? { asset_id: params[`${kind}.asset_id`] } : {}),
    ...(kind === "stocktake" ? { stocktake_id: params[`${kind}.stocktake_id`] } : {}),
    ...(["stock", "movements", "transfers", "maintenance"].includes(kind) && depotId ? { depot_id: depotId } : {}),
  });
  const background = (kind: string, format: string) => act.run(async () => {
    const j = await apiPost("/v1/reports/exports", { kind, format, params: paramsFor(kind) });
    setJobs((cur) => [{ ...j, kind, format }, ...cur]);
  }, "Export mis en file : il sera produit par le traitement en arrière-plan et conservé comme document.");
  const refresh = async () => setJobs(await Promise.all(jobs.map(async (j) => ({ ...j, ...(await apiGet(`/v1/reports/exports/${j.job_id}`)) }))));
  if (!can("report.export")) return <PageTitle title="Rapports"><Alert tone="warn" title="Accès restreint">Les exports sont réservés aux responsables, approbateurs, auditeurs et administrateurs.</Alert></PageTitle>;
  return (
    <PageTitle over="Restitution" title="Rapports et exports">
      {act.feedback}
      <div className="grille g2">
        {(reports.data ?? []).map((r: any) => (
          <Card key={r.kind} title={r.title} right={r.allowed ? <Badge tone="ok" label="Autorisé" /> : <Badge tone="neutre" label="Non autorisé" />}>
            {r.kind === "asset-trace" && <Field label="Équipement"><select value={params["asset-trace.asset_id"] ?? ""} onChange={(e) => setParams({ ...params, "asset-trace.asset_id": e.target.value })}>
              <option value="">—</option>{(assets.data?.items ?? []).map((a: any) => <option key={a.id} value={a.id}>{a.serial_number} — {a.item.designation}</option>)}</select></Field>}
            {r.kind === "stocktake" && <Field label="Inventaire"><select value={params["stocktake.stocktake_id"] ?? ""} onChange={(e) => setParams({ ...params, "stocktake.stocktake_id": e.target.value })}>
              <option value="">—</option>{(stocktakes.data?.items ?? []).map((s: any) => <option key={s.id} value={s.id}>{s.reference} — {s.name}</option>)}</select></Field>}
            <p className="petit muted">{depotId && ["stock", "movements", "transfers", "maintenance"].includes(r.kind) ? "Périmètre : dépôt sélectionné." : "Périmètre : vos dépôts autorisés."}</p>
            {r.allowed && <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              <a className="btn petit" href={downloadUrl(`/v1/reports/${r.kind}/download`, { format: "csv", ...paramsFor(r.kind) })}>CSV immédiat</a>
              <a className="btn sec petit" href={downloadUrl(`/v1/reports/${r.kind}/download`, { format: "pdf", ...paramsFor(r.kind) })}>PDF immédiat</a>
              <button className="btn sec petit" onClick={() => background(r.kind, "pdf")}>PDF en arrière-plan</button>
            </div>}
          </Card>
        ))}
      </div>
      {jobs.length > 0 && (
        <div style={{ marginTop: 16 }}>
          <Card title="Exports en arrière-plan" right={<button className="btn sec petit" onClick={refresh}>Actualiser</button>} flush>
            <table className="tableau"><thead><tr><th>Rapport</th><th>Format</th><th>Statut</th><th>Terminé</th><th /></tr></thead>
              <tbody>{jobs.map((j) => <tr key={j.job_id}><td>{j.kind}</td><td>{j.format}</td><td><Badge code={j.status} />{j.error && <div className="petit">{j.error}</div>}</td>
                <td className="petit">{fmtDate(j.finished_at)}</td>
                <td>{j.result?.document_id && <a className="btn sec petit" href={`/v1/documents/${j.result.document_id}/versions/1/content`}>Télécharger</a>}</td></tr>)}</tbody></table>
          </Card>
        </div>
      )}
    </PageTitle>
  );
}
