"use client";
import Link from "next/link";
import { FormEvent, useEffect, useRef, useState } from "react";
import { Alert, Card, ErrorBox, Field, PageTitle } from "@/components/ui";
import { apiGet } from "@/lib/api";

export default function Scan() {
  const [code, setCode] = useState("");
  const [res, setRes] = useState<any>(null);
  const [error, setError] = useState<unknown>(null);
  const [camera, setCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const supported = typeof window !== "undefined" && "BarcodeDetector" in window;

  const lookup = async (value: string) => {
    setError(null);
    setRes(null);
    try { setRes(await apiGet(`/v1/scan/${encodeURIComponent(value.trim())}`)); } catch (e) { setError(e); }
  };
  const submit = (e: FormEvent) => { e.preventDefault(); if (code.trim()) lookup(code); };
  useEffect(() => inputRef.current?.focus(), []);

  useEffect(() => {
    if (!camera || !supported) return;
    let stream: MediaStream | null = null;
    let stop = false;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        if (videoRef.current) { videoRef.current.srcObject = stream; await videoRef.current.play(); }
        // @ts-expect-error API expérimentale du navigateur
        const detector = new window.BarcodeDetector({ formats: ["code_128", "qr_code"] });
        while (!stop && videoRef.current) {
          const found = await detector.detect(videoRef.current);
          if (found.length) { setCode(found[0].rawValue); lookup(found[0].rawValue); setCamera(false); break; }
          await new Promise((r) => setTimeout(r, 300));
        }
      } catch (e) { setError(e); setCamera(false); }
    })();
    return () => { stop = true; stream?.getTracks().forEach((t) => t.stop()); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [camera]);

  return (
    <PageTitle over="Étiquettes internes" title="Scanner une étiquette">
      <Alert tone="warn" title="Portée d'un scan">Un scan identifie un enregistrement ; il ne prouve ni l'état physique du matériel, ni sa présence effective, ni la réalisation d'un contrôle.</Alert>
      <div className="grille g2">
        <Card title="Saisie ou lecteur">
          <form onSubmit={submit} className="formulaire">
            <Field label="Code lu (étiquette ITD-…, LOC-…, code article, n° de série ou de lot)" help="Un lecteur de codes-barres USB agit comme un clavier : scannez dans ce champ.">
              <input ref={inputRef} value={code} onChange={(e) => setCode(e.target.value)} placeholder="ITD-A000024" autoComplete="off" />
            </Field>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn">Identifier</button>
              {supported && <button type="button" className="btn sec" onClick={() => setCamera(!camera)}>{camera ? "Arrêter la caméra" : "Utiliser la caméra"}</button>}
            </div>
            {camera && <video ref={videoRef} style={{ width: "100%", borderRadius: 6, background: "#000" }} muted playsInline />}
          </form>
        </Card>
        <Card title="Résultat">
          <ErrorBox error={error} />
          {res ? (
            <ul className="actions-liste">
              {res.matches.map((m: any) => (
                <li key={m.kind + m.id}><div className="cat">{{ ASSET: "Équipement", LOCATION: "Emplacement", ITEM: "Article", LOT: "Lot" }[m.kind as string]}</div>
                  <div><Link href={m.link}>{m.label}</Link><div className="mono muted">{m.reference}</div></div></li>
              ))}
            </ul>
          ) : !error && <div className="vide">Aucun code lu.</div>}
        </Card>
      </div>
    </PageTitle>
  );
}
