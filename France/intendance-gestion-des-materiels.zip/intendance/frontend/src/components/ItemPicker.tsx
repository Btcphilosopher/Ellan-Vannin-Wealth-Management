"use client";
import { useApi } from "./ui";

export type LineDraft = { item_id: string; variant_id: string; unit: string; quantity: string; kind?: string; due_date?: string };

/** Éditeur de lignes article / variante / unité / quantité. Seules les unités déclarées pour l'article sont proposées. */
export default function LinesEditor({ lines, setLines, withLoan = false, withUnit = true }:
  { lines: LineDraft[]; setLines: (l: LineDraft[]) => void; withLoan?: boolean; withUnit?: boolean }) {
  const items = useApi("/v1/items", { page_size: 200 });
  const all: any[] = items.data?.items ?? [];
  const upd = (i: number, patch: Partial<LineDraft>) => setLines(lines.map((l, j) => (j === i ? { ...l, ...patch } : l)));
  return (
    <div className="tableau-wrap">
      <table className="tableau lignes-saisie">
        <thead><tr><th>Article</th><th>Variante</th>{withUnit && <th>Unité</th>}<th>Quantité</th>{withLoan && <><th>Nature</th><th>Échéance</th></>}<th /></tr></thead>
        <tbody>
          {lines.map((l, i) => {
            const item = all.find((x) => x.id === l.item_id);
            return (
              <tr key={i}>
                <td><select className="mini" value={l.item_id} onChange={(e) => {
                  const it = all.find((x) => x.id === e.target.value);
                  upd(i, { item_id: e.target.value, variant_id: "", unit: it?.base_unit ?? "" });
                }}><option value="">— article —</option>{all.map((x) => <option key={x.id} value={x.id}>{x.code} — {x.designation}</option>)}</select></td>
                <td>{item?.variants.length ? <select className="mini" value={l.variant_id} onChange={(e) => upd(i, { variant_id: e.target.value })}>
                  <option value="">—</option>{item.variants.map((v: any) => <option key={v.id} value={v.id}>{v.label}</option>)}</select> : <span className="muted">—</span>}</td>
                {withUnit && <td>{item ? <select className="mini" value={l.unit} onChange={(e) => upd(i, { unit: e.target.value })}>
                  <option value={item.base_unit}>{item.base_unit}</option>{item.packagings.map((p: any) => <option key={p.unit_code} value={p.unit_code}>{p.label}</option>)}</select> : "—"}</td>}
                <td><input className="mini" type="number" min={0} step="any" value={l.quantity} onChange={(e) => upd(i, { quantity: e.target.value })} /></td>
                {withLoan && <>
                  <td><select className="mini" value={l.kind ?? "ALLOCATION"} onChange={(e) => upd(i, { kind: e.target.value })} disabled={item && !item.loanable}>
                    <option value="ALLOCATION">Dotation</option>{item?.loanable && <option value="LOAN">Prêt</option>}</select></td>
                  <td>{l.kind === "LOAN" && <input className="mini" type="date" value={l.due_date ?? ""} onChange={(e) => upd(i, { due_date: e.target.value })} />}</td>
                </>}
                <td><button className="btn sec petit" onClick={() => setLines(lines.filter((_, j) => j !== i))} aria-label="Retirer la ligne">✕</button></td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <button className="btn sec petit" style={{ margin: 8 }} onClick={() => setLines([...lines, { item_id: "", variant_id: "", unit: "", quantity: "" }])}>+ Ajouter une ligne</button>
    </div>
  );
}
