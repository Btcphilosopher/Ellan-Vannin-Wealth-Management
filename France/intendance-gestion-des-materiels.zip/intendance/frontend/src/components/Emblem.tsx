// Emblème original : profil de coq stylisé (crête, bec, barbillon) dans une couronne de feuilles de chêne et glands,
// cerclé de laiton, avec un fin filet tricolore. Dessin géométrique créé pour ce concept ; aucun insigne officiel n'est reproduit.
export default function Emblem({ size = 52, title = "Emblème INTENDANCE" }: { size?: number; title?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label={title}>
      <title>{title}</title>
      <defs>
        <linearGradient id="laiton" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#e3c983" />
          <stop offset="0.55" stopColor="#b08d3c" />
          <stop offset="1" stopColor="#7d6223" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="47" fill="#0f1d33" stroke="url(#laiton)" strokeWidth="4" />
      <circle cx="50" cy="50" r="40.5" fill="none" stroke="#c9a95e" strokeWidth="0.8" strokeDasharray="1.5 2.2" />
      {/* filet tricolore discret */}
      <path d="M30 88 h13" stroke="#1f3f8f" strokeWidth="2.4" />
      <path d="M43.5 88 h13" stroke="#ffffff" strokeWidth="2.4" />
      <path d="M57 88 h13" stroke="#b3202a" strokeWidth="2.4" />
      {/* couronne de chêne : feuilles lobées et glands */}
      <g fill="url(#laiton)">
        <path d="M22 70 c-6-8-7-18-3-27 c2 3 5 4 6 8 c-3 1-4 4-2 6 c2 1 4 0 5 2 c-3 1-3 4-1 6 c2 0 3 1 3 3 c-3 0-5 1-8 2z" />
        <path d="M78 70 c6-8 7-18 3-27 c-2 3-5 4-6 8 c3 1 4 4 2 6 c-2 1-4 0-5 2 c3 1 3 4 1 6 c-2 0-3 1-3 3 c3 0 5 1 8 2z" />
        <ellipse cx="29.5" cy="75.5" rx="3.2" ry="4" />
        <ellipse cx="70.5" cy="75.5" rx="3.2" ry="4" />
      </g>
      <g fill="#7d6223">
        <rect x="26.5" y="70.2" width="6" height="2.6" rx="1.2" />
        <rect x="67.5" y="70.2" width="6" height="2.6" rx="1.2" />
      </g>
      {/* coq stylisé (profil tourné vers la gauche) */}
      <g>
        <path d="M58 28 c3-5 8-6 9-2 c3-3 7-2 7 2 c3-1 5 2 3 5 c-2 2-5 2-7 1 z" fill="#b3202a" />
        <path d="M44 41 c1-8 7-13 14-13 c8 0 13 6 13 13 c0 8-3 13-7 17 c5 2 9 7 9 13 h-30 c0-7 3-11 7-14 c-4-3-6-9-6-16z"
              fill="#f6f1e3" stroke="#c9a95e" strokeWidth="1.2" />
        <path d="M44 41 l-9 3 l9 3 z" fill="#c9a95e" />
        <path d="M46 48 c-1 5 1 9 4 9 c2-3 1-7-1-9 z" fill="#b3202a" />
        <circle cx="54.5" cy="38.5" r="2.1" fill="#0f1d33" />
        <path d="M52 64 c4-3 10-3 14 0" fill="none" stroke="#1f3f8f" strokeWidth="2" strokeLinecap="round" />
      </g>
    </svg>
  );
}
