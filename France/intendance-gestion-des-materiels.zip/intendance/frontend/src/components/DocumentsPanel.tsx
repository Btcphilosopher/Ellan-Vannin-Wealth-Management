"use client";
import { useState } from "react";
import { Badge, Card, Field, useAction, useApi } from "./ui";
import { apiUpload } from "@/lib/api";
import { fmtDate } from "@/lib/labels";

export default function DocumentsPanel({ ownerType, ownerId, defaultKind = "OTHER" }: { ownerType: string; ownerId: string; defaultKind?: string }) {
  const docs = useApi("/v1/documents", { owner_type: ownerType, owner_id: ownerId });
  const kinds = useApi("/v1/documents/kinds");
  const act = useAction();
  const [file, setFile] = useState<File | null>(null);
  const [kind, setKind] = useState(defaultKind);
  const [title, setTitle] = useState("");
  const [restricted, setRestricted] = useState(false);
  const upload = () => act.run(async () => {
    if (!file) throw new Error("Choisir un fichier.");
    const form = new FormData();
    form.set("file", file);
    form.set("owner_type", ownerType);
    form.set("owner_id", ownerId);
    form.set("kind", kind);
    form.set("title", title || file.name);
    form.set("access_level", restricted ? "RESTRICTED" : "INTERNAL");
    await apiUpload("/v1/documents", form);
    setFile(null);
    setTitle("");
    docs.reload();
  }, "Document versionné et attaché.");
  return (
    <Card title="Documents attachés" flush>
      <table className="tableau">
        <thead><tr><th>Document</th><th>Nature</th><th>Version</th><th>Auteur / date</th><th /></tr></thead>
        <tbody>
          {(docs.data?.items ?? []).map((d: any) => {
            const v = d.versions[d.versions.length - 1];
            return (
              <tr key={d.id}>
                <td>{d.title}<div className="mono muted">{d.reference}</div></td>
                <td>{d.kind_label}{d.access_level === "RESTRICTED" && <> <Badge tone="warn" label="Restreint" /></>}</td>
                <td className="n">v{d.current_version}</td>
                <td className="petit">{v?.author}<div className="muted">{fmtDate(v?.created_at)}</div></td>
                <td><a className="btn sec petit" href={`/v1/documents/${d.id}/versions/${d.current_version}/content`}>Télécharger</a></td>
              </tr>
            );
          })}
          {docs.data && docs.data.items.length === 0 && <tr><td colSpan={5} className="vide">Aucun document.</td></tr>}
        </tbody>
      </table>
      <div className="carte-corps" style={{ borderTop: "1px solid var(--ligne-2)" }}>
        <div className="grille g3">
          <Field label="Fichier (PDF, PNG, JPEG, TXT, CSV — 10 Mo max)"><input type="file" accept=".pdf,.png,.jpg,.jpeg,.txt,.csv" onChange={(e) => setFile(e.target.files?.[0] ?? null)} /></Field>
          <Field label="Nature"><select value={kind} onChange={(e) => setKind(e.target.value)}>{(kinds.data ?? []).map((k: any) => <option key={k.code} value={k.code}>{k.label}</option>)}</select></Field>
          <Field label="Titre"><input value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
        </div>
        <label className="petit"><input type="checkbox" checked={restricted} onChange={(e) => setRestricted(e.target.checked)} /> Diffusion restreinte (responsables, approbateurs, auditeurs, maintenance)</label>
        {act.feedback}
        <div style={{ marginTop: 8 }}><button className="btn sec petit" onClick={upload} disabled={act.busy || !file}>Attacher le document</button></div>
      </div>
    </Card>
  );
}
