"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import Emblem from "./Emblem";
import { apiGet, apiPost } from "@/lib/api";
import { fmtDate } from "@/lib/labels";

export type Me = {
  id: string; username: string; full_name: string; organization: { code: string; name: string };
  memberships: { role: string; role_label: string; depot_id: string | null; depot_code: string | null }[];
  permissions: string[]; permissions_by_depot: Record<string, string[]>; visible_depot_ids: string[]; clock: { mode: string; now: string };
};
type Depot = { id: string; code: string; name: string; locations: { id: string; code: string; label: string; kind: string; kind_label: string }[] };

type SessionValue = { me: Me; depots: Depot[]; depotId: string; setDepotId: (id: string) => void; can: (p: string, depotId?: string | null) => boolean; refreshMe: () => void };
const SessionCtx = createContext<SessionValue | null>(null);
export const useSession = () => {
  const v = useContext(SessionCtx);
  if (!v) throw new Error("Session indisponible");
  return v;
};

const NAV: [string, string][] = [
  ["/", "Vue d'ensemble"], ["/catalogue", "Catalogue"], ["/stocks", "Stocks"], ["/depots", "Dépôts"], ["/receptions", "Réceptions"],
  ["/transferts", "Transferts"], ["/maintenance", "Maintenance"], ["/dotations", "Dotations"], ["/documents", "Documents"],
  ["/rapports", "Rapports"], ["/administration", "Administration"],
];

export default function Shell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);
  const [depots, setDepots] = useState<Depot[]>([]);
  const [depotId, setDepotIdState] = useState<string>("");
  const [open, setOpen] = useState(false);
  const isLogin = path?.startsWith("/connexion");

  const load = async () => {
    try {
      const m = await apiGet<Me>("/v1/auth/me");
      setMe(m);
      setDepots(await apiGet<Depot[]>("/v1/depots"));
    } catch {
      /* redirection gérée par le client d'API */
    }
  };
  useEffect(() => {
    if (!isLogin) {
      load();
      setDepotIdState(typeof window !== "undefined" ? localStorage.getItem("intendance.depot") ?? "" : "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLogin]);
  useEffect(() => setOpen(false), [path]);

  if (isLogin) return <>{children}</>;
  const setDepotId = (id: string) => {
    setDepotIdState(id);
    try { localStorage.setItem("intendance.depot", id); } catch { /* stockage indisponible */ }
  };
  const logout = async () => {
    try { await apiPost("/v1/auth/logout"); } finally { router.push("/connexion"); }
  };
  const roles = me ? Array.from(new Set(me.memberships.map((m) => m.role_label + (m.depot_code ? ` (${m.depot_code})` : "")))).join(", ") : "";

  return (
    <>
      <div className="tricolore" />
      <header className="bandeau">
        <div className="bandeau-inner">
          <Link href="/" className="marque" aria-label="INTENDANCE — accueil">
            <Emblem size={50} />
            <div>
              <div className="marque-titre">INTENDANCE</div>
              <div className="marque-sous">Gestion des matériels</div>
            </div>
          </Link>
          {me && (
            <div className="bandeau-droite">
              <label className="sr" htmlFor="depot">Périmètre</label>
              <select id="depot" value={depotId} onChange={(e) => setDepotId(e.target.value)} title="Périmètre affiché">
                <option value="">Tous mes dépôts</option>
                {depots.map((d) => <option key={d.id} value={d.id}>{d.code} — {d.name.split("—")[0].trim()}</option>)}
              </select>
              <span className="horloge" title={me.clock.mode === "fixed" ? "Horloge de démonstration (figée)" : "Heure réelle"}>
                {me.clock.mode === "fixed" ? "Horloge démo · " : ""}{fmtDate(me.clock.now)}
              </span>
              <div className="utilisateur">
                {me.full_name}
                <small>{roles}</small>
              </div>
              <button onClick={logout}>Se déconnecter</button>
            </div>
          )}
        </div>
      </header>
      <nav className="nav" aria-label="Navigation principale">
        <button className="menu-mobile" onClick={() => setOpen(!open)} aria-expanded={open}>☰ Menu</button>
        <div className={`nav-inner${open ? " ouvert" : ""}`}>
          {NAV.map(([href, label]) => {
            const active = href === "/" ? path === "/" : path?.startsWith(href);
            return <Link key={href} href={href} className={active ? "actif" : ""} aria-current={active ? "page" : undefined}>{label}</Link>;
          })}
          <Link href="/scan" className={`scan${path?.startsWith("/scan") ? " actif" : ""}`}>▮▯▮ Scanner</Link>
        </div>
      </nav>
      <main className="page">
        {me ? (
          <SessionCtx.Provider value={{ me, depots, depotId, setDepotId, can: (p, d) => (d ? (me.permissions_by_depot[d] ?? []).includes(p) : me.permissions.includes(p)), refreshMe: load }}>
            {children}
          </SessionCtx.Provider>
        ) : <div className="chargement">Ouverture de la session…</div>}
      </main>
      <footer className="pied">
        <span className="mention">
          Concept logiciel indépendant — organisations, matériels et mouvements fictifs — sans affiliation officielle ni connexion à des systèmes réels.
          Prototype <strong>non apte au traitement d'informations classifiées</strong>.
        </span>
      </footer>
    </>
  );
}
