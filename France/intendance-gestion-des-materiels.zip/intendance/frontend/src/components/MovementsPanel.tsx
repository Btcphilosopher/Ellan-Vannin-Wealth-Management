"use client";
import { Card, useApi } from "./ui";
import { fmtDate, fmtQty, MOVEMENT_LABELS, statusLabel } from "@/lib/labels";

export default function MovementsPanel({ sourceId, title = "Mouvements liés" }: { sourceId: string; title?: string }) {
  const { data } = useApi("/v1/movements", { source_id: sourceId, page_size: 100 });
  return (
    <Card title={title} flush>
      <div className="tableau-wrap">
        <table className="tableau">
          <thead><tr><th>Référence</th><th>Date</th><th>Type</th><th>Article</th><th className="n">Qté</th><th>De → vers</th><th>Acteur</th></tr></thead>
          <tbody>
            {(data?.items ?? []).map((m: any) => (
              <tr key={m.id}><td className="mono">{m.reference}</td><td className="petit">{fmtDate(m.occurred_at)}</td><td>{MOVEMENT_LABELS[m.type] ?? m.type}
                <div className="petit muted">{m.from_status !== m.to_status ? `${statusLabel(m.from_status)} → ${statusLabel(m.to_status)}` : ""}</div></td>
                <td className="petit">{m.asset?.serial_number ?? m.item.code} {m.variant_label ?? m.lot_number ?? ""}</td>
                <td className="n">{fmtQty(m.quantity)}</td><td className="mono petit">{m.from_location ?? "∅"} → {m.to_location ?? "∅"}</td><td className="petit">{m.actor}</td></tr>
            ))}
            {data?.items.length === 0 && <tr><td colSpan={7} className="vide">Aucun mouvement.</td></tr>}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
