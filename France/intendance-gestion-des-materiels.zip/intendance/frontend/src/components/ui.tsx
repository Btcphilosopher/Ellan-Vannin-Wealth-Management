"use client";
import Link from "next/link";
import { ReactNode, useCallback, useEffect, useState } from "react";
import { ApiError, apiGet } from "@/lib/api";
import { statusLabel, statusTone, Tone } from "@/lib/labels";

export function Badge({ code, label, tone }: { code?: string | null; label?: string; tone?: Tone }) {
  const t = tone ?? statusTone(code);
  return <span className={`badge b-${t}`}>{label ?? statusLabel(code)}</span>;
}

export function Alert({ tone = "info", title, children }: { tone?: "danger" | "warn" | "info" | "ok"; title?: string; children?: ReactNode }) {
  const ico = { danger: "!", warn: "▲", info: "i", ok: "✓" }[tone];
  const label = { danger: "Alerte", warn: "Attention", info: "Information", ok: "Confirmé" }[tone];
  return (
    <div className={`alerte a-${tone}`} role={tone === "danger" ? "alert" : "status"}>
      <span className="ico" aria-hidden>{ico}</span>
      <div>
        <strong>{title ?? label}</strong>
        {children}
      </div>
    </div>
  );
}

export function Card({ title, num, right, children, flush }: { title?: ReactNode; num?: string; right?: ReactNode; children: ReactNode; flush?: boolean }) {
  return (
    <section className="carte">
      {title !== undefined && (
        <header className="carte-entete">
          {num && <span className="num">{num}</span>}
          <h2>{title}</h2>
          {right && <div className="droite">{right}</div>}
        </header>
      )}
      <div className={`carte-corps${flush ? " sans-marge" : ""}`}>{children}</div>
    </section>
  );
}

export function PageTitle({ over, title, actions, children }: { over?: string; title: string; actions?: ReactNode; children?: ReactNode }) {
  return (
    <>
      <div className="titre-page">
        <div>
          {over && <div className="surtitre">{over}</div>}
          <h1>{title}</h1>
        </div>
        {actions && <div className="actions">{actions}</div>}
      </div>
      <div className="filet" />
      {children}
    </>
  );
}

export function Flow({ steps, current, done }: { steps: [string, string][]; current?: string; done?: string[] }) {
  const idx = steps.findIndex(([c]) => c === current);
  return (
    <div className="flux" aria-label="Cycle de vie">
      {steps.map(([code, label], i) => (
        <span key={code} style={{ display: "contents" }}>
          {i > 0 && <i aria-hidden>→</i>}
          <span className={code === current ? "courant" : (done?.includes(code) || (idx >= 0 && i < idx)) ? "fait" : ""}>{label}</span>
        </span>
      ))}
    </div>
  );
}

export function Loading() {
  return <div className="chargement">Chargement des données…</div>;
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="vide">{children}</div>;
}

export function ErrorBox({ error }: { error: unknown }) {
  if (!error) return null;
  const e = error as ApiError;
  const tone = e.status === 403 ? "danger" : e.status === 409 ? "warn" : "danger";
  const title = e.status === 403 ? "Action refusée" : e.status === 409 ? "Opération impossible en l'état" : e.status === 422 ? "Données invalides" : "Erreur";
  const errs = (e.details?.errors as { loc: string[]; msg: string }[] | undefined) ?? [];
  return (
    <Alert tone={tone} title={title}>
      <div>{e.message}</div>
      {errs.length > 0 && <ul className="petit">{errs.map((x, i) => <li key={i}>{x.loc.slice(1).join(" › ")} : {x.msg}</li>)}</ul>}
      {e.requestId && <div className="petit muted">Identifiant de requête : <span className="mono">{e.requestId}</span></div>}
    </Alert>
  );
}

export function useApi<T = any>(path: string | null, params?: Record<string, any>) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const key = path ? path + JSON.stringify(params ?? {}) : null;
  const reload = useCallback(async () => {
    if (!path) return;
    setLoading(true);
    try {
      setData(await apiGet<T>(path, params));
      setError(null);
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  useEffect(() => { reload(); }, [reload]);
  return { data, error, loading, reload, setData };
}

/** Bouton d'action métier : affiche l'erreur serveur (refus, conflit de version…) sous le bouton. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [ok, setOk] = useState<string | null>(null);
  const run = async (fn: () => Promise<unknown>, success?: string) => {
    setBusy(true);
    setError(null);
    setOk(null);
    try {
      await fn();
      if (success) setOk(success);
      return true;
    } catch (e) {
      setError(e);
      return false;
    } finally {
      setBusy(false);
    }
  };
  const feedback = (
    <>
      <ErrorBox error={error} />
      {ok && <Alert tone="ok" title="Enregistré">{ok}</Alert>}
    </>
  );
  return { busy, error, run, feedback, setError };
}

export function Pager({ page, total, pageSize, onPage }: { page: number; total: number; pageSize: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (pages <= 1) return <div className="petit muted" style={{ padding: "8px 12px" }}>{total} enregistrement(s)</div>;
  return (
    <div className="barre-outils petit" style={{ padding: "8px 12px", margin: 0 }}>
      <button className="btn sec petit" disabled={page <= 1} onClick={() => onPage(page - 1)}>← Précédent</button>
      <span>Page {page} / {pages} — {total} enregistrement(s)</span>
      <button className="btn sec petit" disabled={page >= pages} onClick={() => onPage(page + 1)}>Suivant →</button>
    </div>
  );
}

export function Field({ label, children, help }: { label: string; children: ReactNode; help?: string }) {
  return (
    <div className="champ">
      <label>{label}</label>
      {children}
      {help && <div className="aide">{help}</div>}
    </div>
  );
}

export function RefLink({ href, children }: { href: string; children: ReactNode }) {
  return <Link href={href} className="mono">{children}</Link>;
}
