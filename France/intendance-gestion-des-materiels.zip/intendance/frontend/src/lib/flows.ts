// Parcours métier affichés (les transitions sont validées côté serveur).
export const RECEIPT_FLOW: [string, string][] = [["DRAFT", "Brouillon"], ["SUBMITTED", "Soumise"], ["RECEIVED", "Reçue physiquement"],
  ["IN_INSPECTION", "Contrôlée"], ["PARTIALLY_ACCEPTED", "Acceptée (partiellement / totalement)"], ["CLOSED", "Clôturée"]];
export const REQUEST_FLOW: [string, string][] = [["SUBMITTED", "Demande"], ["REVIEWED", "Revue"], ["APPROVED", "Approbation"], ["RESERVED", "Réservation"],
  ["IN_PREPARATION", "Préparation"], ["PARTIALLY_ISSUED", "Remise"], ["CLOSED", "Clôture"]];
export const TRANSFER_FLOW: [string, string][] = [["REQUESTED", "Demandé"], ["APPROVED", "Approuvé"], ["RESERVED", "Réservé"],
  ["IN_TRANSIT", "Expédié · en transit"], ["RECEIVED", "Réceptionné"], ["RECONCILED", "Rapproché"]];
export const MAINTENANCE_FLOW: [string, string][] = [["SIGNALED", "Signalé"], ["ASSESSED", "Évalué"], ["PLANNED", "Planifié"], ["IN_PROGRESS", "En intervention"],
  ["TO_INSPECT", "À contrôler"], ["CLOSED", "Clôturé"]];

/** Ramène les statuts équivalents sur l'étape affichée. */
export function flowStep(status: string): string {
  const map: Record<string, string> = { ACCEPTED: "PARTIALLY_ACCEPTED", REJECTED: "PARTIALLY_ACCEPTED", ISSUED: "PARTIALLY_ISSUED", CANCELLED: "CLOSED" };
  return map[status] ?? status;
}
