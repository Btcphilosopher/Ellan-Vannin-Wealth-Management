// Libellés français et tonalités des statuts (la couleur accompagne toujours un texte).
export type Tone = "ok" | "info" | "warn" | "danger" | "neutre";

const S: Record<string, [string, Tone]> = {
  // réceptions
  DRAFT: ["Brouillon", "neutre"], SUBMITTED: ["Soumise", "info"], RECEIVED: ["Reçue physiquement", "warn"],
  IN_INSPECTION: ["Contrôle en cours", "warn"], ACCEPTED: ["Acceptée", "ok"], PARTIALLY_ACCEPTED: ["Acceptée partiellement", "warn"],
  REJECTED: ["Rejetée", "danger"], CLOSED: ["Clôturée", "neutre"], CANCELLED: ["Annulée", "neutre"],
  // demandes
  REVIEWED: ["Revue", "info"], APPROVED: ["Approuvée", "info"], RESERVED: ["Réservée", "info"], IN_PREPARATION: ["En préparation", "info"],
  PARTIALLY_ISSUED: ["Remise partielle", "warn"], ISSUED: ["Remise", "ok"],
  // transferts
  REQUESTED: ["Demandé", "info"], IN_TRANSIT: ["En transit", "warn"], RECONCILED: ["Rapproché", "ok"],
  // maintenance
  SIGNALED: ["Signalé", "danger"], ASSESSED: ["Évalué", "warn"], PLANNED: ["Planifié", "info"], IN_PROGRESS: ["En intervention", "warn"],
  TO_INSPECT: ["À contrôler", "warn"],
  // inventaires
  COUNTING: ["Comptage en cours", "warn"], REVIEW: ["Écarts à décider", "warn"], TO_COUNT: ["À compter", "neutre"], MATCHED: ["Conforme", "ok"],
  RECOUNT_REQUIRED: ["Recomptage requis", "warn"], VARIANCE_CONFIRMED: ["Écart confirmé", "danger"], ADJUSTED: ["Ajusté", "ok"],
  // stock / exemplaires
  USABLE: ["Utilisable", "ok"], PENDING_INSPECTION: ["Non contrôlé", "warn"], QUARANTINE: ["Quarantaine", "danger"], MAINTENANCE: ["En maintenance", "warn"],
  IN_STOCK: ["En stock", "ok"], MISSING: ["Manquant", "danger"], CONDEMNED: ["Réformé", "neutre"],
  AWAITING_INSPECTION: ["En attente de contrôle", "warn"], SERVICEABLE: ["Apte", "ok"], UNSERVICEABLE: ["Inapte", "danger"], IN_MAINTENANCE: ["En maintenance", "warn"],
  // jobs / contrôles
  PENDING: ["En attente", "info"], RUNNING: ["En cours", "info"], DONE: ["Terminé", "ok"], FAILED: ["Échec", "danger"],
  PASS: ["Conforme", "ok"], FAIL: ["Non conforme", "danger"], PARTIAL: ["Partiel", "warn"],
  SUCCESS: ["Réussi", "ok"], DENIED: ["Refusé (accès)", "danger"], REFUSED: ["Refusé (règle)", "warn"],
  CRITIQUE: ["Critique", "danger"], HAUTE: ["Haute", "warn"], NORMALE: ["Normale", "info"],
  LOAN: ["Prêt", "info"], ALLOCATION: ["Dotation", "neutre"],
  GOOD: ["Bon état", "ok"], DAMAGED: ["Endommagé", "danger"], INCOMPLETE: ["Incomplet", "warn"],
  RETURN_TO_SERVICE: ["Remise à disposition", "ok"], KEEP_UNSERVICEABLE: ["Maintien inapte", "warn"], CONDEMN: ["Réforme", "neutre"],
};

export function statusLabel(code?: string | null): string {
  if (!code) return "—";
  return S[code]?.[0] ?? code;
}

export function statusTone(code?: string | null): Tone {
  if (!code) return "neutre";
  return S[code]?.[1] ?? "neutre";
}

export const MOVEMENT_LABELS: Record<string, string> = {
  RECEIPT: "Réception", PUTAWAY: "Mise en emplacement", RELOCATION: "Déplacement", STATUS_CHANGE: "Changement de statut",
  QUARANTINE: "Quarantaine", RESERVE: "Réservation", UNRESERVE: "Libération", ISSUE: "Remise", RETURN: "Retour",
  TRANSFER_OUT: "Expédition", TRANSFER_IN: "Réception transfert", CONSUMPTION: "Consommation", CONDEMNATION: "Réforme",
  ADJUSTMENT: "Ajustement", LOSS: "Perte", CORRECTION: "Correction liée",
};

export const TRACKING_LABELS: Record<string, string> = { QUANTITY: "Quantité", LOT: "Lot", SERIAL: "Numéro de série" };
export const INSPECTION_LABELS: Record<string, string> = { VISUAL: "Visuel et quantitatif", FUNCTIONAL: "Essai de fonctionnement", TECHNICAL: "Contrôle technique" };
export const PHASE_LABELS: Record<string, string> = {
  RECEPTION: "Réception", CONTROLE: "Contrôle", EMPLACEMENT: "Emplacement", AFFECTATION: "Affectation", RETOUR: "Retour",
  MAINTENANCE: "Maintenance", ETAT: "État",
};

export const ROLE_LABELS: Record<string, string> = {
  VIEWER: "Consultation", STOREKEEPER: "Magasinier", DEPOT_MANAGER: "Responsable de dépôt", MAINTENANCE: "Maintenance",
  APPROVER: "Approbateur", AUDITOR: "Auditeur", ADMIN: "Administrateur",
};

export function fmtQty(v?: number | null, unit?: string): string {
  if (v === null || v === undefined) return "—";
  const s = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 3 }).format(v);
  return unit ? `${s} ${unit}` : s;
}

export function fmtDate(v?: string | null, withTime = true): string {
  if (!v) return "—";
  const d = new Date(v.length === 10 ? `${v}T00:00:00` : v);
  if (Number.isNaN(d.getTime())) return v;
  return new Intl.DateTimeFormat("fr-FR", withTime && v.length > 10
    ? { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Paris" }
    : { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "Europe/Paris" }).format(d);
}

export function fmtMoney(v?: number | null): string {
  if (v === null || v === undefined) return "—";
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(v);
}
