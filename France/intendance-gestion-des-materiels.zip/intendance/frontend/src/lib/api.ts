// Client d'API : même origine (/v1 réécrit vers FastAPI), cookie de session HttpOnly + jeton CSRF,
// clé d'idempotence générée pour chaque soumission de formulaire.

export class ApiError extends Error {
  status: number;
  code: string;
  details: Record<string, unknown>;
  requestId?: string;
  constructor(status: number, code: string, message: string, details: Record<string, unknown> = {}, requestId?: string) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
    this.requestId = requestId;
  }
}

function csrfToken(): string {
  if (typeof document === "undefined") return "";
  const m = document.cookie.match(/(?:^|;\s*)intendance_csrf=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : "";
}

export function newIdempotencyKey(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

type Params = Record<string, string | number | boolean | null | undefined>;

function withParams(path: string, params?: Params): string {
  if (!params) return path;
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
  const s = q.toString();
  return s ? `${path}?${s}` : path;
}

async function handle<T>(res: Response): Promise<T> {
  if (res.status === 401 && typeof window !== "undefined" && !location.pathname.startsWith("/connexion")) {
    const body = await res.json().catch(() => ({}));
    if (body.code !== "mfa_invalide" && body.code !== "identifiants_invalides") {
      location.href = `/connexion?retour=${encodeURIComponent(location.pathname + location.search)}`;
    }
    throw new ApiError(401, body.code ?? "non_authentifie", body.message ?? "Authentification requise.");
  }
  const ct = res.headers.get("content-type") ?? "";
  const body = ct.includes("application/json") ? await res.json() : await res.text();
  if (!res.ok) {
    const b = typeof body === "object" && body ? (body as Record<string, unknown>) : {};
    throw new ApiError(res.status, String(b.code ?? "erreur"), String(b.message ?? res.statusText), (b.details as Record<string, unknown>) ?? {},
      b.request_id as string | undefined);
  }
  return body as T;
}

export async function apiGet<T = any>(path: string, params?: Params): Promise<T> {
  const res = await fetch(withParams(path, params), { credentials: "same-origin", headers: { Accept: "application/json" }, cache: "no-store" });
  return handle<T>(res);
}

export async function apiSend<T = any>(method: "POST" | "PATCH" | "DELETE", path: string, body?: unknown, idemKey?: string): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json", "X-CSRF-Token": csrfToken() };
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (method === "POST") headers["Idempotency-Key"] = idemKey ?? newIdempotencyKey();
  const res = await fetch(path, { method, credentials: "same-origin", headers, body: body === undefined ? undefined : JSON.stringify(body) });
  return handle<T>(res);
}

export const apiPost = <T = any>(path: string, body?: unknown, idemKey?: string) => apiSend<T>("POST", path, body ?? {}, idemKey);

export async function apiUpload<T = any>(path: string, form: FormData): Promise<T> {
  const res = await fetch(path, {
    method: "POST", credentials: "same-origin", body: form,
    headers: { "X-CSRF-Token": csrfToken(), "Idempotency-Key": newIdempotencyKey(), Accept: "application/json" },
  });
  return handle<T>(res);
}

export function downloadUrl(path: string, params?: Params) {
  return withParams(path, params);
}
