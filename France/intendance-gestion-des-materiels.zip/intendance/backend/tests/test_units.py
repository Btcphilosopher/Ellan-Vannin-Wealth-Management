"""Tests unitaires : conversions d'unités, TOTP, Code 128, expurgation, numéros de série, PDF."""
from decimal import Decimal
from types import SimpleNamespace

import pytest

from app.core.errors import ValidationFailed
from app.core.logging import redact
from app.core.pdf import render_pdf
from app.core.security import TOTPAdapter, hash_password, verify_password
from app.db import SessionLocal
from app.modules.catalog.models import Item
from app.modules.inventory.service import normalize_serial, to_base_quantity
from app.modules.scan.barcode import PATTERNS, encode_b, svg


@pytest.fixture()
def ctx(ids):
    db = SessionLocal()
    yield SimpleNamespace(db=db)
    db.rollback()
    db.close()


def _item(db, code):
    from sqlalchemy import select

    return db.execute(select(Item).where(Item.code == code)).scalar_one()


def test_conversion_carton_vers_piece(ctx):
    item = _item(ctx.db, "HAB-VPL-01")
    assert to_base_quantity(ctx, item, 3, "CARTON") == Decimal(60)
    assert to_base_quantity(ctx, item, 7, "PCE") == Decimal(7)


def test_conversion_non_declaree_refusee(ctx):
    item = _item(ctx.db, "HAB-VPL-01")
    with pytest.raises(ValidationFailed) as e:
        to_base_quantity(ctx, item, 2, "L")
    assert e.value.code == "conversion_interdite"
    with pytest.raises(ValidationFailed):
        to_base_quantity(ctx, item, 2, "BIDON")  # conditionnement d'un autre article


def test_fractions_interdites_pour_les_pieces_autorisees_pour_les_litres(ctx):
    with pytest.raises(ValidationFailed):
        to_base_quantity(ctx, _item(ctx.db, "HAB-VPL-01"), Decimal("2.5"), "CARTON")
    with pytest.raises(ValidationFailed):
        to_base_quantity(ctx, _item(ctx.db, "HAB-VPL-01"), Decimal("1.5"), "PCE")
    oil = _item(ctx.db, "FOU-HUI-60")
    assert to_base_quantity(ctx, oil, Decimal("1.5"), "L") == Decimal("1.5")
    assert to_base_quantity(ctx, oil, 2, "BIDON") == Decimal(10)


def test_quantite_nulle_refusee(ctx):
    with pytest.raises(ValidationFailed):
        to_base_quantity(ctx, _item(ctx.db, "HAB-VPL-01"), 0, "PCE")


def test_totp_rfc6238():
    # Vecteur RFC 6238 (SHA-1) : secret ASCII "12345678901234567890", T=59 → 94287082 (8 chiffres) → 287082 sur 6 chiffres
    secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
    assert TOTPAdapter.code_at(secret, 59) == "287082"
    adapter = TOTPAdapter()
    assert adapter.verify(secret, "287082", at=59)
    assert not adapter.verify(secret, "000000", at=59)


def test_mot_de_passe_argon2():
    h = hash_password("Une-phrase-de-passe-longue")
    assert h.startswith("$argon2")
    assert verify_password(h, "Une-phrase-de-passe-longue")
    assert not verify_password(h, "mauvais")
    assert not verify_password(None, "x")


def test_code128_table_et_somme_de_controle():
    assert len(PATTERNS) == 107
    assert all(sum(int(c) for c in p) == 11 for p in PATTERNS[:106])
    assert sum(int(c) for c in PATTERNS[106]) == 13
    codes = encode_b("ITD-A000024")
    assert codes[0] == 104 and codes[-1] == 106
    values = [ord(c) - 32 for c in "ITD-A000024"]
    assert codes[-2] == (104 + sum(i * v for i, v in enumerate(values, 1))) % 103
    assert svg("LOC-DN-A01").startswith("<svg")
    with pytest.raises(ValueError):
        encode_b("GEN-DÉMO")  # caractère hors ASCII : étiquette interne obligatoire


def test_expurgation_des_journaux():
    out = redact({"username": "c.marchand", "password": "secret", "nested": {"token": "abc"}, "msg": "Authorization: Bearer xyz"})
    assert out["password"] == "***" and out["nested"]["token"] == "***"
    assert "xyz" not in out["msg"]
    assert out["username"] == "c.marchand"


def test_normalisation_numero_de_serie():
    assert normalize_serial("GEN-DÉMO-024") == "GENDEMO024"
    assert normalize_serial(" gen demo 024 ") == "GENDEMO024"


def test_pdf_minimal():
    data = render_pdf("Rapport d'essai", ["Ligne é à ç", "Deuxième ligne"] * 60)
    assert data.startswith(b"%PDF-1.4") and data.rstrip().endswith(b"%%EOF")
    assert data.count(b"/Type /Page ") == 3
