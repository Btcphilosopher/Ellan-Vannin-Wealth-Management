"""Rejoue l'intégralité du scénario de démonstration (14 étapes + cas limites) et vérifie les invariants."""
from sqlalchemy import text

from app.db import engine
from tests.conftest import _truncate
from tests.test_stock_concurrency import assert_ledger_matches_balances


def test_scenario_complet(app, migrated):
    from seed import demo

    _truncate()
    demo.LOG.clear()
    out = demo.run(app)
    steps = {e["step"] for e in out["log"]}
    assert {str(n) for n in range(0, 15)} - {"9", "10", "11", "12", "13", "14"} <= steps
    assert {"9", "10", "11", "12", "13", "14"} <= steps
    edge = [e for e in out["log"] if e["step"] == "cas limite"]
    assert len(edge) >= 12
    assert_ledger_matches_balances()
    with engine.connect() as c:
        # aucun exemplaire n'est à deux endroits ; toute position d'exemplaire est cohérente
        assert c.execute(text("SELECT count(*) FROM assets WHERE lifecycle IN ('ISSUED','IN_TRANSIT','MISSING','CONDEMNED') AND location_id IS NOT NULL")).scalar() == 0
        # GEN-DÉMO-024 : apte, en stock, décision attribuée
        row = c.execute(text("SELECT a.technical_state, a.lifecycle, d.decided_by IS NOT NULL FROM assets a JOIN release_decisions d ON d.asset_id = a.id "
                             "WHERE a.serial_number = 'GEN-DÉMO-024'")).one()
        assert row == ("SERVICEABLE", "IN_STOCK", True)
        # refus journalisés (accès et règles)
        denied = c.execute(text("SELECT count(*) FROM audit_events WHERE outcome IN ('DENIED','REFUSED')")).scalar()
        assert denied >= 10
        # 120 reçues, 112 acceptées, 8 rejetées
        tot = c.execute(text("SELECT sum(received_qty), sum(accepted_qty), sum(rejected_qty) FROM receipt_lines rl JOIN items i ON i.id = rl.item_id "
                             "WHERE i.code = 'HAB-VPL-01'")).one()
        assert [float(x) for x in tot] == [120, 112, 8]
