"""Dotations, prêts, retours, transferts, maintenance, inventaires."""
from tests.conftest import stock_row
from tests.test_stock_concurrency import assert_ledger_matches_balances


def _veste(ids, v="M"):
    return {"item_id": ids["item"]["HAB-VPL-01"], "variant_id": ids["var"][f"HAB-VPL-01:{v}"]}


# ----------------------------------------------------------------------------- dotations
def test_reservation_n_est_pas_une_remise_et_remise_partielle(users, ids, stock_in, approved_request):
    stock_in("DN", [{**_veste(ids), "expected_quantity": 30}])
    cm = users("c.marchand")
    d = approved_request([{**_veste(ids), "quantity": 20}])
    d = cm.post(f"/v1/requests/{d['id']}/reservation", {"version": d["version"], "allow_partial": False})
    row = stock_row(cm, ids["depots"]["DN"], ids["item"]["HAB-VPL-01"], "Taille M")
    assert (row["physical"], row["reserved"], row["available"]) == (30, 20, 10)
    # remise impossible avant préparation
    assert cm.raw_post("/v1/allocations", {"request_id": d["id"], "version": d["version"], "recipient_name": "Xavier fictif", "proof_reference": "JR-1",
                                           "lines": [{"request_line_id": d["lines"][0]["id"], "quantity": 5}]}).status_code == 409
    d = cm.post(f"/v1/requests/{d['id']}/preparation", {"version": d["version"]})
    a = cm.post("/v1/allocations", {"request_id": d["id"], "version": d["version"], "recipient_name": "Sgt fictif", "proof_reference": "JR-1",
                                    "lines": [{"request_line_id": d["lines"][0]["id"], "quantity": 12}]})
    assert a["lines"][0]["quantity"] == 12
    row = stock_row(cm, ids["depots"]["DN"], ids["item"]["HAB-VPL-01"], "Taille M")
    assert (row["physical"], row["reserved"], row["available"]) == (18, 8, 10)
    d = cm.get(f"/v1/requests/{d['id']}")
    assert d["status"] == "PARTIALLY_ISSUED"
    # la clôture libère le reliquat réservé
    d = users("r.garnier").post(f"/v1/requests/{d['id']}/close", {"version": d["version"], "reason": "Reliquat abandonné"})
    row = stock_row(cm, ids["depots"]["DN"], ids["item"]["HAB-VPL-01"], "Taille M")
    assert (row["physical"], row["reserved"], row["available"]) == (18, 0, 18)
    assert_ledger_matches_balances()


def test_approbateur_distinct_et_remise_sans_reservation(users, ids, stock_in):
    stock_in("DN", [{**_veste(ids), "expected_quantity": 5}])
    # l'approbatrice ne peut approuver sa propre demande : elle n'a pas le rôle de création — on vérifie le rôle
    cm = users("c.marchand")
    d = cm.post("/v1/requests", {"depot_id": ids["depots"]["DN"], "beneficiary_org_id": ids["org"]["UIB"], "responsible_name": "Resp. fictif",
                                 "administrative_destination": "Destination fictive", "lines": [{**_veste(ids), "quantity": 2}]})
    assert cm.raw_post(f"/v1/requests/{d['id']}/approval", {"version": d["version"], "decision": "APPROVE", "comment": "auto"}).status_code == 403
    # approbation avant revue refusée (transition métier)
    assert users("a.lefevre").raw_post(f"/v1/requests/{d['id']}/approval", {"version": d["version"], "decision": "APPROVE", "comment": "trop tôt"}).status_code == 409


def test_pret_prolongation_retour_bloque(users, ids, stock_in, approved_request, clock):
    stock_in("DN", [{"item_id": ids["item"]["COM-RAD-50"], "expected_quantity": 1, "serials": ["RAD-T1"]}], location="A-02")
    cm, rg, al = users("c.marchand"), users("r.garnier"), users("a.lefevre")
    d = approved_request([{"item_id": ids["item"]["COM-RAD-50"], "quantity": 1, "kind": "LOAN", "due_date": "2026-12-10"}])
    d = cm.post(f"/v1/requests/{d['id']}/reservation", {"version": d["version"]})
    d = cm.post(f"/v1/requests/{d['id']}/preparation", {"version": d["version"]})
    a = cm.post("/v1/allocations", {"request_id": d["id"], "version": d["version"], "recipient_name": "Cpl fictif", "proof_reference": "JR-9",
                                    "lines": [{"request_line_id": d["lines"][0]["id"], "quantity": 1}]})
    ln = a["lines"][0]
    asset = cm.get(f"/v1/assets/{ln['asset']['id']}")
    assert asset["lifecycle"] == "ISSUED" and asset["location"] is None and asset["custody"]["organization"]["code"] == "UIB"
    a = al.post(f"/v1/allocation-lines/{ln['id']}/extension", {"version": ln["version"], "new_due_date": "2026-12-20", "reason": "Exercice prolongé"})
    ln = a["lines"][0]
    assert ln["due_date"] == "2026-12-20" and ln["extensions_count"] == 1
    assert al.raw_post(f"/v1/allocation-lines/{ln['id']}/extension", {"version": ln["version"], "new_due_date": "2027-03-01",
                                                                       "reason": "Trop long"}).status_code == 422
    assert cm.raw_post(f"/v1/allocation-lines/{ln['id']}/consumption", {"version": ln["version"], "quantity": 1, "reason": "x"}).status_code == 422
    clock("2026-12-21T09:00:00+01:00")
    dash = rg.get("/v1/dashboard")
    assert any(x["category"] == "Prêt" and x["severity"] == "CRITIQUE" for x in dash["priority_actions"])
    ret = cm.post("/v1/returns", {"allocation_line_id": ln["id"], "asset_id": ln["asset"]["id"], "condition": "GOOD",
                                  "observed_condition": "RAS", "returned_by_name": "Cpl fictif"})
    assert ret["stock_status"] == "PENDING_INSPECTION"
    asset = cm.get(f"/v1/assets/{ln['asset']['id']}")
    assert asset["technical_state"] == "AWAITING_INSPECTION" and asset["location"]["code"] == "QUAI"
    # un retour n'est pas disponible
    assert stock_row(cm, ids["depots"]["DN"], ids["item"]["COM-RAD-50"])["available"] == 0
    # double retour refusé
    assert cm.raw_post("/v1/returns", {"allocation_line_id": ln["id"], "asset_id": ln["asset"]["id"], "condition": "GOOD",
                                       "observed_condition": "RAS", "returned_by_name": "Cpl fictif"}).status_code == 422
    assert_ledger_matches_balances()


# ----------------------------------------------------------------------------- transferts
def test_transfert_transit_ecart_et_permissions(users, ids, stock_in):
    stock_in("DN", [{**_veste(ids, "L"), "expected_quantity": 40}])
    rg, al, cm, lp, sb = users("r.garnier"), users("a.lefevre"), users("c.marchand"), users("l.perrin"), users("s.benali")
    t = rg.post("/v1/transfers", {"source_depot_id": ids["depots"]["DN"], "destination_depot_id": ids["depots"]["DS"], "reason": "Rééquilibrage",
                                  "lines": [{**_veste(ids, "L"), "quantity": 25}]})
    assert lp.raw_post(f"/v1/transfers/{t['id']}/approval", {"version": t["version"], "decision": "APPROVE", "comment": "pas habilitée"}).status_code == 403
    t = al.post(f"/v1/transfers/{t['id']}/approval", {"version": t["version"], "decision": "APPROVE", "comment": "Validé"})
    t = cm.post(f"/v1/transfers/{t['id']}/reservation", {"version": t["version"]})
    t = cm.post(f"/v1/transfers/{t['id']}/dispatch", {"version": t["version"], "carrier": "Transports fictifs", "waybill_ref": "LV-1"})
    dn = stock_row(rg, ids["depots"]["DN"], ids["item"]["HAB-VPL-01"], "Taille L")
    ds = stock_row(sb, ids["depots"]["DS"], ids["item"]["HAB-VPL-01"], "Taille L")
    assert dn["physical"] == 15 and ds["physical"] == 0 and ds["in_transit"] == 25 and ds["available"] == 0
    # réception par le dépôt expéditeur interdite
    assert cm.raw_post(f"/v1/transfers/{t['id']}/receipt", {"version": t["version"], "lines": [
        {"line_id": t["lines"][0]["id"], "received_qty": 25}]}).status_code == 403
    assert lp.raw_post(f"/v1/transfers/{t['id']}/receipt", {"version": t["version"], "lines": [
        {"line_id": t["lines"][0]["id"], "received_qty": 25, "damaged_qty": 1}]}).status_code == 422
    t = lp.post(f"/v1/transfers/{t['id']}/receipt", {"version": t["version"], "lines": [
        {"line_id": t["lines"][0]["id"], "received_qty": 21, "damaged_qty": 1, "note": "3 manquantes"}]})
    ln = t["lines"][0]
    assert (ln["shipped_qty"], ln["received_qty"], ln["damaged_qty"], ln["discrepancy_qty"]) == (25, 21, 1, 3)
    ds = stock_row(sb, ids["depots"]["DS"], ids["item"]["HAB-VPL-01"], "Taille L")
    assert ds["available"] == 21 and ds["blocked"] == 1 and ds["in_transit"] == 0
    # perte : approbateur requis ; une partie est retrouvée
    assert sb.raw_post(f"/v1/transfers/{t['id']}/reconciliation", {"version": t["version"], "lines": [
        {"line_id": ln["id"], "action": "WRITE_OFF", "quantity": 3, "justification": "Perte en transport"}]}).status_code == 403
    t = lp.post(f"/v1/transfers/{t['id']}/reconciliation", {"version": t["version"], "lines": [
        {"line_id": ln["id"], "action": "FOUND", "quantity": 1, "justification": "Retrouvée dans un autre colis"}]})
    assert t["status"] == "RECEIVED" and t["lines"][0]["discrepancy_qty"] == 2
    t = al.post(f"/v1/transfers/{t['id']}/reconciliation", {"version": t["version"], "lines": [
        {"line_id": ln["id"], "action": "WRITE_OFF", "quantity": 2, "justification": "Perte en transport déclarée"}]})
    assert t["status"] == "RECONCILED" and t["lines"][0]["written_off_qty"] == 2
    assert_ledger_matches_balances()


# ----------------------------------------------------------------------------- maintenance
def test_cloture_ne_vaut_pas_aptitude(users, ids, stock_in):
    stock_in("DN", [{"item_id": ids["item"]["GEN-5KVA-30"], "expected_quantity": 1, "serials": ["GEN-T-1"]},
                    {"item_id": ids["item"]["PDR-FIL-70"], "expected_quantity": 5}], location="B-01")
    cm, mr, rg = users("c.marchand"), users("m.roux"), users("r.garnier")
    asset = cm.get("/v1/assets", q="GEN-T-1")["items"][0]
    o = cm.post("/v1/maintenance-orders", {"asset_id": asset["id"], "defect_description": "Bruit anormal au démarrage", "priority": "HIGH"})
    assert cm.get(f"/v1/assets/{asset['id']}")["stock_status"] == "QUARANTINE"
    assert cm.raw_post(f"/v1/maintenance-orders/{o['id']}/assessment", {"version": o["version"], "diagnosis": "pas habilité"}).status_code == 403
    o = mr.post(f"/v1/maintenance-orders/{o['id']}/assessment", {"version": o["version"], "diagnosis": "Filtre colmaté", "estimated_cost": 50})
    o = mr.post(f"/v1/maintenance-orders/{o['id']}/planning", {"version": o["version"], "planned_start": "2026-11-28", "technician_name": "Tech fictif",
                                                               "provider_id": ids["org"]["AEM"]})
    o = mr.post(f"/v1/maintenance-orders/{o['id']}/start", {"version": o["version"]})
    assert cm.get(f"/v1/assets/{asset['id']}")["location"]["code"] == "ATEL"
    assert mr.raw_post(f"/v1/maintenance-orders/{o['id']}/completion", {"version": o["version"], "work_result": "Sans temps saisi"}).status_code == 422
    mr.post(f"/v1/maintenance-orders/{o['id']}/labour", {"technician_name": "Tech fictif", "hours": 2, "cost": 120})
    o = mr.post(f"/v1/maintenance-orders/{o['id']}/parts", {"item_id": ids["item"]["PDR-FIL-70"], "location_id": ids["loc"]["DN:B-01"], "quantity": 1})
    assert o["costs"]["total"] == 138
    o = mr.post(f"/v1/maintenance-orders/{o['id']}/completion", {"version": o["version"], "work_result": "Filtre remplacé"})
    assert mr.raw_post(f"/v1/maintenance-orders/{o['id']}/closure", {"version": o["version"]}).json()["code"] == "controle_manquant"
    fail = mr.post("/v1/inspections/asset", {"asset_id": asset["id"], "kind": "PRE_RELEASE", "result": "FAIL", "maintenance_order_id": o["id"],
                                             "findings": "Essai en charge non conforme"})
    o = mr.post(f"/v1/maintenance-orders/{o['id']}/closure", {"version": o["version"]})
    a = rg.get(f"/v1/assets/{asset['id']}")
    assert o["status"] == "CLOSED" and a["technical_state"] == "AWAITING_INSPECTION" and a["stock_status"] == "MAINTENANCE"
    assert stock_row(rg, ids["depots"]["DN"], ids["item"]["GEN-5KVA-30"])["available"] == 0
    r = rg.raw_post(f"/v1/assets/{asset['id']}/release-decision", {"version": a["version"], "decision": "RETURN_TO_SERVICE", "inspection_id": fail["id"],
                                                                    "reason": "Tentative", "to_location_id": ids["loc"]["DN:B-01"]})
    assert r.status_code == 409 and r.json()["code"] == "controle_non_conforme"


def test_decision_remise_a_disposition_attribuee(users, ids, stock_in):
    stock_in("DN", [{"item_id": ids["item"]["COM-RAD-50"], "expected_quantity": 1, "serials": ["RAD-M1"]}], location="A-02")
    cm, mr, rg = users("c.marchand"), users("m.roux"), users("r.garnier")
    asset = cm.get("/v1/assets", q="RAD-M1")["items"][0]
    o = cm.post("/v1/maintenance-orders", {"asset_id": asset["id"], "defect_description": "Antenne endommagée"})
    for step, body in [("assessment", {"diagnosis": "Antenne à remplacer"}), ("planning", {"planned_start": "2026-11-28", "technician_name": "Tech fictif"}),
                       ("start", {})]:
        o = mr.post(f"/v1/maintenance-orders/{o['id']}/{step}", {"version": o["version"], **body})
    mr.post(f"/v1/maintenance-orders/{o['id']}/labour", {"technician_name": "Tech fictif", "hours": 1, "cost": 60})
    o = mr.post(f"/v1/maintenance-orders/{o['id']}/completion", {"version": o["version"], "work_result": "Antenne remplacée"})
    ok = mr.post("/v1/inspections/asset", {"asset_id": asset["id"], "kind": "PRE_RELEASE", "result": "PASS", "maintenance_order_id": o["id"],
                                           "findings": "Essai sur banc conforme"})
    o = mr.post(f"/v1/maintenance-orders/{o['id']}/closure", {"version": o["version"]})
    a = rg.get(f"/v1/assets/{asset['id']}")
    d = rg.post(f"/v1/assets/{asset['id']}/release-decision", {"version": a["version"], "decision": "RETURN_TO_SERVICE", "inspection_id": ok["id"],
                                                                "reason": "Contrôle conforme", "to_location_id": ids["loc"]["DN:A-02"]})
    assert d["asset"]["technical_state"] == "SERVICEABLE" and d["asset"]["stock_status"] == "USABLE"
    hist = rg.get(f"/v1/assets/{asset['id']}/history")
    phases = [e["phase"] for e in hist["events"]]
    assert phases[0] == "RECEPTION" and "MAINTENANCE" in phases and phases[-1] == "ETAT"
    assert "apte" in hist["explanation"]
    assert_ledger_matches_balances()


# ----------------------------------------------------------------------------- inventaires
def test_inventaire_aveugle_recomptage_mouvement_pendant_comptage(users, ids, stock_in, clock):
    stock_in("DN", [{"item_id": ids["item"]["MOB-TAB-20"], "expected_quantity": 30}, {**_veste(ids), "expected_quantity": 10}])
    cm, rg, al = users("c.marchand"), users("r.garnier"), users("a.lefevre")
    clock("2026-11-28T08:00:00+01:00")
    st = rg.post("/v1/stocktakes", {"depot_id": ids["depots"]["DN"], "name": "Test A-01", "location_ids": [ids["loc"]["DN:A-01"]]})
    st = rg.post(f"/v1/stocktakes/{st['id']}/start", {"version": st["version"]})
    view = cm.get(f"/v1/stocktakes/{st['id']}")
    assert view["expected_visible"] is False and all(ln["snapshot_qty"] is None for ln in view["lines"])
    clock("2026-11-28T08:30:00+01:00")
    cm.post("/v1/stock/relocations", {"from_location_id": ids["loc"]["DN:A-01"], "to_location_id": ids["loc"]["DN:B-01"],
                                      "item_id": ids["item"]["MOB-TAB-20"], "quantity": 4, "reason": "Besoin salle"})
    clock("2026-11-28T09:00:00+01:00")
    lines = {ln["item_code"]: ln for ln in view["lines"]}
    st = cm.post(f"/v1/stocktakes/{st['id']}/counts", {"lines": [
        {"line_id": lines["MOB-TAB-20"]["id"], "counted_qty": 26},  # 30 − 4 déplacées : aucun écart
        {"line_id": lines["HAB-VPL-01"]["id"], "counted_qty": 9}]})
    by = {ln["item_code"]: ln for ln in st["lines"]}
    assert by["MOB-TAB-20"]["status"] == "MATCHED"
    assert by["HAB-VPL-01"]["status"] == "RECOUNT_REQUIRED"
    # le premier comptage n'a rien modifié
    assert stock_row(cm, ids["depots"]["DN"], ids["item"]["HAB-VPL-01"], "Taille M")["physical"] == 10
    assert rg.raw_post(f"/v1/stocktakes/{st['id']}/review", {"version": rg.get(f"/v1/stocktakes/{st['id']}")["version"]}).status_code == 409
    st = cm.post(f"/v1/stocktakes/{st['id']}/counts", {"lines": [{"line_id": lines["HAB-VPL-01"]["id"], "counted_qty": 9}]})
    st = rg.post(f"/v1/stocktakes/{st['id']}/review", {"version": rg.get(f"/v1/stocktakes/{st['id']}")["version"]})
    line = next(ln for ln in st["lines"] if ln["item_code"] == "HAB-VPL-01")
    assert line["status"] == "VARIANCE_CONFIRMED" and line["variance_qty"] == -1
    # le compteur ne peut approuver ; justification obligatoire
    assert rg.raw_post(f"/v1/stocktakes/{st['id']}/adjustments", {"version": st["version"], "decisions": [
        {"line_id": line["id"], "approve": True, "justification": "court"}]}).status_code == 422
    st = rg.post(f"/v1/stocktakes/{st['id']}/adjustments", {"version": st["version"], "decisions": [
        {"line_id": line["id"], "approve": True, "justification": "Écart confirmé par deux comptages"}]})
    assert stock_row(cm, ids["depots"]["DN"], ids["item"]["HAB-VPL-01"], "Taille M")["physical"] == 9
    st = rg.post(f"/v1/stocktakes/{st['id']}/close", {"version": st["version"]})
    assert st["status"] == "CLOSED"
    assert_ledger_matches_balances()


def test_ajustement_important_exige_approbateur_distinct(users, ids, stock_in):
    stock_in("DN", [{"item_id": ids["item"]["MOB-TAB-20"], "expected_quantity": 30}])
    rg, al = users("r.garnier"), users("a.lefevre")
    st = rg.post("/v1/stocktakes", {"depot_id": ids["depots"]["DN"], "name": "Test", "location_ids": [ids["loc"]["DN:A-01"]]})
    st = rg.post(f"/v1/stocktakes/{st['id']}/start", {"version": st["version"]})
    ln = st["lines"][0]
    rg.post(f"/v1/stocktakes/{st['id']}/counts", {"lines": [{"line_id": ln["id"], "counted_qty": 20}]})
    st = rg.post(f"/v1/stocktakes/{st['id']}/counts", {"lines": [{"line_id": ln["id"], "counted_qty": 20}]})
    st = rg.post(f"/v1/stocktakes/{st['id']}/review", {"version": st["version"]})
    assert st["lines"][0]["requires_approver"] is True
    r = rg.raw_post(f"/v1/stocktakes/{st['id']}/adjustments", {"version": st["version"], "decisions": [
        {"line_id": ln["id"], "approve": True, "justification": "Le responsable a compté lui-même"}]})
    assert r.status_code == 403
    st = al.post(f"/v1/stocktakes/{st['id']}/adjustments", {"version": st["version"], "decisions": [
        {"line_id": ln["id"], "approve": False, "justification": "Recherche complémentaire demandée avant ajustement"}]})
    assert st["lines"][0]["status"] == "REJECTED"
    assert stock_row(rg, ids["depots"]["DN"], ids["item"]["MOB-TAB-20"])["physical"] == 30
