"""Catalogue, réceptions partielles, contrôles, numéros de série."""
from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError

import pytest

from app.db import SessionLocal
from app.modules.inventory.models import Asset
from tests.conftest import stock_row


def test_creation_article_et_regles_catalogue(users, ids):
    rg = users("r.garnier")
    item = rg.post("/v1/items", {"code": "OUT-MAR-12", "designation": "Marteau de coffreur", "family_code": "OUT", "base_unit": "PCE",
                                 "tracking": "QUANTITY", "packagings": [{"unit_code": "CARTON", "label": "Carton de 10", "factor": 10}]}, expect=201)
    assert item["conversions"] == ["1 CARTON = 10 PCE"]
    assert rg.get("/v1/items", q="MAR")["total"] == 1
    # code en double
    r = rg.raw_post("/v1/items", {"code": "OUT-MAR-12", "designation": "Doublon", "family_code": "OUT", "base_unit": "PCE", "tracking": "QUANTITY"})
    assert r.status_code == 409
    # sérialisé hors pièce
    r = rg.raw_post("/v1/items", {"code": "FOU-X-1", "designation": "Incohérent", "family_code": "FOU", "base_unit": "L", "tracking": "SERIAL"})
    assert r.status_code == 422
    # conditionnement d'une autre dimension (kg vers pièces)
    r = rg.raw_post("/v1/items", {"code": "FOU-X-2", "designation": "Incohérent", "family_code": "FOU", "base_unit": "PCE", "tracking": "QUANTITY",
                                  "packagings": [{"unit_code": "KG", "label": "kilo", "factor": 3}]})
    assert r.status_code == 422 and r.json()["code"] == "conversion_interdite"
    # profil consultation
    assert users("v.consult").raw_post("/v1/items", {"code": "OUT-Z-1", "designation": "Zinc", "family_code": "OUT", "base_unit": "PCE",
                                                     "tracking": "QUANTITY"}).status_code == 403


def test_modification_article_versionnee(users, ids):
    rg = users("r.garnier")
    item = rg.get(f"/v1/items/{ids['item']['MOB-TAB-20']}")
    rg.c.patch(f"/v1/items/{item['id']}", json={"version": item["version"], "min_stock": 12}, headers=rg.h)
    r = rg.c.patch(f"/v1/items/{item['id']}", json={"version": item["version"], "min_stock": 14}, headers=rg.h)
    assert r.status_code == 409 and r.json()["code"] == "version_obsolete"


def test_reception_partielle_quantites_distinctes(users, ids):
    cm, rg = users("c.marchand"), users("r.garnier")
    dn, veste = ids["depots"]["DN"], ids["item"]["HAB-VPL-01"]
    r = cm.post("/v1/receipts", {"depot_id": dn, "supplier_id": ids["org"]["TXD"], "supplier_document_ref": "BL-1", "submit": True, "lines": [
        {"item_id": veste, "variant_id": ids["var"]["HAB-VPL-01:M"], "unit": "CARTON", "expected_quantity": 6}]})
    assert r["lines"][0]["expected_qty"] == 120
    # écart sans motif refusé
    bad = cm.raw_post(f"/v1/receipts/{r['id']}/physical-receipt", {"version": r["version"], "lines": [{"line_id": r["lines"][0]["id"], "received_quantity": 5}]})
    assert bad.status_code == 422
    r = cm.post(f"/v1/receipts/{r['id']}/physical-receipt", {"version": r["version"], "lines": [
        {"line_id": r["lines"][0]["id"], "received_quantity": 6}]})
    row = stock_row(cm, dn, veste, "Taille M")
    assert row["physical"] == 120 and row["available"] == 0 and row["blocked"] == 120
    # contrôle partiel en deux temps
    r = rg.post(f"/v1/receipts/{r['id']}/inspection", {"version": r["version"], "lines": [{"line_id": r["lines"][0]["id"], "accepted_qty": 70, "rejected_qty": 5}]})
    ln = r["lines"][0]
    assert (ln["received_qty"], ln["accepted_qty"], ln["rejected_qty"], ln["pending_qty"]) == (120, 70, 5, 45)
    assert r["status"] == "IN_INSPECTION"
    assert rg.raw_post(f"/v1/receipts/{r['id']}/close", {"version": r["version"]}).status_code == 409
    over = cm.raw_post(f"/v1/receipts/{r['id']}/putaway", {"version": r["version"], "lines": [
        {"line_id": ln["id"], "location_id": ids["loc"]["DN:A-01"], "quantity": 71}]})
    assert over.status_code == 422
    row = stock_row(cm, dn, veste, "Taille M")
    assert row["available"] == 70 and row["blocked"] == 50
    r = rg.post(f"/v1/receipts/{r['id']}/inspection", {"version": r["version"], "lines": [{"line_id": ln["id"], "accepted_qty": 42, "rejected_qty": 3}]})
    assert r["status"] == "PARTIALLY_ACCEPTED" and r["totals"]["pending_qty"] == 0
    r = rg.post(f"/v1/receipts/{r['id']}/close", {"version": r["version"]})
    assert r["status"] == "CLOSED"


def test_controle_par_le_receptionnaire_refuse(users, ids):
    cm = users("c.marchand")
    r = cm.post("/v1/receipts", {"depot_id": ids["depots"]["DN"], "supplier_id": ids["org"]["EQO"], "supplier_document_ref": "BL-2", "submit": True,
                                 "lines": [{"item_id": ids["item"]["PDR-FIL-70"], "expected_quantity": 5}]})
    r = cm.post(f"/v1/receipts/{r['id']}/physical-receipt", {"version": r["version"], "lines": [{"line_id": r["lines"][0]["id"], "received_quantity": 5}]})
    resp = cm.raw_post(f"/v1/receipts/{r['id']}/inspection", {"version": r["version"], "lines": [{"line_id": r["lines"][0]["id"], "accepted_qty": 5}]})
    assert resp.status_code == 403 and resp.json()["code"] == "separation_des_taches"


def test_series_distinctes_et_position_unique(users, ids, stock_in):
    cm = users("c.marchand")
    r = cm.post("/v1/receipts", {"depot_id": ids["depots"]["DN"], "supplier_id": ids["org"]["EQO"], "supplier_document_ref": "BL-3", "submit": True,
                                 "lines": [{"item_id": ids["item"]["COM-RAD-50"], "expected_quantity": 2}]})
    dup = cm.raw_post(f"/v1/receipts/{r['id']}/physical-receipt", {"version": r["version"], "lines": [
        {"line_id": r["lines"][0]["id"], "received_quantity": 2, "serial_numbers": ["RAD-1", "rad 1"]}]})
    assert dup.status_code == 422
    stock_in("DN", [{"item_id": ids["item"]["COM-RAD-50"], "expected_quantity": 2, "serials": ["RAD-X1", "RAD-X2"]}], location="A-02")
    # un même numéro ne peut être réceptionné deux fois
    r2 = cm.post("/v1/receipts", {"depot_id": ids["depots"]["DN"], "supplier_id": ids["org"]["EQO"], "supplier_document_ref": "BL-4", "submit": True,
                                  "lines": [{"item_id": ids["item"]["COM-RAD-50"], "expected_quantity": 1}]})
    again = cm.raw_post(f"/v1/receipts/{r2['id']}/physical-receipt", {"version": r2["version"], "lines": [
        {"line_id": r2["lines"][0]["id"], "received_quantity": 1, "serial_numbers": ["rad-x1"]}]})
    assert again.status_code == 409 and again.json()["code"] == "serie_en_double"
    # contrainte base : un exemplaire remis ne peut conserver un emplacement (une seule position cohérente)
    with SessionLocal() as db:
        asset = db.execute(select(Asset).where(Asset.serial_number == "RAD-X1")).scalar_one()
        with pytest.raises(IntegrityError):
            db.execute(update(Asset).where(Asset.id == asset.id).values(lifecycle="ISSUED"))
            db.flush()
        db.rollback()
    assets = cm.get("/v1/assets", item_id=ids["item"]["COM-RAD-50"])["items"]
    assert {a["technical_state"] for a in assets} == {"SERVICEABLE"} and all(a["location"]["code"] == "A-02" for a in assets)


def test_scan_identifie_sans_prouver(users, ids, stock_in):
    stock_in("DN", [{"item_id": ids["item"]["GEN-5KVA-30"], "expected_quantity": 1, "serials": ["GEN-DÉMO-099"]}], location="B-01")
    cm = users("c.marchand")
    res = cm.get("/v1/scan/gen-demo-099")
    assert res["matches"][0]["kind"] == "ASSET" and "ne prouve" in res["warning"]
    tag = cm.get("/v1/scan/LOC-DN-B01")["matches"][0]
    assert tag["kind"] == "LOCATION"
    assert cm.c.get("/v1/scan/INCONNU-123", headers=cm.h).status_code == 404
    # le Dépôt Sud ne voit pas l'équipement du Dépôt Nord
    assert users("l.perrin").c.get("/v1/scan/gen-demo-099", headers=users("l.perrin").h).status_code == 404
