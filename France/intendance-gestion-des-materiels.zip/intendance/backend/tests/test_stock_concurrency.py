"""Contraintes de stock, journal immuable, corrections liées, concurrence, idempotence."""
import threading

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError, IntegrityError

from app.db import SessionLocal, engine
from tests.conftest import Api, new_key, stock_row


def _vestes(ids, qty=50, variant="M"):
    return [{"item_id": ids["item"]["HAB-VPL-01"], "variant_id": ids["var"][f"HAB-VPL-01:{variant}"], "expected_quantity": qty}]


def test_contraintes_base_disponible_jamais_negatif(users, ids, stock_in):
    stock_in("DN", _vestes(ids, 10))
    with engine.connect() as conn:
        with pytest.raises(IntegrityError):
            conn.execute(text("UPDATE stock_balances SET reserved = quantity + 1 WHERE stock_status = 'USABLE'"))
        conn.rollback()
        with pytest.raises(IntegrityError):
            conn.execute(text("UPDATE stock_balances SET quantity = -1"))
        conn.rollback()
        with pytest.raises(IntegrityError):
            conn.execute(text("UPDATE stock_balances SET reserved = 1 WHERE stock_status <> 'USABLE'"))
        conn.rollback()


def test_journal_non_modifiable(users, ids, stock_in):
    stock_in("DN", _vestes(ids, 10))
    with engine.connect() as conn:
        with pytest.raises(DBAPIError, match="Journal non modifiable"):
            conn.execute(text("UPDATE stock_movements SET quantity = 999"))
        conn.rollback()
        with pytest.raises(DBAPIError, match="Journal non modifiable"):
            conn.execute(text("DELETE FROM audit_events"))
        conn.rollback()
        with pytest.raises(DBAPIError):
            conn.execute(text("TRUNCATE stock_movements CASCADE"))
        conn.rollback()


def test_grand_livre_coherent_avec_les_soldes(users, ids, stock_in, approved_request):
    """Chaque solde est exactement la somme des mouvements du journal (physique et réservé)."""
    stock_in("DN", _vestes(ids, 30))
    d = approved_request([{"item_id": ids["item"]["HAB-VPL-01"], "variant_id": ids["var"]["HAB-VPL-01:M"], "quantity": 12}])
    users("c.marchand").post(f"/v1/requests/{d['id']}/reservation", {"version": d["version"], "allow_partial": False})
    assert_ledger_matches_balances()


def assert_ledger_matches_balances():
    with SessionLocal() as db:
        rows = db.execute(text("""
            WITH flows AS (
              SELECT to_location_id AS loc, item_id, variant_id, lot_id, to_status AS st, quantity AS q, 0::numeric AS r
                FROM stock_movements WHERE to_location_id IS NOT NULL AND movement_type NOT IN ('RESERVE','UNRESERVE')
              UNION ALL
              SELECT from_location_id, item_id, variant_id, lot_id, from_status, -quantity, reserved_delta
                FROM stock_movements WHERE from_location_id IS NOT NULL AND movement_type NOT IN ('RESERVE','UNRESERVE')
              UNION ALL
              SELECT from_location_id, item_id, variant_id, lot_id, from_status, 0, reserved_delta
                FROM stock_movements WHERE movement_type IN ('RESERVE','UNRESERVE'))
            SELECT b.bucket_key, b.quantity, b.reserved, COALESCE(SUM(f.q),0) AS lq, COALESCE(SUM(f.r),0) AS lr
              FROM stock_balances b LEFT JOIN flows f ON f.loc = b.location_id AND f.item_id = b.item_id
               AND f.variant_id IS NOT DISTINCT FROM b.variant_id AND f.lot_id IS NOT DISTINCT FROM b.lot_id AND f.st = b.stock_status
             GROUP BY b.bucket_key, b.quantity, b.reserved""")).all()
        assert rows
        for key, q, r, lq, lr in rows:
            assert q == lq, f"physique {key}: solde {q} ≠ journal {lq}"
            assert r == lr, f"réservé {key}: solde {r} ≠ journal {lr}"
        # exemplaires sérialisés : un exemplaire = une unité dans le solde de sa position
        mismatches = db.execute(text("""
            SELECT b.bucket_key FROM stock_balances b JOIN items i ON i.id = b.item_id AND i.tracking = 'SERIAL'
             WHERE b.quantity <> (SELECT count(*) FROM assets a WHERE a.location_id = b.location_id AND a.item_id = b.item_id
                                  AND a.stock_status = b.stock_status)""")).all()
        assert not mismatches


def test_correction_par_mouvements_lies(users, ids, stock_in):
    r = stock_in("DN", _vestes(ids, 20), location="A-02")
    rg = users("r.garnier")
    mv = rg.get("/v1/movements", source_id=r["id"], type="PUTAWAY")["items"][0]
    out = rg.post(f"/v1/movements/{mv['id']}/correction", {"reason": "Mauvais emplacement saisi", "corrected_to_location_id": ids["loc"]["DN:A-01"]})
    assert len(out["corrections"]) == 2 and all(c["corrects_movement_id"] == mv["id"] for c in out["corrections"])
    assert out["original"]["to_location"] == "A-02" and out["original"]["quantity"] == 20  # original intact
    assert rg.raw_post(f"/v1/movements/{mv['id']}/correction", {"reason": "Seconde correction"}).status_code == 409
    pos = {p["location"]["code"]: p["quantity"] for p in rg.get("/v1/stock/positions", depot_id=ids["depots"]["DN"])}
    assert pos == {"A-01": 20}
    assert users("c.marchand").raw_post(f"/v1/movements/{mv['id']}/correction", {"reason": "Pas habilité"}).status_code == 403
    assert_ledger_matches_balances()


def test_reservations_simultanees_sans_double_allocation(app, users, ids, stock_in, approved_request):
    stock_in("DN", _vestes(ids, 50))
    reqs = [approved_request([{"item_id": ids["item"]["HAB-VPL-01"], "variant_id": ids["var"]["HAB-VPL-01:M"], "quantity": 20}]) for _ in range(4)]
    clients = [Api(app, "c.marchand") for _ in reqs]
    codes = []
    barrier = threading.Barrier(len(reqs))

    def go(api, d):
        barrier.wait()
        codes.append(api.raw_post(f"/v1/requests/{d['id']}/reservation", {"version": d["version"], "allow_partial": False}).status_code)

    threads = [threading.Thread(target=go, args=(c, d)) for c, d in zip(clients, reqs)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert sorted(codes) == [200, 200, 409, 409]
    row = stock_row(users("c.marchand"), ids["depots"]["DN"], ids["item"]["HAB-VPL-01"], "Taille M")
    assert row["reserved"] == 40 and row["available"] == 10 and row["physical"] == 50
    assert_ledger_matches_balances()


def test_reservations_simultanees_exemplaires(app, users, ids, stock_in, approved_request):
    stock_in("DN", [{"item_id": ids["item"]["GEN-5KVA-30"], "expected_quantity": 3, "serials": ["G-1", "G-2", "G-3"]}], location="B-01")
    reqs = [approved_request([{"item_id": ids["item"]["GEN-5KVA-30"], "quantity": 2, "kind": "LOAN", "due_date": "2027-01-15"}]) for _ in range(3)]
    clients = [Api(app, "c.marchand") for _ in reqs]
    results = []
    barrier = threading.Barrier(3)

    def go(api, d):
        barrier.wait()
        results.append(api.raw_post(f"/v1/requests/{d['id']}/reservation", {"version": d["version"], "allow_partial": True}).status_code)

    threads = [threading.Thread(target=go, args=(c, d)) for c, d in zip(clients, reqs)]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assets = users("c.marchand").get("/v1/assets", item_id=ids["item"]["GEN-5KVA-30"])["items"]
    assert sum(1 for a in assets if a["lifecycle"] == "RESERVED") == 3  # jamais plus que le parc
    total = sum(sum(ln["reserved_open_qty"] for ln in users("c.marchand").get(f"/v1/requests/{d['id']}")["lines"]) for d in reqs)
    assert total == 3
    assert_ledger_matches_balances()


def test_requete_dupliquee_rejouee(users, ids):
    cm = users("c.marchand")
    body = {"depot_id": ids["depots"]["DN"], "beneficiary_org_id": ids["org"]["UIB"], "responsible_name": "Resp. fictif", "administrative_destination": "Destination fictive",
            "lines": [{"item_id": ids["item"]["MOB-TAB-20"], "quantity": 2}]}
    key = new_key()
    a = cm.raw_post("/v1/requests", body, headers={"Idempotency-Key": key})
    b = cm.raw_post("/v1/requests", body, headers={"Idempotency-Key": key})
    assert a.status_code == b.status_code == 201
    assert b.headers.get("idempotent-replayed") == "true" and a.json()["reference"] == b.json()["reference"]
    c = cm.raw_post("/v1/requests", {**body, "responsible_name": "Autre responsable"}, headers={"Idempotency-Key": key})
    assert c.status_code == 422
    assert cm.get("/v1/requests")["total"] == 1


def test_requetes_dupliquees_simultanees(app, users, ids):
    body = {"depot_id": ids["depots"]["DN"], "beneficiary_org_id": ids["org"]["UIB"], "responsible_name": "Resp. fictif", "administrative_destination": "Destination fictive",
            "lines": [{"item_id": ids["item"]["MOB-TAB-20"], "quantity": 2}]}
    key = new_key()
    clients = [Api(app, "c.marchand") for _ in range(5)]
    barrier = threading.Barrier(5)
    codes = []

    def go(api):
        barrier.wait()
        codes.append(api.raw_post("/v1/requests", body, headers={"Idempotency-Key": key}).status_code)

    threads = [threading.Thread(target=go, args=(c,)) for c in clients]
    [t.start() for t in threads]
    [t.join() for t in threads]
    assert set(codes) <= {201, 409} and 201 in codes
    assert users("c.marchand").get("/v1/requests")["total"] == 1


def test_version_obsolete(users, ids, approved_request, stock_in):
    stock_in("DN", _vestes(ids, 5))
    d = approved_request([{"item_id": ids["item"]["HAB-VPL-01"], "variant_id": ids["var"]["HAB-VPL-01:M"], "quantity": 2}])
    r = users("c.marchand").raw_post(f"/v1/requests/{d['id']}/reservation", {"version": d["version"] + 7})
    assert r.status_code == 409 and r.json()["details"]["current_version"] == d["version"]
