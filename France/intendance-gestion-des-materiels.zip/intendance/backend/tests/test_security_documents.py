"""Permissions, sessions, MFA, CSRF, audit, documents, rapports, tableau de bord."""
from fastapi.testclient import TestClient

from app.core.security import TOTPAdapter
from app.jobs import run_pending
from seed.bootstrap import ADMIN_TOTP_SECRET, DEMO_PASSWORD


def test_perimetre_par_depot(users, ids, stock_in):
    stock_in("DN", [{"item_id": ids["item"]["MOB-TAB-20"], "expected_quantity": 3}])
    vc, lp = users("v.consult"), users("l.perrin")
    assert vc.c.get(f"/v1/stock?depot_id={ids['depots']['DS']}", headers=vc.h).status_code == 403
    assert len(vc.get("/v1/depots")) == 1
    assert lp.get("/v1/stock", depot_id=ids["depots"]["DS"])["total"] == 0
    assert lp.raw_post("/v1/receipts", {"depot_id": ids["depots"]["DN"], "supplier_id": ids["org"]["EQO"], "supplier_document_ref": "BL-X",
                                        "lines": [{"item_id": ids["item"]["MOB-TAB-20"], "expected_quantity": 1}]}).status_code == 403


def test_refus_journalises_avec_identifiant_de_requete(users, ids):
    vc = users("v.consult")
    r = vc.c.get("/v1/audit-events", headers={**vc.h, "X-Request-ID": "test-req-000123"})
    assert r.status_code == 403 and r.headers["x-request-id"] == "test-req-000123"
    ev = users("j.morel").get("/v1/audit-events", outcome="DENIED", request_id="test-req-000123")["items"]
    assert ev and ev[0]["actor_name"] == "Victor Consult" and ev[0]["action"] == "access.denied"
    # l'auditeur lit, mais ne modifie rien
    assert users("j.morel").raw_post("/v1/items", {"code": "XX-1", "designation": "Essai", "family_code": "OUT", "base_unit": "PCE",
                                                   "tracking": "QUANTITY"}).status_code == 403


def test_session_cookie_csrf_et_deconnexion(app, ids):
    c = TestClient(app)
    r = c.post("/v1/auth/login", json={"username": "c.marchand", "password": DEMO_PASSWORD})
    assert r.status_code == 200
    set_cookie = r.headers.get_list("set-cookie") if hasattr(r.headers, "get_list") else r.headers.get("set-cookie")
    assert "httponly" in str(set_cookie).lower() and "samesite=strict" in str(set_cookie).lower()
    csrf = c.cookies.get("intendance_csrf")
    assert c.get("/v1/auth/me").status_code == 200
    body = {"depot_id": ids["depots"]["DN"], "beneficiary_org_id": ids["org"]["UIB"], "responsible_name": "Resp. fictif", "administrative_destination": "Destination fictive",
            "lines": [{"item_id": ids["item"]["MOB-TAB-20"], "quantity": 1}]}
    assert c.post("/v1/requests", json=body).status_code == 403  # sans jeton CSRF
    assert c.post("/v1/requests", json=body, headers={"X-CSRF-Token": csrf}).status_code == 201
    assert c.post("/v1/auth/logout", headers={"X-CSRF-Token": csrf}).status_code == 200
    c.cookies.clear()
    assert c.get("/v1/auth/me").status_code == 401


def test_mfa_obligatoire_pour_l_administrateur(app, ids):
    c = TestClient(app)
    r = c.post("/v1/auth/login", json={"username": "admin", "password": DEMO_PASSWORD})
    assert r.json()["mfa_required"] is True
    h = {"Authorization": f"Bearer {r.json()['token']}"}
    assert c.get("/v1/admin/users", headers=h).status_code == 401
    assert c.post("/v1/auth/mfa", json={"code": "000000"}, headers=h).status_code == 401
    assert c.post("/v1/auth/mfa", json={"code": TOTPAdapter.code_at(ADMIN_TOTP_SECRET)}, headers=h).status_code == 200
    assert c.get("/v1/admin/users", headers=h).status_code == 200


def test_verrouillage_et_authentification_organisationnelle(app, ids):
    c = TestClient(app)
    for _ in range(5):
        assert c.post("/v1/auth/login", json={"username": "j.morel", "password": "faux"}).status_code == 401
    r = c.post("/v1/auth/login", json={"username": "j.morel", "password": DEMO_PASSWORD})
    assert r.status_code == 401 and r.json()["code"] == "compte_verrouille"
    r = c.post("/v1/auth/login", json={"username": "e.partenaire", "password": DEMO_PASSWORD})
    assert r.status_code == 403 and r.json()["code"] == "authentification_organisationnelle"


def test_administrateur_n_approuve_pas(users, ids, approved_request):
    admin = users("admin")
    d = users("c.marchand").post("/v1/requests", {"depot_id": ids["depots"]["DN"], "beneficiary_org_id": ids["org"]["UIB"], "responsible_name": "Resp. fictif",
                                                  "administrative_destination": "Destination fictive", "lines": [{"item_id": ids["item"]["MOB-TAB-20"], "quantity": 1}]})
    assert admin.raw_post(f"/v1/requests/{d['id']}/review", {"version": d["version"], "comment": "admin"}).status_code == 403
    r = admin.raw_post(f"/v1/admin/users/{ids['users']['admin']}/memberships", {"organization_id": ids["org"]["GSFA"], "role_code": "APPROVER"})
    assert r.status_code == 409


def test_documents_versions_types_et_acces(users, ids, stock_in):
    r = stock_in("DN", [{"item_id": ids["item"]["MOB-TAB-20"], "expected_quantity": 2}])
    cm = users("c.marchand")
    pdf = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF"
    up = cm.c.post("/v1/documents", headers=cm.h, data={"owner_type": "RECEIPT", "owner_id": r["id"], "kind": "RECEIPT_NOTE", "title": "Bon de réception"},
                   files={"file": ("bon.pdf", pdf, "application/pdf")})
    assert up.status_code == 201, up.text
    doc = up.json()
    assert doc["current_version"] == 1 and doc["versions"][0]["sha256"]
    bad = cm.c.post("/v1/documents", headers=cm.h, data={"owner_type": "RECEIPT", "owner_id": r["id"], "kind": "RECEIPT_NOTE", "title": "Exe"},
                    files={"file": ("x.pdf", b"MZ\x90\x00\x03\x00\x00\x00binaire", "application/pdf")})
    assert bad.status_code == 422 and bad.json()["code"] == "type_fichier_refuse"
    v2 = cm.c.post(f"/v1/documents/{doc['id']}/versions", headers=cm.h, data={"version": doc["version"], "comment": "Version signée"},
                   files={"file": ("bon-signe.pdf", pdf + b"\n%signed", "application/pdf")})
    assert v2.status_code == 201 and v2.json()["current_version"] == 2
    dl = cm.c.get(f"/v1/documents/{doc['id']}/versions/2/content", headers=cm.h)
    assert dl.status_code == 200 and dl.headers["content-disposition"].startswith("attachment") and dl.content.endswith(b"%signed")
    # le Dépôt Sud n'accède pas au document du Dépôt Nord
    lp = users("l.perrin")
    assert lp.c.get(f"/v1/documents/{doc['id']}", headers=lp.h).status_code == 403
    # document restreint : la consultation ne le voit pas
    rs = cm.c.post("/v1/documents", headers=cm.h, data={"owner_type": "RECEIPT", "owner_id": r["id"], "kind": "INSPECTION_REPORT", "title": "PV",
                                                        "access_level": "RESTRICTED"}, files={"file": ("pv.txt", "Constat fictif".encode(), "text/plain")})
    assert rs.status_code == 201
    vc = users("v.consult")
    assert vc.c.get(f"/v1/documents/{rs.json()['id']}", headers=vc.h).status_code == 403
    assert users("r.garnier").c.get(f"/v1/documents/{rs.json()['id']}", headers=users("r.garnier").h).status_code == 200


def test_rapports_et_export_en_arriere_plan(users, ids, stock_in):
    stock_in("DN", [{"item_id": ids["item"]["MOB-TAB-20"], "expected_quantity": 7}])
    rg = users("r.garnier")
    csv = rg.c.get("/v1/reports/stock/download?format=csv", headers=rg.h)
    assert csv.status_code == 200 and "MOB-TAB-20" in csv.content.decode("utf-8-sig")
    job = rg.post("/v1/reports/exports", {"kind": "movements", "format": "pdf"})
    assert rg.get(f"/v1/reports/exports/{job['job_id']}")["status"] == "PENDING"
    assert run_pending() >= 1
    st = rg.get(f"/v1/reports/exports/{job['job_id']}")
    assert st["status"] == "DONE"
    doc = rg.get(f"/v1/documents/{st['result']['document_id']}")
    assert doc["kind"] == "REPORT_EXPORT"
    assert users("c.marchand").c.get("/v1/reports/stock/download", headers=users("c.marchand").h).status_code == 403
    assert rg.c.get("/v1/reports/audit/download", headers=rg.h).status_code == 403


def test_tableau_de_bord_issu_de_la_base(users, ids, stock_in):
    rg = users("r.garnier")
    before = rg.get("/v1/dashboard")
    stock_in("DN", [{"item_id": ids["item"]["MOB-TAB-20"], "expected_quantity": 7}])
    after = rg.get("/v1/dashboard")
    assert after["kpis"]["items"]["value"] == 12
    assert after["stock_state"]["totals"]["physical"] == before["stock_state"]["totals"]["physical"] + 7
    assert after["recent_movements"][0]["item"]["code"] == "MOB-TAB-20"
    assert after["clock"]["mode"] == "fixed"
