"""Configuration des tests : base PostgreSQL dédiée, schéma migré par Alembic, référentiel fictif réinitialisé par test."""
from __future__ import annotations

import os
import tempfile
import uuid

os.environ.setdefault("INTENDANCE_DATABASE_URL", "postgresql+psycopg://intendance:intendance@localhost:5432/intendance_test")
os.environ.setdefault("INTENDANCE_ENVIRONMENT", "test")
os.environ.setdefault("INTENDANCE_STORAGE_LOCAL_PATH", tempfile.mkdtemp(prefix="intendance-objects-"))
os.environ.setdefault("INTENDANCE_LOG_LEVEL", "WARNING")

import pytest  # noqa: E402
from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import text  # noqa: E402

from app.core.security import TOTPAdapter  # noqa: E402
from app.db import Base, SessionLocal, engine  # noqa: E402
from seed.bootstrap import ADMIN_TOTP_SECRET, DEMO_PASSWORD, bootstrap  # noqa: E402

KEEP = {"roles", "units", "alembic_version"}


@pytest.fixture(scope="session", autouse=True)
def migrated():
    cfg = Config(os.path.join(os.path.dirname(__file__), "..", "alembic.ini"))
    cfg.set_main_option("script_location", os.path.join(os.path.dirname(__file__), "..", "alembic"))
    command.downgrade(cfg, "base")
    command.upgrade(cfg, "head")
    yield


def _truncate():
    tables = [t.name for t in Base.metadata.sorted_tables if t.name not in KEEP]
    with engine.begin() as conn:
        conn.execute(text("SET LOCAL intendance.allow_journal_maintenance = 'on'"))
        conn.execute(text(f"TRUNCATE {', '.join(tables)} RESTART IDENTITY CASCADE"))


@pytest.fixture()
def ids(migrated):
    _truncate()
    with SessionLocal() as db:
        out = bootstrap(db)
    return {
        "depots": {k: str(v) for k, v in out["depots"].items()},
        "loc": {k: str(v) for k, v in out["locations"].items()},
        "item": {k: str(v) for k, v in out["items"].items()},
        "var": {k: str(v) for k, v in out["variants"].items()},
        "org": {k: str(v) for k, v in out["orgs"].items()},
        "users": {k: str(v) for k, v in out["users"].items()},
    }


@pytest.fixture(scope="session")
def app():
    from app.main import app as fastapi_app

    return fastapi_app


class Api:
    def __init__(self, app, username: str, password: str = DEMO_PASSWORD):
        self.username = username
        self.c = TestClient(app)
        r = self.c.post("/v1/auth/login", json={"username": username, "password": password})
        assert r.status_code == 200, r.text
        self.token = r.json()["token"]
        self.h = {"Authorization": f"Bearer {self.token}"}
        if r.json()["mfa_required"]:
            assert self.c.post("/v1/auth/mfa", json={"code": TOTPAdapter.code_at(ADMIN_TOTP_SECRET)}, headers=self.h).status_code == 200

    def get(self, path, expect=200, **params):
        r = self.c.get(path, params=params, headers=self.h)
        assert r.status_code == expect, f"GET {path} → {r.status_code} {r.text}"
        return r.json()

    def post(self, path, body=None, expect=(200, 201, 202), idem=None):
        headers = dict(self.h)
        if idem:
            headers["Idempotency-Key"] = idem
        r = self.c.post(path, json=body or {}, headers=headers)
        expected = expect if isinstance(expect, tuple) else (expect,)
        assert r.status_code in expected, f"POST {path} ({self.username}) → {r.status_code} {r.text}"
        return r.json()

    def raw_post(self, path, body=None, headers=None):
        return self.c.post(path, json=body or {}, headers={**self.h, **(headers or {})})


@pytest.fixture()
def users(app, ids):
    cache: dict = {}

    def get(name: str) -> Api:
        if name not in cache:
            cache[name] = Api(app, name)
        return cache[name]

    return get


@pytest.fixture()
def clock(users):
    def set_(at: str):
        users("admin").post("/v1/admin/clock", {"at": at, "reason": "Horloge de test"})

    return set_


@pytest.fixture()
def stock_in(users, ids):
    """Fait entrer du stock contrôlé et rangé (réception → contrôle → mise en stock) par l'API."""

    def run(depot="DN", lines=(), location="A-01", inspect_override=None):
        dep = ids["depots"][depot]
        receiver = users("c.marchand" if depot == "DN" else "l.perrin")
        inspector = users("r.garnier" if depot == "DN" else "s.benali")
        payload = []
        for ln in lines:
            payload.append({k: v for k, v in ln.items() if k in ("item_id", "variant_id", "unit", "expected_quantity", "lot_number")})
        r = receiver.post("/v1/receipts", {"depot_id": dep, "supplier_id": ids["org"]["EQO"], "supplier_document_ref": "BL-TEST-01",
                                           "lines": payload, "submit": True})
        phys = [{"line_id": rl["id"], "received_quantity": ln.get("received", ln["expected_quantity"]), "serial_numbers": ln.get("serials", []),
                 "lot_number": ln.get("lot_number"), "discrepancy_note": ln.get("discrepancy", "")} for rl, ln in zip(r["lines"], lines)]
        r = receiver.post(f"/v1/receipts/{r['id']}/physical-receipt", {"version": r["version"], "lines": phys})
        il = inspect_override(r) if inspect_override else [
            {"line_id": x["id"], "accepted_qty": x["received_qty"], "rejected_qty": 0} for x in r["lines"]]
        r = inspector.post(f"/v1/receipts/{r['id']}/inspection", {"version": r["version"], "lines": il})
        pa = [{"line_id": x["id"], "location_id": ids["loc"][f"{depot}:{location}"], "quantity": x["accepted_qty"]} for x in r["lines"] if x["accepted_qty"]]
        if pa:
            r = receiver.post(f"/v1/receipts/{r['id']}/putaway", {"version": r["version"], "lines": pa})
        return r

    return run


@pytest.fixture()
def approved_request(users, ids):
    def run(lines, depot="DN", beneficiary="UIB"):
        creator = users("c.marchand" if depot == "DN" else "l.perrin")
        manager = users("r.garnier" if depot == "DN" else "s.benali")
        d = creator.post("/v1/requests", {"depot_id": ids["depots"][depot], "beneficiary_org_id": ids["org"][beneficiary],
                                          "responsible_name": "Responsable fictif", "administrative_destination": "Destination fictive",
                                          "lines": lines})
        d = manager.post(f"/v1/requests/{d['id']}/review", {"version": d["version"], "comment": "Revue de test"})
        return users("a.lefevre").post(f"/v1/requests/{d['id']}/approval", {"version": d["version"], "decision": "APPROVE", "comment": "Approuvé (test)"})

    return run


def stock_row(api, depot_id, item_id, variant_label=None):
    rows = api.get("/v1/stock", depot_id=depot_id, item_id=item_id)["items"]
    if variant_label is not None:
        rows = [r for r in rows if r["variant_label"] == variant_label]
    assert len(rows) <= 1
    return rows[0] if rows else {"physical": 0, "reserved": 0, "available": 0, "blocked": 0, "in_transit": 0}


def new_key() -> str:
    return uuid.uuid4().hex
