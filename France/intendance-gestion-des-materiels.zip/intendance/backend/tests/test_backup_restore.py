"""Sauvegarde et restauration testées : pg_dump → base neuve → pg_restore → comparaison et invariants."""
import glob
import os
import shutil
import subprocess
import tempfile

import pytest
from sqlalchemy import create_engine, text

from app.db import engine

TABLES = ["items", "assets", "stock_balances", "stock_movements", "audit_events", "receipts", "transfers", "documents"]


def _pg_url(url) -> str:
    return url.set(drivername="postgresql").render_as_string(hide_password=False)


def _tool(name: str) -> str | None:
    """Binaire PostgreSQL : PG_BIN, puis /usr/lib/postgresql/<version>/bin, puis PATH."""
    candidates = [os.path.join(os.environ.get("PG_BIN", ""), name)] if os.environ.get("PG_BIN") else []
    candidates += sorted(glob.glob(f"/usr/lib/postgresql/*/bin/{name}"), reverse=True)
    for c in candidates:
        if os.access(c, os.X_OK):
            return c
    return shutil.which(name)


@pytest.mark.skipif(not _tool("pg_dump") or not _tool("pg_restore"), reason="outils PostgreSQL absents")
def test_sauvegarde_puis_restauration(users, ids, stock_in):
    stock_in("DN", [{"item_id": ids["item"]["MOB-TAB-20"], "expected_quantity": 12},
                    {"item_id": ids["item"]["GEN-5KVA-30"], "expected_quantity": 1, "serials": ["GEN-B-1"]}])
    src = engine.url
    target_name = f"{src.database}_restore"
    with tempfile.TemporaryDirectory() as tmp:
        dump = os.path.join(tmp, "intendance.dump")
        subprocess.run([_tool("pg_dump"), "-Fc", "--no-owner", "-f", dump, _pg_url(engine.url)], check=True)
        admin = create_engine(src.set(database="postgres"), isolation_level="AUTOCOMMIT")
        with admin.connect() as c:
            c.execute(text(f'DROP DATABASE IF EXISTS "{target_name}"'))
            c.execute(text(f'CREATE DATABASE "{target_name}"'))
        target_url = src.set(database=target_name)
        subprocess.run([_tool("pg_restore"), "--no-owner", "--exit-on-error", "-d", _pg_url(target_url), dump], check=True)
        restored = create_engine(target_url)
        try:
            with engine.connect() as a, restored.connect() as b:
                for t in TABLES:
                    assert a.execute(text(f"SELECT count(*) FROM {t}")).scalar() == b.execute(text(f"SELECT count(*) FROM {t}")).scalar(), t
                q = "SELECT coalesce(sum(quantity),0), coalesce(sum(reserved),0) FROM stock_balances"
                assert a.execute(text(q)).one() == b.execute(text(q)).one()
                # le journal reste non modifiable après restauration (déclencheurs restaurés)
                with pytest.raises(Exception, match="Journal non modifiable"):
                    b.execute(text("UPDATE stock_movements SET reason = 'altéré'"))
        finally:
            restored.dispose()
            with admin.connect() as c:
                c.execute(text(f'DROP DATABASE IF EXISTS "{target_name}"'))
            admin.dispose()
