"""Journal immuable et données de référence

Les tables stock_movements et audit_events refusent UPDATE et DELETE pour les
opérations ordinaires. Une purge d'archivage exceptionnelle exige qu'un
administrateur de base de données positionne explicitement
SET LOCAL intendance.allow_journal_maintenance = 'on' dans sa transaction.

Revision ID: 0002
Revises: 0001
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

FUNCTION = """
CREATE OR REPLACE FUNCTION intendance_forbid_mutation() RETURNS trigger AS $$
BEGIN
    IF current_setting('intendance.allow_journal_maintenance', true) = 'on' THEN
        RETURN COALESCE(NEW, OLD);
    END IF;
    RAISE EXCEPTION 'Journal non modifiable : % sur % refusé (utiliser un mouvement de correction lié)',
        TG_OP, TG_TABLE_NAME USING ERRCODE = 'check_violation';
END;
$$ LANGUAGE plpgsql;
"""

ROLES = [
    ("VIEWER", "Consultation", "Lecture seule dans son périmètre."),
    ("STOREKEEPER", "Magasinier", "Réceptions, mises en emplacement, préparations, remises, retours, comptages."),
    ("DEPOT_MANAGER", "Responsable de dépôt", "Pilotage du dépôt, revues, corrections, décisions de remise à disposition."),
    ("MAINTENANCE", "Maintenance", "Ordres de travail, contrôles techniques."),
    ("APPROVER", "Approbateur", "Approbation des demandes, transferts, ajustements importants."),
    ("AUDITOR", "Auditeur", "Lecture du journal d'audit et des rapports."),
    ("ADMIN", "Administrateur", "Administration des utilisateurs, rôles et paramètres."),
]

UNITS = [
    ("PCE", "Pièce", "COUNT", False),
    ("PAIRE", "Paire", "COUNT", False),
    ("JEU", "Jeu", "COUNT", False),
    ("KG", "Kilogramme", "MASS", True),
    ("L", "Litre", "VOLUME", True),
    ("M", "Mètre", "LENGTH", True),
    ("CARTON", "Carton", "PACKAGE", False),
    ("PALETTE", "Palette", "PACKAGE", False),
    ("BIDON", "Bidon", "PACKAGE", False),
    ("SACHET", "Sachet", "PACKAGE", False),
]


def upgrade() -> None:
    op.execute(FUNCTION)
    for table in ("stock_movements", "audit_events"):
        op.execute(
            f"CREATE TRIGGER {table}_immutable BEFORE UPDATE OR DELETE ON {table} "
            f"FOR EACH ROW EXECUTE FUNCTION intendance_forbid_mutation();"
        )
        op.execute(
            f"CREATE TRIGGER {table}_no_truncate BEFORE TRUNCATE ON {table} "
            f"FOR EACH STATEMENT EXECUTE FUNCTION intendance_forbid_mutation();"
        )
    for code, label, desc in ROLES:
        op.execute(
            f"INSERT INTO roles (code, label, description) VALUES ('{code}', '{label}', '{desc.replace(chr(39), chr(39)*2)}')"
        )
    for code, label, dim, dec in UNITS:
        op.execute(
            f"INSERT INTO units (code, label, dimension, decimals_allowed) VALUES ('{code}', '{label}', '{dim}', {str(dec).lower()})"
        )


def downgrade() -> None:
    for table in ("stock_movements", "audit_events"):
        op.execute(f"DROP TRIGGER IF EXISTS {table}_immutable ON {table}")
        op.execute(f"DROP TRIGGER IF EXISTS {table}_no_truncate ON {table}")
    op.execute("DROP FUNCTION IF EXISTS intendance_forbid_mutation()")
    # Les données de référence (rôles, unités) disparaissent avec les tables en 0001.
