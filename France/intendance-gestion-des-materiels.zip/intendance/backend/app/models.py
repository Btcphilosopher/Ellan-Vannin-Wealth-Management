"""Registre de tous les modèles (utilisé par Alembic et par les tests)."""
from app.core.models import IdempotencyRecord, Job  # noqa: F401
from app.modules.audit.models import AuditEvent  # noqa: F401
from app.modules.auth.models import UserSession  # noqa: F401
from app.modules.catalog.models import Item, ItemFamily, ItemPackaging, ItemVariant, Lot, UnitOfMeasure  # noqa: F401
from app.modules.documents.models import Document, DocumentVersion  # noqa: F401
from app.modules.inventory.models import (  # noqa: F401
    Asset,
    Depot,
    Inspection,
    Location,
    Reservation,
    StockBalance,
    StockMovement,
)
from app.modules.maintenance.models import (  # noqa: F401
    MaintenanceLabour,
    MaintenanceOrder,
    MaintenancePart,
    ReleaseDecision,
)
from app.modules.org.models import Membership, Organization, ReferenceCounter, Role, Setting, User  # noqa: F401
from app.modules.receipts.models import Receipt, ReceiptLine  # noqa: F401
from app.modules.requests.models import Allocation, AllocationLine, RequestLine, ReturnRecord, SupplyRequest  # noqa: F401
from app.modules.stocktakes.models import StockCount, Stocktake, StocktakeLine  # noqa: F401
from app.modules.transfers.models import Transfer, TransferLine  # noqa: F401
from app.db import Base  # noqa: F401
