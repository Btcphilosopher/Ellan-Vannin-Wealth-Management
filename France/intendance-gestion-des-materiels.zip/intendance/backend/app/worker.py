"""Processus de traitements en arrière-plan : python -m app.worker"""
from __future__ import annotations

import logging
import signal
import time
from datetime import datetime, timedelta, timezone

from app.config import get_settings
from app.core.logging import configure_logging
from app.db import SessionLocal
from app.jobs import enqueue, run_one

configure_logging(get_settings().log_level)
log = logging.getLogger("intendance.worker")
_running = True


def _stop(*_):
    global _running
    _running = False


def main() -> None:
    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    log.info("Worker démarré")
    next_purge = datetime.now(timezone.utc)
    while _running:
        if datetime.now(timezone.utc) >= next_purge:
            with SessionLocal() as db:
                enqueue(db, "purge", {})
                db.commit()
            next_purge = datetime.now(timezone.utc) + timedelta(hours=1)
        if not run_one():
            time.sleep(2)
    log.info("Worker arrêté")


if __name__ == "__main__":
    main()
