"""INTENDANCE — Gestion des matériels. Application FastAPI (monolithe modulaire).

Concept logiciel indépendant, sans affiliation officielle ni connexion à un système réel.
Prototype non apte au traitement d'informations classifiées.
"""
from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError, IntegrityError
from sqlalchemy.orm.exc import StaleDataError

from app.config import get_settings
from app.core.errors import DomainError, Forbidden
from app.core.logging import configure_logging, request_id_var
from app.core.middleware import IdempotencyMiddleware, RequestIdMiddleware
from app.db import engine
from app.modules.admin.api import router as admin_router
from app.modules.audit.api import router as audit_router
from app.modules.audit.service import audit_out_of_band
from app.modules.auth.api import router as auth_router
from app.modules.catalog.api import router as catalog_router
from app.modules.dashboard.api import router as dashboard_router
from app.modules.documents.api import router as documents_router
from app.modules.inventory.api import router as inventory_router
from app.modules.maintenance.api import router as maintenance_router
from app.modules.receipts.api import router as receipts_router
from app.modules.reports.api import router as reports_router
from app.modules.requests.api import router as requests_router
from app.modules.scan.api import router as scan_router
from app.modules.stocktakes.api import router as stocktakes_router
from app.modules.transfers.api import router as transfers_router

settings = get_settings()
configure_logging(settings.log_level)
log = logging.getLogger("intendance")

DESCRIPTION = """
**INTENDANCE — Gestion des matériels.** Stocks, dépôts, réceptions, dotations, transferts, maintenance.

Concept logiciel indépendant utilisant exclusivement des données fictives ; aucune affiliation officielle,
aucune connexion à des systèmes réels. **Prototype non apte au traitement d'informations classifiées.**

* Authentification : cookie de session (`HttpOnly`, `SameSite=Strict`) + en-tête `X-CSRF-Token`,
  ou `Authorization: Bearer <jeton>` pour les clients d'API.
* Idempotence : en-tête `Idempotency-Key` sur les `POST` (réponse rejouée, `Idempotent-Replayed: true`).
* Concurrence : les actions métier exigent le champ `version` de l'enregistrement (409 si obsolète).
* Pagination : `page`, `page_size` (≤ 200) ; réponse `{items, total, page, page_size}`.
* Erreurs : `{code, message, details, request_id}`.
"""

app = FastAPI(
    title="INTENDANCE — Gestion des matériels",
    version="0.1.0",
    description=DESCRIPTION,
    openapi_url="/v1/openapi.json",
    docs_url="/v1/docs",
    redoc_url="/v1/redoc",
)
app.add_middleware(IdempotencyMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE"],
    allow_headers=["Content-Type", "X-CSRF-Token", "Idempotency-Key", "Authorization", "X-Request-ID"],
)
app.add_middleware(RequestIdMiddleware)


def _error(status: int, code: str, message: str, details: dict | None = None) -> JSONResponse:
    return JSONResponse(
        status_code=status,
        content={"code": code, "message": message, "details": details or {}, "request_id": request_id_var.get()},
    )


@app.exception_handler(DomainError)
async def domain_error_handler(request: Request, exc: DomainError):
    ctx = getattr(request.state, "ctx", None)
    if ctx is not None and ctx.actor_id is not None and exc.status_code in (403, 409):
        # Les refus (accès, séparation des tâches, contrôle manquant, stock insuffisant…) sont journalisés
        # dans une transaction distincte, la transaction métier étant annulée.
        audit_out_of_band(
            ctx, "access.denied" if isinstance(exc, Forbidden) else "rule.refused",
            outcome="DENIED" if isinstance(exc, Forbidden) else "REFUSED", reason=exc.message,
            details={"path": request.url.path, "method": request.method, "code": exc.code, **exc.details},
        )
    return _error(exc.status_code, exc.code, exc.message, exc.details)


@app.exception_handler(StaleDataError)
async def stale_handler(request: Request, exc: StaleDataError):
    return _error(409, "version_obsolete", "L'enregistrement a été modifié simultanément par une autre opération. Rechargez et réessayez.")


@app.exception_handler(IntegrityError)
async def integrity_handler(request: Request, exc: IntegrityError):
    constraint = getattr(getattr(exc.orig, "diag", None), "constraint_name", None)
    log.warning("Contrainte violée : %s", constraint)
    messages = {
        "ck_stock_balances_available_non_negative": "Opération refusée : la quantité disponible deviendrait négative.",
        "ck_stock_balances_quantity_non_negative": "Opération refusée : le stock physique deviendrait négatif.",
        "ck_assets_location_coherence": "Opération refusée : un exemplaire doit avoir une et une seule position cohérente.",
    }
    return _error(409, "contrainte_violee", messages.get(constraint, "Opération refusée par une contrainte d'intégrité."), {"constraint": constraint})


@app.exception_handler(DBAPIError)
async def dbapi_handler(request: Request, exc: DBAPIError):
    sqlstate = getattr(exc.orig, "sqlstate", None)
    if sqlstate in ("40P01", "40001", "55P03"):
        return _error(409, "conflit_concurrent", "Conflit d'accès concurrent : réessayez l'opération.")
    log.exception("Erreur base de données")
    return _error(500, "erreur_interne", "Erreur interne.")


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    errors = [{"loc": list(e.get("loc", [])), "msg": e.get("msg")} for e in exc.errors()]
    return _error(422, "donnees_invalides", "Données invalides.", {"errors": errors})


@app.get("/v1/health", tags=["Système"])
def health():
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))
    return {"status": "ok", "service": "intendance", "classification": "NON CLASSIFIÉ — prototype de démonstration"}


for r in (
    auth_router, dashboard_router, catalog_router, inventory_router, receipts_router, requests_router,
    transfers_router, stocktakes_router, maintenance_router, documents_router, scan_router, reports_router,
    audit_router, admin_router,
):
    app.include_router(r)
