"""Demandes, dotations (remises), prêts et retours."""
from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, Qty, Timestamped, Versioned, uuid_pk


class RequestStatus(StrEnum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"  # demande
    REVIEWED = "REVIEWED"  # revue
    APPROVED = "APPROVED"  # approbation
    REJECTED = "REJECTED"
    RESERVED = "RESERVED"  # réservation (totale ou partielle)
    IN_PREPARATION = "IN_PREPARATION"  # préparation
    PARTIALLY_ISSUED = "PARTIALLY_ISSUED"  # remise partielle
    ISSUED = "ISSUED"  # remise totale
    CLOSED = "CLOSED"  # clôture
    CANCELLED = "CANCELLED"


class LineKind(StrEnum):
    ALLOCATION = "ALLOCATION"  # dotation définitive
    LOAN = "LOAN"  # prêt avec échéance


class SupplyRequest(Base, Timestamped, Versioned):
    __tablename__ = "supply_requests"
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"), index=True)
    beneficiary_org_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    responsible_name: Mapped[str] = mapped_column(String(200))
    administrative_destination: Mapped[str] = mapped_column(String(200))
    justification: Mapped[str] = mapped_column(Text, default="")
    needed_by: Mapped[date | None] = mapped_column(Date)
    status: Mapped[RequestStatus] = mapped_column(String(24), default=RequestStatus.DRAFT, index=True)
    created_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reviewed_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    review_comment: Mapped[str] = mapped_column(Text, default="")
    decided_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    decision_comment: Mapped[str] = mapped_column(Text, default="")
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    lines: Mapped[list["RequestLine"]] = relationship(
        back_populates="request", order_by="RequestLine.line_no", lazy="selectin", cascade="all, delete-orphan"
    )


class RequestLine(Base, Timestamped, Versioned):
    __tablename__ = "request_lines"
    __table_args__ = (
        CheckConstraint("requested_qty > 0", name="requested_positive"),
        CheckConstraint("approved_qty <= requested_qty", name="approved_bounded"),
        CheckConstraint("issued_qty <= approved_qty", name="issued_bounded"),
        CheckConstraint("kind <> 'LOAN' OR due_date IS NOT NULL", name="loan_due_date"),
    )
    id: Mapped[uuid.UUID] = uuid_pk()
    request_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("supply_requests.id", ondelete="CASCADE"))
    line_no: Mapped[int] = mapped_column(Integer)
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"))
    variant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("item_variants.id"))
    kind: Mapped[LineKind] = mapped_column(String(16), default=LineKind.ALLOCATION)
    due_date: Mapped[date | None] = mapped_column(Date)
    requested_qty: Mapped[Decimal] = mapped_column(Qty)
    approved_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    issued_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    request: Mapped[SupplyRequest] = relationship(back_populates="lines")


class Allocation(Base, Timestamped, Versioned):
    """Dotation : remise effective (partielle possible) au bénéficiaire, avec justificatif."""

    __tablename__ = "allocations"
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    request_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("supply_requests.id"), index=True)
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"))
    beneficiary_org_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    recipient_name: Mapped[str] = mapped_column(String(200))
    responsible_name: Mapped[str] = mapped_column(String(200))
    administrative_destination: Mapped[str] = mapped_column(String(200))
    proof_reference: Mapped[str] = mapped_column(String(120))  # n° du justificatif de remise signé
    issued_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    notes: Mapped[str] = mapped_column(Text, default="")
    lines: Mapped[list["AllocationLine"]] = relationship(back_populates="allocation", lazy="selectin")


class AllocationLine(Base, Timestamped, Versioned):
    __tablename__ = "allocation_lines"
    __table_args__ = (
        CheckConstraint("quantity > 0", name="quantity_positive"),
        CheckConstraint("returned_qty + consumed_qty <= quantity", name="settled_bounded"),
        CheckConstraint("extensions_count >= 0", name="extensions"),
    )
    id: Mapped[uuid.UUID] = uuid_pk()
    allocation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("allocations.id"))
    request_line_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("request_lines.id"))
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"))
    variant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("item_variants.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("lots.id"))
    asset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id"), index=True)
    kind: Mapped[LineKind] = mapped_column(String(16))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    returned_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    consumed_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    due_date: Mapped[date | None] = mapped_column(Date)
    extensions_count: Mapped[int] = mapped_column(Integer, default=0)
    extension_history: Mapped[list] = mapped_column(JSONB, default=list)
    allocation: Mapped[Allocation] = relationship(back_populates="lines")

    @property
    def outstanding_qty(self) -> Decimal:
        return self.quantity - self.returned_qty - self.consumed_qty


class ReturnRecord(Base, Timestamped):
    __tablename__ = "returns"
    __table_args__ = (CheckConstraint("quantity > 0", name="quantity_positive"),)
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    allocation_line_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("allocation_lines.id"))
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"))
    asset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id"), index=True)
    quantity: Mapped[Decimal] = mapped_column(Qty)
    condition: Mapped[str] = mapped_column(String(16))  # GOOD | DAMAGED | INCOMPLETE
    observed_condition: Mapped[str] = mapped_column(Text, default="")
    returned_by_name: Mapped[str] = mapped_column(String(200))
    received_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    returned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    maintenance_order_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("maintenance_orders.id"))
