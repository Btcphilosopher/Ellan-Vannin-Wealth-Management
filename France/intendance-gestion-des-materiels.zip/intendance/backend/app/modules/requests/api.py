"""Demandes et dotations : demande → revue → approbation → réservation → préparation → remise → clôture.

Une réservation n'est pas une remise ; une remise n'est pas nécessairement une consommation.
"""
from __future__ import annotations

import uuid
from datetime import date, timedelta
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import select

from app.core.deps import CtxDep, PageDep, paginate
from app.core.errors import Conflict, NotFound, ValidationFailed, expect_status, expect_version
from app.core.refs import next_reference
from app.core.schemas import PositiveQty, StrictModel, VersionedAction, dec
from app.modules.audit.service import audit
from app.modules.catalog.models import Item, ItemVariant, Lot, Tracking
from app.modules.inventory import service as inv
from app.modules.inventory.models import (
    Asset,
    AssetLifecycle,
    CustodyType,
    Depot,
    LocationKind,
    MovementType,
    Reservation,
    ReservationStatus,
    StockStatus,
    TechnicalState,
)
from app.modules.org.models import Organization, OrgKind, User
from app.modules.requests.models import (
    Allocation,
    AllocationLine,
    LineKind,
    RequestLine,
    RequestStatus as S,
    ReturnRecord,
    SupplyRequest,
)

router = APIRouter(prefix="/v1", tags=["Demandes et dotations"])


class RequestLineIn(StrictModel):
    item_id: uuid.UUID
    variant_id: uuid.UUID | None = None
    quantity: PositiveQty
    unit: str | None = None
    kind: Literal["ALLOCATION", "LOAN"] = "ALLOCATION"
    due_date: date | None = None


class RequestIn(StrictModel):
    depot_id: uuid.UUID
    beneficiary_org_id: uuid.UUID
    responsible_name: str = Field(min_length=2, max_length=200)
    administrative_destination: str = Field(min_length=2, max_length=200)
    justification: str = Field(default="", max_length=2000)
    needed_by: date | None = None
    lines: list[RequestLineIn] = Field(min_length=1, max_length=100)
    submit: bool = True


class ReviewIn(VersionedAction):
    comment: str = Field(min_length=3, max_length=2000)


class ApprovalLineIn(StrictModel):
    line_id: uuid.UUID
    approved_qty: Decimal = Field(ge=0)


class ApprovalIn(VersionedAction):
    decision: Literal["APPROVE", "REJECT"]
    comment: str = Field(min_length=3, max_length=2000)
    lines: list[ApprovalLineIn] = Field(default_factory=list)


class ReservationIn(VersionedAction):
    allow_partial: bool = True
    asset_selection: dict[uuid.UUID, list[uuid.UUID]] = Field(
        default_factory=dict, description="Exemplaires précis à réserver, par ligne de demande (articles sérialisés)")


class AllocationLineIn(StrictModel):
    request_line_id: uuid.UUID
    quantity: PositiveQty
    asset_ids: list[uuid.UUID] = Field(default_factory=list)


class AllocationIn(StrictModel):
    request_id: uuid.UUID
    version: int
    recipient_name: str = Field(min_length=2, max_length=200)
    proof_reference: str = Field(min_length=3, max_length=120, description="Référence du justificatif de remise signé")
    notes: str = ""
    lines: list[AllocationLineIn] = Field(min_length=1)


class ExtensionIn(StrictModel):
    version: int
    new_due_date: date
    reason: str = Field(min_length=5, max_length=1000)


class ConsumptionIn(StrictModel):
    version: int
    quantity: PositiveQty
    reason: str = Field(min_length=3, max_length=1000)


class ReturnIn(StrictModel):
    allocation_line_id: uuid.UUID
    quantity: PositiveQty = Decimal(1)
    asset_id: uuid.UUID | None = None
    condition: Literal["GOOD", "DAMAGED", "INCOMPLETE"]
    observed_condition: str = Field(min_length=3, max_length=2000)
    returned_by_name: str = Field(min_length=2, max_length=200)
    report_defect: bool = False
    defect_description: str | None = None


class CloseIn(VersionedAction):
    reason: str = Field(default="", max_length=1000)


# ----------------------------------------------------------------------------- lecture
def _line_reservations(ctx, line_id) -> list[Reservation]:
    return list(ctx.db.execute(
        select(Reservation).where(Reservation.request_line_id == line_id).order_by(Reservation.created_at)
    ).scalars())


def request_dict(ctx, r: SupplyRequest, detailed: bool = True) -> dict:
    depot = ctx.db.get(Depot, r.depot_id)
    org = ctx.db.get(Organization, r.beneficiary_org_id)
    users = {u.id: u.full_name for u in ctx.db.execute(select(User)).scalars()}
    lines = []
    for ln in r.lines:
        item = ctx.db.get(Item, ln.item_id)
        v = ctx.db.get(ItemVariant, ln.variant_id) if ln.variant_id else None
        res = _line_reservations(ctx, ln.id) if detailed else []
        lines.append({
            "id": ln.id, "line_no": ln.line_no, "item_id": item.id, "item_code": item.code, "designation": item.designation,
            "tracking": item.tracking, "base_unit": item.base_unit, "variant_id": ln.variant_id, "variant_label": v.label if v else None,
            "kind": ln.kind, "due_date": ln.due_date, "requested_qty": dec(ln.requested_qty), "approved_qty": dec(ln.approved_qty),
            "reserved_open_qty": dec(sum((x.open_quantity for x in res if x.status == ReservationStatus.ACTIVE), Decimal(0))),
            "issued_qty": dec(ln.issued_qty), "remaining_to_issue": dec(ln.approved_qty - ln.issued_qty), "version": ln.version,
            "reservations": [
                {"id": x.id, "quantity": dec(x.quantity), "consumed": dec(x.consumed), "released": dec(x.released), "status": x.status,
                 "asset_id": x.asset_id, "lot_id": x.lot_id, "location_id": x.location_id}
                for x in res
            ],
        })
    allocs = ctx.db.execute(select(Allocation).where(Allocation.request_id == r.id).order_by(Allocation.issued_at)).scalars().all() if detailed else []
    return {
        "id": r.id, "reference": r.reference, "status": r.status, "version": r.version,
        "depot": {"id": depot.id, "code": depot.code, "name": depot.name},
        "beneficiary": {"id": org.id, "code": org.code, "name": org.name},
        "responsible_name": r.responsible_name, "administrative_destination": r.administrative_destination,
        "justification": r.justification, "needed_by": r.needed_by, "created_by": users.get(r.created_by),
        "created_by_id": r.created_by, "submitted_at": r.submitted_at, "reviewed_by": users.get(r.reviewed_by), "reviewed_at": r.reviewed_at,
        "review_comment": r.review_comment, "decided_by": users.get(r.decided_by), "decided_at": r.decided_at,
        "decision_comment": r.decision_comment, "closed_at": r.closed_at, "lines": lines,
        "allocations": [allocation_dict(ctx, a) for a in allocs],
    }


def allocation_dict(ctx, a: Allocation) -> dict:
    users = {u.id: u.full_name for u in ctx.db.execute(select(User)).scalars()}
    org = ctx.db.get(Organization, a.beneficiary_org_id)
    req = ctx.db.get(SupplyRequest, a.request_id)
    lines = []
    for ln in a.lines:
        item = ctx.db.get(Item, ln.item_id)
        asset = ctx.db.get(Asset, ln.asset_id) if ln.asset_id else None
        lot = ctx.db.get(Lot, ln.lot_id) if ln.lot_id else None
        v = ctx.db.get(ItemVariant, ln.variant_id) if ln.variant_id else None
        overdue = ln.kind == LineKind.LOAN and ln.outstanding_qty > 0 and ln.due_date is not None and ln.due_date < ctx.now.date()
        lines.append({
            "id": ln.id, "item_code": item.code, "designation": item.designation, "variant_label": v.label if v else None,
            "lot_number": lot.lot_number if lot else None,
            "asset": {"id": asset.id, "serial_number": asset.serial_number, "internal_tag": asset.internal_tag} if asset else None,
            "kind": ln.kind, "quantity": dec(ln.quantity), "returned_qty": dec(ln.returned_qty), "consumed_qty": dec(ln.consumed_qty),
            "outstanding_qty": dec(ln.outstanding_qty), "due_date": ln.due_date, "overdue": overdue,
            "extensions_count": ln.extensions_count, "extension_history": ln.extension_history, "version": ln.version,
        })
    return {
        "id": a.id, "reference": a.reference, "request_id": a.request_id, "request_reference": req.reference if req else None,
        "beneficiary": {"id": org.id, "code": org.code, "name": org.name},
        "recipient_name": a.recipient_name, "responsible_name": a.responsible_name, "administrative_destination": a.administrative_destination,
        "proof_reference": a.proof_reference, "issued_by": users.get(a.issued_by), "issued_at": a.issued_at, "notes": a.notes,
        "lines": lines, "version": a.version,
    }


@router.get("/requests")
def list_requests(ctx: CtxDep, page: PageDep, status: str | None = None, depot_id: uuid.UUID | None = None):
    ctx.require("stock.read")
    stmt = select(SupplyRequest).where(SupplyRequest.depot_id.in_(ctx.visible_depot_ids())).order_by(SupplyRequest.created_at.desc())
    if status:
        stmt = stmt.where(SupplyRequest.status.in_(status.split(",")))
    if depot_id:
        stmt = stmt.where(SupplyRequest.depot_id == depot_id)
    return paginate(ctx, stmt, page, lambda r: request_dict(ctx, r, detailed=False))


def load(ctx, request_id) -> SupplyRequest:
    r = ctx.db.execute(
        select(SupplyRequest).where(SupplyRequest.id == request_id).with_for_update().execution_options(populate_existing=True)
    ).scalar_one_or_none()
    if r is None:
        raise NotFound("Demande introuvable.")
    ctx.require("stock.read", r.depot_id)
    return r


@router.get("/requests/{request_id}")
def get_request(ctx: CtxDep, request_id: uuid.UUID):
    return request_dict(ctx, load(ctx, request_id))


# ----------------------------------------------------------------------------- cycle de la demande
@router.post("/requests", status_code=201)
def create_request(ctx: CtxDep, body: RequestIn):
    ctx.require("request.create", body.depot_id)
    org = ctx.db.get(Organization, body.beneficiary_org_id)
    if org is None or org.kind != OrgKind.BENEFICIARY:
        raise ValidationFailed("Organisation bénéficiaire inconnue.")
    r = SupplyRequest(
        id=uuid.uuid4(), reference=next_reference(ctx.db, "request", ctx.now.year), depot_id=body.depot_id, beneficiary_org_id=org.id,
        responsible_name=body.responsible_name, administrative_destination=body.administrative_destination,
        justification=body.justification, needed_by=body.needed_by, created_by=ctx.user_id,
        status=S.SUBMITTED if body.submit else S.DRAFT, submitted_at=ctx.now if body.submit else None,
    )
    ctx.db.add(r)
    for n, ln in enumerate(body.lines, start=1):
        item = ctx.db.get(Item, ln.item_id)
        if item is None or not item.active:
            raise ValidationFailed(f"Ligne {n} : article inconnu ou inactif.")
        if item.variants and not ln.variant_id:
            raise ValidationFailed(f"Ligne {n} : variante obligatoire pour {item.code}.")
        if ln.kind == "LOAN":
            if not item.loanable:
                raise ValidationFailed(f"Ligne {n} : l'article {item.code} n'est pas prêtable.")
            if ln.due_date is None or ln.due_date <= ctx.now.date():
                raise ValidationFailed(f"Ligne {n} : échéance de prêt future obligatoire.")
        qty = inv.to_base_quantity(ctx, item, ln.quantity, ln.unit, purpose="issue")
        r.lines.append(RequestLine(id=uuid.uuid4(), line_no=n, item_id=item.id, variant_id=ln.variant_id, kind=ln.kind,
                                   due_date=ln.due_date, requested_qty=qty))
    audit(ctx, "request.create", "REQUEST", r.id, object_ref=r.reference, depot_id=r.depot_id, details={"lines": len(body.lines)})
    ctx.commit()
    return request_dict(ctx, r)


@router.post("/requests/{request_id}/submit")
def submit_request(ctx: CtxDep, request_id: uuid.UUID, body: VersionedAction):
    r = load(ctx, request_id)
    ctx.require("request.create", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.DRAFT}, "soumettre")
    r.status, r.submitted_at = S.SUBMITTED, ctx.now
    audit(ctx, "request.submit", "REQUEST", r.id, object_ref=r.reference, depot_id=r.depot_id)
    ctx.commit()
    return request_dict(ctx, r)


@router.post("/requests/{request_id}/review")
def review_request(ctx: CtxDep, request_id: uuid.UUID, body: ReviewIn):
    r = load(ctx, request_id)
    ctx.require("request.review", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.SUBMITTED}, "revue")
    r.status, r.reviewed_by, r.reviewed_at, r.review_comment = S.REVIEWED, ctx.user_id, ctx.now, body.comment
    audit(ctx, "request.review", "REQUEST", r.id, object_ref=r.reference, depot_id=r.depot_id, reason=body.comment)
    ctx.commit()
    return request_dict(ctx, r)


@router.post("/requests/{request_id}/approval")
def approve_request(ctx: CtxDep, request_id: uuid.UUID, body: ApprovalIn):
    r = load(ctx, request_id)
    ctx.require("request.approve", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.REVIEWED}, "approbation")
    ctx.separate("sod.request_approver_not_creator", r.created_by, "L'approbateur doit être distinct de l'auteur de la demande.")
    overrides = {a.line_id: a.approved_qty for a in body.lines}
    if body.decision == "REJECT":
        r.status = S.REJECTED
    else:
        for ln in r.lines:
            q = overrides.get(ln.id, ln.requested_qty)
            if q > ln.requested_qty:
                raise ValidationFailed(f"Ligne {ln.line_no} : quantité approuvée supérieure à la demande.")
            ln.approved_qty = q
        if all(ln.approved_qty == 0 for ln in r.lines):
            raise ValidationFailed("Aucune quantité approuvée : utilisez la décision REJECT.")
        r.status = S.APPROVED
    r.decided_by, r.decided_at, r.decision_comment = ctx.user_id, ctx.now, body.comment
    audit(ctx, f"request.{body.decision.lower()}", "REQUEST", r.id, object_ref=r.reference, depot_id=r.depot_id, reason=body.comment,
          details={"approved": {str(ln.line_no): ln.approved_qty for ln in r.lines}})
    ctx.commit()
    return request_dict(ctx, r)


@router.post("/requests/{request_id}/reservation")
def reserve_request(ctx: CtxDep, request_id: uuid.UUID, body: ReservationIn):
    """Réserve le stock disponible (contrôlé, utilisable, non réservé). Verrouillage des soldes : pas de double allocation."""
    r = load(ctx, request_id)
    ctx.require("request.reserve", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.APPROVED, S.RESERVED}, "réservation")
    src = ("REQUEST", r.id, r.reference)
    summary = []
    for ln in r.lines:
        existing = sum((x.quantity - x.released for x in _line_reservations(ctx, ln.id)), Decimal(0))
        missing = ln.approved_qty - existing
        if missing <= 0:
            continue
        item = ctx.db.get(Item, ln.item_id)
        chosen = body.asset_selection.get(ln.id) or None
        if chosen and len(chosen) != missing:
            raise ValidationFailed(f"Ligne {ln.line_no} : {missing:g} exemplaire(s) à sélectionner.")
        _, got = inv.reserve_stock(ctx, depot_id=r.depot_id, item=item, variant_id=ln.variant_id, quantity=missing, source=src,
                                   request_line_id=ln.id, allow_partial=body.allow_partial, asset_ids=chosen)
        summary.append({"line": ln.line_no, "requested": missing, "reserved": got})
    total_reserved = sum((s["reserved"] for s in summary), Decimal(0))
    if summary and total_reserved == 0:
        raise Conflict("Aucune quantité disponible à réserver (stock non contrôlé, bloqué ou déjà réservé).", code="stock_insuffisant",
                       details={"lines": [{k: float(v) if isinstance(v, Decimal) else v for k, v in s.items()} for s in summary]})
    r.status = S.RESERVED
    audit(ctx, "request.reserve", "REQUEST", r.id, object_ref=r.reference, depot_id=r.depot_id, details={"lines": summary})
    ctx.commit()
    out = request_dict(ctx, r)
    out["reservation_summary"] = [{k: float(v) if isinstance(v, Decimal) else v for k, v in s.items()} for s in summary]
    return out


@router.post("/requests/{request_id}/preparation")
def prepare_request(ctx: CtxDep, request_id: uuid.UUID, body: VersionedAction):
    r = load(ctx, request_id)
    ctx.require("request.issue", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.RESERVED}, "préparation")
    r.status = S.IN_PREPARATION
    audit(ctx, "request.prepare", "REQUEST", r.id, object_ref=r.reference, depot_id=r.depot_id)
    ctx.commit()
    return request_dict(ctx, r)


@router.post("/requests/{request_id}/close")
def close_request(ctx: CtxDep, request_id: uuid.UUID, body: CloseIn):
    """Clôture : libère les reliquats réservés non remis."""
    r = load(ctx, request_id)
    ctx.require("request.close", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.APPROVED, S.RESERVED, S.IN_PREPARATION, S.PARTIALLY_ISSUED, S.ISSUED, S.REJECTED, S.DRAFT, S.SUBMITTED, S.REVIEWED}, "clôturer")
    released = Decimal(0)
    for ln in r.lines:
        for res in _line_reservations(ctx, ln.id):
            if res.status == ReservationStatus.ACTIVE and res.open_quantity > 0:
                released += inv.release_reservation(ctx, res, source=("REQUEST", r.id, r.reference), reason=body.reason or "Clôture de la demande")
    r.status = S.CLOSED if r.status not in (S.DRAFT, S.SUBMITTED, S.REVIEWED) else S.CANCELLED
    r.closed_at = ctx.now
    audit(ctx, "request.close", "REQUEST", r.id, object_ref=r.reference, depot_id=r.depot_id, reason=body.reason, details={"released": released})
    ctx.commit()
    return request_dict(ctx, r)


# ----------------------------------------------------------------------------- remise (dotation)
@router.post("/allocations", status_code=201)
def create_allocation(ctx: CtxDep, body: AllocationIn):
    """Remise effective, partielle autorisée, avec justificatif. Consomme les réservations de la demande."""
    r = load(ctx, body.request_id)
    ctx.require("request.issue", r.depot_id)
    expect_version(r, body.version)
    expect_status(r, {S.IN_PREPARATION, S.PARTIALLY_ISSUED}, "remise")
    lines = {ln.id: ln for ln in r.lines}
    alloc = Allocation(
        id=uuid.uuid4(), reference=next_reference(ctx.db, "allocation", ctx.now.year), request_id=r.id, depot_id=r.depot_id,
        beneficiary_org_id=r.beneficiary_org_id, recipient_name=body.recipient_name, responsible_name=r.responsible_name,
        administrative_destination=r.administrative_destination, proof_reference=body.proof_reference, issued_by=ctx.user_id,
        issued_at=ctx.now, notes=body.notes,
    )
    ctx.db.add(alloc)
    src = ("ALLOCATION", alloc.id, alloc.reference)
    for al in body.lines:
        ln = lines.get(al.request_line_id)
        if ln is None:
            raise ValidationFailed("Ligne de demande inconnue.")
        if ln.issued_qty + al.quantity > ln.approved_qty:
            raise ValidationFailed(f"Ligne {ln.line_no} : remise supérieure à la quantité approuvée.")
        item = ctx.db.get(Item, ln.item_id)
        inv.check_integral(ctx, item, al.quantity)
        open_res = [x for x in _line_reservations(ctx, ln.id) if x.status == ReservationStatus.ACTIVE and x.open_quantity > 0]
        if al.asset_ids:
            if len(al.asset_ids) != al.quantity:
                raise ValidationFailed("Nombre d'exemplaires différent de la quantité remise.")
            open_res = [x for x in open_res if x.asset_id in set(al.asset_ids)]
        if sum((x.open_quantity for x in open_res), Decimal(0)) < al.quantity:
            raise Conflict(f"Ligne {ln.line_no} : quantité réservée insuffisante. Une remise exige une réservation préalable.", code="reservation_insuffisante")
        remaining = al.quantity
        for res in open_res:
            if remaining <= 0:
                break
            take = min(remaining, res.open_quantity)
            inv.consume_reservation(ctx, res, take, mtype=MovementType.ISSUE, source=src, counterpart_org_id=r.beneficiary_org_id)
            asset = ctx.db.get(Asset, res.asset_id) if res.asset_id else None
            if asset is not None:
                asset.lifecycle = AssetLifecycle.ISSUED
                asset.custody_type = CustodyType.ORGANIZATION
                asset.custody_org_id = r.beneficiary_org_id
                asset.custody_person = r.responsible_name
            alloc.lines.append(AllocationLine(
                id=uuid.uuid4(), request_line_id=ln.id, item_id=ln.item_id, variant_id=res.variant_id, lot_id=res.lot_id,
                asset_id=res.asset_id, kind=ln.kind, quantity=take, due_date=ln.due_date,
            ))
            remaining -= take
        ln.issued_qty += al.quantity
    r.status = S.ISSUED if all(ln.issued_qty >= ln.approved_qty for ln in r.lines) else S.PARTIALLY_ISSUED
    audit(ctx, "allocation.issue", "ALLOCATION", alloc.id, object_ref=alloc.reference, depot_id=r.depot_id,
          details={"request": r.reference, "proof": body.proof_reference, "recipient": body.recipient_name,
                   "quantities": {str(al.request_line_id): al.quantity for al in body.lines}})
    ctx.commit()
    return allocation_dict(ctx, alloc)


@router.get("/allocations")
def list_allocations(ctx: CtxDep, page: PageDep, depot_id: uuid.UUID | None = None, loans_only: bool = False, overdue_only: bool = False):
    ctx.require("stock.read")
    stmt = select(Allocation).where(Allocation.depot_id.in_(ctx.visible_depot_ids())).order_by(Allocation.issued_at.desc())
    if depot_id:
        stmt = stmt.where(Allocation.depot_id == depot_id)
    if loans_only or overdue_only:
        sub = select(AllocationLine.allocation_id).where(AllocationLine.kind == LineKind.LOAN)
        if overdue_only:
            sub = sub.where(AllocationLine.due_date < ctx.now.date(),
                            AllocationLine.quantity > AllocationLine.returned_qty + AllocationLine.consumed_qty)
        stmt = stmt.where(Allocation.id.in_(sub))
    return paginate(ctx, stmt, page, lambda a: allocation_dict(ctx, a))


@router.get("/allocations/{allocation_id}")
def get_allocation(ctx: CtxDep, allocation_id: uuid.UUID):
    a = ctx.db.get(Allocation, allocation_id)
    if a is None:
        raise NotFound("Dotation introuvable.")
    ctx.require("stock.read", a.depot_id)
    return allocation_dict(ctx, a)


def _load_line(ctx, line_id) -> tuple[AllocationLine, Allocation]:
    ln = ctx.db.execute(
        select(AllocationLine).where(AllocationLine.id == line_id).with_for_update().execution_options(populate_existing=True)
    ).scalar_one_or_none()
    if ln is None:
        raise NotFound("Ligne de dotation introuvable.")
    alloc = ctx.db.get(Allocation, ln.allocation_id)
    return ln, alloc


@router.post("/allocation-lines/{line_id}/extension")
def extend_loan(ctx: CtxDep, line_id: uuid.UUID, body: ExtensionIn):
    """Prolongation autorisée d'un prêt (nombre et durée plafonnés par paramètres)."""
    ln, alloc = _load_line(ctx, line_id)
    ctx.require("loan.extend", alloc.depot_id)
    expect_version(ln, body.version)
    if ln.kind != LineKind.LOAN or ln.outstanding_qty <= 0:
        raise Conflict("Seul un prêt en cours peut être prolongé.")
    if ln.extensions_count >= int(ctx.setting("loan.max_extensions")):
        raise Conflict("Nombre maximal de prolongations atteint.", code="prolongation_plafonnee")
    if body.new_due_date <= ln.due_date:
        raise ValidationFailed("La nouvelle échéance doit être postérieure à l'échéance actuelle.")
    if body.new_due_date > ln.due_date + timedelta(days=int(ctx.setting("loan.max_extension_days"))):
        raise ValidationFailed("Prolongation supérieure à la durée maximale autorisée.")
    ln.extension_history = [*ln.extension_history, {"from": str(ln.due_date), "to": str(body.new_due_date), "by": ctx.user.full_name,
                                                     "at": ctx.now.isoformat(), "reason": body.reason}]
    ln.due_date = body.new_due_date
    ln.extensions_count += 1
    audit(ctx, "loan.extend", "ALLOCATION", alloc.id, object_ref=alloc.reference, depot_id=alloc.depot_id, reason=body.reason,
          details={"line": str(ln.id), "new_due_date": str(body.new_due_date)})
    ctx.commit()
    return allocation_dict(ctx, alloc)


@router.post("/allocation-lines/{line_id}/consumption")
def declare_consumption(ctx: CtxDep, line_id: uuid.UUID, body: ConsumptionIn):
    """Déclare consommée une quantité remise (la remise seule n'est pas une consommation)."""
    ln, alloc = _load_line(ctx, line_id)
    ctx.require("request.issue", alloc.depot_id)
    expect_version(ln, body.version)
    item = ctx.db.get(Item, ln.item_id)
    if not item.consumable:
        raise ValidationFailed(f"L'article {item.code} n'est pas un consommable.")
    if body.quantity > ln.outstanding_qty:
        raise ValidationFailed("Quantité supérieure au reliquat détenu par le bénéficiaire.")
    ln.consumed_qty += body.quantity
    audit(ctx, "allocation.consumption", "ALLOCATION", alloc.id, object_ref=alloc.reference, depot_id=alloc.depot_id, reason=body.reason,
          details={"line": str(ln.id), "quantity": body.quantity})
    ctx.commit()
    return allocation_dict(ctx, alloc)


# ----------------------------------------------------------------------------- retours
@router.post("/returns", status_code=201)
def create_return(ctx: CtxDep, body: ReturnIn):
    """Retour d'un matériel remis : entre bloqué (contrôle de retour ou quarantaine) — jamais directement disponible."""
    ln, alloc = _load_line(ctx, body.allocation_line_id)
    ctx.require("return.create", alloc.depot_id)
    item = ctx.db.get(Item, ln.item_id)
    if body.quantity > ln.outstanding_qty:
        raise ValidationFailed(f"Quantité retournée supérieure au reliquat détenu ({ln.outstanding_qty}).")
    asset = None
    if item.tracking == Tracking.SERIAL:
        if body.asset_id is None or body.asset_id != ln.asset_id or body.quantity != 1:
            raise ValidationFailed("Indiquer l'exemplaire remis sur cette ligne (quantité 1).")
        asset = ctx.db.execute(select(Asset).where(Asset.id == body.asset_id).with_for_update()).scalar_one()
        if asset.lifecycle != AssetLifecycle.ISSUED:
            raise Conflict("Cet exemplaire n'est pas en situation de remise.")
    good = body.condition == "GOOD"
    loc = inv.location_of_kind(ctx, alloc.depot_id, LocationKind.RECEIVING if good else LocationKind.QUARANTINE)
    ret = ReturnRecord(
        id=uuid.uuid4(), reference=next_reference(ctx.db, "return", ctx.now.year), allocation_line_id=ln.id, depot_id=alloc.depot_id,
        asset_id=asset.id if asset else None, quantity=body.quantity, condition=body.condition, observed_condition=body.observed_condition,
        returned_by_name=body.returned_by_name, received_by=ctx.user_id, returned_at=ctx.now,
    )
    ctx.db.add(ret)
    if asset is not None:
        asset.lifecycle = AssetLifecycle.IN_STOCK
        asset.custody_type, asset.custody_org_id, asset.custody_person = CustodyType.DEPOT, None, None
        asset.technical_state = TechnicalState.AWAITING_INSPECTION if good else TechnicalState.UNSERVICEABLE
    inv.post_movement(
        ctx, mtype=MovementType.RETURN, item=item, quantity=body.quantity, variant_id=ln.variant_id, lot_id=ln.lot_id, asset=asset,
        to_location=loc, to_status=StockStatus.PENDING_INSPECTION if good else StockStatus.QUARANTINE,
        source=("RETURN", ret.id, ret.reference), counterpart_org_id=alloc.beneficiary_org_id, reason=body.observed_condition,
    )
    ln.returned_qty += body.quantity
    order = None
    if body.report_defect:
        if asset is None:
            raise ValidationFailed("Un signalement de défaut porte sur un exemplaire sérialisé.")
        from app.modules.maintenance.api import signal_order

        order = signal_order(ctx, asset, body.defect_description or body.observed_condition, origin="RETURN", priority="HIGH")
        ret.maintenance_order_id = order.id
    audit(ctx, "return.create", "RETURN", ret.id, object_ref=ret.reference, depot_id=alloc.depot_id,
          details={"allocation": alloc.reference, "condition": body.condition, "maintenance_order": order.reference if order else None})
    ctx.commit()
    return {
        "id": ret.id, "reference": ret.reference, "condition": ret.condition, "location": loc.code,
        "stock_status": "PENDING_INSPECTION" if good else "QUARANTINE",
        "maintenance_order": {"id": order.id, "reference": order.reference} if order else None,
        "allocation": allocation_dict(ctx, alloc),
    }
