"""Authentification : sessions sécurisées, MFA via adaptateur, authentification organisationnelle."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, Request, Response
from pydantic import Field
from sqlalchemy import select

from app.config import get_settings
from app.core.clock import clock_info
from app.core.context import PERMISSIONS, Ctx
from app.core.deps import CtxDep, get_ctx_pending_mfa, get_public_ctx
from app.core.errors import Forbidden, Unauthorized
from app.core.schemas import StrictModel
from app.core.security import get_mfa_adapter, new_token, token_hash, verify_password
from app.modules.audit.service import audit
from app.modules.auth.models import UserSession
from app.modules.org.models import ROLE_LABELS, Organization, User

router = APIRouter(prefix="/v1/auth", tags=["Authentification"])


class LoginIn(StrictModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)
    organization_code: str | None = None


class MfaIn(StrictModel):
    code: str = Field(min_length=6, max_length=8)


def _requires_mfa(user: User) -> bool:
    required = {r.strip() for r in get_settings().mfa_required_roles.split(",") if r.strip()}
    return user.mfa_enabled or any(m.role_code in required for m in user.memberships)


def _set_cookies(response: Response, token: str, csrf: str) -> None:
    s = get_settings()
    max_age = s.session_ttl_minutes * 60
    response.set_cookie(s.session_cookie_name, token, max_age=max_age, httponly=True, secure=s.cookie_secure, samesite="strict", path="/")
    response.set_cookie(s.csrf_cookie_name, csrf, max_age=max_age, httponly=False, secure=s.cookie_secure, samesite="strict", path="/")


def me_dict(ctx: Ctx) -> dict:
    from app.modules.inventory.models import Depot

    user = ctx.user
    depots = {d.id: d for d in ctx.db.execute(select(Depot)).scalars()}
    org = ctx.db.get(Organization, user.organization_id)
    return {
        "id": user.id,
        "username": user.username,
        "full_name": user.full_name,
        "organization": {"id": org.id, "code": org.code, "name": org.name},
        "mfa_enabled": user.mfa_enabled,
        "memberships": [
            {
                "role": m.role_code,
                "role_label": ROLE_LABELS.get(m.role_code, m.role_code),
                "organization_id": m.organization_id,
                "depot_id": m.depot_id,
                "depot_code": depots[m.depot_id].code if m.depot_id in depots else None,
            }
            for m in user.memberships
        ],
        "visible_depot_ids": sorted(str(d) for d in ctx.visible_depot_ids()),
        "permissions": sorted(p for p in PERMISSIONS if ctx.can(p)),
        "permissions_by_depot": {str(d): sorted(p for p in PERMISSIONS if ctx.can(p, d)) for d in depots},
        "clock": clock_info(ctx.db),
    }


@router.post("/login")
def login(body: LoginIn, request: Request, response: Response, ctx: Annotated[Ctx, Depends(get_public_ctx)]):
    s = get_settings()
    user = ctx.db.execute(select(User).where(User.username == body.username)).scalar_one_or_none()
    real_now = datetime.now(timezone.utc)
    generic = Unauthorized("Identifiant ou mot de passe incorrect.", code="identifiants_invalides")
    if user is None or not user.active:
        verify_password(None, body.password)  # temps constant approximatif
        raise generic
    org = ctx.db.get(Organization, user.organization_id)
    if body.organization_code and org.code != body.organization_code:
        raise generic
    if org.auth_mode == "OIDC":
        raise Forbidden(
            "Cette organisation utilise l'authentification organisationnelle (OIDC). "
            "L'adaptateur n'est pas branché dans ce prototype.",
            code="authentification_organisationnelle",
        )
    if user.locked_until and user.locked_until > real_now:
        raise Unauthorized("Compte temporairement verrouillé après plusieurs échecs.", code="compte_verrouille")
    if not verify_password(user.password_hash, body.password):
        user.failed_logins += 1
        if user.failed_logins >= s.login_max_failures:
            user.locked_until = real_now + timedelta(minutes=s.login_lock_minutes)
            user.failed_logins = 0
        ctx.user = user
        audit(ctx, "auth.login", "USER", user.id, object_ref=user.username, outcome="DENIED", reason="mot de passe invalide")
        ctx.commit()
        raise generic
    needs_mfa = _requires_mfa(user)
    if needs_mfa and not (user.mfa_enabled and user.mfa_secret):
        raise Forbidden("MFA obligatoire pour ce rôle : enrôlement à réaliser par un administrateur.", code="mfa_non_enrolee")
    user.failed_logins = 0
    user.locked_until = None
    token, csrf = new_token(), new_token()
    sess = UserSession(
        token_hash=token_hash(token), csrf_token=csrf, user_id=user.id, mfa_verified=not needs_mfa,
        expires_at=real_now + timedelta(minutes=s.session_ttl_minutes), last_seen_at=real_now,
        ip=ctx.ip, user_agent=(request.headers.get("user-agent") or "")[:300],
    )
    ctx.db.add(sess)
    ctx.user = user
    audit(ctx, "auth.login", "USER", user.id, object_ref=user.username, details={"mfa_pending": needs_mfa})
    ctx.commit()
    _set_cookies(response, token, csrf)
    # Le jeton est aussi renvoyé pour les clients d'API (en-tête Authorization: Bearer).
    return {"mfa_required": needs_mfa, "token": token, "csrf_token": csrf}


@router.post("/mfa")
def verify_mfa(body: MfaIn, request: Request, ctx: Annotated[Ctx, Depends(get_ctx_pending_mfa)]):
    sess: UserSession = request.state.session
    adapter = get_mfa_adapter(get_settings().mfa_adapter)
    if not ctx.user.mfa_secret or not adapter.verify(ctx.user.mfa_secret, body.code):
        audit(ctx, "auth.mfa", "USER", ctx.user.id, object_ref=ctx.user.username, outcome="DENIED")
        ctx.commit()
        raise Unauthorized("Code de vérification invalide.", code="mfa_invalide")
    sess = ctx.db.get(UserSession, sess.id)
    sess.mfa_verified = True
    audit(ctx, "auth.mfa", "USER", ctx.user.id, object_ref=ctx.user.username)
    ctx.commit()
    return {"mfa_verified": True}


@router.post("/logout")
def logout(request: Request, response: Response, ctx: Annotated[Ctx, Depends(get_ctx_pending_mfa)]):
    sess = ctx.db.get(UserSession, request.state.session.id)
    sess.revoked_at = datetime.now(timezone.utc)
    audit(ctx, "auth.logout", "USER", ctx.user.id, object_ref=ctx.user.username)
    ctx.commit()
    s = get_settings()
    response.delete_cookie(s.session_cookie_name, path="/")
    response.delete_cookie(s.csrf_cookie_name, path="/")
    return {"ok": True}


@router.get("/me")
def me(ctx: CtxDep):
    return me_dict(ctx)
