from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal
from enum import StrEnum

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, Qty, Timestamped, Versioned, uuid_pk


class TransferStatus(StrEnum):
    REQUESTED = "REQUESTED"  # demandé
    APPROVED = "APPROVED"  # approuvé
    RESERVED = "RESERVED"  # réservé
    IN_TRANSIT = "IN_TRANSIT"  # expédié / en transit
    RECEIVED = "RECEIVED"  # réceptionné (écart éventuel à traiter)
    RECONCILED = "RECONCILED"  # rapproché
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"


class Transfer(Base, Timestamped, Versioned):
    __tablename__ = "transfers"
    __table_args__ = (CheckConstraint("source_depot_id <> destination_depot_id", name="distinct_depots"),)
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    source_depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"), index=True)
    destination_depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"), index=True)
    status: Mapped[TransferStatus] = mapped_column(String(16), default=TransferStatus.REQUESTED, index=True)
    reason: Mapped[str] = mapped_column(Text, default="")
    carrier: Mapped[str | None] = mapped_column(String(200))
    waybill_ref: Mapped[str | None] = mapped_column(String(80))
    requested_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    approved_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    dispatched_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    dispatched_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    received_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    received_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reconciled_by: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    reconciled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    lines: Mapped[list["TransferLine"]] = relationship(
        back_populates="transfer", order_by="TransferLine.line_no", lazy="selectin", cascade="all, delete-orphan"
    )


class TransferLine(Base, Timestamped, Versioned):
    """Quantités conservées séparément : expédiée, reçue (bonne), endommagée, écart restant à traiter."""

    __tablename__ = "transfer_lines"
    __table_args__ = (
        CheckConstraint("requested_qty > 0", name="requested_positive"),
        CheckConstraint("shipped_qty <= reserved_qty", name="shipped_bounded"),
        CheckConstraint(
            "received_qty + damaged_qty + written_off_qty <= shipped_qty", name="arrival_bounded"
        ),
    )
    id: Mapped[uuid.UUID] = uuid_pk()
    transfer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("transfers.id", ondelete="CASCADE"))
    line_no: Mapped[int] = mapped_column(Integer)
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"))
    variant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("item_variants.id"))
    requested_qty: Mapped[Decimal] = mapped_column(Qty)
    reserved_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    shipped_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    received_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))  # reçue en bon état
    damaged_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    written_off_qty: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))  # perte approuvée
    shipped_lots: Mapped[list] = mapped_column(JSONB, default=list)  # [{lot_id, quantity}]
    shipped_asset_ids: Mapped[list] = mapped_column(JSONB, default=list)
    discrepancy_note: Mapped[str] = mapped_column(Text, default="")
    transfer: Mapped[Transfer] = relationship(back_populates="lines")

    @property
    def in_transit_qty(self) -> Decimal:
        """Quantité expédiée non encore constatée à destination ni passée en perte."""
        return self.shipped_qty - self.received_qty - self.damaged_qty - self.written_off_qty
