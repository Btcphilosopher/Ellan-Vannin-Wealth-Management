"""Transferts : demandé → approuvé → réservé → expédié/en transit → réceptionné → rapproché.

Un matériel en transit n'appartient au stock d'aucun des deux dépôts. La réception est confirmée par
un utilisateur habilité du dépôt destinataire.
"""
from __future__ import annotations

import uuid
from decimal import Decimal
from typing import Literal

from fastapi import APIRouter
from pydantic import Field
from sqlalchemy import select

from app.core.deps import CtxDep, PageDep, paginate
from app.core.errors import Conflict, Forbidden, NotFound, ValidationFailed, expect_status, expect_version
from app.core.refs import next_reference
from app.core.schemas import NonNegQty, PositiveQty, StrictModel, VersionedAction, dec
from app.modules.audit.service import audit
from app.modules.catalog.models import Item, ItemVariant, Tracking
from app.modules.inventory import service as inv
from app.modules.inventory.models import (
    Asset,
    AssetLifecycle,
    CustodyType,
    Depot,
    LocationKind,
    MovementType,
    Reservation,
    ReservationStatus,
    StockStatus,
    TechnicalState,
)
from app.modules.org.models import User
from app.modules.transfers.models import Transfer, TransferLine, TransferStatus as S

router = APIRouter(prefix="/v1/transfers", tags=["Transferts"])


class TransferLineIn(StrictModel):
    item_id: uuid.UUID
    variant_id: uuid.UUID | None = None
    quantity: PositiveQty
    unit: str | None = None


class TransferIn(StrictModel):
    source_depot_id: uuid.UUID
    destination_depot_id: uuid.UUID
    reason: str = Field(min_length=3, max_length=1000)
    lines: list[TransferLineIn] = Field(min_length=1, max_length=100)


class ApprovalIn(VersionedAction):
    decision: Literal["APPROVE", "REJECT"]
    comment: str = Field(min_length=3, max_length=1000)


class DispatchIn(VersionedAction):
    carrier: str = Field(min_length=2, max_length=200)
    waybill_ref: str = Field(min_length=2, max_length=80)


class ArrivalLineIn(StrictModel):
    line_id: uuid.UUID
    received_qty: NonNegQty
    damaged_qty: NonNegQty = Decimal(0)
    damaged_asset_ids: list[uuid.UUID] = Field(default_factory=list)
    missing_asset_ids: list[uuid.UUID] = Field(default_factory=list)
    note: str = ""


class ArrivalIn(VersionedAction):
    lines: list[ArrivalLineIn] = Field(min_length=1)


class ReconcileLineIn(StrictModel):
    line_id: uuid.UUID
    action: Literal["WRITE_OFF", "FOUND"]
    quantity: PositiveQty
    asset_ids: list[uuid.UUID] = Field(default_factory=list)
    justification: str = Field(min_length=10, max_length=2000)


class ReconcileIn(VersionedAction):
    lines: list[ReconcileLineIn] = Field(default_factory=list)


def transfer_dict(ctx, t: Transfer) -> dict:
    users = {u.id: u.full_name for u in ctx.db.execute(select(User)).scalars()}
    src, dst = ctx.db.get(Depot, t.source_depot_id), ctx.db.get(Depot, t.destination_depot_id)
    lines = []
    for ln in t.lines:
        item = ctx.db.get(Item, ln.item_id)
        v = ctx.db.get(ItemVariant, ln.variant_id) if ln.variant_id else None
        assets = [ctx.db.get(Asset, uuid.UUID(a)) for a in ln.shipped_asset_ids]
        remaining = ln.in_transit_qty
        lines.append({
            "id": ln.id, "line_no": ln.line_no, "item_id": item.id, "item_code": item.code, "designation": item.designation,
            "tracking": item.tracking, "base_unit": item.base_unit, "variant_label": v.label if v else None,
            "requested_qty": dec(ln.requested_qty), "reserved_qty": dec(ln.reserved_qty), "shipped_qty": dec(ln.shipped_qty),
            "received_qty": dec(ln.received_qty), "damaged_qty": dec(ln.damaged_qty), "written_off_qty": dec(ln.written_off_qty),
            "in_transit_qty": dec(remaining) if t.status == S.IN_TRANSIT else 0.0,
            "discrepancy_qty": dec(remaining) if t.status in (S.RECEIVED, S.RECONCILED) else 0.0,
            "discrepancy_note": ln.discrepancy_note,
            "assets": [{"id": a.id, "serial_number": a.serial_number, "internal_tag": a.internal_tag, "lifecycle": a.lifecycle,
                        "technical_state": a.technical_state} for a in assets if a],
            "version": ln.version,
        })
    return {
        "id": t.id, "reference": t.reference, "status": t.status, "version": t.version, "reason": t.reason,
        "source_depot": {"id": src.id, "code": src.code, "name": src.name},
        "destination_depot": {"id": dst.id, "code": dst.code, "name": dst.name},
        "carrier": t.carrier, "waybill_ref": t.waybill_ref,
        "requested_by": users.get(t.requested_by), "requested_at": t.requested_at, "approved_by": users.get(t.approved_by),
        "approved_at": t.approved_at, "dispatched_by": users.get(t.dispatched_by), "dispatched_at": t.dispatched_at,
        "received_by": users.get(t.received_by), "received_at": t.received_at, "reconciled_by": users.get(t.reconciled_by),
        "reconciled_at": t.reconciled_at, "lines": lines,
        "totals": {k: float(sum((getattr(ln, k) for ln in t.lines), Decimal(0))) for k in
                   ("requested_qty", "shipped_qty", "received_qty", "damaged_qty", "written_off_qty")},
    }


@router.get("")
def list_transfers(ctx: CtxDep, page: PageDep, status: str | None = None, depot_id: uuid.UUID | None = None):
    ctx.require("stock.read")
    vis = ctx.visible_depot_ids()
    stmt = select(Transfer).where((Transfer.source_depot_id.in_(vis)) | (Transfer.destination_depot_id.in_(vis))).order_by(Transfer.created_at.desc())
    if status:
        stmt = stmt.where(Transfer.status.in_(status.split(",")))
    if depot_id:
        stmt = stmt.where((Transfer.source_depot_id == depot_id) | (Transfer.destination_depot_id == depot_id))
    return paginate(ctx, stmt, page, lambda t: transfer_dict(ctx, t))


def load(ctx, transfer_id) -> Transfer:
    t = ctx.db.execute(select(Transfer).where(Transfer.id == transfer_id).with_for_update().execution_options(populate_existing=True)).scalar_one_or_none()
    if t is None:
        raise NotFound("Transfert introuvable.")
    if not (ctx.can("stock.read", t.source_depot_id) or ctx.can("stock.read", t.destination_depot_id)):
        raise Forbidden("Transfert hors de votre périmètre.")
    return t


@router.get("/{transfer_id}")
def get_transfer(ctx: CtxDep, transfer_id: uuid.UUID):
    return transfer_dict(ctx, load(ctx, transfer_id))


@router.post("", status_code=201)
def create_transfer(ctx: CtxDep, body: TransferIn):
    ctx.require("transfer.create", body.source_depot_id)
    if body.source_depot_id == body.destination_depot_id:
        raise ValidationFailed("Les dépôts d'origine et de destination doivent être différents.")
    if ctx.db.get(Depot, body.destination_depot_id) is None:
        raise ValidationFailed("Dépôt destinataire inconnu.")
    t = Transfer(id=uuid.uuid4(), reference=next_reference(ctx.db, "transfer", ctx.now.year), source_depot_id=body.source_depot_id,
                 destination_depot_id=body.destination_depot_id, reason=body.reason, requested_by=ctx.user_id, requested_at=ctx.now)
    ctx.db.add(t)
    for n, ln in enumerate(body.lines, start=1):
        item = ctx.db.get(Item, ln.item_id)
        if item is None:
            raise ValidationFailed(f"Ligne {n} : article inconnu.")
        if item.variants and not ln.variant_id:
            raise ValidationFailed(f"Ligne {n} : variante obligatoire.")
        t.lines.append(TransferLine(id=uuid.uuid4(), line_no=n, item_id=item.id, variant_id=ln.variant_id,
                                    requested_qty=inv.to_base_quantity(ctx, item, ln.quantity, ln.unit, purpose="issue")))
    audit(ctx, "transfer.create", "TRANSFER", t.id, object_ref=t.reference, depot_id=t.source_depot_id)
    ctx.commit()
    return transfer_dict(ctx, t)


@router.post("/{transfer_id}/approval")
def approve_transfer(ctx: CtxDep, transfer_id: uuid.UUID, body: ApprovalIn):
    t = load(ctx, transfer_id)
    ctx.require("transfer.approve", t.source_depot_id)
    expect_version(t, body.version)
    expect_status(t, {S.REQUESTED}, "approbation")
    ctx.separate("sod.transfer_approver_not_requester", t.requested_by, "L'approbateur doit être distinct du demandeur du transfert.")
    t.status = S.APPROVED if body.decision == "APPROVE" else S.REJECTED
    t.approved_by, t.approved_at = ctx.user_id, ctx.now
    audit(ctx, f"transfer.{body.decision.lower()}", "TRANSFER", t.id, object_ref=t.reference, depot_id=t.source_depot_id, reason=body.comment)
    ctx.commit()
    return transfer_dict(ctx, t)


@router.post("/{transfer_id}/reservation")
def reserve_transfer(ctx: CtxDep, transfer_id: uuid.UUID, body: VersionedAction):
    t = load(ctx, transfer_id)
    ctx.require("transfer.dispatch", t.source_depot_id)
    expect_version(t, body.version)
    expect_status(t, {S.APPROVED}, "réservation")
    src = ("TRANSFER", t.id, t.reference)
    for ln in t.lines:
        item = ctx.db.get(Item, ln.item_id)
        _, got = inv.reserve_stock(ctx, depot_id=t.source_depot_id, item=item, variant_id=ln.variant_id, quantity=ln.requested_qty,
                                   source=src, transfer_line_id=ln.id, allow_partial=False)
        ln.reserved_qty = got
    t.status = S.RESERVED
    audit(ctx, "transfer.reserve", "TRANSFER", t.id, object_ref=t.reference, depot_id=t.source_depot_id)
    ctx.commit()
    return transfer_dict(ctx, t)


@router.post("/{transfer_id}/dispatch")
def dispatch_transfer(ctx: CtxDep, transfer_id: uuid.UUID, body: DispatchIn):
    """Expédition : le stock quitte le dépôt d'origine et passe « en transit » (aucun des deux dépôts)."""
    t = load(ctx, transfer_id)
    ctx.require("transfer.dispatch", t.source_depot_id)
    expect_version(t, body.version)
    expect_status(t, {S.RESERVED}, "expédition")
    src = ("TRANSFER", t.id, t.reference)
    for ln in t.lines:
        lots: dict[str, Decimal] = {}
        asset_ids = []
        for res in ctx.db.execute(select(Reservation).where(Reservation.transfer_line_id == ln.id, Reservation.status == ReservationStatus.ACTIVE)).scalars():
            qty = res.open_quantity
            inv.consume_reservation(ctx, res, qty, mtype=MovementType.TRANSFER_OUT, source=src, reason=f"Expédition vers dépôt destinataire ({body.waybill_ref})")
            if res.asset_id:
                asset = ctx.db.get(Asset, res.asset_id)
                asset.lifecycle, asset.custody_type, asset.custody_person = AssetLifecycle.IN_TRANSIT, CustodyType.CARRIER, body.carrier
                asset_ids.append(str(asset.id))
            key = str(res.lot_id) if res.lot_id else "-"
            lots[key] = lots.get(key, Decimal(0)) + qty
            ln.shipped_qty += qty
        ln.shipped_lots = [{"lot_id": k, "quantity": float(v), "arrived": 0.0} for k, v in lots.items()]
        ln.shipped_asset_ids = asset_ids
    t.status, t.carrier, t.waybill_ref, t.dispatched_by, t.dispatched_at = S.IN_TRANSIT, body.carrier, body.waybill_ref, ctx.user_id, ctx.now
    audit(ctx, "transfer.dispatch", "TRANSFER", t.id, object_ref=t.reference, depot_id=t.source_depot_id,
          details={"carrier": body.carrier, "waybill": body.waybill_ref, "shipped": {str(ln.line_no): ln.shipped_qty for ln in t.lines}})
    ctx.commit()
    return transfer_dict(ctx, t)


def _arrive_quantity(ctx, t: Transfer, ln: TransferLine, item: Item, qty: Decimal, *, damaged: bool, src, reason: str):
    """Fait entrer une quantité non sérialisée au dépôt destinataire, lot par lot, dans l'ordre d'expédition."""
    loc = inv.location_of_kind(ctx, t.destination_depot_id, LocationKind.QUARANTINE if damaged else LocationKind.RECEIVING)
    remaining = qty
    lots = [dict(x) for x in ln.shipped_lots]
    for entry in lots:
        if remaining <= 0:
            break
        free = Decimal(str(entry["quantity"])) - Decimal(str(entry["arrived"]))
        take = min(free, remaining)
        if take <= 0:
            continue
        lot_id = None if entry["lot_id"] == "-" else uuid.UUID(entry["lot_id"])
        inv.post_movement(ctx, mtype=MovementType.TRANSFER_IN, item=item, quantity=take, variant_id=ln.variant_id, lot_id=lot_id,
                          to_location=loc, to_status=StockStatus.QUARANTINE if damaged else StockStatus.USABLE, source=src, reason=reason)
        entry["arrived"] = float(Decimal(str(entry["arrived"])) + take)
        remaining -= take
    if remaining > 0:
        raise ValidationFailed("Quantité arrivée supérieure à la quantité expédiée.")
    ln.shipped_lots = lots


@router.post("/{transfer_id}/receipt")
def receive_transfer(ctx: CtxDep, transfer_id: uuid.UUID, body: ArrivalIn):
    """Réception au dépôt destinataire : quantités bonnes, endommagées ; l'écart restant est conservé à traiter."""
    t = load(ctx, transfer_id)
    ctx.require("transfer.receive", t.destination_depot_id)
    expect_version(t, body.version)
    expect_status(t, {S.IN_TRANSIT}, "réception")
    lines = {ln.id: ln for ln in t.lines}
    src = ("TRANSFER", t.id, t.reference)
    for al in body.lines:
        ln = lines.get(al.line_id)
        if ln is None:
            raise ValidationFailed("Ligne inconnue.")
        if al.received_qty + al.damaged_qty > ln.in_transit_qty:
            raise ValidationFailed(f"Ligne {ln.line_no} : quantités constatées supérieures à la quantité expédiée.")
        item = ctx.db.get(Item, ln.item_id)
        if item.tracking == Tracking.SERIAL:
            shipped = {uuid.UUID(a) for a in ln.shipped_asset_ids}
            damaged, missing = set(al.damaged_asset_ids), set(al.missing_asset_ids)
            if not (damaged | missing) <= shipped or damaged & missing:
                raise ValidationFailed("Exemplaires endommagés/manquants incohérents avec l'expédition.")
            good = [a for a in shipped - damaged - missing]
            if len(good) != al.received_qty or len(damaged) != al.damaged_qty:
                raise ValidationFailed(f"Ligne {ln.line_no} : quantités et exemplaires déclarés incohérents.")
            for aid in good + list(damaged):
                a = ctx.db.get(Asset, aid)
                is_damaged = aid in damaged
                loc = inv.location_of_kind(ctx, t.destination_depot_id, LocationKind.QUARANTINE if is_damaged else LocationKind.RECEIVING)
                a.lifecycle, a.custody_type, a.custody_person = AssetLifecycle.IN_STOCK, CustodyType.DEPOT, None
                if is_damaged:
                    a.technical_state = TechnicalState.UNSERVICEABLE
                inv.post_movement(ctx, mtype=MovementType.TRANSFER_IN, item=item, quantity=1, asset=a, to_location=loc,
                                  to_status=StockStatus.QUARANTINE if is_damaged else StockStatus.USABLE, source=src, reason=al.note or None)
            for aid in missing:
                a = ctx.db.get(Asset, aid)
                a.lifecycle, a.custody_type = AssetLifecycle.MISSING, CustodyType.NONE
        else:
            if al.received_qty > 0:
                _arrive_quantity(ctx, t, ln, item, al.received_qty, damaged=False, src=src, reason=al.note or "Réception de transfert")
            if al.damaged_qty > 0:
                _arrive_quantity(ctx, t, ln, item, al.damaged_qty, damaged=True, src=src, reason=al.note or "Endommagé au transport")
        ln.received_qty += al.received_qty
        ln.damaged_qty += al.damaged_qty
        ln.discrepancy_note = al.note
    t.status, t.received_by, t.received_at = S.RECEIVED, ctx.user_id, ctx.now
    gaps = {str(ln.line_no): ln.in_transit_qty for ln in t.lines if ln.in_transit_qty}
    audit(ctx, "transfer.receive", "TRANSFER", t.id, object_ref=t.reference, depot_id=t.destination_depot_id,
          details={"received": {str(ln.line_no): ln.received_qty for ln in t.lines}, "damaged": {str(ln.line_no): ln.damaged_qty for ln in t.lines},
                   "discrepancies": gaps})
    ctx.commit()
    return transfer_dict(ctx, t)


@router.post("/{transfer_id}/reconciliation")
def reconcile_transfer(ctx: CtxDep, transfer_id: uuid.UUID, body: ReconcileIn):
    """Rapprochement : chaque écart restant est soit retrouvé (entrée tardive), soit passé en perte avec justification approuvée."""
    t = load(ctx, transfer_id)
    if not any(ctx.can(p, t.destination_depot_id) for p in ("transfer.reconcile", "transfer.writeoff_approve", "transfer.receive")):
        ctx.require("transfer.reconcile", t.destination_depot_id)
    expect_version(t, body.version)
    expect_status(t, {S.RECEIVED}, "rapprochement")
    lines = {ln.id: ln for ln in t.lines}
    src = ("TRANSFER", t.id, t.reference)
    for rl in body.lines:
        ln = lines.get(rl.line_id)
        if ln is None:
            raise ValidationFailed("Ligne inconnue.")
        if rl.quantity > ln.in_transit_qty:
            raise ValidationFailed(f"Ligne {ln.line_no} : quantité supérieure à l'écart restant ({ln.in_transit_qty}).")
        item = ctx.db.get(Item, ln.item_id)
        if rl.action == "WRITE_OFF":
            if ctx.setting("transfer.writeoff_requires_approver"):
                ctx.require("transfer.writeoff_approve", t.destination_depot_id, action="passation en perte")
            if item.tracking == Tracking.SERIAL:
                if len(rl.asset_ids) != rl.quantity:
                    raise ValidationFailed("Indiquer les exemplaires passés en perte.")
                for aid in rl.asset_ids:
                    a = ctx.db.get(Asset, aid)
                    if a is None or a.lifecycle != AssetLifecycle.MISSING:
                        raise ValidationFailed("Exemplaire non déclaré manquant.")
                    inv.post_movement(ctx, mtype=MovementType.LOSS, item=item, quantity=1, asset=a, depot_id=t.destination_depot_id,
                                      source=src, reason=rl.justification)
                    a.lifecycle, a.technical_state = AssetLifecycle.CONDEMNED, TechnicalState.CONDEMNED
            else:
                lots = [dict(x) for x in ln.shipped_lots]
                remaining = rl.quantity
                for entry in lots:
                    free = Decimal(str(entry["quantity"])) - Decimal(str(entry["arrived"]))
                    take = min(free, remaining)
                    if take <= 0:
                        continue
                    inv.post_movement(ctx, mtype=MovementType.LOSS, item=item, quantity=take, variant_id=ln.variant_id,
                                      lot_id=None if entry["lot_id"] == "-" else uuid.UUID(entry["lot_id"]), depot_id=t.destination_depot_id,
                                      source=src, reason=rl.justification)
                    entry["arrived"] = float(Decimal(str(entry["arrived"])) + take)
                    remaining -= take
                ln.shipped_lots = lots
            ln.written_off_qty += rl.quantity
        else:  # FOUND : arrivée tardive constatée
            ctx.require("transfer.receive", t.destination_depot_id)
            if item.tracking == Tracking.SERIAL:
                loc = inv.location_of_kind(ctx, t.destination_depot_id, LocationKind.RECEIVING)
                for aid in rl.asset_ids:
                    a = ctx.db.get(Asset, aid)
                    if a is None or a.lifecycle != AssetLifecycle.MISSING:
                        raise ValidationFailed("Exemplaire non déclaré manquant.")
                    a.lifecycle, a.custody_type = AssetLifecycle.IN_STOCK, CustodyType.DEPOT
                    a.technical_state = TechnicalState.AWAITING_INSPECTION
                    inv.post_movement(ctx, mtype=MovementType.TRANSFER_IN, item=item, quantity=1, asset=a, to_location=loc,
                                      to_status=StockStatus.PENDING_INSPECTION, source=src, reason=rl.justification)
            else:
                _arrive_quantity(ctx, t, ln, item, rl.quantity, damaged=False, src=src, reason=f"Arrivée tardive : {rl.justification}")
            ln.received_qty += rl.quantity
        audit(ctx, f"transfer.{rl.action.lower()}", "TRANSFER", t.id, object_ref=t.reference, depot_id=t.destination_depot_id,
              reason=rl.justification, details={"line": ln.line_no, "quantity": rl.quantity})
    if all(ln.in_transit_qty == 0 for ln in t.lines):
        t.status, t.reconciled_by, t.reconciled_at = S.RECONCILED, ctx.user_id, ctx.now
        audit(ctx, "transfer.reconciled", "TRANSFER", t.id, object_ref=t.reference, depot_id=t.destination_depot_id)
    else:
        from sqlalchemy.orm.attributes import flag_modified

        flag_modified(t, "reason")
    ctx.commit()
    return transfer_dict(ctx, t)
