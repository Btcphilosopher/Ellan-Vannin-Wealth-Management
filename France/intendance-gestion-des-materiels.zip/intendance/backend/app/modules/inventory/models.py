"""Inventaire : dépôts, emplacements, exemplaires sérialisés, soldes, journal des mouvements, réservations.

Distinctions du modèle :
- Référence de catalogue : ``Item`` (module catalogue).
- Lot : ``Lot``.
- Exemplaire physique : ``Asset`` (numéro de série + étiquette interne).
- Position de stock : ``StockBalance`` (emplacement × article × variante × lot × statut de stock).
- Responsable de garde : ``Asset.custody_*`` (dépôt, organisation bénéficiaire, transporteur, prestataire).
- État technique : ``Asset.technical_state`` (jugement technique, distinct de la disponibilité).
"""
from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum

from sqlalchemy import (
    BigInteger,
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    ForeignKey,
    Identity,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base, Qty, Timestamped, Versioned, uuid_pk


class LocationKind(StrEnum):
    RECEIVING = "RECEIVING"  # quai de réception
    STORAGE = "STORAGE"
    QUARANTINE = "QUARANTINE"
    MAINTENANCE = "MAINTENANCE"
    SHIPPING = "SHIPPING"


class StockStatus(StrEnum):
    USABLE = "USABLE"  # utilisable (disponible si non réservé)
    PENDING_INSPECTION = "PENDING_INSPECTION"  # non contrôlé : bloqué
    QUARANTINE = "QUARANTINE"  # bloqué
    MAINTENANCE = "MAINTENANCE"  # bloqué


BLOCKED_STATUSES = {StockStatus.PENDING_INSPECTION, StockStatus.QUARANTINE, StockStatus.MAINTENANCE}


class AssetLifecycle(StrEnum):
    IN_STOCK = "IN_STOCK"
    RESERVED = "RESERVED"
    ISSUED = "ISSUED"  # remis (dotation ou prêt)
    IN_TRANSIT = "IN_TRANSIT"
    MISSING = "MISSING"  # écart de transfert non résolu
    CONDEMNED = "CONDEMNED"  # réformé


class TechnicalState(StrEnum):
    AWAITING_INSPECTION = "AWAITING_INSPECTION"
    SERVICEABLE = "SERVICEABLE"
    UNSERVICEABLE = "UNSERVICEABLE"
    IN_MAINTENANCE = "IN_MAINTENANCE"
    CONDEMNED = "CONDEMNED"


class CustodyType(StrEnum):
    DEPOT = "DEPOT"
    ORGANIZATION = "ORGANIZATION"
    CARRIER = "CARRIER"
    NONE = "NONE"


class MovementType(StrEnum):
    RECEIPT = "RECEIPT"
    PUTAWAY = "PUTAWAY"
    RELOCATION = "RELOCATION"
    STATUS_CHANGE = "STATUS_CHANGE"
    QUARANTINE = "QUARANTINE"
    RESERVE = "RESERVE"
    UNRESERVE = "UNRESERVE"
    ISSUE = "ISSUE"
    RETURN = "RETURN"
    TRANSFER_OUT = "TRANSFER_OUT"
    TRANSFER_IN = "TRANSFER_IN"
    CONSUMPTION = "CONSUMPTION"
    CONDEMNATION = "CONDEMNATION"
    ADJUSTMENT = "ADJUSTMENT"
    LOSS = "LOSS"
    CORRECTION = "CORRECTION"


class Depot(Base, Timestamped, Versioned):
    __tablename__ = "depots"
    id: Mapped[uuid.UUID] = uuid_pk()
    code: Mapped[str] = mapped_column(String(16), unique=True)
    name: Mapped[str] = mapped_column(String(200))
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    address: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    locations: Mapped[list["Location"]] = relationship(back_populates="depot", order_by="Location.code")


class Location(Base, Timestamped):
    __tablename__ = "locations"
    __table_args__ = (UniqueConstraint("depot_id", "code", name="depot_code"),)
    id: Mapped[uuid.UUID] = uuid_pk()
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"))
    code: Mapped[str] = mapped_column(String(32))
    label: Mapped[str] = mapped_column(String(120))
    kind: Mapped[LocationKind] = mapped_column(String(16))
    internal_tag: Mapped[str] = mapped_column(String(40), unique=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    depot: Mapped[Depot] = relationship(back_populates="locations")


class Asset(Base, Timestamped, Versioned):
    """Exemplaire physique sérialisé. Une seule colonne d'emplacement : il ne peut être à deux endroits."""

    __tablename__ = "assets"
    __table_args__ = (
        UniqueConstraint("item_id", "serial_number", name="item_serial"),
        CheckConstraint(
            "(lifecycle IN ('IN_STOCK','RESERVED') AND location_id IS NOT NULL AND stock_status IS NOT NULL)"
            " OR (lifecycle IN ('ISSUED','IN_TRANSIT','MISSING','CONDEMNED') AND location_id IS NULL AND stock_status IS NULL)",
            name="location_coherence",
        ),
        CheckConstraint(
            "lifecycle <> 'RESERVED' OR (stock_status = 'USABLE' AND technical_state = 'SERVICEABLE')",
            name="reserved_serviceable",
        ),
    )
    id: Mapped[uuid.UUID] = uuid_pk()
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"), index=True)
    variant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("item_variants.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("lots.id"))
    serial_number: Mapped[str] = mapped_column(String(80))
    serial_normalized: Mapped[str] = mapped_column(String(80), index=True)
    internal_tag: Mapped[str] = mapped_column(String(40), unique=True)
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"))  # dépôt détenteur
    location_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("locations.id"))
    stock_status: Mapped[StockStatus | None] = mapped_column(String(24))
    lifecycle: Mapped[AssetLifecycle] = mapped_column(String(16))
    technical_state: Mapped[TechnicalState] = mapped_column(String(24))
    custody_type: Mapped[CustodyType] = mapped_column(String(16), default=CustodyType.DEPOT)
    custody_org_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    custody_person: Mapped[str | None] = mapped_column(String(200))
    next_inspection_due: Mapped[date | None] = mapped_column(Date)
    received_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    notes: Mapped[str] = mapped_column(Text, default="")


class StockBalance(Base, Versioned):
    """Solde d'une position de stock. Mis à jour uniquement par le service de mouvements, dans la même transaction."""

    __tablename__ = "stock_balances"
    __table_args__ = (
        CheckConstraint("quantity >= 0", name="quantity_non_negative"),
        CheckConstraint("reserved >= 0", name="reserved_non_negative"),
        CheckConstraint("reserved <= quantity", name="available_non_negative"),
        CheckConstraint("stock_status = 'USABLE' OR reserved = 0", name="reserve_only_usable"),
    )
    id: Mapped[uuid.UUID] = uuid_pk()
    bucket_key: Mapped[str] = mapped_column(String(200), unique=True)
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"), index=True)
    location_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("locations.id"))
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"), index=True)
    variant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("item_variants.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("lots.id"))
    stock_status: Mapped[StockStatus] = mapped_column(String(24))
    quantity: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    reserved: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class StockMovement(Base):
    """Journal attribuable et non modifiable (déclencheur PostgreSQL : UPDATE/DELETE refusés)."""

    __tablename__ = "stock_movements"
    __table_args__ = (CheckConstraint("quantity > 0", name="quantity_positive"),)
    id: Mapped[uuid.UUID] = uuid_pk()
    seq: Mapped[int] = mapped_column(BigInteger, Identity(always=True), unique=True)
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    movement_type: Mapped[MovementType] = mapped_column(String(20), index=True)
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"), index=True)
    variant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("item_variants.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("lots.id"))
    asset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id"), index=True)
    quantity: Mapped[Decimal] = mapped_column(Qty)
    entered_quantity: Mapped[Decimal | None] = mapped_column(Qty)
    entered_unit: Mapped[str | None] = mapped_column(String(16))
    from_location_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("locations.id"))
    from_status: Mapped[str | None] = mapped_column(String(24))
    to_location_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("locations.id"))
    to_status: Mapped[str | None] = mapped_column(String(24))
    reserved_delta: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    depot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"), index=True)
    counterpart_org_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"))
    source_type: Mapped[str | None] = mapped_column(String(40))
    source_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), index=True)
    source_ref: Mapped[str | None] = mapped_column(String(40))
    corrects_movement_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("stock_movements.id"))
    reason: Mapped[str | None] = mapped_column(Text)
    actor_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    request_id: Mapped[str | None] = mapped_column(String(64))
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)  # horloge métier
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class ReservationStatus(StrEnum):
    ACTIVE = "ACTIVE"
    CONSUMED = "CONSUMED"
    RELEASED = "RELEASED"


class Reservation(Base, Timestamped, Versioned):
    __tablename__ = "reservations"
    __table_args__ = (
        CheckConstraint("quantity > 0", name="quantity_positive"),
        CheckConstraint("consumed + released <= quantity", name="consumption_bounded"),
        CheckConstraint("(request_line_id IS NULL) <> (transfer_line_id IS NULL)", name="single_source"),
    )
    id: Mapped[uuid.UUID] = uuid_pk()
    balance_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("stock_balances.id"))
    depot_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"))
    location_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("locations.id"))
    item_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("items.id"))
    variant_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("item_variants.id"))
    lot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("lots.id"))
    asset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id"))
    request_line_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("request_lines.id"))
    transfer_line_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("transfer_lines.id"))
    quantity: Mapped[Decimal] = mapped_column(Qty)
    consumed: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    released: Mapped[Decimal] = mapped_column(Qty, default=Decimal(0))
    status: Mapped[ReservationStatus] = mapped_column(String(16), default=ReservationStatus.ACTIVE)
    created_by: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))

    @property
    def open_quantity(self) -> Decimal:
        return self.quantity - self.consumed - self.released


class InspectionResult(StrEnum):
    PASS = "PASS"
    PARTIAL = "PARTIAL"
    FAIL = "FAIL"


class Inspection(Base, Timestamped):
    """Contrôle attribué : réception, retour, avant remise à disposition, périodique."""

    __tablename__ = "inspections"
    id: Mapped[uuid.UUID] = uuid_pk()
    reference: Mapped[str] = mapped_column(String(32), unique=True)
    kind: Mapped[str] = mapped_column(String(24))  # RECEIPT | RETURN | PRE_RELEASE | PERIODIC | STOCK
    subject_type: Mapped[str] = mapped_column(String(32))
    subject_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), index=True)
    asset_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("assets.id"), index=True)
    maintenance_order_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("maintenance_orders.id"))
    depot_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("depots.id"))
    result: Mapped[InspectionResult] = mapped_column(String(16))
    accepted_qty: Mapped[Decimal | None] = mapped_column(Qty)
    rejected_qty: Mapped[Decimal | None] = mapped_column(Qty)
    checklist: Mapped[list] = mapped_column(JSONB, default=list)
    findings: Mapped[str] = mapped_column(Text, default="")
    inspector_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    performed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
