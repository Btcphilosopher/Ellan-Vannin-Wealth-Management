"""Service de mouvements de stock — seul point d'écriture des soldes.

Chaque fonction s'exécute dans la transaction de l'appelant : le mouvement, le solde et l'éventuel
exemplaire sont modifiés ensemble ou pas du tout. Les soldes sont verrouillés (SELECT … FOR UPDATE)
et les contraintes CHECK de PostgreSQL interdisent en dernier recours toute quantité disponible négative.
"""
from __future__ import annotations

import re
import unicodedata
import uuid
from decimal import Decimal

from sqlalchemy import and_, func, or_, select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert

from app.core.context import Ctx
from app.core.errors import Conflict, InsufficientStock, NotFound, ValidationFailed
from app.core.refs import next_reference
from app.db import D
from app.modules.catalog.models import Item, Lot, Tracking, UnitOfMeasure
from app.modules.inventory.models import (
    Asset,
    AssetLifecycle,
    CustodyType,
    Depot,
    Location,
    LocationKind,
    MovementType,
    Reservation,
    ReservationStatus,
    StockBalance,
    StockMovement,
    StockStatus,
    TechnicalState,
)

ZERO = Decimal(0)


# ----------------------------------------------------------------------------- utilitaires
def normalize_serial(serial: str) -> str:
    ascii_ = unicodedata.normalize("NFKD", serial).encode("ascii", "ignore").decode()
    return re.sub(r"[^A-Z0-9]", "", ascii_.upper())


def bucket_key(location_id, item_id, variant_id, lot_id, status) -> str:
    return f"{location_id}|{item_id}|{variant_id or '-'}|{lot_id or '-'}|{status}"


def to_base_quantity(ctx: Ctx, item: Item, quantity, unit_code: str | None, *, purpose: str = "receipt") -> Decimal:
    """Convertit une quantité saisie vers l'unité de base. Seules les conversions déclarées sont autorisées."""
    qty = D(quantity)
    if qty <= 0:
        raise ValidationFailed("La quantité doit être strictement positive.")
    unit_code = unit_code or item.base_unit
    if unit_code == item.base_unit:
        base = qty
    else:
        pack = next((p for p in item.packagings if p.unit_code == unit_code), None)
        if pack is None:
            raise ValidationFailed(
                f"Conversion non autorisée : {unit_code} → {item.base_unit} pour l'article {item.code}.",
                code="conversion_interdite",
            )
        if purpose == "receipt" and not pack.allowed_for_receipt or purpose == "issue" and not pack.allowed_for_issue:
            raise ValidationFailed(f"Le conditionnement {unit_code} n'est pas autorisé pour cette opération.")
        if qty != qty.to_integral_value():
            raise ValidationFailed("Un conditionnement se saisit en nombre entier.")
        base = qty * pack.factor
    unit = ctx.db.get(UnitOfMeasure, item.base_unit)
    if unit is not None and not unit.decimals_allowed and base != base.to_integral_value():
        raise ValidationFailed(f"L'unité {item.base_unit} n'accepte pas de décimales.")
    return base


def check_integral(ctx: Ctx, item: Item, qty: Decimal) -> None:
    unit = ctx.db.get(UnitOfMeasure, item.base_unit)
    if unit is not None and not unit.decimals_allowed and qty != qty.to_integral_value():
        raise ValidationFailed(f"L'unité {item.base_unit} n'accepte pas de décimales.")


def location_of_kind(ctx: Ctx, depot_id: uuid.UUID, kind: LocationKind) -> Location:
    loc = ctx.db.execute(
        select(Location).where(Location.depot_id == depot_id, Location.kind == kind, Location.active.is_(True)).order_by(Location.code)
    ).scalars().first()
    if loc is None:
        raise Conflict(f"Le dépôt ne possède pas d'emplacement de type {kind}.")
    return loc


def get_location(ctx: Ctx, location_id: uuid.UUID, depot_id: uuid.UUID | None = None) -> Location:
    loc = ctx.db.get(Location, location_id)
    if loc is None or (depot_id and loc.depot_id != depot_id):
        raise NotFound("Emplacement introuvable dans ce dépôt.")
    return loc


def get_or_create_lot(ctx: Ctx, item: Item, lot_number: str | None, expires_on=None) -> Lot | None:
    if item.tracking != Tracking.LOT:
        if lot_number:
            raise ValidationFailed(f"L'article {item.code} n'est pas suivi par lot.")
        return None
    if not lot_number:
        raise ValidationFailed(f"Numéro de lot obligatoire pour l'article {item.code}.")
    lot = ctx.db.execute(select(Lot).where(Lot.item_id == item.id, Lot.lot_number == lot_number)).scalar_one_or_none()
    if lot is None:
        lot = Lot(id=uuid.uuid4(), item_id=item.id, lot_number=lot_number, expires_on=expires_on)
        ctx.db.add(lot)
        ctx.db.flush()
    return lot


def next_asset_tag(ctx: Ctx) -> str:
    value = ctx.db.execute(
        text(
            "INSERT INTO reference_counters (prefix, year, value) VALUES ('ITD', 0, 1) "
            "ON CONFLICT (prefix, year) DO UPDATE SET value = reference_counters.value + 1 RETURNING value"
        )
    ).scalar_one()
    return f"ITD-A{value:06d}"


def create_asset(ctx: Ctx, item: Item, serial: str, depot_id: uuid.UUID, variant_id=None, lot_id=None) -> Asset:
    if item.tracking != Tracking.SERIAL:
        raise ValidationFailed(f"L'article {item.code} n'est pas suivi par numéro de série.")
    serial = serial.strip()
    if not serial:
        raise ValidationFailed("Numéro de série vide.")
    exists = ctx.db.execute(
        select(Asset.id).where(Asset.item_id == item.id, Asset.serial_normalized == normalize_serial(serial))
    ).first()
    if exists:
        raise Conflict(f"Le numéro de série {serial} existe déjà pour l'article {item.code}.", code="serie_en_double")
    asset = Asset(
        id=uuid.uuid4(),
        item_id=item.id,
        variant_id=variant_id,
        lot_id=lot_id,
        serial_number=serial,
        serial_normalized=normalize_serial(serial),
        internal_tag=next_asset_tag(ctx),
        depot_id=depot_id,
        location_id=None,
        stock_status=None,
        lifecycle=AssetLifecycle.ISSUED,  # provisoire : positionné en stock par le mouvement de réception
        technical_state=TechnicalState.AWAITING_INSPECTION,
        custody_type=CustodyType.NONE,
        received_at=ctx.now,
    )
    return asset


# ----------------------------------------------------------------------------- soldes
def _lock_balance(ctx: Ctx, key: str) -> StockBalance | None:
    """Verrouille la ligne de solde (SELECT … FOR UPDATE).

    Pas de « populate_existing » : si le solde est déjà dans la session, il y a été chargé verrouillé
    plus tôt dans la même transaction et porte nos modifications en attente, qui ne doivent pas être écrasées.
    Convention : aucun chemin d'écriture ne charge un solde sans verrou.
    """
    return ctx.db.execute(
        select(StockBalance)
        .where(StockBalance.bucket_key == key)
        .with_for_update()
    ).scalar_one_or_none()


def _get_or_create_balance(ctx: Ctx, location: Location, item_id, variant_id, lot_id, status) -> StockBalance:
    key = bucket_key(location.id, item_id, variant_id, lot_id, status)
    ctx.db.execute(
        pg_insert(StockBalance)
        .values(
            id=uuid.uuid4(),
            bucket_key=key,
            depot_id=location.depot_id,
            location_id=location.id,
            item_id=item_id,
            variant_id=variant_id,
            lot_id=lot_id,
            stock_status=str(status),
            quantity=0,
            reserved=0,
            version=1,
        )
        .on_conflict_do_nothing(index_elements=["bucket_key"])
    )
    bal = _lock_balance(ctx, key)
    assert bal is not None
    return bal


def post_movement(
    ctx: Ctx,
    *,
    mtype: MovementType,
    item: Item,
    quantity,
    variant_id=None,
    lot_id=None,
    asset: Asset | None = None,
    from_location: Location | None = None,
    from_status: StockStatus | None = None,
    to_location: Location | None = None,
    to_status: StockStatus | None = None,
    release_reserved=ZERO,
    reason: str | None = None,
    source: tuple | None = None,
    corrects_id: uuid.UUID | None = None,
    counterpart_org_id: uuid.UUID | None = None,
    entered: tuple | None = None,
    depot_id: uuid.UUID | None = None,
) -> StockMovement:
    qty = D(quantity)
    release_reserved = D(release_reserved)
    if qty <= 0:
        raise ValidationFailed("Quantité de mouvement nulle ou négative.")
    if from_location is None and to_location is None and not (mtype == MovementType.LOSS and depot_id):
        raise ValidationFailed("Un mouvement physique exige une origine ou une destination.")
    check_integral(ctx, item, qty)
    if item.tracking == Tracking.SERIAL:
        if asset is None or qty != 1:
            raise ValidationFailed("Un article sérialisé se déplace exemplaire par exemplaire (quantité 1).")
        if asset.item_id != item.id:
            raise ValidationFailed("L'exemplaire ne correspond pas à l'article.")
        variant_id, lot_id = asset.variant_id, asset.lot_id
    if item.tracking == Tracking.LOT and lot_id is None:
        raise ValidationFailed(f"Lot obligatoire pour l'article {item.code}.")

    if from_location is not None:
        if from_status is None:
            raise ValidationFailed("Statut d'origine requis.")
        if asset is not None and (asset.location_id != from_location.id or asset.stock_status != from_status):
            raise Conflict(
                f"L'exemplaire {asset.serial_number} n'est pas à l'emplacement/statut indiqué.",
                code="position_exemplaire",
            )
        bal = _lock_balance(ctx, bucket_key(from_location.id, item.id, variant_id, lot_id, from_status))
        if bal is None or bal.quantity < qty:
            raise InsufficientStock(
                f"Stock insuffisant pour {item.code} à l'emplacement {from_location.code} "
                f"(physique {bal.quantity if bal else 0}, demandé {qty}).",
                details={"physical": float(bal.quantity) if bal else 0, "requested": float(qty)},
            )
        new_qty = bal.quantity - qty
        new_reserved = bal.reserved - release_reserved
        if new_reserved < 0:
            raise Conflict("Libération de réservation supérieure à la quantité réservée.")
        if new_qty < new_reserved:
            raise InsufficientStock(
                f"Quantité disponible insuffisante pour {item.code} à {from_location.code} : "
                f"{bal.quantity - bal.reserved} disponible(s), le reste est réservé.",
                details={"available": float(bal.quantity - bal.reserved), "requested": float(qty)},
            )
        bal.quantity = new_qty
        bal.reserved = new_reserved
    elif asset is not None and asset.location_id is not None:
        raise Conflict(f"L'exemplaire {asset.serial_number} est déjà localisé : il ne peut entrer une seconde fois.")

    if to_location is not None:
        if to_status is None:
            raise ValidationFailed("Statut de destination requis.")
        bal_to = _get_or_create_balance(ctx, to_location, item.id, variant_id, lot_id, to_status)
        bal_to.quantity = bal_to.quantity + qty

    if asset is not None:
        asset.location_id = to_location.id if to_location else None
        asset.stock_status = to_status if to_location else None
        if to_location is not None:
            asset.depot_id = to_location.depot_id

    if from_location is not None or to_location is not None:
        depot_id = (from_location or to_location).depot_id
    mv = StockMovement(
        id=uuid.uuid4(),
        reference=next_reference(ctx.db, "movement", ctx.now.year),
        movement_type=mtype,
        item_id=item.id,
        variant_id=variant_id,
        lot_id=lot_id,
        asset_id=asset.id if asset else None,
        quantity=qty,
        entered_quantity=D(entered[0]) if entered else None,
        entered_unit=entered[1] if entered else None,
        from_location_id=from_location.id if from_location else None,
        from_status=str(from_status) if from_status else None,
        to_location_id=to_location.id if to_location else None,
        to_status=str(to_status) if to_status else None,
        reserved_delta=-release_reserved,
        depot_id=depot_id,
        counterpart_org_id=counterpart_org_id,
        source_type=source[0] if source else None,
        source_id=source[1] if source else None,
        source_ref=source[2] if source and len(source) > 2 else None,
        corrects_movement_id=corrects_id,
        reason=reason,
        actor_id=ctx.user_id,
        request_id=ctx.request_id,
        occurred_at=ctx.now,
    )
    ctx.db.add(mv)
    return mv


def _reservation_movement(ctx: Ctx, mtype: MovementType, bal: StockBalance, item: Item, qty: Decimal, asset, source, reason=None):
    loc = ctx.db.get(Location, bal.location_id)
    mv = StockMovement(
        id=uuid.uuid4(),
        reference=next_reference(ctx.db, "movement", ctx.now.year),
        movement_type=mtype,
        item_id=item.id,
        variant_id=bal.variant_id,
        lot_id=bal.lot_id,
        asset_id=asset.id if asset else None,
        quantity=qty,
        from_location_id=loc.id,
        from_status=str(bal.stock_status),
        to_location_id=loc.id,
        to_status=str(bal.stock_status),
        reserved_delta=qty if mtype == MovementType.RESERVE else -qty,
        depot_id=loc.depot_id,
        source_type=source[0],
        source_id=source[1],
        source_ref=source[2] if len(source) > 2 else None,
        reason=reason,
        actor_id=ctx.user_id,
        request_id=ctx.request_id,
        occurred_at=ctx.now,
    )
    ctx.db.add(mv)
    return mv


# ----------------------------------------------------------------------------- réservations
def reserve_stock(
    ctx: Ctx,
    *,
    depot_id: uuid.UUID,
    item: Item,
    variant_id,
    quantity,
    source: tuple,
    request_line_id=None,
    transfer_line_id=None,
    allow_partial: bool = False,
    asset_ids: list | None = None,
) -> tuple[list[Reservation], Decimal]:
    """Réserve du stock utilisable et contrôlé. Les quantités bloquées ou non contrôlées sont exclues."""
    qty = D(quantity)
    if qty <= 0:
        return [], ZERO
    reservations: list[Reservation] = []
    if item.tracking == Tracking.SERIAL:
        q = (
            select(Asset)
            .where(
                Asset.item_id == item.id,
                Asset.depot_id == depot_id,
                Asset.lifecycle == AssetLifecycle.IN_STOCK,
                Asset.stock_status == StockStatus.USABLE,
                Asset.technical_state == TechnicalState.SERVICEABLE,
            )
            .order_by(Asset.internal_tag)
            .with_for_update(skip_locked=True)
        )
        if variant_id:
            q = q.where(Asset.variant_id == variant_id)
        if asset_ids:
            q = q.where(Asset.id.in_(asset_ids))
        assets = list(ctx.db.execute(q.limit(int(qty))).scalars())
        if asset_ids and len(assets) != len(asset_ids):
            raise InsufficientStock("Un ou plusieurs exemplaires demandés ne sont pas disponibles (réservés, bloqués ou non contrôlés).")
        if len(assets) < qty and not allow_partial:
            raise InsufficientStock(
                f"Seulement {len(assets)} exemplaire(s) disponible(s) de {item.code} pour {qty} demandé(s).",
                details={"available": len(assets), "requested": float(qty)},
            )
        for asset in assets:
            bal = _lock_balance(ctx, bucket_key(asset.location_id, item.id, asset.variant_id, asset.lot_id, StockStatus.USABLE))
            if bal is None or bal.quantity - bal.reserved < 1:
                raise Conflict("Incohérence entre exemplaire et solde : opération refusée.")
            bal.reserved += 1
            asset.lifecycle = AssetLifecycle.RESERVED
            res = Reservation(
                id=uuid.uuid4(), balance_id=bal.id, depot_id=depot_id, location_id=bal.location_id, item_id=item.id,
                variant_id=asset.variant_id, lot_id=asset.lot_id, asset_id=asset.id, request_line_id=request_line_id,
                transfer_line_id=transfer_line_id, quantity=Decimal(1), created_by=ctx.user_id,
            )
            ctx.db.add(res)
            reservations.append(res)
            _reservation_movement(ctx, MovementType.RESERVE, bal, item, Decimal(1), asset, source)
        return reservations, Decimal(len(assets))

    lot_alias = Lot
    q = (
        select(StockBalance)
        .outerjoin(lot_alias, lot_alias.id == StockBalance.lot_id)
        .join(Location, Location.id == StockBalance.location_id)
        .where(
            StockBalance.depot_id == depot_id,
            StockBalance.item_id == item.id,
            StockBalance.stock_status == StockStatus.USABLE,
            StockBalance.quantity > StockBalance.reserved,
            Location.kind.in_([LocationKind.STORAGE, LocationKind.RECEIVING]),
        )
        .order_by(lot_alias.expires_on.asc().nulls_last(), Location.kind.desc(), Location.code)
        .with_for_update(of=StockBalance)
    )
    q = q.where(StockBalance.variant_id == variant_id) if variant_id else q.where(StockBalance.variant_id.is_(None))
    balances = list(ctx.db.execute(q).scalars())
    available = sum((b.quantity - b.reserved for b in balances), ZERO)
    if available < qty and not allow_partial:
        raise InsufficientStock(
            f"Disponible insuffisant pour {item.code} : {available} disponible(s) pour {qty} demandé(s).",
            details={"available": float(available), "requested": float(qty)},
        )
    remaining = qty
    for bal in balances:
        if remaining <= 0:
            break
        take = min(remaining, bal.quantity - bal.reserved)
        if take <= 0:
            continue
        bal.reserved += take
        res = Reservation(
            id=uuid.uuid4(), balance_id=bal.id, depot_id=depot_id, location_id=bal.location_id, item_id=item.id,
            variant_id=bal.variant_id, lot_id=bal.lot_id, request_line_id=request_line_id,
            transfer_line_id=transfer_line_id, quantity=take, created_by=ctx.user_id,
        )
        ctx.db.add(res)
        reservations.append(res)
        _reservation_movement(ctx, MovementType.RESERVE, bal, item, take, None, source)
        remaining -= take
    return reservations, qty - remaining


def release_reservation(ctx: Ctx, res: Reservation, quantity=None, *, source: tuple, reason: str | None = None) -> Decimal:
    qty = D(quantity) if quantity is not None else res.open_quantity
    if qty <= 0:
        return ZERO
    if qty > res.open_quantity:
        raise Conflict("Libération supérieure à la quantité réservée restante.")
    bal = ctx.db.execute(
        select(StockBalance).where(StockBalance.id == res.balance_id).with_for_update()
    ).scalar_one()
    bal.reserved -= qty
    res.released += qty
    if res.open_quantity == 0:
        res.status = ReservationStatus.RELEASED if res.consumed == 0 else ReservationStatus.CONSUMED
    item = ctx.db.get(Item, res.item_id)
    asset = ctx.db.get(Asset, res.asset_id) if res.asset_id else None
    if asset is not None:
        asset.lifecycle = AssetLifecycle.IN_STOCK
    _reservation_movement(ctx, MovementType.UNRESERVE, bal, item, qty, asset, source, reason)
    return qty


def consume_reservation(
    ctx: Ctx,
    res: Reservation,
    quantity,
    *,
    mtype: MovementType,
    source: tuple,
    to_location: Location | None = None,
    to_status: StockStatus | None = None,
    counterpart_org_id=None,
    reason=None,
) -> StockMovement:
    """Sortie physique d'une quantité réservée (remise, expédition)."""
    qty = D(quantity)
    if qty <= 0 or qty > res.open_quantity:
        raise Conflict("Quantité supérieure au reliquat réservé.")
    item = ctx.db.get(Item, res.item_id)
    asset = ctx.db.get(Asset, res.asset_id) if res.asset_id else None
    loc = ctx.db.get(Location, res.location_id)
    if asset is not None:
        # L'exemplaire réservé quitte le stock : cycle de vie ajusté par l'appelant.
        asset.lifecycle = AssetLifecycle.IN_STOCK  # transitoire, l'appelant fixe l'état final
    mv = post_movement(
        ctx, mtype=mtype, item=item, quantity=qty, variant_id=res.variant_id, lot_id=res.lot_id, asset=asset,
        from_location=loc, from_status=StockStatus.USABLE, to_location=to_location, to_status=to_status,
        release_reserved=qty, source=source, counterpart_org_id=counterpart_org_id, reason=reason,
    )
    res.consumed += qty
    if res.open_quantity == 0:
        res.status = ReservationStatus.CONSUMED
    return mv


# ----------------------------------------------------------------------------- requalification / contrôle de stock
def change_status(
    ctx: Ctx, *, item: Item, location: Location, from_status: StockStatus, to_status: StockStatus, quantity,
    variant_id=None, lot_id=None, asset=None, source=None, reason=None, mtype=MovementType.STATUS_CHANGE,
    to_location: Location | None = None,
) -> StockMovement:
    return post_movement(
        ctx, mtype=mtype, item=item, quantity=quantity, variant_id=variant_id, lot_id=lot_id, asset=asset,
        from_location=location, from_status=from_status, to_location=to_location or location, to_status=to_status,
        source=source, reason=reason,
    )


# ----------------------------------------------------------------------------- lectures
def stock_overview(ctx: Ctx, depot_ids: set, *, item_id=None, family=None, search=None) -> list[dict]:
    """Synthèse par dépôt × article × variante : physique, réservé, disponible, bloqué, en transit."""
    from app.modules.catalog.models import ItemVariant
    from app.modules.transfers.models import Transfer, TransferLine, TransferStatus

    from sqlalchemy import case

    if not depot_ids:
        return []
    q = (
        select(
            StockBalance.depot_id,
            StockBalance.item_id,
            StockBalance.variant_id,
            func.sum(StockBalance.quantity).label("physical"),
            func.sum(StockBalance.reserved).label("reserved"),
            func.sum(case((StockBalance.stock_status == StockStatus.USABLE, StockBalance.quantity - StockBalance.reserved), else_=0)).label("available"),
            func.sum(case((StockBalance.stock_status != StockStatus.USABLE, StockBalance.quantity), else_=0)).label("blocked"),
        )
        .join(Item, Item.id == StockBalance.item_id)
        .where(StockBalance.depot_id.in_(depot_ids))
        .group_by(StockBalance.depot_id, StockBalance.item_id, StockBalance.variant_id)
    )
    if item_id:
        q = q.where(StockBalance.item_id == item_id)
    if family:
        q = q.where(Item.family_code == family)
    if search:
        like = f"%{search}%"
        q = q.where(or_(Item.code.ilike(like), Item.designation.ilike(like)))
    rows = {(r.depot_id, r.item_id, r.variant_id): dict(r._mapping) for r in ctx.db.execute(q)}

    # En transit : rattaché au dépôt destinataire, jamais compté dans le physique des deux dépôts.
    tq = (
        select(
            Transfer.destination_depot_id,
            TransferLine.item_id,
            TransferLine.variant_id,
            func.sum(TransferLine.shipped_qty - TransferLine.received_qty - TransferLine.damaged_qty - TransferLine.written_off_qty).label("transit"),
        )
        .join(Transfer, Transfer.id == TransferLine.transfer_id)
        .where(Transfer.status.in_([TransferStatus.IN_TRANSIT]), Transfer.destination_depot_id.in_(depot_ids))
        .group_by(Transfer.destination_depot_id, TransferLine.item_id, TransferLine.variant_id)
    )
    if item_id:
        tq = tq.where(TransferLine.item_id == item_id)
    for r in ctx.db.execute(tq):
        key = (r.destination_depot_id, r.item_id, r.variant_id)
        row = rows.setdefault(
            key,
            {"depot_id": key[0], "item_id": key[1], "variant_id": key[2], "physical": ZERO, "reserved": ZERO, "available": ZERO, "blocked": ZERO},
        )
        row["in_transit"] = r.transit
    items = {i.id: i for i in ctx.db.execute(select(Item).where(Item.id.in_({k[1] for k in rows}))).scalars()} if rows else {}
    variants = {v.id: v for v in ctx.db.execute(select(ItemVariant)).scalars()} if rows else {}
    depots = {d.id: d for d in ctx.db.execute(select(Depot)).scalars()}
    out = []
    for key, r in rows.items():
        item = items.get(key[1])
        if item is None or (family and item.family_code != family):
            continue
        v = variants.get(key[2]) if key[2] else None
        out.append(
            {
                "depot_id": key[0], "depot_code": depots[key[0]].code, "depot_name": depots[key[0]].name,
                "item_id": key[1], "item_code": item.code, "designation": item.designation, "family_code": item.family_code,
                "base_unit": item.base_unit, "tracking": item.tracking, "min_stock": item.min_stock,
                "variant_id": key[2], "variant_label": v.label if v else None,
                "physical": r["physical"], "reserved": r["reserved"], "available": r["available"],
                "blocked": r["blocked"], "in_transit": r.get("in_transit", ZERO),
            }
        )
    out.sort(key=lambda r: (r["depot_code"], r["item_code"], r["variant_label"] or ""))
    return out


def asset_label(asset: Asset) -> str:
    return f"{asset.serial_number} ({asset.internal_tag})"


__all__ = [
    "AssetLifecycle", "CustodyType", "MovementType", "StockStatus", "TechnicalState", "and_",
]
